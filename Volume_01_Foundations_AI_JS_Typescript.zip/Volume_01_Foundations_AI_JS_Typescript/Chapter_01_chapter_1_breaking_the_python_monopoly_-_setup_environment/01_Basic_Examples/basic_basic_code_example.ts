/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2025 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

// generateDescription.ts

import { OpenAI } from 'openai';
import * as dotenv from 'dotenv'; 

// 1. Load environment variables from the .env file for local development.
// NOTE: In production environments (like Vercel or AWS), this step is often omitted 
// as variables are injected directly into the runtime environment.
dotenv.config();

/**
 * @typedef {object} Product
 * Defines the strict input structure for the product data payload.
 * Utilizing TypeScript interfaces ensures input validation before the API call.
 */
interface Product {
    name: string;
    features: string[];
    tone: 'professional' | 'witty' | 'casual'; // Using a union type for strict tone control
}

// 2. Initialize the OpenAI client.
// The client automatically reads the OPENAI_API_KEY from process.env.
// This secure, environment-driven initialization is a core best practice.
const openai = new OpenAI();

/**
 * Core business logic function. Generates a marketing description for a product.
 * This function simulates the handler for a secure, authenticated API endpoint.
 *
 * @param {Product} productData - The structured data about the product.
 * @returns {Promise<string>} A promise resolving to the generated product description.
 */
async function generateProductDescription(productData: Product): Promise<string> {
    
    // 3. Construct a clear, structured prompt (System and User roles).
    // Prompt engineering starts with clear instruction and defined variables.
    const featuresList = productData.features.map(f => `- ${f}`).join('\n');
    
    const prompt = `
        You are a professional marketing copywriter. Your task is to generate a concise, 
        compelling product description based on the provided data.

        --- INPUT DATA ---
        Desired Tone: ${productData.tone}
        Product Name: ${productData.name}
        Key Features:
        ${featuresList}
        --- END INPUT DATA ---

        REQUIREMENT: Output ONLY the description text, formatted for a website landing page.
    `;

    console.log(`[INFO] Attempting to generate copy for: ${productData.name}`);

    try {
        // 4. Execute the asynchronous API call using await.
        const completion = await openai.chat.completions.create({
            model: 'gpt-4o-mini', // Using the latest, cost-effective model
            messages: [
                { role: 'system', content: 'You are an expert copywriter focused on clarity and conversion.' },
                { role: 'user', content: prompt },
            ],
            temperature: 0.7, // Balances creativity and adherence to instructions
            max_tokens: 200, // Enforcing a length limit to control cost and response time
            // Future consideration: response_format: { type: "json_object" } for structured output
        });

        // 5. Safely extract the content and perform basic validation.
        const description = completion.choices[0].message.content;

        if (!description) {
            // Handle cases where the API returns a response but the content field is null/empty
            throw new Error("API response content was empty. Check prompt structure.");
        }

        return description.trim(); // Clean up potential leading/trailing whitespace

    } catch (error) {
        // 6. Robust error handling for network issues, API key failures, or rate limits.
        console.error("[CRITICAL ERROR] OpenAI API Call Failed:", error);
        // Re-throw a generic error to prevent leaking internal details to the client.
        throw new Error("AI Service temporary failure. Please try again later.");
    }
}

// 7. Entry point for local execution (simulates the runtime environment calling the function).
async function main() {
    // Sample data payload mimicking a request body from a frontend form submission.
    const sampleProduct: Product = {
        name: "Vector Search TS Engine",
        features: [
            "100% Native TypeScript", 
            "Optimized for Edge Runtime deployment", 
            "Seamless integration with pgvector via Supabase"
        ],
        tone: "professional"
    };

    try {
        console.log(`\nStarting generation for product: ${sampleProduct.name}`);
        const description = await generateProductDescription(sampleProduct);

        console.log("\n=====================================");
        console.log("--- GENERATED MARKETING COPY ---");
        console.log(description);
        console.log("=====================================\n");

    } catch (e) {
        // Catch errors thrown by generateProductDescription
        console.error(`\n[FATAL] Application Execution Halt: ${e.message}`);
        // Exit code 1 indicates an error state to the shell/runtime environment
        process.exit(1); 
    }
}

// Execute the main function
main();
