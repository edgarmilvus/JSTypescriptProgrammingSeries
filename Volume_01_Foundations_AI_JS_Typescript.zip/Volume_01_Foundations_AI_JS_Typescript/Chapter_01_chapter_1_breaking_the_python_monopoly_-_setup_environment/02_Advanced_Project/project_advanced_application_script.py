# These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
# You can find the series on Amazon.
# New books info: https://linktr.ee/edgarmilvus
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import os
import json
from dotenv import load_dotenv
from openai import OpenAI
from typing import Dict, Any

# --- 1. Environment and Client Setup ---

# Load environment variables from a local .env file.
# This ensures the API key is never hardcoded, a critical security practice.
load_dotenv()
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")

if not OPENAI_API_KEY:
    # Fail fast if the required environment variable is missing.
    raise ValueError("OPENAI_API_KEY not found. Please check your .env configuration.")

# Initialize the OpenAI Client instance.
try:
    client = OpenAI(api_key=OPENAI_API_KEY)
except Exception as e:
    print(f"Error initializing OpenAI client. Check API key validity: {e}")
    # In a production environment, this would log the error and exit gracefully.
    exit(1)

# --- 2. Core Service Functions ---

def moderate_content(text: str) -> Dict[str, Any]:
    """
    @function moderate_content
    @description Performs content moderation using the dedicated OpenAI Moderation API.
                 This is the first line of defense against harmful user input.
    @param text: The raw string content submitted by the user.
    @returns: A dictionary indicating safety status and reason.
    """
    print("-> Step 1: Running content moderation check...")
    try:
        # The Moderation API is optimized for speed and cost efficiency.
        response = client.moderations.create(input=text)
        result = response.results[0]
        
        if result.flagged:
            # Output detailed flag categories for logging/review.
            print(f"!!! Content flagged: {result.categories.model_dump_json(indent=2)}")
            return {"safe": False, "reason": "Content flagged by moderation API."}
        
        return {"safe": True, "reason": "Content passed initial moderation."}
    except Exception as e:
        # Handles API connectivity or rate limit errors.
        return {"safe": False, "reason": f"Moderation API error: {e}"}

def summarize_and_categorize(text: str) -> Dict[str, Any]:
    """
    @function summarize_and_categorize
    @description Uses a powerful LLM (gpt-4o-mini) to extract structured data 
                 (summary and category) from safe content.
    @param text: The content string (already confirmed safe).
    @returns: A dictionary containing the structured output or an error message.
    """
    print("-> Step 2: Summarizing and categorizing content...")
    
    # Define a precise system prompt for reliable, predictable output behavior.
    system_prompt = (
        "You are an expert backend content processor for a SaaS platform. Analyze the user's input "
        "and extract a concise summary (max 3 sentences) and the single most "
        "relevant category from the following list: [Feedback, Bug Report, Feature Request, General Inquiry]. "
        "Always respond strictly in the requested JSON format."
    )
    
    try:
        response = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": text}
            ],
            # Enforce JSON output for easy, reliable parsing in the backend.
            response_format={"type": "json_object"} 
        )
        
        # Extract and parse the JSON string response
        json_output = response.choices[0].message.content
        return json.loads(json_output)
        
    except Exception as e:
        return {"error": f"LLM Processing error during chat completion: {e}"}

# --- 3. Main Application Pipeline (The Ingestion Orchestrator) ---

def content_ingestion_pipeline(raw_content: str) -> Dict[str, Any]:
    """
    @function content_ingestion_pipeline
    @description The central orchestration function simulating a microservice endpoint.
    @param raw_content: The text payload received from a user submission endpoint.
    @returns: A standardized response object detailing the outcome of the processing.
    """
    print(f"\n--- Starting Ingestion Pipeline for {len(raw_content)} characters ---")
    
    # 3.1 Moderation Check (Security Gate)
    moderation_result = moderate_content(raw_content)
    
    if not moderation_result["safe"]:
        # Immediate rejection if content is flagged.
        return {
            "status": "REJECTED",
            "reason": moderation_result["reason"],
            "data": None
        }
    
    # 3.2 LLM Processing (Value Extraction)
    processing_data = summarize_and_categorize(raw_content)
    
    if "error" in processing_data:
        # Handles errors during the complex LLM call.
        return {
            "status": "FAILED",
            "reason": processing_data["error"],
            "data": None
        }
        
    # 3.3 Successful Completion
    return {
        "status": "ACCEPTED",
        "reason": "Successfully processed and categorized.",
        "data": processing_data
    }

# --- 4. Execution Example ---

if __name__ == "__main__":
    
    # Example 1: Typical user submission requiring categorization.
    user_input_1 = (
        "The new dark mode feature is fantastic! It really improves usability "
        "during late-night sessions. However, the 'Export CSV' button seems "
        "to be completely broken when I try to use it on Safari. It just hangs. "
        "Please fix this bug quickly."
    )
    
    result_1 = content_ingestion_pipeline(user_input_1)
    print("\n--- RESULT 1 (Successful Ingestion) ---")
    print(json.dumps(result_1, indent=4))

    # Example 2: Short, general inquiry.
    user_input_2 = "Can I integrate this service with my existing payment gateway?"
    result_2 = content_ingestion_pipeline(user_input_2)
    print("\n--- RESULT 2 (General Inquiry) ---")
    print(json.dumps(result_2, indent=4))
