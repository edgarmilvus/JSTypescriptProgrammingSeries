
/*
 * These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
 * You can find the series on Amazon.
 * New books info: https://linktr.ee/edgarmilvus
 *
 * MIT License
 * Copyright (c) 2025 Edgar Milvus
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */

// Source File: solution_exercise_9.ts
// Description: Solution for Exercise 9
// ==========================================

// src/services/openAIService.ts
import OpenAI from 'openai';

// Define a custom error for clear backend configuration failures
class ServiceInitializationError extends Error {
    constructor(message: string) {
        super(message);
        this.name = 'ServiceInitializationError';
    }
}

/**
 * Initializes the OpenAI client securely using environment variables.
 * @returns A configured OpenAI client instance.
 * @throws ServiceInitializationError if the API key is missing.
 */
export function initializeOpenAIClient(): OpenAI {
    // Read the key internally from the backend environment
    const apiKey = process.env.OPENAI_API_KEY;

    // Critical configuration check
    if (!apiKey) {
        throw new ServiceInitializationError(
            "OPENAI_API_KEY is not set. Cannot initialize OpenAI service layer."
        );
    }

    // Key is used here, encapsulated within the backend service
    const openai = new OpenAI({ apiKey });
    
    return openai;
}

export { ServiceInitializationError };
