/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2025 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// src/bootstrap.ts
import * as dotenv from 'dotenv';
import OpenAI from 'openai';

// 1. Secure Loading: Load environment variables immediately
dotenv.config();

async function validateApiKey() {
    // 2. Validation Logic: Check for key existence
    const apiKey = process.env.OPENAI_API_KEY;

    if (!apiKey) {
        // Fail fast if the configuration is missing
        throw new Error("Critical: OPENAI_API_KEY not found. Check .env file configuration.");
    }

    try {
        // 3. Initialize Client using the securely loaded environment variable
        const openai = new new OpenAI({ apiKey });

        // 4. Execute simplest possible API call (e.g., list models)
        // This confirms connectivity and key validity.
        await openai.models.list();

        // 5. Success Output
        console.log("AetherAuth Initialized. API Key validated successfully.");

    } catch (error) {
        // Catch authentication errors (e.g., 401 Unauthorized) or network issues
        console.error("API Key Validation Failed. Check key validity and network connection.");
        // Log the underlying error message for debugging
        console.error("Error Details:", error.message);
        process.exit(1);
    }
}

validateApiKey();

// To run: npm run validate:env (assuming "validate:env": "ts-node src/bootstrap.ts" in package.json)
