/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2025 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part10.ts
// Description: Solutions and Explanations
// ==========================================

// src/main.ts
import * as dotenv from 'dotenv';
import { initializeOpenAIClient, ServiceInitializationError } from './services/openAIService';
import OpenAI from 'openai';

// Load environment variables at the application entry point
dotenv.config();

function runServiceTest() {
    let client: OpenAI | null = null;
    try {
        client = initializeOpenAIClient();
        
        if (client instanceof OpenAI) {
            console.log("OpenAI Service Layer Test Successful.");
            console.log("Client instance created and securely configured, ready for API calls.");
        }

    } catch (error) {
        if (error instanceof ServiceInitializationError) {
            console.error(`[CRITICAL ERROR] Service failed to start: ${error.message}`);
        } else {
            console.error("An unexpected error occurred during service initialization:", error);
        }
        process.exit(1);
    }
}

runServiceTest();
