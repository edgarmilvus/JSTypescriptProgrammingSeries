/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2025 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

// Filename: assistantService.ts
import * as dotenv from 'dotenv';
// Load environment variables from .env file immediately
dotenv.config();

// --- 1. Define Response Structure using TypeScript Interfaces ---

/**
 * Defines the expected structure of the successful response payload
 * from the OpenAI Chat Completions API.
 * This enables robust Type Narrowing later in the code.
 */
interface ChatCompletionResponse {
    id: string;
    object: 'chat.completion';
    created: number;
    model: string;
    choices: Array<{
        index: number;
        message: {
            role: 'assistant';
            content: string;
        };
        logprobs: null;
        finish_reason: string;
    }>;
    usage: {
        prompt_tokens: number;
        completion_tokens: number;
        total_tokens: number;
    };
}

// --- 2. The Core API Interaction Function ---

/**
 * Sends a user prompt to the OpenAI Chat Completions API using native fetch.
 * This simulates the backend logic for a SaaS feature.
 *
 * @param userPrompt The text input provided by the end-user.
 * @returns A promise resolving to the assistant's response content (string).
 */
async function getAIAssistantResponse(userPrompt: string): Promise<string> {
    // Retrieve sensitive configuration securely from environment variables
    const apiKey = process.env.OPENAI_API_KEY;
    const apiUrl = 'https://api.openai.com/v1/chat/completions';

    // Critical Security and Configuration Check
    if (!apiKey) {
        console.error("Configuration Error: OPENAI_API_KEY is not set.");
        // Return a user-friendly error message, logging the technical error internally
        return "Error: The backend service is improperly configured. Please contact support.";
    }

    // Basic Input Validation
    if (!userPrompt || userPrompt.trim().length === 0) {
         return "Error: Your query cannot be empty.";
    }

    try {
        // Construct the Request Body (Payload)
        const requestBody = JSON.stringify({
            // Use a specific, cost-effective model
            model: "gpt-4o-mini",
            // Define the conversation context using the 'messages' array
            messages: [
                // System message sets the persona and constraints
                { role: "system", content: "You are a helpful, concise SaaS onboarding assistant for a project management tool. Keep answers under 50 words." },
                // User message contains the actual query
                { role: "user", content: userPrompt }
            ],
            // Controls randomness (0.0 is deterministic, 1.0 is creative)
            temperature: 0.7,
            // Limit the length of the AI's response to manage costs and latency
            max_tokens: 150,
        });

        // --- Execute the HTTP Request using fetch ---
        const response = await fetch(apiUrl, {
            method: 'POST',
            // Define required headers
            headers: {
                'Content-Type': 'application/json',
                // CRITICAL: Authentication via the Authorization header (Bearer token scheme)
                'Authorization': `Bearer ${apiKey}`,
                // Optional: For organizations, passing the organization ID is recommended
                // 'OpenAI-Organization': process.env.OPENAI_ORG_ID,
            },
            body: requestBody,
        });

        // --- 3. Handle HTTP Errors (Status codes 4xx, 5xx) ---
        if (!response.ok) {
            // Attempt to parse the error response body for detailed debugging
            const errorData = await response.json();
            console.error(`OpenAI API Request Failed (Status: ${response.status}):`, errorData);

            // Specific handling for common errors (e.g., 429 Rate Limit, 401 Auth)
            if (response.status === 401) {
                throw new Error("Authentication failed. Check API key validity.");
            }
            if (response.status === 429) {
                throw new Error("Rate limit exceeded. Please try again shortly.");
            }

            // Throw a generic error for the catch block
            throw new Error(`OpenAI API failed with status ${response.status}.`);
        }

        // --- 4. Parse and Validate Response ---
        // Cast the parsed JSON data to the defined TypeScript interface
        const data: ChatCompletionResponse = await response.json();

        // Use Type Narrowing and Optional Chaining (?.) to safely extract content
        const assistantMessage = data.choices[0]?.message?.content;

        // Final content validation
        if (!assistantMessage) {
            console.warn("API response structure was unexpected or content was missing.");
            return "Error: The AI generated an empty response.";
        }

        return assistantMessage.trim();

    } catch (error) {
        // 5. Catch Network or Unexpected Errors (e.g., DNS failure, JSON parsing failure)
        const errorMessage = error instanceof Error ? error.message : "Unknown API communication error.";
        console.error("An unexpected runtime error occurred:", errorMessage);
        // Return a safe, generic error message to the user/client
        return "Error: Failed to process the request due to a server issue.";
    }
}

// --- Execution Simulation ---
async function main() {
    console.log("=================================================");
    console.log("SaaS Backend Service: AI Assistant Initialization");
    console.log("=================================================");

    const userQuery = "How do I invite a new team member to my project board?";
    console.log(`\n[User Query]: "${userQuery}"`);

    const startTime = process.hrtime.bigint();
    const result = await getAIAssistantResponse(userQuery);
    const endTime = process.hrtime.bigint();
    
    // Demonstrate basic performance measurement (relevant to V8 efficiency)
    const durationMs = Number(endTime - startTime) / 1_000_000;

    console.log("\n[AI Assistant Response]:");
    console.log("-------------------------------------------------");
    console.log(result);
    console.log("-------------------------------------------------");
    console.log(`\nLatency (V8 Execution Time): ${durationMs.toFixed(2)} ms`);
}

main();
