# These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
# You can find the series on Amazon.
# New books info: https://linktr.ee/edgarmilvus
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

# ----------------------------------------------------------------------
# Python Script: SaaS Content Standardization Microservice
# Goal: Analyze raw product descriptions and enforce structured JSON output.
# Demonstrates: Secure API Key handling, Structured JSON output (via Pydantic), and basic Streaming.
# ----------------------------------------------------------------------
import os
import json
from pydantic import BaseModel, Field
from openai import OpenAI, APIError
from dotenv import load_dotenv
import sys

# Load environment variables from .env file for secure key management.
# This practice is analogous to using environment variables in a Next.js server environment.
load_dotenv()

# --- 1. Configuration & Security ---
# Retrieve the API key securely. Server-side execution is mandatory for this key.
API_KEY = os.getenv("OPENAI_API_KEY")
if not API_KEY:
    # Error handling for missing critical configuration
    print("Error: OPENAI_API_KEY not found. Please set it securely in your server environment.", file=sys.stderr)
    sys.exit(1)

# Initialize the OpenAI Client (SDK approach)
# The SDK automatically handles connection pooling, authentication headers, and request retries,
# significantly improving reliability and reducing boilerplate compared to raw fetch calls.
client = OpenAI(api_key=API_KEY)

# --- 2. Defining the Structured Output Schema (Pydantic) ---
# This mirrors the critical role of Zod in TypeScript/LangChain.js development:
# ensuring the AI's output conforms to a predictable, robust data structure.
class ProductAnalysis(BaseModel):
    """Schema for standardized product analysis output."""
    # JSDoc equivalent description for clarity and AI instruction
    product_name: str = Field(description="The standardized, short, and optimized name of the product.")
    tone_classification: str = Field(description="The primary tone of the description (e.g., 'Formal', 'Playful', 'Technical', 'Luxury').")
    key_features: list[str] = Field(description="A list of 3 to 5 critical selling points, extracted verbatim or slightly rephrased.")
    seo_summary: str = Field(description="A concise, SEO-optimized summary suitable for a meta description (under 25 words).")
    confidence_score: float = Field(description="A numerical score from 0.0 to 1.0 indicating the model's confidence in the accuracy of the extraction.")

# --- 3. Core Synchronous Function: Structured Analysis ---

def analyze_product_description_structured(description: str) -> ProductAnalysis | None:
    """
    Executes a synchronous API call, forcing the model to adhere to the defined Pydantic schema.
    This is essential for reliable data ingestion into a database or application state.
    """
    print(f"\n[SYNC CALL] Initiating structured analysis for: '{description[:45]}...'")

    system_prompt = (
        "You are an expert e-commerce content standardizer and data extraction engine. "
        "Analyze the provided product description and output the analysis strictly "
        "in the required JSON format based on the defined schema. Do not include any preamble, "
        "markdown wrappers (like 