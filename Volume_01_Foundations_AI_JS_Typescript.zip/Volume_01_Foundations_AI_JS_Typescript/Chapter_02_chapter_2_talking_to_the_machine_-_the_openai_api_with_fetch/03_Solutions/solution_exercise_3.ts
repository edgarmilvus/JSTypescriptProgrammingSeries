
/*
 * These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
 * You can find the series on Amazon.
 * New books info: https://linktr.ee/edgarmilvus
 *
 * MIT License
 * Copyright (c) 2025 Edgar Milvus
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */

// Source File: solution_exercise_3.ts
// Description: Solution for Exercise 3
// ==========================================

import OpenAI from 'openai';

// Define a custom error class for environment issues
class MissingAPIKeyError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "MissingAPIKeyError";
  }
}

// Initialize client outside the function for efficiency, but only if key exists
let openai: OpenAI | null = null;
if (process.env.OPENAI_API_KEY) {
  openai = new OpenAI();
}

async function safeCompletion(prompt: string): Promise<string> {
  // 1. Pre-flight Key Check
  if (!process.env.OPENAI_API_KEY || !openai) {
    throw new MissingAPIKeyError(
      "The OpenAI API Key is missing. Please set the OPENAI_API_KEY environment variable."
    );
  }

  try {
    const completion = await openai.chat.completions.create({
      model: "gpt-3.5-turbo",
      messages: [{ role: "user", content: prompt }],
    });

    const content = completion.choices[0].message.content;
    if (content === null) {
      throw new Error("Model returned null content.");
    }
    return content;

  } catch (error) {
    // 2. Structured API Error Handling
    if (error instanceof OpenAI.APIError) {
      // 3. Specific Error Reporting based on status code
      switch (error.status) {
        case 401:
          console.error("Authentication Error: The API key is invalid or expired.");
          throw new Error("API Authentication Failed (401). Check your key.");
        case 429:
          console.error("Rate Limit Error: Too many requests. Wait and retry.");
          throw new Error("API Rate Limit Exceeded (429).");
        case 500:
        case 503:
          console.error("Server Error: OpenAI service is currently unavailable.");
          throw new Error("OpenAI Service Unavailable (5xx).");
        default:
          console.error(`Unhandled API Error (${error.status}):`, error.message);
          throw new Error(`OpenAI API Error: ${error.message}`);
      }
    }

    // 4. Catch all other generic errors (e.g., network timeout, JSON parsing issues)
    console.error("Generic Error during API call:", error);
    throw new Error(`A network or unknown error occurred: ${error instanceof Error ? error.message : String(error)}`);
  }
}

// Example usage:
// safeCompletion("Why is structured error handling important?")
//   .then(console.log)
//   .catch(e => console.error(`[FATAL] ${e.message}`));
