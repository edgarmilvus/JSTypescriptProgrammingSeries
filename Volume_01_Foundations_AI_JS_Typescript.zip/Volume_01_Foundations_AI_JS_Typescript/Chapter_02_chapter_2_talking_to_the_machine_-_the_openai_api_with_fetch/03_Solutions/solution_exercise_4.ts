
/*
 * These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
 * You can find the series on Amazon.
 * New books info: https://linktr.ee/edgarmilvus
 *
 * MIT License
 * Copyright (c) 2025 Edgar Milvus
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */

// Source File: solution_exercise_4.ts
// Description: Solution for Exercise 4
// ==========================================

import OpenAI from 'openai';

interface Recipe {
  recipeName: string;
  prepTimeMinutes: number;
  ingredients: string[];
}

const openai = new OpenAI();

async function generateRecipeJson(dishName: string): Promise<Recipe> {
  // 1. Define the system prompt requiring strict JSON adherence
  const systemPrompt = `You are a helpful culinary assistant. Generate a recipe for "${dishName}" strictly in the following JSON format. Do not include any text outside the JSON object.
    {
      "recipeName": "string",
      "prepTimeMinutes": "number",
      "ingredients": ["string", "string", ...]
    }`;

  const completion = await openai.chat.completions.create({
    model: "gpt-3.5-turbo-1106", // Use a model optimized for JSON output
    messages: [
      { role: "system", content: systemPrompt },
      { role: "user", content: `Generate a simple recipe for ${dishName}.` }
    ],
    // 3. Enforce JSON output type
    response_format: { type: "json_object" },
    temperature: 0.5,
  });

  const jsonString = completion.choices[0].message.content;

  if (!jsonString) {
    throw new Error("Model failed to return a JSON string.");
  }

  // 4. Parse the raw string output
  const recipeObject: unknown = JSON.parse(jsonString);

  // 5. Robustness Check (Type guard/runtime validation)
  if (
    typeof recipeObject === 'object' && recipeObject !== null &&
    'recipeName' in recipeObject &&
    'prepTimeMinutes' in recipeObject &&
    'ingredients' in recipeObject &&
    Array.isArray((recipeObject as Recipe).ingredients)
  ) {
    return recipeObject as Recipe;
  } else {
    throw new Error("Parsed JSON did not match the expected Recipe structure.");
  }
}

// Example usage:
// generateRecipeJson("Spicy Tofu Stir Fry")
//   .then(recipe => {
//     console.log("Generated Recipe:", recipe);
//     console.log("Prep Time:", recipe.prepTimeMinutes, "minutes");
//   })
//   .catch(console.error);
