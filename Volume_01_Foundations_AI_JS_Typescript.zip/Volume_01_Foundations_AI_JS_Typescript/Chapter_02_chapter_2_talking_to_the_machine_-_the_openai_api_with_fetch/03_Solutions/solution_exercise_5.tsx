
/*
 * These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
 * You can find the series on Amazon.
 * New books info: https://linktr.ee/edgarmilvus
 *
 * MIT License
 * Copyright (c) 2025 Edgar Milvus
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */

// Source File: solution_exercise_5.tsx
// Description: Solution for Exercise 5
// ==========================================

// =================================================================
// PART 1: Server Action (Simulated Next.js Server Side Logic)
// This file runs on the server.
// =================================================================
import OpenAI from 'openai';
import { Writable } from 'stream';

const openai = new OpenAI();

// Server Action function signature for streaming data
export async function streamCompletion(prompt: string): Promise<ReadableStream> {
  // 1. Streaming SDK Call
  const stream = await openai.chat.completions.create({
    model: 'gpt-3.5-turbo',
    messages: [{ role: 'user', content: prompt }],
    stream: true, // Crucial for streaming
  });

  // Convert the SDK's AsyncIterable stream into a standard Web ReadableStream
  const encoder = new TextEncoder();
  
  return new ReadableStream({
    async start(controller) {
      try {
        // 2. Chunk Processing: Iterate over the stream
        for await (const chunk of stream) {
          const content = chunk.choices[0]?.delta?.content || '';
          if (content) {
            // Yield the content chunk as raw text
            controller.enqueue(encoder.encode(content));
          }
        }
        controller.close();
      } catch (error) {
        // 3. Error Handling during streaming
        console.error("Streaming error occurred:", error);
        // Send an error signal or specific message to the client
        controller.error(new Error("Stream failed due to an API error."));
      }
    },
  });
}

// =================================================================
// PART 2: Client Component (Simulated React Component)
// This file runs in the browser.
// =================================================================
/**
 * NOTE: This requires a framework like Next.js that supports Server Actions
 * and consuming ReadableStreams in the client.
 */
import React, { useState, useCallback } from 'react';
// import { streamCompletion } from './server-actions'; // Assume import

function LiveChatDisplay({ initialPrompt }: { initialPrompt: string }) {
  const [responseText, setResponseText] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  // 2. Incremental Update Logic
  const handleStream = useCallback(async () => {
    setIsLoading(true);
    setResponseText('');
    
    try {
      // Call the Server Action which returns a ReadableStream
      const stream = await streamCompletion(initialPrompt); 
      
      const reader = stream.getReader();
      const decoder = new TextDecoder();
      
      let done = false;
      while (!done) {
        const { value, done: streamDone } = await reader.read();
        done = streamDone;

        if (value) {
          const chunk = decoder.decode(value, { stream: true });
          // Append the new tokens to the state
          setResponseText(prev => prev + chunk);
        }
      }
    } catch (error) {
      console.error("Client stream consumption failed:", error);
      setResponseText(prev => prev + "\n\n[ERROR: Could not complete response.]");
    } finally {
      // 3. Visual Feedback
      setIsLoading(false);
    }
  }, [initialPrompt]);

  return (
    <div>
      <button onClick={handleStream} disabled={isLoading}>
        {isLoading ? 'Streaming...' : 'Start Streaming Response'}
      </button>
      <div style={{ marginTop: '20px', border: '1px solid #ccc', padding: '10px' }}>
        <strong>Prompt:</strong> {initialPrompt}
        <hr />
        <strong>Response:</strong> {responseText || (isLoading ? '...' : 'Click Start')}
      </div>
    </div>
  );
}

// export default LiveChatDisplay;
