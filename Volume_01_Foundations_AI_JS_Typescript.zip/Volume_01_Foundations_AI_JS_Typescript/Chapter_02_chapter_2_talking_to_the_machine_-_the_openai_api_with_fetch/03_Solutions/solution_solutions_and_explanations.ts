/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2025 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// NOTE: This solution uses TypeScript/JavaScript as required by the exercise context (fetch, environment, SDK).
// Ensure OPENAI_API_KEY is set in your environment.

async function fetchCompletion(prompt: string): Promise<string> {
  const apiKey = process.env.OPENAI_API_KEY;
  if (!apiKey) {
    throw new Error("OPENAI_API_KEY environment variable is not set.");
  }

  const API_URL = "https://api.openai.com/v1/chat/completions";

  const payload = {
    model: "gpt-3.5-turbo",
    messages: [
      { role: "user", content: prompt }
    ],
    temperature: 0.7,
    max_tokens: 150,
  };

  const response = await fetch(API_URL, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${apiKey}`,
    },
    body: JSON.stringify(payload),
  });

  // 4. Response Handling (Manual JSON Parsing)
  if (!response.ok) {
    // Read the response body to extract the API error message
    const errorBody = await response.json();
    const statusCode = response.status;
    const errorMessage = errorBody.error?.message || `Unknown API Error (Status: ${statusCode})`;
    throw new Error(`OpenAI API Request Failed (${statusCode}): ${errorMessage}`);
  }

  // Parse the successful response
  const data = await response.json();

  // Navigate the nested structure to get the content
  const content = data.choices?.[0]?.message?.content;

  if (typeof content !== 'string') {
    throw new Error("Failed to extract text content from API response.");
  }

  return content;
}

// Example usage (requires environment setup):
// fetchCompletion("Explain the concept of zero-shot learning in one sentence.")
//   .then(console.log)
//   .catch(console.error);
