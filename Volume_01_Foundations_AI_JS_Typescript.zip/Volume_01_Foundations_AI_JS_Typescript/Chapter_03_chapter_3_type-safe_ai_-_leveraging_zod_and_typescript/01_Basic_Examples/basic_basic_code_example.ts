/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2025 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

// basic-zod-validation.ts

/**
 * 1. Zod Schema Definition
 * We import 'z' to define our runtime data structure contract.
 */
import { z } from "zod";

/**
 * @description Defines the strict schema for a product feature summary.
 * This schema acts as the contract that the LLM MUST adhere to.
 */
const FeatureSummarySchema = z.object({
    /** The internal, unique identifier for the feature. Must be a string. */
    featureId: z.string().uuid("Feature ID must be a valid UUID format."),

    /** The display name of the feature. */
    name: z.string().min(3, "Name must be at least 3 characters long."),

    /** A brief, non-empty description of the feature's purpose. */
    description: z.string().min(20, "Description must be detailed (min 20 chars)."),

    /** 
     * The current deployment status. 
     * Using z.enum enforces that the value can ONLY be one of these three strings, 
     * preventing the LLM from inventing statuses like 'WIP' or 'Testing_Phase'.
     */
    status: z.enum(['BETA', 'LIVE', 'DEPRECATED']),

    /** The version number associated with this feature summary. Optional field. */
    version: z.number().optional(),
});

/**
 * 2. TypeScript Type Inference
 * We use z.infer to automatically create the TypeScript type from the Zod schema.
 * This ensures that the compile-time type definition is always synchronized with 
 * the runtime validation logic.
 */
type FeatureSummary = z.infer<typeof FeatureSummarySchema>;

// --- Simulated LLM Responses ---

// Case A: Perfect, valid output adhering strictly to the schema.
const goodLLMResponse = `{
    "featureId": "a1b2c3d4-e5f6-7890-1234-567890abcdef",
    "name": "Intelligent Dark Mode",
    "description": "A new feature that automatically adjusts color palettes based on ambient light conditions and user preference history.",
    "status": "LIVE"
}`;

// Case B: Invalid output (simulating LLM hallucination or error).
// Issues: 
// 1. 'status' is a number (1) but should be an enum string ('BETA', 'LIVE', 'DEPRECATED').
// 2. 'name' is too short (fails min(3) constraint).
const badLLMResponse = `{
    "featureId": "invalid-uuid-format", 
    "name": "DM",
    "description": "Short description.",
    "status": 1,
    "version": "1.0.0" 
}`;

/**
 * 3. Validation and Type Narrowing Function
 * @param jsonString The raw, untrusted JSON string from the LLM.
 * @returns The validated FeatureSummary object or null if validation fails.
 */
function parseLLMResponse(jsonString: string): FeatureSummary | null {
    console.log(`\n--- Attempting to Parse Response ---`);
    
    // Step 3a: Initial JSON parsing (must handle potential syntax errors first)
    let parsedObject: unknown;
    try {
        parsedObject = JSON.parse(jsonString);
    } catch (error) {
        console.error("CRITICAL ERROR: Failed to parse raw JSON string (Syntax error).");
        return null;
    }

    // Step 3b: Zod Runtime Validation using safeParse
    const result = FeatureSummarySchema.safeParse(parsedObject);

    // Step 3c: Type Guard and Type Narrowing
    if (result.success) {
        // TypeScript now knows 'result.data' is of type FeatureSummary.
        console.log(`SUCCESS: Data validated and type-narrowed.`);
        return result.data;
    } else {
        // The failure case provides detailed Zod error information.
        console.error(`VALIDATION FAILED: Data structure is incorrect.`);
        // result.error is of type ZodError
        console.error(JSON.stringify(result.error.issues, null, 2));
        return null;
    }
}

// --- Execution ---

console.log("--- Running Case A (Good Data) ---");
const validFeature = parseLLMResponse(goodLLMResponse);

if (validFeature) {
    // We can safely access properties without runtime checks because Zod guaranteed them.
    // The compiler knows validFeature.status is 'LIVE', 'BETA', or 'DEPRECATED'.
    console.log(`\nApplication Logic Activated: Feature '${validFeature.name}' is ready.`);
    console.log(`Status Check: ${validFeature.status}`);
}

console.log("\n===================================");

console.log("--- Running Case B (Bad Data) ---");
const invalidFeature = parseLLMResponse(badLLMResponse);

if (invalidFeature === null) {
    console.log("\nApplication Logic Blocked: Cannot proceed with invalid AI data.");
} else {
    // This block is unreachable, demonstrating the effectiveness of the type guard.
    console.log("ERROR: This should not happen.");
}
