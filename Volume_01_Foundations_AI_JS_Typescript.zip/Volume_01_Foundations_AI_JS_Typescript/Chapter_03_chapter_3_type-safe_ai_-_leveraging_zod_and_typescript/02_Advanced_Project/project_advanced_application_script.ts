/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2025 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// feature-parser.ts
// Uses Zod for schema definition and runtime validation of LLM output.

import { z } from 'zod';
import OpenAI from 'openai';
import 'dotenv/config'; // Utility to load environment variables (.env)

// --- 1. Initialization and Configuration ---

/**
 * @description Initializes the OpenAI client using the API key from environment variables.
 * We enforce a strict configuration environment for production readiness.
 */
const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

// --- 2. Zod Schema Definition (The Contract) ---

/**
 * @description Defines the strict schema for parsing feature request analysis from the LLM.
 * This schema dictates the exact structure, types, and allowed values (enums)
 * required by our internal ticketing database. The .strict() modifier prevents
 * the LLM from injecting unexpected fields.
 */
const FeatureRequestSchema = z.object({
  // UUID for tracking the request internally. LLM must generate this.
  id: z.string().uuid().describe("A unique UUID generated for this request."),

  // Category must be one of these specific string literals (enum).
  category: z.enum(['UI/UX', 'Performance', 'Security', 'Data_Model', 'Integration'])
    .describe("The primary functional area this request impacts."),

  // Priority dictates immediate business urgency.
  priority: z.enum(['Low', 'Medium', 'High', 'Critical'])
    .describe("The business urgency of implementing this feature."),

  // Summary must be constrained in length for dashboard display.
  summary: z.string().min(10).max(200)
    .describe("A concise, single-sentence summary of the request."),

  // Array of affected components, maximum of five entries.
  affectedComponents: z.array(z.string()).max(5)
    .describe("A list of specific application components or screens affected (e.g., 'Dashboard', 'Settings API')."),

  // Boolean flag indicating immediate readiness for development.
  isActionable: z.boolean()
    .describe("True if the request is clear enough to be assigned to a developer; false otherwise."),
}).strict();

// --- 3. TypeScript Type Inference ---

/**
 * @typedef {z.infer<typeof FeatureRequestSchema>} ParsedFeatureRequest
 * @description Automatically infers the TypeScript type from the Zod schema,
 * ensuring compile-time safety matches our runtime validation contract.
 */
type ParsedFeatureRequest = z.infer<typeof FeatureRequestSchema>;

// --- 4. System Prompt Definition ---

const SYSTEM_PROMPT = `
  You are an expert SaaS Product Manager AI. Your task is to analyze raw user feedback and structure it into a strict JSON object for our internal ticketing system.
  Adhere strictly to the provided JSON schema. Do not include any explanatory text outside of the JSON object.
  If a field requires a specific enum value (e.g., 'priority'), you MUST use one of the defined values exactly as written.
  Generate a unique UUID for the 'id' field using a standard UUID format.
`;

/**
 * @async
 * @function parseFeatureRequest
 * @description Fetches analysis from OpenAI using JSON mode and validates the structure using Zod.
 * @param {string} rawDescription - The raw text input from the user.
 * @returns {Promise<ParsedFeatureRequest>} The validated, type-safe feature request object.
 * @throws {Error} If the API call fails or Zod validation fails.
 */
async function parseFeatureRequest(rawDescription: string): Promise<ParsedFeatureRequest> {
  console.log(`\n[INFO] Starting analysis for request: "${rawDescription.substring(0, 70)}..."`);

  // 5. API Call Execution (Enforcing JSON Output)
  const response = await openai.chat.completions.create({
    model: 'gpt-4o-mini',
    messages: [
      { role: 'system', content: SYSTEM_PROMPT },
      { role: 'user', content: `Analyze the following user request: ${rawDescription}` },
    ],
    response_format: { type: 'json_object' }, // CRITICAL: Instructs OpenAI to guarantee JSON output
    temperature: 0.0, // Low temperature ensures deterministic, structured responses
  });

  const rawJsonText = response.choices[0].message.content;

  if (!rawJsonText) {
    throw new Error("LLM returned an empty response, cannot proceed with parsing.");
  }

  // 6. Runtime Validation and Type Guard Implementation
  try {
    // Attempt to parse the raw string into a JavaScript object
    const parsedObject = JSON.parse(rawJsonText);

    // Zod validation: This is the critical Type Guard. If it passes, the data
    // is guaranteed to conform to FeatureRequestSchema.
    const validatedData = FeatureRequestSchema.parse(parsedObject);

    console.log(`[SUCCESS] Data validated and parsed successfully by Zod.`);
    // The return value 'validatedData' is now guaranteed to be of type ParsedFeatureRequest.
    return validatedData;

  } catch (error) {
    // Handle specific Zod validation failures, providing detailed feedback
    if (error instanceof z.ZodError) {
      console.error("\n[ERROR] Zod Validation Failed: The LLM output did not match the required schema.");
      // Throw a specific error detailing the first encountered issue
      throw new Error(`Invalid AI output structure: Constraint violation on field '${error.issues[0].path.join('.')}' - ${error.issues[0].message}`);
    }
    // Handle generic JSON parsing errors (e.g., malformed JSON string)
    console.error("[ERROR] Generic JSON Parsing Failed:", error);
    throw new Error("Could not parse raw LLM output into a valid JSON object.");
  }
}

// --- 7. Execution and Type Narrowing Demonstration ---

async function main() {
  // A complex user request touching multiple domains (Performance and UI/UX)
  const userRequest = "The dashboard load time is terrible, especially when I have more than 100 active users. We need to optimize the database query that fetches the user count summary. Also, the button to export data is missing its icon and looks misaligned.";

  try {
    const result = await parseFeatureRequest(userRequest);

    console.log("\n--- Final Type-Safe Result ---");
    console.log(`ID: ${result.id}`);
    console.log(`Category: ${result.category}`);
    console.log(`Priority: ${result.priority}`);
    console.log(`Summary: ${result.summary}`);
    console.log(`Actionable: ${result.isActionable ? 'Yes' : 'No'}`);
    console.log("Components Affected:", result.affectedComponents.join(', '));

    // Type Narrowing Example:
    // Because Zod guaranteed the 'priority' field is one of the enum values,
    // TypeScript can safely narrow the type within this conditional block.
    if (result.priority === 'Critical' || result.priority === 'High') {
         console.log("\n[ALERT] This is a high-priority ticket. Triggering immediate notification.");
         // We can safely call priority-specific functions here without runtime checks.
    } else if (result.category === 'Security') {
         // This block only executes if the type is exactly 'Security'.
         console.log("\n[SECURITY AUDIT REQUIRED] Flagging for immediate security review.");
    }

  } catch (e) {
    // Catch the detailed error thrown by the Zod validation logic
    if (e instanceof Error) {
        console.error(`\nApplication failure: ${e.message}`);
    } else {
        console.error("\nAn unknown error occurred during processing.");
    }
  }
}

main();
