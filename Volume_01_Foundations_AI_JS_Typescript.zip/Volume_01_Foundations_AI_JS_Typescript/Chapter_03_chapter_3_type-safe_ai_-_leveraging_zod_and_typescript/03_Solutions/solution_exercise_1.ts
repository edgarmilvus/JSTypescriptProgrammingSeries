
/*
 * These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
 * You can find the series on Amazon.
 * New books info: https://linktr.ee/edgarmilvus
 *
 * MIT License
 * Copyright (c) 2025 Edgar Milvus
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */

// Source File: solution_exercise_1.ts
// Description: Solution for Exercise 1
// ==========================================

import { z } from 'zod';
import { randomUUID } from 'crypto'; // Simulated UUID generation

// 1. Define Dependency Schema
const DependencySchema = z.object({
    name: z.string().describe("Name of the dependency (e.g., Kafka, Redis)."),
    version: z.string().optional().describe("Specific version required."),
    type: z.union([
        z.literal('internal'),
        z.literal('external'),
        z.literal('database'),
    ]).describe("Classification of the dependency source."),
});

// 2. Define Feature Schema
const FeatureSchema = z.object({
    id: z.string().uuid().describe("Unique identifier for the feature."),
    description: z.string().min(10).describe("Detailed description of the feature."),
    status: z.union([
        z.literal('planned'),
        z.literal('in_progress'),
        z.literal('completed'),
    ]).describe("Current development status."),
});

// 3. Define Blueprint Schema (Root Schema)
const BlueprintSchema = z.object({
    service_name: z.string().min(3).describe("The unique name of the microservice."),
    version: z.string().regex(/^\d+\.\d+\.\d+$/).describe("Semantic version string (e.g., 1.0.0)."),
    max_latency_ms: z.number().int().positive().describe("Maximum acceptable latency in milliseconds."),
    dependencies: z.array(DependencySchema).min(1).describe("List of external and internal dependencies."),
    features: z.array(FeatureSchema).describe("List of features implemented by the service."),
});

// 4. Type Inference Implementation
export type MicroserviceBlueprint = z.infer<typeof BlueprintSchema>;

// Sample data conforming to the inferred type
const rawBlueprintData: MicroserviceBlueprint = {
    service_name: "AuthService",
    version: "1.0.0",
    max_latency_ms: 150,
    dependencies: [
        { name: "UserDB", type: "database" },
        { name: "Gateway", version: "2.1.0", type: "internal" },
    ],
    features: [
        { 
            id: randomUUID(), 
            description: "User login via OAuth2 flow.", 
            status: 'completed' 
        },
    ]
};

// 5. Schema Validation Test
function validateBlueprint(data: unknown): MicroserviceBlueprint {
    console.log(`Attempting validation for: ${data.service_name || 'Unknown Service'}`);
    try {
        // .parse() throws a ZodError on failure, providing detailed structure
        const validatedData = BlueprintSchema.parse(data);
        console.log("Validation Successful.");
        return validatedData;
    } catch (error) {
        // Re-throw the error to demonstrate Zod's descriptive output
        console.error("Validation Failed!");
        throw error;
    }
}

// Example Usage (Successful Case)
// validateBlueprint(rawBlueprintData); 

// Example Usage (Failure Case - uncomment to test failure)
/*
validateBlueprint({ 
    service_name: "AuthService",
    version: "1.0.0",
    max_latency_ms: -50, // Fails: must be positive
    dependencies: [], // Fails: must have at least 1 dependency
    features: []
});
*/
