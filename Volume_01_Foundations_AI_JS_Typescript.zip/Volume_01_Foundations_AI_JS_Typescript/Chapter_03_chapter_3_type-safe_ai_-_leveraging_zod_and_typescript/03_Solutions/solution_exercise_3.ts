
/*
 * These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
 * You can find the series on Amazon.
 * New books info: https://linktr.ee/edgarmilvus
 *
 * MIT License
 * Copyright (c) 2025 Edgar Milvus
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */

// Source File: solution_exercise_3.ts
// Description: Solution for Exercise 3
// ==========================================

import { z } from 'zod';

// 1. Define the Base Schema (Canonical Source of Truth)
const BaseTaskSchema = z.object({
    id: z.string().uuid().describe("Unique system ID for the task."),
    title: z.string().min(5).describe("Short title of the task."),
    description: z.string().min(20).describe("Detailed task description."),
    priority: z.number().int().min(1).max(5).describe("Priority level (1=High, 5=Low)."),
    reviewer_id: z.string().uuid().describe("ID of the reviewer assigned."),
    sensitive_notes: z.string().describe("Internal notes, must not be public."),
    created_at: z.string().datetime().describe("Timestamp of creation."),
});

// 2. Derive the Creation Schema (Omit)
// LLM provides input data, excluding system-generated fields (id, created_at).
const TaskCreationSchema = BaseTaskSchema.omit({
    id: true,
    created_at: true,
});

// 3. Derive the Update Schema (Partial)
// For updates, any field can be present, but none are strictly required.
const TaskUpdateSchema = BaseTaskSchema.partial();

// 4. Derive the Public Display Schema (Pick)
// Only non-sensitive fields are exposed publicly.
const PublicTaskSchema = BaseTaskSchema.pick({
    id: true,
    title: true,
    description: true,
});

// Infer TypeScript Types for derived schemas
type TaskCreationData = z.infer<typeof TaskCreationSchema>;
type TaskUpdateData = z.infer<typeof TaskUpdateSchema>;
type PublicTaskData = z.infer<typeof PublicTaskSchema>;

// Conceptual Validation Testing

// Test Case 1: Task Creation (Requires title, description, priority, reviewer_id, sensitive_notes)
const creationData: TaskCreationData = {
    title: "Review LLM Output",
    description: "Verify structure and content of the generated report.",
    priority: 1,
    reviewer_id: "a1b2c3d4-e5f6-7890-1234-567890abcdef",
    sensitive_notes: "Requires high security clearance."
};
// TaskCreationSchema.parse(creationData); // Would pass

// Test Case 2: Task Update (All fields are optional)
const partialUpdateData: TaskUpdateData = {
    priority: 2, // Only updating priority
    reviewer_id: undefined // Zod partial makes fields optional, including allowing undefined
};
// TaskUpdateSchema.parse(partialUpdateData); // Would pass

// Test Case 3: Public Display (Only id, title, description are allowed/expected)
const publicData: PublicTaskData = {
    id: "fedcba09-8765-4321-fedc-ba0987654321",
    title: "Review LLM Output",
    description: "Verify structure and content of the generated report.",
};
// PublicTaskSchema.parse(publicData); // Would pass
