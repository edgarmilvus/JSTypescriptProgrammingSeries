/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2025 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

import { z, ZodError } from 'zod';

// 1. Define Agent Schema
const AgentSchema = z.object({
    agent_id: z.string().uuid().describe("Unique UUID for the agent."),
    role: z.string().describe("The specialized role of the agent."),
    max_tokens: z.number().int().gt(1000).describe("Maximum allowed context tokens, must be > 1000."),
    is_active: z.boolean().describe("Whether the agent is currently enabled."),
});

// Define Pool Configuration Schema
const PoolConfigurationSchema = z.array(AgentSchema).describe("An array of worker agent definitions.");

// Type definition for the result structure
type PoolConfig = z.infer<typeof PoolConfigurationSchema>;
type ValidationResult = 
    | { success: true, data: PoolConfig } 
    | { success: false, errorType: 'JSON_SYNTAX' | 'SCHEMA_ERROR', details: any, rawInput: string };

// 2. Simulate Untrusted Output
const validJsonOutput = JSON.stringify([
    {
        agent_id: "a1b2c3d4-e5f6-7890-1234-567890abcdef",
        role: "Code Generator",
        max_tokens: 4096,
        is_active: true
    }
]);

const invalidJsonOutput = `{
    "agent_id": "invalid-uuid",
    "role": "Debugger",
    "max_tokens": 500, // Fails Zod constraint (>1000)
    "is_active": true,
},`; // Fails JSON parsing (trailing comma, not an array)

// 3. Implement Safe Parsing and Error Reporting
function parseAgentConfiguration(jsonString: string): ValidationResult {
    let rawObject: unknown;

    // Step 1: Handle JSON Syntax Error
    try {
        // Attempt to parse the raw string output from the LLM
        rawObject = JSON.parse(jsonString);
    } catch (e) {
        if (e instanceof SyntaxError) {
            return {
                success: false,
                errorType: 'JSON_SYNTAX',
                details: `Failed to parse JSON string: ${e.message}`,
                rawInput: jsonString,
            };
        }
        throw e; // Re-throw unexpected errors
    }

    // Step 2: Handle Zod Structural Error using safeParse
    const result = PoolConfigurationSchema.safeParse(rawObject);

    if (result.success) {
        return { success: true, data: result.data };
    } else {
        // Extract detailed Zod error path using .format()
        return {
            success: false,
            errorType: 'SCHEMA_ERROR',
            details: result.error.format(),
            rawInput: jsonString,
        };
    }
}

// Example Usage
// const result1 = parseAgentConfiguration(validJsonOutput);
// console.log("Valid Result:", result1.success ? result1.data : result1.errorType);

// const result2 = parseAgentConfiguration(invalidJsonOutput);
// console.log("Invalid Result:", result2);
