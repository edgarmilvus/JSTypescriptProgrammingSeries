/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2025 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

// prompt-generator.ts

import OpenAI from 'openai';
import * as dotenv from 'dotenv'; 

// Load environment variables from a .env file for local development
dotenv.config();

// 1. Initialize the OpenAI client
// CRITICAL: In production environments (like Vercel or AWS Lambda), 
// the API key must be passed securely via environment variables, 
// not hardcoded.
const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

/**
 * @description Generates a marketing slogan and description based on dynamic product details.
 * This function is the core implementation of basic prompt engineering, combining 
 * a static persona (system prompt) with dynamic user variables.
 *
 * @param productName The user-provided name of the product (e.g., "AuraFlow Smart Mug").
 * @param targetAudience The user-selected demographic or persona (e.g., "Remote Developers aged 25-35").
 * @returns {Promise<string>} The generated marketing content as a string.
 */
async function generateMarketingCopy(
  productName: string,
  targetAudience: string,
): Promise<string> {
  // --- Prompt Engineering Step 1: Define the Static System Persona and Rules ---
  // This prompt controls the AI's behavior and tone for ALL requests.
  const systemPrompt: string = `You are a world-class, witty marketing copywriter specializing in short-form digital advertisements. Your goal is to generate one catchy slogan and one concise product description. The output must be professional, persuasive, and highly tailored to the specified audience.`;

  // --- Prompt Engineering Step 2: Define the Dynamic User Request (The Template) ---
  // We use TypeScript/JavaScript template literals (backticks) for clean variable injection.
  const userPromptTemplate: string = `
    Product Name: ${productName}
    Target Audience: ${targetAudience}

    TASK: Generate the content following these constraints:
    1. Slogan must be under 10 words.
    2. Description must be under 40 words.
    3. Use a tone that resonates specifically with the Target Audience.
    4. Format the output clearly with headers for Slogan and Description.
  `;

  console.log(`\n--- Sending Request for Product: ${productName} ---`);
  
  try {
    // 3. Execute the API Call using the engineered messages structure
    const completion = await openai.chat.completions.create({
      model: 'gpt-4o-mini', // A fast, cost-effective model suitable for simple generation tasks
      
      // The core of the chat API: the messages array
      messages: [
        // The first message is always the 'system' role, setting the stage
        { role: 'system', content: systemPrompt },
        // The second message is the 'user' role, containing the task and dynamic variables
        { role: 'user', content: userPromptTemplate },
      ],
      
      // Critical parameters for controlling LLM behavior
      temperature: 0.7, // A value between 0.0 (deterministic) and 1.0 (highly creative). 0.7 balances creativity and relevance.
      max_tokens: 250,  // Limits the size of the completion response, saving cost and controlling latency.
    });

    // 4. Extract and return the generated content
    const generatedContent = completion.choices[0].message.content;

    if (!generatedContent) {
        // Handle cases where the model returns an empty or null response
        throw new Error("LLM returned no content or an unexpected response structure.");
    }

    return generatedContent;

  } catch (error) {
    // Robust error handling for network or API issues
    console.error('Error during OpenAI API call:', error);
    // Return a graceful fallback message
    return 'Failed to generate copy due to an API error.';
  }
}

// --- Application Execution (Simulating API endpoint calls) ---
async function main() {
  // Example 1: Professional Product
  const product1 = 'ZenithFlow Productivity Timer';
  const audience1 = 'Freelance designers who value deep work sessions.';

  const result1 = await generateMarketingCopy(product1, audience1);
  console.log(`\n### Generated Copy for ${product1} ###\n${result1}`);
  console.log('--------------------------------------------------');

  // Example 2: Niche/Informal Product
  const product2 = 'CryptoCat Browser Extension';
  const audience2 = 'Teenage blockchain enthusiasts and meme coin traders.';

  const result2 = await generateMarketingCopy(product2, audience2);
  console.log(`\n### Generated Copy for ${product2} ###\n${result2}`);
}

// Execute the main function
main();
