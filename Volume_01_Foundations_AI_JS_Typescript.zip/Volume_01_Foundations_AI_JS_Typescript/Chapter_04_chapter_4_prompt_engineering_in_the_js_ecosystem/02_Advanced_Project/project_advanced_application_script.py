# These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
# You can find the series on Amazon.
# New books info: https://linktr.ee/edgarmilvus
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import os
from pydantic import BaseModel, Field
from typing import Literal
from dotenv import load_dotenv

# Ensure environment variables (like OPENAI_API_KEY) are loaded
load_dotenv()

# We use LangChain for robust templating and structured output enforcement.
# In the JS ecosystem, this maps directly to LangChain.js and Zod.
from langchain_openai import ChatOpenAI
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import PydanticOutputParser

# --- 1. Define the Structured Output Schema (Zod/TypeScript equivalent) ---
# This Pydantic model enforces the exact JSON structure the LLM MUST return.
class TicketClassification(BaseModel):
    """
    Schema for classifying an incoming user support ticket.
    This ensures predictable, machine-readable output for downstream systems.
    """
    product_area: Literal["Authentication", "Billing", "Data_API", "Documentation", "Other"] = Field(
        description="The primary product area this ticket relates to. Must be one of the specified literals."
    )
    severity: Literal["Critical", "High", "Medium", "Low"] = Field(
        description="The urgency level based on the user's description and potential impact."
    )
    required_action: str = Field(
        description="A brief, one-sentence summary of the immediate next step for the internal team (e.g., 'Escalate to L2 team for database investigation')."
    )
    extracted_entities: list[str] = Field(
        description="A list of key entities mentioned by the user, such as specific IDs, URLs, or error codes."
    )
    confidence_score: float = Field(
        description="The LLM's confidence (0.0 to 1.0) in the accuracy of this classification."
    )

# --- 2. Initialize the LLM and Parser ---
# Use a model known for strong JSON mode capabilities (like gpt-4o or gpt-4-turbo).
try:
    llm = ChatOpenAI(model="gpt-4o", temperature=0.0)
except Exception as e:
    print(f"Error initializing LLM: {e}. Ensure OPENAI_API_KEY is set.")
    exit()

# Instantiate the parser that links the Pydantic schema to the LLM's output.
parser = PydanticOutputParser(pydantic_object=TicketClassification)

# --- 3. Define the Prompt Engineering Strategy (System Instruction) ---
# This section sets the context, tone, and Chain-of-Thought instructions.
SYSTEM_TEMPLATE = (
    "You are an expert 'Supervisor Node' documentation and ticket classification agent for a major SaaS platform. "
    "Your sole job is to analyze incoming support tickets and provide a structured classification. "
    "Follow these steps rigidly: 1) Identify the core problem. 2) Determine the product area. 3) Assign severity. 4) Extract all relevant IDs. "
    "The output MUST strictly adhere to the required JSON schema provided. Do not include any explanatory text outside the JSON object."
)

# --- 4. Define the User Input Template ---
# This uses standard LangChain templating to handle dynamic input variables efficiently.
USER_TEMPLATE = """
--- TICKET METADATA ---
User ID: {user_id}
Timestamp: {timestamp}
Priority Level: {priority_level}

--- RAW TICKET CONTENT ---
{ticket_content}
"""

# --- 5. Assemble the Full Prompt Template ---
# Combine system context, user input, and the required format instructions from the parser.
prompt = ChatPromptTemplate.from_messages([
    ("system", SYSTEM_TEMPLATE),
    ("user", USER_TEMPLATE),
])

# --- 6. Construct the Chain (Prompt -> LLM -> Structured Output) ---
# LangChain's .with_structured_output method automatically handles injecting the JSON schema 
# instructions into the prompt and validating the output.
structured_classifier_chain = prompt | llm.with_structured_output(schema=TicketClassification)

# --- 7. Define Dynamic Input Data (Simulating a real-time ticket ingestion) ---
ticket_data = {
    "user_id": "USR-92847",
    "timestamp": "2024-10-27T14:30:00Z",
    "priority_level": "P2 - Standard",
    "ticket_content": (
        "I cannot log in using my SSO provider (Okta). I keep getting a '403 Forbidden' error "
        "after the redirect, even though I successfully authenticated with Okta. This started "
        "after the upgrade to version 3.1. The error code displayed is ERR-AUTH-90210. "
        "This is affecting 50 users in my organization. Please fix immediately."
    )
}

# --- 8. Execution and Output ---
def process_ticket(data: dict) -> TicketClassification:
    """
    Invokes the structured LLM chain to classify the ticket data.
    """
    print("--- Invoking LLM for Structured Classification ---")
    try:
        # The chain invocation returns a Pydantic object directly, guaranteeing structure.
        result = structured_classifier_chain.invoke(data)
        return result
    except Exception as e:
        print(f"\n[CRITICAL ERROR] Failed to parse structured output: {e}")
        # In a production environment, this would trigger a fallback mechanism or retry logic.
        return None

if __name__ == "__main__":
    classification_result = process_ticket(ticket_data)

    if classification_result:
        print("\n--- CLASSIFICATION SUCCESS ---")
        # The result is a Pydantic object, which can be easily converted to JSON for API response.
        print(classification_result.model_dump_json(indent=2))
        
        # Demonstrating structured access:
        print(f"\n[Routing Decision]: Send to {classification_result.product_area} Team.")
        print(f"[Urgency]: {classification_result.severity}")
        print(f"[Action]: {classification_result.required_action}")

