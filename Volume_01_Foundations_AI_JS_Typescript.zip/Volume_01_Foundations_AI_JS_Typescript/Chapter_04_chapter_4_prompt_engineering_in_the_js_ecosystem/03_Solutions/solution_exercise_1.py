
/*
 * These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
 * You can find the series on Amazon.
 * New books info: https://linktr.ee/edgarmilvus
 *
 * MIT License
 * Copyright (c) 2025 Edgar Milvus
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */

// Source File: solution_exercise_1.py
// Description: Solution for Exercise 1
// ==========================================

from langchain.prompts import PromptTemplate, FewShotPromptTemplate

# 1. Define the Few-Shot Examples
FEW_SHOT_EXAMPLES = [
    {"input": "The site speed is blazing slow, I love waiting 10 minutes.", "output": "NEGATIVE"},
    {"input": "Finally, a UI that actually hurts my eyes. Five stars!", "output": "NEGATIVE"},
    {"input": "It works exactly as advertised, which is fine.", "output": "NEUTRAL"},
    {"input": "I was skeptical, but the performance boost is incredible.", "output": "POSITIVE"},
    {"input": "This is the best update since the last one.", "output": "NEUTRAL"},
]

USER_INPUT = "The new feature is unbelievably complicated, great job."

# --- Part A: Native JavaScript Template Implementation (Python equivalent) ---

def generate_examples_string(examples):
    """Manually formats the examples into a single string."""
    example_str = ""
    for ex in examples:
        example_str += f"Input: {ex['input']}\nCategory: {ex['output']}\n---\n"
    return example_str

SYSTEM_INSTRUCTION_NATIVE = (
    "You are a sophisticated content moderator. Classify the user input "
    "into POSITIVE, NEGATIVE, or NEUTRAL. Pay close attention to sarcasm. "
    "Only output the category name."
)

examples_str = generate_examples_string(FEW_SHOT_EXAMPLES)

# 2. Construct the Prompt String using native Python formatting
native_prompt_string = f"""
{SYSTEM_INSTRUCTION_NATIVE}

---
FEW-SHOT EXAMPLES:
{examples_str}
---

CLASSIFICATION TASK:
Input: {USER_INPUT}
Category:
"""
# print("Native Prompt:\n", native_prompt_string)


# --- Part B: LangChain.js Refactor (Python FewShotPromptTemplate) ---

# 1. Template Definition and Example Formatting (LangChain handles the structure)
example_template = "Input: {input}\nCategory: {output}"

# Use FewShotPromptTemplate to manage the iteration and insertion of examples
few_shot_template = FewShotPromptTemplate(
    # Defines how each example is formatted
    example_prompt=PromptTemplate.from_template(example_template),
    examples=FEW_SHOT_EXAMPLES,
    # Defines the overall structure (System Prompt + User Input)
    suffix="--- \nCLASSIFICATION TASK:\nInput: {userInput}\nCategory:",
    prefix="You are a sophisticated content moderator. Classify the user input "
           "into POSITIVE, NEGATIVE, or NEUTRAL. Pay close attention to sarcasm. "
           "Only output the category name.\n\n--- \nFEW-SHOT EXAMPLES:\n",
    input_variables=["userInput"]
)

# 2. Final prompt generation
final_langchain_prompt = few_shot_template.format(userInput=USER_INPUT)
# print("\nLangChain Prompt:\n", final_langchain_prompt)
