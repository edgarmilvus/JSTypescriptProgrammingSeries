
/*
 * These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
 * You can find the series on Amazon.
 * New books info: https://linktr.ee/edgarmilvus
 *
 * MIT License
 * Copyright (c) 2025 Edgar Milvus
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */

// Source File: solution_exercise_4.py
// Description: Solution for Exercise 4
// ==========================================

from langchain.prompts import PromptTemplate, FewShotPromptTemplate

# 1. Diagnosis (Internal Comment)
# Missing components:
# 1. Lack of an explicit System Prompt defining the *exact* allowed categories and forbidding commentary.
# 2. Lack of Few-Shot examples to guide the model on handling ambiguous, multi-faceted feedback.

# 3. Refactoring (Few-Shot Integration)
FEW_SHOT_CLASSIFICATION_EXAMPLES = [
    {
        "input": "The documentation says feature X works, but I can't find the setting. Is this a bug?",
        "output": "BUG_REPORT"
    },
    {
        "input": "I love the new layout, but it would be amazing if the sidebar could collapse automatically.",
        "output": "FEATURE_REQUEST"
    }
]

# 2. Refactoring (System Prompt)
STRICT_SYSTEM_PROMPT = (
    "You are a strict, non-conversational feedback classifier. "
    "Your SOLE task is to categorize the user feedback. "
    "You MUST choose one of the following three categories and output ONLY the category label: "
    "FEATURE_REQUEST, BUG_REPORT, or GENERAL_INQUIRY. "
    "DO NOT include any explanation, commentary, or punctuation. Your response must be a single word."
)

# 4. Final Prompt Structure (LangChain FewShotPromptTemplate)
classification_example_template = "Feedback: {input}\nClassification: {output}"

final_classification_template = FewShotPromptTemplate(
    example_prompt=PromptTemplate.from_template(classification_example_template),
    examples=FEW_SHOT_CLASSIFICATION_EXAMPLES,
    prefix=f"{STRICT_SYSTEM_PROMPT}\n\n--- EXAMPLES ---\n",
    suffix="--- CLASSIFY THIS ---\nFeedback: {feedback}\nClassification:",
    input_variables=["feedback"]
)

AMBIGUOUS_FEEDBACK = "I tried to save my profile settings but the button didn't do anything. I had to refresh the page and now I lost all my changes. Also, maybe you could add dark mode next?"

final_prompt_string = final_classification_template.format(feedback=AMBIGUOUS_FEEDBACK)
# print(final_prompt_string)
