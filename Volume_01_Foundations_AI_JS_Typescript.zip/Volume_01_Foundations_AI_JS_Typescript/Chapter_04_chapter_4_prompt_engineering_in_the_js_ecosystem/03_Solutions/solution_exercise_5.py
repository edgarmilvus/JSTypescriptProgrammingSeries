
/*
 * These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
 * You can find the series on Amazon.
 * New books info: https://linktr.ee/edgarmilvus
 *
 * MIT License
 * Copyright (c) 2025 Edgar Milvus
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */

// Source File: solution_exercise_5.py
// Description: Solution for Exercise 5
// ==========================================

# 1. Tool Definition Integration (Conceptual structure passed to the LLM API)
TOOL_DEFINITIONS = [
    {
        "name": "fetchStockPrice",
        "description": "Retrieves the current market price for a given stock ticker. Input: ticker (string).",
        "parameters": {
            "type": "object",
            "properties": {
                "ticker": {"type": "string", "description": "The stock symbol (e.g., 'TSLA')."}
            },
            "required": ["ticker"]
        }
    },
    {
        "name": "fetchNewsHeadlines",
        "description": "Retrieves the top five most recent news headlines related to a specific topic. Input: topic (string).",
        "parameters": {
            "type": "object",
            "properties": {
                "topic": {"type": "string", "description": "The search term for news topics (e.g., 'AI innovation')."}
            },
            "required": ["topic"]
        }
    }
]

# 2. Parallel Execution Prompt Constraint (System Prompt)
SYSTEM_PROMPT_PARALLEL = (
    "You are an expert financial analysis agent. You have access to the following tools. "
    "Analyze the user request and determine the necessary tool calls. "
    "CRITICAL INSTRUCTION FOR EFFICIENCY: If multiple tool calls are required and their inputs are "
    "semantically independent (i.e., the result of one tool is not needed to formulate the input "
    "for another), you MUST combine them into a single, parallel execution response structure. "
    "Always prioritize generating all independent tool calls in a single turn to minimize round trips and latency."
)

USER_QUERY = "What is the current price of TSLA, and what are the top headlines related to AI innovation today?"

# 3. Scenario Analysis: Expected LLM Output Structure (Conceptual JSON/API Call Array)
EXPECTED_PARALLEL_OUTPUT = {
    "tool_calls": [
        {
            "id": "call_stock_price_1",
            "function": "fetchStockPrice",
            "arguments": {"ticker": "TSLA"}
        },
        {
            "id": "call_news_2",
            "function": "fetchNewsHeadlines",
            "arguments": {"topic": "AI innovation"}
        }
    ]
}
