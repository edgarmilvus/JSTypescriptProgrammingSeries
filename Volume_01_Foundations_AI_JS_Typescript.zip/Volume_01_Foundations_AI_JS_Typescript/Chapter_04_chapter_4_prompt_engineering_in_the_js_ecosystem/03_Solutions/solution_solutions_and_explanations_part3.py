# These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
# You can find the series on Amazon.
# New books info: https://linktr.ee/edgarmilvus
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_solutions_and_explanations_part3.py
# Description: Solutions and Explanations
# ==========================================

from langchain.prompts import PromptTemplate

# 3. System Prompt Control
SYSTEM_PROMPT_COT = (
    "You are an Expert Senior Software Architect. Your primary goal is to generate "
    "accurate, clear documentation for the user. Before generating the final summary, "
    "you MUST perform an internal Chain-of-Thought process using the XML tags provided below. "
    "The final output MUST ONLY contain the documentation summary, without the tags or internal thoughts."
)

# 1. Define the CoT Structure
COT_INSTRUCTIONS = """
--- INTERNAL THOUGHT PROCESS REQUIRED ---
<analysis>
Detail the function of the code, identifying all input parameters and external dependencies (if any).
</analysis>

<complexity_assessment>
Rate the code complexity (Low, Medium, High) and justify the rating based on logic flow and dependencies.
</complexity_assessment>

<reasoning>
Based on the analysis, formulate the core concept that must be conveyed in the final summary.
</reasoning>
--- END INTERNAL THOUGHT PROCESS ---

Now, based on your internal thought process, provide the final, user-facing summary below:
"""

CODE_SNIPPET = """
function calculateFibonacci(n) {
    if (n <= 1) return n;
    let a = 0, b = 1, temp;
    for (let i = 2; i <= n; i++) {
        temp = a + b;
        a = b;
        b = temp;
    }
    return b;
}
"""

# 2. Prompt Template Creation
cot_template = PromptTemplate(
    input_variables=["codeSnippet"],
    template=f"""
{SYSTEM_PROMPT_COT}

---
CODE SNIPPET:
