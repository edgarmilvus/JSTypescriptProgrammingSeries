/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2025 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

// basic_langchain_app.ts

// 1. Core LangChain Imports (LCEL Components)
import { ChatOpenAI } from "@langchain/openai";
import { ChatPromptTemplate } from "@langchain/core/prompts";
import { StringOutputParser } from "@langchain/core/output_parsers";
import { RunnableSequence } from "@langchain/core/runnables";

// --- 1. MODEL SETUP ---

/**
 * @description Initializes the Chat Model (ChatOpenAI).
 * Using 'gpt-4o-mini' balances capability and cost efficiency, ideal for high-volume
 * backend utility tasks like summarization.
 *
 * NOTE: The API key is automatically inferred from the OPENAI_API_KEY environment variable.
 * @type {ChatOpenAI}
 */
const model = new ChatOpenAI({
  modelName: "gpt-4o-mini",
  temperature: 0.1, // Low temperature ensures deterministic, factual summarization.
  maxTokens: 100, // Constraint to enforce brevity, crucial for notification text.
});

// --- 2. PROMPT TEMPLATE ---

/**
 * @description Defines the structured input for the LLM using ChatPromptTemplate.
 * This template enforces a specific persona and constraints (System Message)
 * before providing the dynamic input (Human Message).
 * @type {ChatPromptTemplate}
 */
const promptTemplate = ChatPromptTemplate.fromMessages([
  // System Message: Establishes the role, tone, and output format constraints.
  [
    "system",
    "You are a highly concise, professional content summarization engine for a corporate dashboard. Your task is to summarize the provided input into exactly one, short, actionable sentence, suitable for a web application notification banner. Do not use conversational language.",
  ],
  // Human Message: The dynamic placeholder for the document text passed during execution.
  ["human", "{document_text}"],
]);

// --- 3. THE CHAIN (The Orchestration Layer - LCEL) ---

/**
 * @description The core executable sequence (Chain).
 * This uses the LangChain Expression Language (LCEL) via RunnableSequence.
 * The sequence defines the data flow: Prompt -> Model -> Parser.
 * @type {RunnableSequence}
 */
const summarizationChain = RunnableSequence.from([
  promptTemplate,         // Step 1: Takes input payload and formats it into a Chat Message Array.
  model,                  // Step 2: Sends the formatted messages to the OpenAI API.
  new StringOutputParser(), // Step 3: Extracts the raw string content from the AI's response object.
]);

// --- 4. EXECUTION ---

/**
 * @description Simulates the dynamic data input from a SaaS application.
 * This text might be pulled from a database, a file upload, or an external API.
 */
const longDocumentText = `
  The Q3 2024 financial report shows significant growth in the cloud services division,
  exceeding internal projections by 15%. This success is attributed primarily to
  the new pricing structure introduced in July, alongside aggressive expansion
  into the European market. However, the legacy hardware division continues to
  struggle, posting a net loss for the third consecutive quarter, necessitating
  a strategic review slated for early November. Stakeholders are generally optimistic
  about the future trajectory, provided the cloud momentum is maintained.
`;

/**
 * @description Executes the chain with the specific input payload.
 * In a real application, this function would be wrapped in an API endpoint (e.g., Express or Next.js route handler).
 * @param {string} document_text - The text to be summarized.
 * @returns {Promise<string>} The summarized output.
 */
async function runSummarization(document_text: string): Promise<string> {
  console.log("--- Starting LangChain Execution (Model: gpt-4o-mini) ---");

  // The .invoke() method executes the entire RunnableSequence synchronously (awaiting the result).
  const result = await summarizationChain.invoke({
    document_text: document_text, // The key must match the placeholder in the Prompt Template: {document_text}
  });

  console.log("--- Execution Complete ---");
  return result;
}

// Main execution block
runSummarization(longDocumentText)
  .then((summary) => {
    console.log("\n[INPUT TEXT]:", longDocumentText.substring(0, 80) + "...");
    console.log("[GENERATED SUMMARY (Notification Banner Text)]:", summary);
    console.log("\n--- Application Output Simulation ---");
    console.log(`[DASHBOARD NOTIFICATION]: New Report Summary: "${summary}"`);
  })
  .catch((error) => {
    console.error("A critical error occurred during chain execution:", error);
  });
