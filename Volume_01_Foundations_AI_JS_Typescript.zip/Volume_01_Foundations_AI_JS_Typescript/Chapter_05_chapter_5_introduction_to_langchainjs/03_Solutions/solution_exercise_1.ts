
/*
 * These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
 * You can find the series on Amazon.
 * New books info: https://linktr.ee/edgarmilvus
 *
 * MIT License
 * Copyright (c) 2025 Edgar Milvus
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */

// Source File: solution_exercise_1.ts
// Description: Solution for Exercise 1
// ==========================================

import { z } from "zod";
import { ChatPromptTemplate } from "@langchain/core/prompts";
import { ChatOpenAI } from "@langchain/openai";
import { StructuredOutputParser } from "@langchain/core/output_parsers";
import { RunnableSequence } from "@langchain/core/runnables";

// 1. Define the Schema using Zod
const ReviewAnalysisSchema = z.object({
  sentiment: z.enum(["Positive", "Negative", "Neutral"]).describe("The primary sentiment of the review."),
  keywords: z.array(z.string()).length(3).describe("The top three most relevant product keywords."),
  summary_snippet: z.string().describe("A concise, one-sentence summary of the review's content."),
});

// 2. Create the Structured Output Parser
const parser = StructuredOutputParser.fromZodSchema(ReviewAnalysisSchema);

// 3. Create the Prompt Template
const prompt = ChatPromptTemplate.fromMessages([
  ["system", "You are an expert review analysis system. Your task is to analyze raw customer reviews and extract specific structured information. Follow the format instructions precisely."],
  // Injecting the formatting instructions is critical for the LLM
  ["system", parser.getFormatInstructions()], 
  ["human", "Analyze the following review text:\n\n{review_text}"],
]);

// 4. Implement the Chain (Conceptual instantiation of the model)
// const model = new ChatOpenAI({ temperature: 0, modelName: "gpt-4-turbo" });

// const ReviewSanitizerChain = RunnableSequence.from([
//     prompt,
//     model, 
//     parser,
// ]);

// 5. Error Handling Planning (Conceptual Code Structure)
/*
async function executeChain(reviewText: string) {
  try {
    const result = await ReviewSanitizerChain.invoke({
      review_text: reviewText,
    });
    console.log("Analysis Success:", result);
  } catch (error) {
    // This catches errors during the LLM call or, more commonly, 
    // the StructuredOutputParser failing to deserialize the LLM's response.
    if (error.name === 'OutputParserException') {
      console.error("CRITICAL ERROR: LLM failed to return valid JSON conforming to the Zod schema.");
      // In a production system, you would log the raw LLM output here 
      // and potentially retry the request or fall back to a simpler model.
    } else {
      console.error("An unexpected error occurred during chain execution:", error);
    }
  }
}

// Sample invocation:
// const sampleReview = "The product arrived quickly, but the color was completely wrong and the material felt cheap. I would not recommend this at all.";
// executeChain(sampleReview);
*/
