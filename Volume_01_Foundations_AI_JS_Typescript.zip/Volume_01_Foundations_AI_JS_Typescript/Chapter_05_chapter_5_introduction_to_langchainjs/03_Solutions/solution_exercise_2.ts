
/*
 * These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
 * You can find the series on Amazon.
 * New books info: https://linktr.ee/edgarmilvus
 *
 * MIT License
 * Copyright (c) 2025 Edgar Milvus
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */

// Source File: solution_exercise_2.ts
// Description: Solution for Exercise 2
// ==========================================

import { ChatPromptTemplate } from "@langchain/core/prompts";
import { ChatOpenAI } from "@langchain/openai";
import { RunnableSequence } from "@langchain/core/runnables";

// Define Model (conceptual)
// const model = new ChatOpenAI({ temperature: 0.5, modelName: "gpt-3.5-turbo" });

// 1. Define Input and Intermediate Variables:
// Input: technical_draft
// Intermediate: simplified_text
// Final Output: final_social_post

// 2. Create Two Prompt Templates

// Step 1: Simplification Template
const SimplificationPrompt = ChatPromptTemplate.fromMessages([
    ["system", "Simplify the following complex technical draft into plain, accessible language suitable for a 5th-grade reading level."],
    ["human", "{technical_draft}"],
]);

// Step 2: Promotional Template
const PromotionalPrompt = ChatPromptTemplate.fromMessages([
    ["system", "Take the provided text and rewrite it using an exciting, promotional tone. Append exactly three highly relevant marketing hashtags at the end."],
    ["human", "{simplified_text}"], // Expects the output of Step 1
]);

// 3. Construct the Sequential Chain

// Sub-Chain 1: Technical Simplification
const SimplificationChain = RunnableSequence.from([
    SimplificationPrompt,
    // model, // Execution step
]);

// Sub-Chain 2: Promotional Rewrite
const PromotionalChain = RunnableSequence.from([
    PromotionalPrompt,
    // model, // Execution step
]);

// Orchestrate the full sequence using LCEL mapping
const RefinerChain = RunnableSequence.from([
    // Step 1: Execute SimplificationChain, mapping its output to 'simplified_text'
    {
        simplified_text: SimplificationChain,
        // Pass the original draft through, ensuring the context is available if needed
        technical_draft: (input) => input.technical_draft, 
    },
    // Step 2: Execute PromotionalChain, using 'simplified_text' as input
    {
        final_social_post: ({ simplified_text }) => {
            // This closure invokes the second chain, piping the intermediate result
            // return PromotionalChain.invoke({ simplified_text });
            return `[Placeholder for Promotional Chain output using: ${simplified_text}]`; // Placeholder for runnable invocation
        },
    },
    // Final selection to return only the desired output key
    (input) => input.final_social_post,
]);

/*
// 4. Execution and Verification (Conceptual)
const technicalDraft = "The 12nm semiconductor layer achieves 99.8% DCI-P3 coverage.";
// const result = await RefinerChain.invoke({ technical_draft: technicalDraft });
// console.log(result); // Expected to contain the final social media post
*/
