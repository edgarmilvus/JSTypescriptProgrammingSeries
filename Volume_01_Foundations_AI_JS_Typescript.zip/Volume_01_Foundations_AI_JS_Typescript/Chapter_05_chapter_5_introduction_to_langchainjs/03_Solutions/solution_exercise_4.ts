
/*
 * These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
 * You can find the series on Amazon.
 * New books info: https://linktr.ee/edgarmilvus
 *
 * MIT License
 * Copyright (c) 2025 Edgar Milvus
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */

// Source File: solution_exercise_4.ts
// Description: Solution for Exercise 4
// ==========================================

import { PromptTemplate } from "@langchain/core/prompts";
import { CommaSeparatedListOutputParser } from "@langchain/core/output_parsers";
import { RunnableSequence } from "@langchain/core/runnables";

// 1. LangChain Backend Requirements

// Output Parser: Converts "tag1, tag2, tag3" into ["tag1", "tag2", "tag3"]
const tagParser = new CommaSeparatedListOutputParser();

// Prompt Design
const tagPrompt = new PromptTemplate({
    template: `
        Analyze the content below and generate 5 to 7 highly relevant SEO tags/keywords.
        Return the tags as a single, comma-separated list. DO NOT include numbering, quotes, or any extra text.

        Content: {content}

        ---
        {format_instructions}
    `,
    inputVariables: ["content"],
    partialVariables: {
        format_instructions: tagParser.getFormatInstructions(),
    },
});

// The Core Chain (Conceptual)
// const TagGenerationChain = RunnableSequence.from([
//     tagPrompt,
//     // new ChatOpenAI({ temperature: 0.3 }),
//     tagParser,
// ]);

// 4. API Handler Structure (Conceptual Next.js Route)
/*
// POST /api/generate-tags
async function handler(req: Request) {
    const { content } = await req.json();

    // Invoke the chain
    const tagsArray = await TagGenerationChain.invoke({ content });

    // IMPORTANT: To work seamlessly with Vercel's useCompletion (which expects a raw text response), 
    // we return the array joined back into a string.
    const rawTagString = tagsArray.join(', '); 
    
    return new Response(rawTagString, { status: 200 });
}
*/
