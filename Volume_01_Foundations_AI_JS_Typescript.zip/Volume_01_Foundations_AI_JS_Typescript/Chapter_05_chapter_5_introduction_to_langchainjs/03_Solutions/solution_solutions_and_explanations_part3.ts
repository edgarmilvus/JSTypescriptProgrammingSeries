/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2025 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

import { z } from "zod";

// 1. Define Zod Schema and TypeScript Interface
const UserProfileSchema = z.object({
  Name: z.string(),
  Age: z.number().int().positive(),
  Occupation: z.string(),
});

type UserProfile = z.infer<typeof UserProfileSchema>;

// 2. Create a User-Defined Type Guard
/**
 * Type Guard: Checks if the object is structurally a UserProfile AND enforces Age >= 18.
 */
function isAdultProfile(profile: any): profile is UserProfile {
    // Check structural compatibility (basic check, assuming LLM parsing passed Zod validation first)
    if (
        typeof profile !== 'object' ||
        profile === null ||
        typeof profile.Name !== 'string' ||
        typeof profile.Occupation !== 'string' ||
        typeof profile.Age !== 'number'
    ) {
        return false;
    }

    // Critical Business Logic Check: Age must be 18 or over
    return profile.Age >= 18;
}

// Simulated database logging function (only accepts the narrowed type)
const logToDatabase = (profile: UserProfile) => {
    console.log(`[DB LOG] Profile accepted: ${profile.Name} (Age: ${profile.Age})`);
};

// 4. Testing Scenarios
const parsedOutput_Pass: any = { Name: "Sarah Connor", Age: 25, Occupation: "Engineer" }; // Pass
const parsedOutput_Fail: any = { Name: "John Doe", Age: 16, Occupation: "Student" }; // Fail (Age)
const parsedOutput_Malformed: any = { Name: "Invalid", Age: "twenty", Occupation: "Unknown" }; // Fail (Type)

// 3. Chain Integration and Conditional Logic Demonstration
function processProfile(parsedProfile: any) {
    console.log(`\n--- Attempting to process profile: ${parsedProfile.Name || 'Unknown'} ---`);
    
    // Use the Type Guard to narrow the type and enforce business rules
    if (isAdultProfile(parsedProfile)) {
        // Inside this block, parsedProfile is definitively of type UserProfile
        console.log("SUCCESS: Profile is valid and an adult.");
        logToDatabase(parsedProfile);
    } else {
        console.warn("REJECTED: Profile failed validation (Type mismatch or Age restriction).");
    }
}

/*
processProfile(parsedOutput_Pass);
processProfile(parsedOutput_Fail);
processProfile(parsedOutput_Malformed);
*/
