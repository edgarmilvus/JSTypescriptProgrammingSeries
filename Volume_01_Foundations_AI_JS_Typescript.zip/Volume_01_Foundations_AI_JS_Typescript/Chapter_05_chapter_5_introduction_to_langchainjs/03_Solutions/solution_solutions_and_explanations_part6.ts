/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2025 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part6.ts
// Description: Solutions and Explanations
// ==========================================

import { PromptTemplate } from "@langchain/core/prompts";

const refinedPrompt = new PromptTemplate({
    template: `
        You are a highly skilled Senior Financial Analyst drafting an internal executive brief.
        
        ---
        INSTRUCTIONS FOR BRIEF GENERATION:
        1. ROLE/TONE: Maintain a formal, analytical, and professional tone suitable for high-level management.
        2. FORMAT HEADER: Your response MUST begin with the exact header: EXECUTIVE BRIEFING - {current_date}
        3. LENGTH CONSTRAINT: The summary MUST be exactly 50 words long. Adhere strictly to this word count.
        4. MANDATORY INCLUSION: The summary MUST explicitly integrate and mention the following three data points from the article:
           a) The primary stock ticker (e.g., MSFT).
           b) The specific percentage change (increase or decrease).
           c) The name of the CEO or primary executive mentioned.

        ---
        FINANCIAL NEWS ARTICLE TEXT:
        {article_text}
        ---
        
        BEGIN EXECUTIVE BRIEFING (Header followed by 50-word summary):
    `,
    inputVariables: ["article_text", "current_date"],
});
