/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2025 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

// app/api/chat/route.ts

import { OpenAI } from 'openai';
import { OpenAIStream, StreamingTextResponse } from 'ai';
import { NextRequest } from 'next/server';

// 1. Initialize the OpenAI client.
// Assumes OPENAI_API_KEY is set in environment variables.
const openai = new OpenAI();

// 2. CRITICAL: Specify the Edge runtime for maximum performance.
// This enables low-latency streaming capabilities.
export const runtime = 'edge';

/**
 * Handles incoming POST requests for chat completions.
 * @param req The Next.js request object containing the message history.
 * @returns A StreamingTextResponse object that streams the AI response.
 */
export async function POST(req: NextRequest) {
  try {
    // 3. Extract the messages array from the request body.
    // The Vercel AI SDK's 'useChat' hook automatically formats the payload correctly.
    const { messages } = await req.json();

    // 4. Request a streaming completion from OpenAI.
    const response = await openai.chat.completions.create({
      model: 'gpt-3.5-turbo',
      stream: true, // Essential for streaming responses
      messages: messages,
    });

    // 5. Transform the OpenAI response stream using the Vercel AI SDK utility.
    // OpenAIStream handles serialization, error checking, and text decoding.
    const stream = OpenAIStream(response);

    // 6. Return the stream wrapped in a StreamingTextResponse.
    // This sets the correct HTTP headers (Content-Type: text/plain; charset=utf-8)
    // and ensures the browser handles the response as a continuous stream of chunks.
    return new StreamingTextResponse(stream);
  } catch (error) {
    // 7. Robust error handling for API failures or parsing issues.
    console.error('Error processing chat request:', error);
    return new Response('Internal Server Error: Failed to generate response.', { status: 500 });
  }
}
