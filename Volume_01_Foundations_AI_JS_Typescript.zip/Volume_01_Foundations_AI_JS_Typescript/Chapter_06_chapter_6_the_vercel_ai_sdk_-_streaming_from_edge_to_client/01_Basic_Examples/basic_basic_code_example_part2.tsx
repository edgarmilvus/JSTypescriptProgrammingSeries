/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2025 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.tsx
// Description: Basic Code Example
// ==========================================

// app/page.tsx
'use client';

import { useChat } from 'ai/react';
import { FormEvent } from 'react';

/**
 * A simple chat interface component demonstrating real-time streaming using useChat.
 * @returns React component for the chat application.
 */
export default function ChatInterface() {
  // 1. Initialize the useChat hook.
  // It manages state (messages, input), handles the API call, and processes the stream.
  const { messages, input, handleInputChange, handleSubmit, isLoading } = useChat({
    api: '/api/chat', // Target the Edge API endpoint created above
  });

  // 2. Custom submit handler to prevent default form behavior
  // and pass the event to the SDK's handleSubmit function.
  const handleFormSubmit = (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    handleSubmit(e);
  };

  return (
    <div className="flex flex-col h-screen p-4 max-w-2xl mx-auto">
      <h1 className="text-2xl font-bold mb-4">AI Streaming Chat Demo</h1>

      {/* 3. Message Display Area */}
      <div className="flex-grow overflow-y-auto space-y-4 p-2 bg-gray-50 rounded-lg shadow-inner mb-4">
        {messages.length === 0 && (
          <p className="text-gray-500 italic">Start chatting! Your responses will stream in real-time.</p>
        )}
        {messages.map((m) => (
          <div key={m.id} className={`p-3 rounded-lg ${m.role === 'user' ? 'bg-blue-100 self-end' : 'bg-green-100 self-start'}`}>
            <p className="font-semibold capitalize">{m.role}:</p>
            <p className="whitespace-pre-wrap">{m.content}</p>
          </div>
        ))}

        {/* 4. Loading Indicator */}
        {isLoading && (
            <div className="text-center text-sm text-gray-600 animate-pulse">
                AI is thinking and streaming...
            </div>
        )}
      </div>

      {/* 5. Input Form */}
      <form onSubmit={handleFormSubmit} className="flex gap-2">
        <input
          type="text"
          value={input}
          onChange={handleInputChange}
          placeholder="Say something intelligent..."
          disabled={isLoading}
          className="flex-grow p-3 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500"
        />
        <button
          type="submit"
          disabled={isLoading || input.trim() === ''}
          className="p-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:bg-gray-400 transition-colors"
        >
          Send
        </button>
      </form>
    </div>
  );
}
