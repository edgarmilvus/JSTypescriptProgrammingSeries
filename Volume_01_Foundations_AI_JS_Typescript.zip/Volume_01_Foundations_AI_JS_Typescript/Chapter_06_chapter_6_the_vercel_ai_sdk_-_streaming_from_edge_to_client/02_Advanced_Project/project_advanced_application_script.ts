/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2025 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// app/api/chat/route.ts
// This file is configured to run as a high-performance Vercel Edge Function.

import { NextRequest } from 'next/server';
import { OpenAI } from 'openai';
import { OpenAIStream, StreamingTextResponse } from 'ai';

// Initialize the OpenAI client. 
// Using environment variables securely stored and accessed by the Edge runtime.
const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

/**
 * @function POST
 * @description Handles incoming chat requests. It orchestrates the LLM call 
 * and ensures the response is correctly formatted for streaming via the Vercel AI SDK.
 * @param {NextRequest} req - The incoming HTTP request containing the message history.
 * @returns {Promise<StreamingTextResponse | Response>} A streamable response or an error response.
 */
export async function POST(req: NextRequest) {
  // 1. Input Parsing and Validation
  try {
    const { messages } = await req.json();

    // 2. Define the System Prompt for Role Enforcement
    // This establishes the context for the "Document Summarizer" SaaS feature.
    const systemPrompt = {
      role: 'system',
      content: `You are the 'Edge Document Summarizer' AI. Your primary function is to provide concise, professional summaries and Q&A based on the provided context (simulated here). Keep responses direct and focused on the document content. Adhere strictly to a professional tone.`,
    };

    // 3. Initiate the Streaming API Call
    // We pass the role-defining prompt first, followed by the user's message history.
    const response = await openai.chat.completions.create({
      model: 'gpt-4o-mini', // Selected for speed and low latency at the Edge
      stream: true,
      messages: [systemPrompt, ...messages],
      temperature: 0.2, // Low temperature is crucial for factual, summarization tasks
    });

    // 4. Stream Transformation using OpenAIStream
    // The OpenAIStream utility processes the raw OpenAI stream (ndjson format) 
    // and transforms it into a standard, readable web stream.
    const stream = OpenAIStream(response, {
        // Optional: Add a callback to log the final completion status or metadata
        onCompletion: (completion) => {
            console.log(`Stream completed. Final token count: ${completion.length}`);
        },
        // Optional: Hook to inject a prefix or suffix to the stream
        // onStart: async () => { /* Logic before stream starts */ }
    });

    // 5. Return the StreamingTextResponse
    // This utility automatically sets the correct HTTP headers (Content-Type: text/plain)
    // required for the Vercel AI SDK client to consume the stream efficiently.
    return new StreamingTextResponse(stream);

  } catch (error) {
    // 6. Edge-Compliant Error Handling
    console.error('API Error during Edge streaming:', error);
    // Return a standard HTTP response for errors, avoiding streaming on failure.
    return new Response('An internal error occurred while processing the request.', { status: 500 });
  }
}
