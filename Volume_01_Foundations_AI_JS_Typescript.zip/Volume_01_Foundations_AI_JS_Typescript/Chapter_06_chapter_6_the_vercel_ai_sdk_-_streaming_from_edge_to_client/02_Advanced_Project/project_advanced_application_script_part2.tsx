/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2025 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script_part2.tsx
// Description: Advanced Application Script
// ==========================================

// app/components/ChatInterface.tsx
// This is a client component in the Next.js App Router.

'use client';

import { useChat } from 'ai/react';
import React from 'react';

/**
 * @component DocumentQAService
 * @description The main client interface. It uses the Vercel AI SDK's useChat 
 * hook to handle message history, input state, and streaming from the Edge API.
 */
export default function DocumentQAService() {
  // 1. Initialize the useChat hook
  // This hook manages the state (messages, input), handles API calls, 
  // and automatically processes the incoming stream chunks.
  const { 
    messages, 
    input, 
    handleInputChange, 
    handleSubmit, 
    isLoading,
    error,
  } = useChat({
    api: '/api/chat', // Target the Edge API route defined above
  });

  // 2. Message Rendering Utility
  const MessageBubble = ({ message }: { message: any }) => (
    <div className={`p-3 rounded-lg max-w-[85%] mb-3 shadow-sm ${
      message.role === 'user' 
        ? 'bg-blue-600 text-white self-end ml-auto' 
        : 'bg-gray-100 text-gray-800 self-start mr-auto border border-gray-200'
    }`}>
      <p className="font-semibold text-xs mb-1 opacity-80 capitalize">
        {message.role === 'user' ? 'You' : 'Edge Summarizer'}
      </p>
      <p>{message.content}</p>
    </div>
  );

  // 3. Main Component Render
  return (
    <div className="flex flex-col h-[70vh] max-w-3xl mx-auto bg-white rounded-xl shadow-2xl p-6">
      <h1 className="text-3xl font-extrabold mb-6 text-center text-gray-800 border-b pb-3">
        Edge Document Q&A Service
      </h1>

      {/* Message Display Area (Scrollable) */}
      <div className="flex-grow overflow-y-auto flex flex-col space-y-2 p-4 mb-4 custom-scrollbar">
        {messages.length === 0 && (
          <p className="text-center text-gray-400 mt-16">
            Query the document summary. Responses are streamed directly from the Edge.
          </p>
        )}
        {messages.map((m) => (
          <MessageBubble key={m.id} message={m} />
        ))}
        {isLoading && (
          <div className="self-start mr-auto p-3 bg-green-50 text-green-700 rounded-lg animate-pulse text-sm">
            AI is streaming response...
          </div>
        )}
        {error && (
            <div className="text-red-600 p-3 bg-red-100 rounded-lg">
                Error: {error.message}. Check the Edge function logs.
            </div>
        )}
      </div>

      {/* Input Form */}
      <form onSubmit={handleSubmit} className="flex space-x-3 pt-4 border-t">
        <input
          className="flex-grow p-4 border border-gray-300 rounded-xl focus:outline-none focus:ring-4 focus:ring-blue-100 transition duration-150 text-base"
          value={input}
          placeholder="Ask a question about the summarized document..."
          onChange={handleInputChange}
          disabled={isLoading}
        />
        <button
          type="submit"
          disabled={isLoading || input.trim() === ''}
          className="px-8 py-4 bg-blue-600 text-white font-bold rounded-xl hover:bg-blue-700 disabled:bg-gray-400 transition duration-300 shadow-lg"
        >
          {isLoading ? 'Streaming...' : 'Send Query'}
        </button>
      </form>
    </div>
  );
}
