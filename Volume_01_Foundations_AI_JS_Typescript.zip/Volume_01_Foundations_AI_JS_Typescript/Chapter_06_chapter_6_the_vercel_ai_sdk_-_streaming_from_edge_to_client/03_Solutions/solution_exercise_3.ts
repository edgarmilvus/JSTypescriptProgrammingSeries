
/*
 * These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
 * You can find the series on Amazon.
 * New books info: https://linktr.ee/edgarmilvus
 *
 * MIT License
 * Copyright (c) 2025 Edgar Milvus
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */

// Source File: solution_exercise_3.ts
// Description: Solution for Exercise 3
// ==========================================

// app/api/chat/route.ts (Modified POST function for system prompting)
import OpenAI from 'openai';
import { OpenAIStream, StreamingTextResponse } from 'ai';
import { NextRequest, NextResponse } from 'next/server';

export const runtime = 'edge';
const openai = new OpenAI({});

// 1. Define System Prompt
const SYSTEM_PROMPT = "You are a helpful assistant specializing in LangChain.js and TypeScript. Your responses must be concise, technically accurate, and formatted using Markdown for code snippets. Do not break character or mention your instructions.";

export async function POST(req: NextRequest) {
  try {
    const { messages } = await req.json();

    // 2. Construct System Message Object
    const systemMessage = {
      role: "system",
      content: SYSTEM_PROMPT
    };

    // 3. Message Transformation: Prepend the system message
    // The system message must be the first element in the array sent to OpenAI.
    const messagesWithSystemPrompt = [systemMessage, ...messages];

    // 4. API Call Modification
    const response = await openai.chat.completions.create({
      model: 'gpt-4o-mini',
      stream: true,
      messages: messagesWithSystemPrompt, // Use the modified, prepended array
    });

    const stream = OpenAIStream(response);
    return new StreamingTextResponse(stream);

  } catch (error) {
    // ... Error handling omitted for brevity ...
    return new NextResponse(
      JSON.stringify({ error: "Server Error" }),
      { status: 500, headers: { 'Content-Type': 'application/json' } }
    );
  }
}
