
/*
 * These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
 * You can find the series on Amazon.
 * New books info: https://linktr.ee/edgarmilvus
 *
 * MIT License
 * Copyright (c) 2025 Edgar Milvus
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */

// Source File: solution_exercise_4.ts
// Description: Solution for Exercise 4
// ==========================================

// types/extended-chat.d.ts (TypeScript definitions file)
import { Message } from 'ai'; // Import the base type from the SDK

// 1. Define the custom metadata fields
interface MessageMetadata {
    latencyMs?: number; // Optional performance metric (milliseconds)
    sourceId?: string;  // Optional identifier for the data source/generation path
}

// 2. Type Extension using the Intersection Utility Type
// This ensures ExtendedMessage has all properties of Message plus the new metadata.
type ExtendedMessage = Message & MessageMetadata;

// 3. Type Application Example (Client-Side)
/*
import { useChat } from 'ai/react';
import { ExtendedMessage } from './types/extended-chat';

function ChatComponent() {
    // We type the useChat hook to use our extended message type
    const { messages, setMessages, ... } = useChat<ExtendedMessage>({
        api: '/api/chat',
    });

    // 5. Hypothetical Client Modification (Simulating post-stream metric capture)
    const captureMetrics = (responseLatency: number) => {
        if (messages.length === 0) return;

        // Create a copy of the messages array
        const updatedMessages = [...messages];
        const lastIndex = updatedMessages.length - 1;

        // Update the last message (the assistant's response) with metadata
        updatedMessages[lastIndex] = {
            ...updatedMessages[lastIndex],
            latencyMs: responseLatency, // e.g., 4500
            sourceId: 'Edge-Function-A'
        };

        // Update the state, now safely typed as ExtendedMessage[]
        setMessages(updatedMessages);
    };
    // ... rest of component logic
}
*/
