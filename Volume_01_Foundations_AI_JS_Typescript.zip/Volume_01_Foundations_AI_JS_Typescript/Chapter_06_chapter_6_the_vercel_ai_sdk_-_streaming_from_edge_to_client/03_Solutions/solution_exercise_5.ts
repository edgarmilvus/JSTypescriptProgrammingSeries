
/*
 * These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
 * You can find the series on Amazon.
 * New books info: https://linktr.ee/edgarmilvus
 *
 * MIT License
 * Copyright (c) 2025 Edgar Milvus
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */

// Source File: solution_exercise_5.ts
// Description: Solution for Exercise 5
// ==========================================

// ChatInputForm.tsx (React Component)
import React from 'react';
import { UseChatHelpers } from 'ai/react';

// Define the required props derived from useChat
interface CustomFormProps extends Pick<UseChatHelpers, 'input' | 'handleInputChange' | 'append' | 'setInput'> {}

const ChatInputForm: React.FC<CustomFormProps> = ({ 
    input, 
    handleInputChange, 
    append, 
    setInput 
}) => {

    // 1. Form Event Capture & 2. Input Access
    const handleCustomSubmit = (e: React.FormEvent<HTMLFormElement>) => {
        e.preventDefault(); 

        const trimmedInput = input.trim();

        // 3. Validation Logic
        if (!trimmedInput) {
            alert("Error: Message cannot be empty. Please type something.");
            return;
        }
        
        if (trimmedInput.length <= 5) {
            alert(`Error: Message must be longer than 5 characters. Current length: ${trimmedInput.length}`);
            return;
        }

        // 4. Conditional Submission (Validation passed)
        // Manually trigger the API call using the append function
        append({
            role: "user",
            content: trimmedInput,
        });

        // 5. State Management: Manual Input Clear
        // We take explicit control over the input state reset
        setInput("");
    };

    return (
        <form onSubmit={handleCustomSubmit} style={{ display: 'flex', gap: '10px' }}>
            <input
                value={input}
                onChange={handleInputChange}
                placeholder="Ask your technical question..."
                style={{ flexGrow: 1, padding: '12px', border: '1px solid #ccc' }}
            />
            <button type="submit" style={{ padding: '12px 20px', backgroundColor: '#0070f3', color: 'white', border: 'none' }}>
                Send Message
            </button>
        </form>
    );
};
