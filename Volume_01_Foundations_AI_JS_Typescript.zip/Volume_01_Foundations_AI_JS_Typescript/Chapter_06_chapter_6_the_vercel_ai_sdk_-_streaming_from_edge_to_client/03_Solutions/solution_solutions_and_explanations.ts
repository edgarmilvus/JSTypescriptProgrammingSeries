/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2025 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// app/api/chat/route.ts (Next.js Edge Function)
import OpenAI from 'openai';
import { OpenAIStream, StreamingTextResponse } from 'ai';
import { NextRequest, NextResponse } from 'next/server';

// 1. Edge Runtime Configuration
export const runtime = 'edge';

// Initialize the OpenAI client (API key is automatically picked up from process.env)
const openai = new OpenAI({});

// 2. Request Handling & Error Handling Setup
export async function POST(req: NextRequest) {
  try {
    // Parse the request body containing the messages array
    const { messages } = await req.json();

    if (!messages || !Array.isArray(messages)) {
      throw new Error("Invalid request body: 'messages' array is missing or malformed.");
    }

    // 3. OpenAI Integration (Calling the Chat Completions API)
    const response = await openai.chat.completions.create({
      model: 'gpt-4o-mini', 
      stream: true, // Crucial for streaming
      messages: messages,
    });

    // 4. Streaming Implementation: Transform the OpenAI stream
    const stream = OpenAIStream(response);

    // 5. Response Construction: Return the final stream
    return new StreamingTextResponse(stream);

  } catch (error) {
    // 6. Robust Error Handling for API failures or malformed requests
    console.error("API Error:", error);

    const errorMessage = error instanceof Error ? error.message : "An unknown internal server error occurred.";

    return new NextResponse(
      JSON.stringify({ error: `Server Error: ${errorMessage}` }),
      { status: 500, headers: { 'Content-Type': 'application/json' } }
    );
  }
}
