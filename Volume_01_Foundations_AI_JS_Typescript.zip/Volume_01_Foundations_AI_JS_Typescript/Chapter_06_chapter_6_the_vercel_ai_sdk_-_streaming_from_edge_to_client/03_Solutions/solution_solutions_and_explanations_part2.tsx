/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2025 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.tsx
// Description: Solutions and Explanations
// ==========================================

// ChatStatusIndicator.tsx (React Functional Component)
import React from 'react';
import { Message } from 'ai'; 

interface ChatStateProps {
    isLoading: boolean;
    error: Error | undefined;
    messages: Message[];
    clearError: () => void; // Function to reset the error state
}

const ChatStatusIndicator: React.FC<ChatStateProps> = ({
    isLoading,
    error,
    messages,
    clearError
}) => {
    // 3. Error Display: Highest priority status
    if (error) {
        return (
            <div style={{ 
                backgroundColor: '#fee2e2', 
                color: '#991b1b', 
                padding: '12px', 
                borderRadius: '8px',
                border: '1px solid #f87171',
                textAlign: 'center'
            }}>
                🚨 Conversation Error: {error.message}
                <button 
                    onClick={clearError} 
                    style={{ marginLeft: '20px', padding: '5px 10px', cursor: 'pointer', backgroundColor: '#fca5a5' }}
                >
                    Dismiss
                </button>
            </div>
        );
    }

    // 2. Loading State: Display only if a response is actively being generated
    if (isLoading && messages.length > 0) {
        return (
            <div style={{ color: '#1d4ed8', fontWeight: 'bold', animation: 'pulse 1s infinite' }}>
                AI is generating response... (Thinking...)
            </div>
        );
    }

    // 4. Initial State: Display when chat history is empty
    if (messages.length === 0) {
        return (
            <div style={{ color: '#4b5563', fontStyle: 'italic', padding: '20px', border: '1px dashed #ccc' }}>
                👋 Start your conversation here. Ask me a technical question!
            </div>
        );
    }

    // Default: Conversation ongoing, no current activity
    return null; 
};
