/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2025 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.tsx
// Description: Basic Code Example
// ==========================================

// File: app/components/AIChatWindow.tsx
/**
 * @file AIChatWindow.tsx
 * @description A basic conversational interface component demonstrating the Vercel AI SDK's useChat hook.
 * This component manages state, handles streaming input/output, and renders the message history.
 * CRITICAL: Must be marked 'use client' as it relies on React hooks and client-side interactivity.
 */
'use client';

import { useChat, type Message } from 'ai/react';
import React, { FormEvent, useEffect, useRef } from 'react';

/**
 * Renders a single message bubble, styled based on the sender (user or assistant).
 * @param {Message} message - The message object containing content and role ('user' or 'assistant').
 */
const MessageBubble: React.FC<{ message: Message }> = ({ message }) => {
  const isUser = message.role === 'user';
  // Base styling for consistent appearance
  const baseClasses = "p-3 my-2 rounded-xl max-w-lg shadow-lg transition-all duration-300 ease-in-out";
  // Specific styling for user messages (right-aligned, primary color)
  const userClasses = "bg-blue-600 text-white ml-auto";
  // Specific styling for assistant messages (left-aligned, neutral background)
  const assistantClasses = "bg-gray-100 text-gray-800 mr-auto border border-gray-200";

  return (
    // Flex container to control alignment
    <div className={`flex ${isUser ? 'justify-end' : 'justify-start'}`}>
      <div className={`${baseClasses} ${isUser ? userClasses : assistantClasses}`}>
        <p className="font-bold text-xs opacity-80 mb-1">
          {isUser ? 'You' : 'AI Assistant'}
        </p>
        {/* whitespace-pre-wrap preserves line breaks from the streamed response */}
        <div className="whitespace-pre-wrap">{message.content}</div>
      </div>
    </div>
  );
};

/**
 * The main component utilizing the useChat hook to build a streaming conversational interface.
 * @returns {JSX.Element} The fully functional chat window component.
 */
export function AIChatWindow(): JSX.Element {
  
  // 1. Initialize the useChat hook. This is the core state management engine.
  const { 
    messages, 
    input, 
    handleInputChange, 
    handleSubmit, 
    isLoading, 
    error,
    stop,
    reload
  } = useChat({
    // Specifies the API endpoint the hook should call for streaming responses.
    api: '/api/chat', 
    // Optional: Provide a system message or initial greeting.
    initialMessages: [{ id: '0', role: 'assistant', content: "Hello! I am your Intelligent App Builder Assistant. Ask me anything about JavaScript, TypeScript, or AI integration." }]
  });

  // Ref for automatic scrolling to the latest message.
  const messagesEndRef = useRef<HTMLDivElement>(null);

  /**
   * Effect hook to automatically scroll the chat view to the bottom 
   * whenever the 'messages' array updates (i.e., when a new message is sent 
   * or a stream chunk arrives).
   */
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);


  // 2. Render the chat interface structure.
  return (
    <div className="flex flex-col h-[650px] w-full max-w-xl mx-auto border border-gray-300 rounded-xl shadow-2xl bg-white font-sans">
      
      {/* Header Section */}
      <header className="p-4 border-b bg-gray-50 rounded-t-xl flex justify-between items-center">
        <div>
          <h1 className="text-xl font-extrabold text-gray-800">AI Chat Demo</h1>
          <p className="text-sm text-gray-500">Vercel AI SDK + GPT-3.5 Turbo</p>
        </div>
        <button 
          onClick={() => reload()} 
          className="text-sm text-blue-600 hover:text-blue-800 transition duration-150 p-2 rounded-md hover:bg-blue-50"
          disabled={isLoading}
        >
          {isLoading ? 'Processing...' : 'Reload Conversation'}
        </button>
      </header>

      {/* Message Display Area (Scrollable) */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-gray-50" role="log" aria-live="polite">
        {/* Map over the messages array provided by useChat */}
        {messages.map((m: Message) => (
          <MessageBubble key={m.id} message={m} />
        ))}
        {/* Invisible anchor div for scrolling */}
        <div ref={messagesEndRef} /> 
      </div>

      {/* Error Display */}
      {error && (
        <div className="p-3 text-sm bg-red-100 text-red-700 border-t font-mono overflow-auto">
          <p className='font-bold'>Connection Error:</p>
          {error.message}
        </div>
      )}

      {/* Input Form */}
      {/* handleSubmit automatically prevents default form submission and initiates the API call */}
      <form onSubmit={handleSubmit} className="p-4 border-t flex gap-3 bg-white">
        
        {/* Input Field controlled by the 'input' state from useChat */}
        <input
          className="flex-1 p-4 border border-gray-300 rounded-xl focus:ring-blue-500 focus:border-blue-500 transition duration-150 text-base"
          value={input}
          placeholder={isLoading ? "Waiting for AI response..." : "Type your question here..."}
          onChange={handleInputChange} // Updates the 'input' state in real-time
          disabled={isLoading}
          aria-label="Chat input field"
        />
        
        {/* Submit/Stop Button */}
        <button
          // If loading, change the button action to stop the stream
          type={isLoading ? "button" : "submit"} 
          onClick={isLoading ? stop : undefined} 
          className={`px-6 py-3 rounded-xl font-semibold text-lg transition duration-150 shadow-md
            ${isLoading 
              ? 'bg-red-500 hover:bg-red-600 text-white' 
              : 'bg-blue-600 hover:bg-blue-700 text-white disabled:opacity-50'
            }`}
          disabled={input.trim() === '' && !isLoading}
        >
          {isLoading ? 'Stop' : 'Send'}
        </button>
      </form>
    </div>
  );
}
