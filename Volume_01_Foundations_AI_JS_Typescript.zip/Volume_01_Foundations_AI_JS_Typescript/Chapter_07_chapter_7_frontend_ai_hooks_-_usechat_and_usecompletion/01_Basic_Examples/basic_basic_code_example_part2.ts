/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2025 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.ts
// Description: Basic Code Example
// ==========================================

// File: app/api/chat/route.ts
/**
 * @file route.ts
 * @description Next.js API route handler for streaming chat completions.
 * This route receives the full message history from the client via POST.
 */

import { OpenAI } from 'openai';
import { OpenAIStream, StreamingTextResponse } from 'ai';

// Initialize the OpenAI client. It automatically uses the OPENAI_API_KEY environment variable.
const openai = new OpenAI({});

// Set the runtime environment for optimal performance in Vercel.
// 'edge' is preferred for low-latency streaming operations.
export const runtime = 'edge'; 

/**
 * Handles incoming POST requests from the useChat hook.
 * @param {Request} req - The standard Next.js request object.
 * @returns {StreamingTextResponse} A streaming response object compatible with the Vercel AI SDK.
 */
export async function POST(req: Request) {
  try {
    // 1. Extract the message history array sent by the useChat hook.
    // The Vercel AI SDK ensures this body contains the full conversation state.
    const { messages } = await req.json();

    // 2. Call the OpenAI Chat Completions API.
    const response = await openai.chat.completions.create({
      model: 'gpt-3.5-turbo', // The model selected for the conversation
      stream: true,           // CRITICAL: Must be true to enable chunked, real-time response delivery
      messages: messages,     // Pass the entire history for context
    });

    // 3. Convert the native OpenAI stream into a Vercel AI SDK-compatible stream.
    // This handles encoding, error forwarding, and necessary header configurations.
    const stream = OpenAIStream(response);

    // 4. Return the stream wrapped in StreamingTextResponse.
    return new StreamingTextResponse(stream);

  } catch (error) {
    // Robust error handling is crucial for streaming APIs.
    console.error("AI API Error:", error);
    // Return a standard 500 error response.
    return new Response(`An internal server error occurred: ${error instanceof Error ? error.message : 'Unknown error'}`, { status: 500 });
  }
}
