# These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
# You can find the series on Amazon.
# New books info: https://linktr.ee/edgarmilvus
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import os
import json
from typing import List, Dict, Any
from fastapi import FastAPI, Request
from fastapi.responses import StreamingResponse, JSONResponse
from openai import OpenAI
from dotenv import load_dotenv

# Load environment variables (like OPENAI_API_KEY)
load_dotenv()

# --- 1. Initialization and Configuration ---

# JSDoc equivalent: @type {FastAPI} - The core application instance.
app = FastAPI(title="AI SDK Backend Service")

# Initialize OpenAI Client. Handles authentication via environment variable.
client = OpenAI(api_key=os.environ.get("OPENAI_API_KEY"))

# --- 2. Utility Functions ---

def format_message(role: str, content: str) -> Dict[str, str]:
    """
    Helper function to structure message objects compliant with the OpenAI API format.
    @param {string} role - The message sender ('user', 'system', 'assistant').
    @param {string} content - The text content of the message.
    @returns {Dict} The formatted message object.
    """
    return {"role": role, "content": content}

# --- 3. The useChat Endpoint Simulation: /api/chat ---

@app.post("/api/chat")
async def chat_handler(request: Request):
    """
    Handles multi-turn conversational requests, expecting a full message history payload.
    This endpoint must provide a Server-Sent Event (SSE) stream for real-time updates.
    
    The frontend Vercel AI SDK useChat hook sends the payload: {messages: Array<Message>}.
    """
    try:
        # 3.1. Parse the incoming request payload
        data: Dict[str, Any] = await request.json()
        messages: List[Dict] = data.get("messages", [])

        if not messages:
             return JSONResponse(status_code=400, content={"error": "Message history is required."})

        # 3.2. Define the streaming generator function
        def stream_response():
            """
            Generator function that interfaces with the OpenAI API and yields raw text chunks.
            """
            try:
                # Call the OpenAI API using the full history provided by the frontend
                stream = client.chat.completions.create(
                    model="gpt-4o-mini",
                    messages=messages,
                    stream=True,
                )
                
                # 3.3. Iterate over the streamed chunks
                for chunk in stream:
                    content = chunk.choices[0].delta.content
                    # We only yield content chunks that are not None
                    if content:
                        # Vercel AI SDK expects raw text chunks (not SSE format)
                        yield content
                        
            except Exception as e:
                # Log and potentially yield an error message to the client
                print(f"Streaming error occurred: {e}")
                # Note: In production, better error handling and formatting is required.
                
        # 3.4. Return the FastAPI StreamingResponse
        # The media_type is critical; the Vercel AI SDK expects 'text/plain' or compatible stream.
        return StreamingResponse(stream_response(), media_type="text/plain")
    
    except json.JSONDecodeError:
        return JSONResponse(status_code=400, content={"error": "Invalid JSON payload."})
    except Exception as e:
        # Catch general server or API errors
        return JSONResponse(status_code=500, content={"error": f"Internal Server Error: {str(e)}"})

# --- 4. The useCompletion Endpoint Simulation: /api/completion ---

@app.post("/api/completion")
async def completion_handler(request: Request):
    """
    Handles single-turn completion requests, optimized for non-conversational tasks.
    The frontend Vercel AI SDK useCompletion hook sends the payload: {prompt: string}.
    """
    try:
        # 4.1. Parse the incoming request payload
        data: Dict[str, str] = await request.json()
        prompt: str = data.get("prompt")
        
        if not prompt:
            return JSONResponse(status_code=400, content={"error": "Prompt parameter is missing."})
        
        # 4.2. Define the system instruction for the specific task (e.g., summarization)
        system_prompt = "You are an expert content transformer focused on providing concise, direct, and high-quality outputs based on the user's request (e.g., summarization, translation, or expansion)."
        
        # Construct the minimal message list for the single-turn task
        messages = [
            format_message("system", system_prompt),
            format_message("user", prompt)
        ]
        
        # 4.3. Call the OpenAI API (non-streaming for efficiency, as completion is usually fast)
        response = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=messages,
            stream=False, # Standard, synchronous API call
            max_tokens=768 # Set a generous limit for transformation tasks
        )
        
        # 4.4. Extract and return the final text
        completion_text = response.choices[0].message.content
        
        # The frontend useCompletion hook expects the final text response, usually wrapped in JSON.
        return JSONResponse(content={"completion": completion_text})
            
    except Exception as e:
        return JSONResponse(status_code=500, content={"error": f"Completion Error: {str(e)}"})
        
# The script is ready to be run using: uvicorn filename:app --reload
