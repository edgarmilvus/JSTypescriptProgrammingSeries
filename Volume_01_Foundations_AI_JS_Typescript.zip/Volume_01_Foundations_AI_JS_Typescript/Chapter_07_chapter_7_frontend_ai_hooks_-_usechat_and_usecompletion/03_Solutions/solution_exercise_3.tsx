
/*
 * These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
 * You can find the series on Amazon.
 * New books info: https://linktr.ee/edgarmilvus
 *
 * MIT License
 * Copyright (c) 2025 Edgar Milvus
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */

// Source File: solution_exercise_3.tsx
// Description: Solution for Exercise 3
// ==========================================

// SummarizerTool.jsx (React Component using useCompletion)
import { useCompletion } from 'ai/react';
import React, { useState } from 'react';

function SummarizerTool() {
  // 1. Core useCompletion Integration
  const {
    completion,
    input,
    handleInputChange,
    handleSubmit,
    isLoading,
    error,
    setInput, // 6. Reset functionality
    setCompletion, // 6. Reset functionality
  } = useCompletion({
    api: '/api/summarize',
  });

  const [validationError, setValidationError] = useState('');

  // 2. Input and Prompt Construction & 3. Input Validation
  const handleCompletion = (e) => {
    e.preventDefault();
    setValidationError(''); 
    setCompletion(''); // 4. Clear previous output before submission

    const textLength = input.length;
    
    // 3. Validation: Min Length
    if (textLength < 50) {
      setValidationError('Input text must be at least 50 characters long.');
      return;
    }

    // 3. Validation: Max Length (Warning)
    if (textLength > 5000) {
      if (!window.confirm(`Warning: Text is long (${textLength} chars). Continue?`)) {
        return;
      }
    }

    // 2. Dynamic Prompt Construction
    const constructedPrompt = `Summarize the following document into five concise bullet points:\n\n---\n\n${input}`;
    
    // Submit the constructed prompt
    handleSubmit(e, { prompt: constructedPrompt });
  };
  
  // 6. Reset Functionality
  const handleClear = () => {
    setInput('');
    setCompletion('');
    setValidationError('');
  };

  return (
    <div style={{ maxWidth: '700px', margin: 'auto', padding: '20px' }}>
      <h3>Document Summarization Tool</h3>

      <form onSubmit={handleCompletion}>
        <textarea
          value={input}
          onChange={handleInputChange}
          placeholder="Paste your document text here..."
          rows={10}
          style={{ width: '100%', padding: '10px', marginBottom: '10px' }}
          disabled={isLoading}
        />
        
        {validationError && (
          <p style={{ color: 'red', marginBottom: '10px' }}>{validationError}</p>
        )}

        <div style={{ display: 'flex', justifyContent: 'space-between' }}>
          <button type="submit" disabled={isLoading}>
            {isLoading ? 'Generating Summary...' : 'Generate Summary'}
          </button>
          <button type="button" onClick={handleClear} disabled={isLoading}>
            Clear All
          </button>
        </div>
      </form>

      {/* 4. & 5. Result Display and Status Indicators */}
      <div style={{ marginTop: '20px', paddingTop: '15px' }}>
        <h4>Summary Output:</h4>
        <div style={{ minHeight: '150px', padding: '10px', backgroundColor: '#f5f5f5', whiteSpace: 'pre-wrap' }}>
          {error ? (
            <p style={{ color: 'red' }}>Error: Failed to fetch summary.</p>
          ) : isLoading ? (
            <p style={{ fontStyle: 'italic' }}>Streaming summary...</p>
          ) : completion ? (
            completion // 4. Real-time streaming output
          ) : (
            <p style={{ color: 'gray' }}>Summary will appear here...</p>
          )}
        </div>
      </div>
    </div>
  );
}
