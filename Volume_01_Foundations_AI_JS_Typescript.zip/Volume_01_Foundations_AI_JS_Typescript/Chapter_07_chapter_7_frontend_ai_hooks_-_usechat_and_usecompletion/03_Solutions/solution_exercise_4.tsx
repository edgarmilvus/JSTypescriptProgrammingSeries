
/*
 * These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
 * You can find the series on Amazon.
 * New books info: https://linktr.ee/edgarmilvus
 *
 * MIT License
 * Copyright (c) 2025 Edgar Milvus
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */

// Source File: solution_exercise_4.tsx
// Description: Solution for Exercise 4
// ==========================================

// AIContentEditor.jsx (Combining useChat and useCompletion)
import { useChat, useCompletion } from 'ai/react';
import React, { useState } from 'react';

function AIContentEditor() {
  // 3. Mode Toggle Implementation
  const [currentMode, setCurrentMode] = useState('chat'); 
  const [revisionPrompt, setRevisionPrompt] = useState('Tone: Professional');

  // 2. Conditional Hook Initialization (Both hooks are initialized and persist state)
  const chat = useChat({ api: '/api/editor/chat' });
  const completion = useCompletion({ api: '/api/editor/completion' });

  // 6. Interactive Challenge: Cross-Mode Data Transfer
  const handleReviseLatest = () => {
    const lastAssistantMessage = chat.messages
      .filter(m => m.role === 'assistant')
      .pop();
    
    if (lastAssistantMessage) {
      completion.setInput(lastAssistantMessage.content);
      setCurrentMode('completion'); // Switch mode
    } else {
      alert('No AI response available to revise.');
    }
  };

  // Revision Mode Submission Logic (Completion)
  const handleRevisionSubmit = (e) => {
    e.preventDefault();
    if (!completion.input) return;

    const constructedPrompt = `${revisionPrompt} on the following text:\n\n---\n\n${completion.input}`;
    completion.setCompletion(''); 
    completion.handleSubmit(e, { prompt: constructedPrompt });
  };

  // Helper functions for 4. Dynamic UI Rendering
  const renderChatMode = () => (
    <>
      {/* Chat History */}
      <div style={{ height: '300px', overflowY: 'auto', border: '1px solid #ccc', padding: '10px' }}>
        {chat.messages.map((m) => (<div key={m.id}>{m.content}</div>))}
        {chat.isLoading && <p>AI Brainstorming...</p>}
      </div>

      {/* Cross-Mode Transfer Button */}
      <button onClick={handleReviseLatest} disabled={chat.isLoading} style={{ margin: '10px 0' }}>
        Revise Latest AI Response
      </button>

      {/* Chat Input */}
      <form onSubmit={chat.handleSubmit} style={{ display: 'flex' }}>
        <input value={chat.input} onChange={chat.handleInputChange} disabled={chat.isLoading} style={{ flexGrow: 1 }} />
        <button type="submit" disabled={chat.isLoading}>Send</button>
      </form>
    </>
  );

  const renderRevisionMode = () => (
    <form onSubmit={handleRevisionSubmit}>
      {/* Prompt Selector */}
      <select value={revisionPrompt} onChange={(e) => setRevisionPrompt(e.target.value)} style={{ width: '100%', padding: '8px', marginBottom: '10px' }}>
        <option>Tone: Professional</option>
        <option>Action: Shorten by 50%</option>
      </select>

      {/* Input Area (Text to revise) */}
      <textarea value={completion.input} onChange={completion.handleInputChange} rows={6} style={{ width: '100%', marginBottom: '10px' }} />

      <button type="submit" disabled={completion.isLoading}>
        {completion.isLoading ? 'Revising...' : 'Submit Revision'}
      </button>

      {/* Output Area (Completion result) */}
      <div style={{ marginTop: '15px', padding: '10px', backgroundColor: '#e6f7ff' }}>
        <h4>Revised Output:</h4>
        <p>{completion.completion || 'Revision result streams here...'}</p>
      </div>
    </form>
  );

  return (
    <div style={{ maxWidth: '800px', margin: 'auto', padding: '20px' }}>
      <h1>AI Content Editor</h1>

      {/* Mode Toggle */}
      <div style={{ marginBottom: '20px' }}>
        <button onClick={() => setCurrentMode('chat')} disabled={currentMode === 'chat'}>Chat Mode</button>
        <button onClick={() => setCurrentMode('completion')} disabled={currentMode === 'completion'}>Revision Mode</button>
      </div>

      {/* Dynamic Rendering */}
      {currentMode === 'chat' ? renderChatMode() : renderRevisionMode()}
    </div>
  );
}
