/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2025 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.tsx
// Description: Solutions and Explanations
// ==========================================

// QnAChat.jsx (React Component using useChat)
import { useChat } from 'ai/react';
import React from 'react';

function QnAChat() {
  // 2. Core useChat Integration (targets /api/chat)
  const {
    messages,
    input,
    handleInputChange,
    handleSubmit,
    isLoading,
    clearMessages, // 7. Conversation Reset
  } = useChat({
    // Assumes the Next.js API route is at /api/chat
    api: '/api/chat', 
  });

  // 4. Input Handling and Submission
  const handleFormSubmit = (e) => {
    e.preventDefault();
    handleSubmit(e);
    // Input clearing is handled automatically by the SDK after submission
  };

  return (
    <div style={{ maxWidth: '600px', margin: 'auto', border: '1px solid #ccc', padding: '15px', height: '500px', display: 'flex', flexDirection: 'column' }}>
      
      {/* 7. Conversation Reset Button */}
      <button onClick={clearMessages} disabled={isLoading} style={{ marginBottom: '10px' }}>
        Start New Chat
      </button>

      {/* 3. Message History Display & 5. Real-Time Streaming */}
      <div style={{ flexGrow: 1, overflowY: 'auto', padding: '10px', backgroundColor: '#f9f9f9' }}>
        {messages.map((m) => (
          <div key={m.id} style={{ 
            margin: '10px 0', 
            textAlign: m.role === 'user' ? 'right' : 'left',
            color: m.role === 'user' ? '#007bff' : '#333'
          }}>
            <strong>{m.role === 'user' ? 'You' : 'AI'}:</strong> {m.content}
          </div>
        ))}
        
        {/* 6. Loading State Indication */}
        {isLoading && (
          <div style={{ fontStyle: 'italic', color: 'gray', marginTop: '10px' }}>
            AI is typing...
          </div>
        )}
      </div>

      {/* 4. Input Handling and Submission */}
      <form onSubmit={handleFormSubmit} style={{ display: 'flex', marginTop: '10px' }}>
        <input
          value={input}
          onChange={handleInputChange}
          placeholder="Say something..."
          disabled={isLoading}
          style={{ flexGrow: 1, padding: '8px' }}
        />
        <button type="submit" disabled={isLoading} style={{ padding: '8px 15px', marginLeft: '10px' }}>
          Send
        </button>
      </form>
    </div>
  );
}
