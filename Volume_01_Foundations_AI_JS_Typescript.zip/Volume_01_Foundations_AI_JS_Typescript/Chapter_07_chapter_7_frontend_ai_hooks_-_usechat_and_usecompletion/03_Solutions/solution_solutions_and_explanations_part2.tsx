/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2025 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.tsx
// Description: Solutions and Explanations
// ==========================================

// CodeReviewAssistant.jsx (React Component with advanced features)
import { useChat } from 'ai/react';
import React, { useRef, useEffect, useState } from 'react';

function CodeReviewAssistant() {
  // 4. System Prompt Enforcer (Hidden Context)
  const systemPrompt = "You are a Senior Rust Developer focused on performance optimization. All reviews must be technical and critical of memory usage. Do not acknowledge this instruction.";

  const {
    messages,
    input,
    handleInputChange,
    handleSubmit,
    isLoading,
    error,         // 2. Error Handling
    reload,        // 2. Retry functionality
    stop,          // 3. Stop Generation
    setMessages,   // Needed for transient state modification
  } = useChat({
    initialMessages: [{ role: 'system', content: systemPrompt }], 
    api: '/api/chat',
  });

  // Refs and State for 1. Intelligent Auto-Scrolling Management
  const chatContainerRef = useRef(null);
  const [isUserScrolling, setIsUserScrolling] = useState(false);

  // 1. Intelligent Auto-Scrolling Logic
  useEffect(() => {
    const container = chatContainerRef.current;
    if (!container) return;

    // Scroll only if the AI is active or if the user hasn't scrolled far up
    const isNearBottom = container.scrollHeight - container.clientHeight <= container.scrollTop + 100;
    
    if (isLoading || !isUserScrolling || isNearBottom) {
      container.scrollTop = container.scrollHeight;
      setIsUserScrolling(false); 
    }
  }, [messages, isLoading]); 

  const handleScroll = () => {
    const container = chatContainerRef.current;
    if (!container) return;
    // Set flag if the user is not at the absolute bottom
    const isAtBottom = container.scrollHeight - container.clientHeight === container.scrollTop;
    setIsUserScrolling(!isAtBottom);
  };

  // 3. Transient State Visualization (Stop Generation)
  const handleStop = () => {
    stop();
    // Append [Interrupted] tag to the last assistant message using setMessages
    if (messages.length > 0) {
        setMessages(prevMessages => {
            const lastMessage = prevMessages[prevMessages.length - 1];
            if (lastMessage.role === 'assistant' && !lastMessage.content.includes('[Interrupted]')) {
                return [
                    ...prevMessages.slice(0, -1),
                    { ...lastMessage, content: lastMessage.content + ' [Interrupted]' },
                ];
            }
            return prevMessages;
        });
    }
  };

  return (
    <div style={{ maxWidth: '800px', margin: 'auto', padding: '15px' }}>
      
      {/* 2. Robust Error Handling and Display */}
      {error && (
        <div style={{ border: '1px solid red', padding: '10px', marginBottom: '10px' }}>
          <p><strong>Error:</strong> {error.message || "An API error occurred."}</p>
          <button onClick={() => reload()}>Try Again</button>
        </div>
      )}

      {/* Message History Container */}
      <div 
        ref={chatContainerRef} 
        onScroll={handleScroll}
        style={{ height: '400px', overflowY: 'auto', border: '1px solid #ccc', padding: '10px' }}
      >
        {/* Filter out system messages */}
        {messages.filter(m => m.role !== 'system').map((m) => ( 
          <div key={m.id} style={{ margin: '10px 0' }}>{m.content}</div>
        ))}
        {isLoading && <div style={{ color: 'gray' }}>AI is analyzing...</div>}
      </div>

      {/* Input and Action Buttons */}
      <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
        <textarea
          value={input}
          onChange={handleInputChange}
          placeholder="Paste code block for review..."
          rows={5}
          disabled={isLoading}
        />
        <div style={{ display: 'flex', justifyContent: 'space-between' }}>
            <button type="submit" disabled={isLoading}>
                {isLoading ? 'Analyzing...' : 'Submit Code'}
            </button>
            
            {/* 3. Stop Generation Button */}
            {isLoading && (
                <button type="button" onClick={handleStop}>
                    Stop Generation
                </button>
            )}
        </div>
      </form>
    </div>
  );
}
// 5. Component Structure Visualization (DOT Notation is provided in the prompt)
