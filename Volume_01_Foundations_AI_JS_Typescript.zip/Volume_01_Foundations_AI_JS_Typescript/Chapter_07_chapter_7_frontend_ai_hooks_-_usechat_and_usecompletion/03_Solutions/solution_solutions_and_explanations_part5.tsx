/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2025 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.tsx
// Description: Solutions and Explanations
// ==========================================

// HistoricalFactChecker.jsx (Advanced System Prompting and State Manipulation)
import { useChat } from 'ai/react';
import React, { useState } from 'react';

function HistoricalFactChecker() {
  // 1. Strict System Prompt Definition
  const SYSTEM_PROMPT = `You are a highly educated historian living in London in the year 1850. 
  Your knowledge cutoff is strictly January 1, 1850. 
  You must refuse to discuss any event, technology, or political entity that arose after that date. 
  Respond using formal, 19th-century language. Do not break character.`;

  // 2. Initial Message Configuration
  const {
    messages,
    input,
    handleInputChange,
    handleSubmit,
    isLoading,
    setMessages, // Needed for 5. Message Modification
  } = useChat({
    api: '/api/chat',
    initialMessages: [{ role: 'system', content: SYSTEM_PROMPT }],
  });

  const [preSubmitWarning, setPreSubmitWarning] = useState('');
  
  // Keywords for 3. User Prompt Filtering
  const MODERN_KEYWORDS = ['smartphone', 'internet', 'typescript', 'computer', 'world war 2'];

  // 3. Client-side Input Filtering and Submission
  const handleFilteredSubmit = (e) => {
    e.preventDefault();
    setPreSubmitWarning('');

    const lowerInput = input.toLowerCase();
    const isModern = MODERN_KEYWORDS.some(keyword => lowerInput.includes(keyword));

    if (isModern) {
      setPreSubmitWarning("That term is unfamiliar to me, a historian of 1850. Please ask about known events.");
      return;
    }

    // If validation passes, submit to the API
    handleSubmit(e);
  };

  // 5. Message Modification (Post-generation Annotation)
  const handleAnnotate = (id) => {
    setMessages(prevMessages => 
      prevMessages.map(m => {
        if (m.id === id && m.role === 'assistant') {
          const annotation = ' [Source checked: Needs verification.]';
          if (!m.content.endsWith(annotation)) {
            return { ...m, content: m.content + annotation };
          }
        }
        return m;
      })
    );
  };

  return (
    <div style={{ maxWidth: '700px', margin: 'auto', padding: '20px' }}>
      <h2>Historical Fact Checker (1850 Persona)</h2>

      <div style={{ height: '400px', overflowY: 'auto', border: '1px solid #ccc', padding: '10px' }}>
        {/* Filter out system messages from the display */}
        {messages.filter(m => m.role !== 'system').map((m) => (
          <div key={m.id} style={{ margin: '10px 0' }}>
            <p><strong>{m.role === 'user' ? 'Patron' : 'Historian'}:</strong> {m.content}</p>
            
            {/* 5. Annotation Button */}
            {m.role === 'assistant' && (
              <button onClick={() => handleAnnotate(m.id)} style={{ fontSize: '0.7em', marginTop: '5px' }}>
                Annotate
              </button>
            )}
          </div>
        ))}
        {isLoading && <p>The Historian ponders...</p>}
      </div>

      {preSubmitWarning && (
        <p style={{ color: 'orange', marginBottom: '10px' }}>{preSubmitWarning}</p>
      )}

      <form onSubmit={handleFilteredSubmit} style={{ display: 'flex' }}>
        <input
          value={input}
          onChange={handleInputChange}
          placeholder="Ask about events before 1850..."
          disabled={isLoading}
          style={{ flexGrow: 1, padding: '8px' }}
        />
        <button type="submit" disabled={isLoading}>Inquire</button>
      </form>
    </div>
  );
}
