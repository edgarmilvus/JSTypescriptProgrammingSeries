/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2025 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

// filename: subscription_service.ts

import { OpenAI } from 'openai';
import { z } from 'zod';
import 'dotenv/config'; // Used to load OPENAI_API_KEY from .env file

// --- 1. CONFIGURATION AND INITIALIZATION ---
// Ensure your OPENAI_API_KEY is set in your environment variables
const openai = new OpenAI({
    apiKey: process.env.OPENAI_API_KEY,
});

// A map to link the function name string (from the LLM) to the actual JS function
const availableTools: Record<string, Function> = {};

// --- 2. TOOL SCHEMA DEFINITION (ZOD) ---

/**
 * @description Defines the expected input parameters for retrieving subscription data.
 * Zod ensures robust, runtime validation of the parameters suggested by the LLM.
 */
const SubscriptionSchema = z.object({
    userId: z.string().describe("The unique, alphanumeric identifier for the user whose subscription status is being queried. Must be a string."),
}).describe("Input parameters required to retrieve a user's subscription status.");

// --- 3. TOOL IMPLEMENTATION (The External Capability) ---

/**
 * @description Simulates an asynchronous lookup to a database or external Billing API.
 * @param params The validated parameters provided by the LLM.
 * @returns A JSON string containing the requested subscription details.
 */
async function getSubscriptionStatus(params: z.infer<typeof SubscriptionSchema>): Promise<string> {
    console.log(`\n[TOOL EXECUTOR] Executing 'getSubscriptionStatus' for user: ${params.userId}`);

    // CRITICAL: Basic Zod validation check before execution (though the orchestrator should handle this)
    const validationResult = SubscriptionSchema.safeParse(params);
    if (!validationResult.success) {
        return JSON.stringify({ error: "Invalid parameters provided to tool." });
    }

    // --- Simulated Asynchronous Database/API Call ---
    await new Promise(resolve => setTimeout(resolve, 500)); // Simulate network latency

    if (params.userId === "789") {
        const result = {
            userId: params.userId,
            status: "Active",
            plan: "Pro Tier",
            renewalDate: "2024-12-01",
            storageUsedGB: 150
        };
        return JSON.stringify(result);
    } else if (params.userId === "101") {
         return JSON.stringify({ error: "User not found or subscription cancelled." });
    }
    
    // Default response for other IDs
    return JSON.stringify({ status: "Unknown", message: "Could not retrieve status for this ID." });
}

// Register the tool implementation for execution lookup
availableTools['getSubscriptionStatus'] = getSubscriptionStatus;


// --- 4. TOOL DEFINITION FOR OPENAI API ---

// This structure is derived from the Zod schema and is what the OpenAI model reads.
const toolDefinition = {
    type: "function" as const,
    function: {
        name: "getSubscriptionStatus",
        description: "Retrieves the current subscription status, including plan and renewal date, for any user ID in the system.",
        parameters: SubscriptionSchema, // Zod schema is automatically converted to JSON Schema by the OpenAI library
    },
};


// --- 5. MAIN CONVERSATION ORCHESTRATOR ---

/**
 * @description Manages the multi-step conversation flow, including tool selection and execution.
 * @param prompt The user's initial message.
 */
async function runConversation(prompt: string) {
    const messages: any[] = [{ role: "user", content: prompt }];

    console.log(`\n--- 1. Initial Request ---`);
    console.log(`User Prompt: ${prompt}`);

    // --- STEP 1: Initial API Call (Model decides if a tool is needed) ---
    let response = await openai.chat.completions.create({
        model: "gpt-4o", // Use a powerful model known for robust function calling
        messages: messages,
        tools: [toolDefinition],
        tool_choice: "auto", // Let the model decide
    });

    let firstResponse = response.choices[0].message;
    messages.push(firstResponse); // Add the model's decision to the history

    // --- Check if the model requested a tool call ---
    if (firstResponse.tool_calls) {
        console.log(`\n--- 2. Tool Requested by LLM ---`);
        console.log(`Tool Name: ${firstResponse.tool_calls[0].function.name}`);
        console.log(`Arguments: ${firstResponse.tool_calls[0].function.arguments}`);

        // --- STEP 2: Execute the Tool(s) ---
        for (const toolCall of firstResponse.tool_calls) {
            const functionName = toolCall.function.name;
            const functionToCall = availableTools[functionName];

            if (!functionToCall) {
                console.error(`Error: Tool "${functionName}" not found in available tools map.`);
                continue;
            }

            // Parse arguments (CRITICAL: The arguments are a JSON string, which must be parsed)
            let toolArgs: any;
            try {
                toolArgs = JSON.parse(toolCall.function.arguments);
            } catch (e) {
                console.error("Error parsing JSON arguments from LLM.");
                // We send an error back to the LLM if parsing fails
                messages.push({
                    tool_call_id: toolCall.id,
                    role: "tool",
                    name: functionName,
                    content: JSON.stringify({ error: "Failed to parse required JSON arguments." }),
                });
                continue;
            }

            // Execute the actual function asynchronously
            const toolOutput = await functionToCall(toolArgs);

            // Add the tool execution result back to the message history
            messages.push({
                tool_call_id: toolCall.id,
                role: "tool",
                name: functionName,
                content: toolOutput,
            });
        }

        // --- STEP 3: Second API Call (Sending Tool Result Back) ---
        console.log(`\n--- 3. Sending Tool Result Back to LLM ---`);
        const secondResponse = await openai.chat.completions.create({
            model: "gpt-4o",
            messages: messages,
            tools: [toolDefinition], // Tools must still be included
        });

        const finalAnswer = secondResponse.choices[0].message.content;
        console.log(`\n--- 4. Final LLM Answer ---`);
        console.log(`\n${finalAnswer}`);
        return finalAnswer;

    } else {
        // If the model did not request a tool, return the initial response content
        console.log(`\n--- 2. No Tool Needed ---`);
        console.log(`\n${firstResponse.content}`);
        return firstResponse.content;
    }
}

// --- EXECUTION ---
(async () => {
    console.log("--- STARTING FUNCTION CALL DEMO ---");
    const testPrompt = "Can you look up the current subscription status for user ID 789 and tell me their plan and renewal date?";
    await runConversation(testPrompt);
    console.log("\n--- DEMO COMPLETE ---");
})();
