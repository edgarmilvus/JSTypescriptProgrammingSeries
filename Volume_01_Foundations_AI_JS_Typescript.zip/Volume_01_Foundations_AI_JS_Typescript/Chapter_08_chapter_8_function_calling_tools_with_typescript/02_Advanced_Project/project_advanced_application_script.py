# These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
# You can find the series on Amazon.
# New books info: https://linktr.ee/edgarmilvus
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import os
import json
from openai import OpenAI
from pydantic import BaseModel, Field
from typing import List, Dict, Any

# --- 1. CONFIGURATION & CLIENT INITIALIZATION ---
# In a secure AI Chatbot Architecture (Server Component), API keys are accessed securely.
# This client handles all communication with the external LLM provider.
try:
    # Initialize the OpenAI client using environment variables
    client = OpenAI(api_key=os.environ.get("OPENAI_API_KEY"))
except Exception as e:
    print(f"Error initializing OpenAI client: {e}")
    exit()

# --- 2. TOOL SCHEMA DEFINITION (Zod/Pydantic Equivalent for Validation) ---
# Adhering to SRP, schema definition is decoupled from implementation logic.

class ProductQuery(BaseModel):
    """
    @description: Defines the input schema for querying product documentation.
    @schema_source: Zod equivalent for robust, runtime type checking.
    """
    query: str = Field(description="The specific question or keyword to search for in the product documentation.")

class SubscriptionQuery(BaseModel):
    """
    @description: Defines the input schema for checking a user's subscription status.
    @schema_source: Ensures the user_id is always a valid integer.
    """
    user_id: int = Field(description="The unique integer ID of the user whose subscription status is required.")


# --- 3. TOOL IMPLEMENTATION (The actual Server-Side Logic / Business Layer) ---

def get_product_documentation(query: str) -> str:
    """
    @description: Simulates a lookup against an HNSW Index (e.g., pgvector) for product features (RAG).
    @logic_type: Data Access/RAG.
    """
    print(f"-> EXECUTING TOOL: RAG Search for '{query}'...")
    if "pricing" in query.lower() or "enterprise" in query.lower():
        # This result simulates a hit from a high-performance HNSW Index search.
        return "The Enterprise tier starts at $999/month and includes unlimited HNSW index storage and 500,000 vector dimensions."
    if "api limits" in query.lower():
        return "Standard API limits are 1000 requests per minute per user ID, configurable via the 'Throttle Manager' microservice."
    return f"No specific documentation found for '{query}'. Please refine your search."

def check_user_subscription(user_id: int) -> str:
    """
    @description: Simulates fetching transactional data from a secure internal API/Database.
    @logic_type: Transactional/Core Business Logic.
    """
    print(f"-> EXECUTING TOOL: Subscription Check for User ID {user_id}...")
    # Mock data representing a secure database query result
    if user_id == 1001:
        return json.dumps({"status": "Active", "tier": "Pro", "renewal_date": "2024-12-31", "seats": 5})
    elif user_id == 1002:
        return json.dumps({"status": "Inactive", "tier": "Free", "reason": "Expired Trial"})
    return json.dumps({"status": "Error", "message": "User ID not found."})


# --- 4. TOOL REGISTRY (Mapping functions to the required OpenAI JSON schema format) ---

TOOLS = [
    {
        "type": "function",
        "function": {
            "name": get_product_documentation.__name__,
            "description": "Retrieves technical documentation or feature details by performing a vector search (HNSW/RAG) on the knowledge base.",
            "parameters": ProductQuery.model_json_schema(), # Pydantic generates the required JSON schema
        },
    },
    {
        "type": "function",
        "function": {
            "name": check_user_subscription.__name__,
            "description": "Checks the current subscription status and tier level for a specific user ID.",
            "parameters": SubscriptionQuery.model_json_schema(),
        },
    },
]

AVAILABLE_FUNCTIONS = {
    "get_product_documentation": get_product_documentation,
    "check_user_subscription": check_user_subscription,
}


# --- 5. ORCHESTRATION ENGINE (The core AI Chatbot Architecture Logic) ---

def run_conversation(user_prompt: str, user_id: int) -> str:
    """
    @description: Manages the multi-step function calling process within a secure Server Action context.
    @process: Step 1 (Inference/Decision), Step 2 (Execution), Step 3 (Final Inference).
    """
    # 5.1. Initial Request Preparation
    messages = [
        {"role": "system", "content": f"You are a helpful SaaS assistant. The current user ID is {user_id}. Prioritize using tools to answer questions."},
        {"role": "user", "content": user_prompt}
    ]

    # API Call 1: Send prompt and available tools to the LLM
    response = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=messages,
        tools=TOOLS,
        tool_choice="auto" # Let the model decide if a tool is necessary
    )

    response_message = response.choices[0].message

    # 5.2. Tool Call Handling Block
    if response_message.tool_calls:
        print(f"\n-> Model requested tool execution: {response_message.tool_calls[0].function.name}")
        messages.append(response_message) # Append the model's request to call tools

        # Execute all requested tools sequentially
        for tool_call in response_message.tool_calls:
            function_name = tool_call.function.name
            function_to_call = AVAILABLE_FUNCTIONS.get(function_name)

            if not function_to_call:
                # Critical security check: prevent execution of unknown functions
                raise ValueError(f"Security Error: Unknown function requested: {function_name}")

            # Parse arguments, validated implicitly by the model's adherence to the Pydantic/Zod schema
            function_args = json.loads(tool_call.function.arguments)

            # Context Injection: If checking subscription, ensure the server-known user_id is used
            # This prevents user prompt manipulation of sensitive data access.
            if function_name == "check_user_subscription" and 'user_id' not in function_args:
                 function_args['user_id'] = user_id

            # Execute the actual business logic
            function_response = function_to_call(**function_args)

            # Append tool results back to the conversation history for the second call
            messages.append(
                {
                    "tool_call_id": tool_call.id,
                    "role": "tool",
                    "name": function_name,
                    "content": function_response,
                }
            )

        # 5.3. Second API Call (Re-inference with Tool Results)
        print("\n-> Second API Call: Sending tool results back to the model for final synthesis...")
        second_response = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=messages,
        )
        return second_response.choices[0].message.content

    # 5.4. No Tool Call (Direct response from LLM)
    return response_message.content


# --- 6. DEMONSTRATION & EXECUTION ---

print("--- Scenario 1: User asks for account specific data (Requires Subscription Tool) ---")
user_prompt_1 = "What is my current subscription tier and when does it renew? I am curious about my current status."
result_1 = run_conversation(user_prompt=user_prompt_1, user_id=1001)
print(f"\n[FINAL RESPONSE 1]\n{result_1}\n")

print("--- Scenario 2: User asks for general product data (Requires Documentation Tool) ---")
user_prompt_2 = "Can you tell me about the pricing structure for the Enterprise level and the associated HNSW index storage limits?"
result_2 = run_conversation(user_prompt=user_prompt_2, user_id=1002) # User ID 1002 is irrelevant here, demonstrating tool routing
print(f"\n[FINAL RESPONSE 2]\n{result_2}\n")

