
/*
 * These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
 * You can find the series on Amazon.
 * New books info: https://linktr.ee/edgarmilvus
 *
 * MIT License
 * Copyright (c) 2025 Edgar Milvus
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */

// Source File: solution_exercise_3.ts
// Description: Solution for Exercise 3
// ==========================================

// NOTE: This solution uses conceptual LangGraph syntax (TypeScript/JavaScript adaptation)
// as LangGraph is primarily a Python library, but the concepts translate directly.

import { z } from 'zod';
// Assume LangGraph interfaces are available
// import { StateGraph, END } from 'langgraph'; 

// 1. Define the Graph State
interface SupportTicketState {
    query: string;
    sla_level: 'Premium' | 'Standard' | 'Basic' | null;
    retrieval_result: string | null;
    final_response: string | null;
}

// 2. Tool Definitions and Stubs
const CheckSLASchema = z.object({
    customer_id: z.string().describe("The unique ID of the customer."),
});

function checkSLA(args: z.infer<typeof CheckSLASchema>): 'Premium' | 'Standard' | 'Basic' {
    console.log(`[Tool A] Checking SLA for ID: ${args.customer_id}`);
    if (args.customer_id.startsWith('P')) {
        return 'Premium';
    }
    return 'Standard';
}

const RetrieveKBSchema = z.object({
    topic: z.string().describe("The main topic of the support issue."),
});

function retrieveKnowledgeBase(args: z.infer<typeof RetrieveKBSchema>): string {
    console.log(`[Tool B] Retrieving KB for topic: ${args.topic}`);
    return "KB article 404: Steps for resetting password. Summary: Click 'Forgot Password', enter email, check spam folder.";
}

// 3. Define the Nodes (State Mutators)

// Mock LLM call to extract customer_id and update state
const sla_node = (state: SupportTicketState): Partial<SupportTicketState> => {
    // Simulate LLM extracting ID 'P1001' for a premium user
    const customer_id = state.query.includes("premium") ? "P1001" : "S5005";
    const level = checkSLA({ customer_id });
    return { sla_level: level };
};

const retrieval_node = (state: SupportTicketState): Partial<SupportTicketState> => {
    // Simulate LLM extracting topic 'password reset'
    const result = retrieveKnowledgeBase({ topic: "password reset" });
    return { retrieval_result: result };
};

const escalate_node = (state: SupportTicketState): Partial<SupportTicketState> => {
    console.log(`[Node C] Escalation triggered for Premium SLA.`);
    return { final_response: `Ticket immediately escalated to a human agent due to Premium SLA status.` };
};

const final_response_node = (state: SupportTicketState): Partial<SupportTicketState> => {
    if (state.retrieval_result) {
        return { final_response: `Based on the knowledge base: ${state.retrieval_result} - Please try these steps.` };
    }
    return { final_response: state.final_response || "Workflow completed." };
};

// 4. Define the Conditional Edge Predicate
const shouldEscalate = (state: SupportTicketState): 'escalate_node' | 'retrieval_node' => {
    console.log(`[Conditional Edge] Current SLA: ${state.sla_level}`);
    if (state.sla_level === 'Premium') {
        return 'escalate_node';
    }
    return 'retrieval_node';
};

// 5. Graph Construction (Conceptual LangGraph setup)
/*
const graph = new StateGraph<SupportTicketState>()
    .addNode("sla_node", sla_node)
    .addNode("retrieval_node", retrieval_node)
    .addNode("escalate_node", escalate_node)
    .addNode("final_response_node", final_response_node)
    .setEntryPoint("sla_node")
    // Conditional Edge Definition
    .addConditionalEdges("sla_node", shouldEscalate, {
        escalate_node: "escalate_node",
        retrieval_node: "retrieval_node",
    })
    // Standard Edges
    .addEdge("retrieval_node", "final_response_node")
    .addEdge("escalate_node", "final_response_node")
    .setFinishPoint("final_response_node");

const app = graph.compile();
*/

// Test Run Simulation (Premium Path)
let premiumState: SupportTicketState = { query: "My premium account is locked.", sla_level: null, retrieval_result: null, final_response: null };
premiumState = sla_node(premiumState); // sla_level: 'Premium'
// Conditional edge triggers escalate_node
premiumState = escalate_node(premiumState);
premiumState = final_response_node(premiumState);
console.log("\nPremium Path Result:", premiumState.final_response);

// Test Run Simulation (Standard Path)
let standardState: SupportTicketState = { query: "I need help resetting my password.", sla_level: null, retrieval_result: null, final_response: null };
standardState = sla_node(standardState); // sla_level: 'Standard'
// Conditional edge triggers retrieval_node
standardState = retrieval_node(standardState);
standardState = final_response_node(standardState);
console.log("\nStandard Path Result:", standardState.final_response);
