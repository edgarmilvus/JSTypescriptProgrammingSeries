
/*
 * These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
 * You can find the series on Amazon.
 * New books info: https://linktr.ee/edgarmilvus
 *
 * MIT License
 * Copyright (c) 2025 Edgar Milvus
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */

// Source File: solution_exercise_4.ts
// Description: Solution for Exercise 4
// ==========================================

import { z, ZodError } from 'zod';
import { mockOpenAICall } from './mock_openai'; // Mock API client

// Define the strict set of accepted namespaces
const NAMESPACES = ['hr-policies', 'finance-reports', 'it-guides'] as const;

// 1. Tool Definition and Zod Constraint
const SearchInternalDocsSchema = z.object({
    query_text: z.string().describe("The specific question or search query."),
    target_namespace: z.enum(NAMESPACES, {
        errorMap: () => ({ message: `Invalid namespace. Must be one of: ${NAMESPACES.join(', ')}` })
    }).describe("The Pinecone namespace corresponding to the query topic (e.g., 'hr-policies')."),
});

// 2. Namespace Integration Logic (Stubbing)
function searchInternalDocs(args: z.infer<typeof SearchInternalDocsSchema>): string {
    const { query_text, target_namespace } = args;
    
    console.log(`[Tool Executed] Searching Namespace: ${target_namespace}`);
    
    // Mock RAG result based on the selected namespace
    if (target_namespace === 'finance-reports') {
        return "Searching the `finance-reports` namespace returned the Q3 revenue summary showing 15% growth.";
    }
    if (target_namespace === 'hr-policies') {
        return "Searching the `hr-policies` namespace returned the remote work eligibility criteria.";
    }
    if (target_namespace === 'it-guides') {
        return "Searching the `it-guides` namespace returned the VPN configuration guide.";
    }
    return `Error: Unknown namespace ${target_namespace} reached execution (should have been caught by Zod).`;
}

// Orchestration Logic (Simplified)
function runRAGQuery(query: string, mockToolCall: object) {
    console.log(`\n--- Query: "${query}" ---`);
    
    // Simulate LLM response
    const response = {
        tool_calls: [{
            function: {
                name: 'searchInternalDocs',
                arguments: JSON.stringify(mockToolCall)
            }
        }]
    };

    const rawArgs = JSON.parse(response.tool_calls[0].function.arguments);

    try {
        const validatedArgs = SearchInternalDocsSchema.parse(rawArgs);
        const result = searchInternalDocs(validatedArgs);
        console.log("Result:", result);
    } catch (error) {
        if (error instanceof ZodError) {
            console.error("Validation Failed (Zod Error):", error.errors[0].message);
        } else {
            console.error("Execution Error:", error.message);
        }
    }
}

// 3. LLM Intent Mapping Tests (Simulated LLM output)

// Test A (HR Intent)
runRAGQuery("What is the policy regarding remote work eligibility and vacation accrual?", {
    query_text: "remote work eligibility and vacation accrual",
    target_namespace: "hr-policies"
});

// Test B (Finance Intent)
runRAGQuery("Can you summarize the Q4 earnings forecast and the current budget allocation for R&D?", {
    query_text: "Q4 earnings forecast and R&D budget",
    target_namespace: "finance-reports"
});

// Test C (IT Intent)
runRAGQuery("I need steps on how to configure my VPN connection and reset my multi-factor authentication token.", {
    query_text: "VPN configuration and MFA reset",
    target_namespace: "it-guides"
});

// 4. Error Handling (Constraint Enforcement Test)
runRAGQuery("Where are the marketing assets stored?", {
    query_text: "marketing assets location",
    target_namespace: "marketing-assets" // Invalid namespace
});
