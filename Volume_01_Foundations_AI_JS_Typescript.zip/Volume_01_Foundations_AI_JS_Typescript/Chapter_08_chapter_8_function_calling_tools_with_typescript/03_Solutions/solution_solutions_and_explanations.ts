/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2025 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

import { z, ZodError } from 'zod';
import { mockOpenAICall } from './mock_openai'; // Mock API client

// 1. Tool Definitions (Zod Schemas)
const ACCEPTED_CURRENCIES = ['USD', 'EUR', 'GBP', 'JPY'] as const;

const ConvertCurrencySchema = z.object({
    amount: z.number().positive("Amount must be a positive number."),
    from_currency: z.enum(ACCEPTED_CURRENCIES, {
        errorMap: () => ({ message: `Invalid currency code. Must be one of: ${ACCEPTED_CURRENCIES.join(', ')}` })
    }),
    to_currency: z.enum(ACCEPTED_CURRENCIES, {
        errorMap: () => ({ message: `Invalid currency code. Must be one of: ${ACCEPTED_CURRENCIES.join(', ')}` })
    }),
});

const CalculateSimpleInterestSchema = z.object({
    principal: z.number().positive("Principal must be positive."),
    rate: z.number().positive("Rate must be positive."),
    time_years: z.number().positive("Time (years) must be positive."),
});

// Map tool names to their schemas
const toolSchemas = {
    convertCurrency: ConvertCurrencySchema,
    calculateSimpleInterest: CalculateSimpleInterestSchema,
};

// 2. Tool Implementation (Stubs)
function convertCurrency(args: z.infer<typeof ConvertCurrencySchema>): string {
    const { amount, from_currency, to_currency } = args;
    // Mock conversion logic
    const mockRate = (from_currency === 'GBP' && to_currency === 'USD') ? 1.25 : 1.0;
    const result = (amount * mockRate).toFixed(2);
    return `The conversion result is $${result} based on the LLM's request for ${amount} ${from_currency} to ${to_currency}.`;
}

function calculateSimpleInterest(args: z.infer<typeof CalculateSimpleInterestSchema>): string {
    const { principal, rate, time_years } = args;
    const interest = principal * (rate / 100) * time_years;
    const futureValue = principal + interest;
    return `The investment of $${principal} held for ${time_years} years at ${rate}% results in a future value of $${futureValue.toFixed(2)}.`;
}

const toolFunctions = {
    convertCurrency,
    calculateSimpleInterest,
};

// 3. Orchestration Logic
async function handleFinancialQuery(query: string) {
    console.log(`\n--- Processing Query: "${query}" ---`);

    // Step 1: LLM Call (Mocked)
    const response = mockOpenAICall(query, [
        { type: "function", function: { name: "convertCurrency", parameters: ConvertCurrencySchema } },
        { type: "function", function: { name: "calculateSimpleInterest", parameters: CalculateSimpleInterestSchema } },
    ]);

    if (!response.tool_calls || response.tool_calls.length === 0) {
        return `LLM Direct Response: ${response.content}`;
    }

    const toolCall = response.tool_calls[0];
    const toolName = toolCall.function.name;
    const rawArgs = JSON.parse(toolCall.function.arguments);

    console.log(`LLM requested tool: ${toolName} with raw arguments:`, rawArgs);

    if (!toolSchemas[toolName]) {
        return `Error: Unknown tool requested: ${toolName}`;
    }

    // Step 2: Validation using Zod
    try {
        const schema = toolSchemas[toolName];
        const validatedArgs = schema.parse(rawArgs);
        console.log("Validation Successful. Executing tool...");

        // Step 3: Execution
        const toolFunction = toolFunctions[toolName];
        const result = toolFunction(validatedArgs as any);

        // In a real system, this result would be sent back to the LLM for final synthesis.
        return `Tool Execution Result: ${result}`;

    } catch (error) {
        if (error instanceof ZodError) {
            const validationErrors = error.errors.map(e => `Path: ${e.path.join('.')}, Issue: ${e.message}`).join('; ');
            const errorMessage = `Tool execution failed due to invalid input detected by Zod: ${validationErrors}`;
            console.error("Validation Failed:", errorMessage);
            // This error message would typically be sent back to the LLM for self-correction.
            return `User Response: ${errorMessage}`;
        }
        return `An unexpected error occurred: ${error.message}`;
    }
}

// 4. Testing Prompts (Mocked Responses based on query intent)
// Mock implementation detail (not shown, assumes mockOpenAICall returns appropriate tool calls)

// Test 1 (Success)
await handleFinancialQuery("If I have 500 GBP, how much is that in USD?");
// Expected tool call: convertCurrency({ amount: 500, from_currency: 'GBP', to_currency: 'USD' })

// Test 2 (Success)
await handleFinancialQuery("What is the future value of a $10,000 investment held for 3 years at a 4.5% rate?");
// Expected tool call: calculateSimpleInterest({ principal: 10000, rate: 4.5, time_years: 3 })

// Test 3 (Failure/Validation Test)
await handleFinancialQuery("Convert 100 dollars to space bucks.");
// Expected tool call: convertCurrency({ amount: 100, from_currency: 'USD', to_currency: 'SBC' }) 
// (SBC is not in the Zod enum, triggering failure)
