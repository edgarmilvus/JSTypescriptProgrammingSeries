/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2025 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

import { z } from 'zod';
import { mockOpenAICall } from './mock_openai'; // Mock API client

// 1. Tool Definition
const GetProductInventorySchema = z.object({
    product_sku: z.string().describe("The unique product identifier."),
    warehouse_id: z.string().optional().describe("The ID of the warehouse to check."),
});

// Stub Implementation with Latency
async function getProductInventory(args: z.infer<typeof GetProductInventorySchema>): Promise<string> {
    const { product_sku, warehouse_id = 'Default' } = args;
    console.log(`[Tool Executing] Simulating 2s API call for SKU: ${product_sku} at Warehouse: ${warehouse_id}...`);
    // Simulate network latency
    await new Promise(resolve => setTimeout(resolve, 2000));

    if (product_sku.includes("widget")) {
        return `Inventory check complete. SKU ${product_sku} has 45 units in stock at ${warehouse_id}.`;
    }
    return `Inventory check complete. SKU ${product_sku} is out of stock.`;
}

// 2. Backend API Endpoint Logic (Conceptual Headless Inference)
async function handleQuery(query: string) {
    // State 1: Initial LLM call
    let firstResponse = mockOpenAICall(query, [
        { type: "function", function: { name: "getProductInventory", parameters: GetProductInventorySchema } }
    ]);

    if (!firstResponse.tool_calls || firstResponse.tool_calls.length === 0) {
        // State 1: Direct Answer (No Tool)
        return {
            status: 'complete',
            final_response: firstResponse.content,
        };
    }

    const toolCall = firstResponse.tool_calls[0];
    const toolName = toolCall.function.name;
    const rawArgs = JSON.parse(toolCall.function.arguments);

    // State 2: Tool Requested/Pending (Data Contract for UI)
    const toolRequestPayload = {
        status: 'tool_used',
        tool_name: toolName,
        tool_arguments: rawArgs,
    };
    console.log("--- Frontend Contract (State 2): Tool Requested ---", toolRequestPayload);

    // Execute the tool (this is where the 2-second delay happens)
    const toolResult = await getProductInventory(rawArgs);

    // State 3: Second LLM Call (Tool Result Injection)
    const messages = [
        { role: "user", content: query },
        { role: "assistant", tool_calls: [toolCall] },
        { role: "tool", tool_call_id: toolCall.id, content: toolResult }
    ];

    let finalResponse = mockOpenAICall(messages, []); // Second call uses the tool result

    // State 3: Tool Execution Complete (Final Answer)
    return {
        status: 'complete',
        final_response: finalResponse.content,
        tool_execution_summary: toolResult,
    };
}

// 4. Interactive Challenge Test
console.log("Starting Query...");
const result = await handleQuery("Do you have any size 10 widgets in stock at the Dallas warehouse?");
console.log("\n--- Final Backend Response (State 3) ---");
console.log(JSON.stringify(result, null, 2));

/* Example Mocked Output:
--- Frontend Contract (State 2): Tool Requested --- {
  "status": "tool_used",
  "tool_name": "getProductInventory",
  "tool_arguments": {
    "product_sku": "size 10 widgets",
    "warehouse_id": "Dallas"
  }
}
[Tool Executing] Simulating 2s API call for SKU: size 10 widgets at Warehouse: Dallas...
(2 seconds pass)
--- Final Backend Response (State 3) ---
{
  "status": "complete",
  "final_response": "Yes, based on the inventory check, we currently have 45 units of size 10 widgets available at the Dallas warehouse.",
  "tool_execution_summary": "Inventory check complete. SKU size 10 widgets has 45 units in stock at Dallas."
}
*/
