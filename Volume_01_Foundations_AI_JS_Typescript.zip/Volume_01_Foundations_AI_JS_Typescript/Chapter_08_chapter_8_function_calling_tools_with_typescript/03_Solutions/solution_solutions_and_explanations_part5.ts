/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2025 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

import { z, ZodError } from 'zod';

// 1. Modular Structure: Tool Definition
const CalculateShippingCostSchema = z.object({
    weight_kg: z.number().positive("Weight must be a positive number greater than zero."),
    destination_zip: z.string().regex(/^\d{5}$/, "ZIP code must be exactly 5 digits."),
});

interface ToolModule {
    schema: z.ZodSchema<any>;
    execute: (args: any) => string;
}

const ShippingTool: ToolModule = {
    schema: CalculateShippingCostSchema,
    execute: (args: z.infer<typeof CalculateShippingCostSchema>): string => {
        const cost = args.weight_kg * 5 + (args.destination_zip.startsWith('9') ? 10 : 0);
        return `Shipping cost calculated: $${cost.toFixed(2)} for ${args.weight_kg}kg to ZIP ${args.destination_zip}.`;
    }
};

const toolRegistry: Record<string, ToolModule> = {
    calculateShippingCost: ShippingTool,
};

// 3. Isolated Validation Function
function validateToolArguments(toolName: string, rawArgs: object): object | object {
    const tool = toolRegistry[toolName];
    if (!tool) {
        throw new Error(`Tool ${toolName} not found.`);
    }

    try {
        // Attempt validation
        return tool.schema.parse(rawArgs);
    } catch (error) {
        if (error instanceof ZodError) {
            // Structure the error report for the LLM
            const errorDetails = error.issues.map(issue => ({
                path: issue.path,
                message: issue.message,
                received_value: (rawArgs as any)[issue.path[0]], // Extract the specific invalid value
            }));

            return {
                tool_name: toolName,
                status: "validation_failed",
                error_details: errorDetails,
                instruction: "Please review the required data types and format your arguments correctly for your next attempt. Pay attention to number vs. string types and required formats.",
            };
        }
        throw error;
    }
}

// 4. Execution and Self-Correction Loop
function executeToolWithValidation(toolName: string, rawArgs: object) {
    console.log(`\nAttempting to execute tool: ${toolName}`);
    console.log("Raw LLM Arguments:", rawArgs);

    const validationResult = validateToolArguments(toolName, rawArgs);

    if (validationResult.status === 'validation_failed') {
        console.error("--- Validation Failed. Generating Error Report for LLM ---");
        console.log(JSON.stringify(validationResult, null, 2));
        // This JSON object is what is returned to the LLM as the "function result"
        return validationResult;
    }

    console.log("Validation successful. Executing tool...");
    const tool = toolRegistry[toolName];
    const result = tool.execute(validationResult);
    return result;
}

// Test Case (Failure/Self-Correction)
const failedArgs = {
    weight_kg: "ten", // Invalid type: string instead of number
    destination_zip: "123456" // Invalid format: 6 digits instead of 5
};

executeToolWithValidation('calculateShippingCost', failedArgs);

// Test Case (Success)
const successArgs = {
    weight_kg: 10.5,
    destination_zip: "90210"
};

executeToolWithValidation('calculateShippingCost', successArgs);
