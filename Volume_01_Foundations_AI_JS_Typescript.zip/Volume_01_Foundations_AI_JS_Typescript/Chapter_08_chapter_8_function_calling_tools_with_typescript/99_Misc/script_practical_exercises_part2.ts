/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2025 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part2.ts
// Description: Practical Exercises
// ==========================================

digraph Workflow {
    rankdir=TB;
    node [shape=box];

    // Define Nodes
    A [label="LLM/SLA Check (sla_node)"];
    B [label="Knowledge Retrieval (retrieval_node)"];
    C [label="Human Escalation (escalate_node)"];
    D [label="Final Response Generation"];

    // Define Edges
    // Initial Start
    start -> A;

    // Conditional Edge from A
    A -> C [label="SLA == Premium"];
    A -> B [label="SLA != Premium"];

    // Transitions to Final Response
    B -> D;
    C -> D;

    // Final Stop
    D -> end;
}
</DOT_DIAGRAM>

### Exercise 4: RAG Tooling with Pinecone Namespaces for Contextual Retrieval

This exercise focuses on creating a specialized Function Calling tool designed for Retrieval-Augmented Generation (RAG). To ensure highly relevant results and manage large datasets efficiently, the tool must utilize the concept of a **Namespace** within a Pinecone vector index. The LLM’s role is to determine the correct logical partition (Namespace) based on the user's intent.

#### Problem Description

A large corporation stores its internal documents (HR Policies, Financial Reports, and IT Guides) within a single Pinecone index, partitioned into three namespaces: `hr-policies`, `finance-reports`, and `it-guides`. The intelligent assistant needs a single tool, `searchInternalDocs`, that can perform vector similarity search but must first correctly identify which namespace to query based on the user's question.

The core challenge is defining the Zod schema such that the LLM is constrained to selecting only one of the valid namespaces.

#### Requirements

1.  **Tool Definition: `searchInternalDocs`**
    *   Define the tool that handles the RAG operation.
    *   *Parameters:*
        *   `query_text`: The user's question or search query (string).
        *   `target_namespace`: The specific Pinecone Namespace to search.
    *   *Zod Constraint:* The `target_namespace` parameter must be strictly limited to the three defined values (`hr-policies`, `finance-reports`, `it-guides`) using a Zod enumeration (`z.enum`).

2.  **Namespace Integration Logic (Stubbing):**
    *   Create the TypeScript stub function for `searchInternalDocs`.
    *   This function should accept the `query_text` and the `target_namespace`.
    *   The stub should log which namespace was selected by the LLM and return a mock result that reflects the context (e.g., "Searching the `finance-reports` namespace returned the Q3 revenue summary.").

3.  **LLM Intent Mapping Test:** Implement the orchestration logic and test the system with the following three queries, ensuring the LLM correctly maps the intent to the required Namespace before executing the tool:

    *   *Test A (HR Intent):* "What is the policy regarding remote work eligibility and vacation accrual?"
    *   *Test B (Finance Intent):* "Can you summarize the Q4 earnings forecast and the current budget allocation for R&D?"
    *   *Test C (IT Intent):* "I need steps on how to configure my VPN connection and reset my multi-factor authentication token."

4.  **Error Handling (Constraint Enforcement):** Demonstrate how your Zod validation prevents the LLM from attempting to query an invalid or non-existent namespace (e.g., if the LLM hallucinated a namespace like `marketing-assets`). Show the error message generated when the validation fails.

### Exercise 5: Refactoring for Tool Execution Isolation and Error Reporting

This exercise focuses on improving the robustness and maintainability of the tool execution layer by separating the tool definition, validation, and execution into distinct, reusable modules. This is crucial for large-scale applications where tools might be shared across multiple LLM agents.

#### Problem Description

You have inherited a monolithic tool execution handler where Zod validation and function execution are tightly coupled within a single switch statement. This makes error reporting difficult and prevents easy unit testing of the validation layer.

Your task is to refactor the system into a modular architecture that specifically isolates the Zod validation step. If the LLM provides arguments that fail validation, the system must capture the specific Zod error details and return a structured error message to the LLM, allowing the model to self-correct its next function call attempt.

#### Requirements

1.  **Modular Structure:** Define a standardized pattern (e.g., an interface or base class) for all tools that mandates the separation of schema definition and execution logic.

2.  **Tool Definition: `calculateShippingCost`**
    *   Define a tool with parameters: `weight_kg` (number, must be > 0), `destination_zip` (string, must be 5 digits).
    *   Create the corresponding Zod schema.

3.  **Isolated Validation Function:**
    *   Implement a dedicated TypeScript function, `validateToolArguments(toolName: string, args: object)`, which takes the tool name and the raw arguments received from the OpenAI API.
    *   This function must attempt to parse the arguments using the correct Zod schema.
    *   If validation succeeds, it returns the validated, typed object.
    *   If validation fails, it must catch the Zod error (`z.ZodError`) and return a structured JSON object detailing the specific path and type of validation failure (e.g., "Field `weight_kg` failed validation: Expected number, received string").

4.  **Execution and Self-Correction Loop:**
    *   Implement the main orchestration loop (`executeToolWithValidation`).
    *   When the LLM calls `calculateShippingCost`, the loop must first pass the arguments through `validateToolArguments`.
    *   **Test Case (Failure/Self-Correction):** Simulate an LLM output where `weight_kg` is provided as the string `"ten"` instead of the number `10`. The system must detect this failure via Zod, generate the structured error report detailing the validation failure, and feed this error report back into the LLM as the result of the function call. (The requirement is to show the *input* to the LLM for the subsequent turn, not the final response.)

