/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2025 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.ts
// Description: Basic Code Example
// ==========================================

// app/actions.ts

import { createAI, createStreamableUI } from 'ai/rsc';
import { ChatOpenAI } from '@langchain/openai';
import { SalesChart } from '@/components/ui/sales-chart';
import { RegionList } from '@/components/ui/region-list';
import { ReactNode } from 'react';

// --- STATE DEFINITIONS ---

// 1. UIState: What the client renders. An array of displayable React nodes.
type UIState = {
  id: number;
  display: ReactNode;
}[];

// 2. AIState: What the server tracks (conversation history, context).
type AIState = {
  id: number;
  role: 'user' | 'assistant';
  content: string;
}[];

// Initialize LLM (using LangChain wrapper for robust streaming handling)
const llm = new ChatOpenAI({
  modelName: 'gpt-4o-mini',
  temperature: 0.2,
  // Note: API Key must be set in environment variables (OPENAI_API_KEY)
});

/**
 * Handles the user's message, streams text, and dynamically injects components.
 * @param input The user's prompt (e.g., "Summarize Q3 data and visualize top regions").
 */
async function submitUserMessage(input: string): Promise<UIState> {
  'use server'; // CRITICAL: Marks this function as a Next.js Server Action

  // 1. Initialize the main streamable UI container (the final output wrapper)
  const ui = createStreamableUI(
    <p className="text-gray-500 italic">Analyzing request: "{input}"...</p>
  );

  // 2. Initialize a separate stream for raw text (to handle incremental token delivery)
  const textStream = createStreamableUI('');

  // 3. Start the LLM request
  const responseStream = await llm.stream([
    ['system', 'You are a concise business analyst AI focused on sales data.'],
    ['user', input],
  ]);

  // 4. Asynchronously process the stream and update the UI
  (async () => {
    let fullResponse = '';

    // Stream 4a: Process raw text tokens
    for await (const chunk of responseStream) {
      const content = chunk.content;
      if (content) {
        fullResponse += content;
        textStream.update(fullResponse); // Update the raw text stream incrementally
      }
    }

    // Stream 4b: Conditional Component Delivery (Generative UI Logic)
    if (input.toLowerCase().includes('visualize')) {
      
      // Update the main UI stream to include the streamed text and the first component
      // ui.update() replaces the previous content of 'ui' (which was "Analyzing request...")
      ui.update(
        <div className="flex flex-col space-y-4">
          <p className="border-b pb-2">{textStream.value}</p> 
          
          {/* Component 1: Sales Chart */}
          <div className="p-4 border rounded-lg bg-gray-50">
            <h3 className="text-lg font-semibold mb-2">Q3 Sales Overview (Streaming Component 1)</h3>
            <SalesChart data={[{ q: 100 }, { q: 150 }]} />
          </div>
        </div>
      );

      // 5. Simulate waiting for a complex data fetching process (e.g., fetching regional data)
      await new Promise(resolve => setTimeout(resolve, 1800));

      // 6. Append the second component to the existing UI structure
      // ui.append() adds content *after* the current ui.value.
      ui.append(
        <div className="p-4 border rounded-lg bg-blue-50">
          <h3 className="text-lg font-semibold mb-2">Top Performing Regions (Streaming Component 2)</h3>
          <RegionList regions={['North America', 'EMEA', 'APAC']} />
        </div>
      );
    } else {
        // If no visualization requested, just finalize with the text.
        ui.done(textStream.value);
    }

    // 7. Finalize the main UI stream if it hasn't been done yet (e.g., if we used ui.update)
    if (!ui.isDone) {
        // Here, we ensure the final structure is sent if we used update/append logic.
        // We wrap the components (ui.value) and the text (textStream.value) together.
        ui.done(
            <div className="flex flex-col space-y-4">
                <p className="border-b pb-2">{textStream.value}</p> 
                {ui.value}
            </div>
        );
    }

  })(); // Execute the streaming logic immediately

  // 8. Return the initial UIState for the client to start rendering the stream wrapper.
  return [
    {
      id: Date.now(),
      display: ui.value, // The client renders the streamable placeholder
    },
  ];
}

// 9. Initialize the AI instance used by the client components
export const AI = createAI<AIState, UIState>({
  actions: {
    submitUserMessage,
  },
  initialAIState: [],
  initialUIState: [],
});
