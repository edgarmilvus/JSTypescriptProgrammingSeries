/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2025 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example_part3.tsx
// Description: Basic Code Example
// ==========================================

// app/page.tsx
'use client';

import { useActions, useUIState } from 'ai/rsc';
import { AI } from './actions'; // Import the initialized AI instance
import { useState, FormEvent } from 'react';

// Wrap the application in the AI context provider
export default function Chat() {
  return (
    <AI>
      <ChatUI />
    </AI>
  );
}

function ChatUI() {
  const [input, setInput] = useState('');
  const [messages, setMessages] = useUIState();
  const { submitUserMessage } = useActions();

  /**
   * Handles form submission, sending the message to the Server Action.
   */
  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if (!input.trim()) return;

    const userMessage = {
      id: Date.now(),
      display: <div className="p-2 bg-blue-100 rounded-lg">User: {input}</div>,
    };

    // 1. Optimistically update the UI with the user's message
    setMessages(currentMessages => [...currentMessages, userMessage]);

    // 2. Call the Server Action and receive the streamed UIState
    const response = await submitUserMessage(input);

    // 3. Update the UIState with the streamed response (which includes the components)
    setMessages(currentMessages => [...currentMessages, ...response]);
    setInput('');
  };

  return (
    <div className="max-w-3xl mx-auto p-8">
      <h1 className="text-2xl font-bold mb-6">Generative UI Stream Demo</h1>
      
      {/* Display Streamed Messages and Components */}
      <div className="space-y-4 mb-8 h-[50vh] overflow-y-auto border p-4 rounded-lg bg-gray-50">
        {messages.map((message) => (
          <div key={message.id}>{message.display}</div>
        ))}
      </div>

      {/* Input Form */}
      <form onSubmit={handleSubmit} className="flex space-x-2">
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Ask to 'Summarize and visualize Q3 data'..."
          className="flex-grow p-3 border rounded-lg focus:ring-2 focus:ring-indigo-500"
        />
        <button
          type="submit"
          className="p-3 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition"
        >
          Send
        </button>
      </form>
    </div>
  );
}
