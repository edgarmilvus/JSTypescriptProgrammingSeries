/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2025 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example_part4.ts
// Description: Basic Code Example
// ==========================================

rankdir=TB;
node [shape=box, style="filled", fillcolor="#E6F3FF"];

subgraph cluster_server {
    label = "Server (RSC Environment)";
    bgcolor="#F0F8FF";
    A [label="1. User calls Server Action (submitUserMessage)", fillcolor="#C3E6CB"];
    B [label="2. createStreamableUI (ui) initialized"];
    C [label="3. LLM Stream Initiated (Async)"];
    D [label="4. Stream Text Tokens (textStream.update)"];
    E [label="5. Server detects 'visualize' intent"];
    F [label="6. Stream Component 1 (ui.update(<SalesChart/>))", fillcolor="#FFE0B2"];
    G [label="7. Wait for Data (1.8s delay)"];
    H [label="8. Stream Component 2 (ui.append(<RegionList/>))", fillcolor="#FFE0B2"];
    I [label="9. ui.done() / Stream Closed", fillcolor="#C3E6CB"];
}

subgraph cluster_client {
    label = "Client (Browser/React)";
    bgcolor="#FFF0F5";
    J [label="10. Client receives initial UIState (Stream Wrapper)", fillcolor="#F5CBA7"];
    K [label="11. Client receives Text Updates (Incremental Rendering)"];
    L [label="12. Client receives <SalesChart/> (Renders Component 1)"];
    M [label="13. Client receives <RegionList/> (Appends Component 2)"];
    N [label="14. Final UI Rendered"];
}

A -> B [label="Returns initial ui.value"];
B -> J [label="Initial Payload (UIState)"];
C -> D [label="LLM Output"];
D -> K [label="Text Chunks"];
E -> F [label="Decision Logic"];
F -> L [label="Component 1 Payload"];
G -> H [label="Delayed Delivery"];
H -> M [label="Component 2 Payload"];
I -> N [label="Stream Closure"];
}
