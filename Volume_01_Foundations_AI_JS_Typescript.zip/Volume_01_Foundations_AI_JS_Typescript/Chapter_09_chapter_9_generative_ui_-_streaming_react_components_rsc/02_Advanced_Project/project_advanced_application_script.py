# These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
# You can find the series on Amazon.
# New books info: https://linktr.ee/edgarmilvus
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

# 1. Imports and Setup (Simulating TS environment components)
import asyncio
from typing import AsyncGenerator, Literal, Any, Dict
from pydantic import BaseModel, Field
import json

# --- 2. Define Structured Output Schemas (Simulating Component Definition via Zod/Pydantic) ---

class KPIBlockProps(BaseModel):
    """Props for a Key Performance Indicator component."""
    metric: str = Field(description="The name of the KPI.")
    value: str = Field(description="The current value of the metric.")
    trend: Literal["up", "down", "flat"]

class TaskListProps(BaseModel):
    """Props for a list of urgent tasks."""
    tasks: list[str] = Field(description="A list of task descriptions.")
    priority_level: Literal["High", "Medium"]

class UIChunk(BaseModel):
    """
    A single streamable unit, representing either raw text or a component definition.
    This structure is central to the 'streamable-ui' pattern.
    """
    type: Literal["text", "component"]
    content: str | Dict[str, Any]
    component_name: str | None = None

# --- 3. Mock LLM Response (Simulating Streaming and Latency) ---

async def mock_llm_stream(prompt: str) -> AsyncGenerator[str, None]:
    """
    Simulates the LLM generating tokens incrementally and the server injecting
    structured component definitions based on the AI's intent.
    """
    print(f"Server: Processing prompt: '{prompt[:30]}...'")
    
    # 3a. Initial text response (fast delivery)
    yield json.dumps(UIChunk(type="text", content="Generating personalized dashboard...").model_dump()) + "\n"
    await asyncio.sleep(0.1)
    
    # 3b. First Component (KPI Block) - Requires simulated data fetching delay
    # The LLM outputs structured data conforming to KPIBlockProps.
    kpi_data = KPIBlockProps(metric="Q3 Revenue", value="$1.2M", trend="up")
    yield json.dumps(UIChunk(type="component", content=kpi_data.model_dump(), component_name="KPIBlock").model_dump()) + "\n"
    await asyncio.sleep(0.8) # Simulating database lookup/calculation delay
    
    # 3c. Intermediate text update
    yield json.dumps(UIChunk(type="text", content="Analyzing urgent tasks...").model_dump()) + "\n"
    await asyncio.sleep(0.1)
    
    # 3d. Second Component (Task List) - Streamed immediately after generation
    task_data = TaskListProps(tasks=["Review Q4 Budget", "Finalize Migration Plan"], priority_level="High")
    yield json.dumps(UIChunk(type="component", content=task_data.model_dump(), component_name="TaskList").model_dump()) + "\n"
    await asyncio.sleep(0.5) # Simulating generation completion
    
    # 3e. Final text wrap-up
    yield json.dumps(UIChunk(type="text", content="Dashboard complete.").model_dump()) + "\n"

# --- 4. The Edge Runtime Handler (Generative UI Core Logic) ---

async def handle_generative_ui_request(user_prompt: str):
    """
    The main handler, simulating the Vercel AI SDK/Server Action running 
    in the Edge Runtime. This function manages the stream.
    """
    print("Edge Runtime: Starting Generative UI stream...")
    
    async for chunk_json in mock_llm_stream(user_prompt):
        # 4a. Parse the streamed JSON chunk
        chunk_data = json.loads(chunk_json.strip())
        
        # 4b. Server-side processing/validation (minimal latency)
        if chunk_data['type'] == 'component':
            comp_name = chunk_data['component_name']
            props = chunk_data['content']
            # Log the component definition being prepared for streaming
            print(f"  [STREAMING COMPONENT]: Defined <{comp_name}> (Props: {props.get('metric', props.get('priority_level'))})")
            
        elif chunk_data['type'] == 'text':
            print(f"  [STREAMING TEXT]: {chunk_data['content']}")
            
        # 4c. Yield the raw streamable unit (simulating network delivery to client)
        yield chunk_json
        
# --- 5. Client Simulation (Receiving the Stream and Updating UIState) ---

async def client_receive_stream(stream):
    """
    Simulates the browser client receiving the stream and updating the UIState
    to render the components immediately.
    """
    print("\nClient: Awaiting incremental UI updates...")
    async for chunk_json in stream:
        chunk = json.loads(chunk_json.strip())
        
        # This is where the client-side Vercel AI SDK runtime updates the UIState
        # and renders the associated React component.
        
        if chunk['type'] == 'component':
            print(f"  [RENDERED]: Displaying {chunk['component_name']} immediately with data.")
        else:
            print(f"  [RENDERED]: Appending text: '{chunk['content']}'")

# --- 6. Execution ---

async def main():
    prompt = "Generate a summary dashboard focusing on Q3 performance and high-priority tasks."
    server_stream = handle_generative_ui_request(prompt)
    await client_receive_stream(server_stream)

if __name__ == "__main__":
    asyncio.run(main())
