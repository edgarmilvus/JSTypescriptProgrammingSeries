
/*
 * These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
 * You can find the series on Amazon.
 * New books info: https://linktr.ee/edgarmilvus
 *
 * MIT License
 * Copyright (c) 2025 Edgar Milvus
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */

// Source File: solution_exercise_2.tsx
// Description: Solution for Exercise 2
// ==========================================

// 1. Secure Data Fetching in SCs
async function fetchUserProfile(userId: string) {
    console.log(`[Server] Fetching sensitive data for user: ${userId}`);
    // Simulate database latency (500ms)
    await new Promise(resolve => setTimeout(resolve, 500)); 
    return {
        name: "Alex Johnson",
        pendingTasks: 4,
        lastLogin: "2024-10-20T10:00:00Z"
    };
}

// 2. Contextual Prompt Construction & LLM Call Simulation
async function generateGreeting(context: any): Promise<string> {
    console.log("[Server] Calling LLM with contextual data...");
    // Simulate LLM latency (1000ms)
    await new Promise(resolve => setTimeout(resolve, 1000)); 
    
    const prompt = `Generate a personalized, warm welcome message and summary for ${context.name}. Mention their last login date (${new Date(context.lastLogin).toLocaleDateString()}) and that they have ${context.pendingTasks} pending tasks. Keep the entire response concise.`;
    
    // In a real app, this prompt would be sent to the LLM.
    const generatedText = `Welcome back, ${context.name}! Since your last visit on ${new Date(context.lastLogin).toLocaleDateString()}, you have ${context.pendingTasks} urgent tasks waiting. Here is your summary...`;
    return generatedText;
}

// UserGreetingAI.tsx (Server Component)
export async function UserGreetingAI({ userId }: { userId: string }) {
    // Sequential execution: Data fetch blocks the component render
    const userContext = await fetchUserProfile(userId); 
    
    // LLM call blocks the component render until complete
    const greetingText = await generateGreeting(userContext); 

    // This component will only render once both async steps are complete (approx 1500ms total)
    return (
        <div className="ai-greeting">
            <h1 style={{ color: '#0070f3' }}>{greetingText}</h1>
            <p>This message was generated using secure, server-side data.</p>
        </div>
    );
}

// DashboardParent.tsx (Parent Component)
import React from 'react';

const FallbackComponent = () => (
    <div className="loading-state" style={{ border: '1px dashed orange', padding: '10px' }}>
        <p>Loading personalized AI summary (Fetching data and running LLM)...</p>
    </div>
);

// 3. Suspense Implementation
export default function DashboardParent() {
    const userId = "user-123"; 

    return (
        <section>
            <h2>My Personalized Dashboard</h2>
            {/* Suspense boundary manages the latency of the UserGreetingAI SC */}
            <React.Suspense fallback={<FallbackComponent />}>
                <UserGreetingAI userId={userId} />
            </React.Suspense>
            <div style={{ marginTop: '20px' }}>
                Quick Links Section (Renders immediately while AI component loads)
            </div>
        </section>
    );
}

// 4. Analysis Note: The sequential execution (fetch then LLM) means the total latency 
// is additive (500ms + 1000ms). Suspense ensures the client receives the lightweight 
// FallbackComponent immediately, preventing the entire page from blocking.
