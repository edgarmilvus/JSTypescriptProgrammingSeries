
/*
 * These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
 * You can find the series on Amazon.
 * New books info: https://linktr.ee/edgarmilvus
 *
 * MIT License
 * Copyright (c) 2025 Edgar Milvus
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */

// Source File: solution_exercise_3.py
// Description: Solution for Exercise 3
// ==========================================

# Python implementation using LangGraph and Pydantic

from typing import TypedDict, Annotated, List
from langgraph.graph import StateGraph, END, START
from pydantic import BaseModel, Field
import json
import operator

# 1. State Definition (TypedDict for LangGraph state)
class AgentState(TypedDict):
    query: str
    tool_calls: list
    # Annotated ensures the 'iterations' field is incremented
    iterations: Annotated[int, operator.add] 
    tool_output: str
    final_output: dict
    needs_tool_call: bool

# 3. Agent Output Structure (Pydantic Schema)
class WarningCardComponent(BaseModel):
    componentType: str = Field(default="WarningCard", description="Type of UI component.")
    title: str = Field(description="Title of the warning.")
    message: str = Field(description="The detailed warning message.")
    data_summary: dict = Field(description="The underlying data that triggered the warning.")

MAX_ITERATIONS = 3 # Max Iteration Policy constant

# Node Functions
def plan_node(state: AgentState) -> AgentState:
    """Simulates the LLM planning step."""
    # Increment iteration count
    current_iterations = state.get('iterations', 0)
    
    # Simple logic: Force one tool call, then synthesize
    if current_iterations == 0:
        print(f"--- Iteration {current_iterations + 1} --- Planning: Needs tool.")
        return {
            "iterations": 1,
            "needs_tool_call": True,
            "tool_calls": [{"name": "get_inventory_data"}]
        }
    else:
        print(f"--- Iteration {current_iterations + 1} --- Planning: Ready for synthesis.")
        return {
            "iterations": 1, # Only incrementing by 1 per step
            "needs_tool_call": False,
        }

def tool_execution_node(state: AgentState) -> AgentState:
    """Simulates executing the required tool."""
    print("Executing Tool: get_inventory_data...")
    # Simulate data retrieval
    inventory_data = {
        "widget_X": {"warehouse_A": 50, "warehouse_B": 80},
        "threshold": 100
    }
    # Increment iteration count
    return {
        "tool_output": json.dumps(inventory_data),
        "iterations": 1, 
    }

def final_synthesis_node(state: AgentState) -> AgentState:
    """Generates the final structured UI component definition."""
    print("Synthesizing Final UI Component...")
    data = json.loads(state['tool_output'])
    total_stock = sum(data['widget_X'].values())
    
    if total_stock < data['threshold']:
        title = "CRITICAL INVENTORY ALERT"
        message = f"Total stock for Widget X is {total_stock}, below threshold {data['threshold']}."
    else:
        title = "Inventory OK"
        message = f"Total stock for Widget X is {total_stock}."
        
    final_component = WarningCardComponent(title=title, message=message, data_summary=data)
    
    return {"final_output": final_component.model_dump()}

def error_state_node(state: AgentState) -> AgentState:
    """Handles the Max Iteration Policy failure."""
    print(f"ERROR: Max iterations ({MAX_ITERATIONS}) reached.")
    error_component = {
        "componentType": "ErrorCard",
        "title": "Agent Timeout",
        "message": f"The query failed to resolve within {MAX_ITERATIONS} steps due to complex reasoning or loop detection."
    }
    return {"final_output": error_component}


# 2. Max Iteration Policy Implementation (Conditional Edge Logic)
def check_max_iterations(state: AgentState) -> str:
    """Determines the next step based on iteration count and need for tools."""
    current_count = state.get('iterations', 0)
    
    if current_count > MAX_ITERATIONS:
        return "error"  # Transition to Error_State
    
    if state.get('needs_tool_call'):
        return "tool_exec"
    else:
        return "synthesis"


# Build the Graph
workflow = StateGraph(AgentState)
workflow.add_node("Plan", plan_node)
workflow.add_node("Tool_Execution", tool_execution_node)
workflow.add_node("Final_Synthesis", final_synthesis_node)
workflow.add_node("Error_State", error_state_node)

workflow.set_entry_point("Plan")

# Conditional edge governed by the Max Iteration Policy
workflow.add_conditional_edges(
    "Plan",
    check_max_iterations,
    {
        "tool_exec": "Tool_Execution",
        "synthesis": "Final_Synthesis",
        "error": "Error_State",
    }
)

# Loop back for ReAct pattern
workflow.add_edge("Tool_Execution", "Plan")

# Termination points
workflow.add_edge("Final_Synthesis", END)
workflow.add_edge("Error_State", END)

app = workflow.compile()

# Execution Simulation in a Server Component context
initial_state = {"query": "Analyze inventory", "tool_calls": [], "iterations": 0, "tool_output": "", "final_output": {}, "needs_tool_call": False}
final_state = app.invoke(initial_state)

# 4. RSC Integration: The final output is the structured JSON
# print(json.dumps(final_state['final_output'], indent=2))
