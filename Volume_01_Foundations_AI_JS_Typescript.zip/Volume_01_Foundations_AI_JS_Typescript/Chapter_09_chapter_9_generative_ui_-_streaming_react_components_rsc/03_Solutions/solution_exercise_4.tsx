
/*
 * These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
 * You can find the series on Amazon.
 * New books info: https://linktr.ee/edgarmilvus
 *
 * MIT License
 * Copyright (c) 2025 Edgar Milvus
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */

// Source File: solution_exercise_4.tsx
// Description: Solution for Exercise 4
// ==========================================

// 2. InteractiveDataTableCC.tsx (Client Component - "use client")
"use client";

import React, { useState, useMemo } from 'react';

interface DataRow {
  id: number;
  product: string;
  stock: number;
  notes: string;
}

interface ColumnDef {
  key: keyof DataRow;
  label: string;
  isToggleable: boolean;
}

interface DataTableProps {
  initialData: DataRow[];
  columnDefinitions: ColumnDef[];
}

export function InteractiveDataTableCC({ initialData, columnDefinitions }: DataTableProps) {
  // 3. Hydration and State: Manages visibility state client-side
  const [showNotes, setShowNotes] = useState(true);

  // Determine which columns to display based on state
  const visibleColumns = useMemo(() => {
    return columnDefinitions.filter(col => 
      col.key !== 'notes' || (col.key === 'notes' && showNotes)
    );
  }, [columnDefinitions, showNotes]);

  return (
    <div className="interactive-table">
      <h3>Generative UI: Stock Summary (Hydrated)</h3>
      
      {/* 4. Interactivity Implementation */}
      <button 
        onClick={() => setShowNotes(!showNotes)}
        style={{ marginBottom: '15px', padding: '8px 15px', cursor: 'pointer' }}
      >
        {showNotes ? 'Hide Internal Notes (Client Action)' : 'Show Internal Notes (Client Action)'}
      </button>

      <table style={{ borderCollapse: 'collapse', width: '100%' }}>
        <thead>
          <tr style={{ background: '#f4f4f4' }}>
            {visibleColumns.map(col => (
              <th key={col.key} style={{ border: '1px solid #ccc', padding: '10px' }}>{col.label}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {initialData.map(row => (
            <tr key={row.id}>
              {visibleColumns.map(col => (
                <td key={col.key} style={{ border: '1px solid #ccc', padding: '10px' }}>
                  {row[col.key]}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}


// 1. StockSummarySC.tsx (Server Component)
import { InteractiveDataTableCC } from './InteractiveDataTableCC';

export function StockSummarySC() {
  // SC generates the static structure and props (based on LLM output)
  const generatedData = [
    { id: 1, product: 'Widget A', stock: 150, notes: 'High demand forecast.' },
    { id: 2, product: 'Gadget B', stock: 85, notes: 'Below reorder point. Critical.' },
    { id: 3, product: 'Thing C', stock: 210, notes: 'Standard stock level.' },
  ];

  const generatedColumns = [
    { key: 'product' as const, label: 'Product Name', isToggleable: false },
    { key: 'stock' as const, label: 'Current Stock', isToggleable: false },
    { key: 'notes' as const, label: 'Internal Notes', isToggleable: true },
  ];

  return (
    <div className="generative-ui-wrapper">
      {/* The SC passes the generated props to the CC */}
      <InteractiveDataTableCC 
        initialData={generatedData} 
        columnDefinitions={generatedColumns} 
      />
    </div>
  );
}
