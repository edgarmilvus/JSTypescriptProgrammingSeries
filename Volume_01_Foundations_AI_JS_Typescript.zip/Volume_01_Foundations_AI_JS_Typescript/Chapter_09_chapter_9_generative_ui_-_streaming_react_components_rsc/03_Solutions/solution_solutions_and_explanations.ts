/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2025 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// 1. VisualizationSchema.ts
import { z } from 'zod';

const DataPointSchema = z.object({
  label: z.string().describe("The category label (e.g., 'Q1' or 'Region A')."),
  value: z.number().describe("The numerical value associated with the label."),
});

export const VisualizationSchema = z.object({
  componentType: z.enum(['BarChart', 'DataTable', 'LineGraph']).describe("The specific type of visualization component to render."),
  title: z.string().optional().describe("A concise title for the visualization."),
  description: z.string().optional().describe("A detailed description of the data."),
  data: z.array(DataPointSchema).describe("The complete dataset required for rendering."),
});

export type VisualizationProps = z.infer<typeof VisualizationSchema>;

// 2. DynamicDataViz.tsx (React Server Component)
// This file assumes 'ai/react' and '@ai-sdk/openai' are installed and configured.
import { VisualizationSchema, VisualizationProps } from './VisualizationSchema';
import { experimental_stream_object } from 'ai/react'; 
import { createOpenAI } from '@ai-sdk/openai';
// Import placeholder Client Components (defined with "use client"; elsewhere)
import { BarChartClient } from './BarChartClient'; 
import { DataTableClient } from './DataTableClient'; 

const openai = createOpenAI({ apiKey: process.env.OPENAI_API_KEY });

const ComponentMap = {
    BarChart: BarChartClient,
    DataTable: DataTableClient,
    LineGraph: () => <div>Line Graph Client Placeholder</div>,
};

async function generateVisualization(prompt: string): Promise<VisualizationProps> {
    // 6. Prompt Engineering Constraint
    const systemPrompt = `You are a Visualization Generator. Your sole task is to analyze the user query and generate a JSON object strictly conforming to the provided schema. Do not include any conversational text, markdown wrappers (like \`\`\`json), or preamble.`;

    // 3. Vercel AI SDK Integration (Streaming Structured Output)
    const result = await experimental_stream_object({
        model: openai.chat('gpt-4o'),
        schema: VisualizationSchema,
        prompt: prompt,
        system: systemPrompt,
    });
    
    // 4. Streaming Implementation: The RSC waits for the full object 
    // to be streamed and parsed by the SDK before returning the data.
    return result.response; 
}

// 1. Component Architecture Definition (Server Component)
export async function DynamicDataViz({ prompt }: { prompt: string }) {
    const vizData = await generateVisualization(prompt);
    
    // 5. Client Component Integration: Conditional rendering
    const Component = ComponentMap[vizData.componentType];

    if (!Component) {
        return <div>Error: Invalid component type received.</div>;
    }

    // Pass the structured, type-safe data to the Client Component for rendering
    return <Component {...vizData} />;
}
