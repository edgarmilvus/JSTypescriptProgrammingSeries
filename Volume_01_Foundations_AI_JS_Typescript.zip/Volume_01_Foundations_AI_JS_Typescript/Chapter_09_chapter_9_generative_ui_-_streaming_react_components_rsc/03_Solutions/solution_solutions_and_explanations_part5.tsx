/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2025 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.tsx
// Description: Solutions and Explanations
// ==========================================

// ProgressiveWeatherSC.tsx (Server Component)
"use server";

import React from 'react';

// 1. Conceptual Data Structure for Streaming
interface StreamChunk {
    type: 'status' | 'component';
    content: any; // string for status, object for structured component
}

// Placeholder Client Component (must be defined with "use client";)
const WeatherCardClient = ({ title, temp, details, action }: any) => (
    <div className="weather-card" style={{ border: '1px solid #0070f3', padding: '15px', marginTop: '15px', borderRadius: '8px' }}>
        <h4>{title}</h4>
        <p><strong>Temperature:</strong> {temp}</p>
        <p><strong>Details:</strong> {details}</p>
        <p style={{ color: 'green', fontWeight: 'bold' }}>Recommendation: {action}</p>
    </div>
);


// 2. Agent Workflow Modification (Async Generator Simulation)
async function* runAgentAndStream(city: string): AsyncGenerator<StreamChunk> {
    yield { type: 'status', content: `Agent initialized for query: Weather in ${city}.` };

    // Step 1: Tool Invocation
    yield { type: 'status', content: `Agent is calling the external Weather API for ${city}...` };

    // 4. Latency Simulation
    await new Promise(resolve => setTimeout(resolve, 1500)); 

    // Step 2: Tool Output Received
    const weatherData = {
        city: city,
        temperature: 15,
        condition: 'Cloudy with light rain',
        recommendation: 'Wear a waterproof jacket and bring an umbrella.'
    };

    yield { type: 'status', content: `API response received. Synthesizing final UI component.` };

    // Step 3: Final Synthesis (Structured Output)
    const finalComponent = {
        componentType: 'WeatherCard',
        props: {
            title: `Current Weather in ${city}`,
            temp: `${weatherData.temperature}°C`,
            details: weatherData.condition,
            action: weatherData.recommendation
        }
    };

    yield { type: 'component', content: finalComponent };
}

// 3. RSC Streaming Handler and Incremental Rendering
export async function ProgressiveWeatherSC({ city }: { city: string }) {
    const generator = runAgentAndStream(city);
    let finalComponentProps: any = null;
    let statusUpdates: string[] = [];

    // In a real RSC stream implementation (e.g., using `use-client-stream`), 
    // this loop would yield React elements progressively.
    for await (const chunk of generator) {
        if (chunk.type === 'status') {
            // 3. Incremental Rendering: Buffer status updates
            statusUpdates.push(chunk.content as string);
        } else if (chunk.type === 'component') {
            // Buffer the final component definition
            finalComponentProps = chunk.content;
        }
    }

    // Since standard RSC components only render once all promises resolve, 
    // we combine the accumulated status and the final component for demonstration.
    // In a true incremental stream, the status updates would appear before the 1500ms delay.
    return (
        <div className="progressive-output">
            <h3 style={{ borderBottom: '1px dashed #ccc', paddingBottom: '5px' }}>Agent Progress Log:</h3>
            {statusUpdates.map((status, index) => (
                <p key={index} style={{ color: '#555', margin: '5px 0' }}>
                    &gt; {status}
                </p>
            ))}
            
            {finalComponentProps && finalComponentProps.componentType === 'WeatherCard' ? (
                <WeatherCardClient {...finalComponentProps.props} />
            ) : (
                <p style={{ color: 'red' }}>Awaiting final component...</p>
            )}
        </div>
    );
}
