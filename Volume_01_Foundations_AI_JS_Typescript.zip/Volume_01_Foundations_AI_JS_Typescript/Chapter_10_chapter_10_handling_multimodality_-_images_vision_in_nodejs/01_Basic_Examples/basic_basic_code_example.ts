/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2025 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

// index.ts

import { OpenAI } from "openai";
import * as fs from "fs";
import * as path from "path";

// 1. Initialization and Environment Setup
// Ensure OPENAI_API_KEY is set in your environment variables.
if (!process.env.OPENAI_API_KEY) {
    throw new Error("OPENAI_API_KEY environment variable is required.");
}
const openai = new OpenAI();

// --- Configuration Variables ---
const MODEL = "gpt-4o";

// NOTE: Replace 'sample-image.jpg' with the actual path to your asset.
const IMAGE_FILE_NAME = "sample-image.jpg";
const IMAGE_PATH = path.join(process.cwd(), IMAGE_FILE_NAME);
// CRITICAL: Must match the file type (e.g., image/png, image/webp)
const IMAGE_MIME_TYPE = "image/jpeg"; 

/**
 * @description Converts a local image file into a Base64 Data URI string.
 * This function simulates the server-side preparation of a user-uploaded file.
 * @param filePath The absolute path to the image file.
 * @returns The Base64 encoded string prefixed with the data URI scheme.
 */
function fileToBase64DataURI(filePath: string): string {
    console.log(`Attempting to read file: ${filePath}`);
    try {
        // Read the file buffer synchronously (acceptable for small serverless functions)
        const imageBuffer = fs.readFileSync(filePath); 
        const base64Image = imageBuffer.toString("base64");
        
        // Construct the full data URI required by the OpenAI API
        return `data:${IMAGE_MIME_TYPE};base64,${base64Image}`;
    } catch (error) {
        console.error(`Error reading file at ${filePath}. Ensure the file exists.`);
        throw new Error("Image file processing failed.");
    }
}

/**
 * @description Analyzes the image using GPT-4o based on the provided prompt.
 * This is the core API interaction function.
 * @param imageBase64DataURI The Base64 encoded image data URI.
 * @param prompt The specific question or task for the model.
 * @returns A promise that resolves to the model's textual analysis.
 */
async function analyzeInventoryImage(imageBase64DataURI: string, prompt: string): Promise<string> {
    console.log(`\nStarting analysis with model: ${MODEL}`);
    
    try {
        const response = await openai.chat.completions.create({
            model: MODEL,
            // The critical multimodal payload structure
            messages: [
                {
                    role: "user",
                    content: [
                        // Component 1: The Text Instruction
                        { type: "text", text: prompt },
                        
                        // Component 2: The Image Data
                        {
                            type: "image_url",
                            image_url: {
                                url: imageBase64DataURI,
                                // 'high' detail is recommended for complex inventory tasks
                                detail: "high", 
                            },
                        },
                    ],
                },
            ],
            temperature: 0.1, // Low temperature for factual analysis
            max_tokens: 1024,
        });

        // Extract the resulting text description
        const description = response.choices[0].message.content;
        return description || "Error: Model returned no content.";

    } catch (error) {
        console.error("OpenAI API call failed:", error);
        // Re-throw the error for the main application to handle
        throw new Error("API communication failure during vision task.");
    }
}

// --- Main Execution Flow (Simulating a serverless function trigger) ---
async function main() {
    try {
        // 1. Data Preparation
        // NOTE: In a real web app, imageBase64DataURI would come directly from the 
        // file upload handler (e.g., from a multer or busboy stream).
        const imageBase64DataURI = fileToBase64DataURI(IMAGE_PATH);

        // 2. Define the Delegation Strategy (The prompt)
        const analysisPrompt = `You are an expert inventory specialist tasked with generating a structured manifest entry. Analyze the provided image. Identify the primary object, its color, approximate dimensions (if discernible), and suggest a three-character SKU prefix. Respond ONLY with the JSON object schema provided: {"object": "...", "color": "...", "sku_prefix": "...", "description": "..."}`;

        // 3. Execute the Multimodal Analysis
        const analysisResult = await analyzeInventoryImage(
            imageBase64DataURI, 
            analysisPrompt
        );

        // 4. Output Results
        console.log("\n==============================================");
        console.log(`Analysis Status: Success (Model: ${MODEL})`);
        console.log("----------------------------------------------");
        console.log("Input Prompt (Delegation Strategy):\n", analysisPrompt);
        console.log("\nGPT-4o Structured Response:\n", analysisResult);
        console.log("==============================================");

    } catch (e) {
        console.error("\n[FATAL APPLICATION ERROR] Execution terminated:", e);
    }
}

// To run this example, ensure you have a 'sample-image.jpg' in the project root 
// and execute 'main()'.
// main();
