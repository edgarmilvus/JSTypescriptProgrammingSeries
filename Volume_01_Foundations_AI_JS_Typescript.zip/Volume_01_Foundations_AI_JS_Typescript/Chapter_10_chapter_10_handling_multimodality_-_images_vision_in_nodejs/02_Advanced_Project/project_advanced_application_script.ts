/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2025 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// 1. Setup and Imports
import { OpenAI } from 'openai';
import 'dotenv/config';

// 2. Define the expected structured output for compliance
/**
 * @interface ComplianceReport
 * @description Defines the structure for the automated compliance analysis report.
 */
interface ComplianceReport {
  isSingleProductFocus: boolean;
  clarityScore: number; // 1-5 scale
  detectedProhibitedText: string[] | null;
  backgroundCompliance: 'White' | 'Transparent' | 'Non-Compliant';
  overallVerdict: 'PASS' | 'FAIL';
  failureReason: string | null;
}

// Initialize the OpenAI client using the environment variable OPENAI_API_KEY
const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

/**
 * @description Analyzes a product image URL against predefined e-commerce compliance rules using GPT-4o Vision.
 * This function handles the asynchronous processing of the API call, essential in Node.js.
 * @param imageUrl The publicly accessible URL of the image to analyze.
 * @returns A promise resolving to the structured ComplianceReport.
 */
async function analyzeProductImageCompliance(imageUrl: string): Promise<ComplianceReport> {
  console.log(`[SYSTEM] Starting compliance check for: ${imageUrl}`);

  // 3. Define the detailed system prompt and JSON schema
  // This schema guides GPT-4o to produce a reliable, parseable JSON object.
  const complianceSchema = `{
    "type": "object",
    "properties": {
      "isSingleProductFocus": {"type": "boolean", "description": "True if the image clearly features only one primary product."},
      "clarityScore": {"type": "number", "description": "Score from 1 (poor) to 5 (excellent) assessing image sharpness and lighting."},
      "detectedProhibitedText": {"type": "array", "items": {"type": "string"}, "description": "List of any URLs, promotional slogans, or contact info detected via OCR. Null if none."},
      "backgroundCompliance": {"type": "string", "enum": ["White", "Transparent", "Non-Compliant"], "description": "Must be White or Transparent for compliance."},
      "overallVerdict": {"type": "string", "enum": ["PASS", "FAIL"], "description": "The final decision based on all criteria."},
      "failureReason": {"type": "string", "description": "Specific reason if the verdict is FAIL. Null if PASS."}
    },
    "required": ["isSingleProductFocus", "clarityScore", "detectedProhibitedText", "backgroundCompliance", "overallVerdict"]
  }`;

  const systemPrompt = `You are the E-commerce Product Compliance Auditor. Your task is to analyze the provided product image against strict guidelines and output a comprehensive JSON report.
  
  Compliance Rules:
  1. Focus: Must feature a single, clearly visible product.
  2. Quality: Clarity Score must be 4 or 5.
  3. OCR/Text: Must not contain any promotional text, URLs, or watermarks.
  4. Background: Must have a plain white or transparent background.
  
  If any rule is violated, the overallVerdict must be 'FAIL'. Use the provided JSON schema exactly.`;

  try {
    // 4. Construct the multimodal payload
    // The `content` array mixes text instructions and the image reference.
    const response = await openai.chat.completions.create({
      model: 'gpt-4o', // Preferred model for high-quality vision and structured output
      response_format: { type: 'json_object' }, // Enforces JSON output structure
      messages: [
        {
          role: 'system',
          content: systemPrompt,
        },
        {
          role: 'user',
          content: [
            {
              type: 'text',
              text: `Analyze this product image based on the compliance rules and return the structured JSON report.`,
            },
            {
              type: 'image_url',
              image_url: {
                url: imageUrl,
                detail: 'high', // Request high-resolution analysis for better OCR and detail checks
              },
            },
          ],
        },
      ],
      max_tokens: 1024, // Sufficient tokens for the JSON object
    });

    // 5. Parse and return the result
    const jsonString = response.choices[0].message.content;
    if (!jsonString) {
        throw new Error("API returned an empty response.");
    }
    
    // Type casting the parsed result to the defined interface for type safety
    const report = JSON.parse(jsonString) as ComplianceReport;
    console.log(`[SYSTEM] Compliance Check Complete. Verdict: ${report.overallVerdict}`);
    return report;

  } catch (error) {
    console.error("Error during image analysis:", error);
    // 6. Robust Error Handling: Return a safe failure report on API or parsing error
    return {
      isSingleProductFocus: false,
      clarityScore: 1,
      detectedProhibitedText: ['System Error'],
      backgroundCompliance: 'Non-Compliant',
      overallVerdict: 'FAIL',
      failureReason: `API processing failed: ${(error as Error).message}`,
    } as ComplianceReport;
  }
}

// 7. Execution Block (Example Usage)
async function main() {
  // NOTE: These URLs are placeholders and must be replaced with actual public image links for live testing.
  const compliantUrl = "https://example.com/assets/product_compliant_shoe.jpg"; 
  const nonCompliantUrl = "https://example.com/assets/product_noncompliant_ad_watermark.png";
  
  console.log("\n--- Analyzing Compliant Asset (Placeholder) ---");
  const compliantReport = await analyzeProductImageCompliance(compliantUrl);
  console.log(JSON.stringify(compliantReport, null, 2));

  console.log("\n--- Analyzing Non-Compliant Asset (Placeholder) ---");
  const nonCompliantReport = await analyzeProductImageCompliance(nonCompliantUrl);
  console.log(JSON.stringify(nonCompliantReport, null, 2));
}

main().catch(err => console.error("Fatal Script Error:", err));
