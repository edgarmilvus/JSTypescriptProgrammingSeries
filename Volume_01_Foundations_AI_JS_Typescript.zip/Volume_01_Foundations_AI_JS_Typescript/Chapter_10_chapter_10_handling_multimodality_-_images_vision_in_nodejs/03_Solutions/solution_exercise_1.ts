
/*
 * These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
 * You can find the series on Amazon.
 * New books info: https://linktr.ee/edgarmilvus
 *
 * MIT License
 * Copyright (c) 2025 Edgar Milvus
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */

// Source File: solution_exercise_1.ts
// Description: Solution for Exercise 1
// ==========================================

import { OpenAI } from 'openai';
import * as fs from 'fs';
import * as path from 'path';

// Initialize the OpenAI client (assuming API key is in environment variables)
const openai = new OpenAI({});

// --- Placeholder for file path simulation ---
const MOCK_IMAGE_PATH = path.join(process.cwd(), 'data/pallet_image.jpg');

/**
 * Reads a local file and converts it to a Base64 string with MIME prefix.
 * @param filePath Path to the local image file.
 * @returns Base64 string or null on failure.
 */
function encodeImageToBase64(filePath: string): string | null {
    try {
        // 1. Read the file buffer synchronously
        const imageBuffer = fs.readFileSync(filePath);
        
        // 2. Convert the Buffer to a Base64 string
        const base64String = imageBuffer.toString('base64');
        
        // 3. Prefix with the data URI scheme (image/jpeg assumed)
        return `data:image/jpeg;base64,${base64String}`;
    } catch (error) {
        // Handle file not found or read errors
        console.error(`Error reading or encoding file ${filePath}:`, error);
        return null;
    }
}

/**
 * Executes the multimodal audit using the Base64 string.
 * @param base64Image The encoded image string.
 */
async function runInventoryAudit(base64Image: string): Promise<void> {
    if (!base64Image) {
        console.error("No image data provided.");
        return;
    }
    
    try {
        const response = await openai.chat.completions.create({
            model: 'gpt-4o', 
            messages: [
                {
                    role: 'system',
                    content: 'You are an automated inventory auditor. Analyze the provided image of a pallet shipment and extract key metrics accurately.'
                },
                {
                    role: 'user',
                    content: [
                        {
                            type: 'text',
                            text: 'Analyze this image. How many distinct boxes are visible? What is the color of the dominant warning label (e.g., Red, Yellow, None)?'
                        },
                        {
                            type: 'image_url',
                            image_url: {
                                url: base64Image, // Pass the Base64 data URI here
                                detail: 'high', // Use high detail for better object recognition
                            },
                        },
                    ],
                },
            ],
            temperature: 0.1,
        });

        const extractedText = response.choices[0].message.content;
        
        console.log("--- Extracted Audit Summary ---");
        console.log(extractedText);

    } catch (error) {
        console.error("OpenAI API call failed:", error);
    }
}

// // Example Usage (requires a file at MOCK_IMAGE_PATH):
// // const encodedImage = encodeImageToBase64(MOCK_IMAGE_PATH);
// // if (encodedImage) {
// //     await runInventoryAudit(encodedImage);
// // }
