
/*
 * These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
 * You can find the series on Amazon.
 * New books info: https://linktr.ee/edgarmilvus
 *
 * MIT License
 * Copyright (c) 2025 Edgar Milvus
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */

// Source File: solution_exercise_2.ts
// Description: Solution for Exercise 2
// ==========================================

import { z } from 'zod';
import { OpenAI } from 'openai';

// Initialize the OpenAI client
const openai = new OpenAI({});

// 1. Define the Zod Schema
const ProductMetadata = z.object({
    productId: z.string().describe("The unique identifier for the product, e.g., P-10042"),
    price: z.number().positive().describe("The price displayed in the image, as a floating-point number"),
    material: z.string().describe("The primary material of the product visible in the image (e.g., Leather, Plastic, Wood)"),
});

type ProductMetadataType = z.infer<typeof ProductMetadata>;

/**
 * Extracts structured product details from an image URL using Zod validation.
 * @param imageUrl Public URL of the product image.
 * @returns Promise resolving to the validated ProductMetadata object.
 */
async function extractProductDetails(imageUrl: string): Promise<ProductMetadataType> {
    
    // Detailed prompt instructing the model on the required JSON structure
    const schemaDescription = `Extract the product details from the image and return them in a strict JSON object. The JSON structure MUST conform exactly to the required schema: { "productId": string, "price": number, "material": string }`;

    try {
        const response = await openai.chat.completions.create({
            model: 'gpt-4o',
            messages: [
                {
                    role: 'system',
                    content: schemaDescription,
                },
                {
                    role: 'user',
                    content: [
                        {
                            type: 'text',
                            text: 'Analyze this product image and provide the required metadata.',
                        },
                        {
                            type: 'image_url',
                            image_url: {
                                url: imageUrl, // Directly use the public URL
                                detail: 'auto',
                            },
                        },
                    ],
                },
            ],
            // 3. Crucial setting for structured JSON output
            response_format: { type: "json_object" },
            temperature: 0.0,
        });

        const jsonString = response.choices[0].message.content;

        if (!jsonString) {
            throw new Error("API returned an empty JSON response.");
        }
        
        // 4. Parse and Validate the response using Zod
        const rawObject = JSON.parse(jsonString);
        const validatedDetails = ProductMetadata.parse(rawObject); // Throws ZodError on failure

        return validatedDetails;

    } catch (error) {
        if (error instanceof z.ZodError) {
            // 4. Custom error handling for validation failure
            throw new Error(`Structured data validation failed: ${error.errors.map(e => e.path.join('.') + ': ' + e.message).join(', ')}`);
        }
        throw error;
    }
}

// // Example usage (Simulated):
// // const sampleUrl = "https://images.unsplash.com/photo-1542291026-79eedda9cc0a"; 
// // try {
// //     const details = await extractProductDetails(sampleUrl);
// //     console.log("Validated Details:", details);
// // } catch (error) {
// //     console.error("Extraction or Validation Failed:", error);
// // }
