
/*
 * These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
 * You can find the series on Amazon.
 * New books info: https://linktr.ee/edgarmilvus
 *
 * MIT License
 * Copyright (c) 2025 Edgar Milvus
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */

// Source File: solution_exercise_4.tsx
// Description: Solution for Exercise 4
// ==========================================

// Define the necessary function signature for the server interaction.
export type ServerAnalysisResult = {
    success: boolean;
    description: string;
    error?: string;
};

/**
 * Hypothetical Server Action/Route handler signature.
 * (This function body would be implemented on the server side, marked 'use server')
 */
async function analyzeImageAction(base64Image: string): Promise<ServerAnalysisResult> {
    // Placeholder implementation for client interaction simulation
    // In reality, this would call the OpenAI API using the API key.
    if (base64Image.length < 100) {
        return { success: false, description: "", error: "Image data too short or invalid." };
    }
    return { 
        success: true, 
        description: `Analysis successful. Base64 length: ${base64Image.length} characters.`,
    };
}

// Conceptual Client Component structure
'use client'; 

import React, { useState, ChangeEvent, FormEvent, useMemo } from 'react';

function ImageVisionUploader() {
    // 1. State definitions
    const [file, setFile] = useState<File | null>(null);
    const [base64Data, setBase64Data] = useState<string | null>(null);
    const [previewUrl, setPreviewUrl] = useState<string | null>(null);
    const [isLoading, setIsLoading] = useState(false);
    const [result, setResult] = useState<ServerAnalysisResult | null>(null);
    const [error, setError] = useState<string | null>(null);

    // Clean up preview URL when component unmounts or file changes
    useMemo(() => {
        return () => {
            if (previewUrl) URL.revokeObjectURL(previewUrl);
        };
    }, [previewUrl]);

    // 2. Handler for file input change (Browser-side Base64 Conversion)
    const handleFileChange = (event: ChangeEvent<HTMLInputElement>) => {
        const selectedFile = event.target.files?.[0];
        if (selectedFile && selectedFile.type.startsWith('image/')) {
            setFile(selectedFile);
            setError(null);
            setResult(null);
            
            // Display local preview
            setPreviewUrl(URL.createObjectURL(selectedFile));

            // Convert File object to Base64 Data URI
            const reader = new FileReader();
            reader.onloadend = () => {
                setBase64Data(reader.result as string);
            };
            reader.onerror = () => {
                setError("Failed to read file.");
                setBase64Data(null);
            };
            reader.readAsDataURL(selectedFile);
        } else {
            setError("Please select a valid image file.");
            setFile(null);
            setBase64Data(null);
            setPreviewUrl(null);
        }
    };

    // 3. Handler for submission (Calls Server Action)
    const handleSubmit = async (e: FormEvent) => {
        e.preventDefault();
        if (!base64Data) {
            setError("Image data not ready or file missing.");
            return;
        }

        setIsLoading(true);
        setResult(null);
        setError(null);

        try {
            // Call the hypothetical Server Action
            const analysisResult = await analyzeImageAction(base64Data);
            
            if (analysisResult.success) {
                setResult(analysisResult);
            } else {
                // 4. Client-side error handling for server errors
                setError(analysisResult.error || "Server analysis failed without specific error message.");
            }
        } catch (err) {
            setError("An unexpected network or server error occurred.");
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <div className="vision-uploader">
            <form onSubmit={handleSubmit}>
                <input 
                    type="file" 
                    accept="image/*" 
                    onChange={handleFileChange} 
                    disabled={isLoading}
                />
                
                {previewUrl && (
                    <div className="image-preview">
                        <img src={previewUrl} alt="Selected Preview" style={{ maxWidth: '300px' }} />
                    </div>
                )}
                
                <button type="submit" disabled={!file || isLoading}>
                    {isLoading ? 'Analyzing...' : 'Analyze Image with GPT-4o'}
                </button>
            </form>

            {error && <p className="error-message">Error: {error}</p>}
            
            {result && result.success && (
                <div className="analysis-result">
                    <h4>Analysis Complete:</h4>
                    <p>{result.description}</p>
                </div>
            )}
        </div>
    );
}
// export default ImageVisionUploader;
