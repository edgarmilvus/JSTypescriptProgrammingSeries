/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2025 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

import { OpenAI } from 'openai';
import * as fs from 'fs';

const openai = new OpenAI({});

interface ReceiptData {
    subtotal: number;
    taxAmount: number;
    grandTotal: number;
    calculatedTaxPercentage: number; 
}

// Utility to encode PNG (or reuse Ex 1's logic with different MIME)
function encodeImageToBase64Png(filePath: string): string | null {
    try {
        const imageBuffer = fs.readFileSync(filePath);
        const base64String = imageBuffer.toString('base64');
        return `data:image/png;base64,${base64String}`;
    } catch (error) {
        return null;
    }
}

/**
 * Processes a receipt image, extracts key financials, and calculates the tax rate.
 * @param encodedReceipt Base64 encoded receipt image (PNG).
 * @returns Promise resolving to the structured ReceiptData.
 */
async function processReceiptAndCalculateTax(encodedReceipt: string): Promise<ReceiptData> {
    
    // System prompt focuses on OCR accuracy, mandatory numerical extraction, and calculation
    const systemPrompt = `You are a financial OCR specialist. Accurately read the receipt image, extract Subtotal, Tax Amount, and Grand Total as precise numbers. 
    Then, calculate the implied tax percentage using the formula: (Tax Amount / Subtotal) * 100.
    Return all four results in the JSON format: { "subtotal": number, "taxAmount": number, "grandTotal": number, "calculatedTaxPercentage": number }.`;

    try {
        const response = await openai.chat.completions.create({
            model: 'gpt-4o',
            messages: [
                { role: 'system', content: systemPrompt },
                {
                    role: 'user',
                    content: [
                        { type: 'text', text: 'Analyze this receipt and perform the required calculation.' },
                        {
                            type: 'image_url',
                            image_url: { url: encodedReceipt, detail: 'high' },
                        },
                    ],
                },
            ],
            response_format: { type: "json_object" },
            temperature: 0.1,
        });

        const jsonString = response.choices[0].message.content;
        const modelOutput: ReceiptData = JSON.parse(jsonString!);

        // --- Local Verification Check (Requirement 4) ---
        const localSubtotal = modelOutput.subtotal;
        const localTax = modelOutput.taxAmount;
        const modelPercentage = modelOutput.calculatedTaxPercentage;

        // Recalculate the percentage locally
        const localPercentage = (localTax / localSubtotal) * 100;

        // Check for deviation tolerance (0.1%)
        if (Math.abs(localPercentage - modelPercentage) > 0.1) {
            console.warn(
                `[Verification Failed] Model calculated ${modelPercentage.toFixed(2)}%, but local verification shows ${localPercentage.toFixed(2)}%.`
            );
        } else {
            console.log(`[Verification Passed] Calculated tax rate: ${localPercentage.toFixed(2)}%.`);
        }

        return modelOutput;

    } catch (error) {
        console.error("Receipt processing failed:", error);
        throw error;
    }
}

// // Example Usage (requires a file at './data/receipt.png'):
// // const encodedReceipt = encodeImageToBase64Png('./data/receipt.png');
// // if (encodedReceipt) {
// //     await processReceiptAndCalculateTax(encodedReceipt);
// // }
