/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2025 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

import { OpenAI } from 'openai';
import { z } from 'zod';

const openai = new OpenAI({});

// Define the final structured output schema
const FinalReportSchema = z.object({
    finalLength: z.number().describe("The most reliable total length measurement extracted from the blueprint, in meters."),
    finalWidth: z.number().describe("The most reliable total width measurement extracted from the blueprint, in meters."),
    confidenceScore: z.enum(['High', 'Medium', 'Low']).describe("The supervisor's assessment of the reliability of the extracted data."),
});

type FinalReport = z.infer<typeof FinalReportSchema>;

/**
 * Runs a specialized worker agent (Agent A or B) against the image.
 */
async function runWorker(encodedImage: string, specialization: 'Length' | 'Width'): Promise<string> {
    const systemPrompt = `You are a specialized blueprint analysis agent focused ONLY on ${specialization}. 
    Analyze the image and report the primary structure's total ${specialization.toLowerCase()} measurement. 
    State the measurement clearly, including units (convert to meters if necessary). Do not include any other commentary.`;

    const response = await openai.chat.completions.create({
        model: 'gpt-4o',
        messages: [
            { role: 'system', content: systemPrompt },
            {
                role: 'user',
                content: [
                    { type: 'text', text: `Find the total ${specialization.toLowerCase()} of the main structure.` },
                    {
                        type: 'image_url',
                        image_url: { url: encodedImage, detail: 'high' },
                    },
                ],
            },
        ],
        temperature: 0.2, // A bit of creativity needed for complex OCR
    });
    
    return response.choices[0].message.content || 'Measurement not found.';
}

/**
 * Executes the full consensus mechanism process.
 * @param encodedBlueprint Base64 encoded blueprint image.
 */
async function runConsensusAnalysis(encodedBlueprint: string): Promise<FinalReport> {
    
    // 1. Call Worker Agent A (Length Specialist)
    const lengthReport = await runWorker(encodedBlueprint, 'Length');
    
    // 2. Call Worker Agent B (Width Specialist)
    const widthReport = await runWorker(encodedBlueprint, 'Width');

    // 3. Supervisor Node Prompt Construction
    const supervisorSystemPrompt = `You are the Supervisor Agent. Your task is to synthesize the following two specialized reports, resolve any conflicts, and provide a final, unified, reliable measurement.
    
    Report A (Length Specialist): ${lengthReport}
    Report B (Width Specialist): ${widthReport}
    
    Instructions:
    1. Extract the numerical length and width.
    2. Assess consistency: If both reports are clear and consistent, assign 'High' confidence. If one or both reports are ambiguous, conflicting, or non-numeric, assign 'Low' confidence.
    3. Output the final decision in the required JSON format.`;

    const supervisorResponse = await openai.chat.completions.create({
        model: 'gpt-4o',
        messages: [
            { role: 'system', content: supervisorSystemPrompt },
            { role: 'user', content: 'Synthesize the agent reports and output the final structured analysis.' },
        ],
        response_format: { type: "json_object" },
        temperature: 0.0, // Zero temperature for deterministic synthesis
    });

    const jsonString = supervisorResponse.choices[0].message.content;
    const rawData = JSON.parse(jsonString!);
    
    // 4. Parse and Validate the final report
    const finalReport = FinalReportSchema.parse(rawData);
    
    return finalReport;
}

// // Example Usage (requires a mock Base64 blueprint):
// // const encodedBlueprint = "data:image/jpeg;base64,MOCK_BLUEPRINT_DATA";
// // const finalAnalysis = await runConsensusAnalysis(encodedBlueprint);
// // console.log("Final Consensus Analysis:", finalAnalysis);
