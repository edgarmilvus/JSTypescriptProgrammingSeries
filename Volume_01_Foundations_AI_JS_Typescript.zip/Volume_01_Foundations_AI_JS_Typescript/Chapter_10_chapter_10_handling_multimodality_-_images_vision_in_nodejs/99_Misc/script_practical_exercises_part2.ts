/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2025 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part2.ts
// Description: Practical Exercises
// ==========================================

// Required setup structure (Do NOT implement the body)
import { z } from 'zod';
import { OpenAI } from 'openai';

const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

// 1. Define the Zod Schema here
const ProductMetadata = z.object({
    // Schema definition required here
});

type ProductMetadataType = z.infer<typeof ProductMetadata>;

/**
 * Extracts structured product details from an image URL using Zod validation.
 * @param imageUrl Public URL of the product image.
 * @returns Promise resolving to the validated ProductMetadata object.
 */
async function extractProductDetails(imageUrl: string): Promise<ProductMetadataType> {
    // Implementation required here:
    // 1. Construct the multimodal message with the URL.
    // 2. Include the Zod schema description in the prompt.
    // 3. Set the response_format to json_object.
    // 4. Validate the response using ProductMetadata.parse().
    throw new Error("Implementation missing.");
}

// Example usage:
// const sampleUrl = "https://example.com/images/product_shoe.jpg";
// try {
//     const details = await extractProductDetails(sampleUrl);
//     console.log("Validated Details:", details);
// } catch (error) {
//     console.error("Extraction or Validation Failed:", error);
// }
