/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2025 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

// vector-db-example.ts

// 1. Setup Types and Constants
/**
 * CRITICAL CONSTANT: Dimensionality. Must match the embedding model (e.g., text-embedding-ada-002).
 * This value determines the length of every vector array stored in the index.
 */
const DIMENSIONALITY = 1536; 
type VectorID = string;
type Metadata = Record<string, any>;

/**
 * Represents a single vector entry to be stored in the database.
 * This structure is consistent across Pinecone, Weaviate, and pgvector.
 */
interface Vector {
  id: VectorID;
  values: number[]; // The embedding itself (1536 floats)
  metadata: Metadata; // Associated context (e.g., source URL, original text)
}

/**
 * Interface mimicking the response structure of a vector query.
 */
interface QueryResult {
  id: VectorID;
  score: number; // Semantic similarity score (higher is better)
  metadata: Metadata;
}

// 2. Mocking the Embedding Process
/**
 * Simulates calling an LLM provider (like OpenAI) to generate an embedding.
 * In a real application, this is an async network call that consumes tokens.
 * @param {string} text - The text chunk to embed.
 * @returns {number[]} A mock vector of the required dimensionality.
 */
function generateEmbedding(text: string): number[] {
  console.log(`\n[EMBEDDING] Generating vector for: "${text.substring(0, 30)}..."`);
  // We generate a mock vector array of length DIMENSIONALITY.
  const mockVector = Array.from({ length: DIMENSIONALITY }, () => Math.random());
  return mockVector;
}

// 3. The Core Vector Database Client
/**
 * A conceptual class representing the connection and operations for a Vector Index.
 * In production, this would wrap the Pinecone or Supabase client SDK.
 */
class VectorDBClient {
  private indexName: string;
  // Mock internal storage representing the Vector Index itself.
  private vectors: Map<VectorID, Vector> = new Map(); 

  constructor(indexName: string) {
    this.indexName = indexName;
    console.log(`[INIT] Initializing client for index: ${this.indexName} (Dimensionality: ${DIMENSIONALITY})`);
  }

  /**
   * Upserts (inserts or updates) a collection of vectors into the index.
   * This is the critical indexing phase.
   * @param {Vector[]} vectors - The list of vectors to store.
   * @returns {Promise<number>} The count of successfully upserted vectors.
   */
  public async upsertVectors(vectors: Vector[]): Promise<number> {
    console.log(`\n[UPSERT] Starting upsert operation for ${vectors.length} vectors...`);
    let count = 0;
    for (const vector of vectors) {
      // CRITICAL CHECK: Dimensionality must match the index configuration.
      if (vector.values.length !== DIMENSIONALITY) {
        console.error(`ERROR: Vector ID ${vector.id} has incorrect dimensionality (${vector.values.length}). Expected ${DIMENSIONALITY}. Skipping.`);
        continue;
      }
      // Store the vector using its unique Vector ID
      this.vectors.set(vector.id, vector);
      count++;
    }
    console.log(`[UPSERT] Operation complete. Total indexed vectors: ${count}.`);
    return count;
  }

  /**
   * Queries the Vector Index using a query vector to find the nearest neighbors (semantic search).
   * @param {number[]} queryVector - The embedding of the search query.
   * @param {number} topK - The number of nearest results to retrieve.
   * @returns {Promise<QueryResult[]>} A sorted list of the closest vectors.
   */
  public async queryVectors(queryVector: number[], topK: number = 5): Promise<QueryResult[]> {
    console.log(`\n[QUERY] Searching index for nearest neighbors (k=${topK})...`);

    if (queryVector.length !== DIMENSIONALITY) {
         throw new Error(`Query vector dimensionality mismatch. Expected ${DIMENSIONALITY}, got ${queryVector.length}.`);
    }

    // --- Mock Similarity Calculation ---
    // A real vector database uses highly optimized algorithms (HNSW, IVFPQ)
    // to search millions of vectors in milliseconds. We simulate the outcome.
    const results: QueryResult[] = [];

    for (const vector of this.vectors.values()) {
      // Simulate calculating the cosine similarity score (typically 0.0 to 1.0)
      // In a real system, this is the core function of the Vector Index.
      const mockScore = Math.min(1.0, Math.max(0.7, Math.random() + 0.5)); 

      results.push({
        id: vector.id,
        score: mockScore,
        metadata: vector.metadata,
      });
    }

    // Sort by score (descending: highest similarity first) and truncate to topK
    results.sort((a, b) => b.score - a.score);
    return results.slice(0, topK);
  }
}

// 4. Application Logic Execution
async function runDocuSearchIndexingAndQuery() {
  // 4.1. Initialize the client, specifying the target Vector Index
  const vectorDb = new VectorDBClient("docu-support-index");

  // 4.2. Define source data chunks
  const docChunks = [
    {
      text: "The primary method for deploying our application is using Vercel, ensuring serverless function scalability.",
      source: "/docs/deployment/vercel",
    },
    {
      text: "For database persistence, we strictly recommend using Supabase's managed PostgreSQL service.",
      source: "/docs/database/setup",
    },
    {
      text: "All asynchronous operations in the frontend must be handled using the React Query library.",
      source: "/docs/frontend/async-data",
    },
  ];

  // 4.3. Process and Index the data (The RAG indexing pipeline)
  const vectorsToUpsert: Vector[] = docChunks.map((chunk, index) => {
    // Step 1: Generate the embedding for the text chunk
    const embedding = generateEmbedding(chunk.text);

    // Step 2: Create the Vector object
    return {
      id: `doc-${index + 1}`, // Assigning a unique Vector ID
      values: embedding,
      metadata: {
        source: chunk.source,
        original_text_preview: chunk.text.substring(0, 50) + "...",
      },
    };
  });

  // Step 3: Upsert the vectors into the Vector Index
  await vectorDb.upsertVectors(vectorsToUpsert);

  // 4.4. Perform a Semantic Search Query
  const userQuery = "How do I deploy my serverless functions?";

  // Step 1: Embed the user query (creating the Query vector)
  const queryEmbedding = generateEmbedding(userQuery);

  // Step 2: Query the database, asking for the 2 most relevant results (topK=2)
  console.log(`\n[SEARCH] User Query: "${userQuery}"`);
  const searchResults = await vectorDb.queryVectors(queryEmbedding, 2);

  // 4.5. Display Results
  console.log("\n--- Semantic Search Results (Top 2) ---");
  if (searchResults.length === 0) {
    console.log("No results found.");
  } else {
    searchResults.forEach((result, i) => {
      console.log(`\nResult ${i + 1}:`);
      console.log(`  Similarity Score: ${result.score.toFixed(4)}`);
      console.log(`  Vector ID: ${result.id}`);
      console.log(`  Source URL: ${result.metadata.source}`);
      console.log(`  Original Text Snippet: ${result.metadata.original_text_preview}`);
    });
  }
}

// Execute the main function
runDocuSearchIndexingAndQuery().catch(console.error);
