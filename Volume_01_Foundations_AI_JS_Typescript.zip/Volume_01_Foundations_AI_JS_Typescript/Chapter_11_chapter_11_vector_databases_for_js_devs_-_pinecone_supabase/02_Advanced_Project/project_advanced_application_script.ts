/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2025 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// index.ts - SaaS Documentation RAG Service
import { Pinecone } from '@pinecone-database/pinecone';
import { OpenAI } from 'openai';
import 'dotenv/config'; // Used to load API keys and environment variables

// --- Configuration & Constants ---
const INDEX_NAME = process.env.PINECONE_INDEX || 'dev-docs-index';
const EMBEDDING_MODEL = 'text-embedding-ada-002';
const LLM_MODEL = 'gpt-3.5-turbo';
const DIMENSION = 1536; // Standard dimension for Ada-002 embeddings

// Initialize Clients using the Pinecone Client (Node.js) SDK
const pc = new Pinecone({ apiKey: process.env.PINECONE_API_KEY! });
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

/**
 * @typedef {object} DocChunk
 * @property {string} id - Unique identifier for the document chunk.
 * @property {string} text - The raw text content of the chunk.
 * @property {string} source - Metadata indicating the origin of the document.
 */

// 1. Mock Documentation Data (Simulating data loaded, chunked, and ready for ingestion)
const mockDocs: DocChunk[] = [
    { id: 'doc1', text: 'Rate limiting ensures API stability. Standard limits are 100 requests per minute (RPM). Exceeding this returns a 429 status code.', source: 'API_v3_Limits' },
    { id: 'doc2', text: 'To handle 429 errors, implement an exponential backoff strategy in your client application. Retry logic should be capped at five attempts.', source: 'Error_Handling' },
    { id: 'doc3', text: 'The new v4 SDK uses asynchronous methods exclusively for better performance. It leverages WASM SIMD for highly optimized vector and array operations.', source: 'SDK_v4_Features' },
];

/**
 * Creates an embedding vector for a given text string using OpenAI.
 * This is the first step of the RAG pipeline: converting query text to a vector.
 * @param {string} text - The text to embed.
 * @returns {Promise<number[]>} The 1536-dimensional embedding vector.
 */
async function createEmbedding(text: string): Promise<number[]> {
    const response = await openai.embeddings.create({
        model: EMBEDDING_MODEL,
        input: text,
    });
    return response.data[0].embedding;
}

/**
 * Upserts (inserts or updates) documentation vectors into Pinecone.
 * This step defines the memory of the intelligent application.
 * NOTE: In a production script, this is usually a separate ingestion job.
 * @param {DocChunk[]} chunks - Array of document chunks to process.
 */
async function upsertVectors(chunks: DocChunk[]): Promise<void> {
    console.log(`[INGEST] Preparing ${chunks.length} vectors for upsert...`);
    // NOTE: Actual upsert logic is commented out to prevent API calls during architecture testing.
    // const vectors = await Promise.all(chunks.map(async (chunk) => ({ id: chunk.id, values: await createEmbedding(chunk.text), metadata: { source: chunk.source, text: chunk.text } })));
    // await pc.index(INDEX_NAME).upsert(vectors);
    console.log("[INGEST] Upsert simulation complete. Index ready for querying.");
}

/**
 * Performs a semantic search against the Pinecone index (Retrieval step).
 * This uses the generated query vector to find nearest neighbors.
 * @param {string} query - The user's natural language question.
 * @param {number} topK - Number of nearest neighbors to retrieve.
 * @returns {Promise<string[]>} An array of relevant text chunks (context).
 */
async function queryPinecone(query: string, topK: number = 3): Promise<string[]> {
    const queryVector = await createEmbedding(query);
    const index = pc.index(INDEX_NAME);

    console.log(`[SEARCH] Querying index ${INDEX_NAME} for top ${topK} matches...`);
    const queryResults = await index.query({
        vector: queryVector,
        topK: topK,
        includeMetadata: true,
    });

    const relevantChunks: string[] = queryResults.matches
        ?.filter(match => match.score && match.score > 0.7) // Apply score filtering for relevance
        .map(match => (match.metadata as any)?.text || '') || [];

    return relevantChunks;
}

/**
 * Uses the retrieved context to synthesize a final answer using the LLM (Generation step).
 * @param {string} query - The original user query.
 * @param {string[]} contextChunks - The relevant documentation retrieved from Pinecone.
 * @returns {Promise<string>} The synthesized answer.
 */
async function synthesizeAnswer(query: string, contextChunks: string[]): Promise<string> {
    const context = contextChunks.join('\n---\n');
    const prompt = `You are a helpful documentation assistant. Use the following documentation context to answer the user's question accurately. If the context does not contain the answer, state that you cannot find the relevant information.

    CONTEXT:
    ---
    ${context}
    ---

    USER QUESTION: ${query}`;

    console.log('[SYNTHESIS] Sending prompt (with context) to LLM...');
    const chatCompletion = await openai.chat.completions.create({
        model: LLM_MODEL,
        messages: [{ role: 'user', content: prompt }],
        temperature: 0.1, // Low temperature for factual responses
    });

    return chatCompletion.choices[0].message.content || "Error synthesizing response.";
}

/**
 * Main RAG execution pipeline for the SaaS documentation service.
 */
async function main() {
    console.log("--- SaaS Documentation RAG Pipeline Initialized ---");

    // 2. Data Ingestion Simulation (Assuming index exists)
    // await upsertVectors(mockDocs);

    const userQuery = "How should I handle 429 errors when dealing with API rate limits?";

    try {
        // 3. Retrieval Step (RAG - R)
        const context = await queryPinecone(userQuery, 2);

        if (context.length === 0) {
            console.log("\n[RESULT] No relevant documentation found above the score threshold.");
            return;
        }

        console.log(`\n[RETRIEVED CONTEXT] Successfully found ${context.length} relevant chunks.`);

        // 4. Generation Step (RAG - G)
        const answer = await synthesizeAnswer(userQuery, context);

        console.log("\n=================================================");
        console.log(`USER QUERY: ${userQuery}`);
        console.log("-------------------------------------------------");
        console.log(`ASSISTANT RESPONSE:\n${answer}`);
        console.log("=================================================");

    } catch (error) {
        console.error("A critical error occurred during the RAG pipeline execution:", error);
    }
}

main();
