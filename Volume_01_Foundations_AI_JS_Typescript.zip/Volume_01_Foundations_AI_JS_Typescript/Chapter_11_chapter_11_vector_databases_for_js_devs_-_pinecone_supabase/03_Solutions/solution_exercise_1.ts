
/*
 * These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
 * You can find the series on Amazon.
 * New books info: https://linktr.ee/edgarmilvus
 *
 * MIT License
 * Copyright (c) 2025 Edgar Milvus
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */

// Source File: solution_exercise_1.ts
// Description: Solution for Exercise 1
// ==========================================

// Note: This solution uses TypeScript/Node.js as required by the exercise context.
import { Pinecone } from '@pinecone-database/pinecone';
import { OpenAI } from 'openai';
import { v4 as uuidv4 } from 'uuid';

// --- Configuration ---
// Assume environment variables are set: PINECONE_API_KEY, OPENAI_API_KEY
const PC_INDEX_NAME = 'product-docs';
const EMBEDDING_MODEL = 'text-embedding-3-small';
const BATCH_SIZE = 100;

// Initialize clients (using placeholders for environment variables)
// const pc = new Pinecone({ apiKey: process.env.PINECONE_API_KEY });
// const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

// Simulated Data Source (250 documents)
const simulatedCorpus = Array.from({ length: 250 }).map((_, i) => ({
    text: `Content chunk for product feature ${i}. Detailed explanation of API endpoint /v1/feature/${i}.`,
    source_id: `doc_${Math.floor(i / 50) + 1}`,
    version: i % 2 === 0 ? 'v1.0' : 'v2.0',
    timestamp: Date.now() - (i * 10000), 
}));

/** Generates a 1536-dimensional embedding (Mocked for execution) */
async function generateEmbedding(text: string): Promise<number[]> {
    // In a real scenario, this calls openai.embeddings.create
    return Array(1536).fill(0).map(() => Math.random()); 
}

async function ingestDocuments(pcClient: any) {
    console.log(`Starting ingestion into index: ${PC_INDEX_NAME}`);
    const index = pcClient.index(PC_INDEX_NAME);
    let totalUpserted = 0;
    let batch: any[] = [];

    for (const [i, doc] of simulatedCorpus.entries()) {
        const embedding = await generateEmbedding(doc.text);

        const vector = {
            id: uuidv4(),
            values: embedding,
            metadata: {
                source_id: doc.source_id,
                version: doc.version,
                timestamp: doc.timestamp,
            },
        };
        
        batch.push(vector);

        // Batch Upsertion Strategy
        if (batch.length === BATCH_SIZE || i === simulatedCorpus.length - 1) {
            console.log(`Upserting batch of size ${batch.length}...`);
            
            // await index.upsert(batch); // Actual Pinecone API call
            totalUpserted += batch.length;
            batch = []; // Reset batch
        }
    }

    console.log(`\n--- Ingestion Complete ---`);
    console.log(`Total vectors processed and upserted: ${totalUpserted}`);

    // Verification and Reporting (Mocked stats retrieval)
    // const stats = await index.describeIndexStats();
    // const finalCount = stats.namespaces['']?.vectorCount || 0;
    // console.log(`Confirmed vector count in Pinecone index: ${finalCount}`);
}

// Example usage: ingestDocuments(pc);
