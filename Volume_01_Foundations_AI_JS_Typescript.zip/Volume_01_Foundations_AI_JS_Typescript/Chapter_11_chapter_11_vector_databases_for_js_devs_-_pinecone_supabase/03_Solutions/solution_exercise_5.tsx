
/*
 * These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
 * You can find the series on Amazon.
 * New books info: https://linktr.ee/edgarmilvus
 *
 * MIT License
 * Copyright (c) 2025 Edgar Milvus
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */

// Source File: solution_exercise_5.tsx
// Description: Solution for Exercise 5
// ==========================================

// Note: This solution uses TypeScript/React as required by the exercise context.
import React, { useState, useEffect } from 'react';

// 2. Component State Management (TypeScript Interface)
interface SearchResult {
    content: string;
    score: number; // Raw cosine distance (0 to 2)
    sourceId: string;
}

// 3. Debouncing Implementation
const useDebounce = (value: string, delay: number) => {
    const [debouncedValue, setDebouncedValue] = useState(value);
    useEffect(() => {
        const handler = setTimeout(() => { setDebouncedValue(value); }, delay);
        return () => { clearTimeout(handler); };
    }, [value, delay]);
    return debouncedValue;
};

// 4. Scoring Logic: Convert distance to percentage relevance
const scoreToRelevance = (distance: number): string => {
    // Cosine Similarity S = 1 - (Distance / 2)
    const similarity = 1 - (distance / 2);
    return `${(similarity * 100).toFixed(0)}% Relevant`;
};

// Simulated Backend API Call
async function fetchSemanticResults(query: string): Promise<SearchResult[]> {
    await new Promise(resolve => setTimeout(resolve, 800)); 
    return [
        { content: `Result A: Guide on ${query}.`, score: 0.1, sourceId: "doc_1" },
        { content: `Result B: FAQ regarding ${query}.`, score: 0.45, sourceId: "doc_2" },
    ];
}

const SemanticSearchBox: React.FC = () => {
    const [query, setQuery] = useState<string>('');
    const [isLoading, setIsLoading] = useState<boolean>(false);
    const [results, setResults] = useState<SearchResult[]>([]);

    const debouncedQuery = useDebounce(query, 500); // 500ms delay

    useEffect(() => {
        if (debouncedQuery.length < 3) {
            setResults([]);
            return;
        }

        const search = async () => {
            setIsLoading(true);
            try {
                const fetchedResults = await fetchSemanticResults(debouncedQuery);
                setResults(fetchedResults);
            } catch (e) {
                setResults([]);
            } finally {
                setIsLoading(false);
            }
        };
        search();
    }, [debouncedQuery]);

    return (
        <div style={{ maxWidth: '600px', margin: 'auto' }}>
            <input
                type="text"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Search documentation semantically..."
                style={{ width: '100%', padding: '10px' }}
            />

            {/* Conditional Rendering */}
            {isLoading && <p>Searching...</p>}
            
            {!isLoading && results.length > 0 && (
                <ul>
                    {results.map((result, index) => (
                        <li key={index} style={{ marginBottom: '10px' }}>
                            <strong style={{ color: 'green' }}>
                                [{scoreToRelevance(result.score)}]
                            </strong> 
                            {result.content} 
                            <span style={{ display: 'block', fontSize: '0.8em', color: '#888' }}>
                                Source: {result.sourceId}
                            </span>
                        </li>
                    ))}
                </ul>
            )}
        </div>
    );
};
