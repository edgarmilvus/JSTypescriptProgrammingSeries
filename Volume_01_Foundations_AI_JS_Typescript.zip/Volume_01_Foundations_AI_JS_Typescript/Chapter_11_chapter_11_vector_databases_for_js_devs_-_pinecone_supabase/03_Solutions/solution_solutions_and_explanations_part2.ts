/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2025 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

// Note: This solution uses TypeScript/Node.js as required by the exercise context.
import { QueryFilter } from '@pinecone-database/pinecone';

interface SearchResult {
    content: string;
    score: number;
    sourceId: string;
    version: string;
}

// Placeholder for embedding generation (from Exercise 1)
async function generateEmbedding(text: string): Promise<number[]> {
    return Array(1536).fill(0).map(() => Math.random()); 
}

async function performHybridSearch(
    pcClient: any, 
    queryText: string, 
    filters: QueryFilter // Accepts dynamic MongoDB-style filter object
): Promise<SearchResult[]> {
    
    // 1. Generate Query Vector
    const queryVector = await generateEmbedding(queryText);

    // 2. Construct the Pinecone query object
    const queryRequest = {
        vector: queryVector,
        topK: 5,
        includeMetadata: true,
        filter: filters, // Dynamically applied filter
    };

    // 3. Execute the query (simulated)
    // const response = await pcClient.index('product-docs').query(queryRequest);
    
    // Mocking response matches the required output structure
    const response = { matches: [] }; 

    // 4. Process the output
    return response.matches.map((match: any) => ({
        content: match.metadata?.content || 'N/A',
        score: match.score,
        sourceId: match.metadata?.source_id || 'N/A',
        version: match.metadata?.version || 'N/A',
    }));
}

// --- Demonstration of Filtering Syntax ---

// Scenario A (Equality and Range): Search for v2.0 documents created after Jan 1, 2023
const filtersA: QueryFilter = {
    $and: [
        { version: { $eq: "v2.0" } },
        { timestamp: { $gt: 1672531200 } } 
    ]
};

// Scenario B (Inclusion and Exclusion): Search excluding specific deprecated documents
const filtersB: QueryFilter = {
    source_id: { $nin: ["doc_123", "doc_456"] } 
};
