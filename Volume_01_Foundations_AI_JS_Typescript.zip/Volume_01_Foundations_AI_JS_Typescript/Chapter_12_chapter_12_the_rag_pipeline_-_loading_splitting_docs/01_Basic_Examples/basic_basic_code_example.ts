/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2025 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

// ingestionService.ts

import { RecursiveCharacterTextSplitter } from "langchain/text_splitters";
import { Document } from "langchain/document";

/**
 * @typedef {import("langchain/document").Document} Document
 */

/**
 * Simulates the RAG ingestion service for a SaaS platform's knowledge base.
 * This function loads raw text and splits it into optimized chunks for vector storage.
 *
 * CRITICAL: This function adheres to Strict Type Discipline, ensuring the output is
 * always an array of LangChain Document objects, minimizing runtime errors.
 *
 * @param rawText The large, unstructured text content to be processed (e.g., loaded from S3).
 * @returns A promise that resolves to an array of LangChain Document objects (the chunks).
 */
async function processKnowledgeBaseIngestion(rawText: string): Promise<Document[]> {
    // 1. Define Splitting Parameters
    // A chunk size of 1000 characters is a common starting point, optimizing for
    // popular embedding models (which often have context limits around 1536 tokens).
    const CHUNK_SIZE = 1000;
    // Overlap ensures that sentences or critical context spanning two chunks are
    // captured in both, mitigating the "split-sentence" problem during retrieval.
    const CHUNK_OVERLAP = 200;

    console.log(`Starting ingestion process. Raw size: ${rawText.length} characters.`);

    // 2. Instantiate the Splitter
    // RecursiveCharacterTextSplitter attempts to split intelligently by trying a list of
    // separators in order (e.g., paragraphs, then sentences, then words).
    const splitter = new RecursiveCharacterTextSplitter({
        chunkSize: CHUNK_SIZE,
        chunkOverlap: CHUNK_OVERLAP,
        // The order of separators is crucial: prioritize large structural breaks first.
        separators: ["\n\n", "\n", " ", ""],
    });

    // 3. Convert Raw Text into a Single LangChain Document
    // In a real application, a DocumentLoader (like PDFLoader or CSVLoader) would
    // handle this. Here, we manually create the standardized input Document.
    const sourceDocument = new Document({
        pageContent: rawText,
        metadata: {
            source: "SaaS_Policy_Manual_Q3_2024",
            timestamp: new Date().toISOString(),
            // Metadata is essential for filtering (pre-filtering/post-filtering) and attribution.
        },
    });

    // 4. Execute the Asynchronous Splitting Operation
    // Splitting can be computationally intensive for massive files, hence the async nature.
    const splitDocuments = await splitter.splitDocuments([sourceDocument]);

    console.log(`Ingestion complete. Total chunks generated: ${splitDocuments.length}`);

    return splitDocuments;
}

// --- Execution Context (Simulating a serverless function trigger or API endpoint) ---

// Example raw data (e.g., loaded from a database or file storage)
const longPolicyText = `
    Section 1: Service Level Agreement (SLA). Our uptime commitment is 99.9% calculated monthly. 
    Exclusions apply during scheduled maintenance windows, which are typically announced 48 hours in advance. 
    Any downtime exceeding this threshold permits the client to request a 10% credit on the subsequent month's bill. 
    This is critical for enterprise clients. This section is very long and detailed, covering all edge cases 
    of service disruption, including force majeure events, regional outages, and planned infrastructure upgrades. 
    The goal is absolute transparency regarding service availability and compensation mechanisms.

    Section 2: Data Retention and Privacy. All customer data is encrypted at rest using AES-256. 
    We adhere strictly to GDPR and CCPA guidelines. Data is retained for 90 days post-cancellation, 
    after which it is securely purged. Access logs are retained for audit purposes for 1 year. 
    Strict adherence to privacy protocols is mandatory. No customer data leaves the specified geopolitical region 
    unless explicitly authorized by the customer via written consent and audited annually.

    Section 3: Billing and Payment Terms. Invoices are issued on the 1st of every month. 
    Payment is due net 30 days. Late payments incur a 5% interest charge per month, compounded monthly. 
    Subscription downgrades take effect at the start of the next billing cycle. Upgrades are immediate. 
    We accept all major credit cards and wire transfers. Disputes must be filed within 15 days of the invoice date.
`;

// Main invocation function
async function main() {
    try {
        const chunks = await processKnowledgeBaseIngestion(longPolicyText);

        // Output the results for inspection
        console.log("\n--- Sample Chunk Output ---");
        chunks.slice(0, 2).forEach((chunk, index) => {
            console.log(`\n[Chunk ${index + 1} / ${chunks.length}]`);
            // Note how the metadata is preserved across the split
            console.log(`Metadata: ${JSON.stringify(chunk.metadata, null, 2)}`);
            console.log("Content Preview:");
            console.log(`"${chunk.pageContent.substring(0, 250)}..."`);
        });
    } catch (error) {
        console.error("An error occurred during RAG ingestion:", error);
    }
}

// Execute the service
main();
