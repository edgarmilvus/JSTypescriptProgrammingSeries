# These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
# You can find the series on Amazon.
# New books info: https://linktr.ee/edgarmilvus
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import os
import tempfile
from pathlib import Path
from typing import List, Dict, Type

# 1. LangChain Core Imports
# Note: We use the Python LangChain libraries, mimicking the structure and
# functionality of their JavaScript/TypeScript counterparts (LangChain.js).
from langchain_community.document_loaders import TextLoader, UnstructuredHTMLLoader
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_core.documents import Document

# --- Setup: Mocking a SaaS File Upload Environment ---

# Define temporary directory for simulation
TEMP_UPLOAD_DIR = Path(tempfile.mkdtemp())

# 2. Mock Data Generation
def create_mock_files(directory: Path):
    """Creates synthetic documents simulating user uploads (TXT and HTML)."""
    
    # 2.1. Standard Policy Document (TXT)
    policy_content = (
        "## Company Refund Policy (V3.1)\n\n"
        "All subscription cancellations must be submitted 30 days prior to the renewal date. "
        "Failure to adhere to this timeline results in automatic renewal. "
        "Exceptions are made only for documented force majeure events. "
        "Contact the finance department for special consideration. "
        "This policy ensures operational stability and resource allocation planning. "
        "The maximum refund amount processed is capped at $5,000 per quarter."
    )
    with open(directory / "refund_policy.txt", "w", encoding="utf-8") as f:
        f.write(policy_content)
        
    # 2.2. Complex FAQ Page (HTML) - Requires structural parsing
    html_content = (
        "<html><body><h1>FAQ: Technical Support</h1>"
        "<p>Our primary support channel is via email (support@corp.com). "
        "We guarantee a 4-hour response time for all Tier 1 issues. "
        "Tier 2 issues, which require engineering intervention, may take up to 24 hours.</p>"
        "<h2>Service Level Agreements (SLAs)</h2>"
        "<ul><li>P1 Incidents: 1 hour resolution target.</li>"
        "<li>P2 Incidents: 4 hour resolution target.</li>"
        "<li>P3 Incidents: Next business day resolution.</li></ul>"
        "<p>Note: Downtime notifications are posted on the status page.</p></body></html>"
    )
    with open(directory / "support_faq.html", "w", encoding="utf-8") as f:
        f.write(html_content)
        
    print(f"[SETUP] Created mock files in: {directory}")

# --- Core RAG Ingestion Logic ---

class KnowledgeBaseIngestor:
    """
    @class: Orchestrates the loading and splitting stages of the RAG pipeline.
    Designed for high-throughput, multi-format document ingestion in a SaaS backend.
    """
    
    def __init__(self, upload_dir: Path, chunk_size: int = 800, chunk_overlap: int = 150):
        """Initializes the ingestor with configuration parameters."""
        self.upload_dir = upload_dir
        self.chunk_size = chunk_size
        self.chunk_overlap = chunk_overlap
        # Define mapping of file extensions to their corresponding LangChain Loaders
        self.loader_map: Dict[str, Type] = {
            ".txt": TextLoader,
            ".html": UnstructuredHTMLLoader, # Unstructured is better for complex HTML/PDF parsing
        }

    def _load_documents(self) -> List[Document]:
        """
        @description: Iterates through the upload directory and loads documents 
        using the appropriate LangChain DocumentLoader based on file extension.
        @returns: A list of raw, full-content LangChain Document objects.
        """
        all_documents: List[Document] = []
        
        # 3. Dynamic Loading Loop
        for file_path in self.upload_dir.iterdir():
            suffix = file_path.suffix.lower()
            if suffix in self.loader_map:
                try:
                    LoaderClass = self.loader_map[suffix]
                    # Instantiate the loader with the file path
                    loader = LoaderClass(str(file_path))
                    # Load the document(s). Metadata (source) is automatically attached.
                    loaded_docs = loader.load()
                    all_documents.extend(loaded_docs)
                    print(f"    -> Successfully loaded {file_path.name} using {LoaderClass.__name__}.")
                except Exception as e:
                    print(f"    -> ERROR loading {file_path.name}: {e}")
            else:
                print(f"    -> Skipping {file_path.name}: No registered loader.")
                
        return all_documents

    def _split_documents(self, documents: List[Document]) -> List[Document]:
        """
        @description: Chunks the raw documents using the RecursiveCharacterTextSplitter 
        to ensure semantic context preservation.
        @param documents: The list of raw LangChain Documents.
        @returns: The list of optimized, chunked Documents.
        """
        # 4. Text Splitter Initialization
        # Recursive splitter is the industry standard for RAG quality
        text_splitter = RecursiveCharacterTextSplitter(
            chunk_size=self.chunk_size,
            chunk_overlap=self.chunk_overlap,
            # Prioritized separators ensure we try to split by paragraphs/sections first
            separators=["\n\n", "\n", " ", ""], 
            length_function=len # Standard length calculation
        )
        
        # 5. Splitting Execution
        chunked_docs = text_splitter.split_documents(documents)
        return chunked_docs

    def process_ingestion_pipeline(self) -> List[Document]:
        """The main entry point for the ingestion service."""
        print("\n--- RAG Ingestion Pipeline Start ---")
        
        # Stage 1: Loading
        raw_docs = self._load_documents()
        print(f"\n[STAGE 1 COMPLETE] Loaded {len(raw_docs)} raw documents.")

        if not raw_docs:
            print("Pipeline aborted: No documents found.")
            return []

        # Stage 2: Splitting/Chunking
        print(f"\n[STAGE 2 START] Chunking documents (Size: {self.chunk_size}, Overlap: {self.chunk_overlap})...")
        final_chunks = self._split_documents(raw_docs)
        print(f"[STAGE 2 COMPLETE] Generated {len(final_chunks)} optimized chunks.")
        
        # 6. Final Output Inspection (Verification)
        print("\n--- Verification Sample ---")
        if final_chunks:
            sample_chunk = final_chunks[0]
            print(f"Sample Chunk Content (Source: {sample_chunk.metadata.get('source', 'N/A')}):")
            print(f"Length: {len(sample_chunk.page_content)} characters.")
            print(f"Content Snippet: '{sample_chunk.page_content[:150]}...'")
        
        return final_chunks

# --- Execution Simulation ---
if __name__ == "__main__":
    # 7. Execution Context
    create_mock_files(TEMP_UPLOAD_DIR)
    
    # Instantiate and run the ingestion service
    ingestor = KnowledgeBaseIngestor(
        upload_dir=TEMP_UPLOAD_DIR,
        chunk_size=700, # Slightly larger chunks for theoretical embedding efficiency
        chunk_overlap=120
    )
    
    processed_chunks = ingestor.process_ingestion_pipeline()
    
    # 8. Cleanup
    for f in TEMP_UPLOAD_DIR.iterdir():
        os.remove(f)
    os.rmdir(TEMP_UPLOAD_DIR)
    print("\n[CLEANUP] Temporary directory removed.")

