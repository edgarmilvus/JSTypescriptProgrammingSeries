
/*
 * These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
 * You can find the series on Amazon.
 * New books info: https://linktr.ee/edgarmilvus
 *
 * MIT License
 * Copyright (c) 2025 Edgar Milvus
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */

// Source File: solution_exercise_1.ts
// Description: Solution for Exercise 1
// ==========================================

import { z } from 'zod';
import { Document } from 'langchain/document';
import { WebBaseLoader } from 'langchain/document_loaders/web';
import { TextLoader } from 'langchain/document_loaders/fs/text';
import { DirectoryLoader } from 'langchain/document_loaders/fs/directory';

// 1. Define Strict Zod Schemas
const MetadataSchema = z.object({
  source: z.string().min(1, "Metadata source is required."),
}).passthrough(); // Allows other metadata fields to exist

const DocumentSchema = z.object({
  pageContent: z.string().min(1, "Document content cannot be empty."),
  metadata: MetadataSchema,
});

type ValidatedDocument = z.infer<typeof DocumentSchema>;

// 2. Define the Ingestion Function
async function loadAndStandardizeDocs(): Promise<ValidatedDocument[]> {
  // --- Simulation Setup ---
  // In a real scenario, we'd use DirectoryLoader for Markdown, 
  // but for simulation, we use TextLoader on a mock path.
  
  // A. Load Local Markdown (Simulated)
  const markdownLoader = new TextLoader("./data/documentation_guide.md", {
      // Custom handling for Markdown splitting could be added here
  });
  const localDocsPromise = markdownLoader.load();

  // B. Load External Web Page
  const wikiUrl = 'https://example.com/legacy_wiki/setup';
  const webLoader = new WebBaseLoader(wikiUrl);
  const webDocsPromise = webLoader.load();

  // Load both sources in parallel
  const [localDocs, webDocs] = await Promise.all([localDocsPromise, webDocsPromise]);
  
  const allDocs = [...localDocs, ...webDocs];
  const validatedDocs: ValidatedDocument[] = [];

  // 3. Strict Type Enforcement and Error Handling
  for (const doc of allDocs) {
    try {
      // Zod attempts to parse the document structure
      const validatedDoc = DocumentSchema.parse(doc);
      validatedDocs.push(validatedDoc);
    } catch (error) {
      // If validation fails (e.g., missing 'source' in metadata), throw a descriptive error
      console.error(`Validation failed for document: ${JSON.stringify(doc.metadata)}`);
      throw new Error(`Strict Type Discipline Violation: Document failed Zod validation. Details: ${error}`);
    }
  }

  return validatedDocs;
}

// Example usage (assuming mock data loading succeeds)
// loadAndStandardizeDocs().then(docs => console.log(`Successfully loaded and validated ${docs.length} documents.`));
