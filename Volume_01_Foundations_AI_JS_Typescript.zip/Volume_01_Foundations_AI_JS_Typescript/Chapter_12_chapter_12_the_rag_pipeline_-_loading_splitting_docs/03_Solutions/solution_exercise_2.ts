
/*
 * These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
 * You can find the series on Amazon.
 * New books info: https://linktr.ee/edgarmilvus
 *
 * MIT License
 * Copyright (c) 2025 Edgar Milvus
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */

// Source File: solution_exercise_2.ts
// Description: Solution for Exercise 2
// ==========================================

import { RecursiveCharacterTextSplitter } from 'langchain/text_splitter';

const sampleText = `
# Chapter One: Foundations

This is the introductory paragraph for the first chapter. It covers the core principles of RAG.

This is the second paragraph, detailing the importance of vector databases.

#### Sub-Section A: Loaders
The loaders handle data ingestion. They ensure normalization.

1. Use WebBaseLoader for URLs.
2. Use PDFLoader for documents.
3. Use CSVLoader for structured data.


This is the final summary paragraph of the section.


## New Major Section: Splitting Strategy

Chunking is critical for context window management.
`;

// 1. Optimal Separator Definition
const optimalSeparators = [
    "\n\n\n\n", // Highest semantic break (Major Section/Chapter boundary)
    "\n\n\n",  // High semantic break (Major Subsection)
    "\n\n",   // Standard paragraph break
    "\n",     // Line break (for lists/bullet points)
    " ",      // Word break
    "",       // Fallback: character break
];

// 2. Configuration Implementation
const splitter = new RecursiveCharacterTextSplitter({
    chunkSize: 800,
    chunkOverlap: 80,
    separators: optimalSeparators,
});

// 3. Chunk Preservation Test
// const chunks = await splitter.splitText(sampleText);
// console.log(chunks.map(c => c.length)); 

/*
Description of Chunk Preservation:
The splitter will first attempt to break the text using the `\n\n\n\n` separator. Since the sample text does not contain this, it moves to `\n\n\n`. The text contains a triple newline separating the "final summary paragraph" from the "New Major Section: Splitting Strategy". 
The chunk boundary is preserved at the triple newline mark. 
The semantic unit prioritized is the complete scope of "Chapter One: Foundations" and its subsections, ensuring that the entire context of the section is kept together, even if it approaches the 800-character limit, before breaking it away from the subsequent major section.
*/
