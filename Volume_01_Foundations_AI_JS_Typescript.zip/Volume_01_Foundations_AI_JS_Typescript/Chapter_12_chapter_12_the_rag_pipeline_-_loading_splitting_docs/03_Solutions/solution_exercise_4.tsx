
/*
 * These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
 * You can find the series on Amazon.
 * New books info: https://linktr.ee/edgarmilvus
 *
 * MIT License
 * Copyright (c) 2025 Edgar Milvus
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */

// Source File: solution_exercise_4.tsx
// Description: Solution for Exercise 4
// ==========================================

// --- Server Action Simulation (Next.js App Router) ---
// This function runs on the server and handles the latency.
async function runIngestionPipeline(): Promise<{ chunkCount: number }> {
    console.log("Server: Starting pipeline...");
    
    // State 1: Loading (I/O intensive)
    await new Promise(resolve => setTimeout(resolve, 3000)); // Simulate Web/File Loading
    console.log("Server: Data loaded.");
    
    // State 2: Splitting/Validation (CPU intensive)
    // NOTE: To display an intermediate state *before* the final result, 
    // we must leverage client-side status updates or separate server calls.
    // For a single Suspense boundary resolving one promise, we simulate the total time.
    await new Promise(resolve => setTimeout(resolve, 5000)); // Simulate Splitting/Validation
    
    console.log("Server: Splitting complete.");
    return { chunkCount: 450 };
}

// --- Client-Side Component Structure ---
import React, { Suspense, use } from 'react';

// Custom hook/function to initiate and cache the server action result
// (In a real Next.js app, this would be a Server Action or a fetch wrapped in use() )
function useIngestionStatus() {
    // In a real app, this promise would be memoized/cached by the framework
    return use(runIngestionPipeline()); 
}

// Component that consumes the resolved data
function IngestionDetails() {
    const { chunkCount } = useIngestionStatus();
    
    // State 3: Complete
    return (
        <div className="status-complete">
            ✅ Ingestion Complete. {chunkCount} Chunks Ready for Embedding.
        </div>
    );
}

// The main monitor component
export function IngestionMonitor() {
    return (
        <div className="ingestion-monitor-container">
            <h2>RAG Pipeline Status</h2>
            
            {/* Suspense Boundary Implementation */}
            <Suspense fallback={
                // State 1: Initial Fetch (Displayed while runIngestionPipeline is pending)
                <div className="status-loading">
                    🔄 Ingesting Raw Data (Loading files and external sources)...
                </div>
            }>
                {/* 
                Since Suspense only handles the pending state of the initial fetch, 
                to show State 2 (Intermediate Status), we would typically introduce 
                a second, sequential data fetch or use a streaming response.
                
                For this synchronous promise resolution, we assume the component 
                displays State 1 (Loading) then jumps directly to State 3 (Complete).
                
                If we split runIngestionPipeline into two sequential fetches:
                1. loadRawData() -> resolves quickly, updates UI to State 2
                2. splitAndValidate(rawData) -> resolves slowly, updates UI to State 3
                
                Assuming the single-promise model for simplicity:
                */}
                <IngestionDetails />
            </Suspense>
            
            {/* 
            If State 2 was required via client-side logic:
            <IntermediateStatusDisplay /> // This component would monitor a second, faster promise resolution
            */}
        </div>
    );
}
