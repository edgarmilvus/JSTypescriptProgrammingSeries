/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2025 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

import { Document } from 'langchain/document';
import { RecursiveCharacterTextSplitter } from 'langchain/text_splitter';

// 1. Initial Document Setup
const SOURCE_DOC_ID = 'AR-2024-X47A';
const INGESTION_TIMESTAMP = new Date(); // Complex object metadata
const LONG_CONTENT = "The annual report for 2024 details significant growth in the AI sector, specifically focusing on RAG implementation strategies. "
                   + "Key initiatives included the deployment of new vector databases and the standardization of chunking protocols. "
                   + "The financial outlook remains strong, exceeding all previous projections. "
                   + "This section is extremely long and must be split into multiple parts to fit within standard context windows. "
                   + "We must ensure that every resulting chunk retains the full traceability data, including the unique document ID and the exact time of ingestion. "
                   + "The integrity of this metadata is non-negotiable for audit and citation purposes. "
                   + "This final paragraph confirms the successful completion of the project milestones for Q3. "
                   + "The total length of this content ensures multiple chunks are generated."
                   + "Padding data to ensure at least five chunks are created. "
                   + "P1 P2 P3 P4 P5 P6 P7 P8 P9 P10 P11 P12 P13 P14 P15 P16 P17 P18 P19 P20 P21 P22 P23 P24 P25 P26 P27 P28 P29 P30 P31 P32 P33 P34 P35 P36 P37 P38 P39 P40 P41 P42 P43 P44 P45 P46 P47 P48 P49 P50."; // ~1000 characters

const sourceDocument = new Document({
    pageContent: LONG_CONTENT,
    metadata: {
        source: 'annual_report_2024.pdf',
        docId: SOURCE_DOC_ID,
        timestamp: INGESTION_TIMESTAMP,
        page: 1,
    }
});

// 2. Splitting and Verification
const splitter = new RecursiveCharacterTextSplitter({
    chunkSize: 200, // Small size to guarantee multiple chunks
    chunkOverlap: 20,
});

const splitDocuments = await splitter.splitDocuments([sourceDocument]);

// 3. Metadata Check
console.log(`Total Chunks Generated: ${splitDocuments.length}`);

// Condition A: Check chunk count
if (splitDocuments.length <= 5) {
    throw new Error(`Condition A Failed: Expected more than 5 chunks, but got ${splitDocuments.length}`);
}

// Condition B: Check metadata propagation
let verificationSuccess = true;
for (let i = 0; i < splitDocuments.length; i++) {
    const chunk = splitDocuments[i];
    
    // Check docId
    if (chunk.metadata.docId !== SOURCE_DOC_ID) {
        console.error(`Chunk ${i} failed docId check.`);
        verificationSuccess = false;
    }

    // Check timestamp (using value equality for Date objects)
    const chunkTimestamp = chunk.metadata.timestamp as Date;
    if (!(chunkTimestamp instanceof Date && chunkTimestamp.getTime() === INGESTION_TIMESTAMP.getTime())) {
        console.error(`Chunk ${i} failed timestamp check.`);
        verificationSuccess = false;
    }
}

if (verificationSuccess) {
    console.log("Condition B Passed: All chunks successfully inherited the correct docId and timestamp.");
} else {
    throw new Error("Condition B Failed: Metadata integrity compromised during splitting.");
}
