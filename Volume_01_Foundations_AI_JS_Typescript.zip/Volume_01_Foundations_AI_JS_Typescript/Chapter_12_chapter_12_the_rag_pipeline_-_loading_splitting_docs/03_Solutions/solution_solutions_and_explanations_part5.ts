/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2025 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

// TypeScript structure for Scenario C simulation
import { RecursiveCharacterTextSplitter } from 'langchain/text_splitter';
import { Document } from 'langchain/document';

const DOCUMENT_CONTENT = "A very long string of 10,000 characters..."; 
// In a real simulation, this string would be 10,000 characters long.
const CONTENT_SIZE = 10000;
const CHUNK_SIZE = 500;
const OVERLAP_C = 250;

// Create a mock document content of exactly 10,000 characters
const longContent = "X".repeat(CONTENT_SIZE);

const splitterC = new RecursiveCharacterTextSplitter({
    chunkSize: CHUNK_SIZE,
    chunkOverlap: OVERLAP_C,
    separators: ["\n\n", "\n", " ", ""],
});

// Implementation required by the user:
const chunks = await splitterC.splitText(longContent);

// Calculate total character count across all chunks
let totalCharacters = 0;
for (const chunk of chunks) {
    totalCharacters += chunk.length;
}

console.log(`Total Chunks (C): ${chunks.length}`); 
// Expected output: 40 (or 41, depending on exact implementation edge cases, but 40 mathematically)
console.log(`Total Character Count (C): ${totalCharacters}`); 
// Expected output: 20000
