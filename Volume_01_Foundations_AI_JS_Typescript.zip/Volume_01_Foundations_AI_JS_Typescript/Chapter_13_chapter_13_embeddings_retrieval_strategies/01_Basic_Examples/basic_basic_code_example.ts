/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2025 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

import { OpenAIEmbeddings } from "@langchain/openai";
import { MemoryVectorStore } from "langchain/vectorstores/memory";
import { Document } from "langchain/document";

// --- Configuration ---
// NOTE: Ensure process.env.OPENAI_API_KEY is set in your environment.
const apiKey = process.env.OPENAI_API_KEY || "YOUR_API_KEY_HERE"; 

/**
 * @typedef {string} KnowledgeChunk
 * Simulates a simple knowledge base for a SaaS product documentation.
 * In a real application, these would be hundreds or thousands of chunks 
 * loaded from a database or file system.
 */
const saasKnowledgeBase: KnowledgeChunk[] = [
  "The primary subscription tier is 'Pro', which includes unlimited API calls.",
  "To reset your password, navigate to the 'Settings' menu under 'Security'.",
  "Our billing cycle runs from the 1st to the 30th of every month.",
  "The 'Free' tier limits users to 1,000 requests per day.",
  "Data retention policies dictate that inactive accounts are archived after 90 days."
];

/**
 * Main function to demonstrate the embedding and retrieval process.
 * This function handles the entire RAG pipeline from indexing to search.
 * @async
 */
async function runRetrievalExample() {
  // 1. Pre-flight check
  if (apiKey === "YOUR_API_KEY_HERE" || !process.env.OPENAI_API_KEY) {
    console.error("CRITICAL: Please set the OPENAI_API_KEY environment variable.");
    return;
  }

  console.log("--- Starting RAG Indexing and Retrieval Demo ---");
  
  // 2. Initialize Embedding Model
  console.log("1. Initializing OpenAI Embedding Model...");
  /**
   * Initializes the connection to the OpenAI API for generating embeddings.
   * We use text-embedding-3-small for its efficiency and quality.
   */
  const embeddings = new OpenAIEmbeddings({ 
    apiKey: apiKey,
    model: "text-embedding-3-small"
  });

  // 3. Prepare Documents for Indexing
  // LangChain requires data to be wrapped in Document objects, allowing metadata attachment.
  const documents: Document[] = saasKnowledgeBase.map((text, index) => new Document({
    pageContent: text,
    metadata: { source: `doc-${index}`, category: "Billing/Security" }
  }));

  // 4. Create the Vector Index (Indexing Phase)
  console.log(`2. Creating Vector Index from ${documents.length} documents...`);
  
  /**
   * MemoryVectorStore.fromDocuments performs two crucial steps:
   * a) Calls the OpenAI API to convert all document pageContents into vectors (embeddings).
   * b) Stores these vectors and their original text content in memory, creating the index.
   */
  const vectorStore = await MemoryVectorStore.fromDocuments(
    documents,
    embeddings
  );

  console.log("Indexing complete. Vector Store is ready for search.");

  // 5. Define the User Query
  const userQuery = "How many API calls can I make if I don't pay?";
  console.log(`\n3. User Query: "${userQuery}"`);

  // 6. Perform the Similarity Search (Retrieval Phase)
  /**
   * similaritySearch:
   * a) Takes the userQuery string and converts it into a Query Vector using the same 
   *    OpenAIEmbeddings model.
   * b) Compares this Query Vector against all stored vectors in the index using 
   *    a distance metric (like cosine similarity).
   * c) Returns the top K (k=2) documents that are mathematically closest (most semantically similar).
   */
  const K = 2;
  const results = await vectorStore.similaritySearch(userQuery, K);

  console.log(`\n4. Retrieval Results (Top ${K} Context Chunks):`);

  // 7. Display Results
  results.forEach((result, index) => {
    console.log(`\n--- Result ${index + 1} (Source: ${result.metadata.source}, Category: ${result.metadata.category}) ---`);
    console.log(`Content: ${result.pageContent}`);
  });
  
  console.log("\n--- Retrieval Complete ---");
}

runRetrievalExample().catch(console.error);
