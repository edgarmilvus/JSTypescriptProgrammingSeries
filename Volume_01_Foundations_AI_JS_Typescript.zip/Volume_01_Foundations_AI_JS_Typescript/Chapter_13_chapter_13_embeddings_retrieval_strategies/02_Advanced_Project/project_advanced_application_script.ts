/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2025 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

import { OpenAIEmbeddings } from "@langchain/openai";
import { ChatOpenAI } from "@langchain/openai";
import { Document } from "@langchain/core/documents";
import { RecursiveCharacterTextSplitter } from "langchain/text_splitter";
import { MemoryVectorStore } from "langchain/vectorstores/memory";
import { RetrievalQAChain } from "langchain/chains";
import { PromptTemplate } from "@langchain/core/prompts";

// --- 1. Configuration & Initialization ---

// Ensure OPENAI_API_KEY is set in your environment variables.
if (!process.env.OPENAI_API_KEY) {
    throw new Error("OPENAI_API_KEY environment variable is not set.");
}

/**
 * @typedef {Object} RagService
 * @property {RetrievalQAChain} chain - The initialized RAG chain.
 */

// Initialize the LLM and Embedding models
const model = new ChatOpenAI({
    modelName: "gpt-4o-mini",
    temperature: 0.1,
});
const embeddings = new OpenAIEmbeddings();

// --- 2. Simulated Proprietary Data Source ---

/**
 * Represents the internal documentation for the IntelliFlow SaaS product.
 * In a real application, this would be loaded from S3, a database, or a CMS.
 */
const rawDocumentation = [
    "The IntelliFlow API utilizes OAuth 2.0 for secure token generation. Access tokens expire after 60 minutes.",
    "Data synchronization occurs every 5 minutes using the proprietary DeltaSync algorithm, ensuring minimal latency.",
    "Billing plans are tiered: Basic (up to 1,000 requests/day), Pro (unlimited requests, priority support), and Enterprise (custom SLA).",
    "To troubleshoot connectivity issues, ensure port 443 is open and the firewall permits outbound traffic to *.intelliflow.com.",
    "The new feature release, 'FlowControl v2.1,' introduced granular permission settings at the workspace level, replacing v2.0's global roles.",
];

/**
 * @async
 * @description Loads, chunks, and processes raw text data into a vector store.
 * @returns {Promise<MemoryVectorStore>} The initialized vector store containing document embeddings.
 */
async function initializeVectorStore(): Promise<MemoryVectorStore> {
    console.log("1. Starting document preparation and embedding generation...");

    // A. Create Documents from raw data
    const docs = rawDocumentation.map((content) => new Document({ pageContent: content }));

    // B. Chunking Strategy: Splitting large documents into smaller, semantically coherent blocks.
    const splitter = new RecursiveCharacterTextSplitter({
        chunkSize: 500,
        chunkOverlap: 50,
    });
    const chunkedDocuments = await splitter.splitDocuments(docs);
    console.log(`   -> Total documents chunked: ${chunkedDocuments.length}`);

    // C. Embedding Generation and Vector Storage
    // The embedding model converts each text chunk into a high-dimensional vector.
    // This vector is then stored in the Vector Store (in-memory, simulating a dedicated DB).
    const vectorStore = await MemoryVectorStore.fromDocuments(
        chunkedDocuments,
        embeddings
    );
    console.log("2. Vector store initialized and embeddings generated successfully.");
    return vectorStore;
}

// --- 3. Retrieval and Synthesis Pipeline Orchestration ---

/**
 * @async
 * @description Sets up the complete RAG pipeline using the initialized vector store.
 * @param {MemoryVectorStore} vectorStore - The store containing the proprietary document vectors.
 * @returns {RetrievalQAChain} The chain ready for question answering.
 */
function setupRAGChain(vectorStore: MemoryVectorStore): RetrievalQAChain {
    // Define the custom prompt template for the LLM synthesis step.
    const customPromptTemplate = `
        You are the IntelliFlow Technical Support AI. Use the following retrieved context 
        to answer the user's question accurately and concisely. 
        If the answer cannot be found in the context, state clearly, "I apologize, that specific detail 
        is not available in the current documentation."

        Context:
        {context}

        Question: {question}
        Answer:
    `;
    const prompt = PromptTemplate.fromTemplate(customPromptTemplate);

    // Create a retriever object, specifying K=2 for KNN search.
    // This tells the system to find the 2 most semantically similar documents.
    const retriever = vectorStore.asRetriever({ k: 2 });

    // Initialize the RetrievalQAChain: orchestrating retrieval (KNN) and synthesis (LLM).
    const chain = RetrievalQAChain.fromLLM(model, retriever, {
        prompt,
        returnSourceDocuments: true, // Useful for debugging and citation in UI
    });

    console.log("3. RAG RetrievalQAChain initialized.");
    return chain;
}

// --- 4. Execution Function ---

/**
 * @async
 * @description Runs the entire RAG process for a given user query.
 * @param {string} query - The user's question.
 * @param {RetrievalQAChain} ragChain - The initialized RAG chain.
 */
async function runRAGQuery(query: string, ragChain: RetrievalQAChain) {
    console.log(`\n--- Running Query: "${query}" ---`);

    // The chain executes the following steps:
    // 1. Embed the query.
    // 2. Perform KNN search against the vector store (Retrieval).
    // 3. Combine retrieved context and query into the custom prompt.
    // 4. Send the prompt to the LLM (Synthesis).
    const response = await ragChain.call({ query });

    console.log("\n[🤖 AI Response]");
    console.log(response.text);

    console.log("\n[📚 Sources Used]");
    // @ts-ignore
    response.sourceDocuments.forEach((doc, index) => {
        console.log(`Source ${index + 1}: "${doc.pageContent.substring(0, 80)}..."`);
    });
}

// --- 5. Main Application Logic ---

/**
 * @async
 * @description Main function to run the IntelliFlow RAG service.
 */
async function main() {
    // 1. Initialize the Vector Store (Embedding Generation)
    const vectorStore = await initializeVectorStore();

    // 2. Setup the RAG Chain (Prompting & Retrieval Configuration)
    const ragChain = setupRAGChain(vectorStore);

    // 3. Execute Queries
    // Query 1: Direct question based on documentation
    await runRAGQuery("How often does data synchronization occur and what is the algorithm name?", ragChain);

    // Query 2: Question requiring synthesis and multiple context chunks
    await runRAGQuery("I am having trouble connecting to the service. What should I check?", ragChain);

    // Query 3: Question outside the knowledge base (testing hallucination prevention)
    await runRAGQuery("What is the capital of France?", ragChain);
}

main().catch(console.error);

// Target line count: 104 lines
