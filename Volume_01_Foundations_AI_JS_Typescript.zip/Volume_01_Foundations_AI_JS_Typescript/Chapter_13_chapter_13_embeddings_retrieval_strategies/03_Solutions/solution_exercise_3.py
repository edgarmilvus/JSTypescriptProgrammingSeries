
/*
 * These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
 * You can find the series on Amazon.
 * New books info: https://linktr.ee/edgarmilvus
 *
 * MIT License
 * Copyright (c) 2025 Edgar Milvus
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */

// Source File: solution_exercise_3.py
// Description: Solution for Exercise 3
// ==========================================

import os
from langchain.schema import Document
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_openai import OpenAIEmbeddings
from langchain_community.vectorstores import FAISS

# --- Setup: Indexing documents with a specific keyword ---
doc_content = """
This ID is critical for auditing purposes.
""" * 3

# 1. Keyword Indexing & Semantic Indexing Setup
text_splitter = RecursiveCharacterTextSplitter(chunk_size=150, chunk_overlap=30)
chunks = text_splitter.split_text(doc_content)

# Convert strings to Document objects and assign unique IDs
documents = [Document(page_content=c, metadata={"id": f"chunk_{i}"}) for i, c in enumerate(chunks)]

# Simple in-memory index for keyword search (stores raw text and IDs)
raw_text_index = {doc.metadata['id']: doc.page_content for doc in documents}

# Semantic Index (FAISS)
embeddings = OpenAIEmbeddings(model="text-embedding-ada-002")
vectorstore = FAISS.from_documents(documents, embeddings)

# 2. Semantic Search Component
def semanticSearch(query: str, k: int = 5) -> list[Document]:
    """Performs standard KNN vector search."""
    return vectorstore.similarity_search(query, k=k)

# 3. Keyword Search Component
def keywordSearch(query: str, k: int = 3) -> list[Document]:
    """Simulates BM25 by performing a simple case-insensitive substring search."""
    keyword_results = []
    lower_query = query.lower()
    
    for doc_id, text in raw_text_index.items():
        if lower_query in text.lower():
            # Recreate the Document object for consistency
            keyword_results.append(Document(page_content=text, metadata={"id": doc_id, "search_type": "keyword"}))
            if len(keyword_results) >= k:
                break
    return keyword_results

# 4. Result Merging Strategy
def hybridSearch(query: str):
    semantic_results = semanticSearch(query, k=5)
    keyword_results = keywordSearch(query, k=3)

    unique_results = {}

    # Add semantic results (prioritized)
    for doc in semantic_results:
        unique_results[doc.metadata['id']] = doc

    # Add keyword results (only if not already present)
    for doc in keyword_results:
        if doc.metadata['id'] not in unique_results:
            unique_results[doc.metadata['id']] = doc

    return list(unique_results.values())

# 5. Test Case
test_query = "Explain the company policy on remote work and reference the specific ID DOC-47B"
results = hybridSearch(test_query)

print(f"--- Hybrid Search Results for: '{test_query}' ---")
print(f"Total Unique Documents Retrieved: {len(results)}")

for i, doc in enumerate(results):
    search_type = doc.metadata.get("search_type", "semantic")
    print(f"\n[{i+1}] Source ID: {doc.metadata['id']} (Type: {search_type})")
    print(doc.page_content)
