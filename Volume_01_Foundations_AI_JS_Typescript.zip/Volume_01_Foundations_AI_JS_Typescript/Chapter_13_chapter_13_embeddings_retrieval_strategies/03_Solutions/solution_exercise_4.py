
/*
 * These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
 * You can find the series on Amazon.
 * New books info: https://linktr.ee/edgarmilvus
 *
 * MIT License
 * Copyright (c) 2025 Edgar Milvus
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */

// Source File: solution_exercise_4.py
// Description: Solution for Exercise 4
// ==========================================

# Definition of the required data structures using TypeScript syntax in comments.

# 1. Define the Retrieval Response Interface (TypeScript)
print("--- 1. TypeScript Interface Definition ---")
print("""
// Define the required TypeScript interface for the API response
interface RetrievedContext {
    chunkText: string;
    sourceDocument: string; // E.g., 'HR Policy Manual v2.1'
    similarityScore: number; // Relevance score (0.0 to 1.0)
    chunkMetadata: {
        pageNumber?: number;
        dateIndexed: string;
        [key: string]: any; // Allows for flexible additional metadata
    };
}

// Define the expected structure for the full API response array
type RetrievalResult = RetrievedContext[];
""")

# 2. React Component Requirements (Functional Specification)
print("\n--- 2. React Component: RetrievalContextViewer Functional Specification ---")

print("\nRequired Props:")
print("- `retrievalData`: RetrievalResult (The array of context objects from the API)")

print("\nRendering & Display Requirements:")
print("a. Must render a clear, ordered list of the retrieved chunks.")
print("b. Display the `sourceDocument` prominently (e.g., in a header above the text).")
print("c. Display the `similarityScore`, formatted to two decimal places (e.g., 'Score: 0.89').")
print("d. Display a truncated preview of the `chunkText` (e.g., the first 100 characters).")
print("e. Implement an expand/collapse toggle to view the full `chunkText` content.")

print("\nConditional Styling Requirement:")
print("f. The component must apply a distinct visual indicator (e.g., a green border or background) to any chunk whose `similarityScore` is above a defined threshold (e.g., 0.85), effectively highlighting the most relevant context used by the LLM.")
