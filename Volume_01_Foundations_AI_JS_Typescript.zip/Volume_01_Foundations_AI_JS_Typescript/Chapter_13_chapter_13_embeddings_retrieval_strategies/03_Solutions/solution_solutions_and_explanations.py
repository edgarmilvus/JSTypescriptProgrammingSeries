# These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
# You can find the series on Amazon.
# New books info: https://linktr.ee/edgarmilvus
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_solutions_and_explanations.py
# Description: Solutions and Explanations
# ==========================================

import os
from langchain_community.document_loaders import TextLoader
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_openai import OpenAIEmbeddings
from langchain_community.vectorstores import FAISS # Using FAISS for in-memory indexing

# 1. Setup: Create dummy document
document_content = """
Chapter 1: General Conduct. All employees must adhere to the highest standards of integrity.
Any breach of confidentiality will result in immediate disciplinary action. This includes
sharing proprietary information outside the company network. Unauthorized use of company
assets is strictly prohibited. Our policy on remote work states that all remote employees
must maintain secure VPN connections and submit weekly activity reports.
... (content repeated to simulate 1500+ words) ...
Chapter 4: Remote Work Policy Details. Employees working remotely must ensure their home office
environment meets basic security standards. The company provides a stipend for ergonomic equipment.
Requests for permanent remote status must be reviewed annually by HR. The rules regarding remote work
are designed to ensure productivity and data security. Specifically, all devices must use mandated
encryption software.
"""
with open("code_of_conduct.txt", "w") as f:
    f.write(document_content * 5) 

# 1. Load Document
loader = TextLoader("code_of_conduct.txt")
documents = loader.load()

# 2. Chunking Strategy
# chunkSize=500 captures sufficient context (several paragraphs).
# chunkOverlap=50 ensures continuity across splits, critical for semantic similarity.
text_splitter = RecursiveCharacterTextSplitter(
    chunk_size=500,
    chunk_overlap=50,
)
chunks = text_splitter.split_documents(documents)

# 3. Embedding Generation (Requires OPENAI_API_KEY)
embeddings = OpenAIEmbeddings(model="text-embedding-ada-002")

# 4. Indexing (FAISS is used as the high-performance in-memory vector store)
vectorstore = FAISS.from_documents(chunks, embeddings)
print(f"Successfully indexed {len(chunks)} chunks.")

# 5. Retrieval Test
test_query = "What are the rules regarding remote work?"
retrieved_docs = vectorstore.similarity_search(test_query, k=3)

print(f"--- Top 3 Retrieved Chunks for: '{test_query}' ---")
for i, doc in enumerate(retrieved_docs):
    print(f"\n[Chunk {i+1}, Source: {doc.metadata.get('source', 'N/A')}]")
    print(doc.page_content)

# Cleanup
os.remove("code_of_conduct.txt")
