# These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
# You can find the series on Amazon.
# New books info: https://linktr.ee/edgarmilvus
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_solutions_and_explanations_part2.py
# Description: Solutions and Explanations
# ==========================================

import os
from langchain_community.document_loaders import TextLoader
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_openai import OpenAIEmbeddings
from langchain_community.vectorstores import Chroma # Using Chroma for native filtering support

# 1. Document Preparation with Metadata
hr_content = "HR Policy 101: Employee salaries and bonuses are highly sensitive data. Do not discuss compensation. This policy is strictly internal. Security protocol requires two-factor authentication for all HR systems."
product_content = "Product Feature Guide: Our new API implements strict rate limiting of 100 requests per minute per user key. This ensures system stability. Details on the API endpoints can be found in section 4.1."

with open("hr_policy.txt", "w") as f: f.write(hr_content * 5)
with open("product_docs.txt", "w") as f: f.write(product_content * 5)

# Initialize components
text_splitter = RecursiveCharacterTextSplitter(chunk_size=200, chunk_overlap=20)
embeddings = OpenAIEmbeddings(model="text-embedding-ada-002")

# Load HR documents and assign metadata
hr_docs = TextLoader("hr_policy.txt").load()
hr_chunks = text_splitter.split_documents(hr_docs)
for chunk in hr_chunks:
    chunk.metadata["source_type"] = "HR"

# Load Product documents and assign metadata
product_docs = TextLoader("product_docs.txt").load()
product_chunks = text_splitter.split_documents(product_docs)
for chunk in product_chunks:
    chunk.metadata["source_type"] = "Product"

all_chunks = hr_chunks + product_chunks

# 2. Combined Indexing
vectorstore = Chroma.from_documents(all_chunks, embeddings)

# 3. Filtered Retrieval Implementation
query = "How does the API rate limiting work?"

# Define the filter to retrieve only 'Product' documents
metadata_filter = {"source_type": "Product"}

# Execute the search with the filter
retrieved_docs_filtered = vectorstore.similarity_search(
    query, 
    k=5, 
    filter=metadata_filter
)

print(f"--- Filtered Retrieval Results (k=5) for: '{query}' ---")
hr_docs_found = False
for i, doc in enumerate(retrieved_docs_filtered):
    source_type = doc.metadata.get("source_type")
    print(f"Chunk {i+1}: Source Type: {source_type}")
    if source_type == "HR":
        hr_docs_found = True

# 4. Verification
if not hr_docs_found:
    print("\n[SUCCESS] Metadata filtering was effective. No HR policy documents were retrieved.")
else:
    print("\n[FAILURE] HR policy documents were retrieved despite the filter.")

# Cleanup
os.remove("hr_policy.txt")
os.remove("product_docs.txt")
