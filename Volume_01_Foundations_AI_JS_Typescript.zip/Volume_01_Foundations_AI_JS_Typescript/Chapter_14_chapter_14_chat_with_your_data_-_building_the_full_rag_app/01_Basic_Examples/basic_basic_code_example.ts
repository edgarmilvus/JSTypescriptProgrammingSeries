/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2025 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

// rag-orchestrator.ts

// 1. Core Data Structures and Types
/** Represents a chunk of retrieved information from the vector store. */
interface Document {
    id: string;
    content: string;
    source: string;
}

/** The structured instruction the LLM might output to request tool use. */
interface RetrievalToolCall {
    action: 'retrieve';
    query: string; // The query to send to the vector store
}

/** The final, structured output of the RAG chain. */
interface RAGResponse {
    finalAnswer: string;
    usedContext: Document[];
    isToolCallExecuted: boolean;
}

// 2. Custom User-Defined Type Guard
/**
 * Performs a runtime check to narrow the type from 'any' to 'RetrievalToolCall'.
 * This is essential for safety when parsing LLM-generated JSON.
 * @param value The object potentially containing a tool call instruction.
 * @returns True if the object matches the RetrievalToolCall structure.
 */
function isRetrievalToolCall(value: any): value is RetrievalToolCall {
    // CRITICAL: Checks for object structure and required keys/types.
    return (
        typeof value === 'object' &&
        value !== null &&
        value.action === 'retrieve' &&
        typeof value.query === 'string'
    );
}

// 3. Simulated External Asynchronous Tools

/** 
 * Simulates interaction with a Vector Store (e.g., Pinecone, Chroma).
 * This function represents an Asynchronous Tool Handler.
 */
async function retrieveDocuments(query: string): Promise<Document[]> {
    console.log(`[Tool] Initiating asynchronous retrieval for: "${query}"...`);
    // Simulate network latency (critical for Node.js non-blocking execution)
    await new Promise(resolve => setTimeout(resolve, 500));

    // Hardcoded, relevant documents based on query intent
    if (query.toLowerCase().includes('policy')) {
        return [
            { id: 'doc-1', content: "The SaaS model mandates 99.9% uptime.", source: "SaaS Policy Manual" },
            { id: 'doc-2', content: "All user data must be encrypted at rest using AES-256.", source: "Security Standard 2.1" }
        ];
    }
    // Fallback
    return [];
}

/** 
 * Simulates the LLM API call. This acts as both the Router and the Generator.
 * In production, this would use the OpenAI or Anthropic SDK.
 */
async function getLLMDecision(prompt: string): Promise<string> {
    console.log("[LLM] Awaiting decision generation...");
    await new Promise(resolve => setTimeout(resolve, 700));

    // Logic: If the prompt contains 'policy', simulate a structured tool call instruction.
    if (prompt.toLowerCase().includes('policy') && !prompt.includes('Context:')) {
        // This is the output we hope the LLM provides when it needs external data.
        return JSON.stringify({
            action: 'retrieve',
            query: 'SaaS uptime and encryption policy details'
        });
    }
    // Otherwise, simulate a direct text answer.
    return "The current deployment standard requires TypeScript, a non-blocking Node.js architecture, and Zod validation for all API ingress points.";
}

// 4. The RAG Orchestration Chain (The State Machine)
/**
 * Executes the main RAG workflow: Router -> Type Guard -> Retrieval -> Generation.
 * @param initialQuery The user's input query.
 */
async function runRAGChain(initialQuery: string): Promise<RAGResponse> {
    let context: Document[] = [];
    let finalAnswer: string;
    let isToolCallExecuted = false;

    console.log(`\n--- Starting RAG Chain for: "${initialQuery}" ---`);

    // Step 1: Initial LLM Call (Router)
    // The 'await' keyword ensures the application waits non-blockingly for the external API response.
    const initialLLMOutput = await getLLMDecision(initialQuery);

    try {
        // Attempt to parse the output. This is where we handle the LLM's raw text response.
        const parsedOutput = JSON.parse(initialLLMOutput);

        // Step 2: Apply the Type Guard
        if (isRetrievalToolCall(parsedOutput)) {
            console.log("[Router] Tool Call detected and validated.");
            isToolCallExecuted = true;

            // Step 3: Execute the Asynchronous Tool (Retrieval)
            const retrievalQuery = parsedOutput.query;
            context = await retrieveDocuments(retrievalQuery); // Await Tool Handler

            // Step 4: Final LLM Call (Generation with Context)
            const contextString = context.map(doc => `[${doc.source}]: ${doc.content}`).join('\n');
            const generationPrompt = `Based on the following context, answer the user's query: "${initialQuery}". Context:\n${contextString}`;

            // Await the final generation API call
            finalAnswer = await getLLMDecision(generationPrompt); 

        } else {
            // Step 2b: If the Type Guard fails, treat the initial output as the final answer.
            console.log("[Router] Output did not match expected tool structure. Treating as direct answer.");
            finalAnswer = initialLLMOutput;
        }

    } catch (e) {
        // This catch block handles cases where JSON.parse fails (i.e., the LLM returned plain text).
        console.log("[Router] Output was not valid JSON. Treating as direct answer.");
        finalAnswer = initialLLMOutput;
    }

    return {
        finalAnswer: finalAnswer,
        usedContext: context,
        isToolCallExecuted: isToolCallExecuted
    };
}

// 5. Execution
async function main() {
    // Scenario 1: Requires RAG (Tool execution path)
    const policyQuery = "What is our current policy on SaaS security mandates?";
    const policyResult = await runRAGChain(policyQuery);
    console.log("\n--- FINAL RESULT (Policy Query) ---");
    console.log(`Tool Used: ${policyResult.isToolCallExecuted}`);
    console.log(`Answer: ${policyResult.finalAnswer}`);
    if (policyResult.usedContext.length > 0) {
        console.log(`Context Sources: ${policyResult.usedContext.map(d => d.source).join(', ')}`);
    }

    // Scenario 2: Direct Answer (No tool execution path)
    const techQuery = "Tell me about the required architecture standards.";
    const techResult = await runRAGChain(techQuery);
    console.log("\n\n--- FINAL RESULT (General Tech Query) ---");
    console.log(`Tool Used: ${techResult.isToolCallExecuted}`);
    console.log(`Answer: ${techResult.finalAnswer}`);
}

main();
