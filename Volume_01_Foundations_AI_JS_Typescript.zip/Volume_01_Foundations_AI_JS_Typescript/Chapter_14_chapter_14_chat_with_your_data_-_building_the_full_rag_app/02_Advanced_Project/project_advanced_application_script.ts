/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2025 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// server/actions/ragActions.ts
/**
 * @fileoverview Defines the Server Action for handling Retrieval-Augmented Generation (RAG) queries.
 * This file executes exclusively on the server, protecting API keys and managing the vector index connection.
 */
"use server"; // CRITICAL: Designates this file as a Server Action, ensuring secure execution environment.

import { z } from 'zod'; // Zod for robust input validation and schema definition.
import { OpenAI } from 'openai'; // Client for embedding generation and final chat completion.

// --- Mocking External Dependencies for Illustrative Purposes ---
// In a real application, these would be instantiated connectors (e.g., Pinecone client, Weaviate client).
class VectorIndexClient {
    private indexName: string;
    constructor(name: string) { this.indexName = name; }
    
    /**
     * @typedef {object} RetrievalResult
     * @property {string} id Unique identifier of the chunk.
     * @property {string} text The content of the retrieved document chunk.
     * @property {number} score Similarity score.
     * @property {string} sourceUrl URL or path to the original document.
     */
    
    /**
     * Simulates querying the specialized Vector Index structure.
     * @param {object} params
     * @param {number[]} params.vector The query embedding vector.
     * @param {number} params.topK The number of nearest neighbors to retrieve.
     * @param {object} [params.filter] Optional metadata filter (e.g., session ID, document type).
     * @returns {Promise<RetrievalResult[]>} A list of relevant document chunks.
     */
    async query({ vector, topK, filter }: { vector: number[], topK: number, filter?: object }) {
        console.log(`[VectorIndex] Searching index '${this.indexName}' with topK=${topK}.`);
        // Simulate latency and return relevant document chunks based on semantic search.
        await new Promise(resolve => setTimeout(resolve, 150)); 
        
        // Mock results simulating high-relevance chunks retrieved from the index.
        return [
            { id: 'doc-1a', text: 'DataFlow uses proprietary HNSW indexing for rapid metric aggregation.', score: 0.98, sourceUrl: '/docs/architecture/indexing' },
            { id: 'doc-2b', text: 'To configure the API key, ensure it is set as an environment variable starting with DF_API.', score: 0.95, sourceUrl: '/docs/setup/api_keys' },
            { id: 'doc-3c', text: 'The maximum throughput for the standard tier is 1000 requests per second.', score: 0.92, sourceUrl: '/docs/pricing/tiers' },
        ];
    }
}
// --- End Mocking ---

// 1. Initialize external clients securely on the server environment.
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
const indexClient = new VectorIndexClient('dataflow-docs'); // Connects to the specialized Vector Index.

// 2. Define the input schema using Zod for robust type safety and validation.
/**
 * Defines the expected structure for the client-side form submission.
 * Zod ensures that the input is clean before interacting with the LLM or Vector Index.
 */
const RAGQuerySchema = z.object({
  query: z.string().trim().min(10, "Query must be at least 10 characters long."),
  sessionId: z.string().optional(), // Used for potential history or user-specific filtering.
});

/**
 * @typedef {object} RAGResponse
 * @property {string} answer The generated AI response.
 * @property {Array<string>} sources The URLs of the documents used for context.
 */

// 3. The core Server Action function. This is the entry point for the client request.
/**
 * @async
 * @function handleRAGQuery
 * @description Handles the complete Retrieval-Augmented Generation (RAG) flow in a secure, server-side environment.
 * @param {z.infer<typeof RAGQuerySchema>} formData The validated input object from the client.
 * @returns {Promise<RAGResponse>} The generated answer and source documents.
 */
export async function handleRAGQuery(formData: unknown): Promise<RAGResponse> {
  
  // 3a. Runtime Validation using Zod's safeParse.
  // This step is crucial for Server Action security, preventing malformed inputs from reaching the database or LLM APIs.
  const validationResult = RAGQuerySchema.safeParse(formData);
  if (!validationResult.success) {
    console.error("Input validation failed:", validationResult.error.errors);
    // Throwing an error ensures the client receives a structured error response.
    throw new Error("Invalid query format. Please check the input constraints.");
  }
  const { query, sessionId } = validationResult.data;

  // --- Phase 1: Retrieval (Vector Index Interaction) ---
  
  // 4. Generate the embedding vector for the user's query.
  // This transforms the semantic meaning of the text into a high-dimensional vector.
  const embeddingResponse = await openai.embeddings.create({
    model: 'text-embedding-3-small',
    input: query,
  });
  const queryVector = embeddingResponse.data[0].embedding;

  // 5. Query the Vector Index (Nearest Neighbor Search).
  // The Vector Index rapidly finds document chunks whose vectors are closest to the query vector.
  const retrievalResults = await indexClient.query({
    vector: queryVector,
    topK: 5,
    // Example: Applying metadata filtering based on the session ID or user role.
    filter: sessionId ? { user_id: sessionId } : undefined, 
  });

  if (retrievalResults.length === 0) {
    return { 
      answer: "I couldn't find any relevant documentation in the DataFlow knowledge base for that query.", 
      sources: [] 
    };
  }

  // 6. Format the retrieved context and sources for the LLM prompt.
  const context = retrievalResults.map(doc => doc.text).join("\n---\n");
  const sources = retrievalResults.map(doc => doc.sourceUrl);

  // --- Phase 2: Augmentation and Generation (LLM Interaction) ---

  // 7. Construct the highly specific system prompt (Augmentation).
  // The prompt instructs the LLM to act as an authoritative assistant and strictly adhere to the provided context.
  const systemPrompt = `You are the DataFlow Analytics AI assistant, specialized in our documentation. 
    Use ONLY the following provided context to answer the user's question. Do not invent information. 
    If the answer is not present in the context, politely state that the information is unavailable.
    
    --- Context ---
    ${context}
    --- End Context ---`;

  // 8. Call the OpenAI Chat API securely from the server.
  const chatCompletion = await openai.chat.completions.create({
    model: 'gpt-4o-mini',
    messages: [
      { role: 'system', content: systemPrompt },
      { role: 'user', content: query },
    ],
    temperature: 0.1, // Low temperature encourages factual adherence to the context.
  });

  const answer = chatCompletion.choices[0].message.content || "Error: AI generation failed.";

  // 9. Return the final structured response to the client.
  return { answer, sources };
}
