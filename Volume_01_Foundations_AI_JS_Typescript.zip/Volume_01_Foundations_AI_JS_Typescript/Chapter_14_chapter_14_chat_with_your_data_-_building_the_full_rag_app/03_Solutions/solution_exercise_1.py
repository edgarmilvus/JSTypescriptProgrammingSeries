
/*
 * These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
 * You can find the series on Amazon.
 * New books info: https://linktr.ee/edgarmilvus
 *
 * MIT License
 * Copyright (c) 2025 Edgar Milvus
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */

// Source File: solution_exercise_1.py
// Description: Solution for Exercise 1
// ==========================================

# Conceptual TypeScript/LangChain.js implementation for a Vercel AI SDK handler

import { ChatPromptTemplate } from '@langchain/core/prompts';
import { RunnablePassthrough, RunnableSequence } from '@langchain/core/runnables';
import { StringOutputParser } from '@langchain/core/output_parsers';
# Assume LLM and Retriever (from Exercise 4) are instantiated

# 1. Prompt for Question Rewriting (Condensing the history)
const CONDENSE_QUESTION_PROMPT = ChatPromptTemplate.fromMessages([
    ["system", "Given the following conversation and a follow-up question, rephrase the follow-up question to be a standalone question, optimized for vector search. If the question is already standalone, return it as is."],
    ["human", "Chat History:\n{chat_history}\n\nFollow Up Input: {input}\n\nStandalone Question:"],
]);

# 2. Prompt for Final RAG Generation
const RAG_PROMPT = ChatPromptTemplate.fromMessages([
    ["system", "You are a helpful RAG assistant. Answer the user's question based ONLY on the provided context and the chat history. Context:\n{context}"],
    ["human", "Chat History:\n{chat_history}\n\nQuestion: {input}"],
]);

# 3. The Question Rewriting Chain (Standalone Question Generator)
const condenseChain = RunnableSequence.from([
    CONDENSE_QUESTION_PROMPT,
    llm, # A fast LLM (e.g., gpt-3.5-turbo)
    new StringOutputParser(),
]);

# 4. Retrieval Step (using the output of the condense chain)
const retrievalChain = RunnableSequence.from([
    {
        # Use the condensed question for retrieval
        standalone_question: condenseChain,
        # Pass through the original input and history for the final prompt
        original_input: ({ input }) => input, 
        chat_history: ({ chat_history }) => chat_history,
    },
    {
        # Retrieve documents based on the standalone question
        context: ({ standalone_question }) => retriever.invoke(standalone_question).then(docs => docs.map(d => d.pageContent).join("\n\n")),
        input: ({ original_input }) => original_input,
        chat_history: ({ chat_history }) => chat_history,
    },
]);

# 5. The Full Conversational RAG Chain
const fullRAGChain = RunnableSequence.from([
    retrievalChain,
    RAG_PROMPT,
    llm, # A powerful LLM (e.g., gpt-4)
    new StringOutputParser(),
]);

# Example invocation structure:
# const resultStream = await fullRAGChain.stream({
#     input: "What are the benefits of LCEL?",
#     chat_history: "Human: What is RAG? AI: RAG is Retrieval-Augmented Generation.",
# });
