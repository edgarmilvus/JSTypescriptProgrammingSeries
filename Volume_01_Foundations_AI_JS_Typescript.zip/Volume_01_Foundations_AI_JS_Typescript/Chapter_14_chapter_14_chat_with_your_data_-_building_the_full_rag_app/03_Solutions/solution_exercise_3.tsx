
/*
 * These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
 * You can find the series on Amazon.
 * New books info: https://linktr.ee/edgarmilvus
 *
 * MIT License
 * Copyright (c) 2025 Edgar Milvus
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */

// Source File: solution_exercise_3.tsx
// Description: Solution for Exercise 3
// ==========================================

// Server-Side Modification (Conceptual LangChain.js/Vercel AI SDK Handler)
import { RunnablePassthrough } from '@langchain/core/runnables';
# Assume the retriever returns documents with metadata (source_url, title)

// Function to extract and format metadata for streaming
const formatSources = (docs) => {
    return docs.map(doc => ({
        doc_id: doc.metadata.doc_id,
        source_url: doc.metadata.source_url,
        title: doc.metadata.title,
    }));
};

// The modified retrieval chain now also outputs 'sources'
const retrievalChainWithSources = RunnableSequence.from([
    {
        # ... steps to get context and original inputs ...
        context: ({ standalone_question }) => retriever.invoke(standalone_question),
        # Pass through the raw documents for source extraction
        raw_docs: ({ standalone_question }) => retriever.invoke(standalone_question),
        input: ({ original_input }) => original_input,
        chat_history: ({ chat_history }) => chat_history,
    },
    {
        # Extract and format sources before generation
        sources: ({ raw_docs }) => formatSources(raw_docs),
        context: ({ raw_docs }) => raw_docs.map(d => d.pageContent).join("\n\n"),
        input: ({ input }) => input,
        chat_history: ({ chat_history }) => chat_history,
    },
    # Final step uses Vercel AI SDK's streaming mechanism (e.g., streamToolCall)
    # The 'sources' object is emitted as a structured tool call or UI state update 
    # BEFORE the LLM response starts streaming.
    // ... generation and streaming logic ...
]);


// Client-Side Component (React/TypeScript)
'use client';
import React, { useState, useEffect } from 'react';

interface Source {
    doc_id: string;
    source_url: string;
    title: string;
}

// Assume the Vercel AI SDK provides a mechanism to capture structured data (e.g., tool calls)
// For simplicity, we assume a prop 'streamingSources' which updates as data arrives.
export function SourceCitationPanel({ streamingSources }: { streamingSources: Source[] }) {
    const [uniqueSources, setUniqueSources] = useState<Source[]>([]);

    useEffect(() => {
        // 1. Update state when new sources arrive from the stream
        const newUniqueSources = streamingSources.filter(
            (newSrc, index, self) => 
                index === self.findIndex((t) => t.doc_id === newSrc.doc_id)
        );
        setUniqueSources(newUniqueSources);
    }, [streamingSources]);

    const handleCitationClick = (source: Source) => {
        console.log(`Citation clicked: ${source.title}. Triggering UI highlight...`);
        // 4. Interactive Display Logic: Example event trigger
        // dispatch(highlightText(source.doc_id)); 
    };

    if (uniqueSources.length === 0) {
        return null;
    }

    return (
        <div className="source-panel bg-gray-50 p-3 rounded-lg mt-4 border border-gray-200">
            <h4 className="font-semibold text-sm mb-2">Sources Used:</h4>
            <div className="flex flex-wrap gap-2">
                {uniqueSources.map((source) => (
                    <button
                        key={source.doc_id}
                        onClick={() => handleCitationClick(source)}
                        className="text-xs bg-blue-100 text-blue-800 px-3 py-1 rounded-full hover:bg-blue-200 transition"
                        title={source.source_url}
                    >
                        {source.title.substring(0, 30)}...
                    </button>
                ))}
            </div>
        </div>
    );
}
