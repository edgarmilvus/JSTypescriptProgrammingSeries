
/*
 * These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
 * You can find the series on Amazon.
 * New books info: https://linktr.ee/edgarmilvus
 *
 * MIT License
 * Copyright (c) 2025 Edgar Milvus
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */

// Source File: solution_exercise_4.py
// Description: Solution for Exercise 4
// ==========================================

// Conceptual TypeScript/LangChain.js implementation
import { SupabaseVectorStore } from '@langchain/community/vectorstores/supabase';
import { OpenAIEmbeddings } from '@langchain/openai';
import { createClient, SupabaseClient } from '@supabase/supabase-js';
import { Retriever } from '@langchain/core/retrievers';

// Define the signature for the initialization function
type MetadataFilter = {
    document_type?: string;
    [key: string]: any; // Allow for other filters
};

/**
 * Initializes the Supabase client, vector store, and configures a retriever 
 * with optional metadata filtering.
 */
function initializeSupabaseRetriever(
    tableName: string = 'documents', 
    filter?: MetadataFilter
): Retriever {
    // 1. Initialize Supabase Client using environment variables.
    const supabaseClient: SupabaseClient = createClient(
        process.env.SUPABASE_URL!,
        process.env.SUPABASE_SERVICE_ROLE_KEY!, // Use service key for server-side access
    );

    // 2. Initialize the Embeddings model instance.
    // Must match the model used during ingestion (e.g., text-embedding-ada-002)
    const embeddings = new OpenAIEmbeddings({ 
        modelName: "text-embedding-3-small" 
    });

    // 3. Instantiate the SupabaseVectorStore.
    const vectorStore = new SupabaseVectorStore(embeddings, {
        client: supabaseClient,
        tableName: tableName,
        queryName: 'match_documents', // Custom function for similarity search
        // Configuration for the columns used by pgvector
        // contentColumn: 'page_content',
        // embeddingColumn: 'embedding',
    });

    // 4. Configure the Retriever from the Vector Store, applying necessary parameters 
    //    for k (number of documents) and the optional filter.
    const retriever = vectorStore.asRetriever({
        k: 5, // Retrieve top 5 documents
        filter: filter, // Pass the filter object directly to the underlying query
    });

    return retriever;
}

// Example usage:
// const apiRetriever = initializeSupabaseRetriever('docs_chunks', { document_type: 'API_REFERENCE' });
