
/*
 * These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
 * You can find the series on Amazon.
 * New books info: https://linktr.ee/edgarmilvus
 *
 * MIT License
 * Copyright (c) 2025 Edgar Milvus
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */

// Source File: solution_exercise_5.py
// Description: Solution for Exercise 5
// ==========================================

// Conceptual TypeScript/Vercel AI SDK implementation

// Example types based on Vercel AI SDK structure
type Message = { 
    role: 'user' | 'assistant' | 'system'; 
    content: string; 
    metadata?: any; // Structured data field
};
type AIState = { 
    messages: Message[]; 
};
type SourceMetadata = Array<{ doc_id: string, url: string, score: number }>;

/**
 * Updates the server-side AI state after a successful RAG generation cycle.
 * @param currentAIState The state before the current turn.
 * @param userMessage The raw text input from the user.
 * @param llmResponse The final text output from the LLM.
 * @param metadata Structured data retrieved during the RAG step (sources).
 * @returns The updated AIState.
 */
function updateAIStateAfterGeneration(
    currentAIState: AIState,
    userMessage: string,
    llmResponse: string,
    metadata: SourceMetadata[]
): AIState {
    // 1. Define the new user message object.
    const newUserMessage: Message = {
        role: 'user',
        content: userMessage,
    };

    // 2. Define the new assistant message object.
    const newAssistantMessage: Message = {
        role: 'assistant',
        content: llmResponse,
        // 3. Serialize and attach metadata here.
        // We attach the structured sources under the metadata field.
        metadata: {
            sources: metadata,
            timestamp: new Date().toISOString(),
        },
    };

    // 4. Return the new AIState object with the appended messages.
    return {
        messages: [
            ...currentAIState.messages,
            newUserMessage,
            newAssistantMessage,
        ],
    };
}

// Example Usage:
/*
const initial = { messages: [{ role: 'system', content: 'You are RAG bot.' }] };
const sources = [{ doc_id: '123', url: 'doc.com/a', score: 0.8 }];
const updatedState = updateAIStateAfterGeneration(
    initial,
    "Tell me about RAG.",
    "RAG stands for Retrieval-Augmented Generation...",
    sources
);
// updatedState.messages[2] will contain the assistant response AND the metadata object.
*/
