# These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
# You can find the series on Amazon.
# New books info: https://linktr.ee/edgarmilvus
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_solutions_and_explanations_part2.py
# Description: Solutions and Explanations
# ==========================================

# app/lib/supabase.ts (Server-side Supabase Client Setup)
import { createClient } from '@supabase/supabase-js';

# Ensure these are accessed securely in the server environment
const SUPABASE_URL = process.env.NEXT_PUBLIC_SUPABASE_URL!;
const SUPABASE_SERVICE_ROLE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY!;

# Initialize Supabase client for Server Components (using service key for full access)
export const supabaseServer = createClient(
    SUPABASE_URL,
    SUPABASE_SERVICE_ROLE_KEY,
);

# app/lib/data.ts (Data Fetching Function)
interface Persona {
    id: string;
    name: string;
    system_prompt: string;
}

async function fetchSystemPersona(personaId: string): Promise<string> {
    const { data, error } = await supabaseServer
        .from('system_config')
        .select('system_prompt')
        .eq('id', personaId)
        .single();

    if (error || !data) {
        console.error("Failed to fetch persona:", error);
        return "You are a helpful assistant."; // Fallback prompt
    }
    return data.system_prompt;
}

# app/chat/[id]/page.tsx (Next.js Server Component)
import ChatClientComponent from './client'; // Client-side component
# ... imports for fetchSystemPersona

export default async function ChatPage({ params }: { params: { id: string } }) {
    # 1. Asynchronously fetch the system context on the server
    const personaId = 'rag_expert'; 
    const initialSystemPrompt = await fetchSystemPersona(personaId);

    # 2. Pass the fetched data as a prop to the Client Component
    return (
        <main>
            <h1>Chat Interface: {params.id}</h1>
            <ChatClientComponent initialSystemPrompt={initialSystemPrompt} />
        </main>
    );
}

# app/chat/[id]/client.tsx (Client Component Initialization)
'use client';
import { useChat, AIState } from 'ai/react'; // Vercel AI SDK

export default function ChatClientComponent({ initialSystemPrompt }: { initialSystemPrompt: string }) {
    # 3. Use the prop to initialize the AIState or the system message
    const { messages, input, handleInputChange, handleSubmit } = useChat({
        # The SDK uses this initial state to prime the conversation history
        initialMessages: [{ role: 'system', content: initialSystemPrompt }],
        # ... other configurations
    });

    # ... rendering logic
}
