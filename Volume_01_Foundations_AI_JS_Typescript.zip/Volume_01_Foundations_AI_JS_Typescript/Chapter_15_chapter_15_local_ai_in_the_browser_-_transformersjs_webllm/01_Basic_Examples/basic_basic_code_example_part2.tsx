/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2025 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.tsx
// Description: Basic Code Example
// ==========================================

// SentimentAnalyzer.tsx
/**
 * @file SentimentAnalyzer.tsx
 * @description A Next.js Client Component demonstrating basic client-side inference
 * using the @xenova/transformers library for real-time sentiment analysis.
 *
 * CRITICAL: The 'use client' directive is mandatory for utilizing browser APIs
 * and React hooks like useState/useEffect necessary for managing the asynchronous
 * model loading process.
 */
'use client';

import React, { useState, useCallback, useEffect } from 'react';

// -----------------------------------------------------------------------------
// 1. Component Definition and State Initialization
// -----------------------------------------------------------------------------

/**
 * Defines the structure of the output returned by the sentiment analysis pipeline.
 * @typedef {Array<{label: string, score: number}>} SentimentOutput
 */

/**
 * Component for performing client-side sentiment analysis using Transformers.js.
 * @returns {JSX.Element}
 */
export default function SentimentAnalyzer(): JSX.Element {
  
  // State for user interaction and feedback
  const [textInput, setTextInput] = useState<string>("This local AI integration is incredibly fast and eliminates server latency.");
  const [result, setResult] = useState<string | null>(null);
  const [loading, setLoading] = useState<boolean>(false);
  
  // State to hold the initialized AI pipeline function
  // We use 'any' here because the imported pipeline function has a complex, dynamic signature.
  const [pipeline, setPipeline] = useState<any>(null); 

  // Model Configuration Constants
  const MODEL_NAME: string = 'Xenova/distilbert-base-uncased-finetuned-sst-2-english';
  const TASK_NAME: string = 'sentiment-analysis';

  // -----------------------------------------------------------------------------
  // 2. Model Initialization (The Core Setup)
  // -----------------------------------------------------------------------------

  /**
   * Initializes the Transformers.js pipeline using React's useEffect hook.
   * This logic is isolated to run only once after the component mounts in the browser.
   */
  useEffect(() => {
    
    /**
     * Dynamically loads the necessary pipeline function and model weights.
     * This function is designed to be idempotent (safe to run multiple times, though useEffect limits it).
     * @async
     */
    const initializePipeline = async () => {
      // Prevent re-initialization if the pipeline is already set
      if (pipeline) return;
      
      try {
        setLoading(true);
        
        // CRITICAL STEP: Dynamic import ensures the library is only executed client-side.
        // If we used a static import (e.g., `import { pipeline } from '@xenova/transformers';`)
        // Next.js might attempt to bundle or execute it during SSR, leading to errors.
        const { pipeline: pipelineFactory } = await import('@xenova/transformers');
        
        // Initialize the specific task pipeline. This triggers:
        // 1. Downloading the model weights (quantized for smaller size) from the Hugging Face CDN.
        // 2. Compiling the ONNX model graph into WebAssembly.
        const sentimentPipeline = await pipelineFactory(TASK_NAME, MODEL_NAME, {
          quantized: true, // Use smaller, quantized weights for faster download and inference
          cache_dir: 'transformers-js-cache' // Custom cache directory for IndexedDB storage
        });
        
        setPipeline(() => sentimentPipeline); // Store the ready-to-use function
        console.log(`[Transformers.js] Pipeline for ${TASK_NAME} initialized.`);
        
      } catch (error) {
        console.error('[Transformers.js] Failed to initialize pipeline:', error);
        setResult('Error: Failed to load AI model. Check browser console and compatibility.');
      } finally {
        setLoading(false);
      }
    };

    // Ensure initialization runs only if we are in the browser environment
    if (typeof window !== 'undefined') {
      initializePipeline();
    }
  }, []); // Empty dependency array ensures this runs only on initial mount

  // -----------------------------------------------------------------------------
  // 3. Inference Handler (The Execution)
  // -----------------------------------------------------------------------------

  /**
   * Executes the sentiment analysis inference locally using the initialized pipeline.
   * Uses useCallback for performance optimization.
   * @async
   */
  const analyzeSentiment = useCallback(async () => {
    if (!pipeline || loading) {
      setResult('Model is not yet ready. Please wait.');
      return;
    }

    setLoading(true);
    setResult(null);

    try {
      console.log(`[Inference] Starting client-side analysis...`);
      
      // The core inference call. This computation happens entirely within the user's browser.
      /** @type {SentimentOutput} */
      const output = await pipeline(textInput);

      if (output && output.length > 0) {
        const { label, score } = output[0];
        const formattedScore = (score * 100).toFixed(2);
        
        // Update the UI with the result
        setResult(`${label} (Confidence: ${formattedScore}%)`);
      } else {
        setResult('Analysis returned an unexpected empty result.');
      }

    } catch (error) {
      console.error('[Inference] Execution error:', error);
      setResult('An error occurred during local inference. Check console.');
    } finally {
      setLoading(false);
    }
  }, [pipeline, textInput, loading]); // Dependencies ensure fresh state is used

  // -----------------------------------------------------------------------------
  // 4. Render Logic
  // -----------------------------------------------------------------------------
  
  const isReady = !!pipeline && !loading;

  return (
    <div style={{ padding: '30px', maxWidth: '700px', margin: '30px auto', border: '2px solid #0070f3', borderRadius: '12px', boxShadow: '0 4px 12px rgba(0,0,0,0.1)' }}>
      <h1 style={{ borderBottom: '1px solid #eee', paddingBottom: '10px' }}>Local AI: Sentiment Analysis</h1>
      <p style={{ color: '#555' }}>
        Task: {TASK_NAME} | Model: <code>{MODEL_NAME.split('/').pop()}</code>
      </p>
      
      <textarea
        value={textInput}
        onChange={(e) => setTextInput(e.target.value)}
        rows={5}
        placeholder="Enter text for client-side sentiment analysis..."
        style={{ 
          width: '100%', 
          padding: '12px', 
          marginBottom: '20px', 
          fontSize: '16px',
          borderRadius: '6px',
          border: '1px solid #ccc'
        }}
        disabled={!isReady && !pipeline}
      />
      
      <button 
        onClick={analyzeSentiment}
        disabled={!isReady || textInput.trim().length === 0}
        style={{ 
          padding: '12px 25px', 
          fontSize: '18px',
          backgroundColor: isReady ? '#0070f3' : '#999', 
          color: 'white', 
          border: 'none', 
          borderRadius: '6px', 
          cursor: isReady ? 'pointer' : 'not-allowed',
          transition: 'background-color 0.3s'
        }}
      >
        {loading ? 'Processing Inference...' : pipeline ? 'Analyze Sentiment (Local)' : 'Initializing Model Weights...'}
      </button>

      {result && (
        <div style={{ 
          marginTop: '30px', 
          padding: '20px', 
          backgroundColor: result.includes('POSITIVE') ? '#e6ffe6' : (result.includes('NEGATIVE') ? '#ffe6e6' : '#f0f8ff'), 
          borderLeft: `6px solid ${result.includes('POSITIVE') ? '#00cc00' : (result.includes('NEGATIVE') ? '#cc0000' : '#0070f3')}`,
          borderRadius: '6px'
        }}>
          <h3>Analysis Result (Client-Side):</h3>
          <p style={{ fontWeight: 'bold', fontSize: '18px', margin: '0' }}>{result}</p>
        </div>
      )}
      
      {!pipeline && !loading && (
        <p style={{ marginTop: '15px', color: '#cc0000' }}>
          Error or Initialization Pending. Ensure the component is mounted in the browser.
        </p>
      )}
    </div>
  );
}
