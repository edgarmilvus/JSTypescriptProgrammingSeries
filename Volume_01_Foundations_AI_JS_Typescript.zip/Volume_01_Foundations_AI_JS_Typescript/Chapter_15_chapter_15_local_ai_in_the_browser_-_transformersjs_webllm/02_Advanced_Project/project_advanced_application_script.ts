/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2025 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

import { pipeline, env, Pipeline } from '@xenova/transformers';

// 1. Model and Environment Configuration
// The environment object controls backend selection and model loading behavior.
// We prioritize hardware acceleration (WebGPU) and WASM execution over pure CPU.
env.backends.cpu = false;
env.backends.wasm = true;
env.backends.webgpu = true;
// Disallow local file system access for security and consistent caching behavior.
env.allowLocalModels = false;

// Define specific models for their respective tasks.
const SENTIMENT_MODEL = 'Xenova/distilbert-base-uncased-finetuned-sst-2-english';
const ZERO_SHOT_MODEL = 'Xenova/bart-large-mnli';

/**
 * @class FeedbackAnalyzer
 * @description Manages the initialization and execution of client-side ML pipelines 
 * using the Singleton pattern to ensure efficient Cold Start management.
 */
class FeedbackAnalyzer {
    private static instance: FeedbackAnalyzer;
    private sentimentPipeline: Pipeline | null = null;
    private zeroShotPipeline: Pipeline | null = null;
    public isReady: boolean = false;

    /** Private constructor enforces the Singleton pattern. */
    private constructor() {}

    /**
     * @static
     * @returns {FeedbackAnalyzer} The single instance of the analyzer.
     */
    public static getInstance(): FeedbackAnalyzer {
        if (!FeedbackAnalyzer.instance) {
            FeedbackAnalyzer.instance = new FeedbackAnalyzer();
        }
        return FeedbackAnalyzer.instance;
    }

    /**
     * @method initializePipeline
     * @description Handles the initial model loading and compilation (the Cold Start phase).
     * This is the most critical asynchronous step for client-side inference.
     * @returns {Promise<boolean>} Resolves true if both pipelines are successfully loaded.
     */
    public async initializePipeline(): Promise<boolean> {
        if (this.isReady) return true;

        console.log("Starting client-side model initialization (Handling Cold Start)...");
        try {
            // 2. Initialize Sentiment Classification Pipeline (Lightweight BERT variant)
            this.sentimentPipeline = await pipeline(
                'sentiment-analysis',
                SENTIMENT_MODEL,
                {
                    // Use quantized weights for reduced download size and faster loading.
                    quantized: true,
                    // Provide a progress callback to update the user during the Cold Start delay.
                    progress_callback: (details) => {
                        console.log(`[Sentiment Model] Loading progress: ${Math.round(details.progress)}%`);
                    }
                }
            );

            // 3. Initialize Zero-Shot Classification Pipeline (BART-Large for flexibility)
            this.zeroShotPipeline = await pipeline(
                'zero-shot-classification',
                ZERO_SHOT_MODEL,
                { quantized: true }
            );

            this.isReady = true;
            console.log("Client-side inference pipelines initialized successfully.");
            return true;

        } catch (error) {
            console.error("Failed to initialize client-side AI. Falling back to server-side API.", error);
            // Crucial: If WebGPU/WASM fails (e.g., old browser), the application must gracefully degrade.
            this.isReady = false;
            return false;
        }
    }

    /**
     * @method analyzeFeedback
     * @description Executes both local models against the input text.
     * @param {string} text The user feedback string to analyze.
     * @returns {Promise<{sentiment: string, score: number, topics: string[]}>} Analysis results.
     */
    public async analyzeFeedback(text: string): Promise<any> {
        if (!this.isReady || !this.sentimentPipeline || !this.zeroShotPipeline) {
            throw new Error("Analyzer not initialized. Initialization must complete first.");
        }

        console.time("Local Inference Time");

        // 4. Sentiment Analysis Execution (Fast, immediate result)
        const sentimentResult = await this.sentimentPipeline(text);
        const primarySentiment = sentimentResult[0].label;
        const sentimentScore = sentimentResult[0].score;

        // 5. Zero-Shot Classification Execution (Flexible Topic Detection)
        const candidateLabels = ['performance', 'user interface', 'billing', 'feature request', 'bug report', 'support experience'];
        const zeroShotResult = await this.zeroShotPipeline(
            text,
            candidateLabels,
            // Multi-label allows the feedback to cover multiple topics simultaneously.
            { multi_label: true }
        );

        // 6. Post-processing and Filtering
        // Only consider topics with a high confidence score (> 60%).
        const relevantTopics = zeroShotResult.labels.filter(
            (_: string, index: number) => zeroShotResult.scores[index] > 0.60
        );

        console.timeEnd("Local Inference Time");

        return {
            sentiment: primarySentiment,
            score: sentimentScore,
            topics: relevantTopics,
            rawInput: text
        };
    }
}

// --- Example Frontend Integration Logic ---

async function submitFeedback(feedbackText: string) {
    const analyzer = FeedbackAnalyzer.getInstance();

    // Ensure the model is loaded or initiate the Cold Start sequence.
    if (!analyzer.isReady) {
        const success = await analyzer.initializePipeline();
        if (!success) {
            // Graceful degradation: Send raw text to the server for cloud processing.
            console.warn("Local AI unavailable. Submitting raw feedback to server API.");
            return;
        }
    }

    try {
        const results = await analyzer.analyzeFeedback(feedbackText);

        console.log("\n--- Client-Side Analysis Results ---");
        console.log(`Input: "${results.rawInput}"`);
        console.log(`Primary Sentiment: ${results.sentiment} (Confidence: ${results.score.toFixed(2)})`);
        console.log(`Categorized Topics: ${results.topics.length > 0 ? results.topics.join(', ') : 'None detected'}`);

        // The core benefit: We only send anonymized, pre-processed metrics to the server,
        // preserving user privacy by keeping the raw text local.
        // Server API Call Example:
        // sendAnonymizedMetrics({ sentiment: results.sentiment, topics: results.topics });

    } catch (e) {
        console.error("Local analysis runtime error:", e);
    }
}

// simulate user interaction after the page loads
// submitFeedback("The new billing system is much clearer, but the UI still feels slow.");
