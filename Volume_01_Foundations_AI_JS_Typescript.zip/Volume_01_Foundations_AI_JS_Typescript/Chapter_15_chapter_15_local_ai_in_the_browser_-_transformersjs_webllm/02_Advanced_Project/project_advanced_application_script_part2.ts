/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2025 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script_part2.ts
// Description: Advanced Application Script
// ==========================================

rankdir=TB;
node [shape=box, style="filled", fillcolor="#E6F0FF"];

subgraph cluster_cold_start {
    label = "Phase 1: Cold Start (Initial Delay)";
    style = "rounded, filled";
    fillcolor = "#FFF5E6";
    
    A [label="1. App Init/Analyzer.getInstance()", fillcolor="#FFFFFF"];
    B [label="2. initializePipeline() Called", fillcolor="#FFFFFF"];
    C [label="3. Download Model Weights (Quantized)", fillcolor="#FFDDBB"];
    D [label="4. WASM/WebGPU Shader Compilation", fillcolor="#FFC899"];
    E [label="5. Pipelines Ready (isReady = true)", fillcolor="#BBE6BB"];
    
    A -> B [label="First Request"];
    B -> C [label="Network I/O"];
    C -> D [label="CPU/GPU intensive"];
    D -> E [label="Model Loaded"];
}

subgraph cluster_inference {
    label = "Phase 2: High-Speed Client-Side Inference";
    style = "rounded, filled";
    fillcolor = "#E6F0FF";
    
    F [label="6. analyzeFeedback(text)", fillcolor="#FFFFFF"];
    G [label="7. Sentiment Pipeline Execution", fillcolor="#CCCCFF"];
    H [label="8. Zero-Shot Pipeline Execution", fillcolor="#CCCCFF"];
    I [label="9. Post-Processing/Filtering", fillcolor="#FFFFFF"];
    J [label="10. Send Anonymized Metrics to Server", fillcolor="#BBE6BB"];
    
    E -> F [label="Subsequent Requests (Fast)"];
    F -> G [label="Local Inference (ms)"];
    F -> H [label="Local Inference (ms)"];
    G -> I;
    H -> I;
    I -> J [label="Privacy Preserving"];
}

{rank = same; E; J;}
