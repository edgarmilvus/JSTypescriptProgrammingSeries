
/*
 * These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
 * You can find the series on Amazon.
 * New books info: https://linktr.ee/edgarmilvus
 *
 * MIT License
 * Copyright (c) 2025 Edgar Milvus
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */

// Source File: solution_exercise_3.js
// Description: Solution for Exercise 3
// ==========================================

// 2. Cache Identification
const CACHE_NAME = 'ai-model-cache-v1';

// 3. Asset URL Identification (URLs for Xenova/all-MiniLM-L6-v2 assets on Hugging Face CDN)
const MODEL_BASE_URL = 'https://huggingface.co/Xenova/all-MiniLM-L6-v2/resolve/main/';
const ASSETS_TO_CACHE = [
    MODEL_BASE_URL + 'model.onnx',
    MODEL_BASE_URL + 'config.json',
    MODEL_BASE_URL + 'tokenizer.json',
    // Note: In a real scenario, we might also cache the quantized model if used.
];

// 4. Installation Phase (Pre-caching)
self.addEventListener('install', (event) => {
    console.log('[SW] Install: Pre-caching critical model assets.');
    event.waitUntil(
        caches.open(CACHE_NAME)
            .then((cache) => {
                return cache.addAll(ASSETS_TO_CACHE);
            })
            .then(() => self.skipWaiting())
    );
});

// Cleanup old caches upon activation
self.addEventListener('activate', (event) => {
    event.waitUntil(
        caches.keys().then((cacheNames) => {
            return Promise.all(
                cacheNames.map((cacheName) => {
                    if (cacheName !== CACHE_NAME) {
                        return caches.delete(cacheName);
                    }
                })
            );
        })
    );
});


// 5. Fetch Interception (Cache-First Strategy)
self.addEventListener('fetch', (event) => {
    const url = event.request.url;

    // Check if the request is for one of our targeted AI assets
    const isModelAsset = ASSETS_TO_CACHE.some(assetUrl => url.includes(assetUrl));
    
    if (isModelAsset) {
        event.respondWith(
            caches.match(event.request)
                .then((response) => {
                    // Cache Hit: Serve immediately
                    if (response) {
                        console.log(`[SW] Cache Hit: Serving ${url}`);
                        return response;
                    }

                    // Cache Miss: Fetch from network
                    return fetch(event.request).then((networkResponse) => {
                        // Check for valid response before caching
                        if (!networkResponse || networkResponse.status !== 200) {
                            return networkResponse;
                        }

                        // Clone the response stream for caching
                        const responseToCache = networkResponse.clone();

                        caches.open(CACHE_NAME).then((cache) => {
                            cache.put(event.request, responseToCache);
                            console.log(`[SW] Network Fetch: Cached ${url}`);
                        });

                        return networkResponse;
                    });
                })
        );
    }
});
