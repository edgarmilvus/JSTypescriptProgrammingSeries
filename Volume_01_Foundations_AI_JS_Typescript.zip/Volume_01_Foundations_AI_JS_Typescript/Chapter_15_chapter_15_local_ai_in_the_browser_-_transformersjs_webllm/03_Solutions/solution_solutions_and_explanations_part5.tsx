/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2025 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState, useEffect, useMemo } from 'react';
import { pipeline } from '@xenova/transformers'; 
// Note: Requires transformers.js to be installed via npm or imported via CDN in the setup.

// --- 6. Data Flow Visualization (Mermaid Source) ---
/*
graph TD
    A[Parent Component Props: textToEmbed] --> B(LocalEmbedder Component);
    B --> C{useEffect: textToEmbed Change?};
    C -- Yes --> D(Set isLoading: true);
    D --> E(Call embedderPipeline);
    E --> F[Local Execution Engine (WebGPU/WASM)];
    F -- Tensor Result --> G(Process Tensor to Array);
    G --> H(Set embedding State);
    H --> I(Set isLoading: false);
    I --> J[Render Output: Dimensionality & Vector Slice];
*/
// ---------------------------------------------------


// 1. Component Definition
const LocalEmbedder = ({ textToEmbed }) => {
    // 2. State Management
    const [isLoading, setIsLoading] = useState(true);
    const [embedding, setEmbedding] = useState(null);
    const [error, setError] = useState(null);
    
    // State to hold the initialized pipeline instance
    const [embedderPipeline, setEmbedderPipeline] = useState(null);
    
    // 3. Model Integration: Initialize pipeline once
    useEffect(() => {
        const initializePipeline = async () => {
            setError(null);
            try {
                // Use a small, suitable sentence transformer model
                const p = await pipeline('feature-extraction', 'Xenova/all-MiniLM-L6-v2');
                setEmbedderPipeline(p);
                setIsLoading(false); // Initial model loading complete
            } catch (e) {
                setError(`Failed to load model: ${e.message}`);
                setIsLoading(false);
            }
        };
        initializePipeline();
    }, []); // Runs only on component mount

    // 4. Inference Trigger: Reruns whenever text input or pipeline changes
    useEffect(() => {
        if (!embedderPipeline || !textToEmbed) {
            if (embedderPipeline) setIsLoading(false); 
            return;
        }

        const generateEmbedding = async () => {
            setIsLoading(true);
            setError(null);
            setEmbedding(null);

            try {
                // Execute the embedding pipeline
                const output = await embedderPipeline(textToEmbed, {
                    pooling: 'mean',
                    normalize: true, // Standard practice for sentence embeddings
                });

                // Convert the resulting Tensor data into a standard JS array
                // output.data contains the flat array of floats
                const vectorArray = output.data; 
                
                setEmbedding(vectorArray);

            } catch (e) {
                setError(`Inference failed: ${e.message}`);
            } finally {
                setIsLoading(false);
            }
        };

        generateEmbedding();
    }, [textToEmbed, embedderPipeline]); 

    // 5. Rendering Output
    if (error) {
        return <div style={{ color: 'red', border: '1px solid red', padding: '10px' }}>Error: {error}</div>;
    }

    if (isLoading) {
        return <div style={{ color: 'blue', padding: '10px' }}>Loading Model or Generating Embedding...</div>;
    }

    if (embedding) {
        const dimensionality = embedding.length;
        // Display the first 5 elements, formatted to 4 decimal places
        const firstFive = Array.from(embedding.slice(0, 5)).map(n => n.toFixed(4));

        return (
            <div style={{ border: '1px solid #ccc', padding: '15px' }}>
                <h4>Embedding Result (Vector)</h4>
                <p><strong>Input Text:</strong> "{textToEmbed}"</p>
                <p><strong>Dimensionality:</strong> {dimensionality} (768 for MiniLM)</p>
                <p><strong>First 5 Elements:</strong> <code>[{firstFive.join(', ')}...]</code></p>
            </div>
        );
    }
    
    return <div style={{ padding: '10px' }}>Waiting for input...</div>;
};

// Example Usage Component (for context)
/*
const App = () => {
    const [text, setText] = useState("AI models run locally now.");
    return (
        <div>
            <LocalEmbedder textToEmbed={text} />
            <button onClick={() => setText("New input test")}>Change Text</button>
        </div>
    );
};
*/
