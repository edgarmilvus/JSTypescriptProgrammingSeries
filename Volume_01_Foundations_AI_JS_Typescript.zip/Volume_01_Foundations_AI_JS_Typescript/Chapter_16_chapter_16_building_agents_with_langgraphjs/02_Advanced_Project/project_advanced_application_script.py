# These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
# You can find the series on Amazon.
# New books info: https://linktr.ee/edgarmilvus
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: project_advanced_application_script.py
# Description: Advanced Application Script
# ==========================================

import operator
from typing import TypedDict, Annotated, List
from langgraph.graph import StateGraph, END
from langchain_core.messages import BaseMessage, HumanMessage

# --- 1. Define the Graph State ---
# This mirrors the conceptual AgentState in a TypeScript application, 
# holding all necessary data across asynchronous steps.
class AgentState(TypedDict):
    """Represents the state of our agent workflow."""
    input_query: str
    messages: Annotated[List[BaseMessage], operator.add]
    stock_ticker: str
    fetched_data: dict
    volatility_index: float
    next_step: str # Used for routing decisions

# --- 2. Define Tools (Simulation) ---

def fetch_stock_data(ticker: str) -> dict:
    """
    Tool 1: Simulates fetching real-time stock data (e.g., from Polygon or Alpha Vantage).
    In a real application, this would involve async network calls.
    """
    print(f"--- TOOL: Fetching data for {ticker} ---")
    if ticker == "TSLA":
        return {"price": 180.50, "volume": 15000000, "52w_high": 300.00, "52w_low": 100.00}
    else:
        return {"price": 50.00, "volume": 500000, "52w_high": 60.00, "52w_low": 40.00}

def calculate_volatility_index(data: dict) -> float:
    """
    Tool 2: Proprietary calculation based on fetched data.
    (Simple example: Normalized range)
    """
    print("--- TOOL: Calculating Volatility Index ---")
    high = data.get("52w_high", 1.0)
    low = data.get("52w_low", 1.0)
    # Volatility is the range relative to the current price
    index = ((high - low) / data.get("price", 1.0)) * 10
    return round(index, 2)

# --- 3. Define Workflow Nodes ---

def call_llm_router(state: AgentState) -> AgentState:
    """
    Node A: Simulates an LLM call used for initial parsing and routing decisions.
    In a real scenario, this LLM would output a structured JSON indicating the next tool to use.
    """
    print("\n--- NODE: LLM Router/Reasoner Activated ---")
    
    # Mock LLM reasoning based on current state
    if not state.get("stock_ticker"):
        # Initial call: Parse the query and extract the ticker
        ticker = state["input_query"].split()[-1].upper().replace("?", "").replace(".", "")
        print(f"LLM extracted ticker: {ticker}. Next step: Fetch Data.")
        return {"stock_ticker": ticker, "next_step": "fetch_data"}
    
    elif state.get("fetched_data") and not state.get("volatility_index"):
        # Data is fetched, need calculation
        print("LLM confirms data fetched. Next step: Calculate Index.")
        return {"next_step": "calculate_index"}
    
    elif state.get("volatility_index"):
        # Calculation complete, ready for final summary
        print(f"LLM confirms index calculated ({state['volatility_index']}). Next step: Final Output.")
        return {"next_step": "final_output"}
        
    return {"next_step": "error"} # Should not happen

def execute_fetch_data(state: AgentState) -> AgentState:
    """
    Node B: Executes the fetch_stock_data tool.
    """
    ticker = state["stock_ticker"]
    data = fetch_stock_data(ticker)
    # Update state with the result
    return {"fetched_data": data, 
            "messages": [HumanMessage(content=f"Tool Output: Stock data fetched successfully.")]}

def execute_calculation(state: AgentState) -> AgentState:
    """
    Node C: Executes the calculate_volatility_index tool.
    """
    index = calculate_volatility_index(state["fetched_data"])
    # Update state with the result
    return {"volatility_index": index,
            "messages": [HumanMessage(content=f"Tool Output: Volatility Index calculated.")]}

def final_output_node(state: AgentState) -> AgentState:
    """
    Node D: Formats the final, user-facing response.
    """
    print("\n--- NODE: Final Output Generation ---")
    index = state["volatility_index"]
    data = state["fetched_data"]
    
    summary = (f"Analysis for {state['stock_ticker']}:\n"
               f"Current Price: ${data['price']:.2f}. "
               f"52W Range: ${data['52w_low']:.2f} to ${data['52w_high']:.2f}.\n"
               f"Proprietary Volatility Index: {index:.2f}."
               f"\n{'WARNING: High Volatility Detected!' if index > 15.0 else 'Conclusion: Stable performance.'}")
               
    print(summary)
    # In a real app, this would trigger an update to the UIState stream.
    return {"messages": [HumanMessage(content=summary)]}

# --- 4. Define Conditional Routing ---

def route_action(state: AgentState) -> str:
    """
    Conditional Edge: Determines the next node based on the 'next_step' key set by the LLM Router.
    """
    step = state["next_step"]
    if step == "fetch_data":
        return "fetch"
    elif step == "calculate_index":
        return "calculate"
    elif step == "final_output":
        return "output"
    return "error"

# --- 5. Build and Compile the Graph ---

workflow = StateGraph(AgentState)

# Add Nodes
workflow.add_node("router", call_llm_router)
workflow.add_node("fetch", execute_fetch_data)
workflow.add_node("calculate", execute_calculation)
workflow.add_node("output", final_output_node)

# Set Entry Point
workflow.set_entry_point("router")

# Define Edges (Transitions)
# Router decides what happens next based on state
workflow.add_conditional_edges(
    "router",
    route_action,
    {
        "fetch": "fetch",
        "calculate": "calculate",
        "output": "output",
        "error": END # If LLM fails to decide, end the process
    }
)

# Tool execution nodes always return control back to the Router/Reasoner
workflow.add_edge("fetch", "router")
workflow.add_edge("calculate", "router")

# The final output node terminates the graph
workflow.add_edge("output", END)

# Compile the graph
app = workflow.compile()

# --- 6. Execute the Agent ---

print("--- AGENT EXECUTION START ---")
initial_state = {"input_query": "Please analyze the current risk profile for TSLA", 
                 "messages": [HumanMessage(content="Analyze TSLA.")]}

# Note: In a Node.js/TypeScript environment, this execution would be asynchronous 
# and tightly integrated with streaming APIs (like the Vercel AI SDK).
final_state = app.invoke(initial_state)

print("\n--- AGENT EXECUTION COMPLETE ---")
# print(final_state)
