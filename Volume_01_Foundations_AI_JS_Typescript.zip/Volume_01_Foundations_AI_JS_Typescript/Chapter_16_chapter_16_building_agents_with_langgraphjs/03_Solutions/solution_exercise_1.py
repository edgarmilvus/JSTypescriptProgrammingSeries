
/*
 * These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
 * You can find the series on Amazon.
 * New books info: https://linktr.ee/edgarmilvus
 *
 * MIT License
 * Copyright (c) 2025 Edgar Milvus
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */

// Source File: solution_exercise_1.py
// Description: Solution for Exercise 1
// ==========================================

from typing import TypedDict, Annotated, List, Optional
from operator import itemgetter
from langchain_core.messages import BaseMessage, HumanMessage, ToolMessage
from langchain_core.tools import tool
from langgraph.graph import StateGraph, END
from langgraph.prebuilt.tool_executor import ToolExecutor
from langchain_openai import ChatOpenAI

# 1. Define the Graph State (AgentState)
class AgentState(TypedDict):
    """Tracks history, tool requests, output, and loop count."""
    messages: Annotated[List[BaseMessage], itemgetter("messages")]
    tool_calls: Optional[List[dict]]
    tool_output: Optional[str]
    research_iterations: int

# Dummy Tool Definition
@tool
def search_engine(query: str) -> str:
    """Simulates a web search or data retrieval."""
    if "LangGraph" in query:
        return f"Found 5 key features for {query}: State management, Cycles, Conditional Routing, Streaming, and Tool Orchestration."
    return f"Information retrieved for '{query}'. Data is inconclusive."

tools = [search_engine]
# Initialize LLM with tool binding (using a placeholder for API Key safety)
llm = ChatOpenAI(model="gpt-4o", temperature=0).bind_tools(tools)
tool_executor = ToolExecutor(tools)

# 2. Implement Workflow Nodes

def call_model(state: AgentState) -> AgentState:
    """Invokes the LLM, increments iteration, and extracts tool calls."""
    current_iterations = state.get("research_iterations", 0)
    print(f"--- Calling Model (Iteration {current_iterations + 1}) ---")
    
    response = llm.invoke(state["messages"])
    
    new_messages = state["messages"] + [response]
    tool_calls = response.tool_calls if response.tool_calls else None
    
    return {
        "messages": new_messages,
        "tool_calls": tool_calls,
        "research_iterations": current_iterations + 1
    }

def execute_tool(state: AgentState) -> AgentState:
    """Executes requested tools and feeds results back as a ToolMessage."""
    print("--- Executing Tool ---")
    tool_call = state["tool_calls"][0]
    
    tool_input = [{"id": tool_call['id'], "name": tool_call['name'], "args": tool_call['args']}]
    tool_result = tool_executor.invoke(tool_input)
    
    tool_message = ToolMessage(
        content=str(tool_result),
        tool_call_id=tool_call['id']
    )
    
    return {
        "messages": state["messages"] + [tool_message],
        "tool_calls": None, # Clear tool calls after execution
        "tool_output": str(tool_result)
    }

def generate_final_answer(state: AgentState) -> AgentState:
    """Terminal node."""
    print("--- Generating Final Answer ---")
    return state

# 3. Define Conditional Routing (Edges)
def router(state: AgentState) -> str:
    """Routes based on tool requirement or loop limits."""
    if state["research_iterations"] >= 5:
        return "loop_limit_reached"
    
    if state["tool_calls"]:
        return "tool_use"
    else:
        return "finish"

# 4. Build the Graph
workflow = StateGraph(AgentState)
workflow.add_node("call_model", call_model)
workflow.add_node("execute_tool", execute_tool)
workflow.add_node("generate_final_answer", generate_final_answer)

workflow.set_entry_point("call_model")

# Conditional routing from the model decision
workflow.add_conditional_edges(
    "call_model",
    router,
    {
        "tool_use": "execute_tool",
        "finish": "generate_final_answer",
        "loop_limit_reached": END
    }
)

# Cyclical Edge: Tool execution always returns to the model for reflection
workflow.add_edge("execute_tool", "call_model")

# Termination edge
workflow.add_edge("generate_final_answer", END)

# app = workflow.compile()
