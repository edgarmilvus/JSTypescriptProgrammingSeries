
/*
 * These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
 * You can find the series on Amazon.
 * New books info: https://linktr.ee/edgarmilvus
 *
 * MIT License
 * Copyright (c) 2025 Edgar Milvus
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */

// Source File: solution_exercise_2.py
// Description: Solution for Exercise 2
// ==========================================

from typing import TypedDict, Annotated, List, Optional
from operator import itemgetter
from langchain_core.messages import BaseMessage, HumanMessage, ToolMessage
from langchain_core.tools import tool
from langgraph.graph import StateGraph, END
from langgraph.prebuilt.tool_executor import ToolExecutor
from langchain_openai import ChatOpenAI
from pydantic import BaseModel, Field

# 1. Extended Graph State
class ToolResult(TypedDict):
    tool_name: str
    result: any

class FinancialState(TypedDict):
    messages: Annotated[List[BaseMessage], itemgetter("messages")]
    tool_calls: Optional[List[dict]]
    tool_results: Annotated[List[ToolResult], lambda x, y: x + y] # Accumulate results
    # Added field to track initial intent for sequential routing
    initial_route: Optional[str] 

# 2. Tool Definition and Typing
class StockPriceTool(BaseModel):
    ticker: str = Field(description="The stock ticker symbol.")
class CapitalGainsTool(BaseModel):
    purchase_price: float = Field(description="Purchase price per share.")
    sale_price: float = Field(description="Sale price per share.")

@tool(args_schema=StockPriceTool)
def fetch_stock_price(ticker: str) -> str:
    """Fetches stock price."""
    return f"Price data for {ticker.upper()}: $150.00."

@tool(args_schema=CapitalGainsTool)
def calculate_capital_gains(purchase_price: float, sale_price: float) -> str:
    """Calculates capital gains."""
    gain = sale_price - purchase_price
    return f"Calculated gain: ${gain:.2f}."

tools = [fetch_stock_price, calculate_capital_gains]
llm = ChatOpenAI(model="gpt-4o", temperature=0).bind_tools(tools)
tool_executor = ToolExecutor(tools)

# Node Definitions
def call_model_router(state: FinancialState) -> FinancialState:
    """Calls the model to decide tool use and saves the decision."""
    response = llm.invoke(state["messages"])
    tool_calls = response.tool_calls if response.tool_calls else None
    
    # Determine the routing string immediately after LLM call
    tool_names = [tc['name'] for tc in tool_calls or []]
    needs_stock = 'fetch_stock_price' in tool_names
    needs_tax = 'calculate_capital_gains' in tool_names
    
    if needs_stock and needs_tax:
        route = "stock_then_tax"
    elif needs_stock:
        route = "stock_only"
    elif needs_tax:
        route = "tax_only"
    else:
        route = "finish"
        
    return {
        "messages": state["messages"] + [response],
        "tool_calls": tool_calls,
        "initial_route": route
    }

def execute_stock_tool(state: FinancialState) -> FinancialState:
    """Executes stock tool and clears tool_calls."""
    stock_call = next((tc for tc in state["tool_calls"] if tc['name'] == 'fetch_stock_price'), None)
    tool_input = [{"id": stock_call['id'], "name": stock_call['name'], "args": stock_call['args']}]
    result = tool_executor.invoke(tool_input)
    
    new_result = {"tool_name": "fetch_stock_price", "result": result}
    
    return {
        "tool_results": state["tool_results"] + [new_result],
        "tool_calls": None, 
        "messages": state["messages"] + [ToolMessage(content=str(result), tool_call_id=stock_call['id'])]
    }

def execute_tax_tool(state: FinancialState) -> FinancialState:
    """Executes tax tool and clears tool_calls."""
    tax_call = next((tc for tc in state["tool_calls"] if tc['name'] == 'calculate_capital_gains'), None)
    tool_input = [{"id": tax_call['id'], "name": tax_call['name'], "args": tax_call['args']}]
    result = tool_executor.invoke(tool_input)
    
    new_result = {"tool_name": "calculate_capital_gains", "result": result}
    
    return {
        "tool_results": state["tool_results"] + [new_result],
        "tool_calls": None,
        "messages": state["messages"] + [ToolMessage(content=str(result), tool_call_id=tax_call['id'])]
    }

def generate_final_answer_financial(state: FinancialState) -> FinancialState:
    """Terminal node."""
    return state

# 3. Complex Conditional Routing (Primary Router)
def tool_orchestrator(state: FinancialState) -> str:
    """Routes based on the initial intent saved in the state."""
    return state["initial_route"]

# 4. Internal Conditional Edge after Stock Execution
def check_for_tax_followup(state: FinancialState) -> str:
    """Checks the initial intent to see if the tax calculation is required next."""
    if state["initial_route"] == "stock_then_tax":
        # Note: In a real scenario, the model would need to call the tax tool again
        # or we would manually inject the tax tool call into state["tool_calls"] here.
        # For simplicity, we assume the tax tool call is ready in the state 
        # (or the next node handles the invocation).
        return "requires_tax"
    return "done_with_stock"


# Build the Graph
workflow = StateGraph(FinancialState)
workflow.add_node("model_decision", call_model_router)
workflow.add_node("execute_stock_tool", execute_stock_tool)
workflow.add_node("execute_tax_tool", execute_tax_tool)
workflow.add_node("generate_final_answer", generate_final_answer_financial)

workflow.set_entry_point("model_decision")

# Primary Branching from the LLM decision
workflow.add_conditional_edges(
    "model_decision",
    tool_orchestrator,
    {
        "stock_then_tax": "execute_stock_tool",
        "stock_only": "execute_stock_tool",
        "tax_only": "execute_tax_tool",
        "finish": "generate_final_answer"
    }
)

# Sequential flow and completion check after Stock execution
workflow.add_conditional_edges(
    "execute_stock_tool",
    check_for_tax_followup,
    {
        "requires_tax": "execute_tax_tool",
        "done_with_stock": "generate_final_answer"
    }
)

# Termination edges
workflow.add_edge("execute_tax_tool", "generate_final_answer")
workflow.add_edge("generate_final_answer", END)

# app_financial = workflow.compile()
