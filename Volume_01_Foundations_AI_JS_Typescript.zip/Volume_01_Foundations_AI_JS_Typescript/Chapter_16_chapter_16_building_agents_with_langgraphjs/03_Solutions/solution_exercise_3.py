
/*
 * These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
 * You can find the series on Amazon.
 * New books info: https://linktr.ee/edgarmilvus
 *
 * MIT License
 * Copyright (c) 2025 Edgar Milvus
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */

// Source File: solution_exercise_3.py
// Description: Solution for Exercise 3
// ==========================================

from typing import TypedDict, Annotated, List, Optional
from operator import itemgetter
from langchain_core.messages import BaseMessage, HumanMessage, ToolMessage, SystemMessage
from langchain_core.tools import tool
from langgraph.graph import StateGraph, END
from langgraph.prebuilt.tool_executor import ToolExecutor
from langchain_openai import ChatOpenAI
from pydantic import BaseModel, Field, ValidationError

# 1. State Augmentation for Error Handling
class ValidatorState(TypedDict):
    messages: Annotated[List[BaseMessage], itemgetter("messages")]
    tool_calls: Optional[List[dict]]
    error_message: Optional[str] 
    retry_count: int             

# Tool Definition with simulated validation failure
class UserDataInput(BaseModel):
    user_id: str = Field(description="The user identifier, must be a 6-digit number string.")

@tool(args_schema=UserDataInput)
def fetch_user_data(user_id: str) -> str:
    """Fails if ID is not 6 digits or if it's '999999'."""
    if len(user_id) != 6 or not user_id.isdigit():
        raise ValueError(f"Invalid user ID format: '{user_id}'. ID must be exactly 6 digits.")
    if user_id == "999999":
        raise ConnectionError("API connection failed.")
    return f"Success: Data retrieved for user ID {user_id}."

tools = [fetch_user_data]
llm = ChatOpenAI(model="gpt-4o", temperature=0).bind_tools(tools)
tool_executor = ToolExecutor(tools)

# Node Definitions

def call_model_validator(state: ValidatorState) -> ValidatorState:
    """Invokes the LLM, injecting error context if retrying."""
    
    # 4. LLM Instruction Refinement
    if state["error_message"]:
        system_instruction = SystemMessage(
            content=f"ATTENTION: Your previous tool call failed. Error: {state['error_message']}. You have attempted {state['retry_count']} times. Analyze the error and formulate a corrected tool call or terminate."
        )
        messages_for_llm = [system_instruction] + state["messages"]
    else:
        messages_for_llm = state["messages"]
        
    response = llm.invoke(messages_for_llm)
    tool_calls = response.tool_calls if response.tool_calls else None
    
    return {
        "messages": state["messages"] + [response],
        "tool_calls": tool_calls,
        "error_message": None # Clear error message for the next step
    }

# 2. Tool Execution with Try/Catch
def execute_tool_robust(state: ValidatorState) -> ValidatorState:
    """Executes tools, handles errors, and updates retry count."""
    tool_call = state["tool_calls"][0]
    tool_input = [{"id": tool_call['id'], "name": tool_call['name'], "args": tool_call['args']}]
    
    try:
        tool_result = tool_executor.invoke(tool_input)
        
        # Success Path
        tool_message = ToolMessage(content=str(tool_result), tool_call_id=tool_call['id'])
        return {"messages": state["messages"] + [tool_message], "tool_calls": None}
        
    except Exception as e:
        # Error Path: Capture and update state
        error_msg = f"Tool failed: {type(e).__name__}: {str(e)}"
        error_feedback_message = ToolMessage(
            content=f"ERROR: {error_msg}",
            tool_call_id=tool_call['id']
        )
        
        return {
            "messages": state["messages"] + [error_feedback_message],
            "tool_calls": None,
            "error_message": error_msg,
            "retry_count": state["retry_count"] + 1
        }

def fail_and_terminate(state: ValidatorState) -> ValidatorState:
    """Node for final termination after max retries."""
    final_failure_message = HumanMessage(
        content=f"Operation failed after {state['retry_count']} attempts. Last error: {state['error_message']}"
    )
    return {"messages": state["messages"] + [final_failure_message]}

# 3. Error Routing Node
def check_status(state: ValidatorState) -> str:
    """Routes based on error presence and retry count."""
    
    if state["error_message"]:
        if state["retry_count"] >= 3:
            return "max_retries"
        else:
            return "retry" # Route back to model for correction
    
    # Success path (no error)
    if state["tool_calls"]:
        return "continue_react" # Should not happen if tool_calls were cleared
    else:
        return "finish"

# Build the Graph
workflow = StateGraph(ValidatorState)
workflow.add_node("call_model", call_model_validator)
workflow.add_node("execute_tool", execute_tool_robust)
workflow.add_node("check_status", check_status)
workflow.add_node("fail_and_terminate", fail_and_terminate)
workflow.add_node("final_answer", fail_and_terminate)

workflow.set_entry_point("call_model")

# Standard routing from model decision
workflow.add_conditional_edges(
    "call_model",
    lambda state: "tool_use" if state["tool_calls"] else "finish",
    {"tool_use": "execute_tool", "finish": "final_answer"}
)

# Routing after tool execution (Error/Success Check)
workflow.add_conditional_edges(
    "execute_tool",
    check_status,
    {
        "retry": "call_model",             # Self-Correction Loop
        "max_retries": "fail_and_terminate",
        "finish": "final_answer"
    }
)

workflow.add_edge("fail_and_terminate", END)
workflow.add_edge("final_answer", END)

# app_validator = workflow.compile()
