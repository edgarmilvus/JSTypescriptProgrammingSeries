
/*
 * These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
 * You can find the series on Amazon.
 * New books info: https://linktr.ee/edgarmilvus
 *
 * MIT License
 * Copyright (c) 2025 Edgar Milvus
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */

// Source File: solution_exercise_4.py
// Description: Solution for Exercise 4
// ==========================================

import json
from typing import Iterator, Dict, Any, List
from langgraph.graph import StateGraph, END
from langchain_core.messages import HumanMessage, BaseMessage
from typing import TypedDict

# Define the Streaming Protocol Delimiter
STREAM_DELIMITER = "\n--END_STEP--\n"

# Conceptual Graph State (simplified)
class SimpleState(TypedDict):
    messages: List[BaseMessage]

# Conceptual Nodes
def node_thinking(state):
    return state
def node_data_fetch(state):
    return state
def node_synthesis(state):
    # This node provides the final content
    return {"messages": state['messages'] + [HumanMessage(content="The final synthesized answer is here.")]}

# Build a conceptual sequential graph
workflow = StateGraph(SimpleState)
workflow.add_node("Thinking", node_thinking)
workflow.add_node("Data_Fetch", node_data_fetch)
workflow.add_node("Synthesis", node_synthesis)
workflow.set_entry_point("Thinking")
workflow.add_edge("Thinking", "Data_Fetch")
workflow.add_edge("Data_Fetch", "Synthesis")
workflow.add_edge("Synthesis", END)
app_stream = workflow.compile()

# 1. & 2. Custom API Route Implementation and Streaming Protocol
def langgraph_stream_handler(prompt: str) -> Iterator[bytes]:
    """
    Simulated Next.js API route logic using LangGraph's stream method.
    Yields custom JSON payloads separated by a delimiter.
    """
    initial_state = {"messages": [HumanMessage(content=prompt)]}
    
    # 3. Server-Side Step Capture
    for step_output in app_stream.stream(initial_state):
        
        # Extract the node name and output
        node_name = list(step_output.keys())[0]
        node_data = step_output[node_name]
        
        # --- Stream STEP_UPDATE ---
        status_message = f"Executing node: {node_name}"
        step_payload: Dict[str, Any] = {
            "type": "STEP_UPDATE",
            "content": status_message,
            "node": node_name
        }
        
        # Serialize and yield the step update chunk
        yield (json.dumps(step_payload) + STREAM_DELIMITER).encode('utf-8')
        
        # --- Check for FINAL_RESPONSE ---
        # We assume the final node (Synthesis) provides the definitive answer message
        if node_name == "Synthesis" and node_data.get('messages'):
            final_message = node_data['messages'][-1].content
            
            final_payload: Dict[str, Any] = {
                "type": "FINAL_RESPONSE",
                "content": final_message
            }
            
            # Serialize and yield the final response chunk
            yield (json.dumps(final_payload) + STREAM_DELIMITER).encode('utf-8')
            
            # Terminate the server response stream
            break
            
# Example usage (simulating server response):
# for chunk in langgraph_stream_handler("What is the process for data synthesis?"):
#     print(chunk.decode('utf-8'), end='')
