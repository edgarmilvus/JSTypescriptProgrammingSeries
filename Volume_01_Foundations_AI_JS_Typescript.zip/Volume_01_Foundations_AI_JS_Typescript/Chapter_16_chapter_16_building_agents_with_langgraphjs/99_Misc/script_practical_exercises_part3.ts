/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2025 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part3.ts
// Description: Practical Exercises
// ==========================================

    digraph FinancialAnalyst {
        rankdir=TB;
        node [shape=box];
        start [label="Start"];
        model_decision [label="Model Decision (Router)"];
        stock_tool [label="Execute Stock Tool"];
        tax_tool [label="Execute Tax Tool"];
        final_answer [label="Generate Final Answer"];

        start -> model_decision;

        // Primary branches from decision
        model_decision -> stock_tool [label="Needs Stock Data"];
        model_decision -> tax_tool [label="Needs Tax Only"];
        model_decision -> final_answer [label="No Tool Needed"];

        // Sequential flow and completion
        stock_tool -> tax_tool [label="Requires Tax Calculation"];
        stock_tool -> final_answer [label="Done with Stock"];
        tax_tool -> final_answer [label="Done"];
    }
    