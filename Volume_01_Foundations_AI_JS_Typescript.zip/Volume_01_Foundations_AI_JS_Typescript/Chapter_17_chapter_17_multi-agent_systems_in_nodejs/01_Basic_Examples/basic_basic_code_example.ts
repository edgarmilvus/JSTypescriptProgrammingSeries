/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2025 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

// multiAgentSystem.ts

// --- 1. Interface and Mocking ---
interface AgentResult {
    agentId: string;
    modelUsed: string;
    output: string;
    confidenceScore: number;
}

/**
 * Mocks an asynchronous call to an LLM API (e.g., OpenAI, Anthropic).
 * Simulates different quality outputs and processing times, crucial for
 * demonstrating the need for parallel execution.
 * @param model - The model identifier (e.g., 'gpt-4o', 'claude-3').
 * @param prompt - The input prompt.
 * @returns A promise resolving to the generated text.
 */
async function mockLLMCall(model: string, prompt: string): Promise<string> {
    // Simulating latency differences: Mini is fast (500ms), large model is slow (1500ms).
    const latency = model === 'gpt-4o-mini' ? 500 : 1500; 
    await new Promise(resolve => setTimeout(resolve, latency));

    if (model === 'gpt-4o-mini') {
        return `[Fast Draft] Summary of '${prompt}': AI trends focus heavily on multimodal integration and local inference acceleration (SAB/WebGPU).`;
    } else {
        return `[High Quality] Detailed analysis of '${prompt}': The primary 2024 AI trends involve the maturation of RAG architectures, the necessity of robust security protocols, and the critical role of specialized hardware acceleration using technologies like SharedArrayBuffer for parallel processing and WebGPU compute shaders for tensor operations.`;
    }
}

// --- 2. The Worker Agent ---
class WorkerAgent {
    /**
     * @param id - Unique identifier for the agent.
     * @param model - The specific LLM model this agent is configured to use.
     * @param confidence - A pre-assigned confidence score reflecting the model quality/cost.
     */
    constructor(public id: string, public model: string, public confidence: number) {}

    /**
     * Executes the task by calling the (mocked) external LLM service asynchronously.
     * @param taskPrompt - The specific instruction for the LLM.
     * @returns The structured result object containing metadata and output.
     */
    async execute(taskPrompt: string): Promise<AgentResult> {
        console.log(`[${this.id}] Starting task using model: ${this.model}...`);
        const output = await mockLLMCall(this.model, taskPrompt);
        console.log(`[${this.id}] Task complete.`);
        
        return {
            agentId: this.id,
            modelUsed: this.model,
            output: output,
            confidenceScore: this.confidence,
        };
    }
}

// --- 3. The Supervisor Agent (Consensus Mechanism) ---
class SupervisorAgent {
    /**
     * Implements a simple consensus mechanism to select the best result.
     * This mechanism is crucial for mitigating single-agent failure or low-quality output.
     * @param results - Array of results from all worker agents.
     * @returns The final, synthesized best result.
     */
    synthesize(results: AgentResult[]): AgentResult {
        console.log("\n[Supervisor] Analyzing results for consensus...");
        
        // Strategy: Select the highest confidence score. 
        // If scores are tied, prefer the result from the higher-quality model ('gpt-4o').
        let bestResult = results[0];
        
        for (const result of results) {
            if (result.confidenceScore > bestResult.confidenceScore) {
                bestResult = result;
            } else if (result.confidenceScore === bestResult.confidenceScore) {
                // Tie-breaker logic: Prefer the detailed agent output
                if (result.modelUsed === 'gpt-4o') {
                    bestResult = result;
                }
            }
        }
        
        console.log(`[Supervisor] Consensus reached. Selecting output from Agent: ${bestResult.agentId}`);
        return bestResult;
    }
}

// --- 4. Main Execution Flow (SaaS Context) ---
/**
 * Executes the entire multi-agent workflow for a user request.
 */
async function runMultiAgentSystem() {
    console.log("--- SaaS Request Handler: Starting Multi-Agent Task ---");
    const userQuery = "Key advancements in AI acceleration technology in 2024";

    // 1. Initialize Agents
    const agents: WorkerAgent[] = [
        // Agent A: Fast, cheap, lower confidence (Drafting Agent)
        new WorkerAgent('DraftingAgent-A', 'gpt-4o-mini', 0.7), 
        // Agent B: Slow, expensive, high confidence (Reviewer/Detail Agent)
        new WorkerAgent('DetailAgent-B', 'gpt-4o', 0.9), 
    ];

    const supervisor = new SupervisorAgent();

    // 2. Execute Tasks in Parallel
    // Promise.all ensures that the total execution time is max(T_A, T_B), not T_A + T_B.
    const executionPromises = agents.map(agent => agent.execute(userQuery));
    
    // Wait for all agents to complete their LLM calls
    const allResults = await Promise.all(executionPromises);
    
    // 3. Consensus and Synthesis
    const finalResult = supervisor.synthesize(allResults);

    // 4. Output to User/Database
    console.log("\n--- Final System Output ---");
    console.log(`Source Agent: ${finalResult.agentId} (${finalResult.modelUsed})`);
    console.log(`Confidence: ${finalResult.confidenceScore}`);
    console.log("Result:\n", finalResult.output);
}

// Execute the system
runMultiAgentSystem();
