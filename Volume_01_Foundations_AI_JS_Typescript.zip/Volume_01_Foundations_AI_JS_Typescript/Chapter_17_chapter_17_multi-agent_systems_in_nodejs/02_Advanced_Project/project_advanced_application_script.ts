/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2025 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

/**
 * @fileoverview A multi-agent system using LangGraph.js for routing feature requests
 * in a simulated SaaS development workflow.
 * Target Environment: Node.js (V8 Engine)
 */

import { StateGraph, END } from "@langchain/langgraph";
import { z } from "zod";

// --- 1. Define the Graph State using Zod for Type Safety ---

/**
 * @typedef {object} FeaturePlanState
 * @property {string} request - The original feature request from the user.
 * @property {string} [analysis] - The supervisor's categorization of the request.
 * @property {string[]} schema_updates - List of database changes identified.
 * @property {string[]} code_snippets - List of code artifacts generated.
 * @property {'analyze' | 'schema' | 'code' | 'finish'} next_step - The routing instruction for the Conditional Edge.
 */
const FeaturePlanState = z.object({
    request: z.string(),
    analysis: z.string().optional(),
    schema_updates: z.array(z.string()).default([]),
    code_snippets: z.array(z.string()).default([]),
    next_step: z.enum(["analyze", "schema", "code", "finish"]),
});

type FeaturePlanState = z.infer<typeof FeaturePlanState>;

// --- 2. Mock LLM and Tool Functions ---

/**
 * @function mockLLMCall
 * @description Simulates an asynchronous call to an external LLM service.
 * @param {string} prompt The input prompt.
 * @returns {Promise<string>} A simulated response payload.
 */
async function mockLLMCall(prompt: string): Promise<string> {
    // In a real Node.js application, this non-blocking I/O is handled efficiently by V8's event loop.
    await new Promise(resolve => setTimeout(resolve, 50));
    return `LLM Response for: ${prompt.substring(0, 30)}...`;
}

// --- 3. Define the Worker Agent Pool Nodes ---

/**
 * @function analysisNode
 * @description The Supervisor Node. Analyzes the request and sets the routing instruction.
 * @param {FeaturePlanState} state The current graph state.
 * @returns {Promise<Partial<FeaturePlanState>>} Updated state with analysis and next_step.
 */
async function analysisNode(state: FeaturePlanState): Promise<Partial<FeaturePlanState>> {
    const analysisResult = await mockLLMCall(`Analyze request: ${state.request}`);

    let routingInstruction: FeaturePlanState['next_step'];

    // Simple heuristic for routing:
    if (state.request.toLowerCase().includes("database") || state.request.toLowerCase().includes("schema")) {
        routingInstruction = 'schema';
    } else if (state.request.toLowerCase().includes("ui") || state.request.toLowerCase().includes("function")) {
        routingInstruction = 'code';
    } else {
        // Default to finishing if simple or ambiguous
        routingInstruction = 'finish';
    }

    console.log(`[Supervisor] Analysis complete. Next step: ${routingInstruction}`);
    return {
        analysis: analysisResult,
        next_step: routingInstruction,
    };
}

/**
 * @function schemaAgent
 * @description Worker Agent for generating database schema updates.
 * @param {FeaturePlanState} state The current graph state.
 * @returns {Promise<Partial<FeaturePlanState>>} Updated state with schema changes and next_step set to 'code'.
 */
async function schemaAgent(state: FeaturePlanState): Promise<Partial<FeaturePlanState>> {
    console.log("[Schema Agent] Executing database planning...");
    const schemaOutput = await mockLLMCall(`Generate schema for: ${state.request}`);
    return {
        schema_updates: [`CREATE TABLE new_data_structure;`, schemaOutput],
        next_step: 'code', // Force transition to code generation after schema work
    };
}

/**
 * @function codeAgent
 * @description Worker Agent for generating code snippets (e.g., API handlers).
 * @param {FeaturePlanState} state The current graph state.
 * @returns {Promise<Partial<FeaturePlanState>>} Updated state with code snippets and next_step set to 'finish'.
 */
async function codeAgent(state: FeaturePlanState): Promise<Partial<FeaturePlanState>> {
    console.log("[Code Agent] Executing code generation...");
    const codeOutput = await mockLLMCall(`Generate code for: ${state.request}`);
    return {
        code_snippets: [`// Function implementation stub`, codeOutput],
        next_step: 'finish', // End the process
    };
}

// --- 4. Define the Conditional Edge (Router) ---

/**
 * @function routeDecision
 * @description Implements the Conditional Edge logic. Inspects the state to determine the next node.
 * @param {FeaturePlanState} state The current graph state.
 * @returns {string} The name of the next node or END.
 */
function routeDecision(state: FeaturePlanState): string {
    switch (state.next_step) {
        case 'schema':
            return 'schema_agent';
        case 'code':
            return 'code_agent';
        case 'finish':
        default:
            return END;
    }
}

// --- 5. Build and Compile the Graph ---

const builder = new StateGraph<FeaturePlanState>({
    channels: FeaturePlanState,
});

// Add nodes (The Worker Agent Pool and Supervisor)
builder.addNode("analysis_supervisor", analysisNode);
builder.addNode("schema_agent", schemaAgent);
builder.addNode("code_agent", codeAgent);

// Set entry point
builder.setEntryPoint("analysis_supervisor");

// Define Edges (Transitions)

// 1. Conditional Edge from Supervisor to Workers/Finish
builder.addConditionalEdges(
    "analysis_supervisor", // Source Node
    routeDecision,         // The Predicate Function (Conditional Edge)
    {                      // Mappings based on routeDecision output
        schema: "schema_agent",
        code: "code_agent",
        finish: END,
    }
);

// 2. Linear Edge from Schema Agent to Code Agent
builder.addEdge("schema_agent", "code_agent");

// 3. Linear Edge from Code Agent to Finish (END)
builder.addEdge("code_agent", END);

// Compile the graph
const app = builder.compile();

// --- 6. Example Execution ---

/**
 * @async
 * @function runFeaturePlanner
 * @description Executes the multi-agent planning process for a given request.
 */
async function runFeaturePlanner(featureRequest: string) {
    console.log(`\n--- Starting Plan for: "${featureRequest}" ---`);
    const initialState: FeaturePlanState = {
        request: featureRequest,
        next_step: 'analyze', // Initial instruction for the supervisor
        schema_updates: [],
        code_snippets: [],
    };

    const finalState = await app.invoke(initialState);
    console.log("\n--- Final Output Summary ---");
    console.log("Request:", finalState.request);
    console.log("Analysis:", finalState.analysis);
    console.log("Schema Updates:", finalState.schema_updates.length > 0 ? finalState.schema_updates : "None");
    console.log("Code Snippets:", finalState.code_snippets.length > 0 ? finalState.code_snippets : "None");
}

// Scenario 1: Requires Schema and Code (The full pipeline)
runFeaturePlanner("Implement user preference tracking, requiring a new database table and a UI function.");

// Scenario 2: Requires only Code (Bypassing Schema)
runFeaturePlanner("Add a new UI component for displaying statistics.");

// Scenario 3: Simple request (Finishes early)
runFeaturePlanner("Update documentation links.");
