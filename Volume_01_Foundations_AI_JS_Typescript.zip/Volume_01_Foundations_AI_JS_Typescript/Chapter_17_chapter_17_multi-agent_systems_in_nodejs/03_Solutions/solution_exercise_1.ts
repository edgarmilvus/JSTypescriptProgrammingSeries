
/*
 * These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
 * You can find the series on Amazon.
 * New books info: https://linktr.ee/edgarmilvus
 *
 * MIT License
 * Copyright (c) 2025 Edgar Milvus
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */

// Source File: solution_exercise_1.ts
// Description: Solution for Exercise 1
// ==========================================

// --- Node.js/TypeScript Implementation using Zod (Simulated) ---

// 1. Zod Schema Definitions (Simulated using TypeScript interfaces for structure)
interface ResearchFinding {
    topic: string;
    source_url: string;
    confidence_score: number; // 0.0 to 1.0
    raw_finding: string;
}
type ResearchFindingsSchema = ResearchFinding[]; // Array of findings

interface FinalReport {
    executive_summary: string;
    key_findings_list: string[];
    risk_assessment: string;
}
// Zod.infer<typeof FinalReportSchema> = FinalReport;

// 2. Simulated Tools
const tool_market_data = (topic: string) => `Market data for ${topic}: High growth projected.`;
const tool_regulatory_landscape = (topic: string) => `Regulatory analysis for ${topic}: Low barrier to entry.`;

// 3. Agent Definitions
class ResearcherAgent {
    name = "Researcher";

    async research(query: string): Promise<ResearchFindingsSchema> {
        console.log(`[${this.name}] Executing tools for query: ${query}`);
        
        // Step 1: Simulate tool calls based on query decomposition
        const market_data = tool_market_data("DAOs");
        const regulatory_data = tool_regulatory_landscape("DAO Governance");

        // Step 2: LLM generates raw output, then coerced to schema
        const raw_findings: ResearchFindingsSchema = [
            {
                topic: "Market Potential",
                source_url: "simulated.market.com",
                confidence_score: 0.95,
                raw_finding: market_data
            },
            {
                topic: "Ethical Implications",
                source_url: "simulated.ethics.org",
                confidence_score: 0.80,
                raw_finding: "Potential for plutocracy if governance is not decentralized enough."
            }
        ];
        
        // Step 3: Simulate Zod Validation/Coercion (Critical step)
        // If validation failed, the agent would internally reflect and re-generate.
        console.log(`[${this.name}] Output successfully coerced to ResearchFindingsSchema.`);
        return raw_findings;
    }
}

class SynthesizerAgent {
    name = "Synthesizer";

    async synthesize(findings: ResearchFindingsSchema): Promise<FinalReport> {
        console.log(`[${this.name}] Synthesizing ${findings.length} validated findings...`);
        
        // LLM generates the final report based on structured input
        const report: FinalReport = {
            executive_summary: "DAOs show significant market potential but require careful ethical consideration regarding governance centralization.",
            key_findings_list: findings.map(f => `${f.topic}: ${f.raw_finding}`),
            risk_assessment: "The primary risk is regulatory uncertainty and the potential for concentration of power (plutocracy) within the DAO structure."
        };
        
        // Final Zod Validation (Check 2)
        // If validation failed, the agent would internally refine the report.
        console.log(`[${this.name}] Final report successfully coerced to FinalReportSchema.`);
        return report;
    }
}

class OrchestratorAgent {
    researcher = new ResearcherAgent();
    synthesizer = new SynthesizerAgent();
    
    async run(userQuery: string) {
        console.log(`\n--- ORCHESTRATOR START ---`);
        console.log(`Query: ${userQuery}`);

        // 1. Delegation to Researcher (Requires ResearchFindingsSchema)
        let validatedFindings: ResearchFindingsSchema;
        try {
            const rawFindings = await this.researcher.research(userQuery);
            
            // Critical Validation Step 1 (Simulated Zod Check)
            // If rawFindings did not match the schema, this block would throw.
            // For simplicity, we assume success here.
            validatedFindings = rawFindings;
            console.log(`[Orchestrator] Successfully validated Researcher output.`);
            
        } catch (error) {
            console.error(`[Orchestrator] ERROR: Researcher schema violation. Retrying...`);
            // In a real system, this would trigger a re-prompt with schema feedback.
            return; 
        }

        // 2. Delegation to Synthesizer
        const finalReport = await this.synthesizer.synthesize(validatedFindings);
        
        // Critical Validation Step 2 (Simulated Zod Check on Synthesizer output)
        // If finalReport did not match FinalReportSchema, this would throw.
        
        console.log(`\n--- FINAL OUTPUT ---`);
        console.log(JSON.stringify(finalReport, null, 2));
        console.log(`--- ORCHESTRATOR END ---`);
    }
}

// Execution
const orchestrator = new OrchestratorAgent();
orchestrator.run("Analyze the ethical implications and market potential of decentralized autonomous organizations (DAOs) in the next five years");

// 4. Graphviz DOT Code
const graphviz_dot = `
digraph ResearchPipeline {
    rankdir=TB;
    node [shape=box, style="filled", fillcolor="#ECEFF1"];
    edge [fontname="Arial"];

    UserQuery [label="1. User Query Received", shape=oval, fillcolor="#B3E5FC"];
    Orchestrator [label="Orchestrator Agent\\n(Defines ResearchFindingsSchema)"];
    Researcher [label="Researcher Agent\\n(Calls Tools)"];
    Synthesizer [label="Synthesizer Agent\\n(Defines FinalReportSchema)"];
    FinalOutput [label="6. Final Report", shape=oval, fillcolor="#A5D6A7"];

    UserQuery -> Orchestrator [label="Delegation Request"];
    
    subgraph cluster_research {
        label = "Research Phase";
        style = "dashed";
        color = "#FFB74D";
        
        Orchestrator -> Researcher [label="2. Task Delegation (Requires ResearchFindingsSchema)"];
        Researcher -> Tool1 [label="Tool Call: Market Data"];
        Researcher -> Tool2 [label="Tool Call: Regulatory"];
        Tool1 [label="External Tool 1"];
        Tool2 [label="External Tool 2"];
        
        Researcher -> Validation1 [label="3. Raw Output"];
        Validation1 [label="Zod Validation Check 1", shape=diamond, fillcolor="#FFCC80"];
        
        Validation1 -> Researcher [label="Schema Mismatch (Retry/Refine)", style=dashed, color=red, constraint=false];
        Validation1 -> Orchestrator [label="4. Validated Findings Array"];
    }
    
    Orchestrator -> Synthesizer [label="5. Synthesis Request"];
    
    Synthesizer -> Validation2 [label="Draft Report"];
    Validation2 [label="Zod Validation Check 2", shape=diamond, fillcolor="#FFCC80"];
    
    Validation2 -> Synthesizer [label="Schema Mismatch (Refine)", style=dashed, color=red, constraint=false];
    Validation2 -> FinalOutput [label="Validated Final Report"];
}
`;
console.log("\n--- Graphviz DOT Code ---");
console.log(graphviz_dot);
