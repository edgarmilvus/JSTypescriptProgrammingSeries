
/*
 * These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
 * You can find the series on Amazon.
 * New books info: https://linktr.ee/edgarmilvus
 *
 * MIT License
 * Copyright (c) 2025 Edgar Milvus
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */

// Source File: solution_exercise_3.js
// Description: Solution for Exercise 3
// ==========================================

// --- Node.js/JavaScript Implementation (Requires Node.js environment) ---
// Note: This code simulates the core logic; running it requires actual Node.js Worker Threads setup.
const { Worker, isMainThread, parentPort, workerData } = require('worker_threads');
const { TextEncoder, TextDecoder } = require('util');

// 1. Configuration/Schema for the Shared State
const CONFIG_SIZE = 1024 * 10; // 10KB simulated data
const METADATA_LENGTH = 100; // Space reserved for JSON metadata

function serializeState(state) {
    const jsonString = JSON.stringify(state);
    const encoded = new TextEncoder().encode(jsonString);
    if (encoded.length > METADATA_LENGTH) {
        throw new Error("Metadata exceeds reserved space.");
    }
    return encoded;
}

function deserializeState(buffer) {
    // Assume the first METADATA_LENGTH bytes contain the JSON string
    const decoder = new TextDecoder();
    const jsonString = decoder.decode(buffer.slice(0, METADATA_LENGTH)).replace(/\0/g, ''); // Remove null padding
    return JSON.parse(jsonString);
}


// --- Orchestrator (Main Thread) ---
if (isMainThread) {
    console.log("--- Orchestrator: Initializing Shared State ---");
    
    // Initial State Object
    let globalConfig = {
        model_version: "v1.0",
        processed_count: 0,
        last_successful_batch_id: "none",
        feature_vectors: new Array(1000).fill(0.5) // Simulated large array
    };

    // 1. Initialize SharedArrayBuffer (SAB)
    const sab = new SharedArrayBuffer(CONFIG_SIZE);
    
    // Serialize initial metadata into the SAB
    const initialEncoded = serializeState(globalConfig);
    new Uint8Array(sab).set(initialEncoded);

    // 2. Spawn Workers
    const workers = [];
    for (let i = 1; i <= 3; i++) {
        const worker = new Worker(__filename, {
            workerData: { workerId: i, sharedBuffer: sab }
        });
        workers.push(worker);

        // 4. Orchestrator's Role in State Synchronization
        worker.on('message', (newStateSnapshot) => {
            if (newStateSnapshot.type === 'STATE_UPDATE') {
                console.log(`\n[Orchestrator] Received immutable update from Worker ${newStateSnapshot.workerId}.`);
                
                // Validate and accept the new state
                globalConfig = newStateSnapshot.state;
                console.log(`[Orchestrator] New Processed Count: ${globalConfig.processed_count}`);
                
                // (Optional: Propagate the new state to other workers, or update SAB if needed)
                // For this exercise, we keep the SAB static and use postMessage for updates.
            }
        });
    }

} else {
    // --- VectorProcessingAgent (Worker Thread) ---
    const { workerId, sharedBuffer } = workerData;
    
    // 2. Worker Agent Operation: Read SAB
    const currentBuffer = new Uint8Array(sharedBuffer);
    let currentState = deserializeState(currentBuffer);

    console.log(`[Worker ${workerId}] Initial state read. Model Version: ${currentState.model_version}`);

    // 3. Enforcing Immutable State Updates
    function performUpdate() {
        // a. Deserialize the current state (already done above, or re-read if SAB was updated)
        // b. Create a deep copy of the state object (crucial for immutability)
        const newState = JSON.parse(JSON.stringify(currentState)); 
        
        // c. Apply the required update to the copy
        newState.processed_count += 100;
        newState.last_successful_batch_id = `batch-${Date.now()}-${workerId}`;

        // d. Send the *new* state object back to the Orchestrator
        parentPort.postMessage({
            type: 'STATE_UPDATE',
            workerId: workerId,
            state: newState
        });
        
        // Update the worker's internal view of the state (optional, if the orchestrator doesn't send back updates)
        currentState = newState;
    }

    // Simulate multiple asynchronous updates
    setTimeout(() => performUpdate(), 1000 * workerId);
    setTimeout(() => performUpdate(), 1000 * workerId + 500);
}

// 5. Demonstrating Failure Avoidance:
/*
If the worker attempted to write complex data (like updating 'last_successful_batch_id' 
or modifying the 'feature_vectors' array) directly to the SAB without using Atomics 
(which only works reliably for simple integer counters), a race condition would occur. 
Worker 1 might start writing, get context-switched, and Worker 2 overwrites 
the half-written data structure, leading to corruption (e.g., malformed JSON).

By enforcing immutability (copying, updating the copy, and sending the new object), 
the Orchestrator becomes the single, serial bottleneck for state modification, 
eliminating race conditions on complex data fields. The SAB is only used here 
for efficient initial data distribution, not concurrent mutation.
*/
