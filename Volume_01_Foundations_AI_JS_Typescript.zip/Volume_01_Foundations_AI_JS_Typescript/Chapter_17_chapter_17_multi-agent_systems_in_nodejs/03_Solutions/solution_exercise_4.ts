
/*
 * These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
 * You can find the series on Amazon.
 * New books info: https://linktr.ee/edgarmilvus
 *
 * MIT License
 * Copyright (c) 2025 Edgar Milvus
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */

// Source File: solution_exercise_4.ts
// Description: Solution for Exercise 4
// ==========================================

// --- TypeScript Data Model Definition ---

/** 
 * Represents a single, immutable state of an agent at a given moment.
 * Used within the AgentWorkflowSnapshot.
 */
interface AgentState {
    agent_id: string;
    agent_name: 'Orchestrator' | 'Researcher' | 'Synthesizer' | 'Planner';
    status: 'IDLE' | 'RUNNING' | 'WAITING_FOR_TOOL' | 'REFLECTING' | 'COMPLETED' | 'FAILED';
    current_task: string;
    // History of internal thoughts and decision-making steps
    internal_monologue_history: {
        timestamp: string;
        thought: string;
        action_taken: string;
    }[];
    // Specific metadata for the agent (e.g., retry count, data size)
    metadata: Record<string, any>; 
}

/**
 * Log entry for a tool call, regardless of success.
 */
interface ToolCallLogEntry {
    timestamp: string;
    agent_id: string;
    tool_name: string;
    input_params: Record<string, any>;
    observation: {
        status: 'SUCCESS' | 'FAILURE';
        output_data: any;
        error_code?: string;
    };
}

/**
 * The complete, immutable state of the entire workflow at a single point in time.
 * This is the object streamed to the frontend.
 */
interface AgentWorkflowSnapshot {
    timestamp: string; // ISO 8601 format
    run_id: string;
    global_step_count: number; // Monotonically increasing counter for the timeline
    active_agent_id: string; // The agent currently holding control
    
    // Array of all agents' current immutable states
    agent_states: AgentState[]; 
    
    // Full history of tool calls made during this run
    tool_call_log: ToolCallLogEntry[]; 
}

// 2. API Endpoint Design Description
/*
API Type: WebSocket (WS)
Endpoint: /ws/agent-status/{run_id}

Streaming Guarantee:
The Node.js backend orchestrator guarantees that upon every state change 
(e.g., agent handoff, tool call completion, reflection event), it generates 
a brand new AgentWorkflowSnapshot object. This object is serialized and 
streamed over the WebSocket.

The frontend client (the React component) can use the 'global_step_count' 
or 'timestamp' for ordering, and crucially, it can rely on the immutability 
of the received snapshot object. If a new snapshot object reference is received, 
the component knows the state has changed and must re-render; if the reference 
is the same (which should never happen if the backend is implemented correctly), 
it skips unnecessary reconciliation, optimizing performance.
*/

// 4. Backend Workflow State Diagram
const graphviz_dot = `
digraph StateSnapshotStream {
    rankdir=TB;
    node [shape=box, style="filled", fillcolor="#E0F7FA"];
    edge [fontname="Arial"];

    UserAction [label="User Starts Workflow", shape=oval, fillcolor="#B3E5FC"];
    Agent1 [label="Agent A Executes Task"];
    Agent2 [label="Agent B Executes Task"];
    
    Orchestrator [label="Orchestrator (State Manager)", shape=diamond, fillcolor="#FFCC80"];
    SnapshotGenerator [label="Generate New AgentWorkflowSnapshot", shape=box3d];
    WebSocketBroadcast [label="Broadcast Snapshot to Frontend", shape=cylinder, fillcolor="#A5D6A7"];
    
    UserAction -> Orchestrator [label="Start"];
    
    subgraph cluster_execution {
        label = "Agent Execution Cycle";
        style = "dashed";
        color = "#90A4AE";
        
        Orchestrator -> Agent1 [label="Delegate Task"];
        Agent1 -> Orchestrator [label="Task Complete / Handoff Data"];
        
        Orchestrator -> Agent2 [label="Delegate Task"];
        Agent2 -> Orchestrator [label="Task Complete / Tool Reflection Event"];
    }
    
    Orchestrator -> SnapshotGenerator [label="Trigger Snapshot Generation"];
    SnapshotGenerator -> WebSocketBroadcast [label="Immutable Snapshot Object"];
    WebSocketBroadcast -> Orchestrator [label="Ready for Next State"];
    
    {Agent1, Agent2} -> SnapshotGenerator [style=invis];
}
`;
console.log("\n--- Graphviz DOT Code ---");
console.log(graphviz_dot);
