/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2025 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

// --- Node.js/TypeScript Implementation for Reflection ---

const MAX_RETRIES = 3;

interface ToolObservation {
    status: "SUCCESS" | "ERROR";
    result?: number;
    code?: string;
    message?: string;
}

interface ReflectionEntry {
    attempt: number;
    observation: ToolObservation;
    internal_thought: string;
    action_taken: string;
}

// Simulated External Tool
function ComplexMathService(operation: string, attempt: number): ToolObservation {
    // 30% failure rate, but guarantee success on the 4th attempt for testing
    const shouldFail = Math.random() < 0.3 && attempt <= MAX_RETRIES; 

    if (shouldFail) {
        return {
            status: "ERROR",
            code: "429_RATE_LIMIT",
            message: `Service overloaded (Attempt ${attempt}). Retry after 5 seconds.`,
        };
    }
    return {
        status: "SUCCESS",
        result: 42, // The answer to everything
    };
}

class CalculatorAgent {
    query: string;
    current_plan: string;
    reflection_count: number = 0;
    reflection_history: ReflectionEntry[] = [];

    constructor(query: string) {
        this.query = query;
        this.current_plan = `Execute ComplexMathService for: ${query}`;
    }

    // The core reflection mechanism
    private reflect(observation: ToolObservation): ReflectionEntry {
        this.reflection_count++;
        let internal_thought: string;
        let action_taken: string;

        if (this.reflection_count > MAX_RETRIES) {
            internal_thought = `Maximum reflection count (${MAX_RETRIES}) exceeded. The error persists: ${observation.message}. Must escalate the issue.`;
            this.current_plan = "Escalate Failure";
            action_taken = "Escalated to Orchestrator";
        } else if (observation.code === "429_RATE_LIMIT") {
            internal_thought = `Received rate limit error (Code: ${observation.code}). I must wait for a simulated 5 seconds and retry the exact same tool call. This is attempt ${this.reflection_count}.`;
            this.current_plan = "Wait and Retry ComplexMathService";
            action_taken = "Delayed Retry";
        } else {
            internal_thought = `Received unknown error. Attempting a generic retry with modified parameters.`;
            this.current_plan = "Retry ComplexMathService with modified inputs";
            action_taken = "Adjusted parameters and retried";
        }

        return {
            attempt: this.reflection_count,
            observation: observation,
            internal_thought: internal_thought,
            action_taken: action_taken,
        };
    }

    async execute() {
        console.log(`[Agent] Starting query: ${this.query}`);
        
        while (this.current_plan !== "Escalate Failure" && this.current_plan.includes("ComplexMathService")) {
            console.log(`\n[Agent] Current Plan: ${this.current_plan}`);
            
            // 1. Execute Tool
            const observation = ComplexMathService(this.query, this.reflection_count + 1);

            if (observation.status === "SUCCESS") {
                console.log(`[Tool Success] Result: ${observation.result}`);
                this.current_plan = "Task Complete";
                // Record final success log
                this.reflection_history.push({ 
                    attempt: this.reflection_count + 1, 
                    observation: observation, 
                    internal_thought: "Successful execution.",
                    action_taken: "Completed"
                });
                break;
            } else {
                console.warn(`[Tool Failure] Code: ${observation.code}`);
                
                // 2. Perform Reflection
                const reflectionLog = this.reflect(observation);
                this.reflection_history.push(reflectionLog);
                console.log(`[Reflection] Thought: ${reflectionLog.internal_thought}`);
                console.log(`[Reflection] New Plan: ${this.current_plan}`);
                
                // Simulate delay if rate limited
                if (reflectionLog.action_taken === "Delayed Retry") {
                    // await new Promise(resolve => setTimeout(resolve, 500)); 
                    console.log("[Simulation] 5 second delay simulated.");
                }
            }
        }

        console.log(`\n--- Final Reflection Log ---`);
        console.log(`Initial Query: ${this.query}`);
        console.log(`Final Status: ${this.current_plan}`);
        console.log("History:");
        console.log(JSON.stringify(this.reflection_history, null, 2));
    }
}

// Execution demonstrating retries
const calculator = new CalculatorAgent("Calculate the derivative of 3x^2 + 5");
calculator.execute();
