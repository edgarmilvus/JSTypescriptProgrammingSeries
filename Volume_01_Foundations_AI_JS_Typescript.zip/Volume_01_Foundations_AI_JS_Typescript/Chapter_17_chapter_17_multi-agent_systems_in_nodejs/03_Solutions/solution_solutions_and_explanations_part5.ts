/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2025 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

// --- Node.js/TypeScript Implementation for Adaptive Orchestration ---

// 1. Zod Schema for Classifier Output
interface ClassificationSchema {
    workflow_type: 'SIMPLE' | 'COMPLEX';
    primary_topic: string;
    extracted_parameters: Record<string, any>;
}

// --- Agent Definitions ---

class Classifier_Agent {
    name = "Classifier";
    async classify(query: string): Promise<ClassificationSchema> {
        console.log(`[${this.name}] Analyzing query intent...`);
        
        // Simulated LLM Classification Logic
        if (query.toLowerCase().includes("exchange rate") || query.toLowerCase().includes("stock price")) {
            return {
                workflow_type: 'COMPLEX',
                primary_topic: 'Financial Analysis',
                extracted_parameters: { currency_pair: 'USD/EUR', amount: 500 }
            };
        } else {
            return {
                workflow_type: 'SIMPLE',
                primary_topic: 'General Knowledge',
                extracted_parameters: {}
            };
        }
    }
}

class SimpleQA_Agent {
    async run(query: string): Promise<string> {
        return `[SimpleQA] Zero-shot learning is a machine learning paradigm where a model can classify objects it has never explicitly seen during training by leveraging semantic information, such as attributes or descriptions, bridging known and unknown classes.`;
    }
}

// 3. Complex Chain Agents
class Planner_Agent {
    async run(query: string): Promise<string[]> {
        console.log("[Planner] Decomposing complex query.");
        return [
            "Tool Call: Get current USD/EUR exchange rate.",
            "Calculate: 500 USD * Rate.",
            "Synthesize: Format calculation into a brief financial report."
        ];
    }
}

class DataFetcher_Agent {
    async run(tasks: string[]): Promise<Map<string, any>> {
        console.log("[DataFetcher] Executing tool calls...");
        const results = new Map();
        
        if (tasks.includes("Tool Call: Get current USD/EUR exchange rate.")) {
            const rate = 0.92; // Simulated rate
            results.set("exchange_rate", rate);
            results.set("calculation_result", 500 * rate);
        }
        return results;
    }
}

class Drafting_Agent {
    async run(data: Map<string, any>): Promise<string> {
        const rate = data.get("exchange_rate");
        const converted = data.get("calculation_result");
        
        return `[Drafting] Financial Report:\n\n
Current Exchange Rate (USD to EUR): ${rate}\n
$500 USD converts to ${converted.toFixed(2)} EUR.\n
This calculation is based on the current market rate.`;
    }
}


// 2. Adaptive Routing Logic
class AdaptiveOrchestrator {
    classifier = new Classifier_Agent();
    qaAgent = new SimpleQA_Agent();
    planner = new Planner_Agent();
    fetcher = new DataFetcher_Agent();
    drafter = new Drafting_Agent();

    async run(query: string) {
        console.log(`\n--- Adaptive Orchestrator Start ---`);
        
        // Step 1: Classification
        const classification = await this.classifier.classify(query);
        console.log(`[Orchestrator] CLASSIFICATION: ${classification.workflow_type}`);

        let finalResult: string;

        if (classification.workflow_type === 'SIMPLE') {
            // Workflow 1: Simple Q&A
            console.log("--- ROUTING: SIMPLE WORKFLOW ---");
            finalResult = await this.qaAgent.run(query);

        } else if (classification.workflow_type === 'COMPLEX') {
            // Workflow 2: Complex Multi-Step Chain
            console.log("--- ROUTING: COMPLEX WORKFLOW ---");
            
            // 2a. Planning
            const tasks = await this.planner.run(query);
            
            // 2b. Data Fetching
            const data = await this.fetcher.run(tasks);
            
            // 2c. Drafting/Synthesis
            finalResult = await this.drafter.run(data);
        } else {
            finalResult = "Error: Unknown classification type.";
        }
        
        console.log(`\n--- FINAL RESULT ---`);
        console.log(finalResult);
    }
}

// 4. Interactive Test Cases
const simpleQuery = "Explain the concept of zero-shot learning in one paragraph.";
const complexQuery = "Find the current exchange rate for USD to EUR, then calculate how much 500 USD is in EUR, and format the result as a brief financial report.";

const orchestrator = new AdaptiveOrchestrator();

// Test 1: Simple
orchestrator.run(simpleQuery);

// Test 2: Complex
orchestrator.run(complexQuery);
