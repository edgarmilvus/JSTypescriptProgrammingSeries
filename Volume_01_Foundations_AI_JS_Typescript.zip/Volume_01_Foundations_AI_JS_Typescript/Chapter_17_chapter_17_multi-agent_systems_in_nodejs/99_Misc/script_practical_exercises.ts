/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2025 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises.ts
// Description: Practical Exercises
// ==========================================

digraph ResearchPipeline {
    rankdir=TB;
    node [shape=box, style="filled", fillcolor="#ECEFF1"];
    edge [fontname="Arial"];

    UserQuery [label="1. User Query Received", shape=oval, fillcolor="#B3E5FC"];
    Orchestrator [label="Orchestrator Agent\n(Defines ResearchFindingsSchema)"];
    Researcher [label="Researcher Agent\n(Calls Tools)"];
    Synthesizer [label="Synthesizer Agent\n(Defines FinalReportSchema)"];
    FinalOutput [label="6. Final Report", shape=oval, fillcolor="#A5D6A7"];

    UserQuery -> Orchestrator [label="Delegation Request"];
    
    subgraph cluster_research {
        label = "Research Phase";
        style = "dashed";
        color = "#FFB74D";
        
        Orchestrator -> Researcher [label="2. Task Delegation (Requires ResearchFindingsSchema)"];
        Researcher -> Tool1 [label="Tool Call: Market Data"];
        Researcher -> Tool2 [label="Tool Call: Regulatory"];
        Tool1 [label="External Tool 1"];
        Tool2 [label="External Tool 2"];
        
        Researcher -> Validation1 [label="3. Raw Output"];
        Validation1 [label="Zod Validation Check 1", shape=diamond, fillcolor="#FFCC80"];
        
        Validation1 -> Researcher [label="Schema Mismatch (Retry/Refine)", style=dashed, color=red, constraint=false];
        Validation1 -> Orchestrator [label="4. Validated Findings Array"];
    }
    
    Orchestrator -> Synthesizer [label="5. Synthesis Request"];
    
    Synthesizer -> Validation2 [label="Draft Report"];
    Validation2 [label="Zod Validation Check 2", shape=diamond, fillcolor="#FFCC80"];
    
    Validation2 -> Synthesizer [label="Schema Mismatch (Refine)", style=dashed, color=red, constraint=false];
    Validation2 -> FinalOutput [label="Validated Final Report"];
}
