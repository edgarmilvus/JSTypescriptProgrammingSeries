/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2025 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

import { z } from 'zod';

/**
 * @fileoverview Defines the Zod schema and validation utility for user feature requests.
 * This is crucial for ensuring input integrity before data is used in system prompts or tool calls.
 */

// 1. Define the Zod Schema for a SaaS feature request
export const FeatureRequestSchema = z.object({
  /**
   * Identifies the user. Must be a UUID for system tracing and security.
   */
  userId: z.string().uuid('User ID must be a valid UUID format.'),

  /**
   * The core request description. Minimum length enforced to prevent empty requests.
   */
  featureName: z.string().min(5, 'Feature name must be at least 5 characters long.'),

  /**
   * The priority level, strictly limited to an enumeration.
   */
  priority: z.enum(['Low', 'Medium', 'High']).default('Medium'),

  /**
   * Optional detailed description for the LLM to analyze.
   */
  description: z.string().optional(),

  /**
   * Flag indicating if this request bypasses standard queues. Defaults to false.
   */
  isCritical: z.boolean().default(false),
});

// 2. Define the TypeScript type based on the schema for strong typing
export type FeatureRequest = z.infer<typeof FeatureRequestSchema>;

/**
 * Validates raw input data against the FeatureRequestSchema.
 * This function is typically called within an Edge or API route handler.
 *
 * @param data - The raw, untrusted input object (e.g., from request body).
 * @returns The validated and parsed FeatureRequest object.
 * @throws Error if validation fails, containing sanitized Zod error details.
 */
export function validateFeatureRequest(data: unknown): FeatureRequest {
  try {
    // Zod's .parse() method throws a ZodError if validation fails.
    // It also automatically applies defaults and cleans the object.
    return FeatureRequestSchema.parse(data);
  } catch (error) {
    // 3. Error Handling and Sanitization
    if (error instanceof z.ZodError) {
      // Log the detailed error for debugging purposes (server-side only)
      console.error("Validation failed:", JSON.stringify(error.errors, null, 2));

      // Re-throw a standardized, user-friendly error message.
      // We only expose the message of the first failed validation for brevity.
      throw new Error(`Input validation failed: ${error.errors[0].message}`);
    }
    // Handle unexpected errors (e.g., non-Zod errors)
    throw new Error('An unknown validation error occurred during input parsing.');
  }
}
