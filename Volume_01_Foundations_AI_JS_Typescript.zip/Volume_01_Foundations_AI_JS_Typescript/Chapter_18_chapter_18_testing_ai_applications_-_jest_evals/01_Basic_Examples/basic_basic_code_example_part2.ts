/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2025 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.ts
// Description: Basic Code Example
// ==========================================

import { validateFeatureRequest, FeatureRequest } from '../src/utils/inputValidator';

// 1. Setup: Define a consistent UUID for testing purposes
const MOCK_UUID = 'a1b2c3d4-e5f6-7890-1234-567890abcdef';

// 2. Grouping: Describe block for the validation utility
describe('Input Validator Utility (Zod & Jest Integration)', () => {

  // --- Test Case 1: Happy Path (Full, Valid Input) ---
  test('should successfully validate a complete and correct feature request', () => {
    // Arrange: Define the input data
    const validRequest: FeatureRequest = {
      userId: MOCK_UUID,
      featureName: 'Implement Dark Mode Toggle',
      priority: 'High',
      description: 'User accessibility requirement.',
      isCritical: true,
    };

    // Act & Assert: Execute the function and check the output
    const result = validateFeatureRequest(validRequest);

    // Jest Assertion 1: Check deep equality of the resulting object
    expect(result).toEqual(validRequest);

    // Jest Assertion 2: Check type safety (optional but good practice)
    expect(typeof result.userId).toBe('string');
  });

  // --- Test Case 2: Defaults Application (Minimal Input) ---
  test('should apply default values when optional fields are missing', () => {
    // Arrange: Define minimal input (missing priority, description, isCritical)
    const minimalRequest = {
      userId: MOCK_UUID,
      featureName: 'Faster Load Times',
    };

    // Act: Execute the function
    const result = validateFeatureRequest(minimalRequest);

    // Assert: Check if defaults were correctly injected by Zod
    expect(result.priority).toBe('Medium');
    expect(result.isCritical).toBe(false);

    // Assert: Check the full object structure
    const expectedOutput = {
      userId: MOCK_UUID,
      featureName: 'Faster Load Times',
      priority: 'Medium', // Default applied
      isCritical: false,   // Default applied
    };
    expect(result).toEqual(expectedOutput);
  });

  // --- Test Case 3: Error Path (Missing Required Field) ---
  test('should throw an error if a required field (featureName) is missing', () => {
    // Arrange: Invalid input missing 'featureName'
    const invalidRequest = {
      userId: MOCK_UUID,
      priority: 'Low',
    };

    // Act & Assert: Crucial Jest assertion for error handling
    // We wrap the function call in an anonymous function so Jest can catch the throw.
    expect(() => validateFeatureRequest(invalidRequest)).toThrow(
      'Input validation failed: Feature name must be at least 5 characters long.'
    );
  });

  // --- Test Case 4: Error Path (Invalid Format/Type) ---
  test('should throw an error if userId is not a valid UUID format', () => {
    // Arrange: Input with malformed userId
    const malformedRequest = {
      userId: 'not-a-uuid-format', // Invalid format
      featureName: 'Test Feature',
    };

    // Act & Assert: Check for the specific Zod message defined in the schema
    expect(() => validateFeatureRequest(malformedRequest)).toThrow(
      'Input validation failed: User ID must be a valid UUID format.'
    );
  });
});
