/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2025 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// --- src/ai-service.ts ---
import { z } from 'zod';

/**
 * @typedef {object} RetrievalInput
 * @property {string} context - The knowledge base context used for grounding the answer.
 * @property {string} question - The user's query.
 * @property {number} [maxTokens=512] - Maximum tokens for the response.
 */
export type RetrievalInput = z.infer<typeof RetrievalSchema>;

/**
 * Zod Schema for robust runtime validation of retrieval inputs.
 * This is crucial for security and ensuring the prompt structure is sound.
 */
export const RetrievalSchema = z.object({
    context: z.string().min(10, "Context must be substantial."),
    question: z.string().min(5, "Question must be meaningful."),
    maxTokens: z.number().int().min(10).max(1024).default(512).optional(),
});

/**
 * @function validateInput
 * @description Uses Zod to validate the incoming request payload.
 * @param {any} data - The raw input data.
 * @returns {RetrievalInput} - The validated, typed input.
 * @throws {z.ZodError} - If validation fails.
 */
export function validateInput(data: any): RetrievalInput {
    // Jest will test this deterministic logic thoroughly.
    return RetrievalSchema.parse(data);
}

/**
 * @function generateAnswer
 * @description Simulates the core LLM call, grounded in provided context.
 * In a real application, this would involve API calls (e.g., OpenAI, Anthropic).
 * @param {RetrievalInput} input - Validated input object.
 * @returns {Promise<string>} - The generated answer.
 */
export async function generateAnswer(input: RetrievalInput): Promise<string> {
    // In a production environment, this function would be heavily mocked
    // during unit testing to isolate external dependencies.
    console.log(`Processing question: ${input.question} with context length: ${input.context.length}`);

    // Mock LLM response based on a simple heuristic (for testing purposes)
    if (input.question.includes("architecture")) {
        return "The AI architecture relies on a decoupled microservice structure, utilizing the Edge Runtime for high-throughput streaming and Node.js (V8) for heavy data processing.";
    }
    if (input.question.includes("streaming")) {
         // Deliberately unfaithful answer to test the Eval later
        return "Streaming is handled via standard REST API calls, which is the most efficient method.";
    }
    return "I cannot provide a definitive answer based solely on the provided context.";
}


// --- tests/ai-service.test.ts ---
import { validateInput, generateAnswer, RetrievalInput } from '../src/ai-service';
import { z } from 'zod';

// Mocking a simplified LangChain.js Evaluator interface
interface EvalResult {
    score: number; // 1 for pass, 0 for fail
    reasoning: string;
    metric: string;
}

/**
 * @function FaithfulnessEvaluator
 * @description Simulates an Eval designed to check if the LLM output (prediction)
 * is factually supported by the provided context (input).
 * @param {string} prediction - The LLM's generated response.
 * @param {string} context - The source material provided to the LLM.
 * @param {string} referenceAnswer - The ideal, ground truth answer (optional but helpful).
 * @returns {EvalResult}
 */
const FaithfulnessEvaluator = (prediction: string, context: string): EvalResult => {
    // In a real scenario, this would use an LLM-as-a-judge prompt or a sophisticated NLP model.
    // Here, we use simple string checks for demonstration and deterministic testing.

    const contextKeywords = ["Edge Runtime", "streaming", "SSE"];
    let faithful = true;
    let reasoning = "The response appears accurate based on the context.";

    // Simple check: If the prediction mentions a concept contrary to the context's domain.
    if (prediction.includes("standard REST API calls") && context.includes("Server-Sent Events (SSE)")) {
        faithful = false;
        reasoning = "The prediction incorrectly states REST API calls are used for streaming, contradicting the context which implies SSE/Edge Runtime usage.";
    }

    const score = faithful ? 1 : 0;
    return { score, reasoning, metric: "Faithfulness" };
};

describe('Chapter 18: Testing AI Applications - Jest & Evals', () => {

    // --- Part 1: Jest Unit & Integration Testing (Deterministic Logic) ---

    describe('Zod Input Validation (Jest)', () => {
        const validPayload = {
            context: "The system uses SSE for streaming.",
            question: "How is streaming handled?",
            maxTokens: 256
        };

        it('1.1 Should successfully validate a correct payload', () => {
            expect(() => validateInput(validPayload)).not.toThrow();
            const validated = validateInput(validPayload);
            expect(validated.context).toBeDefined();
            expect(validated.maxTokens).toBe(256);
        });

        it('1.2 Should throw ZodError for context too short', () => {
            const invalid = { ...validPayload, context: "short" };
            expect(() => validateInput(invalid)).toThrow(z.ZodError);
        });

        it('1.3 Should throw ZodError for invalid maxTokens type', () => {
            const invalid = { ...validPayload, maxTokens: "500" };
            expect(() => validateInput(invalid)).toThrow(z.ZodError);
        });
    });

    // --- Part 2: LLM Output Evaluation (Non-Deterministic Logic via Evals) ---

    describe('LLM Output Evaluation (Evals)', () => {
        const context = "Our modern retrieval system leverages the V8 Engine architecture within the Edge Runtime for rapid execution. Streaming is exclusively handled via Server-Sent Events (SSE) to ensure low latency.";

        it('2.1 Should pass the Faithfulness Eval when the answer is grounded in context', async () => {
            const input: RetrievalInput = { context, question: "Describe the architecture." };
            const prediction = await generateAnswer(input);

            // The prediction should mention V8/Edge Runtime, confirming grounding.
            expect(prediction).toContain("Edge Runtime");

            const evalResult = FaithfulnessEvaluator(prediction, context);
            console.log(`Eval Result (Pass): ${evalResult.reasoning}`);

            // Asserting the Eval score
            expect(evalResult.score).toBe(1);
            expect(evalResult.metric).toBe("Faithfulness");
        });

        it('2.2 Should fail the Faithfulness Eval when the answer contradicts the context (Hallucination/Misinformation)', async () => {
            const input: RetrievalInput = { context, question: "How is streaming implemented?" };
            // The generateAnswer function is deliberately designed to return an unfaithful answer for this specific question.
            const prediction = await generateAnswer(input);

            // Check that the prediction contains the unfaithful statement
            expect(prediction).toContain("standard REST API calls");

            const evalResult = FaithfulnessEvaluator(prediction, context);
            console.log(`Eval Result (Fail): ${evalResult.reasoning}`);

            // Asserting the Eval score
            expect(evalResult.score).toBe(0);
            expect(evalResult.metric).toBe("Faithfulness");
        });
    });
});
