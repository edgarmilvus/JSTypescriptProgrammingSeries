
/*
 * These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
 * You can find the series on Amazon.
 * New books info: https://linktr.ee/edgarmilvus
 *
 * MIT License
 * Copyright (c) 2025 Edgar Milvus
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */

// Source File: solution_exercise_2.ts
// Description: Solution for Exercise 2
// ==========================================

// File: src/schemas/document.ts (Schema Definition)
import { z } from 'zod';

export const DocumentMetadataSchema = z.object({
  title: z.string(),
  keywords: z.array(z.string()).min(3).max(5),
  readingTimeMinutes: z.number().int(), // Must be an integer
});

// File: src/tests/llm_output.test.ts (Solution)
import { DocumentMetadataSchema } from '../schemas/document';

describe('LLM Structured Output Validation Pipeline', () => {
  // 1. Mock/Simulate LLM Response
  const mockValidJson = JSON.stringify({
    title: "Testing AI Evals",
    keywords: ["jest", "zod", "evals", "ai"],
    readingTimeMinutes: 7,
  });

  const mockInvalidJson = JSON.stringify({
    title: "Broken Output",
    keywords: ["a", "b", "c", "d", "e", "f"], // Too many keywords (max 5)
    readingTimeMinutes: "five", // Incorrect type (string instead of integer)
  });

  test('should successfully parse and validate a perfectly structured LLM response', () => {
    // Step 1: Parse the string output from the LLM
    const parsedObject = JSON.parse(mockValidJson);
    
    // Step 2: Validate against the Zod schema
    expect(() => DocumentMetadataSchema.parse(parsedObject)).not.toThrow();
    
    // Optional check: ensure the resulting type is correct
    const result = DocumentMetadataSchema.parse(parsedObject);
    expect(result.readingTimeMinutes).toBe(7);
  });

  test('should throw a Zod error when parsing structurally invalid LLM output', () => {
    const parsedObject = JSON.parse(mockInvalidJson);

    // Expect the validation step to fail
    expect(() => DocumentMetadataSchema.parse(parsedObject)).toThrow(
      'ZodError'
    );
  });

  test('should throw a Zod error and identify the specific field failures', () => {
    const parsedObject = JSON.parse(mockInvalidJson);
    
    // We use safeParse to inspect the specific errors
    const result = DocumentMetadataSchema.safeParse(parsedObject);
    expect(result.success).toBe(false);

    if (!result.success) {
      const errorPaths = result.error.issues.map(issue => issue.path.join('.'));
      
      // Asserting the specific failures: Too many keywords, wrong type for readingTime
      expect(errorPaths).toContain('keywords');
      expect(errorPaths).toContain('readingTimeMinutes');
      
      // Asserting the error message for readingTimeMinutes
      const readingTimeError = result.error.issues.find(i => i.path[0] === 'readingTimeMinutes');
      expect(readingTimeError?.message).toMatch(/Expected number, received string/);
    }
  });
});
