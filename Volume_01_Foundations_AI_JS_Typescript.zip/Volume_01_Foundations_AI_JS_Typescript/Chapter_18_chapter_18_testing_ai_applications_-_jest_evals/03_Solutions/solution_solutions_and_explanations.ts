/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2025 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// File: src/utils/validation.ts (Setup)
import { z } from 'zod';

export const ModelConfigSchema = z.object({
  temperature: z.number().min(0.0).max(1.0),
  maxTokens: z.number().int().min(50).max(2048),
  systemPrompt: z.string().optional(),
});

const PromptSchema = z.string()
  .min(10, "Prompt must be at least 10 characters long.")
  .max(500, "Prompt must not exceed 500 characters.");

export function validatePrompt(prompt: unknown): string {
  return PromptSchema.parse(prompt);
}

// File: src/utils/__tests__/validation.test.ts (Solution)
import { ModelConfigSchema, validatePrompt } from '../validation';

describe('Prompt Validation (validatePrompt)', () => {
  test('should successfully validate a valid prompt', () => {
    const validPrompt = 'This is a test prompt that is long enough.';
    expect(() => validatePrompt(validPrompt)).not.toThrow();
    expect(validatePrompt(validPrompt)).toBe(validPrompt);
  });

  test('should fail validation if prompt is too short', () => {
    const shortPrompt = 'Too short';
    expect(() => validatePrompt(shortPrompt)).toThrow(
      /Prompt must be at least 10 characters long/
    );
  });

  test.each([
    ['null', null],
    ['undefined', undefined],
    ['number', 12345],
  ])('should fail validation if input is %s (not a string)', (type, input) => {
    expect(() => validatePrompt(input)).toThrow(
      /Expected string, received/
    );
  });
});

describe('Model Configuration Schema Validation', () => {
  const validConfig = {
    temperature: 0.5,
    maxTokens: 512,
  };

  test('should successfully parse a valid configuration', () => {
    expect(() => ModelConfigSchema.parse(validConfig)).not.toThrow();
  });

  test('should succeed when optional systemPrompt is omitted', () => {
    expect(() => ModelConfigSchema.parse(validConfig)).not.toThrow();
  });

  test('should fail when temperature is out of range (too high)', () => {
    const invalidConfig = { ...validConfig, temperature: 1.5 };
    expect(() => ModelConfigSchema.parse(invalidConfig)).toThrow(
      /Number must be less than or equal to 1/
    );
  });

  test('should fail when maxTokens is a float instead of an integer', () => {
    const invalidConfig = { ...validConfig, maxTokens: 512.5 };
    expect(() => ModelConfigSchema.parse(invalidConfig)).toThrow(
      /Expected integer, received float/
    );
  });

  test('should fail when a required field (maxTokens) is missing', () => {
    const { maxTokens, ...missingConfig } = validConfig;
    expect(() => ModelConfigSchema.parse(missingConfig)).toThrow(
      /Required/
    );
  });
});
