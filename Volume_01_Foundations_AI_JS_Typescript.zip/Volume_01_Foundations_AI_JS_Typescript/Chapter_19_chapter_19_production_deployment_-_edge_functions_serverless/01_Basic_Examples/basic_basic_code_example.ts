/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2025 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

// api/edge/stream-summary.ts

// 1. Foundation Types: Using TypeScript Generics for robust type safety.
// Generics allow us to define a standard wrapper for responses, regardless of the data payload type.
/**
 * @template T The type of the data payload (e.g., string, object, array).
 * @typedef {object} EdgeResponse
 * @property {'success' | 'error'} status The outcome of the operation.
 * @property {T} data The primary data payload.
 */
type EdgeResponse<T> = {
  status: 'success' | 'error';
  data: T;
  timestamp: number;
};

// 2. Input Definition: What the client sends to the summarization endpoint.
interface RequestPayload {
  documentText: string;
  maxLength: number;
}

// 3. Output Definition: The structure of each individual chunk sent back in the stream.
interface StreamChunk {
  summaryPart: string;
  tokenCount: number;
}

// 4. Utility: A simple function to simulate network/LLM processing delay.
const delay = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

// 5. The Edge Function Handler: Must adhere to the Web Standard API (Request => Promise<Response>).
export default async function handler(request: Request): Promise<Response> {
  
  // 5a. Input Validation: Check HTTP Method.
  if (request.method !== 'POST') {
    const errorResponse: EdgeResponse<string> = {
      status: 'error',
      data: 'Method Not Allowed. This endpoint requires POST.',
      timestamp: Date.now(),
    };
    // Return a standard Response object with a 405 status.
    return new Response(JSON.stringify(errorResponse), { 
      status: 405, 
      headers: { 'Content-Type': 'application/json' } 
    });
  }

  let payload: RequestPayload;
  try {
    // 5b. Parse the incoming JSON body using request.json().
    // This is a standard Web API feature available in the Edge Runtime.
    payload = await request.json() as RequestPayload;
  } catch (e) {
    const errorResponse: EdgeResponse<string> = {
      status: 'error',
      data: 'Invalid or malformed JSON payload received.',
      timestamp: Date.now(),
    };
    return new Response(JSON.stringify(errorResponse), { status: 400, headers: { 'Content-Type': 'application/json' } });
  }

  const { documentText, maxLength } = payload;

  // 5c. Input Content Validation.
  if (!documentText || documentText.length < 50) {
    const errorResponse: EdgeResponse<string> = {
      status: 'error',
      data: 'Document text must be substantial (min 50 chars) for summarization.',
      timestamp: Date.now(),
    };
    return new Response(JSON.stringify(errorResponse), { status: 400, headers: { 'Content-Type': 'application/json' } });
  }

  // --- 6. Core Streaming Logic (The Edge Advantage) ---
  
  const encoder = new TextEncoder(); // Standard Web API utility for converting strings to bytes.
  let totalTokens = 0;

  // Create a ReadableStream. This object is the key to efficient streaming in the Edge Runtime.
  const stream = new ReadableStream({
    // The start function is called immediately when the stream is created.
    async start(controller) {
      
      // Simulate the data chunks received from an external LLM API (e.g., OpenAI's /v1/chat/completions stream)
      const simulatedChunks = [
        "The Edge Runtime is optimized for concurrent I/O. ",
        "It minimizes latency by avoiding traditional Node.js overhead. ",
        `Summarizing input of length ${documentText.length} and targeting ${maxLength} tokens. `,
        "This approach ensures users receive the summary results instantly, improving perceived performance. ",
        "Stream successfully terminated."
      ];

      for (const part of simulatedChunks) {
        // 6a. Simulate the inherent delay of waiting for the upstream LLM provider.
        // The Edge function remains active, proxying the connection without blocking the thread.
        await delay(75); 
        
        totalTokens += part.split(' ').length; 
        
        const chunkData: StreamChunk = {
          summaryPart: part,
          tokenCount: totalTokens,
        };
        
        // 6b. Encode the chunk data (usually JSON or SSE format) into bytes.
        // We append '\n' to create a sequence of newline-delimited JSON (NDJSON).
        controller.enqueue(encoder.encode(JSON.stringify(chunkData) + '\n'));
      }

      // 6c. Signal that the stream has finished sending data.
      controller.close();
    },
    // Optional: The cancel function can be implemented to clean up resources if the client disconnects early.
    cancel() {
      console.log("Client disconnected, stream cancelled.");
    }
  });

  // 7. Return the final Response object containing the stream.
  // The browser will immediately begin receiving data as it is generated by the stream controller.
  return new Response(stream, {
    status: 200,
    headers: {
      // NDJSON is a common format for structured streaming data.
      'Content-Type': 'application/x-ndjson', 
      // Critical headers to ensure the response is not buffered or cached by proxies.
      'Cache-Control': 'no-cache',
      'Connection': 'keep-alive',
    },
  });
}

// --- Client Simulation (Demonstrating Stream Consumption) ---

async function simulateClientCall() {
    console.log("--- Edge Function Client Simulation Started ---");
    const mockRequestPayload = {
        documentText: "The Edge Runtime, based on V8 isolates, provides a faster cold start time and lower operational overhead compared to standard Node.js serverless environments, making it ideal for proxying LLM requests that require streaming data back to the user.",
        maxLength: 100
    };

    // 8. Create a mock Request object to pass to the handler, simulating an actual network call.
    const mockEdgeRequest = new Request('https://api.saas.com/stream-summary', {
        method: 'POST',
        body: JSON.stringify(mockRequestPayload),
        headers: { 'Content-Type': 'application/json' }
    });

    const edgeResponse = await handler(mockEdgeRequest);

    if (edgeResponse.body) {
        console.log(`\n[API Response] Status: ${edgeResponse.status}`);
        console.log(`[API Response] Streaming Type: ${edgeResponse.headers.get('Content-Type')}\n`);
        
        // 9. Get the reader to consume the stream byte-by-byte.
        const reader = edgeResponse.body.getReader();
        const decoder = new TextDecoder();
        
        let done = false;
        let buffer = ''; // Buffer to handle incomplete chunks received over the network
        
        while (!done) {
            // Read returns an object containing the byte array (value) and the done status.
            const { value, done: streamDone } = await reader.read();
            done = streamDone;
            
            if (value) {
                // Decode the bytes and append to the buffer.
                buffer += decoder.decode(value, { stream: true });
                
                // Process complete lines (NDJSON is line-delimited)
                const lines = buffer.split('\n');
                buffer = lines.pop() || ''; // Keep the last, potentially incomplete line in the buffer

                lines.forEach(line => {
                    if (line.trim()) {
                        try {
                            // Parse the received JSON chunk
                            const chunk: StreamChunk = JSON.parse(line);
                            console.log(`[Token Count: ${chunk.tokenCount}] -> ${chunk.summaryPart.trim()}`);
                        } catch (e) {
                            // This catches cases where the LLM provider might send non-JSON data (e.g., error messages).
                            console.error("Client Error: Failed to parse chunk JSON:", line);
                        }
                    }
                });
            }
        }
        
        // Process any final remaining data in the buffer after the stream closes
        if (buffer.trim()) {
             try {
                const chunk: StreamChunk = JSON.parse(buffer);
                console.log(`[Token Count: ${chunk.tokenCount}] -> ${chunk.summaryPart.trim()} (Final Buffer)`);
            } catch (e) {
                console.error("Client Error: Failed to parse final buffer JSON:", buffer);
            }
        }
        
    } else {
        console.log("Non-streaming response or error:", await edgeResponse.text());
    }
    console.log("\n--- Client Simulation Finished ---");
}

// simulateClientCall(); // Uncomment to test the logic locally
