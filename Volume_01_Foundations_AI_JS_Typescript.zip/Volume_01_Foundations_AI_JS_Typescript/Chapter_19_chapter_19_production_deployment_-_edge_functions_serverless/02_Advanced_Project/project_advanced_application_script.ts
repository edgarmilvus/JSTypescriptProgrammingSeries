/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2025 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// api/summary-proxy.ts - Deployed to Edge Runtime

import { OpenAI } from 'openai';
import { env } from 'process';
import { NextRequest, NextResponse } from 'next/server'; // Vercel Edge Environment Types

// --- 1. Generics & Type Definitions ---
/**
 * @typedef {Object} EdgeResponse
 * @description A generic structure for standardized API responses, ensuring type safety.
 * @template T The type of the data payload.
 */
interface EdgeResponse<T> {
  status: 'success' | 'error';
  data: T | null;
  message: string;
}

/**
 * @typedef {Object} SummaryRequest
 * @description Defines the expected structure of the incoming JSON body.
 */
interface SummaryRequest {
  tenantId: string;
  documentText: string;
  maxLength: number;
}

// --- 2. Edge Configuration and Security Setup ---
// CRITICAL: Forces deployment to the low-latency V8 Isolate Edge Runtime.
export const config = {
  runtime: 'edge',
};

// Securely retrieve the OpenAI API key from environment variables.
// This key is protected within the execution environment and never exposed client-side.
const OPENAI_API_KEY = env.OPENAI_API_KEY;

if (!OPENAI_API_KEY) {
    // In a production setup, this would trigger a deployment failure or a 500 error immediately.
    console.error("CRITICAL ERROR: OPENAI_API_KEY environment variable is not set.");
}

// --- 3. Edge Handler Function (POST) ---
/**
 * @function POST
 * @description Handles incoming summarization requests, acts as a secure proxy, and streams the result.
 * @param {NextRequest} req The incoming HTTP request object.
 * @returns {Response} A streaming response object or a JSON error response.
 */
export async function POST(req: NextRequest) {
  // 3.1. Basic Authorization Check
  const authHeader = req.headers.get('Authorization');
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    // Using the generic type for the error response ensures strong typing even for failures.
    return NextResponse.json<EdgeResponse<null>>({
        status: 'error',
        data: null,
        message: 'Authentication required. Missing or invalid Bearer token.',
    }, { status: 401 });
  }

  // 3.2. Parse and Validate Request Body
  let body: SummaryRequest;
  try {
    // Type assertion using 'as SummaryRequest' relies on the Generics definition.
    body = await req.json() as SummaryRequest;
  } catch (error) {
    return NextResponse.json({ status: 'error', message: 'Invalid JSON payload format.' }, { status: 400 });
  }

  const { documentText, tenantId, maxLength } = body;

  // 3.3. Pre-flight Check (Input size mitigation)
  if (documentText.length > 50000) {
    // This check encourages the client to implement local Model Compression (e.g., chunking)
    // before attempting transmission, optimizing bandwidth and LLM token usage.
    return NextResponse.json({
        status: 'error',
        message: 'Document exceeds size limits. Implement pre-processing or Model Compression locally.',
    }, { status: 413 });
  }

  // 3.4. Prepare and Execute LLM Call
  try {
    const openai = new OpenAI({ apiKey: OPENAI_API_KEY });
    const systemPrompt = `You are a secure, high-speed summarization service for Tenant ID: ${tenantId}. Summarize the following text concisely, aiming for maximum ${maxLength} words. Output only the summary.`;

    // Crucial step: Requesting a stream to prevent serverless function timeouts.
    const responseStream = await openai.chat.completions.create({
      model: 'gpt-4o-mini', // Strategic choice: A smaller model (Model Compression benefit) reduces cold start latency.
      messages: [
        { role: 'system', content: systemPrompt },
        { role: 'user', content: documentText },
      ],
      stream: true,
    });

    // 3.5. Return the Stream directly
    // The Edge Runtime handles piping the streaming response back immediately.
    return new Response(responseStream.toReadableStream(), {
      headers: {
        'Content-Type': 'text/event-stream',
        'Cache-Control': 'no-cache', // Ensure the client receives data immediately
        'Connection': 'keep-alive',
      },
      status: 200,
    });

  } catch (error) {
    console.error(`OpenAI API Error for Tenant ${tenantId}:`, error);
    return NextResponse.json({
        status: 'error',
        message: 'Internal service error during LLM communication.',
    }, { status: 500 });
  }
}
