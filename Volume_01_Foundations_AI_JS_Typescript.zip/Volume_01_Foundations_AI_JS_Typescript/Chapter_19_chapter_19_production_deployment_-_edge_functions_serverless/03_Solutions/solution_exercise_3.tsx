
/*
 * These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
 * You can find the series on Amazon.
 * New books info: https://linktr.ee/edgarmilvus
 *
 * MIT License
 * Copyright (c) 2025 Edgar Milvus
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */

// Source File: solution_exercise_3.tsx
// Description: Solution for Exercise 3
// ==========================================

# The solution defines the structure and logic flow of the required React Client Component.

# --- React Component Definition (TypeScript/JavaScript Pseudo-code) ---

"""
import React, { useState, useEffect, useRef } from 'react';

// Define the critical thresholds
const TIMEOUT_WARNING_THRESHOLD = 20; // Seconds
const HARD_TIMEOUT = 45; // Seconds

interface StreamingLLMAction {
  (prompt: string): Promise<ReadableStream | { error: string }>;
}

interface StreamingLLMResponseMonitorProps {
  initialPrompt: string;
  llmAction: StreamingLLMAction; 
}

export const StreamingLLMResponseMonitor: React.FC<StreamingLLMResponseMonitorProps> = ({ 
    initialPrompt, 
    llmAction 
}) => {
    // State Management
    const [responseText, setResponseText] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [elapsedTime, setElapsedTime] = useState(0);
    const [error, setError] = useState<string | null>(null);
    const timerRef = useRef<NodeJS.Timeout | null>(null);

    // Function to initiate the streaming request
    const startStreaming = async (prompt: string) => {
        setIsLoading(true);
        setError(null);
        setResponseText('');
        setElapsedTime(0);

        // Start the elapsed time timer
        timerRef.current = setInterval(() => {
            setElapsedTime(prev => {
                const newTime = prev + 1;
                // 3. Graceful Timeout Handling (Client-Side)
                if (newTime >= HARD_TIMEOUT) {
                    clearInterval(timerRef.current!);
                    setIsLoading(false);
                    setError("Request Timed Out (45s limit reached). Please try simplifying your query.");
                    return HARD_TIMEOUT;
                }
                return newTime;
            });
        }, 1000);

        try {
            const result = await llmAction(prompt); // Invoke the Server Action

            if ('error' in result) {
                throw new Error(result.error);
            }
            
            // 1. Streaming Display: Process the ReadableStream
            const reader = result.getReader();
            let chunk;
            while (true) {
                chunk = await reader.read();
                if (chunk.done) break;
                const text = new TextDecoder().decode(chunk.value);
                setResponseText(prev => prev + text);
            }

        } catch (e: any) {
            setError(e.message || "A network or streaming error occurred.");
        } finally {
            if (timerRef.current) clearInterval(timerRef.current);
            setIsLoading(false);
        }
    };

    // Initialize the request on component mount
    useEffect(() => {
        startStreaming(initialPrompt);
        return () => {
            if (timerRef.current) clearInterval(timerRef.current);
        };
    }, [initialPrompt]);


    // Rendering Logic
    const showTimeoutWarning = elapsedTime >= TIMEOUT_WARNING_THRESHOLD && isLoading;
    const isRetryActive = error !== null && !isLoading;

    return (
        <div className="llm-monitor">
            {/* 2. Timeout Countdown Visualization */}
            <p className={showTimeoutWarning ? 'text-red-500' : 'text-gray-600'}>
                Elapsed Time: {elapsedTime}s 
                {showTimeoutWarning && " (Potential Serverless Timeout Risk)"}
            </p>

            {/* 1. Streaming Response Area */}
            <pre className="response-box">{responseText || (isLoading ? "..." : "Ready.")}</pre>

            {/* 4. Retry Mechanism */}
            {isRetryActive && (
                <button 
                    onClick={() => startStreaming(initialPrompt)} 
                    className="retry-button"
                >
                    Retry Request
                </button>
            )}
        </div>
    );
};
"""
