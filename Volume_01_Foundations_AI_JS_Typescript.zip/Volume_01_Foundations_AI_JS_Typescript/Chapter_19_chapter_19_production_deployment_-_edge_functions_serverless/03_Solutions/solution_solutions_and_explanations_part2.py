# These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
# You can find the series on Amazon.
# New books info: https://linktr.ee/edgarmilvus
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_solutions_and_explanations_part2.py
# Description: Solutions and Explanations
# ==========================================

# Edge Functions are fundamentally built on the V8 runtime (JavaScript/TypeScript).
# The solution is provided in the required TypeScript structure for the Edge environment.

# --- Edge Function Implementation (TypeScript/JavaScript Pseudo-code) ---

# /middleware.ts

"""
import { NextRequest, NextResponse } from 'next/server';

# 1. Edge Function Setup: Configuration ensures this runs at the Edge
export const config = {
  matcher: '/api/llm-inference', // Intercepts requests to the public endpoint
  runtime: 'edge', 
};

export async function middleware(request: NextRequest) {
  const requestClone = request.clone();
  
  try {
    # 1. Parse the incoming request body
    const data = await requestClone.json();
    const prompt = data.prompt || ''; 

    # 2. Low-Latency Validation: Check prompt length
    if (prompt.length < 5) {
      # 3. Edge Response: Immediate rejection (400 Bad Request)
      # This response is generated and served globally within milliseconds.
      return new NextResponse(
        JSON.stringify({ 
            success: false, 
            message: "Input too short. Request rejected at the Edge." 
        }),
        { status: 400, headers: { 'Content-Type': 'application/json' } }
      );
    }

    # 4. Proxying: Validation passed. Rewrite the request to the secure, 
    # potentially slower Serverless function for LLM invocation.
    const secureServerlessUrl = new URL('/api/secure-serverless-llm', request.url);
    
    # NextResponse.rewrite is crucial as it keeps the original request headers 
    # and body intact while changing the destination URL internally.
    return NextResponse.rewrite(secureServerlessUrl);

  } catch (error) {
    # Handle JSON parsing errors before reaching the backend
    return new NextResponse(
      JSON.stringify({ success: false, message: "Invalid request format." }),
      { status: 400, headers: { 'Content-Type': 'application/json' } }
    );
  }
}
"""
