# These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
# You can find the series on Amazon.
# New books info: https://linktr.ee/edgarmilvus
#
# MIT License
# Copyright (c) 2025 Edgar Milvus
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# Source File: solution_solutions_and_explanations_part4.py
# Description: Solutions and Explanations
# ==========================================

from pydantic import BaseModel, Field, ValidationError
from typing import Optional, Dict, Any
import json

# 1. Define the Zod/Pydantic Validator (Equivalent to Zod schema in Python)
class InventoryLookupSchema(BaseModel):
    """
    Pydantic schema for validating LLM-generated arguments.
    """
    product_id: str = Field(
        ..., 
        description="The unique identifier (SKU or ID) of the product to look up.",
        min_length=1
    )
    quantity: Optional[int] = Field(
        1, 
        description="The quantity to check availability for. Must be a positive integer.",
        ge=1 # Must be greater than or equal to 1
    )

# 2. Define the Function Calling Schema (JSON structure for OpenAI)
FUNCTION_CALLING_SCHEMA = {
    "name": "inventory_lookup",
    "description": "Looks up the current stock and pricing for a specific product.",
    "parameters": InventoryLookupSchema.model_json_schema(),
}

# 3. Serverless Validation Logic
def tool_executor(raw_llm_args: Dict[str, Any]) -> Dict[str, Any]:
    """
    Simulates a secure Serverless function that validates raw LLM arguments.
    """
    print(f"\n--- Processing Raw Arguments: {raw_llm_args} ---")
    try:
        # Attempt to validate and parse the raw data using the Pydantic model
        validated_args = InventoryLookupSchema.model_validate(raw_llm_args)
        
        # Case A: Success
        print(f"Validation Success. Arguments are secure.")
        return {
            "status": "success",
            "message": "Arguments validated successfully.",
            "data": validated_args.model_dump()
        }

    except ValidationError as e:
        # Case B & C: Handle validation errors
        error_details = e.errors()
        print(f"Validation Failure detected.")
        
        # Return a structured error response detailing the validation failure
        return {
            "status": "error",
            "message": "Function arguments failed schema validation.",
            "details": [
                {"field": err['loc'][0], "error": err['msg']} 
                for err in error_details
            ]
        }

# --- Interactive Challenge Testing ---

# Case A (Success): Valid arguments
tool_executor({"product_id": "SKU-90210", "quantity": 5})

# Case B (Type Error): LLM provided quantity as a string ("five")
tool_executor({"product_id": "SKU-404", "quantity": "five"})

# Case C (Missing Required Field): product_id is missing
tool_executor({"quantity": 10})
