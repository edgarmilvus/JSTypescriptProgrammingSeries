/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2025 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

import { z, ZodSchema } from 'zod';

// --- 1. GENERIC INTERFACES AND TYPES (Production Readiness) ---

/**
 * @description Generic structure for all AI service responses in the SaaS.
 * T represents the specific output data type. This standardizes the API contract.
 */
interface AIResponse<T> {
  success: boolean;
  data: T | null;
  error: string | null;
  processingTimeMs: number;
}

// --- 2. ZOD SCHEMAS FOR INPUT/OUTPUT INTEGRITY (SaaS API Contract) ---

// Define the generic input schema (Base Request)
const BaseAIRequestSchema = z.object({
  userId: z.string().uuid("Invalid user ID format."),
  prompt: z.string().min(10, "Prompt must be at least 10 characters."),
});

// Specific Input Schema Example: Blog Title Generation
const BlogTitleInputSchema = BaseAIRequestSchema.extend({
  topic: z.string().min(3, "Topic is required."),
  style: z.enum(["Formal", "Casual", "Hype"]),
});
type BlogTitleInput = z.infer<typeof BlogTitleInputSchema>;

// Specific Output Schema Example: Blog Title Result
const BlogTitleOutputSchema = z.object({
  generatedTitle: z.string(),
  keywordsUsed: z.array(z.string()),
});
type BlogTitleOutput = z.infer<typeof BlogTitleOutputSchema>;

// --- 3. THE CORE GENERIC, TYPE-SAFE PROCESSOR ---

/**
 * @description A generic, high-level utility function to handle AI requests.
 * It ensures strict type checking on input (via Zod) and output (via Generics).
 * @template TInputSchema The Zod schema type used for input validation.
 * @template TOutput The expected type of the AI result data.
 * @param inputSchema The Zod schema for validating the incoming request body.
 * @param processor The actual function that interacts with the AI model (e.g., LangChain agent).
 * @param rawInput The raw, untrusted data received from the API endpoint (e.g., req.body).
 * @returns A strongly typed AIResponse object.
 */
async function safeProcessAIRequest<TInputSchema extends ZodSchema, TOutput>(
  inputSchema: TInputSchema,
  processor: (validatedInput: z.infer<TInputSchema>) => Promise<TOutput>,
  rawInput: unknown
): Promise<AIResponse<TOutput>> {
  const startTime = Date.now();

  try {
    // Step 1: Input Validation (The Zod Guard)
    const validationResult = inputSchema.safeParse(rawInput);

    if (!validationResult.success) {
      // Return structured error on validation failure
      return {
        success: false,
        data: null,
        error: `Input validation failed: ${validationResult.error.errors.map(e => e.message).join(', ')}`,
        processingTimeMs: Date.now() - startTime,
      };
    }

    // Zod guarantees that validatedInput now conforms to the TInputSchema type
    const validatedInput = validationResult.data;

    // Step 2: AI Processing (Simulated Call)
    console.log(`[Processor] Validated Input for User ${validatedInput.userId}:`, validatedInput);
    const resultData = await processor(validatedInput);
    
    // NOTE: For true capstone robustness, the resultData should be validated 
    // against a TOutput Zod schema here, guarding against LLM output errors.

    // Step 3: Success Response
    return {
      success: true,
      data: resultData,
      error: null,
      processingTimeMs: Date.now() - startTime,
    };

  } catch (e) {
    // Step 4: System/Runtime Error Handling
    const errorMessage = e instanceof Error ? e.message : "An unknown internal server error occurred.";
    return {
      success: false,
      data: null,
      error: `Internal AI Service Error: ${errorMessage}`,
      processingTimeMs: Date.now() - startTime,
    };
  }
}

// --- 4. IMPLEMENTATION EXAMPLE (The SaaS Feature API Endpoint Logic) ---

/**
 * @description Simulates the actual call to the LLM (e.g., LangChain agent logic).
 * This function receives guaranteed, strictly validated input.
 * @param input The strictly validated BlogTitleInput.
 * @returns A promise resolving to the BlogTitleOutput structure.
 */
async function blogTitleGenerator(input: BlogTitleInput): Promise<BlogTitleOutput> {
  // Simulate complex AI workflow (API call, prompt engineering, multi-step agent)
  await new Promise(resolve => setTimeout(resolve, 500)); // Simulate 500ms latency (Warm Start)

  const title = `The Ultimate Guide to ${input.topic} in a ${input.style} Style`;
  const keywords = input.topic.split(' ').concat(input.style.toLowerCase()).filter(k => k.length > 2);

  return {
    generatedTitle: title,
    keywordsUsed: keywords,
  };
}

// --- 5. DEMONSTRATION OF USAGE ---

async function runDemo() {
  console.log("--- Demo 1: Successful Request (Strictly Typed) ---");
  const goodInput = {
    userId: 'a1b2c3d4-e5f6-7890-1234-567890abcdef',
    prompt: 'Generate 5 catchy titles for a blog post about TypeScript generics.',
    topic: 'TypeScript Generics in SaaS',
    style: 'Hype',
  };

  const successfulResult = await safeProcessAIRequest(
    BlogTitleInputSchema,
    blogTitleGenerator,
    goodInput
  );

  console.log("Processing Time:", successfulResult.processingTimeMs, "ms");
  console.log("Result:", successfulResult);
  if (successfulResult.success) {
    // TypeScript knows successfulResult.data is BlogTitleOutput because of the generic TOutput
    console.log(`Generated Title: ${successfulResult.data.generatedTitle}`);
    console.log(`Keywords Used: ${successfulResult.data.keywordsUsed.join(', ')}`);
  }


  console.log("\n--- Demo 2: Failed Request (Input Validation Error) ---");
  const badInput = {
    userId: 'invalid-uuid', // Fails UUID validation
    prompt: 'Too short', // Fails min length validation
    topic: 123, // Fails type validation (expected string)
    style: 'UnknownStyle', // Fails enum validation
  };

  const failedResult = await safeProcessAIRequest(
    BlogTitleInputSchema,
    blogTitleGenerator,
    badInput
  );

  console.log("Processing Time:", failedResult.processingTimeMs, "ms");
  console.log("Result:", failedResult);
  if (!failedResult.success) {
    console.log(`Error Details: ${failedResult.error}`);
  }
}

runDemo();
