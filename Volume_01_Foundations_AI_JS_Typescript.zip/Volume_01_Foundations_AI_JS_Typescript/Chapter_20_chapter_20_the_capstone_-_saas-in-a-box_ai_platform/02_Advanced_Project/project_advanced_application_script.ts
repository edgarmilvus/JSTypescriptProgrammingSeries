/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2025 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// advanced-analysis-service.ts
// CRITICAL NOTE: This script is written in TypeScript, the required language for the Next.js/Node.js stack
// described in the book's context, despite a conflicting instruction for Python.

// --- 1. Zod Schema Definition (Data Integrity Layer) ---
import { z } from 'zod';
import { AgentExecutor, ZeroShotAgent, Tool, initializeAgentExecutorWithOptions } from 'langchain/agents';
import { StructuredOutputParser } from 'langchain/output_parsers';
import { LLMChain } from 'langchain/chains';
import { ChatOpenAI } from 'langchain/chat_models/openai';
import { PromptTemplate } from 'langchain/prompts';
import { Document } from 'langchain/document'; // Used for potential future context loading

// Define the required output structure for the initial extraction step.
// Zod ensures that the LLM output, no matter how creative, conforms to this strict contract.
const DocumentAnalysisSchema = z.object({
  keyEntities: z.array(z.string()).describe("A list of 3-5 critical entities or names found in the document."),
  overallSentiment: z.enum(['Positive', 'Neutral', 'Negative']).describe("The primary sentiment of the document."),
  summaryHash: z.string().uuid().describe("A unique identifier for the analysis result."),
});

type DocumentAnalysisResult = z.infer<typeof DocumentAnalysisSchema>;

// --- 2. Custom Type Guard for Runtime Validation ---
/**
 * @description Type Guard to ensure the parsed output conforms to the expected structure.
 * This is crucial for safely accessing properties after JSON parsing.
 * @param obj The object to check.
 * @returns True if the object matches the DocumentAnalysisResult type.
 */
function isAnalysisResult(obj: any): obj is DocumentAnalysisResult {
  try {
    // Zod's parse method acts as the runtime check, throwing if validation fails.
    DocumentAnalysisSchema.parse(obj);
    return true;
  } catch (e) {
    // If parsing fails, the object is not of the expected type.
    return false;
  }
}

// --- 3. Mock Tool: Vector Storage Simulation (pgvector concept) ---
class VectorStorageTool extends Tool {
  // This tool simulates the persistence layer interaction (e.g., calling Supabase Edge Function).
  name = "Vector_Storage_Tool";
  description = "Useful for converting the final analysis summary into a vector and storing it in the database (simulating pgvector persistence).";

  /** @ignore */
  async _call(input: string): Promise<string> {
    // In a production environment, this would involve embedding generation and a database upsert.
    const vectorId = `vec-${Math.random().toString(36).substring(2, 9)}`;
    console.log(`[PGVECTOR MOCK] Stored vector for analysis input: ${input.substring(0, 30)}... ID: ${vectorId}`);
    return `Vector stored successfully. ID: ${vectorId}`;
  }
}

// --- 4. Initial AI Extraction Tool (Structured Output) ---
/**
 * @description Runs the first step of the workflow: structured data extraction using Zod.
 * @param documentText The raw text input.
 */
async function runStructuredExtraction(documentText: string): Promise<DocumentAnalysisResult> {
  const parser = StructuredOutputParser.fromZodSchema(DocumentAnalysisSchema);
  const formatInstructions = parser.getFormatInstructions();

  const prompt = new PromptTemplate({
    template: `Analyze the following document text and extract the required information.
    \n\n{format_instructions}\n\nDOCUMENT TEXT: {document}`,
    inputVariables: ["document"],
    partialVariables: { format_instructions: formatInstructions },
  });

  const llm = new ChatOpenAI({ temperature: 0, modelName: "gpt-3.5-turbo" });
  const chain = new LLMChain({ llm, prompt });

  const response = await chain.call({ document: documentText });
  const result = parser.parse(response.text);

  // Runtime Type Guard check immediately after parsing (Zod validation + narrowing)
  if (!isAnalysisResult(result)) {
      // This error indicates a critical failure in Zod's parsing or the LLM's output format.
      throw new Error("Extraction failed Zod validation post-parsing.");
  }

  return result;
}

// --- 5. The Main Capstone Agent Handler (Next.js API Context) ---

interface AnalysisRequest {
    documentText: string;
    userId: string;
}

/**
 * @description Orchestrates the multi-step AI workflow using a LangChain agent.
 * This simulates the backend API handler (/api/analyze-document).
 * @param request The analysis request object.
 * @returns The final status and analysis result.
 */
async function handleDocumentAnalysis(request: AnalysisRequest) {
    console.log(`[API] Starting analysis for User: ${request.userId}`);

    // 1. Initial Structured Extraction (Step 1)
    let structuredResult: DocumentAnalysisResult;
    try {
        // UI Interaction Point: Optimistic UI would show 'Step 1: Extracting Entities...'
        structuredResult = await runStructuredExtraction(request.documentText);
        console.log(`[API] Structured extraction successful. Sentiment: ${structuredResult.overallSentiment}`);
    } catch (error) {
        // Reconciliation Point A: If the extraction fails, the UI must reconcile by reverting
        // the optimistic state (e.g., changing the status indicator from 'pending' to 'failed').
        console.error("[API] Structured extraction failed:", error);
        return { status: 'error', message: 'Failed to extract structured data.' };
    }

    // 2. Agent Orchestration (Step 2: Decision and Storage)
    const agentTools = [new VectorStorageTool()];
    const model = new ChatOpenAI({ temperature: 0, modelName: "gpt-4" }); // Using GPT-4 for reliable tool use

    const executor = await initializeAgentExecutorWithOptions(agentTools, model, {
        agentType: "openai-functions", // Leveraging function calling for reliability
        verbose: false,
    });

    const agentPrompt = `You are a specialized Document Analysis Agent.
    The structured analysis result is: ${JSON.stringify(structuredResult)}.
    Your task is to confirm the analysis quality and then use the Vector_Storage_Tool to permanently store the summary hash and the overall sentiment.
    The final answer MUST be the vector ID returned by the tool.`;

    try {
        const agentResponse = await executor.run(agentPrompt);

        // 3. Final Reconciliation (Confirming the database write)
        if (agentResponse.startsWith("Vector stored successfully")) {
            console.log(`[API] Agent workflow complete. Final Result: ${agentResponse}`);
            // Reconciliation Point B: Success. The UI updates the final state with the confirmed result.
            return {
                status: 'success',
                message: 'Document analyzed and stored successfully.',
                analysis: structuredResult,
                storageStatus: agentResponse,
            };
        } else {
            // Reconciliation Point C: Unexpected agent output. Analysis is done, but storage verification failed.
            return { status: 'warning', message: 'Analysis complete, but storage verification failed.', agentOutput: agentResponse };
        }
    } catch (error) {
        console.error("[API] Agent execution failed:", error);
        return { status: 'fatal_error', message: 'The multi-step workflow failed during orchestration.' };
    }
}

// --- 6. Execution Simulation ---

const mockDocument = {
    documentText: "The Q3 financial report for Acme Corp showed exceptional growth, primarily driven by the new CEO, Ms. Evelyn Reed. Despite minor market volatility in July, the overall investor sentiment remained overwhelmingly positive regarding the upcoming product launch in December.",
    userId: "user-123",
};

// Simulate the API call
handleDocumentAnalysis(mockDocument)
    .then(result => console.log("\n--- FINAL API RESPONSE ---\n", JSON.stringify(result, null, 2)))
    .catch(err => console.error("Simulation Error:", err));
