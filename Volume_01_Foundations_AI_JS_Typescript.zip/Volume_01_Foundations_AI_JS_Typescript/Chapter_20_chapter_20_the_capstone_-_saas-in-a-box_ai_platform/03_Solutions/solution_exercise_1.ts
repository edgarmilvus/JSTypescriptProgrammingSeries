
/*
 * These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
 * You can find the series on Amazon.
 * New books info: https://linktr.ee/edgarmilvus
 *
 * MIT License
 * Copyright (c) 2025 Edgar Milvus
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */

// Source File: solution_exercise_1.ts
// Description: Solution for Exercise 1
// ==========================================

import { z } from 'zod';

// 1. Define Complex Zod Schemas
const ProductionReportSchema = z.object({
  status: z.enum(['SUCCESS', 'FAILURE']).describe("Overall status of the AI transaction."),
  summary: z.string().describe("A comprehensive summary of the research."),
  metadata: z.object({
    timestamp: z.string().datetime().describe("ISO 8601 timestamp of completion."),
    keywords: z.array(z.string()).min(3, "Must include at least 3 keywords."),
  }).describe("Structured metadata about the report."),
});

const FailureSchema = z.object({
  code: z.enum(['SCHEMA_VIOLATION', 'INTERNAL_ERROR', 'TIMEOUT']),
  message: z.string().describe("A user-friendly description of the failure."),
  details: z.record(z.string(), z.any()).optional().describe("Technical details for debugging."),
});

type ProductionReport = z.infer<typeof ProductionReportSchema>;
type FailureReport = z.infer<typeof FailureSchema>;

// Mock Agent Execution Function (Simulates LangChain structured output)
// This function fails on attempt 1, indicating a schema violation (missing keywords).
async function executeStructuredAgent(topic: string, attempt: number): Promise<ProductionReport> {
  console.log(`[Agent] Starting execution attempt ${attempt} for topic: ${topic}`);
  
  if (attempt === 1) {
    // Simulate LLM output that violates the Zod schema (keywords min length failure)
    const rawOutput = {
      status: "SUCCESS",
      summary: `Initial draft summary for ${topic}. Missing required metadata structure.`,
      metadata: { 
        timestamp: new Date().toISOString(),
        keywords: ["incomplete"], // Fails min(3) check
      }
    };
    
    try {
        return ProductionReportSchema.parse(rawOutput);
    } catch (e) {
        throw new Error(`Zod validation failed: ${e instanceof z.ZodError ? e.errors[0].message : "Unknown error"}`);
    }
  }

  // Simulation: Successful output on attempt 2 (after receiving the "fix your format" instruction)
  const successfulOutput = {
    status: "SUCCESS",
    summary: `Final, validated summary for ${topic}. The format is now correct.`,
    metadata: {
      timestamp: new Date().toISOString(),
      keywords: ["SaaS", "AI", "Integrity", topic],
    },
  };
  return ProductionReportSchema.parse(successfulOutput);
}

// 2. & 3. Transactional Wrapper with Retries
async function runTransactionalAgent(topic: string): Promise<ProductionReport | FailureReport> {
  const MAX_RETRIES = 2;
  let lastError: Error | null = null;

  for (let attempt = 1; attempt <= MAX_RETRIES; attempt++) {
    try {
      // In a real LangChain setup, the prompt would be dynamically adjusted on retry
      const result = await executeStructuredAgent(topic, attempt);
      return result; 
    } catch (error) {
      lastError = error as Error;
      console.warn(`[Agent Runner] Attempt ${attempt} failed. Retrying...`);
    }
  }

  // 4. Structured Failure Output
  return FailureSchema.parse({
    code: 'SCHEMA_VIOLATION',
    message: `AI transaction failed. Agent could not produce valid structured output after ${MAX_RETRIES} attempts.`,
    details: {
      originalError: lastError?.message || 'Unknown validation error.',
      schemaExpected: ProductionReportSchema.description,
      // In a real system, we would log the full failed LLM output here
    }
  });
}

// Example Execution (simulated API usage):
// runTransactionalAgent("Optimizing Serverless Cold Starts").then(result => {
//   console.log("\n--- Final API Response ---");
//   console.log(JSON.stringify(result, null, 2));
// });
