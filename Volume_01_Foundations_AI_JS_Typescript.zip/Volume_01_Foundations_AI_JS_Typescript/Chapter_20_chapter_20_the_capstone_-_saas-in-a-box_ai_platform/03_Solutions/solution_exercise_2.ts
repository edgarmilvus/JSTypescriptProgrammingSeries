
/*
 * These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
 * You can find the series on Amazon.
 * New books info: https://linktr.ee/edgarmilvus
 *
 * MIT License
 * Copyright (c) 2025 Edgar Milvus
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */

// Source File: solution_exercise_2.ts
// Description: Solution for Exercise 2
// ==========================================

// Edge API Route: app/api/stream/route.ts

// 1. Edge Runtime Configuration
export const runtime = 'edge';

// Mock OpenAI Stream Generator (simulates the async iterator provided by LLM SDKs)
async function* mockOpenAIStreamGenerator() {
  const tokens = ["The", " quick", " brown", " fox", " jumps", " over", " the", " lazy", " dog."];
  for (const token of tokens) {
    await new Promise(resolve => setTimeout(resolve, 50)); // Simulate token delay
    yield token;
  }
}

// 5. Integrity Check Variables (must be tracked outside the stream handler)
let requestStartTime: number;
let firstChunkTime: number | null = null;

export async function POST(req: Request) {
  requestStartTime = Date.now();

  const encoder = new TextEncoder();
  
  // 3. ReadableStream Construction
  const stream = new ReadableStream({
    async start(controller) {
      try {
        // 2. Streaming Implementation: Get the LLM async iterator
        const iterator = mockOpenAIStreamGenerator();

        for await (const chunk of iterator) {
          if (!firstChunkTime) {
            firstChunkTime = Date.now();
            // 5. Streaming Integrity Check Logging
            console.log(`[Edge Log] Request received: ${requestStartTime}ms`);
            console.log(`[Edge Log] First token sent: ${firstChunkTime}ms`);
            console.log(`[Edge Log] Time-to-First-Token (TTFT): ${firstChunkTime - requestStartTime}ms`);
          }
          
          // Map the raw token string to binary data (Uint8Array)
          controller.enqueue(encoder.encode(chunk));
        }
        
        controller.close();
      } catch (e) {
        console.error("Streaming pipeline error:", e);
        controller.error(e);
      }
    },
  });

  // 4. Response Handling
  return new Response(stream, {
    status: 200,
    headers: {
      // Using text/plain for raw tokens, but text/event-stream is common for richer streams
      'Content-Type': 'text/plain', 
      'Cache-Control': 'no-cache, no-transform',
      'Connection': 'keep-alive',
    },
  });
}
