
/*
 * These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
 * You can find the series on Amazon.
 * New books info: https://linktr.ee/edgarmilvus
 *
 * MIT License
 * Copyright (c) 2025 Edgar Milvus
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */

// Source File: solution_exercise_4.ts
// Description: Solution for Exercise 4
// ==========================================

// WASM Integration Layer (TypeScript/JavaScript)

// 1. WASM Module Integration Setup (Requires WASM binary file)
// const wasmBytes = fetch('vector_processor.wasm').then(res => res.arrayBuffer()); 

// Shared memory definition
const VECTOR_LENGTH = 768; // 3072 bytes total
const VECTOR_BYTE_SIZE = VECTOR_LENGTH * 4; 
const WASM_MEMORY_PAGES = Math.ceil((2 * VECTOR_BYTE_SIZE) / (64 * 1024)); // Calculate required pages

const memory = new WebAssembly.Memory({ initial: WASM_MEMORY_PAGES });

const importObject = {
  env: {
    memory: memory,
  },
};

let calculateSimilarity: (ptrA: number, ptrB: number, length: number) => number;
let float32View: Float32Array;

// Pointers for writing vectors into WASM memory
const PTR_A = 0; 
const PTR_B = VECTOR_BYTE_SIZE; 

async function initializeWasm(wasmBytes: ArrayBuffer) {
  const { instance } = await WebAssembly.instantiate(wasmBytes, importObject);
  
  // Link to the exported SIMD function
  calculateSimilarity = instance.exports.calculate_similarity as 
    (ptrA: number, ptrB: number, length: number) => number;
  
  // Create a view over the shared memory buffer
  float32View = new Float32Array(memory.buffer);
}

// 2. 3. Memory Management and Optimized Call Wrapper
function wasmOptimizedSimilarity(vecA: Float32Array, vecB: Float32Array): number {
  if (!calculateSimilarity) throw new Error("WASM not initialized.");

  // Write vecA to memory starting at PTR_A (offset in elements: 0)
  float32View.set(vecA, PTR_A / 4); 
  
  // Write vecB to memory starting at PTR_B (offset in elements: VECTOR_LENGTH)
  float32View.set(vecB, PTR_B / 4); 

  // Call the WASM SIMD function
  const similarityScore = calculateSimilarity(PTR_A, PTR_B, VECTOR_LENGTH);
  
  return similarityScore;
}

// 4. Integration into LangChain RAG Tool (Conceptual)
interface DocumentEmbedding { id: string; vector: Float32Array; }

async function ragToolVectorSearch(queryVector: Float32Array, documents: DocumentEmbedding[], k: number) {
    if (documents.length === 0) return [];

    const similarities = documents.map(doc => ({
        id: doc.id,
        // *** WASM SIMD call replaces slow JS loop here ***
        score: wasmOptimizedSimilarity(queryVector, doc.vector), 
    }));

    return similarities.sort((a, b) => b.score - a.score).slice(0, k);
}

// 5. Verification: Benchmark Structure
function runBenchmark(iterations: number, jsFunc: Function, wasmFunc: Function, vecA: Float32Array, vecB: Float32Array) {
    // --- Native JS Loop Implementation (Simulation) ---
    const startJS = performance.now();
    for (let i = 0; i < iterations; i++) { jsFunc(vecA, vecB); }
    const durationJS = performance.now() - startJS;

    // --- WASM SIMD Implementation ---
    const startWASM = performance.now();
    for (let i = 0; i < iterations; i++) { wasmFunc(vecA, vecB); }
    const durationWASM = performance.now() - startWASM;
    
    console.log(`Native JS Time for ${iterations} ops: ${durationJS.toFixed(2)}ms`);
    console.log(`WASM SIMD Time for ${iterations} ops: ${durationWASM.toFixed(2)}ms`);
    console.log(`Speedup: ${(durationJS / durationWASM).toFixed(2)}x`);
}
