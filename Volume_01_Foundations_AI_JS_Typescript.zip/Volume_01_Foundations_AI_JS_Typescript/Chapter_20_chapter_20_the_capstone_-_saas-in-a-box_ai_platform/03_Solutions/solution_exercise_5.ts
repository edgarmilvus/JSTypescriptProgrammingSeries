
/*
 * These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
 * You can find the series on Amazon.
 * New books info: https://linktr.ee/edgarmilvus
 *
 * MIT License
 * Copyright (c) 2025 Edgar Milvus
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */

// Source File: solution_exercise_5.ts
// Description: Solution for Exercise 5
// ==========================================

// Edge API Route: app/api/resilient-stream/route.ts

export const runtime = 'edge';

// 1. Failure Simulation: Custom Error
class ExternalAPITimeoutError extends Error {
  name = 'ExternalAPITimeoutError';
}

// Mock Agent/Chain Simulation
async function* mockStreamingAgent(topic: string) {
  yield "The research for " + topic + " is complete. "; // Step 1: Success
  
  // Step 2: Summarization (Potential Failure Point)
  const tokens = ["Now", " generating", " the", " detailed", " summary..."];
  for (let i = 0; i < tokens.length; i++) {
    const token = tokens[i];
    yield token;
    
    // 1. Failure Simulation (30% chance after 3 tokens)
    if (i === 2 && Math.random() < 0.3) {
      throw new ExternalAPITimeoutError("External tool failed mid-execution.");
    }
    await new Promise(resolve => setTimeout(resolve, 10)); 
  }

  // Step 3 (Success Path):
  yield "Final structure generated.";
}

export async function POST(req: Request) {
  const encoder = new TextEncoder();
  const topic = "Stream Resilience Test"; 
  let accumulatedPartialOutput = ""; // Tracks what was successfully streamed

  const stream = new ReadableStream({
    async start(controller) {
      const agentIterator = mockStreamingAgent(topic);

      try {
        for await (const chunk of agentIterator) {
          accumulatedPartialOutput += chunk;
          controller.enqueue(encoder.encode(chunk));
        }
        
        controller.close(); // Successful completion

      } catch (error) {
        // 2. Stream Interruption and Error Handling
        if (error instanceof ExternalAPITimeoutError) {
          
          // 4. Partial State Logging
          console.error(`[SERVER LOG] Agent Failure: ${error.message}`);
          console.log(`[SERVER LOG] Partial Output (100 chars): "${accumulatedPartialOutput.substring(0, 100)}..."`);
          
          // 3. Graceful Client Notification (Structured Termination Signal)
          const terminationSignal = JSON.stringify({
            error: "TIMEOUT",
            message: "AI workflow interrupted. Partial result displayed.",
            partial: true,
            step: "Summarization",
          });
          
          // Write the structured error chunk to the stream
          controller.enqueue(encoder.encode(`\n\n###STREAM_ERROR###${terminationSignal}###END_ERROR###`));
          
          // Stop piping tokens and close the stream gracefully
          controller.close();
        } else {
          // Handle unknown internal errors
          controller.error(error);
        }
      }
    },
  });

  return new Response(stream, {
    status: 200,
    headers: { 'Content-Type': 'text/plain' },
  });
}
