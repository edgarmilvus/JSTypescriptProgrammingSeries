/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2025 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

// React Component: StructuredStreamRenderer.tsx
import React, { useState, useEffect } from 'react';
import { z } from 'zod';
// Assuming ReactMarkdown is installed:
// import ReactMarkdown from 'react-markdown'; 

interface StructuredStreamRendererProps {
  streamUrl: string;
  schema: z.ZodSchema<any>;
}

const METADATA_START = '###METADATA_START###';
const METADATA_END = '###METADATA_END###';

function StructuredStreamRenderer({ streamUrl, schema }: StructuredStreamRendererProps) {
  const [rawText, setRawText] = useState<string>('');
  const [metadata, setMetadata] = useState<any>(null);
  const [validationError, setValidationError] = useState<string | null>(null);
  const [statusMessage, setStatusMessage] = useState<string | null>(null);

  useEffect(() => {
    let accumulatedText = '';
    let isMetadataExtracted = false;

    const readStream = async () => {
      try {
        const response = await fetch(streamUrl);
        if (!response.body) return;

        const reader = response.body.getReader();
        const decoder = new TextDecoder();

        while (true) {
          const { done, value } = await reader.read();
          if (done) break;

          const chunk = decoder.decode(value, { stream: true });
          accumulatedText += chunk;
          
          // 2. Progressive Rendering
          // Update state only with the non-metadata content
          setRawText(accumulatedText.split(METADATA_START)[0]); 
          
          // 5. Tool Use Visualization
          if (chunk.includes("> Tool Used:")) {
              const toolMatch = chunk.match(/> Tool Used: (.*?)\n/);
              if (toolMatch) {
                  setStatusMessage(`Agent Action: ${toolMatch[1]}`);
                  setTimeout(() => setStatusMessage(null), 1800);
              }
          }

          // 3. Embedded Data Extraction & 4. Client-Side Zod Validation
          if (!isMetadataExtracted && accumulatedText.includes(METADATA_END)) {
            const startIdx = accumulatedText.indexOf(METADATA_START);
            const endIdx = accumulatedText.indexOf(METADATA_END);

            if (startIdx !== -1 && endIdx !== -1) {
              const jsonString = accumulatedText.substring(
                startIdx + METADATA_START.length, endIdx
              ).trim();
              isMetadataExtracted = true;

              try {
                const parsedJson = JSON.parse(jsonString);
                const validatedData = schema.parse(parsedJson); // Zod Validation
                setMetadata(validatedData);
                setValidationError(null);
                
              } catch (e) {
                console.error("Client-side validation failed:", e);
                setValidationError("Data integrity error: Structured metadata failed validation.");
              }
            }
          }
        }
      } catch (error) {
        setValidationError(`Stream connection error: ${error instanceof Error ? error.message : 'Unknown error'}`);
      }
    };

    readStream();
  }, [streamUrl, schema]);

  return (
    <div className="structured-renderer">
      {statusMessage && <div className="status-bar">{statusMessage}</div>}
      
      {metadata && (
        <div className="metadata-panel">
          <h4>Validated Report Metadata</h4>
          {/* Render structured data fields */}
          <p>Status: {metadata.status}</p>
          <p>Keywords: {metadata.metadata.keywords.join(', ')}</p>
        </div>
      )}

      <div className="content-area">
        {/* Replace with <ReactMarkdown> in a real app */}
        <pre>{rawText}</pre> 
      </div>

      {validationError && (
        <div className="error-banner">{validationError}</div>
      )}
    </div>
  );
}
// export default StructuredStreamRenderer;
