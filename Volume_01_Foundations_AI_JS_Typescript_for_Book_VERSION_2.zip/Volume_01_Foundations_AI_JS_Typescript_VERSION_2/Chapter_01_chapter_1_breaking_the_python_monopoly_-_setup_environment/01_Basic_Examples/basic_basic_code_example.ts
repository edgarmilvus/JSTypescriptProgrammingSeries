/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * @fileoverview Immutable State Management Example
 * Demonstrates how to manage application state (specifically AI model configurations)
 * in an immutable manner using TypeScript.
 * 
 * Context: SaaS Web Application managing user AI preferences.
 */

// 1. Define the shape of our state using a TypeScript Interface.
// This ensures type safety for our AI configuration objects.
interface AIModelConfig {
    id: string;
    modelName: string;
    temperature: number; // Controls randomness (0.0 to 1.0)
    maxTokens: number;
    isActive: boolean;
}

// 2. Define the initial state of our application.
// In a real app, this might come from a database or local storage.
// We use 'as const' to make the object deeply immutable at the type level (readonly).
const initialConfig: AIModelConfig = {
    id: "model-001",
    modelName: "GPT-4-Turbo",
    temperature: 0.7,
    maxTokens: 4096,
    isActive: true,
} as const;

/**
 * Updates a specific property of the AI configuration immutably.
 * 
 * @param currentConfig - The current configuration object (readonly).
 * @param updates - An object containing the properties to update.
 * @returns A NEW configuration object with the merged updates.
 * 
 * Why this is immutable:
 * We use the spread operator (...) to create a shallow copy of 'currentConfig'.
 * Then, we overlay the 'updates'. The original 'currentConfig' remains untouched.
 */
function updateConfig(
    currentConfig: AIModelConfig, 
    updates: Partial<AIModelConfig>
): AIModelConfig {
    // Create a new object by spreading the current properties
    // and then applying the updates. This overwrites the matching keys.
    return {
        ...currentConfig,
        ...updates,
    };
}

/**
 * Toggles the active status of the model.
 * 
 * @param config - The current configuration.
 * @returns A new configuration object with 'isActive' flipped.
 */
function toggleModelStatus(config: AIModelConfig): AIModelConfig {
    return {
        ...config,
        isActive: !config.isActive,
    };
}

/**
 * Main execution function to demonstrate the concept.
 * In a web app, this logic would be part of a state manager (like Redux, Zustand, or React Context).
 */
function main() {
    console.log("--- Initial State ---");
    console.log(JSON.stringify(initialConfig, null, 2));

    // 3. Simulate a user changing the temperature setting in the UI.
    // We pass the current state and the desired changes to our update function.
    const updatedConfig = updateConfig(initialConfig, { temperature: 0.5 });

    console.log("\n--- After Updating Temperature ---");
    console.log(JSON.stringify(updatedConfig, null, 2));

    // 4. Verify Immutability: Check if the original object was modified.
    // If 'initialConfig' changed, our function is NOT immutable.
    console.log("\n--- Verification of Immutability ---");
    console.log(`Original Temperature: ${initialConfig.temperature}`); // Should still be 0.7
    console.log(`Updated Temperature:  ${updatedConfig.temperature}`);   // Should be 0.5
    
    if (initialConfig.temperature === 0.7) {
        console.log("✅ SUCCESS: Original state remains unchanged (Immutable).");
    } else {
        console.error("❌ FAILURE: Original state was mutated.");
    }

    // 5. Simulate a complex operation: Toggling status and changing model name.
    // We chain operations, creating a new state at each step.
    const finalConfig = toggleModelStatus(
        updateConfig(updatedConfig, { modelName: "GPT-4o-Mini" })
    );

    console.log("\n--- Final Chained State ---");
    console.log(JSON.stringify(finalConfig, null, 2));
    console.log(`Is Active: ${finalConfig.isActive}`);
}

// Execute the main function
main();
