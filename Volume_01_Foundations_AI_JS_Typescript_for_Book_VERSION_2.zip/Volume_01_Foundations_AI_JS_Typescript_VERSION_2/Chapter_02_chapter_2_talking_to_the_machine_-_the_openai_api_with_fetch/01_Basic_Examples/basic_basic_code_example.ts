/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

// File: openai-hello-world.ts
// Requires: npm install openai
// Requires: OPENAI_API_KEY environment variable

import OpenAI from 'openai';

/**
 * Configuration for the OpenAI client.
 * In a production SaaS app, NEVER hardcode secrets.
 * Use environment variables (e.g., process.env.OPENAI_API_KEY).
 */
const configuration = {
  apiKey: process.env.OPENAI_API_KEY,
};

// 1. Initialize the OpenAI Client
// The SDK handles the underlying HTTP requests, headers, and JSON parsing.
const openai = new OpenAI(configuration);

/**
 * A simple asynchronous function to generate text based on a prompt.
 * This represents the core logic of a backend API endpoint.
 * 
 * @param prompt - The user input string to send to the AI.
 * @returns The generated text content from the AI.
 */
async function generateHelloWorldResponse(prompt: string): Promise<string> {
  try {
    // 2. Construct the API Request
    // We use the chat completions endpoint (gpt-3.5-turbo or gpt-4).
    // Messages are an array of objects with 'role' and 'content'.
    const completion = await openai.chat.completions.create({
      model: 'gpt-3.5-turbo', // The specific AI model to use
      messages: [
        { role: 'system', content: 'You are a helpful assistant.' }, // Context for the AI
        { role: 'user', content: prompt }, // The user's specific request
      ],
      temperature: 0.7, // Controls randomness (0.0 to 2.0)
    });

    // 3. Parse the Response
    // The API returns a complex object. We extract the message content.
    const responseMessage = completion.choices[0]?.message?.content;

    if (!responseMessage) {
      throw new Error('No response content generated.');
    }

    return responseMessage;

  } catch (error) {
    // 4. Error Handling
    // In a SaaS app, log errors internally but return safe messages to the client.
    console.error('Error communicating with OpenAI:', error);
    throw new Error('Failed to generate response from AI.');
  }
}

// 5. Execution (Simulating a Server Route)
(async () => {
  const userPrompt = "Explain the concept of 'Hello World' in programming in one sentence.";
  
  console.log(`User Prompt: ${userPrompt}`);
  
  try {
    const aiResponse = await generateHelloWorldResponse(userPrompt);
    console.log(`AI Response: ${aiResponse}`);
  } catch (err) {
    console.error(err);
  }
})();
