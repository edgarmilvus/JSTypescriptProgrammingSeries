/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// 1. Define Interfaces for Type Safety
interface ChatMessage {
  role: 'system' | 'user' | 'assistant';
  content: string;
}

interface OpenAIResponse {
  choices: {
    message: {
      content: string;
    };
  }[];
}

interface OpenAIErrorPayload {
  error: {
    message: string;
    type: string;
    code: string;
  };
}

// 2. Define Custom Error Classes
class RateLimitError extends Error {
  public retryAfter: number;

  constructor(message: string, retryAfter: number = 60) {
    super(message);
    this.name = 'RateLimitError';
    this.retryAfter = retryAfter;
  }
}

class OpenAIError extends Error {
  public code: string;

  constructor(message: string, code: string) {
    super(message);
    this.name = 'OpenAIError';
    this.code = code;
  }
}

// 3. The Main Fetch Function
async function fetchChatCompletion(
  apiKey: string,
  messages: ChatMessage[]
): Promise<string> {
  const url = 'https://api.openai.com/v1/chat/completions';

  try {
    const response = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        model: 'gpt-3.5-turbo',
        messages: messages,
      }),
    });

    // Handle Rate Limiting (429)
    if (response.status === 429) {
      const retryAfterHeader = response.headers.get('retry-after');
      const retryAfter = retryAfterHeader ? parseInt(retryAfterHeader, 10) : 60;
      throw new RateLimitError('Too Many Requests', retryAfter);
    }

    // Handle other non-OK responses
    if (!response.ok) {
      const errorData: OpenAIErrorPayload = await response.json();
      throw new OpenAIError(
        errorData.error.message,
        errorData.error.code || 'UNKNOWN'
      );
    }

    // Parse Success
    const data: OpenAIResponse = await response.json();
    const content = data.choices[0]?.message?.content;
    
    if (!content) {
      throw new Error('No content in response');
    }

    return content;

  } catch (error) {
    // Re-throw custom errors, wrap others
    if (error instanceof RateLimitError || error instanceof OpenAIError) {
      throw error;
    }
    // Handle JSON parsing errors or network failures
    if (error instanceof SyntaxError) {
        throw new Error('Failed to parse JSON response');
    }
    throw new Error(`Network or unknown error: ${error}`);
  }
}

// 4. Interactive Challenge: Exponential Backoff Wrapper
async function fetchWithBackoff(
  apiKey: string,
  messages: ChatMessage[],
  maxRetries: number = 3
): Promise<string> {
  let attempt = 0;

  while (attempt < maxRetries) {
    try {
      console.log(`Attempt ${attempt + 1}...`);
      const result = await fetchChatCompletion(apiKey, messages);
      return result;
    } catch (error) {
      if (error instanceof RateLimitError) {
        attempt++;
        // Calculate wait time: 1s, 2s, 4s...
        const waitTime = error.retryAfter * 1000 * Math.pow(2, attempt - 1); 
        console.warn(`Rate limited. Retrying in ${waitTime / 1000}s...`);
        
        if (attempt >= maxRetries) {
            throw new Error(`Max retries (${maxRetries}) exceeded due to rate limits.`);
        }
        
        await new Promise(resolve => setTimeout(resolve, waitTime));
      } else {
        // For non-rate-limit errors, fail immediately
        throw error;
      }
    }
  }
  
  throw new Error('Unexpected flow control');
}

// Example Usage (Mocked for demonstration)
/*
const API_KEY = 'sk-...'; 
const messages: ChatMessage[] = [{ role: 'user', content: 'Hello' }];

fetchWithBackoff(API_KEY, messages)
  .then(console.log)
  .catch(console.error);
*/
