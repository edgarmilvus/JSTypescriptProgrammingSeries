/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

import OpenAI from 'openai';
import { z } from 'zod';
import { zodResponseFormat } from 'openai/helpers/zod';

// 1. Define the Zod Schema
const ActionItemSchema = z.object({
  actionItems: z.array(
    z.object({
      title: z.string().describe("The title of the action item"),
      assignee: z.string().describe("The person responsible"),
      dueDate: z.string().datetime().describe("ISO 8601 date string"),
    })
  ),
});

// Type inference for later use
type ActionItem = z.infer<typeof ActionItemSchema>;

// 2. Initialize OpenAI Client
const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

// 3. The Extraction Function
async function extractActionItems(
  transcript: string,
  strict: boolean = false
): Promise<ActionItem> {
  
  const systemPrompt = `
    Extract action items from the meeting transcript.
    ${strict ? 'Output ONLY valid JSON.' : 'Output a JSON object.'}
    Ensure dates are in ISO 8601 format.
  `;

  // 4. Prepare the Request
  const completionParams: OpenAI.Chat.ChatCompletionCreateParams = {
    model: 'gpt-3.5-turbo',
    messages: [
      { role: 'system', content: systemPrompt },
      { role: 'user', content: `Transcript: ${transcript}` },
    ],
    temperature: 0.1, // Lower temp for consistency
  };

  // 5. Apply Strict JSON Mode if requested
  if (strict) {
    // Using the experimental Zod helper for newer SDK versions, 
    // or standard response_format for older ones.
    // For this exercise, we use the explicit JSON mode parameter.
    completionParams.response_format = { type: 'json_object' };
    
    // Note: In production with newer SDKs, you might use:
    // completionParams.response_format = zodResponseFormat(ActionItemSchema, 'action_items');
  }

  // 6. Call the API
  const completion = await openai.chat.completions.create(completionParams);

  const content = completion.choices[0].message.content;

  if (!content) {
    throw new Error('No content returned from AI');
  }

  // 7. Parse with Zod
  try {
    // Parse the string content as JSON first, then validate with Zod
    const rawJson = JSON.parse(content);
    const validatedData = ActionItemSchema.parse(rawJson);
    return validatedData;
  } catch (error) {
    if (error instanceof z.ZodError) {
      console.error('Zod Validation Errors:', error.errors);
      throw new Error(`Structured output failed validation: ${JSON.stringify(error.errors)}`);
    }
    if (error instanceof SyntaxError) {
      throw new Error('AI returned invalid JSON');
    }
    throw error;
  }
}

// Example Usage
/*
const transcript = "Meeting with John: He will update the API docs by Friday. Sarah needs to review the PR.";
extractActionItems(transcript, true)
  .then(data => console.log('Extracted:', data))
  .catch(err => console.error(err));
*/
