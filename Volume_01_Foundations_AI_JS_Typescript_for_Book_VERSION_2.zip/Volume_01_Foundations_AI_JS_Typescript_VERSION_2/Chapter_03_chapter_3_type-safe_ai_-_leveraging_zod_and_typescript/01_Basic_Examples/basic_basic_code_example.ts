/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

// Import Zod. In a real project, this would be installed via npm i zod
import { z } from 'zod';

// 1. DEFINE THE SCHEMA
// We define a schema that represents the expected shape of a user profile.
// This schema is the single source of truth for both runtime validation and static type inference.
const UserProfileSchema = z.object({
  // 'username' must be a string, at least 3 characters long.
  // .trim() removes whitespace, .toLowerCase() normalizes casing.
  username: z.string().min(3).trim().toLowerCase(),

  // 'email' must be a valid email format.
  email: z.string().email(),

  // 'age' is optional. If provided, it must be a number between 13 and 120.
  // We use .optional() to allow the field to be omitted.
  age: z.number().min(13).max(120).optional(),

  // 'preferences' is an object with a specific structure.
  // 'notifications' is required and must be a boolean.
  preferences: z.object({
    notifications: z.boolean(),
  }),
});

// 2. INFERENCE OF TYPESCRIPT TYPES
// We use Zod's `.infer` utility type to derive a static TypeScript type from the schema.
// This ensures our TypeScript types and runtime validation rules are always in sync.
type UserProfile = z.infer<typeof UserProfileSchema>;

// 3. VALIDATION FUNCTION
// This function takes unknown data, validates it against the schema,
// and returns either the typed data or a formatted error object.
function validateUserProfile(input: unknown): { success: true; data: UserProfile } | { success: false; errors: string[] } {
  // Attempt to parse the input against the schema.
  const result = UserProfileSchema.safeParse(input);

  if (result.success) {
    // If validation succeeds, return a success object with the typed data.
    // `result.data` is now guaranteed to be of type `UserProfile`.
    return { success: true, data: result.data };
  } else {
    // If validation fails, extract user-friendly error messages.
    // Zod's `format()` method organizes errors by field path.
    const formattedErrors = result.error.format();
    const errorMessages: string[] = [];

    // Iterate over the error keys to build a readable error list.
    Object.keys(formattedErrors).forEach((key) => {
      const fieldError = formattedErrors[key as keyof typeof formattedErrors];
      if (fieldError && typeof fieldError === 'object' && '_errors' in fieldError) {
        errorMessages.push(`${key}: ${fieldError._errors.join(', ')}`);
      }
    });

    return { success: false, errors: errorMessages };
  }
}

// 4. EXAMPLE USAGE
// Simulating a scenario where we receive data from a form or API.
const rawInputData: unknown = {
  username: '  john_doe  ', // Contains whitespace and uppercase
  email: 'john.doe@example.com',
  age: 25,
  preferences: {
    notifications: true,
  },
};

// Validate the input
const validationResult = validateUserProfile(rawInputData);

// Handle the result based on the validation outcome
if (validationResult.success) {
  // TypeScript knows `validationResult.data` is of type `UserProfile`.
  // We can safely access its properties without runtime checks.
  const { username, email, age, preferences } = validationResult.data;
  console.log('✅ Validation Successful!');
  console.log(`   Username: ${username}`); // Output: john_doe (trimmed and lowercased)
  console.log(`   Email: ${email}`);
  console.log(`   Age: ${age}`);
  console.log(`   Notifications: ${preferences.notifications}`);
} else {
  // TypeScript knows `validationResult.errors` is an array of strings.
  console.log('❌ Validation Failed:');
  validationResult.errors.forEach((error) => console.log(`   - ${error}`));
}

// 5. DEMONSTRATING TYPE-SAFE INFERENCE
// The `UserProfile` type is automatically generated from the schema.
// This means if we change the schema, the type updates automatically.
const typedUser: UserProfile = {
  username: 'jane_doe',
  email: 'jane@example.com',
  preferences: { notifications: false },
}; // Age is optional, so it's omitted here.

// If we try to assign an invalid object, TypeScript will catch it at compile time.
// Uncomment the line below to see a TypeScript error:
// const invalidUser: UserProfile = { email: 'invalid-email' }; // Error: Property 'username' is missing.
