/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// pages/api/analyze-feedback.ts
// Next.js API Route for Type-Safe Feedback Analysis

import type { NextApiRequest, NextApiResponse } from 'next';
import { z } from 'zod';
import { OpenAI } from 'langchain/llms/openai';
import { StructuredOutputParser } from 'langchain/output_parsers';
import { PromptTemplate } from 'langchain/prompts';

/**
 * SECTION 1: SCHEMA DEFINITION
 * We define a Zod schema to represent the structured data we expect from the LLM.
 * This serves as the "Single Source of Truth" for our data structure.
 * 
 * Why Zod? It allows us to infer TypeScript types automatically (Type Inference)
 * while providing runtime validation capabilities.
 */
const FeedbackAnalysisSchema = z.object({
  // Enum validation ensures the LLM picks one of the allowed categories
  category: z.enum(['BUG', 'FEATURE_REQUEST', 'UI_FEEDBACK', 'GENERAL_INQUIRY']),
  
  // A numeric score between 1 and 10, parsed as a string by LLM, converted to number
  sentimentScore: z.number().min(1).max(10),
  
  // Boolean flag indicating urgency
  isUrgent: z.boolean(),
  
  // Summary of the feedback, capped at 200 characters
  summary: z.string().max(200),
});

// Infer the TypeScript type from the Zod schema using .infer
// This allows us to use 'FeedbackAnalysis' as a type throughout our app without duplication.
export type FeedbackAnalysis = z.infer<typeof FeedbackAnalysisSchema>;

/**
 * SECTION 2: PROMPT ENGINEERING & PARSER SETUP
 * We utilize LangChain's StructuredOutputParser to bridge the gap between
 * unstructured LLM text and our strict Zod schema.
 */
const parser = StructuredOutputParser.fromZodSchema(FeedbackAnalysisSchema);

// The prompt instructs the LLM to adhere strictly to the schema format.
// We inject the parser's format instructions to guide the LLM.
const prompt = new PromptTemplate({
  template: `
    You are an AI assistant analyzing customer feedback for a SaaS platform.
    Analyze the following user input and categorize it strictly according to the schema provided.
    
    User Input: {feedback}
    
    {format_instructions}
  `,
  inputVariables: ['feedback'],
  partialVariables: { format_instructions: parser.getFormatInstructions() },
});

/**
 * SECTION 3: API HANDLER
 * The main request handler. It orchestrates the LLM call and validation.
 */
export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse<FeedbackAnalysis | { error: string }>
) {
  // Strict HTTP Method check
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method Not Allowed' });
  }

  // Input Sanitization: We expect a JSON body with a 'feedback' string.
  const rawInput = req.body.feedback;

  if (!rawInput || typeof rawInput !== 'string') {
    return res.status(400).json({ error: 'Invalid input: "feedback" string is required.' });
  }

  try {
    // Initialize the LLM (Ensure OPENAI_API_KEY is in your .env.local)
    const model = new OpenAI({ 
      temperature: 0.1, // Low temperature for deterministic categorization
      modelName: 'gpt-3.5-turbo' 
    });

    // Chain the prompt and model
    const chain = prompt.pipe(model).pipe(parser);

    // Invoke the chain. The output is already parsed into an object by LangChain.
    // However, we will perform an additional validation pass for maximum safety.
    const rawOutput = await chain.invoke({ feedback: rawInput });

    /**
     * SECTION 4: RUNTIME VALIDATION (The Critical Step)
     * Even though LangChain parsed the output, we run it through Zod again.
     * This catches any subtle type mismatches (e.g., "8" vs 8) or schema drift.
     * 
     * Type Narrowing occurs inside the .parse() method. If it throws, we know the type is invalid.
     * If it succeeds, TypeScript knows 'rawOutput' is of type 'FeedbackAnalysis'.
     */
    const validatedAnalysis = FeedbackAnalysisSchema.parse(rawOutput);

    // Return the strictly typed object
    res.status(200).json(validatedAnalysis);

  } catch (error) {
    // Error Handling: Distinguishing between Zod errors and other errors
    if (error instanceof z.ZodError) {
      console.error('Validation Failed:', error.errors);
      return res.status(422).json({ 
        error: 'LLM output failed validation. Data structure was inconsistent.' 
      });
    }
    
    console.error('Internal Error:', error);
    res.status(500).json({ error: 'Internal Server Error during analysis.' });
  }
}
