/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

import { z } from 'zod';

// 1. Define the TypeScript interface (optional, as Zod infers it, but good for explicit type definitions)
export interface UserRegistration {
  username: string;
  email: string;
  password: string;
  age?: number;
}

// 2. Create the Zod schema with specific constraints
const userRegistrationSchema = z.object({
  username: z
    .string()
    .min(3, { message: "Username must be at least 3 characters long" })
    .regex(/^[a-zA-Z0-9]+$/, { message: "Username must be alphanumeric only" }),
  
  email: z
    .string()
    .email({ message: "Invalid email format" }),
  
  password: z
    .string()
    .min(8, { message: "Password must be at least 8 characters long" })
    .regex(/[A-Z]/, { message: "Password must contain at least one uppercase letter" })
    .regex(/[a-z]/, { message: "Password must contain at least one lowercase letter" })
    .regex(/[0-9]/, { message: "Password must contain at least one number" })
    .regex(/[^A-Za-z0-9]/, { message: "Password must contain at least one special character" }),
  
  age: z
    .number()
    .int()
    .min(18, { message: "You must be at least 18 years old" })
    .max(120, { message: "Age cannot exceed 120" })
    .optional()
});

// 3. Function to parse and sanitize input
export function parseUserInput(input: unknown): UserRegistration {
  try {
    // safeParse returns an object with success boolean and data or error
    // Here we use parse() to throw an error directly if validation fails
    const validatedData = userRegistrationSchema.parse(input);
    return validatedData;
  } catch (error) {
    if (error instanceof z.ZodError) {
      // Format errors for readability
      const formattedErrors = error.errors.map(err => 
        `${err.path.join('.')}: ${err.message}`
      ).join(', ');
      
      throw new Error(`Validation failed: ${formattedErrors}`);
    }
    // Re-throw unexpected errors
    throw error;
  }
}

// 4. Demonstration with malicious input
/*
const rawInput = { 
  username: 'a', 
  email: 'invalid-email', 
  password: '123', 
  age: 15 
};

try {
  parseUserInput(rawInput);
} catch (e) {
  console.error(e.message);
  // Output: Validation failed: username: Username must be at least 3 characters long, email: Invalid email format, password: Password must be at least 8 characters long, age: You must be at least 18 years old
}
*/
