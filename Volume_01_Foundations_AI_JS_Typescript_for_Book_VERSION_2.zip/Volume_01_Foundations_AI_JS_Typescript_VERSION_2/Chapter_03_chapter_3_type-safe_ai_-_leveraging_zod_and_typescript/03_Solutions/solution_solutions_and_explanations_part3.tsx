/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState, useTransition } from 'react';
import { z } from 'zod';

// 1. Define the Zod schema
const itinerarySchema = z.object({
  destination: z.string().min(2, "Destination must be at least 2 characters"),
  budget: z.number().positive("Budget must be a positive number"),
  dates: z.object({
    start: z.string().refine((date) => !isNaN(Date.parse(date)), "Invalid start date"),
    end: z.string().refine((date) => !isNaN(Date.parse(date)), "Invalid end date"),
  }).refine((data) => new Date(data.end) > new Date(data.start), {
    message: "End date must be after start date",
    path: ["end"],
  }),
});

type ItineraryForm = z.infer<typeof itinerarySchema>;

interface SmartFormProps {
  onSubmit: (data: ItineraryForm) => void | Promise<void>;
}

// 2. Create the SmartForm Component
export const SmartForm: React.FC<SmartFormProps> = ({ onSubmit }) => {
  // Local state for form fields
  const [form, setForm] = useState({
    destination: '',
    budget: '',
    start: '',
    end: ''
  });
  
  // State for validation errors
  const [errors, setErrors] = useState<Record<string, string>>({});
  
  // 5. useTransition for handling submission state
  const [isPending, startTransition] = useTransition();

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setForm(prev => ({ ...prev, [name]: value }));
    // Optional: Clear error on change
    if (errors[name]) setErrors(prev => ({ ...prev, [name]: '' }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Prepare data for validation (converting budget to number)
    const rawData = {
      destination: form.destination,
      budget: Number(form.budget),
      dates: { start: form.start, end: form.end }
    };

    // 4. Validate using Zod
    const result = itinerarySchema.safeParse(rawData);

    if (!result.success) {
      // Map Zod errors to a display-friendly object
      const fieldErrors: Record<string, string> = {};
      result.error.errors.forEach(err => {
        const path = err.path[0]; // e.g., 'destination', 'dates.end'
        fieldErrors[path] = err.message;
      });
      setErrors(fieldErrors);
      return;
    }

    // If valid, trigger the submission wrapped in startTransition
    startTransition(() => {
      onSubmit(result.data);
    });
  };

  return (
    <form onSubmit={handleSubmit} className="smart-form">
      <div>
        <label>Destination:</label>
        <input name="destination" value={form.destination} onChange={handleChange} />
        {errors.destination && <span className="error">{errors.destination}</span>}
      </div>

      <div>
        <label>Budget ($):</label>
        <input name="budget" type="number" value={form.budget} onChange={handleChange} />
        {errors.budget && <span className="error">{errors.budget}</span>}
      </div>

      <div>
        <label>Start Date:</label>
        <input name="start" type="date" value={form.start} onChange={handleChange} />
        {errors.start && <span className="error">{errors.start}</span>}
      </div>

      <div>
        <label>End Date:</label>
        <input name="end" type="date" value={form.end} onChange={handleChange} />
        {/* Handle nested path error display */}
        {errors.end && <span className="error">{errors.end}</span>}
      </div>

      <button type="submit" disabled={isPending}>
        {isPending ? 'Planning...' : 'Plan Trip'}
      </button>
    </form>
  );
};
