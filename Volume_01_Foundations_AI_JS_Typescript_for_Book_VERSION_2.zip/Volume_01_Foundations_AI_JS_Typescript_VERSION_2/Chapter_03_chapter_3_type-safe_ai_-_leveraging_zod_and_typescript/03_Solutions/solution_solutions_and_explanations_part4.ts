/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

import { z } from 'zod';

// 1. Define the generic Result type (Discriminated Union)
type Success<T> = { status: 'success'; data: T };
type Failure<E> = { status: 'failure'; error: E };
export type Result<T, E = Error> = Success<T> | Failure<E>;

// 2. Define the Zod schema for the LLM response
const llmResponseSchema = z.object({
  content: z.string(),
  confidence: z.number().min(0).max(1),
});

type LLMResponse = z.infer<typeof llmResponseSchema>;

// 3. Simulate an async LLM API call
async function simulatedLLMCall(prompt: string): Promise<LLMResponse> {
  // Simulate network delay
  await new Promise(resolve => setTimeout(resolve, 500));
  
  // Simulate a potential failure or success
  if (prompt.includes("fail")) {
    throw new Error("API Error: 500 Internal Server Error");
  }
  
  return {
    content: `Generated content for: ${prompt}`,
    confidence: 0.95
  };
}

// 4. Higher-order function to execute safely
async function executeSafely<T>(
  operation: () => Promise<T>
): Promise<Result<T>> {
  try {
    const data = await operation();
    // Validate against schema if applicable (optional but recommended)
    // const parsed = llmResponseSchema.parse(data); 
    return { status: 'success', data };
  } catch (error) {
    // Normalize error to standard Error object
    const err = error instanceof Error ? error : new Error(String(error));
    return { status: 'failure', error: err };
  }
}

// 5. Usage Example
async function main() {
  const prompt = "Generate a summary.";
  
  // The result is typed as Result<LLMResponse, Error>
  const result = await executeSafely(() => simulatedLLMCall(prompt));

  // Consumer MUST check the status property
  if (result.status === 'success') {
    // TypeScript knows 'data' exists here
    console.log("Content:", result.data.content);
    console.log("Confidence:", result.data.confidence);
  } else {
    // TypeScript knows 'error' exists here
    console.error("Operation failed:", result.error.message);
  }

  // Example of failure path
  const failResult = await executeSafely(() => simulatedLLMCall("trigger fail"));
  if (failResult.status === 'failure') {
    console.log("Caught expected error:", failResult.error.message);
  }
}

// Run main for demonstration
// main();
