/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

// 1. Define the AgentState interface
export interface AgentState {
  userQuery: string;
  intent: 'search' | 'chat' | 'command' | null;
  validatedInput: unknown; // Refined by Zod in the validator node
  response: string | null;
}

// 2. Description of Zod usage in InputValidator Node
/*
In the InputValidator node of the LangGraph, we would perform the following steps:

1.  **Define a Schema**: Create a Zod schema specific to the detected intent (or a generic one for initial validation).
    Example: `const searchQuerySchema = z.object({ query: z.string().min(1) });`

2.  **Parse**: Access `state.userQuery` and attempt to parse it.
    `const result = searchQuerySchema.safeParse({ query: state.userQuery });`

3.  **Update State**:
    - If `result.success` is true, update `state.validatedInput` with `result.data` (now typed as `{ query: string }`).
    - If false, we might route to an error handling node or return the state unchanged with an error flag.

4.  **Type Narrowing**: By updating `validatedInput` with parsed data, subsequent nodes (like `IntentClassifier` or `ResponseGenerator`) can use Type Guards to ensure the data entering them is structurally valid.
*/

// 3. Visualization (Graphviz DOT)
export const graphVizDiagram = `
digraph AgentPipeline {
    rankdir=TB; // Top to Bottom layout
    node [shape=box, style=rounded];

    // Nodes
    Start [label="Start", shape=ellipse, style=filled, fillcolor="#e0e0e0"];
    InputValidator [label="InputValidator\n(Validate with Zod)"];
    IntentClassifier [label="IntentClassifier\n(Determine Type)"];
    ResponseGenerator [label="ResponseGenerator\n(LLM Call)"];
    End [label="End", shape=ellipse, style=filled, fillcolor="#e0e0e0"];

    // Edges representing data flow
    Start -> InputValidator [label="state.userQuery"];
    InputValidator -> IntentClassifier [label="state.validatedInput\n(typed)"];
    IntentClassifier -> ResponseGenerator [label="state.intent"];
    ResponseGenerator -> End [label="state.response"];

    // Subgraph to emphasize the State object flow (Optional visual aid)
    // Note: DOT syntax doesn't easily support object labels on edges, 
    // so we describe the state properties in the edge labels.
}
`;
