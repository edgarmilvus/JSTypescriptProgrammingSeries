/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

// Import necessary libraries
// Zod is used for runtime schema validation
import { z } from 'zod';

/**
 * TOOL DEFINITION (SRP: Single Responsibility)
 * We define the tool's interface strictly. This is what the LLM "sees" 
 * to understand what data it needs to provide if it chooses to call this tool.
 */
const weatherToolDefinition = {
  name: 'get_weather',
  description: 'Get the current weather for a specific city.',
  parameters: {
    type: 'object',
    properties: {
      city: {
        type: 'string',
        description: 'The city name (e.g., London, New York)',
      },
    },
    required: ['city'],
  },
};

/**
 * ZOD SCHEMA (Data Integrity)
 * We define a schema that matches the expected output of the tool.
 * This ensures that even if the LLM hallucinates a structure, we validate it strictly.
 */
const WeatherResponseSchema = z.object({
  city: z.string(),
  temperature: z.number(),
  condition: z.enum(['sunny', 'cloudy', 'rainy', 'snowy']),
});

type WeatherResponse = z.infer<typeof WeatherResponseSchema>;

/**
 * MOCK TOOL EXECUTION (Simulating External Data Fetching)
 * In a real app, this would be an async fetch call to an API like OpenWeatherMap.
 * Adheres to SRP: This module only handles data retrieval, not conversation logic.
 */
async function fetchWeather(city: string): Promise<WeatherResponse> {
  // Simulate network delay
  await new Promise((resolve) => setTimeout(resolve, 500));

  // Mock data logic
  const mockData = {
    city: city,
    temperature: Math.floor(Math.random() * (30 - 10 + 1) + 10), // Random temp between 10 and 30
    condition: ['sunny', 'cloudy', 'rainy'][Math.floor(Math.random() * 3)] as 'sunny' | 'cloudy' | 'rainy',
  };

  // Validate against Zod schema before returning
  // This catches any inconsistencies in our mock data or API response
  return WeatherResponseSchema.parse(mockData);
}

/**
 * MAIN CONVERSATION HANDLER (The Orchestrator)
 * This function simulates the interaction between the user and the AI model.
 * It handles the decision to use a tool and processes the result.
 */
async function runConversationalAgent(userPrompt: string) {
  console.log(`\n[User]: ${userPrompt}`);
  console.log("[System]: Analyzing prompt...");

  // 1. Simulate LLM analyzing the prompt and deciding a tool is needed.
  // In a real app, this decision is made by the LLM based on the provided tool definitions.
  // For this "Hello World", we simulate the decision logic.
  
  let toolCallDetected = false;
  let cityArgument = '';

  // Simple keyword matching to simulate the LLM's "thought process"
  if (userPrompt.toLowerCase().includes('weather') && userPrompt.toLowerCase().includes('in')) {
    toolCallDetected = true;
    // Extract city (very basic simulation)
    const match = userPrompt.match(/in\s+([a-zA-Z\s]+)/);
    cityArgument = match ? match[1].trim() : 'Unknown City';
    console.log(`[System]: Tool Call Detected: get_weather(city="${cityArgument}")`);
  }

  // 2. Execute the Tool
  if (toolCallDetected) {
    try {
      const weatherData = await fetchWeather(cityArgument);
      
      // 3. Construct the Final Response
      // The LLM would naturally integrate this data. We simulate that integration here.
      const finalResponse = `Based on the latest data, the weather in ${weatherData.city} is ${weatherData.temperature}°C and ${weatherData.condition}.`;
      
      console.log(`[AI]: ${finalResponse}`);
      return finalResponse;
    } catch (error) {
      if (error instanceof z.ZodError) {
        console.error("[System Error]: Tool returned invalid data structure:", error.errors);
      } else {
        console.error("[System Error]: Unexpected error:", error);
      }
    }
  } else {
    // Fallback for general conversation
    console.log("[AI]: I can help you check the weather. Just ask 'What's the weather in [City]?'");
  }
}

// --- EXECUTION ---

// Example 1: Triggering the tool
runConversationalAgent("What's the weather in London?");

// Example 2: General conversation (no tool needed)
// setTimeout(() => runConversationalAgent("Hello there!"), 1500);
