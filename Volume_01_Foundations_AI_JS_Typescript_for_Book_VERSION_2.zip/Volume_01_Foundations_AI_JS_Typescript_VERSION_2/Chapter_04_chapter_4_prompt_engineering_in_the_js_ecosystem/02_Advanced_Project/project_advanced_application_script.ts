/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

/**
 * Advanced Application Script: Supervisor Agent with Parallel Tool Execution
 * 
 * Context: SaaS Content Intelligence Platform
 * Tech Stack: Next.js (API Route), LangGraph.js, LangChain.js, Zod, OpenAI
 * 
 * Objective: Ingest a raw article, route it to specialized agents, and execute
 * independent tasks (SEO generation & Social Summary) in parallel.
 */

import { NextResponse, NextRequest } from 'next/server';
import { z } from 'zod';
import { ChatOpenAI } from '@langchain/openai';
import { ChatPromptTemplate } from '@langchain/core/prompts';
import { ToolNode } from '@langchain/langgraph/prebuilt';
import { StateGraph, END, START, Annotation } from '@langchain/langgraph';
import { RunnableToolLike } from '@langchain/core/language_models/base';

// ============================================================================
// 1. DOMAIN TYPES & SCHEMAS
// ============================================================================

/**
 * Zod Schema for the Supervisor's Output.
 * The Supervisor must output a JSON object matching this schema to route the graph.
 * This ensures strict control over the graph flow (Type Safety).
 */
const SupervisorSchema = z.object({
  next: z.enum(['seo_agent', 'social_agent', 'finish']),
  reason: z.string().describe("Brief reasoning for the routing decision."),
  context: z.string().optional().describe("Any context passed to the next agent.")
});

/**
 * State Annotation for the Graph.
 * Defines the shared state passed between nodes.
 */
const GraphState = Annotation.Root({
  articleDraft: Annotation<string>({
    reducer: (state, update) => update, // Overwrites with new draft
    default: () => "",
  }),
  seoData: Annotation<object>({
    reducer: (state, update) => ({ ...state, ...update }),
    default: () => ({}),
  }),
  socialPosts: Annotation<object>({
    reducer: (state, update) => ({ ...state, ...update }),
    default: () => ({}),
  }),
  supervisorDecision: Annotation<z.infer<typeof SupervisorSchema> | null>({
    reducer: (state, update) => update,
    default: () => null,
  })
});

// ============================================================================
// 2. TOOL DEFINITIONS (Worker Capabilities)
// ============================================================================

/**
 * Tool 1: SEO Metadata Generator
 * Simulates an external API call to generate SEO tags.
 */
const generateSEOMetadata = async (content: string) => {
  // Simulate latency
  await new Promise(resolve => setTimeout(resolve, 500));
  return {
    title: `Optimized: ${content.substring(0, 50)}...`,
    keywords: ["tech", "AI", "javascript", "langgraph"],
    metaDescription: `An analysis of ${content.substring(0, 100)}...`
  };
};

/**
 * Tool 2: Social Media Copywriter
 * Simulates generating platform-specific posts.
 */
const generateSocialCopy = async (content: string) => {
  // Simulate latency
  await new Promise(resolve => setTimeout(resolve, 500));
  return {
    twitter: `🚀 New Post: ${content.substring(0, 140)}... #AI #Dev`,
    linkedin: `Professional Insight: ${content.substring(0, 200)}...`
  };
};

// Wrap functions as LangChain tools for the ToolNode
const tools: RunnableToolLike[] = [
  {
    name: "generate_seo_metadata",
    description: "Generates SEO keywords and meta descriptions for an article.",
    schema: z.object({ content: z.string() }),
    func: async ({ content }: { content: string }) => generateSEOMetadata(content),
  },
  {
    name: "generate_social_copy",
    description: "Generates Twitter and LinkedIn posts for an article.",
    schema: z.object({ content: z.string() }),
    func: async ({ content }: { content: string }) => generateSocialCopy(content),
  },
];

// ============================================================================
// 3. AGENT NODES
// ============================================================================

/**
 * Supervisor Node: The "Brain" of the operation.
 * Uses Few-Shot Prompting to enforce JSON output structure.
 */
const createSupervisorNode = async (state: typeof GraphState.State) => {
  const model = new ChatOpenAI({ model: "gpt-4-turbo-preview", temperature: 0 });

  // FEW-SHOT PROMPTING: Providing examples to guide the LLM behavior
  const prompt = ChatPromptTemplate.fromMessages([
    [
      "system",
      `
      You are a content routing supervisor. You analyze an article draft and decide which agent to call next.
      
      RULES:
      1. If SEO data is missing, route to 'seo_agent'.
      2. If Social data is missing, route to 'social_agent'.
      3. If both are present, route to 'finish'.
      4. Output ONLY valid JSON.
      
      FEW-SHOT EXAMPLES:
      Input: { "seoData": {}, "socialPosts": {} }
      Output: {{ "next": "seo_agent", "reason": "SEO data is missing." }}

      Input: { "seoData": { "title": "..." }, "socialPosts": {} }
      Output: {{ "next": "social_agent", "reason": "Social data is missing." }}

      Input: { "seoData": { "title": "..." }, "socialPosts": { "twitter": "..." } }
      Output: {{ "next": "finish", "reason": "All tasks completed." }}
      `,
    ],
    ["human", `Current State: {seoData: {${Object.keys(state.seoData).length > 0 ? 'populated' : 'empty'}}, socialPosts: {${Object.keys(state.socialPosts).length > 0 ? 'populated' : 'empty'}}}`],
  ]);

  const response = await prompt.pipe(model).invoke({});
  
  // Extract JSON from LLM response string
  const content = response.content as string;
  const jsonMatch = content.match(/\{.*\}/s);
  
  if (!jsonMatch) {
    throw new Error("Supervisor failed to return valid JSON.");
  }

  const parsed = JSON.parse(jsonMatch[0]);
  const validated = SupervisorSchema.parse(parsed);

  return { supervisorDecision: validated };
};

/**
 * Worker Node: SEO Agent
 * Invokes the SEO tool and updates state.
 */
const seoWorkerNode = async (state: typeof GraphState.State) => {
  const toolNode = new ToolNode(tools);
  // We pass a specific action to the tool node to force execution of the SEO tool
  // In a complex graph, we might route through a generic tool executor, 
  // but here we simulate the worker invoking its specific capability.
  const result = await generateSEOMetadata(state.articleDraft);
  return { seoData: result };
};

/**
 * Worker Node: Social Agent
 * Invokes the Social tool and updates state.
 */
const socialWorkerNode = async (state: typeof GraphState.State) => {
  const result = await generateSocialCopy(state.articleDraft);
  return { socialPosts: result };
};

// ============================================================================
// 4. GRAPH CONSTRUCTION & EXECUTION
// ============================================================================

/**
 * Builds the LangGraph.
 * Architecture:
 * 1. Supervisor decides the path.
 * 2. Workers execute tasks.
 * 3. Workers route back to Supervisor for re-evaluation (Loop).
 */
const buildGraph = () => {
  const workflow = new StateGraph(GraphState);

  // Register Nodes
  workflow.addNode("supervisor", createSupervisorNode);
  workflow.addNode("seo_agent", seoWorkerNode);
  workflow.addNode("social_agent", socialWorkerNode);

  // Define Edges
  // Supervisor acts as the router
  workflow.addConditionalEdges(
    "supervisor",
    (state: typeof GraphState.State) => {
      return state.supervisorDecision?.next || "finish";
    },
    {
      seo_agent: "seo_agent",
      social_agent: "social_agent",
      finish: END
    }
  );

  // Workers always return to the supervisor for re-evaluation
  workflow.addEdge("seo_agent", "supervisor");
  workflow.addEdge("social_agent", "supervisor");

  // Start at the supervisor
  workflow.addEdge(START, "supervisor");

  return workflow.compile();
};

/**
 * API Route Handler (Next.js)
 */
export async function POST(request: NextRequest) {
  try {
    const { articleDraft } = await request.json();

    if (!articleDraft) {
      return NextResponse.json({ error: "Article draft is required." }, { status: 400 });
    }

    const graph = buildGraph();
    
    // Execute the graph
    const finalState = await graph.invoke({
      articleDraft: articleDraft,
      seoData: {},
      socialPosts: {},
    });

    return NextResponse.json({
      status: "success",
      data: {
        seo: finalState.seoData,
        social: finalState.socialPosts,
      }
    });

  } catch (error) {
    console.error("Graph Execution Error:", error);
    return NextResponse.json(
      { error: "Internal Server Error", details: (error as Error).message },
      { status: 500 }
    );
  }
}
