/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

import { z } from 'zod';
import OpenAI from 'openai';

// 1. Define the Zod Schema
const TaskPrioritySchema = z.array(
  z.object({
    taskId: z.string(),
    priority: z.enum(["High", "Medium", "Low"]),
    reasoning: z.string(),
  })
);

// 2. Construct the Prompt
export function generatePrioritizationPrompt(tasks: string[]): string {
  const systemContext = `You are an expert project management assistant. Your task is to categorize tasks into "High", "Medium", or "Low" priority based on urgency and importance.
You must output ONLY valid JSON that matches the following schema:
[
  {
    "taskId": "string",
    "priority": "High" | "Medium" | "Low",
    "reasoning": "string"
  }
]
Do not include any markdown formatting or conversational text.`;

  const fewShotExamples = `
Example 1:
Input: "Fix critical security vulnerability in the authentication API"
Output: [{"taskId": "ex1", "priority": "High", "reasoning": "Security vulnerabilities pose immediate risk to data integrity and user safety."}]

Example 2:
Input: "Update the company logo in the footer"
Output: [{"taskId": "ex2", "priority": "Low", "reasoning": "Visual updates are cosmetic and do not affect functionality."}]

Example 3:
Input: "Prepare quarterly financial report for stakeholders"
Output: [{"taskId": "ex3", "priority": "Medium", "reasoning": "Important for business operations but has a reasonable deadline."}]`;

  const userTasks = tasks
    .map((task, index) => `Task ${index + 1}: ${task}`)
    .join("\n");

  return `${systemContext}\n\n${fewShotExamples}\n\nNow prioritize the following tasks:\n${userTasks}\nOutput:`;
}

// 3. Implement the Logic
export async function prioritizeTasks(tasks: string[]) {
  const openai = new OpenAI(); // Assumes OPENAI_API_KEY is in env

  const prompt = generatePrioritizationPrompt(tasks);

  const response = await openai.chat.completions.create({
    model: "gpt-4o-mini",
    messages: [
      { role: "user", content: prompt }
    ],
    temperature: 0.1, // Low temp for consistency
  });

  const content = response.choices[0].message.content;

  if (!content) {
    throw new Error("No content returned from LLM");
  }

  try {
    // Parse the raw string response using the Zod schema
    const parsedResponse = JSON.parse(content);
    const validatedData = TaskPrioritySchema.parse(parsedResponse);
    return validatedData;
  } catch (error) {
    console.error("Parsing or Validation Error:", error);
    throw new Error("Failed to validate LLM response against schema.");
  }
}
