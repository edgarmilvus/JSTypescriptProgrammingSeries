/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part7.ts
// Description: Solutions and Explanations
// ==========================================

digraph G {
    rankdir=LR;
    node [shape=box, style="rounded,filled", color="#E3F2FD"];
    
    UserQuery [label="User Query", fillcolor="#BBDEFB"];
    Split [label="Parallel Execution", shape=diamond, fillcolor="#FFF9C4"];
    
    subgraph cluster_weather {
        style=filled;
        color="#E8F5E9";
        label="Branch 1";
        WeatherTool [label="getWeather()", fillcolor="#C8E6C9"];
    }

    subgraph cluster_facts {
        style=filled;
        color="#E8F5E9";
        label="Branch 2";
        FactsTool [label="getFunFacts()", fillcolor="#C8E6C9"];
    }

    Combine [label="Combine Results\n(Promise.all)", fillcolor="#FFCCBC"];
    LLM [label="Send to LLM", fillcolor="#D1C4E9"];

    UserQuery -> Split;
    Split -> WeatherTool;
    Split -> FactsTool;
    WeatherTool -> Combine;
    FactsTool -> Combine;
    Combine -> LLM;
}
