/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// pages/api/triage.ts
// Next.js API Route for Hierarchical Agentic Workflow
import type { NextApiRequest, NextApiResponse } from 'next';
import { OpenAI } from '@langchain/openai';
import { LLMChain } from 'langchain/chains';
import { PromptTemplate } from '@langchain/prompts';
import { z } from 'zod';
import { StructuredOutputParser } from 'langchain/output_parsers';

/**
 * ============================================================================
 * 1. SCHEMA DEFINITION & VALIDATION (Zod)
 * ============================================================================
 * We define the expected output structure for the Supervisor Agent.
 * This ensures type safety and prevents hallucinated outputs from breaking
 * the downstream logic.
 */

// Define the schema for the Supervisor's classification
const ClassificationSchema = z.object({
  category: z.enum(['TECHNICAL', 'BILLING', 'FEATURE_REQUEST']),
  confidence: z.number().min(0).max(1),
  reasoning: z.string().describe("Brief explanation for the classification."),
});

// Create a LangChain output parser from the Zod schema
const outputParser = StructuredOutputParser.fromZodSchema(ClassificationSchema);
const formatInstructions = outputParser.getFormatInstructions();

/**
 * ============================================================================
 * 2. PROMPT TEMPLATES (The "Brain" of the Agents)
 * ============================================================================
 * Prompts define the behavior of the LLM. We separate the Supervisor's 
 * classification logic from the Executor's generation logic.
 */

// --- Supervisor Prompt ---
// This prompt instructs the LLM to act as a strict classifier.
const SUPERVISOR_TEMPLATE = `
You are a triage supervisor for a SaaS application. 
Analyze the user's input and classify it strictly into one of three categories:
1. TECHNICAL: Bugs, errors, API issues, integration problems.
2. BILLING: Invoices, refunds, subscription changes, payment failures.
3. FEATURE_REQUEST: Suggestions for new functionality or improvements.

You must respond ONLY with a JSON object matching the instructions below. 
Do not add conversational filler.

User Input: "{input}"

{format_instructions}
`;

// --- Executor Prompt ---
// This prompt instructs the LLM to act as a specific department agent.
const EXECUTOR_TEMPLATE = `
You are an agent in the "{category}" department. 
Your goal is to provide a helpful, concise, and professional response to the user.
Your tone should match the department:
- If TECHNICAL: Be precise, ask for logs or steps to reproduce.
- If BILLING: Be polite, provide clear invoice details or next steps.
- If FEATURE_REQUEST: Be enthusiastic, acknowledge the value, and explain the roadmap process.

User Input: "{input}"

Response:
`;

/**
 * ============================================================================
 * 3. AGENT SETUP (LangChain.js Components)
 * ============================================================================
 * We instantiate the LLM and Chain components. 
 * Note: In a production app, API keys should be loaded from environment variables.
 */

const llm = new OpenAI({
  modelName: 'gpt-3.5-turbo', // Optimized for speed and cost in this demo
  temperature: 0, // Low temperature for deterministic classification
});

/**
 * ============================================================================
 * 4. MAIN LOGIC: The Hierarchical Workflow
 * ============================================================================
 * This function orchestrates the flow: Supervisor -> Validation -> Executor.
 */

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  // Only accept POST requests
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method Not Allowed' });
  }

  const { input } = req.body;

  if (!input || typeof input !== 'string') {
    return res.status(400).json({ error: 'Valid "input" string is required.' });
  }

  try {
    // -------------------------------------------------------------------------
    // STEP 1: The Supervisor Agent (Classification)
    // -------------------------------------------------------------------------
    // We use an LLMChain to process the input through the Supervisor Prompt.
    
    const supervisorPrompt = new PromptTemplate({
      template: SUPERVISOR_TEMPLATE,
      inputVariables: ['input'],
      partialVariables: { format_instructions: formatInstructions },
    });

    const supervisorChain = new LLMChain({ llm, prompt: supervisorPrompt });

    // Execute the chain
    const supervisorResult = await supervisorChain.call({ input });

    // -------------------------------------------------------------------------
    // STEP 2: Validation & Parsing
    // -------------------------------------------------------------------------
    // Parse the raw string output into our Zod schema.
    // This catches hallucinations or malformed JSON from the LLM.
    
    const parsedOutput = await outputParser.parse(supervisorResult.text);
    
    // -------------------------------------------------------------------------
    // STEP 3: The Executor Agent (Generation)
    // -------------------------------------------------------------------------
    // Based on the Supervisor's decision, we route to the specialized Executor.
    
    const executorPrompt = new PromptTemplate({
      template: EXECUTOR_TEMPLATE,
      inputVariables: ['category', 'input'],
    });

    const executorChain = new LLMChain({ llm, prompt: executorPrompt });

    // Execute the chain with the classified category
    const executorResult = await executorChain.call({
      category: parsedOutput.category,
      input: input,
    });

    // -------------------------------------------------------------------------
    // STEP 4: Final Response Construction
    // -------------------------------------------------------------------------
    // Return the structured result to the client.
    
    res.status(200).json({
      success: true,
      classification: {
        category: parsedOutput.category,
        confidence: parsedOutput.confidence,
        reasoning: parsedOutput.reasoning,
      },
      response: executorResult.text.trim(),
    });

  } catch (error) {
    console.error("Workflow Error:", error);
    res.status(500).json({ 
      error: 'Internal Workflow Error', 
      details: error instanceof Error ? error.message : 'Unknown error' 
    });
  }
}
