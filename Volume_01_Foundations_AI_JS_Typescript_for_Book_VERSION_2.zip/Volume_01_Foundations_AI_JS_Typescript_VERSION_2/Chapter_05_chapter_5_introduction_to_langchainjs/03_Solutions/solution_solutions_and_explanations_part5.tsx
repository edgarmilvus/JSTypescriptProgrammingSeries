/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.tsx
// Description: Solutions and Explanations
// ==========================================

// ChainBuilder.tsx
'use client';

import { useState } from 'react';
import { visualizeChain } from './visualize';

// 1. Component Registry
interface ChainNode {
  name: string;
  description: string;
  execute: (input: string) => Promise<string>;
}

const nodeRegistry: ChainNode[] = [
  {
    name: "Summarizer",
    description: "Condenses text into a short summary.",
    execute: async (input: string) => {
      // Simulate processing
      return `[SUMMARY]: ${input.substring(0, 50)}... (summarized)`;
    }
  },
  {
    name: "Translator (French)",
    description: "Translates text to French.",
    execute: async (input: string) => {
      return `[FRENCH]: Bonjour! ${input}`; // Mock translation
    }
  },
  {
    name: "Keyword Extractor",
    description: "Extracts key entities.",
    execute: async (input: string) => {
      const keywords = input.split(' ').slice(0, 3).join(', ');
      return `[KEYWORDS]: ${keywords}`;
    }
  }
];

export default function ChainBuilder() {
  const [selectedNodes, setSelectedNodes] = useState<ChainNode[]>([]);
  const [inputText, setInputText] = useState('');
  const [output, setOutput] = useState<string>('');
  const [isLoading, setIsLoading] = useState(false);

  // 2. Add Node Logic
  const addNode = (nodeName: string) => {
    const node = nodeRegistry.find(n => n.name === nodeName);
    if (node) {
      setSelectedNodes([...selectedNodes, node]);
    }
  };

  // 3. Remove Node Logic
  const removeNode = (index: number) => {
    const newNodes = [...selectedNodes];
    newNodes.splice(index, 1);
    setSelectedNodes(newNodes);
  };

  // 4. Execution Logic
  const runChain = async () => {
    if (!inputText.trim() || selectedNodes.length === 0) return;
    
    setIsLoading(true);
    setOutput('');
    
    try {
      let currentOutput = inputText;
      
      // Iterate through nodes in order
      for (const node of selectedNodes) {
        // Visualize the current step (console log for debugging)
        console.log(`Executing: ${node.name} on input: ${currentOutput}`);
        currentOutput = await node.execute(currentOutput);
      }
      
      setOutput(currentOutput);
    } catch (err) {
      setOutput("Error running chain.");
    } finally {
      setIsLoading(false);
    }
  };

  // 5. Visualization Logic
  const getChainDiagram = () => {
    if (selectedNodes.length === 0) return "No chain constructed.";
    
    // Generate a custom DOT string based on current selection
    let dotNodes = ['Input [label="User Input"]'];
    let dotEdges = [];
    let prevNode = "Input";

    selectedNodes.forEach((node, idx) => {
      const nodeId = `Node${idx}`;
      dotNodes.push(`${nodeId} [label="${node.name}"]`);
      dotEdges.push(`${prevNode} -> ${nodeId}`);
      prevNode = nodeId;
    });

    dotEdges.push(`${prevNode} -> FinalOutput`);

    return `
digraph G {
  rankdir=LR;
  node [shape=box];
  ${dotNodes.join(';\n  ')};
  ${dotEdges.join(';\n  ')}
  FinalOutput [label="Output"]
}`;
  };

  return (
    <div className="p-6 max-w-4xl mx-auto">
      <h1 className="text-3xl font-bold mb-6">Dynamic Chain Builder</h1>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Left Panel: Available Nodes */}
        <div className="bg-gray-50 p-4 rounded-lg">
          <h2 className="text-xl font-semibold mb-3">Available Nodes</h2>
          <div className="space-y-2">
            {nodeRegistry.map((node) => (
              <div key={node.name} className="p-3 bg-white border rounded flex justify-between items-center">
                <div>
                  <strong>{node.name}</strong>
                  <p className="text-xs text-gray-500">{node.description}</p>
                </div>
                <button
                  onClick={() => addNode(node.name)}
                  className="px-3 py-1 bg-blue-500 text-white rounded text-sm hover:bg-blue-600"
                >
                  Add
                </button>
              </div>
            ))}
          </div>
        </div>

        {/* Right Panel: Construction & Execution */}
        <div className="space-y-4">
          {/* Construction Area */}
          <div className="p-4 border-2 border-dashed border-gray-300 rounded-lg min-h-[150px]">
            <h3 className="font-semibold mb-2">Construction Area</h3>
            {selectedNodes.length === 0 ? (
              <p className="text-gray-400 text-sm">Click nodes to add them here...</p>
            ) : (
              <ul className="space-y-2">
                {selectedNodes.map((node, idx) => (
                  <li key={idx} className="flex justify-between items-center bg-white p-2 rounded shadow-sm">
                    <span>{idx + 1}. {node.name}</span>
                    <button 
                      onClick={() => removeNode(idx)} 
                      className="text-red-500 hover:text-red-700 text-sm font-bold"
                    >
                      ×
                    </button>
                  </li>
                ))}
              </ul>
            )}
          </div>

          {/* Input Area */}
          <div>
            <label className="block text-sm font-medium mb-1">Input Text</label>
            <textarea
              className="w-full p-2 border rounded"
              rows={3}
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              placeholder="Enter text to process..."
            />
          </div>

          {/* Actions */}
          <button
            onClick={runChain}
            disabled={isLoading || selectedNodes.length === 0}
            className="w-full py-2 bg-green-600 text-white rounded font-bold disabled:bg-gray-400"
          >
            {isLoading ? 'Processing...' : 'Run Chain'}
          </button>

          {/* Output */}
          {output && (
            <div className="p-4 bg-black text-green-400 font-mono rounded">
              <strong>Final Output:</strong>
              <div>{output}</div>
            </div>
          )}
        </div>
      </div>

      {/* Visualization Section */}
      <div className="mt-8 p-4 bg-gray-100 rounded-lg">
        <h2 className="text-xl font-semibold mb-3">Chain Visualization</h2>
        <div className="bg-white p-4 rounded border">
          <pre className="text-xs overflow-auto text-gray-700">
            {getChainDiagram()}
          </pre>
        </div>
      </div>
    </div>
  );
}
