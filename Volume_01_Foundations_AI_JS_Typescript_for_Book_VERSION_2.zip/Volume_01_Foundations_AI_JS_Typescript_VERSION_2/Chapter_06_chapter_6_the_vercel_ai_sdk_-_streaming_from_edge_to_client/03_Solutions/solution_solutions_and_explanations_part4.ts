/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

// File: components/ValidatedStreamingChat.tsx
// Problem: Integrate Zod validation into the client-side stream processing.

import { z } from 'zod';
import { useState, useCallback } from 'react';

// 1. Define the Zod schema
const ChatResponseSchema = z.object({
  role: z.literal('assistant'),
  content: z.string(),
});

type ChatResponse = z.infer<typeof ChatResponseSchema>;

export default function ValidatedStreamingChat() {
  const [validatedContent, setValidatedContent] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  // Function to handle the stream with validation
  const startStream = useCallback(async () => {
    setIsLoading(true);
    setValidatedContent(''); // Reset content

    try {
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: "Tell me a story." }),
      });

      if (!response.body) return;
      const reader = response.body.getReader();
      const decoder = new TextDecoder();
      let buffer = '';

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        // Assuming the server sends NDJSON: {"role":"assistant","content":"..."}\n
        buffer += decoder.decode(value, { stream: true });

        const lines = buffer.split('\n');
        buffer = lines.pop() || ''; // Keep incomplete line

        for (const line of lines) {
          if (!line.trim()) continue;

          try {
            // 2. Parse the chunk
            const parsed = JSON.parse(line);

            // 3. Validate against Zod schema
            const result = ChatResponseSchema.safeParse(parsed);

            if (result.success) {
              // 4. Update UI only if valid
              const { content } = result.data;
              setValidatedContent((prev) => prev + content);
            } else {
              // 5. Discard invalid data and log error
              console.warn('Validation failed for chunk:', result.error);
            }
          } catch (parseError) {
            console.error('JSON Parse error:', parseError);
          }
        }
      }
    } catch (error) {
      console.error('Stream error:', error);
    } finally {
      setIsLoading(false);
    }
  }, []);

  return (
    <div style={{ padding: '20px', maxWidth: '600px', margin: '0 auto' }}>
      <h2>Validated Streaming Chat</h2>
      <button onClick={startStream} disabled={isLoading}>
        {isLoading ? 'Streaming...' : 'Start Stream'}
      </button>

      <div style={{ 
        marginTop: '20px', 
        padding: '15px', 
        border: '1px solid #ccc', 
        borderRadius: '4px',
        minHeight: '100px',
        backgroundColor: '#f0f8ff'
      }}>
        <strong>Validated Response:</strong>
        <p style={{ whiteSpace: 'pre-wrap', marginTop: '10px' }}>
          {validatedContent}
        </p>
      </div>
      
      <div style={{ marginTop: '10px', fontSize: '0.9em', color: '#666' }}>
        Check the browser console to see validation errors if the server sends malformed data.
      </div>
    </div>
  );
}
