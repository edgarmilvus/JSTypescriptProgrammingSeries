/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part6.ts
// Description: Solutions and Explanations
// ==========================================

digraph StreamingFlow {
    rankdir=LR;
    node [shape=box, style="rounded,filled", fontname="Helvetica"];
    edge [fontname="Helvetica", fontsize=10];

    // Define Nodes
    Client [label="Browser Client\n(React Component)", fillcolor="#e1f5fe"];
    EdgeRuntime [label="Edge Function\n(Vercel AI SDK)", fillcolor="#fff3e0"];
    LLM [label="OpenAI / LLM API", fillcolor="#f3e5f5"];
    
    subgraph cluster_client {
        label="Client Side";
        style="dashed";
        ClientStreamReader [label="StreamReader\n& TextDecoder", fillcolor="#e8f5e9"];
        ClientUI [label="React UI State\n(useState / useSWR)", fillcolor="#e0f2f1"];
    }

    subgraph cluster_server {
        label="Server Side";
        style="dashed";
        ServerStream [label="LLM Token Stream", fillcolor="#ffebee"];
        ServerProcessor [label="Stream Processing\n& JSON Serialization", fillcolor="#fff8e1"];
    }

    // Define Edges (Data Flow)
    Client -> EdgeRuntime [label="1. HTTP Request\n(JSON Body)"];
    EdgeRuntime -> LLM [label="2. API Call\n(Prompt)"];
    
    LLM -> ServerStream [label="3. Token Stream\n(Raw Text)"];
    ServerStream -> ServerProcessor [label="4. Chunking\n& Formatting"];
    
    // Highlight Backpressure/Buffering
    ServerProcessor -> EdgeRuntime [label="5. HTTP Response Stream\n(ReadableStream)", style="bold", color="blue"];
    
    EdgeRuntime -> ClientStreamReader [label="6. Binary Chunks"];
    ClientStreamReader -> ClientUI [label="7. Decoded Text\n(State Update)"];
    
    // Feedback Loop for UX
    ClientUI -> Client [label="8. Re-render UI", style="dashed", color="gray"];
}
