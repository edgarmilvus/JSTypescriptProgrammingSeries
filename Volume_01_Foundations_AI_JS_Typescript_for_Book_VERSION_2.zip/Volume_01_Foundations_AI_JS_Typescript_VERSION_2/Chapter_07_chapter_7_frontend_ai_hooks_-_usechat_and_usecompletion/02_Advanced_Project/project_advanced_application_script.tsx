/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.tsx
// Description: Advanced Application Script
// ==========================================

import React, { useState, useEffect } from 'react';
import { useChat } from 'ai/react';
import { useCompletion } from 'ai/react';
import { z } from 'zod';

// -----------------------------------------------------------------------------
// 1. Client-Side Response Validation (Zod)
// -----------------------------------------------------------------------------
// Even though the backend generates the response, we validate it on the client 
// to ensure type safety and prevent rendering malformed data in our SaaS UI.
// This is crucial for maintaining a robust "Intelligent App".
const SummaryResponseSchema = z.object({
  summary: z.string().min(10, "Summary too short, model might be hallucinating"),
  sentiment: z.enum(["positive", "neutral", "negative"]),
  actionItems: z.array(z.string()).max(5)
});

type SummaryResult = z.infer<typeof SummaryResponseSchema>;

// -----------------------------------------------------------------------------
// 2. Component: Productivity Dashboard
// -----------------------------------------------------------------------------
/**
 * A composite component demonstrating the dual usage of `useChat` and `useCompletion`.
 * 
 * Architecture:
 * - Left Panel: Uses `useCompletion` for raw text processing (Summarization).
 * - Right Panel: Uses `useChat` for conversational context.
 * - State Bridge: The summarized output from the Left Panel is injected into the 
 *   Right Panel's context to create a seamless user experience.
 */
export default function ProductivityDashboard() {
  // --- State Management ---
  const [rawInput, setRawInput] = useState<string>("");
  const [parsedSummary, setParsedSummary] = useState<SummaryResult | null>(null);
  const [error, setError] = useState<string | null>(null);

  // --- HOOK 1: useCompletion (Single-Turn Transformation) ---
  // 'useCompletion' is designed for tasks where we want a single generated string 
  // based on a prompt. It does not manage a history of messages.
  const {
    completion,       // The current generated text stream
    input,            // The input value bound to the form
    handleInputChange, // Updates the input state
    handleSubmit,     // Handles the form submission
    isLoading,        // Boolean indicating if the API is responding
    error: completionError // Any errors from the completion endpoint
  } = useCompletion({
    api: '/api/summarize', // Our LangChain/OpenAI backend route
    prompt: rawInput,      // We control the prompt via local state
    onFinish: (prompt, completionText) => {
      // 'onFinish' is a lifecycle hook that triggers when the stream ends.
      // Here, we parse the raw text stream into a structured object using Zod.
      try {
        // Note: In a real app, the backend should return JSON. 
        // If streaming raw text, we might need to buffer it. 
        // Assuming the backend sends a JSON string at the end of the stream:
        const parsed = JSON.parse(completionText) as SummaryResult;
        
        // Validate strictly using Zod
        const validated = SummaryResponseSchema.parse(parsed);
        setParsedSummary(validated);
        setError(null);
      } catch (e) {
        console.error("Validation failed", e);
        setError("The AI response was invalid. Please try again.");
      }
    }
  });

  // --- HOOK 2: useChat (Multi-Turn Conversation) ---
  // 'useChat' manages an array of message objects (role/content).
  // It handles streaming chunks automatically and appends them to the history.
  const {
    messages,          // Array of Message objects (user + AI)
    input: chatInput,  // Input state for the chat window
    handleInputChange: handleChatChange,
    handleSubmit: handleChatSubmit,
    isLoading: isChatLoading,
    append             // Programmatic way to add messages (used for context injection)
  } = useChat({
    api: '/api/chat', // Separate endpoint for conversational logic
    // We can pass initial messages if we want to pre-populate the chat
  });

  // --- LOGIC: Context Injection (The "Smart" Feature) ---
  // When the Summarizer finishes, we automatically inject the result 
  // into the Chat context so the user can ask questions about it immediately.
  useEffect(() => {
    if (parsedSummary && !messages.some(m => m.content.includes(parsedSummary.summary))) {
      const contextMessage = `I have summarized my notes. Here is the structured output: 
      Summary: ${parsedSummary.summary}. 
      Sentiment: ${parsedSummary.sentiment}. 
      Action Items: ${parsedSummary.actionItems.join(", ")}.
      
      Please acknowledge this summary and be ready to answer questions about it.`;

      append({
        role: 'user',
        content: contextMessage
      }, {
        options: { body: { generatedContext: true } } // Custom flag for backend
      });
    }
  }, [parsedSummary, messages, append]);

  // --- RENDER LOGIC ---

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6 p-6 h-screen bg-gray-50">
      
      {/* COLUMN 1: The Summarizer (useCompletion) */}
      <div className="flex flex-col bg-white rounded-lg shadow-lg border border-gray-200 overflow-hidden">
        <div className="p-4 bg-blue-600 text-white font-bold flex justify-between items-center">
          <span>Document Processor</span>
          {isLoading && <span className="animate-pulse text-sm">Processing...</span>}
        </div>
        
        <div className="flex-1 p-4 flex flex-col gap-4 overflow-y-auto">
          {/* Input Area */}
          <div className="flex flex-col gap-2">
            <label className="text-sm font-semibold text-gray-700">Raw Notes</label>
            <textarea
              className="w-full p-3 border rounded-md focus:ring-2 focus:ring-blue-500 outline-none transition-all"
              rows={6}
              placeholder="Paste meeting notes, transcripts, or raw data here..."
              value={rawInput}
              onChange={(e) => setRawInput(e.target.value)}
            />
            <button
              onClick={(e) => {
                // We manually trigger the completion by updating the prompt state
                // In standard usage, you might pass the input directly to the hook.
                // Here, we bind `rawInput` to the hook's prompt prop.
                // To simulate a submit event:
                const fakeEvent = { preventDefault: () => {} } as any;
                handleSubmit(fakeEvent);
              }}
              disabled={isLoading || !rawInput}
              className="bg-blue-600 text-white py-2 rounded-md hover:bg-blue-700 disabled:opacity-50 transition-colors"
            >
              {isLoading ? 'Generating...' : 'Summarize & Analyze'}
            </button>
            {error && <div className="text-red-500 text-sm">{error}</div>}
          </div>

          {/* Output Area */}
          <div className="flex-1 bg-gray-50 p-3 rounded-md border border-gray-200">
            <h4 className="text-xs font-bold uppercase text-gray-500 mb-2">Structured Result</h4>
            
            {/* Streaming Text (Visible while loading) */}
            {isLoading && (
              <div className="text-gray-400 italic font-mono text-sm">
                {completion}
              </div>
            )}

            {/* Parsed JSON (Visible after validation) */}
            {parsedSummary && !isLoading && (
              <div className="space-y-2 animate-fade-in">
                <div className="flex items-center gap-2">
                  <span className="text-xs font-bold px-2 py-1 rounded bg-gray-200">
                    Sentiment: {parsedSummary.sentiment}
                  </span>
                </div>
                <p className="text-sm font-medium text-gray-800">{parsedSummary.summary}</p>
                <ul className="list-disc list-inside text-sm text-gray-600 pl-2">
                  {parsedSummary.actionItems.map((item, i) => (
                    <li key={i}>{item}</li>
                  ))}
                </ul>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* COLUMN 2: The Chatbot (useChat) */}
      <div className="flex flex-col bg-white rounded-lg shadow-lg border border-gray-200 overflow-hidden">
        <div className="p-4 bg-emerald-600 text-white font-bold flex justify-between items-center">
          <span>Contextual Assistant</span>
          {isChatLoading && <span className="text-xs opacity-75">Thinking...</span>}
        </div>

        {/* Message History */}
        <div className="flex-1 p-4 overflow-y-auto flex flex-col gap-3 bg-gray-50">
          {messages.length === 0 && (
            <div className="text-center text-gray-400 mt-10">
              <p>Summarize a document to start a context-aware chat.</p>
            </div>
          )}
          
          {messages.map((m, index) => (
            <div 
              key={index} 
              className={`max-w-[85%] p-3 rounded-lg text-sm whitespace-pre-wrap ${
                m.role === 'user' 
                  ? 'self-end bg-emerald-100 text-emerald-900 rounded-br-none' 
                  : 'self-start bg-white border border-gray-200 text-gray-800 rounded-bl-none'
              }`}
            >
              <div className="font-bold text-xs mb-1 opacity-60">
                {m.role === 'user' ? 'You' : 'Assistant'}
              </div>
              {m.content}
            </div>
          ))}
        </div>

        {/* Chat Input */}
        <form 
          onSubmit={handleChatSubmit} 
          className="p-3 bg-white border-t border-gray-200 flex gap-2"
        >
          <input
            className="flex-1 p-2 border rounded-md focus:ring-2 focus:ring-emerald-500 outline-none text-sm"
            value={chatInput}
            placeholder="Ask about the summary or general questions..."
            onChange={handleChatChange}
          />
          <button 
            type="submit" 
            disabled={isChatLoading || !chatInput}
            className="bg-emerald-600 text-white px-4 py-2 rounded-md hover:bg-emerald-700 disabled:opacity-50"
          >
            Send
          </button>
        </form>
      </div>
    </div>
  );
}
