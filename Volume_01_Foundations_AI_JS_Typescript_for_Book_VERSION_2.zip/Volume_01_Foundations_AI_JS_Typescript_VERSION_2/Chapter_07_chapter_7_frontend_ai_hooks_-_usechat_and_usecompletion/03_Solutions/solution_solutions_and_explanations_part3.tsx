/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState } from 'react';
import { useChat } from 'ai/react';

type AgentTask = 'summarize' | 'poem';

export function AgentDashboard() {
  // 1. Local state for UI control
  const [task, setTask] = useState<AgentTask>('summarize');
  const [localInput, setLocalInput] = useState('');

  // 2. Initialize useChat for the agent endpoint
  const { 
    messages, 
    input, 
    handleSubmit, 
    isLoading, 
    setInput 
  } = useChat({ 
    api: '/api/agent' 
  });

  // 3. Custom submit handler to format the prompt dynamically
  const handleExecute = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Construct the specific prompt based on the selected task
    const formattedPrompt = `Task: ${task}\nInput: ${localInput}`;
    
    // Set the hook's internal input and trigger the API call
    setInput(formattedPrompt);
    handleSubmit(e);
    
    // Clear local input after submission
    setLocalInput('');
  };

  return (
    <div className="max-w-3xl mx-auto p-6">
      <div className="bg-white rounded-lg shadow-lg p-6 border">
        <h2 className="text-2xl font-bold mb-4">Multi-Tool Agent</h2>

        {/* Task Selector */}
        <div className="mb-6">
          <label className="block text-sm font-medium mb-2">Select Task</label>
          <select 
            value={task} 
            onChange={(e) => setTask(e.target.value as AgentTask)}
            className="w-full p-2 border rounded focus:ring-2 focus:ring-purple-500"
          >
            <option value="summarize">Summarize Text</option>
            <option value="poem">Generate Poem</option>
          </select>
        </div>

        {/* Dynamic Input Form */}
        <form onSubmit={handleExecute} className="mb-6 space-y-4">
          <div>
            {task === 'summarize' ? (
              <textarea
                value={localInput}
                onChange={(e) => setLocalInput(e.target.value)}
                disabled={isLoading}
                rows={4}
                className="w-full p-2 border rounded"
                placeholder="Enter text to summarize..."
              />
            ) : (
              <input
                type="text"
                value={localInput}
                onChange={(e) => setLocalInput(e.target.value)}
                disabled={isLoading}
                className="w-full p-2 border rounded"
                placeholder="Enter a topic for the poem..."
              />
            )}
          </div>
          <button
            type="submit"
            disabled={isLoading || !localInput.trim()}
            className="px-4 py-2 bg-purple-600 text-white rounded hover:bg-purple-700 disabled:opacity-50"
          >
            {isLoading ? 'Processing...' : 'Execute Task'}
          </button>
        </form>

        {/* Agent Response Stream */}
        <div className="border-t pt-4">
          <h3 className="font-semibold text-gray-700 mb-2">Agent Output:</h3>
          {messages.length > 0 ? (
            <div className="space-y-3">
              {messages.map((msg) => (
                <div key={msg.id} className="p-3 bg-gray-50 rounded border">
                  <span className="font-bold text-purple-700 uppercase text-xs">
                    {msg.role}
                  </span>
                  <div className="mt-1 text-sm whitespace-pre-wrap">
                    {msg.content}
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-gray-400 italic">No results yet.</p>
          )}
          
          {isLoading && (
            <div className="mt-2 text-purple-600 animate-pulse">
              Agent is thinking...
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
