/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState } from 'react';
import { useCompletion } from 'ai/react';
import { z } from 'zod';

// 1. Define the Zod Schema for validation
const extractionSchema = z.object({
  entities: z.array(
    z.object({
      type: z.string(),
      value: z.string(),
    })
  ),
});

type ExtractionResult = z.infer<typeof extractionSchema>;

export function DataExtractor() {
  // 2. Local state to store the validated result or parsing errors
  const [parsedData, setParsedData] = useState<ExtractionResult | null>(null);
  const [parseError, setParseError] = useState<string | null>(null);
  const [userPrompt, setUserPrompt] = useState('');

  // 3. Initialize useCompletion with an onFinish callback
  const { complete, isLoading } = useCompletion({
    api: '/api/extract',
    onFinish: (prompt, completion) => {
      // Reset previous states
      setParseError(null);
      setParsedData(null);

      try {
        // 4. Attempt to parse the AI's string response as JSON
        const rawJson = JSON.parse(completion);
        
        // 5. Validate the parsed JSON against the Zod schema
        const validatedData = extractionSchema.parse(rawJson);
        
        // Success: Save the typed data
        setParsedData(validatedData);
      } catch (err) {
        // Failure: Handle both JSON parse errors and Zod validation errors
        if (err instanceof z.ZodError) {
          setParseError(`Validation failed: ${err.errors.map(e => e.message).join(', ')}`);
        } else if (err instanceof SyntaxError) {
          setParseError("The AI response was not valid JSON.");
        } else {
          setParseError("An unknown error occurred during parsing.");
        }
      }
    },
  });

  const handleExtract = async () => {
    setParsedData(null);
    setParseError(null);
    await complete(userPrompt);
  };

  return (
    <div className="max-w-2xl mx-auto p-6 bg-white rounded-lg shadow-md">
      <h2 className="text-xl font-bold mb-4">Data Extractor</h2>
      
      <div className="mb-4">
        <input
          type="text"
          value={userPrompt}
          onChange={(e) => setUserPrompt(e.target.value)}
          placeholder="e.g., Extract names from: John Doe and Jane Smith..."
          className="w-full p-2 border rounded mb-2"
        />
        <button
          onClick={handleExtract}
          disabled={isLoading}
          className="px-4 py-2 bg-blue-600 text-white rounded"
        >
          {isLoading ? 'Extracting...' : 'Extract Entities'}
        </button>
      </div>

      {/* 6. Conditional Rendering based on State */}
      {parseError && (
        <div className="p-4 bg-red-50 border border-red-200 text-red-700 rounded">
          <strong>Validation Error:</strong> {parseError}
        </div>
      )}

      {parsedData && (
        <div className="p-4 bg-green-50 border border-green-200 rounded">
          <h3 className="font-bold text-green-800 mb-2">Extracted Entities:</h3>
          <ul className="list-disc pl-5 space-y-1">
            {parsedData.entities.map((entity, index) => (
              <li key={index} className="text-sm text-green-900">
                <span className="font-semibold">{entity.type}:</span> {entity.value}
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
}
