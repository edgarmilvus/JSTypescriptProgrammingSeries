/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

// main.ts
// ------------------------------------------------------------
// 1. IMPORTS
// ------------------------------------------------------------
import { z } from 'zod';

// ------------------------------------------------------------
// 2. TOOL DEFINITION (SCHEMA)
// ------------------------------------------------------------
/**
 * Defines the structure of the arguments required for the weather tool.
 * We use Zod for runtime validation, ensuring the data is safe before processing.
 * 
 * Schema: { city: string }
 */
const WeatherToolSchema = z.object({
  city: z.string().min(1, "City name cannot be empty"),
});

// Infer the TypeScript type from the Zod schema for type safety
type WeatherToolInput = z.infer<typeof WeatherToolSchema>;

// ------------------------------------------------------------
// 3. TOOL EXECUTION HANDLER
// ------------------------------------------------------------
/**
 * Simulates fetching weather data from an external API.
 * In a real app, this would call a service like OpenWeatherMap.
 * 
 * @param input - The validated arguments from the LLM
 * @returns - A string containing the weather report
 */
async function getWeather(input: WeatherToolInput): Promise<string> {
  // Simulate an async network call
  await new Promise(resolve => setTimeout(resolve, 100)); 
  
  // Mock logic: Random weather for demonstration
  const conditions = ['Sunny', 'Cloudy', 'Rainy', 'Stormy'];
  const temp = Math.floor(Math.random() * 30) + 5; // 5 to 35 degrees
  const condition = conditions[Math.floor(Math.random() * conditions.length)];

  return `Current weather in ${input.city}: ${condition}, ${temp}°C.`;
}

// ------------------------------------------------------------
// 4. MAIN ORCHESTRATION LOGIC
// ------------------------------------------------------------
/**
 * Simulates the main SaaS backend loop.
 * 1. Receives a user query.
 * 2. Simulates LLM deciding to call a tool.
 * 3. Validates and executes the tool.
 * 4. Returns the final response.
 */
async function main() {
  console.log('--- SaaS Weather Agent Starting ---\n');

  // Step A: Simulate an incoming request from a user
  const userQuery = "What's the weather in Tokyo?";
  console.log(`User Query: "${userQuery}"`);

  // Step B: Simulate the LLM response (Tool Call)
  // In a real scenario, this comes from the OpenAI API response object
  // We are mocking the structure: { tool_calls: [{ name, arguments }] }
  const llmResponse = {
    tool_calls: [
      {
        name: "get_weather",
        // The LLM returns arguments as a JSON string
        arguments: JSON.stringify({ city: "Tokyo" }) 
      }
    ]
  };

  console.log('\nLLM decided to call a tool...\n');

  // Step C: Process Tool Calls
  if (llmResponse.tool_calls && llmResponse.tool_calls.length > 0) {
    for (const toolCall of llmResponse.tool_calls) {
      const { name, arguments: argsString } = toolCall;

      console.log(`-> Executing Tool: "${name}"`);
      console.log(`-> Raw Arguments: ${argsString}`);

      try {
        // 1. Parse JSON (Runtime check)
        const rawArgs = JSON.parse(argsString);

        // 2. Validate against Zod Schema (Runtime Validation)
        // If validation fails, it throws a ZodError
        const validatedArgs = WeatherToolSchema.parse(rawArgs);

        // 3. Execute the specific tool handler
        let result: string;
        if (name === "get_weather") {
          result = await getWeather(validatedArgs);
        } else {
          throw new Error(`Unknown tool: ${name}`);
        }

        // Step D: Return Tool Output
        console.log(`-> Tool Output: ${result}`);
        console.log('\n--- Agent Finished ---');
        
      } catch (error) {
        if (error instanceof z.ZodError) {
          console.error(`Validation Error for tool "${name}":`, error.errors);
        } else if (error instanceof SyntaxError) {
          console.error('JSON Parsing Error: LLM returned invalid JSON.');
        } else {
          console.error('Unexpected Error:', error);
        }
      }
    }
  }
}

// Execute the main function
main();
