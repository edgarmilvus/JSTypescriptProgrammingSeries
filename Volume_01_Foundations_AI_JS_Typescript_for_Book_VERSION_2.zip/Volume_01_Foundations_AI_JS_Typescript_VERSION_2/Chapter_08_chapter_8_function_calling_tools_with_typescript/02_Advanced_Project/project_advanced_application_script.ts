/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// app/api/smart-scheduler/route.ts

import { NextResponse } from 'next/server';
import { z } from 'zod';
import { ChatOpenAI } from '@langchain/openai';
import { DynamicTool, Tool } from '@langchain/core/tools';
import { AgentExecutor, createOpenAIFunctionsAgent } from 'langchain/agents';
import { ChatPromptTemplate } from '@langchain/core/prompts';

// ==========================================
// 1. Tool Schema Definition (Zod & Type Inference)
// ==========================================

/**
 * Schema for the "check_availability" tool.
 * We use Zod to define the structure of arguments the LLM must provide.
 * 
 * HOW IT WORKS: 
 * TypeScript's type inference engine automatically creates a type alias 
 * `z.infer<typeof availabilitySchema>` based on this definition.
 * This allows us to use `date` and `time` properties with full type safety 
 * in our tool implementation without writing manual interfaces.
 */
const availabilitySchema = z.object({
  date: z.string().describe("The date of the appointment (YYYY-MM-DD)"),
  time: z.string().describe("The time of the appointment (HH:MM 24h format)"),
});

/**
 * Schema for the "book_appointment" tool.
 * Includes a 'reason' field to demonstrate complex argument passing.
 */
const bookingSchema = z.object({
  date: z.string().describe("The date of the appointment (YYYY-MM-DD)"),
  time: z.string().describe("The time of the appointment (HH:MM 24h format)"),
  name: z.string().describe("The name of the client"),
  reason: z.string().optional().describe("The reason for the visit"),
});

// ==========================================
// 2. Tool Implementation (External Logic)
// ==========================================

/**
 * Simulates a database check for availability.
 * In a real app, this would query a PostgreSQL or MongoDB database.
 */
const checkAvailability = async (args: z.infer<typeof availabilitySchema>) => {
  // Simulate async database lookup
  await new Promise(resolve => setTimeout(resolve, 500));
  
  // Mock logic: 10:00 AM and 14:00 PM are busy
  const busySlots = ['10:00', '14:00'];
  const isAvailable = !busySlots.includes(args.time);

  return JSON.stringify({
    date: args.date,
    time: args.time,
    available: isAvailable,
    message: isAvailable 
      ? `Slot ${args.time} on ${args.date} is free.` 
      : `Slot ${args.time} on ${args.date} is already booked.`
  });
};

/**
 * Simulates booking an appointment in a database.
 */
const bookAppointment = async (args: z.infer<typeof bookingSchema>) => {
  // Simulate async database write
  await new Promise(resolve => setTimeout(resolve, 500));

  // Mock logic: Fail if booking 12:00 (maintenance)
  if (args.time === '12:00') {
    return JSON.stringify({
      success: false,
      message: "System maintenance at 12:00. Cannot book."
    });
  }

  return JSON.stringify({
    success: true,
    bookingId: `BK-${Math.floor(Math.random() * 10000)}`,
    details: args,
    message: `Appointment booked for ${args.name} on ${args.date} at ${args.time}.`
  });
};

// ==========================================
// 3. LangChain Tool Wrappers
// ==========================================

/**
 * Wraps the availability check logic into a LangChain Tool.
 * This allows the LLM to understand the tool's purpose via the description.
 */
const availabilityTool = new DynamicTool({
  name: "check_availability",
  description: "Use this to check if a specific time slot is available on a specific date. Input format: YYYY-MM-DD and HH:MM.",
  func: async (input: string) => {
    try {
      // Parse input using Zod schema to validate LLM output before execution
      const parsed = availabilitySchema.parse(JSON.parse(input));
      return await checkAvailability(parsed);
    } catch (e) {
      return "Error: Invalid input format. Ensure date and time are provided.";
    }
  },
  returnDirect: false, // Return to agent for decision making
});

/**
 * Wraps the booking logic into a LangChain Tool.
 */
const bookingTool = new DynamicTool({
  name: "book_appointment",
  description: "Use this to finalize a booking. Requires date, time, client name, and optional reason.",
  func: async (input: string) => {
    try {
      const parsed = bookingSchema.parse(JSON.parse(input));
      return await bookAppointment(parsed);
    } catch (e) {
      return "Error: Invalid booking details provided.";
    }
  },
  returnDirect: false,
});

// ==========================================
// 4. Agent Setup & Execution
// ==========================================

/**
 * Main Handler for the Next.js API Route.
 * Handles the incoming request from the frontend and orchestrates the agent.
 */
export async function POST(req: Request) {
  try {
    const { message } = await req.json();

    // Initialize the LLM (GPT-4 or GPT-3.5-turbo)
    const llm = new ChatOpenAI({
      model: "gpt-3.5-turbo-0125",
      temperature: 0,
    });

    // Define the System Prompt (Few-Shot Prompting context is usually added here)
    const prompt = ChatPromptTemplate.fromMessages([
      ["system", `
        You are a helpful scheduling assistant for a medical clinic.
        Today's date is ${new Date().toISOString().split('T')[0]}.
        
        Workflow:
        1. Always check availability before booking.
        2. If a slot is busy, suggest the next available hour (e.g., +1 hour).
        3. Once a slot is confirmed available, ask for the client's name to book.
        4. Only book when you have all required details.
      `],
      ["human", "{input}"],
      ["assistant", "{agent_scratchpad}"], // Placeholder for tool thoughts/outputs
    ]);

    // Create the Agent
    const agent = await createOpenAIFunctionsAgent({
      llm,
      tools: [availabilityTool, bookingTool],
      prompt,
    });

    // Create the Executor (Manages multi-turn loops)
    const executor = new AgentExecutor({
      agent,
      tools: [availabilityTool, bookingTool],
      // IMPORTANT: Max iterations prevents infinite loops if the agent gets stuck
      maxIterations: 5, 
      verbose: true, // Logs reasoning to console (useful for debugging)
    });

    // Execute the agent
    const result = await executor.invoke({
      input: message,
    });

    // Return the final response to the Next.js frontend
    return NextResponse.json({
      success: true,
      response: result.output,
    });

  } catch (error) {
    console.error("Agent Error:", error);
    return NextResponse.json(
      { success: false, error: "Failed to process request." },
      { status: 500 }
    );
  }
}
