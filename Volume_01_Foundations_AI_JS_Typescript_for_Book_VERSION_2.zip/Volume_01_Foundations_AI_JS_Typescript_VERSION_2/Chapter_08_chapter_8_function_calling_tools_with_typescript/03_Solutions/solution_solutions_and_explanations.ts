/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

import { z } from "zod";

// 1. Define the Zod Schema
const WeatherQuerySchema = z.object({
  location: z.string().min(2, "Location must be at least 2 characters"),
  unit: z.enum(["celsius", "fahrenheit"]).default("celsius"),
});

// 2. Define the return type for type narrowing
type WeatherQueryResult =
  | { success: true; data: z.infer<typeof WeatherQuerySchema> }
  | { success: false; error: string };

// 3. Implement the Validation Function
export async function validateWeatherQuery(
  data: unknown
): Promise<WeatherQueryResult> {
  try {
    // Attempt to parse the data
    const parsedData = await WeatherQuerySchema.parseAsync(data);
    
    return {
      success: true,
      data: parsedData,
    };
  } catch (error) {
    // Handle Zod validation errors specifically
    if (error instanceof z.ZodError) {
      // Format errors into a readable string (e.g., "location: Required")
      const formattedError = error.issues
        .map((issue) => `${issue.path.join(".")}: ${issue.message}`)
        .("; ");

      return {
        success: false,
        error: formattedError,
      };
    }

    // Handle unexpected errors
    return {
      success: false,
      error: "An unexpected error occurred during validation.",
    };
  }
}
