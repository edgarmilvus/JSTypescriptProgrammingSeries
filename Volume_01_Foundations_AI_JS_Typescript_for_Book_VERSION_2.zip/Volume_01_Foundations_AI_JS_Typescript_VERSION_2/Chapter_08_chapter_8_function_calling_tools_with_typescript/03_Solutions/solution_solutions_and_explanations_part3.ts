/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

import { z } from "zod";

// --- Tool Schemas ---
const BookFlightSchema = z.object({
  from: z.string(),
  to: z.string(),
  date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/), // YYYY-MM-DD
});

const CheckHotelSchema = z.object({
  city: z.string(),
  checkIn: z.string(),
  checkOut: z.string(),
});

// --- Tool Handlers ---

async function bookFlightHandler(args: unknown) {
  const parsed = await BookFlightSchema.parseAsync(args);
  // Simulate API latency
  await new Promise((resolve) => setTimeout(resolve, 500));
  const bookingId = Math.random().toString(36).substring(7).toUpperCase();
  return `Flight booked from ${parsed.from} to ${parsed.to} on ${parsed.date}. Confirmation: ${bookingId}`;
}

async function checkHotelAvailabilityHandler(args: unknown) {
  const parsed = await CheckHotelSchema.parseAsync(args);
  // Simulate API latency
  await new Promise((resolve) => setTimeout(resolve, 300));
  const isAvailable = Math.random() > 0.3; // 70% chance of availability
  return isAvailable 
    ? `Rooms available in ${parsed.city} for dates ${parsed.checkIn} to ${parsed.checkOut}.`
    : `No availability in ${parsed.city} for the selected dates.`;
}

// --- Orchestrator ---

type HandlerMap = {
  [key: string]: (args: unknown) => Promise<string>;
};

const handlers: HandlerMap = {
  bookFlight: bookFlightHandler,
  checkHotelAvailability: checkHotelAvailabilityHandler,
};

export async function executeTool(toolName: string, args: unknown): Promise<string> {
  // 1. Check if tool exists
  const handler = handlers[toolName];
  if (!handler) {
    return `Error: Tool '${toolName}' not found.`;
  }

  // 2. Execute with Resilience
  try {
    const result = await handler(args);
    return result;
  } catch (error) {
    // Standardized error message
    const message = error instanceof Error ? error.message : "An unexpected error occurred";
    return `Error executing tool '${toolName}': ${message}`;
  }
}
