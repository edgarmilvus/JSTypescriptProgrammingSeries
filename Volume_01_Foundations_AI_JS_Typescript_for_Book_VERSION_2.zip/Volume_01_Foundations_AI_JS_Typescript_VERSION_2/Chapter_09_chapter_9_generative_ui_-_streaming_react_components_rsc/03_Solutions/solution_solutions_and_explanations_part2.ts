/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

'use client';

import { useState, useEffect } from 'react';
import { getProductRecommendations } from '@/app/actions/recommend';

// Mock Product Card Component (Client Component)
const ProductCard = ({ product }: { product: any }) => (
  <div className="border p-4 rounded shadow-sm mb-2 flex items-center gap-4 bg-white">
    <div className="bg-gray-200 w-16 h-16 rounded flex-shrink-0 flex items-center justify-center text-xs text-gray-500">
      {product.image ? 'IMG' : 'No Img'}
    </div>
    <div className="flex-grow">
      <h3 className="font-bold">{product.name}</h3>
      <p className="text-green-600">${product.price.toFixed(2)}</p>
    </div>
    <button className="bg-blue-600 text-white px-3 py-1 rounded text-sm hover:bg-blue-700">
      Add to Cart
    </button>
  </div>
);

export function ProductStream({ query }: { query: string }) {
  const [components, setComponents] = useState<React.ReactNode[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function startStream() {
      // 1. Call the server action to get the stream
      const stream = await getProductRecommendations(query);
      const reader = stream.getReader();
      const decoder = new TextDecoder();

      // 2. Read the stream
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        const text = decoder.decode(value, { stream: true });
        const lines = text.split('\n').filter(line => line.trim() !== '');

        for (const line of lines) {
          try {
            const productData = JSON.parse(line);
            
            // 3. Update State immediately
            setComponents(prev => [
              ...prev,
              <ProductCard key={productData.id} product={productData} />
            ]);
          } catch (e) {
            console.error("Failed to parse chunk", e);
          }
        }
      }
      setLoading(false);
    }

    startStream();
  }, [query]);

  return (
    <div className="space-y-2">
      {components.length > 0 ? components : (loading && <p>Thinking...</p>)}
    </div>
  );
}
