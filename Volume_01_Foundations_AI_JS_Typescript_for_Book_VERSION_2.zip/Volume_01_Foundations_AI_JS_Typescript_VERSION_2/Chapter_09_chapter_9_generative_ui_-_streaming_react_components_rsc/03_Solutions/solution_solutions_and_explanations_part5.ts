/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

'use client';

import { useState, useEffect, FormEvent } from 'react';
import { z } from 'zod';

// Schema definition
const FormFieldSchema = z.object({
  type: z.enum(['text', 'email', 'select', 'checkbox']),
  label: z.string(),
  name: z.string(),
  options: z.array(z.string()).optional(),
});

type Field = z.infer<typeof FormFieldSchema>;

export function StreamingForm({ prompt }: { prompt: string }) {
  const [fields, setFields] = useState<Field[]>([]);
  const [isComplete, setIsComplete] = useState(false);

  useEffect(() => {
    // Simulate a stream of form fields arriving one by one
    async function simulateStream() {
      const mockFields: Field[] = [
        { type: 'text', label: 'Full Name', name: 'fullname' },
        { type: 'email', label: 'Email Address', name: 'email' },
        { type: 'select', label: 'Priority', name: 'priority', options: ['Low', 'High'] },
        { type: 'checkbox', label: 'Subscribe to newsletter', name: 'subscribe' },
      ];

      for (const field of mockFields) {
        // Simulate network delay
        await new Promise(r => setTimeout(r, 600));
        setFields(prev => [...prev, field]);
      }
      setIsComplete(true);
    }
    simulateStream();
  }, [prompt]);

  // Progressive Enhancement: Form submission handler
  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    if (!isComplete) {
      alert("Form is still generating! Please wait.");
      return;
    }
    const formData = new FormData(e.target as HTMLFormElement);
    const data = Object.fromEntries(formData);
    console.log("Submitting:", data);
    alert("Form Submitted Successfully!");
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4 max-w-md mx-auto p-4 border rounded bg-gray-50">
      <h2 className="text-lg font-bold">Generated Form</h2>
      
      {fields.map((field, idx) => (
        <div key={idx} className="flex flex-col gap-1 animate-fade-in">
          <label className="text-sm font-medium text-gray-700">{field.label}</label>
          
          {/* Render inputs based on type */}
          {field.type === 'text' || field.type === 'email' ? (
            <input 
              type={field.type} 
              name={field.name} 
              className="border p-2 rounded focus:ring-2 focus:ring-blue-500 outline-none"
              required
            />
          ) : field.type === 'select' ? (
            <select name={field.name} className="border p-2 rounded">
              {field.options?.map(opt => <option key={opt} value={opt}>{opt}</option>)}
            </select>
          ) : field.type === 'checkbox' ? (
            <div className="flex items-center gap-2">
              <input type="checkbox" name={field.name} className="w-4 h-4" />
              <span className="text-sm text-gray-600">Yes</span>
            </div>
          ) : null}
        </div>
      ))}

      <div className="pt-2 border-t mt-4">
        <button 
          type="submit" 
          disabled={!isComplete}
          className={`w-full py-2 rounded text-white font-semibold transition-colors ${
            isComplete ? 'bg-green-600 hover:bg-green-700' : 'bg-gray-400 cursor-not-allowed'
          }`}
        >
          {isComplete ? 'Submit Request' : 'Generating Fields...'}
        </button>
      </div>
    </form>
  );
}
