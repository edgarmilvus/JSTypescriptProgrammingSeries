/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part6.ts
// Description: Solutions and Explanations
// ==========================================

'use server';
import { ChatOpenAI } from '@langchain/openai';
import { DynamicTool } from '@langchain/core/tools';
import { AgentExecutor, createToolCallingAgent } from 'langchain/agents';
import { PromptTemplate } from '@langchain/core/prompts';

// Mock Tools
const flightTool = new DynamicTool({
  name: "search_flights",
  description: "Searches for flights. Returns flight data.",
  func: async () => {
    await new Promise(r => setTimeout(r, 1500)); // Simulate 1.5s delay
    return JSON.stringify([{ id: 'FL123', airline: 'SkyAir', time: '10:00 AM' }]);
  },
});

const hotelTool = new DynamicTool({
  name: "search_hotels",
  description: "Searches for hotels. Returns hotel data.",
  func: async () => {
    await new Promise(r => setTimeout(r, 800)); // Simulate 0.8s delay (arrives before flight)
    return JSON.stringify([{ id: 'HT456', name: 'Grand Plaza', price: '$200' }]);
  },
});

export async function streamTravelPlan(query: string) {
  const model = new ChatOpenAI({ model: "gpt-3.5-turbo", temperature: 0 }).bind({
    stream_usage: true,
  });

  // Create a stream that emits UI components based on tool completion
  const stream = new ReadableStream({
    async start(controller) {
      // Simulate parallel tool execution logic
      // In a real LangChain agent, we'd hook into the 'toolEnd' event.
      // Here we simulate the result stream.
      
      const tools = [
        { name: 'hotel', delay: 800, data: { name: 'Grand Plaza', price: '$200' }, type: 'HotelResults' },
        { name: 'flight', delay: 1500, data: { airline: 'SkyAir', time: '10:00 AM' }, type: 'FlightResults' }
      ];

      // 1. Send Optimistic Placeholder immediately
      controller.enqueue(JSON.stringify({ type: 'Thinking', id: 'hotel-placeholder' }) + '\n');

      // Execute promises in parallel
      const promises = tools.map(async (tool) => {
        await new Promise(r => setTimeout(r, tool.delay));
        
        // Construct the "Component Payload"
        const payload = {
          type: tool.type,
          data: tool.data,
          id: tool.name
        };
        
        // Serialize and send
        controller.enqueue(JSON.stringify(payload) + '\n');
      });

      await Promise.all(promises);
      controller.close();
    }
  });

  return stream;
}
