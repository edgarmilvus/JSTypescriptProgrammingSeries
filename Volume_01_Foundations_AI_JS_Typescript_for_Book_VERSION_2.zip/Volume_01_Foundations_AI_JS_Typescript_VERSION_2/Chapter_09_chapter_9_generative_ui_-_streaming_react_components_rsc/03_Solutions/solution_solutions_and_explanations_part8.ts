/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part8.ts
// Description: Solutions and Explanations
// ==========================================

'use client';

import { useState, useEffect, useRef } from 'react';

type StreamState = {
  content: (string | React.ReactElement)[];
  status: 'idle' | 'streaming' | 'complete' | 'error' | 'resuming';
};

export function useStream(url: string, options: RequestInit = {}) {
  const [state, setState] = useState<StreamState>({
    content: [],
    status: 'idle',
  });
  
  const lastIdRef = useRef<number>(0); // Track index for resume

  const start = async (resume: boolean = false) => {
    setState(prev => ({ ...prev, status: resume ? 'resuming' : 'streaming' }));

    // Append resume token to URL if needed
    const fetchUrl = resume ? `${url}?resumeFrom=${lastIdRef.current}` : url;

    try {
      const response = await fetch(fetchUrl, options);
      
      if (!response.ok || !response.body) {
        throw new Error('Failed to fetch stream');
      }

      const reader = response.body.getReader();
      const decoder = new TextDecoder();
      
      // Buffer for partial chunks
      let buffer = '';

      while (true) {
        const { done, value } = await reader.read();
        
        if (done) {
          setState(prev => ({ ...prev, status: 'complete' }));
          break;
        }

        const chunk = decoder.decode(value, { stream: true });
        buffer += chunk;

        // Process complete lines (control codes)
        const lines = buffer.split('\n');
        // Keep the last incomplete line in buffer
        buffer = lines.pop() || '';

        for (const line of lines) {
          if (!line.trim()) continue;

          // 1. Parse Control Codes
          if (line.startsWith('<START_COMPONENT type="card">')) {
            // We could track nesting here if needed
            continue;
          }
          if (line.startsWith('<END_COMPONENT>')) {
            continue;
          }
          if (line.startsWith('<TEXT>')) {
            const textContent = line.replace('<TEXT>', '').replace('</TEXT>', '');
            setState(prev => ({
              ...prev,
              content: [...prev.content, textContent]
            }));
            lastIdRef.current++;
          }
          if (line.startsWith('<ERROR>')) {
            setState(prev => ({ ...prev, status: 'error' }));
            reader.cancel();
            return;
          }
        }
      }
    } catch (err) {
      console.error("Stream interrupted:", err);
      setState(prev => ({ ...prev, status: 'error' }));
    }
  };

  const reconnect = () => {
    start(true); // True indicates resume
  };

  return { state, start, reconnect };
}
