/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.ts
// Description: Basic Code Example
// ==========================================

// Import necessary modules from the 'openai' package and 'dotenv' for environment variables.
import OpenAI from 'openai';
import dotenv from 'dotenv';

// Load environment variables from a .env file (e.g., OPENAI_API_KEY).
dotenv.config();

/**
 * A simple function to analyze an image using the OpenAI Vision API.
 * 
 * @param {string} imageUrl - The publicly accessible URL of the image to analyze.
 * @returns {Promise<string>} A promise that resolves to the descriptive text from the model.
 * @throws {Error} Throws an error if the API key is missing or the API call fails.
 */
async function analyzeImage(imageUrl: string): Promise<string> {
  // 1. Validate Environment Variables
  // We need an API key to interact with the OpenAI service.
  const apiKey = process.env.OPENAI_API_KEY;
  if (!apiKey) {
    throw new Error('OPENAI_API_KEY is not defined in environment variables.');
  }

  // 2. Initialize the OpenAI Client
  // This creates an instance of the client configured with our API key.
  const openai = new OpenAI({
    apiKey: apiKey,
  });

  // 3. Construct the Multimodal Prompt
  // The prompt must be an array of message objects. For vision, we typically use the 'user' role.
  // The content is an array of text and image_url objects.
  const promptMessages = [
    {
      role: 'user',
      content: [
        {
          type: 'text',
          text: 'Describe this image in detail. What are the main objects, colors, and mood?',
        },
        {
          type: 'image_url',
          image_url: {
            // The Vision API supports both URLs and base64 encoded images.
            // Here we use a URL for simplicity.
            url: imageUrl,
          },
        },
      ],
    },
  ];

  try {
    // 4. Call the OpenAI Chat Completions API
    // We use the 'gpt-4-vision-preview' model (or the latest compatible model) which supports image inputs.
    const response = await openai.chat.completions.create({
      model: 'gpt-4-vision-preview', // Ensure you use a model that supports vision capabilities.
      messages: promptMessages,
      max_tokens: 500, // Limit the response length to control costs and output.
    });

    // 5. Extract and Return the Response
    // The response contains a list of choices. We take the first one.
    const description = response.choices[0]?.message?.content;
    if (!description) {
      throw new Error('No content returned from the API.');
    }

    return description;
  } catch (error) {
    // Handle potential API errors (e.g., network issues, invalid image URL, rate limits).
    console.error('Error analyzing image:', error);
    throw error;
  }
}

// --- Example Usage ---
// This block simulates a web app calling the function.
(async () => {
  try {
    // A sample image URL (a golden retriever puppy playing in a field).
    // In a real app, this URL would come from a user upload (e.g., AWS S3 bucket).
    const sampleImageUrl = 'https://upload.wikimedia.org/wikipedia/commons/thumb/4/47/PNG_transparency_demonstration_1.png/800px-PNG_transparency_demonstration_1.png';
    
    console.log('Analyzing image...');
    
    // Call the function and await the result.
    const description = await analyzeImage(sampleImageUrl);
    
    console.log('\n--- Image Analysis Result ---');
    console.log(description);
    console.log('-----------------------------\n');

  } catch (error) {
    console.error('Failed to run the analysis:', error);
  }
})();
