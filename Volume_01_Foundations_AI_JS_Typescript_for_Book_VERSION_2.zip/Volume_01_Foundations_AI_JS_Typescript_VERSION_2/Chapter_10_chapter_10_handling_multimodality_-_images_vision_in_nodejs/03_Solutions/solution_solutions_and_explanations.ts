/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

import OpenAI from 'openai';
import { z } from 'zod';
import { zodResponseFormat } from 'openai/helpers/zod';

// Define the expected response structure using Zod
const MealAnalysisSchema = z.object({
  description: z.string(),
  calories: z.number(),
  ingredients: z.array(z.string()),
});

// Initialize OpenAI client (ensure OPENAI_API_KEY is in env vars)
const openai = new OpenAI();

/**
 * Analyzes a meal image using the OpenAI Vision API.
 * @param base64Image - The image string prefixed with data URI (e.g., "data:image/jpeg;base64,...")
 * @param prompt - Optional custom prompt for the AI
 * @returns A structured object with description, calories, and ingredients
 */
export async function analyzeMealImage(
  base64Image: string,
  prompt?: string
) {
  try {
    // Strip the data URI prefix if present to get raw base64
    const base64Data = base64Image.replace(/^data:image\/\w+;base64,/, '');

    const response = await openai.chat.completions.create({
      model: 'gpt-4-vision-preview',
      messages: [
        {
          role: 'system',
          content: `You are a nutritional assistant. Analyze the image and return ONLY valid JSON matching this schema:
          {
            "description": "Brief description of the meal",
            "calories": "Estimated total calories (number)",
            "ingredients": ["List", "of", "ingredients"]
          }`,
        },
        {
          role: 'user',
          content: [
            {
              type: 'image_url',
              image_url: {
                url: `data:image/jpeg;base64,${base64Data}`,
                detail: 'high', // Requirement: High detail for accuracy
              },
            },
            {
              type: 'text',
              text: prompt || 'Analyze this meal for nutritional information.',
            },
          ],
        },
      ],
      // Use Zod to enforce JSON output structure
      response_format: zodResponseFormat(MealAnalysisSchema, 'meal_analysis'),
      max_tokens: 300,
    });

    // Extract the content from the response
    const content = response.choices[0].message.content;
    
    if (!content) {
      throw new Error('No content returned from OpenAI');
    }

    // Parse and validate the JSON response using Zod
    const parsedData = JSON.parse(content);
    const validatedData = MealAnalysisSchema.parse(parsedData);

    return validatedData;

  } catch (error: any) {
    // Error Handling: Specific checks for API issues
    if (error instanceof OpenAI.APIError) {
      if (error.status === 429) {
        console.error('OpenAI Rate Limit Exceeded:', error.message);
        throw new Error('API rate limit exceeded. Please try again later.');
      }
      if (error.status === 400) {
        console.error('OpenAI Bad Request:', error.message);
        throw new Error('Invalid image format or request payload.');
      }
    }
    
    // Re-throw generic errors (e.g., Zod validation failures)
    console.error('Image Analysis Error:', error);
    throw error;
  }
}
