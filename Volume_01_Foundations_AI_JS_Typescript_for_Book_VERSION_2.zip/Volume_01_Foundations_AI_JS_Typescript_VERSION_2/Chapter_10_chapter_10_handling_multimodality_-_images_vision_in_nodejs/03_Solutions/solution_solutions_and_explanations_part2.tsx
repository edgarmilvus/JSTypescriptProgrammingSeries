/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.tsx
// Description: Solutions and Explanations
// ==========================================

'use server'; // Marks this file as containing Server Actions

import { revalidatePath } from 'next/cache';
import OpenAI from 'openai';

const openai = new OpenAI();

// 1. Server Action to handle extraction
export async function extractTextFromImage(formData: FormData) {
  const file = formData.get('documentImage') as File | null;

  if (!file || file.size === 0) {
    return { error: 'No file selected' };
  }

  // Convert file to base64
  const bytes = await file.arrayBuffer();
  const base64Image = Buffer.from(bytes).toString('base64');

  try {
    const response = await openai.chat.completions.create({
      model: 'gpt-4-vision-preview',
      messages: [
        {
          role: 'user',
          content: [
            {
              type: 'image_url',
              image_url: {
                url: `data:image/jpeg;base64,${base64Image}`,
                detail: 'high',
              },
            },
            {
              type: 'text',
              text: 'Extract all text from this document verbatim. Return only the text.',
            },
          ],
        },
      ],
      max_tokens: 1000,
    });

    const extractedText = response.choices[0].message.content || '';
    
    // Revalidate the path to update the UI if needed
    revalidatePath('/digitizer');

    return { text: extractedText };
  } catch (error) {
    console.error('OCR Error:', error);
    return { error: 'Failed to extract text from image.' };
  }
}

// 2. React Server Component UI
import { extractTextFromImage } from './actions';

export default function DocumentDigitizer() {
  return (
    <div className="p-6 max-w-2xl mx-auto">
      <h1 className="text-2xl font-bold mb-4">Document Digitizer</h1>
      
      {/* 3. Form utilizing the Server Action */}
      <form action={extractTextFromImage} className="space-y-4">
        <div className="border-2 border-dashed p-4 rounded text-center">
          <input 
            type="file" 
            name="documentImage" 
            accept="image/*" 
            className="block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100"
          />
        </div>
        
        <button 
          type="submit" 
          className="w-full bg-blue-600 text-white py-2 rounded hover:bg-blue-700 transition"
        >
          Extract Text
        </button>
      </form>

      {/* 4. Result Display Area (Server-side rendering of results) */}
      {/* Note: In a real app, you might use `useFormState` to handle the result object */}
      <div className="mt-6 p-4 bg-gray-50 rounded min-h-[100px]">
        <h2 className="font-semibold mb-2">Extracted Text:</h2>
        {/* This would typically be populated by the form action result */}
        <p className="text-gray-600 italic text-sm">
          Upload an image and click extract to see results here.
        </p>
      </div>
    </div>
  );
}
