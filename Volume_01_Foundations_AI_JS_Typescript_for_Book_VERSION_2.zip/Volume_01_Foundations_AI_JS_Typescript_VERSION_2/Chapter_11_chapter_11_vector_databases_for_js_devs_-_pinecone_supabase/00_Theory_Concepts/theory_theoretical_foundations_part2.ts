/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part2.ts
// Description: Theoretical Foundations
// ==========================================

// ANTI-PATTERN: Mutating state in place. This is dangerous and unpredictable.

let sharedVector: Vector = [0.1, 0.2, 0.3];

function updateVector(newData: number[]) {
    // This directly mutates the original array, which can cause
    // race conditions and unexpected side effects in a concurrent system.
    sharedVector.length = 0; // Clear the array
    sharedVector.push(...newData);
}

// The correct approach is to create new copies.
// This aligns with functional programming principles and ensures
// that each version of a vector is preserved for auditing and consistency.

let immutableVector: Vector = [0.1, 0.2, 0.3];

function createUpdatedVector(original: Vector, newData: number[]): Vector {
    // Return a new array, leaving the original untouched.
    return [...original, ...newData]; // Or a more complex transformation.
}

const newVector = createUpdatedVector(immutableVector, [0.4, 0.5]);
// Now, `immutableVector` is still [0.1, 0.2, 0.3], and `newVector` is [0.1, 0.2, 0.3, 0.4, 0.5].
