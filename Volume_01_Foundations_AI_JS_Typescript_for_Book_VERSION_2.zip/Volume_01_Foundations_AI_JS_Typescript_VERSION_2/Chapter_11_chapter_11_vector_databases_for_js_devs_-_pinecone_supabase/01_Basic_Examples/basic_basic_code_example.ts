/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

// File: semantic-search.ts
// Run with: npx tsx semantic-search.ts

import { createClient } from '@supabase/supabase-js';
import OpenAI from 'openai';

// ============================================================================
// 1. CONFIGURATION & SETUP
// ============================================================================

// Load environment variables (Supabase URL, Key, OpenAI Key)
// In a real app, use 'dotenv' or Vercel/System environment variables.
const SUPABASE_URL = process.env.SUPABASE_URL || 'https://your-project.supabase.co';
const SUPABASE_KEY = process.env.SUPABASE_KEY || 'your-anon-key';
const OPENAI_API_KEY = process.env.OPENAI_API_KEY || 'your-openai-key';

// Initialize Clients
const supabase = createClient(SUPABASE_URL, SUPABASE_KEY);
const openai = new OpenAI({ apiKey: OPENAI_API_KEY });

// The specific table in Supabase where we store vectors
const TABLE_NAME = 'documents';
const COLUMN_NAME = 'embedding';

/**
 * The user's natural language question.
 * In a web app, this comes from a form input (e.g., req.body.query).
 */
const USER_QUERY = "How do I reset my password?";

// ============================================================================
// 2. THE LOGIC FLOW
// ============================================================================

/**
 * Main entry point.
 * 1. Generates an embedding for the user query.
 * 2. Queries Supabase for the closest matching document.
 * 3. Logs the result.
 */
async function semanticSearch() {
  console.log(`\n🔍 Searching for: "${USER_QUERY}"\n`);

  // --- Step A: Generate Query Vector ---
  // We must use the EXACT SAME model used to create the database vectors.
  // For this example, assume 'text-embedding-ada-002' was used previously.
  const embeddingResponse = await openai.embeddings.create({
    model: 'text-embedding-ada-002',
    input: USER_QUERY,
  });

  // Extract the vector array (e.g., [0.1, -0.2, 0.05, ...])
  const queryVector = embeddingResponse.data[0].embedding;

  // --- Step B: Perform Semantic Search via pgvector ---
  // We use a raw SQL query with the '<=>' operator (Cosine Distance).
  // Lower distance = Higher similarity.
  const { data: documents, error } = await supabase.rpc('match_documents', {
    query_embedding: queryVector,
    match_threshold: 0.78, // Cosine similarity threshold (0 to 1)
    match_count: 1,        // Limit results
  });

  if (error) {
    console.error("❌ Database Error:", error);
    return;
  }

  // --- Step C: Handle Results ---
  if (!documents || documents.length === 0) {
    console.log("🤷 No relevant documents found.");
    return;
  }

  // In a real app, this content is fed into an LLM to generate the final answer.
  const bestMatch = documents[0];
  console.log("✅ Found Relevant Context:");
  console.log(`   Content: "${bestMatch.content}"`);
  console.log(`   Similarity Score: ${1 - bestMatch.similarity_distance}`);
}

// Execute
semanticSearch().catch(console.error);
