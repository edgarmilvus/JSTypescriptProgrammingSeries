/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// pages/api/assistant.ts (Next.js API Route)
import { NextApiRequest, NextApiResponse } from 'next';
import { createClient } from '@supabase/supabase-js';
import { OpenAIEmbeddings } from '@langchain/openai';
import { ChatOpenAI } from '@langchain/openai';
import { SupabaseVectorStore } from '@langchain/community/vectorstores/supabase';
import { PromptTemplate } from '@langchain/core/prompts';
import { RetrievalQAChain } from 'langchain/chains';

// 1. CONFIGURATION & INITIALIZATION
// Initialize Supabase client with pgvector support enabled.
// Critical: Ensure the 'documents' table has a 'embedding' column of type 'vector(1536)'.
const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL!;
const supabaseKey = process.env.SUPABASE_SERVICE_ROLE_KEY!;
const supabaseClient = createClient(supabaseUrl, supabaseKey);

// Initialize OpenAI LLM and Embedding models.
// 'text-embedding-ada-002' generates 1536-dimensional vectors.
const embeddings = new OpenAIEmbeddings({
  openAIApiKey: process.env.OPENAI_API_KEY,
  modelName: 'text-embedding-ada-002',
});

const llm = new ChatOpenAI({
  openAIApiKey: process.env.OPENAI_API_KEY,
  modelName: 'gpt-4-turbo-preview',
  temperature: 0.7,
});

/**
 * Handler for Next.js API requests.
 * Supports two operations:
 * 1. POST /api/assistant -> Ingest text chunks into the vector store.
 * 2. GET /api/assistant?q= -> Perform semantic search and RAG.
 */
export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  // CORS Headers (Optional but recommended for SaaS apps)
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, GET, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  try {
    // 2. INGESTION LOGIC (Upsert Operation)
    if (req.method === 'POST') {
      const { text, metadata } = req.body; // Expect raw text and optional metadata

      if (!text) {
        return res.status(400).json({ error: 'Text content is required.' });
      }

      // LangChain handles chunking and embedding generation automatically.
      // We use SupabaseVectorStore to manage the 'upsert' operation.
      // This adds new vectors or updates existing ones based on unique IDs.
      await SupabaseVectorStore.fromTexts(
        [text], // Input text array
        [{ source: 'user_upload', ...metadata }], // Metadata array
        embeddings, // The embedding model
        {
          client: supabaseClient,
          tableName: 'documents',
          queryName: 'documents_query', // A custom RPC function for similarity search in Supabase
        }
      );

      return res.status(200).json({ message: 'Document ingested successfully.' });
    }

    // 3. RETRIEVAL & GENERATION LOGIC (RAG)
    if (req.method === 'GET') {
      const query = req.query.q as string;

      if (!query) {
        return res.status(400).json({ error: 'Query parameter "q" is required.' });
      }

      // Initialize the Vector Store interface with our Supabase connection
      const vectorStore = new SupabaseVectorStore(embeddings, {
        client: supabaseClient,
        tableName: 'documents',
        queryName: 'documents_query',
      });

      // 4. SEMANTIC SEARCH & RETRIEVAL
      // We perform a similarity search to find the top 4 most relevant chunks.
      // This uses the cosine distance metric under the hood in pgvector.
      const retriever = vectorStore.asRetriever({
        k: 4, // Number of documents to retrieve
        searchType: 'similarity', // Can also be 'mmr' for diversity
      });

      // 5. CHAIN CONSTRUCTION (LangChain.js)
      // We construct a RetrievalQAChain which links the retriever to the LLM.
      // It automatically injects retrieved context into the prompt.
      const chain = RetrievalQAChain.fromLLM(llm, retriever);

      // Custom Prompt Template for better context handling
      const prompt = new PromptTemplate({
        template: `
          You are a helpful AI assistant for a SaaS platform.
          Use the following context to answer the user's question.
          If you don't know the answer based on the context, say so.
          
          Context: {context}
          
          Question: {question}
          
          Answer:
        `,
        inputVariables: ['context', 'question'],
      });

      // 6. EXECUTION
      // Pass the query through the chain.
      const response = await chain.call({
        query: query,
      });

      return res.status(200).json({
        answer: response.text,
        sources: response.sourceDocuments, // Optional: return the raw chunks used
      });
    }

    return res.status(405).json({ error: 'Method not allowed' });

  } catch (error) {
    console.error('Vector Database Error:', error);
    return res.status(500).json({ error: 'Internal server error during vector processing.' });
  }
}
