/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// 1. Define the Document interface
interface Document {
  id: string;
  content: string;
  embedding: number[];
}

/**
 * Calculates the Cosine Similarity between two vectors.
 * Formula: (A . B) / (||A|| * ||B||)
 */
function cosineSimilarity(vecA: number[], vecB: number[]): number {
  if (vecA.length !== vecB.length) {
    throw new Error("Vectors must be of the same dimension");
  }

  // Calculate Dot Product
  let dotProduct = 0;
  let normA = 0;
  let normB = 0;

  for (let i = 0; i < vecA.length; i++) {
    dotProduct += vecA[i] * vecB[i];
    normA += vecA[i] * vecA[i];
    normB += vecB[i] * vecB[i];
  }

  // Calculate Magnitudes (L2 Norm)
  const magA = Math.sqrt(normA);
  const magB = Math.sqrt(normB);

  // Handle division by zero
  if (magA === 0 || magB === 0) return 0;

  return dotProduct / (magA * magB);
}

/**
 * Performs a vector search to find the top k most similar documents.
 */
function vectorSearch(queryVector: number[], documents: Document[], k: number): Document[] {
  // 1. Calculate similarity scores for all documents
  const scoredDocs = documents.map((doc) => {
    const score = cosineSimilarity(queryVector, doc.embedding);
    return { ...doc, score };
  });

  // 2. Sort by score in descending order
  scoredDocs.sort((a, b) => b.score - a.score);

  // 3. Return top k documents (strip the score if strict return type is Document[])
  return scoredDocs.slice(0, k).map(({ score, ...keepAttrs }) => keepAttrs);
}

// --- Example Usage ---
const mockDocuments: Document[] = [
  { id: '1', content: 'JavaScript is a scripting language', embedding: [0.1, 0.2, 0.3] },
  { id: '2', content: 'TypeScript adds static typing', embedding: [0.9, 0.8, 0.7] },
  { id: '3', content: 'Python is great for data science', embedding: [0.2, 0.3, 0.4] },
];

const query: number[] = [0.15, 0.25, 0.35];
const results = vectorSearch(query, mockDocuments, 2);
console.log(results);
