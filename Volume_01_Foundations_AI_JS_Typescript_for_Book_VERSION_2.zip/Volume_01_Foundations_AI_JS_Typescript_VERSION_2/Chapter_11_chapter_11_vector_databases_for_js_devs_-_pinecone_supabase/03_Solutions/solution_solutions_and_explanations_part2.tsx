/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState } from 'react';

// 1. Define Types
type SearchResult = {
  text: string;
  score: number;
};

// 2. Mock API Implementation
const mockSemanticSearch = async (query: string): Promise<SearchResult[]> => {
  // Simulate network delay
  await new Promise(resolve => setTimeout(resolve, 500));

  // Mock data: varying scores based on "relevance" (simulated)
  // In a real app, this would come from the backend
  const mockData: SearchResult[] = [
    { text: "How to install React?", score: 0.95 },
    { text: "State management in React", score: 0.82 },
    { text: "JavaScript basics", score: 0.65 },
    { text: "Advanced CSS techniques", score: 0.40 },
  ];

  // Filter based on query length just to show some dynamic behavior
  // (In a real scenario, the backend handles the filtering/ranking)
  return mockData.filter(item => 
    item.text.toLowerCase().includes(query.toLowerCase()) || query.length < 3
  );
};

// 3. Component Implementation
const SemanticSearchBar: React.FC = () => {
  const [query, setQuery] = useState<string>('');
  const [results, setResults] = useState<SearchResult[]>([]);
  const [loading, setLoading] = useState<boolean>(false);

  const handleSearch = async () => {
    if (!query.trim()) return;

    setLoading(true);
    try {
      const data = await mockSemanticSearch(query);
      setResults(data);
    } catch (error) {
      console.error("Search failed:", error);
      setResults([]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{ padding: '20px', maxWidth: '500px', margin: '0 auto' }}>
      <div style={{ display: 'flex', gap: '10px', marginBottom: '20px' }}>
        <input
          type="text"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Enter your query..."
          style={{ flex: 1, padding: '8px' }}
          onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
        />
        <button onClick={handleSearch} disabled={loading} style={{ padding: '8px 16px' }}>
          {loading ? 'Searching...' : 'Search'}
        </button>
      </div>

      {loading && <p>Loading results...</p>}

      <ul style={{ listStyle: 'none', padding: 0 }}>
        {results.map((result, index) => (
          <li key={index} style={{ borderBottom: '1px solid #eee', padding: '10px 0' }}>
            <div style={{ fontWeight: 'bold' }}>{result.text}</div>
            <div style={{ fontSize: '0.85em', color: '#666' }}>
              Similarity Score: {result.score.toFixed(3)}
            </div>
          </li>
        ))}
      </ul>
      
      {!loading && results.length === 0 && query && <p>No results found.</p>}
    </div>
  );
};

export default SemanticSearchBar;
