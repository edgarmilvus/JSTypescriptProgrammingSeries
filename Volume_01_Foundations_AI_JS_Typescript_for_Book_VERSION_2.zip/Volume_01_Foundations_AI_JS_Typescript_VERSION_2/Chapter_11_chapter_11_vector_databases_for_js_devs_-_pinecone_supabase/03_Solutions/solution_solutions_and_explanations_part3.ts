/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

// 1. Interface Definitions
interface PineconeMetadata {
  sourceUrl: string;
  chunkIndex: number;
  pageStart: number;
}

interface PineconeVector {
  id: string;
  values: number[];
  metadata: PineconeMetadata;
}

// 2. Batching Logic
function chunkArrayForUpsert<T>(items: T[], batchSize: number): T[][] {
  const chunks: T[][] = [];
  for (let i = 0; i < items.length; i += batchSize) {
    chunks.push(items.slice(i, i + batchSize));
  }
  return chunks;
}

// 3. Upsert Preparation Function
function upsertToPinecone(
  documents: Array<{ id: string; embedding: number[]; content: string; url: string }>
): void {
  // Define Pinecone batch limit (standard is usually 100 vectors per upsert)
  const BATCH_SIZE = 100;

  // Transform raw documents into PineconeVector format
  const vectors: PineconeVector[] = documents.map((doc, index) => ({
    id: doc.id,
    values: doc.embedding,
    metadata: {
      sourceUrl: doc.url,
      chunkIndex: index,
      pageStart: Math.floor(index / 10) + 1 // Mock calculation for page number
    }
  }));

  // Split into batches
  const batches = chunkArrayForUpsert(vectors, BATCH_SIZE);

  console.log(`Prepared ${vectors.length} vectors for upsert.`);
  console.log(`Split into ${batches.length} batches of size ${BATCH_SIZE}.`);

  // Simulation of the upsert process
  batches.forEach((batch, batchIndex) => {
    // In a real app: await pineconeIndex.upsert(batch);
    console.log(`Upserting batch ${batchIndex + 1}...`, batch);
  });
}

// --- Example Usage ---
const mockDocs = [
  { id: 'doc_1', embedding: [0.1, 0.2], content: 'Intro', url: 'http://example.com/1' },
  { id: 'doc_2', embedding: [0.3, 0.4], content: 'Body', url: 'http://example.com/2' },
  // ... imagine 150 items
];
// Generate dummy data to test batching
const largeDataset = Array(250).fill(0).map((_, i) => ({
    id: `doc_${i}`,
    embedding: [Math.random(), Math.random()],
    content: `Content ${i}`,
    url: `http://example.com/${i}`
}));

upsertToPinecone(largeDataset);
