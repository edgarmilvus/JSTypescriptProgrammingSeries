/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

import * as readline from 'readline';

// 1. Interfaces and Helper (Reused from Exercise 1)
interface Document {
  id: string;
  content: string;
  embedding: number[];
}

function cosineSimilarity(vecA: number[], vecB: number[]): number {
  let dotProduct = 0, normA = 0, normB = 0;
  for (let i = 0; i < vecA.length; i++) {
    dotProduct += vecA[i] * vecB[i];
    normA += vecA[i] * vecA[i];
    normB += vecB[i] * vecB[i];
  }
  return dotProduct / (Math.sqrt(normA) * Math.sqrt(normB));
}

function vectorSearch(queryVector: number[], documents: Document[], k: number): Document[] {
  const scoredDocs = documents.map((doc) => ({
    ...doc,
    score: cosineSimilarity(queryVector, doc.embedding),
  }));
  scoredDocs.sort((a, b) => b.score - a.score);
  return scoredDocs.slice(0, k);
}

// 2. Setup Mock Data
const mockDocs: Document[] = [
  { id: '1', content: 'Vector DB Basics', embedding: [0.9, 0.1, 0.1] },
  { id: '2', content: 'Advanced Indexing', embedding: [0.85, 0.15, 0.1] },
  { id: '3', content: 'RAG Architecture', embedding: [0.8, 0.2, 0.2] },
  { id: '4', content: 'Embedding Models', embedding: [0.7, 0.3, 0.3] },
  { id: '5', content: 'Pinecone vs Weaviate', embedding: [0.6, 0.4, 0.4] },
  { id: '6', content: 'Supabase Setup', embedding: [0.5, 0.5, 0.5] },
  { id: '7', content: 'SQL Optimization', embedding: [0.4, 0.6, 0.6] },
  { id: '8', content: 'React Hooks', embedding: [0.3, 0.7, 0.7] },
  { id: '9', content: 'TypeScript Types', embedding: [0.2, 0.8, 0.8] },
  { id: '10', content: 'Node.js Streams', embedding: [0.1, 0.9, 0.9] },
];

const queryVector: number[] = [0.8, 0.2, 0.2]; // Closely matches "RAG Architecture"

// 3. Interactive Logic
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

console.log("--- Similarity Slider Tool ---");
console.log("Query Vector: [0.8, 0.2, 0.2]");
console.log("Dataset Size: 10 documents");
console.log("-----------------------------");

rl.question('Enter k value (1-10): ', (kInput) => {
  const k = parseInt(kInput, 10);

  if (isNaN(k) || k < 1 || k > 10) {
    console.log("Invalid input. Please enter an integer between 1 and 10.");
    rl.close();
    return;
  }

  const results = vectorSearch(queryVector, mockDocs, k);
  
  // Calculate Average Score
  const totalScore = results.reduce((sum, doc) => sum + (doc as any).score, 0);
  const avgScore = totalScore / k;

  console.log(`\nTop ${k} Results:`);
  results.forEach((doc: any) => {
    console.log(`- [Score: ${doc.score.toFixed(4)}] ${doc.content}`);
  });

  console.log(`\nAverage Similarity Score: ${avgScore.toFixed(4)}`);
  
  // Analysis Logic
  if (k > 3) {
    console.log(`\nAnalysis: Increasing k to ${k} lowered the average score to ${avgScore.toFixed(4)}, potentially introducing less relevant documents (noise).`);
  } else {
    console.log(`\nAnalysis: Keeping k at ${k} maintains a high average score of ${avgScore.toFixed(4)}, focusing on high precision.`);
  }

  rl.close();
});
