/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.ts
// Description: Basic Code Example
// ==========================================

/**
 * RAG Pipeline: Data Ingestion (Loading & Splitting)
 * 
 * This script demonstrates the first stage of a RAG pipeline. It loads a text
 * document and splits it into chunks suitable for embedding and retrieval.
 * 
 * Context: SaaS Application / Node.js Environment
 * Dependencies: langchain, @langchain/community
 */

import { RecursiveCharacterTextSplitter } from 'langchain/text_splitter';
import { Document } from '@langchain/core/documents';
import * as fs from 'fs';
import * as path from 'path';

/**
 * 1. SETUP & MOCK DATA
 * 
 * In a real SaaS app, this data would come from a database, an API, or a file upload.
 * For this standalone example, we create a dummy text file to simulate a document.
 */
const setupMockDocument = async (): Promise<string> => {
    const fileName = 'user_manual.txt';
    const filePath = path.join(process.cwd(), fileName);
    
    // A long text to demonstrate chunking
    const content = `
        Chapter 1: Introduction to the System
        The system is designed for high performance and scalability. It utilizes a distributed architecture to ensure reliability.
        
        Chapter 2: Installation
        To install the software, run the setup.exe file. Ensure you have Node.js v18+ installed. 
        Follow the on-screen prompts. If you encounter errors, check the logs in the /var/log directory.
        
        Chapter 3: Configuration
        Configuration is handled via the config.json file. Key parameters include API keys and timeout settings. 
        Always keep your API keys secure. Do not commit them to version control.
        
        Chapter 4: Troubleshooting
        Common issues include connection timeouts and memory leaks. To resolve memory leaks, monitor heap usage.
        Restarting the service often resolves transient network issues. Contact support if problems persist.
    `;

    // Write the file to disk
    fs.writeFileSync(filePath, content.trim());
    console.log(`[System] Mock document created: ${fileName}`);
    return filePath;
};

/**
 * 2. LOAD THE DOCUMENT
 * 
 * While LangChain offers specialized loaders (e.g., PDFLoader, WebLoader), 
 * we use the native Node.js 'fs' module here for maximum simplicity and clarity.
 * In a production app, you would use `TextLoader` from `@langchain/community/document_loaders/fs/text`.
 */
const loadDocument = async (filePath: string): Promise<Document> => {
    console.log(`[Loader] Reading file from: ${filePath}`);
    
    const text = fs.readFileSync(filePath, 'utf-8');
    
    // LangChain's Document object wraps raw content with metadata
    return new Document({
        pageContent: text,
        metadata: {
            source: filePath,
            chunkId: 0 // Initial metadata
        }
    });
};

/**
 * 3. SPLIT THE DOCUMENT
 * 
 * LLMs have limited context windows. We must split large documents into smaller chunks.
 * 
 * Strategy: RecursiveCharacterTextSplitter
 * - It attempts to split by characters (newlines, spaces) recursively.
 * - It prioritizes keeping meaningful units (like paragraphs) together.
 * - 'chunkSize': The maximum size of a chunk (in characters).
 * - 'chunkOverlap': How much text overlaps between consecutive chunks (preserves context).
 */
const splitDocument = async (document: Document): Promise<Document[]> => {
    console.log(`[Splitter] Initializing RecursiveCharacterTextSplitter...`);
    
    const splitter = new RecursiveCharacterTextSplitter({
        chunkSize: 500,    // Small chunks for this demo
        chunkOverlap: 50   // Slight overlap to maintain flow
    });

    console.log(`[Splitter] Splitting document...`);
    const chunks = await splitter.splitDocuments([document]);
    
    return chunks;
};

/**
 * 4. MAIN EXECUTION FLOW
 * 
 * Orchestrates the loading and splitting process.
 */
const runRagIngestion = async () => {
    try {
        // Step A: Prepare environment
        const filePath = await setupMockDocument();

        // Step B: Load raw data
        const rawDocument = await loadDocument(filePath);

        // Step C: Process data (Splitting)
        const chunks = await splitDocument(rawDocument);

        // Step D: Output results
        console.log('\n=== RAG Pipeline: Ingestion Results ===');
        console.log(`Total Chunks Generated: ${chunks.length}\n`);

        chunks.forEach((chunk, index) => {
            console.log(`--- Chunk ${index + 1} ---`);
            console.log(`Content: "${chunk.pageContent.replace(/\n/g, ' ').trim()}"`);
            console.log(`Metadata: ${JSON.stringify(chunk.metadata)}`);
            console.log(`Size: ${chunk.pageContent.length} chars\n`);
        });

        // Cleanup: Remove the mock file
        fs.unlinkSync(filePath);
        console.log('[System] Cleanup complete.');

    } catch (error) {
        console.error('[Error] Pipeline failed:', error);
    }
};

// Execute the script
runRagIngestion();
