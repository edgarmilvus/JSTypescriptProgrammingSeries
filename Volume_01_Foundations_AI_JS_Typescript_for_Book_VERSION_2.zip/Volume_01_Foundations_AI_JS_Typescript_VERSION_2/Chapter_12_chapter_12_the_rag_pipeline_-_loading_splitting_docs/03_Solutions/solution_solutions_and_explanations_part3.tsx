/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState } from 'react';

type FileStatus = {
  path: string;
  status: 'idle' | 'loading' | 'splitting' | 'complete';
  chunkCount: number | null;
};

type IngestionPipelineDashboardProps = {
  filePaths: string[];
};

const IngestionPipelineDashboard: React.FC<IngestionPipelineDashboardProps> = ({ filePaths }) => {
  // Initialize state
  const [files, setFiles] = useState<FileStatus[]>(
    filePaths.map(path => ({ path, status: 'idle', chunkCount: null }))
  );

  const updateFileStatus = (path: string, updates: Partial<FileStatus>) => {
    setFiles(prev => prev.map(f => f.path === path ? { ...f, ...updates } : f));
  };

  const simulateIngestion = async (path: string) => {
    // Step 1: Loading
    updateFileStatus(path, { status: 'loading' });
    await new Promise(resolve => setTimeout(resolve, 1000)); // 1s delay

    // Step 2: Splitting
    updateFileStatus(path, { status: 'splitting' });
    await new Promise(resolve => setTimeout(resolve, 500)); // 0.5s delay

    // Step 3: Complete
    const randomChunkCount = Math.floor(Math.random() * (20 - 5 + 1)) + 5;
    updateFileStatus(path, { 
      status: 'complete', 
      chunkCount: randomChunkCount 
    });
  };

  const startIngestion = async (targetPaths?: string[]) => {
    const targets = targetPaths || files.map(f => f.path);
    // Process sequentially for individual updates, or use Promise.all for concurrency
    // Here we use Promise.all for the "Bonus" requirement (concurrency)
    const promises = targets.map(path => simulateIngestion(path));
    await Promise.all(promises);
  };

  const getIndicatorColor = (status: string) => {
    switch (status) {
      case 'loading': return 'yellow';
      case 'splitting': return 'orange';
      case 'complete': return 'green';
      default: return 'gray';
    }
  };

  return (
    <div style={{ padding: '20px', fontFamily: 'sans-serif' }}>
      <div style={{ marginBottom: '20px' }}>
        <button 
          onClick={() => startIngestion()} 
          style={{ padding: '8px 16px', cursor: 'pointer' }}
        >
          Start All Ingestion
        </button>
      </div>

      <ul style={{ listStyle: 'none', padding: 0 }}>
        {files.map(file => (
          <li key={file.path} style={{ marginBottom: '10px', padding: '10px', border: '1px solid #eee', borderRadius: '4px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <div>
              <span style={{ marginRight: '10px', color: '#555' }}>{file.path}</span>
              <span style={{ fontWeight: 'bold', color: '#333' }}>{file.status.toUpperCase()}</span>
            </div>
            
            <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
              {file.status !== 'idle' && (
                <div 
                  style={{ 
                    width: '12px', 
                    height: '12px', 
                    borderRadius: '50%', 
                    backgroundColor: getIndicatorColor(file.status) 
                  }} 
                />
              )}
              
              {file.chunkCount !== null && (
                <span style={{ color: 'green', fontWeight: 'bold' }}>
                  Chunks: {file.chunkCount}
                </span>
              )}
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default IngestionPipelineDashboard;
