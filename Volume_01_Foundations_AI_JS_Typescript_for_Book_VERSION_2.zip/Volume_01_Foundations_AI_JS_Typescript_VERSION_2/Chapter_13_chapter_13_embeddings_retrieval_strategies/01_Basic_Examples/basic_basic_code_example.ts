/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * SIMPLE RAG PIPELINE: Product Knowledge Base Assistant
 * 
 * Context: SaaS App - Internal Support Tool
 * Goal: Answer user queries by retrieving relevant context from a stored knowledge base.
 * 
 * Note: This is a "Hello World" example using an in-memory vector store.
 * In production, you would use a dedicated vector database (e.g., Pinecone, pgvector).
 */

import OpenAI from 'openai';

// 1. CONFIGURATION
// -----------------------------------------------------------------------------
const OPENAI_API_KEY = process.env.OPENAI_API_KEY || 'sk-your-api-key-here';
const openai = new OpenAI({ apiKey: OPENAI_API_KEY });

// Mock database of documents (Product Knowledge Base)
const documents = [
  { id: 'doc_1', content: 'The SmartLight X1 uses a standard E26 base and consumes 10W.' },
  { id: 'doc_2', content: 'To reset the SmartLight X1, toggle the power switch 5 times rapidly.' },
  { id: 'doc_3', content: 'The warranty for the SmartLight X1 is 2 years for residential use.' },
  { id: 'doc_4', content: 'The SmartLight X1 is compatible with Alexa, Google Home, and Apple HomeKit.' },
];

// 2. VECTOR STORE SIMULATION
// -----------------------------------------------------------------------------

/**
 * Represents a vector entry in our store.
 * In a real DB, this would be a row in a table with a vector column.
 */
interface VectorEntry {
  id: string;
  content: string;
  embedding: number[]; // The numerical vector representation
}

/**
 * A simple in-memory vector store class.
 * This simulates the behavior of a dedicated vector database.
 */
class InMemoryVectorStore {
  private vectors: VectorEntry[] = [];

  /**
   * Adds a document and its embedding to the store.
   * @param entry - The vector entry containing ID, content, and embedding.
   */
  async add(entry: VectorEntry) {
    this.vectors.push(entry);
  }

  /**
   * Performs a similarity search (K-Nearest Neighbors).
   * Calculates the Euclidean distance (simplified) between the query vector and stored vectors.
   * @param queryEmbedding - The vector representing the user's question.
   * @param k - Number of top results to return.
   * @returns The top K most similar documents.
   */
  async similaritySearch(queryEmbedding: number[], k: number = 2) {
    // Calculate similarity scores
    const scored = this.vectors.map((vec) => {
      const similarity = cosineSimilarity(queryEmbedding, vec.embedding);
      return { ...vec, similarity };
    });

    // Sort by similarity (highest first) and take top K
    return scored.sort((a, b) => b.similarity - a.similarity).slice(0, k);
  }
}

// 3. HELPER FUNCTIONS (MATH & EMBEDDINGS)
// -----------------------------------------------------------------------------

/**
 * Calculates the Cosine Similarity between two vectors.
 * This is the standard metric for comparing text embeddings.
 * Range: -1 (completely opposite) to 1 (identical). For embeddings, usually 0 to 1.
 */
function cosineSimilarity(vecA: number[], vecB: number[]): number {
  const dotProduct = vecA.reduce((acc, val, i) => acc + val * vecB[i], 0);
  const magnitudeA = Math.sqrt(vecA.reduce((acc, val) => acc + val * val, 0));
  const magnitudeB = Math.sqrt(vecB.reduce((acc, val) => acc + val * val, 0));
  return dotProduct / (magnitudeA * magnitudeB);
}

/**
 * Generates an embedding for a given text string using OpenAI.
 * @param text - The text to embed.
 * @returns A promise that resolves to the embedding array.
 */
async function getEmbedding(text: string): Promise<number[]> {
  const response = await openai.embeddings.create({
    model: 'text-embedding-ada-002',
    input: text,
  });
  return response.data[0].embedding;
}

/**
 * Generates a response using GPT-4 with the retrieved context.
 * @param query - The user's question.
 * @param context - The retrieved documents to ground the answer.
 * @returns The generated answer.
 */
async function generateAnswer(query: string, context: string[]): Promise<string> {
  const contextText = context.join('\n\n');
  const prompt = `
    You are a helpful assistant for a smart home product company.
    Answer the user question based ONLY on the following context:
    
    Context:
    "${contextText}"
    
    Question: "${query}"
    
    Answer:
  `;

  const completion = await openai.chat.completions.create({
    model: 'gpt-4',
    messages: [{ role: 'user', content: prompt }],
    max_tokens: 150,
  });

  return completion.choices[0].message.content || 'I could not find an answer.';
}

// 4. MAIN EXECUTION LOGIC
// -----------------------------------------------------------------------------

/**
 * Orchestrates the RAG pipeline.
 * 1. Embed the query.
 * 2. Retrieve relevant documents from the vector store.
 * 3. Generate an answer using the retrieved context.
 */
async function runRagPipeline(userQuery: string) {
  console.log(`\n[1] Processing Query: "${userQuery}"`);

  // Step A: Embed the User Query
  // This converts natural language into a numerical vector.
  const queryEmbedding = await getEmbedding(userQuery);
  console.log(`[2] Query embedded. Vector dimension: ${queryEmbedding.length}`);

  // Step B: Retrieve (K-Nearest Neighbors)
  // We search the vector store for the most similar documents.
  const vectorStore = new InMemoryVectorStore();
  
  // First, we need to populate the store (in a real app, this is pre-computed)
  console.log(`[3] Populating Vector Store...`);
  for (const doc of documents) {
    const embedding = await getEmbedding(doc.content);
    await vectorStore.add({ id: doc.id, content: doc.content, embedding });
  }

  // Perform the search
  const retrievedDocs = await vectorStore.similaritySearch(queryEmbedding, 2); // K=2
  console.log(`[4] Retrieved ${retrievedDocs.length} relevant documents.`);
  
  // Step C: Generate Answer
  // Pass the raw text of retrieved docs to the LLM for synthesis.
  const contextTexts = retrievedDocs.map(d => d.content);
  const answer = await generateAnswer(userQuery, contextTexts);
  
  console.log(`\n[5] FINAL ANSWER:\n${answer}`);
}

// 5. RUN THE APP
// -----------------------------------------------------------------------------
// Example usage
const userQuestion = "How do I fix my SmartLight if it's not responding?";
runRagPipeline(userQuestion).catch(console.error);
