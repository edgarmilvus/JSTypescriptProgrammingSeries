/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

import OpenAI from 'openai';

// Initialize OpenAI client (Assume environment variable OPENAI_API_KEY is set)
const openai = new OpenAI();

// 1. Data Preparation: Mock Dataset
const faqDocuments = [
    { id: "1", content: "To reset your password, go to the login page and click 'Forgot Password'. You will receive an email with instructions." },
    { id: "2", content: "You can view your invoices in the 'Billing' section of your account dashboard. Download options are available." },
    { id: "3", content: "Our support team is available 24/7 via chat or email. Response times are usually under 2 hours." },
    { id: "4", content: "To update your profile, navigate to 'Settings' > 'Account Info' and edit your details." },
    { id: "5", content: "If you see a payment error, check your card details or try a different payment method." }
];

// In-memory vector store
let vectorStore: Array<{ id: string, content: string, embedding: Float32Array }> = [];

// 2. Embedding Generation & 3. Vector Storage
async function prepareData() {
    for (const doc of faqDocuments) {
        const embeddingResponse = await openai.embeddings.create({
            model: "text-embedding-ada-002",
            input: doc.content,
        });
        const embedding = new Float32Array(embeddingResponse.data[0].embedding);
        vectorStore.push({ id: doc.id, content: doc.content, embedding });
    }
    console.log("Data prepared and stored.");
}

// Helper: Cosine Similarity
function cosineSimilarity(vecA: Float32Array, vecB: Float32Array): number {
    let dotProduct = 0;
    let normA = 0;
    let normB = 0;
    for (let i = 0; i < vecA.length; i++) {
        dotProduct += vecA[i] * vecB[i];
        normA += vecA[i] * vecA[i];
        normB += vecB[i] * vecB[i];
    }
    return dotProduct / (Math.sqrt(normA) * Math.sqrt(normB));
}

// 4. Retrieval Logic: Semantic Search
async function semanticSearch(query: string, k: number) {
    if (vectorStore.length === 0) await prepareData();

    // Generate query embedding
    const queryEmbeddingResponse = await openai.embeddings.create({
        model: "text-embedding-ada-002",
        input: query,
    });
    const queryEmbedding = new Float32Array(queryEmbeddingResponse.data[0].embedding);

    // Calculate similarity
    const results = vectorStore.map(doc => ({
        id: doc.id,
        content: doc.content,
        similarityScore: cosineSimilarity(queryEmbedding, doc.embedding)
    }));

    // Sort and return top k
    return results.sort((a, b) => b.similarityScore - a.similarityScore).slice(0, k);
}

// --- Interactive Challenge: Hybrid Search ---

// Helper: Keyword Score (Normalized by document length)
function calculateKeywordScore(query: string, content: string): number {
    const queryWords = new Set(query.toLowerCase().split(/\s+/));
    const contentWords = content.toLowerCase().split(/\s+/);
    
    let matches = 0;
    contentWords.forEach(word => {
        if (queryWords.has(word)) matches++;
    });

    // Normalize by length of content to prevent long documents from dominating
    return matches / contentWords.length;
}

async function hybridSearch(query: string, k: number) {
    if (vectorStore.length === 0) await prepareData();

    // Generate query embedding
    const queryEmbeddingResponse = await openai.embeddings.create({
        model: "text-embedding-ada-002",
        input: query,
    });
    const queryEmbedding = new Float32Array(queryEmbeddingResponse.data[0].embedding);

    const results = vectorStore.map(doc => {
        const semanticScore = cosineSimilarity(queryEmbedding, doc.embedding);
        const keywordScore = calculateKeywordScore(query, doc.content);
        
        // Weighted Average: 70% Semantic, 30% Keyword
        const finalScore = (0.7 * semanticScore) + (0.3 * keywordScore);

        return {
            id: doc.id,
            content: doc.content,
            semanticScore,
            keywordScore,
            finalScore
        };
    });

    return results.sort((a, b) => b.finalScore - a.finalScore).slice(0, k);
}

// Example Usage (Mocking the OpenAI call for demonstration if needed, but code assumes valid API key)
// prepareData().then(() => {
//     // Test Case: Query "billing issue" vs Document "invoice payment problem"
//     // Note: In a real scenario, we would wait for data prep.
//     // For this exercise, we assume vectorStore is populated.
//     const query = "billing issue";
//     const doc = { content: "invoice payment problem" }; // Hypothetical match
//     
//     // Semantic score might be low (0.5) due to synonyms
//     // Keyword score is 0 (no overlapping words)
//     // Hybrid score = 0.7 * 0.5 + 0.3 * 0 = 0.35
//     
//     // Compare with a document containing "billing"
//     // Semantic score high (0.9), Keyword score high (0.5)
//     // Hybrid score = 0.7 * 0.9 + 0.3 * 0.5 = 0.78
// });
