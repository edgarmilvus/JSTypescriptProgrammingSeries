/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

interface Chunk {
    content: string;
    start_index: number;
    source_length: number;
}

/**
 * Recursively splits text into chunks.
 * @param text The text to split.
 * @param separators List of separators to try (in order of preference).
 * @param chunkSize Maximum size of a chunk.
 * @param chunkOverlap Amount of overlap between chunks.
 */
function recursiveSplitter(
    text: string, 
    separators: string[], 
    chunkSize: number, 
    chunkOverlap: number
): Chunk[] {
    const chunks: Chunk[] = [];
    
    // Base case: If text is small enough, return it as a chunk
    if (text.length <= chunkSize) {
        return [{
            content: text,
            start_index: 0,
            source_length: text.length
        }];
    }

    // Determine the separator to use
    let separator = separators[0];
    let nextSeparators = separators.slice(1);

    // If we run out of separators, split by empty string (character level)
    if (separators.length === 0) {
        separator = "";
        nextSeparators = [];
    }

    // Split the text by the current separator
    const parts = text.split(separator);

    let currentChunk = "";
    let currentStartIndex = 0;

    for (let i = 0; i < parts.length; i++) {
        const part = parts[i];
        // Re-attach separator unless it's the last part or empty string split
        const textToAdd = (i > 0 && separator !== "") ? separator + part : part;

        // Check if adding this text exceeds the chunk size
        if (currentChunk.length + textToAdd.length > chunkSize && currentChunk.length > 0) {
            // If it exceeds, finalize the current chunk
            chunks.push({
                content: currentChunk,
                start_index: currentStartIndex,
                source_length: text.length
            });

            // Handle Overlap: 
            // The next chunk should start with the last 'chunkOverlap' characters of the current chunk.
            // We need to look back in the original text to find where that overlap begins.
            // For simplicity in this simulation, we take the tail of the current chunk 
            // and prepend it to the next accumulation.
            
            const overlapText = currentChunk.slice(-chunkOverlap);
            
            // Reset for next chunk
            currentChunk = overlapText;
            
            // Update start index: 
            // We need to calculate the actual character index in the original text.
            // This is complex with recursive splitting, so we approximate for the simulation
            // by tracking how much text we've consumed.
            // In a robust system, we'd track indices strictly.
            currentStartIndex = (currentStartIndex + currentChunk.length) - chunkOverlap; 
        }

        currentChunk += textToAdd;
    }

    // Add the final chunk
    if (currentChunk.length > 0) {
        chunks.push({
            content: currentChunk,
            start_index: currentStartIndex,
            source_length: text.length
        });
    }

    // If chunks are still too large (e.g., single word is longer than chunkSize), 
    // recurse with next separator or split by character.
    const finalChunks: Chunk[] = [];
    for (const chunk of chunks) {
        if (chunk.content.length > chunkSize) {
            // Recurse with next separators
            const subChunks = recursiveSplitter(chunk.content, nextSeparators, chunkSize, chunkOverlap);
            // Adjust indices relative to the parent chunk's start
            const adjustedSubChunks = subChunks.map(sub => ({
                ...sub,
                start_index: chunk.start_index + sub.start_index,
                source_length: chunk.source_length
            }));
            finalChunks.push(...adjustedSubChunks);
        } else {
            finalChunks.push(chunk);
        }
    }

    return finalChunks;
}

// Validation
function validateChunks(originalText: string, chunks: Chunk[], chunkSize: number) {
    let reconstructed = "";
    let allValid = true;

    for (const chunk of chunks) {
        // Check size constraint
        if (chunk.content.length > chunkSize) {
            console.error(`Validation Failed: Chunk exceeds size limit (${chunk.content.length} > ${chunkSize})`);
            allValid = false;
        }
        reconstructed += chunk.content;
    }

    // Check reconstruction (Handling overlap is tricky for exact string match, 
    // so we check if the original text is a substring of the reconstructed text 
    // or handle logic specific to how we handled overlap).
    // For this exercise, we simply log the results.
    console.log("Validation Complete. All chunks within size limit:", allValid);
}

// Example Usage
const largeText = "This is a sentence. This is another sentence. " + 
                  "Here is a paragraph with multiple sentences. It continues here. " + 
                  "And another one. " + 
                  "End of text.";
                  
const chunks = recursiveSplitter(largeText, ["\n\n", "\n", " "], 50, 10);
validateChunks(largeText, chunks, 50);
