/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

type VectorRecord = {
    id: string;
    embedding: Float32Array;
    metadata: Record<string, any>;
};

class VectorStore {
    // Internal storage simulating a database table
    private records: VectorRecord[] = [];

    /**
     * Batch insert vectors into the store.
     */
    addVectors(ids: string[], embeddings: Float32Array[], metadata: Record<string, any>[]): void {
        if (ids.length !== embeddings.length || ids.length !== metadata.length) {
            throw new Error("Input arrays must have the same length.");
        }

        for (let i = 0; i < ids.length; i++) {
            this.records.push({
                id: ids[i],
                embedding: embeddings[i],
                metadata: metadata[i]
            });
        }
    }

    /**
     * K-Nearest Neighbors search using Cosine Similarity.
     */
    similaritySearch(queryEmbedding: Float32Array, k: number): VectorRecord[] {
        const scoredResults = this.records.map(record => {
            const score = this.cosineSimilarity(queryEmbedding, record.embedding);
            return { ...record, score };
        });

        // Sort by score descending
        scoredResults.sort((a, b) => b.score - a.score);

        // Return top k (without the score in the return type per strict interface, 
        // but usually you want to return the score. Adhering to prompt return type: VectorRecord[])
        return scoredResults.slice(0, k).map(({ score, ...rest }) => rest);
    }

    /**
     * Delete a record by ID.
     */
    delete(id: string): boolean {
        const initialLength = this.records.length;
        this.records = this.records.filter(record => record.id !== id);
        return this.records.length < initialLength;
    }

    // Helper for Cosine Similarity
    private cosineSimilarity(vecA: Float32Array, vecB: Float32Array): number {
        let dotProduct = 0;
        let normA = 0;
        let normB = 0;
        for (let i = 0; i < vecA.length; i++) {
            dotProduct += vecA[i] * vecB[i];
            normA += vecA[i] * vecA[i];
            normB += vecB[i] * vecB[i];
        }
        const denominator = Math.sqrt(normA) * Math.sqrt(normB);
        return denominator === 0 ? 0 : dotProduct / denominator;
    }

    // Helper to get record count (for testing)
    getCount(): number {
        return this.records.length;
    }
}

// --- Interactive Challenge & Usage ---

// Initialize Store
const store = new VectorStore();

// Mock Data
const ids = ["doc1", "doc2", "doc3"];
const embeddings = [
    new Float32Array([0.1, 0.2, 0.3]),
    new Float32Array([0.4, 0.5, 0.6]),
    new Float32Array([0.7, 0.8, 0.9])
];
const metadata = [{ type: "faq" }, { type: "guide" }, { type: "policy" }];

// Add Vectors
store.addVectors(ids, embeddings, metadata);

// Search
const queryVec = new Float32Array([0.15, 0.25, 0.35]);
const results = store.similaritySearch(queryVec, 2);
// console.log("Search Results:", results);

// Delete
const isDeleted = store.delete("doc2");
// console.log(`Deleted doc2: ${isDeleted}. New Count: ${store.getCount()}`);

// Verify Deletion (Search again, doc2 should not appear)
const newResults = store.similaritySearch(queryVec, 2);
// console.log("Results after deletion:", newResults);
