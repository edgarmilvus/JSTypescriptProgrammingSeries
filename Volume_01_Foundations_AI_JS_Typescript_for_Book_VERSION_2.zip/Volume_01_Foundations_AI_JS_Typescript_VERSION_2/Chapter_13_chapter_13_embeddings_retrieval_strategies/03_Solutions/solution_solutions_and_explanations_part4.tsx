/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState } from 'react';

interface SearchResult {
    id: string;
    content: string;
    similarityScore: number; // 0 to 1
}

interface SearchResultsProps {
    results: SearchResult[];
}

const SearchResults: React.FC<SearchResultsProps> = ({ results }) => {
    // State to track which item is currently copied
    const [copiedId, setCopiedId] = useState<string | null>(null);

    const handleCopy = async (content: string, id: string) => {
        try {
            await navigator.clipboard.writeText(content);
            setCopiedId(id);
            
            // Reset "Copied!" text after 2 seconds
            setTimeout(() => {
                setCopiedId(null);
            }, 2000);
        } catch (err) {
            console.error('Failed to copy text: ', err);
        }
    };

    // Helper to determine color based on score
    const getScoreColor = (score: number) => {
        if (score >= 0.8) return '#4caf50'; // Green
        if (score >= 0.5) return '#ff9800'; // Yellow
        return '#f44336'; // Red
    };

    if (!results || results.length === 0) {
        return (
            <div style={{ padding: '20px', textAlign: 'center', color: '#666' }}>
                No results found. Try a different query.
            </div>
        );
    }

    return (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '16px', padding: '20px' }}>
            {results.map((result) => (
                <div 
                    key={result.id} 
                    style={{ 
                        border: '1px solid #ddd', 
                        borderRadius: '8px', 
                        padding: '16px', 
                        backgroundColor: '#fff',
                        boxShadow: '0 2px 4px rgba(0,0,0,0.05)'
                    }}
                >
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '8px' }}>
                        <span style={{ fontWeight: 'bold', fontSize: '0.9em', color: '#444' }}>
                            Match: {Math.round(result.similarityScore * 100)}%
                        </span>
                        <button 
                            onClick={() => handleCopy(result.content, result.id)}
                            style={{
                                padding: '4px 12px',
                                border: 'none',
                                borderRadius: '4px',
                                backgroundColor: copiedId === result.id ? '#4caf50' : '#007bff',
                                color: 'white',
                                cursor: 'pointer',
                                fontSize: '0.8em'
                            }}
                        >
                            {copiedId === result.id ? 'Copied!' : 'Copy'}
                        </button>
                    </div>

                    {/* Visual Progress Bar */}
                    <div style={{ width: '100%', backgroundColor: '#e0e0e0', borderRadius: '4px', height: '6px', marginBottom: '12px' }}>
                        <div 
                            style={{ 
                                width: `${result.similarityScore * 100}%`, 
                                backgroundColor: getScoreColor(result.similarityScore), 
                                height: '100%', 
                                borderRadius: '4px' 
                            }} 
                        />
                    </div>

                    <p style={{ margin: 0, lineHeight: '1.5', color: '#333' }}>
                        {result.content}
                    </p>
                </div>
            ))}
        </div>
    );
};

export default SearchResults;
