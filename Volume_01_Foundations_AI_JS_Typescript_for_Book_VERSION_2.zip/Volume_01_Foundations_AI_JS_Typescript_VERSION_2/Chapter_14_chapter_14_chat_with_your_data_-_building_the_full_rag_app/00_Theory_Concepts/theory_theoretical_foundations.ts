/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: theory_theoretical_foundations.ts
// Description: Theoretical Foundations
// ==========================================

digraph RAG_Pipeline {
    rankdir=TB;
    node [shape=box, style=filled, fillcolor="#e0e0e0"];

    // Indexing Phase
    subgraph cluster_indexing {
        label = "Indexing Phase (Offline)";
        style = dashed;
        color = blue;

        RawData [label="Raw Documents\n(PDF, Markdown, etc.)", fillcolor="#a8d5e2"];
        Loader [label="Document Loader", fillcolor="#b8d8c0"];
        Splitter [label="Text Splitter\n(RecursiveCharacter)", fillcolor="#b8d8c0"];
        Embedder [label="Embedding Model\n(e.g., OpenAI Ada-002)", fillcolor="#b8d8c0"];
        VectorDB [label="Vector Database\n(Pinecone, Weaviate)", fillcolor="#ffd7a0"];
    }

    // Query Phase
    subgraph cluster_query {
        label = "Query Phase (Online)";
        style = dashed;
        color = green;

        UserQuery [label="User Question", fillcolor="#f8b4b4"];
        QueryEmbedder [label="Embedding Model", fillcolor="#b8d8c0"];
        Retriever [label="Vector Store\n(Similarity Search)", fillcolor="#ffd7a0"];
        PromptTemplate [label="Prompt Template\nwith Context", fillcolor="#d0b0ff"];
        LLM [label="LLM\n(e.g., GPT-4)", fillcolor="#ffb3b3"];
        FinalAnswer [label="Generated Answer", fillcolor="#a0e0a0"];
    }

    // Connections
    RawData -> Loader -> Splitter -> Embedder -> VectorDB [label="Offline Process"];
    UserQuery -> QueryEmbedder -> Retriever [label="1. Search"];
    Retriever -> PromptTemplate [label="2. Retrieve Context"];
    UserQuery -> PromptTemplate [label="3. Augment Prompt"];
    PromptTemplate -> LLM -> FinalAnswer [label="4. Generate"];
}
