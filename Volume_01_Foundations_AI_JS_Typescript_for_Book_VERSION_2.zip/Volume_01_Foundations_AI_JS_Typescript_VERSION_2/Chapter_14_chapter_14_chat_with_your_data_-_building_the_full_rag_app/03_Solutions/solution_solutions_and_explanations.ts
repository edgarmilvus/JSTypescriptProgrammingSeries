/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// types.ts
export interface IngestionResult {
    documentsProcessed: number;
    vectorsUpserted: number;
    errors: string[];
}

// ingestion.ts
import { DirectoryLoader } from "langchain/document_loaders/fs/directory";
import { TextLoader } from "langchain/document_loaders/fs/text";
import { RecursiveCharacterTextSplitter } from "langchain/text_splitter";
import { OpenAIEmbeddings } from "@langchain/openai";
import { Pinecone } from "@pinecone-database/pinecone";
import { Document } from "@langchain/core/documents";

// 1. loadDocuments: Loads .txt files from a directory with error handling
export async function loadDocuments(directoryPath: string): Promise<Document[]> {
    try {
        const loader = new DirectoryLoader(directoryPath, {
            ".txt": (path) => new TextLoader(path),
        });

        const docs = await loader.load();
        return docs;
    } catch (error) {
        throw new Error(`Failed to load documents: ${error instanceof Error ? error.message : String(error)}`);
    }
}

// 2. splitDocuments: Splits documents into chunks with overlap
export async function splitDocuments(docs: Document[]): Promise<Document[]> {
    const textSplitter = new RecursiveCharacterTextSplitter({
        chunkSize: 1000,
        chunkOverlap: 200,
    });

    const splitDocs = await textSplitter.splitDocuments(docs);
    return splitDocs;
}

// 3. ingestToPinecone: Generates embeddings and upserts to Pinecone
export async function ingestToPinecone(
    docs: Document[],
    pineconeIndexName: string,
    namespace: string = "default"
): Promise<IngestionResult> {
    const result: IngestionResult = {
        documentsProcessed: docs.length,
        vectorsUpserted: 0,
        errors: [],
    };

    try {
        // Initialize Pinecone client
        const pinecone = new Pinecone();
        const index = pinecone.Index(pineconeIndexName);

        // Initialize Embeddings model
        const embeddings = new OpenAIEmbeddings({
            model: "text-embedding-ada-002",
        });

        // Prepare vectors for upsert
        // We need to generate embeddings for the text content and attach metadata
        const vectors = [];
        for (let i = 0; i < docs.length; i++) {
            const doc = docs[i];
            const text = doc.pageContent;
            
            // Generate embedding for the text
            const embedding = await embeddings.embedQuery(text);
            
            // Create Pinecone vector object
            const vector = {
                id: `chunk_${i}_${Date.now()}`, // Unique ID
                values: embedding,
                metadata: {
                    content: text, // Store content in metadata for retrieval
                    filename: doc.metadata.source || "unknown",
                    chunkIndex: i,
                },
            };
            vectors.push(vector);
        }

        // Upsert in batches of 50
        const batchSize = 50;
        for (let i = 0; i < vectors.length; i += batchSize) {
            const batch = vectors.slice(i, i + batchSize);
            await index.namespace(namespace).upsert(batch);
            result.vectorsUpserted += batch.length;
        }

        return result;
    } catch (error) {
        const errorMsg = `Pinecone ingestion failed: ${error instanceof Error ? error.message : String(error)}`;
        result.errors.push(errorMsg);
        throw new Error(errorMsg);
    }
}
