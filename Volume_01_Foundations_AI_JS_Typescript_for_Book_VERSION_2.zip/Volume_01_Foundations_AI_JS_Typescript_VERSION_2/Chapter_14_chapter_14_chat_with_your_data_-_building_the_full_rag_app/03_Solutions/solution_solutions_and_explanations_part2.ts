/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

// types.ts
export interface SearchResult {
    content: string;
    score: number;
    metadata: {
        filename: string;
        chunkIndex: number;
    };
}

// retriever.ts
import { Pinecone } from "@pinecone-database/pinecone";
import { OpenAIEmbeddings } from "@langchain/openai";

// 1. initializePineconeRetriever: Creates a configured search function
export function initializePineconeRetriever(indexName: string, namespace: string = "default") {
    const pinecone = new Pinecone();
    const index = pinecone.Index(indexName);
    const embeddings = new OpenAIEmbeddings({
        model: "text-embedding-ada-002",
    });

    // Return an object with a search method
    return {
        // 2. & 3. Search method with query and k parameter
        search: async (query: string, k: number = 4, filter?: Record<string, any>): Promise<SearchResult[]> => {
            try {
                // Generate embedding for the query
                const queryEmbedding = await embeddings.embedQuery(query);

                // Perform similarity search
                const queryResponse = await index.namespace(namespace).query({
                    vector: queryEmbedding,
                    topK: k,
                    includeMetadata: true,
                    filter: filter, // Optional metadata filtering
                });

                // 4. & 5. Map results to the required output format
                if (!queryResponse.matches) {
                    return [];
                }

                const results: SearchResult[] = queryResponse.matches.map((match) => {
                    // Ensure metadata exists and is typed correctly
                    const metadata = match.metadata as any;
                    return {
                        content: metadata.content, // Content is stored in metadata
                        score: match.score || 0,
                        metadata: {
                            filename: metadata.filename || "unknown",
                            chunkIndex: metadata.chunkIndex || 0,
                        },
                    };
                });

                return results;
            } catch (error) {
                console.error("Search error:", error);
                throw new Error(`Search failed: ${error instanceof Error ? error.message : String(error)}`);
            }
        },
    };
}
