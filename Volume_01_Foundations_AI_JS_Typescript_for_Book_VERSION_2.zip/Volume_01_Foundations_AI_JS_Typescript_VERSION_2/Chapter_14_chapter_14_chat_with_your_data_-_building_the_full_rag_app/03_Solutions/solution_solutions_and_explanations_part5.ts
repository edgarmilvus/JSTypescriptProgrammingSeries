/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

digraph RAG_Architecture {
    rankdir=TB; // Top to Bottom layout
    splines=ortho; // Orthogonal edges for cleaner look
    nodesep=0.6; // Increase separation between nodes
    ranksep=0.8; // Increase separation between ranks

    // Define Node Styles
    node [shape=box, style="rounded,filled", fontname="Helvetica"];

    // User Interface Node
    User [label="User", shape=ellipse, fillcolor="#a8d5e2"];

    // Frontend Component
    Frontend [label="React Component\n(Chat Interface)", fillcolor="#e1f5fe"];

    // Backend API
    Backend [label="Backend API\n(/api/chat)", fillcolor="#fff3e0"];

    // RAG Chain Components
    Retriever [label="LangChain Retriever", fillcolor="#f3e5f5"];
    Embeddings [label="OpenAI Embeddings\n(text-embedding-ada-002)", shape=ellipse, fillcolor="#e8f5e9"];
    LLM [label="OpenAI LLM\n(GPT-3.5/4)", fillcolor="#fce4ec"];

    // Database
    Pinecone [label="Pinecone Vector Store", shape=cylinder, fillcolor="#fff9c4"];

    // Data Flow Edges
    edge [fontname="Helvetica", fontsize=10];

    // 1. User to Frontend
    User -> Frontend [label="User Question"];

    // 2. Frontend to Backend
    Frontend -> Backend [label="HTTP Request\n(JSON: {question})"];

    // 3. Backend to Retriever (Query Vector)
    Backend -> Retriever [label="Query String"];

    // 4. Parallel Operations: Retrieval Phase
    // We group embedding generation and vector search logically
    subgraph cluster_retrieval {
        label = "Retrieval Phase";
        style = "dashed";
        rank = same;

        // Embeddings are generated for the query
        Retriever -> Embeddings [label="Generate Query Vector"];
        
        // Vector Search against Pinecone
        Embeddings -> Pinecone [label="Similarity Search\n(Vector Query)"];
        Pinecone -> Retriever [label="Relevant Context Chunks"];
    }

    // 5. Retriever to LLM
    Retriever -> Backend [label="Context Chunks"];
    Backend -> LLM [label="Prompt\n(Context + Question)"];

    // 6. Streaming Response Loop
    LLM -> Backend [label="Streamed Tokens"];
    Backend -> Frontend [label="Server-Sent Events / Stream"];
    Frontend -> User [label="Rendered Response\n(Typing Animation)"];

    // Styling for specific edges to highlight flow
    Backend -> LLM [color="#e91e63", penwidth=2];
    LLM -> Backend [color="#e91e63", penwidth=2, style=dashed];
}
