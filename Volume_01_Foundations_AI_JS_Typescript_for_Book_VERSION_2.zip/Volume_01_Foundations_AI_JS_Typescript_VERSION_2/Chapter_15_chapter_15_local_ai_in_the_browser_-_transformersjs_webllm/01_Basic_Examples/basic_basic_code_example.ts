/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * sentiment-analyzer.ts
 * 
 * A self-contained module for performing local sentiment analysis 
 * using Transformers.js in a browser environment.
 */

// 1. Import the necessary library.
// In a real SaaS app, this would be installed via `npm install @xenova/transformers`.
// We use a dynamic import to handle the library loading asynchronously.
import { pipeline, env, Pipeline } from '@xenova/transformers';

// 2. Configure Environment Settings.
// Disable local model checks to allow loading from remote URLs (CDN) without 
// strict origin checks, useful for development.
env.allowRemoteModels = true;

/**
 * Represents the shape of the result returned by the sentiment analysis pipeline.
 */
interface SentimentResult {
    label: string;    // e.g., "POSITIVE" or "NEGATIVE"
    score: number;    // Confidence score between 0 and 1
}

/**
 * Main Class: LocalSentimentAnalyzer
 * 
 * Encapsulates the logic for loading the model and performing inference.
 * This prevents global namespace pollution and manages the model lifecycle.
 */
class LocalSentimentAnalyzer {
    private classifier: Pipeline | null = null;
    private modelName: string = 'distilbert-base-uncased-finetuned-sst-2-english';

    /**
     * Initializes the AI model.
     * This is the most expensive operation (network download + WASM compilation).
     * Should be called once when the app initializes or on user interaction (lazy loading).
     */
    public async initialize(): Promise<void> {
        console.log(`Loading model: ${this.modelName}...`);
        
        try {
            // The 'pipeline' function is the main entry point.
            // It handles downloading weights, parsing configs, and initializing the WASM backend.
            this.classifier = await pipeline('sentiment-analysis', this.modelName);
            console.log('Model loaded successfully.');
        } catch (error) {
            console.error('Error loading model:', error);
            throw new Error('Failed to initialize local AI model.');
        }
    }

    /**
     * Performs sentiment analysis on the provided text.
     * 
     * @param text - The input string to analyze.
     * @returns A Promise resolving to the sentiment result.
     */
    public async analyze(text: string): Promise<SentimentResult> {
        if (!this.classifier) {
            throw new Error('Model not initialized. Call initialize() first.');
        }

        if (!text || text.trim().length === 0) {
            throw new Error('Input text cannot be empty.');
        }

        // Execute the inference. 
        // Under the hood: Tokenization -> Tensor creation -> WASM Inference -> Post-processing.
        const results = await this.classifier(text);
        
        // The pipeline returns an array of results (handling batch inputs).
        // We take the first result for single input.
        return results[0] as SentimentResult;
    }
}

// --- SaaS Web App Integration Example ---

/**
 * DOM Event Handler
 * 
 * This function bridges the gap between the UI and the AI logic.
 * It handles the asynchronous nature of model loading and inference.
 */
document.addEventListener('DOMContentLoaded', async () => {
    const inputElement = document.getElementById('userInput') as HTMLTextAreaElement;
    const buttonElement = document.getElementById('analyzeBtn') as HTMLButtonElement;
    const outputElement = document.getElementById('resultOutput') as HTMLDivElement;
    const statusElement = document.getElementById('status') as HTMLSpanElement;

    if (!inputElement || !buttonElement || !outputElement || !statusElement) {
        console.error('HTML elements missing.');
        return;
    }

    const analyzer = new LocalSentimentAnalyzer();

    // Lazy load the model only when the user first interacts with the app
    // to improve initial page load performance.
    let modelLoaded = false;

    buttonElement.addEventListener('click', async () => {
        const text = inputElement.value;

        // 1. Load model on first click
        if (!modelLoaded) {
            statusElement.textContent = 'Loading AI Model (this happens once)...';
            buttonElement.disabled = true;
            
            try {
                await analyzer.initialize();
                modelLoaded = true;
                statusElement.textContent = 'Model Ready.';
            } catch (err) {
                statusElement.textContent = 'Error loading model.';
                return;
            } finally {
                buttonElement.disabled = false;
            }
        }

        // 2. Run Inference
        if (text.trim().length > 0) {
            statusElement.textContent = 'Analyzing...';
            buttonElement.disabled = true;

            try {
                const result = await analyzer.analyze(text);
                
                // Update UI with results
                const sentimentEmoji = result.label === 'POSITIVE' ? '😊' : '🙁';
                outputElement.innerHTML = `
                    <strong>Sentiment:</strong> ${result.label} ${sentimentEmoji}<br>
                    <strong>Confidence:</strong> ${(result.score * 100).toFixed(2)}%
                `;
                
                // Visual feedback
                outputElement.style.color = result.label === 'POSITIVE' ? 'green' : 'red';
            } catch (error) {
                outputElement.textContent = 'Error during analysis.';
                console.error(error);
            } finally {
                statusElement.textContent = 'Ready.';
                buttonElement.disabled = false;
            }
        }
    });
});
