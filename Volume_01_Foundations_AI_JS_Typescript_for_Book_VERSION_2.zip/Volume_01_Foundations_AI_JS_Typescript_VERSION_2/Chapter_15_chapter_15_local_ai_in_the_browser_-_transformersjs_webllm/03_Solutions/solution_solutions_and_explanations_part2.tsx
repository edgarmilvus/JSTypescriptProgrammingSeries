/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState, useEffect, useRef } from 'react';
import { ChatModule, InitProgressReport } from '@mlc-ai/web-llm';

// Define the available models
const MODELS = {
  'Llama-2-7B-Chat': 'Llama-2-7B-Chat-q4f16_1', // Quantized 4-bit
  'Llama-3-2-1B': 'Llama-3-2-1B-Instruct-q4f16_1' // Smaller model for faster testing
};

export const LocalChatbot: React.FC = () => {
  const [chatModule, setChatModule] = useState<ChatModule | null>(null);
  const [messages, setMessages] = useState<Array<{ role: string, content: string }>>([]);
  const [input, setInput] = useState('');
  const [status, setStatus] = useState('Idle');
  const [progress, setProgress] = useState(0);
  const [currentModel, setCurrentModel] = useState<string>(MODELS['Llama-2-7B-Chat']);
  
  // Ref for scrolling to bottom of chat
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Initialize Chat Module
  const initChat = async (modelName: string) => {
    if (chatModule) {
      await chatModule.unload(); // Free memory if switching models
    }

    setStatus('Initializing...');
    setProgress(0);
    
    const newChatModule = new ChatModule();
    
    // Progress callback for model loading
    const initProgressCallback = (report: InitProgressReport) => {
      const p = Math.min(100, Math.round(report.progress * 100));
      setProgress(p);
      setStatus(`Downloading: ${p}%`);
    };

    try {
      await newChatModule.init(
        modelName, 
        { initProgressCallback }
      );
      setChatModule(newChatModule);
      setStatus('Ready');
      setMessages([{ role: 'system', content: 'Model loaded. How can I help you?' }]);
    } catch (err) {
      console.error("Init failed", err);
      setStatus('Failed to load model.');
    }
  };

  // Handle sending message
  const handleSend = async () => {
    if (!input.trim() || !chatModule || status === 'Generating') return;

    const userMessage = { role: 'user', content: input };
    const newMessages = [...messages, userMessage];
    setMessages(newMessages);
    setInput('');
    setStatus('Generating');

    // Placeholder for assistant message
    const assistantMessage = { role: 'assistant', content: '' };
    setMessages([...newMessages, assistantMessage]);

    // Streaming generation
    try {
      await chatModule.generate(
        input, 
        (chunk: string, isComplete: boolean) => {
          // Update the assistant message with the new chunk
          setMessages((prev) => {
            const updated = [...prev];
            // Update the last message (assistant)
            if (updated.length > 0) {
              updated[updated.length - 1].content += chunk;
            }
            return updated;
          });
          
          if (isComplete) {
            setStatus('Ready');
          }
        }
      );
    } catch (err) {
      console.error("Generation error", err);
      setStatus('Error generating response');
    }
  };

  const handleClearMemory = async () => {
    if (chatModule) {
      await chatModule.unload();
      setChatModule(null);
      setMessages([]);
      setStatus('Memory Cleared');
    }
  };

  const handleModelToggle = async () => {
    const newModel = currentModel === MODELS['Llama-2-7B-Chat'] 
      ? MODELS['Llama-3-2-1B'] 
      : MODELS['Llama-2-7B-Chat'];
    setCurrentModel(newModel);
    await initChat(newModel);
  };

  // Auto-scroll to bottom
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  return (
    <div style={{ padding: '20px', maxWidth: '800px', margin: '0 auto', fontFamily: 'sans-serif' }}>
      <h2>Local WebLLM Chat</h2>
      
      <div style={{ marginBottom: '10px', display: 'flex', gap: '10px' }}>
        <button onClick={() => initChat(currentModel)} disabled={status !== 'Idle' && status !== 'Ready'}>
          Load Model
        </button>
        <button onClick={handleModelToggle} disabled={status === 'Initializing' || status === 'Generating'}>
          Toggle Model (Current: {currentModel.includes('7B') ? '7B' : '1B'})
        </button>
        <button onClick={handleClearMemory}>Clear Memory</button>
      </div>

      <div style={{ background: '#f0f0f0', padding: '10px', marginBottom: '10px', borderRadius: '5px' }}>
        <strong>Status:</strong> {status} {status.includes('Downloading') && <span> ({progress}%)</span>}
      </div>

      <div style={{ 
        border: '1px solid #ccc', 
        height: '400px', 
        overflowY: 'auto', 
        padding: '10px', 
        marginBottom: '10px',
        borderRadius: '5px' 
      }}>
        {messages.map((msg, idx) => (
          <div key={idx} style={{ marginBottom: '10px', textAlign: msg.role === 'user' ? 'right' : 'left' }}>
            <div style={{ 
              display: 'inline-block', 
              padding: '8px 12px', 
              borderRadius: '10px', 
              background: msg.role === 'user' ? '#007bff' : '#e9ecef', 
              color: msg.role === 'user' ? 'white' : 'black',
              maxWidth: '80%',
              whiteSpace: 'pre-wrap'
            }}>
              <strong>{msg.role.toUpperCase()}:</strong> {msg.content}
            </div>
          </div>
        ))}
        <div ref={messagesEndRef} />
      </div>

      <div style={{ display: 'flex', gap: '10px' }}>
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && handleSend()}
          placeholder="Type a message..."
          style={{ flex: 1, padding: '10px' }}
          disabled={status !== 'Ready'}
        />
        <button onClick={handleSend} disabled={status !== 'Ready'}>Send</button>
      </div>
    </div>
  );
};
