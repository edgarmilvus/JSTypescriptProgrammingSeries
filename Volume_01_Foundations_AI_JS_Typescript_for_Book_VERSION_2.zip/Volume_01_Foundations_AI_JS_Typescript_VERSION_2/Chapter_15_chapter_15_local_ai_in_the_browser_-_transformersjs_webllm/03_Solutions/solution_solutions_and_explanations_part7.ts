/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part7.ts
// Description: Solutions and Explanations
// ==========================================

digraph LocalAIArchitecture {
    rankdir=LR;
    node [shape=box, style="rounded,filled", color="#4A90E2", fontname="Helvetica"];
    
    // Layers
    subgraph cluster_app {
        label = "Application Layer (React/HTML/CSS)";
        style = "rounded,filled";
        color = "#E0E0E0";
        node [color="#A2D2FF"];
        
        UI [label = "User Interface\n(Inputs/Outputs)"];
        State [label = "State Management\n(React Hooks)"];
    }

    subgraph cluster_engine {
        label = "Inference Engine Layer";
        style = "rounded,filled";
        color = "#FFF2CC";
        node [color="#FFE082"];
        
        Pipeline [label = "Pipeline API\n(Classifier/ASR)"];
        Tokenizer [label = "Tokenizer\n(Text to IDs)"];
        Model [label = "Model Inference\n(ONNX/WASM)"];
    }

    subgraph cluster_hardware {
        label = "Browser Hardware Abstraction";
        style = "rounded,filled";
        color = "#D5E8D4";
        node [color="#A7D7C5"];
        
        WebGPU [label = "WebGPU\n(Parallel Compute)"];
        WASM [label = "WebAssembly\n(CPU Fallback)"];
        Cache [label = "Cache API / IndexedDB\n(Storage)"];
        WebAudio [label = "Web Audio API\n(Audio Processing)"];
    }

    // Data Flow Connections
    UI -> State [label = "User Action"];
    State -> Pipeline [label = "Text/Audio Blob"];
    
    Pipeline -> Tokenizer [label = "Preprocessing"];
    Tokenizer -> Model [label = "Input IDs"];
    
    Model -> WebGPU [label = "Matrix Ops"];
    Model -> WASM [label = "Fallback Ops"];
    Model -> Cache [label = "Read/Write Weights"];
    
    // Audio specific flow
    State -> WebAudio [label = "Stream Capture"];
    WebAudio -> Pipeline [label = "PCM Buffer"];

    // Return flow
    Model -> Pipeline [label = "Logits/Tokens"];
    Pipeline -> State [label = "Formatted Output"];
    State -> UI [label = "Render Update"];

    // Styling for edges
    edge [color="#555555", fontname="Helvetica", fontsize=10];
}
