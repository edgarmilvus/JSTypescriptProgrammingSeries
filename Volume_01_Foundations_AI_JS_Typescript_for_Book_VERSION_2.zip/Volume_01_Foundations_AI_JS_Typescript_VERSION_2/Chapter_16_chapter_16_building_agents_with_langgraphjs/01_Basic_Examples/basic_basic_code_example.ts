/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

// ==========================================
// IMPORTS
// ==========================================
import { z } from "zod";
import { StateGraph, END, START } from "@langchain/langgraph";

// ==========================================
// 1. STATE DEFINITION (Zod Schema)
// ==========================================
/**
 * Defines the state of our agent.
 * In a SaaS context, this represents the data passed between
 * server actions and the agent's internal memory.
 */
const AgentStateSchema = z.object({
  /**
   * The code snippet provided by the user.
   */
  codeSnippet: z.string(),

  /**
   * The generated review from the LLM.
   */
  review: z.string(),

  /**
   * A flag indicating if the review meets quality standards.
   * This drives the cyclical behavior (the "loop").
   */
  isReviewValid: z.boolean(),

  /**
   * Count of iterations to prevent infinite loops.
   */
  iterations: z.number().default(0),
});

// TypeScript type inference from Zod schema
type AgentState = z.infer<typeof AgentStateSchema>;

// ==========================================
// 2. NODE DEFINITIONS (Worker Agents)
// ==========================================

/**
 * Node 1: Generate Review
 * Simulates calling an LLM (like GPT-4) to generate a code review.
 * In a real app, this would use `generateText` from @ai-sdk/openai.
 */
async function generateReviewNode(state: AgentState): Promise<Partial<AgentState>> {
  console.log("🤖 [Node] Generating Review...");
  
  // Simulated LLM response (mocking OpenAI API)
  // In reality: const { text } = await generateText({ model: openai('gpt-4'), prompt: ... });
  const mockReview = "The code looks good, but consider adding error handling.";
  
  return {
    review: mockReview,
    iterations: state.iterations + 1,
  };
}

/**
 * Node 2: Check Review Quality
 * Simulates a validation step. 
 * In a real app, this might use a smaller LLM or a heuristic check.
 * For this demo, we force a "fail" on the first pass to demonstrate the loop.
 */
async function checkReviewNode(state: AgentState): Promise<Partial<AgentState>> {
  console.log(`🔍 [Node] Checking Review (Iteration ${state.iterations})...`);

  // LOGIC: If it's the first iteration, mark it invalid to force a loop.
  // Otherwise, mark it valid to exit.
  const isValid = state.iterations > 1;

  if (isValid) {
    console.log("✅ Review passed validation.");
  } else {
    console.log("❌ Review failed validation. Triggering retry...");
  }

  return {
    isReviewValid: isValid,
  };
}

// ==========================================
// 3. CONTROL FLOW (Edges)
// ==========================================

/**
 * Determines the next step based on the current state.
 * This is the "Brain" of the agent.
 */
function decideNextStep(state: AgentState): string {
  if (state.isReviewValid) {
    return "end"; // Go to END node
  }
  return "generate_review"; // Loop back to generate_review node
}

// ==========================================
// 4. GRAPH COMPILATION
// ==========================================

/**
 * Initializes the LangGraph.
 * This creates the stateful workflow.
 */
function createAgentGraph() {
  // Initialize the graph with the defined state schema
  const workflow = new StateGraph<AgentState>({
    stateSchema: AgentStateSchema,
    // In a real app, we'd pass an initial state object here
  });

  // Add nodes (Worker Agents)
  workflow.addNode("generate_review", generateReviewNode);
  workflow.addNode("check_review", checkReviewNode);
  workflow.addNode("end", () => {
    console.log("🏁 [Node] Workflow Complete.");
    return {};
  });

  // Define Edges (Control Flow)
  
  // 1. Start -> Generate Review
  workflow.addEdge(START, "generate_review");

  // 2. Generate Review -> Check Review (Always happens after generation)
  workflow.addEdge("generate_review", "check_review");

  // 3. Check Review -> Conditional Edge (Loop or End)
  // We use `addConditionalEdges` to create the cyclical logic.
  workflow.addConditionalEdges(
    "check_review", 
    decideNextStep, 
    {
      "generate_review": "generate_review", // If logic returns "generate_review"
      "end": END, // If logic returns "end"
    }
  );

  return workflow.compile();
}

// ==========================================
// 5. EXECUTION (Main Entry Point)
// ==========================================

/**
 * Runs the agent with a user's request.
 * In a SaaS app, this function would be a Server Action.
 */
async function runAgent() {
  console.log("--- Starting Agent Workflow ---");

  const graph = createAgentGraph();

  // Initial State: User provides code, review is empty, invalid by default.
  const initialState: AgentState = {
    codeSnippet: "function add(a, b) { return a + b; }",
    review: "",
    isReviewValid: false,
    iterations: 0,
  };

  // Stream execution (Simulates a real-time WebSocket or Server-Sent Events)
  const stream = await graph.stream(initialState);

  // Process each step in the graph
  for await (const step of stream) {
    // 'step' contains the state updates for the specific node
    const nodeName = Object.keys(step)[0];
    const stateUpdate = step[nodeName];
    
    console.log(`--- Step Update: ${nodeName} ---`);
    console.log(JSON.stringify(stateUpdate, null, 2));
  }

  console.log("--- Final State ---");
  // To get the full final state, we can run the graph one last time or accumulate it.
  // For simplicity, we assume the last stream update contains the final state.
}

// Execute the example
runAgent().catch(console.error);
