/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// File: lib/agents/support-supervisor.ts
// Context: Next.js API Route or Server Action (Server-Side Only)

import { z } from "zod";
import { ChatOpenAI } from "@langchain/openai";
import { ChatPromptTemplate } from "@langchain/core/prompts";
import { StateGraph, Annotation, END, START } from "langgraph/graph";
import { ToolNode } from "@langchain/langgraph/prebuilt";

// =============================================================================
// 1. STATE DEFINITION & TYPE SAFETY (Zod & Generics)
// =============================================================================

/**
 * Defines the structure of the graph state using Zod for runtime validation.
 * This ensures that every node in the graph receives a strictly typed object.
 */
const StateAnnotation = Annotation.Root({
  // The current customer inquiry
  ticket: Annotation<string>({
    reducer: (curr, update) => update, // Simply overwrites
    default: () => "",
  }),
  // The assigned department (used by the supervisor)
  department: Annotation<string>({
    reducer: (curr, update) => update,
    default: () => "",
  }),
  // The generated response from the worker agent
  response: Annotation<string>({
    reducer: (curr, update) => update,
    default: () => "",
  }),
  // A flag to determine if the loop should continue
  next: Annotation<"sales" | "tech" | "billing" | "finish">({
    reducer: (curr, update) => update,
    default: () => "finish",
  }),
});

// Infer the TypeScript type from the Zod schema for type narrowing
type State = typeof StateAnnotation.State;

// =============================================================================
// 2. LLM & TOOLS SETUP
// =============================================================================

// Initialize the LLM (Ensure OPENAI_API_KEY is in env)
const llm = new ChatOpenAI({ 
  model: "gpt-4-turbo-preview",
  temperature: 0 
});

/**
 * Tool: Sales Agent
 * Simulates a specialized agent handling product inquiries.
 */
const salesAgent = async (state: State): Promise<Partial<State>> => {
  console.log(`[Sales Agent] Processing: "${state.ticket}"`);
  
  const prompt = ChatPromptTemplate.fromMessages([
    ["system", "You are a Sales Associate. Respond helpfully to customer inquiries about pricing, features, and demos. If the question is technical or billing-related, ask for clarification."],
    ["human", state.ticket]
  ]);
  
  const chain = prompt.pipe(llm);
  const result = await chain.invoke({});
  
  // Logic: If the response indicates the user is asking for technical specs, 
  // we might flag this for a handoff. For this demo, we return a response.
  return { 
    response: result.content as string,
    department: "sales"
  };
};

/**
 * Tool: Technical Support Agent
 * Simulates a specialized agent handling bugs and technical issues.
 */
const techAgent = async (state: State): Promise<Partial<State>> => {
  console.log(`[Tech Agent] Processing: "${state.ticket}"`);
  
  const prompt = ChatPromptTemplate.fromMessages([
    ["system", "You are a Technical Support Engineer. Diagnose bugs and provide troubleshooting steps. If the issue involves payment, hand off to Billing."],
    ["human", state.ticket]
  ]);
  
  const chain = prompt.pipe(llm);
  const result = await chain.invoke({});
  
  return { 
    response: result.content as string,
    department: "tech"
  };
};

/**
 * Tool: Billing Agent
 * Simulates a specialized agent handling invoices and payments.
 */
const billingAgent = async (state: State): Promise<Partial<State>> => {
  console.log(`[Billing Agent] Processing: "${state.ticket}"`);
  
  const prompt = ChatPromptTemplate.fromMessages([
    ["system", "You are a Billing Specialist. Handle invoice disputes, refunds, and payment methods."],
    ["human", state.ticket]
  ]);
  
  const chain = prompt.pipe(llm);
  const result = await chain.invoke({});
  
  return { 
    response: result.content as string,
    department: "billing"
  };
};

// =============================================================================
// 3. SUPERVISOR NODE (The Router)
// =============================================================================

/**
 * Supervisor Node
 * Uses an LLM to analyze the state and determine which worker to route to.
 * This is a classic example of using Generics in LangGraph to define
 * flexible return types for control flow.
 */
const supervisorNode = async (state: State): Promise<Partial<State>> => {
  const prompt = ChatPromptTemplate.fromMessages([
    ["system", 
      `You are a customer support supervisor. Analyze the incoming ticket and route it to the correct department.
       Departments:
       - sales: For pricing, demos, and product features.
       - tech: For bugs, errors, and technical usage.
       - billing: For invoices, payments, and refunds.
       - finish: If the ticket seems resolved or is a general greeting.
       
       Return ONLY the department name (sales, tech, billing, or finish) in lowercase.`
    ],
    ["human", state.ticket]
  ]);

  const chain = prompt.pipe(llm);
  const result = await chain.invoke({});
  
  // Type Narrowing: We parse the LLM output to ensure it matches our expected union type
  const rawContent = result.content as string;
  const nextStep = rawContent.toLowerCase().includes("sales") ? "sales" :
                   rawContent.toLowerCase().includes("tech") ? "tech" :
                   rawContent.toLowerCase().includes("billing") ? "billing" : "finish";

  return { next: nextStep };
};

// =============================================================================
// 4. GRAPH ORCHESTRATION (LangGraph)
// =============================================================================

/**
 * Initializes and compiles the LangGraph.
 */
function createSupportGraph() {
  // Define the graph using the StateAnnotation
  const workflow = new StateGraph(StateAnnotation);

  // Add Nodes
  workflow.addNode("supervisor", supervisorNode);
  workflow.addNode("sales", salesAgent);
  workflow.addNode("tech", techAgent);
  workflow.addNode("billing", billingAgent);

  // Define Edges (Control Flow)
  
  // 1. Start at the supervisor
  workflow.addEdge(START, "supervisor");

  // 2. Define conditional edges based on the 'next' field in state.
  // This creates the cyclical loop: Worker -> Supervisor -> Next Worker
  workflow.addConditionalEdges(
    "supervisor",
    (state: State) => {
      // This function acts as the router logic
      if (state.next === "sales") return "sales";
      if (state.next === "tech") return "tech";
      if (state.next === "billing") return "billing";
      return END; // If 'finish', go to end
    }
  );

  // 3. Worker nodes always route back to the supervisor for review
  // This allows the supervisor to decide if further routing is needed
  workflow.addEdge("sales", "supervisor");
  workflow.addEdge("tech", "supervisor");
  workflow.addEdge("billing", "supervisor");

  return workflow.compile();
}

// =============================================================================
// 5. EXECUTION (Next.js API Route Handler Example)
// =============================================================================

/**
 * Main Entry Point for the API.
 * This simulates a Next.js API route handler.
 * 
 * @param ticket - The customer inquiry string
 * @returns The final response object
 */
export async function runCustomerSupportAgent(ticket: string) {
  const graph = createSupportGraph();
  
  // Initial State
  const initialState: State = {
    ticket: ticket,
    department: "",
    response: "",
    next: "finish" // Will be overridden by supervisor
  };

  // Execute the graph
  // The graph will loop Supervisor -> Worker -> Supervisor until 'next' is 'finish'
  const finalState = await graph.invoke(initialState);

  // Return the result (In a real app, this would be sent to the frontend)
  return {
    department: finalState.department,
    response: finalState.response,
    stepsTaken: "See server logs for agent routing."
  };
}

// Example Usage (Mocking a Next.js Route)
/*
export async function POST(req: Request) {
  const { ticket } = await req.json();
  const result = await runCustomerSupportAgent(ticket);
  return Response.json(result);
}
*/

// Example Invocation for Testing
(async () => {
  console.log("--- Starting Agent Loop ---");
  const result = await runCustomerSupportAgent("I am having trouble logging into my account and my credit card was declined.");
  console.log("--- Final Result ---");
  console.log(result);
})();
