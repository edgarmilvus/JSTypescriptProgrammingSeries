/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// app/api/agents/content-gen/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import { ChatOpenAI } from '@langchain/openai';
import { ToolDefinition } from '@langchain/core/language_models/base';
import { StateGraph, END, MessageGraph } from '@langchain/langgraph';
import { BaseMessage, HumanMessage, AIMessage } from '@langchain/core/messages';

// ============================================================================
// 1. GRAPH STATE DEFINITION
// ============================================================================

/**
 * Defines the canonical data structure passed between all nodes.
 * This ensures persistent context and aggregation of results.
 */
interface AgentState {
  topic: string;
  outline?: string[];
  researchNotes?: string;
  draft?: string;
  nextAgent: 'planner' | 'researcher' | 'writer' | 'finish';
}

// ============================================================================
// 2. TOOL DEFINITIONS (Simulated Internal Tools)
// ============================================================================

/**
 * Simulates an internal SaaS tool that fetches industry-specific data.
 * In a real app, this might query a vector database or internal API.
 */
const researchToolSchema = z.object({
  query: z.string().describe("The specific topic to research facts for.")
});

/**
 * Mock function to simulate fetching data asynchronously.
 * Demonstrates Asynchronous Tool Handling.
 */
async function fetchResearchData(query: string): Promise<string> {
  // Simulate network latency
  await new Promise(resolve => setTimeout(resolve, 500));
  
  // Return dummy context based on query
  return `Research Context for "${query}": 
  1. Key trend: AI adoption is up 40% in 2024.
  2. Statistic: 70% of SaaS platforms integrate LLMs.
  3. Insight: User personalization is the primary driver.`;
}

// ============================================================================
// 3. AGENT NODES (Logic Units)
// ============================================================================

/**
 * Node 1: The Planner
 * Uses LLM to break down the topic into a logical outline.
 */
async function plannerNode(state: AgentState): Promise<Partial<AgentState>> {
  const model = new ChatOpenAI({ model: "gpt-4-turbo-preview" });
  
  const prompt = `You are a Content Strategist. Create a concise outline for a blog post about: "${state.topic}". 
  Return only the outline as a JSON array of strings.`;

  const response = await model.invoke(prompt);
  
  // Parse the LLM response (simplified parsing for demo)
  const content = response.content as string;
  const outline = content.split('\n').filter(line => line.trim().length > 0);

  return {
    outline,
    nextAgent: 'researcher' // Route to the next agent
  };
}

/**
 * Node 2: The Researcher
 * Takes the outline, iterates over points, and gathers data using tools.
 */
async function researcherNode(state: AgentState): Promise<Partial<AgentState>> {
  if (!state.outline) throw new Error("No outline provided to researcher.");

  const researchPromises = state.outline.map(async (point) => {
    // Asynchronous Tool Handling: Await the external tool call
    return await fetchResearchData(point);
  });

  const results = await Promise.all(researchPromises);
  const researchNotes = results.join('\n\n');

  return {
    researchNotes,
    nextAgent: 'writer'
  };
}

/**
 * Node 3: The Writer
 * Synthesizes the outline and research into a final draft.
 */
async function writerNode(state: AgentState): Promise<Partial<AgentState>> {
  if (!state.outline || !state.researchNotes) {
    throw new Error("Missing outline or research notes for writer.");
  }

  const model = new ChatOpenAI({ model: "gpt-4-turbo-preview" });

  const prompt = `You are a Senior Copywriter. Write a comprehensive blog post based on the following outline and research notes.
  
  Outline: ${JSON.stringify(state.outline)}
  Research: ${state.researchNotes}
  
  Format the output in Markdown.`;

  const response = await model.invoke(prompt);
  const draft = response.content as string;

  return {
    draft,
    nextAgent: 'finish'
  };
}

// ============================================================================
// 4. GRAPH ORCHESTRATION
// ============================================================================

/**
 * Routes the execution flow based on the state's 'nextAgent' property.
 */
function router(state: AgentState): string {
  return state.nextAgent;
}

/**
 * Constructs the LangGraph.
 * Defines nodes, edges, and the entry point.
 */
function createWorkflow() {
  const workflow = new StateGraph<AgentState>({
    channels: {
      topic: { value: null }, // Initial input
      outline: { value: null },
      researchNotes: { value: null },
      draft: { value: null },
      nextAgent: { value: null } // Control flow channel
    }
  });

  // Add nodes to the graph
  workflow.addNode("planner", plannerNode);
  workflow.addNode("researcher", researcherNode);
  workflow.addNode("writer", writerNode);

  // Define entry point
  workflow.setEntryPoint("planner");

  // Define conditional edges (routing)
  workflow.addConditionalEdges(
    "planner",
    router,
    { researcher: "researcher" }
  );

  workflow.addConditionalEdges(
    "researcher",
    router,
    { writer: "writer" }
  );

  workflow.addConditionalEdges(
    "writer",
    router,
    { finish: END }
  );

  return workflow.compile();
}

// ============================================================================
// 5. NEXT.JS API ROUTE HANDLER
// ============================================================================

/**
 * POST Handler: Receives a topic and triggers the multi-agent workflow.
 */
export async function POST(req: NextRequest) {
  try {
    const { topic } = await req.json();

    if (!topic) {
      return NextResponse.json(
        { error: "Topic is required" },
        { status: 400 }
      );
    }

    // Initialize the compiled graph
    const app = createWorkflow();

    // Initial State
    const initialState: AgentState = {
      topic,
      nextAgent: 'planner'
    };

    // Execute the graph asynchronously
    // The graph handles the flow: Planner -> Researcher -> Writer -> END
    const finalState = await app.invoke(initialState);

    return NextResponse.json({
      status: "success",
      draft: finalState.draft,
      outline: finalState.outline,
      researchNotes: finalState.researchNotes
    });

  } catch (error) {
    console.error("Agent Workflow Error:", error);
    return NextResponse.json(
      { error: "Internal Server Error" },
      { status: 500 }
    );
  }
}
