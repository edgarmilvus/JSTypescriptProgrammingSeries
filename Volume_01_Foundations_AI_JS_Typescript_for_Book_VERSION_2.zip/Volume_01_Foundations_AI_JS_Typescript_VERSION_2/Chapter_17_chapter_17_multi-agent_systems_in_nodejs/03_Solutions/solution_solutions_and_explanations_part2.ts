/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

import { Tool } from "@langchain/core/tools";

// 1. Simulated Delays
const getPrice = (product: string): Promise<number> => {
  return new Promise((resolve) => {
    console.log(`Fetching price for ${product}...`);
    setTimeout(() => {
      console.log(`Price fetched for ${product}.`);
      resolve(999); // Dummy price
    }, 2000);
  });
};

const checkInventory = (product: string, location: string): Promise<boolean> => {
  return new Promise((resolve) => {
    console.log(`Checking inventory for ${product} in ${location}...`);
    setTimeout(() => {
      console.log(`Inventory checked for ${product}.`);
      resolve(true); // Dummy stock status
    }, 2000);
  });
};

// 2. Custom Tool Wrapper
class FetchProductDataTool extends Tool {
  name = "fetch_product_data";
  description = "Fetches price and inventory status for a product. Input: product name and location.";

  async _call(input: string): Promise<string> {
    // Simple parsing: "Product, Location"
    const parts = input.split(",");
    if (parts.length < 2) return "Error: Please provide 'Product, Location'";
    
    const product = parts[0].trim();
    const location = parts[1].trim();

    const startTime = Date.now();
    console.log("--- Starting Parallel Execution ---");

    // 3. Parallel Execution using Promise.all
    try {
      const [price, inStock] = await Promise.all([
        getPrice(product),
        checkInventory(product, location)
      ]);

      const endTime = Date.now();
      const duration = (endTime - startTime) / 1000;
      
      return `Success! Product: ${product}. Price: $${price}. In Stock: ${inStock}. Total time: ${duration}s`;
    } catch (error) {
      return "Error fetching product data.";
    }
  }
}

// 4. Agent Integration (Conceptual usage)
export async function checkProductStatus(product: string, location: string): Promise<string> {
  const tool = new FetchProductDataTool();
  // In a real agent, this would be passed to createOpenAIFunctionsAgent
  // Here we invoke the tool directly to demonstrate the parallel logic
  return await tool.invoke(`${product}, ${location}`);
}
