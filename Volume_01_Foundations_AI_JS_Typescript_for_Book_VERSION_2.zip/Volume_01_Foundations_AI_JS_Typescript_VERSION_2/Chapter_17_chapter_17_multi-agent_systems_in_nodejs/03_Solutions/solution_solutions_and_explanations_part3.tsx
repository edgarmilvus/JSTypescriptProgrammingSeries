/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState, useEffect } from 'react';

// 1. Type Definitions
type AgentStatus = 'idle' | 'thinking' | 'executing_tool';

interface Agent {
  id: string;
  name: string;
  status: AgentStatus;
  lastAction: string | null;
}

// Helper for styling status dots
const getStatusColor = (status: AgentStatus): string => {
  switch (status) {
    case 'idle': return 'green';
    case 'thinking': return 'yellow';
    case 'executing_tool': return 'red';
    default: return 'gray';
  }
};

export const AgentDashboard: React.FC = () => {
  // 2. State Management
  const [agents, setAgents] = useState<Agent[]>([
    { id: '1', name: 'Classifier Agent', status: 'idle', lastAction: null },
    { id: '2', name: 'Researcher Agent', status: 'idle', lastAction: null },
  ]);

  // 3. Simulation Logic
  useEffect(() => {
    const interval = setInterval(() => {
      setAgents((prevAgents) => {
        return prevAgents.map((agent) => {
          // Randomly cycle status
          const statuses: AgentStatus[] = ['idle', 'thinking', 'executing_tool'];
          const randomStatus = statuses[Math.floor(Math.random() * statuses.length)];
          
          // Only update if status changes to avoid unnecessary re-renders
          if (agent.status !== randomStatus) {
            return { ...agent, status: randomStatus };
          }
          return agent;
        });
      });
    }, 2000); // Update every 2 seconds

    return () => clearInterval(interval);
  }, []);

  // 4. Interactivity
  const handleNewTask = () => {
    const timestamp = new Date().toLocaleTimeString();
    setAgents((prevAgents) =>
      prevAgents.map((agent) => ({
        ...agent,
        status: 'thinking', // Reset to thinking on new task
        lastAction: `Task dispatched at ${timestamp}`,
      }))
    );
  };

  return (
    <div className="dashboard" style={{ padding: '20px', fontFamily: 'Arial, sans-serif' }}>
      <h2>Agent Supervisor Dashboard</h2>
      <button 
        onClick={handleNewTask} 
        style={{ marginBottom: '20px', padding: '8px 16px', cursor: 'pointer' }}
      >
        Dispatch New Task
      </button>

      <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
        {agents.map((agent) => (
          <div 
            key={agent.id} 
            style={{ 
              border: '1px solid #ccc', 
              padding: '10px', 
              borderRadius: '5px',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between'
            }}
          >
            <div>
              <strong>{agent.name}</strong>
              <div style={{ fontSize: '0.8em', color: '#666' }}>
                Last Action: {agent.lastAction || 'None'}
              </div>
            </div>
            
            {/* 4. Visualization: Status Indicator */}
            <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
              <span>{agent.status.toUpperCase()}</span>
              <div 
                style={{ 
                  width: '12px', 
                  height: '12px', 
                  borderRadius: '50%', 
                  backgroundColor: getStatusColor(agent.status) 
                }} 
              />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
