/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

// 1. State Interface
interface TravelState {
  flightBooked: boolean;
  hotelBooked: boolean;
}

// 2. Conditional Tools (Simulated as functions for this logic-heavy exercise)
// In a real LangChain agent, these would extend the Tool class.
class TravelTools {
  
  static bookFlight(state: TravelState): { newState: TravelState; log: string } {
    console.log("Executing Tool: bookFlight");
    return {
      newState: { ...state, flightBooked: true },
      log: "Flight to Paris has been booked."
    };
  }

  static bookHotel(state: TravelState): { newState: TravelState; log: string } {
    console.log("Executing Tool: bookHotel");
    return {
      newState: { ...state, hotelBooked: true },
      log: "Hotel in Paris has been reserved."
    };
  }

  static askForMissingInfo(state: TravelState): { newState: TravelState; log: string } {
    console.log("Executing Tool: askForMissingInfo");
    return {
      newState: state, // No state change
      log: "Ask user: Please confirm destination and dates."
    };
  }
}

// 3. Router Logic & 4. Loop Implementation
export async function planTravelItinerary(
  initialState: TravelState,
  goal: string
): Promise<string[]> {
  
  let currentState = initialState;
  const executionLog: string[] = [];
  let iterations = 0;
  const MAX_ITERATIONS = 10; // Safety break

  console.log(`Starting itinerary planning. Goal: ${goal}`);

  while (iterations < MAX_ITERATIONS) {
    iterations++;

    // Check if goal is met
    if (currentState.flightBooked && currentState.hotelBooked) {
      executionLog.push("Goal achieved: Flight and Hotel booked.");
      console.log("Goal achieved.");
      break;
    }

    // Router Logic: Decide which tool to call based on current state
    let actionResult: { newState: TravelState; log: string };

    if (!currentState.flightBooked) {
      // Priority 1: Book Flight
      actionResult = TravelTools.bookFlight(currentState);
    } else if (!currentState.hotelBooked) {
      // Priority 2: Book Hotel
      actionResult = TravelTools.bookHotel(currentState);
    } else {
      // Fallback (should not be reached due to while condition, but good for safety)
      actionResult = TravelTools.askForMissingInfo(currentState);
    }

    // Update State and Log
    currentState = actionResult.newState;
    executionLog.push(actionResult.log);
  }

  return executionLog;
}
