/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

// file: ai-stream-parser.ts
import { z } from 'zod';

// 1. Define the Schema
// We expect the AI to return a structured summary of a user's project.
// This ensures type safety in our React/Vue/Svelte frontend.
const ProjectSummarySchema = z.object({
  title: z.string().min(1),
  sentiment: z.enum(['positive', 'neutral', 'negative']),
  keyFeatures: z.array(z.string()).max(3),
  estimatedHours: z.number().positive(),
});

// Type inference for TypeScript
export type ProjectSummary = z.infer<typeof ProjectSummarySchema>;

/**
 * Simulates an LLM streaming response (Server-Sent Events).
 * In a real app, this would be an OpenAI stream or LangChain.js callback.
 * 
 * @param input - The prompt sent to the AI
 * @returns An async generator yielding string tokens
 */
async function* mockLLMStream(input: string): AsyncGenerator<string, void, unknown> {
  // Simulating a JSON response stream from the AI
  const jsonTokens = JSON.stringify({
    title: "Project Alpha",
    sentiment: "positive",
    keyFeatures: ["Fast", "Scalable", "Secure"],
    estimatedHours: 40
  }).split(''); // Split into individual characters to simulate streaming

  // Yield tokens with a slight delay to simulate network latency
  for (const char of jsonTokens) {
    yield char;
    await new Promise(resolve => setTimeout(resolve, 10)); // Simulate network delay
  }
}

/**
 * Accumulates stream tokens and validates against the Zod schema.
 * 
 * @param stream - The AsyncGenerator from the LLM
 * @returns The validated, typed object
 * @throws Error if the accumulated JSON is invalid or schema validation fails
 */
export async function parseAndValidateStream(
  stream: AsyncGenerator<string, void, unknown>
): Promise<ProjectSummary> {
  let accumulatedContent = '';

  // 1. Consume the stream
  for await (const chunk of stream) {
    accumulatedContent += chunk;
  }

  // 2. Attempt to parse the raw string into JSON
  let parsedData: unknown;
  try {
    parsedData = JSON.parse(accumulatedContent);
  } catch (error) {
    throw new Error(`Failed to parse JSON from stream: ${accumulatedContent}`);
  }

  // 3. Validate against the Zod schema
  // This is the critical step: converting unstructured AI output into typed data
  const validationResult = ProjectSummarySchema.safeParse(parsedData);

  if (!validationResult.success) {
    // Format Zod errors for debugging (useful in SaaS logs)
    const errorMessages = validationResult.error.issues.map(issue => 
      `${issue.path.join('.')}: ${issue.message}`
    ).join(', ');
    throw new Error(`Schema validation failed: ${errorMessages}`);
  }

  return validationResult.data;
}
