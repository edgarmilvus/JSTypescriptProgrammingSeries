/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

// schemas.ts
import { z } from 'zod';

// 1. Schema Definition
export const SummarizationRequestSchema = z.object({
  text: z.string().min(1), // Non-empty string
  style: z.enum(['bullet_points', 'paragraph']).optional(),
});

export const SummarizationResponseSchema = z.object({
  summary: z.string().min(1), // Non-empty string
  wordCount: z.number().int().positive(), // Positive integer
});

// 2. Validation Function
export function validateSummarizationResponse(response: unknown) {
  try {
    // Attempt to parse the response against the schema
    const parsedData = SummarizationResponseSchema.parse(response);
    return parsedData;
  } catch (error) {
    // Check if it is a Zod error to access .issues
    if (error instanceof z.ZodError) {
      // Create a descriptive error message
      const errorMessages = error.issues.map(issue => 
        `${issue.path.join('.')}: ${issue.message}`
      ).join('; ');
      
      throw new Error(`Validation failed: ${errorMessages}`);
    }
    // Re-throw if it's an unexpected error type
    throw error;
  }
}

// --- Jest Tests for the function (would typically be in schemas.test.ts) ---
// Included here for completeness of the solution context

/**
 * describe('validateSummarizationResponse', () => {
 *   it('should return parsed data for valid response', () => {
 *     const valid = { summary: 'Test', wordCount: 5 };
 *     const result = validateSummarizationResponse(valid);
 *     expect(result).toEqual(valid);
 *   });
 *
 *   it('should throw error for missing summary', () => {
 *     const invalid = { wordCount: 5 };
 *     expect(() => validateSummarizationResponse(invalid))
 *       .toThrow('Validation failed: summary: Required');
 *   });
 *
 *   it('should throw error for negative wordCount', () => {
 *     const invalid = { summary: 'Test', wordCount: -1 };
 *     expect(() => validateSummarizationResponse(invalid))
 *       .toThrow('Validation failed: wordCount: Number must be greater than 0');
 *   });
 *
 *   it('should throw error for string wordCount', () => {
 *     const invalid = { summary: 'Test', wordCount: 'five' };
 *     expect(() => validateSummarizationResponse(invalid))
 *       .toThrow('Validation failed: wordCount: Expected number');
 *   });
 * });
 */
