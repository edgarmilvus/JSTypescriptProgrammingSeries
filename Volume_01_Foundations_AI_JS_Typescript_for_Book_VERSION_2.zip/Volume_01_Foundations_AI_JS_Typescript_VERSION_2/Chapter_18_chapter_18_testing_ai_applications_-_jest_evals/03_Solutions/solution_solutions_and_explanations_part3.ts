/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

// 1. Golden Dataset (golden_dataset.json)
/*
[
  { "input": "I cannot access my account.", "expectedCategory": "Technical" },
  { "input": "My invoice is wrong.", "expectedCategory": "Billing" },
  { "input": "How do I reset my password?", "expectedCategory": "Technical" },
  { "input": "I love this product!", "expectedCategory": "General Inquiry" },
  { "input": "Refund request for order #123.", "expectedCategory": "Billing" },
  { "input": "The app crashes on startup.", "expectedCategory": "Technical" },
  { "input": "Where is your office located?", "expectedCategory": "General Inquiry" },
  { "input": "When will I be charged?", "expectedCategory": "Billing" },
  { "input": "Feature request: dark mode.", "expectedCategory": "General Inquiry" },
  { "input": "Error 404 on dashboard.", "expectedCategory": "Technical" }
]
*/

// 2. Mock Chain (mockClassifierChain.ts)
export class MockClassifierChain {
  async invoke(input: string): Promise<{ text: string }> {
    // Simulate network delay
    await new Promise(resolve => setTimeout(resolve, 10));

    // Intentional misclassification logic (20% failure rate simulation)
    // We use a deterministic check based on input length to make testing reproducible,
    // but strictly following the prompt's request for randomness:
    const shouldFail = Math.random() < 0.2;

    if (shouldFail) {
      // Return a wrong category
      return { text: 'General Inquiry' };
    }

    // Simple keyword matching for "correct" behavior
    const lowerInput = input.toLowerCase();
    if (lowerInput.includes('invoice') || lowerInput.includes('refund') || lowerInput.includes('charge')) {
      return { text: 'Billing' };
    }
    if (lowerInput.includes('access') || lowerInput.includes('reset') || lowerInput.includes('crash') || lowerInput.includes('error')) {
      return { text: 'Technical' };
    }
    
    return { text: 'General Inquiry' };
  }
}

// 3. Evaluation Script (evaluate.ts)
import dataset from './golden_dataset.json';
import { MockClassifierChain } from './mockClassifierChain';

interface DatasetItem {
  input: string;
  expectedCategory: string;
}

interface EvaluationResult {
  input: string;
  expected: string;
  predicted: string;
  correct: boolean;
}

async function runEvaluation() {
  const chain = new MockClassifierChain();
  const results: EvaluationResult[] = [];
  let correctCount = 0;

  console.log('Starting Evaluation...');

  for (const item of dataset) {
    // Run the chain
    const response = await chain.invoke(item.input);
    const predictedCategory = response.text.trim();
    
    // Compare
    const isCorrect = predictedCategory === item.expectedCategory;
    if (isCorrect) correctCount++;

    // Store result
    results.push({
      input: item.input,
      expected: item.expectedCategory,
      predicted: predictedCategory,
      correct: isCorrect
    });
  }

  // Calculate Accuracy
  const accuracy = (correctCount / dataset.length) * 100;

  // Visualization
  console.log('\n--- Evaluation Results ---');
  console.table(results);
  console.log(`\nTotal Accuracy: ${accuracy.toFixed(2)}% (${correctCount}/${dataset.length})`);
}

runEvaluation().catch(console.error);
