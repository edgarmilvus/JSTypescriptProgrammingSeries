/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.tsx
// Description: Solutions and Explanations
// ==========================================

// AIChatStream.tsx
import React, { useState, useEffect, useRef } from 'react';

// Define Message type
interface Message {
  role: 'user' | 'assistant';
  content: string;
}

// Custom Mock Hook to simulate `useChat`
const useMockChat = () => {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [streamingContent, setStreamingContent] = useState('');
  const [error, setError] = useState<string | null>(null);

  const sendMessage = async () => {
    if (!input.trim()) return;

    // 1. Add user message immediately
    const userMessage: Message = { role: 'user', content: input };
    const newMessages = [...messages, userMessage];
    setMessages(newMessages);
    setInput('');
    setIsLoading(true);
    setError(null);
    setStreamingContent(''); // Reset stream

    // 2. Simulate API delay and streaming response
    // Mock response text
    const mockResponse = `This is a simulated streaming response to: "${input}". It arrives token by token.`;
    
    let index = 0;
    
    // 3. Simulate Server-Sent Events (SSE) with setInterval
    const streamInterval = setInterval(() => {
      if (index < mockResponse.length) {
        setStreamingContent(prev => prev + mockResponse[index]);
        index++;
      } else {
        // Stream finished
        clearInterval(streamInterval);
        
        // 4. Commit stream to history
        const assistantMessage: Message = { role: 'assistant', content: mockResponse };
        setMessages([...newMessages, assistantMessage]);
        setStreamingContent(''); // Clear stream buffer
        setIsLoading(false);
      }
    }, 50); // 50ms delay between characters
  };

  return {
    messages,
    input,
    setInput,
    sendMessage,
    isLoading,
    streamingContent,
    error
  };
};

export const AIChatStream: React.FC = () => {
  const {
    messages,
    input,
    setInput,
    sendMessage,
    isLoading,
    streamingContent,
    error
  } = useMockChat();

  // Feature: Auto-scroll to bottom
  const messagesEndRef = useRef<HTMLDivElement>(null);
  
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, streamingContent]);

  return (
    <div style={{ maxWidth: '600px', margin: '0 auto', fontFamily: 'sans-serif', border: '1px solid #ccc', borderRadius: '8px', overflow: 'hidden' }}>
      {/* Conversation Area */}
      <div style={{ height: '400px', overflowY: 'auto', padding: '16px', background: '#f9f9f9' }}>
        {messages.map((msg, idx) => (
          <div key={idx} style={{ marginBottom: '8px', textAlign: msg.role === 'user' ? 'right' : 'left' }}>
            <span style={{ 
              display: 'inline-block', 
              padding: '8px 12px', 
              borderRadius: '12px', 
              background: msg.role === 'user' ? '#007bff' : '#e9ecef', 
              color: msg.role === 'user' ? 'white' : 'black',
              maxWidth: '80%'
            }}>
              {msg.content}
            </span>
          </div>
        ))}
        
        {/* Streaming Indicator */}
        {isLoading && streamingContent && (
          <div style={{ marginBottom: '8px', textAlign: 'left' }}>
            <span style={{ 
              display: 'inline-block', 
              padding: '8px 12px', 
              borderRadius: '12px', 
              background: '#e9ecef', 
              color: '#555',
              fontStyle: 'italic'
            }}>
              {streamingContent} <span style={{ animation: 'blink 1s infinite' }}>|</span>
            </span>
          </div>
        )}

        {/* Loading without text yet (Typing indicator) */}
        {isLoading && !streamingContent && (
           <div style={{ marginBottom: '8px', textAlign: 'left' }}>
            <span style={{ background: '#e9ecef', padding: '8px 12px', borderRadius: '12px' }}>
              ...
            </span>
           </div>
        )}

        {/* Error Display */}
        {error && (
          <div style={{ color: 'red', background: '#ffe6e6', padding: '8px', marginTop: '8px' }}>
            Error: {error}
          </div>
        )}
        
        {/* Dummy div for scrolling */}
        <div ref={messagesEndRef} />
      </div>

      {/* Input Area */}
      <div style={{ display: 'flex', padding: '16px', background: 'white', borderTop: '1px solid #ccc' }}>
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && sendMessage()}
          placeholder="Type a message..."
          disabled={isLoading}
          style={{ flex: 1, padding: '8px', border: '1px solid #ddd', borderRadius: '4px', marginRight: '8px' }}
        />
        <button 
          onClick={sendMessage} 
          disabled={isLoading}
          style={{ padding: '8px 16px', background: '#007bff', color: 'white', border: 'none', borderRadius: '4px', cursor: 'pointer' }}
        >
          {isLoading ? 'Sending...' : 'Send'}
        </button>
      </div>
    </div>
  );
};

// Add basic CSS for blink animation (usually in a CSS file, but included here for completeness)
// In a real app, this would be in your index.css
const style = document.createElement('style');
style.textContent = `
  @keyframes blink { 0%, 100% { opacity: 1; } 50% { opacity: 0; } }
`;
document.head.appendChild(style);
