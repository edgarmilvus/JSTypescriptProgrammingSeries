/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

// solution.ts
import { z } from 'zod';

// --- 1. Define Zod Schema ---
const EntitySchema = z.object({
  city: z.string().min(1),
  day: z.string().min(1),
});

// --- 2. Mock Chain Logic (Simulating LangChain) ---

// Mock for Step 1 (Entity Extraction)
// Returns a promise resolving to a JSON string (simulating LLM text output)
const mockStep1_Extractor = async (input: string): Promise<string> => {
  // Simulate LLM processing
  await new Promise(r => setTimeout(r, 10));
  
  if (input.includes("Paris") && input.includes("Friday")) {
    // Valid JSON output
    return JSON.stringify({ city: "Paris", day: "Friday" });
  }
  // Invalid JSON output (missing 'city') to test error handling
  if (input.includes("Invalid")) {
    return JSON.stringify({ day: "Saturday" }); 
  }
  // Default valid
  return JSON.stringify({ city: "London", day: "Today" });
};

// Mock for Step 2 (Response Generation)
// Takes the parsed object and returns text
const mockStep2_Generator = async (entities: { city: string, day: string }): Promise<string> => {
  await new Promise(r => setTimeout(r, 10));
  return `The weather in ${entities.city} on ${entities.day} is sunny.`;
};

// --- 3. The Robust Pipeline Function ---
export async function runWeatherPipeline(userQuery: string): Promise<string> {
  // Step 1: Extract
  const rawOutput = await mockStep1_Extractor(userQuery);

  // Validation Layer: Parse string to JSON, then validate against Schema
  let validatedEntities: z.infer<typeof EntitySchema>;
  
  try {
    // Parse JSON string
    const parsedJson = JSON.parse(rawOutput);
    
    // Validate against Zod Schema
    validatedEntities = EntitySchema.parse(parsedJson);
  } catch (error) {
    // Handle both JSON parse errors and Zod validation errors
    if (error instanceof z.ZodError) {
      return `Pipeline Error: Entity extraction failed validation. Issues: ${error.issues.map(i => i.path.join('.')).join(', ')}`;
    }
    if (error instanceof SyntaxError) {
      return `Pipeline Error: Entity extraction returned invalid JSON.`;
    }
    return `Pipeline Error: Unknown error.`;
  }

  // Step 2: Generate (Only runs if Step 1 validation passed)
  const finalResponse = await mockStep2_Generator(validatedEntities);
  return finalResponse;
}

// --- 4. Jest Tests (Conceptual) ---
/**
 * describe('Weather Pipeline', () => {
 *   it('should successfully complete the pipeline with valid extraction', async () => {
 *     const result = await runWeatherPipeline("What is the weather in Paris on Friday?");
 *     expect(result).toBe("The weather in Paris on Friday is sunny.");
 *   });
 *
 *   it('should stop and return error message if extraction is invalid', async () => {
 *     // This input triggers the mock to return JSON missing 'city'
 *     const result = await runWeatherPipeline("Invalid input query");
 *     expect(result).toContain("Pipeline Error: Entity extraction failed validation");
 *     // Ensure it did NOT call the generator (by checking the specific error message)
 *     expect(result).not.toContain("The weather in");
 *   });
 * });
 */

// Example Usage for verification
(async () => {
  console.log("Test 1 (Valid):", await runWeatherPipeline("What is the weather in Paris on Friday?"));
  console.log("Test 2 (Invalid):", await runWeatherPipeline("Invalid input query"));
})();
