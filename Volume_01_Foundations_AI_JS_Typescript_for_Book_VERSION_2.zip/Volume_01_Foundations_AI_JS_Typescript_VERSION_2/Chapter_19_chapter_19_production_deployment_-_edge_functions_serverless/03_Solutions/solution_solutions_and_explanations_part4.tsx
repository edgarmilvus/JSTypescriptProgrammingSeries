/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.tsx
// Description: Solutions and Explanations
// ==========================================

// File: components/LatencySimulator.tsx
import React, { useState } from 'react';

type DeploymentMode = 'Edge' | 'Traditional';
type Location = 'US-East' | 'EU-West' | 'Asia-Pacific';

const ORIGIN_LOCATION: Location = 'US-East';

export function LatencySimulator() {
  const [mode, setMode] = useState<DeploymentMode>('Edge');
  const [location, setLocation] = useState<Location>('EU-West');
  const [latency, setLatency] = useState<number>(0);
  const [diagram, setDiagram] = useState<string>('');

  // Calculate distance (mock logic)
  const getDistance = (loc: Location): number => {
    const distances: Record<Location, number> = {
      'US-East': 0,
      'EU-West': 5000, // km
      'Asia-Pacific': 12000, // km
    };
    return distances[loc];
  };

  const calculateLatency = () => {
    const distance = getDistance(location);
    let calculated = 0;

    if (mode === 'Edge') {
      // Edge: Low latency, distributed nodes
      // Base 20ms + (distance * 0.0005ms per km) - simplified math for visual impact
      calculated = 20 + (distance * 0.0005); 
    } else {
      // Traditional: High latency, backhaul to origin
      // Base 50ms + (distance * 0.002ms per km)
      calculated = 50 + (distance * 0.002);
    }
    
    setLatency(Math.round(calculated));
    generateDiagram(distance, calculated);
  };

  const generateDiagram = (distance: number, calculatedLatency: number) => {
    // Graphviz DOT syntax
    let dot = `digraph NetworkPath {\n  rankdir=LR;\n  node [shape=box];\n`;
    
    if (mode === 'Edge') {
      dot += `  User [label="User (${location})"];\n`;
      dot += `  EdgeNode [label="Edge Node (Local)\nLatency: ~${Math.round(calculatedLatency * 0.3)}ms"];\n`;
      dot += `  Origin [label="Origin (US-East)\nLatency: ~${Math.round(calculatedLatency * 0.7)}ms"];\n`;
      dot += `  User -> EdgeNode [label="Local Connection"];\n`;
      dot += `  EdgeNode -> Origin [label="Internal Backhaul"];\n`;
    } else {
      dot += `  User [label="User (${location})"];\n`;
      dot += `  Origin [label="Origin (US-East)\nLatency: ~${calculatedLatency}ms"];\n`;
      dot += `  User -> Origin [label="Long Haul (${Math.round(distance)}km)"];\n`;
    }
    
    dot += `}`;
    setDiagram(dot);
  };

  return (
    <div style={{ padding: '20px', fontFamily: 'sans-serif' }}>
      <h2>Latency Simulator</h2>
      
      <div style={{ marginBottom: '20px', display: 'flex', gap: '10px', alignItems: 'center' }}>
        <label>
          Mode:
          <select value={mode} onChange={(e) => setMode(e.target.value as DeploymentMode)}>
            <option value="Edge">Edge Network</option>
            <option value="Traditional">Traditional Serverless</option>
          </select>
        </label>

        <label>
          User Location:
          <select value={location} onChange={(e) => setLocation(e.target.value as Location)}>
            <option value="US-East">US-East</option>
            <option value="EU-West">EU-West</option>
            <option value="Asia-Pacific">Asia-Pacific</option>
          </select>
        </label>

        <button onClick={calculateLatency} style={{ padding: '8px 16px', cursor: 'pointer' }}>
          Calculate Latency
        </button>
      </div>

      {latency > 0 && (
        <div style={{ marginBottom: '20px', padding: '15px', border: '2px solid #333', borderRadius: '8px', backgroundColor: '#f0f0f0' }}>
          <h3>Estimated Latency: <span style={{ color: mode === 'Edge' ? 'green' : 'orange' }}>{latency}ms</span></h3>
        </div>
      )}

      {diagram && (
        <div style={{ marginTop: '20px' }}>
          <h4>Network Path Visualization (Graphviz DOT):</h4>
          <pre style={{ backgroundColor: '#222', color: '#0f0', padding: '10px', borderRadius: '4px', overflowX: 'auto' }}>
            {diagram}
          </pre>
          <p style={{ fontSize: '0.8em', color: '#666' }}>
            *Note: Paste the DOT code into a tool like <a href="https://dreampuf.github.io/GraphvizOnline/" target="_blank">GraphvizOnline</a> to render the image.*
          </p>
        </div>
      )}
    </div>
  );
}
