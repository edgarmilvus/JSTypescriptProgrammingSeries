/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

// File: app/api/summary/route.ts
import { NextResponse } from 'next/server';

// 1. Define the Generic Caching Interface
interface EdgeCache<T> {
  get(key: string): Promise<T | null>;
  set(key: string, value: T): Promise<void>;
}

// 2. Mock Implementation using Map (In production, this would be Vercel KV, Cloudflare KV, etc.)
const memoryCache: EdgeCache<string> = {
  store: new Map<string, string>(),
  async get(key: string) {
    return this.store.get(key) || null;
  },
  async set(key: string, value: string) {
    this.store.set(key, value);
  },
};

// Mock function simulating an expensive LLM call
async function generateSummary(articleId: string): Promise<string> {
  // Simulate delay for LLM generation
  await new Promise(resolve => setTimeout(resolve, 1000));
  return `Summary for article ${articleId}: This is a generated AI summary of the news content...`;
}

// 3. Edge Function Handler
export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const articleId = searchParams.get('id');

  if (!articleId) {
    return NextResponse.json({ error: 'Article ID is required' }, { status: 400 });
  }

  const cacheKey = `summary:${articleId}`;

  try {
    // 4. Check Cache
    const cachedSummary = await memoryCache.get(cacheKey);

    if (cachedSummary) {
      // Return cached response with headers
      return new NextResponse(cachedSummary, {
        headers: {
          'Content-Type': 'text/plain',
          // s-maxage is used by CDN/Edge caches, maxage by browser
          'Cache-Control': 'public, s-maxage=3600, stale-while-revalidate=86400',
          'X-Cache': 'HIT',
        },
      });
    }

    // 5. Generate and Cache
    const newSummary = await generateSummary(articleId);
    await memoryCache.set(cacheKey, newSummary);

    return new NextResponse(newSummary, {
      headers: {
        'Content-Type': 'text/plain',
        'Cache-Control': 'public, s-maxage=3600',
        'X-Cache': 'MISS',
      },
    });
  } catch (error) {
    console.error('Summary generation error:', error);
    return NextResponse.json({ error: 'Internal Server Error' }, { status: 500 });
  }
}
