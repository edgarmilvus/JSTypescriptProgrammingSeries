/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * @fileoverview Edge Runtime AI Proxy
 * 
 * This file demonstrates a serverless function running on an Edge Runtime.
 * It performs three critical tasks:
 * 1. Validates incoming JSON payload using Zod to prevent injection attacks.
 * 2. Acts as a secure proxy to an external AI provider (simulated here).
 * 3. Streams the response back to the client to minimize Time-to-First-Byte (TTFB).
 */

// -----------------------------------------------------------------------------
// 1. Dependency Imports
// -----------------------------------------------------------------------------
// We import 'zod' for runtime schema validation.
// We import 'next/headers' for Edge-compatible runtime configuration.
import { z } from 'zod';

// -----------------------------------------------------------------------------
// 2. Schema Definition (Zod)
// -----------------------------------------------------------------------------
// In a multi-tenant SaaS, you cannot trust incoming data. 
// We define a strict schema for the incoming request.
const RequestSchema = z.object({
  prompt: z.string().min(1).max(1000), // Ensure prompt is a non-empty string
  tenantId: z.string().uuid(),         // Ensure tenant ID is a valid UUID
});

// Infer the TypeScript type from the Zod schema for type safety
type RequestPayload = z.infer<typeof RequestSchema>;

// -----------------------------------------------------------------------------
// 3. The Edge Function
// -----------------------------------------------------------------------------
/**
 * Handles POST requests to the AI proxy endpoint.
 * 
 * @param req - The incoming Request object
 * @returns A Response object with a streaming body
 */
export async function POST(req: Request): Promise<Response> {
  try {
    // -------------------------------------------------------------------------
    // 4. Input Validation (The "Gatekeeper")
    // -------------------------------------------------------------------------
    // Parse the JSON body. If validation fails, Zod throws an error immediately.
    // This prevents malformed data from reaching the AI model or database.
    const body = await req.json();
    const { prompt, tenantId } = RequestSchema.parse(body);

    // -------------------------------------------------------------------------
    // 5. Simulated AI Call & Stream Creation
    // -------------------------------------------------------------------------
    // In production, you would fetch from OpenAI or a local model via WebGPU/WASM.
    // Here, we simulate a streaming response using a ReadableStream.
    // This pattern is crucial for Edge runtimes to avoid timeouts on large payloads.
    
    const encoder = new TextEncoder();
    const stream = new ReadableStream({
      async start(controller) {
        // Simulate a "thinking" delay (common in LLMs)
        await new Promise(resolve => setTimeout(resolve, 100));

        // Simulate streaming chunks of text
        const chunks = [
          `Processing request for Tenant: ${tenantId}...\n`,
          `Received prompt: "${prompt}"\n`,
          `Response: Hello from the Edge! This is a streamed response.\n`,
          `Optimized for low latency and high concurrency.`
        ];

        for (const chunk of chunks) {
          controller.enqueue(encoder.encode(chunk));
          // Simulate network latency between chunks
          await new Promise(resolve => setTimeout(resolve, 100));
        }

        controller.close();
      },
    });

    // -------------------------------------------------------------------------
    // 6. Return Streamed Response
    // -------------------------------------------------------------------------
    // We return the stream immediately. The client receives data as it is generated.
    return new Response(stream, {
      headers: {
        'Content-Type': 'text/plain; charset=utf-8',
        // Enable CORS for SaaS frontend consumption
        'Access-Control-Allow-Origin': '*',
      },
    });

  } catch (error) {
    // -------------------------------------------------------------------------
    // 7. Error Handling
    // -------------------------------------------------------------------------
    // Specific handling for Zod validation errors
    if (error instanceof z.ZodError) {
      return new Response(
        JSON.stringify({ 
          error: 'Validation Failed', 
          details: error.errors 
        }), 
        { status: 400, headers: { 'Content-Type': 'application/json' } }
      );
    }

    // Generic error handling
    return new Response(
      JSON.stringify({ error: 'Internal Server Error' }), 
      { status: 500, headers: { 'Content-Type': 'application/json' } }
    );
  }
}
