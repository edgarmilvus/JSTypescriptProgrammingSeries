/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

import { z } from "zod";

// 1. Define the TypeScript interface
export interface DocumentMetadata {
  tenantId: string; // UUID
  documentId: string; // UUID
  fileName: string;
  fileSize: number; // Bytes
  mimeType: string;
  status: 'pending' | 'processing' | 'completed' | 'failed';
  uploadedAt: string; // ISO Date string
}

// 2. Create the Zod schema with specific validation rules
export const DocumentMetadataSchema = z.object({
  tenantId: z.string().uuid("Tenant ID must be a valid UUID"),
  documentId: z.string().uuid("Document ID must be a valid UUID"),
  fileName: z.string()
    .min(1, "File name cannot be empty")
    .max(255, "File name must be 255 characters or less"),
  fileSize: z.number()
    .positive("File size must be a positive number")
    .max(10 * 1024 * 1024, "File size must be less than 10MB"),
  mimeType: z.enum([
    "application/pdf",
    "text/plain",
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
  ], {
    errorMap: () => ({ message: "Invalid MIME type. Allowed types are PDF, TXT, or DOCX." })
  }),
  status: z.enum(['pending', 'processing', 'completed', 'failed']).default('pending'),
  uploadedAt: z.string().datetime("Uploaded at must be a valid ISO date string")
});

// 3. Implement the validation function
export async function validateAndSanitizeDocumentInput(input: unknown): Promise<DocumentMetadata> {
  try {
    // .parse() throws an error if validation fails
    // .parseAsync() handles potential async refinements if added later
    const validatedData = await DocumentMetadataSchema.parseAsync(input);
    return validatedData;
  } catch (error) {
    // Re-throw with a descriptive message or handle specific Zod errors
    if (error instanceof z.ZodError) {
      const errorMessage = error.errors.map(err => `${err.path.join('.')}: ${err.message}`).join(', ');
      throw new Error(`Validation failed: ${errorMessage}`);
    }
    throw new Error("An unexpected error occurred during validation.");
  }
}
