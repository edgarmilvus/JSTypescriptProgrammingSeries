/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

digraph RagPipeline {
    rankdir=LR;
    node [shape=box, style="rounded,filled", color=lightblue];

    // Client Side
    subgraph cluster_client {
        label = "Client (Browser)";
        style = dashed;
        node [color=lightgrey];
        User [label="User"];
        UI [label="React Component\n(DocumentAnalysisChat)"];
    }

    // Server Side
    subgraph cluster_server {
        label = "SaaS Backend (Node.js/TypeScript)";
        style = solid;
        
        API [label="API Gateway\n(Express/Fastify)"];
        Validator [label="Zod Validation\n(Exercise 1)"];
        Ingestion [label="Document Processor\n(Chunking & Embedding)"];
        VectorDB [label="Vector DB\n(Pinecone/Chroma)", shape=cylinder];
        RAGChain [label="LangChain.js RAG Chain\n(Exercise 2 & 5)", color=orange];
    }

    // External Services
    External [label="LLM Provider\n(OpenAI)", shape=ellipse];

    // Flow 1: Ingestion
    User -> UI [label="Upload Document"];
    UI -> API [label="POST /upload"];
    API -> Validator [label="Validate Metadata"];
    Validator -> Ingestion [label="Valid Data"];
    Ingestion -> External [label="Generate Embeddings"];
    Ingestion -> VectorDB [label="Store Vectors + Metadata\n(tenantId)"];

    // Flow 2: Query & Response
    User -> UI [label="Ask Question"];
    UI -> API [label="POST /analyze\n(documentId, query)"];
    API -> RAGChain [label="Execute Chain"];
    
    RAGChain -> VectorDB [label="Retrieve Context\n(Filter: tenantId)"];
    VectorDB -> RAGChain [label="Relevant Chunks"];
    
    RAGChain -> External [label="Generate Answer"];
    External -> RAGChain [label="Stream Tokens"];
    
    RAGChain -> API [label="Stream Response"];
    API -> UI [label="SSE/Fetch Stream"];
    UI -> User [label="Display Real-Time Text"];

    // Annotations
    { rank = same; VectorDB; External; }
}
