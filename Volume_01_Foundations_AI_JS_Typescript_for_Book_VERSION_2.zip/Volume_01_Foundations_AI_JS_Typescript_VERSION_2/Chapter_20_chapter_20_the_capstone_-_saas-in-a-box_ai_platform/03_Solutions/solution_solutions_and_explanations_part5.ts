/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

import { ChatOpenAI } from "@langchain/openai";
import { RunnableSequence, RunnablePassthrough } from "@langchain/core/runnables";
import { BaseRetriever } from "@langchain/core/retrievers";
import { Document } from "@langchain/core/documents";

// 1. Enhanced Chain Creation
export async function createResilientRetrievalChain(tenantId: string): Promise<RunnableSequence> {
  // Primary Model: GPT-4 (Expensive, High Quality)
  const primaryModel = new ChatOpenAI({ 
    modelName: "gpt-4", 
    temperature: 0 
  });

  // Fallback Model: GPT-3.5 (Cheaper, Faster)
  const fallbackModel = new ChatOpenAI({ 
    modelName: "gpt-3.5-turbo", 
    temperature: 0 
  });

  // Mock Retriever
  const retriever: BaseRetriever = {
    async _getRelevantQueries(query: string): Promise<Document[]> {
        // Simulate potential failure
        if (Math.random() > 0.9) throw new Error("Vector Store Connection Error");
        return [new Document({ pageContent: "Context data." })];
    }
  };

  const prompt = `Context: {context}\nQuestion: {question}\nAnswer:`;

  // Helper to build the core logic
  const buildChain = (model: ChatOpenAI) => 
    RunnableSequence.from([
      {
        question: (input: { question: string }) => input.question,
        context: async (input: { question: string }) => {
            try {
                const docs = await retriever._getRelevantQueries(input.question);
                return docs.map(d => d.pageContent).join("\n");
            } catch (e) {
                // If retrieval fails, we throw to trigger the chain's error handler
                // or return a safe context string.
                console.error("Retrieval failed:", e);
                return "No context available.";
            }
        },
      },
      prompt,
      model,
      (output) => output.content as string
    ]);

  // 2. Implementing Fallbacks using .withFallbacks (LangChain Feature)
  // Note: .withFallbacks is available in recent LangChain versions.
  // If unavailable, a try/catch wrapper around the invoke call is used.
  
  // We construct the chain with the primary model
  const primaryChain = buildChain(primaryModel);
  
  // We define the fallback chain logic
  const fallbackChain = buildChain(fallbackModel);

  // Create a combined chain that tries primary, then fallback
  const resilientChain = RunnableSequence.from([
    primaryChain,
    // Using a custom fallback logic wrapper since .withFallbacks might vary by version
    // This wrapper catches errors from the previous step (primaryChain)
    new RunnablePassthrough({
      func: async (input: string) => input, // Pass through if successful
    }).withFallbacks({
        fallbacks: [
            // If primaryChain fails (throws), try fallbackChain
            fallbackChain,
            // If fallbackChain also fails, return generic message
            RunnablePassthrough.from(() => "Sorry, I'm having trouble accessing that information right now. Please try again later.")
        ]
    })
  ]);

  return resilientChain;
}

// 3. Test Function
export async function simulateFailure(chain: RunnableSequence) {
  console.log("Simulating failure scenario...");
  
  // Mocking environment variable to force API error
  const originalKey = process.env.OPENAI_API_KEY;
  delete process.env.OPENAI_API_KEY;

  try {
    const result = await chain.invoke({ question: "What is the policy?" });
    console.log("Result:", result);
    
    // Verify fallback triggered
    if (result === "Sorry, I'm having trouble accessing that information right now. Please try again later.") {
        console.log("SUCCESS: Fallback mechanism triggered correctly.");
    } else {
        console.log("Result received (might be cached or mocked).");
    }
  } catch (error) {
    console.error("FAILURE: The chain did not handle the error gracefully:", error);
  } finally {
    // Restore key
    if (originalKey) process.env.OPENAI_API_KEY = originalKey;
  }
}
