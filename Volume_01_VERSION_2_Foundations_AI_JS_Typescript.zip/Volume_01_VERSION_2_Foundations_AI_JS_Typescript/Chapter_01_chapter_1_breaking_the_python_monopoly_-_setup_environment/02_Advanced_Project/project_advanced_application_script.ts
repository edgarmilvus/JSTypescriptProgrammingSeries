/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// src/lib/rag-pipeline.ts
/**
 * @fileoverview Advanced RAG Pipeline Orchestrator.
 * This script demonstrates a modular, type-safe approach to building a RAG system
 * in a TypeScript/Next.js environment, utilizing Zod for validation and pgvector for storage.
 */

import { z } from 'zod';
import { createClient } from '@supabase/supabase-js';
import { OpenAI } from 'openai';

// ==========================================
// 1. Configuration & Type Safety (Zod)
// ==========================================

/**
 * Schema for environment variables.
 * Ensures all required keys are present and valid at runtime.
 * This bridges the gap between .env files and TypeScript types.
 */
const EnvSchema = z.object({
  OPENAI_API_KEY: z.string().min(1),
  SUPABASE_URL: z.string().url(),
  SUPABASE_SERVICE_ROLE_KEY: z.string().min(1),
  MODEL_NAME: z.string().default('text-embedding-ada-002'),
});

// Parse and infer TypeScript type
type EnvConfig = z.infer<typeof EnvSchema>;

/**
 * Validates environment variables strictly.
 * Throws an error if validation fails, preventing the app from running in an invalid state.
 */
function loadConfig(): EnvConfig {
  const env = {
    OPENAI_API_KEY: process.env.OPENAI_API_KEY,
    SUPABASE_URL: process.env.SUPABASE_URL,
    SUPABASE_SERVICE_ROLE_KEY: process.env.SUPABASE_SERVICE_ROLE_KEY,
    MODEL_NAME: process.env.MODEL_NAME,
  };

  const result = EnvSchema.safeParse(env);

  if (!result.success) {
    console.error('❌ Invalid Environment Configuration:', result.error.flatten());
    throw new Error('Environment validation failed');
  }

  return result.data;
}

// Initialize Config
const config = loadConfig();

// ==========================================
// 2. Service Initialization
// ==========================================

/**
 * OpenAI Client Instance.
 * Initialized with strict typing from the 'openai' package.
 */
const openai = new OpenAI({
  apiKey: config.OPENAI_API_KEY,
});

/**
 * Supabase Client Instance.
 * Configured with the Service Role Key for secure, server-side operations.
 * We use the generic type to ensure database schema compliance (optional but recommended).
 */
const supabase = createClient(config.SUPABASE_URL, config.SUPABASE_SERVICE_ROLE_KEY, {
  auth: {
    autoRefreshToken: false,
    persistSession: false,
  },
});

// ==========================================
// 3. Core Logic Modules
// ==========================================

/**
 * Generates an embedding vector for a given text string using OpenAI.
 * @param text - The text to embed.
 * @returns A Promise resolving to an array of numbers (the vector).
 */
async function generateEmbedding(text: string): Promise<number[]> {
  try {
    const response = await openai.embeddings.create({
      model: config.MODEL_NAME,
      input: text,
    });

    // Extract the embedding vector from the response
    const embedding = response.data[0].embedding;
    return embedding;
  } catch (error) {
    console.error('Error generating embedding:', error);
    throw new Error('Embedding generation failed');
  }
}

/**
 * Stores a document and its embedding in the Supabase database using pgvector.
 * Assumes a table named 'documents' with columns: content (text), embedding (vector(1536)).
 * 
 * @param content - The raw text content.
 * @param metadata - Optional metadata (e.g., source URL, title).
 */
async function storeDocument(content: string, metadata: Record<string, any> = {}) {
  // 1. Generate embedding
  const embedding = await generateEmbedding(content);

  // 2. Insert into Supabase
  // Note: Supabase's pgvector syntax uses a specific format for array insertion.
  const { error } = await supabase
    .from('documents')
    .insert({
      content,
      embedding: JSON.stringify(embedding), // pgvector often expects a JSON string or array format
      metadata,
    });

  if (error) {
    console.error('Error storing document:', error);
    throw new Error('Database storage failed');
  }
}

/**
 * Retrieves relevant context based on a user query.
 * Uses pgvector's cosine similarity operator (<=>) to find the closest matches.
 * 
 * @param query - The user's search query.
 * @param k - The number of top results to retrieve.
 * @returns A Promise resolving to an array of document chunks.
 */
async function retrieveContext(query: string, k: number = 3): Promise<string[]> {
  // 1. Generate embedding for the query
  const queryEmbedding = await generateEmbedding(query);

  // 2. Perform vector search
  // We use 'embedding' column and the cosine distance operator.
  // 'order by ... asc' sorts by smallest distance (most similar).
  const { data, error } = await supabase.rpc('match_documents', {
    query_embedding: queryEmbedding,
    match_count: k,
  });

  if (error) {
    console.error('Error retrieving context:', error);
    throw new Error('Retrieval failed');
  }

  // 3. Map results to text content
  // Assuming the RPC function returns an array of objects with a 'content' field
  return data?.map((doc: { content: string }) => doc.content) || [];
}

/**
 * Synthesizes an answer using the OpenAI Chat Completions API.
 * 
 * @param query - The original user question.
 * @param context - The retrieved documents to ground the answer.
 * @returns A Promise resolving to the generated answer string.
 */
async function synthesizeAnswer(query: string, context: string[]): Promise<string> {
  const contextText = context.join('\n\n---\n\n');
  
  const systemPrompt = `You are a helpful assistant. Answer the user's question based strictly on the provided context.
  If the answer is not found in the context, state that you do not have the information.
  
  Context:
  ${contextText}
  `;

  const completion = await openai.chat.completions.create({
    model: 'gpt-4-turbo-preview',
    messages: [
      { role: 'system', content: systemPrompt },
      { role: 'user', content: query },
    ],
    temperature: 0.1, // Low temperature for factual consistency
  });

  return completion.choices[0].message.content || 'No response generated.';
}

// ==========================================
// 4. Main Orchestration Function
// ==========================================

/**
 * Main entry point for the RAG pipeline.
 * Orchestrates the flow: Ingestion (optional) -> Retrieval -> Synthesis.
 * 
 * In a Next.js API route, this function would be called upon a POST request.
 */
export async function runRagPipeline(query: string, mode: 'retrieve' | 'ingest' = 'retrieve') {
  console.log(`🚀 Starting RAG Pipeline in mode: ${mode}`);

  try {
    // Example: Ingestion Mode (Simulating a background job or admin action)
    if (mode === 'ingest') {
      console.log('📝 Ingesting sample document...');
      await storeDocument('Node.js is a JavaScript runtime built on Chrome\'s V8 JavaScript engine.', {
        source: 'docs/nodejs.org',
        section: 'introduction',
      });
      await storeDocument('TypeScript is a strongly typed programming language that builds on JavaScript.', {
        source: 'docs.typescriptlang.org',
        section: 'overview',
      });
      console.log('✅ Ingestion complete.');
      return;
    }

    // Retrieval & Synthesis Mode
    console.log('🔍 Retrieving context for query:', query);
    const context = await retrieveContext(query);

    if (context.length === 0) {
      return "I couldn't find any relevant information in the knowledge base.";
    }

    console.log('🧠 Synthesizing answer...');
    const answer = await synthesizeAnswer(query, context);

    console.log('✅ Pipeline Complete.');
    return {
      query,
      context,
      answer,
    };

  } catch (error) {
    console.error('❌ Pipeline Error:', error);
    throw error;
  }
}

// ==========================================
// 5. Execution (For local testing)
// ==========================================

// Example usage block (would be removed in production build, kept here for demonstration)
(async () => {
  // Check if running directly via ts-node/tsx
  if (require.main === module) {
    try {
      const result = await runRagPipeline('What is TypeScript?', 'retrieve');
      if (result && typeof result !== 'string') {
        console.log('\n--- FINAL OUTPUT ---');
        console.log('Question:', result.query);
        console.log('Answer:', result.answer);
      }
    } catch (e) {
      console.error(e);
    }
  }
})();
