/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

// src/env.ts
import { z } from 'zod';

// 1. Define the Zod schema
const EnvSchema = z.object({
  OPENAI_API_KEY: z.string().startsWith('sk-', {
    message: "OpenAI API key must start with 'sk-'",
  }),
  PORT: z.coerce.number().default(3000),
  NODE_ENV: z.enum(['development', 'production', 'test']).default('development'),
});

// 2. Define the inferred TypeScript type
export type Env = z.infer<typeof EnvSchema>;

// 3. Create the loader function
export function loadEnv(): Env {
  try {
    // Parse process.env against the schema
    const validatedEnv = EnvSchema.parse(process.env);
    console.log('✅ Environment variables validated successfully.');
    return validatedEnv;
  } catch (error) {
    if (error instanceof z.ZodError) {
      const errorMessage = `❌ Invalid environment configuration:\n${error.issues
        .map((issue) => `  - ${issue.path.join('.')}: ${issue.message}`)
        .join('\n')}`;
      console.error(errorMessage);
      // Throw error to stop execution
      throw new Error('Environment validation failed');
    }
    throw error;
  }
}

// src/index.ts
import { loadEnv } from './env';

// Load and validate environment variables
const env = loadEnv();

// 4. Demonstrate usage with masked key
const maskedKey = `${env.OPENAI_API_KEY.slice(0, 7)}...${env.OPENAI_API_KEY.slice(-4)}`;
console.log(`Using API Key: ${maskedKey}`);
console.log(`Server running on port: ${env.PORT}`);
console.log(`Current environment: ${env.NODE_ENV}`);
