/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

// src/types.ts
export interface StandardCompletion {
  role: 'assistant';
  content: string;
}

export interface ToolCallCompletion {
  role: 'assistant';
  tool_calls: {
    name: string;
    arguments: string; // JSON string
  }[];
}

// src/processResponse.ts
import { StandardCompletion, ToolCallCompletion } from './types';

// 1. Define the User-Defined Type Guard
function isToolCallCompletion(
  response: StandardCompletion | ToolCallCompletion
): response is ToolCallCompletion {
  // Check for the existence of the specific property
  return 'tool_calls' in response && Array.isArray(response.tool_calls);
}

// 2. The processing function
export function processResponse(
  response: StandardCompletion | ToolCallCompletion
): void {
  if (isToolCallCompletion(response)) {
    // TypeScript now knows 'response' is ToolCallCompletion
    const tool = response.tool_calls[0];
    console.log(`Tool Call: ${tool.name} with arguments: ${tool.arguments}`);
  } else {
    // TypeScript now knows 'response' is StandardCompletion
    console.log(`Content: ${response.content}`);
  }
}

// src/index.ts (Interactive Challenge)
import { StandardCompletion, ToolCallCompletion } from './types';
import { processResponse } from './processResponse';

// 3. Helper to generate random response
function generateRandomResponse(): StandardCompletion | ToolCallCompletion {
  if (Math.random() > 0.5) {
    return {
      role: 'assistant',
      content: 'This is a standard text response.',
    };
  } else {
    return {
      role: 'assistant',
      tool_calls: [
        {
          name: 'get_weather',
          arguments: JSON.stringify({ location: 'San Francisco' }),
        },
      ],
    };
  }
}

// 4. Run the simulation
console.log('--- Running Interactive Simulation ---');
for (let i = 0; i < 5; i++) {
  console.log(`\nAttempt ${i + 1}:`);
  const randomResponse = generateRandomResponse();
  processResponse(randomResponse);
}
