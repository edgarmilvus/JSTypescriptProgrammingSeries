/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part6.tsx
// Description: Solutions and Explanations
// ==========================================

// src/components/ModelStatusDisplay.tsx
import React from 'react';

// 1. Define the union type for status
export type ModelStatus = 'connecting' | 'processing' | 'finished' | 'error';

interface ModelStatusProps {
  status: ModelStatus;
  message?: string; // Optional message for errors
}

// 2. Helper component for a simple spinner
const Spinner = () => (
  <div style={{ border: '4px solid #f3f3f3', borderTop: '4px solid #3498db', borderRadius: '50%', width: '20px', height: '20px', animation: 'spin 1s linear infinite', display: 'inline-block', marginLeft: '10px' }} />
);

// 3. Helper component for a progress bar
const ProgressBar = () => (
  <div style={{ width: '100%', backgroundColor: '#e0e0e0', borderRadius: '5px', marginTop: '5px' }}>
    <div style={{ width: '70%', height: '10px', backgroundColor: '#4caf50', borderRadius: '5px', animation: 'progress 2s ease-in-out infinite' }} />
  </div>
);

// 4. Main Component
export const ModelStatusDisplay: React.FC<ModelStatusProps> = ({ status, message }) => {
  const renderContent = () => {
    switch (status) {
      case 'connecting':
        return (
          <div>
            <span>Connecting to model...</span>
            <Spinner />
          </div>
        );

      case 'processing':
        return (
          <div>
            <div>Model is thinking...</div>
            <ProgressBar />
          </div>
        );

      case 'finished':
        return (
          <div style={{ color: 'green', fontWeight: 'bold' }}>
            <span>Complete! </span>
            <span role="img" aria-label="checkmark">✅</span>
          </div>
        );

      case 'error':
        return (
          <div style={{ color: 'red', fontWeight: 'bold' }}>
            <div>Error occurred</div>
            {message && <div style={{ fontWeight: 'normal', fontSize: '0.9em', marginTop: '5px' }}>{message}</div>}
          </div>
        );
        
      default:
        return null;
    }
  };

  return (
    <div style={{ padding: '20px', border: '1px solid #ccc', borderRadius: '8px', maxWidth: '300px', fontFamily: 'sans-serif' }}>
      {renderContent()}
    </div>
  );
};

// Optional: Add basic CSS animations for the spinner/progress bar
// In a real app, this would be in a CSS file
const style = document.createElement('style');
style.innerHTML = `
  @keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }
  @keyframes progress { 0% { width: 0%; } 50% { width: 80%; } 100% { width: 70%; } }
`;
document.head.appendChild(style);
