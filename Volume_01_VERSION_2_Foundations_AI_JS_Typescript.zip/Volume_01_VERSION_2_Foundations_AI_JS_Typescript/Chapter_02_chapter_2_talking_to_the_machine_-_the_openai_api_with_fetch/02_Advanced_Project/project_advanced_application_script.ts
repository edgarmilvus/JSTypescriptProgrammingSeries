/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// /pages/api/analyze-feedback.ts
// Next.js API Route for processing customer feedback using OpenAI.

import type { NextApiRequest, NextApiResponse } from 'next';
import { Configuration, OpenAIApi } from 'openai';
import { z } from 'zod';

// -----------------------------------------------------------------------------
// 1. TYPE DEFINITIONS & UTILITY TYPES
// -----------------------------------------------------------------------------

/**
 * Represents a single customer feedback entry.
 * We use a mapped type here to ensure immutability of the incoming data.
 */
type FeedbackEntry = {
  id: string;
  text: string;
  timestamp: number;
};

/**
 * Utility Type: Extracts only the 'text' property from FeedbackEntry.
 * This is useful for preparing data specifically for the AI prompt, 
 * separating the core content from metadata.
 */
type AIPromptInput = Pick<FeedbackEntry, 'text'>;

/**
 * The structured output expected from the OpenAI model.
 * We define this strictly to ensure the downstream application 
 * receives predictable data.
 */
export interface AnalysisResult {
  sentiment: 'positive' | 'neutral' | 'negative';
  summary: string;
  keywords: string[];
  urgency: number; // 1-10 scale
}

// -----------------------------------------------------------------------------
// 2. SCHEMA VALIDATION (ZOD)
// -----------------------------------------------------------------------------

/**
 * Zod schema to validate the incoming request body.
 * Ensures 'feedbacks' is an array of objects containing 'text' (string) and 'id' (string).
 * This prevents malformed data from hitting the OpenAI API, saving costs and latency.
 */
const RequestSchema = z.object({
  feedbacks: z.array(
    z.object({
      id: z.string().uuid(),
      text: z.string().min(1).max(1000), // Limit input size
    })
  ),
});

type RequestBody = z.infer<typeof RequestSchema>;

// -----------------------------------------------------------------------------
// 3. CONFIGURATION & IMMUTABLE STATE
// -----------------------------------------------------------------------------

// Initialize OpenAI configuration.
// In a real app, process.env.OPENAI_API_KEY is used.
const configuration = new Configuration({
  apiKey: process.env.OPENAI_API_KEY,
});
const openai = new OpenAIApi(configuration);

/**
 * Immutable State: System Prompt
 * This configuration dictates the AI's behavior. It is defined as a constant
 * to prevent accidental mutation during the request lifecycle.
 */
const SYSTEM_PROMPT = `
You are an AI assistant for a SaaS Customer Support platform. 
Analyze the provided customer feedback and return a JSON object with the following structure:
{
  "sentiment": "positive" | "neutral" | "negative",
  "summary": "A concise 1-sentence summary.",
  "keywords": ["array", "of", "relevant", "words"],
  "urgency": number (1-10, where 10 is critical)
}
Strictly return only the JSON object. No Markdown formatting.
`;

// -----------------------------------------------------------------------------
// 4. LOGIC BREAKDOWN
// -----------------------------------------------------------------------------

/**
 * API Route Handler
 * 
 * 1. Validates incoming request using Zod.
 * 2. Maps feedback data to an immutable array of prompt inputs.
 * 3. Constructs a robust prompt for OpenAI.
 * 4. Calls OpenAI Chat Completions API.
 * 5. Parses and validates the AI response.
 * 6. Returns structured JSON.
 */
export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse
) {
  // --- Step 1: Validation ---
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  const parsed = RequestSchema.safeParse(req.body);
  if (!parsed.success) {
    return res.status(400).json({ error: 'Invalid input', details: parsed.error });
  }

  // --- Step 2: Immutable Data Transformation ---
  // We create a new array containing only the text needed for the prompt.
  // This adheres to immutable state management principles.
  const promptInputs: AIPromptInput[] = parsed.data.feedbacks.map((fb) => ({
    text: fb.text,
  }));

  // --- Step 3: Prompt Engineering ---
  // We aggregate the feedback texts into a single string for the user message.
  const userMessage = promptInputs
    .map((input, idx) => `Feedback ${idx + 1}: "${input.text}"`)
    .join('\n\n');

  try {
    // --- Step 4: OpenAI API Call ---
    const completion = await openai.createChatCompletion({
      model: 'gpt-3.5-turbo', // Or 'gpt-4'
      messages: [
        { role: 'system', content: SYSTEM_PROMPT },
        { role: 'user', content: userMessage },
      ],
      temperature: 0.3, // Lower temperature for deterministic structured output
      max_tokens: 500,
    });

    const rawContent = completion.data.choices[0].message?.content;

    if (!rawContent) {
      throw new Error('Empty response from AI');
    }

    // --- Step 5: Parsing & Response ---
    // Parse the string response into a JSON object.
    // In a production app, we would run this through a Zod schema again
    // to ensure the AI didn't hallucinate the structure.
    const result: AnalysisResult = JSON.parse(rawContent);

    // Return the immutable result object
    return res.status(200).json(result);

  } catch (error: any) {
    console.error('OpenAI Error:', error);
    return res.status(500).json({ 
      error: 'Failed to analyze feedback', 
      details: error.message 
    });
  }
}
