/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState, useRef } from 'react';

interface SmartSummaryProps {
  sourceText: string;
}

export const SmartSummary: React.FC<SmartSummaryProps> = ({ sourceText }) => {
  const [summary, setSummary] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  
  // Ref to store the AbortController for cancellation
  const abortControllerRef = useRef<AbortController | null>(null);

  const generateSummary = async () => {
    // Reset state
    setSummary('');
    setError(null);
    setIsLoading(true);

    // Initialize AbortController
    const controller = new AbortController();
    abortControllerRef.current = controller;

    try {
      // NOTE: In a real app, this endpoint would be a Next.js API route or Server Action
      // to protect the API key. For this exercise, we simulate the fetch call.
      const response = await fetch('/api/proxy-summary', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: `Summarize this text: ${sourceText}`,
          stream: true,
        }),
        signal: controller.signal, // Attach signal for aborting
      });

      if (!response.ok) {
        throw new Error(`API Error: ${response.statusText}`);
      }

      // 1. Get the readable stream
      const reader = response.body?.getReader();
      if (!reader) throw new Error('No response body');

      const decoder = new TextDecoder();
      let done = false;

      // 2. Loop through the stream chunks
      while (!done) {
        const { value, done: streamDone } = await reader.read();
        done = streamDone;

        if (value) {
          const chunk = decoder.decode(value, { stream: true });
          // Parse Server-Sent Events (SSE) format: "data: {json}"
          const lines = chunk.split('\n').filter(line => line.startsWith('data: '));
          
          for (const line of lines) {
            try {
              const jsonStr = line.replace('data: ', '');
              if (jsonStr === '[DONE]') continue;
              
              const data = JSON.parse(jsonStr);
              const delta = data.choices[0]?.delta?.content;
              if (delta) {
                // Accumulate content
                setSummary(prev => prev + delta);
              }
            } catch (e) {
              // Ignore parsing errors for incomplete JSON chunks
            }
          }
        }
      }
    } catch (err: any) {
      if (err.name === 'AbortError') {
        setError('Generation stopped by user.');
      } else {
        setError(err.message || 'An unknown error occurred');
      }
    } finally {
      setIsLoading(false);
      abortControllerRef.current = null;
    }
  };

  const handleStop = () => {
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
    }
  };

  return (
    <div style={{ padding: '20px', border: '1px solid #ccc', borderRadius: '8px' }}>
      <h3>Smart Summary</h3>
      
      <textarea 
        value={sourceText} 
        readOnly 
        style={{ width: '100%', height: '100px', marginBottom: '10px' }} 
      />

      <div style={{ marginBottom: '10px' }}>
        {!isLoading ? (
          <button onClick={generateSummary} disabled={!sourceText}>
            Generate Summary
          </button>
        ) : (
          <button onClick={handleStop} style={{ backgroundColor: '#ffcccc' }}>
            Stop Generation
          </button>
        )}
      </div>

      {isLoading && <p>Generating summary...</p>}
      
      {error && <div style={{ color: 'red' }}>Error: {error}</div>}

      {summary && (
        <div style={{ marginTop: '10px' }}>
          <strong>Summary:</strong>
          <p>{summary}</p>
        </div>
      )}
    </div>
  );
};
