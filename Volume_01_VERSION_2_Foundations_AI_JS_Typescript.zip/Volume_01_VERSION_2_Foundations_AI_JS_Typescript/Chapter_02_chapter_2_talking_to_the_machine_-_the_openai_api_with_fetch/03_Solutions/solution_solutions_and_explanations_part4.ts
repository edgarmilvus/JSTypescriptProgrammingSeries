/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

import OpenAI from 'openai';

// 1. Define Types
type WorkerAgent = 'CodeReviewer' | 'CreativeWriter' | 'Generalist';

// Initialize OpenAI
const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

/**
 * Supervisor Node: Routes prompts to the appropriate worker agent.
 * Handles low confidence by routing to 'Generalist'.
 */
async function supervisorRouter(userPrompt: string): Promise<WorkerAgent> {
  const systemPrompt = `
    You are a supervisor. Analyze the user input.
    If it is about programming, code, or debugging, respond with 'CodeReviewer'.
    If it is about writing, storytelling, or brainstorming, respond with 'CreativeWriter'.
    If you are unsure or the confidence is low, respond with 'UNCERTAIN'.
    Respond ONLY with the single word agent name.
  `;

  try {
    const completion = await openai.chat.completions.create({
      model: 'gpt-3.5-turbo',
      messages: [
        { role: 'system', content: systemPrompt },
        { role: 'user', content: userPrompt },
      ],
      max_tokens: 10,
      temperature: 0.1, // Low temp for deterministic routing
    });

    const rawResponse = completion.choices[0].message.content?.trim() || '';
    
    // 2. Conflict Resolution Logic
    if (rawResponse.includes('UNCERTAIN')) {
      console.log(`Supervisor: Low confidence detected. Routing to Generalist.`);
      return 'Generalist';
    }

    // Validate response against allowed types
    if (rawResponse === 'CodeReviewer' || rawResponse === 'CreativeWriter') {
      return rawResponse;
    }

    // Fallback for malformed responses
    console.warn(`Supervisor: Unexpected response '${rawResponse}'. Defaulting to Generalist.`);
    return 'Generalist';

  } catch (error) {
    console.error('Supervisor routing failed:', error);
    // Fail safe: route to generalist on system failure
    return 'Generalist';
  }
}

// Example Usage
/*
supervisorRouter("How do I fix a null pointer exception in Java?")
  .then(agent => console.log(`Routed to: ${agent}`)); // Output: CodeReviewer

supervisorRouter("Write a poem about the rain.")
  .then(agent => console.log(`Routed to: ${agent}`)); // Output: CreativeWriter

supervisorRouter("Maybe something about apples?")
  .then(agent => console.log(`Routed to: ${agent}`)); // Output: Generalist (Low confidence)
*/
