/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part6.ts
// Description: Solutions and Explanations
// ==========================================

'use server';

import { z } from 'zod';
import OpenAI from 'openai';

// 1. Input Validation Schema
const IdeaSchema = z.object({
  topic: z.string().min(3, { message: "Topic must be at least 3 characters long." }),
});

// Initialize OpenAI (Server-side only, key is safe)
const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

/**
 * Server Action: Generates a business idea based on a topic.
 * Returns a structured object for use with useFormState.
 */
export async function generateIdea(prevState: any, formData: FormData) {
  const topic = formData.get('topic') as string;

  // 2. Validate Input
  const validation = IdeaSchema.safeParse({ topic });

  if (!validation.success) {
    return {
      error: true,
      message: validation.error.errors[0].message,
      idea: null,
    };
  }

  try {
    // 3. Call OpenAI (Securely on Server)
    const completion = await openai.chat.completions.create({
      model: 'gpt-3.5-turbo',
      messages: [
        { role: 'system', content: 'You are a creative business idea generator.' },
        { role: 'user', content: `Generate a unique business idea for the topic: ${validation.data.topic}` },
      ],
      max_tokens: 150,
    });

    const idea = completion.choices[0].message.content;

    return {
      error: false,
      message: 'Idea generated successfully.',
      idea: idea,
    };

  } catch (err) {
    return {
      error: true,
      message: 'Failed to generate idea. Please try again.',
      idea: null,
    };
  }
}
