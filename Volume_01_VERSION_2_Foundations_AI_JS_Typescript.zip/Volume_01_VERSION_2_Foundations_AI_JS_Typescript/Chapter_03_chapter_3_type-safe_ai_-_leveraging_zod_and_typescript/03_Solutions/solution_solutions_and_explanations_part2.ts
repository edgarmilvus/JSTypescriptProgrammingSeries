/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

import { z } from 'zod';
import { StructuredOutputParser } from 'langchain/output_parsers';

// 1. Define the Zod schema for the recipe
const recipeSchema = z.object({
  title: z.string().describe("The name of the recipe"),
  ingredients: z.array(z.string()).describe("List of ingredients needed"),
  steps: z.array(z.string()).describe("Step-by-step instructions"),
  prepTimeMinutes: z.number().describe("Preparation time in minutes")
});

// 2. Create the LangChain StructuredOutputParser
const parser = StructuredOutputParser.fromZodSchema(recipeSchema);

// Helper type for TypeScript inference
type Recipe = z.infer<typeof recipeSchema>;

// 3. Function to parse LLM response
async function parseLLMResponse(llmOutput: string): Promise<Recipe> {
  try {
    // The parser expects the output to match the schema instructions.
    // In a real scenario, the LLM prompt should include parser.getFormatInstructions().
    const parsedResult = await parser.parse(llmOutput);
    
    // Additional runtime validation (defensive programming)
    // Although the parser does a lot, re-validating against the schema ensures strict type safety
    return recipeSchema.parse(parsedResult);
    
  } catch (error) {
    if (error instanceof z.ZodError) {
      console.error("Zod Validation Error:", error.errors);
      throw new Error("LLM output did not match the expected recipe schema.");
    }
    // Handle parsing errors from LangChain (e.g., unparseable JSON)
    throw new Error(`Failed to parse LLM response: ${error}`);
  }
}

// 4. Usage Example
/*
const llmOutput = `
Title: Chocolate Chip Cookies. 
Ingredients: Flour, Sugar, Eggs, Chocolate Chips. 
Steps: Mix dry ingredients, add wet ingredients, fold in chips, bake at 375F. 
Prep Time: 30 minutes.
`;

// Note: In a real LangChain chain, you would pass the parser to the LLM chain:
// const chain = new LLMChain({ llm, prompt, outputParser: parser });
// const result = await chain.call({ ... });

// Simulating the parsing process manually for the exercise:
(async () => {
  try {
    // We need to format the string to match what the parser expects (JSON-like or specific format)
    // For this demo, let's assume the parser can handle the text or we format it to JSON.
    const jsonLikeOutput = JSON.stringify({
      title: "Chocolate Chip Cookies",
      ingredients: ["Flour", "Sugar", "Eggs", "Chocolate Chips"],
      steps: ["Mix dry ingredients", "Add wet ingredients", "Fold in chips", "Bake at 375F"],
      prepTimeMinutes: 30
    });
    
    const recipe = await parseLLMResponse(jsonLikeOutput);
    console.log("Parsed Recipe:", recipe.title); 
  } catch (e) {
    console.error(e);
  }
})();
*/
