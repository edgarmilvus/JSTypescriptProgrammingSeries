/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

import { z } from 'zod';
import OpenAI from 'openai';

// 1. Define the Zod Schema
const ReceiptSchema = z.object({
  vendor: z.string(),
  date: z.coerce.date(), // Handles various date strings
  total: z.number(),
  items: z.array(
    z.object({
      description: z.string(),
      amount: z.number(),
    })
  ),
});

// 2. Design the CoT Prompt
function generateCoTPrompt(ocrText: string): string {
  return `You are a specialized receipt parser. Analyze the OCR text provided below.
Follow these steps strictly:
1. Identify the vendor name and transaction date.
2. Extract all line items (description and price).
3. Identify the subtotal, tax, and final total amount.
4. Construct a JSON object matching the schema: { vendor: string, date: string (ISO format), total: number, items: [{ description: string, amount: number }] }.

CRITICAL: Output ONLY the JSON object. Do not include the reasoning steps in the final output.

OCR Text:
${ocrText}`;
}

// 3. Implement the Extraction Function
export async function parseReceipt(ocrText: string) {
  const openai = new OpenAI();

  const response = await openai.chat.completions.create({
    model: "gpt-4o-mini",
    messages: [
      { role: "user", content: generateCoTPrompt(ocrText) }
    ],
    temperature: 0,
  });

  const content = response.choices[0].message.content;

  if (!content) {
    throw new Error("No content returned from LLM");
  }

  // Parsing Strategy: Extract JSON block
  // Since the prompt asks for "ONLY the JSON object", we look for the first `{` and last `}`
  // to handle potential minor hallucinations or whitespace.
  const jsonStart = content.indexOf('{');
  const jsonEnd = content.lastIndexOf('}') + 1;

  if (jsonStart === -1 || jsonEnd === 0) {
    throw new Error("LLM did not return a JSON object.");
  }

  const jsonString = content.substring(jsonStart, jsonEnd);

  try {
    const rawObj = JSON.parse(jsonString);
    // Validate against Zod schema
    const validatedReceipt = ReceiptSchema.parse(rawObj);
    return validatedReceipt;
  } catch (error) {
    console.error("Validation Error:", error);
    throw new Error("Failed to extract valid receipt data.");
  }
}
