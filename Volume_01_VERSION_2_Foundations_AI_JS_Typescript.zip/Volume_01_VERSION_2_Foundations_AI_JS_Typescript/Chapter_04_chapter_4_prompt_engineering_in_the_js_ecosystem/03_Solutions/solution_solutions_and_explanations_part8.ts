/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part8.ts
// Description: Solutions and Explanations
// ==========================================

import { z } from 'zod';
import OpenAI from 'openai';

// 1. Define the Schema
const BlogOutlineSchema = z.object({
  title: z.string(),
  introduction: z.string(),
  sections: z.array(
    z.object({
      heading: z.string(),
      bullets: z.array(z.string()),
    })
  ),
  conclusion: z.string(),
});

// 2. Implement the Generator
export async function generateOutline(topic: string) {
  const openai = new OpenAI();

  // System prompt instructing strict JSON output
  const systemPrompt = `You are an expert content strategist. Generate a blog post outline based on the user's topic.
  The output must be a raw JSON object matching this exact structure:
  {
    "title": "string",
    "introduction": "string",
    "sections": [
      { "heading": "string", "bullets": ["string", "string"] }
    ],
    "conclusion": "string"
  }
  Do not include any markdown formatting (like \`\`\`json), comments, or conversational text. Output only the JSON.`;

  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4o-mini",
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: `Topic: ${topic}` }
      ],
      // Enable JSON mode
      response_format: { type: "json_object" },
      temperature: 0.7,
    });

    const content = response.choices[0].message.content;

    if (!content) {
      throw new Error("Empty response from LLM");
    }

    // Parse and Validate
    const rawJson = JSON.parse(content);
    const validatedOutline = BlogOutlineSchema.parse(rawJson);

    return {
      success: true,
      data: validatedOutline,
    };

  } catch (error) {
    // 3. Error Handling
    if (error instanceof z.ZodError) {
      console.error("Zod Validation Errors:", error.errors);
      return {
        success: false,
        error: "The generated outline did not match the required schema. Please try again.",
        details: error.errors,
      };
    } else if (error instanceof SyntaxError) {
      return {
        success: false,
        error: "The LLM returned invalid JSON. The model likely ignored the JSON mode instruction.",
      };
    } else {
      return {
        success: false,
        error: "An unexpected error occurred during generation.",
      };
    }
  }
}
