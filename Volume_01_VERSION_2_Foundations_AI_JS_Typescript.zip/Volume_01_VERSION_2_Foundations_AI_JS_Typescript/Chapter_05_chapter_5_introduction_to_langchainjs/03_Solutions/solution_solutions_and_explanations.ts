/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// types.ts
export interface BookRecommendation {
  title: string;
  author: string;
  summary: string;
}

// mockLLM.ts
import { BaseLLM, LLMParams } from "@langchain/core/language_models/llms";

export class MockLLM extends BaseLLM {
  _llmType(): string {
    return "mock_llm";
  }

  async _call(prompt: string, options: this["ParsedCallOptions"]): Promise<string> {
    // Simulate an LLM response based on the prompt
    // In a real scenario, this would call an API or a local model
    if (prompt.includes("fantasy")) {
      return "Title: The Hobbit, Author: J.R.R. Tolkien, Summary: A fantasy adventure about a hobbit who embarks on a quest to reclaim treasure from a dragon.";
    }
    if (prompt.includes("sci-fi")) {
      return "Title: Dune, Author: Frank Herbert, Summary: A science fiction epic set on the desert planet Arrakis, focusing on politics, religion, and ecology.";
    }
    return "Title: Unknown Book, Author: Unknown Author, Summary: No specific recommendation found.";
  }
}

// promptTemplates.ts
import { PromptTemplate } from "@langchain/core/prompts";

export const bookPrompt = PromptTemplate.fromTemplate(
  `You are a helpful book recommendation assistant. Recommend a book based on the following genre: {genre}. 
  Please provide the output in the exact format: Title: [Title], Author: [Author], Summary: [Summary].`
);

// outputParsers.ts
import { BaseOutputParser } from "@langchain/core/output_parsers";
import { BookRecommendation } from "./types";

export class BookOutputParser extends BaseOutputParser<BookRecommendation> {
  lc_namespace = ["custom", "parsers"];

  async parse(text: string): Promise<BookRecommendation> {
    // Simple string parsing logic
    const titleMatch = text.match(/Title: (.*?)(?:,|$)/);
    const authorMatch = text.match(/Author: (.*?)(?:,|$)/);
    const summaryMatch = text.match(/Summary: (.*)/);

    if (!titleMatch || !authorMatch || !summaryMatch) {
      throw new Error(`Failed to parse output: ${text}`);
    }

    return {
      title: titleMatch[1].trim(),
      author: authorMatch[1].trim(),
      summary: summaryMatch[1].trim(),
    };
  }

  getFormatInstructions(): string {
    return "Output should be a string formatted as: Title: [Title], Author: [Author], Summary: [Summary]";
  }
}

// chain.ts
import { bookPrompt } from "./promptTemplates";
import { MockLLM } from "./mockLLM";
import { BookOutputParser } from "./outputParsers";
import { BookRecommendation } from "./types";

export async function runBookChain(genre: string): Promise<BookRecommendation> {
  const llm = new MockLLM({});
  const parser = new BookOutputParser();

  // Manually chaining the components
  // 1. Format the prompt
  const formattedPrompt = await bookPrompt.format({ genre });

  // 2. Call the LLM
  const rawResponse = await llm.invoke(formattedPrompt);

  // 3. Parse the output
  const parsedResponse = await parser.parse(rawResponse);

  return parsedResponse;
}

// Usage example (e.g., in a server file or API route)
/*
import { runBookChain } from './chain';

async function main() {
  try {
    const result = await runBookChain("fantasy");
    console.log("Structured Result:", result);
    // Output: { title: "The Hobbit", author: "J.R.R. Tolkien", summary: "..." }
  } catch (error) {
    console.error(error);
  }
}

main();
*/
