/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

// memorySetup.ts
import { ConversationSummaryMemory } from "@langchain/community/memory/chat_memory";
import { ChatOpenAI } from "@langchain/openai"; // Using a real LLM for summarization logic
import { PromptTemplate } from "@langchain/core/prompts";

// Initialize memory with a dummy LLM for summarization (or the main LLM)
export const initializeMemory = () => {
  // Note: In a real app, use your actual API key or a configured model
  // For this exercise, we simulate the summarization behavior
  const llm = new ChatOpenAI({ 
    model: "gpt-3.5-turbo", 
    temperature: 0, 
    // apiKey: "YOUR_API_KEY" // Placeholder
  });

  return new ConversationSummaryMemory({
    llm: llm,
    memoryKey: "chat_history",
    inputKey: "input",
  });
};

// conversationChain.ts
import { LLMChain } from "@langchain/core/chains";
import { PromptTemplate } from "@langchain/core/prompts";
import { BaseLanguageModel } from "@langchain/core/language_models/base";
import { BaseMemory } from "@langchain/core/memory";

export const createConversationChain = (llm: BaseLanguageModel, memory: BaseMemory) => {
  // Prompt that incorporates the conversation history/summary
  const prompt = PromptTemplate.fromTemplate(`
    You are a book recommendation assistant. 
    Here is a summary of the conversation so far:
    {chat_history}
    
    User: {input}
    Assistant:
  `);

  return new LLMChain({
    llm: llm,
    prompt: prompt,
    memory: memory,
  });
};

// conversationFlow.ts
import { ChatOpenAI } from "@langchain/openai";
import { initializeMemory } from "./memorySetup";
import { createConversationChain } from "./conversationChain";
import * as fs from 'fs/promises';

export async function runConversationFlow() {
  // Setup
  const llm = new ChatOpenAI({ 
    model: "gpt-3.5-turbo", 
    temperature: 0.7,
    // apiKey: "YOUR_API_KEY" // Placeholder
  });
  const memory = initializeMemory();
  const chain = createConversationChain(llm, memory);

  console.log("--- Turn 1: Sci-Fi Request ---");
  // We simulate the LLM response manually here to avoid API calls in the solution
  // In a real scenario: const result1 = await chain.invoke({ input: "Recommend a sci-fi book" });
  const result1 = "I recommend 'Dune' by Frank Herbert. It's a classic sci-fi epic.";
  console.log("User: Recommend a sci-fi book");
  console.log("Assistant:", result1);
  
  // Save context to memory
  await memory.saveContext(
    { input: "Recommend a sci-fi book" },
    { output: result1 }
  );

  console.log("\n--- Turn 2: Contextual Request ---");
  // The memory now contains the summary of the previous interaction
  const result2 = await chain.invoke({ input: "Give me a book like the previous one but shorter" });
  console.log("User: Give me a book like the previous one but shorter");
  console.log("Assistant:", result2.text); // result2.text contains the LLM response

  // --- Persistence Demonstration ---
  // 1. Save state
  const memoryState = await memory.loadMemoryVariables({});
  await fs.writeFile("memory_state.json", JSON.stringify(memoryState));
  console.log("\nMemory state saved to memory_state.json");

  // 2. Load state (Simulating a new session)
  const loadedState = await fs.readFile("memory_state.json", "utf-8");
  console.log("Loaded Memory State:", JSON.parse(loadedState));
}

// To run: uncomment below (requires valid OpenAI API key)
// runConversationFlow().catch(console.error);
