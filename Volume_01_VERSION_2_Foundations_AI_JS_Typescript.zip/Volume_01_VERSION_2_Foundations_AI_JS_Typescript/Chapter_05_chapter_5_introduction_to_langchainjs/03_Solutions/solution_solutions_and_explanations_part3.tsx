/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

// BookRecommender.tsx
'use client';

import { useState } from 'react';
import { BookRecommendation } from './types';

// NOTE: In a real Next.js app, we would call an API Route (e.g., /api/recommend) 
// to execute the LangChain code securely. We cannot run LangChain directly 
// in the browser without a server-side proxy or specific client-side compatible libraries.
// For this exercise, we simulate the API call delay and success.

export default function BookRecommender() {
  const [input, setInput] = useState('');
  const [result, setResult] = useState<BookRecommendation | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleRecommendation = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim()) return;

    setIsLoading(true);
    setError(null);
    setResult(null);

    try {
      // Simulate an API call to the backend LangChain logic
      // In reality: const res = await fetch('/api/recommend', { method: 'POST', body: JSON.stringify({ genre: input }) });
      // const data = await res.json();
      
      await new Promise(r => setTimeout(r, 1500)); // Fake delay

      // Mocking the response based on input for the UI demo
      const mockResponse: BookRecommendation = input.toLowerCase().includes('fantasy')
        ? { title: 'The Hobbit', author: 'J.R.R. Tolkien', summary: 'A fantasy adventure.' }
        : { title: 'Dune', author: 'Frank Herbert', summary: 'A sci-fi epic.' };

      setResult(mockResponse);
    } catch (err) {
      setError('Failed to generate recommendation. Please try again.');
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="max-w-md mx-auto p-6 bg-white rounded-lg shadow-md">
      <h2 className="text-2xl font-bold mb-4 text-gray-800">Book Recommender</h2>
      
      <form onSubmit={handleRecommendation} className="flex gap-2 mb-6">
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Enter a genre (e.g., fantasy)"
          className="flex-1 p-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
          disabled={isLoading}
        />
        <button
          type="submit"
          disabled={isLoading || !input}
          className={`px-4 py-2 rounded text-white font-semibold transition-colors ${
            isLoading || !input
              ? 'bg-gray-400 cursor-not-allowed'
              : 'bg-blue-600 hover:bg-blue-700'
          }`}
        >
          {isLoading ? 'Loading...' : 'Get Recommendation'}
        </button>
      </form>

      {error && (
        <div className="p-3 bg-red-100 text-red-700 rounded mb-4">
          {error}
        </div>
      )}

      {result && (
        <div className="p-4 bg-gray-50 border border-gray-200 rounded-lg animate-fade-in">
          <h3 className="text-xl font-semibold text-gray-900 mb-2">{result.title}</h3>
          <p className="text-sm text-gray-600 mb-2">by {result.author}</p>
          <p className="text-gray-800">{result.summary}</p>
          
          <div className="mt-4 p-2 bg-gray-200 rounded text-xs font-mono overflow-auto">
            <strong>JSON Output:</strong>
            <pre>{JSON.stringify(result, null, 2)}</pre>
          </div>
        </div>
      )}
    </div>
  );
}
