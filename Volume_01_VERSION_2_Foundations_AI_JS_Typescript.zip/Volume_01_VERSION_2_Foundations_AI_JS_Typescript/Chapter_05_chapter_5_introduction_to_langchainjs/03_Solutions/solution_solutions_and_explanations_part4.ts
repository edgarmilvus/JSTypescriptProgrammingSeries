/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

// visualize.ts
/**
 * Generates a Graphviz DOT diagram string for a given LangChain.js chain.
 * Note: Since inspecting live LangChain objects can be complex and version-dependent,
 * this function accepts a structured description of the chain or the chain object
 * and attempts to map its standard properties.
 */
export function visualizeChain(chain: any): string {
  // We define a standard structure for visualization
  // In a real scenario, we might inspect chain.llm, chain.prompt, etc.
  
  let nodes = [
    'Input [label="Input"]',
    'Prompt [label="PromptTemplate"]',
    'LLM [label="LLM"]',
    'Parser [label="OutputParser"]',
    'Output [label="Output"]'
  ];

  let edges = [
    'Input -> Prompt',
    'Prompt -> LLM',
    'LLM -> Parser',
    'Parser -> Output'
  ];

  // If the chain object is provided, we can try to verify components exist
  // For this exercise, we assume the standard sequential flow.
  // If the chain is complex (e.g., has branches), we would need more logic here.

  const dotString = `
digraph G {
  rankdir=TB;
  node [shape=box, style="rounded,filled", fillcolor="lightblue"];
  ${nodes.join(';\n  ')};
  
  edge [color="black", arrowhead="vee"];
  ${edges.join(';\n  ')}
}
  `;

  return dotString.trim();
}

// usage.ts
import { visualizeChain } from "./visualize";
import { runBookChain } from "./chain"; // From Exercise 1

export function displayChainVisualization() {
  // 1. Create a mock chain object representing Exercise 1
  // In a real app, we might pass the actual chain instance
  const exercise1Chain = {
    prompt: "Book Prompt",
    llm: "Mock LLM",
    outputParser: "Book Parser"
  };

  // 2. Generate the DOT string
  const dot = visualizeChain(exercise1Chain);

  // 3. Wrap in HTML tags as requested
  const htmlOutput = `
<div>
  <h3>Chain Visualization (Graphviz DOT)</h3>
  <pre>${dot}</pre>
  <!-- In a real web app, you would render this using a library like viz.js or react-graphviz -->
</div>
  `;

  console.log(htmlOutput);
  return htmlOutput;
}

// Example Output:
/*
<div>
  <h3>Chain Visualization (Graphviz DOT)</h3>
  <pre>digraph G {
  rankdir=TB;
  node [shape=box, style="rounded,filled", fillcolor="lightblue"];
  Input [label="Input"];
  Prompt [label="PromptTemplate"];
  LLM [label="LLM"];
  Parser [label="OutputParser"];
  Output [label="Output"];
  
  edge [color="black", arrowhead="vee"];
  Input -> Prompt;
  Prompt -> LLM;
  LLM -> Parser;
  Parser -> Output
}</pre>
</div>
*/
