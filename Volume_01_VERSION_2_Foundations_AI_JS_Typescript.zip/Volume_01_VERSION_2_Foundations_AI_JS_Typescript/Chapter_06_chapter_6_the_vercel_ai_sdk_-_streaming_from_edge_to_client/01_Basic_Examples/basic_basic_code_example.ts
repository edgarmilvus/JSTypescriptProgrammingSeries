/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

// File: app/api/stream/route.ts
import { NextRequest } from 'next/server';

/**
 * Handles GET requests to the /api/stream endpoint.
 * This function simulates a streaming response from an LLM.
 * @param {NextRequest} request - The incoming HTTP request object.
 * @returns {Response} A streaming HTTP response.
 */
export async function GET(request: NextRequest) {
  // 1. Define the data to stream.
  const textToStream = "Hello, World! This is a streamed response from the Edge.";

  // 2. Create a ReadableStream.
  // The stream controller allows us to enqueue data chunks.
  const stream = new ReadableStream({
    async start(controller) {
      // 3. Loop through the text and enqueue each character.
      // We use a loop with a delay to simulate network latency or processing time.
      for (const char of textToStream) {
        // Enqueue the character as a Uint8Array (standard for byte streams).
        controller.enqueue(new TextEncoder().encode(char));
        
        // Simulate a 50ms delay between characters.
        await new Promise((resolve) => setTimeout(resolve, 50));
      }

      // 4. Close the stream when done.
      controller.close();
    },
  });

  // 5. Return the stream as the HTTP response.
  return new Response(stream, {
    headers: {
      // Standard streaming header.
      'Content-Type': 'text/plain; charset=utf-8',
      // Enable CORS if needed (common in SaaS apps).
      'Access-Control-Allow-Origin': '*',
    },
  });
}
