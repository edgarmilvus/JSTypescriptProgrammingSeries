/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.tsx
// Description: Basic Code Example
// ==========================================

// File: app/page.tsx
'use client'; // This is a Client Component

import { useState, useEffect } from 'react';

/**
 * A simple page component that fetches and displays a streamed response.
 */
export default function StreamPage() {
  // 1. State to hold the accumulated text from the stream.
  const [streamedText, setStreamedText] = useState<string>('');
  
  // 2. State to track loading status.
  const [isLoading, setIsLoading] = useState<boolean>(false);

  /**
   * Fetches the stream from the Edge function and processes it.
   */
  const fetchStream = async () => {
    setIsLoading(true);
    setStreamedText(''); // Reset text

    try {
      // 3. Make the request to the API route.
      const response = await fetch('/api/stream');

      if (!response.ok) {
        throw new Error('Network response was not ok');
      }

      // 4. Get the ReadableStream from the response body.
      const reader = response.body?.getReader();
      if (!reader) return;

      // 5. Create a TextDecoder to convert Uint8Array chunks to strings.
      const decoder = new TextDecoder();

      // 6. Loop to read the stream chunks.
      while (true) {
        const { done, value } = await reader.read();

        if (done) {
          // Stream finished.
          break;
        }

        // 7. Decode the chunk and append to state.
        const chunkText = decoder.decode(value, { stream: true });
        setStreamedText((prev) => prev + chunkText);
      }
    } catch (error) {
      console.error("Error fetching stream:", error);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div style={{ padding: '20px', fontFamily: 'sans-serif' }}>
      <h1>Vercel AI SDK: Basic Streaming Example</h1>
      
      <button 
        onClick={fetchStream} 
        disabled={isLoading}
        style={{ 
          padding: '10px 20px', 
          fontSize: '16px', 
          cursor: isLoading ? 'not-allowed' : 'pointer' 
        }}
      >
        {isLoading ? 'Streaming...' : 'Start Stream'}
      </button>

      <div style={{ marginTop: '20px', padding: '15px', border: '1px solid #ccc', minHeight: '100px' }}>
        <strong>Response:</strong>
        <br />
        {/* 8. Render the accumulated text */}
        {streamedText}
        {/* 9. Show a blinking cursor while loading */}
        {isLoading && <span style={{ animation: 'blink 1s infinite' }}>|</span>}
      </div>
    </div>
  );
}
