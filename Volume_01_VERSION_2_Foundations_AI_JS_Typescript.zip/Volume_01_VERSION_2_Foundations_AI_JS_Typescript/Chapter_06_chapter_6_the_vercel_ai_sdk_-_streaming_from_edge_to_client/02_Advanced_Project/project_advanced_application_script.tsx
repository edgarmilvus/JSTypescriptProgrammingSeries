/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.tsx
// Description: Advanced Application Script
// ==========================================

'use client';

import { useState } from 'react';
import { useStreamableValue } from 'ai/rsc';
import type { StreamableValue } from 'ai/rsc';

// ==========================================
// 1. SERVER-SIDE LOGIC (Edge Runtime)
// ==========================================

/**
 * @description A Server Action that processes a document and streams back
 * both raw text tokens and interactive React components.
 * 
 * @param {string} document - The text content to analyze.
 * @returns {Promise<StreamableValue>} - A stream of UI updates.
 * 
 * ARCHITECTURAL NOTE:
 * This function is marked with 'use server'. It runs on Vercel Edge,
 * minimizing cold starts. It uses the Vercel AI SDK's `createStreamableUI`
 * and `createStreamableValue` to construct the response incrementally.
 */
async function analyzeDocumentAction(document: string) {
  'use server';
  
  // Import server-only dependencies here to prevent client-side bundle bloat
  const { createStreamableUI, createStreamableValue } = await import('ai/rsc');
  const { OpenAI } = await import('openai');

  // Initialize the stream containers
  const uiStream = createStreamableUI(<div />);
  const textStream = createStreamableValue('');

  const openai = new OpenAI({
    apiKey: process.env.OPENAI_API_KEY!,
  });

  (async () => {
    // 1. Start the analysis with an initial status message
    uiStream.update(
      <div className="p-4 bg-blue-50 text-blue-800 rounded-md mb-4">
        <strong>Analysis Started:</strong> Scanning document structure...
      </div>
    );

    // 2. Call the LLM (simulated or real) to generate insights
    // In a real scenario, we would stream tokens from OpenAI's API directly.
    // Here, we simulate a stream to demonstrate the SDK's capabilities.
    const insights = [
      "The document contains three main sections.",
      "Key entities detected: 'Project Alpha', 'Q4 Deadline'.",
      "Sentiment analysis: Neutral.",
    ];

    // Simulate streaming tokens for the text summary
    let fullSummary = '';
    for (const token of insights) {
      fullSummary += token + ' ';
      textStream.update(fullSummary); // Update the raw text stream
      await new Promise(r => setTimeout(r, 300)); // Simulate network delay
    }

    // 3. Stream a Dynamic UI Component (The "Streamable UI" concept)
    // This is where we inject an interactive React component into the stream.
    // The client receives this JSX as a payload and renders it.
    uiStream.append(
      <div className="mt-4 p-4 border border-green-200 bg-green-50 rounded-lg">
        <h3 className="font-bold text-green-900">✅ Analysis Complete</h3>
        <p className="text-sm text-green-700 mt-1">
          Found 2 critical action items.
        </p>
        {/* Interactive Component: Copy Button */}
        <button 
          onClick={() => navigator.clipboard.writeText(fullSummary)}
          className="mt-2 px-3 py-1 bg-green-600 text-white text-xs rounded hover:bg-green-700 transition"
        >
          Copy Summary
        </button>
      </div>
    );

    // 4. Finalize the streams
    textStream.done();
    uiStream.done();
  })();

  // Return the composite stream object
  return {
    ui: uiStream.value,
    text: textStream.value,
  };
}

// ==========================================
// 2. CLIENT-SIDE COMPONENT
// ==========================================

/**
 * @description A Next.js Client Component that provides the UI for the
 * Document Assistant. It handles user input, triggers the Server Action,
 * and renders the incoming stream of UI and text.
 */
export default function DocumentAssistant() {
  const [document, setDocument] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  
  // `useStreamableValue` is a hook provided by the Vercel AI SDK.
  // It subscribes to the stream and provides the latest value.
  // We use it for both the raw text and the UI updates.
  const [uiState, setUiState] = useState<React.ReactNode | null>(null);
  const [textState, setTextState] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!document.trim()) return;

    setIsLoading(true);
    setTextState('');
    setUiState(null);

    try {
      // Trigger the Server Action
      const result = await analyzeDocumentAction(document);

      // Subscribe to the UI stream
      // Note: The SDK handles the subscription internally, but we need to 
      // update our local state when the stream updates.
      // We simulate the subscription loop here for clarity in this demo context.
      const uiStream = result.ui;
      const textStream = result.text;

      // In a real app with `useSWR` or `useStreamableValue`, this is handled automatically.
      // For this script, we demonstrate the manual consumption of the stream reader.
      const uiReader = uiStream.getReader();
      const textReader = textReaderHelper(textStream); // Helper for text stream

      // Read UI updates
      (async function readUI() {
        while (true) {
          const { done, value } = await uiReader.read();
          if (done) {
            setIsLoading(false);
            break;
          }
          // Type Narrowing: The SDK ensures 'value' is a valid React node
          // or a JSON-serializable object representing a component.
          setUiState(value);
        }
      })();

      // Read text updates
      (async function readText() {
        while (true) {
          const { done, value } = await textReader.read();
          if (done) break;
          setTextState(value);
        }
      })();

    } catch (error) {
      console.error("Stream error:", error);
      setIsLoading(false);
    }
  };

  return (
    <div className="max-w-2xl mx-auto p-6 bg-white shadow-lg rounded-xl">
      <h2 className="text-2xl font-bold mb-4 text-gray-800">
        Smart Document Assistant
      </h2>
      
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Paste Document Text
          </label>
          <textarea
            value={document}
            onChange={(e) => setDocument(e.target.value)}
            className="w-full h-32 p-3 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:outline-none"
            placeholder="Enter text to analyze..."
            disabled={isLoading}
          />
        </div>
        
        <button
          type="submit"
          disabled={isLoading}
          className={`px-4 py-2 rounded-md font-medium text-white transition ${
            isLoading 
              ? 'bg-gray-400 cursor-not-allowed' 
              : 'bg-blue-600 hover:bg-blue-700'
          }`}
        >
          {isLoading ? 'Analyzing...' : 'Analyze Document'}
        </button>
      </form>

      {/* Live Text Stream Display */}
      {textState && (
        <div className="mt-6 p-4 bg-gray-50 rounded-md border border-gray-200">
          <h3 className="font-semibold text-gray-700 mb-2">Live Summary:</h3>
          <p className="text-gray-800 font-mono text-sm whitespace-pre-wrap">
            {textState}
          </p>
        </div>
      )}

      {/* Dynamic UI Stream Display */}
      {uiState && (
        <div className="mt-4">
          {/* 
            Type Narrowing & Rendering:
            The SDK returns a React Node. We simply render it.
            The client hydration process ensures that event listeners 
            (like the onClick on the Copy button) attached in the server 
            action are correctly bound in the browser.
          */}
          {uiState}
        </div>
      )}
    </div>
  );
}

// ==========================================
// 3. HELPER UTILITIES
// ==========================================

/**
 * @description A helper to simulate reading from a StreamableValue text stream.
 * In production, use `useStreamableValue` hook which handles this logic.
 */
async function* textReaderHelper(stream: StreamableValue<string>) {
  // This is a simplified simulation of the SDK's internal stream reading.
  // The actual SDK uses complex async generators to handle patch updates.
  // Here we yield the full string as it updates.
  let current = '';
  
  // Mocking the reader behavior for the purpose of the script demonstration
  // In reality, the SDK handles the diff/patch logic.
  if (typeof stream === 'string') {
    yield stream;
  } else if (typeof stream === 'object' && stream !== null) {
    // If the stream object has a specific structure (like a generator), we'd iterate it.
    // For this demo, we assume the stream updates are pushed to a reader.
    // This is a placeholder for the complex SDK internals.
    yield ''; 
  }
}
