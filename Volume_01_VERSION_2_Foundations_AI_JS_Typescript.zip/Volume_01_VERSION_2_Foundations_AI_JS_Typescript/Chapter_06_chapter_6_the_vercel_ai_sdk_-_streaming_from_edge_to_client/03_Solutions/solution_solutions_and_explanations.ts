/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// File: components/StreamingChat.tsx
// Problem: Implement the client-side logic to consume a stream from '/api/chat'
// and render the partial response in real-time.

import { useState, useEffect } from 'react';

export default function StreamingChat() {
  // State to manage user input, the streamed response, and loading status
  const [userInput, setUserInput] = useState('');
  const [streamedResponse, setStreamedResponse] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  // Function to handle the API call and stream processing
  const handleStream = async () => {
    if (!userInput.trim()) return;

    setIsLoading(true);
    setStreamedResponse(''); // Reset previous response

    try {
      // 1. Call the API endpoint with the user input
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: userInput }),
      });

      if (!response.ok) {
        throw new Error('Network response was not ok');
      }

      // 2. Access the ReadableStream from the response body
      const body = response.body;
      if (!body) return;

      // 3. Get a reader from the stream
      const reader = body.getReader();
      const decoder = new TextDecoder();

      // 4. Read the stream in a loop
      while (true) {
        const { done, value } = await reader.read();

        if (done) {
          // Stream has finished
          break;
        }

        // 5. Decode the binary chunk to text
        const chunk = decoder.decode(value, { stream: true });

        // 6. Append the chunk to the state to update the UI in real-time
        setStreamedResponse((prev) => prev + chunk);
      }
    } catch (error) {
      console.error('Stream error:', error);
      setStreamedResponse('Error generating response.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div style={{ padding: '20px', fontFamily: 'sans-serif' }}>
      <h2>Streaming Chat</h2>
      
      {/* Input field for user message */}
      <div style={{ marginBottom: '10px' }}>
        <input
          type="text"
          value={userInput}
          onChange={(e) => setUserInput(e.target.value)}
          placeholder="Type your message..."
          style={{ width: '300px', padding: '8px', marginRight: '8px' }}
          disabled={isLoading}
        />
        <button onClick={handleStream} disabled={isLoading}>
          {isLoading ? 'Sending...' : 'Send'}
        </button>
      </div>

      {/* Display area for the streamed response */}
      <div style={{ 
        border: '1px solid #ccc', 
        padding: '10px', 
        minHeight: '100px',
        backgroundColor: '#f9f9f9'
      }}>
        <strong>AI Response:</strong>
        <div style={{ marginTop: '5px', whiteSpace: 'pre-wrap' }}>
          {streamedResponse}
        </div>
      </div>
    </div>
  );
}
