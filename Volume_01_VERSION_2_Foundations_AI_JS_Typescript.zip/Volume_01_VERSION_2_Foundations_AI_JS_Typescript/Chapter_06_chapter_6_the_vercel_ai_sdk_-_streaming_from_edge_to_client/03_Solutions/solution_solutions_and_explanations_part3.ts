/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

// File: components/IdeaGenerator.tsx
// Interactive Challenge: Stream a JSON array and parse it incrementally to update the UI.

import { useState, useCallback } from 'react';

export default function IdeaGenerator() {
  const [topic, setTopic] = useState('');
  const [ideas, setIdeas] = useState<{ title: string; outline: string }[]>([]);
  const [isLoading, setIsLoading] = useState(false);

  const generateIdeas = useCallback(async () => {
    if (!topic.trim()) return;

    setIsLoading(true);
    setIdeas([]); // Clear previous ideas

    try {
      const response = await fetch('/api/generate-ideas', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ topic }),
      });

      if (!response.body) return;
      const reader = response.body.getReader();
      const decoder = new TextDecoder();
      
      // Buffer to hold partial JSON data
      let buffer = '';

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        const chunk = decoder.decode(value, { stream: true });
        buffer += chunk;

        // Strategy: Attempt to parse the buffer.
        // Since the stream might contain a JSON array like [{"title":"..."}, {"title":"..."}],
        // we can look for closing braces `}` to identify complete objects.
        // However, a safer way for arrays is to try parsing the whole buffer as a JSON array.
        // If it fails, we wait for more data.
        // Note: This is a simplified approach. For production, a streaming JSON parser is recommended.
        
        try {
          // Attempt to parse the buffer as JSON
          const parsedData = JSON.parse(buffer);
          
          // If parsing succeeds, we assume the data is an array of ideas
          if (Array.isArray(parsedData)) {
            setIdeas(parsedData);
            // We don't clear the buffer here because we want to keep accumulating
            // until the stream ends, or we might want to process line-by-line if the server sends JSON lines.
            // For this exercise, we assume the server sends a complete JSON array at the end, 
            // OR we are using a strategy where we look for complete objects.
            
            // A better strategy for "streaming JSON" is if the server sends JSON Lines (NDJSON).
            // Let's assume the server sends NDJSON: {"title": "...", "outline": "..."}\n
            // We will implement that logic below as it's more robust for streaming structures.
          }
        } catch (e) {
          // JSON is incomplete, wait for more data
          // This is expected behavior while streaming
        }
      }
    } catch (error) {
      console.error("Generation failed:", error);
    } finally {
      setIsLoading(false);
    }
  }, [topic]);

  // NOTE: The logic above assumes the server sends a standard JSON array at the end.
  // If the server sends Newline Delimited JSON (NDJSON), the logic changes slightly:
  // We would split the buffer by '\n' and parse each line individually.
  // Let's adjust `generateIdeas` to handle NDJSON, which is standard for streaming structured data.

  const generateIdeasNDJSON = async () => {
    if (!topic.trim()) return;
    setIsLoading(true);
    setIdeas([]);

    const response = await fetch('/api/generate-ideas', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ topic }),
    });

    const reader = response.body.getReader();
    const decoder = new TextDecoder();
    let buffer = '';

    while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        buffer += decoder.decode(value, { stream: true });

        // Process lines in the buffer
        const lines = buffer.split('\n');
        // Keep the last line in buffer as it might be incomplete
        buffer = lines.pop() || '';

        for (const line of lines) {
            if (line.trim()) {
                try {
                    const idea = JSON.parse(line);
                    setIdeas(prev => [...prev, idea]);
                } catch (e) {
                    console.warn('Failed to parse line:', line);
                }
            }
        }
    }
    setIsLoading(false);
  };

  return (
    <div style={{ padding: '20px' }}>
      <h3>Blog Post Idea Generator</h3>
      <div style={{ marginBottom: '10px' }}>
        <input
          value={topic}
          onChange={(e) => setTopic(e.target.value)}
          placeholder="Enter a topic (e.g., 'Sustainable Tech')"
          style={{ padding: '8px', width: '250px' }}
        />
        <button 
          onClick={generateIdeasNDJSON} 
          disabled={isLoading}
          style={{ marginLeft: '8px', padding: '8px 16px' }}
        >
          {isLoading ? 'Generating...' : 'Generate Ideas'}
        </button>
      </div>
      
      <ul>
        {ideas.map((idea, index) => (
          <li key={index} style={{ marginBottom: '10px', border: '1px solid #eee', padding: '10px' }}>
            <strong>{idea.title || 'Loading title...'}</strong>
            <div>{idea.outline || 'Loading outline...'}</div>
          </li>
        ))}
      </ul>
    </div>
  );
}
