/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.tsx
// Description: Basic Code Example
// ==========================================

// File: components/MinimalistChat.tsx
'use client'; // Required for Next.js App Router

import { useChat } from 'ai/react';
import { z } from 'zod';

/**
 * @description A minimalist chat interface demonstrating the useChat hook.
 * It handles user input, message streaming, and basic error states.
 */
export default function MinimalistChat() {
  // 1. HOOK INITIALIZATION
  // The useChat hook automatically manages:
  // - `messages`: Array of message objects (role, content)
  // - `input`: String value for the controlled input field
  // - `handleInputChange`: Updates the input state
  // - `handleSubmit`: Submits the message to the API
  // - `isLoading`: Boolean indicating if the AI is processing
  // - `error`: Error object if the API call fails
  const { messages, input, handleInputChange, handleSubmit, isLoading, error } = useChat({
    api: '/api/chat', // The backend endpoint handling the AI logic
  });

  // 2. CLIENT-SIDE RESPONSE VALIDATION (Zod)
  // While useChat handles streaming, we can validate specific metadata 
  // if the backend sends structured JSON alongside text. 
  // This is a placeholder for where you would parse complex JSON streams.
  const metadataSchema = z.object({
    model: z.string(),
    finishReason: z.string().optional(),
  });

  return (
    <div className="flex flex-col w-full max-w-md mx-auto p-4 border rounded-lg shadow-sm">
      {/* 3. MESSAGE DISPLAY AREA */}
      <div className="flex flex-col gap-2 mb-4 h-64 overflow-y-auto">
        {messages.length > 0 ? (
          messages.map((message) => (
            <div
              key={message.id}
              className={`p-3 rounded-md text-sm ${
                message.role === 'user'
                  ? 'bg-blue-100 text-blue-900 self-end'
                  : 'bg-gray-100 text-gray-900 self-start'
              }`}
            >
              <strong>{message.role === 'user' ? 'You' : 'AI'}:</strong>
              <span className="ml-2">{message.content}</span>
            </div>
          ))
        ) : (
          <div className="text-center text-gray-500 mt-10">
            No messages yet. Start a conversation!
          </div>
        )}

        {/* 4. LOADING STATE */}
        {isLoading && (
          <div className="text-center text-gray-400 animate-pulse">
            Thinking...
          </div>
        )}

        {/* 5. ERROR STATE */}
        {error && (
          <div className="bg-red-50 text-red-600 p-2 rounded text-xs">
            Error: {error.message}
          </div>
        )}
      </div>

      {/* 6. INPUT FORM */}
      <form onSubmit={handleSubmit} className="flex gap-2">
        <input
          type="text"
          value={input}
          onChange={handleInputChange}
          placeholder="Type a message..."
          className="flex-1 border border-gray-300 rounded px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
          disabled={isLoading} // Prevent input while AI is thinking
        />
        <button
          type="submit"
          disabled={isLoading || !input.trim()}
          className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed"
        >
          Send
        </button>
      </form>
    </div>
  );
}
