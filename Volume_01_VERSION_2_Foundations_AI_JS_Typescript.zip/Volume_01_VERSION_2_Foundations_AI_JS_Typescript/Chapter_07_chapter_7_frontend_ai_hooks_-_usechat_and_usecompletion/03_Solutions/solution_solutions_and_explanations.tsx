/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.tsx
// Description: Solutions and Explanations
// ==========================================

import React from 'react';
import { useChat } from 'ai/react';

export function SupportChat() {
  // 1. Initialize the useChat hook with the specific API endpoint
  //    - api: Points to the backend route handling the chat logic
  //    - onError: Handles network or server errors gracefully
  const { 
    messages, 
    input, 
    handleInputChange, 
    handleSubmit, 
    isLoading, 
    error 
  } = useChat({ 
    api: '/api/chat',
    onError: (err) => {
      console.error('Chat API Error:', err);
    }
  });

  return (
    <div className="flex flex-col w-full max-w-md mx-auto p-4 border rounded-lg shadow-sm">
      {/* 2. Message List Display */}
      <div className="flex flex-col gap-3 mb-4 h-64 overflow-y-auto">
        {messages.length === 0 && (
          <p className="text-gray-500 text-center">Start a conversation...</p>
        )}
        
        {messages.map((message) => (
          <div
            key={message.id}
            className={`p-3 rounded-lg max-w-[80%] ${
              message.role === 'user'
                ? 'self-end bg-blue-100 text-blue-900'
                : 'self-start bg-gray-100 text-gray-900'
            }`}
          >
            <div className="font-semibold text-xs uppercase opacity-70 mb-1">
              {message.role}
            </div>
            <div className="text-sm">{message.content}</div>
          </div>
        ))}

        {/* 3. Loading Indicator */}
        {isLoading && (
          <div className="self-start p-3 bg-gray-100 rounded-lg text-sm text-gray-500 animate-pulse">
            AI is typing...
          </div>
        )}
      </div>

      {/* 4. Error Display */}
      {error && (
        <div className="mb-3 p-2 bg-red-100 text-red-700 text-sm rounded">
          Error: Unable to connect to the support agent.
        </div>
      )}

      {/* 5. Input Form */}
      <form onSubmit={handleSubmit} className="flex gap-2">
        <input
          type="text"
          value={input}
          onChange={handleInputChange}
          disabled={isLoading}
          placeholder="Type your message..."
          className="flex-1 p-2 border rounded focus:outline-none focus:ring-2 focus:ring-blue-500 disabled:opacity-50"
        />
        <button
          type="submit"
          disabled={isLoading || !input.trim()}
          className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed"
        >
          Send
        </button>
      </form>
    </div>
  );
}
