/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState } from 'react';
import { useCompletion } from 'ai/react';

export function TextSummarizer() {
  // 1. Local state for the user's raw input (textarea)
  const [userText, setUserText] = useState('');

  // 2. Initialize useCompletion for single-turn tasks
  const { 
    completion, 
    complete, 
    isLoading, 
    error 
  } = useCompletion({ 
    api: '/api/summarize' 
  });

  // 3. Handler to trigger the completion
  const handleSummarize = async () => {
    if (!userText.trim()) return;
    // Pass the local text as the prompt
    await complete(userText);
  };

  return (
    <div className="max-w-2xl mx-auto p-6 bg-white rounded-lg shadow-md">
      <h2 className="text-xl font-bold mb-4">Text Summarizer</h2>

      {/* Input Area */}
      <div className="mb-4">
        <label className="block text-sm font-medium mb-2">
          Text to Summarize
        </label>
        <textarea
          value={userText}
          onChange={(e) => setUserText(e.target.value)}
          disabled={isLoading}
          rows={6}
          className="w-full p-3 border rounded focus:ring-2 focus:ring-blue-500 disabled:opacity-50"
          placeholder="Paste the text you want to summarize here..."
        />
      </div>

      {/* Action Button */}
      <button
        onClick={handleSummarize}
        disabled={isLoading || !userText.trim()}
        className="px-6 py-2 bg-green-600 text-white rounded hover:bg-green-700 disabled:opacity-50"
      >
        {isLoading ? 'Summarizing...' : 'Summarize'}
      </button>

      {/* Error Display */}
      {error && (
        <div className="mt-4 p-3 bg-red-50 text-red-600 rounded">
          Failed to generate summary.
        </div>
      )}

      {/* Streaming Result Display */}
      {completion && (
        <div className="mt-6 p-4 bg-gray-50 border rounded">
          <h3 className="font-semibold text-gray-700 mb-2">Summary:</h3>
          <div className="text-gray-800 whitespace-pre-wrap">
            {completion}
          </div>
        </div>
      )}
    </div>
  );
}
