/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.tsx
// Description: Solutions and Explanations
// ==========================================

import React from 'react';
import { useChat, type Message } from 'ai/react';

// Define the prop types for the component
interface ChatInputProps {
  onResponseReceived?: (message: Message) => void;
}

export function ChatInput({ onResponseReceived }: ChatInputProps) {
  // 1. Use the hook internally
  const { 
    messages, 
    input, 
    handleInputChange, 
    handleSubmit, 
    isLoading 
  } = useChat({ 
    api: '/api/chat',
    // 2. Hook into the onFinish callback to notify the parent
    onFinish: (message) => {
      if (onResponseReceived) {
        onResponseReceived(message);
      }
    }
  });

  // Get the latest message to display the streaming response
  const latestMessage = messages[messages.length - 1];

  return (
    <div className="w-full max-w-md p-4 border rounded-lg bg-gray-50">
      {/* Streaming Response Display Area */}
      <div className="mb-3 min-h-[60px] p-3 bg-white rounded border">
        {isLoading ? (
          <span className="text-gray-400 animate-pulse">Typing...</span>
        ) : latestMessage && latestMessage.role === 'assistant' ? (
          <div className="text-sm text-gray-800">
            {latestMessage.content}
          </div>
        ) : (
          <span className="text-gray-400 text-sm">Response will appear here...</span>
        )}
      </div>

      {/* Input Form */}
      <form onSubmit={handleSubmit} className="flex gap-2">
        <input
          type="text"
          value={input}
          onChange={handleInputChange}
          disabled={isLoading}
          className="flex-1 p-2 border rounded text-sm"
          placeholder="Ask something..."
        />
        <button
          type="submit"
          disabled={isLoading || !input.trim()}
          className="px-3 py-2 bg-blue-600 text-white text-sm rounded hover:bg-blue-700 disabled:opacity-50"
        >
          Send
        </button>
      </form>
    </div>
  );
}

// --- Example Parent Component Usage ---
/*
import React from 'react';
import { ChatInput } from './ChatInput';
import type { Message } from 'ai/react';

export function ParentDashboard() {
  const handleResponse = (msg: Message) => {
    console.log('Full response received:', msg.content);
    // Save to database, update analytics, etc.
  };

  return (
    <div>
      <h1>Support Portal</h1>
      <ChatInput onResponseReceived={handleResponse} />
    </div>
  );
}
*/
