/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState } from "react";

// --- Types ---
interface ChatMessage {
  role: "user" | "agent" | "tool";
  content: string;
}

interface ToolCallRequest {
  toolName: string;
  args: Record<string, any>;
}

// --- Component ---
const ToolDashboard: React.FC = () => {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [inputValue, setInputValue] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [pendingToolCall, setPendingToolCall] = useState<ToolCallRequest | null>(null);

  // 1. Handle User Sending a Query
  const handleSend = () => {
    if (!inputValue.trim()) return;

    // Add user message
    const userMsg: ChatMessage = { role: "user", content: inputValue };
    setMessages((prev) => [...prev, userMsg]);
    setInputValue("");
    setIsLoading(true);

    // Simulate LLM Thinking & Tool Request (2 seconds delay)
    setTimeout(() => {
      const simulatedToolRequest: ToolCallRequest = {
        toolName: "bookFlight",
        args: { from: "NYC", to: "LAX", date: "2023-12-01" },
      };
      setPendingToolCall(simulatedToolRequest);
      
      // Add agent message suggesting a tool call
      setMessages((prev) => [
        ...prev,
        { role: "agent", content: "I need to book a flight to proceed. Requesting tool execution." }
      ]);
    }, 2000);
  };

  // 2. Handle Confirming the Tool Call
  const handleConfirm = () => {
    if (!pendingToolCall) return;

    const currentCall = pendingToolCall;
    setPendingToolCall(null); // Clear UI immediately
    
    // Simulate Tool Execution (1.5 seconds delay)
    setTimeout(() => {
      const resultContent = `Tool '${currentCall.toolName}' executed successfully. Booking ID: ABC123`;
      
      const toolMsg: ChatMessage = { role: "tool", content: resultContent };
      
      setMessages((prev) => [...prev, toolMsg]);
      setIsLoading(false);
    }, 1500);
  };

  // 3. Handle Canceling the Tool Call
  const handleCancel = () => {
    setPendingToolCall(null);
    setIsLoading(false);
  };

  return (
    <div style={{ padding: "20px", maxWidth: "600px", margin: "0 auto", fontFamily: "sans-serif" }}>
      <h2>Agent Tool Dashboard</h2>
      
      {/* Chat Log Display */}
      <div style={{ border: "1px solid #ccc", height: "300px", overflowY: "auto", padding: "10px", marginBottom: "10px" }}>
        {messages.map((msg, index) => (
          <div key={index} style={{ marginBottom: "8px" }}>
            <strong style={{ color: msg.role === "user" ? "blue" : msg.role === "agent" ? "green" : "purple" }}>
              {msg.role.toUpperCase()}:
            </strong>{" "}
            {msg.content}
          </div>
        ))}
        {isLoading && !pendingToolCall && <div style={{ fontStyle: "italic", color: "#666" }}>Agent is thinking...</div>}
      </div>

      {/* User Input */}
      <div style={{ display: "flex", gap: "10px" }}>
        <input
          type="text"
          value={inputValue}
          onChange={(e) => setInputValue(e.target.value)}
          placeholder="Ask the agent to book a flight..."
          style={{ flex: 1, padding: "8px" }}
          disabled={isLoading}
        />
        <button onClick={handleSend} disabled={isLoading || !inputValue}>
          Send
        </button>
      </div>

      {/* Tool Call Request Card (Conditional Rendering) */}
      {pendingToolCall && (
        <div style={{ marginTop: "20px", border: "2px solid orange", padding: "15px", borderRadius: "8px", background: "#fff8e1" }}>
          <h4>🛠️ Tool Call Request</h4>
          <p><strong>Tool:</strong> {pendingToolCall.toolName}</p>
          <p><strong>Arguments:</strong></p>
          <pre style={{ background: "#eee", padding: "5px", borderRadius: "4px" }}>
            {JSON.stringify(pendingToolCall.args, null, 2)}
          </pre>
          <div style={{ marginTop: "10px", display: "flex", gap: "10px" }}>
            <button onClick={handleConfirm} style={{ background: "green", color: "white", border: "none", padding: "8px 12px" }}>
              Confirm Execution
            </button>
            <button onClick={handleCancel} style={{ background: "red", color: "white", border: "none", padding: "8px 12px" }}>
              Cancel
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default ToolDashboard;
