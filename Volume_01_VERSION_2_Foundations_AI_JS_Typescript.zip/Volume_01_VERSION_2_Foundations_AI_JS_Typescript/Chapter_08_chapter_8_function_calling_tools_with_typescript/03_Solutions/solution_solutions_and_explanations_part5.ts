/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

import { z } from "zod";

// --- Schemas ---
const StockSymbolSchema = z.object({
  symbol: z.string().min(1).toUpperCase(),
});

// --- Handlers ---

// Primary Tool: 50% chance of failure
async function fetchStockPriceHandler(args: unknown): Promise<string> {
  const { symbol } = await StockSymbolSchema.parseAsync(args);
  
  // Simulate API delay
  await new Promise(resolve => setTimeout(resolve, 500));
  
  // Random failure simulation
  if (Math.random() > 0.5) {
    throw new Error("Primary API Connection Timeout");
  }
  
  const price = (Math.random() * 100 + 50).toFixed(2);
  return `$${price}`;
}

// Fallback Tool: 100% success rate
async function fetchCachedStockPriceHandler(args: unknown): Promise<string> {
  const { symbol } = await StockSymbolSchema.parseAsync(args);
  
  // Simulate Cache speed (fast)
  await new Promise(resolve => setTimeout(resolve, 100));
  
  // Always succeeds
  const cachedPrice = (Math.random() * 100 + 40).toFixed(2); // Slightly older data
  return `$${cachedPrice} (Cached)`;
}

// --- Orchestrator with Fallback ---

export async function getStockInfo(symbolInput: string): Promise<string> {
  const args = { symbol: symbolInput };

  try {
    // 1. Attempt Primary Tool
    try {
      console.log("Attempting primary API fetch...");
      const price = await fetchStockPriceHandler(args);
      return `Live Price: ${price}`;
    } catch (primaryError) {
      // 2. Primary Failed: Log and attempt Fallback
      console.warn(`Primary failed: ${primaryError}. Switching to fallback...`);
      
      try {
        const cachedPrice = await fetchCachedStockPriceHandler(args);
        return `Data from cache: ${cachedPrice}`;
      } catch (fallbackError) {
        // 3. Fallback Failed: Throw final error
        throw new Error(`Both live and cached data failed. Fallback error: ${fallbackError}`);
      }
    }
  } catch (finalError) {
    // Catch block for the entire operation
    return `Critical Error: ${finalError instanceof Error ? finalError.message : "Unknown error"}`;
  }
}
