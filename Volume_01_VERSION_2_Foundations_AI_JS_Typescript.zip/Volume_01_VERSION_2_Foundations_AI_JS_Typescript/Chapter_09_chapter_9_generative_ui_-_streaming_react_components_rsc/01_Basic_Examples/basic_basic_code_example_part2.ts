/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.ts
// Description: Basic Code Example
// ==========================================

// File: app/api/generate-component/route.ts
import { NextResponse } from 'next/server';
import { ChatOpenAI } from '@langchain/openai';
import { PromptTemplate } from '@langchain/core/prompts';
import { StringOutputParser } from '@langchain/core/output_parsers';

/**
 * @description Server Action / API Route to handle the stream.
 * Note: In Next.js App Router, this is a Route Handler.
 */
export async function POST() {
  // 1. Initialize the Model (Streaming enabled)
  const model = new ChatOpenAI({
    model: 'gpt-3.5-turbo',
    temperature: 0,
    streaming: true, // CRITICAL: Enables the stream
  });

  // 2. Define a prompt that forces JSON output representing a React component
  const prompt = PromptTemplate.fromTemplate(
    `You are a UI generator. Respond ONLY with a JSON object representing a React component.
     Do not include markdown code blocks or explanations.
     Structure: { "type": "div", "props": { "className": "...", "children": [ ... ] } }
     
     Generate a simple "Welcome Card" component with a heading, a paragraph, and a button.
     Component:`
  );

  // 3. Chain the prompt, model, and parser
  const chain = prompt.pipe(model).pipe(new StringOutputParser());

  // 4. Create a TransformStream to pipe the response
  const { readable, writable } = new TransformStream();

  // 5. Start the generation in a non-blocking way
  (async () => {
    const writer = writable.getWriter();
    const encoder = new TextEncoder();

    try {
      // LangChain's streaming callback
      let accumulatedContent = '';
      
      // We use the stream method directly to intercept chunks
      await chain.stream({}, {
        callbacks: [
          {
            handleLLMNewToken(token: string) {
              accumulatedContent += token;
              // In a real app, we might parse partial JSON here.
              // For simplicity, we wait for the full response in this demo,
              // but typically we stream partial chunks as they arrive.
            },
            async handleLLMEnd() {
              // When the stream finishes, send the complete JSON
              // In a production app, you would stream partial UI updates (e.g., first the div, then the children)
              
              // Sanitize the response (remove markdown artifacts if any)
              let cleanJson = accumulatedContent.trim();
              if (cleanJson.startsWith('