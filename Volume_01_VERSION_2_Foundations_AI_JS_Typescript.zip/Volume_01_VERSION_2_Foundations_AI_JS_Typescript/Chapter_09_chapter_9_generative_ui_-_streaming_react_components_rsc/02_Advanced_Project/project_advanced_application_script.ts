/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// File: app/actions/generate-report.tsx
'use server';

import { streamObject } from 'ai';
import { openai } from '@ai-sdk/openai';
import { z } from 'zod';
import { ReactElement } from 'react';
import { ReportCard } from '@/components/ui/report-card';
import { DataTable } from '@/components/ui/data-table';

/**
 * SCHEMA DEFINITION
 * Defines the structure of the UI components the AI is allowed to generate.
 * We use Zod to strictly enforce the output format from the LLM.
 */
const ComponentSchema = z.discriminatedUnion('type', [
  z.object({
    type: z.literal('summary_card'),
    title: z.string(),
    value: z.string(),
    trend: z.enum(['up', 'down', 'neutral']),
  }),
  z.object({
    type: z.literal('data_table'),
    headers: z.array(z.string()),
    rows: z.array(z.array(z.string())),
  }),
]);

// The schema for the stream object (an array of components)
const ReportSchema = z.object({
  components: z.array(ComponentSchema),
});

/**
 * SERVER ACTION: generateStreamableReport
 * 
 * This function acts as the Generative UI engine. It:
 * 1. Receives a user prompt.
 * 2. Streams a structured object from the AI (adhering to Zod schema).
 * 3. Maps the raw JSON tokens to React Server Components.
 * 4. Streams the React components back to the client.
 * 
 * @param prompt - The user's request for the report.
 * @returns A stream of React elements.
 */
export async function generateStreamableReport(prompt: string) {
  // 1. Initialize the AI stream with the Zod schema
  const { elementStream } = await streamObject({
    model: openai('gpt-4-turbo-preview'),
    schema: ReportSchema,
    prompt: `Generate a dashboard report based on: ${prompt}. 
             Output strictly JSON objects matching the schema.`,
    // 2. The 'onToken' callback allows us to process chunks as they arrive
    onToken: async (token) => {
      // In a real RSC stream, we would yield here. 
      // However, the Vercel AI SDK 'streamObject' returns a stream of partial objects.
      // We will map these partial objects to components in the iterator below.
    },
  });

  // 3. Create a custom async iterator to transform JSON -> React Components
  // This is the "Generative UI" bridge.
  const componentStream = new ReadableStream<ReactElement>({
    async start(controller) {
      for await (const partialObject of elementStream) {
        // The AI generates a stream of partial objects. 
        // We only render when we have a complete component definition.
        const components = partialObject.components;
        if (!components || components.length === 0) continue;

        // Get the last fully parsed component
        const lastComponent = components[components.length - 1];

        try {
          // Validate the structure using Zod
          const validatedComponent = ComponentSchema.parse(lastComponent);

          let reactNode: ReactElement;

          // DYNAMIC COMPONENT MAPPING
          // This is where we map AI data to actual React components.
          switch (validatedComponent.type) {
            case 'summary_card':
              reactNode = (
                <ReportCard 
                  title={validatedComponent.title} 
                  value={validatedComponent.value} 
                  trend={validatedComponent.trend} 
                />
              );
              break;
            case 'data_table':
              reactNode = (
                <DataTable 
                  headers={validatedComponent.headers} 
                  rows={validatedComponent.rows} 
                />
              );
              break;
            default:
              // Skip unknown types
              continue;
          }

          // Enqueue the React component to the stream
          controller.enqueue(reactNode);
        } catch (error) {
          // Zod validation failed for this chunk; skip or handle error
          console.error('Validation failed for token:', error);
        }
      }
      controller.close();
    },
  });

  return componentStream;
}
