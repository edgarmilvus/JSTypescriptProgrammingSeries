/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script_part2.ts
// Description: Advanced Application Script
// ==========================================

// File: app/components/report-viewer.tsx
'use client';

import { useState, useEffect, useRef } from 'react';
import { generateStreamableReport } from '@/app/actions/generate-report';

/**
 * CLIENT COMPONENT: ReportViewer
 * 
 * Handles the consumption of the stream. It uses a generic 'ReadableStream'
 * reader to fetch chunks. In a real RSC implementation, this would be handled
 * by the framework's streaming hydration, but for this custom stream, we manually
 * handle the reading and rendering.
 */
export function ReportViewer() {
  const [components, setComponents] = useState<React.ReactNode[]>([]);
  const [isGenerating, setIsGenerating] = useState(false);
  const streamRef = useRef<ReadableStream | null>(null);

  const handleGenerate = async () => {
    setComponents([]);
    setIsGenerating(true);

    // 1. Call the Server Action
    const stream = await generateStreamableReport(
      "Show me a summary of Q3 revenue and a table of top 5 customers."
    );
    
    streamRef.current = stream;
    const reader = stream.getReader();

    try {
      while (true) {
        // 2. Read the stream chunk by chunk
        const { done, value } = await reader.read();
        
        if (done) {
          setIsGenerating(false);
          break;
        }

        // 3. Append the received React Component to the state
        // Note: In a pure RSC setup, 'value' is already a React Node.
        // Here we assume the stream transports serialized UI or we rely on 
        // the fact that 'value' is passed from the server action (React Element).
        setComponents((prev) => [...prev, value]);
      }
    } catch (error) {
      console.error("Stream reading error:", error);
      setIsGenerating(false);
    }
  };

  return (
    <div className="p-8 space-y-6 max-w-4xl mx-auto">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold">Generative UI Dashboard</h1>
        <button 
          onClick={handleGenerate}
          disabled={isGenerating}
          className="px-4 py-2 bg-blue-600 text-white rounded disabled:opacity-50"
        >
          {isGenerating ? 'Generating...' : 'Generate Report'}
        </button>
      </div>

      {/* 
        DYNAMIC RENDERING AREA
        The 'components' array contains actual React elements streamed from the server.
        They are rendered as soon as they arrive.
      */}
      <div className="grid gap-4">
        {components.length > 0 ? components : (
          <div className="text-gray-500 text-center py-10">
            Click generate to see streaming UI components.
          </div>
        )}
      </div>
    </div>
  );
}
