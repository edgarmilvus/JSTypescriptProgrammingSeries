/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

'use server';

import { ChatOpenAI } from '@langchain/openai';
import { PromptTemplate } from '@langchain/core/prompts';
import { StructuredOutputParser } from '@langchain/core/output_parsers';
import { z } from 'zod';
import { ReactNode } from 'react';

// 1. Define the Zod Schema
const ProductSchema = z.object({
  id: z.string(),
  name: z.string(),
  price: z.number(),
  image: z.string().url(),
});

const parser = StructuredOutputParser.fromZodSchema(
  z.array(ProductSchema)
);

const formatInstructions = parser.getFormatInstructions();

const prompt = new PromptTemplate({
  template:
    "Generate a list of 3 products based on the user query. {format_instructions}\nQuery: {query}",
  inputVariables: ["query"],
  partialVariables: { format_instructions: formatInstructions },
});

// 2. The Server Action returning a Stream
export async function getProductRecommendations(query: string) {
  const model = new ChatOpenAI({
    model: "gpt-3.5-turbo",
    temperature: 0.7,
  }).bind({ stream_usage: true }); // Enable streaming usage

  // We create a ReadableStream to handle the parsing and serialization
  const stream = new ReadableStream({
    async start(controller) {
      // We use a custom wrapper to intercept the stream chunks
      const stream = await model.stream(await prompt.format({ query }));

      let buffer = ''; // Buffer to accumulate chunks for parsing
      let isOpenBracket = false;

      for await (const chunk of stream) {
        const content = chunk.content as string;
        
        // Note: In a real production scenario, parsing LLM JSON stream is complex.
        // We are simulating the behavior where the LLM outputs structured JSON.
        // Often, you'd use an output parser that handles streaming, 
        // but for this exercise, we simulate chunk accumulation.
        
        buffer += content;

        // Simple heuristic: Check if we have a complete JSON object
        // (In reality, use a streaming JSON parser library)
        if (buffer.trim().startsWith('[') && buffer.trim().endsWith(']')) {
           try {
             const products = JSON.parse(buffer);
             
             // Stream each product individually
             for (const product of products) {
               const validated = ProductSchema.parse(product);
               
               // We serialize the component data, not the component itself
               // The client will render the component
               controller.enqueue(JSON.stringify(validated) + '\n');
             }
             
             buffer = ''; // Reset buffer
           } catch (e) {
             // Incomplete JSON, continue buffering
             continue;
           }
        }
      }
      
      controller.close();
    },
  });

  return stream;
}
