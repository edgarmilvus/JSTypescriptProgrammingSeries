/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

// Server Component (runs on Edge)
import { z } from 'zod';
import dynamic from 'next/dynamic';
import { Suspense } from 'react';

// 1. Define Schema
const ChartConfigSchema = z.object({
  type: z.enum(['bar', 'line', 'pie']),
  data: z.array(z.object({ name: z.string(), value: z.number() })),
});

// 2. Dynamically import the Client Component (Chart)
// We use dynamic import to ensure this Server Component doesn't try to render the chart logic
const ClientChart = dynamic(() => import('./ClientChart'), {
  ssr: false,
  loading: () => <div className="h-64 bg-gray-100 animate-pulse rounded" />,
});

// Fallback for invalid types
const ErrorComponent = () => (
  <div className="p-4 bg-red-100 text-red-700 rounded">
    Error: Invalid chart type requested by AI.
  </div>
);

export async function ChartWrapper({ prompt }: { prompt: string }) {
  // 3. Simulate AI Generation and Validation
  // In a real app, this would be the LLM call.
  // Here we simulate the output based on the prompt content.
  let aiOutput: any;
  
  if (prompt.includes('bar')) {
    aiOutput = { type: 'bar', data: [{ name: 'Jan', value: 5000 }, { name: 'Feb', value: 7000 }] };
  } else if (prompt.includes('line')) {
    aiOutput = { type: 'line', data: [{ name: 'Q1', value: 16500 }] };
  } else {
    // Simulating an invalid output (e.g., "3D Surface Plot")
    aiOutput = { type: '3d_surface', data: [] };
  }

  // 4. Validate against Zod
  const result = ChartConfigSchema.safeParse(aiOutput);

  if (!result.success) {
    return <ErrorComponent />;
  }

  const { type, data } = result.data;

  // 5. Stream the Client Component with props
  return (
    <div className="dashboard-panel border p-4 rounded-lg">
      <h3 className="font-bold mb-2">Generated Visualization: {type.toUpperCase()}</h3>
      <ClientChart type={type} data={data} />
    </div>
  );
}
