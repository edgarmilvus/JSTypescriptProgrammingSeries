/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part9.ts
// Description: Solutions and Explanations
// ==========================================

'use client';

import { useStream } from '@/hooks/useStream';

export function GenerativeUIState() {
  // Mock URL for demonstration
  const { state, reconnect } = useStream('/api/state-machine-stream');

  return (
    <div className="p-6 border rounded-lg bg-white shadow-sm">
      <div className="flex justify-between items-center mb-4">
        <h3 className="font-bold text-lg">Generative UI Stream</h3>
        <span className={`text-xs px-2 py-1 rounded ${
          state.status === 'streaming' ? 'bg-blue-100 text-blue-800' :
          state.status === 'error' ? 'bg-red-100 text-red-800' :
          'bg-gray-100 text-gray-800'
        }`}>
          Status: {state.status.toUpperCase()}
        </span>
      </div>

      <div className="space-y-2 min-h-[200px] border p-4 rounded bg-gray-50">
        {state.content.map((item, idx) => (
          <div key={idx} className="animate-fade-in">
            {typeof item === 'string' ? (
              <p className="text-gray-700 font-mono bg-white p-2 border">{item}</p>
            ) : item}
          </div>
        ))}

        {state.status === 'error' && (
          <div className="bg-red-50 border border-red-200 p-4 rounded flex justify-between items-center">
            <span className="text-red-700">Network Connection Lost</span>
            <button 
              onClick={reconnect}
              className="bg-red-600 text-white px-3 py-1 rounded text-sm hover:bg-red-700"
            >
              Reconnect
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
