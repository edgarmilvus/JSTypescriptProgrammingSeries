/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.tsx
// Description: Advanced Application Script
// ==========================================

// File: app/components/ImageAnalyzer.tsx
"use client";

import React, { useState, ChangeEvent, FormEvent } from 'react';

/**
 * @description Client Component for handling image uploads and displaying analysis results.
 * Uses browser APIs for file reading and fetch for API communication.
 */
export default function ImageAnalyzer() {
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [analysisResult, setAnalysisResult] = useState<any>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  // 1. Handle File Selection
  const handleFileChange = (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setImageFile(file);
    // Create a local preview URL (browser only)
    setPreviewUrl(URL.createObjectURL(file));
    setError(null);
    setAnalysisResult(null);
  };

  // 2. Form Submission & API Call
  const handleSubmit = async (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!imageFile) return;

    setIsLoading(true);
    setError(null);

    try {
      // Convert image to Base64 for transmission
      const reader = new FileReader();
      reader.readAsDataURL(imageFile);
      
      reader.onload = async () => {
        const base64Image = reader.result as string;

        // Call our API Route
        const response = await fetch('/api/analyze-defect', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ image: base64Image, prompt: "Inspect for manufacturing defects." }),
        });

        if (!response.ok) throw new Error('Analysis failed');

        const data = await response.json();
        setAnalysisResult(data);
        setIsLoading(false);
      };

      reader.onerror = () => {
        throw new Error('Error reading file');
      };

    } catch (err: any) {
      setError(err.message);
      setIsLoading(false);
    }
  };

  return (
    <div className="max-w-2xl mx-auto p-6 bg-white shadow-lg rounded-lg">
      <h2 className="text-2xl font-bold mb-4 text-gray-800">Visual Defect Detector</h2>
      
      <form onSubmit={handleSubmit} className="mb-6 space-y-4">
        <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center hover:border-blue-500 transition-colors">
          <input 
            type="file" 
            accept="image/*" 
            onChange={handleFileChange} 
            className="block w-full text-sm text-slate-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100"
          />
        </div>

        {previewUrl && (
          <div className="relative">
            <img src={previewUrl} alt="Preview" className="max-h-64 mx-auto rounded-md border" />
          </div>
        )}

        <button 
          type="submit" 
          disabled={!imageFile || isLoading}
          className={`w-full py-2 px-4 rounded-md font-semibold text-white transition-colors ${
            isLoading ? 'bg-gray-400 cursor-not-allowed' : 'bg-blue-600 hover:bg-blue-700'
          }`}
        >
          {isLoading ? 'Analyzing...' : 'Analyze Image'}
        </button>
      </form>

      {error && <div className="p-3 bg-red-100 text-red-700 rounded-md mb-4">{error}</div>}

      {/* 3. Displaying the Structured Result */}
      {analysisResult && (
        <div className="bg-gray-50 p-4 rounded-md border">
          <h3 className="font-bold text-lg mb-2">Analysis Report</h3>
          
          <div className="mb-3">
            <span className="font-semibold">Status:</span>
            <span className={`ml-2 px-2 py-1 rounded text-white text-sm ${
              analysisResult.status === 'CRITICAL' ? 'bg-red-600' : 'bg-green-600'
            }`}>
              {analysisResult.status}
            </span>
          </div>

          <div className="mb-3">
            <span className="font-semibold">Severity Score:</span>
            <span className="ml-2 text-gray-700">{analysisResult.severityScore}/10</span>
          </div>

          <div className="mb-3">
            <span className="font-semibold">Observations:</span>
            <p className="mt-1 text-gray-700 whitespace-pre-wrap">{analysisResult.details}</p>
          </div>

          {analysisResult.recommendation && (
            <div className="p-3 bg-yellow-100 border-l-4 border-yellow-500 text-yellow-800">
              <span className="font-bold">Action Required:</span> {analysisResult.recommendation}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
