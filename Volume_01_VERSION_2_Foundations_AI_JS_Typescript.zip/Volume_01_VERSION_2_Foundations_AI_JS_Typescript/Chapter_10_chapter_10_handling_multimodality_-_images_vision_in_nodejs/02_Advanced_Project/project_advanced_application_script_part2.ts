/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script_part2.ts
// Description: Advanced Application Script
// ==========================================

// File: app/api/analyze-defect/route.ts
import { NextResponse } from 'next/server';
import { OpenAI } from 'openai';
import { StateGraph, END, Annotation } from '@langchain/langgraph';
import { z } from 'zod';

// Initialize OpenAI Client
const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

/**
 * @description Zod schema for validating the structured output from OpenAI.
 * This ensures the AI returns consistent data regardless of its natural language generation.
 */
const AnalysisSchema = z.object({
  severityScore: z.number().min(0).max(10).describe("Score 0-10, where 10 is critical failure."),
  defectsFound: z.array(z.string()).describe("List of specific defects identified."),
  summary: z.string().describe("Brief summary of the visual inspection."),
});

type AnalysisResult = z.infer<typeof AnalysisSchema>;

/**
 * @description LangGraph State Definition.
 * Defines the data structure passed between nodes in our workflow.
 */
const GraphState = Annotation.Root({
  imageBase64: Annotation<string>,
  prompt: Annotation<string>,
  analysis: Annotation<AnalysisResult | null>({ default: null }),
  status: Annotation<string>({ default: 'PENDING' }), // 'PENDING', 'STANDARD', 'CRITICAL'
});

/**
 * @description Node 1: Image Analysis
 * Calls OpenAI Vision API to analyze the image and extract structured data.
 */
async function analyzeImage(state: typeof GraphState.State) {
  const { imageBase64, prompt } = state;

  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4o-mini", // Or gpt-4-vision-preview
      messages: [
        {
          role: "user",
          content: [
            { type: "text", text: `Analyze the following image for defects. Return a JSON object matching this schema: ${JSON.stringify(AnalysisSchema.shape)}. Focus strictly on visual anomalies.` },
            {
              type: "image_url",
              image_url: { url: imageBase64, detail: "high" },
            },
          ],
        },
      ],
      // Note: For strict JSON parsing, we might use response_format: { type: "json_object" } 
      // but Vision API often requires prompting for JSON.
      max_tokens: 300,
    });

    const content = response.choices[0].message.content;
    
    // Parse the string response into our Zod schema
    // In production, use a library like 'zod-ai' or 'llm-response-parser' for robustness
    const parsedContent = JSON.parse(content || '{}');
    const validatedAnalysis = AnalysisSchema.parse(parsedContent);

    return {
      analysis: validatedAnalysis,
    };
  } catch (error) {
    console.error("OpenAI Error:", error);
    throw new Error("Failed to analyze image via OpenAI.");
  }
}

/**
 * @description Node 2: Conditional Logic Handler (Decision)
 * Inspects the severity score and updates the workflow status.
 */
function determineSeverity(state: typeof GraphState.State) {
  if (!state.analysis) return { status: 'ERROR' };

  // Threshold logic: Severity > 7 is considered Critical
  if (state.analysis.severityScore > 7) {
    return { status: 'CRITICAL' };
  }
  return { status: 'STANDARD' };
}

/**
 * @description Node 3: Generate Standard Report
 * Formats a standard success message.
 */
function generateStandardReport(state: typeof GraphState.State) {
  if (!state.analysis) return {};
  
  return {
    status: 'STANDARD',
    details: `Inspection complete. Found ${state.analysis.defectsFound.length} minor issues. Summary: ${state.analysis.summary}`,
    recommendation: 'No immediate action required. Continue monitoring.',
  };
}

/**
 * @description Node 4: Generate Critical Alert
 * Formats a high-priority alert message.
 */
function generateCriticalReport(state: typeof GraphState.State) {
  if (!state.analysis) return {};

  const defectList = state.analysis.defectsFound.join(', ');
  return {
    status: 'CRITICAL',
    details: `URGENT: Severity score ${state.analysis.severityScore}. Defects identified: ${defectList}.`,
    recommendation: 'STOP PRODUCTION LINE. Immediate engineering review required.',
  };
}

/**
 * @description Construct the LangGraph Workflow
 */
function createWorkflow() {
  const workflow = new StateGraph(GraphState)
    // 1. Analyze the image
    .addNode("analyze_image", analyzeImage)
    // 2. Determine severity (Conditional logic preparation)
    .addNode("determine_severity", determineSeverity)
    // 3. Report nodes
    .addNode("report_standard", generateStandardReport)
    .addNode("report_critical", generateCriticalReport);

  // Set Entry Point
  workflow.setEntryPoint("analyze_image");

  // Define Edges
  // analyze_image -> determine_severity
  workflow.addEdge("analyze_image", "determine_severity");

  // determine_severity -> (Conditional Edge)
  // We use a conditional edge function to check the state status
  workflow.addConditionalEdges(
    "determine_severity",
    (state: typeof GraphState.State) => {
      if (state.status === 'CRITICAL') return "report_critical";
      if (state.status === 'STANDARD') return "report_standard";
      return END;
    }
  );

  // report_standard -> END
  workflow.addEdge("report_standard", END);
  // report_critical -> END
  workflow.addEdge("report_critical", END);

  return workflow.compile();
}

/**
 * @description API Route Handler (Next.js App Router)
 * Receives the image, executes the LangGraph workflow, and returns the result.
 */
export async function POST(request: Request) {
  try {
    const { image, prompt } = await request.json();

    if (!image) {
      return NextResponse.json({ error: "No image provided" }, { status: 400 });
    }

    // Initialize Graph
    const app = createWorkflow();

    // Execute Graph
    const inputs = {
      imageBase64: image,
      prompt: prompt || "Analyze this image.",
    };

    // Run the graph asynchronously
    const finalState = await app.invoke(inputs);

    // Extract the final result from the graph state
    // The graph returns the accumulated state. We pick the relevant fields.
    const result = {
      status: finalState.status,
      severityScore: finalState.analysis?.severityScore || 0,
      details: finalState.details || finalState.analysis?.summary || "No details generated.",
      recommendation: finalState.recommendation,
    };

    return NextResponse.json(result);

  } catch (error) {
    console.error("API Error:", error);
    return NextResponse.json(
      { error: "Internal Server Error", details: (error as Error).message },
      { status: 500 }
    );
  }
}
