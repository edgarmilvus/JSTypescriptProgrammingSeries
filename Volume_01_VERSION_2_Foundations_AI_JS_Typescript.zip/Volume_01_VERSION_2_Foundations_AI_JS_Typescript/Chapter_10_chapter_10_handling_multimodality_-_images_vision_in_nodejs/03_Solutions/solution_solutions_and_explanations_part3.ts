/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

import { StateGraph, END, Command, START } from '@langchain/langgraph';
import OpenAI from 'openai';

const openai = new OpenAI();

// 1. Define State Interface
interface VisionState {
  imageBase64: string;
  descriptions: string[];
}

// 2. Node: Generate Description
async function generateDescription(state: VisionState): Promise<Partial<VisionState>> {
  const { imageBase64, descriptions } = state;
  
  // Determine prompt based on iteration
  let prompt = "Create a vivid, imaginative description suitable for a children's book.";
  if (descriptions.length > 0) {
    const previous = descriptions[descriptions.length - 1];
    prompt = `The previous description was: "${previous}". Please refine it to be more detailed, colorful, and engaging for a child.`;
  }

  const response = await openai.chat.completions.create({
    model: 'gpt-4-vision-preview',
    messages: [
      {
        role: 'user',
        content: [
          { type: 'image_url', image_url: { url: `data:image/jpeg;base64,${imageBase64}`, detail: 'high' } },
          { type: 'text', text: prompt }
        ],
      }
    ],
    max_tokens: 200,
  });

  const newDescription = response.choices[0].message.content || "No description generated.";
  
  // Return updated state (appends to the descriptions array)
  return {
    descriptions: [...descriptions, newDescription]
  };
}

// 3. Node: Check Iteration Count
function checkIteration(state: VisionState): Command {
  if (state.descriptions.length < 3) {
    // Route back to generateDescription node
    return new Command({ goto: 'generateDescription' });
  }
  // Route to END
  return new Command({ goto: END });
}

// 4. Construct the Graph
const workflow = new StateGraph<VisionState>({
  channels: {
    imageBase64: {
      value: (x: string, y?: string) => y ?? x, // Reducer logic
      default: () => '',
    },
    descriptions: {
      value: (x: string[], y?: string[]) => (y ? [...x, ...y] : x), // Append logic
      default: () => [],
    },
  },
});

// Add nodes
workflow.addNode('generateDescription', generateDescription);
workflow.addNode('checkIteration', checkIteration);

// Define edges
workflow.addEdge(START, 'generateDescription');
workflow.addEdge('generateDescription', 'checkIteration');

// Compile the graph
export const visionChain = workflow.compile();

// --- Usage Example ---
/*
const imageBase64 = "..."; // Base64 string
const result = await visionChain.invoke({ imageBase64, descriptions: [] });
console.log(result.descriptions); // Array of 3 refined descriptions
*/
