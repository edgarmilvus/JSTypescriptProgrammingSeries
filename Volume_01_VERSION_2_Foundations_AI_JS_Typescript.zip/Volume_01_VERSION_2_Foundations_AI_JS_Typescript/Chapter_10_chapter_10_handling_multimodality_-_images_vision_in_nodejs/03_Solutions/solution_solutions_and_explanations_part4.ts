/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

import OpenAI from 'openai';
import { Pinecone } from '@pinecone-database/pinecone';

const openai = new OpenAI();

/**
 * Indexes a product image by generating a description, embedding it, and storing it in Pinecone.
 * @param productId - Unique ID for the product
 * @param base64Image - Base64 encoded image string
 * @param pc - Initialized Pinecone client instance
 */
export async function indexProductImage(
  productId: string,
  base64Image: string,
  pc: Pinecone
) {
  const indexName = 'product-search-index';
  const index = pc.index(indexName);

  console.log(`Starting indexing process for Product ID: ${productId}`);

  try {
    // ---------------------------------------------------------
    // Step 1: Vision - Generate detailed text description
    // ---------------------------------------------------------
    console.log("Step 1: Generating visual description...");
    
    const visionResponse = await openai.chat.completions.create({
      model: 'gpt-4-vision-preview',
      messages: [
        {
          role: 'user',
          content: [
            {
              type: 'image_url',
              image_url: { url: `data:image/jpeg;base64,${base64Image}`, detail: 'high' }
            },
            {
              type: 'text',
              text: 'Describe this product in detail for an e-commerce search engine. Focus on color, material, style, and unique features.'
            }
          ],
        }
      ],
      max_tokens: 150,
    });

    const description = visionResponse.choices[0].message.content;
    if (!description) throw new Error('Vision API returned no description.');
    
    console.log("Description generated:", description.substring(0, 50) + "...");

    // ---------------------------------------------------------
    // Step 2: Embedding - Convert text to vector
    // ---------------------------------------------------------
    console.log("Step 2: Creating vector embedding...");
    
    const embeddingResponse = await openai.embeddings.create({
      model: 'text-embedding-ada-002',
      input: description,
    });

    const vector = embeddingResponse.data[0].embedding;
    console.log(`Vector created with dimension: ${vector.length}`);

    // ---------------------------------------------------------
    // Step 3: Upsert - Store in Pinecone
    // ---------------------------------------------------------
    console.log("Step 3: Upserting to Pinecone...");

    await index.upsert([
      {
        id: productId,
        values: vector,
        metadata: {
          description: description,
          productId: productId,
        }
      }
    ]);

    console.log(`Successfully indexed product ${productId}.`);
    return { success: true, productId };

  } catch (error) {
    console.error(`Error indexing product ${productId}:`, error);
    throw error;
  }
}
