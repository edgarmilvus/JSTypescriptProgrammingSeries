/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

import OpenAI from 'openai';

const openai = new OpenAI();

/**
 * Retrieves an image caption with fallback strategies (Vision -> OCR -> Default).
 * @param base64Image - The image to process
 * @returns A string caption
 */
export async function getResilientImageCaption(base64Image: string): Promise<string> {
  const DEFAULT_CAPTION = "Image description unavailable";

  // ---------------------------------------------------------
  // Primary Attempt: GPT-4 Vision for Captioning
  // ---------------------------------------------------------
  try {
    console.log("Attempting primary Vision API call...");
    const response = await openai.chat.completions.create({
      model: 'gpt-4-vision-preview',
      messages: [
        {
          role: 'user',
          content: [
            { 
              type: 'image_url', 
              image_url: { url: `data:image/jpeg;base64,${base64Image}`, detail: 'low' } 
            },
            { type: 'text', text: 'Provide a brief caption for this image.' }
          ],
        }
      ],
      max_tokens: 50,
    });

    if (response.choices[0].message.content) {
      return response.choices[0].message.content;
    }
    throw new Error("Empty response from Vision API");
    
  } catch (visionError: any) {
    console.error(`Vision API Failed: ${visionError.message || visionError}`);

    // ---------------------------------------------------------
    // Fallback 1: OCR (Text Extraction)
    // ---------------------------------------------------------
    try {
      console.log("Vision failed. Attempting OCR fallback...");
      const ocrResponse = await openai.chat.completions.create({
        model: 'gpt-4-vision-preview',
        messages: [
          {
            role: 'user',
            content: [
              { 
                type: 'image_url', 
                image_url: { url: `data:image/jpeg;base64,${base64Image}`, detail: 'low' } 
              },
              { 
                type: 'text', 
                text: 'Extract all visible text from this image. If there is no text, return "No text found".' 
              }
            ],
          }
        ],
        max_tokens: 100,
      });

      const extractedText = ocrResponse.choices[0].message.content;
      
      // If OCR found text, use it as the caption
      if (extractedText && extractedText !== "No text found") {
        return `Text found in image: "${extractedText}"`;
      }
      
      // If OCR succeeded but found no text, we still fall through to default 
      // because we need a caption, not just text.
      console.log("OCR succeeded but found no text.");
      
    } catch (ocrError: any) {
      console.error(`OCR Fallback Failed: ${ocrError.message || ocrError}`);
    }

    // ---------------------------------------------------------
    // Fallback 2: Default Placeholder
    // ---------------------------------------------------------
    console.log("All automated attempts failed. Returning default caption.");
    return DEFAULT_CAPTION;
  }
}
