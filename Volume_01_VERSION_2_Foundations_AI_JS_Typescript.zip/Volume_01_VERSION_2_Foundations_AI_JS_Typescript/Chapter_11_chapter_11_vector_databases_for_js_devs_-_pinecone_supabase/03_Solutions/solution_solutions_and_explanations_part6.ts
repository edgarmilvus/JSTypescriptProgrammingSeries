/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part6.ts
// Description: Solutions and Explanations
// ==========================================

import { PineconeStore } from "@langchain/pinecone";
import { OpenAIEmbeddings } from "@langchain/openai";
import { createRetrievalChain } from "langchain/chains/retrieval";
import { createStuffDocumentsChain } from "langchain/chains/combine_documents";
import { ChatPromptTemplate } from "@langchain/core/prompts";
import { ChatOpenAI } from "@langchain/openai";

// Mock Initialization (Assuming these are already instantiated)
// In a real app, these would be initialized with API keys and config
const embeddings = new OpenAIEmbeddings({ model: "text-embedding-ada-002" });
// const pineconeStore = new PineconeStore(embeddings, { ... }); 

// 1. Configure the Retriever
// We assume pineconeStore is an instance of PineconeStore
const configureRetriever = (pineconeStore: PineconeStore) => {
  return pineconeStore.asRetriever({
    k: 4, // Fetch top 4 documents
    filter: { // Metadata filtering
      source: "technical_manual.pdf"
    }
  });
};

// 2. Define the System Prompt
const systemPrompt = `
You are an assistant for question-answering tasks. 
Use the following pieces of retrieved context to answer the question. 
If you don't know the answer, say that you don't know. 
Keep the answer concise.

<context>
{context}
</context>
`;

const prompt = ChatPromptTemplate.fromMessages([
  ["system", systemPrompt],
  ["human", "{input}"],
]);

// 3. Create the RAG Chain
const createRAGChain = (retriever: any) => {
  const llm = new ChatOpenAI({ model: "gpt-3.5-turbo", temperature: 0 });
  
  // Chain to combine documents into a single string for the LLM
  const documentChain = createStuffDocumentsChain({
    llm,
    prompt,
  });

  // Chain that handles retrieval and passing context to the document chain
  const retrievalChain = createRetrievalChain({
    retriever,
    combineDocsChain: documentChain,
  });

  return retrievalChain;
};

// 4. Execution Function
async function runRAGQuery(question: string, pineconeStore: PineconeStore) {
  // Setup
  const retriever = configureRetriever(pineconeStore);
  const chain = createRAGChain(retriever);

  // Run
  console.log(`Asking: "${question}"`);
  const result = await chain.invoke({
    input: question,
  });

  console.log("Answer:", result.answer);
  // result.source_documents contains the docs retrieved
}

// --- Mock Usage Context ---
// (This part would be inside an async main function in a real script)
/*
const pineconeIndex = ... // Get Pinecone index
const store = new PineconeStore(embeddings, { index: pineconeIndex });
await runRAGQuery("What is the warranty period?", store);
*/
