/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

/**
 * File: /app/api/rag/route.ts
 * 
 * Objective: Implement a RAG pipeline with a focus on pre-computation strategies
 * to minimize user-facing latency (Perceived Performance).
 * 
 * Dependencies (assumed for this demo):
 * - langchain/document_loaders/fs/pdf
 * - langchain/text_splitter
 * - langchain/schema
 */

import { NextResponse } from 'next/server';
import { PDFLoader } from 'langchain/document_loaders/fs/pdf';
import { RecursiveCharacterTextSplitter } from 'langchain/text_splitter';
import { Document } from 'langchain/document';
import { Embeddings } from '@langchain/core/embeddings';

// ============================================================================
// 1. MOCK INFRASTRUCTURE (Simulating External Services)
// ============================================================================

/**
 * Simulates a Vector Database (e.g., Pinecone, Weaviate, Qdrant).
 * In a real app, this would be a connection to a cloud service.
 * We use an in-memory Map to store vectors for this demo.
 */
const mockVectorStore: Map<string, number[]> = new Map();

/**
 * Simulates an Embedding Model (e.g., OpenAI text-embedding-ada-002).
 * Converts text strings into high-dimensional vectors.
 */
class MockEmbeddings extends Embeddings {
    async embedDocuments(texts: string[]): Promise<number[]>[] {
        // In a real scenario, this calls the LLM API.
        // Here, we generate deterministic 'vectors' based on string length for demo purposes.
        return texts.map(text => {
            const hash = text.split('').reduce((a, b) => {
                a = ((a << 5) - a) + b.charCodeAt(0);
                return a & a;
            }, 0);
            // Return a mock 1536-dimension vector (standard for OpenAI)
            return Array.from({ length: 1536 }, (_, i) => 
                Math.sin((hash + i) * 0.001)
            );
        });
    }

    async embedQuery(text: string): Promise<number[]> {
        const docs = await this.embedDocuments([text]);
        return docs[0];
    }
}

const embeddings = new MockEmbeddings();

// ============================================================================
// 2. DOCUMENT INGESTION & SPLITTING ENGINE
// ============================================================================

/**
 * Loads a raw file buffer and splits it into manageable chunks.
 * 
 * Why Splitting Matters:
 * LLMs have limited context windows. Splitting text ensures that we only
 * pass relevant chunks to the LLM during synthesis, reducing token usage
 * and improving relevance.
 * 
 * Strategy: RecursiveCharacterTextSplitter
 * - Tries to split on new lines first.
 * - If chunks are still too large, it splits on spaces, then characters.
 * - This preserves semantic meaning better than simple fixed-size cuts.
 */
async function processAndSplitDocs(fileBuffer: Buffer): Promise<Document[]> {
    console.log('[Pipeline] Loading document...');
    // Load PDF directly from buffer (Node.js environment)
    const loader = new PDFLoader(new Blob([fileBuffer]), {
        parsedItemSeparator: ' ',
    });
    const rawDocs = await loader.load();

    console.log('[Pipeline] Splitting text...');
    const textSplitter = new RecursiveCharacterTextSplitter({
        chunkSize: 1000, // Target size of each chunk
        chunkOverlap: 200, // Overlap helps maintain context between chunks
    });

    const splitDocs = await textSplitter.splitDocuments(rawDocs);
    return splitDocs;
}

// ============================================================================
// 3. VECTOR STORAGE SERVICE
// ============================================================================

/**
 * Generates embeddings for chunks and stores them in the mock DB.
 * 
 * Performance Note:
 * In a real SaaS app, this step is often offloaded to a background job queue
 * (e.g., BullMQ) to provide immediate feedback to the user (Optimistic UI).
 */
async function storeEmbeddings(docs: Document[]): Promise<void> {
    console.log(`[Pipeline] Generating embeddings for ${docs.length} chunks...`);
    
    const texts = docs.map(doc => doc.pageContent);
    const vectors = await embeddings.embedDocuments(texts);

    // Store in mock DB with a unique ID based on index
    vectors.forEach((vec, index) => {
        const id = `chunk_${Date.now()}_${index}`;
        mockVectorStore.set(id, vec);
    });

    console.log('[Pipeline] Embeddings stored in vector DB.');
}

// ============================================================================
// 4. RETRIEVAL & SYNTHESIS ENGINE
// ============================================================================

/**
 * Performs semantic search against the vector store.
 */
async function retrieveContext(query: string, topK: number = 3): Promise<string[]> {
    console.log(`[Retrieval] Searching for: "${query}"`);
    
    // 1. Embed the query
    const queryVector = await embeddings.embedQuery(query);
    
    // 2. Calculate Cosine Similarity (Mocked for simplicity)
    // Real vector DBs do this efficiently in C++/Rust.
    const scores: { id: string; score: number; content: string }[] = [];

    mockVectorStore.forEach((vec, id) => {
        const dotProduct = queryVector.reduce((sum, val, i) => sum + val * vec[i], 0);
        // Simple approximation of cosine similarity for normalized vectors
        scores.push({ id, score: dotProduct, content: `Content for ${id}` }); 
    });

    // 3. Sort and retrieve top K
    scores.sort((a, b) => b.score - a.score);
    const topResults = scores.slice(0, topK).map(s => s.content);
    
    return topResults;
}

/**
 * Simulates an LLM call (e.g., GPT-4) to synthesize an answer.
 */
async function synthesizeAnswer(context: string[], query: string): Promise<string> {
    console.log('[Synthesis] Generating answer...');
    // In production, this would be: await llm.invoke({ context, query });
    const contextText = context.join('\n\n');
    return `Based on the retrieved context, here is the answer to "${query}":\n\nContext Summary: ${contextText}`;
}

// ============================================================================
// 5. NEXT.JS API ROUTE HANDLER
// ============================================================================

/**
 * Main Route Handler.
 * Handles two types of requests:
 * 1. UPLOAD: Ingests PDF, splits, and pre-computes embeddings.
 * 2. SEARCH: Queries the pre-computed embeddings and generates an answer.
 */
export async function POST(req: Request) {
    try {
        const formData = await req.formData();
        const type = formData.get('type') as string;

        // ---------------------------------------------------------
        // SCENARIO A: Upload & Pre-compute (The "Warm Up" Phase)
        // ---------------------------------------------------------
        if (type === 'UPLOAD') {
            const file = formData.get('file') as File;
            if (!file) return NextResponse.json({ error: 'No file provided' }, { status: 400 });

            // Convert File to Buffer
            const bytes = await file.arrayBuffer();
            const buffer = Buffer.from(bytes);

            // Execute Pipeline Steps
            const splitDocs = await processAndSplitDocs(buffer);
            await storeEmbeddings(splitDocs);

            return NextResponse.json({
                status: 'success',
                message: 'Document processed and indexed.',
                chunksCount: splitDocs.length
            });
        }

        // ---------------------------------------------------------
        // SCENARIO B: Search (The "Inference" Phase)
        // ---------------------------------------------------------
        if (type === 'SEARCH') {
            const query = formData.get('query') as string;
            if (!query) return NextResponse.json({ error: 'No query provided' }, { status: 400 });

            // 1. Retrieve relevant context (Fast, as data is pre-computed)
            const context = await retrieveContext(query);

            if (context.length === 0) {
                return NextResponse.json({
                    answer: "I couldn't find relevant information. Please upload a document first."
                });
            }

            // 2. Synthesize Answer
            const answer = await synthesizeAnswer(context, query);

            return NextResponse.json({
                status: 'success',
                answer: answer,
                sources: context.length
            });
        }

        return NextResponse.json({ error: 'Invalid request type' }, { status: 400 });

    } catch (error) {
        console.error('RAG Pipeline Error:', error);
        return NextResponse.json({ error: 'Internal Server Error' }, { status: 500 });
    }
}
