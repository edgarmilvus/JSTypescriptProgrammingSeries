/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

import { BaseDocumentLoader } from "@langchain/core/document_loaders/base";
import { Document } from "@langchain/core/documents";
import * as fs from "fs/promises";

export class SystemAuditLogLoader extends BaseDocumentLoader {
  constructor(private filePath: string) {
    super();
  }

  public async load(): Promise<Document[]> {
    try {
      // Read the file content asynchronously
      const content = await fs.readFile(this.filePath, "utf-8");
      
      // Split the content by the delimiter '---'
      const rawEntries = content.split("---");
      
      const documents: Document[] = [];

      // Process each entry
      rawEntries.forEach((entry, index) => {
        const trimmedEntry = entry.trim();
        
        // Skip empty entries resulting from trailing delimiters
        if (!trimmedEntry) return;

        // Extract the timestamp from the first line
        // Assuming format: "2023-10-27T10:00:00Z User login..."
        const firstLine = trimmedEntry.split("\n")[0];
        const timestampMatch = firstLine.match(/^(\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z)/);
        const timestamp = timestampMatch ? timestampMatch[1] : "unknown";

        // Create a new Document instance
        const doc = new Document({
          pageContent: trimmedEntry,
          metadata: {
            source: this.filePath,
            entry_index: index,
            timestamp: timestamp,
          },
        });

        documents.push(doc);
      });

      return documents;
    } catch (error) {
      console.error(`Error loading file ${this.filePath}:`, error);
      throw new Error(`Failed to load audit log: ${error}`);
    }
  }
}

// Usage Example:
// const loader = new SystemAuditLogLoader("./audit.log");
// const docs = await loader.load();
