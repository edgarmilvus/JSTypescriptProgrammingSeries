/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

// A basic set of stop words for the heuristic
const STOP_WORDS = new Set(["the", "is", "and", "a", "to", "of", "in", "it", "for", "on", "with"]);

/**
 * Calculates the cohesion score between two sentences based on shared words.
 */
function calculateCohesion(sentenceA: string, sentenceB: string): number {
  const wordsA = new Set(
    sentenceA.toLowerCase()
      .replace(/[^\w\s]/g, '')
      .split(/\s+/)
      .filter(word => word.length > 0 && !STOP_WORDS.has(word))
  );
  
  const wordsB = sentenceB.toLowerCase()
    .replace(/[^\w\s]/g, '')
    .split(/\s+/)
    .filter(word => word.length > 0 && !STOP_WORDS.has(word));

  let intersectionCount = 0;
  for (const word of wordsB) {
    if (wordsA.has(word)) {
      intersectionCount++;
    }
  }
  
  return intersectionCount;
}

export function semanticChunker(text: string, maxTokens: number = 1000): string[] {
  // 1. Split text into sentences
  const sentences = text.match(/[^.!?]+[.!?]+/g) || [text];
  
  const chunks: string[] = [];
  let currentChunk: string[] = [];
  
  // Heuristic threshold for semantic similarity
  const COHESION_THRESHOLD = 2;

  sentences.forEach((sentence, index) => {
    const trimmedSentence = sentence.trim();
    if (!trimmedSentence) return;

    // Approximate token count by characters (rough heuristic)
    const sentenceLength = trimmedSentence.length;

    // Check if adding this sentence exceeds the limit
    const currentChunkLength = currentChunk.join(" ").length;
    
    if (currentChunkLength + sentenceLength > maxTokens && currentChunk.length > 0) {
      // If limit exceeded, push current chunk and start new one
      chunks.push(currentChunk.join(" "));
      currentChunk = [trimmedSentence];
      return;
    }

    // Check semantic cohesion with the previous sentence
    if (currentChunk.length > 0) {
      const prevSentence = currentChunk[currentChunk.length - 1];
      const cohesionScore = calculateCohesion(prevSentence, trimmedSentence);

      // If cohesion is low, start a new chunk (topic shift)
      if (cohesionScore < COHESION_THRESHOLD) {
        chunks.push(currentChunk.join(" "));
        currentChunk = [trimmedSentence];
        return;
      }
    }

    // Add to current chunk
    currentChunk.push(trimmedSentence);
  });

  // Push the final chunk if it exists
  if (currentChunk.length > 0) {
    chunks.push(currentChunk.join(" "));
  }

  return chunks;
}
