/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

/**
 * ============================================================================
 * ADVANCED APPLICATION SCRIPT: SMART SUPPORT TICKET TRIAGE (RAG PIPELINE)
 * ============================================================================
 * 
 * Context: Chapter 13 - Embeddings & Retrieval Strategies
 * Objective: Implement a robust RAG pipeline in a TypeScript/Next.js environment.
 * 
 * This script simulates a backend API endpoint that:
 * 1. Ingests a Knowledge Base (KB) of technical documentation.
 * 2. Chunks the text and generates embeddings for semantic search.
 * 3. Accepts a user support ticket.
 * 4. Retrieves relevant context using K-Nearest Neighbors (KNN).
 * 5. Synthesizes a response using an LLM.
 */

import { NextApiRequest, NextApiResponse } from 'next';
import { OpenAIEmbeddings } from '@langchain/openai';
import { ChatOpenAI } from '@langchain/openai';
import { HNSWLib } from '@langchain/community/vectorstores/hnswlib';
import { RecursiveCharacterTextSplitter } from '@langchain/textsplitters';
import { ChatPromptTemplate, PromptTemplate } from '@langchain/core/prompts';
import { createStuffDocumentsChain } from 'langchain/chains/combine_documents';
import { z } from 'zod';

// ----------------------------------------------------------------------------
// 1. CONFIGURATION & SCHEMAS
// ----------------------------------------------------------------------------

// Runtime validation for incoming API requests using Zod.
const RequestSchema = z.object({
  query: z.string().min(5, "Query must be at least 5 characters long."),
});

// Mock Knowledge Base Data (Simulating a loaded PDF or Markdown file)
const KNOWLEDGE_BASE_DOCS = [
  "The 'Pro' plan includes 1TB of storage, SSO integration, and 24/7 priority support.",
  "To reset your API key, navigate to Settings > Developer > API Keys. Click 'Regenerate'.",
  "Billing cycles are monthly. Invoices are sent on the 1st of every month via email.",
  "SSO is available for Enterprise plans only. It supports SAML 2.0 and OIDC.",
  "Data retention policies: Free tier (30 days), Pro (1 year), Enterprise (Unlimited).",
];

// ----------------------------------------------------------------------------
// 2. SERVICE CLASS: RAG PIPELINE ORCHESTRATOR
// ----------------------------------------------------------------------------

/**
 * Manages the lifecycle of the RAG pipeline.
 * Handles initialization (indexing), retrieval, and generation.
 */
class RagOrchestrator {
  private vectorStore: HNSWLib | null = null;
  private embeddings: OpenAIEmbeddings;
  private llm: ChatOpenAI;

  constructor() {
    // Initialize LLMs. 
    // Note: In a real app, API keys should be loaded from environment variables.
    this.embeddings = new OpenAIEmbeddings({
      model: "text-embedding-ada-002",
    });

    this.llm = new ChatOpenAI({
      model: "gpt-3.5-turbo",
      temperature: 0, // Deterministic output for support responses
    });
  }

  /**
   * Step 1: Ingestion & Indexing (The "Offline" Phase)
   * Converts raw text into vector embeddings and stores them.
   * This is typically done once or triggered when documentation updates.
   */
  public async initializeIndex(): Promise<void> {
    console.log("🚀 Starting Indexing Process...");

    // A. Document Loading
    // In a real app, use PDFLoader or CheerioWebLoader.
    const documents = KNOWLEDGE_BASE_DOCS.map((content) => ({
      pageContent: content,
      metadata: { source: "kb_v1" },
    }));

    // B. Chunking
    // Splitting text to fit context windows and improve retrieval granularity.
    const splitter = new RecursiveCharacterTextSplitter({
      chunkSize: 200,
      chunkOverlap: 20,
    });
    const chunkedDocs = await splitter.splitDocuments(documents);

    // C. Vector Storage (Embedding + Indexing)
    // HNSWLib creates an in-memory index. In production, this might be Pinecone or pgvector.
    this.vectorStore = await HNSWLib.fromDocuments(chunkedDocs, this.embeddings);
    
    console.log(`✅ Indexing Complete. Indexed ${chunkedDocs.length} chunks.`);
  }

  /**
   * Step 2: Retrieval & Synthesis (The "Online" Phase)
   * Handles a user query by retrieving context and generating an answer.
   */
  public async processSupportTicket(query: string): Promise<string> {
    if (!this.vectorStore) {
      throw new Error("Vector store not initialized. Please run initializeIndex() first.");
    }

    console.log(`🔎 Processing Query: "${query}"`);

    // A. Retrieval Strategy (KNN)
    // We search for the top 3 most similar vectors (k=3) to the query.
    // This is the core of Semantic Search.
    const retriever = this.vectorStore.asRetriever({
      k: 3, // Number of neighbors to retrieve
      searchType: "similarity", // Can also be "mmr" for diversity
    });

    // B. Context Retrieval
    const retrievedDocs = await retriever.invoke(query);
    const context = retrievedDocs.map((doc) => doc.pageContent).join("\n\n");

    // C. LLM Synthesis (RAG Chain)
    // We construct a prompt that injects the retrieved context.
    const prompt = ChatPromptTemplate.fromMessages([
      [
        "system",
        `You are a helpful customer support assistant. 
         Use the following context to answer the user's question. 
         If the context is irrelevant, politely state you don't know.
         
         Context:
         {context}`,
      ],
      ["human", "{input}"],
    ]);

    // Create the chain: Prompt + LLM
    const chain = await createStuffDocumentsChain({
      llm: this.llm,
      prompt,
    });

    // Execute the chain
    const response = await chain.invoke({
      input: query,
      context: retrievedDocs,
    });

    return response;
  }
}

// ----------------------------------------------------------------------------
// 3. NEXT.JS API ROUTE HANDLER
// ----------------------------------------------------------------------------

/**
 * API Handler: /api/support
 * 
 * This function simulates a Next.js API route.
 * It validates input, initializes the RAG orchestrator, and returns the result.
 */
export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse
) {
  // Only allow POST requests
  if (req.method !== "POST") {
    return res.status(405).json({ error: "Method Not Allowed" });
  }

  try {
    // 1. Validate Input with Zod
    const validation = RequestSchema.safeParse(req.body);
    if (!validation.success) {
      return res.status(400).json({ errors: validation.error.format() });
    }

    const { query } = validation.data;

    // 2. Instantiate Orchestrator
    // In a real app, you might cache the initialized vector store in a global singleton
    // to avoid re-indexing on every request.
    const orchestrator = new RagOrchestrator();
    
    // 3. Run the Pipeline
    // Note: In production, indexing should happen separately (e.g., during build time or a cron job).
    // For this script, we run it inline to ensure the vector store is ready.
    await orchestrator.initializeIndex();
    
    const answer = await orchestrator.processSupportTicket(query);

    // 4. Return Response
    return res.status(200).json({
      success: true,
      data: {
        answer,
        // Optional: Return sources for transparency
        sources: ["kb_v1"] 
      }
    });

  } catch (error) {
    console.error("RAG Pipeline Error:", error);
    return res.status(500).json({ 
      error: "Internal Server Error", 
      details: (error as Error).message 
    });
  }
}

// ----------------------------------------------------------------------------
// 4. EXAMPLE USAGE (Simulated Client-Side Call)
// ----------------------------------------------------------------------------

/**
 * Example of how the frontend would interact with this API.
 * 
 * const response = await fetch('/api/support', {
 *   method: 'POST',
 *   headers: { 'Content-Type': 'application/json' },
 *   body: JSON.stringify({ query: "How do I reset my API key?" })
 * });
 * 
 * Expected Output:
 * {
 *   "success": true,
 *   "data": {
 *     "answer": "To reset your API key, you should navigate to Settings > Developer > API Keys and click 'Regenerate'.",
 *     "sources": ["kb_v1"]
 *   }
 * }
 */
