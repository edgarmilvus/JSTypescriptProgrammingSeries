/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

// Assuming semanticSearch from Exercise 1 is available
// Mocking the semanticSearch function for this standalone example
async function mockSemanticSearch(query: string, k: number): Promise<{ id: string, content: string, similarityScore: number }[]> {
    // Simulating retrieval results
    return [
        { id: "1", content: "Password reset instructions: Go to settings.", similarityScore: 0.92 },
        { id: "2", content: "Account recovery options include email.", similarityScore: 0.85 }
    ];
}

// Mock LLM Call
function mockLLMCall(prompt: string): string {
    // In a real scenario, this would call OpenAI.chat.completions.create
    return `Generated Response based on prompt:\n\n${prompt.substring(0, 100)}...`; // Truncated for display
}

/**
 * Executes the RAG Pipeline.
 * @param query The user's question.
 * @param threshold Optional similarity threshold to filter results.
 */
async function executeRAGPipeline(query: string, threshold: number = 0.0) {
    try {
        // Step 1: Retrieval
        // Note: In a real app, we would pass the actual semanticSearch function
        const retrievedDocs = await mockSemanticSearch(query, 2);

        // Step 5 Interactive Challenge: Similarity Threshold Filter
        if (retrievedDocs.length === 0) {
            return "No relevant context found to answer the query.";
        }

        // Check if the top result meets the threshold
        if (retrievedDocs[0].similarityScore < threshold) {
            return "The retrieved context is not relevant enough to answer the question confidently.";
        }

        // Step 2: Context Formatting
        const context = retrievedDocs.map(doc => 
            `[Doc ID: ${doc.id}] Content: ${doc.content}`
        ).join('\n\n');

        // Step 3: Prompt Engineering
        const promptTemplate = `You are a helpful assistant. Answer the following question using only the provided context. If the answer is not in the context, say "I don't know".\n\nContext:\n${context}\n\nQuestion:\n${query}`;

        // Step 4: LLM Call
        const llmResponse = mockLLMCall(promptTemplate);
        
        return llmResponse;

    } catch (error) {
        console.error("Pipeline Error:", error);
        return "An error occurred while processing your request.";
    }
}

// --- Usage Examples ---

// Example 1: Standard execution
// executeRAGPipeline("How do I reset my password?").then(console.log);

// Example 2: Execution with high threshold (0.95) that might fail
// executeRAGPipeline("Unrelated query", 0.95).then(console.log);
