/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.ts
// Description: Basic Code Example
// ==========================================

/**
 * Minimal RAG Pipeline Example
 * 
 * This script demonstrates a basic Retrieval-Augmented Generation (RAG) flow.
 * It ingests a small set of documents, creates vector embeddings, retrieves
 * relevant context based on a user query, and generates an answer using OpenAI.
 * 
 * Usage: npx ts-node rag-minimal.ts
 */

import { OpenAIEmbeddings, ChatOpenAI } from "@langchain/openai";
import { MemoryVectorStore } from "langchain/vectorstores/memory";
import { Document } from "@langchain/core/documents";
import { ChatPromptTemplate } from "@langchain/core/prompts";
import { createStuffDocumentsChain } from "langchain/chains/combine_documents";
import { StringOutputParser } from "@langchain/core/output_parsers";

// 1. CONFIGURATION
// ---------------------------------------------------------
// In a real SaaS app, this would come from environment variables (.env file).
// We use a placeholder here for demonstration. 
// WARNING: Never hardcode API keys in production code.
const OPENAI_API_KEY = process.env.OPENAI_API_KEY || "sk-...";

// 2. DATA INGESTION (Simulated)
// ---------------------------------------------------------
/**
 * Represents a raw document in our knowledge base.
 * In a real app, this might come from a database, PDF, or Markdown file.
 */
const rawDocuments: string[] = [
    "The 'Acme Rocket' product has a top speed of Mach 5 and uses liquid hydrogen.",
    "The 'Acme Rocket' requires a launch pad clearance of at least 100 meters.",
    "The 'Acme Drone' model X1 can fly for 45 minutes on a single charge.",
    "The 'Acme Drone' is waterproof up to IP67 standards, suitable for rain.",
];

// 3. MAIN RAG FUNCTION
// ---------------------------------------------------------
async function runRAGPipeline(query: string) {
    console.log(`\n[1] Processing Query: "${query}"`);

    // A. Initialize the LLM (Large Language Model)
    // ---------------------------------------------------------
    // We use gpt-3.5-turbo for this example due to its speed and cost efficiency.
    const llm = new ChatOpenAI({
        apiKey: OPENAI_API_KEY,
        modelName: "gpt-3.5-turbo",
        temperature: 0, // Deterministic output for factual retrieval
    });

    // B. Initialize Embeddings and Vector Store
    // ---------------------------------------------------------
    // Embeddings convert text into numerical vectors (semantic meaning).
    // MemoryVectorStore simulates a vector database (like Pinecone or Weaviate) in RAM.
    const embeddings = new OpenAIEmbeddings({
        apiKey: OPENAI_API_KEY,
    });

    // C. Ingest Documents into the Vector Store
    // ---------------------------------------------------------
    // We convert raw strings into LangChain Document objects (with metadata).
    const documents = rawDocuments.map(
        (text, index) =>
            new Document({
                pageContent: text,
                metadata: { source: "product_manuals", id: index },
            })
        );

    // Create the vector store from documents. This performs the embedding generation.
    const vectorStore = await MemoryVectorStore.fromDocuments(
        documents,
        embeddings
    );

    console.log("[2] Documents embedded and stored in memory.");

    // D. Semantic Search (Retrieval)
    // ---------------------------------------------------------
    // We perform a similarity search to find the top 2 most relevant documents.
    // This is the "Retrieval" step of RAG.
    const retrievedDocs = await vectorStore.similaritySearch(query, 2);

    console.log("[3] Retrieved Context:");
    retrievedDocs.forEach((doc, i) => {
        console.log(`   ${i + 1}. ${doc.pageContent}`);
    });

    // E. Contextual Generation (Augmentation)
    // ---------------------------------------------------------
    // We construct a prompt that instructs the LLM to answer strictly 
    // based on the provided context.
    const prompt = ChatPromptTemplate.fromMessages([
        ["system", "You are a helpful assistant for Acme Corp. Answer the user's question strictly based on the following context:"],
        ["context", ""], // This placeholder will be filled by the document chain
        ["human", "{input}"],
    ]);

    // The "Stuff" chain takes the context documents and "stuffs" them into the prompt.
    const documentChain = await createStuffDocumentsChain({
        llm,
        prompt,
        outputParser: new StringOutputParser(),
    });

    // F. Execute the Chain
    // ---------------------------------------------------------
    // We pass the user query and the retrieved documents to the chain.
    const response = await documentChain.invoke({
        input: query,
        context: retrievedDocs, // Injecting the retrieved data
    });

    return response;
}

// 4. EXECUTION
// ---------------------------------------------------------
(async () => {
    try {
        // Define a user query that requires external knowledge
        const userQuery = "What is the water resistance rating of the Acme Drone?";
        
        const answer = await runRAGPipeline(userQuery);
        
        console.log("\n[4] Final Answer Generated by LLM:");
        console.log("------------------------------------------------");
        console.log(answer);
        console.log("------------------------------------------------");
        
    } catch (error) {
        console.error("Pipeline failed:", error);
    }
})();
