/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// app/actions/rag-ingest.ts
'use server';

import { PDFLoader } from 'langchain/document_loaders/fs/pdf';
import { RecursiveCharacterTextSplitter } from 'langchain/text_splitter';
import { OpenAIEmbeddings } from '@langchain/openai';
import { PineconeStore } from '@langchain/pinecone';
import { pinecone } from '@/lib/pinecone-client'; // Assumed initialized client
import { uploadFile, getFileBlob } from '@/lib/file-storage'; // Assumed file storage utility

/**
 * @description Server Action: Ingests a PDF, chunks it, and upserts vectors to Pinecone.
 * @param {FormData} formData - Contains the PDF file.
 * @returns {Promise<{ success: boolean; message: string }>}
 * 
 * @architecture
 * 1. File Extraction: Retrieves the file from the client form.
 * 2. Parsing: Loads the PDF content into Document objects.
 * 3. Chunking: Splits text into semantic chunks (Overlap strategy).
 * 4. Embedding: Generates vector representations using OpenAI.
 * 5. Storage: Upserts vectors into Pinecone for semantic search.
 */
export async function ingestDocument(formData: FormData) {
  try {
    // 1. File Extraction
    const file = formData.get('file') as File;
    if (!file) return { success: false, message: 'No file provided' };

    // 2. Parsing (Headless Inference on Edge)
    // PDFLoader runs purely in memory, no GUI required.
    const loader = new PDFLoader(file, { splitPages: true });
    const docs = await loader.load();

    // 3. Chunking
    // We use a recursive splitter to handle code/text boundaries efficiently.
    // Overlap prevents context loss at chunk boundaries.
    const textSplitter = new RecursiveCharacterTextSplitter({
      chunkSize: 1000,
      chunkOverlap: 200,
    });
    const splitDocs = await textSplitter.splitDocuments(docs);

    // 4. Embedding & 5. Storage
    // We use OpenAIEmbeddings to convert text to vectors.
    const embeddings = new OpenAIEmbeddings({
      modelName: 'text-embedding-ada-002',
      openAIApiKey: process.env.OPENAI_API_KEY,
    });

    // PineconeStore handles the upsert of vectors and metadata.
    await PineconeStore.fromDocuments(splitDocs, embeddings, {
      pineconeIndex: pinecone.Index(process.env.PINECONE_INDEX_NAME!),
      namespace: 'customer-support', // Isolate data per tenant
    });

    return { success: true, message: `Successfully ingested ${splitDocs.length} chunks.` };
  } catch (error) {
    console.error('Ingestion Error:', error);
    return { success: false, message: 'Failed to process document.' };
  }
}
