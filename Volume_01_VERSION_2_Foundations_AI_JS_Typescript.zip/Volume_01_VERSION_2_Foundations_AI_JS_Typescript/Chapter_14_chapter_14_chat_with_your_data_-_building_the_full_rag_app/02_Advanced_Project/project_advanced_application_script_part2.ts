/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script_part2.ts
// Description: Advanced Application Script
// ==========================================

// app/api/chat/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { StreamingTextResponse, LangChainStream } from 'ai';
import { ChatOpenAI } from '@langchain/openai';
import { PineconeStore } from '@langchain/pinecone';
import { RetrievalQAChain } from 'langchain/chains';
import { pinecone } from '@/lib/pinecone-client';

export const runtime = 'edge'; // Optimized for low-latency inference

/**
 * @description API Route: Handles chat queries against the ingested data.
 * @param {NextRequest} req - The incoming request containing the user message.
 * @returns {StreamingTextResponse} - Streams the LLM response back to the client.
 * 
 * @architecture
 * 1. Request Parsing: Extracts the user query from the JSON body.
 * 2. Vector Retrieval: Queries Pinecone for context relevant to the query.
 * 3. Chain Construction: Connects the Retriever to the LLM (ChatGPT).
 * 4. Streaming: Pipes the LLM response to the client in real-time.
 */
export async function POST(req: NextRequest) {
  const { prompt } = await req.json();

  if (!prompt) {
    return NextResponse.json({ error: 'No prompt provided' }, { status: 400 });
  }

  // 1. Initialize Headless Inference Model
  const llm = new ChatOpenAI({
    modelName: 'gpt-4-turbo-preview',
    temperature: 0, // Deterministic answers for factual support
    streaming: true, // Enable token-by-token streaming
  });

  // 2. Initialize Vector Store Retriever
  const vectorStore = await PineconeStore.fromExistingIndex(
    new OpenAIEmbeddings({ modelName: 'text-embedding-ada-002' }),
    {
      pineconeIndex: pinecone.Index(process.env.PINECONE_INDEX_NAME!),
      namespace: 'customer-support',
    }
  );

  // 3. Construct the Retrieval Chain
  // We use RetrievalQAChain to handle the "Retrieve then Answer" logic automatically.
  const chain = RetrievalQAChain.fromLLM(llm, vectorStore.asRetriever(), {
    returnSourceDocuments: true, // Useful for debugging/verification
  });

  // 4. Stream the Response
  const { stream, handlers } = LangChainStream();
  
  // Execute the chain. The LLM will query the vector store internally.
  chain.call({ query: prompt }, [handlers]).catch(console.error);

  return new StreamingTextResponse(stream);
}
