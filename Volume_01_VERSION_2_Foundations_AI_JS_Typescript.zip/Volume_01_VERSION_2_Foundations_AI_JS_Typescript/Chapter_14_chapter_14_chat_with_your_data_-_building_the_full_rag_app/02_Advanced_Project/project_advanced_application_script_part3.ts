/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script_part3.ts
// Description: Advanced Application Script
// ==========================================

// app/page.tsx
'use client';

import { useState } from 'react';
import { ingestDocument } from '@/app/actions/rag-ingest';

export default function ChatWithYourData() {
  const [input, setInput] = useState('');
  const [messages, setMessages] = useState<Array<{ role: string; content: string }>>([]);
  const [isUploading, setIsUploading] = useState(false);

  // Handle File Upload (Ingestion)
  const handleUpload = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setIsUploading(true);
    const formData = new FormData(e.currentTarget);
    const result = await ingestDocument(formData);
    alert(result.message);
    setIsUploading(false);
  };

  // Handle Chat (Inference)
  const handleChat = async () => {
    if (!input) return;
    
    // Add user message
    setMessages(prev => [...prev, { role: 'user', content: input }]);
    
    // Fetch streaming response
    const response = await fetch('/api/chat', {
      method: 'POST',
      body: JSON.stringify({ prompt: input }),
    });

    if (!response.body) return;
    
    const reader = response.body.getReader();
    const decoder = new TextDecoder();
    let botMessage = '';

    // Read stream
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      const chunk = decoder.decode(value, { stream: true });
      botMessage += chunk;
      // Update UI incrementally
      setMessages(prev => {
        const newMsgs = [...prev];
        const lastMsg = newMsgs[newMsgs.length - 1];
        if (lastMsg && lastMsg.role === 'assistant') {
          lastMsg.content += chunk;
          return newMsgs;
        }
        return [...newMsgs, { role: 'assistant', content: chunk }];
      });
    }
  };

  return (
    <div className="p-8 max-w-4xl mx-auto">
      {/* Upload Section */}
      <div className="mb-8 p-4 border rounded-lg bg-gray-50">
        <h2 className="text-xl font-bold mb-2">1. Ingest Knowledge Base</h2>
        <form onSubmit={handleUpload} className="flex gap-4">
          <input type="file" name="file" accept=".pdf" required className="block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100" />
          <button disabled={isUploading} type="submit" className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 disabled:opacity-50">
            {isUploading ? 'Processing...' : 'Upload & Index'}
          </button>
        </form>
      </div>

      {/* Chat Section */}
      <div className="flex flex-col gap-4">
        <div className="h-96 overflow-y-auto border rounded-lg p-4 bg-white shadow-inner">
          {messages.map((msg, i) => (
            <div key={i} className={`mb-2 ${msg.role === 'user' ? 'text-right' : 'text-left'}`}>
              <span className={`inline-block px-3 py-1 rounded-lg ${msg.role === 'user' ? 'bg-blue-600 text-white' : 'bg-gray-200 text-gray-800'}`}>
                {msg.content}
              </span>
            </div>
          ))}
        </div>
        <div className="flex gap-2">
          <input 
            type="text" 
            value={input} 
            onChange={(e) => setInput(e.target.value)}
            placeholder="Ask a question about the document..."
            className="flex-1 border rounded px-3 py-2"
            onKeyDown={(e) => e.key === 'Enter' && handleChat()}
          />
          <button onClick={handleChat} className="px-6 py-2 bg-green-600 text-white rounded hover:bg-green-700">
            Send
          </button>
        </div>
      </div>
    </div>
  );
}
