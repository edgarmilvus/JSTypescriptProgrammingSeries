/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

// ragChain.ts
import { ChatOpenAI } from "@langchain/openai";
import { PromptTemplate } from "@langchain/core/prompts";
import { RunnableSequence, RunnableLambda, RunnablePassthrough } from "@langchain/core/runnables";
import { initializePineconeRetriever } from "./retriever"; // Assuming Exercise 2 export

// 1. Chain Construction & 2. Prompt Engineering
const systemPrompt = `You are a helpful assistant. Answer the user's question based ONLY on the following context:
<context>
{context}
</context>

Question: {question}

If the context is empty or irrelevant, politely state that you don't have information on that topic.`;

const prompt = PromptTemplate.fromTemplate(systemPrompt);

// 3. Model Integration
const model = new ChatOpenAI({
    model: "gpt-3.5-turbo",
    temperature: 0.7,
});

// Initialize retriever
const retriever = initializePineconeRetriever("your-index-name", "your-namespace");

// 4. Output Parsing: The LLM returns a string, so no complex parsing is needed.

// 5. Interactive Challenge: Fallback Logic
// We need a function to format the context. If no matches, return "No relevant context found."
const formatContext = (input: { context: any[] }) => {
    if (!input.context || input.context.length === 0) {
        return "No relevant context found.";
    }
    // Join the content of the retrieved chunks
    return input.context.map((c) => c.content).join("\n\n");
};

// Construct the RAG Chain
const ragChain = RunnableSequence.from([
    // Input is the question string
    // We need to pass the question to the retriever and also keep it for the prompt
    {
        // Pass the question through
        question: new RunnablePassthrough(),
        // Run the retriever
        context: new RunnableLambda(async (input: string) => {
            const results = await retriever.search(input);
            return results;
        }),
    },
    // Format the context
    {
        question: (input: { question: string }) => input.question, // Pass question through
        context: new RunnableLambda(formatContext),
    },
    // Pass to prompt
    prompt,
    // Pass to model
    model,
    // Extract string content
    new RunnableLambda({
        func: async (output) => output.content,
    }),
]);

// Function to execute the chain
export async function askQuestion(question: string): Promise<string> {
    try {
        const response = await ragChain.invoke(question);
        return response as string;
    } catch (error) {
        console.error("Error in RAG chain:", error);
        return "Sorry, an error occurred while processing your request.";
    }
}
