/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.tsx
// Description: Solutions and Explanations
// ==========================================

// types.ts
export interface ChatMessageProps {
    message: string;
    isUser: boolean;
}

// ChatMessage.tsx
import React, { Suspense } from 'react';

// 2. Streaming Simulation
const simulateStream = async (): Promise<string> => {
    // Simulate a network delay
    return new Promise((resolve) => {
        setTimeout(() => {
            resolve("This is a simulated streamed response from the AI. It appears after a 2-second delay.");
        }, 2000);
    });
};

// Async component to handle the suspense boundary
const AsyncAIContent = async () => {
    const text = await simulateStream();
    return <span>{text}</span>;
};

// 1. Component Structure
export const ChatMessage: React.FC<ChatMessageProps> = ({ message, isUser }) => {
    // 3. Suspense Boundary & 4. Async Rendering
    // If it's a user message, we just display the message prop directly.
    // If it's an AI message (and message is empty/loading), we show the Suspense boundary.
    
    return (
        <div className={`flex ${isUser ? 'justify-end' : 'justify-start'} mb-4`}>
            <div
                className={`max-w-[70%] px-4 py-2 rounded-lg ${
                    isUser ? 'bg-blue-500 text-white rounded-br-none' : 'bg-gray-200 text-gray-800 rounded-bl-none'
                }`}
            >
                {isUser ? (
                    message
                ) : (
                    // 3. Wrap the async content in Suspense
                    <Suspense fallback={<span className="animate-pulse">Typing...</span>}>
                        {/* In a real app, the message prop might contain a promise or we'd pass an ID to fetch. 
                            Here we simulate the streaming directly inside the component. */}
                        <AsyncAIContent />
                    </Suspense>
                )}
            </div>
        </div>
    );
};

// 5. State Management (Optional Parent Component)
// ChatContainer.tsx
import React, { useState } from 'react';

export const ChatContainer = () => {
    const [messages, setMessages] = useState<Array<{ text: string; isUser: boolean }>>([]);

    const handleSend = () => {
        // Add user message
        const userMsg = { text: "What is the context?", isUser: true };
        setMessages((prev) => [...prev, userMsg]);

        // Add AI message placeholder (empty string triggers the Suspense loading state)
        // In a real scenario, this might be a promise or a loading ID.
        const aiMsg = { text: "", isUser: false };
        setMessages((prev) => [...prev, aiMsg]);
    };

    return (
        <div className="chat-container">
            <div className="messages-area">
                {messages.map((msg, index) => (
                    <ChatMessage key={index} message={msg.text} isUser={msg.isUser} />
                ))}
            </div>
            <button onClick={handleSend}>Send Question</button>
        </div>
    );
};
