/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.tsx
// Description: Advanced Application Script
// ==========================================

'use client';

import React, { useState, useEffect, useRef } from 'react';
import { pipeline, Pipeline, PipelineType } from '@xenova/transformers';

// ----------------------------------------------------------------------------
// 1. TYPE DEFINITIONS & INTERFACES
// ----------------------------------------------------------------------------

/**
 * Defines the structure of the classification result returned by the model.
 */
interface ClassificationResult {
  label: string;  // The predicted category (e.g., "bug", "feature")
  score: number;  // Confidence score (0 to 1)
}

/**
 * Defines the state of the application.
 * - 'idle': Waiting for user input.
 * - 'loading': Downloading the model weights (happens once).
 * - 'classifying': Processing the text.
 * - 'done': Results are ready.
 * - 'error': Something went wrong.
 */
type AppState = 'idle' | 'loading' | 'classifying' | 'done' | 'error';

// ----------------------------------------------------------------------------
// 2. THE REACT COMPONENT
// ----------------------------------------------------------------------------

/**
 * ZeroShotFeedbackAnalyzer Component
 * 
 * A Client Component that runs a local NLP model to categorize user feedback.
 * It leverages Transformers.js to perform inference directly in the browser.
 */
export default function ZeroShotFeedbackAnalyzer() {
  // State for managing UI feedback and application lifecycle
  const [status, setStatus] = useState<AppState>('idle');
  const [inputText, setInputText] = useState<string>('');
  const [results, setResults] = useState<ClassificationResult[]>([]);
  const [error, setError] = useState<string | null>(null);

  // Ref to store the classification pipeline instance.
  // We use a ref to persist the pipeline across re-renders without 
  // triggering unnecessary reloads.
  const classifierRef = useRef<Pipeline<'zero-shot-classification'> | null>(null);

  // ----------------------------------------------------------------------------
  // 3. MODEL INITIALIZATION (USE EFFECT)
  // ----------------------------------------------------------------------------

  /**
   * Loads the Transformers.js pipeline on component mount.
   * 
   * Why use a pipeline?
   * A pipeline is a high-level abstraction that handles tokenization, 
   * model inference, and post-processing in one call.
   * 
   * Under the Hood:
   * - 'zero-shot-classification': Specifies the task.
   * - 'Xenova/bert-base-uncased-mnli': A lightweight BERT model fine-tuned 
   *   for Natural Language Inference (NLI), adapted for zero-shot classification.
   * - quantized: true: Loads a 8-bit quantized version (smaller file size, faster load).
   */
  useEffect(() => {
    let isMounted = true;

    const loadModel = async () => {
      if (classifierRef.current) return; // Model already loaded

      setStatus('loading');
      try {
        // Dynamically import the pipeline function to keep bundle size manageable
        const { pipeline: pipe } = await import('@xenova/transformers');
        
        // Initialize the pipeline
        const classifier = await pipe(
          'zero-shot-classification', 
          'Xenova/bert-base-uncased-mnli',
          { quantized: true } // Optimization for browser performance
        );

        if (isMounted) {
          classifierRef.current = classifier;
          setStatus('idle');
        }
      } catch (err) {
        if (isMounted) {
          setStatus('error');
          setError('Failed to load AI model. Check your internet connection.');
          console.error(err);
        }
      }
    };

    loadModel();

    // Cleanup function to prevent memory leaks if component unmounts
    return () => {
      isMounted = false;
    };
  }, []);

  // ----------------------------------------------------------------------------
  // 4. CLASSIFICATION LOGIC
  // ----------------------------------------------------------------------------

  /**
   * Handles the form submission and triggers the local inference.
   * 
   * @param e - React Form Event
   */
  const handleAnalyze = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!inputText.trim()) return;
    if (!classifierRef.current) {
      setError('Model is not ready yet.');
      return;
    }

    setStatus('classifying');
    setResults([]);
    setError(null);

    try {
      // Define candidate labels (Zero-Shot capability)
      const candidateLabels = ['bug report', 'feature request', 'praise'];

      // Execute inference locally
      // This runs on the main thread (or web worker if configured), 
      // blocking UI if the model is large. For BERT-base, it's fast enough.
      const output = await classifierRef.current(inputText, candidateLabels, {
        multi_class: true, // Allow multiple labels if applicable
      });

      // Format and set results
      // The model returns labels and scores arrays mapped by index
      const formattedResults: ClassificationResult[] = output.labels.map((label: string, index: number) => ({
        label,
        score: output.scores[index],
      }));

      setResults(formattedResults);
      setStatus('done');
    } catch (err) {
      setStatus('error');
      setError('Error during classification.');
      console.error(err);
    }
  };

  // ----------------------------------------------------------------------------
  // 5. UI RENDERING
  // ----------------------------------------------------------------------------

  return (
    <div className="max-w-2xl mx-auto p-6 bg-white rounded-lg shadow-lg border border-gray-200">
      <h2 className="text-2xl font-bold mb-4 text-gray-800">
        Local Feedback Analyzer
      </h2>
      <p className="text-gray-600 mb-6 text-sm">
        Analyze customer feedback locally using Transformers.js. 
        No data leaves your browser.
      </p>

      {/* Status Indicator */}
      <div className="mb-4 p-3 rounded-md bg-gray-50 text-sm font-mono text-gray-700">
        Status: <span className="font-bold uppercase">{status}</span>
      </div>

      {/* Input Form */}
      <form onSubmit={handleAnalyze} className="space-y-4">
        <div>
          <label htmlFor="feedback" className="block text-sm font-medium text-gray-700">
            Customer Feedback
          </label>
          <textarea
            id="feedback"
            rows={4}
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 border p-2"
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            placeholder="e.g., The app crashes when I click the export button..."
            disabled={status === 'loading' || status === 'classifying'}
          />
        </div>

        <button
          type="submit"
          className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 disabled:opacity-50"
          disabled={status === 'loading' || status === 'classifying' || !inputText}
        >
          {status === 'loading' ? 'Loading Model...' : 
           status === 'classifying' ? 'Analyzing...' : 'Analyze Locally'}
        </button>
      </form>

      {/* Error Display */}
      {error && (
        <div className="mt-4 p-3 bg-red-50 border border-red-200 text-red-700 rounded">
          Error: {error}
        </div>
      )}

      {/* Results Display */}
      {status === 'done' && results.length > 0 && (
        <div className="mt-6 space-y-3">
          <h3 className="text-lg font-semibold text-gray-900">Results:</h3>
          {results.map((result, idx) => (
            <div 
              key={idx} 
              className="flex items-center justify-between p-3 bg-gray-50 rounded border"
            >
              <span className="capitalize font-medium text-gray-800">
                {result.label}
              </span>
              <div className="flex items-center gap-2">
                <div className="w-32 h-2 bg-gray-200 rounded-full overflow-hidden">
                  <div 
                    className="h-full bg-indigo-500" 
                    style={{ width: `${result.score * 100}%` }}
                  ></div>
                </div>
                <span className="text-sm font-mono text-gray-600">
                  {(result.score * 100).toFixed(1)}%
                </span>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
