/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState, useEffect } from 'react';
import { pipeline, PipelineType } from '@xenova/transformers';

// Define the shape of the classification result
interface ClassificationResult {
  label: string;
  score: number;
}

export const ZeroShotClassifier: React.FC = () => {
  const [model, setModel] = useState<any>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [loadingProgress, setLoadingProgress] = useState<number>(0);
  const [text, setText] = useState<string>('');
  const [labelsInput, setLabelsInput] = useState<string>('');
  const [results, setResults] = useState<ClassificationResult[]>([]);
  const [error, setError] = useState<string | null>(null);

  // Load the model on component mount
  useEffect(() => {
    const loadModel = async () => {
      try {
        // Initialize the zero-shot classification pipeline
        // We use a progress callback to update the UI during download
        const classifier = await pipeline('zero-shot-classification', 
          'Xenova/roberta-large-mnli', 
          {
            progress_callback: (data: any) => {
              if (data.status === 'progress') {
                setLoadingProgress(Math.round(data.progress || 0));
              }
            }
          }
        );
        setModel(classifier);
        setLoading(false);
      } catch (err) {
        console.error("Error loading model:", err);
        setError("Failed to load model. Check your network connection.");
        setLoading(false);
      }
    };

    loadModel();

    // Cleanup function to free up memory if needed
    return () => {
      // In a real app, you might want to explicitly dispose of the model here
      // if the library supports it (e.g., model.dispose())
    };
  }, []);

  const handleClassify = async () => {
    if (!text.trim() || !labelsInput.trim()) {
      setError("Please provide both text and candidate labels.");
      return;
    }

    if (!model) {
      setError("Model is not loaded yet.");
      return;
    }

    setError(null);
    setLoading(true); // Show loading state during inference

    try {
      // Parse comma-separated labels
      const candidateLabels = labelsInput.split(',').map(l => l.trim()).filter(l => l);

      // Run inference
      const output = await model(text, candidateLabels);

      // Format results
      // Transformers.js output for zero-shot usually contains labels and scores arrays
      const formattedResults: ClassificationResult[] = output.labels.map((label: string, index: number) => ({
        label: label,
        score: output.scores[index]
      }));

      setResults(formattedResults);
    } catch (err) {
      console.error("Classification error:", err);
      setError("Error during classification.");
    } finally {
      setLoading(false);
    }
  };

  if (loading && !model) {
    return (
      <div style={{ padding: '20px', textAlign: 'center' }}>
        <p>Loading Model... {loadingProgress}%</p>
        <progress value={loadingProgress} max="100" />
      </div>
    );
  }

  return (
    <div style={{ padding: '20px', maxWidth: '600px', margin: '0 auto' }}>
      <h2>Zero-Shot Classification</h2>
      
      <div style={{ marginBottom: '15px' }}>
        <label style={{ display: 'block', marginBottom: '5px' }}>Text to classify:</label>
        <textarea
          value={text}
          onChange={(e) => setText(e.target.value)}
          rows={4}
          style={{ width: '100%', padding: '8px' }}
          placeholder="Enter text here..."
        />
      </div>

      <div style={{ marginBottom: '15px' }}>
        <label style={{ display: 'block', marginBottom: '5px' }}>Candidate Labels (comma-separated):</label>
        <input
          type="text"
          value={labelsInput}
          onChange={(e) => setLabelsInput(e.target.value)}
          style={{ width: '100%', padding: '8px' }}
          placeholder="e.g., Sports, Politics, Technology"
        />
      </div>

      <button 
        onClick={handleClassify} 
        disabled={loading}
        style={{ padding: '10px 20px', cursor: loading ? 'not-allowed' : 'pointer' }}
      >
        {loading ? 'Processing...' : 'Classify'}
      </button>

      {error && <p style={{ color: 'red', marginTop: '10px' }}>{error}</p>}

      {results.length > 0 && (
        <div style={{ marginTop: '20px' }}>
          <h3>Results:</h3>
          {results.map((result, index) => (
            <div key={index} style={{ marginBottom: '10px' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                <span>{result.label}</span>
                <span>{(result.score * 100).toFixed(1)}%</span>
              </div>
              <div style={{ background: '#eee', height: '10px', borderRadius: '5px', overflow: 'hidden' }}>
                <div 
                  style={{ 
                    width: `${result.score * 100}%`, 
                    background: '#4caf50', 
                    height: '100%' 
                  }} 
                />
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
