/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

// File: public/model-cache-worker.js (Service Worker)
const CACHE_NAME = 'transformers-model-cache-v1';
const MODEL_ASSETS = [
  // List of specific model files to cache proactively
  // Note: In a real scenario, you'd dynamically fetch the dependency list
  '/models/xenova/roberta-large-mnli/tokenizer.json',
  '/models/xenova/roberta-large-mnli/config.json',
  // Wildcard handling is done in fetch event
];

self.addEventListener('install', (event: any) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => {
      return cache.addAll(MODEL_ASSETS);
    })
  );
});

self.addEventListener('fetch', (event: any) => {
  // Check if request is for a model file (e.g., .onnx, .json, .bin)
  if (event.request.url.includes('/models/') || event.request.url.endsWith('.onnx')) {
    event.respondWith(
      caches.match(event.request).then((response) => {
        if (response) {
          console.log('Serving from cache:', event.request.url);
          return response;
        }
        console.log('Fetching and caching:', event.request.url);
        return fetch(event.request).then((response) => {
          // Clone the response because it can be consumed only once
          const responseClone = response.clone();
          caches.open(CACHE_NAME).then((cache) => {
            cache.put(event.request, responseClone);
          });
          return response;
        }).catch(() => {
          // Handle offline scenario if needed
          return new Response('Offline - Model not cached');
        });
      })
    );
  }
});

// Helper function to visualize dependencies (Mock implementation)
// In a real app, this would fetch the model's config.json and map the 'files' property
export const getDependencyTree = async (modelId: string) => {
  // This logic would typically run in the main thread or a Web Worker
  // fetching the model index.json to determine file sizes and structure
  return [
    { file: 'tokenizer.json', size: '2.5MB' },
    { file: 'config.json', size: '1KB' },
    { file: 'model.onnx', size: '400MB' },
    { file: 'tokenizer_config.json', size: '500B' }
  ];
};
