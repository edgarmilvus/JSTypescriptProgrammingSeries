/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState, useRef } from 'react';
import { pipeline } from '@xenova/transformers';

interface SentimentData {
  text: string;
  label: string;
  score: number;
}

export const SentimentDashboard: React.FC = () => {
  const [inputText, setInputText] = useState('');
  const [results, setResults] = useState<SentimentData[]>([]);
  const [processingTime, setProcessingTime] = useState<number | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const classifierRef = useRef<any>(null);

  const analyzeSentiment = async () => {
    if (!inputText.trim()) return;

    setIsLoading(true);
    const startTime = performance.now();

    try {
      // Lazy load model only when needed
      if (!classifierRef.current) {
        classifierRef.current = await pipeline('sentiment-analysis', 'distilbert-base-uncased-finetuned-sst-2-english');
      }

      // Split text into sentences (simple regex split)
      const sentences = inputText.split(/[.!?]+/).filter(s => s.trim().length > 0);
      
      // Process batch
      // Note: Transformers.js pipeline can handle arrays of strings for efficiency
      const output = await classifierRef.current(sentences);

      // Format output
      const formatted = sentences.map((text, i) => ({
        text,
        label: output[i].label,
        score: output[i].score
      }));

      const endTime = performance.now();
      setProcessingTime(endTime - startTime);
      setResults(formatted);

    } catch (error) {
      console.error("Analysis failed", error);
    } finally {
      setIsLoading(false);
    }
  };

  // Simulated API delay for comparison
  const simulateAPICall = async () => {
    setIsLoading(true);
    await new Promise(resolve => setTimeout(resolve, 200)); // Simulate 200ms network latency
    setIsLoading(false);
    alert(`Simulated API Call completed. Total time: 200ms (Network Latency + Overhead)`);
  };

  return (
    <div style={{ padding: '20px', fontFamily: 'sans-serif' }}>
      <h2>Sentiment Analysis Dashboard</h2>
      
      <div style={{ marginBottom: '15px' }}>
        <textarea
          value={inputText}
          onChange={(e) => setInputText(e.target.value)}
          rows={4}
          style={{ width: '100%', padding: '8px' }}
          placeholder="Enter text with multiple sentences..."
        />
        <div style={{ marginTop: '10px' }}>
          <button onClick={analyzeSentiment} disabled={isLoading} style={{ marginRight: '10px' }}>
            {isLoading ? 'Analyzing...' : 'Analyze Locally'}
          </button>
          <button onClick={simulateAPICall} disabled={isLoading}>
            Simulate API Call
          </button>
        </div>
      </div>

      {processingTime !== null && (
        <div style={{ background: '#eef', padding: '10px', borderRadius: '5px', marginBottom: '15px' }}>
          <strong>Local Processing Time:</strong> {processingTime.toFixed(2)}ms <br/>
          <small>(Compare to ~200ms + network overhead for API)</small>
        </div>
      )}

      {/* Visualization */}
      <div style={{ display: 'flex', alignItems: 'flex-end', height: '150px', gap: '10px', borderLeft: '1px solid #ccc', paddingLeft: '10px' }}>
        {results.map((res, idx) => {
          const height = res.score * 100;
          const color = res.label === 'POSITIVE' ? '#4caf50' : '#f44336';
          return (
            <div key={idx} style={{ textAlign: 'center', width: '40px' }}>
              <div style={{ 
                height: `${height}%`, 
                backgroundColor: color, 
                width: '100%',
                transition: 'height 0.5s'
              }} title={`${res.text}: ${res.score}`}></div>
              <div style={{ fontSize: '10px', marginTop: '5px' }}>{res.label}</div>
            </div>
          );
        })}
      </div>

      <div style={{ marginTop: '20px' }}>
        <h4>Detailed Results:</h4>
        <ul>
          {results.map((res, idx) => (
            <li key={idx}>
              <strong>{res.text}</strong>: {res.label} ({(res.score * 100).toFixed(1)}%)
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
};
