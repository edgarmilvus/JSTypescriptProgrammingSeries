/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part6.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState, useRef } from 'react';
import { pipeline } from '@xenova/transformers';

export const LocalTranscriber: React.FC = () => {
  const [isRecording, setIsRecording] = useState(false);
  const [transcription, setTranscription] = useState('');
  const [status, setStatus] = useState('Idle');
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const transcriberRef = useRef<any>(null);

  // Helper to decode audio buffer (simplified logic for browser environment)
  // In a full app, you might use a library like 'audio-buffer-utils' or Web Audio API
  const processAudio = async (audioBlob: Blob) => {
    setStatus('Processing Audio...');
    
    // 1. Load the model if not already loaded
    if (!transcriberRef.current) {
      setStatus('Loading Whisper Model...');
      // Using a smaller model for browser viability
      transcriberRef.current = await pipeline('automatic-speech-recognition', 'Xenova/whisper-tiny.en');
    }

    setStatus('Transcribing...');
    
    // 2. Pass the blob directly to the pipeline. 
    // Transformers.js pipeline for 'automatic-speech-recognition' accepts a Blob/File object
    // and handles the AudioContext decoding internally.
    try {
      const result = await transcriberRef.current(audioBlob, {
        // For longer audio, chunking might be needed, but whisper-tiny handles short clips well
        chunk_length_s: 30, 
        stride_length_s: 5,
      });
      
      setTranscription(result.text);
      setStatus('Done');
    } catch (err) {
      console.error("Transcription error:", err);
      setStatus('Error');
    }
  };

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mediaRecorder = new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;
      audioChunksRef.current = [];

      mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          audioChunksRef.current.push(event.data);
        }
      };

      mediaRecorder.onstop = () => {
        const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/webm' });
        processAudio(audioBlob);
        // Stop all tracks to release microphone
        stream.getTracks().forEach(track => track.stop());
      };

      mediaRecorder.start();
      setIsRecording(true);
      setStatus('Recording...');
    } catch (err) {
      console.error("Error accessing microphone:", err);
      setStatus('Microphone access denied');
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
    }
  };

  return (
    <div style={{ padding: '20px', maxWidth: '600px', margin: '0 auto', textAlign: 'center' }}>
      <h2>Local Audio Transcriber</h2>
      
      <div style={{ marginBottom: '20px' }}>
        <button 
          onClick={isRecording ? stopRecording : startRecording}
          style={{ 
            padding: '10px 20px', 
            borderRadius: '50%', 
            backgroundColor: isRecording ? '#f44336' : '#4caf50', 
            color: 'white', 
            border: 'none',
            cursor: 'pointer',
            width: '60px',
            height: '60px',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            margin: '0 auto'
          }}
          title={isRecording ? "Stop Recording" : "Start Recording"}
        >
          {isRecording ? '■' : '🎤'}
        </button>
        <p style={{ marginTop: '10px' }}>{status}</p>
      </div>

      <div style={{ textAlign: 'left' }}>
        <h3>Transcription:</h3>
        <textarea 
          value={transcription} 
          onChange={(e) => setTranscription(e.target.value)}
          rows={8} 
          style={{ width: '100%', padding: '10px', border: '1px solid #ccc' }}
          placeholder="Transcription will appear here..."
        />
        <div style={{ marginTop: '10px' }}>
          <button onClick={() => navigator.clipboard.writeText(transcription)}>Copy Text</button>
          <button onClick={() => setTranscription('')} style={{ marginLeft: '10px' }}>Clear</button>
        </div>
      </div>
    </div>
  );
};
