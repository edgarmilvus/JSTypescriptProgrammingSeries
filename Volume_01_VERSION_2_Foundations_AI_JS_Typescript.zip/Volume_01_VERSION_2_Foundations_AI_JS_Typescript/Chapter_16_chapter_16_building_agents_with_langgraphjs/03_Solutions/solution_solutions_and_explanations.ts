/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

import { StateGraph, END, START } from "@langchain/langgraph";
import { BaseMessage, HumanMessage, AIMessage } from "@langchain/core/messages";
import { ChatOpenAI } from "@langchain/openai";
import { z } from "zod";

// 1. Define the Zod State Schema
const AgentStateSchema = z.object({
  messages: z.array(z.instanceOf(BaseMessage)),
  iterations: z.number().default(0),
});

type AgentState = z.infer<typeof AgentStateSchema>;

// Initialize the LLM
const model = new ChatOpenAI({ model: "gpt-3.5-turbo" });

// 2. Create the thinkNode
async function thinkNode(state: AgentState): Promise<AgentState> {
  const { messages, iterations } = state;
  
  // Interactive Challenge: Include iteration count in prompt
  const systemPrompt = `You are on iteration ${iterations} of 5. 
  If you know the answer, respond with "Final Answer: [answer]". 
  If you need to perform an action, respond with "Action: [description]".
  Do not make up facts.`;

  const systemMessage = new HumanMessage(systemPrompt);
  const inputMessages = [systemMessage, ...messages];

  const response = await model.invoke(inputMessages);
  
  return {
    messages: [...messages, response],
    iterations: iterations + 1,
  };
}

// 3. Create the actNode
function actNode(state: AgentState): AgentState {
  const lastMessage = state.messages[state.messages.length - 1] as AIMessage;
  const content = lastMessage.content as string;

  // Simulate a tool call response
  if (content.includes("Action:")) {
    const toolMessage = new HumanMessage(`Tool Result: [Simulated result for action: "${content.replace("Action:", "").trim()}"]`);
    return {
      messages: [...state.messages, toolMessage],
      iterations: state.iterations,
    };
  }

  // If Final Answer, no change needed yet
  return state;
}

// 4. Define Conditional Edges
function router(state: AgentState): string {
  const lastMessage = state.messages[state.messages.length - 1] as AIMessage;
  const content = lastMessage.content as string;

  // Max Iteration Policy Guardrail
  if (state.iterations >= 5) {
    console.warn("Max iterations reached.");
    return "max_iterations_end";
  }

  if (content.includes("Action:")) {
    return "act";
  }
  
  if (content.includes("Final Answer:")) {
    return END;
  }

  // Fallback if LLM doesn't follow instructions
  return "act"; 
}

// 5. Build the Graph
const workflow = new StateGraph(AgentStateSchema);

workflow.addNode("thinkNode", thinkNode);
workflow.addNode("actNode", actNode);

workflow.addEdge(START, "thinkNode");
workflow.addConditionalEdges("thinkNode", router, {
  act: "actNode",
  [END]: END,
  max_iterations_end: END, // Terminates on max iterations
});
workflow.addEdge("actNode", "thinkNode");

export const graph = workflow.compile();

// --- Usage Example ---
// const result = await graph.invoke({
//   messages: [new HumanMessage("What is the capital of France?")],
//   iterations: 0,
// });
// console.log(result.messages[result.messages.length - 1].content);
