/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

import { StateGraph, END, START } from "@langchain/langgraph";
import { BaseMessage, HumanMessage, AIMessage, ToolMessage } from "@langchain/core/messages";
import { ChatOpenAI } from "@langchain/openai";
import { z } from "zod";
import { zodToJsonSchema } from "@langchain/core/utils/json_schema";

// 1. Update State Schema
const AgentStateSchema = z.object({
  messages: z.array(z.instanceOf(BaseMessage)),
  iterations: z.number().default(0),
  // New field for tracking tool calls explicitly if needed, though usually handled in messages
});

type AgentState = z.infer<typeof AgentStateSchema>;

// 2. Define Tools
const weatherToolSchema = z.object({
  city: z.string().describe("The city to get weather for"),
});

const getCurrentTimeSchema = z.object({
  timezone: z.string().describe("The timezone (e.g., America/New_York)"),
});

// Mock implementations
async function getWeather(args: z.infer<typeof weatherToolSchema>) {
  return `The weather in ${args.city} is sunny, 72°F.`;
}

async function getCurrentTime(args: z.infer<typeof getCurrentTimeSchema>) {
  return `Current time in ${args.timezone} is ${new Date().toLocaleTimeString()}.`;
}

// Bind tools to the model
const model = new ChatOpenAI({ model: "gpt-3.5-turbo" });
const tools = [
  {
    name: "getWeather",
    description: "Get the current weather for a city",
    schema: zodToJsonSchema(weatherToolSchema),
  },
  {
    name: "getCurrentTime",
    description: "Get the current time for a timezone",
    schema: zodToJsonSchema(getCurrentTimeSchema),
  },
];
const modelWithTools = model.bindTools(tools);

// 3. Modified thinkNode (Reasoning)
async function thinkNode(state: AgentState): Promise<AgentState> {
  const { messages } = state;
  const response = await modelWithTools.invoke(messages);
  return {
    messages: [...messages, response],
    iterations: state.iterations + 1,
  };
}

// 4. New toolNode (Execution)
async function toolNode(state: AgentState): Promise<AgentState> {
  const lastMessage = state.messages[state.messages.length - 1] as AIMessage;
  const toolMessages: ToolMessage[] = [];

  if (lastMessage.tool_calls?.length) {
    for (const toolCall of lastMessage.tool_calls) {
      let result = "Unknown tool";
      try {
        if (toolCall.name === "getWeather") {
          const args = weatherToolSchema.parse(JSON.parse(toolCall.args));
          result = await getWeather(args);
        } else if (toolCall.name === "getCurrentTime") {
          const args = getCurrentTimeSchema.parse(JSON.parse(toolCall.args));
          result = await getCurrentTime(args);
        }
      } catch (e) {
        result = `Error validating tool arguments: ${e}`;
      }
      
      toolMessages.push(new ToolMessage({
        content: result,
        tool_call_id: toolCall.id!,
      }));
    }
  }

  return {
    messages: [...state.messages, ...toolMessages],
    iterations: state.iterations,
  };
}

// 5. Conditional Edges
function router(state: AgentState): string {
  const lastMessage = state.messages[state.messages.length - 1];
  
  // If the last message is an AIMessage with tool calls, route to toolNode
  if (lastMessage instanceof AIMessage && lastMessage.tool_calls?.length) {
    return "toolNode";
  }
  
  // Otherwise, we are done (either final answer or error)
  return END;
}

// Build Graph
const workflow = new StateGraph(AgentStateSchema);
workflow.addNode("thinkNode", thinkNode);
workflow.addNode("toolNode", toolNode);

workflow.addEdge(START, "thinkNode");
workflow.addConditionalEdges("thinkNode", router, {
  toolNode: "toolNode",
  [END]: END,
});
workflow.addEdge("toolNode", "thinkNode");

export const graph = workflow.compile();

// --- Usage Example ---
// const result = await graph.invoke({
//   messages: [new HumanMessage("What is the weather in Tokyo and the current time in New York?")],
//   iterations: 0,
// });
// console.log(result.messages[result.messages.length - 1].content);
