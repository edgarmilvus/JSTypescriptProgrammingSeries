/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

import { StateGraph, END, START } from "@langchain/langgraph";
import { BaseMessage, HumanMessage, AIMessage } from "@langchain/core/messages";
import { ChatOpenAI } from "@langchain/openai";
import { z } from "zod";

// 1. Extended State Schema
const AgentStateSchema = z.object({
  messages: z.array(z.instanceOf(BaseMessage)),
  iterations: z.number().default(0),
  humanApproval: z.object({
    required: z.boolean().default(false),
    approved: z.boolean().optional(),
    actionDescription: z.string().optional(),
  }),
});

type AgentState = z.infer<typeof AgentStateSchema>;
const model = new ChatOpenAI({ model: "gpt-3.5-turbo" });

// 2. Decision Node (Simulating LLM output parsing)
function decisionNode(state: AgentState): AgentState {
  const lastMessage = state.messages[state.messages.length - 1] as AIMessage;
  const content = lastMessage.content as string;

  // Check for risky keywords
  const riskyKeywords = ["purchase", "delete", "send", "transfer"];
  const isRisky = riskyKeywords.some(keyword => content.toLowerCase().includes(keyword));

  if (isRisky) {
    return {
      ...state,
      humanApproval: {
        required: true,
        approved: false, // Waiting for approval
        actionDescription: content,
      },
    };
  }

  return {
    ...state,
    humanApproval: { required: false, approved: true },
  };
}

// 3. Approval Node (Simulating Human Interaction)
function approvalNode(state: AgentState): AgentState {
  console.log(`[HITL PAUSE] Action requested: "${state.humanApproval.actionDescription}"`);
  
  // Simulation: In a real app, this would pause and wait for an API call.
  // Here, we simulate a rejection for demonstration purposes.
  const humanDecision = false; // Set to true to approve

  if (!humanDecision) {
    console.log("[HITL] Human REJECTED the plan.");
    return {
      ...state,
      messages: [
        ...state.messages,
        new HumanMessage("Human rejected the plan. Please propose an alternative.")
      ],
      humanApproval: {
        required: false,
        approved: false,
      },
      iterations: state.iterations + 1,
    };
  }

  console.log("[HITL] Human APPROVED the plan.");
  return {
    ...state,
    humanApproval: {
      required: false,
      approved: true,
    },
  };
}

// 4. Think Node (Updated to handle rejection feedback)
async function thinkNode(state: AgentState): Promise<AgentState> {
  // If human rejected, the last message is the rejection instruction
  // If normal flow, we just invoke model
  const response = await model.invoke(state.messages);
  return {
    messages: [...state.messages, response],
    iterations: state.iterations + 1,
    humanApproval: { required: false, approved: true }, // Reset approval state
  };
}

// 5. Conditional Edges Router
function router(state: AgentState): string {
  // Max Iteration Guardrail
  if (state.iterations >= 3) {
    return "max_iterations_end";
  }

  // Logic for HITL
  if (state.humanApproval.required && !state.humanApproval.approved) {
    return "approvalNode";
  }

  // If we just came from approval node and was rejected, go back to think
  if (!state.humanApproval.required && state.humanApproval.approved === false) {
    return "thinkNode";
  }

  // Standard flow: check if we need to decide on approval
  const lastMessage = state.messages[state.messages.length - 1];
  if (lastMessage instanceof AIMessage) {
    // If we haven't run decision node yet for this AI message
    // In this simple graph structure, we route to decisionNode after thinkNode
    return "decisionNode";
  }

  return END;
}

// Build Graph
const workflow = new StateGraph(AgentStateSchema);
workflow.addNode("thinkNode", thinkNode);
workflow.addNode("decisionNode", decisionNode);
workflow.addNode("approvalNode", approvalNode);

workflow.addEdge(START, "thinkNode");
// Think -> Decision
workflow.addEdge("thinkNode", "decisionNode");

// Decision -> Conditional
workflow.addConditionalEdges("decisionNode", (state) => {
  if (state.humanApproval.required && !state.humanApproval.approved) return "approvalNode";
  if (state.iterations >= 3) return "max_iterations_end";
  return END; // No risky action needed
}, {
  approvalNode: "approvalNode",
  max_iterations_end: END,
  [END]: END,
});

// Approval -> Loop back or End
workflow.addConditionalEdges("approvalNode", (state) => {
  if (state.iterations >= 3) return "max_iterations_end";
  // If rejected, we added a message, so we need to think again
  return "thinkNode";
}, {
  thinkNode: "thinkNode",
  max_iterations_end: END,
});

export const graph = workflow.compile();

// --- Usage Example ---
// const result = await graph.invoke({
//   messages: [new HumanMessage("I want to delete all my files.")],
//   iterations: 0,
//   humanApproval: { required: false },
// });
