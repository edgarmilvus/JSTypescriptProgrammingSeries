/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part6.ts
// Description: Solutions and Explanations
// ==========================================

import { StateGraph, END, START } from "@langchain/langgraph";
import { BaseMessage, HumanMessage, AIMessage, ToolMessage } from "@langchain/core/messages";
import { ChatOpenAI } from "@langchain/openai";
import { z } from "zod";
import { Pool } from "pg"; // PostgreSQL client

// 1. Database Schema (Conceptual SQL)
/*
CREATE TABLE threads (id UUID PRIMARY KEY, created_at TIMESTAMP);
CREATE TABLE messages (
  id SERIAL PRIMARY KEY,
  thread_id UUID REFERENCES threads(id),
  role VARCHAR,
  content TEXT,
  tool_calls JSONB,
  timestamp TIMESTAMP
);
*/

// 2. Updated State Schema with Thread ID
const AgentStateSchema = z.object({
  threadId: z.string().uuid(),
  messages: z.array(z.instanceOf(BaseMessage)),
  iterations: z.number().default(0),
});

type AgentState = z.infer<typeof AgentStateSchema>;

// Database Client Setup (Mocked for this example)
const db = new Pool({ connectionString: process.env.DATABASE_URL });

// 3. Helper: Load State from DB
async function loadState(threadId: string): Promise<AgentState> {
  // In a real graph, this happens in the START node or middleware.
  // Here we simulate fetching messages.
  const res = await db.query(
    "SELECT role, content, tool_calls FROM messages WHERE thread_id = $1 ORDER BY timestamp ASC",
    [threadId]
  );
  
  const messages = res.rows.map(row => {
    if (row.role === 'user') return new HumanMessage(row.content);
    if (row.role === 'ai') return new AIMessage(row.content); // Simplified
    if (row.role === 'tool') return new ToolMessage({ content: row.content, tool_call_id: row.tool_calls?.id });
    return new HumanMessage(row.content);
  });

  return { threadId, messages, iterations: 0 };
}

// 4. Helper: Save State to DB
async function saveState(state: AgentState) {
  const lastMessage = state.messages[state.messages.length - 1];
  let role = 'user';
  if (lastMessage instanceof AIMessage) role = 'ai';
  if (lastMessage instanceof ToolMessage) role = 'tool';

  await db.query(
    "INSERT INTO messages (thread_id, role, content, tool_calls, timestamp) VALUES ($1, $2, $3, $4, NOW())",
    [state.threadId, role, lastMessage.content, (lastMessage as any).tool_calls || null]
  );
}

// 5. Vector Search Tool Node
async function vectorSearchNode(state: AgentState): Promise<AgentState> {
  // Extract query from the last AI message's tool call or user message
  // For simplicity, assume the last user message is the query
  const lastUserMessage = state.messages.filter(m => m instanceof HumanMessage).pop();
  const query = lastUserMessage?.content as string;

  // Simulate pgvector similarity search
  // SELECT content FROM knowledge_base ORDER BY embedding <=> query_embedding LIMIT 3;
  const searchResults = [
    "Product A: High durability, waterproof.",
    "Product B: Budget-friendly, lightweight.",
    "Product C: Premium material, 5-year warranty."
  ];

  const toolMessage = new ToolMessage({
    content: JSON.stringify(searchResults),
    tool_call_id: "search_123", // Would come from AIMessage tool_calls
  });

  return {
    ...state,
    messages: [...state.messages, toolMessage],
  };
}

// 6. Main Graph Execution Wrapper (Server Action)
export async function runThreadedAgent(threadId: string, userInput: string) {
  // Initialize or Load State
  let state = await loadState(threadId);
  
  // Append new user input
  state.messages.push(new HumanMessage(userInput));

  // Define Nodes (Simplified for example: think -> search -> end)
  const model = new ChatOpenAI({ model: "gpt-3.5-turbo" });
  
  // Node: Think (decides if search is needed)
  async function thinkNode(s: AgentState) {
    // In a real app, bind tools. Here we simulate intent.
    // If input contains "search", route to vectorSearchNode
    const needsSearch = s.messages[s.messages.length - 1].content?.includes("search");
    
    // We modify state to indicate intent for the router
    return { ...s, intent: needsSearch ? "search" : "answer" };
  }

  // Router
  function router(s: any) {
    return s.intent === "search" ? "vectorSearchNode" : END;
  }

  // Compile Graph
  const workflow = new StateGraph(AgentStateSchema);
  workflow.addNode("thinkNode", thinkNode);
  workflow.addNode("vectorSearchNode", vectorSearchNode);
  workflow.addEdge(START, "thinkNode");
  workflow.addConditionalEdges("thinkNode", router, { vectorSearchNode: "vectorSearchNode", [END]: END });
  
  const graph = workflow.compile();

  // Execute
  const result = await graph.invoke(state);

  // Persist Final State
  await saveState(result);

  // Return response (Last message content)
  const lastMsg = result.messages[result.messages.length - 1];
  return { response: lastMsg.content, threadId };
}
