/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

// multi-agent-demo.ts
// To run this file, ensure you have the following dependencies installed:
// npm install @langchain/core zod
// Run with: npx tsx multi-agent-demo.ts

import { z } from "zod";
import {
  BaseMessage,
  AIMessage,
  HumanMessage,
  SystemMessage,
} from "@langchain/core/messages";
import { BaseTool, ToolParams } from "@langchain/core/tools";
import { BaseLLM } from "@langchain/core/language_models/base";
import { CallbackManagerForLLMRun } from "@langchain/core/callbacks/manager";
import { Generation } from "@langchain/core/outputs";

// ==========================================
// 1. MOCK INFRASTRUCTURE (Simulating OpenAI)
// ==========================================

/**
 * A mock implementation of a Large Language Model (LLM).
 * In a real app, this would be replaced by `new ChatOpenAI({ model: "gpt-4o" })`.
 * We extend BaseLLM to satisfy LangChain's type requirements.
 */
class MockLLM extends BaseLLM {
  _llmType(): string {
    return "mock_llm";
  }

  async _generate(
    prompts: string[],
    runManager?: CallbackManagerForLLMRun
  ): Promise<{ generations: Generation[][] }> {
    // Simulate network latency
    await new Promise((resolve) => setTimeout(resolve, 500));

    const responseText = this.simulateReasoning(prompts[0]);
    
    return {
      generations: [
        [
          {
            text: responseText,
            generationInfo: { finish_reason: "stop" },
          },
        ],
      ],
    };
  }

  /**
   * Hardcoded logic to simulate an LLM's reasoning process.
   * This prevents hallucinations in our demo and ensures predictable output.
   */
  private simulateReasoning(prompt: string): string {
    if (prompt.includes("Researcher") && prompt.includes("fetch_tickets")) {
      return JSON.stringify({
        action: "fetch_tickets",
        action_input: { date_range: "last_7_days" },
      });
    }
    
    if (prompt.includes("Analyst") && prompt.includes("summarize")) {
      return JSON.stringify({
        action: "final_report",
        action_input: { 
          summary: "Overall sentiment is positive (70%), but users are confused about the new dashboard layout.",
          email_draft: "Subject: Weekly Feedback Summary\n\nHi Team, here is the analysis..." 
        },
      });
    }

    // Default fallback
    return "I am thinking...";
  }
}

// ==========================================
// 2. DEFINING TOOLS (Agent Capabilities)
// ==========================================

/**
 * Tool: Fetch Support Tickets
 * Simulates fetching data from a SaaS database.
 */
class FetchTicketsTool extends BaseTool {
  name = "fetch_tickets";
  description = "Fetches recent customer support tickets from the database.";
  
  // Zod schema ensures the LLM provides structured input
  schema = z.object({
    date_range: z.string().describe("e.g., 'last_7_days' or 'today'"),
  });

  async _call(input: z.infer<typeof this.schema>) {
    console.log(`   [Tool: FetchTickets] Fetching data for range: ${input.date_range}...`);
    // Simulated database response
    return JSON.stringify([
      { id: 1, text: "Loving the new update!", sentiment: "positive" },
      { id: 2, text: "Dashboard is confusing.", sentiment: "negative" },
      { id: 3, text: "Great support response time.", sentiment: "positive" },
    ]);
  }
}

/**
 * Tool: Send Email
 * Simulates sending a notification via an API (e.g., SendGrid, Resend).
 */
class SendEmailTool extends BaseTool {
  name = "send_email";
  description = "Sends an email to the internal product team.";
  
  schema = z.object({
    recipient: z.string().email(),
    subject: z.string(),
    body: z.string(),
  });

  async _call(input: z.infer<typeof this.schema>) {
    console.log(`   [Tool: SendEmail] Sending email to ${input.recipient}...`);
    return "Email sent successfully.";
  }
}

// ==========================================
// 3. AGENT CLASS DEFINITIONS
// ==========================================

/**
 * Base Agent Class
 * Encapsulates the logic of taking a prompt, invoking the LLM, 
 * and parsing the output (usually JSON for tool calls).
 */
abstract class BaseAgent {
  protected llm: BaseLLM;
  protected systemPrompt: string;

  constructor(llm: BaseLLM, systemPrompt: string) {
    this.llm = llm;
    this.systemPrompt = systemPrompt;
  }

  /**
   * Core execution loop for the agent.
   * 1. Construct full prompt (System + User input)
   * 2. Invoke LLM
   * 3. Parse JSON response
   */
  async execute(input: string): Promise<any> {
    const fullPrompt = `${this.systemPrompt}\n\nUser Request: ${input}`;
    
    console.log(`\n[Agent: ${this.constructor.name}] Thinking...`);
    
    // In a real LangChain agent, this would be `llm.invoke` with output parsing
    const response = await this.llm.invoke(fullPrompt);
    
    try {
      // Attempt to parse the simulated LLM response as JSON
      const parsed = JSON.parse(response);
      return parsed;
    } catch (e) {
      console.error("Failed to parse LLM response as JSON.");
      return null;
    }
  }
}

/**
 * The Orchestrator Agent (Manager)
 * Decides which sub-agent or tool to delegate tasks to.
 */
class OrchestratorAgent extends BaseAgent {
  constructor(llm: BaseLLM) {
    const prompt = `
      You are an Orchestrator Agent for a SaaS support dashboard.
      Your goal is to route tasks to the correct specialist.
      
      Available Specialists:
      1. "Researcher": Use this to fetch data (tickets).
      2. "Analyst": Use this to summarize data and draft emails.
      
      Output ONLY a JSON object with the following structure:
      {
        "next_agent": "Researcher" | "Analyst" | "FINISH",
        "context": "Any data needed for the next agent"
      }
    `;
    super(llm, prompt);
  }
}

/**
 * The Researcher Agent (Worker)
 * Specialized in data retrieval.
 */
class ResearcherAgent extends BaseAgent {
  private tools: BaseTool[];

  constructor(llm: BaseLLM, tools: BaseTool[]) {
    const prompt = `
      You are a Researcher Agent. You have access to tools.
      If the user asks for data, use the "fetch_tickets" tool.
      Output ONLY a JSON object representing the tool call:
      {
        "action": "fetch_tickets",
        "action_input": { "date_range": "last_7_days" }
      }
    `;
    super(llm, prompt);
    this.tools = tools;
  }

  async execute(input: string): Promise<any> {
    const result = await super.execute(input);
    
    // Check if the LLM wants to use a tool
    if (result && result.action) {
      const tool = this.tools.find((t) => t.name === result.action);
      if (tool) {
        return await tool.invoke(result.action_input);
      }
    }
    return result;
  }
}

/**
 * The Analyst Agent (Worker)
 * Specialized in processing data and generating text.
 */
class AnalystAgent extends BaseAgent {
  constructor(llm: BaseLLM) {
    const prompt = `
      You are an Analyst Agent. You receive raw ticket data.
      Analyze the sentiment and draft a summary email.
      Output ONLY a JSON object:
      {
        "action": "final_report",
        "action_input": {
          "summary": "Brief analysis...",
          "email_draft": "Subject: ...\n\nBody: ..."
        }
      }
    `;
    super(llm, prompt);
  }
}

// ==========================================
// 4. MAIN EXECUTION FLOW (The System)
// ==========================================

/**
 * The Multi-Agent System Orchestrator
 * Manages the state and flow of messages between agents.
 */
async function runMultiAgentSystem() {
  // 1. Initialize Infrastructure
  const llm = new MockLLM();
  const fetchTool = new FetchTicketsTool();
  
  // 2. Initialize Agents
  const researcher = new ResearcherAgent(llm, [fetchTool]);
  const analyst = new AnalystAgent(llm);
  const orchestrator = new OrchestratorAgent(llm);

  // 3. Define the User Request (SaaS Context)
  const userRequest = "Analyze sentiment of recent tickets and draft an email.";

  // 4. Execution Loop
  console.log("🚀 Starting Multi-Agent System...");
  console.log(`📝 User Request: "${userRequest}"`);

  // --- Step A: Orchestrator decides the first step ---
  const orchestratorDecision = await orchestrator.execute(userRequest);
  console.log(`[Orchestrator] Decided: ${orchestratorDecision.next_agent}`);

  // --- Step B: Delegate to Researcher ---
  if (orchestratorDecision.next_agent === "Researcher") {
    const rawData = await researcher.execute(
      `Fetch tickets for ${orchestratorDecision.context || "last_7_days"}`
    );
    
    // --- Step C: Delegate to Analyst ---
    // Pass the raw data from Researcher to Analyst
    const analysisResult = await analyst.execute(
      `Analyze this data: ${rawData}`
    );

    // --- Step D: Final Action (Send Email) ---
    if (analysisResult.action === "final_report") {
      const emailTool = new SendEmailTool();
      const emailInput = analysisResult.action_input;
      
      await emailTool.invoke({
        recipient: "product-team@saas-company.com",
        subject: emailInput.email_draft.split('\n')[0].replace('Subject: ', ''),
        body: emailInput.email_draft,
      });
    }
  }

  console.log("\n✅ Workflow Completed Successfully.");
}

// Execute the system
runMultiAgentSystem().catch(console.error);
