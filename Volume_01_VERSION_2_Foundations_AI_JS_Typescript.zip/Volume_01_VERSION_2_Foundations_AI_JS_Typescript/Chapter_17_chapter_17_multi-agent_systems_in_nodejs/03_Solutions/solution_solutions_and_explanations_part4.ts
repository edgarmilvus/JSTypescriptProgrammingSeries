/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

import { Tool } from "@langchain/core/tools";
import { ChatOpenAI } from "@langchain/openai";
import { initializeAgentExecutorWithOptions } from "langchain/agents";
import { PromptTemplate } from "@langchain/core/prompts";

// 1. Unreliable API Simulation
async function unreliableApiCall(): Promise<string> {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      // 50% chance of success or failure
      if (Math.random() > 0.5) {
        resolve("Success: Data retrieved from external API.");
      } else {
        reject(new Error("Connection timeout to Database"));
      }
    }, 500);
  });
}

// 2. Safe Tool Wrapper
class SafeFetcherTool extends Tool {
  name = "safe_fetcher";
  description = "Fetches data from an external source. Input: a generic query string.";

  async _call(input: string): Promise<string> {
    try {
      // 3. Try/Catch Block
      const result = await unreliableApiCall();
      return result;
    } catch (err: any) {
      // 4. Error Return Format
      // We format the error specifically for the LLM to parse
      return `ERROR: ${err.message}`;
    }
  }
}

// 5. Execution Script
export async function runSafeFetcherTest() {
  const llm = new ChatOpenAI({ temperature: 0 });
  const tools = [new SafeFetcherTool()];

  // 4. Agent Prompting: Instructing the model on how to handle errors
  const prompt = PromptTemplate.fromTemplate(`
    You are a helpful assistant. You must fetch data using the 'safe_fetcher' tool.
    If you receive an error message starting with "ERROR:", acknowledge the failure and suggest a fallback action (e.g., "I will try again" or "System is down").
    
    Input: {input}
  `);

  // Initialize Agent
  const executor = await initializeAgentExecutorWithOptions(tools, llm, {
    agentType: "zero-shot-react-description",
    prompt: prompt, // Injecting our custom prompt
  });

  console.log("--- Starting Error Handling Test (5 runs) ---");

  // Run 5 times
  for (let i = 1; i <= 5; i++) {
    console.log(`\nRun ${i}:`);
    try {
      const result = await executor.invoke({ input: "Fetch the latest user data." });
      console.log("Agent Output:", result.output);
    } catch (error) {
      // This catch block prevents the script from crashing on unhandled rejections
      console.error("CRITICAL AGENT FAILURE:", error);
    }
  }
}
