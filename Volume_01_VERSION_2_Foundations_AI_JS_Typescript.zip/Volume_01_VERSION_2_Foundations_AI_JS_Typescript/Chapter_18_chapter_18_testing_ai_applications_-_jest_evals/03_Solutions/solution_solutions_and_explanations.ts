/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// inputProcessor.test.ts

import { sanitizeInput, formatContext, Message } from './inputProcessor';

describe('Input Processor Utilities', () => {
  
  describe('sanitizeInput', () => {
    it('should remove leading and trailing whitespace', () => {
      const input = '   Hello World   ';
      const result = sanitizeInput(input);
      expect(result).toBe('Hello World');
    });

    it('should remove standard script tags', () => {
      const input = "Hello <script>alert('xss')</script> World";
      const result = sanitizeInput(input);
      expect(result).toBe('Hello  World');
    });

    it('should remove complex nested or malformed script tags', () => {
      const input = "Start <script type='text/javascript'>alert('bad');</script> End";
      const result = sanitizeInput(input);
      expect(result).toBe('Start  End');
    });

    it('should preserve benign content without script tags', () => {
      const input = 'Just a normal string with <div>html</div>.';
      const result = sanitizeInput(input);
      // Note: The regex specifically targets script tags, divs should remain
      expect(result).toBe('Just a normal string with <div>html</div>.');
    });
  });

  describe('formatContext', () => {
    it('should handle an empty array', () => {
      const history: Message[] = [];
      const result = formatContext(history);
      expect(result).toBe('');
    });

    it('should format a single user message correctly', () => {
      const history: Message[] = [{ role: 'user', content: 'Hello' }];
      const result = formatContext(history);
      expect(result).toBe('USER: Hello');
    });

    it('should format a multi-turn conversation history', () => {
      const history: Message[] = [
        { role: 'user', content: 'Hi there' },
        { role: 'assistant', content: 'Hello! How can I help?' },
        { role: 'user', content: 'Tell me a joke.' }
      ];
      const result = formatContext(history);
      
      // Using snapshot testing to guard against formatting changes
      expect(result).toMatchSnapshot();
      
      // Also verify exact string match for clarity
      const expected = "USER: Hi there\nASSISTANT: Hello! How can I help?\nUSER: Tell me a joke.";
      expect(result).toBe(expected);
    });
  });
});
