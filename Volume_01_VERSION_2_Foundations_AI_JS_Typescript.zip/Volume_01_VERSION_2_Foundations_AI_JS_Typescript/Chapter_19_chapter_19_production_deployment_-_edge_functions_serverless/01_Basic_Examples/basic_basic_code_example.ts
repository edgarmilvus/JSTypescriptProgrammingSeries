/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

// app/page.tsx (Client Component)
'use client';

import { useState, FormEvent } from 'react';

/**
 * Home Page Component
 * 
 * Renders a simple form for submitting prompts to the AI.
 * Handles client-side state for the prompt and the streamed response.
 * 
 * @returns {JSX.Element} The rendered component.
 */
export default function Home() {
  const [prompt, setPrompt] = useState(''); // User's input prompt
  const [response, setResponse] = useState(''); // Streamed AI response
  const [isLoading, setIsLoading] = useState(false); // Loading state for UI feedback

  /**
   * Handles form submission.
   * 
   * Uses the Fetch API to call the Edge Function endpoint.
   * Reads the response as a stream and updates the state incrementally.
   * 
   * @param {FormEvent<HTMLFormElement>} e - The form submission event.
   */
  const handleSubmit = async (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!prompt.trim()) return;

    setIsLoading(true);
    setResponse(''); // Clear previous response

    try {
      // Call the Edge API route
      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt }),
      });

      if (!res.ok) {
        throw new Error(`HTTP error! status: ${res.status}`);
      }

      // Get the reader from the response body
      const reader = res.body?.getReader();
      if (!reader) {
        throw new Error('No readable stream available');
      }

      // Decode and accumulate the streamed chunks
      const decoder = new TextDecoder();
      let accumulatedResponse = '';

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        // Decode the chunk and append to the accumulated response
        const chunk = decoder.decode(value, { stream: true });
        accumulatedResponse += chunk;
        setResponse(accumulatedResponse); // Update UI with the latest chunk
      }
    } catch (error) {
      console.error('Error fetching response:', error);
      setResponse('An error occurred while generating the response.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div style={{ padding: '2rem', fontFamily: 'sans-serif' }}>
      <h1>AI Chat Stream</h1>
      <form onSubmit={handleSubmit}>
        <input
          type="text"
          value={prompt}
          onChange={(e) => setPrompt(e.target.value)}
          placeholder="Enter your prompt..."
          disabled={isLoading}
          style={{ width: '300px', padding: '0.5rem', marginRight: '0.5rem' }}
        />
        <button type="submit" disabled={isLoading}>
          {isLoading ? 'Generating...' : 'Send'}
        </button>
      </form>
      <div style={{ marginTop: '1rem', whiteSpace: 'pre-wrap', border: '1px solid #ccc', padding: '1rem', minHeight: '100px' }}>
        <strong>Response:</strong>
        {response}
      </div>
    </div>
  );
}
