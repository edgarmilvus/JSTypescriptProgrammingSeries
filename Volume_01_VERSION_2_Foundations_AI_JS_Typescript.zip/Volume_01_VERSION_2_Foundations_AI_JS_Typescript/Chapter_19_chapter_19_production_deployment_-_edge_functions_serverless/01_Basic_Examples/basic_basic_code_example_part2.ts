/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.ts
// Description: Basic Code Example
// ==========================================

// app/api/chat/route.ts (Edge API Route)
import { NextRequest, NextResponse } from 'next/server';
import OpenAI from 'openai';

/**
 * Edge Function for Streaming Chat Response
 * 
 * This route handles POST requests to generate a streaming response from OpenAI.
 * It uses the Edge Runtime for low-latency processing and streaming.
 * 
 * @param {NextRequest} req - The incoming HTTP request.
 * @returns {NextResponse} A streaming response or an error response.
 */
export async function POST(req: NextRequest) {
  // Validate environment variable
  const apiKey = process.env.OPENAI_API_KEY;
  if (!apiKey) {
    return NextResponse.json(
      { error: 'OPENAI_API_KEY is not set' },
      { status: 500 }
    );
  }

  // Parse the request body
  const { prompt } = await req.json();
  if (!prompt || typeof prompt !== 'string') {
    return NextResponse.json(
      { error: 'Invalid or missing prompt' },
      { status: 400 }
    );
  }

  try {
    // Initialize OpenAI client
    const openai = new OpenAI({
      apiKey,
      // Use the Edge-compatible fetch (Next.js handles this automatically)
    });

    // Create a streaming completion
    const stream = await openai.chat.completions.create({
      model: 'gpt-3.5-turbo', // Use a cost-effective model for demo
      messages: [
        {
          role: 'system',
          content: 'You are a helpful assistant. Respond concisely.',
        },
        { role: 'user', content: prompt },
      ],
      stream: true, // Enable streaming
      max_tokens: 100, // Limit for demo purposes
    });

    // Convert the OpenAI stream to a Web ReadableStream
    const encoder = new TextEncoder();
    const readableStream = new ReadableStream({
      async start(controller) {
        try {
          for await (const chunk of stream) {
            const content = chunk.choices[0]?.delta?.content || '';
            if (content) {
              // Encode and enqueue the chunk
              controller.enqueue(encoder.encode(content));
            }
          }
          controller.close();
        } catch (error) {
          console.error('Streaming error:', error);
          controller.error(error);
        }
      },
    });

    // Return the streaming response
    return new NextResponse(readableStream, {
      headers: {
        'Content-Type': 'text/plain; charset=utf-8',
        'Cache-Control': 'no-cache, no-transform', // Prevent caching for dynamic content
        'Connection': 'keep-alive',
      },
    });
  } catch (error) {
    console.error('API Error:', error);
    return NextResponse.json(
      { error: 'Failed to generate response' },
      { status: 500 }
    );
  }
}
