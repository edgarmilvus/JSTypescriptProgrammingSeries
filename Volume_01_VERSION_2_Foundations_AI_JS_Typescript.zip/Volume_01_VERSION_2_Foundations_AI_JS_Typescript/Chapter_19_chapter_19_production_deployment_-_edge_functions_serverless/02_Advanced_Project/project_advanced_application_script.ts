/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

/**
 * File: app/api/chat/route.ts
 * 
 * Objective: Implement a serverless Edge Function to handle AI chat requests.
 * Architecture: 
 * - Uses Edge Runtime for low latency.
 * - Implements SRP by isolating storage logic from AI logic.
 * - Uses Streaming to improve perceived performance.
 */

import { NextRequest, NextResponse } from 'next/server';
import { StreamingTextResponse, LangChainStream } from 'ai';
import { ChatOpenAI } from '@langchain/openai';
import { DynamicTool, ZodOutputParser } from '@langchain/core/output_parsers';
import { z } from 'zod';

// --- 1. DATA LAYER: Edge Storage Adapter (SRP: Data Persistence) ---
// This module has a single responsibility: managing conversation state.
// It abstracts the underlying storage provider (Vercel Edge Config).

import { kv } from '@vercel/kv'; // Serverless Redis for Vercel Edge

/**
 * Interface defining the contract for chat history storage.
 */
export interface ChatHistoryStore {
  getSessionHistory(sessionId: string): Promise<Array<{ role: string; content: string }>>;
  saveMessage(sessionId: string, role: 'user' | 'assistant', content: string): Promise<void>;
}

/**
 * Vercel KV Implementation of the ChatHistoryStore.
 * Under the hood: Uses Upstash Redis, optimized for edge access.
 */
export const kvChatHistory: ChatHistoryStore = {
  async getSessionHistory(sessionId: string) {
    // Retrieve the list of messages for the specific session ID
    // Key structure: `chat:${sessionId}:messages`
    const history = await kv.lrange(`chat:${sessionId}:messages`, 0, -1);
    return history.map((msg) => JSON.parse(msg));
  },

  async saveMessage(sessionId: string, role: 'user' | 'content', content: string) {
    const message = JSON.stringify({ role, content });
    // Push to list with a TTL (Time To Live) to manage costs/privacy
    await kv.lpush(`chat:${sessionId}:messages`, message);
    await kv.expire(`chat:${sessionId}:messages`, 3600); // Keep for 1 hour
  },
};

// --- 2. LOGIC LAYER: Function Calling Schema & AI Logic (SRP: Business Logic) ---
// This module defines the "tools" available to the LLM and handles inference.

/**
 * Zod Schema for Function Calling.
 * Defines the strict structure of data the LLM can request to generate.
 * This acts as our "Function Calling Schema".
 */
const WeatherInputSchema = z.object({
  location: z.string().describe("The city and state, e.g. San Francisco, CA"),
  unit: z.enum(["celsius", "fahrenheit"]).describe("The unit of temperature"),
});

/**
 * Dynamic Tool Definition for the LLM.
 * Connects the Zod schema to a concrete implementation.
 */
const weatherTool = new DynamicTool({
  name: "get_current_weather",
  description: "Get the current weather in a given location",
  func: async (input: string) => {
    // In a real app, we would parse 'input' using Zod here.
    // For demo, we simulate a deterministic API response.
    return JSON.stringify({
      location: input,
      temperature: "72",
      unit: "fahrenheit",
      forecast: ["sunny", "windy"],
    });
  },
  returnDirect: true, // Return tool result directly to user
  schema: WeatherInputSchema,
});

/**
 * Core AI Service.
 * SRP: Handles LLM initialization and prompt engineering.
 */
export class AIService {
  private model: ChatOpenAI;

  constructor(apiKey: string) {
    // Initialize with Edge-compatible settings (no streaming in model config, handled by Vercel AI SDK)
    this.model = new ChatOpenAI({
      modelName: "gpt-3.5-turbo-0125",
      openAIApiKey: apiKey,
      temperature: 0.7,
    });
  }

  /**
   * Generates a response based on history and current input.
   * @param history - Array of previous messages
   * @param input - Current user input
   */
  async generateResponse(history: Array<{ role: string; content: string }>, input: string) {
    // Bind the tool to the model instance
    const modelWithTools = this.model.bindTools([weatherTool]);
    
    // Construct the prompt messages
    const messages = [
      ...history,
      { role: "user" as const, content: input },
    ];

    // Invoke the model
    return modelWithTools.invoke(messages);
  }
}

// --- 3. API LAYER: Edge Route Handler (SRP: HTTP/Transport) ---
// This module handles the HTTP request/response cycle and orchestration.

export const runtime = 'edge'; // Use Edge Runtime for lower latency

export async function POST(req: NextRequest) {
  const { message, sessionId } = await req.json();

  if (!message || !sessionId) {
    return new NextResponse("Missing message or sessionId", { status: 400 });
  }

  // 1. Retrieve History (Data Layer)
  const history = await kvChatHistory.getSessionHistory(sessionId);

  // 2. Initialize AI Service (Logic Layer)
  // Ensure OPENAI_API_KEY is set in Vercel environment variables
  const aiService = new AIService(process.env.OPENAI_API_KEY || "");

  // 3. Generate Response
  // We use the Vercel AI SDK's LangChainStream adapter for easy streaming
  const { stream, handlers } = LangChainStream();

  // We trigger the generation asynchronously. 
  // The stream will be piped to the client response.
  aiService
    .generateResponse(history, message)
    .then(async (response) => {
      // Handle the AI response
      if (typeof response.content === 'string') {
        // Standard text response
        await kvChatHistory.saveMessage(sessionId, 'user', message);
        await kvChatHistory.saveMessage(sessionId, 'assistant', response.content);
      } else if (response.additional_kwargs?.tool_calls) {
        // Handle Tool Call (Function Calling)
        // In a real streaming scenario, we might stream the tool call event.
        // Here we simulate the tool execution result being saved to history.
        const toolResult = await weatherTool.invoke(JSON.stringify(response.additional_kwargs.tool_calls[0].function.arguments));
        await kvChatHistory.saveMessage(sessionId, 'user', message);
        await kvChatHistory.saveMessage(sessionId, 'assistant', `Tool Result: ${toolResult}`);
      }
    })
    .catch(console.error);

  // 4. Return Streamed Response
  return new StreamingTextResponse(stream);
}
