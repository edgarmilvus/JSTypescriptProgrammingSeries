/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.tsx
// Description: Solutions and Explanations
// ==========================================

// File: components/StreamingChat.tsx
import React, { useState, useEffect, useRef } from 'react';

// Define types for the component state
interface ChatMessage {
  role: 'user' | 'assistant';
  content: string;
}

interface StreamChunk {
  content?: string;
  error?: string;
}

export function StreamingChat() {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  
  // Use a ref to store the accumulated stream text
  const accumulatedContentRef = useRef<string>('');

  const handleSend = async () => {
    if (!input.trim()) return;

    const userMessage: ChatMessage = { role: 'user', content: input };
    setMessages((prev) => [...prev, userMessage]);
    setInput('');
    setIsLoading(true);
    setError(null);
    accumulatedContentRef.current = '';

    // AbortController for cleanup and cancellation
    const controller = new AbortController();

    try {
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: input }),
        signal: controller.signal,
      });

      if (!response.ok || !response.body) {
        throw new Error(response.statusText || 'Failed to fetch');
      }

      const reader = response.body.getReader();
      const decoder = new TextDecoder();

      // Process the stream
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        const chunkText = decoder.decode(value, { stream: true });
        
        // Simulate parsing JSON chunks or plain text. 
        // For this example, we assume the stream sends raw text chunks.
        // If it were JSON, we would parse it here.
        accumulatedContentRef.current += chunkText;

        // Update state efficiently. 
        // We create a new object only when the stream updates.
        setMessages((prev) => {
          const lastMessage = prev[prev.length - 1];
          if (lastMessage && lastMessage.role === 'assistant') {
            // Update existing assistant message
            const newMessages = [...prev];
            newMessages[newMessages.length - 1] = {
              role: 'assistant',
              content: accumulatedContentRef.current,
            };
            return newMessages;
          } else {
            // Append new assistant message
            return [...prev, { role: 'assistant', content: accumulatedContentRef.current }];
          }
        });
      }
    } catch (err: any) {
      if (err.name === 'AbortError') {
        console.log('Fetch aborted');
      } else {
        setError(err.message || 'An error occurred');
      }
    } finally {
      setIsLoading(false);
      controller.abort(); // Clean up the signal
    }
  };

  const handleRetry = () => {
    setError(null);
    // Retry the last user message if available
    const lastUserMessage = messages.findLast((m) => m.role === 'user');
    if (lastUserMessage) {
      setInput(lastUserMessage.content);
      handleSend();
    }
  };

  return (
    <div style={{ padding: '20px', maxWidth: '600px', margin: '0 auto' }}>
      <div style={{ border: '1px solid #ccc', minHeight: '300px', padding: '10px', marginBottom: '10px' }}>
        {messages.map((msg, idx) => (
          <div key={idx} style={{ marginBottom: '8px', textAlign: msg.role === 'user' ? 'right' : 'left' }}>
            <strong>{msg.role === 'user' ? 'You' : 'AI'}: </strong>
            <span>{msg.content}</span>
          </div>
        ))}
        {isLoading && <div style={{ fontStyle: 'italic', color: '#888' }}>Typing...</div>}
      </div>

      {error && (
        <div style={{ color: 'red', marginBottom: '10px' }}>
          Error: {error}
          <button onClick={handleRetry} style={{ marginLeft: '10px' }}>Retry</button>
        </div>
      )}

      <div style={{ display: 'flex', gap: '10px' }}>
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && handleSend()}
          disabled={isLoading}
          style={{ flex: 1, padding: '8px' }}
          placeholder="Type a message..."
        />
        <button onClick={handleSend} disabled={isLoading} style={{ padding: '8px 16px' }}>
          Send
        </button>
      </div>
    </div>
  );
}
