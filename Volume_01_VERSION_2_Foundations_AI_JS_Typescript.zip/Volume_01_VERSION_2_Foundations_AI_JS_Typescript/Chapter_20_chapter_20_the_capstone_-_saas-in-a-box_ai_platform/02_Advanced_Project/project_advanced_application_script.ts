/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// src/app/api/analyze-document/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import { OpenAI } from '@langchain/openai';
import { AgentExecutor, createOpenAIFunctionsAgent } from 'langchain/agents';
import { DynamicStructuredTool } from '@langchain/core/tools';
import { ChatPromptTemplate } from '@langchain/core/prompts';
import { StreamingTextResponse } from 'ai'; // Vercel AI SDK

// ============================================================================
// 1. SCHEMA VALIDATION (Zod)
// ============================================================================

/**
 * Validates the incoming request payload from the client.
 * Ensures the document ID and user query are present and correctly formatted.
 */
const RequestSchema = z.object({
  documentId: z.string().uuid("Document ID must be a valid UUID"),
  query: z.string().min(1, "Query cannot be empty").max(500, "Query too long"),
  tenantId: z.string().uuid("Tenant ID is required for multi-tenancy"),
});

/**
 * Validates the output of the 'retrieve_document_content' tool.
 * Ensures the simulated database returns structured data.
 */
const DocumentContentSchema = z.object({
  content: z.string().min(1),
  metadata: z.object({
    title: z.string(),
    author: z.string(),
    version: z.number(),
  }),
});

// ============================================================================
// 2. TOOL DEFINITIONS (LangChain.js)
// ============================================================================

/**
 * Simulates a secure database lookup for document content.
 * In a real SaaS app, this would query a PostgreSQL/Prisma database 
 * with row-level security (RLS) based on the tenantId.
 * 
 * @param documentId - The UUID of the document to fetch.
 * @param tenantId - The multi-tenant context.
 * @returns Structured document data.
 */
const retrieveDocumentContent = async (documentId: string, tenantId: string) => {
  // Simulate DB latency
  await new Promise(resolve => setTimeout(resolve, 300));

  // Mock data retrieval
  const mockData = {
    content: `
      CLAUSE 1: Liability. The Service Provider shall not be liable for indirect damages.
      CLAUSE 2: Termination. Either party may terminate with 30 days written notice.
      CLAUSE 3: Payment. Invoices are due net 30. Late fees apply at 5% monthly.
      // NOTE: Missing Force Majeure clause.
    `,
    metadata: {
      title: "Service Agreement v2.1",
      author: "Legal Dept",
      version: 2.1,
    },
  };

  // Validate output using Zod to prevent tool poisoning or bad data
  try {
    return DocumentContentSchema.parse(mockData);
  } catch (error) {
    throw new Error(`Data validation failed for document ${documentId}`);
  }
};

/**
 * Initializes the tools available to the agent.
 * Tools are the "hands" of the agent, allowing it to interact with external systems.
 */
const initializeTools = () => {
  const documentTool = new DynamicStructuredTool({
    name: "retrieve_document_content",
    description: "Fetches the full text content and metadata of a specific document. Use this when you need to read the actual text of a contract or file.",
    schema: z.object({
      documentId: z.string().uuid(),
      tenantId: z.string().uuid(),
    }),
    func: async ({ documentId, tenantId }) => {
      const data = await retrieveDocumentContent(documentId, tenantId);
      // Return a stringified version for the LLM context window
      return JSON.stringify(data);
    },
  });

  return [documentTool];
};

// ============================================================================
// 3. AGENT ORCHESTRATION
// ============================================================================

/**
 * Main Route Handler for the API Endpoint.
 * Handles the request, sets up the agent, and streams the response.
 */
export async function POST(req: NextRequest) {
  try {
    // 1. Parse and Validate Input
    const body = await req.json();
    const { documentId, query, tenantId } = RequestSchema.parse(body);

    // 2. Initialize LLM (LangChain wrapper around OpenAI)
    // Temperature 0 ensures deterministic behavior for structured tasks
    const llm = new OpenAI({
      modelName: "gpt-4-turbo-preview",
      temperature: 0,
      streaming: true, // Essential for Vercel AI SDK integration
    });

    // 3. Define the Agent Prompt (System Instructions)
    // This prompt dictates the "Persona" and the ReAct format.
    const prompt = ChatPromptTemplate.fromMessages([
      ["system", `
        You are an intelligent document analysis assistant for a SaaS platform.
        You have access to a document database.
        
        CRITICAL RULES:
        1. Always use the 'retrieve_document_content' tool if the user asks about a specific document.
        2. Analyze the retrieved content strictly based on the user's query.
        3. If the content is missing required clauses (like Force Majeure), explicitly state it.
        4. Keep your final answers concise but actionable.
      `],
      ["human", "{input}"],
      ["assistant", "{agent_scratchpad}"],
    ]);

    // 4. Create the Agent
    // We use OpenAIFunctionsAgent which supports structured tool calling (ReAct pattern)
    const tools = initializeTools();
    const agent = await createOpenAIFunctionsAgent({
      llm,
      tools,
      prompt,
    });

    // 5. Initialize Agent Executor
    // The executor manages the ReAct Loop: Thought -> Action -> Observation
    const agentExecutor = new AgentExecutor({
      agent,
      tools,
      verbose: true, // Logs the ReAct steps to the server console for debugging
      maxIterations: 5, // Safety break to prevent infinite loops
    });

    // 6. Stream Execution using Vercel AI SDK
    // We wrap the agent executor's stream output in a StreamingTextResponse.
    // This converts the LangChain stream events into a format Next.js/AI SDK consumes.
    const stream = await agentExecutor.stream({
      input: `Document ID: ${documentId}\nTenant ID: ${tenantId}\nUser Query: ${query}`,
    });

    // Transform the stream to format output for the client
    const transformStream = new ReadableStream({
      async start(controller) {
        for await (const chunk of stream) {
          // LangChain streams 'agent' steps and 'tool' steps. 
          // We generally only want to stream the output tokens to the user.
          if ('output' in chunk) {
            controller.enqueue(chunk.output);
          }
        }
        controller.close();
      },
    });

    return new StreamingTextResponse(transformStream);

  } catch (error) {
    console.error("Agent Execution Error:", error);
    
    // Handle Zod validation errors specifically
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { error: "Invalid input", details: error.errors }, 
        { status: 400 }
      );
    }

    return NextResponse.json(
      { error: "Internal Server Error" }, 
      { status: 500 }
    );
  }
}
