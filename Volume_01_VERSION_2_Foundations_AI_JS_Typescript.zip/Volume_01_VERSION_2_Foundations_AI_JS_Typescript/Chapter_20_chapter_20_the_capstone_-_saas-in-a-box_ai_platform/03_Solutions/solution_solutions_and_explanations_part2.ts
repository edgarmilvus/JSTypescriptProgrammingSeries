/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

import { ChatOpenAI } from "@langchain/openai";
import { RunnableSequence } from "@langchain/core/runnables";
import { BaseRetriever } from "@langchain/core/retrievers";
import { Document } from "@langchain/core/documents";

// Mocking the VectorStoreRetriever for the sake of the example structure.
// In a real app, this would come from @langchain/pinecone or @langchain/chroma
interface MockVectorStoreRetriever extends BaseRetriever {
  init(tenantId: string): void; 
}

// 1. Function to create the tenant-aware chain
export async function createTenantAwareRetrievalChain(tenantId: string): Promise<RunnableSequence> {
  // Initialize the LLM
  const model = new ChatOpenAI({
    modelName: "gpt-3.5-turbo",
    temperature: 0,
  });

  // 2. Configure the retriever with a filter
  // Note: In a real implementation (e.g., Pinecone), the filter syntax would be specific to the provider.
  // Example Pinecone filter: { tenantId: { $eq: tenantId } }
  const retriever: BaseRetriever = {
    async _getRelevantQueries(query: string): Promise<Document[]> {
      // SIMULATION: In a real app, this calls the vector store API.
      // We simulate a database lookup that respects the tenantId.
      console.log(`Querying vector store for tenant: ${tenantId} with query: ${query}`);
      
      // Mock result: returning a document or empty array based on logic
      // In reality, the vector store handles the filtering internally.
      return [
        new Document({
          pageContent: `Context for tenant ${tenantId}: The sky is blue.`,
          metadata: { tenantId }
        })
      ];
    }
  };

  // 3. Construct the RAG prompt
  const prompt = `You are an AI assistant for a specific tenant. Answer the user's question based strictly on the context provided below.
  Context: {context}
  Question: {question}
  Answer:`;

  // 4. Build the chain
  const chain = RunnableSequence.from([
    {
      // Input mapping
      question: (input: { question: string }) => input.question,
      context: async (input: { question: string }) => {
        // Retrieve documents filtered by tenantId
        const docs = await retriever._getRelevantQueries(input.question);
        
        // 5. Handle empty context
        if (!docs || docs.length === 0) {
          return "No relevant documents found for this tenant.";
        }
        
        // Join document content into a single string context
        return docs.map(doc => doc.pageContent).join("\n\n");
      },
    },
    prompt,
    model,
    // Output parsing (LLM output is already a string, so we just pass it through)
    (output) => output.content
  ]);

  return chain;
}
