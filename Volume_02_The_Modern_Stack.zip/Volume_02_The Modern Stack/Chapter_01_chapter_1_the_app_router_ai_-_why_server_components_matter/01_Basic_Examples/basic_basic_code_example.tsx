/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.tsx
// Description: Basic Code Example
// ==========================================

// File: app/greeting-card/page.tsx
// This is a Next.js Server Component. It runs exclusively on the server.
// It does not execute any client-side JavaScript by default.

import { streamText } from 'ai'; // Vercel AI SDK for streaming text generation
import { openai } from '@ai-sdk/openai'; // Provider for OpenAI models
import { Suspense } from 'react'; // React feature for handling async UI boundaries

// Define the props for the component (passed via URL search params in this example)
interface GreetingCardProps {
  searchParams: {
    name?: string;
  };
}

/**
 * Generates a greeting card UI using Server Components and AI streaming.
 * @param {GreetingCardProps} props - The component props.
 * @returns {Promise<JSX.Element>} A React component that renders the greeting card.
 */
export default async function GreetingCard({ searchParams }: GreetingCardProps) {
  const name = searchParams.name || 'Guest'; // Default to 'Guest' if no name is provided

  // 1. SERVER-SIDE AI GENERATION
  // We call the LLM directly from the server. The result is a stream.
  const result = await streamText({
    model: openai('gpt-3.5-turbo'),
    prompt: `Generate a warm, professional greeting for a SaaS dashboard user named ${name}. 
             Keep it under 50 words. Mention the benefit of using the app.`,
  });

  // 2. UI RENDERING
  // We return JSX directly. The 'result' object contains a streamToResponse method,
  // but for Server Components, we often use the 'streamText' result directly in the UI.
  // However, to keep this example simple and fully server-rendered, we will stream the text
  // into a simple HTML structure.
  return (
    <main style={{ padding: '2rem', fontFamily: 'sans-serif' }}>
      <div style={{ 
        border: '1px solid #e2e8f0', 
        borderRadius: '8px', 
        padding: '1.5rem', 
        maxWidth: '400px',
        boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)' 
      }}>
        <h1 style={{ fontSize: '1.5rem', fontWeight: 'bold', marginBottom: '1rem' }}>
          Welcome, {name}!
        </h1>
        
        {/* 
          3. SUSPENSE BOUNDARY
          The Suspense component allows us to show a fallback (loading state) 
          while the AI stream is being processed on the server. 
        */}
        <Suspense fallback={<p style={{ color: '#64748b' }}>Generating your message...</p>}>
          <GreetingMessage result={result} />
        </Suspense>
      </div>
    </main>
  );
}

/**
 * A helper async component to handle the streaming text.
 * This runs on the server and awaits the stream.
 */
async function GreetingMessage({ result }: { result: any }) {
  // The 'result.text' property is a Promise that resolves to the full generated string.
  // By awaiting it here, we ensure the server completes the generation before sending HTML.
  const message = await result.text;

  return (
    <p style={{ lineHeight: '1.6', color: '#334155' }}>
      {message}
    </p>
  );
}
