/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.tsx
// Description: Advanced Application Script
// ==========================================

// app/dashboard/page.tsx
// This is a Server Component by default in the Next.js App Router.
// It executes exclusively on the server, allowing direct database access and secure API calls.

import { Suspense } from 'react';
import { generateAIInsight } from '@/lib/actions/ai-insights';
import { fetchUserAnalytics } from '@/lib/data/analytics';
import { InsightStream } from '@/components/client/insight-stream';
import { AnalyticsSummary } from '@/components/server/analytics-summary';
import { GenerateButton } from '@/components/client/generate-button';

/**
 * Dashboard Page Component.
 * Fetches initial data on the server and renders the layout.
 * Uses Suspense to handle the asynchronous loading of the AI stream.
 */
export default async function DashboardPage() {
  // 1. SERVER-SIDE DATA FETCHING
  // We fetch the user's analytics data directly on the server.
  // This data is never exposed to the client bundle; it stays in the server memory.
  const analyticsData = await fetchUserAnalytics('user_123');

  return (
    <main className="p-8 max-w-4xl mx-auto space-y-8">
      <h1 className="text-3xl font-bold text-slate-900">Executive Dashboard</h1>

      {/* 2. STATIC SERVER RENDERING */}
      {/* The AnalyticsSummary is a Server Component. It renders to HTML on the server. */}
      {/* No JavaScript for this component is sent to the client. */}
      <AnalyticsSummary data={analyticsData} />

      <div className="border-t pt-8">
        <h2 className="text-2xl font-semibold mb-4">Generative Insights</h2>
        
        {/* 3. SUSPENSE BOUNDARY FOR STREAMING */}
        {/* The AI generation might take time (waiting for LLM tokens). */}
        {/* We wrap the streaming component in Suspense. The fallback UI renders immediately. */}
        <Suspense fallback={<div className="animate-pulse bg-slate-100 h-32 rounded-lg" />}>
          {/* 
            The InsightStream component is a Client Component that consumes the stream.
            We pass a Server Action (generateAIInsight) as a prop. 
            This action is invoked on the client but executes on the server.
          */}
          <InsightStream 
            analytics={analyticsData} 
            generateAction={generateAIInsight} 
          />
        </Suspense>
      </div>
    </main>
  );
}
