/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script_part3.tsx
// Description: Advanced Application Script
// ==========================================

// components/client/insight-stream.tsx
// A Client Component (marked 'use client'). 
// It handles the user interaction and consumes the stream.

'use client';

import { useState, useTransition } from 'react';
import { UserAnalytics } from '@/lib/types';

interface InsightStreamProps {
  analytics: UserAnalytics;
  // Accepting the Server Action as a prop allows us to trigger server logic from the client.
  generateAction: (payload: UserAnalytics) => Promise<string>;
}

export function InsightStream({ analytics, generateAction }: InsightStreamProps) {
  const [insight, setInsight] = useState<string>('');
  const [isPending, startTransition] = useTransition();

  const handleGenerate = () => {
    // 4. PROGRESSIVE ENHANCEMENT & TRANSITIONS
    // useTransition allows the UI to remain responsive (non-blocking) 
    // while the Server Action executes.
    startTransition(async () => {
      // The Server Action executes here. It returns a stream or a string.
      const result = await generateAction(analytics);
      setInsight(result);
    });
  };

  return (
    <div className="space-y-4">
      <GenerateButton 
        onClick={handleGenerate} 
        disabled={isPending} 
        isLoading={isPending}
      />
      
      {/* Displaying the streamed result */}
      <div className="p-4 bg-white border rounded-lg shadow-sm min-h-[100px] whitespace-pre-wrap">
        {isPending ? 'Generating insight...' : insight || 'Click generate to see insights.'}
      </div>
    </div>
  );
}
