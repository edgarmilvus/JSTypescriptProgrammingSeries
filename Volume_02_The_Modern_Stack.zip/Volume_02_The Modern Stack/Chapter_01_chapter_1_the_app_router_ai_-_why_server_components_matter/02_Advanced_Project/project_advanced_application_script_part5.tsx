/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script_part5.tsx
// Description: Advanced Application Script
// ==========================================

// lib/actions/ai-insights.ts
// Server Actions. Defined in a separate file (no 'use client').
// These functions run exclusively on the server.

'use server';

import { UserAnalytics } from '@/lib/types';

/**
 * Server Action to generate AI insights.
 * This mimics an LLM call. In a real app, this would stream tokens from an API.
 * Because it is a Server Action, we can securely call the LLM API here.
 */
export async function generateAIInsight(analytics: UserAnalytics): Promise<string> {
  // Simulate network delay for LLM generation
  await new Promise(resolve => setTimeout(resolve, 1500));

  // Mock LLM generation logic based on data
  const revenue = analytics.orders.reduce((sum, o) => sum + o.amount, 0);
  let insight = `Analysis of your data shows:\n\n`;
  
  if (revenue > 5000) {
    insight += `• Revenue is strong ($${revenue}). Consider scaling ad spend.\n`;
  } else {
    insight += `• Revenue is moderate ($${revenue}). Focus on retention strategies.\n`;
  }

  if (analytics.conversionRate < 2) {
    insight += `• Conversion rate is low (${analytics.conversionRate}%). A/B test the checkout flow.`;
  } else {
    insight += `• Conversion rate is healthy (${analytics.conversionRate}%).`;
  }

  return insight;
}
