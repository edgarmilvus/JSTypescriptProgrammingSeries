/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part10.ts
// Description: Solutions and Explanations
// ==========================================

// File: app/conversation/Conversation.tsx
'use client';

import { useTransition, useState } from 'react';
import { updateAIState } from '@/app/actions';

export default function Conversation({ initialAIState }: { initialAIState: any }) {
  const [aiState, setAiState] = useState(initialAIState);
  const [isPending, startTransition] = useTransition();
  const [error, setError] = useState<string | null>(null);

  const sendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    const formData = new FormData(e.target as HTMLFormElement);
    const message = formData.get('message') as string;

    // 6. Optimistic Update
    const optimisticMessage = { role: 'user', content: message };
    const optimisticState = {
      ...aiState,
      messages: [...aiState.messages, optimisticMessage]
    };

    // Update UI immediately
    setAiState(optimisticState);

    startTransition(async () => {
      // Call Server Action
      const result = await updateAIState(null, formData);
      
      if (result?.error) {
        // 6. Revert on error
        setAiState(initialAIState); 
        setError(result.error);
      } else {
        // Clear error on success
        setError(null);
      }
    });
  };

  return (
    <div>
      {error && <div style={{ color: 'red', marginBottom: '10px' }}>{error}</div>}
      
      <div style={{ border: '1px solid #ccc', padding: '10px', minHeight: '200px' }}>
        {aiState.messages.map((msg: any, i: number) => (
          <div key={i}><strong>{msg.role}:</strong> {msg.content}</div>
        ))}
        {isPending && <div style={{ color: 'gray' }}>Saving...</div>}
      </div>

      <form onSubmit={sendMessage} style={{ marginTop: '10px' }}>
        <input name="message" type="text" placeholder="Type a message..." disabled={isPending} />
        <button type="submit" disabled={isPending}>Send</button>
      </form>
    </div>
  );
}
