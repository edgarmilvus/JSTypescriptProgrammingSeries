/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part12.ts
// Description: Solutions and Explanations
// ==========================================

digraph DataFlow {
    rankdir=TB;
    node [shape=box, style="rounded,filled", fontname="Helvetica"];
    edge [fontname="Helvetica", fontsize=10];

    // Define Nodes
    Browser [label="Browser (Client)", fillcolor="#a7c7e7"];
    Server [label="Next.js Server", fillcolor="#f9d5e5"];
    DB [label="Database", fillcolor="#e0e0e0", shape=cylinder];
    SC [label="Server Component\n(Initial Render)", fillcolor="#b8e0d2"];
    CC [label="Client Component\n(Interactive UI)", fillcolor="#fff5ba"];
    SA [label="Server Action\n(Form Handler / AI)", fillcolor="#ffdae0"];
    Suspense [label="Suspense Boundary", fillcolor="#e6e6fa", shape=ellipse];

    // Define Subgraphs for clarity
    subgraph cluster_client {
        label = "Client Side";
        Browser;
        CC;
    }

    subgraph cluster_server {
        label = "Server Side";
        Server;
        SC;
        SA;
        DB;
    }

    // Flow 1: Initial Page Load
    Browser -> Server [label="1. HTTP Request (GET /page)"];
    Server -> SC [label="2. Execute Server Component"];
    SC -> DB [label="3. Fetch Data (await getUserContext)"];
    DB -> SC [label="4. Return Data"];
    
    // Suspense Logic
    SC -> Suspense [label="If Data Pending", style=dashed];
    Suspense -> Browser [label="Stream Fallback UI", style=dashed];
    
    SC -> Server [label="5. Serialize Props"];
    Server -> Browser [label="6. Stream HTML (Props injected)"];

    // Hydration & Interaction
    Browser -> CC [label="7. Hydrate Client Component"];
    
    // Flow 2: User Interaction (Server Action)
    CC -> Browser [label="8. User submits form"];
    Browser -> Server [label="9. fetch('/api/action')\n(Invoked by startTransition)"];
    Server -> SA [label="10. Execute Server Action"];
    SA -> DB [label="11. Update/Persist State"];
    SA -> Server [label="12. Return JSON Response"];
    Server -> Browser [label="13. Return Data to Client"];
    
    // Flow 3: UI Update
    Browser -> CC [label="14. Resolve Promise\n(Update State / Optimistic UI)"];
}
