/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

// File: components/PromptForm.tsx
'use client';

import { useTransition, useState } from 'react';
import { generateResponse } from '@/app/actions';

export default function PromptForm() {
  const [isPending, startTransition] = useTransition();
  const [response, setResponse] = useState<{ text: string; timestamp: string } | null>(null);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const formData = new FormData(e.target as HTMLFormElement);
    const prompt = formData.get('prompt') as string;

    // 4. Wrap async call in startTransition
    startTransition(async () => {
      try {
        setError(null);
        const result = await generateResponse(prompt);
        setResponse(result);
      } catch (err) {
        setError('Failed to generate response');
      }
    });
  };

  return (
    <form onSubmit={handleSubmit}>
      <input name="prompt" type="text" placeholder="Enter your prompt..." disabled={isPending} />
      <button type="submit" disabled={isPending}>
        {isPending ? 'Generating...' : 'Submit'}
      </button>
      
      {error && <div style={{ color: 'red' }}>{error}</div>}
      
      {/* 6. Display streamed response data */}
      {response && (
        <div className="response">
          <p>{response.text}</p>
          <small>Generated at: {response.timestamp}</small>
        </div>
      )}
    </form>
  );
}
