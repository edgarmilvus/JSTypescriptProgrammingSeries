/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

// File: app/api/edge-chat/route.ts
// Runtime: Edge (Vercel Edge Runtime)

import { NextResponse } from 'next/server';

/**
 * @description Simulates a network delay to mimic an LLM generating tokens.
 * @param ms - Milliseconds to wait.
 */
const simulateLLMDelay = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

/**
 * @description Edge Runtime API Route.
 * Uses the Web Streams API directly. No Node.js `stream` module available.
 * @param req - The incoming Request object (Web Standard API).
 */
export async function GET(req: Request) {
  // 1. Create a ReadableStream to handle the streaming response.
  const stream = new ReadableStream({
    async start(controller) {
      // 2. Define the chunks of text to stream (simulating AI tokens).
      const tokens = ["Hello", " from", " the", " Edge", "!"];
      
      for (const token of tokens) {
        // 3. Simulate network latency (non-blocking in Edge).
        await simulateLLMDelay(100); 
        
        // 4. Enqueue the token into the stream.
        controller.enqueue(new TextEncoder().encode(token));
      }
      
      // 5. Close the stream.
      controller.close();
    },
  });

  // 6. Return the response with the stream.
  return new NextResponse(stream, {
    headers: {
      'Content-Type': 'text/plain; charset=utf-8',
      // Enable streaming for clients
      'Transfer-Encoding': 'chunked',
      'X-Accel-Buffering': 'no',
    },
  });
}
