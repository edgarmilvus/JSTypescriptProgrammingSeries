/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// File: /app/api/chat/route.ts
// Target Runtime: Vercel Edge (Default for Next.js App Router API Routes)
import { NextRequest, NextResponse } from 'next/server';
import { StreamingTextResponse, experimental_StreamData } from 'ai';
import { createStreamableValue } from 'rsc/stream';

// --- CONFIGURATION & TYPES ---

/**
 * Defines the structure of a message in our chat history.
 */
type ChatMessage = {
  role: 'user' | 'assistant' | 'system';
  content: string;
};

/**
 * Defines the structure of a task delegated to the Worker Pool.
 * This allows the Edge function to remain lightweight, only sending structured requests.
 */
type WorkerTask = {
  type: 'DATA_FETCH' | 'CODE_GENERATION';
  payload: Record<string, any>;
};

// --- EDGE RUNTIME SUPERVISOR LOGIC ---

export const runtime = 'edge'; // CRITICAL: Forces execution on Vercel Edge.

/**
 * Main API Entry Point.
 * Handles the incoming request and initiates the streaming response.
 */
export async function POST(req: NextRequest) {
  const { messages } = await req.json();

  // 1. Initialize the Stream.
  // We use RSC (React Server Components) streams for tight integration with Next.js UI.
  const stream = createStreamableValue('');
  const data = new experimental_StreamData();

  // 2. Start the asynchronous Supervisor Loop.
  // We do not await this immediately; we return the response stream immediately.
  superviseAndGenerate(messages, stream, data).catch((error) => {
    console.error('Edge Runtime Error:', error);
    stream.update('Error processing request.');
  });

  // 3. Return the stream response.
  // This happens almost instantly, keeping TTFB (Time to First Byte) low.
  return new StreamingTextResponse(stream.value, {}, data);
}

/**
 * The Supervisor Agent.
 * Implements a cyclical graph logic: Analyze -> Delegate -> Render -> Analyze.
 * 
 * @param messages - The conversation history.
 * @param stream - The writable stream to push tokens to the client.
 * @param data - The StreamData object for attaching metadata.
 */
async function superviseAndGenerate(
  messages: ChatMessage[],
  stream: ReturnType<typeof createStreamableValue>,
  data: experimental_StreamData
) {
  const lastMessage = messages[messages.length - 1];
  
  // --- CYCLICAL GRAPH LOGIC START ---
  
  // Iteration 1: Analyze Intent
  const intent = analyzeIntent(lastMessage.content);
  
  if (intent.needsWorker) {
    // --- DELEGATION PHASE ---
    // In a real app, this might be a fetch call to a separate API route running on Node.js
    // or a background function. Here, we simulate the worker call.
    
    stream.update("Thinking... ");
    
    // Simulate network latency to worker
    await new Promise(r => setTimeout(r, 500)); 

    // Call the Worker Agent (Simulated here as a function import)
    // The worker handles the heavy lifting (e.g., SQL generation, complex math).
    const workerResult = await mockAnalyticsWorker(intent.query);

    // --- RENDERING PHASE ---
    // We generate a React Component string (Server Component) based on the worker data.
    const uiComponent = generateReactComponent(workerResult);
    
    // Stream the UI component to the client
    stream.update(uiComponent);
    
    // Attach metadata for the client to hydrate the component
    data.append({
      type: 'ui_component',
      timestamp: Date.now(),
      componentType: 'BarChart'
    });
  } else {
    // Fallback for general chat
    stream.update("I can help you visualize data. Try asking for 'sales trends'.");
  }

  stream.done();
  data.close();
  // --- CYCLICAL GRAPH LOGIC END ---
}

/**
 * Simple intent analyzer to decide routing.
 * In a full LangGraph implementation, this would be an LLM call.
 */
function analyzeIntent(text: string): { needsWorker: boolean; query: string } {
  const keywords = ['chart', 'graph', 'data', 'sales', 'stats'];
  const hasKeyword = keywords.some(k => text.toLowerCase().includes(k));
  return {
    needsWorker: hasKeyword,
    query: text
  };
}

/**
 * Generates a React Server Component string (simplified for demo).
 * This is the "Generative UI" aspect.
 */
function generateReactComponent(data: any): string {
  // In a real app, you might return a serialized React element or JSX string
  // that the client hydrates.
  return `\n<BarChart data='${JSON.stringify(data)}' />\n`;
}

// --- WORKER AGENT POOL (Simulated) ---

// File: /lib/workers/analyticsWorker.ts
// Note: In a production app, this logic would likely run in a Node.js environment
// or a separate Edge Function optimized for CPU, allowing the main Edge function
// to stay lean.

/**
 * Mocks a heavy computation worker (e.g., a Database Query Agent).
 * This isolates the heavy logic from the streaming Edge runtime.
 * 
 * Why separate this?
 * 1. Edge Runtime has a 128MB memory limit. Database drivers (like 'pg' or 'mysql2')
 *    often exceed this or rely on Node.js APIs not available on the Edge.
 * 2. By delegating, we keep the Edge function fast and cheap.
 */
async function mockAnalyticsWorker(query: string): Promise<{ label: string; value: number }[]> {
  // Simulate heavy CPU work or DB I/O
  console.log(`Worker processing: ${query}`);
  
  // Simulate a database fetch
  const mockData = [
    { label: 'Jan', value: 65 },
    { label: 'Feb', value: 59 },
    { label: 'Mar', value: 80 },
    { label: 'Apr', value: 81 },
    { label: 'May', value: 56 },
    { label: 'Jun', value: 55 },
  ];

  // Simulate processing time
  await new Promise(resolve => setTimeout(resolve, 800));

  return mockData;
}
