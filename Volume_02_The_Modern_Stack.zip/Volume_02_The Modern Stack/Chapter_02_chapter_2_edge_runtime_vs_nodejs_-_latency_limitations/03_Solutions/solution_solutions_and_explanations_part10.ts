/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part10.ts
// Description: Solutions and Explanations
// ==========================================

import { NextResponse } from 'next/server';
export const runtime = 'edge';

// Simulate LangGraph node execution
const simulateNode = (name: string, delay: number): Promise<void> => {
  return new Promise(resolve => setTimeout(resolve, delay));
};

export async function GET(req: Request) {
  const { searchParams } = new URL(req.url);
  const query = searchParams.get('query') || 'Default Query';

  // Initial State
  let state: AppGraphState = {
    userQuery: query,
    searchResults: [],
    summary: '',
    uiComponents: [],
    status: 'running',
  };

  const stream = new TransformStream();
  const writer = stream.writable.getWriter();
  const encoder = new TextEncoder();

  // Execute logic asynchronously without blocking the response
  (async () => {
    try {
      // Node 1: Search
      await simulateNode('Search', 500);
      state.searchResults = ['Result 1: Large text...', 'Result 2: More text...'];
      // Optimization: Only stream necessary updates, not the whole state if huge
      await writer.write(encoder.encode(JSON.stringify({ type: 'search', data: state.searchResults }) + '\n'));

      // Node 2: Summarize
      await simulateNode('Summarize', 500);
      state.summary = 'A concise summary of the search results.';
      await writer.write(encoder.encode(JSON.stringify({ type: 'summary', data: state.summary }) + '\n'));

      // Node 3: Generate UI
      await simulateNode('Generate', 500);
      state.uiComponents = [{ type: 'button', content: 'Click Me' }];
      await writer.write(encoder.encode(JSON.stringify({ type: 'ui', data: state.uiComponents }) + '\n'));

      state.status = 'complete';
      await writer.write(encoder.encode(JSON.stringify({ type: 'done', data: state.status }) + '\n'));
    } catch (e) {
      await writer.write(encoder.encode(JSON.stringify({ type: 'error', error: e }) + '\n'));
    } finally {
      await writer.close();
    }
  })();

  return new NextResponse(stream.readable, {
    headers: { 'Content-Type': 'application/x-ndjson' },
  });
}
