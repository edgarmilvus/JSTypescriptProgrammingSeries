/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part11.ts
// Description: Solutions and Explanations
// ==========================================

import { useState, useEffect } from 'react';

interface Metric {
  runtime: 'node' | 'edge';
  latency: number;
}

export function useRuntimeMetrics() {
  const [history, setHistory] = useState<Metric[]>([]);
  const [loading, setLoading] = useState(false);

  const triggerRequest = async (runtime: 'node' | 'edge') => {
    setLoading(true);
    const start = performance.now();
    
    const endpoint = runtime === 'node' 
      ? '/api/chat-node?prompt=metric' 
      : '/api/chat-edge?prompt=metric';

    try {
      const res = await fetch(endpoint);
      // Consume stream to get total duration
      const reader = res.body?.getReader();
      if (reader) {
        while (!(await reader.read()).done) {}
      }
      
      const latency = performance.now() - start;
      
      setHistory(prev => [...prev, { runtime, latency }]);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  // Calculate averages based on last 10 requests
  const averages = {
    node: 0,
    edge: 0,
  };

  const last10 = history.slice(-10);
  const nodeMetrics = last10.filter(h => h.runtime === 'node');
  const edgeMetrics = last10.filter(h => h.runtime === 'edge');

  if (nodeMetrics.length) averages.node = nodeMetrics.reduce((a, b) => a + b.latency, 0) / nodeMetrics.length;
  if (edgeMetrics.length) averages.edge = edgeMetrics.reduce((a, b) => a + b.latency, 0) / edgeMetrics.length;

  return {
    triggerRequest,
    averages,
    history: last10,
    loading,
  };
}
