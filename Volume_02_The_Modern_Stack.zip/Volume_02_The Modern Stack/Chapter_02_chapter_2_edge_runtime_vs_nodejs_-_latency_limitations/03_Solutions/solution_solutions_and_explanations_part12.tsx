/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part12.tsx
// Description: Solutions and Explanations
// ==========================================

'use client';

import { useState } from 'react';
import { useRuntimeMetrics } from '@/hooks/useRuntimeMetrics';

type RuntimeType = 'node' | 'edge';

export default function RuntimeConfigurator({ defaultRuntime }: { defaultRuntime: RuntimeType }) {
  const [currentRuntime, setCurrentRuntime] = useState<RuntimeType>(defaultRuntime);
  const { triggerRequest, averages, loading } = useRuntimeMetrics();

  const handleToggle = () => {
    const newRuntime = currentRuntime === 'node' ? 'edge' : 'node';
    setCurrentRuntime(newRuntime);
  };

  const handleTest = () => {
    triggerRequest(currentRuntime);
  };

  return (
    <div className="p-4 border rounded-lg shadow-md bg-white max-w-md mx-auto">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-lg font-bold">Runtime Configurator</h2>
        <span 
          className={`px-2 py-1 rounded text-xs font-bold uppercase ${
            currentRuntime === 'edge' 
              ? 'bg-green-100 text-green-800' 
              : 'bg-blue-100 text-blue-800'
          }`}
        >
          {currentRuntime}
        </span>
      </div>

      <div className="flex gap-2 mb-4">
        <button 
          onClick={handleToggle}
          className="flex-1 px-3 py-2 bg-gray-200 rounded hover:bg-gray-300 transition"
        >
          Switch to {currentRuntime === 'node' ? 'Edge' : 'Node.js'}
        </button>
        
        <button 
          onClick={handleTest}
          disabled={loading}
          className="flex-1 px-3 py-2 bg-indigo-600 text-white rounded hover:bg-indigo-700 disabled:opacity-50 transition"
        >
          {loading ? 'Testing...' : 'Test Current Runtime'}
        </button>
      </div>

      <div className="bg-gray-50 p-3 rounded text-sm space-y-2">
        <div className="flex justify-between border-b pb-2">
          <span>Avg Node Latency:</span>
          <span className="font-mono font-bold text-blue-600">
            {averages.node ? `${averages.node.toFixed(0)}ms` : '-'}
          </span>
        </div>
        <div className="flex justify-between">
          <span>Avg Edge Latency:</span>
          <span className="font-mono font-bold text-green-600">
            {averages.edge ? `${averages.edge.toFixed(0)}ms` : '-'}
          </span>
        </div>
      </div>
      
      {averages.edge > 0 && averages.node > 0 && (
        <div className="mt-2 text-xs text-center text-gray-500">
          Improvement: {((averages.node - averages.edge) / averages.node * 100).toFixed(1)}%
        </div>
      )}
    </div>
  );
}
