/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

'use client';

import { useState } from 'react';

type RuntimeType = 'node' | 'edge';

interface Metrics {
  ttfb: number;
  total: number;
  type: RuntimeType;
}

export default function ChatComparison() {
  const [metrics, setMetrics] = useState<Metrics[]>([]);
  const [loading, setLoading] = useState(false);
  const [activeRuntime, setActiveRuntime] = useState<RuntimeType>('node');

  const simulateRequest = async (type: RuntimeType) => {
    setLoading(true);
    const url = type === 'node' ? '/api/chat-node?prompt=Compare' : '/api/chat-edge?prompt=Compare';
    
    const start = performance.now();
    let ttfb = 0;
    
    try {
      const response = await fetch(url);
      
      // Measure TTFB (time until the first byte is received)
      ttfb = performance.now() - start;

      // Consume the stream to measure total duration
      const reader = response.body?.getReader();
      if (reader) {
        while (true) {
          const { done } = await reader.read();
          if (done) break;
        }
      }
      
      const total = performance.now() - start;

      setMetrics(prev => [...prev, { ttfb, total, type }]);
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="p-6 border rounded-lg shadow-sm">
      <div className="flex gap-4 mb-4">
        <button 
          onClick={() => simulateRequest('node')}
          disabled={loading}
          className="px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600 disabled:opacity-50"
        >
          Test Node.js Runtime
        </button>
        <button 
          onClick={() => simulateRequest('edge')}
          disabled={loading}
          className="px-4 py-2 bg-green-500 text-white rounded hover:bg-green-600 disabled:opacity-50"
        >
          Test Edge Runtime
        </button>
      </div>

      <div className="space-y-2">
        <h3 className="font-bold">Latency Results (Last 5 Requests)</h3>
        {metrics.slice(-5).map((m, i) => (
          <div key={i} className="flex justify-between p-2 bg-gray-50 rounded">
            <span className={`font-semibold ${m.type === 'edge' ? 'text-green-600' : 'text-blue-600'}`}>
              {m.type.toUpperCase()}
            </span>
            <span>TTFB: {m.ttfb.toFixed(2)}ms</span>
            <span>Total: {m.total.toFixed(2)}ms</span>
          </div>
        ))}
      </div>
    </div>
  );
}
