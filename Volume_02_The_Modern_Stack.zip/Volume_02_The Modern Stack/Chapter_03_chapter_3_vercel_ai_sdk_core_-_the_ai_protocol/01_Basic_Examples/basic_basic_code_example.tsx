/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.tsx
// Description: Basic Code Example
// ==========================================

// File: app/page.tsx
// This is a React Server Component (RSC) that runs exclusively on the server.
// It orchestrates the AI generation and streams the UI directly to the client.

'use server'; // Marks this file as a Server Component in Next.js App Router.

import { streamUI } from '@vercel/ai-sdk/rsc'; // Import the RSC-specific streamUI function.
import { generateId } from '@vercel/ai-sdk/core'; // Helper for unique IDs.
import { ChatInterface } from '@/components/ChatInterface'; // Client component for UI.
import { MockProvider } from '@/lib/mock-ai'; // Simulated AI provider (defined below).

/**
 * @description A mock AI provider that simulates a streaming response.
 * In production, this would be replaced with `openai.chat.completions.createStream`.
 * @returns {AsyncIterable<{content: string}>} A stream of text chunks.
 */
const mockProvider = new MockProvider();

/**
 * @description The main server action triggered by the client.
 * @param {string} prompt - The user's input.
 * @returns {Promise<React.ReactNode>} A streamable UI component.
 */
export async function generateUI(prompt: string) {
  // 1. Define the UI component to be rendered by the AI.
  //    This is a function that returns a React element.
  //    The `content` prop will be streamed from the AI.
  const component = ({ content }: { content: string }) => (
    <div className="p-4 bg-blue-100 border border-blue-300 rounded-lg shadow-sm">
      <h3 className="font-bold text-blue-800">Generated Response</h3>
      <p className="text-blue-700 mt-2">{content}</p>
    </div>
  );

  // 2. Call streamUI to generate and stream the component.
  //    This function handles the SSE connection under the hood.
  const result = await streamUI({
    model: 'gpt-3.5-turbo', // Placeholder model name.
    prompt: `Generate a concise response to: "${prompt}". Keep it under 20 words.`,
    
    // 3. The text stream callback: This is called incrementally as tokens arrive.
    text: ({ content, done }) => {
      // If done, we finalize; otherwise, we return the partial content.
      // This is where immutable state updates happen on the server side.
      if (done) {
        return component({ content }); // Final render.
      }
      // Return a loading state or partial content while streaming.
      return (
        <div className="p-4 bg-gray-100 border border-gray-300 rounded-lg">
          <p className="text-gray-500">Thinking... {content}</p>
        </div>
      );
    },
    
    // 4. Optional: Define tools (not used in this basic example).
    tools: {},
  });

  return result;
}

// 5. The Page Component that renders the Client Interface.
export default function Page() {
  return (
    <main className="min-h-screen bg-gray-50 p-8">
      <h1 className="text-2xl font-bold mb-4">Generative UI Streaming</h1>
      <ChatInterface generateUI={generateUI} />
    </main>
  );
}
