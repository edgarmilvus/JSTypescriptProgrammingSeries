/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// app/api/chat/route.ts
import { openai } from '@ai-sdk/openai';
import { streamUI } from 'ai/rsc';
import { z } from 'zod';

// Define the schema for the feedback form that the AI might generate
const feedbackSchema = z.object({
  satisfaction: z.enum(['satisfied', 'neutral', 'dissatisfied']),
  comment: z.string().optional(),
});

// Define the types for our custom UI components
type UIComponent = {
  type: 'text' | 'feedback_form' | 'diagnostic_button';
  content: any; // Varies by component type
};

/**
 * Server Action: Generates a streaming UI response based on a user query.
 * This runs on the server, allowing direct access to the database and LLM.
 * 
 * @param query - The user's support question.
 * @returns A streamable UI object.
 */
export async function generateSupportResponse(query: string) {
  // 1. INITIALIZE STREAMING
  // We use streamUI instead of generateText to allow component streaming.
  const result = await streamUI({
    model: openai('gpt-4-turbo'),
    // 2. SYSTEM PROMPT INSTRUCTION
    // We instruct the model to return structured JSON for specific scenarios.
    system: `You are a senior support engineer. Analyze the user query. 
    - If the query is a simple greeting, reply with text.
    - If the query implies a technical error, generate a "Diagnostic Button" to run a health check.
    - If the user seems frustrated or asks for feedback, generate a "Feedback Form".
    - Always be helpful and concise.`,
    prompt: query,
    
    // 3. TEXT GENERATION MAPPING
    // This handles the standard text streaming tokens.
    text: ({ content, done }) => {
      return (
        <div className="p-4 bg-blue-50 rounded-lg border border-blue-100">
          <p className="text-sm text-blue-900">{content}</p>
        </div>
      );
    },

    // 4. TOOL DEFINITION: DIAGNOSTIC BUTTON
    // The AI can invoke this tool to render an interactive button.
    tools: {
      renderDiagnostic: {
        description: 'Renders a button to run system diagnostics when a technical issue is detected.',
        parameters: z.object({ 
          service: z.string().describe('The service name to diagnose') 
        }),
        generate: async function* ({ service }) {
          // Yield a loading state immediately
          yield (
            <div className="animate-pulse text-gray-500 text-xs">
              Preparing diagnostic tools for {service}...
            </div>
          );
          
          // Simulate a network delay
          await new Promise(resolve => setTimeout(resolve, 1000));

          // Return the actual interactive component
          return (
            <div className="p-4 border border-red-200 bg-red-50 rounded-lg mt-2">
              <p className="text-sm font-bold text-red-800 mb-2">
                Potential issue detected in {service}.
              </p>
              <button 
                onClick={() => alert(`Running diagnostics for ${service}...`)}
                className="px-3 py-1 bg-red-600 text-white text-xs rounded hover:bg-red-700 transition"
              >
                Run Diagnostics
              </button>
            </div>
          );
        },
      },
      
      // 5. TOOL DEFINITION: FEEDBACK FORM
      // The AI can invoke this tool to render a Zod-validated form.
      renderFeedbackForm: {
        description: 'Renders a customer satisfaction form if the user expresses frustration or asks for feedback.',
        parameters: z.object({}),
        generate: async function* () {
          yield <div className="text-xs text-gray-400 italic">Loading feedback mechanism...</div>;
          
          await new Promise(resolve => setTimeout(resolve, 800));

          // In a real app, this would be a Server Action form
          return (
            <form className="mt-3 p-3 bg-white border rounded-md shadow-sm space-y-2">
              <p className="text-sm font-medium">How was your experience?</p>
              <div className="flex gap-2">
                <button type="button" className="text-lg hover:scale-125 transition">😊</button>
                <button type="button" className="text-lg hover:scale-125 transition">😐</button>
                <button type="button" className="text-lg hover:scale-125 transition">😡</button>
              </div>
              <input 
                type="text" 
                placeholder="Additional comments..." 
                className="w-full text-sm border p-1 rounded"
              />
              <button 
                type="submit" 
                className="w-full bg-blue-600 text-white text-xs py-1 rounded hover:bg-blue-700"
              >
                Submit Feedback
              </button>
            </form>
          );
        },
      }
    },
  });

  return result;
}
