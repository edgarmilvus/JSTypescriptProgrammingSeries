/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

// File: app/actions.ts
'use server';

import { streamUI } from 'ai/rsc';
import { openai } from '@ai-sdk/openai';
import { z } from 'zod';

// 1. Define the React components to be rendered
function BarChart({ data }: { data: { label: string; value: number }[] }) {
  return (
    <div className="border p-4 rounded shadow">
      <h3 className="font-bold mb-2">Sales by Region</h3>
      <div className="flex items-end h-32 gap-2">
        {data.map((item, index) => (
          <div key={index} className="flex-1 bg-blue-500 rounded-t" style={{ height: `${item.value}%` }} title={`${item.label}: ${item.value}`}>
          </div>
        ))}
      </div>
    </div>
  );
}

function DataTable({ data }: { data: string[][] }) {
  return (
    <div className="border p-4 rounded shadow mt-4">
      <table className="w-full text-sm">
        <tbody>
          {data.map((row, i) => (
            <tr key={i}>
              {row.map((cell, j) => (
                <td key={j} className="border px-2 py-1">{cell}</td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

// 2. Define the server action
export async function generateDashboard(query: string) {
  const result = await streamUI({
    model: openai('gpt-4-turbo'),
    prompt: `Generate a dashboard for: ${query}. 
    Output strictly in the following JSON format. Do not include any text outside the JSON.
    {
      "type": "bar_chart" | "data_table",
      "data": [ { "label": string, "value": number } ] | [ [string, string] ]
    }`,
    
    // 3. Define the text parser to extract JSON from the stream
    text: ({ content }) => {
      try {
        // Attempt to parse the content as JSON
        const parsed = JSON.parse(content);
        return parsed;
      } catch (error) {
        // If parsing fails (stream is incomplete), return null to wait for more tokens
        return null;
      }
    },

    // 4. Map the parsed output to components
    components: {
      bar_chart: ({ data }) => <BarChart data={data} />,
      data_table: ({ data }) => <DataTable data={data} />,
    },
  });

  return result.value;
}
