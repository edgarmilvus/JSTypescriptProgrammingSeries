/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

// File: components/DiagramGenerator.tsx
'use client';

import { useAI } from 'ai/react';
import { useState } from 'react';
import { generateDiagram } from '@/app/actions';

// Define a local interface for our specific UI state
interface DiagramStep {
  id: string;
  status: 'planning' | 'generating' | 'completed' | 'error';
  content: React.ReactNode | null;
}

export function DiagramGenerator() {
  const [input, setInput] = useState('');
  const [steps, setSteps] = useState<DiagramStep[]>([]);
  
  // We use a simple state for the current request to avoid overcomplicating 
  // the useAI hook's generic message structure for this specific multi-step logic.
  const [isGenerating, setIsGenerating] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input) return;

    setIsGenerating(true);
    const tempId = `step-${Date.now()}`;
    
    // Optimistic UI update: Add a planning step immediately
    setSteps(prev => [...prev, { id: tempId, status: 'planning', content: null }]);
    
    try {
      // Call the server action which handles the multi-step stream
      const streamResult = await generateDiagram(input);
      
      // In a real scenario, streamResult would be a stream of UI components.
      // For this exercise, we simulate the state updates based on the stream events.
      // The SDK's `useUI` hook handles this automatically, but here we simulate manual handling.
      
      // 1. Update status to generating
      setSteps(prev => prev.map(s => s.id === tempId ? { ...s, status: 'generating' } : s));

      // 2. The server streams components. We append them to the step.
      // (Assuming the server returns a stream of React nodes)
      for await (const component of streamResult) {
         setSteps(prev => prev.map(s => s.id === tempId ? { ...s, content: component } : s));
      }

      // 3. Finalize
      setSteps(prev => prev.map(s => s.id === tempId ? { ...s, status: 'completed' } : s));

    } catch (error) {
      setSteps(prev => prev.map(s => s.id === tempId ? { ...s, status: 'error' } : s));
    } finally {
      setIsGenerating(false);
      setInput('');
    }
  };

  const handleRegenerate = async (stepId: string) => {
    // Logic to call server for a specific step regeneration
    // This would likely involve passing the step ID and previous context to the server
    console.log(`Regenerating step ${stepId}`);
  };

  return (
    <div className="p-4 border rounded shadow max-w-2xl mx-auto">
      <form onSubmit={handleSubmit} className="flex gap-2 mb-6">
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Describe the diagram (e.g., 'Draw a login flowchart')..."
          className="flex-1 border p-2 rounded"
          disabled={isGenerating}
        />
        <button type="submit" disabled={isGenerating} className="bg-blue-500 text-white px-4 py-2 rounded">
          {isGenerating ? 'Generating...' : 'Generate'}
        </button>
      </form>

      <div className="space-y-4">
        {steps.map((step) => (
          <div key={step.id} className="border p-3 rounded bg-gray-50">
            <div className="flex justify-between items-center mb-2">
              <span className="text-sm font-bold uppercase text-gray-600">
                Status: {step.status}
              </span>
              {step.status === 'completed' && (
                <button 
                  onClick={() => handleRegenerate(step.id)}
                  className="text-xs bg-yellow-100 text-yellow-800 px-2 py-1 rounded hover:bg-yellow-200"
                >
                  Regenerate Step
                </button>
              )}
            </div>
            <div className="min-h-[50px]">
              {step.content || <span className="text-gray-400 italic">Waiting for content...</span>}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
