/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

// File: app/actions.ts
'use server';

import { streamText, ToolExecutionArgs } from 'ai';
import { openai } from '@ai-sdk/openai';
import { z } from 'zod';

// Mock API calls
const fetchWeather = async (city: string) => {
  await new Promise(resolve => setTimeout(resolve, 1000)); // Simulate delay
  return { temp: 72, condition: 'Sunny', city };
};

const generateImage = async (prompt: string) => {
  await new Promise(resolve => setTimeout(resolve, 2000)); // Simulate delay
  return `https://via.placeholder.com/150?text=${encodeURIComponent(prompt)}`;
};

export async function getAnswer(question: string) {
  const result = await streamText({
    model: openai('gpt-4-turbo'),
    prompt: question,
    tools: {
      getWeather: {
        description: 'Get the current weather for a location',
        parameters: z.object({
          city: z.string().describe('The city to get weather for'),
        }),
        execute: async ({ city }: { city: string }) => {
          const data = await fetchWeather(city);
          return `It is currently ${data.temp}°F and ${data.condition} in ${data.city}.`;
        },
      },
      generateImage: {
        description: 'Generate an image based on a prompt',
        parameters: z.object({
          prompt: z.string().describe('The prompt to generate an image for'),
        }),
        execute: async ({ prompt }: { prompt: string }) => {
          const url = await generateImage(prompt);
          // Return a structured object that the client can recognize as an image
          return { type: 'image', url };
        },
      },
    },
    // This callback is crucial for client-side tool UI rendering
    onToolCall: ({ toolName, args }) => {
      // This function is called when the AI decides to use a tool.
      // It allows the server to stream a specific UI component back to the client
      // immediately, before the tool execution completes.
      
      if (toolName === 'getWeather') {
        return <div className="text-blue-500">Checking weather for {args.city}...</div>;
      }
      
      if (toolName === 'generateImage') {
        return (
          <div className="border-2 border-dashed border-gray-300 p-4 text-center">
            <p>Generating image for: "{args.prompt}"</p>
            <div className="animate-spin h-8 w-8 border-4 border-blue-500 rounded-full border-t-transparent mx-auto mt-2"></div>
          </div>
        );
      }
    },
  });

  return result.toAIStreamResponse();
}
