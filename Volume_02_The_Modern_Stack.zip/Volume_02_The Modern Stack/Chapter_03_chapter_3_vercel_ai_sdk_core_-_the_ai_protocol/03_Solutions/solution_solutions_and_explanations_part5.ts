/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

// File: hooks/useResilientAI.ts
import { useAI, UseChatOptions } from 'ai/react';
import { useEffect, useState } from 'react';

// Mock server storage functions (in a real app, these would be API calls)
const saveStateToServer = async (sessionId: string, messages: any[]) => {
  console.log(`Saving state for session ${sessionId}:`, messages);
  // await fetch('/api/session', { method: 'POST', body: JSON.stringify({ id: sessionId, messages }) });
};

const loadStateFromServer = async (sessionId: string): Promise<any[] | null> => {
  console.log(`Loading state for session ${sessionId}`);
  // const res = await fetch(`/api/session/${sessionId}`);
  // return res.ok ? res.json() : null;
  return null; // Simulate no saved state initially
};

export function useResilientAI(sessionId: string, options?: UseChatOptions) {
  // 1. Use the standard hook
  const chat = useAI(options);
  const [isRecovering, setIsRecovering] = useState(false);

  // 2. Load initial state on mount
  useEffect(() => {
    const recoverSession = async () => {
      if (!sessionId) return;
      
      setIsRecovering(true);
      const savedMessages = await loadStateFromServer(sessionId);
      
      if (savedMessages && savedMessages.length > 0) {
        // If we have saved messages, populate the hook's initial state
        // Note: Depending on SDK version, you might need to manipulate the internal state directly 
        // or rely on the `initialMessages` prop if passed dynamically.
        // Here we assume we can update the state via the hook's methods or a provided setter.
        // For `useAI`, we typically pass `initialMessages` at initialization.
        // Since we are inside a hook, we can't easily change the initialization props.
        // A workaround is to use a key prop on the component using this hook to force a remount
        // with the new initialMessages, or use the `id` prop of useAI to sync state.
        
        // For this exercise, we will simulate updating the internal state:
        // (In a real implementation, you might use `chat.setMessages` if available, 
        // or rely on the `id` prop of `useAI` which syncs with localStorage/Server).
        
        console.log("Session recovered. Messages loaded.");
      }
      setIsRecovering(false);
    };

    recoverSession();
  }, [sessionId]);

  // 3. Save state on changes
  const { messages } = chat;
  useEffect(() => {
    if (sessionId && messages.length > 0 && !isRecovering) {
      // Debounce or save on specific intervals/events in a real app
      saveStateToServer(sessionId, messages);
    }
  }, [messages, sessionId, isRecovering]);

  // 4. Handle errors and resume
  const handleError = (error: Error) => {
    console.error("Stream error:", error);
    // Logic to show a "Resume" button could be added here
  };

  return {
    ...chat,
    isRecovering,
    // You could expose custom methods here, e.g., restoreVersion(versionId: string)
  };
}
