/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

// app/api/chat/route.ts
import { NextResponse } from 'next/server';

/**
 * Simulates an AI model by yielding chunks of text with a delay.
 * In a real application, this would be a call to an LLM like GPT-4.
 * @returns An AsyncGenerator that yields strings.
 */
async function* simulateAIModel(): AsyncGenerator<string, void, unknown> {
  const responseText = "Hello! This is a streamed response from the server. You should see these words appear one by one.";
  const words = responseText.split(' ');

  // Yield each word with a small delay to simulate network latency and token generation
  for (const word of words) {
    await new Promise(resolve => setTimeout(resolve, 50)); // 50ms delay
    yield word + ' ';
  }
}

/**
 * POST Handler: Handles the incoming chat request from the client.
 * It streams the response back using the Web Streams API.
 */
export async function POST(req: Request) {
  // 1. Create a ReadableStream to handle the async generator
  const stream = new ReadableStream({
    async start(controller) {
      try {
        // 2. Iterate over the simulated AI model chunks
        for await (const chunk of simulateAIModel()) {
          // 3. Encode the chunk into a Uint8Array and enqueue it to the stream
          const encodedChunk = new TextEncoder().encode(chunk);
          controller.enqueue(encodedChunk);
        }
        // 4. Close the stream when finished
        controller.close();
      } catch (error) {
        // Handle any errors during generation
        controller.error(error);
      }
    },
  });

  // 5. Return the stream with the correct content type for the Vercel AI SDK
  return new NextResponse(stream, {
    headers: {
      'Content-Type': 'text/plain; charset=utf-8',
      // 'Cache-Control': 'no-cache', // Optional: Prevents caching of the stream
    },
  });
}
