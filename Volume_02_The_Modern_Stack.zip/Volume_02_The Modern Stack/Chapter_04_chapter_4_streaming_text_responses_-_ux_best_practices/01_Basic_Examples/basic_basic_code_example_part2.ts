/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.ts
// Description: Basic Code Example
// ==========================================

// app/page.tsx
'use client'; // This is a Client Component

import { useChat } from 'ai/react';

/**
 * The main page component for our chat interface.
 * It uses the `useChat` hook to manage message state and API communication.
 */
export default function ChatPage() {
  // Destructure properties from the useChat hook
  const { messages, input, handleInputChange, handleSubmit, isLoading, error } = useChat({
    api: '/api/chat', // Point to our custom API route
  });

  return (
    <div style={{ maxWidth: '600px', margin: '0 auto', padding: '20px', fontFamily: 'sans-serif' }}>
      <h1>Streaming Text Demo</h1>
      
      {/* Message Display Area */}
      <div style={{ border: '1px solid #ccc', minHeight: '300px', padding: '10px', marginBottom: '10px', borderRadius: '8px' }}>
        {messages.length > 0 ? (
          messages.map((message) => (
            <div key={message.id} style={{ marginBottom: '10px' }}>
              <strong>{message.role === 'user' ? 'You: ' : 'AI: '}</strong>
              <span>{message.content}</span>
            </div>
          ))
        ) : (
          <p style={{ color: '#888' }}>No messages yet. Click the button to start.</p>
        )}
        
        {/* Loading State Indicator */}
        {isLoading && (
          <div style={{ color: '#666', fontStyle: 'italic' }}>
            AI is thinking...
          </div>
        )}

        {/* Error State Display */}
        {error && (
          <div style={{ color: 'red', marginTop: '10px' }}>
            Error: {error.message}
          </div>
        )}
      </div>

      {/* Action Buttons */}
      <div style={{ display: 'flex', gap: '10px' }}>
        {/* 
          We use a simple button instead of a form for this "Hello World" example 
          to trigger a specific, pre-defined AI response.
        */}
        <button 
          onClick={(e) => {
            e.preventDefault();
            // Manually trigger the API call with a user message
            handleSubmit({ preventDefault: () => {} } as any, {
              data: { message: "Tell me a simple fact." } // Mock data for the API
            });
          }}
          disabled={isLoading}
          style={{ 
            padding: '10px 20px', 
            backgroundColor: isLoading ? '#ccc' : '#0070f3', 
            color: 'white', 
            border: 'none', 
            borderRadius: '5px',
            cursor: isLoading ? 'not-allowed' : 'pointer'
          }}
        >
          {isLoading ? 'Streaming...' : 'Trigger AI Response'}
        </button>
      </div>
    </div>
  );
}
