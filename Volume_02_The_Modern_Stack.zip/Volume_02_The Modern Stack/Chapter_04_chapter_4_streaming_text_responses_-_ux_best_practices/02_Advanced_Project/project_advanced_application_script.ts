/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

import { OpenAIStream, StreamingTextResponse } from 'ai';
import OpenAI from 'openai';

// Initialize the OpenAI client.
// In a production environment, ensure OPENAI_API_KEY is set in your Vercel/Next.js environment variables.
const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY || '',
});

/**
 * POST /api/onboard
 * 
 * Handles the generation of onboarding steps based on user context.
 * Uses the Edge Runtime for optimized streaming performance.
 * 
 * @param {Request} req - The incoming HTTP request containing the user's prompt.
 * @returns {StreamingTextResponse} - A streamed response of text tokens.
 */
export async function POST(req: Request) {
  // Parse the JSON body to extract the prompt sent from the client.
  const { prompt } = await req.json();

  // Request the OpenAI API to generate a chat completion.
  // We specify 'stream: true' to receive tokens as they are generated.
  const response = await openai.chat.completions.create({
    model: 'gpt-4-turbo-preview',
    messages: [
      {
        role: 'system',
        content: `
          You are an expert SaaS onboarding assistant. 
          The user has just signed up for a project management tool. 
          Based on their input, generate a concise, 3-step onboarding checklist.
          Format the output using Markdown (bold headers, bullet points).
          Keep the tone friendly and professional.
        `,
      },
      {
        role: 'user',
        content: prompt,
      },
    ],
    temperature: 0.7,
    stream: true, // Critical for streaming
  });

  // Convert the OpenAI stream into a standard Web ReadableStream.
  const stream = OpenAIStream(response);

  // Return a StreamingTextResponse.
  // This sets the necessary headers (Transfer-Encoding: chunked) and pipes the stream.
  return new StreamingTextResponse(stream);
}
