/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script_part3.ts
// Description: Advanced Application Script
// ==========================================

'use client';

import { useCompletion } from 'ai/react';
import { useState } from 'react';

interface OnboardingWizardProps {
  initialContext: string; // Passed from the Server Component
}

export default function OnboardingWizard({ initialContext }: OnboardingWizardProps) {
  // State for the user's specific goal input
  const [input, setInput] = useState('');

  // Vercel AI SDK Hook: useCompletion
  // This hook manages the API call, streaming state, and UI updates.
  const {
    completion,    // The currently streamed text string
    input: aiInput, // Bound input state for the hook (optional, we manage our own)
    handleInputChange,
    handleSubmit,
    isLoading,    // Boolean indicating if the stream is active
    error,        // Error object if the request fails
  } = useCompletion({
    api: '/api/onboard', // The Edge API route defined above
    body: {
      // We can inject additional context here that wasn't available during the initial Server render
      context: initialContext,
    },
  });

  return (
    <div className="bg-white rounded-lg shadow-md p-6 space-y-6">
      {/* Input Form */}
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label htmlFor="goal" className="block text-sm font-medium text-gray-700">
            What is your primary goal for this quarter?
          </label>
          <input
            id="goal"
            type="text"
            value={input}
            onChange={(e) => {
              setInput(e.target.value);
              handleInputChange(e); // Sync with AI hook if using bound state
            }}
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm border p-2"
            placeholder="e.g., Launch the new marketing campaign"
            disabled={isLoading} // Disable during generation
          />
        </div>
        
        <button
          type="submit"
          disabled={isLoading || !input}
          className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 disabled:opacity-50"
        >
          {isLoading ? 'Generating...' : 'Generate Checklist'}
        </button>
      </form>

      {/* Error State */}
      {error && (
        <div className="text-red-600 bg-red-50 p-3 rounded border border-red-200">
          Error: {error.message}
        </div>
      )}

      {/* Streaming Output Area */}
      <div className="mt-6 p-4 bg-gray-50 rounded-md min-h-[150px] whitespace-pre-wrap">
        <h3 className="text-lg font-semibold text-gray-900 mb-2">Your Personalized Plan:</h3>
        
        {/* 
          UX Best Practice: 
          We render the 'completion' string directly. As tokens arrive from the stream, 
          React updates this text node incrementally.
          
          We also render a blinking cursor if loading to indicate active processing.
        */}
        <div className="text-gray-800 leading-relaxed">
          {completion}
          {isLoading && (
            <span className="inline-block w-2 h-4 bg-gray-500 animate-pulse ml-1 align-middle"></span>
          )}
        </div>

        {/* Empty State Helper */}
        {!isLoading && !completion && !error && (
          <p className="text-gray-400 italic">
            Enter a goal to see your AI-generated checklist here.
          </p>
        )}
      </div>
    </div>
  );
}
