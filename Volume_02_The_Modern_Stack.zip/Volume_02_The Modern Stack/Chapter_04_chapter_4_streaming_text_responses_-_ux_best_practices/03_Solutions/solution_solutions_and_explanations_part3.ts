/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

// File: app/api/chat/route.ts
import { streamText } from 'ai';
import { openai } from '@ai-sdk/openai';

// Define a safe context window limit (approximate token count)
const MAX_CONTEXT_TOKENS = 4000; 
// Approximate chars per token (rough heuristic for GPT models)
const CHARS_PER_TOKEN = 4;

export async function POST(req: Request) {
  // 1. Extract the messages from the request body.
  const { messages } = await req.json();

  // 2. Context Augmentation & Truncation Logic
  let augmentedMessages = [...messages];
  
  // Calculate approximate length (sum of all content strings)
  // In a production app, use a proper tokenizer like 'gpt-tokenizer' or 'tiktoken'
  const totalChars = augmentedMessages.reduce((acc, msg) => acc + msg.content.length, 0);
  const estimatedTokens = totalChars / CHARS_PER_TOKEN;

  if (estimatedTokens > MAX_CONTEXT_TOKENS) {
    console.log('Context window exceeded. Truncating history...');
    
    // Strategy: Keep the system prompt (if present) and the last few messages.
    // We filter out the oldest messages until we are under the limit.
    
    // 1. Identify the system prompt (usually the first message)
    const systemMessage = augmentedMessages[0].role === 'system' ? augmentedMessages[0] : null;
    
    // 2. The rest of the messages
    const conversationHistory = systemMessage ? augmentedMessages.slice(1) : augmentedMessages;
    
    // 3. Truncate from the start of the conversation history
    // Keep the most recent messages (e.g., last 4 exchanges) to maintain context
    const maxHistoryLength = 8; // Keep last 8 messages (approx 4 exchanges)
    const truncatedHistory = conversationHistory.slice(-maxHistoryLength);
    
    // 4. Reassemble
    augmentedMessages = systemMessage 
      ? [systemMessage, ...truncatedHistory] 
      : truncatedHistory;
  }

  // 3. Pass the augmented context to the LLM
  const result = await streamText({
    model: openai('gpt-4-turbo'),
    messages: augmentedMessages, // <--- The augmented context
  });

  return result.toAIStreamResponse();
}
