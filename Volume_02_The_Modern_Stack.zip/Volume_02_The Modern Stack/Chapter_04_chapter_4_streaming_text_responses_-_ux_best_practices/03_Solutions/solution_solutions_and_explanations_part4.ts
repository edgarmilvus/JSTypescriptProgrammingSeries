/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

// File: hooks/useStreamedText.ts
import { useState, useEffect, useRef } from 'react';

export function useStreamedText(textStream: string, mode: 'typewriter' | 'block') {
  const [displayedText, setDisplayedText] = useState('');
  
  // Ref to store the interval ID for cleanup
  const intervalRef = useRef<NodeJS.Timeout | null>(null);
  // Ref to store the buffer for block mode
  const bufferRef = useRef<string>('');

  useEffect(() => {
    // Reset displayed text when the stream changes significantly
    setDisplayedText('');
    bufferRef.current = '';
    
    // Clear any existing interval
    if (intervalRef.current) {
      clearInterval(intervalRef.current);
      intervalRef.current = null;
    }

    if (mode === 'typewriter') {
      let index = 0;
      
      // Start interval to type out characters
      intervalRef.current = setInterval(() => {
        if (index < textStream.length) {
          setDisplayedText((prev) => prev + textStream[index]);
          index++;
        } else {
          // Stream finished, clear interval
          if (intervalRef.current) clearInterval(intervalRef.current);
        }
      }, 15); // 15ms delay per character
    } 
    else if (mode === 'block') {
      // For block mode, we process the stream as it arrives
      // Since textStream is the full accumulated string from the parent,
      // we need to detect what's new vs what's already displayed.
      
      // Logic: We only append when we find sentence-ending punctuation
      // in the *new* part of the stream.
      
      // We use an interval here to simulate "checking" the stream for new blocks
      // In a real streaming scenario, this would be an event listener on a ReadableStream.
      intervalRef.current = setInterval(() => {
        // Append new content to buffer
        const newContent = textStream.slice(bufferRef.current.length);
        bufferRef.current += newContent;

        // Check for sentence endings (. ? !) followed by space or end of string
        // Regex explanation: Look for punctuation, optional closing quote/paren, followed by space or end
        const regex = /[^.!?]+[.!?]["')]*\s+/g; 
        
        let match;
        let lastIndex = 0;
        let readyText = '';

        // Find all complete sentences in the buffer
        while ((match = regex.exec(bufferRef.current)) !== null) {
          readyText += match[0];
          lastIndex = regex.lastIndex;
        }

        if (readyText) {
          setDisplayedText((prev) => prev + readyText);
          // Keep the remaining incomplete part in the buffer
          bufferRef.current = bufferRef.current.slice(lastIndex);
        }

        // If stream is fully received and buffer has remaining text, flush it
        if (textStream.length > 0 && textStream === bufferRef.current && bufferRef.current.length > 0) {
           setDisplayedText((prev) => prev + bufferRef.current);
           bufferRef.current = '';
           if (intervalRef.current) clearInterval(intervalRef.current);
        }
      }, 50); // Check for blocks every 50ms
    }

    // Cleanup function
    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    };
  }, [textStream, mode]);

  return displayedText;
}
