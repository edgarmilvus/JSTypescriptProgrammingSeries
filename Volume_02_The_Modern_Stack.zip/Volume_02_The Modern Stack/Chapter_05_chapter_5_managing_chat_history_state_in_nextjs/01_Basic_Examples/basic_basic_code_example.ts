/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

// app/components/ChatComponent.tsx
'use client';

import { useChat } from 'ai/react';
import { sendMessage } from '@/app/actions/chatActions';

/**
 * A simple chat component that leverages the Vercel AI SDK's `useChat` hook.
 * It handles the UI state, input rendering, and triggers the Server Action
 * for AI generation and history persistence.
 */
export default function ChatComponent({ initialMessages }: { initialMessages?: any[] }) {
  // useChat hook manages the local UI state (messages, input value, loading status)
  // It automatically handles streaming updates from the Server Action.
  const { messages, input, handleInputChange, handleSubmit, isLoading, error } = useChat({
    api: '/api/chat', // We will point this to our Server Action route
    initialMessages,
    // We inject our custom Server Action here to handle the request.
    // In a real Next.js App Router setup, we might route this via an API route
    // or directly call the action from the form submission.
    // For this example, we simulate the direct call pattern.
    onFinish: (message) => {
      // Optional: Trigger a side effect after streaming finishes
      console.log('Stream finished:', message);
    }
  });

  return (
    <div className="flex flex-col w-full max-w-md mx-auto p-4 border rounded-lg shadow-sm">
      <div className="flex flex-col gap-4 mb-4 h-96 overflow-y-auto">
        {messages.map((msg) => (
          <div
            key={msg.id}
            className={`p-3 rounded-lg ${
              msg.role === 'user'
                ? 'bg-blue-100 self-end text-blue-900'
                : 'bg-gray-100 self-start text-gray-900'
            }`}
          >
            <p className="text-sm font-semibold">{msg.role === 'user' ? 'You' : 'AI'}</p>
            <p className="mt-1">{msg.content}</p>
          </div>
        ))}
        {isLoading && (
          <div className="text-gray-500 text-sm animate-pulse">AI is thinking...</div>
        )}
        {error && (
          <div className="text-red-500 text-sm">Error: {error.message}</div>
        )}
      </div>

      {/* 
        The form submission is intercepted by useChat. 
        It calls the configured `api` endpoint (our Server Action) with the input.
      */}
      <form onSubmit={handleSubmit} className="flex gap-2">
        <input
          type="text"
          value={input}
          onChange={handleInputChange}
          placeholder="Type a message..."
          className="flex-1 p-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
          disabled={isLoading}
        />
        <button
          type="submit"
          disabled={isLoading}
          className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 disabled:opacity-50"
        >
          Send
        </button>
      </form>
    </div>
  );
}
