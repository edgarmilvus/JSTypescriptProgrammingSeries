/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.ts
// Description: Basic Code Example
// ==========================================

// app/actions/chatActions.ts
'use server';

import { streamText } from 'ai';
import { openai } from '@ai-sdk/openai'; // Assumes @ai-sdk/openai is installed
import { createStreamableValue } from 'ai/rsc';

// MOCK DATABASE: In a real app, use Vercel Postgres or similar.
// This simulates a key-value store for chat sessions.
const mockDb = new Map<string, any[]>();

/**
 * Server Action to handle chat messages.
 * This runs on the server, has access to the database, and streams the AI response.
 * 
 * @param history - The current conversation history (array of messages).
 * @param newMessage - The new user message string.
 * @returns A streamable value containing the AI response.
 */
export async function sendMessage(history: any[], newMessage: string) {
  // 1. Append user message to the history
  const currentHistory = [...history, { role: 'user', content: newMessage }];
  
  // 2. Generate a unique Session ID (simplified for this example)
  // In a real app, this might come from URL params or a cookie.
  const sessionId = 'session-123';

  // 3. Persist the User Message immediately to the database
  // Note: We are overwriting the whole history here for simplicity.
  mockDb.set(sessionId, currentHistory);

  // 4. Prepare the AI Stream
  const stream = createStreamableValue();

  // 5. Run the AI generation asynchronously
  (async () => {
    try {
      // streamText generates tokens one by one
      const result = await streamText({
        model: openai('gpt-3.5-turbo'),
        messages: currentHistory,
        system: 'You are a helpful assistant. Keep responses brief.',
      });

      // 6. Stream the AI response to the client
      for await (const chunk of result.textStream) {
        stream.update(chunk);
      }

      // 7. Finalize the stream
      stream.done();

      // 8. Persist the AI response to the database
      // We need to reconstruct the full message object after streaming.
      // In a production app, we might accumulate the chunks or store the final result.
      const finalAiMessage = { role: 'assistant', content: result.text }; // result.text is the full accumulated text
      const finalHistory = [...currentHistory, finalAiMessage];
      mockDb.set(sessionId, finalHistory);
      
      console.log(`Session ${sessionId} saved. Total messages: ${finalHistory.length}`);
    } catch (err) {
      stream.error(err);
    }
  })();

  return { stream: stream.value, sessionId };
}
