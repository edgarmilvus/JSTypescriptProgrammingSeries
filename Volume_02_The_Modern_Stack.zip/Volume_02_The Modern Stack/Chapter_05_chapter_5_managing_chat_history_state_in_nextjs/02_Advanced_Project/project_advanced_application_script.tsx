/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.tsx
// Description: Advanced Application Script
// ==========================================

'use client';

import { useChat } from 'ai/react';
import { useState, useEffect, useOptimistic, startTransition } from 'react';
import { Database } from '@/lib/database.types'; // Assumed Supabase/Vercel Postgres types

// ============================================================================
// 1. TYPE DEFINITIONS & STATE STRUCTURE
// ============================================================================

/**
 * Represents a single message in the chat history.
 * Extends the standard AI SDK message to include a unique ID and parent reference
 * for branching capabilities.
 */
type ChatMessage = {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
  parentId: string | null; // Null if it's the root of a branch
};

/**
 * The shape of the conversation thread.
 * We store messages in an array, but the branching logic relies on the `parentId`
 * to reconstruct the visual tree or specific timelines.
 */
type ChatState = {
  messages: ChatMessage[];
  isStreaming: boolean;
};

// ============================================================================
// 2. SERVER ACTIONS (Simulated for Context)
// ============================================================================

/**
 * SERVER ACTION: saveMessage
 * Persists a single message to the database.
 * In a real app, this would interact directly with Vercel Postgres.
 * 
 * @param message - The message object to save
 * @returns The saved message with DB-generated ID
 */
async function saveMessage(message: Omit<ChatMessage, 'id'>): Promise<ChatMessage> {
  // Simulate network latency
  await new Promise(resolve => setTimeout(resolve, 300));
  
  // Mock DB Insert
  const savedMessage: ChatMessage = {
    ...message,
    id: `msg_${Math.random().toString(36).substr(2, 9)}`,
  };
  
  console.log('[Server] Saved message to DB:', savedMessage.id);
  return savedMessage;
}

/**
 * SERVER ACTION: getConversationHistory
 * Fetches the full conversation history.
 * Used in the parent Server Component to hydrate the initial client state.
 */
export async function getConversationHistory(): Promise<ChatMessage[]> {
  // Simulate fetching from DB
  return [
    {
      id: 'msg_root_1',
      role: 'user',
      content: 'What is the capital of France?',
      timestamp: new Date(Date.now() - 100000),
      parentId: null,
    },
    {
      id: 'msg_root_2',
      role: 'assistant',
      content: 'The capital of France is Paris.',
      timestamp: new Date(Date.now() - 95000),
      parentId: 'msg_root_1',
    },
  ];
}

// ============================================================================
// 3. CLIENT COMPONENT: CHAT INTERFACE
// ============================================================================

interface ChatInterfaceProps {
  initialMessages: ChatMessage[];
}

export default function ChatInterface({ initialMessages }: ChatInterfaceProps) {
  // -- State Management --
  // We use `useOptimistic` to handle the "Optimistic UI" requirement.
  // This allows us to immediately render messages before the server confirms them,
  // then reconcile them once the server responds.
  const [optimisticMessages, addOptimisticMessage] = useOptimistic<
    ChatMessage[],
    Omit<ChatMessage, 'id'>
  >(initialMessages, (state, newMessage) => {
    return [...state, { ...newMessage, id: `optimistic_${Date.now()}` }];
  });

  // Local state for branching logic (tracking which message we are replying to)
  const [activeParentId, setActiveParentId] = useState<string | null>(null);

  // -- Vercel AI SDK Integration --
  const { 
    messages: aiStreamMessages, 
    input, 
    handleInputChange, 
    handleSubmit, 
    isLoading, 
    append 
  } = useChat({
    api: '/api/chat', // Standard AI SDK endpoint
    onFinish: (message) => {
      // When streaming finishes, we need to persist this to our main state
      // and sync with the database.
      startTransition(async () => {
        const savedMsg = await saveMessage({
          role: 'assistant',
          content: message.content,
          timestamp: new Date(),
          parentId: activeParentId, // Link to the specific branch parent
        });
        // In a real app, we would trigger a revalidation of the parent data
        // or update a global state manager here.
      });
    }
  });

  // -- Branching Logic Handler --
  /**
   * Handles the "Branch" action. When a user clicks "Branch" on a specific message,
   * we set that message as the new parent for the subsequent input.
   */
  const handleBranchSelect = (messageId: string) => {
    setActiveParentId(messageId);
    // Visual feedback could be added here (e.g., highlighting the active branch)
  };

  // -- Combined Message View --
  // We merge the optimistic local state with the streaming AI SDK state.
  // The AI SDK handles the streaming text chunks, while `optimisticMessages`
  // handles the structural insertion of the message object.
  const displayMessages = [...optimisticMessages];

  // If the AI is currently streaming, we append the streaming message to the view
  // Note: In a complex app, we might merge these based on IDs, but for this demo
  // we append the streaming message to the end of the list if it's not already there.
  if (aiStreamMessages.length > 0) {
    const lastStreamMsg = aiStreamMessages[aiStreamMessages.length - 1];
    const exists = displayMessages.some(m => m.id === lastStreamMsg.id);
    if (!exists && lastStreamMsg.content) {
      // Map AI SDK message to our ChatMessage type
      displayMessages.push({
        id: lastStreamMsg.id,
        role: lastStreamMsg.role,
        content: lastStreamMsg.content,
        timestamp: new Date(),
        parentId: activeParentId, // Link to current branch
      });
    }
  }

  // -- Render --
  return (
    <div className="flex flex-col h-full max-w-4xl mx-auto p-4 bg-white shadow-lg rounded-lg">
      {/* Header: Shows current branching context */}
      <div className="border-b pb-4 mb-4">
        <h2 className="text-xl font-bold text-gray-800">Chat Thread</h2>
        {activeParentId && (
          <div className="mt-2 text-sm text-blue-600 bg-blue-50 p-2 rounded">
            <span className="font-semibold">Branching Mode:</span> Replying to message{' '}
            <code className="bg-blue-100 px-1 rounded">{activeParentId}</code>
            <button 
              onClick={() => setActiveParentId(null)}
              className="ml-2 text-xs underline hover:text-blue-800"
            >
              (Exit Branch)
            </button>
          </div>
        )}
      </div>

      {/* Message List */}
      <div className="flex-1 overflow-y-auto space-y-4 mb-4">
        {displayMessages.map((msg) => (
          <div 
            key={msg.id} 
            className={`p-3 rounded-lg max-w-[80%] ${
              msg.role === 'user' 
                ? 'self-end bg-blue-600 text-white ml-auto' 
                : 'self-start bg-gray-200 text-gray-900'
            }`}
          >
            <div className="text-xs opacity-75 mb-1">
              {msg.role.toUpperCase()} • {msg.id}
            </div>
            <div className="whitespace-pre-wrap">{msg.content}</div>
            
            {/* Branching UI Control */}
            {msg.role === 'assistant' && (
              <button 
                onClick={() => handleBranchSelect(msg.id)}
                className="mt-2 text-xs bg-white/20 hover:bg-white/30 px-2 py-1 rounded transition-colors"
              >
                Branch from here
              </button>
            )}
          </div>
        ))}
        
        {/* Loading Indicator for Streaming */}
        {isLoading && (
          <div className="text-gray-400 text-sm animate-pulse">
            AI is thinking...
          </div>
        )}
      </div>

      {/* Input Form */}
      <form onSubmit={(e) => {
        e.preventDefault();
        
        // 1. Optimistic Update: Add user message immediately to UI
        const tempId = `user_${Date.now()}`;
        addOptimisticMessage({
          role: 'user',
          content: input,
          timestamp: new Date(),
          parentId: activeParentId,
        });

        // 2. Persist User Message to DB
        startTransition(async () => {
          await saveMessage({
            role: 'user',
            content: input,
            timestamp: new Date(),
            parentId: activeParentId,
          });
        });

        // 3. Trigger AI Streaming
        append({
          content: input,
          role: 'user',
        }, {
          data: { parentId: activeParentId } // Custom data passed to API route
        });
      }} className="flex gap-2">
        <input
          type="text"
          value={input}
          onChange={handleInputChange}
          placeholder="Type a message..."
          className="flex-1 border border-gray-300 rounded px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
          disabled={isLoading}
        />
        <button 
          type="submit" 
          disabled={isLoading}
          className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 disabled:opacity-50"
        >
          Send
        </button>
      </form>
    </div>
  );
}
