/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// app/actions.ts
'use server';

import { prisma } from '@/lib/prisma'; // Assumes Prisma client setup
import { revalidatePath } from 'next/cache';

export interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  chatId: string;
  createdAt: Date;
}

// 1. Save a single message to the database
export async function saveMessage(
  chatId: string, 
  role: 'user' | 'assistant', 
  content: string
) {
  try {
    await prisma.message.create({
      data: {
        chatId,
        role,
        content,
      },
    });
    
    // Optional: Revalidate the path if displaying a list of chats
    // revalidatePath('/chats');
  } catch (error) {
    console.error('Failed to save message:', error);
    throw new Error('Database error');
  }
}

// 2. Load all messages for a specific chat ID
export async function loadChatHistory(chatId: string): Promise<Message[]> {
  try {
    const messages = await prisma.message.findMany({
      where: {
        chatId,
      },
      orderBy: {
        createdAt: 'asc',
      },
    });
    return messages;
  } catch (error) {
    console.error('Failed to load chat history:', error);
    return [];
  }
}
