/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

// lib/context-utils.ts

// 1. Token Estimation Utility
export function estimateTokens(text: string): number {
  // Rough approximation: 1 token ≈ 4 characters for English text.
  // This is a simulation; production apps often use specific tokenizer libraries (like gpt-tokenizer).
  return Math.ceil(text.length / 4);
}

// 2. Context Trimmer Function
export function prepareContext(messages: Message[], maxTokens: number): Message[] {
  // Always include the first system message if it exists
  const systemMessage = messages.find(msg => msg.role === 'system');
  const conversationMessages = messages.filter(msg => msg.role !== 'system');

  let currentTokens = systemMessage ? estimateTokens(systemMessage.content) : 0;
  const selectedMessages: Message[] = [];

  // If system message exists, add it first
  if (systemMessage) {
    selectedMessages.push(systemMessage);
  }

  // Iterate backwards from the most recent message (end of array)
  for (let i = conversationMessages.length - 1; i >= 0; i--) {
    const msg = conversationMessages[i];
    const tokenCount = estimateTokens(msg.content);

    // Check if adding this message exceeds the limit
    if (currentTokens + tokenCount > maxTokens) {
      // If it exceeds, we stop adding older messages (sliding window closes)
      break;
    }

    // Add message to the beginning of the selected array (to maintain chronological order)
    selectedMessages.unshift(msg);
    currentTokens += tokenCount;
  }

  // Sort to ensure correct order: System -> Oldest -> Newest
  return selectedMessages.sort((a, b) => {
    // Keep system message at the top if it exists
    if (a.role === 'system') return -1;
    if (b.role === 'system') return 1;
    return 0; // Maintain existing relative order for others
  });
}
