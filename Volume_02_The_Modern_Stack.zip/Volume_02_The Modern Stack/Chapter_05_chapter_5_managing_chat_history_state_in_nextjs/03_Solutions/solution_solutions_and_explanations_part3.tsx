/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

// app/components/ChartComponent.tsx
'use client';

interface ChartProps {
  type: 'bar';
  data: { label: string; value: number }[];
}

export default function ChartComponent({ data }: ChartProps) {
  // Simple SVG Bar Chart Rendering
  const maxValue = Math.max(...data.map(d => d.value));
  const barWidth = 40;
  const gap = 10;
  const height = 150;

  return (
    <div className="p-4 border rounded-lg bg-gray-50">
      <h4 className="text-sm font-bold mb-2">Sales Data Chart</h4>
      <svg width={data.length * (barWidth + gap)} height={height}>
        {data.map((item, index) => {
          const barHeight = (item.value / maxValue) * (height - 20);
          const x = index * (barWidth + gap);
          const y = height - barHeight - 20;
          
          return (
            <g key={index}>
              <rect x={x} y={y} width={barWidth} height={barHeight} fill="#3b82f6" />
              <text x={x + barWidth / 2} y={height - 5} textAnchor="middle" fontSize="10">
                {item.label}
              </text>
            </g>
          );
        })}
      </svg>
    </div>
  );
}
