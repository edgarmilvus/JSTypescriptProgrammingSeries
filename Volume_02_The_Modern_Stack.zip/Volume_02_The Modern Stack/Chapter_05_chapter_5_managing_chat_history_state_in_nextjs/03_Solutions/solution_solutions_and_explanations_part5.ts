/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

// types.ts
export interface Message {
  id: string;
  parentId: string | null; // Points to the previous message in the chain
  branchId: string;        // Unique ID for this specific branch (e.g., 'branch-1')
  role: 'user' | 'assistant';
  content: string;
  // ... other fields like createdAt
}

// app/hooks/useChatTree.ts
import { useState } from 'react';

export function useChatTree() {
  // State holds all messages across all branches
  const [messages, setMessages] = useState<Message[]>([]);
  // State tracks which branch is currently active
  const [activeBranchId, setActiveBranchId] = useState<string>('main');

  // Helper to get messages for the current branch (linear traversal)
  const getMessagesForActiveBranch = (): Message[] => {
    // Filter by active branch
    const branchMessages = messages.filter(m => m.branchId === activeBranchId);
    
    // Sort linearly based on parentId (simplified logic for demo)
    // In a real app, you might build a tree structure or rely on creation time
    return branchMessages.sort((a, b) => 
      new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime()
    );
  };

  // Function to handle regeneration
  const regenerateResponse = (parentUserMessageId: string) => {
    const parentMsg = messages.find(m => m.id === parentUserMessageId);
    if (!parentMsg) return;

    // Create a new branch ID
    const newBranchId = `branch-${Date.now()}`;
    
    // Find the existing assistant response to "branch" from
    const existingResponse = messages.find(m => m.parentId === parentUserMessageId);
    
    if (existingResponse) {
      // In a real app, you would likely trigger an API call here.
      // For state simulation, we can mark the old response as inactive 
      // or simply start a new stream that will be added to the new branch.
      
      // Update the active branch ID to the new one
      setActiveBranchId(newBranchId);
      
      // Note: The actual API call would happen here, resulting in a new Assistant message
      // added to the state with the new `branchId` and `parentId`.
    }
  };

  // Function to add a message (handles branching logic)
  const addMessage = (msg: Omit<Message, 'branchId'>) => {
    setMessages(prev => [...prev, { ...msg, branchId: activeBranchId }]);
  };

  return {
    messages: getMessagesForActiveBranch(),
    allMessages: messages,
    activeBranchId,
    addMessage,
    regenerateResponse,
    setActiveBranchId,
  };
}
