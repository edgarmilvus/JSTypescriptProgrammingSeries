/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part6.tsx
// Description: Solutions and Explanations
// ==========================================

// app/components/OptimisticChat.tsx
'use client';

import { useChat } from 'ai/react';
import { useOptimistic, useState } from 'react';
import { Button } from './ui/button'; // Assuming a UI library

export default function OptimisticChat() {
  const { messages, input, handleInputChange, handleSubmit, isLoading, error } = useChat();
  
  // State to hold the "Thinking..." placeholder
  const [thinkingId, setThinkingId] = useState<string | null>(null);

  // Define the shape of our optimistic message
  type OptimisticMessage = {
    id: string;
    role: 'user' | 'assistant';
    content: string;
  };

  // useOptimistic hook
  const [optimisticMessages, addOptimisticMessage] = useOptimistic<
    OptimisticMessage[],
    OptimisticMessage
  >(messages, (state, newMessage) => {
    return [...state, newMessage];
  });

  const handleFormSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();

    // 1. Create a temporary ID for the optimistic user message
    const tempId = `temp-${Date.now()}`;
    
    // 2. Immediately update UI with User Message
    addOptimisticMessage({
      id: tempId,
      role: 'user',
      content: input,
    });

    // 3. Add a placeholder for the assistant response
    const thinkingMsgId = `thinking-${Date.now()}`;
    setThinkingId(thoughtMsgId);
    addOptimisticMessage({
      id: thinkingMsgId,
      role: 'assistant',
      content: 'Thinking...', // Placeholder text
    });

    // 4. Trigger the actual API call
    // The useChat hook handles the streaming response and replaces the messages array.
    // We need to ensure our optimistic state aligns with the hook's state.
    await handleSubmit(e);

    // 5. Cleanup placeholder
    setThinkingId(null);
  };

  // We render the optimistic messages if they exist, otherwise fallback to SDK messages
  // Note: In a complex app, you might merge these arrays carefully. 
  // Here, we rely on the fact that 'useChat' updates 'messages' once the stream starts,
  // effectively replacing the optimistic ones.
  
  return (
    <div className="flex flex-col h-full">
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {optimisticMessages.map((msg) => (
          <div key={msg.id} className={`p-2 rounded ${msg.role === 'user' ? 'bg-blue-100' : 'bg-gray-100'}`}>
            {msg.content}
            {msg.id === thinkingId && <span className="animate-pulse">...</span>}
          </div>
        ))}
        {error && <div className="text-red-500">Error: {error.message}</div>}
      </div>

      <form onSubmit={handleFormSubmit} className="p-4 border-t flex gap-2">
        <input
          value={input}
          onChange={handleInputChange}
          className="flex-1 border rounded px-2 py-1"
          disabled={isLoading}
        />
        <Button type="submit" disabled={isLoading}>
          {isLoading ? 'Sending...' : 'Send'}
        </Button>
      </form>
    </div>
  );
}
