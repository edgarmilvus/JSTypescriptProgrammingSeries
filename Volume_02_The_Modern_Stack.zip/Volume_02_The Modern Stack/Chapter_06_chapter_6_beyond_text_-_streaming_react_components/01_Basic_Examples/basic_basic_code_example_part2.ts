/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.ts
// Description: Basic Code Example
// ==========================================

// app/page.tsx
'use client';

import { useCompletion } from 'ai/react';

export default function DashboardPage() {
  // 1. Initialize the useCompletion hook
  // The /api/generate-report endpoint handles the stream generation.
  const { completion, input, handleInputChange, handleSubmit, isLoading } = useCompletion({
    api: '/api/generate-report',
  });

  return (
    <div className="max-w-2xl mx-auto p-8 space-y-6">
      <h1 className="text-2xl font-bold">SaaS Dashboard</h1>
      
      {/* 2. Input Form */}
      <form onSubmit={handleSubmit} className="flex gap-2">
        <input
          type="text"
          value={input}
          onChange={handleInputChange}
          placeholder="Ask for a report (e.g., 'Q3 Sales')..."
          className="flex-1 p-2 border rounded text-black"
          disabled={isLoading}
        />
        <button 
          type="submit" 
          className="px-4 py-2 bg-blue-600 text-white rounded disabled:opacity-50"
          disabled={isLoading}
        >
          Generate
        </button>
      </form>

      {/* 3. Display Area for Streamed Components */}
      <div className="space-y-4 border-t pt-4">
        <h2 className="font-semibold text-lg">Output:</h2>
        
        {/* 
          The `completion` string from useCompletion is actually a serialized 
          React component tree (RSC payload) in this context. 
          We render it directly. 
        */}
        <div className="rendered-content">
          {completion ? (
            // In a real RSC streaming setup, the SDK might return a stream of UI nodes.
            // For this simplified 'Hello World' using useCompletion, 
            // we assume the stream payload is rendered into the completion state.
            // Note: In strict RSC streaming, you might use a dedicated hook like `useStreamableUI`.
            // However, `useCompletion` is often adapted for this or the payload is parsed.
            // Here, we treat the output as the rendered HTML string or component tree provided by the SDK.
            <div dangerouslySetInnerHTML={{ __html: completion }} />
          ) : (
            <p className="text-gray-400 italic">No report generated yet.</p>
          )}
          
          {/* Loading Indicator */}
          {isLoading && (
            <div className="flex items-center gap-2 text-blue-500">
              <span className="animate-pulse">●</span>
              <span>Streaming component...</span>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
