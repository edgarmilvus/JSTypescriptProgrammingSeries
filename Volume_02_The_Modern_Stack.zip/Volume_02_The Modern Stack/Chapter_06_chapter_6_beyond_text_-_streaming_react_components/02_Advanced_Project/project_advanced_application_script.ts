/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// app/actions/analyze-document.ts
'use server';

import { streamObject } from 'ai';
import { z } from 'zod';
import { createStreamableValue } from 'ai/rsc';
import { StateGraph, END, START } from '@langchain/langgraph';
import { BaseMessage, HumanMessage } from '@langchain/core/messages';
import { ChatOpenAI } from '@langchain/openai';

// ============================================================================
// 1. DEFINITIONS & TYPES
// ============================================================================

/**
 * Represents the state of our LangGraph node.
 * This is passed between nodes in the cyclical graph.
 */
interface AgentState {
  messages: BaseMessage[];
  iterationCount: number;
  maxIterations: number;
  finalAnalysis?: string;
}

// ============================================================================
// 2. LANGGRAPH CONFIGURATION (CYCLICAL STRUCTURE & MAX ITERATION POLICY)
// ============================================================================

/**
 * The Max Iteration Policy is implemented as a conditional edge.
 * It checks the state's iteration count against the limit.
 * If exceeded, it routes to 'END' to prevent infinite loops.
 */
const checkIterationLimit = (state: AgentState) => {
  console.log(`[Policy Check] Iteration: ${state.iterationCount}/${state.maxIterations}`);
  
  // If we hit the limit, terminate the graph
  if (state.iterationCount >= state.maxIterations) {
    return 'end_node';
  }
  
  // Otherwise, continue to the refinement node
  return 'refinement_node';
};

/**
 * Node 1: The Refinement Loop
 * This node simulates the "ReAct" cycle (Reasoning and Acting).
 * It generates a partial analysis and decides if it needs more work.
 */
const refinementNode = async (state: AgentState) => {
  const model = new ChatOpenAI({ 
    model: 'gpt-4-turbo-preview', 
    temperature: 0.7 
  });

  // Increment iteration count
  const nextIteration = state.iterationCount + 1;

  // Prompt engineering for iterative refinement
  const prompt = `
    Iteration ${nextIteration} of ${state.maxIterations}.
    Current Context: ${JSON.stringify(state.messages)}
    
    Task: Refine the document analysis. 
    Focus on extracting key themes and identifying potential risks.
    If the analysis is comprehensive, mark it as "FINAL".
  `;

  const response = await model.invoke([new HumanMessage(prompt)]);

  return {
    messages: [...state.messages, response],
    iterationCount: nextIteration,
  };
};

/**
 * Node 2: Finalizer
 * Prepares the final output for streaming.
 */
const finalizeNode = async (state: AgentState) => {
  const lastMessage = state.messages[state.messages.length - 1].content as string;
  
  return {
    ...state,
    finalAnalysis: lastMessage,
    messages: [...state.messages, new HumanMessage("Analysis Complete.")],
  };
};

// Construct the Graph
const workflow = new StateGraph<AgentState>({
  channels: {
    messages: {
      value: (x: BaseMessage[], y: BaseMessage[]) => (y ? x.concat(y) : x),
      default: () => [],
    },
    iterationCount: {
      value: (x: number, y?: number) => (y !== undefined ? y : x),
      default: () => 0,
    },
    maxIterations: {
      value: (x: number, y?: number) => (y !== undefined ? y : x),
      default: () => 3, // Hardcoded limit for this demo
    },
    finalAnalysis: {
      value: (x?: string, y?: string) => (y !== undefined ? y : x),
      default: () => undefined,
    },
  },
});

// Add nodes
workflow.addNode('refinement_node', refinementNode);
workflow.addNode('finalize_node', finalizeNode);
workflow.addNode('end_node', finalizeNode); // Alias for termination

// Add edges
// 1. Start -> Refinement
workflow.addEdge(START, 'refinement_node');

// 2. Refinement -> Conditional Check (The Cyclical Logic)
workflow.addConditionalEdges(
  'refinement_node',
  checkIterationLimit,
  {
    'refinement_node': 'refinement_node', // Loops back to self
    'end_node': 'end_node',               // Terminates
  }
);

// 3. End Node -> END
workflow.addEdge('end_node', END);

// Compile the graph
const app = workflow.compile();

// ============================================================================
// 3. SERVER ACTION (STREAMING LOGIC)
// ============================================================================

/**
 * The primary Server Action called by the client.
 * It initializes the graph and streams the output.
 */
export async function streamDocumentAnalysis(documentText: string) {
  // Create a streamable value to push updates to the client
  const stream = createStreamableValue();

  (async () => {
    try {
      // Initialize graph state
      const initialState: AgentState = {
        messages: [new HumanMessage(`Document: ${documentText}`)],
        iterationCount: 0,
        maxIterations: 3,
      };

      // Execute the cyclical graph
      const finalState = await app.invoke(initialState);

      // Stream the final result
      // In a real app, we might stream intermediate steps too.
      // Here we stream the final accumulated analysis.
      stream.update(finalState.finalAnalysis || "No analysis generated.");
      
      stream.done();
    } catch (error) {
      stream.error(error);
    }
  })();

  return { stream: stream.value };
}
