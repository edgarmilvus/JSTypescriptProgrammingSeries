/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script_part2.tsx
// Description: Advanced Application Script
// ==========================================

// app/components/DocumentAnalyzer.tsx
'use client';

import { useState } from 'react';
import { streamDocumentAnalysis } from '@/app/actions/analyze-document';
import { readStreamableValue } from 'ai/rsc';

// ============================================================================
// 4. CLIENT COMPONENT (UI RENDERING)
// ============================================================================

export default function DocumentAnalyzer() {
  const [analysis, setAnalysis] = useState<string>('');
  const [isProcessing, setIsProcessing] = useState<boolean>(false);
  const [status, setStatus] = useState<string>('Idle');

  /**
   * Handles the form submission and initiates the server-side graph execution.
   */
  const handleAnalyze = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setIsProcessing(true);
    setAnalysis('');
    setStatus('Initializing LangGraph...');

    const formData = new FormData(e.currentTarget);
    const text = formData.get('document') as string;

    try {
      // Call the Server Action
      const { stream } = await streamDocumentAnalysis(text);

      // Read the streamable value
      // The client receives updates incrementally as the graph iterates
      for await (const chunk of readStreamableValue(stream)) {
        if (chunk) {
          setStatus('Refining analysis...');
          setAnalysis(chunk);
        }
      }

      setStatus('Analysis Complete');
    } catch (error) {
      console.error(error);
      setStatus('Error occurred');
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="max-w-2xl mx-auto p-6 bg-white shadow-lg rounded-lg border border-gray-200">
      <h2 className="text-xl font-bold mb-4 text-gray-800">
        SaaS Document Risk Analyzer
      </h2>
      
      <form onSubmit={handleAnalyze} className="space-y-4">
        <div>
          <label htmlFor="document" className="block text-sm font-medium text-gray-700">
            Upload Document Text
          </label>
          <textarea
            id="document"
            name="document"
            rows={6}
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm border p-2"
            placeholder="Paste your contract or report text here..."
            required
            disabled={isProcessing}
          />
        </div>
        
        <button
          type="submit"
          disabled={isProcessing}
          className={`w-flex items-center justify-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white 
            ${isProcessing ? 'bg-gray-400 cursor-not-allowed' : 'bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500'}`}
        >
          {isProcessing ? (
            <span className="flex items-center">
              <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
              </svg>
              Processing...
            </span>
          ) : (
            'Analyze Document'
          )}
        </button>
      </form>

      {/* Status Indicator */}
      <div className="mt-4 text-sm text-gray-500">
        Status: <span className="font-semibold text-indigo-600">{status}</span>
      </div>

      {/* Streamed Result Area */}
      {analysis && (
        <div className="mt-6 p-4 bg-gray-50 rounded-md border border-gray-200">
          <h3 className="text-sm font-semibold text-gray-700 mb-2">Analysis Result</h3>
          <div className="prose prose-sm text-gray-800 whitespace-pre-wrap">
            {analysis}
          </div>
        </div>
      )}
    </div>
  );
}
