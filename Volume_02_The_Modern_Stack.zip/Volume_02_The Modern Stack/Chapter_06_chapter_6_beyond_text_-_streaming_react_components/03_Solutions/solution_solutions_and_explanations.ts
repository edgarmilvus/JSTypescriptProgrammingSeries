/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

'use server';

import { streamUI } from 'ai/rsc';
import { openai } from '@ai-sdk/openai';
import { ReactNode } from 'react';

// 1. Define the Props for the ThinkingStep component
interface ThinkingStepProps {
  thought: string;
  index: number;
}

// 2. Define the Server Component to be streamed
const ThinkingStep = async ({ thought, index }: ThinkingStepProps) => {
  // This is a Server Component streamed to the client
  return (
    <details className="mb-2 border border-blue-200 rounded-md bg-blue-50 p-2">
      <summary className="cursor-pointer font-semibold text-blue-800">
        Thought Step {index}
      </summary>
      <div className="mt-2 text-sm text-gray-700 p-2 bg-white rounded">
        {thought}
        {/* Client Component for interactivity (Copy Button) */}
        <div className="mt-2 text-right">
          <CopyThoughtButton thought={thought} />
        </div>
      </div>
    </details>
  );
};

// 3. Define the Client Component for the Copy Button
'use client';
import { useState } from 'react';

function CopyThoughtButton({ thought }: { thought: string }) {
  const [copied, setCopied] = useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(thought);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <button
      onClick={handleCopy}
      className="text-xs bg-gray-200 hover:bg-gray-300 px-2 py-1 rounded transition-colors"
    >
      {copied ? 'Copied!' : 'Copy Thought'}
    </button>
  );
}

// 4. The Server Action that streams the UI
export async function streamThinkingProcess(input: string) {
  let hasStartedThinking = false;
  let stepIndex = 0;

  const result = await streamUI({
    model: openai('gpt-4o'),
    prompt: `Generate a chain of thought for: "${input}". Mark specific thoughts with <thought> tags.`,
    text: ({ content }) => {
      // Standard text streaming
      return <span>{content}</span>;
    },
    tools: {
      thinking_step: {
        description: 'A single step in the reasoning process',
        parameters: z.object({
          step: z.string().describe('The thought process step'),
        }),
        generate: async function* ({ step }) {
          // Stream the ThinkingStep component
          yield <div>Loading thought...</div>; // Optional immediate placeholder
          await new Promise((resolve) => setTimeout(resolve, 500)); // Simulate delay
          return <ThinkingStep thought={step} index={++stepIndex} />;
        },
      },
    },
  });

  return result.value;
}
