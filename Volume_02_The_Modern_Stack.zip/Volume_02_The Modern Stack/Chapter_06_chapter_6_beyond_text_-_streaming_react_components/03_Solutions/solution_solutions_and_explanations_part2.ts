/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

'use server';

import { streamUI } from 'ai/rsc';
import { openai } from '@ai-sdk/openai';
import { z } from 'zod';

// 1. Define the Async Server Component
async function ResourceCard({ url, name }: { url: string; name: string }) {
  // Simulate an async fetch to an external API
  const fetchData = async () => {
    try {
      // In a real app, this would be a fetch call
      // await fetch(`https://api.example.com/status?url=${url}`);
      await new Promise((resolve) => setTimeout(resolve, 1500)); // Simulate network delay
      
      // Mock data
      return {
        status: 'Operational',
        lastChecked: new Date().toISOString(),
        latency: '45ms',
      };
    } catch (error) {
      return null; // Return null on error
    }
  };

  const data = await fetchData();

  if (!data) {
    return (
      <div className="p-4 bg-red-100 border border-red-400 text-red-700 rounded">
        <strong>Failed to fetch data for {name}</strong>
      </div>
    );
  }

  return (
    <div className="p-4 bg-white border border-gray-300 rounded shadow-sm mb-2">
      <h3 className="font-bold text-lg">{name}</h3>
      <div className="mt-2 text-sm text-gray-600 space-y-1">
        <p>Status: <span className="text-green-600 font-semibold">{data.status}</span></p>
        <p>Latency: {data.latency}</p>
        <p>Last Checked: {new Date(data.lastChecked).toLocaleTimeString()}</p>
      </div>
      
      {/* Client Component for Refresh */}
      <RefreshButton url={url} name={name} />
    </div>
  );
}

// 2. Client Component for Refreshing
'use client';

function RefreshButton({ url, name }: { url: string; name: string }) {
  // In a real app, this would trigger a Server Action to re-fetch
  // and update the specific component in the UI state
  const handleRefresh = () => {
    alert(`Simulating refresh for ${name} at ${url}`);
    // Implementation detail: This would require a complex state update mechanism
    // to replace this specific component instance in the parent list.
  };

  return (
    <button 
      onClick={handleRefresh}
      className="mt-3 text-xs bg-blue-500 text-white px-3 py-1 rounded hover:bg-blue-600"
    >
      Refresh Data
    </button>
  );
}

// 3. The Server Action
export async function streamResourceRecommendation(resource: string) {
  const result = await streamUI({
    model: openai('gpt-4o'),
    prompt: `Recommend a resource for ${resource} and provide the URL.`,
    text: ({ content }) => <span>{content}</span>,
    tools: {
      recommend_resource: {
        description: 'Recommends a resource',
        parameters: z.object({
          name: z.string(),
          url: z.string(),
        }),
        generate: async ({ name, url }) => {
          // Stream the ResourceCard immediately
          // React will automatically handle the async data fetching on the server
          // and stream the final HTML once the data is ready.
          return <ResourceCard url={url} name={name} />;
        },
      },
    },
  });

  return result.value;
}
