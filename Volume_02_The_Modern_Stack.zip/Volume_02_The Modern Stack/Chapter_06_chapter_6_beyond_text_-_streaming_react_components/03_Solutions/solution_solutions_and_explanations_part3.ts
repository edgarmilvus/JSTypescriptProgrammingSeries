/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

'use server';

import { streamUI } from 'ai/rsc';
import { openai } from '@ai-sdk/openai';
import { z } from 'zod';

// State interface for the graph
interface RefinementState {
  iteration: number;
  history: Array<{ type: string; content: React.ReactNode }>;
  feedback?: string;
}

// 1. Define the Streamed Components
const DraftResponse = ({ content, iteration }: { content: string; iteration: number }) => (
  <div className="p-3 border border-yellow-400 bg-yellow-50 rounded mb-2">
    <h4 className="font-bold text-yellow-700">Draft Iteration {iteration}</h4>
    <p>{content}</p>
  </div>
);

const RegeneratedResponse = ({ content, iteration }: { content: string; iteration: number }) => (
  <div className="p-3 border border-green-400 bg-green-50 rounded mb-2">
    <h4 className="font-bold text-green-700">Refined Iteration {iteration}</h4>
    <p>{content}</p>
  </div>
);

// 2. The LangGraph Logic (Simplified for Server Action context)
async function executeRefinementGraph(state: RefinementState, userInput?: string) {
  const MAX_ITERATIONS = 3;
  
  // Termination Condition
  if (state.iteration >= MAX_ITERATIONS) {
    return { 
      ...state, 
      done: true,
      nextComponent: <div className="p-4 bg-blue-800 text-white text-center font-bold">Final Version Complete</div>
    };
  }

  // Node: Generate Draft (or Regenerate based on feedback)
  const prompt = state.feedback 
    ? `Improve the draft based on feedback: "${state.feedback}". Previous draft: "${userInput}"`
    : `Generate a draft for: "${userInput}"`;

  const draftResult = await streamUI({
    model: openai('gpt-4o'),
    prompt: prompt,
    text: ({ content }) => <span>{content}</span>, // Fallback
  });

  // In a real graph, this would be a node transition
  // Here we simulate the output of the GenerateDraft/Regenerate node
  const newContent = draftResult.value; // This assumes text response for simplicity, could be component

  return {
    ...state,
    iteration: state.iteration + 1,
    nextComponent: state.feedback 
      ? <RegeneratedResponse content={newContent} iteration={state.iteration + 1} />
      : <DraftResponse content={newContent} iteration={state.iteration + 1} />,
    done: false
  };
}

// 3. The Server Action handling the cycle
export async function runRefinementLoop(
  currentState: RefinementState, 
  userInput: string, 
  feedback?: string
) {
  // Update state with feedback if provided
  const updatedState = {
    ...currentState,
    feedback: feedback,
  };

  // Execute the graph step
  const result = await executeRefinementGraph(updatedState, userInput);

  // If not done, we return the component and the updated state to the client
  // The client will render the component and wait for the next interaction
  return {
    component: result.nextComponent,
    newState: {
      iteration: result.iteration,
      history: [...currentState.history, { type: feedback ? 'regenerate' : 'draft', content: result.nextComponent }],
      feedback: undefined // Reset feedback
    },
    done: result.done
  };
}
