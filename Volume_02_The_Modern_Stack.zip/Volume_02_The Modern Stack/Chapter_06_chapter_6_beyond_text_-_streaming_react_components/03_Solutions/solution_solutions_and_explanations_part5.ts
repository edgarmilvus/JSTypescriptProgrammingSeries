/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

'use server';

import { streamUI } from 'ai/rsc';
import { openai } from '@ai-sdk/openai';
import { z } from 'zod';

// 1. The Server Component (Streamed)
// Note: It accepts initial code, but doesn't control the state after streaming.
async function CodeEditor({ initialCode, language }: { initialCode: string; language: string }) {
  // This component simply renders the initial state provided by the AI.
  // The actual state management happens inside the 'use client' wrapper below.
  return (
    <CodeEditorClient initialCode={initialCode} language={language} />
  );
}

// 2. The Client Component (Interactive)
'use client';

import { useState, useRef, useEffect } from 'react';

function CodeEditorClient({ initialCode, language }: { initialCode: string; language: string }) {
  // Internal state ensures stability. Changes to 'initialCode' prop 
  // only update state if the component mounts fresh or explicitly handles it.
  const [code, setCode] = useState(initialCode);
  const [output, setOutput] = useState<string[]>([]);
  const [isRunning, setIsRunning] = useState(false);

  // Effect to update local state ONLY if the prop changes significantly 
  // (e.g., AI suggests a completely new block).
  useEffect(() => {
    if (initialCode && code === '') {
      setCode(initialCode);
    }
  }, [initialCode]);

  const runCode = () => {
    setIsRunning(true);
    setOutput([]);
    
    // Sandbox Simulation using a Function constructor (eval alternative)
    // In production, use Web Workers or isolated iframes.
    try {
      // Capture console.log
      const logs: string[] = [];
      const safeLog = (...args: any[]) => logs.push(args.join(' '));
      
      // Create a function from the code string
      const runner = new Function('console', code);
      runner({ log: safeLog });
      
      setOutput(logs.length > 0 ? logs : ['Code executed (no output)']);
    } catch (error: any) {
      setOutput([`Error: ${error.message}`]);
    } finally {
      setIsRunning(false);
    }
  };

  const copyToClipboard = () => {
    navigator.clipboard.writeText(code);
    // Visual feedback could be added here
  };

  return (
    <div className="border rounded-md overflow-hidden bg-gray-900 text-white font-mono text-sm my-4">
      <div className="flex justify-between items-center bg-gray-800 p-2 border-b border-gray-700">
        <span className="text-gray-400">{language}</span>
        <div className="space-x-2">
          <button onClick={copyToClipboard} className="text-gray-400 hover:text-white">
            Copy
          </button>
          <button 
            onClick={runCode} 
            disabled={isRunning}
            className="bg-green-600 hover:bg-green-700 text-white px-3 py-1 rounded disabled:opacity-50"
          >
            {isRunning ? 'Running...' : 'Run'}
          </button>
        </div>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2">
        <textarea
          value={code}
          onChange={(e) => setCode(e.target.value)}
          className="w-full h-48 bg-gray-900 text-gray-100 p-2 focus:outline-none resize-none"
          spellCheck="false"
        />
        <div className="border-l border-gray-700 p-2 bg-gray-800 min-h-[12rem]">
          <div className="text-gray-400 mb-1">Output:</div>
          <pre className="whitespace-pre-wrap text-green-400">
            {output.join('\n')}
          </pre>
        </div>
      </div>
    </div>
  );
}

// 3. The Server Action to stream the component
export async function streamCodeSnippet(description: string) {
  const result = await streamUI({
    model: openai('gpt-4o'),
    prompt: `Generate a ${description}. Provide the code in a <code> tag.`,
    text: ({ content }) => <span>{content}</span>,
    tools: {
      code_block: {
        description: 'Generates a code snippet',
        parameters: z.object({
          code: z.string(),
          language: z.string(),
        }),
        generate: async ({ code, language }) => {
          return <CodeEditor initialCode={code} language={language} />;
        },
      },
    },
  });

  return result.value;
}
