/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part6.ts
// Description: Solutions and Explanations
// ==========================================

'use server';

import { streamUI } from 'ai/rsc';
import { openai } from '@ai-sdk/openai';
import { z } from 'zod';

// 1. Define Skeleton Components
const ResourceCardSkeleton = () => (
  <div className="p-4 border rounded mb-2 bg-gray-100 animate-pulse h-32">
    <div className="h-4 bg-gray-300 rounded w-3/4 mb-2"></div>
    <div className="h-3 bg-gray-300 rounded w-1/2"></div>
  </div>
);

const ThinkingStepSkeleton = () => (
  <div className="p-2 border rounded mb-2 bg-blue-50 animate-pulse h-16">
    <div className="h-3 bg-blue-200 rounded w-1/3 mb-1"></div>
    <div className="h-2 bg-blue-100 rounded w-full"></div>
  </div>
);

// 2. The Priority Wrapper Component
async function PriorityWrapper({ 
  priority, 
  children 
}: { 
  priority: 'high' | 'low'; 
  children: React.ReactNode 
}) {
  // If high priority, we stream the content immediately.
  // If low priority, we introduce an artificial delay to ensure the skeleton 
  // is visible for at least 500ms, preventing flash of content.
  if (priority === 'low') {
    await new Promise((resolve) => setTimeout(resolve, 600));
  }
  return <>{children}</>;
}

// 3. The Component Generators
async function ResourceCard({ url, name }: { url: string; name: string }) {
  // Simulate data fetch
  await new Promise((resolve) => setTimeout(resolve, 1000));
  return (
    <div className="p-4 border border-green-200 bg-green-50 rounded mb-2">
      <strong>{name}</strong>
      <div className="text-xs text-gray-500 mt-1">Status: Online ({url})</div>
    </div>
  );
}

async function ThinkingStep({ thought }: { thought: string }) {
  return (
    <div className="p-2 border border-blue-200 bg-blue-50 rounded mb-2">
      <div className="font-bold text-xs">Thought:</div>
      <div className="text-sm">{thought}</div>
    </div>
  );
}

// 4. The Server Action with Priority Logic
export async function streamWithSkeletons(type: 'resource' | 'thought', content: string, priority: 'high' | 'low') {
  const result = await streamUI({
    model: openai('gpt-4o'),
    prompt: `Generate a ${type} for: ${content}`,
    text: ({ content }) => <span>{content}</span>,
    tools: {
      generate_item: {
        description: 'Generates the requested item',
        parameters: z.object({
          data: z.string(),
        }),
        generate: async ({ data }) => {
          // Step 1: Always stream the Skeleton first for 'low' priority
          // For 'high' priority, we might skip this or keep it minimal
          if (priority === 'low') {
            if (type === 'resource') return <ResourceCardSkeleton />;
            if (type === 'thought') return <ThinkingStepSkeleton />;
          }

          // Step 2: Wrap the actual component in PriorityWrapper
          const actualContent = type === 'resource' 
            ? <ResourceCard url={data} name={data} /> 
            : <ThinkingStep thought={data} />;

          return (
            <PriorityWrapper priority={priority}>
              {actualContent}
            </PriorityWrapper>
          );
        },
      },
    },
  });

  return result.value;
}
