/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

// app/api/chat/route.ts

import { streamText, ToolExecutionUnion } from 'ai';
import { z } from 'zod';
import { openai } from '@ai-sdk/openai';

// IMPORTANT: This tool executes on the Edge Runtime.
// It simulates a network call to a weather API.
const fetchWeatherTool = {
  description: 'Get the current weather for a given city.',
  parameters: z.object({
    city: z.string().describe('The city name (e.g., "New York", "London")'),
  }),
  // The execute function runs ONLY when the LLM decides to call this tool.
  // It is executed on the server (Edge) before the result is streamed to the client.
  execute: async ({ city }: { city: string }) => {
    // Simulate a network delay to show loading states
    await new Promise((resolve) => setTimeout(resolve, 1500));

    // Mock data based on city (simple logic for demo)
    const weatherMap: Record<string, string> = {
      'new york': 'Sunny, 22°C',
      'london': 'Rainy, 15°C',
      'tokyo': 'Cloudy, 18°C',
    };

    const weather = weatherMap[city.toLowerCase()] || 'Unknown weather conditions';

    return {
      city,
      weather,
      timestamp: new Date().toISOString(),
    };
  },
};

export async function POST(req: Request) {
  const { messages } = await req.json();

  // Initialize the text streamer
  const result = await streamText({
    model: openai('gpt-4-turbo-preview'),
    messages,
    tools: {
      getWeather: fetchWeatherTool as ToolExecutionUnion,
    },
    // This system prompt guides the LLM to use the tool when appropriate
    system: 'You are a helpful assistant. Use the getWeather tool to answer questions about the weather.',
  });

  // Stream the response back to the client
  // The SDK handles the serialization of tool calls and results automatically
  return result.toAIStreamResponse();
}
