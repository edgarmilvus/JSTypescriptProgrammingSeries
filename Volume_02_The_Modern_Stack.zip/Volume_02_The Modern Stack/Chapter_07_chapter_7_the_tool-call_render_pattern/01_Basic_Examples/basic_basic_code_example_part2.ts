/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.ts
// Description: Basic Code Example
// ==========================================

// app/page.tsx (Client Component)

'use client';

import { useChat } from 'ai/react';

export default function Chat() {
  const { messages, input, handleInputChange, handleSubmit, isLoading } = useChat({
    api: '/api/chat',
  });

  return (
    <div className="flex flex-col w-full max-w-md mx-auto p-4 space-y-4">
      <div className="border rounded-lg p-4 h-64 overflow-y-auto space-y-2">
        {messages.map((message, index) => (
          <div key={index} className="p-2 rounded bg-gray-100">
            <strong>{message.role === 'user' ? 'You: ' : 'AI: '}</strong>
            
            {/* 
              CRITICAL RENDER LOGIC:
              We check for the presence of a 'toolInvocations' property on the message.
              This property is injected by the Vercel AI SDK when a tool is called.
            */}
            {message.toolInvocations ? (
              message.toolInvocations.map((tool, toolIndex) => (
                <div key={toolIndex} className="mt-2 p-2 bg-blue-50 text-sm text-blue-800 rounded">
                  {/* Render based on tool state */}
                  {tool.state === 'call' && (
                    <span>⚡ Executing tool: {tool.toolName} for {tool.args.city}...</span>
                  )}
                  {tool.state === 'result' && (
                    <span>
                      ✅ Result: {tool.result.city} is {tool.result.weather}
                    </span>
                  )}
                </div>
              ))
            ) : (
              // Render standard text content
              <span>{message.content}</span>
            )}
          </div>
        ))}
        
        {/* Loading Indicator for the stream */}
        {isLoading && (
          <div className="text-gray-500 italic">AI is thinking...</div>
        )}
      </div>

      <form onSubmit={handleSubmit} className="flex gap-2">
        <input
          type="text"
          value={input}
          onChange={handleInputChange}
          placeholder="Ask about weather in New York..."
          className="flex-1 border p-2 rounded"
        />
        <button type="submit" className="bg-black text-white px-4 py-2 rounded">
          Send
        </button>
      </form>
    </div>
  );
}
