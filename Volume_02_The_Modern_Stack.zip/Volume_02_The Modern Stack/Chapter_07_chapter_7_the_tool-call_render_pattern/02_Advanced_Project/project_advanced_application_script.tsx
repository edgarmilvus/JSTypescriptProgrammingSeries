/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.tsx
// Description: Advanced Application Script
// ==========================================

// app/project-dashboard/page.tsx

import { openai } from '@ai-sdk/openai';
import { streamText, ToolExecutionResult } from 'ai';
import { auth } from '@/auth'; // Hypothetical auth helper
import { db } from '@/db'; // Hypothetical DB client
import { Chat } from './_components/chat';

// ==========================================
// 1. Server-Side Context Fetching
// ==========================================

/**
 * Fetches initial conversation context and user data directly within the Server Component.
 * This eliminates client-side waterfalls and ensures the LLM has immediate access to 
 * relevant project data (e.g., existing tasks, user role).
 * 
 * @returns {Promise<ServerContext>} The pre-fetched data for the AI system prompt.
 */
async function getServerContext() {
  const session = await auth();
  
  if (!session?.user?.id) {
    throw new Error('Unauthorized');
  }

  // Fetch user profile and current project tasks from the database
  const [user, tasks] = await Promise.all([
    db.user.findUnique({ where: { id: session.user.id } }),
    db.task.findMany({ where: { projectId: 'proj_123' } }),
  ]);

  return {
    userName: user?.name || 'User',
    existingTasks: tasks.map(t => t.title),
    projectId: 'proj_123',
  };
}

// ==========================================
// 2. Tool Definitions (Server-Side)
// ==========================================

/**
 * Tool Invocation Signature: createTask
 * Accepts parameters from the LLM and persists data to the database.
 * Returns a structured result for the LLM to interpret.
 */
const createTaskTool = {
  description: 'Create a new task in the current project',
  parameters: {
    type: 'object',
    properties: {
      title: { type: 'string', description: 'The title of the task' },
      description: { type: 'string', description: 'Detailed description of the task' },
      priority: { type: 'string', enum: ['low', 'medium', 'high'] },
    },
    required: ['title'],
  },
  execute: async ({ title, description, priority }: { title: string; description?: string; priority?: string }) => {
    // Simulate DB write
    const newTask = await db.task.create({
      data: {
        title,
        description: description || 'No description provided',
        priority: priority || 'medium',
        projectId: 'proj_123',
        status: 'todo',
      },
    });

    return {
      success: true,
      taskId: newTask.id,
      message: `Task "${title}" created successfully with ID ${newTask.id}.`,
    };
  },
};

/**
 * Tool Invocation Signature: assignTask
 * Assigns an existing task to a specific user.
 */
const assignTaskTool = {
  description: 'Assign a task to a specific user',
  parameters: {
    type: 'object',
    properties: {
      taskId: { type: 'string', description: 'The ID of the task to assign' },
      assigneeName: { type: 'string', description: 'The name of the user to assign to' },
    },
    required: ['taskId', 'assigneeName'],
  },
  execute: async ({ taskId, assigneeName }: { taskId: string; assigneeName: string }) => {
    // Simulate DB update
    const updatedTask = await db.task.update({
      where: { id: taskId },
      data: { assignee: assigneeName },
    });

    return {
      success: true,
      message: `Task "${updatedTask.title}" assigned to ${assigneeName}.`,
    };
  },
};

// ==========================================
// 3. The Server Component (Stream Handler)
// ==========================================

/**
 * The main Server Component.
 * 1. Fetches context.
 * 2. Defines the AI model and tools.
 * 3. Streams the response directly to the client.
 */
export default async function ProjectDashboard() {
  const context = await getServerContext();

  // Define the system prompt using the pre-fetched context
  const systemPrompt = `
    You are a helpful project management assistant for user ${context.userName}.
    The current project ID is ${context.projectId}.
    Existing tasks are: ${context.existingTasks.join(', ') || 'None'}.
    
    You have access to tools to create and assign tasks.
    If you create a task, you must provide a title.
    If you assign a task, you must have a valid Task ID.
  `;

  // The main action handler for the component
  async function handleAction(prevState: any, formData: FormData) {
    'use server';
    
    const message = formData.get('message') as string;

    // Initialize the AI stream with tools
    const result = await streamText({
      model: openai('gpt-4-turbo-preview'),
      system: systemPrompt,
      messages: [{ role: 'user', content: message }],
      tools: {
        createTask: createTaskTool,
        assignTask: assignTaskTool,
      },
      // Control randomness: 0.1 ensures deterministic tool selection
      temperature: 0.1,
    });

    // Return the stream to the client
    return result.toAIStreamResponse();
  }

  // Render the client-side chat component, passing the server action
  return <Chat action={handleAction} />;
}
