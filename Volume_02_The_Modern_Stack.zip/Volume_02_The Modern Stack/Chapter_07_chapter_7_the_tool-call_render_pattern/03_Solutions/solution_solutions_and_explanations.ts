/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

'use server';

import { streamText } from 'ai';
import { openai } from '@ai-sdk/openai'; // Assuming OpenAI provider is configured

// --- Server Action (actions.ts) ---

export async function generateSummary(documentId: string, style: 'bullet_points' | 'paragraph') {
  // 1. Define the tool within the streamText call
  const result = await streamText({
    model: openai('gpt-4o-mini'), // Or any model supporting tools
    messages: [{ role: 'user', content: `Summarize document ${documentId}` }],
    tools: {
      summarizeDocument: {
        description: 'Summarizes a document based on style',
        parameters: {
          type: 'object',
          properties: {
            documentId: { type: 'string' },
            style: { type: 'string', enum: ['bullet_points', 'paragraph'] }
          },
          required: ['documentId', 'style']
        },
        execute: async ({ documentId, style }) => {
          // 2. Simulate processing delay
          await new Promise(resolve => setTimeout(resolve, 2000));

          const baseSummary = "This document discusses the architectural benefits of React Server Components, emphasizing performance optimization and reduced client-side JavaScript bundle size.";
          
          // 3. Format based on style
          if (style === 'bullet_points') {
            return `• ${baseSummary}\n• It also covers security implications.`;
          }
          return baseSummary; // Default paragraph
        }
      }
    }
  });

  return result.toAIStreamResponse();
}

// --- Client Component (SummaryGenerator.tsx) ---

'use client';

import { useStreamableValue, useActions } from 'ai/rsc';
import { useState } from 'react';
import type { generateSummary } from './actions'; // Import type for type safety

export function SummaryGenerator({ documentId }: { documentId: string }) {
  const [inputStyle, setInputStyle] = useState<'bullet_points' | 'paragraph'>('paragraph');
  const { generateSummary } = useActions();
  
  // Hook to handle streaming state
  const [summaryState, setSummaryState] = useState<{
    status: 'idle' | 'loading' | 'success' | 'error';
    content: string;
  }>({ status: 'idle', content: '' });

  const handleSubmit = async () => {
    // 4. Reset state and set loading
    setSummaryState({ status: 'loading', content: 'Generating summary...' });

    try {
      // Invoke server action
      const response = await generateSummary(documentId, inputStyle);
      
      // Read the stream
      const reader = response.body?.getReader();
      if (!reader) throw new Error('No stream');

      const decoder = new TextDecoder();
      let fullContent = '';

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        
        // Decode and accumulate chunks
        const chunk = decoder.decode(value, { stream: true });
        fullContent += chunk;
        
        // Update UI with partial content
        setSummaryState({ status: 'loading', content: fullContent });
      }

      setSummaryState({ status: 'success', content: fullContent });

    } catch (error) {
      // 6. Error Handling
      setSummaryState({ status: 'error', content: 'An error occurred while generating the summary.' });
    }
  };

  return (
    <div className="p-4 border rounded">
      <div className="mb-4">
        <label className="block mb-2 text-sm font-medium">Summary Style:</label>
        <select 
          value={inputStyle} 
          onChange={(e) => setInputStyle(e.target.value as any)}
          className="border p-2 rounded w-full"
          disabled={summaryState.status === 'loading'}
        >
          <option value="paragraph">Paragraph</option>
          <option value="bullet_points">Bullet Points</option>
        </select>
      </div>

      {/* 5. UI State Management */}
      {summaryState.status === 'idle' && (
        <button onClick={handleSubmit} className="bg-blue-500 text-white px-4 py-2 rounded">
          Generate Summary
        </button>
      )}

      {summaryState.status === 'loading' && (
        <div className="flex items-center gap-2 text-gray-600">
          <span className="animate-spin">⏳</span>
          <span>{summaryState.content}</span>
        </div>
      )}

      {summaryState.status === 'success' && (
        <div className="p-3 bg-green-50 border border-green-200 rounded">
          <p className="font-bold mb-1">Summary:</p>
          <p>{summaryState.content}</p>
          <button onClick={() => setSummaryState({ status: 'idle', content: '' })} className="text-sm text-blue-600 mt-2 underline">Reset</button>
        </div>
      )}

      {summaryState.status === 'error' && (
        <div className="p-3 bg-red-50 border border-red-200 text-red-700 rounded">
          {summaryState.content}
        </div>
      )}
    </div>
  );
}
