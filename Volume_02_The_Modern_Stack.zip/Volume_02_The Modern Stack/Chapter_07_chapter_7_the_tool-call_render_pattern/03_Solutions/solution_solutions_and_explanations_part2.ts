/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

'use server';

import { streamText } from 'ai';
import { openai } from '@ai-sdk/openai';

export async function researchWorkflow(topic: string) {
  return streamText({
    model: openai('gpt-4o-mini'),
    messages: [{ role: 'user', content: `Research topic: ${topic}` }],
    tools: {
      searchArticles: {
        description: 'Search for articles on a topic',
        parameters: { type: 'object', properties: { topic: { type: 'string' } }, required: ['topic'] },
        execute: async ({ topic }) => {
          // Simulate search delay
          await new Promise(r => setTimeout(r, 1500));
          // Mock data - Interactive Challenge: Handle empty array
          if (topic.toLowerCase().includes('quantum')) return []; 
          return [`Article 1: ${topic} Basics`, `Article 2: Advanced ${topic}`];
        }
      },
      generateCitations: {
        description: 'Generate citations from articles',
        parameters: { 
          type: 'object', 
          properties: { articles: { type: 'array', items: { type: 'string' } } }, 
          required: ['articles'] 
        },
        execute: async ({ articles }) => {
          await new Promise(r => setTimeout(r, 1000));
          return articles.map(a => `[Citation] ${a}`).join('\n');
        }
      },
      suggestAlternativeTopics: {
        description: 'Suggest alternatives if no results found',
        parameters: { type: 'object', properties: {} },
        execute: async () => {
          await new Promise(r => setTimeout(r, 1000));
          return "No results found. Try 'React Server Components' or 'AI Integration'.";
        }
      }
    },
    // Chaining Logic: Use onToolFinish to trigger next step
    onToolFinish: async (result, toolName, toolCallId) => {
      if (toolName === 'searchArticles') {
        const articles = result;
        
        // Interactive Challenge: Conditional Branching
        if (!articles || articles.length === 0) {
          // Trigger the alternative tool manually
          return { tool: 'suggestAlternativeTopics', args: {} };
        }

        // Trigger the next tool in the chain
        return { tool: 'generateCitations', args: { articles } };
      }
    }
  });
}

// --- Client Component (ResearchAssistant.tsx) ---
'use client';

import { useActions } from 'ai/rsc';
import { useState } from 'react';
import type { researchWorkflow } from './actions';

export function ResearchAssistant() {
  const { researchWorkflow } = useActions();
  const [ui, setUi] = useState<React.ReactNode[]>([]);
  const [input, setInput] = useState('');

  const runResearch = async () => {
    setUi([<div key="start">Starting research on: {input}...</div>]);
    
    const response = await researchWorkflow(input);
    const reader = response.body?.getReader();
    const decoder = new TextDecoder();

    // We need to accumulate text to render structured updates
    let currentStepText = '';
    
    if (reader) {
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        
        const chunk = decoder.decode(value, { stream: true });
        currentStepText += chunk;

        // This is a simplified visualization. 
        // In a real app, you might parse specific markers or use the SDK's `useStreamableValue` 
        // which handles incremental JSON updates if structured.
        // Here we just append chunks to show streaming.
        
        // To visualize the "Chain", we can cheat slightly by looking at the accumulated text
        // or simply render the stream as it comes.
        setUi(prev => {
            const last = prev[prev.length - 1];
            // Update the last node or add a new one if we detect a logical break (not perfectly detectable in raw text stream without markers)
            // For this exercise, we will render the raw stream to show continuity.
            return [<div key="stream">{currentStepText}</div>];
        });
      }
    }
  };

  return (
    <div>
      <input value={input} onChange={e => setInput(e.target.value)} placeholder="Topic..." />
      <button onClick={runResearch}>Research</button>
      <div className="mt-4 p-4 bg-gray-100 min-h-[100px]">
        {ui}
      </div>
    </div>
  );
}
