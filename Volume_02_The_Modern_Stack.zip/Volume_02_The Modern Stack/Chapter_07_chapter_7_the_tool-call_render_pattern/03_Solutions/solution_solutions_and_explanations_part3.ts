/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

// --- Server Component (CodeGeneratorPage.tsx) ---

// 1. RSC Parent Component
export default async function CodeGeneratorPage() {
  // 2. Simulated DB fetch for static data
  const supportedLanguages = ['Python', 'JavaScript', 'TypeScript', 'Go'];
  
  // Interactive Challenge: Fetch System Prompt
  const systemPrompt = "You are a helpful coding assistant. Output clean, efficient code.";

  // Pass data directly as props (no client-side fetch needed)
  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-4">Code Generator</h1>
      {/* 5. Zero JS for static data: 'languages' and 'systemPrompt' are rendered on server */}
      <CodeInput languages={supportedLanguages} systemPrompt={systemPrompt} />
    </div>
  );
}

// --- Client Component (CodeInput.tsx) ---

'use client';

import { useActions } from 'ai/rsc';
import { useState } from 'react';
import type { generateCode } from './actions';

// 3. Client Component receiving props
export function CodeInput({ languages, systemPrompt }: { languages: string[], systemPrompt: string }) {
  const [language, setLanguage] = useState(languages[0]);
  const [description, setDescription] = useState('');
  const [code, setCode] = useState('');
  const [loading, setLoading] = useState(false);

  const { generateCode } = useActions();

  const handleGenerate = async () => {
    setLoading(true);
    setCode('');
    
    // 4. Streaming Execution
    const response = await generateCode({ language, description, systemPrompt });
    
    // Read stream
    const reader = response.body?.getReader();
    const decoder = new TextDecoder();
    if (reader) {
      let result = '';
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        result += decoder.decode(value, { stream: true });
        setCode(result);
      }
    }
    setLoading(false);
  };

  return (
    <div className="grid grid-cols-2 gap-4">
      <div className="flex flex-col gap-2">
        <label>Language:</label>
        <select value={language} onChange={(e) => setLanguage(e.target.value)} className="border p-2">
          {languages.map(lang => <option key={lang} value={lang}>{lang}</option>)}
        </select>
        
        <label>Description:</label>
        <textarea 
          value={description} 
          onChange={(e) => setDescription(e.target.value)} 
          className="border p-2 h-24"
          placeholder="e.g., A function to calculate factorial"
        />
        
        <button 
          onClick={handleGenerate} 
          disabled={loading}
          className="bg-blue-600 text-white p-2 rounded disabled:opacity-50"
        >
          {loading ? 'Generating...' : 'Generate Code'}
        </button>
      </div>

      <div className="bg-slate-800 text-green-400 p-4 rounded font-mono text-sm whitespace-pre-wrap">
        {code || '// Output will appear here'}
      </div>
    </div>
  );
}

// --- Server Action (actions.ts) ---

'use server';

import { streamText } from 'ai';
import { openai } from '@ai-sdk/openai';

export async function generateCode({ language, description, systemPrompt }: { 
  language: string; 
  description: string; 
  systemPrompt: string 
}) {
  return streamText({
    model: openai('gpt-4o-mini'),
    // 5. Incorporate the system prompt passed from RSC
    system: systemPrompt, 
    prompt: `Generate ${language} code for: ${description}`,
    // Simulate streaming
    experimental_streamSimulateFunctionCalls: true, 
  });
}
