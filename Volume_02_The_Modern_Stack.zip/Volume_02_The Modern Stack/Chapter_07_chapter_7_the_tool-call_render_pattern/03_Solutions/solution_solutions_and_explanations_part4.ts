/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

'use server';

import { streamText } from 'ai';
import { openai } from '@ai-sdk/openai';

// Helper to simulate API call
async function fetchExternalAPI() {
  // 50% chance of failure
  if (Math.random() > 0.5) {
    throw new Error('External API Network Error');
  }
  return '$150.00';
}

function getMockPrice() {
  return '$149.99 (Cached)';
}

export async function getStockPrice(symbol: string, retry: boolean = false) {
  return streamText({
    model: openai('gpt-4o-mini'),
    messages: [{ role: 'user', content: `Get price for ${symbol}` }],
    tools: {
      fetchStockPrice: {
        description: 'Fetches stock price',
        parameters: { 
          type: 'object', 
          properties: { 
            symbol: { type: 'string' },
            retry: { type: 'boolean' } // Pass retry flag
          }, 
          required: ['symbol'] 
        },
        execute: async ({ symbol, retry }) => {
          // 1. Unreliable Tool Logic
          // If retry is true, bypass the random error simulation
          if (!retry) {
             // Simulate random failure logic (simplified for demo, usually handled before calling tool)
             // In this specific exercise structure, we handle the try/catch inside execute
             // to stream the error message.
          }

          try {
            // If retry is forced, we assume success or we try the fetch again
            if (retry) {
               // Force success for demo
               return `Current Price: $152.50 (Retried successfully)`;
            }

            // Attempt primary fetch
            const price = await fetchExternalAPI();
            return `Current Price: ${price}`;
            
          } catch (error) {
            // 2. Fallback Mechanism
            // Instead of throwing (which kills the stream), we catch and return a specific message
            // or trigger the fallback logic.
            
            const fallbackPrice = getMockPrice();
            
            // 3. UI Feedback via Stream
            // We can return a string that includes the warning
            return `⚠️ Live data unavailable (API Error). Showing cached data: ${fallbackPrice}`;
          }
        }
      }
    }
  });
}

// --- Client Component (StockAnalyzer.tsx) ---

'use client';

import { useActions } from 'ai/rsc';
import { useState } from 'react';

export function StockAnalyzer() {
  const { getStockPrice } = useActions();
  const [output, setOutput] = useState('');
  const [loading, setLoading] = useState(false);

  const fetchData = async (retry = false) => {
    setLoading(true);
    setOutput('');
    
    const response = await getStockPrice('AAPL', retry);
    const reader = response.body?.getReader();
    const decoder = new TextDecoder();

    if (reader) {
      let text = '';
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        text += decoder.decode(value, { stream: true });
        setOutput(text);
      }
    }
    setLoading(false);
  };

  return (
    <div className="p-4 border rounded max-w-md">
      <h2 className="font-bold mb-2">Financial Data Analyzer</h2>
      <div className="flex gap-2 mb-4">
        <button onClick={() => fetchData(false)} disabled={loading} className="bg-blue-500 text-white px-3 py-1 rounded">
          Fetch Price
        </button>
      </div>

      <div className="p-3 bg-gray-100 rounded min-h-[60px] font-mono text-sm">
        {loading ? 'Fetching...' : output}
      </div>

      {/* 4. Retry Mechanism */}
      {output.includes('Live data unavailable') && (
        <div className="mt-3">
          <p className="text-sm text-gray-600 mb-1">Data looks wrong?</p>
          <button onClick={() => fetchData(true)} className="bg-green-600 text-white px-3 py-1 rounded text-sm">
            Retry Connection
          </button>
        </div>
      )}
    </div>
  );
}
