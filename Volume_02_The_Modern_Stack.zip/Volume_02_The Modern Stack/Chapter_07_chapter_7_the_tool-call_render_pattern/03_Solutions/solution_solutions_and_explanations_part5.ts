/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

digraph ToolCallFlow {
    rankdir=TB;
    node [fontname="Arial", shape=box, style="rounded,filled", fillcolor="lightgrey"];
    edge [fontname="Arial", fontsize=10];

    // --- Nodes ---
    subgraph cluster_client {
        label = "Client Side";
        style = "dashed";
        node [fillcolor="lightblue"];
        
        UserAction [label="User Clicks Button", shape=ellipse, fillcolor="white"];
        ClientInvoke [label="Client Invokes\nServer Action"];
        ClientStream [label="Stream Reader\n(useStreamableValue)"];
        UIUpdate [label="React Re-render\n(Loading/Success/Error)", shape="component"];
    }

    subgraph cluster_server {
        label = "Server Side";
        style = "dashed";
        node [fillcolor="lightgreen"];
        
        ServerAction [label="Server Action Entry"];
        StreamText [label="streamText() Execution"];
        ToolExec [label="Tool Execution\n(execute function)"];
        APIFetch [label="External API Call", shape="database"];
        ErrorHandler [label="Error Handler\n(Try/Catch)", fillcolor="#ffcccc"];
        Fallback [label="Return Fallback Data", fillcolor="#fff2cc"];
    }

    // --- Happy Path Edges ---
    UserAction -> ClientInvoke [label="1. Trigger Event"];
    ClientInvoke -> ServerAction [label="2. HTTP Request\n(Input Args)"];
    ServerAction -> StreamText [label="3. Initialize Stream"];
    StreamText -> ToolExec [label="4. Match & Execute Tool"];
    ToolExec -> APIFetch [label="5. Primary Data Source"];
    APIFetch -> StreamText [label="6. Raw Data"];

    // --- Streaming Back to Client ---
    StreamText -> ClientStream [label="7. Stream Chunks\n(Text Tokens)", dir=back];
    ClientStream -> UIUpdate [label="8. Update State\n(Loading -> Content)"];

    // --- Error Path ---
    ToolExec -> ErrorHandler [label="API Failure", style="dashed", color="red"];
    ErrorHandler -> Fallback [label="Catch & Fallback", style="dashed", color="red"];
    Fallback -> StreamText [label="Inject Fallback Text", style="dashed", color="red"];
    
    // --- Unhandled Error Path (Termination) ---
    ErrorHandler -> UIUpdate [label="Unhandled Error\n(Close Stream)", style="dashed", color="darkred", constraint=false];
}
