/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.tsx
// Description: Basic Code Example
// ==========================================

'use client';

import React, { useState, useTransition } from 'react';

// ==========================================
// 1. CLIENT COMPONENT (Dashboard.tsx)
// ==========================================
// This component handles user input and manages the pending state
// using React.useTransition to prevent UI blocking.

export default function Dashboard() {
  const [input, setInput] = useState('');
  // useTransition allows us to mark state updates as non-urgent.
  // This keeps the input field responsive while the server processes the request.
  const [isPending, startTransition] = useTransition();
  const [renderedComponent, setRenderedComponent] = useState<React.ReactNode>(null);

  /**
   * Handles the form submission.
   * Wraps the server action in a transition to handle async state.
   */
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim()) return;

    // Start the transition
    startTransition(async () => {
      try {
        // Import the server action dynamically to ensure it runs on the server
        const { generateDashboard } = await import('./actions');
        
        // Execute the server action
        const result = await generateDashboard(input);
        
        // The result is a serialized RSC payload. 
        // In a real app, you'd use a hydration method, but for this 
        // example, we assume a component is returned or we simulate it.
        setRenderedComponent(result);
      } catch (error) {
        console.error('Client Error:', error);
        alert('An error occurred while processing your request.');
      }
    });
  };

  return (
    <div style={{ padding: '20px', fontFamily: 'sans-serif' }}>
      <h1>Natural Language Dashboard</h1>
      
      <form onSubmit={handleSubmit}>
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Ask for data (e.g., 'Sales by region')"
          disabled={isPending}
          style={{ width: '300px', padding: '8px', marginRight: '10px' }}
        />
        <button type="submit" disabled={isPending}>
          {isPending ? 'Thinking...' : 'Analyze'}
        </button>
      </form>

      <div style={{ marginTop: '20px', border: '1px solid #ddd', padding: '20px' }}>
        {isPending ? <div>Loading visualization...</div> : renderedComponent}
      </div>
    </div>
  );
}
