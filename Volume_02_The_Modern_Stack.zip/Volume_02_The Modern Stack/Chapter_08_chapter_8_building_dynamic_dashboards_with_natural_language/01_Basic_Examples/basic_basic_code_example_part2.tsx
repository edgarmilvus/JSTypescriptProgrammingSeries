/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.tsx
// Description: Basic Code Example
// ==========================================

// ==========================================
// 2. SERVER ACTION (actions.ts)
// ==========================================
// This file runs exclusively on the server. It handles the LLM call
// and database query with Exhaustive Asynchronous Resilience.

'use server';

import { generateObject } from 'ai'; // Vercel AI SDK
import { z } from 'zod';
import { openai } from '@ai-sdk/openai';

// Mock Database Connection
// In a real app, this would be Prisma, Drizzle, or a direct SQL client.
const mockDb = {
  query: async (sql: string): Promise<Array<{ category: string; value: number }>> => {
    // Simulate network latency
    await new Promise(resolve => setTimeout(resolve, 500));
    
    // Mock data response
    return [
      { category: 'Electronics', value: 1200 },
      { category: 'Clothing', value: 850 },
      { category: 'Home', value: 430 },
    ];
  }
};

/**
 * Schema for the structured output expected from the LLM.
 * This ensures the AI returns valid JSON matching our database query structure.
 */
const QuerySchema = z.object({
  metric: z.string().describe('The metric to analyze (e.g., sales, users, revenue)'),
  dimension: z.string().describe('The grouping dimension (e.g., region, category, date)'),
});

/**
 * Server Action: Generates a dashboard based on natural language input.
 * 
 * 1. Parses intent using LLM.
 * 2. Generates SQL/Query.
 * 3. Fetches Data.
 * 4. Returns a React Component (RSC).
 */
export async function generateDashboard(userPrompt: string) {
  // ---------------------------------------------------------
  // RESILIENCE PATTERN: Try/Catch/Finally
  // ---------------------------------------------------------
  try {
    // 1. INTENT PARSING (LLM Call)
    // We use 'generateObject' to force the LLM into our schema.
    const { object } = await generateObject({
      model: openai('gpt-4o-mini'),
      schema: QuerySchema,
      prompt: `Analyze the user request and determine the metric and dimension for a chart.
      User Request: "${userPrompt}"
      
      Available Metrics: sales, revenue, users.
      Available Dimensions: region, category, date.`,
    });

    // 2. QUERY GENERATION & EXECUTION
    // Construct a safe query based on LLM output.
    // Note: In production, validate 'object.dimension' against a whitelist to prevent SQL injection.
    const sql = `SELECT ${object.dimension}, SUM(${object.metric}) as value FROM data GROUP BY ${object.dimension}`;
    
    // Execute query with resilience
    const data = await mockDb.query(sql);

    // 3. UI GENERATION (RSC)
    // Since we are in a 'use server' file, we can import React components
    // and return them directly to the client.
    const { DataChart } = await import('./DataChart');
    
    // Return the component instance (RSC payload)
    return <DataChart title={`${object.metric} by ${object.dimension}`} data={data} />;

  } catch (error) {
    // ---------------------------------------------------------
    // ERROR HANDLING
    // ---------------------------------------------------------
    console.error('Server Action Error:', error);
    
    // Return a fallback UI component or throw to trigger error boundary
    return (
      <div style={{ color: 'red' }}>
        <strong>System Error:</strong> Failed to generate dashboard. Please try rephrasing your request.
      </div>
    );
  } finally {
    // ---------------------------------------------------------
    // RESOURCE CLEANUP
    // ---------------------------------------------------------
    // Close database connections, flush logs, etc.
    // Even if the query fails, this block executes.
    console.log('Transaction completed for prompt:', userPrompt.substring(0, 20) + '...');
  }
}
