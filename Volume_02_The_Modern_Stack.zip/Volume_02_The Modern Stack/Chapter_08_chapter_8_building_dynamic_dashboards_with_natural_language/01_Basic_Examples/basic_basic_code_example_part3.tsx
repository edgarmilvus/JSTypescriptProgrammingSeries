/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example_part3.tsx
// Description: Basic Code Example
// ==========================================

// ==========================================
// 3. SERVER COMPONENT (DataChart.tsx)
// ==========================================
// This component renders entirely on the server.
// It receives data as props and returns pure HTML/JSX.

import React from 'react';

interface DataChartProps {
  title: string;
  data: Array<{ category: string; value: number }>;
}

/**
 * A server-side chart component that renders data as a simple bar chart.
 * No client-side interactivity is required for this visualization.
 */
export function DataChart({ title, data }: DataChartProps) {
  // Calculate max value for scaling
  const maxValue = Math.max(...data.map((d) => d.value));

  return (
    <div style={{ padding: '10px' }}>
      <h3 style={{ marginBottom: '15px', borderBottom: '1px solid #eee' }}>
        {title}
      </h3>
      <div style={{ display: 'flex', alignItems: 'flex-end', gap: '10px', height: '150px' }}>
        {data.map((item, index) => {
          const height = (item.value / maxValue) * 100;
          return (
            <div
              key={index}
              style={{
                display: 'flex',
                flexDirection: 'column',
                alignItems: 'center',
                flex: 1,
              }}
            >
              <div
                style={{
                  width: '100%',
                  height: `${height}%`,
                  backgroundColor: '#3b82f6',
                  borderRadius: '4px 4px 0 0',
                  transition: 'height 0.3s ease',
                }}
              />
              <span style={{ fontSize: '12px', marginTop: '5px' }}>
                {item.category}
              </span>
              <span style={{ fontSize: '10px', color: '#666' }}>
                {item.value}
              </span>
            </div>
          );
        })}
      </div>
    </div>
  );
}
