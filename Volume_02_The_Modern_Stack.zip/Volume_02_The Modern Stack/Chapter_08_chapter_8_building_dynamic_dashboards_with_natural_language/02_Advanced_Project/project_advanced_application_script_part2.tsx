/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script_part2.tsx
// Description: Advanced Application Script
// ==========================================

// lib/data-service.ts
/**
 * Data Access Layer (DAL) for fetching metrics.
 * Uses Generics to ensure type safety between the database query
 * and the consuming UI component.
 */

import { db } from './db'; // Hypothetical database connection

// 1. Define Generic Types for flexible data structures
export type ChartDataPoint = {
  name: string;
  value: number;
};

export type TimeSeriesData = ChartDataPoint[];

/**
 * Generic fetch function.
 * @param T - The specific shape of the data row returned by SQL.
 * @param query - The raw SQL string to execute.
 * @returns Promise<T[]> - Strictly typed array of results.
 */
export async function fetchDatabaseMetrics<T extends ChartDataPoint>(
  query: string
): Promise<T[]> {
  // In a real app, use parameterized queries or a query builder like Drizzle/Kysely
  // to prevent SQL injection. Here we assume the AI generated safe SQL.
  const result = await db.query(query);
  
  // Map database rows to the expected ChartDataPoint shape
  const mappedData: T[] = result.rows.map((row: any) => ({
    name: row.label, // Assuming DB column 'label' maps to 'name'
    value: Number(row.metric), // Assuming DB column 'metric' maps to 'value'
  }));

  return mappedData;
}
