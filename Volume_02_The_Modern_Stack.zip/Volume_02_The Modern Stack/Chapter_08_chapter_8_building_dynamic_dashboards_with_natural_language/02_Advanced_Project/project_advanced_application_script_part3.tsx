/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script_part3.tsx
// Description: Advanced Application Script
// ==========================================

// app/actions/dashboard.ts
'use server';

import { streamUI } from 'ai/rsc';
import { generateId } from 'ai';
import { fetchDatabaseMetrics, TimeSeriesData } from '@/lib/data-service';
import { BarChartComponent } from '@/app/components/BarChartComponent';

/**
 * Server Action: Natural Language to Visualization.
 * 
 * This function acts as the controller. It takes user input, uses an LLM
 * to generate SQL, executes it securely on the server, and streams the
 * resulting React component back to the client.
 */
export async function generateDashboardChart(naturalLanguageQuery: string) {
  const id = generateId();

  // 1. Define the Tool: SQL Generator
  // The AI will invoke this tool to generate the database query.
  const generateSQLTool = async (input: { description: string }) => {
    // In a production app, you would prompt the LLM here to convert
    // `naturalLanguageQuery` into a specific SQL string.
    // For this demo, we simulate the output.
    
    // Simulated AI-generated SQL
    const sqlQuery = `
      SELECT 
        EXTRACT(MONTH FROM created_at) as label, 
        SUM(amount) as metric 
      FROM transactions 
      GROUP BY 1 
      ORDER BY 1;
    `;

    // 2. Execute Query on Server
    // We use the Generic function to ensure data matches the chart props.
    const data: TimeSeriesData = await fetchDatabaseMetrics(sqlQuery);

    return {
      id,
      component: <BarChartComponent data={data} />,
    };
  };

  // 3. Stream the UI
  // The `streamUI` function orchestrates the LLM response and tool execution.
  const result = await streamUI({
    model: 'gpt-4-turbo', // Or any tool-capable model
    messages: [
      { role: 'user', content: `Generate a chart for: ${naturalLanguageQuery}` },
    ],
    text: ({ content }) => <div>{content}</div>, // Fallback text response
    tools: {
      generateSQL: {
        description: 'Generate SQL to answer the user question about data.',
        parameters: {
          type: 'object',
          properties: {
            description: { type: 'string', description: 'The logic for the query' },
          },
          required: ['description'],
        },
        generate: generateSQLTool,
      },
    },
  });

  return result;
}
