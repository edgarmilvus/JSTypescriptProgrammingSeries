/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script_part5.tsx
// Description: Advanced Application Script
// ==========================================

// app/components/DashboardClient.tsx
/**
 * Client Component: The User Interface.
 * Handles user input and displays the streaming response.
 */

'use client';

import { useState } from 'react';
import { generateDashboardChart } from '@/app/actions/dashboard';

export function DashboardClient() {
  const [input, setInput] = useState('');
  const [uiStream, setUiStream] = useState<React.ReactNode>(null);
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input) return;

    setIsLoading(true);
    setUiStream(null);

    try {
      // Call the Server Action
      const { value } = await generateDashboardChart(input);
      
      // The `value` contains the streamed React component
      setUiStream(value);
    } catch (error) {
      console.error("Error generating chart:", error);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto p-6 space-y-6">
      <div className="bg-white p-6 rounded-lg shadow">
        <h1 className="text-2xl font-bold mb-4">AI Data Analyst</h1>
        <form onSubmit={handleSubmit} className="flex gap-2">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Ask for a chart (e.g., 'Sales by month')..."
            className="flex-1 border p-2 rounded text-black"
            disabled={isLoading}
          />
          <button 
            type="submit" 
            className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 disabled:opacity-50"
            disabled={isLoading}
          >
            {isLoading ? 'Generating...' : 'Analyze'}
          </button>
        </form>
      </div>

      {/* Dynamic Rendering Area */}
      <div className="min-h-[400px]">
        {uiStream ? (
          <div className="animate-in fade-in slide-in-from-bottom-4">
            {uiStream}
          </div>
        ) : (
          <div className="text-center text-gray-500 py-20">
            {isLoading ? 'AI is thinking...' : 'Ask a question to visualize data.'}
          </div>
        )}
      </div>
    </div>
  );
}
