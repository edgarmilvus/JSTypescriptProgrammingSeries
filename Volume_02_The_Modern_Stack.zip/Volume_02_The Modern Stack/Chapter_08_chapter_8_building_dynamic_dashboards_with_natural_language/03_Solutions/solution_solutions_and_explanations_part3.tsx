/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

// SalesChart.tsx (Client Component)
'use client';

// This component accepts a Promise as a prop (Server Component Promise Passing Pattern)
// In Next.js, we use the experimental `use` hook to unwrap the promise, 
// or we can make this an async component if it were a Server Component.
// Since the requirement says "Client Component", we handle the promise via `use` or a wrapper.
// However, standard React Client Components cannot accept Promises directly as props in standard React yet.
// Next.js allows passing promises from Server to Client components and unwrapping them with `use`.

import { use } from 'react';

export default function SalesChart({ dataPromise }: { dataPromise: Promise<any> }) {
  const data = use(dataPromise); // Unwraps the promise

  return (
    <div className="border p-4 rounded shadow">
      <h3 className="text-lg font-semibold">Sales Data</h3>
      <pre className="text-sm text-gray-600">{JSON.stringify(data, null, 2)}</pre>
    </div>
  );
}

// UserChart.tsx (Client Component) - Similar structure
'use client';
import { use } from 'react';

export default function UserChart({ dataPromise }: { dataPromise: Promise<any> }) {
  const data = use(dataPromise);

  return (
    <div className="border p-4 rounded shadow">
      <h3 className="text-lg font-semibold">User Data</h3>
      <pre className="text-sm text-gray-600">{JSON.stringify(data, null, 2)}</pre>
    </div>
  );
}
