/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.tsx
// Description: Solutions and Explanations
// ==========================================

// OptimisticDashboard.tsx
'use client';

import { useState, useTransition } from 'react';
import { updateDashboard } from './actions';

// Define state types
type DashboardState = {
  data: any[] | null;
  status: 'idle' | 'pending' | 'success' | 'error';
  message?: string;
};

export function OptimisticDashboard() {
  const [state, setState] = useState<DashboardState>({ data: null, status: 'idle' });
  const [isPending, startTransition] = useTransition();

  const handleQuery = async (query: string) => {
    // 1. Optimistic Update
    // Immediately set a pending state with placeholder data
    const optimisticData = [{ id: 'optimistic', value: 'Loading...' }];
    setState({ 
      data: optimisticData, 
      status: 'pending',
      message: `Processing: "${query}"...` 
    });

    // 2. Server Action in Transition
    startTransition(async () => {
      try {
        const result = await updateDashboard(query);
        
        // 3. Reconciliation
        // Check if the result is different from our optimistic state
        // In a real app, we might compare IDs or timestamps.
        // Here, we simply replace the optimistic state with the confirmed data.
        if (result.success) {
          setState({
            data: result.data,
            status: 'success',
            message: 'Data updated successfully.'
          });
        } else {
          // 4. Error Handling
          throw new Error(result.error);
        }
      } catch (error) {
        // Revert to previous state or show error
        setState({
          data: null,
          status: 'error',
          message: `Error: ${(error as Error).message}. Reverting changes.`
        });
      }
    });
  };

  return (
    <div className="p-4 border rounded-lg max-w-md mx-auto">
      <h2 className="text-xl font-bold mb-2">Optimistic Dashboard</h2>
      
      <div className="flex gap-2 mb-4">
        <button 
          onClick={() => handleQuery('Show Sales')}
          disabled={isPending}
          className="px-4 py-2 bg-blue-600 text-white rounded disabled:opacity-50"
        >
          {isPending ? 'Updating...' : 'Get Sales'}
        </button>
        <button 
          onClick={() => handleQuery('Show Users')}
          disabled={isPending}
          className="px-4 py-2 bg-green-600 text-white rounded disabled:opacity-50"
        >
          {isPending ? 'Updating...' : 'Get Users'}
        </button>
      </div>

      <div className="p-4 bg-gray-50 rounded min-h-[150px]">
        <p className="mb-2 text-sm font-semibold text-gray-500">Status: {state.status}</p>
        {state.message && <p className="mb-2 text-sm italic">{state.message}</p>}
        
        {state.data && (
          <ul className="list-disc pl-5">
            {state.data.map((item, idx) => (
              <li key={idx} className={item.id === 'optimistic' ? 'text-gray-400' : 'text-black'}>
                {JSON.stringify(item)}
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
}
