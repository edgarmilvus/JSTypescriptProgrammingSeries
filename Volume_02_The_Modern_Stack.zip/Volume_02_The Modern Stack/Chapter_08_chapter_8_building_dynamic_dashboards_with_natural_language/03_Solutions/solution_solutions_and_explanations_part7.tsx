/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part7.tsx
// Description: Solutions and Explanations
// ==========================================

// types.ts
// Define ChartData<T> where T is the type of the data point
export interface ChartData<T> {
  data: T[];
  label: string;
}

// ChartWrapper.tsx
import React from 'react';

// Define the props for the wrapper
interface ChartWrapperProps<T> {
  data: ChartData<T> | null; // Data can be null initially
  renderChart: (data: T[]) => React.ReactNode; // Function to render the chart
  loading?: boolean;
  error?: string | null;
}

// Generic Component
export function ChartWrapper<T>({ data, renderChart, loading, error }: ChartWrapperProps<T>) {
  if (loading) {
    return <div className="p-4 bg-gray-100 rounded">Loading Chart...</div>;
  }

  if (error) {
    return <div className="p-4 bg-red-100 text-red-700 rounded">Error: {error}</div>;
  }

  if (!data || data.data.length === 0) {
    return <div className="p-4 bg-gray-50 rounded">No data available</div>;
  }

  // Render the chart using the provided render function
  return (
    <div className="border p-4 rounded shadow-sm">
      <h3 className="font-bold mb-2">{data.label}</h3>
      <div className="chart-content">
        {renderChart(data.data)}
      </div>
    </div>
  );
}
