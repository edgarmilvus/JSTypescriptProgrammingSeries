/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part8.ts
// Description: Solutions and Explanations
// ==========================================

// Usage.tsx
import { ChartWrapper, ChartData } from './ChartWrapper';

// 1. Define specific data types
type SalesData = { amount: number; date: string };
type UserData = { name: string; role: string };

// 2. Mock Data
const salesData: ChartData<SalesData> = {
  label: 'Monthly Sales',
  data: [
    { amount: 1000, date: 'Jan' },
    { amount: 1500, date: 'Feb' },
  ],
};

const userData: ChartData<UserData> = {
  label: 'Team Members',
  data: [
    { name: 'Alice', role: 'Dev' },
    { name: 'Bob', role: 'Designer' },
  ],
};

// 3. Usage Component
export default function Dashboard() {
  return (
    <div className="grid grid-cols-2 gap-4">
      {/* Sales Chart Instance */}
      <ChartWrapper<SalesData>
        data={salesData}
        loading={false}
        renderChart={(data) => (
          <ul>
            {data.map((d, i) => (
              <li key={i} className="text-green-600">
                ${d.amount} on {d.date}
              </li>
            ))}
          </ul>
        )}
      />

      {/* User Chart Instance */}
      <ChartWrapper<UserData>
        data={userData}
        loading={false}
        renderChart={(data) => (
          <ul>
            {data.map((d, i) => (
              <li key={i} className="text-blue-600">
                {d.name} - {d.role}
              </li>
            ))}
          </ul>
        )}
      />
      
      {/* Error State Example */}
      <ChartWrapper<SalesData>
        data={null}
        error="Failed to fetch sales data"
        renderChart={() => null}
      />
    </div>
  );
}
