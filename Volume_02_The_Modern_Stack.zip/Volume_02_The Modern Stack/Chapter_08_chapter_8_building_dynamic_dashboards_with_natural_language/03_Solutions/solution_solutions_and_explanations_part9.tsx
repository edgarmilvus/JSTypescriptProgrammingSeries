/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part9.tsx
// Description: Solutions and Explanations
// ==========================================

// app/page.tsx (Client Component)
'use client';

import { useChat } from 'ai/react';
import { useState, useEffect } from 'react';

// Mock Dataset
const MOCK_DATA = [
  { id: 1, status: 'active', amount: 100 },
  { id: 2, status: 'inactive', amount: 200 },
  { id: 3, status: 'active', amount: 150 },
  { id: 4, status: 'pending', amount: 50 },
];

// Define the expected filter structure
interface FilterCriteria {
  field: 'status' | 'amount';
  operator: 'equals' | 'greaterThan';
  value: string | number;
}

export default function NaturalLanguageQuery() {
  const { messages, input, handleInputChange, handleSubmit, isLoading } = useChat();
  const [parsedFilter, setParsedFilter] = useState<FilterCriteria | null>(null);
  const [filteredData, setFilteredData] = useState(MOCK_DATA);

  // 1. Real-time Parsing
  // The AI response is in messages[1].content. We try to parse it as JSON.
  useEffect(() => {
    const lastMessage = messages[messages.length - 1];
    if (lastMessage?.role === 'assistant') {
      try {
        // In a real stream, this might happen chunk by chunk. 
        // The `useChat` hook accumulates the stream into `message.content`.
        // We attempt to parse the content as JSON.
        const jsonContent: FilterCriteria = JSON.parse(lastMessage.content);
        
        // Validate basic structure
        if (jsonContent.field && jsonContent.operator) {
          setParsedFilter(jsonContent);
        }
      } catch (e) {
        // Ignore parsing errors while the JSON is incomplete or malformed
      }
    }
  }, [messages]);

  // 2. Data Filtering
  useEffect(() => {
    if (!parsedFilter) {
      setFilteredData(MOCK_DATA);
      return;
    }

    const { field, operator, value } = parsedFilter;

    const filtered = MOCK_DATA.filter(item => {
      const itemValue = item[field];
      
      if (operator === 'equals') {
        return itemValue == value; // Loose equality for string/number mix
      }
      if (operator === 'greaterThan') {
        return itemValue > value;
      }
      return true;
    });

    setFilteredData(filtered);
  }, [parsedFilter]);

  return (
    <div className="max-w-4xl mx-auto p-6 space-y-6">
      <div className="bg-white p-4 rounded shadow border">
        <h2 className="text-xl font-bold mb-2">Natural Language Query Builder</h2>
        <p className="text-sm text-gray-600 mb-4">
          Ask to filter by status (active/inactive/pending) or amount (e.g., "Show active users" or "Amount greater than 100").
        </p>
        
        <form onSubmit={handleSubmit} className="flex gap-2">
          <input
            type="text"
            value={input}
            onChange={handleInputChange}
            placeholder="Type your query..."
            className="flex-1 border p-2 rounded"
            disabled={isLoading}
          />
          <button 
            type="submit" 
            className="px-4 py-2 bg-black text-white rounded disabled:opacity-50"
            disabled={isLoading}
          >
            {isLoading ? 'Thinking...' : 'Send'}
          </button>
        </form>
      </div>

      {/* Visual Feedback: Show parsed filter */}
      {parsedFilter && (
        <div className="p-3 bg-blue-50 border border-blue-200 rounded text-blue-800">
          <strong>Active Filter:</strong> {parsedFilter.field} {parsedFilter.operator} {parsedFilter.value}
        </div>
      )}

      {/* Data Table */}
      <div className="border rounded overflow-hidden">
        <table className="w-full text-left border-collapse">
          <thead className="bg-gray-100">
            <tr>
              <th className="p-3 border-b">ID</th>
              <th className="p-3 border-b">Status</th>
              <th className="p-3 border-b">Amount</th>
            </tr>
          </thead>
          <tbody>
            {filteredData.map(row => (
              <tr 
                key={row.id} 
                className={`border-b transition-colors duration-300 ${
                  // Highlight matching rows
                  parsedFilter ? 'bg-yellow-50' : 'bg-white'
                }`}
              >
                <td className="p-3">{row.id}</td>
                <td className="p-3">
                  <span className={`px-2 py-1 rounded text-xs font-bold ${
                    row.status === 'active' ? 'bg-green-100 text-green-800' : 
                    row.status === 'inactive' ? 'bg-gray-100 text-gray-800' : 'bg-yellow-100 text-yellow-800'
                  }`}>
                    {row.status}
                  </span>
                </td>
                <td className="p-3">{row.amount}</td>
              </tr>
            ))}
          </tbody>
        </table>
        {filteredData.length === 0 && (
          <div className="p-4 text-center text-gray-500">No results match your filter.</div>
        )}
      </div>
    </div>
  );
}
