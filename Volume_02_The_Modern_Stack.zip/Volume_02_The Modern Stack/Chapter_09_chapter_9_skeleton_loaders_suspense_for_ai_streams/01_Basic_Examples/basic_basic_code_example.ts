/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

// app/actions/generateReport.ts
'use server';

import { streamUI } from 'ai';
import { openai } from '@ai-sdk/openai';
import { z } from 'zod';

/**
 * Server Action to generate a user report stream.
 * This runs on the server and streams tokens to the client.
 */
export async function generateReportStream(userId: string) {
  // We use streamUI to generate a specific React component based on the AI's output.
  // This allows us to stream structured UI, not just raw text.
  const result = await streamUI({
    model: openai('gpt-4o-mini'),
    // Prompt tailored for the SaaS context
    prompt: `Generate a brief status report for user ID: ${userId}. 
             Include a summary of their activity and a recommendation.
             Format it clearly.`,
    
    // Define the schema for the component we want the AI to generate.
    // This ensures the AI outputs valid JSON matching our component props.
    text: ({ content }) => <div>{content}</div>,
    
    // Define a custom component that the AI can invoke to render specific UI blocks.
    tools: {
      report_card: {
        description: 'A card displaying a user status report.',
        parameters: z.object({
          username: z.string().describe('The name of the user'),
          status: z.enum(['active', 'inactive', 'pending']).describe('Current status'),
          summary: z.string().describe('A brief summary of activity'),
          recommendation: z.string().describe('Suggested next step'),
        }),
        // This function renders the UI on the server when the AI provides valid JSON.
        generate: async function* ({ username, status, summary, recommendation }) {
          // Yield a loading state while generating the inner content (if needed)
          yield <div className="animate-pulse">Generating report card...</div>;
          
          // Return the final component
          return (
            <div className="border rounded-lg p-4 shadow-sm bg-white">
              <h3 className="font-bold text-lg text-gray-800">Report for {username}</h3>
              <div className="mt-2 space-y-2">
                <p className="text-sm text-gray-600">
                  <span className="font-semibold">Status:</span> {status}
                </p>
                <p className="text-sm text-gray-700">{summary}</p>
                <div className="mt-3 p-2 bg-blue-50 border-l-4 border-blue-500">
                  <p className="text-sm font-semibold text-blue-700">Recommendation</p>
                  <p className="text-sm text-blue-600">{recommendation}</p>
                </div>
              </div>
            </div>
          );
        },
      },
    },
  });

  return result;
}
