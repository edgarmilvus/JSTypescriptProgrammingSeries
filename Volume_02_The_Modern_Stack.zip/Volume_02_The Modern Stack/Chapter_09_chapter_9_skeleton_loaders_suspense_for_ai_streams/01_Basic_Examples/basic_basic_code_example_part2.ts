/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.ts
// Description: Basic Code Example
// ==========================================

// app/components/ReportGenerator.tsx
'use client';

import { useState, useTransition } from 'react';
import { generateReportStream } from '@/app/actions/generateReport';
import { readStreamableValue } from 'ai';
import { Suspense } from 'react';

/**
 * Client Component to trigger the stream and handle the UI state.
 */
export default function ReportGenerator() {
  const [isPending, startTransition] = useTransition();
  const [uiState, setUiState] = useState<React.ReactNode | null>(null);

  const handleClick = () => {
    startTransition(async () => {
      // 1. Call the Server Action
      const result = await generateReportStream('user_12345');
      
      // 2. Read the streamable value
      // The readStreamableValue utility allows us to consume the stream token-by-token
      for await (const delta of readStreamableValue(result.value)) {
        // 3. Update state with the latest UI component from the stream
        if (delta) {
          setUiState(delta);
        }
      }
    });
  };

  return (
    <div className="max-w-md mx-auto p-6 space-y-6">
      <button
        onClick={handleClick}
        disabled={isPending}
        className="w-full py-2 px-4 bg-blue-600 text-white rounded hover:bg-blue-700 disabled:opacity-50 transition"
      >
        {isPending ? 'Generating...' : 'Generate User Report'}
      </button>

      {/* 
        The Suspense Boundary handles the "loading" state.
        While the stream is initializing (or if we were fetching initial data),
        the fallback UI (Skeleton) is shown immediately.
        Once the stream starts sending components, the children render.
      */}
      <Suspense fallback={<ReportSkeleton />}>
        <div className="min-h-[200px]">
          {isPending ? uiState : null}
        </div>
      </Suspense>
    </div>
  );
}

/**
 * A Skeleton Loader that mimics the structure of the final Report Card.
 * This prevents layout shift and provides immediate visual feedback.
 */
function ReportSkeleton() {
  return (
    <div className="border rounded-lg p-4 shadow-sm bg-white animate-pulse">
      <div className="h-6 bg-gray-200 rounded w-1/2 mb-4"></div>
      <div className="space-y-2">
        <div className="h-4 bg-gray-200 rounded w-1/3"></div>
        <div className="h-4 bg-gray-200 rounded w-full"></div>
        <div className="h-4 bg-gray-200 rounded w-2/3"></div>
        <div className="mt-3 p-2 bg-gray-100 border-l-4 border-gray-300">
          <div className="h-3 bg-gray-200 rounded w-1/3 mb-1"></div>
          <div className="h-3 bg-gray-200 rounded w-3/4"></div>
        </div>
      </div>
    </div>
  );
}
