/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.tsx
// Description: Advanced Application Script
// ==========================================

// app/components/ai-chat-stream.tsx
'use client';

import { useStreamableValue } from 'ai/rsc';
import { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';

// ==========================================
// 1. TYPE DEFINITIONS & INTERFACES
// ==========================================

/**
 * Represents the state of a single streamable message.
 * @typedef {Object} StreamMessage
 * @property {string} id - Unique identifier for the message.
 * @property {'user' | 'assistant'} role - The sender of the message.
 * @property {string} content - The streamed content (updates incrementally).
 * @property {string} status - Current status: 'loading', 'streaming', 'complete'.
 */
type StreamMessage = {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  status: 'loading' | 'streaming' | 'complete';
};

// ==========================================
// 2. SKELETON LOADER COMPONENT
// ==========================================

/**
 * A structural skeleton that mimics the expected output of an AI
 * generating a bulleted list of action items.
 * 
 * Why this matters: It prevents layout shift (CLS) and sets user expectations
 * about the format of the incoming data.
 */
const ActionItemSkeleton = () => {
  return (
    <div className="space-y-3 animate-pulse">
      <div className="h-4 bg-gray-200 rounded w-3/4"></div>
      <div className="h-4 bg-gray-200 rounded w-1/2"></div>
      <div className="h-4 bg-gray-200 rounded w-5/6"></div>
    </div>
  );
};

// ==========================================
// 3. STREAM RENDERER COMPONENT
// ==========================================

/**
 * Renders the streamed content.
 * Uses `useStreamableValue` to access the current state of the stream.
 * 
 * Under the Hood: This component is typically wrapped in <Suspense> in the parent.
 * However, because we want to show the skeleton *only* during the initial load
 * and then transition to the stream, we handle the status internally.
 */
const StreamRenderer = ({ stream }: { stream: any }) => {
  const [content] = useStreamableValue(stream);
  const [displayedContent, setDisplayedContent] = useState('');

  // Simulate typing effect for better UX
  useEffect(() => {
    setDisplayedContent(content);
  }, [content]);

  return (
    <motion.div
      initial={{ opacity: 0, y: 5 }}
      animate={{ opacity: 1, y: 0 }}
      className="prose prose-sm max-w-none text-gray-700"
    >
      {/* Simple Markdown-like parsing for demonstration */}
      {displayedContent.split('\n').map((line, idx) => {
        if (line.startsWith('- ')) {
          return (
            <li key={idx} className="list-disc ml-4">
              {line.substring(2)}
            </li>
          );
        }
        return <p key={idx}>{line}</p>;
      })}
    </motion.div>
  );
};

// ==========================================
// 4. MAIN CHAT MESSAGE COMPONENT
// ==========================================

/**
 * The parent component for a single message row in the chat.
 * It decides whether to show the Skeleton or the Stream based on status.
 */
const ChatMessage = ({ message }: { message: StreamMessage }) => {
  const isAssistant = message.role === 'assistant';

  return (
    <div className={`flex w-full ${isAssistant ? 'justify-start' : 'justify-end'}`}>
      <div
        className={`max-w-[80%] rounded-lg px-4 py-3 ${
          isAssistant ? 'bg-gray-100 text-gray-900' : 'bg-blue-600 text-white'
        }`}
      >
        {/* 
          CRITICAL: Suspense Boundary
          We wrap the dynamic content. If the stream is 'loading', the fallback 
          (Skeleton) is shown immediately without blocking the rest of the page.
        */}
        {isAssistant && message.status === 'loading' ? (
          <ActionItemSkeleton />
        ) : (
          <div className="text-sm whitespace-pre-wrap">
            {message.content}
          </div>
        )}
      </div>
    </div>
  );
};

// ==========================================
// 5. CHAT CONTAINER (PARENT)
// ==========================================

/**
 * Main Chat Interface.
 * Manages the local state of messages and handles the "User Action" trigger.
 * 
 * In a real app, `messages` would come from a server action or context.
 */
export default function AIChatStream() {
  const [messages, setMessages] = useState<StreamMessage[]>([
    { id: '1', role: 'user', content: 'Generate a marketing plan outline.', status: 'complete' },
  ]);

  /**
   * Handles triggering the AI generation.
   * In a real implementation, this would call a Server Action that invokes `streamUI`.
   * For this demo, we simulate the stream arrival.
   */
  const triggerGeneration = async () => {
    // 1. Add the "Skeleton" message immediately
    const assistantMsgId = `msg-${Date.now()}`;
    const skeletonMessage: StreamMessage = {
      id: assistantMsgId,
      role: 'assistant',
      content: '', // Empty initially
      status: 'loading', // Triggers the Skeleton UI
    };

    setMessages((prev) => [...prev, skeletonMessage]);

    // 2. Simulate network delay (latency of AI model)
    await new Promise((resolve) => setTimeout(resolve, 1500));

    // 3. Simulate Stream Arrival
    // In reality, this would be a ReadableStream consumed by `useStreamableValue`.
    // Here we manually chunk the text to show the progression.
    const fullContent = `- Define target audience personas\n- Conduct competitive analysis\n- Establish unique value proposition\n- Outline content marketing calendar\n- Set KPI benchmarks (CAC, LTV)`;
    
    const words = fullContent.split(' ');
    let currentContent = '';

    // Update status to 'streaming' and start appending content
    setMessages((prev) =>
      prev.map((msg) =>
        msg.id === assistantMsgId
          ? { ...msg, status: 'streaming', content: '' }
          : msg
      )
    );

    // Simulate token-by-token streaming
    for (let i = 0; i < words.length; i++) {
      currentContent += (i === 0 ? '' : ' ') + words[i];
      
      // Update the specific message with new content
      setMessages((prev) =>
        prev.map((msg) =>
          msg.id === assistantMsgId
            ? { ...msg, content: currentContent }
            : msg
        )
      );
      
      // Random delay to mimic network jitter/token arrival
      await new Promise((resolve) => setTimeout(resolve, 50 + Math.random() * 50));
    }

    // 4. Finalize
    setMessages((prev) =>
      prev.map((msg) =>
        msg.id === assistantMsgId ? { ...msg, status: 'complete' } : msg
      )
    );
  };

  return (
    <div className="flex flex-col h-full max-w-2xl mx-auto p-4 border rounded-xl shadow-sm bg-white">
      <div className="flex-1 overflow-y-auto space-y-4 mb-4 p-2">
        {messages.map((msg) => (
          <ChatMessage key={msg.id} message={msg} />
        ))}
      </div>

      <div className="border-t pt-4">
        <button
          onClick={triggerGeneration}
          className="w-full bg-black text-white py-2 rounded-lg hover:bg-gray-800 transition-colors"
        >
          Generate Marketing Plan
        </button>
      </div>
    </div>
  );
}
