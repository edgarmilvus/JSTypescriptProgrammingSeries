/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.tsx
// Description: Solutions and Explanations
// ==========================================

// components/MessageSkeleton.tsx
import React from 'react';

// Define the variant types for user vs AI messages
type MessageSkeletonVariant = 'user' | 'ai';

interface MessageSkeletonProps {
  variant?: MessageSkeletonVariant;
}

export const MessageSkeleton: React.FC<MessageSkeletonProps> = ({ 
  variant = 'ai' 
}) => {
  // Determine styling based on variant
  const isUser = variant === 'user';
  const alignment = isUser ? 'justify-end' : 'justify-start';
  const bgColor = isUser ? 'bg-blue-100' : 'bg-gray-100';
  const avatarOrder = isUser ? 'order-2' : 'order-1';
  const bubbleOrder = isUser ? 'order-1' : 'order-2';

  return (
    <div className={`flex ${alignment} w-full mb-4 animate-pulse`}>
      {/* Avatar Placeholder */}
      <div className={`w-8 h-8 rounded-full ${bgColor} ${avatarOrder} mx-2 flex-shrink-0`} />
      
      {/* Bubble Placeholder */}
      <div className={`${bubbleOrder} max-w-[70%] p-3 rounded-2xl ${bgColor}`}>
        <div className="space-y-2">
          {/* Shimmer lines with varying widths */}
          <div className="h-2 bg-white/50 rounded w-3/4"></div>
          <div className="h-2 bg-white/50 rounded w-full"></div>
          <div className="h-2 bg-white/50 rounded w-5/6"></div>
          <div className="h-2 bg-white/50 rounded w-2/3"></div>
        </div>
      </div>
    </div>
  );
};

// components/AIStreamResponse.tsx
import React, { useEffect, useState } from 'react';

interface AIStreamResponseProps {
  stream: ReadableStream<Uint8Array>;
}

export const AIStreamResponse: React.FC<AIStreamResponseProps> = ({ stream }) => {
  const [content, setContent] = useState('');

  useEffect(() => {
    const reader = stream.getReader();
    const decoder = new TextDecoder();

    const readStream = async () => {
      try {
        while (true) {
          const { done, value } = await reader.read();
          if (done) break;
          
          // Decode the chunk and append to state
          const textChunk = decoder.decode(value, { stream: true });
          setContent((prev) => prev + textChunk);
        }
      } catch (error) {
        console.error("Stream reading error:", error);
      } finally {
        reader.releaseLock();
      }
    };

    readStream();
  }, [stream]);

  return (
    <div className="flex justify-start w-full mb-4">
      <div className="bg-gray-100 p-3 rounded-2xl max-w-[70%]">
        <p className="text-gray-800 whitespace-pre-wrap">{content}</p>
      </div>
    </div>
  );
};

// components/Chat.tsx (Integration Example)
import React, { Suspense } from 'react';

// Mock function to simulate fetching a stream
const fetchAIStream = (): Promise<ReadableStream<Uint8Array>> => {
  // In a real app, this would be an API call returning a stream
  return new Promise((resolve) => {
    setTimeout(() => {
      const text = "Here is the streamed response from the AI.";
      const encoder = new TextEncoder();
      const stream = new ReadableStream({
        start(controller) {
          // Simulate token-by-token streaming
          const tokens = text.split(' ');
          tokens.forEach((token, i) => {
            setTimeout(() => {
              controller.enqueue(encoder.encode(token + ' '));
              if (i === tokens.length - 1) controller.close();
            }, 100 * (i + 1));
          });
        }
      });
      resolve(stream);
    }, 1500); // Simulate latency
  });
};

// Async component that suspends until the stream is ready
const AsyncAIStream = async () => {
  const stream = await fetchAIStream();
  return <AIStreamResponse stream={stream} />;
};

export const Chat: React.FC = () => {
  const [startChat, setStartChat] = useState(false);

  return (
    <div className="p-4 max-w-md mx-auto border rounded">
      <button 
        onClick={() => setStartChat(true)}
        className="bg-blue-500 text-white px-4 py-2 rounded mb-4"
      >
        Send Message
      </button>

      {startChat && (
        <Suspense fallback={<MessageSkeleton variant="ai" />}>
          <AsyncAIStream />
        </Suspense>
      )}
    </div>
  );
};
