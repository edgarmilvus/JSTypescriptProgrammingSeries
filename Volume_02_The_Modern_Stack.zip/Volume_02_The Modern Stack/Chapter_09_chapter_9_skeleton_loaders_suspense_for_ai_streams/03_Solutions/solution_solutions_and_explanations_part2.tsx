/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.tsx
// Description: Solutions and Explanations
// ==========================================

// components/SidebarSkeleton.tsx
export const SidebarSkeleton = () => {
  return (
    <div className="space-y-3 p-4 border-r h-full">
      {[1, 2, 3, 4].map((i) => (
        <div key={i} className="h-8 bg-gray-200 rounded animate-pulse w-full" />
      ))}
    </div>
  );
};

// components/Sidebar.tsx
import React, { Suspense } from 'react';

// Simulate async data fetch with potential failure
const fetchSidebarData = async (): Promise<string[]> => {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      // Simulate 10% chance of failure to test error handling
      if (Math.random() < 0.1) {
        reject(new Error("Failed to load sidebar data"));
      } else {
        resolve(["Conversation 1", "Conversation 2", "Conversation 3"]);
      }
    }, 2000); // 2 second delay
  });
};

// Error Boundary Component for local error handling
class ErrorBoundary extends React.Component<{ children: React.ReactNode }, { hasError: boolean; error?: Error }> {
  constructor(props: { children: React.ReactNode }) {
    super(props);
    this.state = { hasError: false };
  }

  static getDerivedStateFromError(error: Error) {
    return { hasError: true, error };
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="p-4 text-red-600 bg-red-50 border rounded">
          <p>Failed to load sidebar.</p>
          <button 
            onClick={() => this.setState({ hasError: false })}
            className="text-sm underline mt-2"
          >
            Retry
          </button>
        </div>
      );
    }
    return this.props.children;
  }
}

// Async component that suspends
const AsyncSidebarContent = async () => {
  const conversations = await fetchSidebarData();
  return (
    <div className="p-4 border-r h-full bg-gray-50">
      <h2 className="font-bold mb-4">History</h2>
      <ul className="space-y-2">
        {conversations.map((conv, idx) => (
          <li key={idx} className="p-2 bg-white rounded shadow-sm cursor-pointer hover:bg-gray-100">
            {conv}
          </li>
        ))}
      </ul>
    </div>
  );
};

// Wrapper component handling the Suspense and Error Boundary
export const Sidebar: React.FC = () => {
  return (
    <ErrorBoundary>
      <Suspense fallback={<SidebarSkeleton />}>
        <AsyncSidebarContent />
      </Suspense>
    </ErrorBoundary>
  );
};

// components/Dashboard.tsx
import React, { useState } from 'react';

export const Dashboard: React.FC = () => {
  const [refreshKey, setRefreshKey] = useState(0);

  return (
    <div className="flex h-screen">
      {/* Header (Static) */}
      <div className="absolute top-0 left-0 right-0 h-16 bg-white border-b flex items-center justify-between px-6 z-10">
        <h1 className="text-xl font-bold">AI Dashboard</h1>
        <button 
          onClick={() => setRefreshKey(prev => prev + 1)}
          className="bg-gray-800 text-white px-3 py-1 rounded text-sm"
        >
          Refresh Sidebar
        </button>
      </div>

      {/* Main Layout */}
      <div className="flex w-full pt-16">
        {/* Sidebar Area */}
        <div className="w-64 flex-shrink-0" key={refreshKey}>
          <Sidebar />
        </div>
        
        {/* Main Content Area (Static/Unaffected by Sidebar refresh) */}
        <div className="flex-1 p-6 bg-gray-100">
          <div className="bg-white p-6 rounded shadow h-full">
            <h2 className="text-lg font-semibold mb-2">Main Chat Area</h2>
            <p>This area remains interactive while the sidebar reloads.</p>
          </div>
        </div>
      </div>
    </div>
  );
};
