/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

// app/actions/generateList.ts (Server Action)
'use server';

import { streamUI } from '@ai-sdk/ui-utils'; // Assuming usage of Vercel AI SDK
import { z } from 'zod';

// Mock delay function
const delay = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

export async function generateList() {
  // 1. Define the initial loading component
  const LoadingList = () => (
    <div className="p-4 border rounded bg-gray-50 animate-pulse">
      <div className="font-bold mb-2">Generating list...</div>
      <div className="h-4 bg-gray-200 rounded w-1/2 mb-2"></div>
      <div className="h-4 bg-gray-200 rounded w-1/3"></div>
    </div>
  );

  // 2. Define the final component schema
  const componentSchema = z.object({
    items: z.array(z.string()),
  });

  // 3. Stream the UI
  const result = await streamUI({
    model: 'gpt-3.5-turbo', // Placeholder for actual model
    prompt: 'Generate a list of 3 todos.',
    
    // The 'initial' property renders this component immediately
    initial: <LoadingList />,
    
    // Text stream for debug console (optional requirement)
    text: ({ content }) => content,
    
    // Schema for structured generation
    schema: componentSchema,
    
    // Function to generate the component
    generate: async function* ({ schema }) {
      // Simulate LLM latency
      await delay(2000);

      // Simulated generated data
      const items = ["Buy milk", "Walk the dog", "Read a book"];

      // Yield the final component
      yield (
        <ul className="list-disc pl-5 p-4 border rounded bg-white shadow-sm">
          {items.map((item, i) => (
            <li key={i} className="mb-1 text-gray-800">
              {item}
            </li>
          ))}
        </ul>
      );
    },
  });

  return result;
}
