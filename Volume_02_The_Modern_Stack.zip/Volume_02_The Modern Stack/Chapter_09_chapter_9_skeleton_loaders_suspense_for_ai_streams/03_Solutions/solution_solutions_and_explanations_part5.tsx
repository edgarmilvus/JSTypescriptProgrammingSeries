/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.tsx
// Description: Solutions and Explanations
// ==========================================

// components/LikeButton.tsx
import React, { useState } from 'react';

interface LikeButtonProps {
  messageId: string;
  initialLiked?: boolean;
}

export const LikeButton: React.FC<LikeButtonProps> = ({ messageId, initialLiked = false }) => {
  const [isLiked, setIsLiked] = useState(initialLiked);
  const [isPending, setIsPending] = useState(false);

  // Mock API call
  const apiLikeMessage = async (id: string, liked: boolean): Promise<void> => {
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        // Simulate random failure
        if (Math.random() > 0.8) {
          reject(new Error("Network Error"));
        } else {
          resolve();
        }
      }, 1000);
    });
  };

  const handleClick = async () => {
    const previousState = isLiked;
    const newState = !previousState;

    // 1. Optimistic Update: Change UI immediately
    setIsLiked(newState);
    setIsPending(true);

    try {
      // 2. API Call
      await apiLikeMessage(messageId, newState);
    } catch (error) {
      // 3. Rollback on failure
      setIsLiked(previousState);
      
      // Show toast error (simulated with alert for simplicity)
      alert("Failed to update like status. Reverting changes.");
    } finally {
      setIsPending(false);
    }
  };

  return (
    <button
      onClick={handleClick}
      disabled={isPending}
      className={`px-3 py-1 rounded text-sm font-medium transition-colors ${
        isLiked 
          ? 'bg-red-500 text-white' 
          : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
      } ${isPending ? 'opacity-70 cursor-not-allowed' : ''}`}
    >
      {isLiked ? '♥ Liked' : '♡ Like'}
    </button>
  );
};

// components/ChatMessage.tsx (Combining with Stream)
import React from 'react';

interface ChatMessageProps {
  id: string;
  content: string;
  isUser: boolean;
}

export const ChatMessage: React.FC<ChatMessageProps> = ({ id, content, isUser }) => {
  return (
    <div className={`flex w-full mb-4 ${isUser ? 'justify-end' : 'justify-start'}`}>
      <div className={`p-3 rounded-2xl max-w-[70%] ${isUser ? 'bg-blue-500 text-white' : 'bg-gray-100 text-gray-800'}`}>
        <p>{content}</p>
        {!isUser && (
          <div className="mt-2 pt-2 border-t border-gray-300/30 flex justify-end">
            <LikeButton messageId={id} />
          </div>
        )}
      </div>
    </div>
  );
};

// components/ChatWithOptimistic.tsx (Integration)
import React, { Suspense, useState } from 'react';
import { MessageSkeleton } from './MessageSkeleton'; // From Exercise 1

export const ChatWithOptimistic: React.FC = () => {
  const [messages, setMessages] = useState<Array<{id: string, text: string, isUser: boolean}>>([]);
  
  // Simulate sending a message
  const handleSend = () => {
    const userMsgId = `msg-${Date.now()}`;
    
    // 1. Optimistic User Message
    setMessages(prev => [...prev, { id: userMsgId, text: "Tell me a joke.", isUser: true }]);

    // 2. Trigger AI Stream (Simulated)
    // In a real app, this would trigger the Suspense boundary
    // Here we simulate the result appearing after a delay
    setTimeout(() => {
      const aiMsgId = `msg-${Date.now() + 1}`;
      setMessages(prev => [...prev, { id: aiMsgId, text: "Why did the scarecrow win an award? Because he was outstanding in his field.", isUser: false }]);
    }, 2000);
  };

  return (
    <div className="p-4 border rounded max-w-md mx-auto space-y-4">
      <div className="h-64 overflow-y-auto border p-2 bg-gray-50">
        {messages.map(msg => (
          <ChatMessage key={msg.id} id={msg.id} content={msg.text} isUser={msg.isUser} />
        ))}
        
        {/* Simulated Suspense for AI Response */}
        {messages.length > 0 && !messages[messages.length - 1].isUser && (
           <Suspense fallback={<MessageSkeleton variant="ai" />}>
             {/* In a real scenario, the AI component would go here. 
                 For this demo, we just let the state update handle it. */}
             <div /> 
           </Suspense>
        )}
      </div>
      
      <button onClick={handleSend} className="w-full bg-blue-600 text-white py-2 rounded">
        Send Message
      </button>
    </div>
  );
};
