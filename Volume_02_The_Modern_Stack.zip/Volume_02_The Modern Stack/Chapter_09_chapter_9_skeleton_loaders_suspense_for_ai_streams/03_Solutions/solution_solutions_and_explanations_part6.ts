/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part6.ts
// Description: Solutions and Explanations
// ==========================================

// File: stream_flow.dot

digraph StreamFlow {
    // Graph settings
    rankdir=LR;
    node [shape=box, style="rounded,filled", fontname="Helvetica"];
    edge [fontname="Helvetica", fontsize=10];

    // Nodes
    UserInput [label="User Input", fillcolor="#e0f7fa"];
    APIRequest [label="API Request", fillcolor="#b3e5fc"];
    ServerProcessing [label="Server Processing\n(LLM Generation)", fillcolor="#fff9c4", shape="cylinder"];
    SSEStream [label="SSE Stream", fillcolor="#ffecb3"];
    ClientReceiver [label="Client Receiver", fillcolor="#e1bee7"];
    
    // Suspense/Skeleton Branch
    SuspenseBoundary [label="Suspense Boundary", fillcolor="#f5f5f5", shape="ellipse"];
    SkeletonLoader [label="Skeleton Loader\n(Visual Placeholder)", fillcolor="#ebebeb", style="dashed"];
    
    // Final UI Branch
    FinalUI [label="Final UI Render", fillcolor="#c8e6c9"];
    
    // Error Branch
    NetworkError [label="Network Error", fillcolor="#ffcdd2"];
    ErrorBoundary [label="Error Boundary", fillcolor="#ef9a9a", shape="doublecircle"];
    ErrorState [label="Error State UI", fillcolor="#ffcdd2"];

    // Flow Logic
    UserInput -> APIRequest [label="Submit", color="black"];
    APIRequest -> ServerProcessing [label="Init Connection", color="black"];
    
    // Latency Edge
    ServerProcessing -> SSEStream [label="First Token (200ms - 2s)", color="black", style="dashed"];
    
    // Client Split
    SSEStream -> ClientReceiver [label="Data Arrives", color="black"];

    // Conditional Branching: Path 1 (Loading)
    ClientReceiver -> SuspenseBoundary [label="Stream Pending", color="blue"];
    SuspenseBoundary -> SkeletonLoader [label="Render Fallback", color="blue"];

    // Conditional Branching: Path 2 (Success)
    ClientReceiver -> FinalUI [label="Stream Active/Complete", color="green"];
    SkeletonLoader -> FinalUI [label="Replaces", color="green", style="dashed", constraint="false"];

    // Conditional Branching: Path 3 (Failure)
    ClientReceiver -> NetworkError [label="Connection Fail", color="red"];
    NetworkError -> ErrorBoundary [label="Caught", color="red"];
    ErrorBoundary -> ErrorState [label="Render", color="red"];

    // Visual grouping
    { rank=same; SuspenseBoundary; FinalUI; ErrorBoundary }
    { rank=same; SkeletonLoader; ErrorState }
}
