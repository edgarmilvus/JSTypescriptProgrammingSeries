/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.tsx
// Description: Basic Code Example
// ==========================================

'use client';

import { useChat } from '@ai-sdk/react';
import { StreamableValue, readStreamableValue } from 'ai';
import { useState } from 'react';

// -----------------------------------------------------------------------------
// 1. Client-Side Interactive Component (The "Interactive" Part)
// -----------------------------------------------------------------------------
/**
 * @description A simple counter component that runs on the client.
 * It receives a `value` and an `onIncrement` callback to communicate
 * with the server.
 * @param {Object} props
 * @param {number} props.initialValue - The starting number.
 * @param {function} props.onIncrement - Callback to trigger server action.
 */
function InteractiveCounter({
  initialValue,
  onIncrement,
}: {
  initialValue: number;
  onIncrement: () => void;
}) {
  // We maintain local state for immediate UI feedback (Optimistic UI)
  const [count, setCount] = useState(initialValue);

  const handleClick = () => {
    // Update local state immediately for responsiveness
    setCount((prev) => prev + 1);
    // Trigger the server action to persist the change
    onIncrement();
  };

  return (
    <div style={{ 
      border: '1px solid #e2e8f0', 
      padding: '12px', 
      borderRadius: '8px', 
      margin: '10px 0',
      backgroundColor: '#f8fafc'
    }}>
      <strong>Estimated Users:</strong>
      <div style={{ fontSize: '24px', margin: '8px 0' }}>{count}</div>
      <button 
        onClick={handleClick}
        style={{
          padding: '6px 12px',
          backgroundColor: '#3b82f6',
          color: 'white',
          border: 'none',
          borderRadius: '4px',
          cursor: 'pointer'
        }}
      >
        + Increment
      </button>
    </div>
  );
}

// -----------------------------------------------------------------------------
// 2. Main Chat Interface
// -----------------------------------------------------------------------------
/**
 * @description The primary component handling the chat stream.
 * It intercepts the stream, identifies the embedded component instruction,
 * and renders the `InteractiveCounter` in place of the stream token.
 */
export default function InteractiveStreamPage() {
  const { messages, input, handleSubmit, isLoading, error } = useChat({
    // The API endpoint that generates the stream
    api: '/api/chat',
  });

  return (
    <div style={{ maxWidth: '600px', margin: '0 auto', padding: '20px' }}>
      <h1>SaaS Dashboard Generator</h1>
      
      {/* Message List */}
      <div>
        {messages.map((message) => (
          <div key={message.id} style={{ marginBottom: '12px' }}>
            <strong>{message.role === 'user' ? 'You: ' : 'AI: '}</strong>
            
            {/* 
              The Vercel AI SDK `useChat` hook returns a structured message object.
              The `content` property contains the streamed text and component placeholders.
            */}
            <div>
              {message.content}
            </div>
          </div>
        ))}
      </div>

      {/* Input Form */}
      <form onSubmit={handleSubmit} style={{ marginTop: '20px' }}>
        <input
          type="text"
          value={input}
          onChange={(e) => input.onChange(e.target.value)}
          placeholder="Ask for a dashboard..."
          style={{ width: '80%', padding: '8px' }}
        />
        <button type="submit" disabled={isLoading} style={{ padding: '8px' }}>
          {isLoading ? 'Generating...' : 'Send'}
        </button>
      </form>

      {error && <div style={{ color: 'red' }}>Error: {error.message}</div>}
    </div>
  );
}
