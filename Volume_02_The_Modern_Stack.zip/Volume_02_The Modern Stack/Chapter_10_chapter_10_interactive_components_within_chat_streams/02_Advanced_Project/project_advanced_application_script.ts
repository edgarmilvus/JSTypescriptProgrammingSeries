/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// app/api/chat/route.ts

import { streamText, StreamTextResult, ToolCall } from 'ai';
import { openai } from '@ai-sdk/openai';
import { createAI, getMutableAIState, streamUI } from 'ai/rsc';
import { ReactNode } from 'react';

// Import the client component that will be rendered on the server
import { ProjectTaskList, ProjectTaskListProps } from '@/components/project-task-list';

// Define the types for the AI state and the available tools
// The AI state will store the conversation history
type AIState = {
  messages: {
    role: 'user' | 'assistant' | 'system';
    content: string;
  }[];
};

// The UI state will store the React nodes to be rendered
type UIState = {
  id: string;
  display: ReactNode;
}[];

// Define the tools available to the AI model
// This is how the model signals its intent to render a component
type Tools = {
  // The tool name is descriptive; the model will learn to call it
  // when a user asks for a project plan or task list.
  createProjectTaskList: {
    // The arguments the model will generate for this tool
    input: {
      tasks: { title: string; description: string }[];
      projectName: string;
    };
    // The tool does not execute server-side logic, it just provides data for the component
    output: null;
  };
};

// Initialize the AI provider with our state types
export const AI = createAI<AIState, UIState>({
  actions: {
    // The primary action that the client will call
    continueConversation: async function* (input: { message: string }) {
      'use server';

      // Get the current history of the conversation
      const history = getMutableAIState<AIState>('history');
      
      // Update the history with the new user message
      history.update([...history.get().messages, { role: 'user', content: input.message }]);

      // Use `streamUI` instead of `streamText` to enable component rendering
      const result: StreamTextResult<Tools> = await streamUI({
        model: openai('gpt-4-turbo-preview'),
        messages: history.get().messages,
        // The system prompt guides the LLM on when to use the tool
        system: `
          You are a helpful project management assistant. 
          When a user asks to create a project plan, list tasks, or organize a project, 
          you MUST call the 'createProjectTaskList' tool. 
          Do not generate a text response; only call the tool.
        `,
        // Define the tool that the LLM can call
        tools: {
          createProjectTaskList: {
            // A clear description helps the LLM decide when to use this tool
            description: 'Create an interactive list of tasks for a project. Call this when the user wants to manage a project.',
            // Define the parameters the LLM needs to provide
            parameters: {
              type: 'object',
              properties: {
                projectName: { type: 'string', description: 'The name of the project' },
                tasks: {
                  type: 'array',
                  items: {
                    type: 'object',
                    properties: {
                      title: { type: 'string', description: 'The title of the task' },
                      description: { type: 'string', description: 'A brief description of the task' },
                    },
                    required: ['title'],
                  },
                  description: 'A list of initial tasks for the project',
                },
              },
              required: ['projectName', 'tasks'],
            },
            // **THE CORE LOGIC**: This is where the magic happens.
            // When the LLM calls this tool, this function is executed.
            // Instead of returning text, it returns the React component.
            generate: async function* ({ projectName, tasks }) {
              // We can stream a loading message while the component "generates"
              yield <div>Generating interactive project plan for <strong>{projectName}</strong>...</div>;
              
              // Simulate a small delay for realism
              await new Promise(resolve => setTimeout(resolve, 1000));

              // Return the fully-hydrated, interactive React component
              // The SDK will serialize the props and stream this to the client
              return (
                <ProjectTaskList 
                  initialProjectName={projectName} 
                  initialTasks={tasks} 
                />
              );
            },
          },
        },
      });

      // For this example, we only care about the UI stream from the tool call
      // In a full app, you might also handle text responses
      for await (const uiPart of result.uiStream) {
        // The uiPart contains the rendered React node from the `generate` function
        // We append it to the UI state to be rendered on the client
        const id = `task-list-${Date.now()}`;
        const uiState = getMutableAIState<UIState>('ui');
        uiState.update([...uiState.get(), { id, display: uiPart }]);
      }
      
      // Update the AI history with the assistant's response (the tool call)
      history.update([...history.get().messages, { role: 'assistant', content: `Created interactive task list for ${input.message}` }]);
    },
  },
  // Initial state values
  initialUIState: [],
  initialAIState: { messages: [] },
});
