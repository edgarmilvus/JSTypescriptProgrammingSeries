/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script_part2.ts
// Description: Advanced Application Script
// ==========================================

// components/project-task-list.tsx

'use client';

import { useState } from 'react';
import { Button } from './ui/button'; // Assuming a shadcn/ui button component
import { Checkbox } from './ui/checkbox'; // Assuming a shadcn/ui checkbox component
import { Input } from './ui/input'; // Assuming a shadcn/ui input component
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from './ui/card';

// Define the props that the server will pass to this component
export interface ProjectTaskListProps {
  initialProjectName: string;
  initialTasks: { title: string; description: string }[];
}

/**
 * An interactive task list component that is streamed from the server.
 * It manages its own local state for task completion and new task addition.
 * @param {ProjectTaskListProps} props - The initial data for the project and tasks.
 */
export function ProjectTaskList({ initialProjectName, initialTasks }: ProjectTaskListProps) {
  // --- LOCAL STATE MANAGEMENT ---
  // We use React's useState to make this component interactive on the client.
  // The state is initialized with the data provided by the server-side tool call.
  const [projectName] = useState(initialProjectName);
  const [tasks, setTasks] = useState(
    initialTasks.map(task => ({ ...task, completed: false }))
  );
  const [newTaskTitle, setNewTaskTitle] = useState('');

  // --- EVENT HANDLERS ---
  // These functions handle user interactions without a full page reload.

  /**
   * Toggles the completed status of a task.
   * @param {number} index - The index of the task to toggle.
   */
  const toggleTask = (index: number) => {
    setTasks(prevTasks => {
      const newTasks = [...prevTasks];
      newTasks[index] = { ...newTasks[index], completed: !newTasks[index].completed };
      return newTasks;
    });
  };

  /**
   * Adds a new task to the list.
   */
  const addTask = () => {
    if (newTaskTitle.trim() === '') return;
    setTasks(prev => [...prev, { title: newTaskTitle, description: 'Added by user', completed: false }]);
    setNewTaskTitle('');
  };

  // --- UI RENDERING ---
  // Calculate progress for the visual progress bar
  const completedCount = tasks.filter(t => t.completed).length;
  const progress = tasks.length > 0 ? (completedCount / tasks.length) * 100 : 0;

  return (
    <Card className="w-full max-w-md shadow-lg border-blue-200">
      <CardHeader>
        <CardTitle className="text-xl font-bold text-blue-800">
          📋 Project: {projectName}
        </CardTitle>
        {/* Visual Progress Bar */}
        <div className="w-full bg-gray-200 rounded-full h-2.5">
          <div 
            className="bg-blue-600 h-2.5 rounded-full transition-all duration-500" 
            style={{ width: `${progress}%` }}
          ></div>
        </div>
        <p className="text-xs text-gray-500">
          {completedCount} / {tasks.length} tasks completed
        </p>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Task List */}
        {tasks.map((task, index) => (
          <div key={index} className="flex items-start space-x-3 p-2 hover:bg-gray-50 rounded-md transition-colors">
            <Checkbox 
              id={`task-${index}`} 
              checked={task.completed} 
              onCheckedChange={() => toggleTask(index)}
            />
            <div className="flex-1">
              <label 
                htmlFor={`task-${index}`}
                className={`text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 ${task.completed ? 'line-through text-gray-400' : ''}`}
              >
                {task.title}
              </label>
              <p className="text-xs text-gray-500">{task.description}</p>
            </div>
          </div>
        ))}
      </CardContent>
      <CardFooter className="flex flex-col gap-3">
        {/* Add New Task Input */}
        <div className="flex w-full items-center space-x-2">
          <Input 
            type="text" 
            placeholder="Add a new task..." 
            value={newTaskTitle}
            onChange={(e) => setNewTaskTitle(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && addTask()}
          />
          <Button onClick={addTask}>Add</Button>
        </div>
      </CardFooter>
    </Card>
  );
}
