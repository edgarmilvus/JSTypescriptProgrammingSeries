/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// AddressForm.tsx
'use client';

import { useState, useEffect } from 'react';
import { updateAddress } from './actions'; // Assume this is a server action

// Define TypeScript interfaces for type safety
interface AddressFormData {
  street: string;
  city: string;
  zip: string;
  country: string;
}

interface AddressFormProps {
  initialData?: Partial<AddressFormData>;
}

export default function AddressForm({ initialData }: AddressFormProps) {
  // State management for form inputs
  const [formData, setFormData] = useState<AddressFormData>({
    street: initialData?.street || '',
    city: initialData?.city || '',
    zip: initialData?.zip || '',
    country: initialData?.country || '',
  });

  // State for UI feedback (loading, success, error)
  const [status, setStatus] = useState<'idle' | 'loading' | 'success' | 'error'>('idle');
  const [countries, setCountries] = useState<string[]>([]);
  const [error, setError] = useState<string | null>(null);

  // Client-side data fetching for the country dropdown
  useEffect(() => {
    const fetchCountries = async () => {
      try {
        const response = await fetch('https://restcountries.com/v3.1/all');
        if (!response.ok) throw new Error('Failed to fetch countries');
        const data = await response.json();
        // Map API response to array of country names
        const countryNames = data.map((country: any) => country.name.common).sort();
        setCountries(countryNames);
      } catch (err) {
        // Fail silently or show a non-blocking error, as this is non-critical
        console.error("Could not load countries:", err);
      }
    };

    fetchCountries();
  }, []);

  // Handle input changes
  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  // Handle form submission
  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setStatus('loading');
    setError(null);

    try {
      // Call the server action with the form data
      const result = await updateAddress(formData);
      
      if (result.success) {
        setStatus('success');
      } else {
        setStatus('error');
        setError(result.message || 'Update failed');
      }
    } catch (err) {
      setStatus('error');
      setError('An unexpected error occurred.');
    }
  };

  // Render the form UI
  if (status === 'success') {
    return (
      <div className="p-4 bg-green-100 text-green-800 rounded-md">
        <p>✅ Address updated successfully!</p>
      </div>
    );
  }

  return (
    <div className="p-4 border rounded-md bg-gray-50">
      <h3 className="font-bold mb-3">Update Shipping Address</h3>
      <form onSubmit={handleSubmit} className="space-y-3">
        <div>
          <label htmlFor="street" className="block text-sm font-medium">Street</label>
          <input
            id="street"
            name="street"
            type="text"
            required
            value={formData.street}
            onChange={handleChange}
            className="w-full p-2 border rounded"
            disabled={status === 'loading'}
          />
        </div>
        <div>
          <label htmlFor="city" className="block text-sm font-medium">City</label>
          <input
            id="city"
            name="city"
            type="text"
            required
            value={formData.city}
            onChange={handleChange}
            className="w-full p-2 border rounded"
            disabled={status === 'loading'}
          />
        </div>
        <div>
          <label htmlFor="zip" className="block text-sm font-medium">Zip Code</label>
          <input
            id="zip"
            name="zip"
            type="text"
            required
            value={formData.zip}
            onChange={handleChange}
            className="w-full p-2 border rounded"
            disabled={status === 'loading'}
          />
        </div>
        <div>
          <label htmlFor="country" className="block text-sm font-medium">Country</label>
          <select
            id="country"
            name="country"
            required
            value={formData.country}
            onChange={handleChange}
            className="w-full p-2 border rounded"
            disabled={status === 'loading' || countries.length === 0}
          >
            <option value="" disabled>Select a country</option>
            {countries.map(country => (
              <option key={country} value={country}>{country}</option>
            ))}
          </select>
          {countries.length === 0 && <p className="text-xs text-gray-500">Loading countries...</p>}
        </div>
        
        <button
          type="submit"
          disabled={status === 'loading'}
          className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 disabled:opacity-50"
        >
          {status === 'loading' ? 'Saving...' : 'Update Address'}
        </button>

        {status === 'error' && (
          <p className="text-red-600 text-sm mt-2">Error: {error}</p>
        )}
      </form>
    </div>
  );
}

// actions.ts (Server Action Example)
'use server';

import { z } from 'zod';

// Define validation schema
const addressSchema = z.object({
  street: z.string().min(1),
  city: z.string().min(1),
  zip: z.string().min(1),
  country: z.string().min(1),
});

export async function updateAddress(formData: unknown) {
  // Validate input on the server
  const parsed = addressSchema.safeParse(formData);
  
  if (!parsed.success) {
    return { success: false, message: 'Invalid form data' };
  }

  // Simulate database update
  try {
    // await db.user.update({ where: { id: userId }, data: { address: parsed.data } });
    console.log('Updating address in database:', parsed.data);
    return { success: true };
  } catch (e) {
    return { success: false, message: 'Database update failed' };
  }
}
