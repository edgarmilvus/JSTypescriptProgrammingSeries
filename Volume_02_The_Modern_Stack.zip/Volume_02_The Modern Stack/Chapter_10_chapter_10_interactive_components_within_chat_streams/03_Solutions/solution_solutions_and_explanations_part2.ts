/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

// BookingWizard.tsx
'use client';

import { useReducer } from 'react';
import { confirmBooking } from './actions'; // Server action

// Define state and action types for the reducer
interface WizardState {
  step: number;
  departureDate: string;
  returnDate: string;
  passengers: number;
  error: string | null;
}

type WizardAction =
  | { type: 'NEXT_STEP' }
  | { type: 'PREV_STEP' }
  | { type: 'UPDATE_FIELD'; field: keyof Omit<WizardState, 'step' | 'error'>; value: string | number }
  | { type: 'SET_ERROR'; message: string }
  | { type: 'CLEAR_ERROR' };

const initialState: WizardState = {
  step: 1,
  departureDate: '',
  returnDate: '',
  passengers: 1,
  error: null,
};

function wizardReducer(state: WizardState, action: WizardAction): WizardState {
  switch (action.type) {
    case 'NEXT_STEP':
      // Validation logic for Step 1
      if (state.step === 1) {
        if (!state.departureDate || !state.returnDate) {
          return { ...state, error: 'Please select both dates.' };
        }
        if (new Date(state.returnDate) < new Date(state.departureDate)) {
          return { ...state, error: 'Return date cannot be before departure date.' };
        }
      }
      return { ...state, step: state.step + 1, error: null };
    case 'PREV_STEP':
      return { ...state, step: state.step - 1, error: null };
    case 'UPDATE_FIELD':
      return { ...state, [action.field]: action.value, error: null };
    case 'SET_ERROR':
      return { ...state, error: action.message };
    case 'CLEAR_ERROR':
      return { ...state, error: null };
    default:
      return state;
  }
}

export default function BookingWizard() {
  const [state, dispatch] = useReducer(wizardReducer, initialState);

  const handleNext = () => dispatch({ type: 'NEXT_STEP' });
  const handlePrev = () => dispatch({ type: 'PREV_STEP' });
  
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    dispatch({ 
      type: 'UPDATE_FIELD', 
      field: e.target.name as keyof Omit<WizardState, 'step' | 'error'>, 
      value: e.target.value 
    });
  };

  const handlePassengerChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    dispatch({ 
      type: 'UPDATE_FIELD', 
      field: 'passengers', 
      value: parseInt(e.target.value, 10) 
    });
  };

  const handleConfirm = async () => {
    // Send the final state to the server action
    const result = await confirmBooking({
      departureDate: state.departureDate,
      returnDate: state.returnDate,
      passengers: state.passengers,
    });
    
    if (result.success) {
      // In a real app, you might dispatch a 'CONFIRMED' action to show a success message
      // For this example, we'll just log it, but the parent chat stream would handle the response.
      console.log('Booking confirmed:', result.message);
    }
  };

  return (
    <div className="p-4 border rounded-md bg-gray-50 space-y-4">
      {/* Progress Indicator */}
      <div className="flex justify-between text-sm text-gray-600">
        <span>Step {state.step} of 3</span>
        <span>{state.step === 1 ? 'Dates' : state.step === 2 ? 'Passengers' : 'Summary'}</span>
      </div>

      {/* Step 1: Dates */}
      {state.step === 1 && (
        <div className="space-y-3">
          <h3 className="font-bold">Select Travel Dates</h3>
          <div>
            <label className="block text-sm">Departure</label>
            <input 
              type="date" 
              name="departureDate" 
              value={state.departureDate} 
              onChange={handleInputChange} 
              className="w-full p-2 border rounded"
            />
          </div>
          <div>
            <label className="block text-sm">Return</label>
            <input 
              type="date" 
              name="returnDate" 
              value={state.returnDate} 
              onChange={handleInputChange} 
              className="w-full p-2 border rounded"
            />
          </div>
          {state.error && <p className="text-red-600 text-sm">{state.error}</p>}
          <div className="flex gap-2">
            <button onClick={handleNext} className="px-4 py-2 bg-blue-600 text-white rounded disabled:opacity-50" disabled={!!state.error}>
              Next
            </button>
          </div>
        </div>
      )}

      {/* Step 2: Passengers */}
      {state.step === 2 && (
        <div className="space-y-3">
          <h3 className="font-bold">Number of Passengers</h3>
          <div>
            <label className="block text-sm">Passengers</label>
            <select 
              name="passengers" 
              value={state.passengers} 
              onChange={handlePassengerChange} 
              className="w-full p-2 border rounded"
            >
              {[1, 2, 3, 4, 5].map(n => <option key={n} value={n}>{n}</option>)}
            </select>
          </div>
          <div className="flex gap-2">
            <button onClick={handlePrev} className="px-4 py-2 bg-gray-300 rounded">Previous</button>
            <button onClick={handleNext} className="px-4 py-2 bg-blue-600 text-white rounded">Next</button>
          </div>
        </div>
      )}

      {/* Step 3: Summary & Confirmation */}
      {state.step === 3 && (
        <div className="space-y-3">
          <h3 className="font-bold">Review Your Booking</h3>
          <ul className="text-sm space-y-1">
            <li><strong>Departure:</strong> {state.departureDate}</li>
            <li><strong>Return:</strong> {state.returnDate}</li>
            <li><strong>Passengers:</strong> {state.passengers}</li>
          </ul>
          <div className="flex gap-2 pt-2">
            <button onClick={handlePrev} className="px-4 py-2 bg-gray-300 rounded">Previous</button>
            <button onClick={handleConfirm} className="px-4 py-2 bg-green-600 text-white rounded">Confirm Booking</button>
          </div>
        </div>
      )}
    </div>
  );
}
