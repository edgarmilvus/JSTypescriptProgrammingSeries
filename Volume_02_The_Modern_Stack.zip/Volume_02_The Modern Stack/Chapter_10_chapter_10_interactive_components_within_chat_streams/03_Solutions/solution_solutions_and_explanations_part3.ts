/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

// PollComponent.tsx
'use client';

import { useState, useEffect } from 'react';
import { castVote } from './actions'; // Server action

// Define types for poll data and real-time messages
interface PollOption {
  id: string;
  text: string;
  count: number;
}

interface PollData {
  id: string;
  question: string;
  options: PollOption[];
}

interface RealTimeMessage {
  type: 'vote_update';
  pollId: string;
  optionId: string;
  newCount: number;
}

export default function PollComponent({ initialData }: { initialData: PollData }) {
  const [pollData, setPollData] = useState<PollData>(initialData);
  const [hasVoted, setHasVoted] = useState<string | null>(null); // Track user's vote
  const [isVoting, setIsVoting] = useState(false);

  // --- Real-Time Subscription ---
  useEffect(() => {
    // In a real app, this would be a WebSocket or SSE connection
    // For this example, we simulate it with a mock event listener
    const handleRealTimeUpdate = (event: CustomEvent<RealTimeMessage>) => {
      const { pollId, optionId, newCount } = event.detail;
      if (pollId === pollData.id) {
        setPollData(prev => ({
          ...prev,
          options: prev.options.map(opt => 
            opt.id === optionId ? { ...opt, count: newCount } : opt
          )
        }));
      }
    };

    // @ts-ignore - Mocking custom event
    window.addEventListener('poll-update', handleRealTimeUpdate as any);

    return () => {
      // @ts-ignore
      window.removeEventListener('poll-update', handleRealTimeUpdate as any);
    };
  }, [pollData.id]);

  // --- Optimistic Voting Logic ---
  const handleVote = async (optionId: string) => {
    if (hasVoted || isVoting) return;

    // 1. Optimistic Update: Immediately update UI
    setIsVoting(true);
    setHasVoted(optionId);
    setPollData(prev => ({
      ...prev,
      options: prev.options.map(opt => 
        opt.id === optionId ? { ...opt, count: opt.count + 1 } : opt
      )
    }));

    // 2. Server Action: Send vote to server
    try {
      const result = await castVote({ pollId: pollData.id, optionId });
      
      if (!result.success) {
        // 3. Revert on failure
        throw new Error(result.message || 'Vote failed');
      }
      // On success, the real-time update (via the subscription) will confirm and correct any discrepancies.
    } catch (error) {
      console.error('Vote failed, reverting:', error);
      // Revert optimistic update
      setPollData(prev => ({
        ...prev,
        options: prev.options.map(opt => 
          opt.id === optionId ? { ...opt, count: Math.max(0, opt.count - 1) } : opt
        )
      }));
      setHasVoted(null);
      alert('Your vote could not be processed. Please try again.');
    } finally {
      setIsVoting(false);
    }
  };

  const totalVotes = pollData.options.reduce((sum, opt) => sum + opt.count, 0);

  return (
    <div className="p-4 border rounded-md bg-gray-50 space-y-3">
      <h3 className="font-bold text-lg">{pollData.question}</h3>
      <div className="text-sm text-gray-600">Total votes: {totalVotes}</div>
      
      <div className="space-y-2">
        {pollData.options.map(option => (
          <button
            key={option.id}
            onClick={() => handleVote(option.id)}
            disabled={isVoting || hasVoted !== null}
            className={`w-full p-2 text-left border rounded flex justify-between items-center transition-colors ${
              hasVoted === option.id 
                ? 'bg-blue-100 border-blue-500 font-semibold' 
                : 'bg-white hover:bg-gray-100'
            }`}
          >
            <span>{option.text}</span>
            <span className="bg-gray-200 px-2 py-1 rounded text-sm">{option.count}</span>
          </button>
        ))}
      </div>
      
      {hasVoted && <p className="text-green-600 text-sm">Thank you for your vote!</p>}
    </div>
  );
}
