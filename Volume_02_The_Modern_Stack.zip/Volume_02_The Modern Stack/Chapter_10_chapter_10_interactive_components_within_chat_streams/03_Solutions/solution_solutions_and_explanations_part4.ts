/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

// DataVisualization.tsx
'use client';

import { BarChart, Bar, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { useState, useRef } from 'react';

// Define TypeScript interfaces for props and state
interface ChartDataPoint {
  date: string;
  value: number;
}

interface DataVisualizationProps {
  data: ChartDataPoint[];
}

type ChartType = 'bar' | 'line';

export default function DataVisualization({ data }: DataVisualizationProps) {
  const [chartType, setChartType] = useState<ChartType>('bar');
  const chartRef = useRef<HTMLDivElement>(null);

  // Handler to toggle chart view
  const toggleChartType = () => {
    setChartType(prev => prev === 'bar' ? 'line' : 'bar');
  };

  // Handler to download chart as PNG
  const handleDownload = () => {
    if (!chartRef.current) return;

    // Note: This is a simplified example. In a real application, you would need a library
    // like html2canvas to render the DOM element to a canvas and then to a PNG.
    // The DOM API alone cannot directly convert a React component to an image.
    // For this exercise, we simulate the logic.
    
    const svgElement = chartRef.current.querySelector('svg');
    if (!svgElement) return;

    // Serialize SVG to string
    const serializer = new XMLSerializer();
    const svgString = serializer.serializeToString(svgElement);
    
    // Create a canvas (this is a conceptual step; actual SVG-to-Canvas is complex)
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');
    const img = new Image();

    // Create a blob from the SVG string
    const svgBlob = new Blob([svgString], { type: 'image/svg+xml;charset=utf-8' });
    const url = URL.createObjectURL(svgBlob);

    img.onload = () => {
      if (ctx) {
        canvas.width = img.width;
        canvas.height = img.height;
        ctx.drawImage(img, 0, 0);
        
        // Create a download link
        const link = document.createElement('a');
        link.download = `chart-${new Date().toISOString().slice(0,10)}.png`;
        link.href = canvas.toDataURL('image/png');
        link.click();
        
        // Clean up
        URL.revokeObjectURL(url);
      }
    };
    img.src = url;
  };

  return (
    <div className="p-4 border rounded-md bg-white space-y-4">
      <div className="flex justify-between items-center">
        <h3 className="font-bold text-lg">Sales Data Visualization</h3>
        <div className="space-x-2">
          <button
            onClick={toggleChartType}
            className="px-3 py-1 text-sm bg-gray-200 rounded hover:bg-gray-300"
          >
            Switch to {chartType === 'bar' ? 'Line' : 'Bar'} Chart
          </button>
          <button
            onClick={handleDownload}
            className="px-3 py-1 text-sm bg-blue-600 text-white rounded hover:bg-blue-700"
          >
            Download as PNG
          </button>
        </div>
      </div>

      {/* Chart Container */}
      <div ref={chartRef} className="h-64 w-full">
        <ResponsiveContainer width="100%" height="100%">
          {chartType === 'bar' ? (
            <BarChart data={data}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="date" />
              <YAxis />
              <Tooltip />
              <Bar dataKey="value" fill="#8884d8" />
            </BarChart>
          ) : (
            <LineChart data={data}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="date" />
              <YAxis />
              <Tooltip />
              <Line type="monotone" dataKey="value" stroke="#8884d8" strokeWidth={2} />
            </LineChart>
          )}
        </ResponsiveContainer>
      </div>
    </div>
  );
}
