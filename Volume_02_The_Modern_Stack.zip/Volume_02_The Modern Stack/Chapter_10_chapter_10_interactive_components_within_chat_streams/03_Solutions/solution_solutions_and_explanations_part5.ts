/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

// AgentStep.tsx
'use client';

import { useState } from 'react';

// Define the type for a single ReAct step
export type ReActStepType = 'thought' | 'action' | 'observation';

export interface ReActStep {
  id: string; // Unique ID for each step
  type: ReActStepType;
  content: string;
  details?: string;
}

interface AgentStepProps {
  step: ReActStep;
  isExpanded: boolean; // Controlled by parent
  onToggle: (id: string) => void; // Callback to parent
}

// Helper for styling based on step type
const getStyle = (type: ReActStepType) => {
  switch (type) {
    case 'thought': return 'bg-yellow-50 border-yellow-200';
    case 'action': return 'bg-blue-50 border-blue-200';
    case 'observation': return 'bg-green-50 border-green-200';
    default: return 'bg-gray-50 border-gray-200';
  }
};

export function AgentStep({ step, isExpanded, onToggle }: AgentStepProps) {
  return (
    <div className={`p-3 my-2 border rounded-md ${getStyle(step.type)}`}>
      <div 
        className="flex justify-between items-center cursor-pointer font-mono text-sm"
        onClick={() => onToggle(step.id)}
      >
        <span className="font-bold uppercase">{step.type}:</span>
        <span className="text-xs text-gray-500">{isExpanded ? '▼' : '▶'}</span>
      </div>
      <div className="mt-1 text-sm font-semibold">{step.content}</div>
      {isExpanded && step.details && (
        <div className="mt-2 p-2 bg-white bg-opacity-50 text-xs rounded border-t border-gray-200">
          {step.details}
        </div>
      )}
    </div>
  );
}

// AgentLog.tsx (Parent Component)
'use client';

import { useState, useMemo } from 'react';
import { AgentStep, ReActStep } from './AgentStep';

// Mock data for the log, which would be streamed from the server
const mockSteps: ReActStep[] = [
  { id: '1', type: 'thought', content: 'I need to find the current weather.', details: 'The user asked for the weather in London. I should use a weather API.' },
  { id: '2', type: 'action', content: 'Search for "weather London API"', details: 'Searching web for a reliable weather API endpoint...' },
  { id: '3', type: 'observation', content: 'Found API: openweathermap.org', details: 'API endpoint: api.openweathermap.org/data/2.5/weather?q={city}' },
];

export default function AgentLog() {
  const [expandedSteps, setExpandedSteps] = useState<Set<string>>(new Set());

  // Toggle a single step
  const toggleStep = (id: string) => {
    setExpandedSteps(prev => {
      const newSet = new Set(prev);
      if (newSet.has(id)) {
        newSet.delete(id);
      } else {
        newSet.add(id);
      }
      return newSet;
    });
  };

  // Global toggle logic
  const toggleAll = () => {
    setExpandedSteps(prev => {
      // If all are expanded, collapse all. Otherwise, expand all.
      if (prev.size === mockSteps.length) {
        return new Set(); // Collapse all
      } else {
        return new Set(mockSteps.map(s => s.id)); // Expand all
      }
    });
  };

  // Determine button text based on current state
  const allExpanded = useMemo(() => expandedSteps.size === mockSteps.length, [expandedSteps, mockSteps]);

  return (
    <div className="space-y-2">
      {/* Global Controls - Placed outside the stream area */}
      <div className="flex justify-end mb-2">
        <button 
          onClick={toggleAll}
          className="text-xs px-2 py-1 bg-gray-200 rounded hover:bg-gray-300"
        >
          {allExpanded ? 'Collapse All' : 'Expand All'}
        </button>
      </div>

      {/* Streamed Steps */}
      <div className="space-y-1">
        {mockSteps.map(step => (
          <AgentStep 
            key={step.id} 
            step={step} 
            isExpanded={expandedSteps.has(step.id)}
            onToggle={toggleStep}
          />
        ))}
      </div>
    </div>
  );
}
