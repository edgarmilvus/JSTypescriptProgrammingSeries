/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

// app/actions/user-tool.ts

'use server';

import { z } from 'zod';
import { generateText } from 'ai';
import { openai } from '@ai-sdk/openai';

/**
 * 1. DEFINE THE SCHEMA
 * We use Zod to define the strict structure of data the tool expects.
 * This serves two purposes:
 *   a) It acts as the runtime validation logic.
 *   b) The Vercel AI SDK extracts this schema to generate the JSON Schema
 *      definition sent to the LLM.
 */
const userProfileSchema = z.object({
  name: z.string().min(1).describe('The full name of the user'),
  age: z.number().min(0).max(120).describe('The age of the user in years'),
  subscriptionTier: z.enum(['free', 'pro', 'enterprise']).describe('The user subscription level'),
});

/**
 * 2. DEFINE THE TOOL
 * We create a standard TypeScript function that will execute the logic.
 * In a real app, this might save to a database. Here, we just return a string.
 */
async function createUserProfile(data: z.infer<typeof userProfileSchema>) {
  // Simulate database insertion
  console.log(`Creating user: ${data.name}, Tier: ${data.subscriptionTier}`);
  
  return `Success: User profile created for ${data.name} (Age: ${data.age}).`;
}

/**
 * 3. IMPLEMENT THE SERVER ACTION
 * This is the entry point for the client component.
 * It handles the LLM interaction and tool execution.
 */
export async function generateUserProfileAction(userRequest: string) {
  
  // The Vercel AI SDK automatically converts the Zod schema 
  // into the JSON Schema format required by OpenAI.
  const tools = {
    createUserProfile: {
      description: 'Creates a new user profile in the system.',
      parameters: userProfileSchema, // <-- Magic happens here
    },
  };

  try {
    // 4. GENERATE TEXT WITH TOOLS
    const result = await generateText({
      model: openai('gpt-4o-mini'),
      prompt: userRequest,
      tools: tools,
      // We strictly enforce that the model must use a tool.
      // This prevents hallucination of text responses.
      toolChoice: 'required', 
    });

    // 5. PROCESS THE TOOL CALL
    // The SDK returns a structured result object containing tool calls.
    // We iterate over them to execute our server-side logic.
    for (const toolCall of result.toolCalls) {
      if (toolCall.toolName === 'createUserProfile') {
        // The arguments are already parsed and validated by the SDK
        // against the Zod schema.
        const resultText = await createUserProfile(toolCall.args);
        return resultText;
      }
    }

    return "No valid tool call was generated.";

  } catch (error) {
    console.error('Error in tool execution:', error);
    return 'An error occurred while processing your request.';
  }
}
