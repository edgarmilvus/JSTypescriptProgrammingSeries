/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script_part2.ts
// Description: Advanced Application Script
// ==========================================

// lib/actions.ts
'use server';

import { deleteUserSchema, updateUserSchema } from './schemas';

/**
 * Server Action: Delete User
 * Re-validates input against the Zod schema before simulating deletion.
 * 
 * @param input - The arguments provided by the AI tool call.
 * @returns A success message or validation error.
 */
export async function deleteUserAction(input: unknown) {
  // 1. Secure Re-validation
  const result = deleteUserSchema.safeParse(input);
  
  if (!result.success) {
    return { error: 'Invalid input provided to delete tool', details: result.error.flatten() };
  }

  const { userId } = result.data;

  // 2. Execute Business Logic (Simulated DB call)
  console.log(`[SERVER] Deleting user with ID: ${userId}`);
  
  // Simulate async database operation
  await new Promise(resolve => setTimeout(resolve, 500));

  return { success: true, message: `User ${userId} deleted successfully.` };
}

/**
 * Server Action: Update User Email
 * Re-validates input against the Zod schema before simulating update.
 * 
 * @param input - The arguments provided by the AI tool call.
 * @returns A success message or validation error.
 */
export async function updateUserAction(input: unknown) {
  // 1. Secure Re-validation
  const result = updateUserSchema.safeParse(input);
  
  if (!result.success) {
    return { error: 'Invalid input provided to update tool', details: result.error.flatten() };
  }

  const { userId, newEmail } = result.data;

  // 2. Execute Business Logic (Simulated DB call)
  console.log(`[SERVER] Updating user ${userId} email to: ${newEmail}`);
  
  // Simulate async database operation
  await new Promise(resolve => setTimeout(resolve: 500));

  return { success: true, message: `User ${userId} updated with email ${newEmail}.` };
}
