/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script_part3.ts
// Description: Advanced Application Script
// ==========================================

// lib/ai-config.ts
import { tool } from 'ai';
import { deleteUserSchema, updateUserSchema } from './schemas';
import { deleteUserAction, updateUserAction } from './actions';

/**
 * AI Tool Definition: Delete User
 * The SDK infers the parameters schema directly from the Zod schema.
 * The `execute` function is called by the AI SDK when the model decides to use this tool.
 */
export const deleteTool = tool({
  description: 'Delete a user from the system. Use this when the user explicitly asks to remove or delete an account.',
  parameters: deleteUserSchema,
  execute: async ({ userId }) => {
    // The execute function receives the parsed, type-safe arguments
    return await deleteUserAction({ userId });
  },
});

/**
 * AI Tool Definition: Update User
 * The SDK infers the parameters schema directly from the Zod schema.
 */
export const updateTool = tool({
  description: 'Update a user\'s email address. Use this when the user asks to change an email.',
  parameters: updateUserSchema,
  execute: async ({ userId, newEmail }) => {
    return await updateUserAction({ userId, newEmail });
  },
});

// The complete tool object passed to the AI SDK
export const tools = {
  delete_user: deleteTool,
  update_user: updateTool,
};
