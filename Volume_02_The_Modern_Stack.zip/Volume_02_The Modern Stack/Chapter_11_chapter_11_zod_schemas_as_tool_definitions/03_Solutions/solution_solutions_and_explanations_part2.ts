/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

// File: handleDeviceControl.ts
import { generateText } from 'ai';
import { openai } from '@ai-sdk/openai'; // Assuming OpenAI provider is configured
import { z } from 'zod';

// 1. Define the Zod Schema for the tool parameters
const deviceControlSchema = z.object({
  deviceType: z.enum(["light", "thermostat", "lock"]),
  action: z.enum(["turnOn", "turnOff", "setTemperature", "lock", "unlock"]),
  // Value is optional. If action is 'setTemperature', it expects a number.
  value: z.union([z.number(), z.string()]).optional(),
});

export async function handleDeviceControl(userPrompt: string) {
  // 2. Use the schema in the Vercel AI SDK generateText call
  const result = await generateText({
    model: openai('gpt-4o'),
    prompt: userPrompt,
    tools: {
      controlDevice: {
        // The schema is passed directly to the tool definition.
        // The SDK automatically converts this Zod schema into a JSON Schema
        // format that the LLM understands (e.g., describing enums, types).
        parameters: deviceControlSchema,
        
        // 3. Execute function: Runs when the LLM decides to call this tool
        execute: async ({ deviceType, action, value }) => {
          // Simulate backend logic
          console.log(`Executing: ${action} on ${deviceType} with value: ${value}`);
          
          // Return a result to the LLM (observation)
          return {
            success: true,
            message: `${deviceType} ${action} completed successfully.`,
          };
        },
      },
    },
  });

  return result;
}

// Example usage:
// const result = await handleDeviceControl("Set the thermostat in the living room to 72 degrees");
// console.log(result.text); // The LLM's final natural language response
