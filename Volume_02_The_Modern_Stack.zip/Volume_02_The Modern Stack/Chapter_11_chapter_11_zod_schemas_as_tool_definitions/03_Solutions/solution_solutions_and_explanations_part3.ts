/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

// File: WeatherDashboard.tsx
'use server'; // Mark this file or the specific function as a server action

import { generateText } from 'ai';
import { openai } from '@ai-sdk/openai';
import { z } from 'zod';

// 1. Define Zod Schema for the weather tool
const weatherSchema = z.object({
  city: z.string().min(2, "City name must be at least 2 characters"),
  unit: z.enum(["celsius", "fahrenheit"]).default("celsius"),
});

// 2. Mock Weather API function
async function fetchMockWeather(city: string, unit: string) {
  // Simulate network delay
  await new Promise(resolve => setTimeout(resolve, 500));
  
  // Mock data based on city (static response for demo)
  const temp = unit === "celsius" ? 22 : 72;
  const condition = city.toLowerCase().includes("rain") ? "Rainy" : "Sunny";
  
  return {
    city,
    temperature: temp,
    condition,
    unit,
  };
}

// 3. Server Action / Component Logic
export default async function WeatherDashboard({ query }: { query: string }) {
  const result = await generateText({
    model: openai('gpt-4o'),
    prompt: `User query: "${query}". Determine the city and unit preference if specified.`,
    tools: {
      getWeather: {
        parameters: weatherSchema,
        execute: async ({ city, unit }) => {
          // 4. Fetch data using validated input
          return fetchMockWeather(city, unit);
        },
      },
    },
  });

  // 5. Render the UI based on the AI result
  // The 'result' object contains the text response and tool execution results
  const weatherData = result.toolResults?.[0]?.result;
  
  return (
    <div className="p-4 border rounded shadow-sm">
      <h2 className="text-xl font-bold mb-2">Weather Dashboard</h2>
      
      {weatherData ? (
        <div className="bg-blue-50 p-3 rounded">
          <h3 className="font-semibold">Weather in {weatherData.city}</h3>
          <p>Condition: {weatherData.condition}</p>
          <p>Temperature: {weatherData.temperature}°{weatherData.unit === 'celsius' ? 'C' : 'F'}</p>
        </div>
      ) : (
        <div className="text-gray-500">
          <p>Processing: "{query}"</p>
          <p>AI Response: {result.text}</p>
        </div>
      )}
    </div>
  );
}
