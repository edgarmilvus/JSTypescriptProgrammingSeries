/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

// File: researchAgent.ts
import { z } from 'zod';
import { ChatOpenAI } from '@langchain/openai';
import { ToolNode } from '@langchain/langgraph/prebuilt';
import { StateGraph, END, MessageGraph } from '@langchain/langgraph';
import { ToolMessage } from '@langchain/core/messages';

// 1. Define Zod Schemas
const searchSchema = z.object({
  query: z.string().describe("The search query to look up information."),
});

const calculatorSchema = z.object({
  expression: z.string().describe("The mathematical expression to evaluate."),
});

// 2. Define Tools (Simulated)
const tools = [
  new DynamicTool({
    name: "search",
    description: "Searches the web for information.",
    schema: searchSchema,
    func: async (input) => {
      // Simulate async search
      return `Search results for "${input.query": ...[Mock Data]...`;
    },
  }),
  new DynamicTool({
    name: "calculator",
    description: "Calculates mathematical expressions.",
    schema: calculatorSchema,
    func: async (input) => {
      try {
        // Safe eval for demo purposes only
        const result = eval(input.expression); 
        return `Result: ${result}`;
      } catch (e) {
        return "Error calculating expression.";
      }
    },
  }),
];

// 3. Define the Research Node
const researchNode = async (state: typeof AgentState.State) => {
  const model = new ChatOpenAI({ model: "gpt-4o" }).bindTools(tools);
  
  // The LLM reasons and decides whether to call a tool
  const response = await model.invoke(state.messages);

  // Check if the LLM wants to call a tool
  const toolCalls = response.additional_kwargs?.tool_calls || [];

  if (toolCalls && toolCalls.length > 0) {
    // 4. Asynchronous Tool Handling
    // We return a special state update that tells LangGraph to route to the tool executor
    return { messages: [response] };
  } else {
    // No tool calls, the LLM has the final answer
    return { messages: [response] };
  }
};

// 5. Define the Graph Structure
const workflow = new MessageGraph();

// Define State (simplified for this example)
const AgentState = {
  messages: {
    value: (x: any[], y: any[]) => x.concat(y),
    default: () => [],
  },
};

// Add the reasoning node
workflow.addNode("agent", researchNode);

// Add the tools node (prebuilt by LangGraph to handle execution)
workflow.addNode("tools", new ToolNode(tools));

// Define Edges (Logic Flow)
workflow.addConditionalEdges(
  "agent",
  (state: any) => {
    // If the last message has tool calls, go to tools, else finish
    const lastMessage = state.messages[state.messages.length - 1];
    if (lastMessage.additional_kwargs?.tool_calls) {
      return "tools";
    }
    return END;
  }
);

workflow.addEdge("tools", "agent"); // After tools run, go back to agent for reasoning
workflow.setEntryPoint("agent"); // Start at the agent node

export const researchGraph = workflow.compile();

// --- VISUALIZATION (DOT Diagram) ---
/*
digraph G {
    node [shape=box, style="rounded,filled", color="lightblue"];
    
    Start [label="Start", shape="ellipse", fillcolor="lightgrey"];
    Agent [label="Reasoning Node (LLM + Tools)"];
    Tools [label="Tool Execution Node (Async)"];
    End [label="End", shape="ellipse", fillcolor="lightgrey"];

    Start -> Agent;
    
    // Conditional Edge: Does LLM need a tool?
    Agent -> Tools [label="Tool Call Requested"];
    Agent -> End [label="Final Answer"];
    
    // Loop back to reasoning after observation
    Tools -> Agent [label="Observation Returned"];
}
*/
