/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

// File: DynamicFormGenerator.tsx
'use client'; // Client component to handle form state and input rendering
'use server'; // Actions must be server-side

import { useState } from 'react';
import { z, ZodObject, ZodRawShape } from 'zod';
import { generateText } from 'ai';
import { openai } from '@ai-sdk/openai';

// 1. Server Action: Handles validation and AI tool call
export async function submitFormAction(schema: ZodObject<ZodRawShape>, formData: FormData) {
  // Convert FormData to a plain object
  const rawValues: Record<string, any> = {};
  schema.keyof().forEach((key) => {
    const value = formData.get(key as string);
    // Basic type conversion based on schema definition could be added here
    rawValues[key] = value; 
  });

  // 2. Validate against the provided Zod schema
  const validation = schema.safeParse(rawValues);
  
  if (!validation.success) {
    return { error: validation.error.format() };
  }

  // 3. Pass validated data to an AI tool definition
  const result = await generateText({
    model: openai('gpt-4o'),
    prompt: `Process the following data: ${JSON.stringify(validation.data)}`,
    tools: {
      // Dynamic tool generation based on the schema
      processForm: {
        parameters: schema, // Reuse the schema for the tool!
        execute: async (data) => {
          // Simulate AI action (e.g., database insert, API call)
          return { status: "success", id: Math.random().toString(36).substring(7) };
        },
      },
    },
  });

  return { success: true, message: result.text };
}

// 4. React Component: Dynamic UI Generation
interface DynamicFormProps {
  schema: ZodObject<ZodRawShape>;
}

export default function DynamicFormGenerator({ schema }: DynamicFormProps) {
  const [state, setState] = useState<any>(null);

  // Helper to render fields based on schema shape
  const renderFields = () => {
    const shape = schema.shape;
    return Object.keys(shape).map((fieldName) => {
      const fieldDef = shape[fieldName];
      const isEnum = fieldDef instanceof z.ZodEnum;
      const isNumber = fieldDef instanceof z.ZodNumber;
      
      return (
        <div key={fieldName} className="mb-4">
          <label className="block text-sm font-medium mb-1">{fieldName}</label>
          
          {isEnum ? (
            <select name={fieldName} className="border p-2 rounded w-full">
              {fieldDef.options.map((opt: string) => (
                <option key={opt} value={opt}>{opt}</option>
              ))}
            </select>
          ) : (
            <input 
              name={fieldName} 
              type={isNumber ? "number" : "text"} 
              className="border p-2 rounded w-full" 
              required={!fieldDef.isOptional()}
            />
          )}
        </div>
      );
    });
  };

  // 5. Form Submission Handler
  const handleSubmit = async (formData: FormData) => {
    const result = await submitFormAction(schema, formData);
    setState(result);
  };

  return (
    <div className="max-w-md mx-auto p-6 bg-white rounded shadow">
      <form action={handleSubmit}>
        {renderFields()}
        <button type="submit" className="bg-blue-500 text-white p-2 rounded mt-4 w-full">
          Submit to AI
        </button>
      </form>

      {state?.error && (
        <div className="mt-4 text-red-500">
          <pre>{JSON.stringify(state.error, null, 2)}</pre>
        </div>
      )}
      {state?.success && (
        <div className="mt-4 text-green-600">
          Success: {state.message}
        </div>
      )}
    </div>
  );
}

// --- Usage Example (e.g., in a parent page) ---
// const userSchema = z.object({
//   name: z.string(),
//   role: z.enum(["admin", "user"]),
//   age: z.number(),
// });
// <DynamicFormGenerator schema={userSchema} />
