/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.tsx
// Description: Basic Code Example
// ==========================================

// app/page.tsx

import { Suspense } from 'react';
import { GreetingServer } from './components/GreetingServer';
import { GreetingClient } from './components/GreetingClient';

/**
 * The Root Page Component.
 * In the Next.js App Router, this is a Server Component by default.
 * We use it to orchestrate the boundary between server and client.
 */
export default function HomePage() {
  return (
    <main style={{ padding: '2rem', fontFamily: 'sans-serif' }}>
      <h1>SaaS Greeting Generator</h1>
      
      {/* 
        The Client Component handles user input and immediate UI updates.
        It is interactive because it uses 'useState' and event handlers.
      */}
      <GreetingClient>
        {/* 
          The Server Component is a child of the Client Component.
          Even though it's nested, it runs on the server.
          We wrap it in Suspense to handle async data fetching (streaming).
        */}
        <Suspense fallback={<p>Loading personalized greeting...</p>}>
          <GreetingServer name="User" />
        </Suspense>
      </GreetingClient>
    </main>
  );
}
