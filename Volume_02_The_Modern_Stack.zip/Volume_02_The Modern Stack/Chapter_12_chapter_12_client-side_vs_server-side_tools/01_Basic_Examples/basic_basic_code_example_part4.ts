/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example_part4.ts
// Description: Basic Code Example
// ==========================================

// lib/aiService.ts
// A mock service simulating AI generation or database logic.

/**
 * Simulates a secure server-side function.
 * In a real SaaS, this would interact with the Vercel AI SDK or Pinecone.
 * 
 * @param {string} name - The input name.
 * @returns {Promise<string>} A promise resolving to the greeting string.
 */
export async function generateGreeting(name: string): Promise<string> {
  // Simulate network latency (e.g., waiting for an LLM response)
  await new Promise(resolve => setTimeout(resolve, 1500));

  if (!name || name.trim() === '') {
    return "Hello, stranger! Please enter a name.";
  }

  // Simulate logic based on the input
  if (name.toLowerCase() === 'admin') {
    return "Welcome back, Admin. System status: Operational.";
  }

  return `Hello, ${name}! Welcome to the Modern Stack.`;
}
