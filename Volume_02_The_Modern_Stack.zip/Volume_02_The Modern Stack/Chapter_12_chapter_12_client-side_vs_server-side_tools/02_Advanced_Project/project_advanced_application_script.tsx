/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.tsx
// Description: Advanced Application Script
// ==========================================

'use client';

import React, { useState, useRef } from 'react';
import { useChat } from 'ai/react'; // Vercel AI SDK for client-side streaming UI
import { createClient } from '@supabase/supabase-js'; // Supabase Client (JS)

// --- Types & Interfaces ---

/**
 * Represents a document stored in our vector database.
 * @typedef {Object} Document
 * @property {string} id - Unique identifier.
 * @property {string} content - The text content.
 * @property {number[]} embedding - The vector representation (stored in pgvector).
 */
interface Document {
  id: string;
  content: string;
  embedding: number[];
}

/**
 * Result from a vector similarity search.
 * @typedef {Object} SearchResult
 * @property {Document} document - The matched document.
 * @property {number} similarity - The cosine similarity score (0-1).
 */
interface SearchResult {
  document: Document;
  similarity: number;
}

// --- SERVER-SIDE LOGIC (Simulated via Server Actions) ---
// In a real Next.js app, these functions would be in a separate 'actions.ts' file
// marked with 'use server'. They run on the server, not the client.

/**
 * SERVER ACTION: Perform Vector Search
 * 
 * Why Server-Side?
 * 1. Security: Supabase API keys and Database credentials are never exposed to the client.
 * 2. Performance: Database connections are pooled on the server. Running pgvector 
 *    queries (cosine similarity) is computationally expensive and should be done 
 *    close to the data.
 * 3. Scalability: Offloads heavy math from the user's device.
 * 
 * @param {number[]} queryVector - The vectorized search query.
 * @returns {Promise<SearchResult[]>} - Top 3 matching documents.
 */
async function searchDocumentsByVector(queryVector: number[]): Promise<SearchResult[]> {
  // Initialize Supabase Client (Server-side only)
  const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL!;
  const supabaseKey = process.env.SUPABASE_SERVICE_ROLE_KEY!; // Use Service Role Key for server operations
  const supabase = createClient(supabaseUrl, supabaseKey);

  // Perform the pgvector similarity search (Cosine Distance)
  // We use the '<=>' operator provided by the pgvector extension.
  const { data, error } = await supabase
    .rpc('match_documents', {
      query_embedding: queryVector,
      match_threshold: 0.7, // Filter out low-confidence matches
      match_count: 3 // Limit results
    });

  if (error) {
    console.error("Database Error:", error);
    return [];
  }

  return data as SearchResult[];
}

// --- CLIENT-SIDE LOGIC ---

/**
 * Client-Side Vectorizer
 * 
 * Why Client-Side?
 * While typically we send text to an API to get embeddings, this specific function
 * demonstrates the use of WebGPU for local computation. In a production app, 
 * you might use ONNX Runtime Web or Transformers.js to run a small embedding model 
 * directly in the browser. This reduces latency and server load.
 * 
 * Note: This is a mock implementation of a vectorizer. In reality, this would 
 * involve loading a model via WebGPU.
 * 
 * @param {string} text - The user's search query.
 * @returns {Promise<number[]>} - A 384-dimension vector (mocked).
 */
const vectorizeOnClient = async (text: string): Promise<number[]> => {
  // In a real WebGPU implementation, we would:
  // 1. Load a tokenizer (e.g., BERT tokenizer).
  // 2. Create a WebGPU buffer for input data.
  // 3. Execute the inference shader on the GPU.
  // 4. Read the resulting tensor back as a Float32Array.
  
  // Mocking the output for this educational script:
  // We generate a deterministic "hash" vector based on the text length and char codes
  // to simulate a unique embedding.
  const vector: number[] = [];
  for (let i = 0; i < 384; i++) {
    // Pseudo-random generation based on text content
    const charCode = text.charCodeAt(i % text.length) || 0;
    vector.push(Math.sin((charCode + i) * 0.1)); 
  }
  
  // Normalize the vector (L2 Norm) - Crucial for Cosine Similarity
  const magnitude = Math.sqrt(vector.reduce((sum, val) => sum + val * val, 0));
  const normalizedVector = vector.map(v => v / magnitude);
  
  return normalizedVector;
};

// --- REACT COMPONENT ---

export default function SemanticSearchApp() {
  // UI State
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<SearchResult[]>([]);
  const [isSearching, setIsSearching] = useState(false);

  // Vercel AI SDK Hook for Streaming UI
  // Used here to stream a "summary" of the found documents to the client
  // This provides immediate feedback while the server processes the data.
  const { messages, input, handleInputChange, handleSubmit, isLoading } = useChat({
    api: '/api/summarize-results', // Endpoint that streams the summary
  });

  /**
   * Orchestrates the Search Flow
   * 
   * 1. Client: Captures input.
   * 2. Client: Vectorizes input (WebGPU/Local Compute).
   * 3. Server: Queries Database (Supabase/pgvector).
   * 4. Server: Returns raw data.
   * 5. Client: Displays raw data immediately (Optimistic UI).
   * 6. Client: Triggers Streaming API for AI Summary (Vercel AI SDK).
   */
  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!query.trim()) return;

    setIsSearching(true);
    setResults([]);

    try {
      // Step 1 & 2: Client-Side Vectorization
      // We process the text locally before sending it over the network.
      // This keeps the payload small (binary array vs. large text) and 
      // decouples the search logic from the text processing logic.
      const queryVector = await vectorizeOnClient(query);

      // Step 3 & 4: Server-Side Search (Server Action)
      // We pass the vector to the server action. The server handles the 
      // secure database connection and pgvector math.
      const searchResults = await searchDocumentsByVector(queryVector);
      
      // Step 5: Update UI immediately
      setResults(searchResults);

      // Step 6: Trigger Streaming Summary
      // We use the Vercel AI SDK's `useChat` hook by appending a user message.
      // The backend API route '/api/summarize-results' will receive this, 
      // query the LLM, and stream the response back.
      // Note: We pass the search results IDs to the API so it knows what to summarize.
      const summaryRequest = new Request('/api/summarize-results', {
        method: 'POST',
        body: JSON.stringify({ 
          message: `Summarize these documents: ${searchResults.map(r => r.document.content).join(' ')}` 
        }),
      });
      
      // Manually triggering the Vercel AI SDK's internal submit logic
      // (In a real app, you might use a custom hook or pass data via context)
      handleSubmit(summaryRequest as any); 

    } catch (error) {
      console.error("Search failed:", error);
    } finally {
      setIsSearching(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto p-6 font-sans text-gray-800">
      <h1 className="text-2xl font-bold mb-6">Semantic Document Search</h1>
      
      {/* Search Input */}
      <form onSubmit={handleSearch} className="flex gap-2 mb-8">
        <input
          type="text"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Enter semantic query (e.g., 'financial growth Q4')..."
          className="flex-1 p-3 border rounded-lg shadow-sm focus:ring-2 focus:ring-blue-500 outline-none"
          disabled={isSearching}
        />
        <button 
          type="submit" 
          className="px-6 py-3 bg-blue-600 text-white rounded-lg font-semibold hover:bg-blue-700 disabled:opacity-50"
          disabled={isSearching}
        >
          {isSearching ? 'Processing...' : 'Search'}
        </button>
      </form>

      {/* Results Section (Raw Data) */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div>
          <h2 className="text-lg font-semibold mb-3 text-gray-700">Retrieved Context</h2>
          {results.length > 0 ? (
            <ul className="space-y-4">
              {results.map((result) => (
                <li key={result.document.id} className="p-4 bg-white border rounded-lg shadow-sm">
                  <div className="flex justify-between items-center mb-2">
                    <span className="text-xs font-mono text-gray-400">ID: {result.document.id}</span>
                    <span className="text-xs font-bold text-green-600">
                      Match: {(result.similarity * 100).toFixed(1)}%
                    </span>
                  </div>
                  <p className="text-sm leading-relaxed">{result.document.content}</p>
                </li>
              ))}
            </ul>
          ) : (
            <p className="text-gray-400 italic">No results found.</p>
          )}
        </div>

        {/* AI Summary Section (Streaming) */}
        <div>
          <h2 className="text-lg font-semibold mb-3 text-gray-700">AI Synthesis (Streaming)</h2>
          <div className="p-4 bg-gray-50 border rounded-lg min-h-[200px]">
            {messages.length > 0 ? (
              <div className="prose prose-sm">
                {/* Render the streamed message from Vercel AI SDK */}
                {messages[messages.length - 1].content}
              </div>
            ) : (
              <p className="text-gray-400 italic text-sm">
                {isLoading 
                  ? 'Generating summary...' 
                  : 'Search results will be summarized here using AI.'}
              </p>
            )}
          </div>
        </div>
      </div>

      {/* Technical Details Footer */}
      <div className="mt-8 p-4 bg-black text-gray-300 rounded-lg text-xs font-mono">
        <p><strong>Architecture:</strong></p>
        <ul className="list-disc list-inside mt-2 space-y-1">
          <li><span className="text-yellow-500">Client:</span> Input handling, WebGPU Vectorization (Mocked), UI State.</li>
          <li><span className="text-blue-400">Server:</span> Supabase pgvector query, Secure DB connection.</li>
          <li><span className="text-green-400">Stream:</span> Vercel AI SDK streaming summary generation.</li>
        </ul>
      </div>
    </div>
  );
}
