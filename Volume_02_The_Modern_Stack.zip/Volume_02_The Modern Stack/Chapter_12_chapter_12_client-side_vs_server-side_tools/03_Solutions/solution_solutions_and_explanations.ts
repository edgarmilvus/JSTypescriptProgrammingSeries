/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// QuickChat.tsx
"use client";

import { useChat } from "@ai-sdk/react";

export function QuickChat() {
  // useChat hook manages the client-side state for messages, input, and streaming
  const { messages, input, handleInputChange, handleSubmit, isLoading, stop, error } = useChat({
    api: "/api/chat", // Assumes a standard API route handling streaming
  });

  return (
    <div className="flex flex-col w-full max-w-md p-4 mx-auto border rounded-lg shadow-sm bg-white">
      <div className="flex flex-col gap-2 mb-4 max-h-60 overflow-y-auto">
        {messages.map((m) => (
          <div key={m.id} className={`flex ${m.role === "user" ? "justify-end" : "justify-start"}`}>
            <div
              className={`px-3 py-2 rounded-lg max-w-[80%] ${
                m.role === "user" ? "bg-blue-500 text-white" : "bg-gray-200 text-gray-900"
              }`}
            >
              <p className="text-sm whitespace-pre-wrap">{m.content}</p>
            </div>
          </div>
        ))}
        
        {/* Loading / Streaming Indicator */}
        {isLoading && (
          <div className="flex justify-start">
            <div className="px-3 py-2 bg-gray-200 rounded-lg text-gray-900 animate-pulse">
              <span className="inline-block w-2 h-2 bg-current rounded-full mr-1"></span>
              <span className="inline-block w-2 h-2 bg-current rounded-full mr-1" style={{ animationDelay: '0.1s' }}></span>
              <span className="inline-block w-2 h-2 bg-current rounded-full" style={{ animationDelay: '0.2s' }}></span>
            </div>
          </div>
        )}

        {error && (
          <div className="text-red-500 text-sm text-center">Error: {error.message}</div>
        )}
      </div>

      <form 
        onSubmit={handleSubmit} 
        className="flex gap-2"
      >
        <input
          type="text"
          value={input}
          onChange={handleInputChange}
          disabled={isLoading}
          placeholder="Type a message..."
          className="flex-1 p-2 border rounded-md text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 disabled:opacity-50"
        />
        
        {/* Conditional Rendering for Send vs Stop */}
        {isLoading ? (
          <button
            type="button"
            onClick={stop}
            className="px-4 py-2 bg-red-500 text-white rounded-md text-sm font-medium hover:bg-red-600 transition-colors"
          >
            Stop
          </button>
        ) : (
          <button
            type="submit"
            disabled={!input.trim()}
            className="px-4 py-2 bg-blue-600 text-white rounded-md text-sm font-medium hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
          >
            Send
          </button>
        )}
      </form>
    </div>
  );
}
