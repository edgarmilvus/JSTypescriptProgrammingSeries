/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

// ProductSummary.tsx (Server Component - No "use client" directive)
import { generateText } from "ai";
import { mockOpenAI } from "./mocks"; // Assuming a mock provider for the exercise

interface ProductSummaryProps {
  features: string[];
}

// This function runs exclusively on the server
async function generateProductDescription(features: string[]) {
  // Simulate AI generation
  const prompt = `Write a short product summary for a device with these features: ${features.join(", ")}`;
  
  // In a real app, this would be `await generateText({ model: openai('gpt-4'), prompt })`
  // Here we mock it to avoid external dependencies.
  const result = await mockOpenAI(prompt); 
  
  return result;
}

export default async function ProductSummary({ features }: ProductSummaryProps) {
  // 1. Data fetching happens on the server
  const description = await generateProductDescription(features);

  // 2. The result is rendered directly into the HTML response
  return (
    <div className="p-6 bg-gray-50 border rounded-md mt-4">
      <h3 className="text-lg font-bold mb-2">Generated Summary</h3>
      <p className="text-gray-700 leading-relaxed">
        {description}
      </p>
      <div className="mt-3 text-xs text-gray-500">
        <em>Rendered entirely on the server at {new Date().toLocaleTimeString()}.</em>
      </div>
    </div>
  );
}

// Parent Page Component (Client Component for interactivity)
// "use client" needed here to handle form state and navigation
"use client";
import { useState, useTransition } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import ProductSummary from "./ProductSummary";

export function ProductPage() {
  const [selectedFeatures, setSelectedFeatures] = useState<string[]>([]);
  
  // Simulating a form submission that triggers a server re-render
  // In Next.js App Router, this would likely be a Server Action or URL param update
  const handleUpdate = () => {
    // Logic to update URL params or call a server action
    // For this example, we assume the parent manages the props passed to ProductSummary
  };

  // UI for selecting features
  return (
    <div>
      <h2>Feature Selector</h2>
      {/* Checkboxes UI omitted for brevity */}
      <button onClick={() => setSelectedFeatures(["Fast", "Durable", "Wireless"])}>Select Features</button>
      
      {/* The Server Component is embedded here. 
          If selectedFeatures changes, Next.js will re-fetch the server component data 
          and re-render the HTML on the server. */}
      <ProductSummary features={selectedFeatures} />
    </div>
  );
}
