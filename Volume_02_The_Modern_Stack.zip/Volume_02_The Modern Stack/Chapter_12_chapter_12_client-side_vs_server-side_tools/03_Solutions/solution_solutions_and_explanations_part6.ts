/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part6.ts
// Description: Solutions and Explanations
// ==========================================

// actions.ts
"use server";

import { generateText } from "ai";
import { openai } from "@ai-sdk/openai";

// Strict System Prompt defined on the server
const SYSTEM_PROMPT = "You are a senior code reviewer. Analyze the code for security vulnerabilities and logic errors. Only output the critique.";

export async function analyzeCode(prevState: any, formData: FormData) {
  const code = formData.get("code") as string;

  // SECURITY: API Keys are never exposed here. The logic runs on the server.
  
  try {
    // MITIGATION: We separate the user input from the system prompt.
    // The user input is strictly treated as "content" to be analyzed.
    const result = await generateText({
      model: openai("gpt-4"),
      system: SYSTEM_PROMPT, 
      prompt: `Review this code:\n${code}`,
    });

    // VALIDATION: Ensure the output structure is correct (simple example)
    if (!result.text) {
      throw new Error("No response generated.");
    }

    return { status: "success", analysis: result.text };
  } catch (error) {
    return { status: "error", message: "Analysis failed." };
  }
}
