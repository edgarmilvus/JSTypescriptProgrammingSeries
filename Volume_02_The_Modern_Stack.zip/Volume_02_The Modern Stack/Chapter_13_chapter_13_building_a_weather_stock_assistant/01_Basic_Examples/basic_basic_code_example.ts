/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

// app/actions.ts
'use server';

import { generateText } from 'ai';
import { openai } from '@ai-sdk/openai';
import { z } from 'zod';

/**
 * SCHEMA DEFINITION
 * We use Zod to define the JSON schema. This serves two purposes:
 * 1. It acts as the runtime validation schema.
 * 2. The Vercel AI SDK can extract the JSON Schema definition from this Zod object
 *    to pass to the LLM as a constraint.
 */
const userProfileSchema = z.object({
  name: z.string().describe("The user's first name"),
  age: z.number().min(0).max(120).describe("The user's age in years"),
  interests: z.array(z.string()).describe("List of hobbies or interests"),
});

/**
 * SERVER ACTION
 * This function runs on the server. It accepts a prompt from the client
 * and returns the structured JSON result.
 * 
 * @param prompt - The user's free-text description.
 * @returns The parsed JSON object adhering to the schema.
 */
export async function generateUserProfile(prompt: string) {
  try {
    // The 'generateText' function is used here. 
    // In a streaming UI context (like useChat), we usually use 'streamText',
    // but for this specific "Basic Code Example" focusing on JSON Schema validation,
    // 'generateText' is often simpler to demonstrate the structured output first.
    // However, to match the "Streaming UI" context of the chapter, we will simulate
    // a stream or use 'streamText' if strictly required. 
    // Let's stick to 'generateText' for the pure JSON logic, 
    // as streaming JSON parsing is complex to show in a single snippet.
    
    const { text, finishReason } = await generateText({
      model: openai('gpt-4o-mini'),
      prompt: `Generate a user profile based on this description: ${prompt}`,
      
      // CRITICAL: This is where we enforce the JSON Schema.
      // The AI SDK converts the Zod schema into a JSON Schema definition
      // and passes it to the LLM's 'response_format' parameter.
      experimental_providerMetadata: {
        openai: {
          response_format: {
            type: 'json_schema',
            json_schema: {
              name: 'user_profile_schema',
              strict: true,
              schema: userProfileSchema,
            },
          },
        },
      },
    });

    // Parse the result using the Zod schema to ensure validity
    const parsedData = userProfileSchema.parse(JSON.parse(text));

    return parsedData;
    
  } catch (error) {
    console.error("Error generating profile:", error);
    throw new Error("Failed to generate user profile.");
  }
}
