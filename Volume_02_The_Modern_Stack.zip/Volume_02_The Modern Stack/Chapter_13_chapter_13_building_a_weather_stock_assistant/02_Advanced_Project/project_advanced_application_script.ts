/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// app/api/chat/route.ts
import { NextRequest } from 'next/server';
import { streamText } from 'ai';
import { openai } from '@ai-sdk/openai';
import { z } from 'zod';

// Mock data services (in a real app, these would be fetch calls to external APIs)
const mockStockData = (symbol: string) => ({
  symbol,
  price: (Math.random() * 100 + 50).toFixed(2),
  change: (Math.random() * 5 - 2.5).toFixed(2),
  timestamp: new Date().toISOString(),
});

const mockWeatherData = (city: string) => ({
  city,
  temp: Math.floor(Math.random() * 30),
  condition: ['Sunny', 'Cloudy', 'Rainy'][Math.floor(Math.random() * 3)],
  humidity: Math.floor(Math.random() * 100),
});

export async function POST(req: NextRequest) {
  const { messages } = await req.json();

  const result = await streamText({
    model: openai('gpt-4-turbo-preview'),
    messages,
    // Tool Definitions: Using Zod for JSON Schema Output
    tools: {
      getStockPrice: {
        description: 'Get the current stock price for a specific ticker symbol.',
        parameters: z.object({
          symbol: z.string().describe('The stock ticker symbol, e.g., AAPL, TSLA'),
        }),
        // Execute the tool logic
        execute: async ({ symbol }) => {
          // Simulate network latency
          await new Promise(resolve => setTimeout(resolve, 500));
          return mockStockData(symbol);
        },
      },
      getWeather: {
        description: 'Get the current weather conditions for a specific city.',
        parameters: z.object({
          city: z.string().describe('The city name, e.g., New York, London'),
        }),
        execute: async ({ city }) => {
          // Simulate network latency
          await new Promise(resolve => setTimeout(resolve, 500));
          return mockWeatherData(city);
        },
      },
    },
    // Strictly enforce tool usage for structured data retrieval
    toolChoice: 'auto', 
  });

  return result.toAIStreamResponse();
}
