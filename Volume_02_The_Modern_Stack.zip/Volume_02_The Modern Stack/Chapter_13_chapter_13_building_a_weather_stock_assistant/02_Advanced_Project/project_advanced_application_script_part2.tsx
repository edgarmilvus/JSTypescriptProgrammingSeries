/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script_part2.tsx
// Description: Advanced Application Script
// ==========================================

// app/page.tsx
'use client';

import { useChat } from 'ai/react';
import { useState, useEffect } from 'react';

// --- Component: Stock Card ---
// Renders a financial data point with visual indicators
const StockCard = ({ data }: { data: any }) => {
  const isPositive = parseFloat(data.change) >= 0;
  return (
    <div className="p-4 bg-gray-800 rounded-lg border border-gray-700 shadow-lg">
      <h3 className="text-lg font-bold text-white">{data.symbol}</h3>
      <div className="flex items-baseline gap-2">
        <span className="text-2xl font-mono text-green-400">${data.price}</span>
        <span className={`text-sm ${isPositive ? 'text-green-400' : 'text-red-400'}`}>
          {isPositive ? '▲' : '▼'} {data.change}%
        </span>
      </div>
      <p className="text-xs text-gray-500 mt-1">Updated: {new Date(data.timestamp).toLocaleTimeString()}</p>
    </div>
  );
};

// --- Component: Weather Card ---
// Renders meteorological data
const WeatherCard = ({ data }: { data: any }) => {
  const iconMap = {
    Sunny: '☀️',
    Cloudy: '☁️',
    Rainy: '🌧️',
  };
  return (
    <div className="p-4 bg-blue-900/30 rounded-lg border border-blue-500/30">
      <h3 className="text-lg font-bold text-blue-200">{data.city}</h3>
      <div className="flex items-center gap-3 mt-2">
        <span className="text-4xl">{iconMap[data.condition as keyof typeof iconMap]}</span>
        <div>
          <p className="text-2xl font-mono text-white">{data.temp}°C</p>
          <p className="text-sm text-blue-300">{data.condition}</p>
        </div>
      </div>
      <p className="text-xs text-blue-400 mt-1">Humidity: {data.humidity}%</p>
    </div>
  );
};

// --- Main Dashboard Component ---
export default function Dashboard() {
  const { messages, input, handleInputChange, handleSubmit, isLoading } = useChat();
  const [toolResults, setToolResults] = useState<any[]>([]);

  // Effect to extract and store tool invocations for visualization
  useEffect(() => {
    const lastMessage = messages[messages.length - 1];
    
    // Check if the last message is a tool invocation result
    if (lastMessage?.role === 'tool') {
      // Parse the content which is a stringified JSON object
      try {
        const data = JSON.parse(lastMessage.content);
        setToolResults((prev) => [...prev, { type: lastMessage.toolName, data }]);
      } catch (e) {
        console.error("Failed to parse tool result", e);
      }
    }
  }, [messages]);

  return (
    <div className="min-h-screen bg-gray-900 text-gray-100 p-8 font-sans">
      <div className="max-w-4xl mx-auto space-y-8">
        
        {/* Header & Visualization Area */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {toolResults.length === 0 ? (
            <div className="col-span-2 flex items-center justify-center h-48 border border-dashed border-gray-700 rounded-lg text-gray-500">
              Ask for a stock price or weather forecast to see data visualized here.
            </div>
          ) : (
            toolResults.map((item, idx) => (
              <div key={idx}>
                {item.type === 'getStockPrice' && <StockCard data={item.data} />}
                {item.type === 'getWeather' && <WeatherCard data={item.data} />}
              </div>
            ))
          )}
        </div>

        {/* Chat Interface */}
        <div className="border border-gray-700 rounded-lg overflow-hidden bg-gray-800">
          <div className="h-64 overflow-y-auto p-4 space-y-4">
            {messages.map((m, index) => (
              <div key={index} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                <div className={`max-w-xs md:max-w-md px-4 py-2 rounded-lg ${
                  m.role === 'user' ? 'bg-blue-600 text-white' : 'bg-gray-700 text-gray-200'
                }`}>
                  {/* Hide raw tool output in chat bubble, show user-friendly text */}
                  {m.role === 'tool' ? (
                    <span className="italic text-gray-400">Fetching {m.toolName} data...</span>
                  ) : (
                    m.content
                  )}
                </div>
              </div>
            ))}
            {isLoading && (
              <div className="flex justify-start">
                <div className="bg-gray-700 px-4 py-2 rounded-lg animate-pulse">
                  Thinking...
                </div>
              </div>
            )}
          </div>

          {/* Input Form */}
          <form onSubmit={handleSubmit} className="p-4 bg-gray-850 border-t border-gray-700 flex gap-2">
            <input
              className="flex-1 bg-gray-900 border border-gray-700 rounded px-3 py-2 text-white focus:outline-none focus:border-blue-500"
              value={input}
              placeholder="e.g., 'What is the price of AAPL?' or 'Weather in Tokyo?'"
              onChange={handleInputChange}
            />
            <button 
              type="submit" 
              disabled={isLoading}
              className="bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white px-4 py-2 rounded font-medium transition-colors"
            >
              Send
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}
