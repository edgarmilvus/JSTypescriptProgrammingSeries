/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

// components/StatusCard.tsx
import { Suspense } from 'react';
import { streamUI } from 'ai'; // Assuming Vercel AI SDK
import { z } from 'zod';

// Define the props interface
interface StatusCardProps {
  promise: ReturnType<typeof streamUI>; 
}

// A helper to simulate reading the stream for demonstration
// In a real app, this logic would be handled by the streamUI result
async function* readStream(promise: ReturnType<typeof streamUI>) {
  const result = await promise;
  // The result typically contains a stream of UI elements
  for await (const chunk of result.uiStream) {
    yield chunk;
  }
}

export async function StatusCard({ promise }: StatusCardProps) {
  // 1. Await the initial stream setup
  const streamResult = await promise;

  // 2. We need to consume the stream. 
  // In RSCs, we often use a helper component to handle the async iteration.
  // Here we simulate the logic inside the component body.
  
  // Note: In strict RSC environments, you cannot use 'await' inside the component 
  // body for streaming iteration without a wrapper like <Suspense> or a stream reader.
  
  // For this exercise, we will render the initial state and rely on the 
  // streamResult's internal handling or a dedicated stream reader component.
  
  // However, to strictly follow the "use await to suspend" and "visual transition":
  // We will assume the streamResult contains a `value` property that updates.
  
  // Let's simulate the visual transition logic:
  const content = await streamResult.value;

  return (
    <div className="status-card">
      <div className="spinner"></div>
      {/* 
        The content here updates as the stream resolves. 
        If using raw streams, we would map stream chunks to state updates.
        Since this is an RSC, we rely on the resolved value or nested Suspense boundaries.
      */}
      <p>{content || 'Waiting for response...'}</p>
    </div>
  );
}

// To strictly handle the stream chunks in an RSC without client hooks:
// We usually wrap the stream reading in an async component or use a library.
// Here is a more robust approach using a dedicated Stream Reader:

async function StreamReader({ stream }: { stream: ReadableStream }) {
  const reader = stream.getReader();
  const chunks: any[] = [];
  
  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    chunks.push(value);
  }
  
  return <div>{chunks.map((c, i) => <p key={i}>{c}</p>)}</div>;
}
