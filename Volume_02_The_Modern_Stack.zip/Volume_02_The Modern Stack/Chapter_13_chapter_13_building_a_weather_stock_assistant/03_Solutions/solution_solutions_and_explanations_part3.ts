/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

// utils/fetchWeatherData.ts

// 1. Mock async functions simulating API delays
const fetchGeolocation = (location: string): Promise<{ lat: number; lon: number }> => {
  return new Promise(resolve => {
    console.log('Fetching Geolocation...');
    setTimeout(() => {
      console.log('Geolocation fetched.');
      resolve({ lat: 35.6762, lon: 139.6503 });
    }, 500); // 500ms delay
  });
};

const fetchForecast = (coords: { lat: number; lon: number }): Promise<string> => {
  return new Promise(resolve => {
    console.log('Fetching Forecast...');
    setTimeout(() => {
      console.log('Forecast fetched.');
      resolve('Sunny, 25°C');
    }, 800); // 800ms delay
  });
};

const fetchHistoricalData = (coords: { lat: number; lon: number }): Promise<string> => {
  return new Promise(resolve => {
    console.log('Fetching Historical Data...');
    setTimeout(() => {
      console.log('Historical data fetched.');
      resolve('Avg: 22°C');
    }, 300); // 300ms delay
  });
};

// 2. Orchestration Logic
export async function fetchWeatherData(location: string) {
  // Step A: Get Geolocation (Must happen first)
  const coords = await fetchGeolocation(location);
  
  // Step B & C: Fetch Forecast and Historical Data
  // CRITICAL: We can run these in parallel using Promise.all.
  // Even though they take 800ms and 300ms respectively, the Event Loop 
  // is not blocked by one waiting for the other.
  
  const [forecast, history] = await Promise.all([
    fetchForecast(coords),
    fetchHistoricalData(coords)
  ]);

  return {
    location,
    coords,
    forecast,
    history
  };
}

// 3. Explanation of Event Loop Behavior (in comments):
/*
  Why this approach prevents freezing:
  
  1. Non-Blocking I/O: By wrapping setTimeout in Promises, we offload the waiting 
     to the Node.js runtime. The main thread is free to handle other requests or 
     stream chunks to the client.

  2. Parallel Execution: Using Promise.all([fetchForecast, fetchHistoricalData]) 
     allows both timers to run simultaneously. If we used sequential awaits 
     (e.g., await fetchForecast then await fetchHistoricalData), the total time 
     would be 500 + 800 + 300 = 1600ms. With Promise.all, it's roughly 
     500 + max(800, 300) = 1300ms.

  3. Streaming: During the 500ms wait for geolocation, the Event Loop can process 
     outgoing network packets (streaming "Fetching location..." to the client). 
     During the 800ms wait for the forecast, it can stream "Fetching forecast...".
     The 'await' keyword yields control back to the event loop at every pause, 
     allowing the stream to flush buffers to the client incrementally.
*/
