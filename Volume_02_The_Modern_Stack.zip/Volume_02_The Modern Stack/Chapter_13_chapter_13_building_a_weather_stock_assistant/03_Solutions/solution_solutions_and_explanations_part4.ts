/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

// app/actions.ts
import { streamUI } from 'ai';
import { z } from 'zod';

// Mock React Components (assuming they are imported or defined here)
const WeatherCard = ({ city, temp }: { city: string; temp: number }) => (
  <div className="weather-card">
    <h3>Weather in {city}</h3>
    <p>{temp}°C</p>
  </div>
);

const StockBadge = ({ symbol, price }: { symbol: string; price: number }) => (
  <div className="stock-badge">
    <span>{symbol}</span>
    <strong>${price}</strong>
  </div>
);

// Define the tools object
export const tools = {
  getWeather: {
    description: "Get the current weather for a location",
    parameters: z.object({ location: z.string() }),
    // The tool generates a React Component directly
    generate: async function* ({ location }) {
      // Simulate a delay for streaming effect
      yield <div>Loading weather for {location}...</div>;
      await new Promise(r => setTimeout(r, 1000));
      
      // Return the final component
      return <WeatherCard city={location} temp={25} />;
    },
  },
  
  getStock: {
    description: "Get the current stock price for a ticker",
    parameters: z.object({ ticker: z.string() }),
    // The tool generates a React Component directly
    generate: async function* ({ ticker }) => {
      yield <div>Fetching stock data for {ticker}...</div>;
      await new Promise(r => setTimeout(r, 800));
      
      return <StockBadge symbol={ticker} price={150} />;
    },
  },
};

// Usage in a Server Action
export async function handleUserMessage(userInput: string) {
  // Assuming messages array exists
  const result = await streamUI({
    messages: [{ role: 'user', content: userInput }],
    tools: tools,
    text: ({ content }) => <p>{content}</p>,
  });

  return result.uiStream; // Returns the stream of React components
}
