/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

import { z } from 'zod';

// 1. Update the Zod schema to be a Union Type
const StockResultSchema = z.union([
  // Success State
  z.object({
    status: z.literal('success'),
    symbol: z.string(),
    price: z.number(),
    currency: z.string().default("USD"),
    timestamp: z.string().datetime(),
  }),
  // Error State
  z.object({
    status: z.literal('error'),
    error: z.string(),
    code: z.number(),
  }),
]);

export type StockResult = z.infer<typeof StockResultSchema>;

// 2. Modified Tool Definition with Try/Catch
export async function getStockPrice(ticker: string): Promise<StockResult> {
  try {
    // Simulate an external API call that might fail
    const response = await fetch(`https://api.stocks.com/v1/${ticker}`);
    
    if (!response.ok) {
      // Handle HTTP errors (e.g., 404, 500)
      throw new Error(`API Error: ${response.status}`);
    }

    const data = await response.json();

    // Validate against success schema (or rely on LLM generation validation)
    return {
      status: 'success',
      symbol: ticker,
      price: data.price,
      currency: 'USD',
      timestamp: new Date().toISOString(),
    };

  } catch (error) {
    // 3. Catch block returns the specific error object
    console.error(`Failed to fetch stock ${ticker}:`, error);
    
    return {
      status: 'error',
      error: 'Service Unavailable',
      code: 500,
    };
  }
}

// Usage Example:
// const result = await getStockPrice('INVALID');
// if (result.status === 'error') {
//   console.error(result.error);
// } else {
//   console.log(result.price);
// }
