/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part4.ts
// Description: Theoretical Foundations
// ==========================================

// Example of a secure Server Action concept
'use server';

import { getServerSession } from './lib/auth';
import { z } from 'zod';
import { db } from './lib/db';

// 1. Define the input schema (Runtime Validation)
const updateProfileSchema = z.object({
  bio: z.string().max(200),
});

export async function updateUserProfile(formData: FormData) {
  // 2. Authentication Check
  const session = await getServerSession();
  if (!session) {
    throw new Error('Unauthorized');
  }

  // 3. Input Validation
  const data = {
    bio: formData.get('bio'),
  };
  
  const result = updateProfileSchema.safeParse(data);
  if (!result.success) {
    throw new Error('Invalid input');
  }

  // 4. Authorization (Implicit via query)
  // We only update the profile belonging to the authenticated user ID
  await db.user.update({
    where: { id: session.user.id },
    data: { bio: result.data.bio },
  });

  return { success: true };
}
