/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

// File: app/api/hello-ai/route.ts
// Context: Next.js 14+ App Router API Route
// Dependencies: next-auth, @auth/next-auth, ai, openai

import { NextResponse } from 'next/server';
import { getServerSession } from 'next-auth/next';
import { authOptions } from '@/app/api/auth/[...nextauth]/route'; // Assumes standard NextAuth config
import { streamText } from 'ai';
import { openai } from '@ai-sdk/openai';
import { Ratelimit } from '@upstash/ratelimit';
import { Redis } from '@upstash/redis';

// --- Configuration ---
// In a real app, use environment variables for secrets.
const ratelimit = new Ratelimit({
  redis: Redis.fromEnv(), // Requires UPSTASH_REDIS_REST_URL and UPSTASH_REDIS_REST_TOKEN env vars
  limiter: Ratelimit.slidingWindow(5, '60 s'), // 5 requests per 60 seconds
  analytics: true, // Optional: Enable analytics in Upstash dashboard
});

/**
 * POST /api/hello-ai
 * 
 * 1. Validates user session (Authentication).
 * 2. Checks rate limit (Authorization/Security).
 * 3. Streams AI response (Business Logic).
 */
export async function POST(req: Request) {
  // 1. Authentication: Verify the user is logged in
  const session = await getServerSession(authOptions);

  if (!session || !session.user?.email) {
    // SRP: This module handles presentation logic; we return a 401 immediately if auth fails.
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  // 2. Rate Limiting: Prevent abuse using Upstash Redis
  // We identify the user by their email for the rate limit key.
  const { success, limit, reset, remaining } = await ratelimit.limit(
    session.user.email
  );

  if (!success) {
    return NextResponse.json(
      { 
        error: 'Rate limit exceeded', 
        details: { limit, reset, remaining } 
      }, 
      { status: 429 }
    );
  }

  // 3. AI Generation: Stream the response
  try {
    // Parse the user's prompt from the request body
    const { prompt } = await req.json();

    if (!prompt) {
      return NextResponse.json({ error: 'Prompt is required' }, { status: 400 });
    }

    // Use Vercel AI SDK to stream the response
    // This creates a ReadableStream that the client can consume.
    const result = await streamText({
      model: openai('gpt-4o-mini'),
      prompt: `Generate a friendly, short hello message for ${session.user.name || 'User'}. Context: ${prompt}`,
      // Temperature controls randomness. Low temp for consistent "hello world" style responses.
      temperature: 0.7,
    });

    // Return the stream as a response.
    // The AI SDK handles the streaming format (TextEncoderStream) automatically.
    return result.toAIStreamResponse();
    
  } catch (error) {
    console.error('AI Generation Error:', error);
    return NextResponse.json(
      { error: 'Internal Server Error' }, 
      { status: 500 }
    );
  }
}

// File: components/HelloAIButton.tsx
// Context: A client-side React component to trigger the API route.

'use client';

import { useState } from 'react';
import { useSession } from 'next-auth/react';

export default function HelloAIButton() {
  const { data: session } = useSession();
  const [response, setResponse] = useState('');
  const [loading, setLoading] = useState(false);

  const generateGreeting = async () => {
    if (!session) {
      alert('Please sign in first.');
      return;
    }

    setLoading(true);
    setResponse('');

    try {
      const res = await fetch('/api/hello-ai', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          prompt: 'Say hello and ask how I am doing.' 
        }),
      });

      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.error || 'Failed to generate');
      }

      // Handle Streaming Response
      const reader = res.body?.getReader();
      const decoder = new TextDecoder();

      if (!reader) return;

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        
        const chunk = decoder.decode(value, { stream: true });
        setResponse((prev) => prev + chunk);
      }
    } catch (error) {
      console.error(error);
      setResponse('Error: ' + (error as Error).message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{ padding: '20px', border: '1px solid #ccc' }}>
      <h3>AI Greeting Generator</h3>
      <button onClick={generateGreeting} disabled={loading}>
        {loading ? 'Generating...' : 'Say Hello to AI'}
      </button>
      {response && (
        <div style={{ marginTop: '10px', padding: '10px', background: '#f0f0f0' }}>
          {response}
        </div>
      )}
    </div>
  );
}
