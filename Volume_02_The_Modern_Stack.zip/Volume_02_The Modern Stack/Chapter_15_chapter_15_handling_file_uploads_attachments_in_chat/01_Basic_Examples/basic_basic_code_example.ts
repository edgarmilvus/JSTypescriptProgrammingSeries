/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

'use client';

import { useChat } from 'ai/react';
import { useState, ChangeEvent, FormEvent } from 'react';

/**
 * FileChatInterface Component
 * 
 * A minimal client-side component demonstrating how to attach files
 * to a message using the Vercel AI SDK's `useChat` hook.
 */
export default function FileChatInterface() {
  // 1. Initialize the useChat hook.
  // The hook manages message history, input state, and API communication.
  const { 
    messages, 
    input, 
    handleInputChange, 
    handleSubmit, 
    isLoading, 
    error 
  } = useChat({
    api: '/api/chat', // The backend route handling the AI logic
  });

  // 2. Local state to visualize the selected file before sending.
  // In a production app, you might not need this if you rely solely on the hook's internal state.
  const [selectedFile, setSelectedFile] = useState<File | null>(null);

  /**
   * Handles the file selection from the <input type="file"> element.
   * 
   * @param event - The change event from the file input.
   */
  const handleFileChange = (event: ChangeEvent<HTMLInputElement>) => {
    if (event.target.files && event.target.files.length > 0) {
      const file = event.target.files[0];
      setSelectedFile(file);
      
      // CRITICAL: The `useChat` hook accepts an optional `files` array 
      // in its submit handler. We don't need to manually convert to Base64 here;
      // the SDK handles the conversion or streaming preparation.
      // However, to make the hook aware, we typically pass the file object 
      // directly in the custom submit handler (see below).
    }
  };

  /**
   * Custom submit handler to combine text input and file attachments.
   * 
   * @param event - The form submission event.
   */
  const handleCustomSubmit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();

    // Check if we have a file to attach
    if (selectedFile) {
      // The `handleSubmit` function provided by `useChat` accepts an options object.
      // We pass the `files` property here to attach the file to the outgoing message.
      handleSubmit(event, {
        files: [selectedFile],
      });
      
      // Reset local UI state
      setSelectedFile(null);
    } else {
      // Standard text-only submission
      handleSubmit(event);
    }
  };

  return (
    <div className="chat-container">
      {/* Message Display Area */}
      <div className="messages-list">
        {messages.map((m) => (
          <div key={m.id} className={`message ${m.role}`}>
            <strong>{m.role === 'user' ? 'You: ' : 'AI: '}</strong>
            {/* If the message has attachments, we can display them (or a placeholder) */}
            {m.experimental_attachments && m.experimental_attachments.length > 0 && (
              <span>[Attachment: {m.experimental_attachments[0].name}] </span>
            )}
            <span>{m.content}</span>
          </div>
        ))}
      </div>

      {/* Input Area */}
      <form onSubmit={handleCustomSubmit} className="input-area">
        <input
          type="text"
          value={input}
          onChange={handleInputChange}
          placeholder="Type a message..."
          disabled={isLoading}
        />
        
        {/* File Input: Hidden styling, triggered by a label for better UX */}
        <label htmlFor="file-upload" className="file-label">
          {selectedFile ? `Selected: ${selectedFile.name}` : '📎 Attach File'}
        </label>
        <input
          id="file-upload"
          type="file"
          onChange={handleFileChange}
          style={{ display: 'none' }}
          disabled={isLoading}
        />

        <button type="submit" disabled={isLoading || !input.trim()}>
          {isLoading ? 'Sending...' : 'Send'}
        </button>
      </form>

      {error && <div className="error">Error: {error.message}</div>}
    </div>
  );
}
