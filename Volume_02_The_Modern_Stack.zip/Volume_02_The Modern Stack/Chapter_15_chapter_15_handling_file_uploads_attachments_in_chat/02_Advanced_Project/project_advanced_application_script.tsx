/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.tsx
// Description: Advanced Application Script
// ==========================================

'use client';

import { useChat } from 'ai/react';
import { useState, useRef, ChangeEvent, FormEvent } from 'react';
import type { Message } from 'ai';

/**
 * ChatInterface Component
 * 
 * A client-side component that manages the chat UI, file selection, and message streaming.
 * It integrates with the Vercel AI SDK's `useChat` hook but enhances it with file attachment logic.
 * 
 * Security Note: We do not upload files directly here. We read them as Data URLs or Blobs
 * to attach them to the request payload, allowing the Server Action to handle validation and storage.
 */
export default function ChatInterface() {
  // State to hold files selected by the user but not yet sent
  const [pendingFiles, setPendingFiles] = useState<File[]>([]);
  
  // Ref for the hidden file input
  const fileInputRef = useRef<HTMLInputElement>(null);

  // useChat hook configuration
  const { 
    messages, 
    input, 
    handleInputChange, 
    handleSubmit: originalSubmit, 
    isLoading, 
    error 
  } = useChat({
    api: '/api/chat/route', // Pointing to our Server Action wrapper
  });

  /**
   * Handles file selection from the input element.
   * Updates local state with selected files.
   */
  const handleFileChange = (e: ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      setPendingFiles(Array.from(e.target.files));
    }
  };

  /**
   * Custom submission handler.
   * 
   * 1. Prevents default form submission.
   * 2. Constructs a custom message payload.
   * 3. Reads file contents (as Data URLs) to attach to the payload.
   * 4. Calls the internal `handleSubmit` provided by useChat with the augmented data.
   */
  const handleFileSubmit = async (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();

    // If there are no files, fall back to standard text submission
    if (pendingFiles.length === 0) {
      originalSubmit(e);
      return;
    }

    // Process files into a format suitable for the API payload
    const fileData = await Promise.all(
      pendingFiles.map(async (file) => ({
        name: file.name,
        type: file.type,
        size: file.size,
        // Convert file to Base64 string for transmission
        // Note: For very large files, streaming or presigned URLs are preferred over Base64
        data: await readFileAsBase64(file),
      }))
    );

    // Construct the experimental 'attachments' property supported by useChat
    const attachments = fileData;

    // Reset file input and state
    setPendingFiles([]);
    if (fileInputRef.current) fileInputRef.current.value = '';

    // Trigger the AI SDK submission with the augmented data
    // The SDK will POST this to the configured API endpoint
    originalSubmit(e, {
      data: {
        attachments, // This property is captured by the server action
      },
    });
  };

  /**
   * Helper: Reads a File object as a Base64 encoded string.
   */
  const readFileAsBase64 = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result as string);
      reader.onerror = reject;
      reader.readAsDataURL(file);
    });
  };

  return (
    <div className="flex flex-col h-full max-w-4xl mx-auto p-4 bg-white shadow-lg rounded-lg">
      {/* Message List */}
      <div className="flex-1 overflow-y-auto space-y-4 mb-4 p-2 border rounded">
        {messages.map((msg: Message) => (
          <div key={msg.id} className={`p-3 rounded ${msg.role === 'user' ? 'bg-blue-100 text-right' : 'bg-gray-100 text-left'}`}>
            <p className="font-semibold text-sm text-gray-600">{msg.role === 'user' ? 'You' : 'AI'}</p>
            <div className="mt-1 whitespace-pre-wrap">{msg.content}</div>
            
            {/* Render Attachments in UI */}
            {msg.experimental_attachments && (
              <div className="mt-2 flex flex-wrap gap-2 justify-end">
                {msg.experimental_attachments.map((att: any, i: number) => (
                  <div key={i} className="text-xs bg-purple-100 border border-purple-300 rounded px-2 py-1">
                    📎 {att.name}
                  </div>
                ))}
              </div>
            )}
          </div>
        ))}
        {isLoading && <div className="text-center text-gray-400 animate-pulse">AI is thinking...</div>}
        {error && <div className="text-red-500 text-center">Error: {error.message}</div>}
      </div>

      {/* Input Area */}
      <form onSubmit={handleFileSubmit} className="flex flex-col gap-2">
        {/* File Preview & Management */}
        {pendingFiles.length > 0 && (
          <div className="flex gap-2 overflow-x-auto pb-2">
            {pendingFiles.map((file, idx) => (
              <div key={idx} className="bg-gray-200 px-2 py-1 rounded text-xs whitespace-nowrap">
                {file.name} ({(file.size / 1024).toFixed(1)} KB)
              </div>
            ))}
          </div>
        )}

        <div className="flex gap-2">
          <input
            type="text"
            value={input}
            onChange={handleInputChange}
            placeholder="Ask a question or describe the image..."
            className="flex-1 border border-gray-300 rounded px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
            disabled={isLoading}
          />
          
          {/* Hidden File Input Trigger */}
          <button
            type="button"
            onClick={() => fileInputRef.current?.click()}
            className="bg-gray-200 hover:bg-gray-300 text-gray-700 font-bold py-2 px-4 rounded"
            disabled={isLoading}
          >
            📁
          </button>
          <input
            ref={fileInputRef}
            type="file"
            multiple
            onChange={handleFileChange}
            className="hidden"
          />

          <button
            type="submit"
            disabled={isLoading || !input.trim()}
            className="bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded disabled:opacity-50"
          >
            Send
          </button>
        </div>
      </form>
    </div>
  );
}
