/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script_part2.ts
// Description: Advanced Application Script
// ==========================================

import { streamText, StreamTextResult, CoreMessage } from 'ai';
import { openai } from '@ai-sdk/openai';
import { put } from '@vercel/blob'; // Vercel Blob storage SDK
import { z } from 'zod';

// IMPORTANT: Ensure this route is protected by authentication in a real app
export const runtime = 'edge'; // Use Edge Runtime for optimal performance

/**
 * POST /api/chat/route
 * 
 * Handles incoming chat requests containing text and file attachments.
 * 
 * Workflow:
 * 1. Parse incoming request body.
 * 2. Validate and sanitize files (size, type).
 * 3. Upload valid files to Vercel Blob storage.
 * 4. Construct a system prompt summarizing the attachments.
 * 5. Stream the response from the AI model.
 */
export async function POST(req: Request) {
  try {
    const json = await req.json();
    const messages: CoreMessage[] = json.messages;
    const attachments = json.data?.attachments || [];

    // 1. Process and Store Attachments
    const storedUrls: string[] = [];

    for (const attachment of attachments) {
      // --- SECURITY: VALIDATION ---
      // Validate File Size (Limit to 5MB)
      if (attachment.size > 5 * 1024 * 1024) {
        return new Response('File too large. Max 5MB.', { status: 413 });
      }

      // Validate File Type (Allow images and PDFs only)
      const allowedTypes = ['image/jpeg', 'image/png', 'image/webp', 'application/pdf'];
      if (!allowedTypes.includes(attachment.type)) {
        return new Response('Invalid file type.', { status: 415 });
      }

      // --- STORAGE: VERCEL BLOB ---
      // Extract base64 data string (remove data URL prefix)
      const base64Data = attachment.data.split(',')[1];
      const buffer = Buffer.from(base64Data, 'base64');
      
      // Upload to Blob
      // In a real app, generate a unique ID (e.g., UUID) for the filename
      const { url } = await put(`uploads/${Date.now()}-${attachment.name}`, buffer, {
        access: 'public', // or 'private' depending on requirements
        contentType: attachment.type,
      });

      storedUrls.push(url);
    }

    // 2. Construct the Prompt
    // We append a system message describing the attachments so the LLM knows about them.
    // Note: For images, the Vercel AI SDK supports passing URLs directly to models like GPT-4V.
    // For this example, we treat them as context references.
    
    const lastMessage = messages[messages.length - 1];
    
    // If files were attached, we might want to inject context or rely on the SDK's native attachment handling
    // However, currently `useChat` attachments are primarily for UI. 
    // We explicitly prompt the model about the attachments here for robustness.
    
    let systemContext = '';
    if (storedUrls.length > 0) {
      systemContext = `\n[Context]: The user has uploaded the following files. Reference them in your response if relevant: ${storedUrls.join(', ')}. `;
    }

    // 3. Stream the Response
    const result = await streamText({
      model: openai('gpt-4o-mini'), // Or 'gpt-4-vision-preview' for image analysis
      messages: [
        { role: 'system', content: 'You are a helpful assistant capable of analyzing text and references to uploaded files.' + systemContext },
        ...messages
      ],
    });

    return result.toAIStreamResponse();
    
  } catch (error) {
    console.error('Chat API Error:', error);
    return new Response('Internal Server Error', { status: 500 });
  }
}
