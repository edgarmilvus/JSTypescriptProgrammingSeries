/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.tsx
// Description: Solutions and Explanations
// ==========================================

// FileUploadChat.tsx
import React, { useState, useRef, ChangeEvent, DragEvent } from 'react';
import { useChat } from '@ai-sdk/react';

export default function FileUploadChat() {
  const { messages, input, handleInputChange, handleSubmit, isLoading } = useChat();
  const [files, setFiles] = useState<File[]>([]);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isDragging, setIsDragging] = useState(false);

  // 1. Handle file selection via input button
  const handleFileChange = (e: ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      setFiles(Array.from(e.target.files));
    }
  };

  // 2. Helper to convert File to DataURL (Base64)
  const fileToDataURL = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result as string);
      reader.onerror = reject;
      reader.readAsDataURL(file);
    });
  };

  // 3. Custom Submit Handler
  const customHandleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();

    // Convert files to DataURLs
    const attachments = await Promise.all(
      files.map(async (file) => ({
        contentType: file.type,
        data: await fileToDataURL(file),
      }))
    );

    // Submit with attachments
    handleSubmit(e, {
      // The SDK merges these options into the next message
      data: {
        attachments, // AI SDK expects this structure in the message
      },
    });

    // 4. Cleanup: Reset file input and state
    setFiles([]);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  // 5. Drag and Drop Handlers
  const handleDragOver = (e: DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(true);
  };

  const handleDragLeave = (e: DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
  };

  const handleDrop = (e: DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);

    if (e.dataTransfer.files) {
      // Merge existing files with dropped files
      setFiles((prev) => [...prev, ...Array.from(e.dataTransfer.files)]);
    }
  };

  return (
    <div className="flex flex-col w-full max-w-3xl mx-auto p-4">
      {/* Message List */}
      <div className="space-y-4 mb-4">
        {messages.map((m) => (
          <div key={m.id} className={`p-3 rounded ${m.role === 'user' ? 'bg-blue-100' : 'bg-gray-100'}`}>
            <strong>{m.role === 'user' ? 'User: ' : 'AI: '}</strong>
            {m.content}
            {m.experimental_attachments && (
              <div className="mt-2 text-xs text-gray-500">
                {m.experimental_attachments.map((att, i) => (
                  <span key={i} className="bg-white px-2 py-1 rounded border mr-1">
                    {att.contentType}
                  </span>
                ))}
              </div>
            )}
          </div>
        ))}
      </div>

      {/* Drop Zone Overlay (Visualized when dragging) */}
      {isDragging && (
        <div 
          className="fixed inset-0 bg-blue-500/20 z-50 flex items-center justify-center backdrop-blur-sm"
          onDragOver={handleDragOver}
          onDrop={handleDrop}
          onDragLeave={handleDragLeave}
        >
          <div className="bg-white p-8 rounded-lg shadow-xl text-xl font-bold text-blue-600">
            Drop files here to upload
          </div>
        </div>
      )}

      {/* File Chips */}
      {files.length > 0 && (
        <div className="flex flex-wrap gap-2 mb-2 p-2 border rounded bg-gray-50">
          {files.map((file, idx) => (
            <span 
              key={idx} 
              className="inline-flex items-center gap-1 px-2 py-1 bg-white border rounded text-sm"
            >
              {file.name}
              <button 
                onClick={() => setFiles(files.filter((_, i) => i !== idx))}
                className="text-red-500 hover:text-red-700 font-bold"
              >
                &times;
              </button>
            </span>
          ))}
        </div>
      )}

      {/* Chat Input Area with Drop Zone Handlers */}
      <div 
        className={`border-2 rounded-lg p-4 transition-colors ${isDragging ? 'border-blue-500 bg-blue-50' : 'border-gray-300'}`}
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
      >
        <form onSubmit={customHandleSubmit} className="flex items-center gap-2">
          {/* Hidden File Input */}
          <input 
            type="file" 
            ref={fileInputRef}
            onChange={handleFileChange}
            multiple 
            accept="image/*,application/pdf,text/plain"
            className="hidden"
          />
          
          {/* Visible Trigger Button */}
          <button
            type="button"
            onClick={() => fileInputRef.current?.click()}
            className="p-2 text-gray-600 hover:text-blue-600 transition"
            title="Attach files"
          >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.172 7l-6.586 6.586a2 2 0 102.828 2.828l6.414-6.586a4 4 0 00-5.656-5.656l-6.415 6.585a6 6 0 108.486 8.486L20.5 13" />
            </svg>
          </button>

          <input
            type="text"
            value={input}
            onChange={handleInputChange}
            className="flex-1 p-2 border rounded outline-none focus:border-blue-500"
            placeholder="Type a message..."
            disabled={isLoading}
          />
          
          <button 
            type="submit" 
            disabled={isLoading || (!input && files.length === 0)}
            className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 disabled:opacity-50"
          >
            {isLoading ? 'Sending...' : 'Send'}
          </button>
        </form>
      </div>
    </div>
  );
}
