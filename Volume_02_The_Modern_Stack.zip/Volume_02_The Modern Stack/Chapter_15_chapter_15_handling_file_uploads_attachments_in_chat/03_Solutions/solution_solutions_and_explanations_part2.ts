/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

// app/api/chat/route.ts
import { NextResponse } from 'next/server';
import { streamText } from 'ai'; // Assuming usage of Vercel AI SDK
import { openai } from '@ai-sdk/openai';

// 1. Configuration for file size limits (5MB)
const MAX_FILE_SIZE = 5 * 1024 * 1024; 

// 2. Helper to simulate non-blocking file processing (e.g., OCR or PDF read)
async function processAttachment(attachment: { data: string; contentType: string; name?: string }) {
  // Extract base64 data
  const base64Data = attachment.data.split(',')[1]; // Remove data:image/png;base64, prefix
  const buffer = Buffer.from(base64Data, 'base64');

  // 3. Size Validation (Interactive Challenge)
  if (buffer.length > MAX_FILE_SIZE) {
    throw new Error('FileTooLarge');
  }

  // 4. Simulate Async Processing (e.g., calling an external OCR library)
  // In a real scenario: await tesseract.recognize(buffer);
  // We use a promise to simulate I/O latency and ensure non-blocking behavior.
  await new Promise(resolve => setTimeout(resolve, 500)); 

  // Return simulated extracted text
  return `[Processed content from ${attachment.contentType} (${buffer.length} bytes)]: The user has uploaded a document containing relevant data for your context.`;
}

export async function POST(req: Request) {
  try {
    const { messages } = await req.json();

    // Extract the latest user message
    const lastMessage = messages[messages.length - 1];

    if (!lastMessage || !lastMessage.attachments) {
      // If no attachments, proceed normally
      const result = await streamText({
        model: openai('gpt-4o'),
        prompt: lastMessage.content,
      });
      return result.toAIStreamResponse();
    }

    // 5. Process all attachments concurrently using Promise.all
    // This ensures we don't block the event loop waiting for one file at a time.
    const processingPromises = lastMessage.attachments.map((att: any) => 
      processAttachment(att).catch(e => {
        if (e.message === 'FileTooLarge') throw e;
        return `Error processing attachment: ${att.contentType}`;
      })
    );

    const processedContents = await Promise.all(processingPromises);

    // 6. Context Injection
    // Construct a system prompt that includes the processed file data
    const contextPrompt = `
      Context from uploaded files:
      ${processedContents.join('\n\n')}
      
      User Query: ${lastMessage.content}
    `;

    // 7. Stream response with injected context
    const result = await streamText({
      model: openai('gpt-4o'),
      prompt: contextPrompt,
    });

    return result.toAIStreamResponse();

  } catch (error: any) {
    console.error('API Error:', error);
    
    if (error.message === 'FileTooLarge') {
      return NextResponse.json(
        { error: 'Payload Too Large: File exceeds 5MB limit.' },
        { status: 413 }
      );
    }

    return NextResponse.json(
      { error: 'Internal Server Error' },
      { status: 500 }
    );
  }
}
