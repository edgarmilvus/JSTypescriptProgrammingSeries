/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

// app/api/chat/route.ts
import { NextResponse } from 'next/server';
import { z } from 'zod';

// 1. Define the Attachment Schema
const attachmentSchema = z.object({
  contentType: z.string().min(1),
  data: z.string().min(1), // Assuming DataURL or Base64 string
});

// 2. Define the Message Schema
const messageSchema = z.object({
  role: z.enum(['user', 'assistant']),
  content: z.string(),
  // Attachments are optional but must match the schema if present
  attachments: z.array(attachmentSchema).optional(),
});

// 3. Define the Request Body Schema
const requestSchema = z.object({
  messages: z.array(messageSchema),
});

// 4. Interactive Challenge: Whitelist Validation
// We extend the attachment schema to refine the contentType
const secureAttachmentSchema = attachmentSchema.refine(
  (data) => {
    const allowedTypes = ['image/png', 'image/jpeg', 'application/pdf', 'text/plain'];
    return allowedTypes.includes(data.contentType);
  },
  {
    message: 'Invalid file type. Only PNG, JPEG, PDF, and TXT are allowed.',
    path: ['contentType'], // Error path points to the specific field
  }
);

// Updated Request Schema with security
const secureRequestSchema = z.object({
  messages: z.array(
    z.object({
      role: z.enum(['user', 'assistant']),
      content: z.string(),
      attachments: z.array(secureAttachmentSchema).optional(),
    })
  ),
});

// Type inference for downstream usage
export type ValidatedRequest = z.infer<typeof secureRequestSchema>;

export async function POST(req: Request) {
  // 5. Parse and Validate
  const body = await req.json();
  const validation = secureRequestSchema.safeParse(body);

  if (!validation.success) {
    // 6. Return 422 Unprocessable Entity with Zod errors
    return NextResponse.json(
      {
        error: 'Validation Failed',
        details: validation.error.format(),
      },
      { status: 422 }
    );
  }

  // Proceed with validated data
  const { messages } = validation.data;
  const lastMessage = messages[messages.length - 1];

  // ... (Rest of logic to call LLM) ...
  
  return NextResponse.json({ 
    status: 'success', 
    received: lastMessage.content 
  });
}
