/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

// 1. Client-Side: Upload Helper (using native fetch with progress simulation)
async function uploadToBlob(file: File): Promise<string> {
  // Create a form data payload
  const formData = new FormData();
  formData.append('file', file);

  // Note: In a real app, we might use XMLHttpRequest for precise progress events.
  // Here we simulate the flow.
  const response = await fetch('/api/upload', {
    method: 'POST',
    body: formData,
  });

  if (!response.ok) {
    throw new Error('Upload failed');
  }

  const { url } = await response.json();
  return url;
}

// 2. Client-Side: Modified Submit Handler
const customHandleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
  e.preventDefault();
  setIsUploading(true); // UI State for progress

  try {
    // Upload all files concurrently
    const uploadPromises = files.map((file) => uploadToBlob(file));
    const blobUrls = await Promise.all(uploadPromises);

    // Submit message with URLs instead of DataURLs
    handleSubmit(e, {
      data: {
        // We can use a custom field or standard attachments structure if SDK supports URLs
        // For this example, we pass a custom metadata field or standard structure
        attachments: blobUrls.map((url, i) => ({
          contentType: files[i].type,
          url: url, // Sending URL, not data
        })),
      },
    });

    setFiles([]);
  } catch (error) {
    console.error('Upload error:', error);
  } finally {
    setIsUploading(false);
  }
};

// ---------------------------------------------------------
// 3. Server-Side: API Route for Upload (app/api/upload/route.ts)
import { put } from '@vercel/blob';
import { NextResponse } from 'next/server';

export async function POST(request: Request) {
  // Vercel Blob handles the multipart form data parsing
  const { searchParams } = new URL(request.url);
  const file = await request.blob(); // or .json() if sending JSON

  // 4. Security: Validate file type and size before upload
  if (file.size > 5 * 1024 * 1024) {
    return NextResponse.json({ error: 'File too large' }, { status: 413 });
  }
  
  // Allowlist check
  const allowedTypes = ['image/', 'application/pdf', 'text/'];
  if (!allowedTypes.some(type => file.type.startsWith(type))) {
    return NextResponse.json({ error: 'File type not allowed' }, { status: 400 });
  }

  try {
    // Generate blob URL
    const blob = await put(`chat-uploads/${Date.now()}-${file.type}`, file, {
      access: 'public', // or 'private' depending on needs
      token: process.env.BLOB_READ_WRITE_TOKEN,
    });

    return NextResponse.json({ url: blob.url });
  } catch (error) {
    return NextResponse.json({ error: 'Failed to upload' }, { status: 500 });
  }
}
