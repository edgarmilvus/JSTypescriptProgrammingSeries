/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: theory_theoretical_foundations.ts
// Description: Theoretical Foundations
// ==========================================

digraph VisionPipeline {
    rankdir=TB;
    node [shape=box, style="rounded,filled", fontname="Helvetica"];

    subgraph cluster_client {
        label="Client Side (Browser)";
        style=dashed;
        User [label="User Interaction\n(File Upload)", fillcolor="#e1f5fe"];
        FileReader [label="FileReader API\n(Async Serialization)", fillcolor="#b3e5fc"];
        ClientFetch [label="Fetch Request\n(Base64 + Prompt)", fillcolor="#81d4fa"];
    }

    subgraph cluster_server {
        label="Server Side (Next.js / RSC)";
        style=dashed;
        ServerRoute [label="React Server Component\n(Async Function)", fillcolor="#fff3e0"];
        SecureKey [label="Environment Variables\n(OpenAI API Key)", fillcolor="#ffe0b2", shape=note];
        AI_SDK [label="Vercel AI SDK\n(Stream Management)", fillcolor="#ffcc80"];
    }

    subgraph cluster_external {
        label="External API";
        OpenAI [label="GPT-4o Vision API\n(Multi-Modal Inference)", fillcolor="#f3e5f5", shape=ellipse];
    }

    User -> FileReader [label="1. Select Image"];
    FileReader -> ClientFetch [label="2. Convert to Base64"];
    ClientFetch -> ServerRoute [label="3. HTTP POST Request"];
    
    ServerRoute -> SecureKey [label="Accesses", style=dashed];
    ServerRoute -> AI_SDK [label="4. Passes Payload"];
    AI_SDK -> OpenAI [label="5. Sends Image + Text Tokens"];
    
    OpenAI -> AI_SDK [label="6. Streamed Response Tokens"];
    AI_SDK -> ServerRoute [label="7. Parse Stream to UI"];
    ServerRoute -> ClientFetch [label="8. Rendered React Component", dir=back];
}
