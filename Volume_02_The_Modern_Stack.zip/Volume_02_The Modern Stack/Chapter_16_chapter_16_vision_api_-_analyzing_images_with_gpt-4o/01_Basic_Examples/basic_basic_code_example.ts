/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

// File: app/actions.ts
'use server';

import { generateText } from 'ai';
import { openai } from '@ai-sdk/openai';
import { z } from 'zod';

/**
 * Server Action: analyzeImage
 * 
 * Handles the secure transmission of image data to OpenAI.
 * Uses 'use server' to allow client components to invoke this function directly.
 * 
 * @param formData - Contains the uploaded file from an HTML form.
 * @returns A string containing the AI-generated description.
 */
export async function analyzeImage(formData: FormData) {
  // 1. Extract the file from the form data
  const file = formData.get('image') as File | null;

  if (!file) {
    throw new Error('No image file provided.');
  }

  // 2. Convert the image to a Base64 string
  // This allows us to embed the image directly in the JSON payload sent to OpenAI
  const bytes = await file.arrayBuffer();
  const base64Image = Buffer.from(bytes).toString('base64');

  // 3. Define the prompt for GPT-4o
  // We use a structured prompt to guide the model's output.
  const prompt = 'Describe this image in a single, concise sentence. Focus on the main subject and setting.';

  try {
    // 4. Call the AI SDK's generateText function
    // The SDK handles the HTTP request, headers, and stream processing.
    const { text } = await generateText({
      model: openai('gpt-4o-mini'), // Using the 'o-mini' variant for speed/cost in this demo
      messages: [
        {
          role: 'user',
          content: [
            { type: 'text', text: prompt },
            {
              type: 'image',
              image: `data:image/jpeg;base64,${base64Image}`,
            },
          ],
        },
      ],
    });

    return text;
  } catch (error) {
    console.error('Error analyzing image:', error);
    // In a production app, handle specific API errors (rate limits, safety violations)
    return 'Error analyzing image. Please try again.';
  }
}
