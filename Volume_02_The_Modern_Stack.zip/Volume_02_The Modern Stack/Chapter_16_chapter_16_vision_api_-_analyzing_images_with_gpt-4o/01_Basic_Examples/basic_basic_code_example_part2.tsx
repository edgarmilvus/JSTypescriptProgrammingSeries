/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.tsx
// Description: Basic Code Example
// ==========================================

// File: app/page.tsx
'use client';

import { useRef, useState, useTransition } from 'react';
import { analyzeImage } from './actions';

export default function VisionDemo() {
  const [result, setResult] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [isPending, startTransition] = useTransition();
  const fileInputRef = useRef<HTMLInputElement>(null);

  /**
   * Handles the form submission.
   * Wraps the server action in startTransition to handle React concurrent mode
   * and provide a loading state.
   */
  const handleSubmit = async (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setResult(null);
    setError(null);

    const formData = new FormData(event.currentTarget);
    
    // Basic client-side validation
    const file = formData.get('image') as File;
    if (!file || file.size === 0) {
      setError('Please select an image to analyze.');
      return;
    }

    startTransition(async () => {
      try {
        // Invoke the server action
        const analysis = await analyzeImage(formData);
        setResult(analysis);
      } catch (err) {
        setError('Failed to analyze image on the server.');
      }
    });
  };

  return (
    <div style={{ maxWidth: '600px', margin: '2rem auto', fontFamily: 'sans-serif' }}>
      <h1>AI Vision Analyzer</h1>
      
      <form onSubmit={handleSubmit}>
        <div style={{ marginBottom: '1rem' }}>
          <label htmlFor="image">Upload Image:</label>
          <input 
            ref={fileInputRef}
            type="file" 
            id="image" 
            name="image" 
            accept="image/*" 
            required 
            style={{ display: 'block', marginTop: '0.5rem' }}
          />
        </div>
        
        <button 
          type="submit" 
          disabled={isPending}
          style={{ 
            padding: '0.5rem 1rem', 
            backgroundColor: isPending ? '#ccc' : '#0070f3', 
            color: 'white', 
            border: 'none', 
            borderRadius: '4px',
            cursor: isPending ? 'not-allowed' : 'pointer'
          }}
        >
          {isPending ? 'Analyzing...' : 'Analyze Image'}
        </button>
      </form>

      {/* Result Display Area */}
      {isPending && (
        <div style={{ marginTop: '1rem', color: '#666' }}>
          Processing image with GPT-4o...
        </div>
      )}

      {result && (
        <div style={{ marginTop: '1rem', padding: '1rem', backgroundColor: '#f0f9ff', border: '1px solid #bae6fd' }}>
          <h3 style={{ marginTop: 0 }}>Analysis Result:</h3>
          <p>{result}</p>
        </div>
      )}

      {error && (
        <div style={{ marginTop: '1rem', padding: '1rem', backgroundColor: '#fef2f2', border: '1px solid #fecaca', color: '#991b1b' }}>
          {error}
        </div>
      )}
    </div>
  );
}
