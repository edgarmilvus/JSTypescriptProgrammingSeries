/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

'use server';

import { generateText, streamText } from 'ai';
import { createOpenAI } from '@ai-sdk/openai';
import { createStreamableValue } from 'ai/rsc';
import { z } from 'zod';

// ==============================================================================
// 1. CONFIGURATION & SECURITY
// ==============================================================================

/**
 * Initializes the OpenAI provider instance.
 * CRITICAL: This runs exclusively on the server. The API key is stored in 
 * environment variables and is never exposed to the client bundle.
 */
const openai = createOpenAI({
  apiKey: process.env.OPENAI_API_KEY!,
  compatibility: 'strict', // Enforce API format compliance
});

// ==============================================================================
// 2. SERVER ACTION: IMAGE ANALYSIS LOGIC
// ==============================================================================

/**
 * Analyzes a user-uploaded image for accessibility and UI compliance using GPT-4o.
 * 
 * @param prevResult - The previous form state (for Next.js useFormState).
 * @param formData - Contains the image file and optional context notes.
 * @returns An object containing the streamed AI response or error messages.
 * 
 * IMPLEMENTS: Exhaustive Asynchronous Resilience
 */
export async function analyzeImageAction(
  prevResult: any,
  formData: FormData
) {
  // --- Resource Management Setup ---
  // We use a streamable value to allow the UI to render text incrementally.
  const stream = createStreamableValue('');
  
  // --- Input Validation ---
  const file = formData.get('image') as File | null;
  if (!file || file.size === 0) {
    stream.done();
    return { 
      error: 'No image provided.', 
      aiResponse: null 
    };
  }

  // --- Asynchronous Execution Block ---
  (async () => {
    try {
      // 1. Convert File to Base64 string for the AI SDK
      // We use a Node.js Buffer for efficient conversion.
      const bytes = await file.arrayBuffer();
      const base64Image = Buffer.from(bytes).toString('base64');
      const dataUrl = `data:${file.type};base64,${base64Image}`;

      // 2. Define the System Prompt for GPT-4o
      // This guides the model to act as an accessibility auditor.
      const systemPrompt = `
        You are an expert Accessibility and UI Compliance Auditor. 
        Analyze the provided screenshot.
        Look for: 
        1. Missing Alt Text on images.
        2. Low contrast ratios (if detectable).
        3. Form inputs without labels.
        4. Semantic HTML structure issues.
        Respond in clear, structured Markdown. Be concise but specific.
      `;

      // 3. Initialize the Stream
      // We use streamText to handle the LLM's response token-by-token.
      const { textStream } = await streamText({
        model: openai('gpt-4o'),
        system: systemPrompt,
        messages: [
          {
            role: 'user',
            content: [
              { type: 'text', text: 'Analyze this interface screenshot.' },
              { type: 'image', data: dataUrl, mimeType: file.type },
            ],
          },
        ],
        temperature: 0.4, // Lower temp for deterministic analysis
      });

      // 4. Stream Processing
      // Iterate over the stream and update the UI incrementally.
      for await (const chunk of textStream) {
        stream.update(chunk);
      }

    } catch (error) {
      // --- Error Handling ---
      // Log the error server-side (in a real app, use a logger like Sentry).
      console.error('Vision API Error:', error);
      
      // Update stream with a user-friendly error message.
      stream.update('Sorry, an error occurred while analyzing the image.');
    } finally {
      // --- Resource Cleanup ---
      // Always close the stream to signal completion to the client.
      stream.done();
    }
  })();

  // Return the stream controller to the client component
  return { aiResponse: stream.value, error: null };
}
