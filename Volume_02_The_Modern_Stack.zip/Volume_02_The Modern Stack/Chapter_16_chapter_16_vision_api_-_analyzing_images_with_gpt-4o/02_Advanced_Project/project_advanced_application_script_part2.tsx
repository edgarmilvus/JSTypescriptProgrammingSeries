/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script_part2.tsx
// Description: Advanced Application Script
// ==========================================

'use client';

import { useFormState, useFormStatus } from 'react-dom';
import { analyzeImageAction } from './actions';
import { readStreamableValue } from 'ai/rsc';
import { useEffect, useState } from 'react';

// ==============================================================================
// 3. CLIENT COMPONENT: UI & INTERACTION
// ==============================================================================

/**
 * A form component to upload images and display the streamed analysis.
 * Uses `useFormState` for server-side validation handling.
 */
export function ImageAuditorForm() {
  // Bind the Server Action to the form state
  const [state, formAction] = useFormState(analyzeImageAction, null);
  const [aiText, setAiText] = useState('');
  const { pending } = useFormStatus();

  // ==============================================================================
  // 4. STREAM CONSUMPTION EFFECT
  // ==============================================================================
  
  /**
   * Monitors the state for a new streamable value and reads it incrementally.
   * This bridges the gap between the Server Action stream and the React state.
   */
  useEffect(() => {
    if (state?.aiResponse) {
      // Reset text if it's a new request
      setAiText('');

      (async () => {
        // Read the streamable value asynchronously
        for await (const chunk of readStreamableValue(state.aiResponse)) {
          // Append each chunk to the UI state
          setAiText((prev) => prev + chunk);
        }
      })();
    }
  }, [state?.aiResponse]);

  return (
    <div className="max-w-2xl mx-auto p-6 bg-white rounded-lg shadow-md">
      <h2 className="text-2xl font-bold mb-4 text-gray-800">
        Screenshot Compliance Auditor
      </h2>
      
      {/* Upload Form */}
      <form action={formAction} className="space-y-4">
        <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center hover:border-blue-500 transition-colors">
          <input 
            type="file" 
            name="image" 
            accept="image/*" 
            className="block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100"
          />
        </div>

        <button
          type="submit"
          disabled={pending}
          className={`w-full py-2 px-4 rounded font-semibold text-white transition-colors ${
            pending 
              ? 'bg-gray-400 cursor-not-allowed' 
              : 'bg-blue-600 hover:bg-blue-700'
          }`}
        >
          {pending ? 'Analyzing...' : 'Analyze Image'}
        </button>
      </form>

      {/* Error Display */}
      {state?.error && (
        <div className="mt-4 p-3 bg-red-100 text-red-700 rounded border border-red-200">
          {state.error}
        </div>
      )}

      {/* Streamed AI Response Display */}
      <div className="mt-6 p-4 bg-gray-50 rounded border border-gray-200 min-h-[150px]">
        <h3 className="text-sm font-semibold text-gray-500 uppercase tracking-wide mb-2">
          Analysis Report
        </h3>
        <div className="prose prose-sm text-gray-800 whitespace-pre-wrap">
          {aiText || <span className="text-gray-400 italic">Waiting for analysis...</span>}
        </div>
      </div>
    </div>
  );
}
