/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script_part3.ts
// Description: Advanced Application Script
// ==========================================

digraph Architecture {
    rankdir=TB;
    node [shape=box, style="rounded,filled", fillcolor="#e3f2fd", fontname="Helvetica"];
    
    Client [label="Client Browser\n(Form & UI)", fillcolor="#fff3e0"];
    ServerAction [label="Server Action\n('use server')", fillcolor="#e8f5e9"];
    StreamController [label="StreamableValue\nController", fillcolor="#f3e5f5"];
    OpenAI [label="OpenAI GPT-4o\nVision API", fillcolor="#ffebee"];
    
    Client -> ServerAction [label="1. Upload Image\n(Base64 String)"];
    ServerAction -> ServerAction [label="2. Validation &\nPrompt Construction"];
    ServerAction -> OpenAI [label="3. Async Stream Request"];
    OpenAI -> ServerAction [label="4. Token Stream\n(Chunks)"];
    
    // Internal Loop
    ServerAction -> StreamController [label="5. Update Stream\n(stream.update)"];
    StreamController -> Client [label="6. Incremental UI Update\n(React State)"];
    
    // Cleanup
    ServerAction -> StreamController [label="7. Finally: Done\n(stream.done)"];
}
