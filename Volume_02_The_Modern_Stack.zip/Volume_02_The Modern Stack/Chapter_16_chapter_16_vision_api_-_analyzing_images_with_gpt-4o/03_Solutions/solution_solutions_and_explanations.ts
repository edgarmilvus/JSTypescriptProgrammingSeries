/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

'use server';

import { generateText } from 'ai';
import { openai } from '@ai-sdk/openai';
import { z } from 'zod';

// Define the input schema for validation
const analyzeImageSchema = z.object({
  file: z.instanceof(File),
  tone: z.enum(['descriptive', 'poetic', 'technical']),
});

export async function analyzeImage(prevState: any, formData: FormData) {
  const validatedFields = analyzeImageSchema.safeParse({
    file: formData.get('image'),
    tone: formData.get('tone'),
  });

  if (!validatedFields.success) {
    return {
      error: 'Invalid file or tone selection. Please upload a valid image.',
    };
  }

  const { file, tone } = validatedFields.data;

  // Convert file to a data URL for the Vercel AI SDK
  const bytes = await file.arrayBuffer();
  const base64String = Buffer.from(bytes).toString('base64');
  const dataUrl = `data:${file.type};base64,${base64String}`;

  // Dynamic prompt based on selected tone
  let systemPrompt = '';
  switch (tone) {
    case 'poetic':
      systemPrompt = 'You are a poetic visual analyst. Describe the image in a lyrical, evocative paragraph.';
      break;
    case 'technical':
      systemPrompt = 'You are a technical visual analyst. Describe the image focusing on composition, lighting, colors, and technical details.';
      break;
    default:
      systemPrompt = 'You are a professional visual analyst. Provide a rich, descriptive paragraph of the image content.';
  }

  try {
    // Stream the response
    const result = await generateText({
      model: openai('gpt-4o'),
      system: systemPrompt,
      messages: [
        {
          role: 'user',
          content: [
            { type: 'text', text: 'Describe this image in detail.' },
            { type: 'image', image: dataUrl },
          ],
        },
      ],
    });

    return { text: result.text };
  } catch (error) {
    console.error('Error analyzing image:', error);
    return { error: 'Failed to analyze the image. Please try again.' };
  }
}
