/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part10.ts
// Description: Solutions and Explanations
// ==========================================

'use client';

import { useRef, useState } from 'react';
import { useActionState } from 'react';
import { analyzeImage } from '@/actions/analyzeImage'; // Reusing Exercise 1 action
import { compressImage } from '@/lib/imageUtils';

export default function OptimizedVisionDescriber() {
  const [preview, setPreview] = useState<string | null>(null);
  const [originalSize, setOriginalSize] = useState<number>(0);
  const [compressedSize, setCompressedSize] = useState<number>(0);
  const [quality, setQuality] = useState<number>(0.7); // Default quality
  const [state, formAction, pending] = useActionState(analyzeImage, null);
  
  const formRef = useRef<HTMLFormElement>(null);

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setOriginalSize(file.size);
    
    // Compress the image before setting preview or submitting
    try {
      const compressedFile = await compressImage(file, quality, 1024);
      
      setCompressedSize(compressedFile.size);
      
      // Create preview URL for the compressed image
      const url = URL.createObjectURL(compressedFile);
      setPreview(url);

      // Update the hidden file input in the form with the compressed file
      // We need to manually update the FormData in the form submission
      // Or we can replace the file in the input (tricky due to React controlled/uncontrolled)
      // A cleaner way for this specific pattern is to handle submission via a custom handler
      // that injects the compressed file into FormData.
    } catch (err) {
      console.error("Compression failed", err);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formRef.current) return;

    const formData = new FormData(formRef.current);
    const originalFile = formData.get('image') as File;

    if (originalFile && originalFile.size > 0) {
      // Perform compression
      const compressedFile = await compressImage(originalFile, quality, 1024);
      
      // Replace the file in FormData
      formData.set('image', compressedFile);
      
      // Submit the modified FormData to the server action
      // Note: formAction expects a FormData, but we are calling it manually here
      // to ensure we pass the compressed file.
      const result = await analyzeImage(null, formData);
      
      // Manually update state since we bypassed useActionState's native submission
      // (In a real app, you might dispatch an event or use a different hook pattern)
      // For simplicity in this exercise, we rely on the server action return value.
      console.log(result); 
    }
  };

  return (
    <div className="p-6 border rounded-lg max-w-2xl mx-auto space-y-4">
      <h2 className="text-xl font-bold">Optimized Vision Describer (Quantized)</h2>
      
      <form ref={formRef} onSubmit={handleSubmit} className="space-y-4">
        <input 
          type="file" 
          name="image" 
          accept="image/*" 
          onChange={handleFileChange}
          className="block w-full text-sm text-gray-500"
        />

        {/* Quality Control */}
        <div className="bg-gray-50 p-4 rounded">
          <label className="block text-sm font-medium mb-1">
            Compression Quality: {quality.toFixed(2)}
          </label>
          <input 
            type="range" 
            min="0.1" 
            max="1.0" 
            step="0.1" 
            value={quality}
            onChange={(e) => setQuality(parseFloat(e.target.value))}
            className="w-full"
          />
          <div className="flex justify-between text-xs text-gray-500 mt-1">
            <span>Low Quality (Small Size)</span>
            <span>High Quality (Large Size)</span>
          </div>
        </div>

        {/* Size Comparison */}
        {originalSize > 0 && (
          <div className="text-sm">
            <div>Original: {(originalSize / 1024).toFixed(1)} KB</div>
            <div>Processed: {(compressedSize / 1024).toFixed(1)} KB</div>
            <div className="font-bold text-green-600">
              Saved: {((1 - compressedSize / originalSize) * 100).toFixed(0)}%
            </div>
          </div>
        )}

        {preview && (
          <div className="mt-4">
            <h3 className="text-sm font-semibold mb-2">Preview (Compressed):</h3>
            <img src={preview} alt="Preview" className="max-h-48 rounded border" />
          </div>
        )}

        <button 
          type="submit" 
          disabled={pending || compressedSize === 0}
          className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 disabled:opacity-50"
        >
          {pending ? 'Analyzing...' : 'Analyze Image'}
        </button>
      </form>

      {state?.text && (
        <div className="p-4 bg-gray-50 rounded border">
          <h3 className="font-semibold mb-2">Analysis Result:</h3>
          <p className="whitespace-pre-wrap">{state.text}</p>
        </div>
      )}
    </div>
  );
}
