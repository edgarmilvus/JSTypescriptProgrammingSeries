/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

'use client';

import { useRef, useState } from 'react';
import { useActionState } from 'react';
import { analyzeImage } from '@/actions/analyzeImage';

export default function VisionDescriber() {
  const [preview, setPreview] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  // useActionState handles the form submission and pending state
  const [state, formAction, pending] = useActionState(analyzeImage, null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const url = URL.createObjectURL(file);
      setPreview(url);
    }
  };

  return (
    <div className="p-6 border rounded-lg max-w-2xl mx-auto space-y-4">
      <h2 className="text-xl font-bold">Vision Describer</h2>
      
      <form action={formAction} className="space-y-4">
        {/* Hidden input for file data */}
        <input 
          type="file" 
          name="image" 
          accept="image/*" 
          ref={fileInputRef}
          onChange={handleFileChange}
          className="block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100"
        />

        {/* Tone Selector */}
        <div className="flex items-center space-x-4">
          <label htmlFor="tone" className="text-sm font-medium">Tone:</label>
          <select name="tone" defaultValue="descriptive" className="border rounded p-2">
            <option value="descriptive">Descriptive</option>
            <option value="poetic">Poetic</option>
            <option value="technical">Technical</option>
          </select>
        </div>

        {/* Preview Area */}
        {preview && (
          <div className="mt-4">
            <h3 className="text-sm font-semibold mb-2">Preview:</h3>
            <img src={preview} alt="Preview" className="max-h-48 rounded border" />
          </div>
        )}

        <button 
          type="submit" 
          disabled={pending}
          className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 disabled:opacity-50"
        >
          {pending ? 'Analyzing...' : 'Analyze Image'}
        </button>
      </form>

      {/* Results Area */}
      {state?.error && (
        <div className="p-3 bg-red-100 text-red-700 rounded">
          {state.error}
        </div>
      )}
      
      {state?.text && (
        <div className="p-4 bg-gray-50 rounded border">
          <h3 className="font-semibold mb-2">Analysis Result:</h3>
          <p className="whitespace-pre-wrap">{state.text}</p>
        </div>
      )}
    </div>
  );
}
