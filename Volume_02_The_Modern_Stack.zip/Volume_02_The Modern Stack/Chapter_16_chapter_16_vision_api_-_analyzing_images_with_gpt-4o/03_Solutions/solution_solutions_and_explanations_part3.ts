/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

'use server';

import { generateObject } from 'ai';
import { openai } from '@ai-sdk/openai';
import { z } from 'zod';

// 1. Define the Zod Schema
const receiptSchema = z.object({
  vendorName: z.string().nullable(),
  totalAmount: z.number().nullable(),
  transactionDate: z.string().nullable(), // ISO format
  items: z.array(
    z.object({
      description: z.string(),
      price: z.number(),
    })
  ).optional(),
});

export async function extractReceiptData(formData: FormData) {
  const file = formData.get('image') as File;
  
  if (!file || file.size === 0) {
    return { error: 'No file selected.' };
  }

  // Convert file to data URL
  const bytes = await file.arrayBuffer();
  const base64String = Buffer.from(bytes).toString('base64');
  const dataUrl = `data:${file.type};base64,${base64String}`;

  try {
    // 2. Use generateObject with the schema
    const result = await generateObject({
      model: openai('gpt-4o'),
      schema: receiptSchema,
      prompt: `Extract the vendor name, total amount, transaction date, and line items from this receipt image. 
               If a field is not legible or present, return null for that field. 
               Ignore any text that is not part of the receipt data.`,
      messages: [
        {
          role: 'user',
          content: [
            { type: 'text', text: 'Analyze this receipt.' },
            { type: 'image', image: dataUrl },
          ],
        },
      ],
    });

    // 3. Validate the output with Zod (Defensive Programming)
    const validatedData = receiptSchema.safeParse(result.object);
    
    if (!validatedData.success) {
      return { error: 'Failed to validate extracted data structure.' };
    }

    return { data: validatedData.data };
  } catch (error) {
    console.error('Extraction error:', error);
    return { error: 'Failed to extract data from receipt.' };
  }
}
