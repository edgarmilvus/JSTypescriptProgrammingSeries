/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

import { generateText } from 'ai';
import { openai } from '@ai-sdk/openai';
import Image from 'next/image';

// Helper function to simulate delay (optional, for visualizing streaming)
const delay = (ms: number) => new Promise(res => setTimeout(res, ms));

export default async function LandscapeStory({ imageSrc, genre }: { imageSrc: string, genre: string }) {
  // --- STEP 1: Object Detection ---
  // We run this sequentially. The component waits for this to finish.
  const objectDetectionResult = await generateText({
    model: openai('gpt-4o'),
    prompt: `List the 3-5 most prominent objects or elements in this image, separated by commas. Do not describe them, just list them.`,
    messages: [{ role: 'user', content: [{ type: 'image', image: imageSrc }] }],
  });

  // Parse the comma-separated string into an array
  const elements = objectDetectionResult.text.split(',').map(e => e.trim()).filter(e => e);

  // --- STEP 2: Story Generation ---
  // Construct the prompt using the output from Step 1 and the genre prop
  const storyPrompt = `Using the following elements: ${elements.join(', ')}, write a short, two-sentence story in the ${genre} genre.`;

  // We use generateText again. In a real streaming scenario, you might use streamText 
  // and the React 'ai' component, but for standard Server Components, we await the result.
  const storyResult = await generateText({
    model: openai('gpt-4o'),
    prompt: storyPrompt,
  });

  return (
    <div className="p-6 bg-white rounded-lg shadow border">
      <div className="flex gap-4 mb-6">
        <div className="w-1/2">
          <Image 
            src={imageSrc} 
            alt="Landscape" 
            width={400} 
            height={300} 
            className="rounded w-full h-auto object-cover"
          />
        </div>
        <div className="w-1/2">
          <h3 className="text-lg font-bold mb-2">Detected Elements:</h3>
          <ul className="list-disc pl-5 space-y-1">
            {elements.map((el, idx) => (
              <li key={idx} className="text-gray-700">{el}</li>
            ))}
          </ul>
        </div>
      </div>

      <div className="mt-4 p-4 bg-gray-50 rounded border">
        <h3 className="text-lg font-bold mb-2">Generated Story ({genre}):</h3>
        <p className="text-lg leading-relaxed text-gray-800 italic">
          "{storyResult.text}"
        </p>
      </div>
    </div>
  );
}
