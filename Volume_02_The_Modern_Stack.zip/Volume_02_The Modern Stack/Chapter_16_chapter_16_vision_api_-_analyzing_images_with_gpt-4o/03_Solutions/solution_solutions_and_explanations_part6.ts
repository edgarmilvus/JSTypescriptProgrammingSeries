/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part6.ts
// Description: Solutions and Explanations
// ==========================================

'use client';

import { useState } from 'react';
import LandscapeStory from './LandscapeStory';

export default function StoryGenerator() {
  const [imageSrc, setImageSrc] = useState<string | null>(null);
  const [genre, setGenre] = useState('Fantasy');

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const url = URL.createObjectURL(file);
      setImageSrc(url);
    }
  };

  return (
    <div className="p-6 max-w-4xl mx-auto">
      <div className="flex gap-4 mb-6 items-end">
        <div>
          <label className="block text-sm font-medium mb-1">Upload Landscape</label>
          <input type="file" accept="image/*" onChange={handleImageUpload} className="block w-full text-sm text-gray-500" />
        </div>
        <div>
          <label className="block text-sm font-medium mb-1">Genre</label>
          <select 
            value={genre} 
            onChange={(e) => setGenre(e.target.value)} 
            className="border rounded p-2"
          >
            <option value="Fantasy">Fantasy</option>
            <option value="Sci-Fi">Sci-Fi</option>
            <option value="Mystery">Mystery</option>
          </select>
        </div>
      </div>

      {/* 
        The Server Component is conditionally rendered. 
        When imageSrc exists, Next.js will stream this component to the client.
        The async logic inside LandscapeStory executes on the server.
      */}
      {imageSrc && (
        <LandscapeStory imageSrc={imageSrc} genre={genre} />
      )}
    </div>
  );
}
