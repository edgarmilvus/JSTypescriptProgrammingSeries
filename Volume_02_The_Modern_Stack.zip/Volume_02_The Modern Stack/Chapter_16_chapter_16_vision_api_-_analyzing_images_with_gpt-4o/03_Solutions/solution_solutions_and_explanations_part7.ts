/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part7.ts
// Description: Solutions and Explanations
// ==========================================

'use server';

import { generateText } from 'ai';
import { openai } from '@ai-sdk/openai';
import { revalidatePath } from 'next/cache';

// In a real app, use a database or Redis. 
// For this exercise, we use a simple in-memory store scoped to the user/session.
// Note: This resets on server restart.
const contextStore = new Map<string, string>();

export async function processVisualQA(
  previousState: any, 
  formData: FormData
) {
  const file = formData.get('image') as File;
  const question = formData.get('question') as string;
  const sessionId = formData.get('sessionId') as string;

  // Case 1: New Image Upload (Initial Analysis)
  if (file && file.size > 0) {
    const bytes = await file.arrayBuffer();
    const base64String = Buffer.from(bytes).toString('base64');
    const dataUrl = `data:${file.type};base64,${base64String}`;

    // Generate the visual context
    const contextResult = await generateText({
      model: openai('gpt-4o'),
      prompt: `Analyze this image and provide a detailed visual summary. 
               Include objects, colors, textures, and the overall mood. 
               This context will be used to answer questions later.`,
      messages: [{ role: 'user', content: [{ type: 'image', image: dataUrl }] }],
    });

    // Store the context in memory
    contextStore.set(sessionId, contextResult.text);

    return { 
      status: 'context_created', 
      message: 'Image analyzed. You can now ask questions.' 
    };
  }

  // Case 2: Answering a Question
  if (question && sessionId) {
    const context = contextStore.get(sessionId);

    if (!context) {
      return { error: 'No image context found. Please upload an image first.' };
    }

    // Use the stored context to answer the question
    const answerResult = await generateText({
      model: openai('gpt-4o'),
      system: `You are a helpful assistant. Use the following visual context to answer the user's question. Context: ${context}`,
      prompt: question,
    });

    return { answer: answerResult.text };
  }

  return { error: 'Invalid input.' };
}
