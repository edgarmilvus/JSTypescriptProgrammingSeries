/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part8.ts
// Description: Solutions and Explanations
// ==========================================

'use client';

import { useState } from 'react';
import { useActionState } from 'react';
import { processVisualQA } from '@/actions/visualQA';
import { v4 as uuidv4 } from 'uuid';

export default function VisualQABot() {
  // Generate a persistent session ID for the duration of the session
  const [sessionId] = useState(() => uuidv4());
  const [history, setHistory] = useState<{ role: 'user' | 'bot'; text: string }[]>([]);
  const [state, formAction, pending] = useActionState(processVisualQA, null);

  // Handle the result from the server action
  useState(() => {
    if (state?.status === 'context_created') {
      setHistory(prev => [...prev, { role: 'bot', text: state.message }]);
    }
    if (state?.answer) {
      setHistory(prev => [...prev, { role: 'bot', text: state.answer }]);
    }
    if (state?.error) {
      setHistory(prev => [...prev, { role: 'bot', text: `Error: ${state.error}` }]);
    }
  });

  const handleAskQuestion = (e: React.FormEvent) => {
    const form = e.currentTarget as HTMLFormElement;
    const questionInput = form.querySelector('input[name="question"]') as HTMLInputElement;
    
    // Add user question to history immediately for UI feedback
    if (questionInput.value) {
      setHistory(prev => [...prev, { role: 'user', text: questionInput.value }]);
    }
  };

  const handleReset = () => {
    setHistory([]);
    // In a real app, you might invalidate the server cache or reset the store
    window.location.reload(); // Simple reset for this exercise
  };

  return (
    <div className="p-6 border rounded-lg max-w-2xl mx-auto space-y-4">
      <div className="flex justify-between items-center">
        <h2 className="text-xl font-bold">Visual QA Bot</h2>
        <button onClick={handleReset} className="text-sm text-red-600 underline">Reset Image</button>
      </div>

      {/* Initial Upload Form */}
      {history.length === 0 && (
        <form action={formAction} className="space-y-4 p-4 bg-gray-50 rounded">
          <input type="hidden" name="sessionId" value={sessionId} />
          <div>
            <label className="block text-sm font-medium mb-1">Upload Image</label>
            <input type="file" name="image" accept="image/*" required className="w-full" />
          </div>
          <button type="submit" disabled={pending} className="bg-blue-600 text-white px-4 py-2 rounded">
            {pending ? 'Analyzing...' : 'Analyze Image'}
          </button>
        </form>
      )}

      {/* Chat Interface */}
      {history.length > 0 && (
        <div className="space-y-4 max-h-96 overflow-y-auto border p-4 rounded">
          {history.map((msg, idx) => (
            <div key={idx} className={`p-2 rounded ${msg.role === 'user' ? 'bg-blue-100 text-right' : 'bg-gray-100 text-left'}`}>
              <p className="text-sm">{msg.text}</p>
            </div>
          ))}
          
          {pending && <div className="text-gray-500 italic">Thinking...</div>}

          <form action={formAction} onSubmit={handleAskQuestion} className="mt-4 flex gap-2">
            <input type="hidden" name="sessionId" value={sessionId} />
            <input 
              type="text" 
              name="question" 
              placeholder="Ask about the image..." 
              className="flex-1 border rounded p-2"
              disabled={pending}
            />
            <button type="submit" disabled={pending} className="bg-green-600 text-white px-4 py-2 rounded">
              Ask
            </button>
          </form>
        </div>
      )}
    </div>
  );
}
