/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

'use server';

import { generateImage } from '@ai-sdk/openai';
import { experimental_generateImage as generateImageCore } from 'ai';

/**
 * Generates an image using DALL-E 3 via the Vercel AI SDK.
 * 
 * @param prompt - The text description of the image to generate.
 * @returns An object containing the image URL or an error message.
 */
export async function generateImageAction(prompt: string) {
  try {
    // 1. Define the model. We are using DALL-E 3 via the OpenAI provider.
    // The 'dall-e-3' model is specified here.
    const model = openai.image('dall-e-3');

    // 2. Call the generateImage function.
    // This sends the request to OpenAI and awaits the response.
    const { image } = await generateImage({
      model: model,
      prompt: prompt,
      // Optional: DALL-E 3 supports specific sizes and qualities
      size: '1024x1024', 
      quality: 'standard',
    });

    // 3. Process the result.
    // The 'image' object contains the base64 data or URL provided by the SDK.
    // For this example, we assume the SDK returns a base64 string which we convert to a data URL.
    if (!image) {
      return { error: 'No image data received.' };
    }

    // Convert the Uint8Array (binary data) to a Base64 string for display in the browser
    const base64 = Buffer.from(image.uint8Array).toString('base64');
    const dataUrl = `data:image/png;base64,${base64}`;

    return { url: dataUrl };

  } catch (error) {
    // 4. Error Handling
    // Log the error server-side for debugging.
    console.error('Image generation error:', error);
    
    // Return a safe error message to the client.
    return { error: 'Failed to generate image. Please try again.' };
  }
}
