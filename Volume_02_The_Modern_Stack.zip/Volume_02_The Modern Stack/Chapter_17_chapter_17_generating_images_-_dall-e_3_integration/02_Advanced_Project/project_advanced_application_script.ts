/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// app/generate/page.tsx
// This is the main Server Component for the page. It imports the client component
// and passes necessary server-side data (like session info or feature flags).

import { Suspense } from 'react';
import ImageGeneratorClient from '@/components/ImageGeneratorClient';
import { generateImageAction } from '@/app/actions/generateImage';

export default function GeneratePage() {
  return (
    <main className="min-h-screen bg-gray-50 p-8">
      <div className="max-w-4xl mx-auto">
        <header className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900">Marketing Asset Studio</h1>
          <p className="text-gray-600 mt-2">
            Generate high-quality visuals for your campaigns using DALL-E 3.
          </p>
        </header>

        {/* 
          Suspense boundary isolates the interactive client component.
          While the AI processes the request, we show a fallback UI.
        */}
        <Suspense fallback={<div className="animate-pulse bg-white rounded-lg h-96 shadow-sm" />}>
          <ImageGeneratorClient generateAction={generateImageAction} />
        </Suspense>
      </div>
    </main>
  );
}
