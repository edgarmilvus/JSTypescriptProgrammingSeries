/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script_part2.ts
// Description: Advanced Application Script
// ==========================================

// components/ImageGeneratorClient.tsx
// This is the interactive Client Component (use client).
// It manages user input and consumes the streaming response from the Server Action.

'use client';

import { useState } from 'react';
import { useCompletion } from 'ai/react'; // Vercel AI SDK hook for text-to-text generation
// Note: For pure image generation, we often use a custom fetch wrapper or `useSWR` for polling.
// However, to strictly adhere to the "streaming status" requirement, we simulate the 
// streaming of text status updates (e.g., "Generating prompt...", "Rendering image...")
// while the actual image URL is resolved at the end of the stream.

// Define the shape of the action prop passed from the Server Component
type GenerateAction = (params: { prompt: string }) => Promise<ReadableStream>;

interface ImageGeneratorClientProps {
  generateAction: GenerateAction;
}

export default function ImageGeneratorClient({ generateAction }: ImageGeneratorClientProps) {
  const [prompt, setPrompt] = useState('');
  const [imageUrl, setImageUrl] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  // We use a custom handler to bridge the Server Action stream with local state.
  // The Vercel AI SDK's `useCompletion` is great for text, but here we need 
  // to parse a stream that might contain JSON objects (status updates) and a final URL.
  const handleGenerate = async () => {
    if (!prompt.trim()) return;

    setError(null);
    setImageUrl(null);

    try {
      // 1. Invoke the Server Action
      const stream = await generateAction({ prompt });

      // 2. Process the ReadableStream
      const reader = stream.getReader();
      const decoder = new TextDecoder();
      let done = false;

      while (!done) {
        const { value, done: streamDone } = await reader.read();
        done = streamDone;

        if (value) {
          const chunk = decoder.decode(value, { stream: true });
          
          // In a real app, we might parse NDJSON (Newline Delimited JSON).
          // For this demo, we assume the stream sends status messages followed by the final URL.
          // We'll just append text to a temporary log or update state if it's JSON.
          
          try {
            // Attempt to parse as JSON (simulating the final payload)
            const parsed = JSON.parse(chunk);
            if (parsed.type === 'image_url' && parsed.url) {
              setImageUrl(parsed.url);
            }
          } catch {
            // If it's not JSON, it's a status update text.
            // We could update a "status" state here (e.g., "Optimizing prompt...").
            console.log('Status:', chunk);
          }
        }
      }
    } catch (err) {
      setError('Failed to generate image. Please try again.');
      console.error(err);
    }
  };

  return (
    <div className="bg-white rounded-xl shadow-lg overflow-hidden border border-gray-200">
      <div className="p-6 space-y-4">
        {/* Input Section */}
        <div className="flex gap-4">
          <input
            type="text"
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            placeholder="Describe your visual (e.g., 'A cyberpunk coffee shop')"
            className="flex-1 rounded-lg border-gray-300 border px-4 py-2 focus:ring-2 focus:ring-blue-500 focus:outline-none"
          />
          <button
            onClick={handleGenerate}
            disabled={!prompt}
            className="bg-blue-600 text-white px-6 py-2 rounded-lg font-medium hover:bg-blue-700 disabled:opacity-50 transition-colors"
          >
            Generate
          </button>
        </div>

        {/* Error State */}
        {error && <div className="text-red-500 bg-red-50 p-3 rounded-md text-sm">{error}</div>}

        {/* Result Section */}
        <div className="min-h-[300px] bg-gray-50 rounded-lg border border-dashed border-gray-300 flex items-center justify-center relative">
          {imageUrl ? (
            <img 
              src={imageUrl} 
              alt="Generated AI Visual" 
              className="max-h-[400px] rounded shadow-md object-contain"
            />
          ) : (
            <div className="text-gray-400 text-center">
              <p>Image will appear here</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
