/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script_part3.ts
// Description: Advanced Application Script
// ==========================================

// app/actions/generateImage.ts
// Server Actions (Server Components) run only on the server.
// This is where we securely call the OpenAI API using the Vercel AI SDK.

'use server';

import { generateText } from 'ai'; // Using generateText to simulate the tool-calling loop
import { openai } from '@ai-sdk/openai';
import { z } from 'zod';

/**
 * Server Action to handle image generation logic.
 * 
 * Why use `generateText` here instead of `generateImage` directly?
 * In an advanced application, we often want to refine the user's raw prompt 
 * before sending it to DALL-E (e.g., adding "highly detailed, 8k, cinematic" 
 * to improve output). We use an LLM (GPT-4) as a "Prompt Refiner" tool.
 * 
 * Architecture:
 * 1. Receive raw prompt.
 * 2. Call LLM with a tool to refine the prompt.
 * 3. Receive refined prompt.
 * 4. Call DALL-E 3 (via OpenAI SDK) to generate the image.
 * 5. Stream the status back to the client.
 */
export async function generateImageAction(input: { prompt: string }) {
  const { prompt } = input;

  // 1. Create a TransformStream to pipe data back to the client
  const encoder = new TextEncoder();
  const stream = new TransformStream();
  const writer = stream.writable.getWriter();

  // 2. Define the tool for prompt refinement (ReAct pattern simulation)
  const refinePromptTool = {
    description: 'Refines a user prompt for DALL-E 3 image generation',
    parameters: z.object({
      refinedPrompt: z.string().describe('The improved, detailed prompt'),
    }),
    execute: async (args: { refinedPrompt: string }) => {
      // Write status update to the stream
      await writer.write(
        encoder.encode(`[STATUS] Prompt refined. Generating image...`)
      );
      return args.refinedPrompt;
    },
  };

  // 3. Execute the AI generation with the tool
  // Note: In a real production app, we might run this in a background job (e.g., Vercel Background Functions)
  // to avoid blocking the request for 30-60 seconds.
  const { text: refinedPrompt } = await generateText({
    model: openai('gpt-4o'),
    prompt: `Refine this prompt for DALL-E 3: "${prompt}". Make it descriptive and artistic.`,
    tools: {
      refine: refinePromptTool,
    },
    maxSteps: 1, // We only want one step: refine and execute
  });

  // 4. Call DALL-E 3
  // We use the raw OpenAI SDK here because the Vercel AI SDK's `generateImage` 
  // returns a single image buffer, but we need a URL to stream to the client.
  const openaiClient = new OpenAI({
    apiKey: process.env.OPENAI_API_KEY,
  });

  try {
    const response = await openaiClient.images.generate({
      model: 'dall-e-3',
      prompt: refinedPrompt || prompt, // Fallback to original if refinement failed
      n: 1,
      size: '1024x1024',
      quality: 'standard',
      response_format: 'url', // Crucial: Request a URL, not a b64json
    });

    const imageUrl = response.data[0].url;

    // 5. Stream the final result (JSON payload)
    // The client parses this to display the image.
    const resultPayload = JSON.stringify({
      type: 'image_url',
      url: imageUrl,
      promptUsed: refinedPrompt,
    });

    await writer.write(encoder.encode(resultPayload));
  } catch (err) {
    const errorPayload = JSON.stringify({
      type: 'error',
      message: 'DALL-E API call failed',
    });
    await writer.write(encoder.encode(errorPayload));
  } finally {
    await writer.close();
  }

  // 6. Return the readable stream to the client
  return stream.readable;
}
