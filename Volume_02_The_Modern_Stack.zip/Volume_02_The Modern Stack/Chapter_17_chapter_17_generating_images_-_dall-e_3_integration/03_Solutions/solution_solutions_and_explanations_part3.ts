/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

// app/api/generate-image/route.ts
import { generateText } from '@ai-sdk/core';
import { openai } from '@ai-sdk/openai';
import { generateDalleImageTool } from '@/tools/imageGenerator';
import { NextResponse } from 'next/server';

export async function POST(req: Request) {
  try {
    // 1. Parse the request body to get the prompt
    const { prompt } = await req.json();

    if (!prompt) {
      return NextResponse.json(
        { error: 'Prompt is required' },
        { status: 400 }
      );
    }

    // 2. Call generateText with the model, prompt, and tools
    // Note: We use generateText because we want the tool result to be the final output.
    // The LLM (GPT-4) acts as a router to invoke our specific image tool.
    const result = await generateText({
      model: openai('gpt-4-turbo-preview'),
      prompt: prompt,
      tools: {
        generateDalleImage: generateDalleImageTool,
      },
      // Optional: Force the model to use the tool if the prompt implies image generation
      // maxSteps: 1, 
    });

    // 3. Return the response
    // The result object contains text and toolResults. 
    // For useCompletion, we need to return the string content.
    // Since our tool returns the URL string, we extract it from the toolResults.
    if (result.toolResults && result.toolResults.length > 0) {
      const imageUrl = result.toolResults[0].result;
      
      // Return the URL as plain text so useCompletion can stream it
      return new Response(imageUrl, {
        headers: { 'Content-Type': 'text/plain' },
      });
    }

    // Fallback if no tool was called (should not happen with proper prompting)
    return new Response(result.text, {
      headers: { 'Content-Type': 'text/plain' },
    });

  } catch (error) {
    // 4. Error Handling
    console.error('API Route Error:', error);
    return NextResponse.json(
      { error: 'Internal Server Error' },
      { status: 500 }
    );
  }
}
