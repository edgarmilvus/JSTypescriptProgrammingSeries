/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

import { generateText } from '@ai-sdk/core';
import { openai } from '@ai-sdk/openai';
import { generateDalleImageTool } from '@/tools/imageGenerator';
import { NextResponse } from 'next/server';

export async function POST(req: Request) {
  try {
    // Parse the request body to get both prompt and style
    const { prompt, style } = await req.json();

    if (!prompt || !style) {
      return NextResponse.json({ error: 'Missing prompt or style' }, { status: 400 });
    }

    const result = await generateText({
      model: openai('gpt-4-turbo-preview'),
      // We pass the structured input directly to the prompt context
      prompt: `Generate an image with prompt: "${prompt}" and style: "${style}"`,
      tools: {
        generateDalleImage: generateDalleImageTool,
      },
    });

    if (result.toolResults && result.toolResults.length > 0) {
      const imageUrl = result.toolResults[0].result;
      return new Response(imageUrl, { headers: { 'Content-Type': 'text/plain' } });
    }

    return new Response(result.text || 'No image generated', { headers: { 'Content-Type': 'text/plain' } });

  } catch (error) {
    console.error('API Error:', error);
    return NextResponse.json({ error: 'Internal Server Error' }, { status: 500 });
  }
}
