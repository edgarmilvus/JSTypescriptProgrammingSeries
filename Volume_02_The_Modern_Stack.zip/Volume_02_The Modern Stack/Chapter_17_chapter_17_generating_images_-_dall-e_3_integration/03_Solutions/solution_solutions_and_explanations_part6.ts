/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part6.ts
// Description: Solutions and Explanations
// ==========================================

'use client';

import { useCompletion } from '@ai-sdk/react';
import { useState } from 'react';

// Define the available styles
const STYLES = ['watercolor', 'cyberpunk', 'oil_painting'] as const;

export default function ImageGenerator() {
  const [selectedStyle, setSelectedStyle] = useState<string>(STYLES[0]);
  
  const {
    completion,
    input,
    handleInputChange,
    handleSubmit,
    isLoading,
    error,
  } = useCompletion({
    api: '/api/generate-image',
  });

  // Custom submit handler to include the style in the request
  const onSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    
    // Log the final prompt construction for debugging
    const finalPrompt = `${input}, ${selectedStyle} style`;
    console.log('Sending to server:', { prompt: input, style: selectedStyle, finalPrompt });

    // We need to send the body manually via the 'body' option in handleSubmit
    // or use a custom fetch. The useCompletion hook supports passing body data.
    handleSubmit(e, {
      body: {
        prompt: input,
        style: selectedStyle,
      },
    });
  };

  return (
    <div className="w-full max-w-md p-6 bg-white rounded-lg shadow-md">
      <h2 className="text-xl font-bold mb-4 text-gray-800">Style Transfer Generator</h2>
      
      {error && (
        <div className="mb-4 p-3 bg-red-100 text-red-700 rounded">
          Error: {error.message}
        </div>
      )}

      {/* Style Selection */}
      <div className="mb-4">
        <label className="block text-sm font-medium mb-2">Select Style:</label>
        <div className="flex gap-2">
          {STYLES.map((style) => (
            <button
              key={style}
              type="button"
              onClick={() => setSelectedStyle(style)}
              className={`px-3 py-1 rounded border ${
                selectedStyle === style
                  ? 'bg-blue-600 text-white border-blue-600'
                  : 'bg-gray-100 text-gray-700 border-gray-300 hover:bg-gray-200'
              }`}
            >
              {style}
            </button>
          ))}
        </div>
      </div>

      {/* Input Form */}
      <form onSubmit={onSubmit} className="flex flex-col gap-4">
        <input
          type="text"
          value={input}
          onChange={handleInputChange}
          placeholder="Describe the subject (e.g., 'A cat on a bench')..."
          className="p-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
          disabled={isLoading}
        />
        
        <button
          type="submit"
          disabled={isLoading || !input.trim()}
          className="p-2 bg-blue-600 text-white rounded hover:bg-blue-700 disabled:bg-gray-400 transition-colors"
        >
          {isLoading ? 'Generating...' : 'Generate Image'}
        </button>
      </form>

      {isLoading && (
        <div className="mt-4 flex items-center justify-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
        </div>
      )}

      {completion && !isLoading && (
        <div className="mt-6">
          <h3 className="font-semibold mb-2">Result ({selectedStyle}):</h3>
          <img 
            src={completion} 
            alt="Generated from prompt" 
            className="w-full rounded shadow-sm"
          />
        </div>
      )}
    </div>
  );
}
