/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.tsx
// Description: Basic Code Example
// ==========================================

// app/page.tsx
'use client';

import React, { useState, useRef } from 'react';

// Define the structure of the MediaRecorder API (standard browser API)
interface MediaRecorderEvent extends Event {
  data: Blob;
}

export default function VoiceInput() {
  // State to manage recording status
  const [isRecording, setIsRecording] = useState<boolean>(false);
  // State to hold the transcribed text from the server
  const [transcription, setTranscription] = useState<string>('');
  // State to display loading indicators
  const [isLoading, setIsLoading] = useState<boolean>(false);

  // Ref to hold the MediaRecorder instance
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  // Ref to hold audio chunks
  const chunksRef = useRef<Blob[]>([]);

  /**
   * Starts the microphone recording process.
   */
  const startRecording = async () => {
    try {
      // 1. Request permission to use the microphone
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      
      // 2. Initialize MediaRecorder with the audio stream
      // We use 'audio/webm' or 'audio/ogg' as these are widely supported and accepted by Whisper
      mediaRecorderRef.current = new MediaRecorder(stream, {
        mimeType: 'audio/webm;codecs=opus',
      });

      // 3. Clear previous chunks and reset state
      chunksRef.current = [];
      setIsRecording(true);
      setTranscription('');

      // 4. Listen for data availability events
      mediaRecorderRef.current.ondataavailable = (event: any) => {
        if (event.data.size > 0) {
          chunksRef.current.push(event.data);
        }
      };

      // 5. Listen for the 'stop' event to process the audio
      mediaRecorderRef.current.onstop = async () => {
        await processAudio();
      };

      // 6. Start recording
      mediaRecorderRef.current.start();

    } catch (err) {
      console.error('Error accessing microphone:', err);
      alert('Could not access microphone. Please check permissions.');
    }
  };

  /**
   * Stops the recording and triggers the processing logic.
   */
  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
      
      // Stop all tracks to release the microphone
      mediaRecorderRef.current.stream.getTracks().forEach(track => track.stop());
    }
  };

  /**
   * Aggregates chunks, creates a Blob, and sends to API.
   */
  const processAudio = async () => {
    if (chunksRef.current.length === 0) return;

    setIsLoading(true);

    // 1. Create a Blob from the audio chunks
    const audioBlob = new Blob(chunksRef.current, { type: 'audio/webm' });
    
    // 2. Create a FormData object to send the file
    const formData = new FormData();
    // The key 'audio' must match what the server expects
    formData.append('audio', audioBlob, 'recording.webm');

    try {
      // 3. Send the POST request to our API Route
      const response = await fetch('/api/transcribe', {
        method: 'POST',
        body: formData,
      });

      if (!response.ok) throw new Error('API Request failed');

      // 4. Parse the JSON response
      const data = await response.json();
      
      // 5. Update the UI with the transcription
      setTranscription(data.text);
    } catch (error) {
      console.error('Error processing audio:', error);
      setTranscription('Error processing audio. Please try again.');
    } finally {
      setIsLoading(false);
      // Clean up refs if necessary
      chunksRef.current = [];
    }
  };

  return (
    <div style={{ padding: '2rem', fontFamily: 'sans-serif' }}>
      <h1>Voice AI Transcriber</h1>
      
      <div style={{ margin: '1rem 0' }}>
        {!isRecording ? (
          <button 
            onClick={startRecording} 
            disabled={isLoading}
            style={{ padding: '10px 20px', backgroundColor: 'green', color: 'white', border: 'none', borderRadius: '5px', cursor: 'pointer' }}
          >
            {isLoading ? 'Processing...' : 'Start Recording'}
          </button>
        ) : (
          <button 
            onClick={stopRecording}
            style={{ padding: '10px 20px', backgroundColor: 'red', color: 'white', border: 'none', borderRadius: '5px', cursor: 'pointer' }}
          >
            Stop Recording
          </button>
        )}
      </div>

      {isRecording && (
        <p style={{ color: 'red', fontWeight: 'bold' }}>🔴 Recording...</p>
      )}

      {transcription && (
        <div style={{ marginTop: '1rem', padding: '1rem', backgroundColor: '#f0f0f0', borderRadius: '5px' }}>
          <h3>Transcription:</h3>
          <p>{transcription}</p>
        </div>
      )}
    </div>
  );
}
