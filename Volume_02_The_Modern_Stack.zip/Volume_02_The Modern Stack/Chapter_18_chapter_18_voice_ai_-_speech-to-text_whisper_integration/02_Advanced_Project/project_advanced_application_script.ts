/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// app/api/voice-chat/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { OpenAI } from 'openai';
import { OpenAIStream, StreamingTextResponse } from 'ai';
import { z } from 'zod';

// ============================================================================
// 1. CONFIGURATION & INITIALIZATION
// ============================================================================

/**
 * Initialize the OpenAI client.
 * In a production SaaS environment, ensure the API key is stored in environment
 * variables (process.env.OPENAI_API_KEY) and rotated regularly.
 */
const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

// ============================================================================
// 2. SCHEMA DEFINITION & SYSTEM PROMPT
// ============================================================================

/**
 * Define the expected structure of the generative UI response.
 * We use Zod for runtime type validation to ensure the LLM outputs
 * structured data compatible with our frontend components.
 */
const UiSchema = z.object({
  action: z.enum(['create_ticket', 'summarize_text', 'unknown']),
  content: z.string().describe('The actionable text or summary for the UI'),
  priority: z.enum(['low', 'high']).optional(),
});

/**
 * The System Prompt acts as the instruction set for the LLM.
 * It defines the persona (Voice Assistant), constraints (JSON output),
 * and the specific UI schema the model must adhere to.
 */
const SYSTEM_PROMPT = `
You are a voice-activated assistant for a SaaS project management dashboard.
The user has spoken a command. Your task is to transcribe the intent and format it as a UI action.

Rules:
1. Analyze the transcribed text.
2. Determine if the user wants to create a ticket, summarize a note, or if the intent is unclear.
3. Output strictly valid JSON matching the following schema:
{
  "action": "create_ticket" | "summarize_text" | "unknown",
  "content": "string",
  "priority": "low" | "high" | null
}

Examples:
- Input: "Create a high priority ticket to fix the login bug."
- Output: { "action": "create_ticket", "content": "Fix the login bug", "priority": "high" }

- Input: "Summarize the meeting notes from yesterday."
- Output: { "action": "summarize_text", "content": "Summarize meeting notes from yesterday", "priority": null }
`;

// ============================================================================
// 3. SERVER COMPONENT LOGIC
// ============================================================================

/**
 * Handles the incoming POST request containing audio data.
 * 
 * @param req - The Next.js Request object containing the audio Blob.
 * @returns A StreamingTextResponse allowing the client to consume the LLM response in real-time.
 */
export async function POST(req: NextRequest) {
  try {
    // 1. Extract Audio Data
    // In a real-world scenario, the client sends a Blob or File.
    // We convert this to a ReadableStream for efficient handling.
    const formData = await req.formData();
    const audioFile = formData.get('audio') as Blob;

    if (!audioFile) {
      return NextResponse.json(
        { error: 'No audio file provided' },
        { status: 400 }
      );
    }

    // 2. Speech-to-Text (Whisper Integration)
    // We stream the audio directly to OpenAI's Whisper API.
    // 'language' hint improves accuracy; 'response_format' is set to 'text' or 'json'.
    const transcription = await openai.audio.transcriptions.create({
      file: audioFile,
      model: 'whisper-1',
      language: 'en',
      response_format: 'text', // We only need the raw text string for the next step
    });

    // Handle empty transcription
    if (!transcription || transcription.trim().length === 0) {
      return NextResponse.json(
        { error: 'Audio could not be transcribed' },
        { status: 422 }
      );
    }

    // 3. Generative UI (LLM Integration)
    // We pass the transcribed text to GPT-4, instructing it to return structured JSON.
    // We use the Vercel AI SDK's `OpenAIStream` to handle token streaming.
    const response = await openai.chat.completions.create({
      model: 'gpt-4-turbo-preview',
      stream: true,
      messages: [
        { role: 'system', content: SYSTEM_PROMPT },
        { role: 'user', content: transcription },
      ],
      // We instruct the model to output JSON format explicitly
      response_format: { type: 'json_object' },
    });

    const stream = OpenAIStream(response, {
      // 4. Stream Processing
      // We can optionally parse the stream here, but for maximum flexibility,
      // we stream the raw JSON string to the client and parse it there.
      // This keeps the server lightweight and stateless.
    });

    // 5. Return Stream
    // The client (using Vercel AI SDK's `useChat` hook) will consume this stream.
    return new StreamingTextResponse(stream);

  } catch (error) {
    console.error('Voice Chat API Error:', error);
    return NextResponse.json(
      { error: 'Internal Server Error' },
      { status: 500 }
    );
  }
}
