/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.tsx
// Description: Solutions and Explanations
// ==========================================

// File: components/VoiceRecorder.tsx
'use client';

import React, { useState, useRef, useEffect, useCallback } from 'react';

interface VoiceRecorderProps {
  // Callback to expose audio chunks to parent
  onAudioChunks?: (chunks: Blob[]) => void;
  // Callback to expose the final combined blob
  onRecordingComplete?: (blob: Blob) => void;
}

type RecordingState = 'idle' | 'recording' | 'processing';

const VoiceRecorder: React.FC<VoiceRecorderProps> = ({ onAudioChunks, onRecordingComplete }) => {
  const [recordingState, setRecordingState] = useState<RecordingState>('idle');
  const [error, setError] = useState<string | null>(null);
  const [volume, setVolume] = useState<number>(0); // For waveform visualization

  // Refs for MediaRecorder and AudioContext to manage lifecycles
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const streamRef = useRef<MediaStream | null>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const analyserRef = useRef<AnalyserNode | null>(null);
  const animationFrameRef = useRef<number>();

  // Cleanup function to stop tracks and close audio context
  const cleanup = useCallback(() => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((track) => track.stop());
      streamRef.current = null;
    }
    if (audioContextRef.current) {
      audioContextRef.current.close();
      audioContextRef.current = null;
    }
    if (animationFrameRef.current) {
      cancelAnimationFrame(animationFrameRef.current);
    }
    mediaRecorderRef.current = null;
    setVolume(0);
  }, []);

  // Visualize Audio Amplitude
  const visualize = useCallback(() => {
    if (!analyserRef.current) return;

    const analyser = analyserRef.current;
    const bufferLength = analyser.frequencyBinCount;
    const dataArray = new Uint8Array(bufferLength);

    const draw = () => {
      analyser.getByteFrequencyData(dataArray);
      
      // Calculate average volume
      let sum = 0;
      for (let i = 0; i < bufferLength; i++) {
        sum += dataArray[i];
      }
      const average = sum / bufferLength;
      
      // Normalize volume to 0-100 for UI display
      setVolume(Math.min(100, Math.max(0, average)));

      if (recordingState === 'recording') {
        animationFrameRef.current = requestAnimationFrame(draw);
      }
    };
    draw();
  }, [recordingState]);

  const startRecording = async () => {
    setError(null);
    try {
      // 1. Request Microphone Access
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      streamRef.current = stream;

      // 2. Setup Web Audio API for Visualization
      const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
      audioContextRef.current = audioContext;
      const source = audioContext.createMediaStreamSource(stream);
      const analyser = audioContext.createAnalyser();
      analyser.fftSize = 256;
      source.connect(analyser);
      analyserRef.current = analyser;

      // 3. Setup MediaRecorder
      const mediaRecorder = new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;
      audioChunksRef.current = []; // Reset chunks

      mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          audioChunksRef.current.push(event.data);
          // Optional: Send chunks live if needed
          // onAudioChunks?.([...audioChunksRef.current]);
        }
      };

      mediaRecorder.onstop = () => {
        const blob = new Blob(audioChunksRef.current, { type: 'audio/webm' });
        onRecordingComplete?.(blob);
        onAudioChunks?.(audioChunksRef.current);
        cleanup();
        setRecordingState('processing'); // Briefly processing before idle
        setTimeout(() => setRecordingState('idle'), 500);
      };

      // Start recording every 1000ms (1 second chunks)
      mediaRecorder.start(1000);
      setRecordingState('recording');
      visualize();

    } catch (err: any) {
      console.error("Error accessing microphone:", err);
      if (err.name === 'NotAllowedError') {
        setError('Microphone access denied. Please check your browser permissions.');
      } else if (err.name === 'NotFoundError') {
        setError('No microphone found. Please connect a microphone.');
      } else {
        setError(`Error: ${err.message}`);
      }
      cleanup();
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && recordingState === 'recording') {
      mediaRecorderRef.current.stop();
    }
  };

  // Ensure cleanup on unmount
  useEffect(() => {
    return () => {
      cleanup();
    };
  }, [cleanup]);

  return (
    <div style={{ padding: '20px', border: '1px solid #ccc', borderRadius: '8px', maxWidth: '400px' }}>
      <h3>Voice Recorder</h3>
      
      {/* Visualization */}
      <div style={{ height: '50px', background: '#f0f0f0', marginBottom: '10px', display: 'flex', alignItems: 'flex-end' }}>
        <div 
          style={{ 
            width: '100%', 
            height: `${volume}%`, 
            background: recordingState === 'recording' ? '#4caf50' : '#ddd', 
            transition: 'height 0.1s' 
          }} 
        />
      </div>
      <div style={{ fontSize: '12px', color: '#666' }}>Volume: {Math.round(volume)}%</div>

      {/* Controls */}
      <div style={{ marginTop: '15px', display: 'flex', gap: '10px' }}>
        {recordingState === 'idle' ? (
          <button onClick={startRecording} style={{ padding: '10px 20px', background: '#2196F3', color: 'white', border: 'none', borderRadius: '4px' }}>
            Start Recording
          </button>
        ) : (
          <button onClick={stopRecording} disabled={recordingState !== 'recording'} style={{ padding: '10px 20px', background: '#f44336', color: 'white', border: 'none', borderRadius: '4px' }}>
            Stop Recording
          </button>
        )}
      </div>

      {/* Status & Errors */}
      <div style={{ marginTop: '10px', minHeight: '20px' }}>
        {recordingState === 'recording' && <span style={{ color: '#4caf50' }}>🔴 Recording...</span>}
        {recordingState === 'processing' && <span style={{ color: '#ff9800' }}>Processing audio...</span>}
        {error && <span style={{ color: '#f44336' }}>{error}</span>}
      </div>
    </div>
  );
};

export default VoiceRecorder;
