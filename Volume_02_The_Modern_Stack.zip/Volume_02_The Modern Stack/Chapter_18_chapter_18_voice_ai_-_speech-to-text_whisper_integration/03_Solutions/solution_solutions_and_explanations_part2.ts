/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

// File: app/actions/transcribe.ts
'use server';

import { z } from 'zod';

// Define the expected response structure from OpenAI
interface WhisperResponse {
  text: string;
}

// Define the input schema using Zod for validation
const transcribeSchema = z.object({
  audioFile: z.instanceof(Blob).refine((blob) => blob.size > 0, {
    message: "Audio file is empty.",
  }),
});

/**
 * Server Action to transcribe audio using OpenAI Whisper API.
 * @param formData - FormData containing the audio file under the key 'audio_file'.
 * @returns The transcribed text or an error object.
 */
export async function transcribeAudio(formData: FormData) {
  try {
    // 1. Extract and Validate File
    const file = formData.get('audio_file') as File | null;
    if (!file || file.size === 0) {
      return { error: 'No audio file provided or file is empty.' };
    }

    // 2. Prepare Request Payload
    // Note: We create a new FormData instance for the OpenAI API request
    const openAiFormData = new FormData();
    openAiFormData.append('file', file);
    openAiFormData.append('model', 'whisper-1');
    // Optional: Add prompt or response_format if needed
    // openAiFormData.append('response_format', 'json');

    // 3. Check for API Key
    const apiKey = process.env.OPENAI_API_KEY;
    if (!apiKey) {
      console.error('OPENAI_API_KEY is not set');
      return { error: 'Server configuration error: API key missing.' };
    }

    // 4. Call OpenAI API
    const response = await fetch('https://api.openai.com/v1/audio/transcriptions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${apiKey}`,
        // Do NOT set Content-Type header manually; fetch sets it automatically with the boundary
      },
      body: openAiFormData,
    });

    // 5. Handle Response
    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}));
      console.error('OpenAI API Error:', errorData);
      return { 
        error: `Transcription failed: ${errorData.error?.message || response.statusText}` 
      };
    }

    const data = (await response.json()) as WhisperResponse;
    
    // Validate response structure (optional but recommended)
    if (!data.text) {
        return { error: 'Invalid response from transcription service.' };
    }

    return { text: data.text };

  } catch (error) {
    console.error('Server Action Error:', error);
    return { error: 'An unexpected error occurred during transcription.' };
  }
}
