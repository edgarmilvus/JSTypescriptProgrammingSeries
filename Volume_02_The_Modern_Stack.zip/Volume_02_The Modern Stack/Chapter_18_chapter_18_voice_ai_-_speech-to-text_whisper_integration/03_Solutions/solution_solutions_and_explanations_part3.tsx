/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

// File: components/VoiceChatInterface.tsx
'use client';

import React, { useState, useCallback } from 'react';
import { useChat } from 'ai/react';
import VoiceRecorder from './VoiceRecorder'; // From Exercise 1
import { transcribeAudio } from '@/app/actions/transcribe'; // From Exercise 2

interface VoiceChatInterfaceProps {
  systemContext?: string; // Passed from Server Component
}

type ChatState = 'idle' | 'recording' | 'transcribing' | 'generating';

const VoiceChatInterface: React.FC<VoiceChatInterfaceProps> = ({ systemContext }) => {
  const [chatState, setChatState] = useState<ChatState>('idle');
  const [transcribedText, setTranscribedText] = useState('');
  
  // Vercel AI SDK hook
  const { messages, append, isLoading, error: chatError } = useChat({
    // Optionally inject system context via initialMessages or api options
    initialMessages: systemContext ? [{ role: 'system', content: systemContext }] : [],
  });

  // Handle recording completion
  const handleRecordingComplete = useCallback(async (blob: Blob) => {
    setChatState('transcribing');
    
    // 1. Prepare FormData for Server Action
    const formData = new FormData();
    // Convert Blob to File for proper filename/mime handling if needed, or just append blob
    const file = new File([blob], 'recording.webm', { type: 'audio/webm' });
    formData.append('audio_file', file);

    try {
      // 2. Call Server Action
      const result = await transcribeAudio(formData);

      if (result.error) {
        console.error(result.error);
        setChatState('idle');
        return; // Handle error in UI (omitted for brevity)
      }

      if (result.text) {
        setTranscribedText(result.text);
        setChatState('generating');

        // 3. Send transcribed text to AI
        await append({
          role: 'user',
          content: result.text,
        });

        setChatState('idle');
      }
    } catch (err) {
      console.error("Pipeline failed:", err);
      setChatState('idle');
    }
  }, [append]);

  return (
    <div style={{ maxWidth: '600px', margin: '0 auto', padding: '20px' }}>
      {/* Chat History Display */}
      <div style={{ marginBottom: '20px', border: '1px solid #eee', padding: '10px', height: '300px', overflowY: 'auto' }}>
        {messages.map((m, index) => (
          <div key={index} style={{ marginBottom: '8px', textAlign: m.role === 'user' ? 'right' : 'left' }}>
            <strong style={{ display: 'block', fontSize: '0.8em', color: '#666' }}>
              {m.role === 'user' ? 'You' : 'AI'}
            </strong>
            <span 
              style={{ 
                display: 'inline-block', 
                padding: '8px 12px', 
                borderRadius: '12px', 
                background: m.role === 'user' ? '#007bff' : '#f1f1f1', 
                color: m.role === 'user' ? 'white' : 'black',
                maxWidth: '80%'
              }}
            >
              {m.content}
            </span>
          </div>
        ))}
        {/* Live Transcription Preview (Optimistic UI) */}
        {chatState === 'transcribing' && (
           <div style={{ textAlign: 'right', marginBottom: '8px' }}>
             <strong style={{ display: 'block', fontSize: '0.8em', color: '#666' }}>You</strong>
             <span style={{ display: 'inline-block', padding: '8px 12px', borderRadius: '12px', background: '#e0f0ff', color: '#555', fontStyle: 'italic' }}>
               Listening...
             </span>
           </div>
        )}
        {chatState === 'generating' && isLoading && (
           <div style={{ textAlign: 'left', marginBottom: '8px' }}>
             <strong style={{ display: 'block', fontSize: '0.8em', color: '#666' }}>AI</strong>
             <span style={{ display: 'inline-block', padding: '8px 12px', borderRadius: '12px', background: '#f1f1f1' }}>
               Typing...
             </span>
           </div>
        )}
      </div>

      {/* Status Indicator */}
      <div style={{ marginBottom: '10px', minHeight: '20px', fontWeight: 'bold' }}>
        {chatState === 'recording' && '🔴 Recording...'}
        {chatState === 'transcribing' && '🔄 Transcribing...'}
        {chatState === 'generating' && '✨ Generating response...'}
        {chatError && <span style={{ color: 'red' }}>Error: {chatError.message}</span>}
      </div>

      {/* Voice Recorder Component */}
      <VoiceRecorder 
        onRecordingComplete={handleRecordingComplete}
      />
    </div>
  );
};

export default VoiceChatInterface;
