/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.tsx
// Description: Solutions and Explanations
// ==========================================

// File: components/ResilientVoiceInterface.tsx
'use client';

import React, { useState, useCallback, useReducer } from 'react';
import { useChat } from 'ai/react';
import VoiceRecorder from './VoiceRecorder';
import { transcribeAudio } from '@/app/actions/transcribe';

// --- 1. State Machine Definition ---
type State = 'IDLE' | 'RECORDING' | 'TRANSCRIBING' | 'GENERATING' | 'ERROR';
type Action = 
  | { type: 'START_RECORDING' } 
  | { type: 'STOP_RECORDING' } 
  | { type: 'START_TRANSCRIBING' } 
  | { type: 'START_GENERATING' } 
  | { type: 'SUCCESS' } 
  | { type: 'FAIL'; error: string };

const initialState: { state: State; error: string | null; lastAudioBlob: Blob | null } = {
  state: 'IDLE',
  error: null,
  lastAudioBlob: null,
};

function reducer(state: typeof initialState, action: Action): typeof initialState {
  switch (action.type) {
    case 'START_RECORDING':
      return { ...state, state: 'RECORDING', error: null };
    case 'STOP_RECORDING':
      return { ...state, state: 'TRANSCRIBING' }; // Immediately move to transcribing
    case 'START_TRANSCRIBING':
      return { ...state, state: 'TRANSCRIBING', error: null };
    case 'START_GENERATING':
      return { ...state, state: 'GENERATING', error: null };
    case 'SUCCESS':
      return { ...state, state: 'IDLE', error: null, lastAudioBlob: null };
    case 'FAIL':
      return { ...state, state: 'ERROR', error: action.error };
    default:
      return state;
  }
}

// --- 2. Error Boundary Component ---
class ErrorBoundary extends React.Component<{ children: React.ReactNode }, { hasError: boolean; error: string | null }> {
  constructor(props: { children: React.ReactNode }) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error: Error) {
    return { hasError: true, error: error.message };
  }

  componentDidCatch(error: Error, errorInfo: React.ErrorInfo) {
    console.log("Caught by Error Boundary:", error, errorInfo);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div style={{ padding: '20px', border: '1px solid red', background: '#ffe6e6' }}>
          <h4>Something went wrong.</h4>
          <p>{this.state.error}</p>
          <button onClick={() => this.setState({ hasError: false, error: null })}>
            Try Recovering
          </button>
        </div>
      );
    }
    return this.props.children;
  }
}

// --- 3. Main Component ---
const ResilientVoiceInterface: React.FC = () => {
  const [localState, dispatch] = useReducer(reducer, initialState);
  const { messages, append, isLoading, error: chatError } = useChat();

  // Helper to handle retries
  const retryTranscription = useCallback(() => {
    if (localState.lastAudioBlob) {
      processAudio(localState.lastAudioBlob);
    }
  }, [localState.lastAudioBlob]);

  const processAudio = async (blob: Blob) => {
    dispatch({ type: 'START_TRANSCRIBING' });
    
    // Timeout Logic: Wrap the transcription in a Promise.race
    const timeoutPromise = new Promise<never>((_, reject) => 
      setTimeout(() => reject(new Error('Transcription timed out')), 15000)
    );

    try {
      const formData = new FormData();
      formData.append('audio_file', new File([blob], 'audio.webm', { type: 'audio/webm' }));

      // Race between API call and timeout
      const result = await Promise.race([
        transcribeAudio(formData),
        timeoutPromise
      ]) as { text?: string; error?: string };

      if (result.error) {
        dispatch({ type: 'FAIL', error: result.error });
        return;
      }

      if (result.text) {
        dispatch({ type: 'START_GENERATING' });
        await append({ role: 'user', content: result.text });
        dispatch({ type: 'SUCCESS' });
      }
    } catch (err: any) {
      dispatch({ type: 'FAIL', error: err.message || 'Unknown error' });
    }
  };

  const handleRecordingComplete = useCallback((blob: Blob) => {
    // Store blob for potential retries
    // Note: In a real app, we might store this in state, but for this example we pass it down
    // We'll rely on the reducer to hold the reference if we wanted to persist it across renders
    // For simplicity, we trigger processing immediately.
    processAudio(blob);
    dispatch({ type: 'STOP_RECORDING' });
  }, []);

  const renderUI = () => {
    switch (localState.state) {
      case 'IDLE':
        return <VoiceRecorder onRecordingComplete={handleRecordingComplete} />;
      
      case 'RECORDING':
        return (
          <div>
            <div style={{ color: 'red', fontWeight: 'bold' }}>🔴 Recording Active...</div>
            <VoiceRecorder onRecordingComplete={handleRecordingComplete} />
          </div>
        );

      case 'TRANSCRIBING':
        return (
          <div style={{ padding: '20px', textAlign: 'center' }}>
            <div className="spinner" style={{ border: '4px solid #f3f3f3', borderTop: '4px solid #3498db', borderRadius: '50%', width: '40px', height: '40px', animation: 'spin 1s linear infinite', margin: '0 auto' }}></div>
            <p>Converting speech to text...</p>
          </div>
        );

      case 'GENERATING':
        return (
          <div style={{ padding: '20px' }}>
            <p><em>AI is generating a response...</em></p>
            {/* Render existing messages to show context */}
            <div style={{ marginTop: '10px', opacity: 0.7 }}>
              {messages.slice(-1).map(m => <div key={m.id}>{m.role}: {m.content}</div>)}
            </div>
          </div>
        );

      case 'ERROR':
        return (
          <div style={{ padding: '20px', border: '1px solid #f44336', background: '#ffebee' }}>
            <h4>Error: {localState.error}</h4>
            {localState.error?.includes('timeout') || localState.error?.includes('Network') ? (
              <button onClick={retryTranscription}>Retry Last Action</button>
            ) : (
              <p>Please check microphone permissions or network connection.</p>
            )}
            <button onClick={() => dispatch({ type: 'SUCCESS' })} style={{ marginLeft: '10px' }}>Reset</button>
          </div>
        );
    }
  };

  return (
    <ErrorBoundary>
      <div style={{ maxWidth: '600px', margin: '20px auto', padding: '20px', border: '1px solid #ddd', borderRadius: '8px' }}>
        <h2>Voice AI Interface</h2>
        
        {/* Chat History */}
        <div style={{ marginBottom: '20px', minHeight: '100px', background: '#f9f9f9', padding: '10px' }}>
          {messages.filter(m => m.role !== 'system').map(m => (
            <div key={m.id} style={{ marginBottom: '5px' }}>
              <strong>{m.role === 'user' ? 'You' : 'AI'}: </strong>
              {m.content}
            </div>
          ))}
        </div>

        {/* Interactive Area */}
        <div style={{ minHeight: '100px' }}>
          {renderUI()}
        </div>
        
        {/* Global Error Display (from useChat) */}
        {chatError && (
          <div style={{ color: 'red', marginTop: '10px' }}>
            Chat Error: {chatError.message}
          </div>
        )}
      </div>
    </ErrorBoundary>
  );
};

export default ResilientVoiceInterface;
