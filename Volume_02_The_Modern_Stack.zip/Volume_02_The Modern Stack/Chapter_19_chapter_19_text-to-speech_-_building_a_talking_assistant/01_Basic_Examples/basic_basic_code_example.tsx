/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.tsx
// Description: Basic Code Example
// ==========================================

'use client';

import React, { useState, useEffect, useRef } from 'react';

// Define the shape of the streamable UI or text token
// In a real app, this comes from `@ai-sdk/react` or a custom stream parser.
type StreamToken = {
  type: 'text';
  content: string;
};

/**
 * TalkingAssistant Component
 * 
 * A client-side component that listens to a text stream and synthesizes
 * speech using the Web Speech API in real-time.
 */
export default function TalkingAssistant() {
  // State to hold the visual text output (for users who prefer reading)
  const [displayText, setDisplayText] = useState<string>('');
  
  // State to manage the speech synthesis status
  const [isSpeaking, setIsSpeaking] = useState<boolean>(false);
  
  // Ref to store the SpeechSynthesisUtterance to allow pausing/resuming
  const utteranceRef = useRef<SpeechSynthesisUtterance | null>(null);
  
  // Ref to store the accumulated text buffer to ensure continuity
  const textBufferRef = useRef<string>('');

  /**
   * Simulates a Server Action stream.
   * In a real app, this would be replaced by `useStreamableUI` or `useChat`.
   * We mock it here to make the example fully self-contained.
   */
  const simulateStream = async (): Promise<void> => {
    const mockTokens = [
      'Hello, ',
      'this is a ',
      'real-time ',
      'audio stream ',
      'from your Next.js app.',
      ' We are using ',
      'React Server Components ',
      'and the Web Speech API.'
    ];

    for (const token of mockTokens) {
      // Simulate network latency
      await new Promise(resolve => setTimeout(resolve, 300));
      
      // 1. Update Visual UI
      setDisplayText(prev => prev + token);
      
      // 2. Trigger Audio Synthesis
      speakText(token);
    }
  };

  /**
   * Handles Text-to-Speech synthesis using the Web Speech API.
   * @param text - The text string to speak.
   */
  const speakText = (text: string) => {
    // Check browser support
    if (!window || !window.speechSynthesis) {
      console.error('Web Speech API not supported in this browser.');
      return;
    }

    // Create a new utterance for the specific text token
    const utterance = new SpeechSynthesisUtterance(text);
    
    // Optional: Select a specific voice (e.g., English US)
    const voices = window.speechSynthesis.getVoices();
    const preferredVoice = voices.find(v => v.name.includes('Google US English') || v.lang === 'en-US');
    if (preferredVoice) utterance.voice = preferredVoice;

    // Configure utterance settings
    utterance.rate = 1.0; // Speed
    utterance.pitch = 1.0; // Tone
    utterance.volume = 1.0; // Volume

    // Event: When speech starts
    utterance.onstart = () => setIsSpeaking(true);
    
    // Event: When speech ends
    utterance.onend = () => {
      // Only set speaking to false if there are no more pending utterances
      if (window.speechSynthesis.pending === false && window.speechSynthesis.speaking === false) {
        setIsSpeaking(false);
      }
    };

    // CRITICAL: Queue the utterance.
    // The browser handles the queue automatically.
    window.speechSynthesis.speak(utterance);
  };

  /**
   * Pauses the audio playback.
   */
  const pauseSpeech = () => {
    if (window.speechSynthesis.speaking) {
      window.speechSynthesis.pause();
      setIsSpeaking(false);
    }
  };

  /**
   * Resumes the audio playback.
   */
  const resumeSpeech = () => {
    if (window.speechSynthesis.paused) {
      window.speechSynthesis.resume();
      setIsSpeaking(true);
    }
  };

  /**
   * Stops and clears the audio queue.
   */
  const stopSpeech = () => {
    window.speechSynthesis.cancel();
    setIsSpeaking(false);
  };

  // Clean up on unmount
  useEffect(() => {
    return () => {
      window.speechSynthesis.cancel();
    };
  }, []);

  return (
    <div style={{ padding: '20px', fontFamily: 'sans-serif', maxWidth: '600px', margin: '0 auto' }}>
      <h2>AI Talking Assistant</h2>
      
      {/* Visual Output Area */}
      <div style={{ 
        border: '1px solid #ddd', 
        padding: '15px', 
        minHeight: '100px', 
        marginBottom: '20px',
        borderRadius: '8px',
        backgroundColor: '#f9f9f9'
      }}>
        <p style={{ color: '#333', lineHeight: '1.6' }}>
          {displayText || <span style={{ color: '#999' }}>Waiting for stream...</span>}
        </p>
      </div>

      {/* Controls */}
      <div style={{ display: 'flex', gap: '10px', flexWrap: 'wrap' }}>
        <button 
          onClick={simulateStream}
          disabled={isSpeaking}
          style={{ 
            padding: '10px 20px', 
            backgroundColor: '#0070f3', 
            color: 'white', 
            border: 'none', 
            borderRadius: '5px',
            cursor: 'pointer'
          }}
        >
          Start Stream
        </button>

        <button 
          onClick={pauseSpeech}
          disabled={!isSpeaking}
          style={{ padding: '10px 20px', backgroundColor: '#f59e0b', color: 'white', border: 'none', borderRadius: '5px', cursor: 'pointer' }}
        >
          Pause
        </button>

        <button 
          onClick={resumeSpeech}
          style={{ padding: '10px 20px', backgroundColor: '#10b981', color: 'white', border: 'none', borderRadius: '5px', cursor: 'pointer' }}
        >
          Resume
        </button>

        <button 
          onClick={stopSpeech}
          style={{ padding: '10px 20px', backgroundColor: '#ef4444', color: 'white', border: 'none', borderRadius: '5px', cursor: 'pointer' }}
        >
          Stop
        </button>
      </div>

      <div style={{ marginTop: '20px', fontSize: '0.85rem', color: '#666' }}>
        Status: {isSpeaking ? 'Speaking...' : 'Idle'}
      </div>
    </div>
  );
}
