/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.tsx
// Description: Advanced Application Script
// ==========================================

'use client';

import React, { useEffect, useRef, useState, useCallback } from 'react';
import { useChat } from '@ai-sdk/react';

// --- Types & Interfaces ---

/**
 * Represents the state of the audio synthesis engine.
 */
interface AudioState {
  isPlaying: boolean;
  isPaused: boolean;
  currentUtterance: SpeechSynthesisUtterance | null;
}

/**
 * Configuration for the TTS engine.
 */
interface VoiceSettings {
  voiceName: string | null;
  rate: number; // 0.1 to 10
  pitch: number; // 0 to 2
  volume: number; // 0 to 1
}

// --- Audio Manager Class (SRP: Single Responsibility) ---
/**
 * Handles all interactions with the Web Speech API.
 * Decoupled from React to allow usage in hooks or standalone functions.
 */
class SpeechManager {
  private synth: SpeechSynthesis;
  private queue: SpeechSynthesisUtterance[];
  private currentUtterance: SpeechSynthesisUtterance | null;

  constructor() {
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      this.synth = window.speechSynthesis;
      this.queue = [];
      this.currentUtterance = null;
    } else {
      throw new Error('Web Speech API not supported in this browser.');
    }
  }

  /**
   * Adds text to the speaking queue.
   * @param text - The text to synthesize.
   * @param settings - Voice and audio parameters.
   */
  public speak(text: string, settings: VoiceSettings) {
    const utterance = new SpeechSynthesisUtterance(text);
    
    // Apply settings
    if (settings.voiceName) {
      const voices = this.synth.getVoices();
      const voice = voices.find(v => v.name === settings.voiceName);
      if (voice) utterance.voice = voice;
    }
    utterance.rate = settings.rate;
    utterance.pitch = settings.pitch;
    utterance.volume = settings.volume;

    // Event Listeners for Queue Management
    utterance.onend = () => {
      this.currentUtterance = null;
      this.playNext();
    };

    utterance.onerror = (e) => {
      console.error('Speech synthesis error:', e);
      this.currentUtterance = null;
      this.playNext();
    };

    this.queue.push(utterance);
    this.playNext();
  }

  /**
   * Internal method to trigger playback if nothing is playing.
   */
  private playNext() {
    if (this.currentUtterance || this.queue.length === 0) return;

    this.currentUtterance = this.queue.shift()!;
    this.synth.speak(this.currentUtterance);
  }

  /**
   * Pauses current audio.
   */
  public pause() {
    this.synth.pause();
  }

  /**
   * Resumes paused audio.
   */
  public resume() {
    this.synth.resume();
  }

  /**
   * Clears queue and stops current audio.
   */
  public cancel() {
    this.synth.cancel();
    this.queue = [];
    this.currentUtterance = null;
  }
}

// --- React Component ---

/**
 * A Real-Time Talking Assistant Component.
 * Integrates Vercel AI SDK streaming with Web Speech API.
 */
export default function TalkingAssistant() {
  // 1. State Management
  const [audioSettings, setAudioSettings] = useState<VoiceSettings>({
    voiceName: null,
    rate: 1.0,
    pitch: 1.0,
    volume: 1.0,
  });
  const [isAudioEnabled, setIsAudioEnabled] = useState(true);
  const audioManagerRef = useRef<SpeechManager | null>(null);
  
  // 2. Vercel AI SDK Integration
  const { messages, input, handleInputChange, handleSubmit, isLoading, stop } = useChat({
    api: '/api/chat', // Secure Server Action endpoint
    onFinish: (message) => {
      // Ensure the last chunk is spoken if the stream ended abruptly
      if (isAudioEnabled && audioManagerRef.current) {
        // We often rely on chunk streaming, but this is a fallback
        // to ensure the full final message is captured if chunking was too fast.
      }
    }
  });

  // 3. Initialize Audio Manager
  useEffect(() => {
    if (typeof window !== 'undefined') {
      audioManagerRef.current = new SpeechManager();
      
      // Load voices asynchronously (browser requirement)
      const loadVoices = () => {
        const voices = window.speechSynthesis.getVoices();
        if (voices.length > 0 && !audioSettings.voiceName) {
          // Default to first English voice
          const defaultVoice = voices.find(v => v.lang.startsWith('en')) || voices[0];
          setAudioSettings(prev => ({ ...prev, voiceName: defaultVoice!.name }));
        }
      };
      window.speechSynthesis.onvoiceschanged = loadVoices;
      loadVoices();
    }

    return () => {
      if (audioManagerRef.current) {
        audioManagerRef.current.cancel();
      }
    };
  }, []);

  // 4. Token Streaming Logic (The "Advanced" Part)
  // We watch the 'messages' array. When the AI adds a new message or updates one,
  // we parse the content. Since `useChat` streams tokens, we need to avoid 
  // re-speaking old text.
  
  const lastMessage = messages[messages.length - 1];
  const isUserMessage = lastMessage?.role === 'user';

  useEffect(() => {
    if (!lastMessage || !isAudioEnabled || !audioManagerRef.current || isUserMessage) return;

    // Logic: We only want to speak the NEW tokens.
    // However, `useChat` updates the full message content on every token.
    // To prevent re-speaking, we track the length of what we've already spoken.
    const spokenRef = useRef<string>(''); // Persist across renders

    // Check if we have new content to speak
    const newContent = lastMessage.content;
    if (newContent.length > spokenRef.current.length) {
      const delta = newContent.substring(spokenRef.current.length);
      
      // Heuristic: Split by punctuation to create natural pauses
      // This is a simplified tokenizer for audio synthesis
      const segments = delta.split(/(?<=[.,!?;:])\s+/);
      
      segments.forEach((segment) => {
        if (segment.trim().length > 0) {
          audioManagerRef.current!.speak(segment.trim(), audioSettings);
        }
      });

      spokenRef.current = newContent;
    }
    
    // Reset ref if a new message object is created (conversation reset)
    if (lastMessage.id !== spokenRef.current) {
       // In a real app, you'd map IDs to spoken content. 
       // For this demo, we assume linear streaming.
    }

  }, [lastMessage, isAudioEnabled, audioSettings, isUserMessage]);

  // 5. Controls
  const handlePauseAudio = () => {
    audioManagerRef.current?.pause();
  };

  const handleResumeAudio = () => {
    audioManagerRef.current?.resume();
  };

  const handleStopEverything = () => {
    stop(); // Stop AI generation
    audioManagerRef.current?.cancel(); // Stop Audio
  };

  return (
    <div className="w-full max-w-2xl mx-auto p-6 bg-white shadow-lg rounded-lg border border-gray-200">
      {/* Header & Controls */}
      <div className="flex justify-between items-center mb-6 border-b pb-4">
        <h2 className="text-xl font-bold text-gray-800">AI Talking Assistant</h2>
        <div className="flex gap-2">
          <button
            onClick={() => setIsAudioEnabled(!isAudioEnabled)}
            className={`px-3 py-1 rounded text-sm font-medium transition ${
              isAudioEnabled ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-500'
            }`}
          >
            {isAudioEnabled ? 'Audio ON' : 'Audio OFF'}
          </button>
          <button
            onClick={handlePauseAudio}
            className="px-3 py-1 bg-yellow-100 text-yellow-700 rounded text-sm font-medium hover:bg-yellow-200"
          >
            Pause
          </button>
          <button
            onClick={handleResumeAudio}
            className="px-3 py-1 bg-blue-100 text-blue-700 rounded text-sm font-medium hover:bg-blue-200"
          >
            Resume
          </button>
        </div>
      </div>

      {/* Chat Interface */}
      <div className="h-80 overflow-y-auto space-y-4 mb-6 p-2 bg-gray-50 rounded">
        {messages.map((msg) => (
          <div
            key={msg.id}
            className={`p-3 rounded-lg max-w-[80%] ${
              msg.role === 'user'
                ? 'ml-auto bg-blue-600 text-white'
                : 'bg-white border border-gray-200 text-gray-800'
            }`}
          >
            <p className="text-sm whitespace-pre-wrap">{msg.content}</p>
          </div>
        ))}
        {isLoading && (
          <div className="text-gray-400 text-sm animate-pulse">AI is thinking...</div>
        )}
      </div>

      {/* Input Form */}
      <form onSubmit={handleSubmit} className="flex gap-2">
        <input
          type="text"
          value={input}
          onChange={handleInputChange}
          placeholder="Ask me anything..."
          className="flex-1 p-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
        />
        <button
          type="submit"
          disabled={isLoading}
          className="px-6 py-3 bg-blue-600 text-white font-bold rounded-lg hover:bg-blue-700 disabled:opacity-50"
        >
          Send
        </button>
        <button
          type="button"
          onClick={handleStopEverything}
          className="px-4 py-3 bg-red-500 text-white font-bold rounded-lg hover:bg-red-600"
        >
          Stop
        </button>
      </form>
    </div>
  );
}
