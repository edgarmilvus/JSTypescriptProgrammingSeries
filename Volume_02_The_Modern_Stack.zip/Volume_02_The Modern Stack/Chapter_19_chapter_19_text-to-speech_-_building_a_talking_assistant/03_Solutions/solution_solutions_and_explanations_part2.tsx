/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useEffect, useState, useRef } from 'react';
import { useChat } from 'ai/react';
import { useSpeechSynthesis } from './useSpeechSynthesis'; // Assuming previous exercise

export const VoiceChatInterface = () => {
  const { messages, input, handleInputChange, handleSubmit, isLoading, stop: stopAi } = useChat();
  const { speak, stop: stopSpeech, isSpeaking } = useSpeechSynthesis();
  const [readAloud, setReadAloud] = useState(true);
  
  // Buffer for accumulating text tokens
  const bufferRef = useRef<string>('');
  // Timer to debounce sending chunks to speech synthesis
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  // Handle Interruptions: If user sends a new message while AI is speaking
  useEffect(() => {
    if (messages.length > 0 && isSpeaking) {
      // User sent a new message, stop the previous audio
      stopSpeech();
      // Clear the buffer
      bufferRef.current = '';
      if (timerRef.current) clearTimeout(timerRef.current);
    }
  }, [messages, isSpeaking, stopSpeech]);

  // Process Streaming Tokens
  useEffect(() => {
    if (!readAloud) return;

    const lastMessage = messages[messages.length - 1];
    // Only process if the last message is from the AI and is currently streaming
    if (lastMessage?.role === 'assistant' && isLoading) {
      // Append new content to buffer
      // Note: In a real scenario, we might need to diff the content to avoid duplicates
      // but useChat manages the full message content. We need to track what we've spoken.
      
      // To avoid re-speaking old content, we only speak the *new* part.
      // However, useChat updates the whole string. 
      // Strategy: We keep a reference to the last spoken length.
      
      // Simplified Strategy for this exercise:
      // We will rely on the fact that `isLoading` is true while streaming.
      // We need to extract only the newly arrived characters.
      // Since we don't have a direct "delta" in `useChat` without the `onFinish` or `onUpdate` in the API route,
      // we will simulate a chunking mechanism based on sentence endings.
      
      // *Critical Implementation Detail*: 
      // `useChat` updates the `message.content` incrementally in the UI, but the object reference changes.
      // We will use a ref to track the length of the text we have already queued for speech.
      
      // For this solution, we will implement a simple sentence-based buffer logic
      // assuming we are receiving the full updated string every time.
      
      // In a real production app, you would use the `streamData` from `useChat` (experimental) 
      // or handle raw SSE streams to get true deltas.
      
      // Here, we will simulate the logic by checking the end of the string.
      const content = lastMessage.content;
      
      // Clear buffer if it's a new message (different ID)
      if (bufferRef.current.length > content.length) {
         bufferRef.current = ''; 
      }

      // Append the difference
      const newContent = content.slice(bufferRef.current.length);
      bufferRef.current = content;

      // Check for sentence endings
      const sentenceRegex = /[^.!?]+[.!?]+/g;
      const matches = newContent.match(sentenceRegex);

      if (matches) {
        // Join matches and speak immediately
        const textToSpeak = matches.join(' ');
        if (textToSpeak.trim().length > 0) {
           speak(textToSpeak);
        }
      }
    } else if (!isLoading && bufferRef.current.length > 0) {
      // Stream finished, speak any remaining text in the buffer
      const remaining = bufferRef.current.trim();
      if (remaining.length > 0) {
        speak(remaining);
        bufferRef.current = '';
      }
    }
  }, [messages, isLoading, readAloud, speak]);

  const handleUserSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Stop any current speech immediately when user sends a new message
    stopSpeech();
    bufferRef.current = '';
    handleSubmit(e);
  };

  return (
    <div className="voice-chat-container">
      <div className="controls">
        <label>
          <input 
            type="checkbox" 
            checked={readAloud} 
            onChange={(e) => setReadAloud(e.target.checked)} 
          />
          Read Aloud
        </label>
      </div>

      <div className="chat-window">
        {messages.map((m, i) => (
          <div key={i} className={`message ${m.role}`}>
            {m.content}
          </div>
        ))}
        {isLoading && <div className="typing-indicator">AI is typing...</div>}
      </div>

      <form onSubmit={handleUserSubmit}>
        <input
          value={input}
          onChange={handleInputChange}
          placeholder="Say something..."
        />
        <button type="submit">Send</button>
      </form>
    </div>
  );
};
