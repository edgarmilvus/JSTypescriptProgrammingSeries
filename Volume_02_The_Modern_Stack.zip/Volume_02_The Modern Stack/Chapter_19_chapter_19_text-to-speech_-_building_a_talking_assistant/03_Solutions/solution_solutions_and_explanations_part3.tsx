/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState, useEffect, ChangeEvent } from 'react';

// Define the shape of the settings
interface VoiceSettings {
  voiceURI: string | null;
  rate: number;
  pitch: number;
  volume: number;
}

interface VoiceSettingsPanelProps {
  onSettingsChange: (settings: VoiceSettings) => void;
}

export const VoiceSettingsPanel: React.FC<VoiceSettingsPanelProps> = ({ onSettingsChange }) => {
  const [voices, setVoices] = useState<SpeechSynthesisVoice[]>([]);
  const [settings, setSettings] = useState<VoiceSettings>({
    voiceURI: null,
    rate: 1,
    pitch: 1,
    volume: 1,
  });

  // Load voices and settings on mount
  useEffect(() => {
    // Check browser support
    if (typeof window === 'undefined' || !('speechSynthesis' in window)) return;

    const loadVoices = () => {
      const availableVoices = window.speechSynthesis.getVoices();
      setVoices(availableVoices);
      
      // Load persisted settings
      const savedSettings = localStorage.getItem('voiceSettings');
      if (savedSettings) {
        const parsed = JSON.parse(savedSettings);
        setSettings((prev) => ({ ...prev, ...parsed }));
        // Notify parent immediately with loaded settings
        onSettingsChange({ ...settings, ...parsed });
      } else {
        // Set default voice if none saved
        if (availableVoices.length > 0 && !settings.voiceURI) {
            const defaultVoice = availableVoices.find(v => v.default) || availableVoices[0];
            const defaultSettings = { ...settings, voiceURI: defaultVoice.voiceURI };
            setSettings(defaultSettings);
            onSettingsChange(defaultSettings);
        }
      }
    };

    // Initial load
    loadVoices();

    // The 'voiceschanged' event is crucial because voices load asynchronously
    window.speechSynthesis.onvoiceschanged = loadVoices;

    return () => {
      window.speechSynthesis.onvoiceschanged = null;
    };
  }, []); // Run once on mount

  // Handle changes to settings
  const handleChange = (field: keyof VoiceSettings, value: string | number) => {
    const newSettings = { ...settings, [field]: value };
    setSettings(newSettings);
    onSettingsChange(newSettings); // Pass up to parent/hook
    localStorage.setItem('voiceSettings', JSON.stringify(newSettings));
  };

  const handleTestVoice = () => {
    if (typeof window === 'undefined' || !('speechSynthesis' in window)) return;
    
    const utterance = new SpeechSynthesisUtterance("Hello, this is a test of the selected voice settings.");
    
    // Apply current settings
    if (settings.voiceURI) {
      const voice = voices.find(v => v.voiceURI === settings.voiceURI);
      if (voice) utterance.voice = voice;
    }
    utterance.rate = settings.rate;
    utterance.pitch = settings.pitch;
    utterance.volume = settings.volume;

    window.speechSynthesis.speak(utterance);
  };

  return (
    <div className="voice-settings-panel" style={{ padding: '20px', border: '1px solid #ccc', borderRadius: '8px' }}>
      <h3>Voice Settings</h3>
      
      <div className="form-group">
        <label>Voice:</label>
        <select 
          value={settings.voiceURI || ''} 
          onChange={(e) => handleChange('voiceURI', e.target.value)}
        >
          <option value="" disabled>Select a voice</option>
          {voices.map((voice) => (
            <option key={voice.voiceURI} value={voice.voiceURI}>
              {voice.name} ({voice.lang})
            </option>
          ))}
        </select>
      </div>

      <div className="form-group">
        <label>Rate: {settings.rate}</label>
        <input 
          type="range" min="0.5" max="2" step="0.1" 
          value={settings.rate} 
          onChange={(e) => handleChange('rate', parseFloat(e.target.value))} 
        />
      </div>

      <div className="form-group">
        <label>Pitch: {settings.pitch}</label>
        <input 
          type="range" min="0" max="2" step="0.1" 
          value={settings.pitch} 
          onChange={(e) => handleChange('pitch', parseFloat(e.target.value))} 
        />
      </div>

      <div className="form-group">
        <label>Volume: {settings.volume}</label>
        <input 
          type="range" min="0" max="1" step="0.1" 
          value={settings.volume} 
          onChange={(e) => handleChange('volume', parseFloat(e.target.value))} 
        />
      </div>

      <button onClick={handleTestVoice} style={{ marginTop: '10px' }}>
        Test Voice
      </button>
    </div>
  );
};
