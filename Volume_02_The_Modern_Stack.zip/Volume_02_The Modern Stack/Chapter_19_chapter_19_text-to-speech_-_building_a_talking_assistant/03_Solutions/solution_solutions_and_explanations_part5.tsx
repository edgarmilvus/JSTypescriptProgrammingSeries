/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.tsx
// Description: Solutions and Explanations
// ==========================================

// app/VoiceChatClient.tsx (Client Component)
'use client';

import React, { useState, useEffect } from 'react';
import { useChat } from 'ai/react';
import { useSpeechSynthesis } from './useSpeechSynthesis'; // From Ex 1

interface UserProfile {
  persona: string;
  preferredVoiceURI: string;
}

interface Props {
  initialProfile: UserProfile;
}

const VoiceChatClient: React.FC<Props> = ({ initialProfile }) => {
  const [persona, setPersona] = useState<UserProfile['persona']>(initialProfile.persona);
  const [voiceURI, setVoiceURI] = useState<string | null>(initialProfile.preferredVoiceURI);
  
  const { messages, input, handleInputChange, handleSubmit } = useChat({
    // Inject Server Context into the initial system prompt
    initialMessages: [
      {
        role: 'system',
        content: `You are acting as a ${persona}. Keep your responses concise and in character.`
      }
    ]
  });

  const { speak, stop } = useSpeechSynthesis();

  // Map persona to specific voice if not explicitly set by server
  // This logic runs on the client
  const getVoiceForPersona = (p: string): string | null => {
    switch (p) {
      case 'Teacher': return 'Google US English Female'; // Example mapping
      case 'Storyteller': return 'Google UK English Male';
      case 'Technical Support': return 'Google US English';
      default: return null;
    }
  };

  const handlePersonaChange = (newPersona: UserProfile['persona']) => {
    setPersona(newPersona);
    // Update the system prompt dynamically
    // Note: In useChat, updating initialMessages doesn't retroactively change the system prompt
    // for existing conversations. In a real app, you might restart the chat or append a system message.
    // For this demo, we will just update the voice mapping.
    const mappedVoice = getVoiceForPersona(newPersona);
    setVoiceURI(mappedVoice);
  };

  // Handle speaking logic
  useEffect(() => {
    const lastMessage = messages[messages.length - 1];
    if (lastMessage?.role === 'assistant') {
      // Use the mapped voice URI based on current persona
      speak(lastMessage.content, voiceURI || undefined);
    }
  }, [messages, speak, voiceURI]);

  return (
    <div>
      <div style={{ marginBottom: '20px', padding: '10px', background: '#f0f0f0' }}>
        <strong>Server Context: </strong> Persona: {initialProfile.persona}
        <br />
        <strong>Current Persona Mode: </strong>
        <select 
          value={persona} 
          onChange={(e) => handlePersonaChange(e.target.value as UserProfile['persona'])}
        >
          <option value="Teacher">Teacher</option>
          <option value="Storyteller">Storyteller</option>
          <option value="Technical Support">Technical Support</option>
        </select>
      </div>

      <div className="chat-box">
        {messages.map((m, i) => (
          <div key={i} className={`msg ${m.role}`}>
            <strong>{m.role}: </strong> {m.content}
          </div>
        ))}
      </div>

      <form onSubmit={(e) => { stop(); handleSubmit(e); }}>
        <input value={input} onChange={handleInputChange} />
        <button type="submit">Send</button>
      </form>
    </div>
  );
};

export default VoiceChatClient;
