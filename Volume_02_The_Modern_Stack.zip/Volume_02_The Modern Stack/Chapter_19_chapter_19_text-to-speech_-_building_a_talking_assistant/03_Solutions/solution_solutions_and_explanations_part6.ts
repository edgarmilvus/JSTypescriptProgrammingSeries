/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part6.ts
// Description: Solutions and Explanations
// ==========================================

digraph AudioPipeline {
    rankdir=TB;
    node [shape=box, style=filled, fillcolor=lightblue];
    
    // Define Subgraphs for visual separation of Server vs Client
    subgraph cluster_server {
        label = "Server Environment (Next.js)";
        style = dashed;
        color = blue;
        ServerComp [label="Next.js Server Component\n(Data Fetching & Context)"];
        AIModel [label="AI Model\n(Generation via Vercel AI SDK)"];
    }

    subgraph cluster_client {
        label = "Browser Environment (Client)";
        style = dashed;
        color = green;
        User [label="User (Input & Controls)"];
        AISDK [label="Vercel AI SDK\n(useChat Hook)"];
        WebSpeech [label="Web Speech API\n(Synthesis Engine)"];
    }

    // Define flows
    
    // 1. Initial Context Flow
    ServerComp -> AISDK [label="1. User Profile / Persona Context", color="blue", fontcolor="blue"];
    
    // 2. User Interaction Flow
    User -> AISDK [label="2. User Prompt", color="green", fontcolor="green"];
    
    // 3. API Request Flow (Cross-boundary)
    AISDK -> AIModel [label="3. API Call (Prompt + Context)", dir="both", style="dashed"];
    
    // 4. Streaming Response Flow
    AIModel -> AISDK [label="4. Text Stream (Tokens)", dir="back", color="blue", fontcolor="blue"];
    
    // 5. Audio Synthesis Flow
    AISDK -> WebSpeech [label="5. Trigger Synthesis\n(Buffered Chunks)", color="green", fontcolor="green"];
    
    // 6. Audio Output
    WebSpeech -> User [label="6. Audio Output", color="green", fontcolor="green"];

    // 7. Interruption Feedback Loop (Interactive Challenge)
    User -> WebSpeech [label="7. Interrupt (New Message)", color="red", fontcolor="red", style="dashed"];
    WebSpeech -> AISDK [label="8. Stop Signal", dir="back", color="red", fontcolor="red", style="dashed"];
    AISDK -> AIModel [label="9. Cancel Stream", dir="back", color="red", fontcolor="red", style="dashed"];
}
