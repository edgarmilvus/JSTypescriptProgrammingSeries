/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: theory_theoretical_foundations.ts
// Description: Theoretical Foundations
// ==========================================

digraph Architecture {
    rankdir=TB;
    node [shape=box, style="rounded,filled", fontname="Helvetica"];

    subgraph cluster_client {
        label = "Client (Browser)";
        color = lightgrey;
        style = dashed;

        User [label="User Input", shape=ellipse, fillcolor="#e1f5fe"];
        UI [label="React Client Components\n(useChat Hook)", fillcolor="#b3e5fc"];
        StreamHandler [label="Stream Receiver\n(Tokens -> UI)", fillcolor="#81d4fa"];
    }

    subgraph cluster_server {
        label = "Server (Next.js / Vercel Edge)";
        color = lightgrey;
        style = dashed;

        ServerAction [label="Server Action / API Route", fillcolor="#e8f5e9"];
        RSC [label="React Server Component\n(Secure Gateway)", fillcolor="#c8e6c9"];
        Validator [label="JSON Schema / Zod\nValidation Layer", fillcolor="#fff9c4"];
        AI_SDK [label="Vercel AI SDK\n(LLM Orchestration)", fillcolor="#ffcc80"];
        DB [label="Database\n(Postgres/Redis)", shape=cylinder, fillcolor="#f3e5f5"];
    }

    External [label="External LLM Provider\n(e.g., OpenAI, Anthropic)", shape=ellipse, fillcolor="#ffebee"];

    // Flow
    User -> UI [label="1. Submit Prompt"];
    UI -> ServerAction [label="2. Trigger Server Action"];
    ServerAction -> RSC [label="3. Secure Context & Auth"];
    RSC -> Validator [label="4. Define Output Schema"];
    Validator -> AI_SDK [label="5. Prompt + Schema"];
    AI_SDK -> External [label="6. Inference Request"];
    External -> AI_SDK [label="7. Streamed JSON Tokens"];
    AI_SDK -> DB [label="8. Save Structured Result"];
    AI_SDK -> StreamHandler [label="9. Stream to Client"];
    StreamHandler -> UI [label="10. Real-time Render"];
}
