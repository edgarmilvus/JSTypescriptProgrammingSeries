/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.tsx
// Description: Basic Code Example
// ==========================================

// File: app/page.tsx
'use client';

import { useChat } from 'ai/react';
import { generateCopy } from './actions';
import { useState } from 'react';

export default function CopywriterPage() {
  // 1. Initialize the useChat hook.
  // This hook manages the message history, input state, and the streaming response.
  const { messages, input, handleInputChange, handleSubmit, isLoading } = useChat({
    // We point the hook to our custom Server Action.
    api: '/api/generate-copy', // We will create a route handler for this
  });

  // Local state to parse the JSON stream (optional, but good for demonstration)
  const [parsedCopy, setParsedCopy] = useState<any>(null);

  // Note: In a real app, we would route this through a Next.js API Route 
  // that calls the 'generateCopy' server action, or use the 'useActionState' hook.
  // For this 'Hello World', we simulate the client-server interaction via a standard API route.
  
  return (
    <div className="max-w-2xl mx-auto p-8">
      <h1 className="text-2xl font-bold mb-4">AI Copywriter</h1>
      
      {/* Message Display Area */}
      <div className="border rounded p-4 h-64 overflow-y-auto mb-4 bg-gray-50">
        {messages.map((m, index) => (
          <div key={index} className="mb-2">
            <strong className="block text-sm text-gray-600">
              {m.role === 'user' ? 'You:' : 'AI:'}
            </strong>
            <span className="text-gray-800">
              {m.content}
            </span>
          </div>
        ))}
        {isLoading && (
          <div className="text-gray-400 italic">Generating...</div>
        )}
      </div>

      {/* Input Form */}
      <form onSubmit={handleSubmit} className="flex gap-2">
        <input
          type="text"
          value={input}
          onChange={handleInputChange}
          placeholder="Describe your product..."
          className="flex-1 border p-2 rounded"
          disabled={isLoading}
        />
        <button 
          type="submit" 
          className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 disabled:opacity-50"
          disabled={isLoading}
        >
          Generate
        </button>
      </form>
    </div>
  );
}
