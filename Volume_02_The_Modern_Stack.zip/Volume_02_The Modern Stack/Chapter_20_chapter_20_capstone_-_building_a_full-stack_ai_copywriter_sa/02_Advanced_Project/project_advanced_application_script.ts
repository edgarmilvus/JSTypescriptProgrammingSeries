/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

'use server';

import { streamObject } from 'ai';
import { openai } from '@ai-sdk/openai';
import { z } from 'zod';

/**
 * SERVER ACTION: generateBlogOutline
 * 
 * This server-side function accepts a user prompt and streams a structured
 * JSON object back to the client. It uses Zod to define the JSON Schema,
 * which instructs the LLM to format its output strictly.
 * 
 * Security: By keeping the LLM API key and logic on the server, we prevent
 * exposing sensitive credentials to the client.
 * 
 * @param {string} topic - The subject of the blog post.
 * @returns {Promise<StreamObjectResult>} - A stream of structured JSON data.
 */
export async function generateBlogOutline(topic: string) {
  // 1. Define the Schema using Zod
  // This schema dictates the structure the LLM must adhere to.
  const blogSchema = z.object({
    title: z.string().describe('The catchy title of the blog post'),
    introduction: z.string().describe('A compelling introduction paragraph'),
    sections: z.array(
      z.object({
        heading: z.string().describe('The heading of the section'),
        bullets: z.array(z.string()).describe('Key points to cover in this section'),
      })
    ).describe('An array of sections that make up the body of the blog'),
  });

  // 2. Initiate the Stream
  // We pass the model, the prompt, and the schema to the streamObject function.
  // The Vercel AI SDK handles the prompt engineering to ensure the LLM outputs valid JSON.
  const result = await streamObject({
    model: openai('gpt-4-turbo-preview'),
    prompt: `Generate a comprehensive blog outline for the topic: "${topic}"`,
    schema: blogSchema,
    temperature: 0.7, // Creative but focused
  });

  // 3. Return the stream
  // The result object contains the stream that the client can consume.
  return result;
}
