/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script_part2.tsx
// Description: Advanced Application Script
// ==========================================

'use client';

import { useCompletion } from '@ai-sdk/react';
import { generateBlogOutline } from '@/actions/generateOutline'; // Import the server action
import { z } from 'zod';
import { useEffect, useState } from 'react';

// Define the TypeScript interface based on our Zod schema
interface BlogSection {
  heading: string;
  bullets: string[];
}

interface BlogOutline {
  title: string;
  introduction: string;
  sections: BlogSection[];
}

/**
 * CLIENT COMPONENT: OutlineGenerator
 * 
 * This component manages the UI state and consumes the streamed JSON object.
 * It uses `useCompletion` to handle the stream, but we manually parse the
 * partial JSON into our typed state to render the UI dynamically.
 */
export default function OutlineGenerator() {
  // State to hold the fully parsed JSON structure
  const [outline, setOutline] = useState<BlogOutline>({
    title: '',
    introduction: '',
    sections: [],
  });

  // State to hold the raw string stream for debugging or fallback
  const [input, setInput] = useState('');

  // useCompletion hook configured for object streaming
  const { completion, handleSubmit, isLoading, error } = useCompletion({
    api: '/api/generate-outline', // We need a route handler for the client hook
    // Alternatively, we can invoke the server action directly, but useCompletion 
    // is optimized for streaming UI feedback.
  });

  // 1. Parse the streamed JSON string into our state
  useEffect(() => {
    if (completion) {
      try {
        // The completion string is a partial JSON object. 
        // We attempt to parse it. If valid, we update the UI.
        const parsed = JSON.parse(completion) as BlogOutline;
        setOutline(parsed);
      } catch (e) {
        // Ignore parsing errors while the stream is incomplete
      }
    }
  }, [completion]);

  return (
    <div className="max-w-2xl mx-auto p-6 bg-white rounded-lg shadow-lg">
      <h1 className="text-2xl font-bold mb-4 text-gray-800">AI Blog Outliner</h1>
      
      {/* Input Form */}
      <form onSubmit={handleSubmit} className="flex gap-2 mb-6">
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Enter a blog topic (e.g., 'The Future of React Server Components')"
          className="flex-1 p-2 border border-gray-300 rounded text-black"
          disabled={isLoading}
        />
        <button 
          type="submit" 
          className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 disabled:opacity-50"
          disabled={isLoading}
        >
          {isLoading ? 'Generating...' : 'Generate'}
        </button>
      </form>

      {/* Error Display */}
      {error && (
        <div className="mb-4 p-3 bg-red-100 text-red-700 rounded">
          Error: {error.message}
        </div>
      )}

      {/* Rendered Generative UI */}
      <div className="space-y-6 animate-fade-in">
        {outline.title && (
          <h2 className="text-3xl font-extrabold text-gray-900 border-b pb-2">
            {outline.title}
          </h2>
        )}

        {outline.introduction && (
          <p className="text-gray-600 leading-relaxed italic">
            "{outline.introduction}"
          </p>
        )}

        {outline.sections.map((section, index) => (
          <div key={index} className="border-l-4 border-blue-500 pl-4 py-2 bg-gray-50 rounded-r">
            <h3 className="text-lg font-semibold text-gray-800">
              {section.heading || '...'}
            </h3>
            <ul className="list-disc list-inside mt-2 text-gray-600">
              {section.bullets.map((bullet, bIndex) => (
                <li key={bIndex} className="ml-2">
                  {bullet}
                </li>
              ))}
            </ul>
          </div>
        ))}
      </div>
    </div>
  );
}
