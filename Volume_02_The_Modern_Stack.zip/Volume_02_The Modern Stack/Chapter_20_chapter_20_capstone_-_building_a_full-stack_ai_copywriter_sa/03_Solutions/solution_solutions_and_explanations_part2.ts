/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

// File: app/actions/generateCopy.ts
'use server'; // Mark this file as a Server Action

import { generateObject } from 'ai';
import { openai } from '@ai-sdk/openai';
import { z } from 'zod';

// 1. Define the Zod Schema
const CopyVariationSchema = z.object({
  headline: z.string().max(60, "Headline must be 60 characters or fewer"),
  subHeadline: z.string().max(120, "Sub-headline must be 120 characters or fewer"),
  callToAction: z.string(),
  tone: z.string(),
});

// 2. Create the Server Action
export async function generateCopyAction(tone: string) {
  try {
    // 3. Use generateObject with the schema
    const result = await generateObject({
      model: openai('gpt-4o-mini'), // or gpt-3.5-turbo
      schema: CopyVariationSchema,
      prompt: `Generate a marketing copy for a new SaaS product. 
               The tone should be ${tone}. 
               Ensure the headline is catchy, the sub-headline explains the value, 
               and the CTA is actionable.`,
    });

    // Return the structured object
    return result.object;
  } catch (error) {
    console.error("Error generating copy:", error);
    throw new Error("Failed to generate copy variations.");
  }
}
