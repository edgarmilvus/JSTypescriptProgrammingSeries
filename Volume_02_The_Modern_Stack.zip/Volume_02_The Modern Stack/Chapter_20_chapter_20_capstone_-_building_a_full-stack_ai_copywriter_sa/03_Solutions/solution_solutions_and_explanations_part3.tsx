/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

// File: app/dashboard/page.tsx (Server Component)
import { redirect } from 'next/navigation';
import CopyGeneratorUI from '@/components/CopyGeneratorUI';
import LimitedAccessBanner from '@/components/LimitedAccessBanner';

// Mock function to simulate fetching auth data
// In a real app, this would interact with a database or auth provider (e.g., NextAuth, Clerk)
async function getAuthSession() {
  // Simulate a delay for database lookup
  await new Promise((resolve) => setTimeout(resolve, 500));
  
  // Mock data: Change this to 'pro' or 'free' to test conditional rendering
  return {
    user: {
      id: 'user_123',
      email: 'user@example.com',
    },
    subscriptionTier: 'free' as const, // or 'pro'
  };
}

export default async function DashboardPage() {
  const session = await getAuthSession();

  // If no session, redirect to login
  if (!session) {
    redirect('/login');
  }

  // 4. Conditional Rendering based on Tier
  if (session.subscriptionTier === 'free') {
    return (
      <main className="container mx-auto p-4">
        <h1 className="text-2xl font-bold mb-4">Dashboard</h1>
        <LimitedAccessBanner />
      </main>
    );
  }

  // Pro users get the full UI
  return (
    <main className="container mx-auto p-4">
      <h1 className="text-2xl font-bold mb-4">Dashboard</h1>
      <CopyGeneratorUI user={session.user} />
    </main>
  );
}
