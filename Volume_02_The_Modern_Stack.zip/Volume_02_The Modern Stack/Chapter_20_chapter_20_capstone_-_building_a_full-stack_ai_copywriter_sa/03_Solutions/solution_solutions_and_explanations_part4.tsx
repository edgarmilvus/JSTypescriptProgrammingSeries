/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.tsx
// Description: Solutions and Explanations
// ==========================================

// File: components/CopyDisplay.tsx (Server Component)
// No 'use client' directive here!

interface Variation {
  id: string;
  headline: string;
  subHeadline: string;
  callToAction: string;
}

interface CopyDisplayProps {
  variations: Variation[];
  onSelect: (id: string) => void; // Callback passed from Client Component
}

export default function CopyDisplay({ variations, onSelect }: CopyDisplayProps) {
  // This runs on the server. No useState or useEffect allowed.
  
  return (
    <div className="grid grid-cols-1 gap-6 mt-6">
      {variations.map((variation) => (
        <div 
          key={variation.id} 
          className="p-4 border rounded-lg shadow hover:shadow-md transition-shadow bg-white"
        >
          <h3 className="text-xl font-bold text-gray-900 mb-2">{variation.headline}</h3>
          <p className="text-gray-600 mb-3">{variation.subHeadline}</p>
          
          <div className="flex justify-between items-center mt-4">
            <span className="inline-block bg-gray-200 rounded-full px-3 py-1 text-sm font-semibold text-gray-700">
              {variation.callToAction}
            </span>
            {/* 
              Interaction Note: 
              Even though this is a Server Component, we can pass the event handler 
              down from a Client Component. The function reference is passed via props.
            */}
            <button
              onClick={() => onSelect(variation.id)}
              className="px-3 py-1 bg-blue-600 text-white text-sm rounded hover:bg-blue-700"
            >
              Select
            </button>
          </div>
        </div>
      ))}
    </div>
  );
}
