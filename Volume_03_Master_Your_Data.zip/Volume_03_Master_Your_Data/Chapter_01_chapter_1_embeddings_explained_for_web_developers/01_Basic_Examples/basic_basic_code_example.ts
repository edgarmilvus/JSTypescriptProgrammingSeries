/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * EMBEDDING_GENERATOR_AND_SEARCHER.ts
 * 
 * A self-contained TypeScript example demonstrating how to:
 * 1. Generate text embeddings using OpenAI's API.
 * 2. Perform a semantic search (K-Nearest Neighbors) against a local dataset.
 * 
 * Usage: ts-node embedding_generator_and_searcher.ts
 */

import OpenAI from 'openai';

// ============================================================================
// 1. CONFIGURATION & TYPES
// ============================================================================

// In a production app, store this in environment variables (process.env.OPENAI_API_KEY)
const OPENAI_API_KEY = process.env.OPENAI_API_KEY || 'YOUR_OPENAI_API_KEY_HERE';

// Define the shape of our vector database (in-memory for this example)
type VectorRecord = {
  id: string;
  content: string;
  embedding: number[]; // The vector representation
};

// ============================================================================
// 2. MOCK DATA (SIMULATING A DATABASE)
// ============================================================================

// In a real application, these embeddings would be pre-computed and stored 
// in a vector database like Pinecone, Weaviate, or Qdrant.
const mockDatabase: Omit<VectorRecord, 'embedding'>[] = [
  { id: 'doc_1', content: 'The quick brown fox jumps over the lazy dog.' },
  { id: 'doc_2', content: 'JavaScript is a versatile programming language.' },
  { id: 'doc_3', content: 'Artificial Intelligence is transforming web development.' },
  { id: 'doc_4', content: 'The weather today is sunny and warm.' },
];

// ============================================================================
// 3. HELPER FUNCTIONS
// ============================================================================

/**
 * Generates an embedding vector for a given text string using OpenAI's API.
 * 
 * @param text - The input string to embed.
 * @returns A Promise resolving to an array of numbers (the vector).
 */
async function generateEmbedding(text: string): Promise<number[]> {
  const openai = new OpenAI({
    apiKey: OPENAI_API_KEY,
  });

  try {
    // We use 'text-embedding-ada-002' as it's cost-effective and widely used.
    const response = await openai.embeddings.create({
      model: 'text-embedding-ada-002',
      input: text,
    });

    // The API returns an array of data objects; we need the first one's embedding.
    if (!response.data || response.data.length === 0) {
      throw new Error('No embedding data returned from API');
    }

    return response.data[0].embedding;
  } catch (error) {
    console.error('Error generating embedding:', error);
    throw error;
  }
}

/**
 * Calculates the Cosine Similarity between two vectors.
 * This is the core math behind K-Nearest Neighbors (KNN).
 * 
 * Cosine Similarity measures the cosine of the angle between two vectors.
 * Range: [-1, 1]. 
 * 1 = Identical direction (perfect match).
 * 0 = Orthogonal (no correlation).
 * -1 = Opposite direction.
 * 
 * @param vecA - The query vector.
 * @param vecB - The database vector.
 * @returns A similarity score.
 */
function cosineSimilarity(vecA: number[], vecB: number[]): number {
  if (vecA.length !== vecB.length) {
    throw new Error('Vectors must be of the same dimension');
  }

  let dotProduct = 0;
  let normA = 0;
  let normB = 0;

  for (let i = 0; i < vecA.length; i++) {
    dotProduct += vecA[i] * vecB[i];
    normA += vecA[i] * vecA[i];
    normB += vecB[i] * vecB[i];
  }

  // Handle division by zero
  if (normA === 0 || normB === 0) {
    return 0;
  }

  return dotProduct / (Math.sqrt(normA) * Math.sqrt(normB));
}

/**
 * Performs a semantic search against the in-memory database.
 * 
 * @param queryVector - The vector representation of the user's query.
 * @param database - The list of records containing vectors.
 * @param k - The number of top results to return (K in KNN).
 * @returns The top K matching records sorted by relevance.
 */
function semanticSearch(queryVector: number[], database: VectorRecord[], k: number = 2) {
  // Calculate similarity score for every record in the database
  const scoredResults = database.map(record => ({
    ...record,
    score: cosineSimilarity(queryVector, record.embedding),
  }));

  // Sort by score descending (highest similarity first)
  scoredResults.sort((a, b) => b.score - a.score);

  // Return the top K results
  return scoredResults.slice(0, k);
}

// ============================================================================
// 4. MAIN EXECUTION LOGIC
// ============================================================================

/**
 * Main function to orchestrate the embedding generation and search flow.
 */
async function main() {
  console.log('--- RAG Embedding Example ---\n');

  // Step 1: Pre-process the database (Generate embeddings for stored docs)
  console.log('1. Generating embeddings for database documents...');
  
  // We map over the mock data to add the 'embedding' field
  const processedDatabase: VectorRecord[] = [];
  for (const doc of mockDatabase) {
    const embedding = await generateEmbedding(doc.content);
    processedDatabase.push({ ...doc, embedding });
    console.log(`   - Embedded document: "${doc.content.substring(0, 30)}..."`);
  }

  // Step 2: User Query (Simulating a SaaS App User Input)
  const userQuery = 'Tell me about coding languages and AI.';
  console.log(`\n2. User Query: "${userQuery}"`);

  // Step 3: Generate Embedding for the User Query
  console.log('3. Generating embedding for user query...');
  const queryVector = await generateEmbedding(userQuery);

  // Step 4: Perform Semantic Search (KNN)
  console.log('4. Searching vector database (Calculating Cosine Similarity)...');
  const results = semanticSearch(queryVector, processedDatabase, 2);

  // Step 5: Display Results
  console.log('\n--- Search Results (K-Nearest Neighbors) ---');
  results.forEach((result, index) => {
    console.log(`Rank ${index + 1} (Score: ${result.score.toFixed(4)}):`);
    console.log(`   ID: ${result.id}`);
    console.log(`   Content: ${result.content}`);
    console.log('---');
  });
}

// Execute the script
// Note: In a real web server (Express/Next.js), you would call these functions inside route handlers.
main().catch(console.error);
