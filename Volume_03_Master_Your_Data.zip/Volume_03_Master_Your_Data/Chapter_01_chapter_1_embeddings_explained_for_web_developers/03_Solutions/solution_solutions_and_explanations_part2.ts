/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

// search.ts
import { generateEmbedding } from './index';
import { EmbeddingVector } from './types';

interface Product {
  id: string;
  description: string;
}

/**
 * Calculates the cosine similarity between two vectors.
 * @param vecA - The first vector.
 * @param vecB - The second vector.
 * @returns A number between 0 and 1 representing similarity.
 */
export function calculateCosineSimilarity(vecA: number[], vecB: number[]): number {
  if (vecA.length !== vecB.length) {
    throw new Error('Vectors must be of the same length');
  }

  let dotProduct = 0;
  let normA = 0;
  let normB = 0;

  for (let i = 0; i < vecA.length; i++) {
    dotProduct += vecA[i] * vecB[i];
    normA += vecA[i] * vecA[i];
    normB += vecB[i] * vecB[i];
  }

  const denominator = Math.sqrt(normA) * Math.sqrt(normB);
  
  // Handle division by zero if a vector is all zeros
  if (denominator === 0) return 0;

  return dotProduct / denominator;
}

/**
 * Performs a semantic search against a list of products.
 * @param query - The user's search query string.
 * @param products - The array of product objects.
 * @returns A Promise resolving to an array of product IDs sorted by similarity (descending).
 */
export async function semanticSearch(
  query: string,
  products: Product[]
): Promise<string[]> {
  // 1. Generate embedding for the query
  const queryEmbedding = await generateEmbedding(query);

  // 2. Generate embeddings for all product descriptions
  // Note: In a real system, embeddings would be pre-calculated and stored.
  // Here we calculate them on the fly for the exercise.
  const productsWithEmbeddings = await Promise.all(
    products.map(async (product) => {
      const embedding = await generateEmbedding(product.description);
      return { ...product, embedding };
    })
  );

  // 3. Calculate similarity scores
  const scoredProducts = productsWithEmbeddings.map((product) => {
    const score = calculateCosineSimilarity(queryEmbedding, product.embedding);
    return { id: product.id, score };
  });

  // 4. Sort by score (highest first) and extract IDs
  scoredProducts.sort((a, b) => b.score - a.score);

  return scoredProducts.map((p) => p.id);
}
