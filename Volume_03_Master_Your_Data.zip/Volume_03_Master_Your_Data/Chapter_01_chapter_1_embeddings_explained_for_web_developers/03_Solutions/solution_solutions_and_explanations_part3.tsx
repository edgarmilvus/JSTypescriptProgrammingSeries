/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

// SemanticSearchComponent.tsx
import React, { useState, useEffect } from 'react';

interface DocPage {
  id: string;
  title: string;
  content: string;
}

const mockDocs: DocPage[] = [
  { id: '1', title: 'Getting Started', content: 'Introduction to the library...' },
  { id: '2', title: 'API Reference', content: 'Detailed API documentation...' },
  { id: '3', title: 'Advanced Usage', content: 'Optimization and configuration...' },
];

// Mock function to simulate backend API call
const mockSearch = async (query: string): Promise<DocPage[]> => {
  return new Promise((resolve) => {
    setTimeout(() => {
      if (!query.trim()) resolve([]);
      const lowerQuery = query.toLowerCase();
      const results = mockDocs.filter(doc => 
        doc.title.toLowerCase().includes(lowerQuery) || 
        doc.content.toLowerCase().includes(lowerQuery)
      );
      resolve(results);
    }, 500); // Simulate network delay
  });
};

export const SemanticSearchComponent: React.FC = () => {
  const [query, setQuery] = useState<string>('');
  const [results, setResults] = useState<DocPage[]>([]);
  const [loading, setLoading] = useState<boolean>(false);

  useEffect(() => {
    // Debounce logic
    const handler = setTimeout(() => {
      if (query.trim()) {
        setLoading(true);
        mockSearch(query)
          .then(setResults)
          .finally(() => setLoading(false));
      } else {
        setResults([]);
      }
    }, 300); // 300ms delay

    // Cleanup function to clear timeout if query changes before delay completes
    return () => {
      clearTimeout(handler);
    };
  }, [query]); // Dependency array runs effect when query changes

  return (
    <div style={{ padding: '20px', maxWidth: '600px', margin: '0 auto' }}>
      <h2>Documentation Search</h2>
      <input
        type="text"
        placeholder="Search docs..."
        value={query}
        onChange={(e) => setQuery(e.target.value)}
        style={{
          width: '100%',
          padding: '10px',
          fontSize: '16px',
          marginBottom: '20px',
          border: '1px solid #ccc',
          borderRadius: '4px',
        }}
      />
      
      {loading && <div style={{ color: '#666' }}>Searching...</div>}
      
      {!loading && results.length > 0 && (
        <ul style={{ listStyle: 'none', padding: 0 }}>
          {results.map((doc) => (
            <li key={doc.id} style={{ marginBottom: '15px', padding: '10px', border: '1px solid #eee', borderRadius: '4px' }}>
              <strong>{doc.title}</strong>
              <p style={{ margin: '5px 0 0', color: '#555', fontSize: '0.9em' }}>
                {doc.content.substring(0, 60)}...
              </p>
            </li>
          ))}
        </ul>
      )}

      {!loading && query && results.length === 0 && (
        <p>No results found.</p>
      )}
    </div>
  );
};
