/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

// pineconeManager.ts
import { Pinecone, PineconeRecord } from '@pinecone-database/pinecone';

export class PineconeManager {
  private pc: Pinecone;
  private indexName: string;
  private initialized = false;

  constructor() {
    // Validate environment variables
    if (!process.env.PINECONE_API_KEY) {
      throw new Error('PINECONE_API_KEY is not defined in environment variables');
    }
    if (!process.env.PINECONE_INDEX_NAME) {
      throw new Error('PINECONE_INDEX_NAME is not defined in environment variables');
    }

    this.pc = new Pinecone({
      apiKey: process.env.PINECONE_API_KEY,
    });
    this.indexName = process.env.PINECONE_INDEX_NAME;
  }

  // Lazy initialization helper
  private async getIndex() {
    if (!this.initialized) {
      // Verify connection or perform setup if needed
      // In Pinecone v2+, indexes are created separately, we just target an existing one
      this.initialized = true;
    }
    return this.pc.index(this.indexName);
  }

  /**
   * Upserts a vector into a specific namespace.
   * @param namespace - The tenant identifier.
   * @param vectorId - The unique ID for the vector.
   * @param embedding - The numerical vector array.
   */
  async upsertToNamespace(
    namespace: string,
    vectorId: string,
    embedding: number[]
  ): Promise<void> {
    try {
      const index = await this.getIndex();
      
      // Pinecone expects records in a specific format (PineconeRecord)
      const records: PineconeRecord[] = [
        {
          id: vectorId,
          values: embedding,
        },
      ];

      // Upsert to the specific namespace
      await index.namespace(namespace).upsert(records);
      console.log(`Successfully upserted vector ${vectorId} to namespace ${namespace}`);
    } catch (error) {
      console.error(`Error upserting to Pinecone namespace ${namespace}:`, error);
      throw new Error('Failed to upsert vector');
    }
  }

  /**
   * Queries vectors within a specific namespace.
   * @param namespace - The tenant identifier.
   * @param queryVector - The query embedding vector.
   * @returns Top 5 matches.
   */
  async queryNamespace(namespace: string, queryVector: number[]): Promise<any> {
    try {
      const index = await this.getIndex();

      // Query the index within the specific namespace
      const queryResponse = await index.namespace(namespace).query({
        vector: queryVector,
        topK: 5,
        includeValues: true, // Optional: include the raw vector values in the response
      });

      return queryResponse.matches;
    } catch (error) {
      console.error(`Error querying Pinecone namespace ${namespace}:`, error);
      throw new Error('Failed to query namespace');
    }
  }
}
