/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

// app/api/chat/route.ts
import { streamText } from 'ai';
import { openai } from '@ai-sdk/openai';
import { semanticSearch } from '@/lib/search'; // Assuming this is the function from Exercise 2

// Define the tools available to the AI model
const tools = {
  semantic_search: {
    description: 'Use this tool to find relevant documents based on the user\'s query.',
    parameters: {
      type: 'object',
      properties: {
        query: {
          type: 'string',
          description: 'The search query to look up in the documentation.',
        },
      },
      required: ['query'],
    },
    // The execute function runs locally when the AI decides to call the tool
    execute: async ({ query }: { query: string }) => {
      console.log(`Tool called with query: ${query}`);
      
      // Call the semantic search logic defined in previous exercises
      // In a real app, this would hit a database or vector store
      const results = await semanticSearch(query, [
        { id: 'doc1', description: 'How to install the library' },
        { id: 'doc2', description: 'Configuration settings for the API' },
      ]);

      return {
        query,
        results,
        message: `Found ${results.length} relevant documents for "${query}".`,
      };
    },
  },
};

export async function POST(req: Request) {
  const { messages } = await req.json();

  // Stream the response from the AI model
  const result = await streamText({
    model: openai('gpt-3.5-turbo'),
    messages,
    tools,
    // Optional: Force the model to use a tool if the query is ambiguous
    // toolChoice: 'auto', 
  });

  return result.toAIStreamResponse();
}
