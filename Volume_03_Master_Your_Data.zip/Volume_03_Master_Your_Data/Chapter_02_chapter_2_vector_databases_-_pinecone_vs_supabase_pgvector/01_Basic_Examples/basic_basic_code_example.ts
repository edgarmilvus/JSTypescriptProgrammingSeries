/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * Vector Database Simulation for "Hello World" RAG Example
 * 
 * Objective: Demonstrate storing, indexing, and querying vectors using 
 * Cosine Similarity in a TypeScript environment.
 * 
 * Dependencies: None (Pure Node.js/TypeScript)
 */

// --- 1. Type Definitions ---

/**
 * Represents a single document in our vector store.
 * @property id - Unique identifier for the document.
 * @property content - The original text (for display purposes).
 * @property embedding - The numerical vector representation (array of numbers).
 */
type VectorDocument = {
    id: string;
    content: string;
    embedding: number[];
};

// --- 2. Mock Embedding Model ---

/**
 * Simulates an embedding model (e.g., OpenAI text-embedding-ada-002).
 * In reality, this would be an API call. Here, we generate a deterministic
 * vector based on the text length to simulate semantic meaning.
 * 
 * @param text - The input string to embed.
 * @returns A fixed-size array of numbers (vector).
 */
function mockEmbed(text: string): number[] {
    const vectorSize = 4; // Keeping it small for readability
    const vector: number[] = [];
    
    // Generate a deterministic vector based on character codes
    // This ensures "Hello World" produces a specific vector distinct from others
    let seed = 0;
    for (let i = 0; i < text.length; i++) {
        seed += text.charCodeAt(i);
    }

    for (let i = 0; i < vectorSize; i++) {
        // Create a pseudo-random number based on the seed and index
        const val = Math.sin(seed + i * 10) * 100 + 50;
        vector.push(parseFloat(val.toFixed(4)));
    }

    return vector;
}

// --- 3. Vector Store Operations ---

/**
 * Mock Vector Store (Simulating a PostgreSQL table with pgvector).
 * In a real app, this would be a Supabase table: `documents (id, content, embedding vector(1536))`
 */
const mockDb: VectorDocument[] = [];

/**
 * Inserts a document and its embedding into the store.
 * 
 * @param content - The text to store.
 */
function storeDocument(content: string): void {
    const embedding = mockEmbed(content);
    const doc: VectorDocument = {
        id: `doc_${mockDb.length + 1}`,
        content: content,
        embedding: embedding
    };
    mockDb.push(doc);
    console.log(`[Store] Saved document ID: ${doc.id}`);
}

/**
 * Calculates Cosine Similarity between two vectors.
 * Formula: (A . B) / (||A|| * ||B||)
 * 
 * @param vecA - The query vector.
 * @param vecB - The stored document vector.
 * @returns Similarity score between 0 and 1.
 */
function cosineSimilarity(vecA: number[], vecB: number[]): number {
    if (vecA.length !== vecB.length) {
        throw new Error("Vectors must be of the same dimension");
    }

    let dotProduct = 0;
    let normA = 0;
    let normB = 0;

    for (let i = 0; i < vecA.length; i++) {
        dotProduct += vecA[i] * vecB[i];
        normA += vecA[i] * vecA[i];
        normB += vecB[i] * vecB[i];
    }

    // Handle division by zero
    if (normA === 0 || normB === 0) return 0;

    return dotProduct / (Math.sqrt(normA) * Math.sqrt(normB));
}

/**
 * Queries the vector store for the most similar document.
 * 
 * @param queryText - The user's question.
 * @returns The top matching document and its similarity score.
 */
async function queryStore(queryText: string) {
    console.log(`\n[Query] Searching for: "${queryText}"`);
    
    // 1. Embed the query using the SAME model as the documents
    const queryVector = mockEmbed(queryText);

    // 2. Calculate similarity against all documents in the DB
    const results = mockDb.map((doc) => {
        const score = cosineSimilarity(queryVector, doc.embedding);
        return { ...doc, score };
    });

    // 3. Sort by score (descending) and pick the top result
    results.sort((a, b) => b.score - a.score);

    const topResult = results[0];

    if (topResult && topResult.score > 0.5) {
        console.log(`[Result] Found match: "${topResult.content}" (Score: ${topResult.score.toFixed(4)})`);
        return topResult;
    } else {
        console.log(`[Result] No confident match found. Best score: ${topResult ? topResult.score.toFixed(4) : 'N/A'}`);
        return null;
    }
}

// --- 4. Main Execution Flow ---

/**
 * Main entry point for the simulation.
 * This mimics a web server handling initialization and a search request.
 */
async function main() {
    console.log("--- Vector DB 'Hello World' Simulation ---");

    // A. Populate the database (Indexing Phase)
    // We store documents that are semantically related to "greetings"
    storeDocument("Hello World"); 
    storeDocument("Hi there, friend!"); 
    storeDocument("The quick brown fox jumps over the lazy dog."); // Distractor

    // B. User Interaction (Query Phase)
    // Scenario 1: Direct match
    await queryStore("Greetings world");

    // Scenario 2: Semantic match (different words, similar meaning)
    await queryStore("Hey buddy");

    // Scenario 3: Irrelevant query
    await queryStore("Weather forecast for tomorrow");
}

// Execute the script
main().catch(console.error);
