/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// pages/api/search.ts
// Next.js API Route for Hybrid Search RAG Pipeline
import type { NextApiRequest, NextApiResponse } from 'next';
import { Pool } from 'pg';

// -----------------------------------------------------------------------------
// 1. CONFIGURATION & TYPES
// -----------------------------------------------------------------------------

// Database configuration (In production, use environment variables)
const pool = new Pool({
  host: process.env.DB_HOST || 'localhost',
  port: parseInt(process.env.DB_PORT || '5432'),
  user: process.env.DB_USER || 'postgres',
  password: process.env.DB_PASSWORD || 'postgres',
  database: process.env.DB_NAME || 'vector_db_demo',
});

// Type definitions for our document chunks
interface DocumentChunk {
  id: string; // Vector ID
  content: string;
  embedding: number[];
  metadata: {
    source: string;
    page: number;
  };
}

interface SearchResult {
  id: string;
  content: string;
  source: string;
  page: number;
  hybrid_score: number; // Combined semantic + keyword score
  semantic_score: number;
  keyword_score: number;
}

// -----------------------------------------------------------------------------
// 2. MOCK UTILITIES (Simulating Text Splitting & Embeddings)
// -----------------------------------------------------------------------------

/**
 * Mocks a text splitter. In a real app, this would use a library like
 * 'langchain/textsplitters' to chunk documents intelligently.
 * @param text - The raw document text
 * @returns Array of text chunks
 */
function splitText(text: string): string[] {
  const sentences = text.split(/(?<=[.!?])\s+/);
  // Create overlapping chunks of 2-3 sentences
  const chunks: string[] = [];
  for (let i = 0; i < sentences.length; i += 2) {
    chunks.push(sentences.slice(i, i + 3).join(' '));
  }
  return chunks;
}

/**
 * Mocks a vector embedding generation.
 * In production, this would call an API (OpenAI, Cohere) or run a local model.
 * NOTE: WASM SIMD is critical here for client-side performance.
 * @param text - The text to embed
 * @returns A 1536-dimension vector (simulating OpenAI ada-002)
 */
async function generateEmbedding(text: string): Promise<number[]> {
  // Simulating async API call
  await new Promise(resolve => setTimeout(resolve, 50));
  
  // Deterministic mock vector based on string length for demo consistency
  const dim = 1536;
  const vec = new Array(dim).fill(0);
  const hash = text.length % dim;
  
  // Create a simple spike in the vector
  vec[hash] = 1.0;
  vec[(hash + 1) % dim] = 0.5;
  vec[(hash + 2) % dim] = 0.25;
  
  return vec;
}

// -----------------------------------------------------------------------------
// 3. CORE DATABASE OPERATIONS
// -----------------------------------------------------------------------------

/**
 * Upserts document chunks into the 'documents' table.
 * Uses pgvector's `embedding` column type.
 * 
 * Architecture Note: We use parameterized queries to prevent SQL injection.
 * The `ON CONFLICT` clause handles the Upsert logic based on the Vector ID.
 */
async function upsertChunks(chunks: DocumentChunk[]) {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');

    // Create table if not exists (Idempotent setup)
    await client.query(`
      CREATE TABLE IF NOT EXISTS documents (
        id TEXT PRIMARY KEY,
        content TEXT,
        embedding vector(1536),
        metadata JSONB
      );
      
      -- Create IVFFlat index for fast approximate vector search
      -- nlists = 100 is a heuristic for datasets < 1M rows
      CREATE INDEX IF NOT EXISTS idx_documents_embedding 
      ON documents 
      USING ivfflat (embedding vector_cosine_ops) 
      WITH (lists = 100);
      
      -- Create GIN index for full-text search
      CREATE INDEX IF NOT EXISTS idx_documents_content_ts 
      ON documents 
      USING gin (to_tsvector('english', content));
    `);

    // Batch upsert
    for (const chunk of chunks) {
      const query = `
        INSERT INTO documents (id, content, embedding, metadata)
        VALUES ($1, $2, $3::vector, $4)
        ON CONFLICT (id) DO UPDATE 
        SET content = EXCLUDED.content, 
            embedding = EXCLUDED.embedding, 
            metadata = EXCLUDED.metadata;
      `;
      await client.query(query, [
        chunk.id,
        chunk.content,
        JSON.stringify(chunk.embedding), // pgvector accepts JSON arrays
        JSON.stringify(chunk.metadata)
      ]);
    }

    await client.query('COMMIT');
    console.log(`Successfully upserted ${chunks.length} chunks.`);
  } catch (error) {
    await client.query('ROLLBACK');
    console.error('Error upserting chunks:', error);
    throw error;
  } finally {
    client.release();
  }
}

/**
 * Performs Hybrid Search: Vector Similarity + Full-Text Keyword Search.
 * 
 * Logic:
 * 1. Vector Score: Calculated using Cosine Distance (1 - similarity).
 * 2. Keyword Score: Calculated using `ts_rank` on the full-text index.
 * 3. Hybrid Score: Weighted sum (e.g., 0.7 * Vector + 0.3 * Keyword).
 * 
 * Why this approach?
 * Vector search is great for semantics but can miss exact keywords.
 * Keyword search is precise but lacks semantic understanding.
 * Combining them gives the best of both worlds.
 */
async function hybridSearch(queryText: string, queryEmbedding: number[], limit: number = 5): Promise<SearchResult[]> {
  const client = await pool.connect();
  
  try {
    const searchQuery = `
      WITH vector_search AS (
        SELECT 
          id,
          content,
          metadata->>'source' as source,
          metadata->>'page' as page,
          1 - (embedding <=> $1::vector) as semantic_score
        FROM documents
        ORDER BY embedding <=> $1::vector
        LIMIT 20 -- Retrieve top 20 by vector first
      ),
      keyword_search AS (
        SELECT 
          id,
          content,
          metadata->>'source' as source,
          metadata->>'page' as page,
          ts_rank(to_tsvector('english', content), plainto_tsquery('english', $2)) as keyword_score
        FROM documents
        WHERE to_tsvector('english', content) @@ plainto_tsquery('english', $2)
        ORDER BY keyword_score DESC
        LIMIT 20 -- Retrieve top 20 by keyword match
      ),
      combined AS (
        -- Inner Join: Only keep documents that appear in BOTH searches
        SELECT 
          COALESCE(v.id, k.id) as id,
          COALESCE(v.content, k.content) as content,
          COALESCE(v.source, k.source) as source,
          COALESCE(v.page, k.page) as page,
          COALESCE(v.semantic_score, 0) as semantic_score,
          COALESCE(k.keyword_score, 0) as keyword_score
        FROM vector_search v
        FULL OUTER JOIN keyword_search k ON v.id = k.id
      )
      SELECT 
        id, content, source, page, 
        semantic_score, 
        keyword_score,
        -- Weighted Hybrid Score (Tune weights based on domain)
        (semantic_score * 0.7 + (keyword_score / 10.0) * 0.3) as hybrid_score
      FROM combined
      ORDER BY hybrid_score DESC
      LIMIT $3;
    `;

    const result = await client.query(searchQuery, [
      JSON.stringify(queryEmbedding),
      queryText,
      limit
    ]);

    return result.rows.map(row => ({
      id: row.id,
      content: row.content,
      source: row.source,
      page: parseInt(row.page),
      semantic_score: parseFloat(row.semantic_score),
      keyword_score: parseFloat(row.keyword_score),
      hybrid_score: parseFloat(row.hybrid_score)
    }));

  } finally {
    client.release();
  }
}

// -----------------------------------------------------------------------------
// 4. NEXT.JS API HANDLER
// -----------------------------------------------------------------------------

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  const { action, text, id, metadata } = req.body;

  try {
    // ACTION: UPSERT
    // Used when ingesting new documents into the knowledge base
    if (action === 'upsert') {
      if (!text || !id) {
        return res.status(400).json({ error: 'Missing text or id' });
      }

      // 1. Split text into manageable chunks
      const chunks = splitText(text);
      
      // 2. Generate embeddings for each chunk
      const documentChunks: DocumentChunk[] = await Promise.all(
        chunks.map(async (chunk, index) => ({
          id: `${id}_chunk_${index}`,
          content: chunk,
          embedding: await generateEmbedding(chunk),
          metadata: metadata || { source: 'unknown', page: 0 }
        }))
      );

      // 3. Store in database
      await upsertChunks(documentChunks);
      
      return res.status(200).json({ message: 'Upsert successful', count: documentChunks.length });
    }

    // ACTION: SEARCH
    // Used when querying the knowledge base for RAG
    if (action === 'search') {
      if (!text) {
        return res.status(400).json({ error: 'Missing search query' });
      }

      // 1. Generate embedding for the query
      const queryEmbedding = await generateEmbedding(text);

      // 2. Perform Hybrid Search
      const results = await hybridSearch(text, queryEmbedding);

      return res.status(200).json({ results });
    }

    return res.status(400).json({ error: 'Invalid action' });

  } catch (error) {
    console.error('API Error:', error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
}
