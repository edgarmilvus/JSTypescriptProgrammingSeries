/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

import { createClient, SupabaseClient } from '@supabase/supabase-js';

// 1. Define the Vector Schema Interface
interface VectorData {
  id: string;
  values: number[];
  metadata: {
    documentId: string;
    chunkIndex: number;
    sourceUrl: string;
  };
}

interface SearchResult {
  id: string;
  values: number[];
  metadata: object;
}

// 2. Initialize Supabase Client (Ensure anon key is used in .env)
const SUPABASE_URL = process.env.SUPABASE_URL || 'https://your-project.supabase.co';
const SUPABASE_ANON_KEY = process.env.SUPABASE_ANON_KEY || 'your-anon-key';

const supabase: SupabaseClient = createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

// 3. Vector Service Class
class VectorService {
  private tableName = 'document_embeddings';

  /**
   * Adds a new vector or updates an existing one if the ID matches.
   * Uses Supabase's upsert functionality.
   */
  async upsertVector(id: string, values: number[], metadata: object): Promise<void> {
    try {
      const { error } = await supabase
        .from(this.tableName)
        .upsert({ 
          id, 
          embedding: values, // pgvector expects the column name to be 'embedding' usually
          metadata 
        }, { onConflict: 'id' });

      if (error) throw error;
      console.log(`Vector ${id} upserted successfully.`);
    } catch (err) {
      console.error('Error upserting vector:', err);
      throw err;
    }
  }

  /**
   * Retrieves a vector and its metadata by ID.
   */
  async getVector(id: string): Promise<SearchResult | null> {
    try {
      const { data, error } = await supabase
        .from(this.tableName)
        .select('id, embedding, metadata')
        .eq('id', id)
        .single();

      if (error) {
        if (error.code === 'PGRST116') return null; // Row not found
        throw error;
      }

      return {
        id: data.id,
        values: data.embedding,
        metadata: data.metadata
      };
    } catch (err) {
      console.error('Error getting vector:', err);
      return null;
    }
  }

  /**
   * Removes a vector by ID.
   */
  async deleteVector(id: string): Promise<void> {
    try {
      const { error } = await supabase
        .from(this.tableName)
        .delete()
        .eq('id', id);

      if (error) throw error;
      console.log(`Vector ${id} deleted successfully.`);
    } catch (err) {
      console.error('Error deleting vector:', err);
      throw err;
    }
  }

  /**
   * Lists the first n vectors, returning IDs and metadata only.
   */
  async listVectors(limit: number = 10): Promise<Array<{ id: string; metadata: object }>> {
    try {
      const { data, error } = await supabase
        .from(this.tableName)
        .select('id, metadata')
        .limit(limit);

      if (error) throw error;
      
      // Ensure data is not null
      if (!data) return [];
      
      return data.map(item => ({
        id: item.id,
        metadata: item.metadata
      }));
    } catch (err) {
      console.error('Error listing vectors:', err);
      return [];
    }
  }
}

// 4. Interactive Challenge Script
async function runExercise1() {
  const service = new VectorService();
  const mockVectors: VectorData[] = [];

  // Generate 5 mock vectors (dimension 384)
  console.log("Generating mock data...");
  for (let i = 1; i <= 5; i++) {
    mockVectors.push({
      id: `vec_${i}`,
      values: Array.from({ length: 384 }, () => Math.random()),
      metadata: {
        documentId: `doc_${i}`,
        chunkIndex: i,
        sourceUrl: `https://example.com/doc_${i}`
      }
    });
  }

  // Populate Database
  console.log("\n--- Step 1: Populating Database ---");
  for (const vec of mockVectors) {
    await service.upsertVector(vec.id, vec.values, vec.metadata);
  }

  // Retrieve One
  console.log("\n--- Step 2: Retrieve vec_1 ---");
  const retrieved = await service.getVector('vec_1');
  console.log("Retrieved:", retrieved ? `ID: ${retrieved.id}, Metadata: ${JSON.stringify(retrieved.metadata)}` : "Not found");

  // Update Metadata
  console.log("\n--- Step 3: Update vec_1 Metadata ---");
  if (retrieved) {
    const updatedMetadata = { ...retrieved.metadata, sourceUrl: 'https://example.com/updated' };
    await service.upsertVector(retrieved.id, retrieved.values, updatedMetadata);
    const checkUpdate = await service.getVector('vec_1');
    console.log("Updated Metadata:", checkUpdate?.metadata);
  }

  // Delete Another
  console.log("\n--- Step 4: Delete vec_5 ---");
  await service.deleteVector('vec_5');

  // List Remaining
  console.log("\n--- Step 5: List Remaining Vectors ---");
  const remaining = await service.listVectors(10);
  console.table(remaining);
}

// Execute (uncomment to run if environment is set up)
// runExercise1();
