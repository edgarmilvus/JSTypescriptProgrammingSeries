/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

import { createClient } from '@supabase/supabase-js';

// Initialize Client (Assuming previous setup)
const supabase = createClient(
  process.env.SUPABASE_URL || 'https://your-project.supabase.co',
  process.env.SUPABASE_ANON_KEY || 'your-anon-key'
);

// 1. Define Result Interface
interface SearchResult {
  id: string;
  score: number; // Cosine similarity score (0 to 1)
  metadata: {
    sourceUrl: string;
    snippet?: string;
  };
}

/**
 * 2. Embedding Generation
 * In a real app, use @xenova/transformers or an API like OpenAI.
 * For this exercise, we simulate the function signature and return a random vector.
 */
async function generateEmbedding(text: string): Promise<number[]> {
  console.log(`Generating embedding for text: "${text}"`);
  // Simulate async processing
  await new Promise(resolve => setTimeout(resolve, 100));
  
  // Return a random 384-dim vector (mocking the model output)
  return Array.from({ length: 384 }, () => Math.random());
}

/**
 * 3. Similarity Search Function
 * Uses pgvector's cosine operator (<=>) for distance.
 * Note: pgvector returns distance (0 to 2), where 0 is identical. 
 * We convert distance to similarity: 1 - (distance / 2).
 */
async function semanticSearch(query: string, topK: number): Promise<SearchResult[]> {
  try {
    // Step 1: Generate Query Vector
    const queryVector = await generateEmbedding(query);

    // Step 2: Query Database
    // We use the '<=>' operator which calculates cosine distance.
    // We order by the distance ascending.
    const { data, error } = await supabase.rpc('match_documents', {
      query_embedding: queryVector,
      match_count: topK
    });

    // Fallback if RPC isn't set up (Direct SQL approach):
    /*
    const { data, error } = await supabase
      .from('document_embeddings')
      .select('id, metadata, embedding')
      .order('embedding', { 
        ascending: true, 
        // Note: PostgREST doesn't natively support distance operators in 'order' 
        // easily without a computed column or RPC. 
        // Using a Stored Procedure (RPC) is the standard Supabase pattern for this.
      }) 
      .limit(topK);
    */

    if (error) throw error;
    if (!data) return [];

    // Step 3: Transform Results
    // Assuming the RPC returns { id, metadata, distance }
    return data.map((row: any) => ({
      id: row.id,
      // Convert pgvector distance (0-2) to similarity score (0-1)
      score: 1 - (row.distance / 2),
      metadata: row.metadata
    }));

  } catch (err) {
    console.error('Search failed:', err);
    return [];
  }
}

// 4. Interactive Challenge Script
async function runExercise2() {
  const query = "best practices for vector indexing";
  
  console.log(`--- Performing Semantic Search for: "${query}" ---`);
  const results = await semanticSearch(query, 3);

  console.log("\nTop 3 Results:");
  results.forEach((res, idx) => {
    console.log(`${idx + 1}. ID: ${res.id}`);
    console.log(`   Score: ${res.score.toFixed(4)}`);
    console.log(`   Source: ${res.metadata.sourceUrl}`);
  });

  // Comparison Note:
  // Dot-product search is generally faster but requires normalized vectors.
  // Cosine similarity (used here) handles vector magnitude variations better.
  // In pgvector, dot product is `<#>` and L2 distance is `<->`.
  console.log("\nNote: This solution uses Cosine Similarity (<=>) which is robust for text embeddings.");
}

// Execute
// runExercise2();

// NOTE: To make the supabase.rpc('match_documents') work, you need a SQL function in your DB:
/*
CREATE OR REPLACE FUNCTION match_documents(query_embedding vector(384), match_count int)
RETURNS TABLE(id text, metadata jsonb, distance float)
LANGUAGE sql
AS $$
  SELECT 
    id, 
    metadata, 
    embedding <=> query_embedding as distance
  FROM document_embeddings
  ORDER BY embedding <=> query_embedding
  LIMIT match_count;
$$;
*/
