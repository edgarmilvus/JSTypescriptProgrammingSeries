/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

// 3. Performance Measurement (TypeScript)
import { createClient } from '@supabase/supabase-js';

const supabase = createClient(
  process.env.SUPABASE_URL || '',
  process.env.SUPABASE_ANON_KEY || ''
);

interface PerformanceResult {
  duration: number;
  rowCount: number;
}

async function measureQueryPerformance(queryVector: number[]): Promise<PerformanceResult> {
  const startTime = performance.now();

  // We use the RPC function defined in Exercise 2, which utilizes the index automatically
  // if the query planner deems it optimal.
  const { data, error } = await supabase.rpc('match_documents', {
    query_embedding: queryVector,
    match_count: 10
  });

  const endTime = performance.now();
  const duration = endTime - startTime;

  if (error) {
    console.error("Query Error:", error);
    return { duration: 0, rowCount: 0 };
  }

  return {
    duration,
    rowCount: data ? data.length : 0
  };
}

// 4. Query Adjustment Explanation
/*
 * The 'ef_search' parameter (runtime parameter for HNSW) controls the size of the 
 * dynamic candidate list during the search phase.
 * - Higher 'ef_search': Increases accuracy (recall) but decreases search speed.
 * - Lower 'ef_search': Increases speed but may miss some nearest neighbors.
 * In pgvector, this is set via a configuration parameter, e.g., SET hnsw.ef_search = 40;
 */

// 5. Interactive Challenge: Load Test Simulation
async function runLoadTest() {
  console.log("--- Starting Load Test (100 queries) ---");
  
  // Generate 100 random query vectors
  const queries = Array.from({ length: 100 }, () => 
    Array.from({ length: 384 }, () => Math.random())
  );

  const results: PerformanceResult[] = [];

  // Measure with Index
  for (const query of queries) {
    const res = await measureQueryPerformance(query);
    results.push(res);
  }

  const avgTimeWithIndex = results.reduce((acc, curr) => acc + curr.duration, 0) / results.length;
  
  console.log(`\nAverage Query Time (WITH HNSW Index): ${avgTimeWithIndex.toFixed(2)}ms`);
  console.log("------------------------------------------------");
  console.log("| Metric               | Value                 |");
  console.log("|----------------------|-----------------------|");
  console.log(`| Avg Duration         | ${avgTimeWithIndex.toFixed(2)} ms             |`);
  console.log(`| Total Queries        | 100                   |`);
  console.log("------------------------------------------------");

  console.log("\nNote: To test WITHOUT index, you would run:");
  console.log("1. DROP INDEX idx_document_embedding_hnsw;");
  console.log("2. Run the same loop.");
  console.log("3. Compare the average times (Expect 10x-100x slower without index).");
}

// Execute
// runLoadTest();
