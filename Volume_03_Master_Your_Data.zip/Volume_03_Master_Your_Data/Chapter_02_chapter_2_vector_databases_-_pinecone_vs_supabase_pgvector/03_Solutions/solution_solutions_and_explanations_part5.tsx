/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState, useEffect } from 'react';

// 1. Define Props Interface
interface SearchResult {
  id: string;
  score: number;
  metadata: {
    sourceUrl: string;
    snippet: string;
  };
}

interface SearchResultsListProps {
  results: SearchResult[];
  isLoading: boolean;
  onSelect: (id: string) => void;
}

// 2. Helper for Score Visualization
const getRelevanceBadge = (score: number) => {
  if (score >= 0.8) return <span style={{ color: 'green', fontWeight: 'bold' }}>High</span>;
  if (score >= 0.5) return <span style={{ color: 'orange', fontWeight: 'bold' }}>Medium</span>;
  return <span style={{ color: 'red', fontWeight: 'bold' }}>Low</span>;
};

// 3. SearchResultsList Component
const SearchResultsList: React.FC<SearchResultsListProps> = ({ results, isLoading, onSelect }) => {
  if (isLoading) {
    return (
      <div className="loading-state">
        <p>Searching database...</p>
        {/* Simple spinner visualization */}
        <div style={{ border: '4px solid #f3f3f3', borderTop: '4px solid #3498db', borderRadius: '50%', width: '40px', height: '40px', animation: 'spin 1s linear infinite' }}></div>
      </div>
    );
  }

  if (results.length === 0) {
    return <div className="empty-state"><p>No results found.</p></div>;
  }

  return (
    <div className="results-grid" style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
      {results.map((result) => (
        <div 
          key={result.id} 
          onClick={() => onSelect(result.id)}
          className="result-card"
          style={{
            border: '1px solid #ddd',
            padding: '16px',
            borderRadius: '8px',
            cursor: 'pointer',
            transition: 'background 0.2s',
            boxShadow: '0 2px 4px rgba(0,0,0,0.1)'
          }}
        >
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '8px' }}>
            <a 
              href={result.metadata.sourceUrl} 
              target="_blank" 
              rel="noopener noreferrer"
              onClick={(e) => e.stopPropagation()} // Prevent triggering onSelect when clicking link
              style={{ textDecoration: 'none', color: '#007bff', fontWeight: 'bold' }}
            >
              Source Link ↗
            </a>
            <div className="relevance-score">
              Score: {result.score.toFixed(2)} ({getRelevanceBadge(result.score)})
            </div>
          </div>
          
          <p style={{ margin: 0, color: '#333', fontSize: '0.95rem' }}>
            {result.metadata.snippet.length > 150 
              ? result.metadata.snippet.substring(0, 150) + '...' 
              : result.metadata.snippet}
          </p>
        </div>
      ))}
    </div>
  );
};

// 4. Parent Component (SearchPage)
const SearchPage: React.FC = () => {
  const [results, setResults] = useState<SearchResult[]>([]);
  const [loading, setLoading] = useState(false);

  const simulateSearch = () => {
    setLoading(true);
    setResults([]);
    
    // Simulate network delay
    setTimeout(() => {
      const mockData: SearchResult[] = [
        { 
          id: '1', 
          score: 0.92, 
          metadata: { 
            sourceUrl: 'https://example.com/doc1', 
            snippet: 'HNSW indexing provides fast approximate nearest neighbor search by constructing a multi-layer graph structure.' 
          } 
        },
        { 
          id: '2', 
          score: 0.75, 
          metadata: { 
            sourceUrl: 'https://example.com/doc2', 
            snippet: 'Vector databases store embeddings efficiently. Optimization involves choosing the right distance metric.' 
          } 
        },
        { 
          id: '3', 
          score: 0.60, 
          metadata: { 
            sourceUrl: 'https://example.com/doc3', 
            snippet: 'PostgreSQL with pgvector extension allows storing vectors directly in the database.' 
          } 
        }
      ];
      setResults(mockData);
      setLoading(false);
    }, 2000);
  };

  const handleSelect = (id: string) => {
    console.log(`User selected result ID: ${id}`);
    // In a real app, you might navigate to the detail page or highlight the item
  };

  return (
    <div style={{ padding: '20px', maxWidth: '800px', margin: '0 auto' }}>
      <h1>Semantic Search</h1>
      <button onClick={simulateSearch} disabled={loading} style={{ padding: '10px 20px', marginBottom: '20px' }}>
        {loading ? 'Searching...' : 'Run Search Simulation'}
      </button>
      
      <SearchResultsList 
        results={results} 
        isLoading={loading} 
        onSelect={handleSelect} 
      />
    </div>
  );
};

export default SearchPage;
