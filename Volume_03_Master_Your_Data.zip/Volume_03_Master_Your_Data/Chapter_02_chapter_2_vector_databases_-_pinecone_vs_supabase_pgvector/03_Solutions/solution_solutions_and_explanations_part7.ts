/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part7.ts
// Description: Solutions and Explanations
// ==========================================

import { createClient } from '@supabase/supabase-js';

const supabase = createClient(
  process.env.SUPABASE_URL || '',
  process.env.SUPABASE_ANON_KEY || ''
);

// 2. Hybrid Search Interface
interface HybridResult {
  id: string;
  finalScore: number;
  metadata: object;
  vectorScore: number;
  textRank: number;
}

/**
 * 3. Hybrid Search Function
 * Combines Vector Similarity and Full-Text Search
 */
async function hybridSearch(query: string, topK: number): Promise<HybridResult[]> {
  // Step 1: Generate Query Vector (Mocked from Exercise 2)
  const queryVector = Array.from({ length: 384 }, () => Math.random());

  // Step 2: Fetch Candidates (Top 20 from Vector Search)
  // We fetch more than topK to have enough data to re-rank
  const { data: vectorData, error: vectorError } = await supabase.rpc('match_documents', {
    query_embedding: queryVector,
    match_count: 20 
  });

  if (vectorError) throw vectorError;

  // Step 3: Fetch Candidates (Top 20 from Full-Text Search)
  // Using ts_rank to order by relevance
  const { data: textData, error: textError } = await supabase
    .from('document_embeddings')
    .select('id, metadata')
    .textSearch('search_tsv', query, {
      type: 'websearch', // handles operators like AND, OR, quotes
      config: 'english'
    })
    .limit(20);

  if (textError) throw textError;

  // Step 4: Combine and Score
  // Map to store intermediate scores
  const scoreMap = new Map<string, { vector: number; text: number; meta: object }>();

  // Normalize Vector Scores (Cosine Distance 0-2 -> Score 0-1)
  if (vectorData) {
    vectorData.forEach((item: any) => {
      const score = 1 - (item.distance / 2);
      scoreMap.set(item.id, { vector: score, text: 0, meta: item.metadata });
    });
  }

  // Normalize Text Scores (ts_rank returns a float, usually 0-1 but can vary)
  // We need to normalize based on the max rank in the result set for fair weighting
  if (textData && textData.length > 0) {
    // Since Supabase JS client doesn't return raw ts_rank by default without a computed column,
    // we simulate the rank calculation or assume a computed column 'rank' exists.
    // For this example, we will assign a linear score based on position (1.0 for first, 0.8 for second...)
    // In a real app, use: .select('id, metadata, ts_rank(search_tsv, query) as rank')
    
    textData.forEach((item: any, index: number) => {
      // Mock rank calculation for demonstration
      const mockRank = 1.0 - (index * 0.05); 
      const existing = scoreMap.get(item.id);
      if (existing) {
        existing.text = mockRank;
      } else {
        scoreMap.set(item.id, { vector: 0, text: mockRank, meta: item.metadata });
      }
    });
  }

  // Apply Weighted Scoring
  const combinedResults: HybridResult[] = [];
  scoreMap.forEach((scores, id) => {
    // Normalize scores to 0-1 range if not already
    const normVector = Math.max(0, Math.min(1, scores.vector));
    const normText = Math.max(0, Math.min(1, scores.text));

    // Weighted Algorithm: 70% Vector, 30% Text
    const finalScore = (0.7 * normVector) + (0.3 * normText);

    combinedResults.push({
      id,
      finalScore,
      metadata: scores.meta,
      vectorScore: normVector,
      textRank: normText
    });
  });

  // Step 5: Sort and Return TopK
  return combinedResults
    .sort((a, b) => b.finalScore - a.finalScore)
    .slice(0, topK);
}

// 4. Interactive Challenge Script
async function runExercise5() {
  const query = "best HNSW indexing practices"; // Contains specific term "HNSW"
  
  console.log(`--- Hybrid Search for: "${query}" ---`);
  
  try {
    const results = await hybridSearch(query, 3);

    console.log("\nHybrid Search Results (Weighted 0.7 Vector / 0.3 Text):");
    results.forEach((res, idx) => {
      console.log(`${idx + 1}. ID: ${res.id}`);
      console.log(`   Final Score: ${res.finalScore.toFixed(4)}`);
      console.log(`   (Vector: ${res.vectorScore.toFixed(2)}, Text: ${res.textRank.toFixed(2)})`);
    });

    console.log("\nAnalysis:");
    console.log("1. Pure Semantic Search might miss 'HNSW' if the embedding is generic.");
    console.log("2. Pure Keyword Search might miss conceptual matches like 'approximate neighbor'.");
    console.log("3. Hybrid ensures specific terminology (HNSW) is boosted while context is preserved.");
  } catch (err) {
    console.error(err);
  }
}

// Execute
// runExercise5();
