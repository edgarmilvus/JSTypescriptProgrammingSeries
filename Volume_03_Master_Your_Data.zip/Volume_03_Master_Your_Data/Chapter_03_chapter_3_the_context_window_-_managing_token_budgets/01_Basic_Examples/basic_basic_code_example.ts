/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

// app/api/chat/route.ts
// This file represents a Next.js App Router API Route Handler.
// It runs exclusively on the server.

import { NextRequest, NextResponse } from 'next/server';
import OpenAI from 'openai';

// 1. CONFIGURATION & TYPES
// --------------------------------------------------------------------------------
// In a real app, these would come from your database schema (e.g., Prisma, Drizzle).
interface ChatMessage {
  role: 'user' | 'assistant';
  content: string;
}

interface ProjectContext {
  id: string;
  name: string;
  description: string;
  recentActivity: string;
}

// Initialize the OpenAI client.
const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

/**
 * 2. MOCK DATA FETCHING (Simulating Database Calls)
 * --------------------------------------------------------------------------------
 * In a production RAG system, these functions would query a vector database
 * or a relational database. Here, we simulate fetching data to keep the example
 * self-contained.
 */
async function fetchUserConversationHistory(userId: string): Promise<ChatMessage[]> {
  // Simulate a database query delay
  await new Promise(resolve => setTimeout(resolve, 50));
  
  // Mock data: Returning a short history to provide context
  return [
    { role: 'user', content: 'I want to analyze the sales data for Q3.' },
    { role: 'assistant', content: 'Sure, I have retrieved the Q3 sales report for you.' },
  ];
}

async function fetchRelevantProjectContext(query: string): Promise<ProjectContext | null> {
  // Simulate a vector database search.
  // In a real scenario, the 'query' would be embedded and compared against vector embeddings.
  // We are mocking a match based on keywords.
  
  if (query.toLowerCase().includes('sales')) {
    return {
      id: 'proj_123',
      name: 'Q3 Sales Analysis',
      description: 'A comprehensive breakdown of regional sales performance.',
      recentActivity: 'Report generated 2 days ago.',
    };
  }
  return null;
}

/**
 * 3. THE CORE LOGIC: CONTEXT AUGMENTATION
 * --------------------------------------------------------------------------------
 * This function orchestrates the data fetching and prompt construction.
 */
async function performContextAugmentation(
  userQuery: string,
  userId: string
): Promise<{ systemPrompt: string; contextSummary: string }> {
  
  // Step A: Fetch independent data sources in parallel for efficiency.
  // This is crucial for minimizing latency in production.
  const [history, project] = await Promise.all([
    fetchUserConversationHistory(userId),
    fetchRelevantProjectContext(userQuery),
  ]);

  // Step B: Format the context into a structured string.
  // This is the "Augmentation" step. We are injecting raw text data 
  // into the prompt structure.
  
  let contextString = '';
  
  if (history.length > 0) {
    const historyText = history.map(m => `${m.role}: ${m.content}`).join('\n');
    contextString += `Recent Conversation History:\n${historyText}\n\n`;
  }

  if (project) {
    contextString += `Relevant Project Context:\n`;
    contextString += `ID: ${project.id}\n`;
    contextString += `Name: ${project.name}\n`;
    contextString += `Description: ${project.description}\n`;
    contextString += `Recent Activity: ${project.recentActivity}\n`;
  }

  // Step C: Construct the final System Prompt.
  // We explicitly instruct the model to use the provided context.
  const systemPrompt = `
    You are a helpful AI assistant for a SaaS analytics platform.
    You are having a conversation with a user.
    
    Here is the relevant context retrieved from the database:
    ----------------------------------------
    ${contextString || 'No specific context found.'}
    ----------------------------------------
    
    Instructions:
    1. Answer the user's question based strictly on the context provided above.
    2. If the context does not contain the answer, politely state that you don't have the information.
    3. Keep your answers concise and relevant to the SaaS domain.
  `;

  return { systemPrompt, contextSummary: contextString };
}

/**
 * 4. NEXT.JS API ROUTE HANDLER
 * --------------------------------------------------------------------------------
 * Handles the incoming HTTP request from the client.
 */
export async function POST(request: NextRequest) {
  try {
    // Parse the incoming JSON body
    const { message, userId } = await request.json();

    if (!message || !userId) {
      return NextResponse.json(
        { error: 'Missing message or userId' },
        { status: 400 }
      );
    }

    // Perform the Context Augmentation step
    const { systemPrompt } = await performContextAugmentation(message, userId);

    // Call the LLM with the augmented prompt
    const completion = await openai.chat.completions.create({
      model: 'gpt-3.5-turbo', // Use a model that supports function calling if needed
      messages: [
        { role: 'system', content: systemPrompt },
        { role: 'user', content: message },
      ],
      temperature: 0.2, // Lower temperature for factual consistency
      stream: false, // Set to true for streaming, but we keep it simple here
    });

    // Return the generated response
    const responseContent = completion.choices[0].message.content;

    return NextResponse.json({
      response: responseContent,
      contextUsed: systemPrompt, // Exposing this for debugging/learning purposes
    });

  } catch (error) {
    console.error('Error in chat API:', error);
    return NextResponse.json(
      { error: 'Internal Server Error' },
      { status: 500 }
    );
  }
}
