/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

/**
 * ==============================================================================
 * ADVANCED CONTEXT WINDOW MANAGER (Next.js Server Component Logic)
 * ==============================================================================
 * 
 * This script simulates a production-grade RAG pipeline that enforces a 
 * "Token Budget". It prevents context overflow by dynamically selecting 
 * the most relevant data chunks that fit within a specified limit.
 * 
 * Scenario: A SaaS "Enterprise Search" tool allowing users to query 
 * internal documentation.
 */

// -----------------------------------------------------------------------------
// 1. TYPE DEFINITIONS & CONFIGURATION
// -----------------------------------------------------------------------------

/**
 * Represents a single chunk of data retrieved from a Vector Database.
 * In a real scenario, this comes from Pinecone, Weaviate, or MongoDB Atlas.
 */
type VectorChunk = {
  id: string;
  content: string;
  sourceDocument: string;
  relevanceScore: number;
};

/**
 * Configuration for our context management strategy.
 */
const CONTEXT_CONFIG = {
  // The hard limit of tokens the LLM can accept (e.g., GPT-4 Turbo 128k)
  MAX_CONTEXT_TOKENS: 4000, 
  
  // A safety buffer to account for the user query and system prompt overhead
  SAFETY_BUFFER: 200,       
  
  // Average tokens per character estimate (Standard English: 1 char ~= 0.75 tokens)
  TOKENS_PER_CHAR: 0.75,    
};

// -----------------------------------------------------------------------------
// 2. HELPER UTILITIES (Token Estimation)
// -----------------------------------------------------------------------------

/**
 * Estimates the token count for a given string.
 * 
 * Why: We cannot send every retrieved chunk to the LLM to ask "how many tokens 
 * are you?". We must estimate locally to make budgeting decisions.
 * 
 * How: A simple heuristic: `characters * factor`. For production, use 
 * specialized libraries like `gpt-tokenizer` or `tiktoken`.
 */
function estimateTokenCount(text: string): number {
  return Math.ceil(text.length * CONTEXT_CONFIG.TOKENS_PER_CHAR);
}

// -----------------------------------------------------------------------------
// 3. MOCK DATA LAYER (Simulating Vector DB)
// -----------------------------------------------------------------------------

/**
 * Simulates an asynchronous call to a Vector Database (e.g., Pinecone).
 * In a real app, this would be `await db.vector.search(queryEmbedding)`.
 */
async function fetchRelevantChunks(query: string): Promise<VectorChunk[]> {
  // Simulating a search that returns MORE results than we can fit in the context
  return [
    { 
      id: "chunk_1", 
      content: "The quarterly revenue increased by 15% driven by enterprise adoption.", 
      sourceDocument: "Q3_Financials.pdf", 
      relevanceScore: 0.95 
    },
    { 
      id: "chunk_2", 
      content: "Server latency metrics show a degradation in the US-East region. Average response time is now 450ms.", 
      sourceDocument: "Infrastructure_Report.md", 
      relevanceScore: 0.92 
    },
    { 
      id: "chunk_3", 
      content: "User retention rates for the mobile app dropped by 2% in October. Analysis suggests onboarding friction.", 
      sourceDocument: "Product_Analytics.pdf", 
      relevanceScore: 0.88 
    },
    { 
      id: "chunk_4", 
      content: "The engineering team decided to migrate from Webpack to Vite for better build times. This is a long paragraph explaining the technical details of the migration, including configuration changes, plugin compatibility, and the expected 3x improvement in hot module replacement speeds. This chunk consumes significant token budget.", 
      sourceDocument: "Engineering_Decisions.md", 
      relevanceScore: 0.85 
    },
    { 
      id: "chunk_5", 
      content: "Marketing budget for Q4 is allocated primarily to digital channels.", 
      sourceDocument: "Marketing_Strategy.docx", 
      relevanceScore: 0.80 
    }
  ];
}

// -----------------------------------------------------------------------------
// 4. CORE LOGIC: THE CONTEXT ORCHESTRATOR
// -----------------------------------------------------------------------------

/**
 * Selects the optimal set of chunks that fits within the token budget.
 * 
 * Logic:
 * 1. Calculate available budget (Max - Safety Buffer).
 * 2. Sort chunks by relevance (descending).
 * 3. Iterate: Check if adding the next chunk exceeds the budget.
 * 4. If it fits, add it and deduct cost. If not, stop or attempt compression.
 * 
 * This ensures we never hit the LLM's hard limit with a truncated message.
 */
function selectChunksWithinBudget(
  chunks: VectorChunk[], 
  userQuery: string
): { selected: VectorChunk[]; totalTokens: number } {
  
  // Calculate base cost (System prompt + User Query)
  const basePrompt = `System: You are a helpful assistant.\nUser: ${userQuery}`;
  let currentTokenUsage = estimateTokenCount(basePrompt);
  
  const availableBudget = CONTEXT_CONFIG.MAX_CONTEXT_TOKENS 
                        - CONTEXT_CONFIG.SAFETY_BUFFER;
  
  const selectedChunks: VectorChunk[] = [];

  // Sort by relevance score (highest first) to prioritize quality data
  const sortedChunks = chunks.sort((a, b) => b.relevanceScore - a.relevanceScore);

  for (const chunk of sortedChunks) {
    const chunkTokenCost = estimateTokenCount(chunk.content);

    // Check if adding this chunk respects the budget
    if (currentTokenUsage + chunkTokenCost <= availableBudget) {
      selectedChunks.push(chunk);
      currentTokenUsage += chunkTokenCost;
    } else {
      // We have filled the budget. 
      // In advanced scenarios, we might try to "compress" this specific chunk here.
      // For now, we stop to prioritize the most relevant data.
      break;
    }
  }

  return {
    selected: selectedChunks,
    totalTokens: currentTokenUsage
  };
}

/**
 * Constructs the final prompt for the LLM (Context Augmentation).
 * 
 * This function handles the formatting to ensure the model understands
 * the distinction between instructions, context, and the question.
 */
function buildAugmentedContext(
  query: string,
  selectedChunks: VectorChunk[]
): string {
  // Header
  let prompt = "You are an AI assistant answering questions based strictly on the provided context.\n\n";
  
  // Context Section
  prompt += "--- CONTEXT START ---\n";
  if (selectedChunks.length === 0) {
    prompt += "No relevant context found within token budget.\n";
  } else {
    selectedChunks.forEach((chunk) => {
      // We inject metadata (Source) to help the LLM cite sources
      prompt += `[Source: ${chunk.sourceDocument}]\n${chunk.content}\n\n`;
    });
  }
  prompt += "--- CONTEXT END ---\n\n";

  // User Query
  prompt += `User Question: "${query}"\n\nPlease provide a concise answer based on the context above.`;

  return prompt;
}

// -----------------------------------------------------------------------------
// 5. MAIN EXECUTION FLOW (Server Component Entry Point)
// -----------------------------------------------------------------------------

/**
 * The main function simulating a Next.js Server Component `page.tsx` or `route.ts`.
 * 
 * In a real Next.js App Router setup:
 * 1. This function would be `async` and marked `'use server'`.
 * 2. It would receive the `query` from a Client Component form action.
 * 3. It performs the heavy lifting (DB fetch + Budgeting) on the server.
 * 4. It returns the final prompt to the client, or streams the LLM response.
 */
export async function handleEnterpriseSearch(query: string) {
  console.log(`[System] Received query: "${query}"`);
  console.log(`[System] Token Budget: ${CONTEXT_CONFIG.MAX_CONTEXT_TOKENS}`);

  // Step 1: Data Fetching (Simulated Vector DB Search)
  const rawRetrievedChunks = await fetchRelevantChunks(query);
  console.log(`[Retrieval] Found ${rawRetrievedChunks.length} candidates.`);

  // Step 2: Budgeting & Selection (The "Context Window" Management)
  const { selected, totalTokens } = selectChunksWithinBudget(rawRetrievedChunks, query);
  console.log(`[Budgeting] Selected ${selected.length} chunks. Estimated usage: ${totalTokens} tokens.`);

  // Step 3: Context Augmentation (Prompt Engineering)
  const finalPrompt = buildAugmentedContext(query, selected);
  
  // Step 4: LLM Interaction (Simulated)
  // In production: const response = await openai.chat.completions.create({ model: 'gpt-4', messages: [{ role: 'user', content: finalPrompt }] });
  
  return {
    success: true,
    stats: {
      candidates: rawRetrievedChunks.length,
      selected: selected.length,
      estimatedTokens: totalTokens,
      budgetUtilization: ((totalTokens / CONTEXT_CONFIG.MAX_CONTEXT_TOKENS) * 100).toFixed(2) + "%"
    },
    finalPrompt
  };
}

// --- EXECUTION EXAMPLE (For demonstration purposes) ---
// (In a real app, this is triggered by an HTTP request)
(async () => {
  const result = await handleEnterpriseSearch("What is our current revenue status and server latency?");
  
  console.log("\n=== FINAL RESULT ===");
  console.log(JSON.stringify(result.stats, null, 2));
  console.log("\n--- Generated Prompt (Preview) ---");
  console.log(result.finalPrompt.substring(0, 300) + "...");
})();
