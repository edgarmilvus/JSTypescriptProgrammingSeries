/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// types.ts
export interface ChunkingConfig {
  maxTokensPerChunk: number;
  overlapTokens: number;
  tokenizerModel?: 'gpt-3.5-turbo' | 'gpt-4';
}

// chunkDocument.ts
export async function chunkDocument(
  content: string,
  config: ChunkingConfig
): Promise<string[]> {
  const { maxTokensPerChunk, overlapTokens } = config;
  
  // 1. Define a tokenizer estimation function (4 chars/token heuristic)
  const estimateTokens = (text: string): number => Math.ceil(text.length / 4);

  // 2. Split content into semantic units (paragraphs -> sentences)
  // We split by double newlines first to preserve paragraph structure
  const paragraphs = content.split(/\n\s*\n/).filter(p => p.trim().length > 0);
  
  const chunks: string[] = [];
  let currentChunk = "";
  let currentTokenCount = 0;

  // Helper to split a sentence that is too large
  const forceSplitSentence = (text: string): string[] => {
    // Split by whitespace to avoid breaking words in the middle if possible
    const words = text.split(/\s+/);
    const segments: string[] = [];
    let currentSegment = "";
    
    for (const word of words) {
      const testSegment = currentSegment ? `${currentSegment} ${word}` : word;
      if (estimateTokens(testSegment) > maxTokensPerChunk) {
        if (currentSegment) segments.push(currentSegment);
        currentSegment = word;
      } else {
        currentSegment = testSegment;
      }
    }
    if (currentSegment) segments.push(currentSegment);
    return segments;
  };

  // 3. Process semantic units
  for (const paragraph of paragraphs) {
    // Split paragraph into sentences (keeping delimiters for context)
    const sentences = paragraph.match(/[^.!?]+[.!?]+/g) || [paragraph];

    for (const sentence of sentences) {
      const sentenceTokens = estimateTokens(sentence);

      // Case A: Sentence fits in current chunk
      if (currentTokenCount + sentenceTokens <= maxTokensPerChunk) {
        currentChunk += (currentChunk ? " " : "") + sentence;
        currentTokenCount += sentenceTokens;
      } 
      // Case B: Sentence is too large for a fresh empty chunk (Force Split)
      else if (currentTokenCount === 0 && sentenceTokens > maxTokensPerChunk) {
        const splitParts = forceSplitSentence(sentence);
        for (const part of splitParts) {
          // If adding this part exceeds limit, push current and start new
          if (currentTokenCount + estimateTokens(part) > maxTokensPerChunk) {
            if (currentChunk) chunks.push(currentChunk);
            currentChunk = part;
            currentTokenCount = estimateTokens(part);
          } else {
            currentChunk += (currentChunk ? " " : "") + part;
            currentTokenCount += estimateTokens(part);
          }
        }
      }
      // Case C: Sentence doesn't fit in current chunk, but fits in a new one
      else {
        // Push the accumulated chunk
        if (currentChunk) chunks.push(currentChunk);
        
        // Start new chunk with the sentence
        currentChunk = sentence;
        currentTokenCount = sentenceTokens;
      }
    }

    // Ensure we don't lose the last paragraph's accumulated text
    // but respect the chunk limit before moving to next paragraph
    if (currentChunk && currentTokenCount > 0) {
       // We keep accumulating unless we hit the limit explicitly
       // However, to maintain strict boundaries, we usually finalize chunks 
       // when switching paragraphs to avoid merging unrelated topics.
       // For this implementation, we will finalize the chunk at paragraph end
       // if it pushes us over a reasonable threshold, or just keep it simple:
       // Push the current chunk and reset for the next paragraph.
       chunks.push(currentChunk);
       currentChunk = "";
       currentTokenCount = 0;
    }
  }

  // Catch any remaining text
  if (currentChunk) {
    chunks.push(currentChunk);
  }

  // 4. Apply Overlap Logic
  if (overlapTokens > 0 && chunks.length > 1) {
    const overlappedChunks: string[] = [];
    
    for (let i = 0; i < chunks.length; i++) {
      let current = chunks[i];
      
      // If not the first chunk, prepend overlap from previous
      if (i > 0) {
        const prevChunk = chunks[i - 1];
        const prevWords = prevChunk.split(/\s+/);
        
        // Estimate words needed for overlap (approximate heuristic)
        // We want to grab enough words from the end of the previous chunk
        // to roughly match overlapTokens.
        let overlapText = "";
        let tokensAdded = 0;
        
        // Iterate backwards through previous chunk's words
        for (let j = prevWords.length - 1; j >= 0; j--) {
          const word = prevWords[j];
          const wordTokens = estimateTokens(word + " ");
          
          if (tokensAdded + wordTokens > overlapTokens) break;
          
          overlapText = word + " " + overlapText;
          tokensAdded += wordTokens;
        }

        // Edge Case Handling: Semantic Continuity
        // If the overlap region spans a semantic break (e.g., ends in a period),
        // we ensure we include the full sentence from the previous chunk 
        // to avoid cutting a thought in half.
        const lastPeriodIndex = prevChunk.lastIndexOf('.');
        if (lastPeriodIndex > -1) {
            // If the calculated overlap starts before the last sentence ended,
            // we might be cutting a sentence. 
            // In this simple implementation, we rely on the word-based overlap
            // which usually preserves sentence structure if the overlap size is reasonable.
        }

        current = overlapText.trim() + " " + current;
      }
      
      overlappedChunks.push(current);
    }
    return overlappedChunks;
  }

  return chunks;
}
