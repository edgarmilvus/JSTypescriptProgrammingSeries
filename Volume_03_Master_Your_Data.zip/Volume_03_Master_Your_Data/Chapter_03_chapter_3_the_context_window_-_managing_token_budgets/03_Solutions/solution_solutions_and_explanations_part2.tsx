/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.tsx
// Description: Solutions and Explanations
// ==========================================

// RetrievalVisualizer.tsx
import React, { useState, Suspense, useMemo } from 'react';

interface RetrievedItem {
  id: string;
  content: string;
  score: number;
  tokenCount: number;
}

interface RetrievalVisualizerProps {
  results: RetrievedItem[];
  maxContextTokens: number;
}

// Helper component for Suspense simulation
const RetrievalVisualizerContent: React.FC<RetrievalVisualizerProps> = ({ 
  results, 
  maxContextTokens 
}) => {
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());

  // Calculate total tokens of selected items
  const totalTokens = useMemo(() => {
    return results
      .filter(item => selectedIds.has(item.id))
      .reduce((sum, item) => sum + item.tokenCount, 0);
  }, [results, selectedIds]);

  // Toggle selection logic
  const toggleItem = (id: string) => {
    const newSelected = new Set(selectedIds);
    if (newSelected.has(id)) {
      newSelected.delete(id);
    } else {
      newSelected.add(id);
    }
    setSelectedIds(newSelected);
  };

  // Smart Select Algorithm
  const handleSmartSelect = () => {
    // 1. Filter items that individually fit in the remaining budget
    const remainingBudget = maxContextTokens - totalTokens;
    
    // 2. Sort remaining unselected items by score (descending)
    const availableItems = results
      .filter(item => !selectedIds.has(item.id) && item.tokenCount <= remainingBudget)
      .sort((a, b) => b.score - a.score);

    if (availableItems.length === 0 && remainingBudget > 0) {
      // Check if any item exists that fits in the TOTAL budget (fresh start scenario)
      const anyFit = results.some(item => item.tokenCount <= maxContextTokens);
      if (!anyFit) {
        alert("No single item fits within the total token budget.");
        return;
      }
      alert("No additional items fit within the remaining budget.");
      return;
    }

    // 3. Greedily add items until budget is exhausted
    const newSelected = new Set(selectedIds);
    let currentBudget = remainingBudget;

    for (const item of availableItems) {
      if (item.tokenCount <= currentBudget) {
        newSelected.add(item.id);
        currentBudget -= item.tokenCount;
      }
    }

    setSelectedIds(newSelected);
  };

  // Visual indicators
  const usagePercentage = (totalTokens / maxContextTokens) * 100;
  const isOverBudget = totalTokens > maxContextTokens;
  const barColor = isOverBudget ? 'bg-red-500' : (usagePercentage > 80 ? 'bg-yellow-500' : 'bg-green-500');

  return (
    <div className="p-4 border rounded-lg space-y-4">
      <div className="flex justify-between items-center">
        <h2 className="text-xl font-bold">Retrieval Visualizer</h2>
        <button 
          onClick={handleSmartSelect}
          className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 disabled:opacity-50"
        >
          Smart Select
        </button>
      </div>

      {/* Token Budget Bar */}
      <div className="space-y-1">
        <div className="flex justify-between text-sm text-gray-600">
          <span>Token Usage</span>
          <span>{totalTokens} / {maxContextTokens} tokens</span>
        </div>
        <div className="w-full bg-gray-200 rounded-full h-4 overflow-hidden">
          <div 
            className={`h-full transition-all duration-300 ${barColor}`}
            style={{ width: `${Math.min(usagePercentage, 100)}%` }}
          ></div>
        </div>
        {isOverBudget && <p className="text-red-600 text-sm font-bold">Over Budget!</p>}
      </div>

      {/* Results List */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {results.map(item => {
          const isSelected = selectedIds.has(item.id);
          return (
            <div 
              key={item.id}
              className={`p-3 border rounded cursor-pointer transition-colors ${
                isSelected ? 'border-blue-500 bg-blue-50' : 'border-gray-200 bg-white'
              }`}
              onClick={() => toggleItem(item.id)}
            >
              <div className="flex justify-between items-start mb-2">
                <span className={`px-2 py-1 text-xs rounded ${
                  item.score > 0.8 ? 'bg-green-100 text-green-800' : 
                  item.score > 0.5 ? 'bg-yellow-100 text-yellow-800' : 'bg-gray-100 text-gray-800'
                }`}>
                  Score: {item.score.toFixed(2)}
                </span>
                <span className="text-xs text-gray-500">{item.tokenCount} tokens</span>
              </div>
              <p className="text-sm text-gray-700 line-clamp-3">
                {item.content}
              </p>
              <div className="mt-2 text-xs text-blue-600">
                {isSelected ? 'Selected' : 'Click to select'}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

// Main Component with Suspense Wrapper
const RetrievalVisualizer: React.FC<RetrievalVisualizerProps> = (props) => {
  return (
    <Suspense fallback={<div className="p-4 text-center text-gray-500">Loading retrieval data...</div>}>
      <RetrievalVisualizerContent {...props} />
    </Suspense>
  );
};

export default RetrievalVisualizer;
