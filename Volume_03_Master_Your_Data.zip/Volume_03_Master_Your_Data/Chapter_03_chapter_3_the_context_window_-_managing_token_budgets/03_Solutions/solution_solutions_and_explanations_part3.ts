/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

// conversationManager.ts

interface Message {
  role: 'user' | 'assistant' | 'system';
  content: string;
}

// Mock LLM function for summarization
async function summarizeLLM(text: string): Promise<string> {
  // In a real app, this calls an LLM (e.g., gpt-3.5-turbo)
  // For simulation, we just return a truncated string
  console.log("Triggering Summarization...");
  return `[System Summary]: Context of previous conversation involving ${text.length} chars condensed.`;
}

export class ConversationManager {
  private history: Message[] = [];
  private readonly MAX_HISTORY_TOKENS = 3000;

  constructor(private systemPrompt?: string) {
    if (systemPrompt) {
      this.history.push({ role: 'system', content: systemPrompt });
    }
  }

  // Helper to estimate tokens (4 chars/token heuristic)
  private estimateTokens(text: string): number {
    return Math.ceil(text.length / 4);
  }

  private getTotalTokens(): number {
    return this.history.reduce((acc, msg) => acc + this.estimateTokens(msg.content), 0);
  }

  public async addMessage(role: 'user' | 'assistant', content: string): Promise<void> {
    const newMessage: Message = { role, content };
    const newMessageTokens = this.estimateTokens(content);
    const currentTotal = this.getTotalTokens();

    // Check if adding the new message exceeds the limit
    if (currentTotal + newMessageTokens > this.MAX_HISTORY_TOKENS) {
      await this.performSummarization();
    }

    this.history.push(newMessage);
  }

  private async performSummarization(): Promise<void> {
    // 1. Identify oldest messages to summarize
    // We exclude the system prompt (index 0) if it exists
    const startIndex = this.history[0]?.role === 'system' ? 1 : 0;
    
    // If there's nothing to summarize (only system prompt or empty), return
    if (this.history.length <= startIndex) return;

    // 2. Extract content to summarize
    // Strategy: Summarize the oldest 50% of the conversation to free up significant space
    const messagesToSummarize = this.history.slice(startIndex, Math.ceil(this.history.length / 2));
    const textToSummarize = messagesToSummarize.map(m => `${m.role}: ${m.content}`).join('\n');

    // 3. Call LLM (Mocked)
    const summaryContent = await summarizeLLM(textToSummarize);

    // 4. Replace old messages with the summary
    // Create the new summary message
    const summaryMessage: Message = { role: 'system', content: summaryContent };

    // Keep the system prompt (if exists) + New Summary + Remaining recent messages
    const remainingMessages = this.history.slice(Math.ceil(this.history.length / 2));
    
    if (startIndex === 1) {
        // If system prompt existed, keep it
        this.history = [this.history[0], summaryMessage, ...remainingMessages];
    } else {
        this.history = [summaryMessage, ...remainingMessages];
    }
  }

  public getHistory(): Message[] {
    return this.history;
  }
  
  public getTokenCount(): number {
      return this.getTotalTokens();
  }
}
