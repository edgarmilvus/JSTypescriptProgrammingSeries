/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.tsx
// Description: Solutions and Explanations
// ==========================================

// app/chat/page.tsx
'use client';

import { useAIState, useUIState } from 'ai/rsc';
import { useState } from 'react';
import { AI } from './ai'; // Assuming AI provider setup is in ./ai.ts

// Message Component for UI
const Message = ({ content, type }: { content: string; type: 'user' | 'assistant' | 'reasoning' }) => {
  if (type === 'reasoning') {
    return (
      <div className="bg-gray-100 text-gray-600 text-xs p-2 rounded font-mono italic">
        Reasoning: {content}
      </div>
    );
  }
  return (
    <div className={`p-3 rounded-lg ${type === 'user' ? 'bg-blue-100 ml-4' : 'bg-green-100 mr-4'}`}>
      {content}
    </div>
  );
};

export default function Chat() {
  const [messages, setMessages] = useUIState<typeof AI>();
  const [aiState, setAiState] = useAIState<typeof AI>();
  const [showReasoning, setShowReasoning] = useState(false);
  const [input, setInput] = useState("");

  // 1. Handle User Input & Stream Parsing
  const handleSendMessage = async () => {
    if (!input) return;

    // Add user message to UI and AI State
    setMessages(prev => [...prev, <Message key={Date.now()} content={input} type="user" />]);
    setAiState(prev => ({ ...prev, messages: [...prev.messages, { role: 'user', content: input }] }));

    // Clear input
    setInput("");

    // Call the AI action (assuming defined in AI provider)
    // The AI action returns a stream. We need to parse it.
    // For this example, we simulate the streaming logic within the component 
    // or assume the AI provider handles the stream and returns components.
    
    // SIMULATION OF STREAM LOGIC:
    const streamResponse = await fetch('/api/chat', { 
        method: 'POST', 
        body: JSON.stringify({ messages: aiState.messages }) 
    });
    
    const reader = streamResponse.body?.getReader();
    if (!reader) return;

    let accumulatedReasoning = "";
    let accumulatedAnswer = "";
    let isThinking = false;
    let finalMessageId = Date.now() + 1;

    // Create a placeholder message in UI
    setMessages(prev => [...prev, <Message key={finalMessageId} content="..." type="assistant" />]);

    while (true) {
      const { done, value } = await reader.read();
      if (done) break;

      const chunk = new TextDecoder().decode(value);
      
      // Parse for <thinking> tags
      // This is a simplified parser. A robust one would handle tags across chunks.
      if (chunk.includes('<thinking>')) {
        isThinking = true;
        // Remove tag from chunk for processing
        const parts = chunk.split('<thinking>');
        if (parts[0]) accumulatedAnswer += parts[0]; // Text before tag is answer
        if (parts[1]) accumulatedReasoning += parts[1]; // Text after is reasoning start
      } else if (chunk.includes('</thinking>')) {
        isThinking = false;
        const parts = chunk.split('</thinking>');
        if (parts[0]) accumulatedReasoning += parts[0]; // Remaining reasoning
        if (parts[1]) accumulatedAnswer += parts[1]; // Text after tag is answer
      } else {
        if (isThinking) {
          accumulatedReasoning += chunk;
        } else {
          accumulatedAnswer += chunk;
        }
      }

      // Update UI State dynamically (only the answer part)
      // We map over the UI state to update the specific message
      setMessages(prev => prev.map((msg, idx) => {
        if (idx === prev.length - 1) {
           // Only show answer in UI
           return <Message key={finalMessageId} content={accumulatedAnswer} type="assistant" />;
        }
        return msg;
      }));
    }

    // Finalize: Update AI State with full context (Reasoning + Answer)
    setAiState(prev => {
      const newMessages = [...prev.messages];
      // Remove the temporary user message we added earlier if needed, 
      // or just append the full assistant response.
      // Ideally, AIState tracks the raw text.
      newMessages.push({ role: 'assistant', content: `<thinking>${accumulatedReasoning}</thinking> ${accumulatedAnswer}` });
      return { ...prev, messages: newMessages };
    });
  };

  return (
    <div className="flex flex-col h-screen max-w-2xl mx-auto p-4">
      <div className="flex justify-between items-center mb-4">
        <h1 className="text-2xl font-bold">Context Compression Chat</h1>
        <button 
          onClick={() => setShowReasoning(!showReasoning)}
          className="text-sm px-3 py-1 bg-gray-200 rounded hover:bg-gray-300"
        >
          {showReasoning ? 'Hide' : 'Show'} Reasoning
        </button>
      </div>

      <div className="flex-1 overflow-y-auto space-y-4 border p-4 rounded bg-gray-50">
        {messages.map((msg, idx) => {
          // Logic to handle rendering based on toggle
          // We inspect the content of the message to see if it contains reasoning
          // If it does, and showReasoning is false, we might strip it or hide the component.
          
          // Since we are using React components in UIState, we can check props.
          // However, the `msg` here is a React Element.
          // A cleaner way is to render everything but conditionally style/hide reasoning 
          // based on the `type` prop we set earlier.
          
          const msgProps = msg.props; 
          if (msgProps.type === 'reasoning' && !showReasoning) {
            return null; // Don't render reasoning if toggle is off
          }
          
          return msg;
        })}
      </div>

      <div className="mt-4 flex gap-2">
        <input 
          type="text" 
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && handleSendMessage()}
          className="flex-1 border p-2 rounded"
          placeholder="Type a message..."
        />
        <button onClick={handleSendMessage} className="px-4 py-2 bg-blue-600 text-white rounded">
          Send
        </button>
      </div>
    </div>
  );
}
