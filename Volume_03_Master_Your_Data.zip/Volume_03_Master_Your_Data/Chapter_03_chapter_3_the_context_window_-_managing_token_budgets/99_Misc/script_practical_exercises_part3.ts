/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part3.ts
// Description: Practical Exercises
// ==========================================

// conversationManager.ts

interface Message {
  role: 'user' | 'assistant' | 'system';
  content: string;
}

// Mock LLM function for summarization
async function summarizeLLM(text: string): Promise<string> {
  // In a real app, this calls an LLM
  return `[Summary]: ${text.substring(0, 50)}...`;
}

export class ConversationManager {
  private history: Message[] = [];
  private readonly MAX_HISTORY_TOKENS = 3000;

  constructor(private systemPrompt?: string) {
    if (systemPrompt) {
      this.history.push({ role: 'system', content: systemPrompt });
    }
  }

  // TODO: Implement the logic
  // 1. addMessage method
  // 2. Token estimation logic
  // 3. Summarization trigger and replacement logic
  // 4. getHistory method
}



::: {style="text-align: center"}
![This diagram illustrates the AI's internal workflow where token estimation and summarization trigger logic work together to manage conversation history via the `getHistory` method.](images/b3_c3_s4_diag1.png){width=80% caption="This diagram illustrates the AI's internal workflow where token estimation and summarization trigger logic work together to manage conversation history via the `getHistory` method."}
:::


