/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * @fileoverview A basic PDF parsing example for a SaaS backend.
 * This script reads a PDF file from disk, extracts its text content,
 * and logs it to the console.
 * 
 * Dependencies: 
 * - npm install pdf-parse
 * - npm install @types/node --save-dev
 */

import * as fs from 'fs';
import * as path from 'path';
import pdfParse from 'pdf-parse';

/**
 * Represents the metadata and text content extracted from a PDF.
 * @typedef {Object} ParsedDocument
 * @property {string} text - The full extracted text content.
 * @property {number} pageCount - The number of pages in the PDF.
 * @property {number} totalPages - Total pages (alias for pageCount).
 * @property {number} info - PDF metadata (author, title, etc.).
 */
interface ParsedDocument {
  text: string;
  pageCount: number;
  totalPages: number;
  info: any; 
}

/**
 * Parses a PDF buffer and returns structured text data.
 * This function wraps the pdf-parse library to provide type safety.
 * 
 * @param {Buffer} buffer - The binary buffer of the PDF file.
 * @returns {Promise<ParsedDocument>} - A promise resolving to the parsed data.
 */
async function parsePdfBuffer(buffer: Buffer): Promise<ParsedDocument> {
  try {
    // pdf-parse returns a promise that resolves with detailed data.
    const data = await pdfParse(buffer);
    
    return {
      text: data.text,          // The raw text string extracted from the PDF
      pageCount: data.numpages, // Number of pages detected
      totalPages: data.numpages, // Alias often used in metadata
      info: data.info           // PDF metadata (Title, Author, CreationDate)
    };
  } catch (error) {
    console.error("Error parsing PDF buffer:", error);
    throw new Error("Failed to parse PDF document.");
  }
}

/**
 * Main execution function.
 * Simulates reading a file from a storage system (e.g., AWS S3 or local disk).
 * In a real SaaS app, this 'buffer' would come from an HTTP request (multer/next-connect).
 */
async function main() {
  // 1. Define the path to a sample PDF.
  // NOTE: Ensure you have a 'sample.pdf' in the same directory, 
  // or update this path to a valid file.
  const filePath = path.join(__dirname, 'sample.pdf');

  // 2. Check if file exists to prevent runtime crashes.
  if (!fs.existsSync(filePath)) {
    console.error(`File not found: ${filePath}`);
    console.error("Please create a 'sample.pdf' in the current directory to run this example.");
    return;
  }

  console.log(`Reading file: ${filePath}...`);

  try {
    // 3. Read the file as a binary Buffer.
    // In a web context (Next.js API route), this buffer would be provided 
    // by 'req.body' or a multipart form parser.
    const fileBuffer: Buffer = fs.readFileSync(filePath);

    console.log(`File loaded. Buffer size: ${fileBuffer.length} bytes`);

    // 4. Parse the PDF content.
    const parsedData = await parsePdfBuffer(fileBuffer);

    // 5. Output the results.
    console.log("\n--- Parsing Successful ---");
    console.log(`Pages Extracted: ${parsedData.pageCount}`);
    console.log(`Text Length: ${parsedData.text.length} characters`);
    console.log(`Metadata:`, parsedData.info);
    
    // Log a snippet of the text (first 200 chars)
    console.log(`\nText Snippet:\n"${parsedData.text.substring(0, 200).trim()}..."`);

  } catch (error) {
    console.error("Execution failed:", error);
  }
}

// Execute the main function.
// Using top-level await is not standard in pure Node scripts without .mjs flags,
// so we wrap it in an async IIFE or call .then().
main();
