/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

/**
 * advanced-ingestion-engine.ts
 * 
 * A Next.js API Route handler and utility suite for parsing PDF, HTML, and Notion
 * documents into a standardized format for RAG pipelines.
 * 
 * Dependencies:
 * - pdf-parse: For PDF binary parsing
 * - cheerio: For HTML DOM traversal
 * - @notionhq/client: For Notion API interaction
 */

import { NextApiRequest, NextApiResponse } from 'next';
import pdf from 'pdf-parse';
import * as cheerio from 'cheerio';
import { Client } from '@notionhq/client';

// =============================================================================
// 1. INTERFACE DEFINITION & TYPES
// =============================================================================

/**
 * Represents the standardized output of any document parser.
 * This structure is critical for the 'Vectorization' step in the RAG pipeline.
 * 
 * @property id - Unique identifier (UUID or hash) for the chunk.
 * @property content - The clean text content to be embedded.
 * @property metadata - Source info for citation and context window management.
 */
export interface NormalizedDocument {
  id: string;
  content: string;
  metadata: {
    source: 'pdf' | 'html' | 'notion';
    originUrl?: string; // URL or File Path
    chunkIndex: number; // Helps reconstruct order
    lastModified?: string;
  };
}

// =============================================================================
// 2. PDF PARSER (Unstructured Binary Data)
// =============================================================================

/**
 * Parses raw PDF buffer data into text.
 * 
 * Why this approach?
 * PDFs are binary formats. Unlike HTML, they lack semantic tags. We rely on 
 * pdf-parse to perform layout analysis and extract raw text streams.
 * 
 * Under the Hood:
 * 1. We pass the buffer to the library.
 * 2. We receive a single string of text.
 * 3. We split this text into chunks to prevent exceeding the LLM's Context Window 
 *    during the retrieval phase.
 */
async function parsePdf(buffer: Buffer): Promise<NormalizedDocument[]> {
  try {
    const data = await pdf(buffer);
    
    // Basic chunking strategy: Split by newlines or fixed character count
    // For this demo, we split by double newlines to approximate paragraphs.
    const chunks = data.text.split(/\n\s*\n/).filter((chunk) => chunk.trim().length > 0);

    return chunks.map((chunk, index) => ({
      id: `pdf-${Date.now()}-${index}`, // Simple ID generation
      content: chunk.replace(/\s+/g, ' ').trim(), // Normalize whitespace
      metadata: {
        source: 'pdf',
        chunkIndex: index,
      },
    }));
  } catch (error) {
    console.error("PDF Parsing Error:", error);
    throw new Error("Failed to parse PDF buffer.");
  }
}

// =============================================================================
// 3. HTML PARSER (Semi-Structured DOM Data)
// =============================================================================

/**
 * Parses HTML content from a string or fetch response.
 * 
 * Why this approach?
 * HTML contains noise (scripts, styles, ads). We use Cheerio to query specific 
 * elements (e.g., <article>, <p>) to extract only the meaningful content.
 * 
 * Under the Hood:
 * 1. Cheerio loads the HTML string into a virtual DOM.
 * 2. We exclude 'script' and 'style' tags.
 * 3. We iterate through paragraphs to maintain logical flow.
 */
async function parseHtml(htmlContent: string): Promise<NormalizedDocument[]> {
  const $ = cheerio.load(htmlContent);
  
  // Select only meaningful content (e.g., inside <article> or all <p> tags)
  // In a real app, this selector would be configurable per domain.
  const paragraphs = $('p, h1, h2, h3').toArray();
  
  const documents: NormalizedDocument[] = [];

  paragraphs.forEach((el, index) => {
    const text = $(el).text().trim();
    if (text.length > 0) {
      documents.push({
        id: `html-${Date.now()}-${index}`,
        content: text,
        metadata: {
          source: 'html',
          chunkIndex: index,
        },
      });
    }
  });

  return documents;
}

// =============================================================================
// 4. NOTION PARSER (API-Driven Structured Data)
// =============================================================================

/**
 * Fetches and parses content from a Notion Page ID.
 * 
 * Why this approach?
 * Notion data is block-based. We must recursively fetch blocks and handle 
 * different block types (paragraphs, headings, lists) to reconstruct text.
 * 
 * Under the Hood:
 * 1. Initialize Notion Client with API Key.
 * 2. Fetch 'block children' recursively.
 * 3. Map block types to text content.
 */
async function parseNotionPage(pageId: string, apiKey: string): Promise<NormalizedDocument[]> {
  const notion = new Client({ auth: apiKey });
  
  try {
    // Fetch all blocks children
    const blocks = await notion.blocks.children.list({ block_id: pageId });
    
    const documents: NormalizedDocument[] = [];
    
    blocks.results.forEach((block, index) => {
      // @ts-ignore: Checking for 'rich_text' property common to text blocks
      if (block.type && block[block.type].rich_text) {
        // @ts-ignore
        const richText = block[block.type].rich_text;
        
        // Extract plain text from RichText array
        const textContent = richText.map((textObj: any) => textObj.plain_text).join(' ');
        
        if (textContent.trim().length > 0) {
          documents.push({
            id: `notion-${block.id}`,
            content: textContent,
            metadata: {
              source: 'notion',
              originUrl: `https://www.notion.so/${block.id.replace(/-/g, '')}`,
              chunkIndex: index,
            },
          });
        }
      }
    });

    return documents;
  } catch (error) {
    console.error("Notion API Error:", error);
    throw new Error("Failed to fetch Notion page content.");
  }
}

// =============================================================================
// 5. NEXT.JS API ROUTE (The Orchestrator)
// =============================================================================

/**
 * POST /api/ingest
 * 
 * Body:
 * {
 *   type: 'pdf' | 'html' | 'notion',
 *   data: string | Buffer (Base64 encoded for PDFs in JSON),
 *   pageId?: string (Required for Notion),
 *   apiKey?: string (Required for Notion)
 * }
 * 
 * This endpoint acts as the entry point for the SaaS application's 
 * file upload or data sync feature.
 */
export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  const { type, data, pageId, apiKey } = req.body;

  try {
    let parsedDocs: NormalizedDocument[] = [];

    switch (type) {
      case 'pdf':
        if (!data) throw new Error("PDF data missing.");
        // In a real Next.js API route handling file uploads, you'd get a Buffer directly.
        // Here we assume a Base64 string was sent in the JSON body.
        const buffer = Buffer.from(data, 'base64');
        parsedDocs = await parsePdf(buffer);
        break;

      case 'html':
        if (!data) throw new Error("HTML content missing.");
        parsedDocs = await parseHtml(data);
        break;

      case 'notion':
        if (!pageId || !apiKey) throw new Error("Notion Page ID or API Key missing.");
        parsedDocs = await parseNotionPage(pageId, apiKey);
        break;

      default:
        return res.status(400).json({ error: 'Unsupported document type' });
    }

    // Success: Return standardized documents ready for vectorization
    return res.status(200).json({
      success: true,
      count: parsedDocs.length,
      documents: parsedDocs,
    });

  } catch (error) {
    console.error("Ingestion Pipeline Error:", error);
    return res.status(500).json({ 
      error: 'Ingestion failed', 
      details: error instanceof Error ? error.message : 'Unknown error' 
    });
  }
}
