/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

// notionLoader.ts
import { Client } from '@notionhq/client';
import { DocumentChunk } from './types';

// Initialize client with environment variable
const notion = new Client({ auth: process.env.NOTION_API_KEY });

// Helper to flatten rich text arrays
function flattenRichText(richTextArray: any[]): string {
  if (!richTextArray || richTextArray.length === 0) return '';
  // Concatenate the 'plain_text' property of each rich text object
  return richTextArray.map((textObj) => textObj.plain_text).join('');
}

export async function fetchNotionDatabase(
  databaseId: string
): Promise<DocumentChunk[]> {
  const results: DocumentChunk[] = [];
  let startCursor: string | undefined = undefined;
  let hasMore = true;

  // 1. Loop while has_more is true to handle pagination
  while (hasMore) {
    // Query the database
    const response = await notion.databases.query({
      database_id: databaseId,
      start_cursor: startCursor,
      page_size: 100, // Max allowed per request
    });

    // 2. Process each page result
    for (const page of response.results) {
      // Ensure we are dealing with a valid page object
      if ('properties' in page && 'url' in page) {
        // Fetch the actual content blocks for this page
        const blocks = await notion.blocks.children.list({
          block_id: page.id,
        });

        // 3. Flatten content from all blocks into a single string
        const contentText = blocks.results
          .map((block: any) => {
            // Check for rich text properties in various block types (paragraph, heading, etc.)
            if (block.type && block[block.type] && block[block.type].rich_text) {
              return flattenRichText(block[block.type].rich_text);
            }
            return '';
          })
          .filter((text: string) => text.length > 0) // Remove empty strings
          .join('\n');

        // 4. Construct DocumentChunk
        if (contentText.length > 0 || page.url) { // Include even if empty, if URL exists
          results.push({
            content: contentText,
            metadata: {
              notionPageId: page.id,
              lastEditedTime: (page as any).last_edited_time,
              url: page.url,
            },
          });
        }
      }
    }

    // 5. Update pagination state
    hasMore = response.has_more;
    startCursor = response.next_cursor || undefined;
  }

  return results;
}
