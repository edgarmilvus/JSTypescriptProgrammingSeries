/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

// htmlLoader.ts
import * as cheerio from 'cheerio';

export function sanitizeHtml(htmlString: string): string {
  // Load HTML into cheerio
  const $ = cheerio.load(htmlString);

  // 1. Remove noise tags (script, style, nav, footer, header)
  $('script, style, nav, footer, header').remove();

  // 2. Extract and format text with semantic markers
  let cleanText = '';

  // Process h1-h6
  $('h1, h2, h3, h4, h5, h6').each((i, el) => {
    const level = el.tagName.substring(1); // '1', '2', etc.
    const prefix = '#'.repeat(parseInt(level)); // '##', '###'
    cleanText += `\n${prefix} ${$(el).text().trim()}\n\n`;
  });

  // Process paragraphs and list items
  $('p, li').each((i, el) => {
    const text = $(el).text().trim();
    if (text) {
      cleanText += `${text}\n\n`;
    }
  });

  // Process tables (simple concatenation of cells)
  $('table').each((i, el) => {
    const tableText = $(el).text().replace(/\s+/g, ' ').trim();
    cleanText += `[Table Data]: ${tableText}\n\n`;
  });

  return cleanText.trim();
}

export function chunkHtmlContent(
  sanitizedText: string,
  maxTokens: number = 512
): string[] {
  // Note: 1 token ≈ 4 characters for estimation
  const maxChars = maxTokens * 4;
  const chunks: string[] = [];

  // 1. Split primarily by double newlines (paragraphs)
  // We use a regex to handle various newline characters safely
  const paragraphs = sanitizedText.split(/\n\s*\n/);

  for (const paragraph of paragraphs) {
    if (paragraph.length === 0) continue;

    // 2. Check if paragraph fits within limit
    if (paragraph.length <= maxChars) {
      chunks.push(paragraph.trim());
    } else {
      // 3. Fallback: Split by sentence boundaries (., ?, ! followed by space or newline)
      const sentences = paragraph.match(/[^.!?]+[.!?]+\s*/g) || [paragraph];
      
      let currentChunk = '';
      
      for (const sentence of sentences) {
        // If adding this sentence exceeds the limit, push current and start new
        if ((currentChunk + sentence).length > maxChars && currentChunk !== '') {
          chunks.push(currentChunk.trim());
          currentChunk = sentence;
        } else {
          currentChunk += sentence;
        }
      }
      
      // Push any remaining text
      if (currentChunk.trim().length > 0) {
        chunks.push(currentChunk.trim());
      }
    }
  }

  return chunks;
}
