/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.tsx
// Description: Solutions and Explanations
// ==========================================

// ContextWindowVisualizer.tsx
import React, { useState, useMemo } from 'react';

interface Props {
  text: string;
  maxTokens: number;
  tokensPerChar?: number;
}

const ContextWindowVisualizer: React.FC<Props> = ({ 
  text, 
  maxTokens, 
  tokensPerChar = 0.25 
}) => {
  // State for dynamic token limit input
  const [localMaxTokens, setLocalMaxTokens] = useState<number>(maxTokens);

  // Calculate estimated total tokens
  const estimatedTotalTokens = Math.ceil(text.length * tokensPerChar);

  // Determine the truncation point based on the character limit
  const charLimit = Math.floor(localMaxTokens / tokensPerChar);
  const isTruncated = estimatedTotalTokens > localMaxTokens;

  // Split the text into valid and truncated parts
  const validText = isTruncated ? text.substring(0, charLimit) : text;
  const truncatedText = isTruncated ? text.substring(charLimit) : '';

  // Calculate percentage of text truncated
  const truncationPercentage = isTruncated 
    ? ((truncatedText.length / text.length) * 100).toFixed(1) 
    : '0';

  return (
    <div className="context-visualizer" style={{ fontFamily: 'monospace', padding: '10px', border: '1px solid #ccc' }}>
      
      {/* Input for dynamic adjustment */}
      <div style={{ marginBottom: '15px', padding: '10px', background: '#f5f5f5' }}>
        <label>
          Max Token Limit: 
          <input 
            type="number" 
            value={localMaxTokens} 
            onChange={(e) => setLocalMaxTokens(Number(e.target.value))}
            style={{ marginLeft: '8px', width: '80px' }}
          />
        </label>
        <span style={{ marginLeft: '15px', fontWeight: 'bold' }}>
          Total Tokens: {estimatedTotalTokens}
        </span>
      </div>

      {/* Visualization Stats */}
      <div style={{ marginBottom: '10px', fontSize: '0.9em' }}>
        {isTruncated ? (
          <span style={{ color: 'red' }}>
            Truncated: {truncationPercentage}% (Over limit by {estimatedTotalTokens - localMaxTokens} tokens)
          </span>
        ) : (
          <span style={{ color: 'green' }}>
            Within Limit ({estimatedTotalTokens} / {localMaxTokens} tokens)
          </span>
        )}
      </div>

      {/* Text Rendering */}
      <div style={{ whiteSpace: 'pre-wrap', lineHeight: '1.5' }}>
        {/* Valid Section */}
        {validText && (
          <span style={{ background: '#d4edda', border: '1px solid #c3e6cb', padding: '2px' }}>
            {validText}
          </span>
        )}
        
        {/* Truncated Section */}
        {truncatedText && (
          <span style={{ background: '#f8d7da', border: '1px solid #f5c6cb', padding: '2px', textDecoration: 'line-through' }}>
            {truncatedText}
          </span>
        )}
      </div>
    </div>
  );
};

export default ContextWindowVisualizer;
