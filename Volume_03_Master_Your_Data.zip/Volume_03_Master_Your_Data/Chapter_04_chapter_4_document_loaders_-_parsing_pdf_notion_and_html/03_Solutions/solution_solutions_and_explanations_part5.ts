/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

// chunker.ts
export function hybridChunk(
  text: string,
  maxChunkSize: number,
  overlap: number = 0
): string[] {
  // Define the hierarchy of delimiters
  const delimiters = ['\n\n', '\n', '. '];

  // Recursive helper function
  function recursiveSplit(
    segment: string, 
    delimiterIndex: number
  ): string[] {
    // Base case: If segment is small enough, return it
    if (segment.length <= maxChunkSize) {
      return [segment];
    }

    // Base case: If we have run out of delimiters, perform a hard split
    if (delimiterIndex >= delimiters.length) {
      const chunks: string[] = [];
      for (let i = 0; i < segment.length; i += maxChunkSize) {
        chunks.push(segment.substring(i, i + maxChunkSize));
      }
      return chunks;
    }

    // Recursive step: Split by current delimiter
    const currentDelimiter = delimiters[delimiterIndex];
    const parts = segment.split(currentDelimiter);

    const processedParts: string[] = [];

    for (const part of parts) {
      // If the part is empty, skip it
      if (!part) continue;

      // Recursively split the part using the next delimiter level
      const subParts = recursiveSplit(part, delimiterIndex + 1);
      
      // Add results to our list
      processedParts.push(...subParts);
    }

    return processedParts;
  }

  // 1. Perform the initial recursive split starting at level 0
  let chunks = recursiveSplit(text, 0);

  // 2. Apply Overlap Logic
  if (overlap > 0 && chunks.length > 1) {
    const overlappedChunks: string[] = [];
    
    for (let i = 0; i < chunks.length; i++) {
      let currentChunk = chunks[i];
      
      // If not the first chunk, prepend overlap from previous chunk
      if (i > 0) {
        const prevChunk = chunks[i - 1];
        const overlapText = prevChunk.slice(-overlap);
        // Ensure we don't duplicate text if the previous chunk ended exactly where this one starts
        // (Simple concatenation approach)
        currentChunk = overlapText + currentChunk;
      }
      
      overlappedChunks.push(currentChunk);
    }
    
    // Update chunks with overlap applied
    chunks = overlappedChunks;
  }

  return chunks;
}
