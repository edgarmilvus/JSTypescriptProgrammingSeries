/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * @fileoverview A basic demonstration of Fixed-Size and Semantic chunking strategies
 * for a RAG pipeline in a Node.js environment.
 * 
 * Context: SaaS Document Processing
 * 
 * Dependencies: None (Native Node.js APIs only)
 */

// --- 1. Type Definitions ---
// Using immutable interfaces ensures we don't modify data structures in place.

/**
 * Represents a single chunk of text extracted from a document.
 * @property content - The actual text segment.
 * @property metadata - Context about the chunk (source, page number, etc.).
 */
interface TextChunk {
  content: string;
  metadata: {
    source: string;
    chunkIndex: number;
    strategy: 'fixed' | 'semantic';
  };
}

// --- 2. Mock Data ---
// Simulating a document loaded from a database or file system.

const mockDocument: string = `
  Artificial Intelligence (AI) is intelligence demonstrated by machines, as opposed to natural intelligence displayed by animals including humans. Leading AI textbooks define the field as the study of "intelligent agents": any system that perceives its environment and takes actions that maximize its chance of achieving its goals. Some popular accounts use the term "artificial intelligence" to describe machines that mimic "cognitive" functions that humans associate with the human mind, such as "learning" and "problem solving", however, this definition is rejected by major AI researchers.

  AI applications include advanced web search engines (e.g., Google), recommendation systems (used by YouTube, Amazon and Netflix), understanding human speech (such as Siri and Alexa), self-driving cars (e.g., Waymo), automated decision-making and competing at the highest level in strategic game systems (such as chess and Go). As machines become increasingly capable, tasks considered to require "intelligence" are often removed from the definition of AI, a phenomenon known as the AI effect.

  The field of AI research was born at a workshop at Dartmouth College in 1956. Those who attended became the founders and leaders of AI research. They and their students produced programs that the press described as "astonishing": computers were learning checker strategies, solving word problems in algebra, proving logical theorems and speaking English. By the middle of the 1960s, research in the U.S. was heavily funded by the Department of Defense and laboratories had been established around the world.
`.trim();

// --- 3. Logic Implementation ---

/**
 * STRATEGY 1: Fixed-Size Chunking
 * 
 * How it works:
 * 1. Takes a raw string and a maximum character length.
 * 2. Splits the text strictly by character count.
 * 3. Ignores sentence structure or semantic boundaries.
 * 
 * Pros: Simple, predictable, fast.
 * Cons: Can cut sentences in half, losing context.
 * 
 * @param text - The raw document text.
 * @param maxSize - Maximum characters per chunk.
 * @param sourceName - Name of the file/source.
 * @returns Array of TextChunks
 */
function fixedSizeChunking(
  text: string, 
  maxSize: number, 
  sourceName: string
): TextChunk[] {
  const chunks: TextChunk[] = [];
  let currentIndex = 0;

  // Loop until we've processed the entire text
  while (currentIndex < text.length) {
    // Extract a substring of the max size
    let chunkContent = text.substring(currentIndex, currentIndex + maxSize);

    // Edge Case: If we are at the end, just take what's left.
    // If we are in the middle, we might be cutting a word. 
    // A simple fix is to find the last space before the limit (greedy approach).
    if (currentIndex + maxSize < text.length) {
      const lastSpace = chunkContent.lastIndexOf(' ');
      if (lastSpace > -1) {
        chunkContent = chunkContent.substring(0, lastSpace);
      }
    }

    chunks.push({
      content: chunkContent,
      metadata: {
        source: sourceName,
        chunkIndex: chunks.length,
        strategy: 'fixed'
      }
    });

    // Advance the index. 
    // Note: We add the length of the chunk we just pushed, 
    // not strictly 'maxSize', because we might have trimmed whitespace.
    currentIndex += chunkContent.length;
    
    // Skip the space we split on to avoid leading spaces in the next chunk
    if (text[currentIndex] === ' ') {
      currentIndex++;
    }
  }

  return chunks;
}

/**
 * STRATEGY 2: Semantic (Sentence-Aware) Chunking
 * 
 * How it works:
 * 1. Breaks text into logical units (sentences or paragraphs) first.
 * 2. Groups these units until the max size is reached.
 * 3. Preserves semantic integrity (no cut sentences).
 * 
 * Pros: Higher quality embeddings, better context for the LLM.
 * Pros: Slightly more complex logic.
 * 
 * @param text - The raw document text.
 * @param maxSize - Maximum characters per chunk.
 * @param sourceName - Name of the file/source.
 * @returns Array of TextChunks
 */
function semanticChunking(
  text: string, 
  maxSize: number, 
  sourceName: string
): TextChunk[] {
  const chunks: TextChunk[] = [];
  
  // Step 1: Split by sentences (using regex for punctuation)
  // This regex looks for periods, exclamation marks, or question marks followed by whitespace.
  const sentences = text.match(/[^.!?]+[.!?]+/g) || [];

  let currentChunkContent = '';

  for (const sentence of sentences) {
    const sentenceTrimmed = sentence.trim();
    
    // Check if adding the next sentence exceeds the limit
    if (currentChunkContent.length + sentenceTrimmed.length > maxSize) {
      // If current chunk has content, push it
      if (currentChunkContent.length > 0) {
        chunks.push({
          content: currentChunkContent,
          metadata: {
            source: sourceName,
            chunkIndex: chunks.length,
            strategy: 'semantic'
          }
        });
        currentChunkContent = '';
      }
      
      // If a single sentence is longer than maxSize, we must split it anyway
      // (Rare in text, common in code or logs)
      if (sentenceTrimmed.length > maxSize) {
        const words = sentenceTrimmed.split(' ');
        let tempSentence = '';
        for (const word of words) {
          if (tempSentence.length + word.length > maxSize) {
             chunks.push({
              content: tempSentence,
              metadata: {
                source: sourceName,
                chunkIndex: chunks.length,
                strategy: 'semantic'
              }
            });
            tempSentence = '';
          }
          tempSentence += word + ' ';
        }
        currentChunkContent = tempSentence;
      } else {
        currentChunkContent = sentenceTrimmed;
      }
    } else {
      // Append to current chunk
      currentChunkContent += (currentChunkContent ? ' ' : '') + sentenceTrimmed;
    }
  }

  // Push the final remaining chunk
  if (currentChunkContent.length > 0) {
    chunks.push({
      content: currentChunkContent,
      metadata: {
        source: sourceName,
        chunkIndex: chunks.length,
        strategy: 'semantic'
      }
    });
  }

  return chunks;
}

// --- 4. Execution / Simulation ---

/**
 * Main entry point for the simulation.
 * Demonstrates the output difference between the two strategies.
 */
function runSimulation() {
  console.log('--- RUNNING CHUNKING SIMULATION ---\n');

  // Define a max chunk size (e.g., for an embedding model with 512 tokens)
  const MAX_SIZE = 300; 

  // 1. Run Fixed-Size Strategy
  console.log(`[1] Fixed-Size Strategy (Max: ${MAX_SIZE} chars)`);
  const fixedChunks = fixedSizeChunking(mockDocument, MAX_SIZE, 'doc_001');
  
  // Log the first 2 chunks to show the difference
  fixedChunks.slice(0, 2).forEach((chunk, idx) => {
    console.log(`   Chunk ${idx + 1}: ${chunk.content.substring(0, 50)}... (Len: ${chunk.content.length})`);
  });
  console.log(`   Total Chunks: ${fixedChunks.length}\n`);

  // 2. Run Semantic Strategy
  console.log(`[2] Semantic Strategy (Max: ${MAX_SIZE} chars)`);
  const semanticChunks = semanticChunking(mockDocument, MAX_SIZE, 'doc_001');
  
  semanticChunks.slice(0, 2).forEach((chunk, idx) => {
    console.log(`   Chunk ${idx + 1}: ${chunk.content.substring(0, 50)}... (Len: ${chunk.content.length})`);
  });
  console.log(`   Total Chunks: ${semanticChunks.length}\n`);

  // 3. Comparison Analysis
  console.log('--- ANALYSIS ---');
  console.log(`Fixed strategy produced ${fixedChunks.length} chunks.`);
  console.log(`Semantic strategy produced ${semanticChunks.length} chunks.`);
  console.log('Notice how Semantic chunks end with complete sentences, preserving meaning for the vector embedding.');
}

// Execute the simulation
runSimulation();
