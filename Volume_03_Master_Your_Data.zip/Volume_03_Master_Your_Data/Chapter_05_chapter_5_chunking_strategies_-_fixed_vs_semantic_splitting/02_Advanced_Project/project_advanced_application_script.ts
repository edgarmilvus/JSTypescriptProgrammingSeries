/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

/**
 * ============================================================================
 *  ADVANCED CHUNKING SERVICE: HYBRID STRATEGY IMPLEMENTATION
 * ============================================================================
 * 
 * Context: Book 3, Chapter 5 - Production RAG Pipeline
 * Objective: Implement a Supervisor Node that delegates chunking tasks to 
 * specialized Worker Agents based on document metadata.
 * 
 * Environment: Node.js (TypeScript)
 * Dependencies: langchain (for text splitting logic)
 */

// 1. TYPE DEFINITIONS & INTERFACES
// ----------------------------------------------------------------------------

/**
 * Represents the metadata associated with a document to be processed.
 * This is crucial for the Supervisor Node's decision-making logic.
 */
export interface DocumentMetadata {
  id: string;
  type: 'legal_contract' | 'technical_manual' | 'general_text';
  source: string;
}

/**
 * Represents a single text segment (chunk) ready for embedding.
 */
export interface Chunk {
  content: string;
  metadata: {
    sourceId: string;
    chunkIndex: number;
    strategy: string;
  };
}

/**
 * The Graph State passed between nodes.
 */
export interface ProcessingState {
  rawText: string;
  metadata: DocumentMetadata;
  chunks: Chunk[];
}

// 2. WORKER AGENTS (CONCRETE STRATEGIES)
// ----------------------------------------------------------------------------

/**
 * Worker Agent A: Fixed Chunker
 * 
 * Strategy: Splits text into chunks of a constant size based on character count.
 * Why: Best for technical manuals or logs where context is linear and 
 *      consistent formatting is preferred. It maximizes token utilization 
 *      within the LLM context window.
 * 
 * Under the Hood: Uses a simple recursive text splitter.
 */
class FixedChunker {
  private chunkSize: number;
  private overlap: number;

  constructor(chunkSize: number = 1000, overlap: number = 200) {
    this.chunkSize = chunkSize;
    this.overlap = overlap;
  }

  /**
   * Executes the fixed-size splitting logic.
   * @param text - The raw text to split.
   * @param metadata - Source document metadata.
   * @returns Promise<Chunk[]>
   */
  public async process(text: string, metadata: DocumentMetadata): Promise<Chunk[]> {
    console.log(`[Worker: FixedChunker] Processing ${metadata.id}...`);
    
    // Simulating the split logic (simplified for this script)
    // In production, you would use: new RecursiveCharacterTextSplitter(...)
    const chunks: Chunk[] = [];
    let start = 0;
    let index = 0;

    while (start < text.length) {
      let end = start + this.chunkSize;
      
      // Ensure we don't cut words in half (naive implementation)
      if (end < text.length) {
        const lastSpace = text.lastIndexOf(' ', end);
        if (lastSpace > start) end = lastSpace;
      }

      const content = text.substring(start, end).trim();
      if (content.length > 0) {
        chunks.push({
          content,
          metadata: {
            sourceId: metadata.id,
            chunkIndex: index++,
            strategy: 'fixed_size'
          }
        });
      }
      
      // Apply overlap logic for the next chunk
      start = end - this.overlap; 
      if (start < 0) start = end; // Prevent negative start
    }

    return chunks;
  }
}

/**
 * Worker Agent B: Semantic Chunker
 * 
 * Strategy: Splits text based on semantic boundaries (sentences, paragraphs).
 * Why: Essential for legal contracts or narrative text where context is 
 *      hierarchical. Preserving a full sentence prevents "meaning cutoff" 
 *      during vectorization.
 * 
 * Under the Hood: Analyzes punctuation and whitespace to find natural 
 *      break points, ensuring chunks remain semantically complete.
 */
class SemanticChunker {
  private minChunkSize: number;

  constructor(minChunkSize: number = 300) {
    this.minChunkSize = minChunkSize;
  }

  /**
   * Executes semantic splitting logic.
   * @param text - The raw text to split.
   * @param metadata - Source document metadata.
   * @returns Promise<Chunk[]>
   */
  public async process(text: string, metadata: DocumentMetadata): Promise<Chunk[]> {
    console.log(`[Worker: SemanticChunker] Processing ${metadata.id}...`);
    
    const chunks: Chunk[] = [];
    // Split by sentences (simple heuristic: period followed by space or newline)
    const sentences = text.match(/[^.!?]+[.!?]+/g) || [text];
    
    let currentChunk = "";
    let chunkIndex = 0;

    for (const sentence of sentences) {
      const sentenceTrimmed = sentence.trim();
      
      // If adding this sentence exceeds the rough limit and we have content
      if (currentChunk.length + sentenceTrimmed.length > this.minChunkSize && currentChunk.length > 0) {
        chunks.push({
          content: currentChunk,
          metadata: {
            sourceId: metadata.id,
            chunkIndex: chunkIndex++,
            strategy: 'semantic_sentence'
          }
        });
        currentChunk = sentenceTrimmed;
      } else {
        currentChunk += (currentChunk ? " " : "") + sentenceTrimmed;
      }
    }

    // Push the remaining chunk
    if (currentChunk.length > 0) {
      chunks.push({
        content: currentChunk,
        metadata: {
          sourceId: metadata.id,
          chunkIndex: chunkIndex++,
          strategy: 'semantic_sentence'
        }
      });
    }

    return chunks;
  }
}

// 3. SUPERVISOR NODE (ORCHESTRATOR)
// ----------------------------------------------------------------------------

/**
 * Supervisor Node: AdaptiveChunkingService
 * 
 * Logic:
 * 1. Receives raw text and metadata.
 * 2. Analyzes the document type (metadata).
 * 3. Routes the payload to the appropriate Worker Agent.
 * 4. Aggregates results.
 */
export class AdaptiveChunkingService {
  private fixedWorker: FixedChunker;
  private semanticWorker: SemanticChunker;

  constructor() {
    // Initialize workers (Dependency Injection could be used here)
    this.fixedWorker = new FixedChunker(800, 100);
    this.semanticWorker = new SemanticChunker(500);
  }

  /**
   * The entry point for the Supervisor.
   * @param text - Raw document string.
   * @param metadata - Document metadata.
   * @returns Promise<Chunk[]>
   */
  public async execute(text: string, metadata: DocumentMetadata): Promise<Chunk[]> {
    console.log(`[Supervisor] Routing task for: ${metadata.type}`);

    // Supervisor Decision Logic
    let chunks: Chunk[];

    switch (metadata.type) {
      case 'technical_manual':
      case 'general_text':
        // Route to Fixed Worker for linear data
        chunks = await this.fixedWorker.process(text, metadata);
        break;

      case 'legal_contract':
        // Route to Semantic Worker for context-heavy data
        chunks = await this.semanticWorker.process(text, metadata);
        break;

      default:
        throw new Error(`Unknown document type: ${metadata.type}`);
    }

    return chunks;
  }
}

// 4. USAGE EXAMPLE (SIMULATING A NEXT.JS API ROUTE)
// ----------------------------------------------------------------------------

/**
 * Mock Data: A snippet of a legal contract.
 * Note the sentence structure—cutting this mid-sentence destroys meaning.
 */
const LEGAL_TEXT = `
However, gross negligence shall result in full liability. This clause supersedes all previous agreements.
`;

/**
 * Mock Data: A technical manual snippet.
 * Note the linear flow—fixed chunks are acceptable here.
 */
const TECH_TEXT = `
Step 1: Connect the power cable to the port labeled 'DC IN'.
Step 2: Ensure the voltage switch is set to 110V or 220V depending on your region.
Step 3: Press the power button located on the front panel.
Step 4: Wait for the LED indicator to turn solid green, signaling system readiness.
`;

/**
 * Main execution function (simulating a server-side process).
 */
async function runChunkingPipeline() {
  const supervisor = new AdaptiveChunkingService();

  // Case 1: Legal Document (Requires Semantic Splitting)
  console.log("\n--- Processing Legal Document ---");
  const legalState: ProcessingState = {
    rawText: LEGAL_TEXT,
    metadata: {
      id: "doc_001",
      type: "legal_contract",
      source: "contracts/v1/NDA.pdf"
    },
    chunks: []
  };

  const legalChunks = await supervisor.execute(legalState.rawText, legalState.metadata);
  console.log(`Result: Generated ${legalChunks.length} chunks.`);
  console.log("First Chunk:", legalChunks[0].content.substring(0, 50) + "...");

  // Case 2: Technical Manual (Requires Fixed Splitting)
  console.log("\n--- Processing Technical Manual ---");
  const techState: ProcessingState = {
    rawText: TECH_TEXT,
    metadata: {
      id: "doc_002",
      type: "technical_manual",
      source: "manuals/v2/setup_guide.md"
    },
    chunks: []
  };

  const techChunks = await supervisor.execute(techState.rawText, techState.metadata);
  console.log(`Result: Generated ${techChunks.length} chunks.`);
  console.log("First Chunk:", techChunks[0].content.substring(0, 50) + "...");
}

// Execute the pipeline
// runChunkingPipeline(); // Uncomment to run in a Node environment
