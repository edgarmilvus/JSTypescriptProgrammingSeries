/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// types.ts
export interface ChunkingOptions {
  chunkSize: number;
  overlap: number;
  strategy: 'fixed' | 'semantic';
}

// chunker.ts
export async function chunkWithOverlap(
  text: string, 
  options: ChunkingOptions
): Promise<string[]> {
  const { chunkSize, overlap } = options;
  
  // Return text as is if it's smaller than the chunk size
  if (text.length <= chunkSize) {
    return [text];
  }

  const chunks: string[] = [];
  let currentChunk = "";
  let currentIndex = 0;

  // Regex to find sentence terminators followed by whitespace or end of string
  // This helps identify potential split points.
  const sentenceEndRegex = /(?<=[.!?])\s+/g;

  while (currentIndex < text.length) {
    // Determine the theoretical end of the chunk based on size
    let chunkEnd = Math.min(currentIndex + chunkSize, text.length);
    
    // If we are not at the very end of the text, try to find a sentence break
    if (chunkEnd < text.length) {
      // Look ahead from the chunkEnd backwards to find the nearest sentence terminator
      // We limit the search range to avoid finding breaks too far back
      const searchStart = Math.max(currentIndex, chunkEnd - 100); // Look back up to 100 chars
      const textSegment = text.substring(searchStart, chunkEnd);
      const lastBreakIndex = textSegment.search(sentenceEndRegex);

      if (lastBreakIndex !== -1) {
        // Adjust chunkEnd to include the sentence terminator and whitespace
        // The regex match ends at the whitespace, so we include it.
        chunkEnd = searchStart + lastBreakIndex + textSegment.match(sentenceEndRegex)![0].length;
      } else {
        // No sentence break found in the segment, force cut at chunkSize
        // Ensure we don't cut a multi-byte character in half (basic safety)
        while (chunkEnd < text.length && (text.charCodeAt(chunkEnd) & 0xF800) === 0xD800) {
            chunkEnd++;
        }
      }
    }

    let chunk = text.substring(currentIndex, chunkEnd);

    // Handle Overlap
    if (chunks.length > 0 && overlap > 0) {
      const previousChunk = chunks[chunks.length - 1];
      const overlapText = previousChunk.slice(-overlap);
      chunk = overlapText + chunk;
    }

    chunks.push(chunk);
    
    // Move index forward. 
    // Note: We subtract overlap from the next start index to create the sliding window effect
    // effectively "rewinding" the index to capture the overlap context again.
    currentIndex = chunkEnd - overlap;
    
    // Prevent infinite loop if overlap is larger than chunk size or text stalls
    if (currentIndex <= chunks[chunks.length - 1].length && currentIndex >= chunkEnd) {
        currentIndex = chunkEnd; // Fallback to strict progression
    }
    
    // Safety break if index doesn't move forward
    if (currentIndex >= text.length) break;
  }

  // Simulate async operation
  return new Promise((resolve) => {
    setImmediate(() => resolve(chunks));
  });
}
