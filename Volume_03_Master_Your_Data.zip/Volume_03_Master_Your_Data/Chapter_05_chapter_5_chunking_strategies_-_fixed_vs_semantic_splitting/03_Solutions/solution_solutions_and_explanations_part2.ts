/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

// chunker.ts

/**
 * Recursively splits text based on a hierarchy of separators.
 * Optimized for large documents by using an iterative approach for merging 
 * to avoid deep recursion stack overflow.
 */
export function semanticRecursiveSplit(
  text: string, 
  separators: string[], 
  maxSize: number
): string[] {
  // Base case: If no separators left or text is short enough, return as is
  if (separators.length === 0 || text.length <= maxSize) {
    return [text];
  }

  const currentSeparator = separators[0];
  const nextSeparators = separators.slice(1);

  // 1. Split the text by the current separator
  let chunks = text.split(currentSeparator);

  // 2. Process chunks: Recurse if too big, Merge if too small
  const finalChunks: string[] = [];
  
  for (let chunk of chunks) {
    if (chunk.length > maxSize) {
      // Recursive Step: If chunk is too large, use the next separator
      const subChunks = semanticRecursiveSplit(chunk, nextSeparators, maxSize);
      finalChunks.push(...subChunks);
    } else {
      finalChunks.push(chunk);
    }
  }

  // 3. Merge small chunks iteratively (avoids recursion depth issues)
  return mergeChunksIterative(finalChunks, maxSize, currentSeparator);
}

/**
 * Helper function to merge adjacent chunks until they reach maxSize.
 * Uses an iterative loop instead of recursion for performance and stack safety.
 */
function mergeChunksIterative(chunks: string[], maxSize: number, separator: string): string[] {
  const merged: string[] = [];
  let buffer = "";

  for (const chunk of chunks) {
    // If adding the next chunk exceeds maxSize, push current buffer and start new
    // We check buffer length + chunk length + separator length
    if (buffer.length + chunk.length + separator.length > maxSize && buffer.length > 0) {
      merged.push(buffer);
      buffer = chunk; // Start new buffer with current chunk
    } else {
      // Append to buffer
      buffer = buffer ? buffer + separator + chunk : chunk;
    }
  }

  // Push the remaining buffer
  if (buffer.length > 0) {
    merged.push(buffer);
  }

  return merged;
}
