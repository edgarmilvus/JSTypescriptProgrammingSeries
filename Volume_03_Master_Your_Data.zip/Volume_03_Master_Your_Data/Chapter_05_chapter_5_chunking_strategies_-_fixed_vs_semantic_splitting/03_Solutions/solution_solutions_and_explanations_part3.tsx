/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

// ChunkVisualizer.tsx
import React, { useState } from 'react';
import { chunkWithOverlap, ChunkingOptions } from './chunker'; 
import { semanticRecursiveSplit } from './chunker';

interface ChunkVisualizerProps {}

// Styles for the grid layout
const styles = {
  container: { padding: '20px', fontFamily: 'sans-serif' },
  controls: { marginBottom: '20px', padding: '10px', border: '1px solid #ccc', borderRadius: '5px' },
  grid: { display: 'flex', flexWrap: 'wrap', gap: '10px' },
  chunkCard: (index: number) => ({
    flex: '1 1 300px',
    border: '1px solid #ddd',
    borderRadius: '5px',
    padding: '10px',
    backgroundColor: index % 2 === 0 ? '#f9f9f9' : '#ffffff',
    position: 'relative' as const,
    cursor: 'pointer',
    minHeight: '100px',
    boxShadow: '0 2px 4px rgba(0,0,0,0.1)'
  }),
  tooltip: {
    position: 'absolute' as const,
    top: '5px',
    right: '5px',
    background: 'rgba(0,0,0,0.8)',
    color: '#fff',
    padding: '5px',
    borderRadius: '3px',
    fontSize: '0.8em',
    pointerEvents: 'none' as const,
    zIndex: 10
  }
};

export const ChunkVisualizer: React.FC<ChunkVisualizerProps> = () => {
  const [text, setText] = useState<string>('');
  const [chunks, setChunks] = useState<string[]>([]);
  const [strategy, setStrategy] = useState<'fixed' | 'semantic'>('fixed');
  const [chunkSize, setChunkSize] = useState<number>(100);
  const [overlap, setOverlap] = useState<number>(20);
  const [loading, setLoading] = useState<boolean>(false);
  const [hoveredIndex, setHoveredIndex] = useState<number | null>(null);

  const handleProcess = async () => {
    if (!text.trim()) return;
    setLoading(true);
    setChunks([]);

    try {
      let result: string[] = [];
      
      if (strategy === 'fixed') {
        const options: ChunkingOptions = { chunkSize, overlap, strategy: 'fixed' };
        result = await chunkWithOverlap(text, options);
      } else {
        // Semantic split: using simple separators for this demo
        // In a real app, these might be configurable
        const separators = ['\n\n', '\n', '. ', ' '];
        result = semanticRecursiveSplit(text, separators, chunkSize);
      }

      setChunks(result);
    } catch (error) {
      console.error("Chunking failed:", error);
      alert("Error processing text. Check console.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={styles.container}>
      <h2>RAG Chunk Visualizer</h2>
      
      <div style={styles.controls}>
        <div style={{ marginBottom: '10px' }}>
          <label>Strategy: </label>
          <select 
            value={strategy} 
            onChange={(e) => setStrategy(e.target.value as 'fixed' | 'semantic')}
          >
            <option value="fixed">Fixed Size + Overlap</option>
            <option value="semantic">Semantic Recursive</option>
          </select>
        </div>

        <div style={{ marginBottom: '10px' }}>
          <label>Max Size / Chunk Size: </label>
          <input 
            type="number" 
            value={chunkSize} 
            onChange={(e) => setChunkSize(Number(e.target.value))} 
            style={{ width: '60px' }}
          />
          {strategy === 'fixed' && (
            <>
              <label style={{ marginLeft: '10px' }}>Overlap: </label>
              <input 
                type="number" 
                value={overlap} 
                onChange={(e) => setOverlap(Number(e.target.value))} 
                style={{ width: '60px' }}
              />
            </>
          )}
        </div>

        <textarea
          rows={5}
          style={{ width: '100%', marginBottom: '10px' }}
          value={text}
          onChange={(e) => setText(e.target.value)}
          placeholder="Paste text here..."
        />

        <button onClick={handleProcess} disabled={loading} style={{ padding: '8px 16px' }}>
          {loading ? 'Processing...' : 'Process Text'}
        </button>
      </div>

      <div style={styles.grid}>
        {chunks.map((chunk, index) => (
          <div
            key={index}
            style={styles.chunkCard(index)}
            onMouseEnter={() => setHoveredIndex(index)}
            onMouseLeave={() => setHoveredIndex(null)}
          >
            {hoveredIndex === index && (
              <div style={styles.tooltip}>
                Index: {index} | Length: {chunk.length}
              </div>
            )}
            <div style={{ whiteSpace: 'pre-wrap', fontSize: '0.9em' }}>
              {chunk}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
