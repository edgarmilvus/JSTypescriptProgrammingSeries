/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

// test-runner.ts
import { chunkWithOverlap } from './chunker';
import { semanticRecursiveSplit } from './chunker';

// 1. Mock Embedding Generator (Deterministic)
export function generateMockEmbedding(text: string): number[] {
  const dim = 384;
  const embedding: number[] = new Array(dim);
  
  // Simple hash function to seed randomness based on text content
  let hash = 0;
  for (let i = 0; i < text.length; i++) {
    const char = text.charCodeAt(i);
    hash = ((hash << 5) - hash) + char;
    hash = hash & hash; // Convert to 32bit integer
  }

  // Generate pseudo-random floats based on the hash
  for (let i = 0; i < dim; i++) {
    // Math.sin ensures values stay within a predictable range
    const x = Math.sin(hash + i) * 10000;
    embedding[i] = x - Math.floor(x); // Fractional part
  }
  return embedding;
}

// 2. Distance Calculator
export function euclideanDistance(a: number[], b: number[]): number {
  if (a.length !== b.length) throw new Error("Vectors must be same length");
  let sum = 0;
  for (let i = 0; i < a.length; i++) {
    sum += Math.pow(a[i] - b[i], 2);
  }
  return Math.sqrt(sum);
}

// 3. Vector Search Simulation
export function findBestMatch(queryEmbedding: number[], chunks: string[], embeddings: number[][]): { chunk: string, distance: number } {
  let minDistance = Infinity;
  let bestChunk = "";
  
  for (let i = 0; i < embeddings.length; i++) {
    const dist = euclideanDistance(queryEmbedding, embeddings[i]);
    if (dist < minDistance) {
      minDistance = dist;
      bestChunk = chunks[i];
    }
  }
  return { chunk: bestChunk, distance: minDistance };
}

// 4. Main Test Runner
export async function runEvaluation() {
  const sampleText = `
    The water cycle describes how water evaporates from the surface of the Earth, rises into the atmosphere, cools and condenses into rain or snow in clouds, and falls again to the surface as precipitation. 
    The sun, which drives the water cycle, heats water in the oceans. This evaporation occurs when water changes from a liquid to a gas or vapor. 
    Water vapor rises into the air. As it rises, it cools and condenses into tiny liquid water droplets, forming clouds. 
    Wind moves air masses containing water vapor. When clouds become heavy, precipitation occurs. Water collects in rivers, lakes, and oceans, and the cycle begins again.
  `;

  // Define Strategies
  const fixedOptions = { chunkSize: 150, overlap: 20, strategy: 'fixed' as const };
  
  // 1. Chunk with Fixed Strategy
  const fixedChunks = await chunkWithOverlap(sampleText, fixedOptions);
  
  // 2. Chunk with Semantic Strategy
  const semanticChunks = semanticRecursiveSplit(sampleText, ['\n', '. '], 150);

  // 3. Generate Embeddings for both sets
  const fixedEmbeddings = fixedChunks.map(c => generateMockEmbedding(c));
  const semanticEmbeddings = semanticChunks.map(c => generateMockEmbedding(c));

  // 4. Define Queries
  const queries = [
    "How does the sun affect the water cycle?",
    "What happens when water vapor rises?",
    "Where does precipitation collect?"
  ];

  console.log("=== EVALUATION RESULTS ===\n");

  for (const query of queries) {
    const queryEmbedding = generateMockEmbedding(query);
    
    const fixedMatch = findBestMatch(queryEmbedding, fixedChunks, fixedEmbeddings);
    const semanticMatch = findBestMatch(queryEmbedding, semanticChunks, semanticEmbeddings);

    console.log(`Query: "${query}"`);
    console.log(`> Fixed Strategy Match (Dist: ${fixedMatch.distance.toFixed(4)}): ${fixedMatch.chunk.substring(0, 50)}...`);
    console.log(`> Semantic Strategy Match (Dist: ${semanticMatch.distance.toFixed(4)}): ${semanticMatch.chunk.substring(0, 50)}...`);
    
    // Simple heuristic for logging which is "better" (lower distance)
    if (fixedMatch.distance < semanticMatch.distance) {
      console.log(`>> Winner: Fixed Strategy\n`);
    } else {
      console.log(`>> Winner: Semantic Strategy\n`);
    }
  }
}

// To run this in a Node environment:
// runEvaluation();
