/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

// pipeline.ts
import { chunkWithOverlap, ChunkingOptions } from './chunker';
import { semanticRecursiveSplit } from './chunker';

// Simulate file I/O with random delay
async function readFileAsync(path: string): Promise<string> {
  return new Promise((resolve) => {
    const delay = Math.random() * 400 + 100; // 100-500ms
    setTimeout(() => {
      // Mock content varies slightly based on path to simulate different files
      const content = `Content from ${path}. The quick brown fox jumps over the lazy dog. 
      This is a simulated document for processing. ${path} contains important data about chunking strategies.`;
      resolve(content);
    }, delay);
  });
}

// Mock Embedding Generation (Step C)
function mockEmbeddingGeneration(chunk: string): string {
  // Returning a simple hash/length as a placeholder for a vector
  return `vec_${chunk.length}_${chunk.substring(0, 5)}`;
}

export async function processDocuments(
  paths: string[], 
  strategy: 'fixed' | 'semantic'
): Promise<{ path: string; chunks: string[]; embeddings: string[] }[]> {
  
  // Map each path to a promise that handles the full processing for that file
  const processingPromises = paths.map(async (path) => {
    try {
      // Step A: Read File
      const content = await readFileAsync(path);

      // Step B: Chunk Content
      let chunks: string[];
      if (strategy === 'fixed') {
        const options: ChunkingOptions = { chunkSize: 100, overlap: 10, strategy: 'fixed' };
        chunks = await chunkWithOverlap(content, options);
      } else {
        chunks = semanticRecursiveSplit(content, ['\n', '. ', ' '], 100);
      }

      // Step C: Generate Embeddings (Mock)
      const embeddings = chunks.map(mockEmbeddingGeneration);

      return { path, chunks, embeddings };

    } catch (error) {
      // Step D: Error Handling
      console.error(`Failed to process ${path}:`, error);
      // Return null or a specific error object to filter out later, 
      // or re-throw if we want Promise.all to reject.
      // Here we return a special object to allow other files to succeed.
      return { path, chunks: [], embeddings: [], error: String(error) };
    }
  });

  // Use Promise.all to wait for all parallel operations
  const results = await Promise.all(processingPromises);

  // Filter out failed results if desired, or keep them for logging
  // For this exercise, we return everything.
  return results;
}

// Example Usage:
/*
(async () => {
  const files = ['./docs/doc1.txt', './docs/doc2.md', './docs/missing.txt'];
  const results = await processDocuments(files, 'fixed');
  console.log(JSON.stringify(results, null, 2));
})();
*/
