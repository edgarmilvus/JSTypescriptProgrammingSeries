/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// pages/api/search.ts (Next.js API Route)
// This script demonstrates a server-side hybrid search implementation.
// It combines keyword (lexical) and semantic (vector) search, then reranks the results.

import type { NextApiRequest, NextApiResponse } from 'next';

// --- TYPE DEFINITIONS ---

/**
 * Represents a single document in our knowledge base.
 * In a real application, this would be a chunk from a larger document (e.g., a PDF, a webpage).
 */
interface Document {
    id: string;
    content: string;
    metadata: {
        source: string;
        category: string;
    };
    // The vector embedding for semantic search. In production, this is stored in a vector DB.
    embedding: number[];
}

/**
 * Represents a search result with a calculated relevance score.
 */
interface SearchResult {
    id: string;
    content: string;
    metadata: {
        source: string;
        category: string;
    };
    score: number;
    searchType: 'lexical' | 'semantic' | 'hybrid';
}

// --- MOCK DATA & INDEXES ---

/**
 * Mock dataset of documents. In a real system, this data is loaded from a database.
 * The `embedding` property is a placeholder for a 512-dimension vector from `text-embedding-3-small`.
 */
const MOCK_DOCUMENTS: Document[] = [
    {
        id: 'doc-1',
        content: 'Our SaaS platform offers advanced analytics for e-commerce businesses. Track sales, user engagement, and conversion rates in real-time.',
        metadata: { source: 'product_overview.md', category: 'Product' },
        embedding: Array(512).fill(0).map((_, i) => (i % 10) * 0.1), // Mock vector
    },
    {
        id: 'doc-2',
        content: 'To integrate our API, you need an API key. The documentation provides a step-by-step guide for authentication using Bearer tokens.',
        metadata: { source: 'api_docs.md', category: 'Documentation' },
        embedding: Array(512).fill(0).map((_, i) => (i % 10) * 0.1 + 0.05), // Mock vector
    },
    {
        id: 'doc-3',
        content: 'Pricing plans are available for startups, growth, and enterprise tiers. The enterprise plan includes dedicated support and custom SLAs.',
        metadata: { source: 'pricing.md', category: 'Sales' },
        embedding: Array(512).fill(0).map((_, i) => (i % 10) * 0.2), // Mock vector
    },
    {
        id: 'doc-4',
        content: 'Customer support can be reached via email or our live chat portal. We offer 24/7 assistance for all premium plan subscribers.',
        metadata: { source: 'support.md', category: 'Support' },
        embedding: Array(512).fill(0).map((_, i) => (i % 10) * 0.2 + 0.05), // Mock vector
    },
];

/**
 * Inverted Index for Keyword Search.
 * Maps tokens to a list of document IDs that contain them.
 * In production, this would be managed by a dedicated search engine like Elasticsearch.
 */
const invertedIndex: Record<string, Set<string>> = {};
function buildInvertedIndex() {
    MOCK_DOCUMENTS.forEach(doc => {
        const tokens = doc.content.toLowerCase().split(/\W+/);
        tokens.forEach(token => {
            if (token.length > 2) { // Ignore short stop words
                if (!invertedIndex[token]) {
                    invertedIndex[token] = new Set();
                }
                invertedIndex[token].add(doc.id);
            }
        });
    });
}
buildInvertedIndex();

// --- CORE SERVICES ---

/**
 * Simulates an Embedding Model (e.g., text-embedding-3-small).
 * In a real app, this would make an API call to OpenAI.
 * @param text - The input text to embed.
 * @returns A number array representing the vector embedding.
 */
async function generateEmbedding(text: string): Promise<number[]> {
    // In a real scenario: const response = await openai.embeddings.create({ model: 'text-embedding-3-small', input: text });
    // Here, we create a deterministic mock vector based on the text's hash.
    let hash = 0;
    for (let i = 0; i < text.length; i++) {
        hash = ((hash << 5) - hash) + text.charCodeAt(i);
        hash |= 0;
    }
    const vector = Array(512).fill(0).map((_, i) => {
        return (Math.abs(hash + i) % 100) / 100;
    });
    return vector;
}

/**
 * Calculates the cosine similarity between two vectors.
 * This is the core metric for K-Nearest Neighbors (KNN) search.
 * @param vecA - First vector.
 * @param vecB - Second vector.
 * @returns A similarity score between 0 and 1.
 */
function cosineSimilarity(vecA: number[], vecB: number[]): number {
    if (vecA.length !== vecB.length) {
        throw new Error('Vectors must have the same dimensionality');
    }
    let dotProduct = 0;
    let normA = 0;
    let normB = 0;
    for (let i = 0; i < vecA.length; i++) {
        dotProduct += vecA[i] * vecB[i];
        normA += vecA[i] * vecA[i];
        normB += vecB[i] * vecB[i];
    }
    if (normA === 0 || normB === 0) return 0;
    return dotProduct / (Math.sqrt(normA) * Math.sqrt(normB));
}

/**
 * The main service class that orchestrates the hybrid search.
 */
class HybridSearchService {
    /**
     * Performs keyword (lexical) search using the inverted index.
     * @param query - The user's search query.
     * @returns A map of document IDs to their lexical relevance score.
     */
    private async searchLexical(query: string): Promise<Map<string, number>> {
        const results = new Map<string, number>();
        const tokens = query.toLowerCase().split(/\W+/);

        tokens.forEach(token => {
            if (invertedIndex[token]) {
                invertedIndex[token].forEach(docId => {
                    const currentScore = results.get(docId) || 0;
                    // Simple scoring: increment score for each matching token.
                    results.set(docId, currentScore + 1);
                });
            }
        });
        return results;
    }

    /**
     * Performs semantic (vector) search using K-Nearest Neighbors.
     * @param query - The user's search query.
     * @param k - The number of top results to retrieve.
     * @returns A map of document IDs to their semantic similarity score.
     */
    private async searchSemantic(query: string, k: number): Promise<Map<string, number>> {
        const queryVector = await generateEmbedding(query);
        const results = new Map<string, number>();

        MOCK_DOCUMENTS.forEach(doc => {
            const similarity = cosineSimilarity(queryVector, doc.embedding);
            results.set(doc.id, similarity);
        });

        // Sort by similarity and take top K
        const sortedResults = Array.from(results.entries())
            .sort(([, scoreA], [, scoreB]) => scoreB - scoreA)
            .slice(0, k);

        return new Map(sortedResults);
    }

    /**
     * Merges and reranks results from lexical and semantic searches.
     * @param lexicalScores - Map of document IDs to lexical scores.
     * @param semanticScores - Map of document IDs to semantic scores.
     * @param alpha - Weight for semantic score (0 = pure lexical, 1 = pure semantic).
     * @returns A sorted array of SearchResult objects.
     */
    private rerank(
        lexicalScores: Map<string, number>,
        semanticScores: Map<string, number>,
        alpha: number
    ): SearchResult[] {
        const allDocIds = new Set([...lexicalScores.keys(), ...semanticScores.keys()]);
        const combinedResults: SearchResult[] = [];

        allDocIds.forEach(docId => {
            const doc = MOCK_DOCUMENTS.find(d => d.id === docId);
            if (!doc) return;

            const lexicalScore = lexicalScores.get(docId) || 0;
            const semanticScore = semanticScores.get(docId) || 0;

            // Normalize scores for fair combination (optional but recommended)
            // For simplicity, we assume scores are already in a comparable range.
            // A weighted sum is a common and effective reranking strategy.
            const hybridScore = (1 - alpha) * lexicalScore + alpha * semanticScore;

            combinedResults.push({
                id: doc.id,
                content: doc.content,
                metadata: doc.metadata,
                score: hybridScore,
                searchType: 'hybrid',
            });
        });

        // Sort by the final hybrid score in descending order
        return combinedResults.sort((a, b) => b.score - a.score);
    }

    /**
     * Executes the full hybrid search pipeline.
     * @param query - The user's search query.
     * @param options - Configuration for the search (e.g., weights, result count).
     * @returns A promise that resolves to an array of ranked search results.
     */
    public async search(
        query: string,
        options: { alpha?: number; topK?: number } = {}
    ): Promise<SearchResult[]> {
        const { alpha = 0.5, topK = 5 } = options; // Default: equal weight, top 5 results

        // 1. Execute both search paths in parallel for efficiency
        const [lexicalScores, semanticScores] = await Promise.all([
            this.searchLexical(query),
            this.searchSemantic(query, topK * 2), // Get a larger pool for reranking
        ]);

        // 2. Rerank the combined results
        const rankedResults = this.rerank(lexicalScores, semanticScores, alpha);

        // 3. Return the top K results
        return rankedResults.slice(0, topK);
    }
}

// --- NEXT.JS API HANDLER ---

export default async function handler(
    req: NextApiRequest,
    res: NextApiResponse
) {
    // Only allow GET requests
    if (req.method !== 'GET') {
        res.setHeader('Allow', ['GET']);
        return res.status(405).json({ error: `Method ${req.method} Not Allowed` });
    }

    const { q: query, alpha, topK } = req.query;

    if (!query || typeof query !== 'string') {
        return res.status(400).json({ error: 'A search query "q" is required.' });
    }

    try {
        const searchService = new HybridSearchService();
        const results = await searchService.search(query, {
            alpha: alpha ? parseFloat(alpha as string) : undefined,
            topK: topK ? parseInt(topK as string) : undefined,
        });

        return res.status(200).json({
            query,
            resultCount: results.length,
            results,
        });
    } catch (error) {
        console.error('Search error:', error);
        return res.status(500).json({ error: 'An internal server error occurred.' });
    }
}
