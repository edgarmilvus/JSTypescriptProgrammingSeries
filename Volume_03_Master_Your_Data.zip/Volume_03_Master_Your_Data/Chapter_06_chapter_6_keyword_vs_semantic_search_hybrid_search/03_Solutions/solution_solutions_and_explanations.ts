/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// Define the configuration interface as specified
interface SearchQueryConfig {
  searchType: 'keyword' | 'semantic' | 'hybrid';
  queryText: string;
  vectorEmbedding?: number[];
  topK: number;
  hybridAlpha?: number;
}

/**
 * Builds a search query object for Pinecone-style databases.
 * @param config - The search configuration parameters.
 * @returns A query object compatible with the database.
 * @throws Error if vector embedding is missing for semantic/hybrid modes or if alpha is invalid.
 */
function buildSearchQuery(config: SearchQueryConfig): object {
  const { searchType, queryText, vectorEmbedding, topK, hybridAlpha } = config;

  // Common base object
  const baseQuery = {
    queryText,
    topK,
  };

  // Logic based on search type
  switch (searchType) {
    case 'keyword':
      // Pure keyword search: relies on text index filtering
      return {
        ...baseQuery,
        filter: { text: queryText }, // Simulating a text index query
      };

    case 'semantic':
      // Semantic search: relies on vector similarity
      if (!vectorEmbedding) {
        throw new Error("Missing required 'vectorEmbedding' for semantic search.");
      }
      return {
        ...baseQuery,
        vector: vectorEmbedding,
      };

    case 'hybrid':
      // Hybrid search: combines vector and keyword filter
      if (!vectorEmbedding) {
        throw new Error("Missing required 'vectorEmbedding' for hybrid search.");
      }
      if (hybridAlpha === undefined || hybridAlpha < 0 || hybridAlpha > 1) {
        throw new Error("Invalid 'hybridAlpha'. Must be a number between 0 and 1.");
      }
      return {
        ...baseQuery,
        vector: vectorEmbedding,
        filter: { text: queryText },
        hybridAlpha, // Controls the weight of semantic vs keyword
      };

    default:
      throw new Error(`Unknown search type: ${searchType}`);
  }
}
