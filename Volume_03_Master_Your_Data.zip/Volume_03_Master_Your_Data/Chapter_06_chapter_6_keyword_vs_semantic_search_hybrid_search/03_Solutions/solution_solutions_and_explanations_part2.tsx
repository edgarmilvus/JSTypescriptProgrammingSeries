/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.tsx
// Description: Solutions and Explanations
// ==========================================

import React from 'react';

// Define the interfaces as specified
interface SearchResult {
  id: string;
  content: string;
  source: string;
  scores: {
    keyword: number;
    semantic: number;
    combined: number;
  };
}

interface SearchResultItemProps {
  result: SearchResult;
}

// Simple CSS-in-JS styles for demonstration (or use CSS Modules)
const styles = {
  container: {
    border: '1px solid #e0e0e0',
    borderRadius: '8px',
    padding: '16px',
    marginBottom: '12px',
    fontFamily: 'Arial, sans-serif',
    backgroundColor: '#fff',
    boxShadow: '0 2px 4px rgba(0,0,0,0.05)',
  },
  header: {
    display: 'flex',
    justifyContent: 'space-between',
    marginBottom: '8px',
  },
  content: {
    fontSize: '16px',
    color: '#333',
    marginBottom: '8px',
    lineHeight: '1.5',
  },
  source: {
    fontSize: '12px',
    color: '#666',
    marginBottom: '12px',
  },
  chartContainer: {
    marginTop: '10px',
  },
  barWrapper: {
    display: 'flex',
    height: '20px',
    borderRadius: '10px',
    overflow: 'hidden',
    backgroundColor: '#f0f0f0',
    width: '100%',
  },
  keywordBar: {
    backgroundColor: '#ff9800', // Orange for keyword
    height: '100%',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    color: 'white',
    fontSize: '10px',
    fontWeight: 'bold',
  },
  semanticBar: {
    backgroundColor: '#2196f3', // Blue for semantic
    height: '100%',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    color: 'white',
    fontSize: '10px',
    fontWeight: 'bold',
  },
  label: {
    fontSize: '12px',
    fontWeight: 'bold',
    marginTop: '4px',
    textAlign: 'right',
  },
};

const SearchResultItem: React.FC<SearchResultItemProps> = ({ result }) => {
  const { content, source, scores } = result;

  // Calculate percentages for the bar chart
  // We normalize based on the combined score to show relative contribution
  const total = scores.keyword + scores.semantic;
  const keywordPercent = total > 0 ? (scores.keyword / total) * 100 : 0;
  const semanticPercent = total > 0 ? (scores.semantic / total) * 100 : 0;

  // Determine dominant method
  const isSemanticDominant = scores.semantic > scores.keyword;
  const dominantLabel = isSemanticDominant ? "Semantic Match" : "Keyword Match";

  return (
    <div style={styles.container}>
      <div style={styles.header}>
        <strong>Result ID: {result.id}</strong>
      </div>
      <div style={styles.content}>{content}</div>
      <div style={styles.source}>Source: {source}</div>
      
      {/* Visual Breakdown */}
      <div style={styles.chartContainer}>
        <div style={styles.barWrapper}>
          <div style={{ ...styles.keywordBar, width: `${keywordPercent}%` }}>
            {keywordPercent > 10 && `K: ${scores.keyword.toFixed(2)}`}
          </div>
          <div style={{ ...styles.semanticBar, width: `${semanticPercent}%` }}>
            {semanticPercent > 10 && `S: ${scores.semantic.toFixed(2)}`}
          </div>
        </div>
        <div style={styles.label}>
          Dominant: {dominantLabel} ({scores.combined.toFixed(2)})
        </div>
      </div>
    </div>
  );
};

export default SearchResultItem;
