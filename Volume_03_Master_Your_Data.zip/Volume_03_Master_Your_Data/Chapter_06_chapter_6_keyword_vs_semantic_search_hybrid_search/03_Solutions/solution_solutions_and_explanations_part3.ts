/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

// Define the discriminated union type
type ChunkingStrategy =
  | { type: 'FixedLength'; chunkSize: number; overlap: number }
  | { type: 'RecursiveCharacter'; chunkSize: number; separators: string[] }
  | { type: 'Semantic'; minimumLength: number; maximumLength: number };

/**
 * Validates a chunking configuration strategy.
 * @param strategy - The chunking configuration.
 * @returns An object containing validity status and an array of error messages.
 */
function validateChunkingConfig(strategy: ChunkingStrategy): { valid: boolean; errors: string[] } {
  const errors: string[] = [];

  // Discriminated union allows safe access to specific properties
  switch (strategy.type) {
    case 'FixedLength':
      if (strategy.chunkSize <= 0) errors.push("Chunk size must be greater than 0.");
      if (strategy.overlap < 0) errors.push("Overlap cannot be negative.");
      if (strategy.overlap >= strategy.chunkSize) {
        errors.push("Overlap must be less than chunk size.");
      }
      break;

    case 'RecursiveCharacter':
      if (strategy.chunkSize <= 0) errors.push("Chunk size must be greater than 0.");
      if (!strategy.separators || strategy.separators.length === 0) {
        errors.push("Separators array cannot be empty.");
      }
      break;

    case 'Semantic':
      if (strategy.minimumLength <= 0) errors.push("Minimum length must be greater than 0.");
      if (strategy.maximumLength <= 0) errors.push("Maximum length must be greater than 0.");
      if (strategy.minimumLength >= strategy.maximumLength) {
        errors.push("Minimum length must be strictly less than maximum length.");
      }
      break;
    
    default:
      // Exhaustiveness check (good practice, though TS usually catches this)
      const _exhaustiveCheck: never = strategy;
      return { valid: false, errors: ["Unknown strategy type."] };
  }

  return {
    valid: errors.length === 0,
    errors,
  };
}
