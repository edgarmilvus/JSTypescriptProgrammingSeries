/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

interface SearchCandidate {
  id: string;
  keywordScore: number;
  semanticScore: number;
}

/**
 * Simulates hybrid ranking by combining keyword and semantic scores.
 * @param results - Array of search candidates.
 * @param alpha - Weight for semantic score (0.0 to 1.0).
 * @returns - Sorted array of results based on combined score.
 */
function simulateHybridRanking(results: SearchCandidate[], alpha: number): SearchCandidate[] {
  // Calculate combined score
  const scoredResults = results.map(result => ({
    ...result,
    combinedScore: (alpha * result.semanticScore) + ((1 - alpha) * result.keywordScore)
  }));

  // Sort descending by combined score
  scoredResults.sort((a, b) => b.combinedScore - a.combinedScore);

  return scoredResults;
}

// --- Interactive Loop & Mock Data ---

// Mock Data: 
// ID 1: High Keyword, Low Semantic (Traditional match)
// ID 2: Low Keyword, High Semantic (Conceptual match)
// ID 3: Moderate Keyword, Moderate Semantic (Balanced)
const mockData: SearchCandidate[] = [
  { id: 'Doc_A', keywordScore: 0.9, semanticScore: 0.2 }, 
  { id: 'Doc_B', keywordScore: 0.2, semanticScore: 0.9 },
  { id: 'Doc_C', keywordScore: 0.6, semanticScore: 0.6 },
];

console.log("--- Hybrid Search Simulation ---");

for (let alpha = 0; alpha <= 1.0; alpha += 0.1) {
  // Round alpha for cleaner logging
  const currentAlpha = Math.round(alpha * 10) / 10;
  
  const rankedResults = simulateHybridRanking(mockData, currentAlpha);
  const topResult = rankedResults[0];

  console.log(`Alpha (Semantic Weight): ${currentAlpha.toFixed(1)} | Top Result: ${topResult.id} (Score: ${topResult.combinedScore.toFixed(3)})`);
}

/* 
 * OBSERVATION ANALYSIS:
 * 
 * As alpha increases from 0.0 to 1.0:
 * 1. Low Alpha (0.0 - 0.3): The ranking is dominated by 'keywordScore'. 
 *    'Doc_A' (High Keyword) will likely be the top result because the system prioritizes exact text matches.
 * 2. Mid Alpha (0.4 - 0.6): A transition phase. 'Doc_C' might rise to the top if its balanced scores 
 *    yield a higher weighted average than the extremes of A or B.
 * 3. High Alpha (0.7 - 1.0): The ranking is dominated by 'semanticScore'. 
 *    'Doc_B' (High Semantic) becomes the top result, representing a conceptual match rather than a lexical one.
 * 
 * This demonstrates the "tuning" capability: adjusting alpha shifts the retrieval strategy from 
 * precision (keyword) to recall/conceptual understanding (semantic).
 */
