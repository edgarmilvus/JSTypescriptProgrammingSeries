/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

digraph HybridSearchPipeline {
    rankdir=LR; // Layout from Left to Right
    node [shape=box, style="rounded,filled", fontname="Helvetica"];
    edge [fontname="Helvetica", fontsize=10];

    // --- Input Nodes ---
    node [fillcolor="#e1f5fe"]; // Light Blue
    "Raw Documents" [shape=folder];
    "User Query" [shape=ellipse];

    // --- Processing Nodes ---
    node [fillcolor="#fff3e0"]; // Light Orange
    "Text Chunking";
    "Embedding Generation";
    "Query Embedding";

    // --- Storage Nodes ---
    node [fillcolor="#e8f5e9"]; // Light Green
    "Vector Index" [shape=cylinder];
    "Keyword Index" [shape=cylinder];

    // --- Logic/Ranker Nodes ---
    node [fillcolor="#f3e5f5"]; // Light Purple
    "Hybrid Ranker";

    // --- Output Node ---
    node [fillcolor="#eeeeee"]; // Light Grey
    "Final Results" [shape=doubleoctagon];

    // --- Edges: Ingestion Path ---
    "Raw Documents" -> "Text Chunking" [label="Full Text"];
    "Text Chunking" -> "Embedding Generation" [label="Chunks"];
    "Embedding Generation" -> "Vector Index" [label="Vectors"];
    
    // Parallel Indexing (Implicit in pipeline, shown for clarity)
    "Text Chunking" -> "Keyword Index" [label="Text Chunks"];

    // --- Edges: Query Path (Divergence) ---
    "User Query" -> "Query Embedding" [label="Text", color="blue", penwidth=2];
    "User Query" -> "Keyword Index" [label="Text", color="orange", penwidth=2];

    // --- Edges: Retrieval (Convergence) ---
    "Query Embedding" -> "Vector Index" [label="Vector Search", color="blue", penwidth=2];
    "Vector Index" -> "Hybrid Ranker" [label="Top K Vectors", color="blue", style=dashed];
    
    "Keyword Index" -> "Hybrid Ranker" [label="Top K Matches", color="orange", style=dashed];

    // --- Edges: Ranking ---
    "Hybrid Ranker" -> "Final Results" [label="Ranked List", penwidth=2];

    // --- Subgraph for Visual Grouping (Optional but helpful) ---
    subgraph cluster_ingestion {
        label = "Ingestion Pipeline";
        style = "dashed";
        "Raw Documents" -> "Text Chunking" -> "Embedding Generation";
    }
}
