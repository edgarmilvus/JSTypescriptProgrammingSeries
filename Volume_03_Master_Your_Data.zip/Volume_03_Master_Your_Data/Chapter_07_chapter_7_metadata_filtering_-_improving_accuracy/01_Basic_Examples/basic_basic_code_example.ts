/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

// app/api/search/route.ts
import { NextResponse } from 'next/server';

// ==========================================
// 1. Type Definitions
// ==========================================

/**
 * Represents a document stored in our simulated vector database.
 * @property id - Unique identifier.
 * @property text - The raw text content.
 * @property embedding - The vector representation (simplified as number[]).
 * @property metadata - Scalar fields for filtering.
 */
type Document = {
  id: string;
  text: string;
  embedding: number[]; // In production, this is a 1536-dim vector (OpenAI ada-002)
  metadata: {
    author: string;
    category: string;
    year: number;
  };
};

/**
 * Request body structure for the API endpoint.
 * @property query - The user's natural language search term.
 * @property filters - Key-value pairs to filter results by.
 */
type SearchRequest = {
  query: string;
  filters: {
    author?: string;
    category?: string;
    year?: { $gt: number }; // Simple operator simulation
  };
};

// ==========================================
// 2. Simulated Vector Database (Mock Data)
// ==========================================

// In a real app, this lives in Pinecone, Weaviate, or PostgreSQL (pgvector).
const mockVectorDB: Document[] = [
  {
    id: "doc_1",
    text: "JavaScript is a versatile language for web development.",
    embedding: [0.1, 0.2, 0.9], // High similarity to "JS web dev"
    metadata: { author: "Smith", category: "Tech", year: 2021 }
  },
  {
    id: "doc_2",
    text: "TypeScript adds static typing to JavaScript, improving reliability.",
    embedding: [0.15, 0.25, 0.85], // Similar to doc_1
    metadata: { author: "Doe", category: "Tech", year: 2023 }
  },
  {
    id: "doc_3",
    text: "Cooking pasta requires boiling water and salt.",
    embedding: [0.8, 0.9, 0.1], // Completely different vector space
    metadata: { author: "Smith", category: "Culinary", year: 2019 }
  },
  {
    id: "doc_4",
    text: "Advanced React patterns with hooks.",
    embedding: [0.12, 0.22, 0.88], // Very close to doc_1
    metadata: { author: "Doe", category: "Tech", year: 2024 }
  }
];

// ==========================================
// 3. Helper Functions
// ==========================================

/**
 * Calculates Cosine Similarity between two vectors.
 * Formula: (A . B) / (||A|| * ||B||)
 * Used to rank how "close" a document is to the query.
 */
function cosineSimilarity(vecA: number[], vecB: number[]): number {
  const dotProduct = vecA.reduce((acc, val, i) => acc + val * vecB[i], 0);
  const magnitudeA = Math.sqrt(vecA.reduce((acc, val) => acc + val * val, 0));
  const magnitudeB = Math.sqrt(vecB.reduce((acc, val) => acc + val * val, 0));
  
  if (magnitudeA === 0 || magnitudeB === 0) return 0;
  return dotProduct / (magnitudeA * magnitudeB);
}

/**
 * Simulates an embedding generation call (e.g., OpenAI Embeddings API).
 * In production, this would be an async call to an LLM provider.
 * We return a hardcoded vector for the specific query "JS web dev" to ensure
 * deterministic results for this example.
 */
async function generateEmbedding(query: string): Promise<number[]> {
  // Simulate network delay
  await new Promise(resolve => setTimeout(resolve, 100));
  
  // Hardcoded vector for "JS web dev" to match doc_1 and doc_4
  // In reality, "JS web dev" -> [0.11, 0.21, 0.89]
  return [0.11, 0.21, 0.89];
}

/**
 * Applies scalar filters to a list of documents.
 * This is the "Pre-filtering" strategy: we filter BEFORE calculating similarity
 * to save computational resources.
 */
function applyMetadataFilters(
  documents: Document[], 
  filters: SearchRequest['filters']
): Document[] {
  return documents.filter(doc => {
    // Check Author Filter
    if (filters.author && doc.metadata.author !== filters.author) {
      return false;
    }

    // Check Category Filter
    if (filters.category && doc.metadata.category !== filters.category) {
      return false;
    }

    // Check Year Filter (Greater Than)
    if (filters.year?.$gt && doc.metadata.year <= filters.year.$gt) {
      return false;
    }

    return true;
  });
}

// ==========================================
// 4. API Route Handler (Next.js App Router)
// ==========================================

/**
 * POST /api/search
 * Accepts a query and filters, returns ranked documents.
 */
export async function POST(request: Request) {
  try {
    // 1. Parse Request Body
    const body = await request.json() as SearchRequest;
    const { query, filters = {} } = body;

    if (!query) {
      return NextResponse.json(
        { error: "Query is required" }, 
        { status: 400 }
      );
    }

    // 2. Generate Query Embedding
    // Convert natural language query into a vector representation.
    const queryVector = await generateEmbedding(query);

    // 3. Apply Metadata Filtering (Pre-filtering)
    // We filter the database *before* calculating similarity scores.
    // This reduces the search space and avoids processing irrelevant documents.
    const filteredDocs = applyMetadataFilters(mockVectorDB, filters);

    if (filteredDocs.length === 0) {
      return NextResponse.json({ results: [] });
    }

    // 4. Calculate Similarity Scores
    // Compare the query vector against the filtered document vectors.
    const rankedDocs = filteredDocs.map(doc => {
      const score = cosineSimilarity(queryVector, doc.embedding);
      return {
        ...doc,
        similarityScore: score
      };
    });

    // 5. Sort by Score (Descending)
    rankedDocs.sort((a, b) => b.similarityScore - a.similarityScore);

    // 6. Return Top Results
    // We limit the response to the most relevant matches.
    const topResults = rankedDocs.slice(0, 5);

    return NextResponse.json({
      query,
      filtersApplied: filters,
      count: topResults.length,
      results: topResults
    });

  } catch (error) {
    console.error("Search API Error:", error);
    return NextResponse.json(
      { error: "Internal Server Error" }, 
      { status: 500 }
    );
  }
}
