/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// app/api/chat/route.ts
import { NextRequest, NextResponse } from 'next/server';
import OpenAI from 'openai';
import { VectorStoreClient } from '@/lib/vector-store'; // Hypothetical client wrapper

// -----------------------------------------------------------------------------
// CONFIGURATION & TYPES
// -----------------------------------------------------------------------------

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

// Define the structure of our metadata filters
interface MetadataFilter {
  department?: string;
  dateRange?: { start: string; end: string };
  author?: string;
  status?: 'published' | 'draft';
}

// Define the expected request payload
interface ChatRequest {
  query: string;
  filters?: MetadataFilter;
  conversationId?: string;
}

// -----------------------------------------------------------------------------
// HELPER: FEW-SHOT PROMPT CONSTRUCTION
// -----------------------------------------------------------------------------

/**
 * Constructs a system prompt with few-shot examples to guide the LLM.
 * This ensures the model understands how to handle the specific enterprise context
 * and cite the filtered documents.
 */
const buildSystemPrompt = (filters: MetadataFilter) => {
  const filterContext = Object.entries(filters || {})
    .map(([key, value]) => `${key}: ${JSON.stringify(value)}`)
    .join(', ');

  return `
    You are an AI Enterprise Search Assistant. Your goal is to answer user queries strictly based on the provided context.
    
    CONSTRAINTS:
    1. Only use information from the <CONTEXT> block below.
    2. If the answer is not in the context, state "I could not find relevant information based on the current filters."
    3. Cite your sources by referencing the document ID.
    4. Current Active Filters: ${filterContext || 'None'}.

    EXAMPLES (Few-Shot Prompting):
    User: "What was the revenue in Q3?"
    Context: [DocID: 123, Content: "Q3 revenue was $5M.", Metadata: { Dept: Finance }]
    Assistant: "According to document 123, Q3 revenue was $5M."

    User: "Find project updates."
    Context: []
    Assistant: "I could not find relevant information based on the current filters."

    Begin processing the user query.
  `;
};

// -----------------------------------------------------------------------------
// CORE LOGIC: DYNAMIC METADATA FILTERING & STREAMING
// -----------------------------------------------------------------------------

/**
 * POST Handler for the Chat API.
 * 
 * Flow:
 * 1. Parse request and validate inputs.
 * 2. Generate vector embedding for the user query.
 * 3. Query Vector DB with scalar metadata filters (Pre-filtering).
 * 4. Construct a prompt using the retrieved context and few-shot examples.
 * 5. Stream the LLM response back to the client.
 */
export async function POST(req: NextRequest) {
  try {
    // 1. REQUEST PARSING
    const body: ChatRequest = await req.json();
    const { query, filters = {} } = body;

    if (!query) {
      return new NextResponse('Query is required', { status: 400 });
    }

    // 2. EMBEDDING GENERATION
    // In a production environment, caching embeddings is recommended.
    const embeddingResponse = await openai.embeddings.create({
      model: 'text-embedding-ada-002',
      input: query,
    });
    const queryVector = embeddingResponse.data[0].embedding;

    // 3. VECTOR STORE QUERY (PRE-FILTERING)
    // We pass the metadata filters to the vector store.
    // The database filters records *before* calculating cosine similarity,
    // drastically reducing latency and cost for large datasets.
    const vectorStore = new VectorStoreClient(process.env.VECTOR_DB_INDEX!);
    
    const searchResults = await vectorStore.query({
      vector: queryVector,
      topK: 5,
      filter: {
        // Dynamic mapping of filters to DB schema
        ...(filters.department && { department: filters.department }),
        ...(filters.author && { author: filters.author }),
        // Example of range filtering (syntax depends on specific DB)
        ...(filters.dateRange && { 
          $and: [
            { date: { $gte: filters.dateRange.start } },
            { date: { $lte: filters.dateRange.end } }
          ]
        })
      }
    });

    // 4. CONTEXT PREPARATION
    // Format retrieved documents for the LLM context window
    const contextText = searchResults.matches
      .map((match) => {
        const meta = match.metadata;
        return `[DocID: ${match.id} | ${meta.department} | ${meta.date}] Content: ${meta.content || match.content}`;
      })
      .join('\n\n---\n\n');

    // 5. STREAMING RESPONSE GENERATION
    // We use the Edge Runtime compatible streaming approach
    
    const systemPrompt = buildSystemPrompt(filters);
    
    const stream = await openai.chat.completions.create({
      model: 'gpt-4-turbo-preview',
      stream: true,
      messages: [
        { role: 'system', content: systemPrompt },
        { role: 'user', content: `Context:\n<context>${contextText}</context>\n\nUser Query: ${query}` }
      ],
      temperature: 0.2, // Lower temp for factual retrieval
    });

    // 6. RETURN STREAM
    // Convert OpenAI stream to Next.js ReadableStream
    const encoder = new TextEncoder();
    const readableStream = new ReadableStream({
      async start(controller) {
        for await (const chunk of stream) {
          const content = chunk.choices[0]?.delta?.content;
          if (content) {
            controller.enqueue(encoder.encode(content));
          }
        }
        controller.close();
      },
    });

    return new Response(readableStream, {
      headers: {
        'Content-Type': 'text/event-stream',
        'Cache-Control': 'no-cache',
        'Connection': 'keep-alive',
      },
    });

  } catch (error) {
    console.error('API Error:', error);
    return new NextResponse('Internal Server Error', { status: 500 });
  }
}
