/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// types.ts
export interface DocumentMetadata {
  author: string;
  department: string;
  dateCreated: Date;
  documentType: 'report' | 'email' | 'presentation';
}

interface QueryParams {
  author?: string;
  department?: string;
  startDate?: string; // ISO date string
  endDate?: string;   // ISO date string
  documentType?: string;
  [key: string]: any; // Allow for dynamic keys
}

/**
 * Validates query parameters against the DocumentMetadata schema.
 * Throws an error if an invalid field is requested.
 */
function validateQueryParams(params: QueryParams) {
  const validKeys = new Set([
    'author', 'department', 'startDate', 'endDate', 'documentType'
  ]);
  
  for (const key in params) {
    if (!validKeys.has(key)) {
      throw new Error(`400 Bad Request: Invalid filter field '${key}' provided.`);
    }
  }
}

/**
 * Builds a structured filter object for a vector database (e.g., Pinecone style).
 * Handles optional parameters and date ranges.
 */
export function buildMetadataFilter(params: QueryParams): any {
  // 1. Validate inputs
  validateQueryParams(params);

  const filter: any = {};

  // 2. Map simple equality filters
  if (params.author) {
    filter.author = { $eq: params.author };
  }
  if (params.department) {
    filter.department = { $eq: params.department };
  }
  if (params.documentType && params.documentType !== 'all') {
    filter.documentType = { $eq: params.documentType };
  }

  // 3. Handle Date Range (Start and End)
  if (params.startDate || params.endDate) {
    filter.dateCreated = {};
    if (params.startDate) {
      filter.dateCreated.$gte = new Date(params.startDate);
    }
    if (params.endDate) {
      filter.dateCreated.$lte = new Date(params.endDate);
    }
  }

  return filter;
}

/**
 * Mocks a vector database search function.
 * In a real scenario, this would connect to Pinecone, Weaviate, etc.
 */
async function mockVectorSearch(embedding: number[], filter: any) {
  console.log("Performing vector search with filter:", JSON.stringify(filter, null, 2));
  // Simulate database latency
  return new Promise(resolve => setTimeout(resolve, 100, { results: [] }));
}

/**
 * Main entry point for the search API.
 */
export async function searchWithMetadata(
  embedding: number[],
  queryParams: QueryParams
) {
  try {
    const filter = buildMetadataFilter(queryParams);
    const results = await mockVectorSearch(embedding, filter);
    return results;
  } catch (error: any) {
    // Return 400 status code for invalid filters
    if (error.message.startsWith('400')) {
      return { status: 400, error: error.message };
    }
    return { status: 500, error: 'Internal Server Error' };
  }
}

// --- Interactive Challenge Simulation ---

// Helper to generate a mock embedding (array of 1536 numbers)
const generateMockEmbedding = (): number[] => new Array(1536).fill(0.5);

async function runSimulation() {
  console.log("--- Exercise 1 Simulation ---");

  // Test Case 1: Valid filter (Author + Date)
  console.log("\n[1] Testing Valid Filter (Author + Date Range):");
  await searchWithMetadata(generateMockEmbedding(), {
    author: "Jane Doe",
    startDate: "2023-01-01",
    endDate: "2023-12-31"
  });

  // Test Case 2: Valid filter (Document Type only)
  console.log("\n[2] Testing Valid Filter (Document Type):");
  await searchWithMetadata(generateMockEmbedding(), {
    documentType: "report"
  });

  // Test Case 3: Invalid Field (Should throw 400)
  console.log("\n[3] Testing Invalid Field (Should fail):");
  const result = await searchWithMetadata(generateMockEmbedding(), {
    invalidField: "hacker"
  } as any);
  console.log("API Response:", result);
}

// To run: uncomment the line below
// runSimulation();
