/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState, useEffect, useCallback } from 'react';

interface FilterState {
  author?: string;
  department?: string;
  startDate?: string;
  endDate?: string;
  documentType?: 'report' | 'email' | 'presentation' | 'all';
}

// Mock API call function
const fetchResults = async (filters: FilterState) => {
  console.log("Fetching with filters:", filters);
  return new Promise<{ id: string; title: string }[]>((resolve) => {
    setTimeout(() => resolve([{ id: '1', title: 'Mock Result' }]), 500);
  });
};

// Custom Hook: useDebouncedFetch
const useDebouncedFetch = (filters: FilterState) => {
  const [data, setData] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const handler = setTimeout(async () => {
      if (!filters.documentType && !filters.author && !filters.department) {
        setData([]); // Clear if no filters
        return;
      }

      setLoading(true);
      setError(null);
      try {
        const results = await fetchResults(filters);
        setData(results);
      } catch (err) {
        setError("Failed to fetch");
      } finally {
        setLoading(false);
      }
    }, 500); // 500ms debounce

    return () => clearTimeout(handler);
  }, [filters]);

  return { data, loading, error };
};

export const MetadataFilterSidebar: React.FC = () => {
  const [filters, setFilters] = useState<FilterState>({ documentType: 'all' });
  
  // Use the custom hook
  const { data, loading, error } = useDebouncedFetch(filters);

  // Handlers for input changes
  const handleInputChange = (key: keyof FilterState, value: string | undefined) => {
    setFilters(prev => {
      const newFilters = { ...prev };
      if (value === undefined || value === '' || value === 'all') {
        delete newFilters[key];
      } else {
        newFilters[key] = value as any;
      }
      return newFilters;
    });
  };

  const clearFilters = () => {
    setFilters({ documentType: 'all' });
  };

  const removeFilterChip = (key: keyof FilterState) => {
    handleInputChange(key, undefined);
  };

  // Helper to render active chips
  const renderChips = () => {
    const chips: React.ReactNode[] = [];
    Object.entries(filters).forEach(([key, value]) => {
      if (key === 'documentType' && value === 'all') return;
      if (value) {
        chips.push(
          <span key={key} className="filter-chip">
            {key}: {value.toString()}
            <button onClick={() => removeFilterChip(key as keyof FilterState)}>x</button>
          </span>
        );
      }
    });
    return chips;
  };

  return (
    <div className="sidebar" style={{ padding: '20px', borderRight: '1px solid #ccc' }}>
      <h3>Filters</h3>
      
      {/* Document Type Dropdown */}
      <div>
        <label>Document Type: </label>
        <select 
          value={filters.documentType || 'all'} 
          onChange={(e) => handleInputChange('documentType', e.target.value)}
        >
          <option value="all">All</option>
          <option value="report">Report</option>
          <option value="email">Email</option>
          <option value="presentation">Presentation</option>
        </select>
      </div>

      {/* Author Input */}
      <div style={{ marginTop: 10 }}>
        <label>Author: </label>
        <input 
          type="text" 
          value={filters.author || ''} 
          onChange={(e) => handleInputChange('author', e.target.value)}
          placeholder="Enter author name"
        />
      </div>

      {/* Department Input (Simple text for simulation) */}
      <div style={{ marginTop: 10 }}>
        <label>Department: </label>
        <input 
          type="text" 
          value={filters.department || ''} 
          onChange={(e) => handleInputChange('department', e.target.value)}
          placeholder="Enter department"
        />
      </div>

      {/* Date Range */}
      <div style={{ marginTop: 10 }}>
        <label>Start Date: </label>
        <input 
          type="date" 
          value={filters.startDate || ''} 
          onChange={(e) => handleInputChange('startDate', e.target.value)}
        />
      </div>
      <div style={{ marginTop: 5 }}>
        <label>End Date: </label>
        <input 
          type="date" 
          value={filters.endDate || ''} 
          onChange={(e) => handleInputChange('endDate', e.target.value)}
        />
      </div>

      <button onClick={clearFilters} style={{ marginTop: 15 }}>Clear Filters</button>

      {/* Active Filter Chips */}
      <div style={{ marginTop: 20, minHeight: 50 }}>
        <strong>Active:</strong>
        <div style={{ display: 'flex', gap: '5px', flexWrap: 'wrap' }}>
          {renderChips()}
        </div>
      </div>

      {/* Results Area */}
      <div style={{ marginTop: 20 }}>
        {loading && <p>Loading...</p>}
        {error && <p style={{ color: 'red' }}>{error}</p>}
        {!loading && !error && (
          <ul>
            {data.map((item) => (
              <li key={item.id}>{item.title}</li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
};
