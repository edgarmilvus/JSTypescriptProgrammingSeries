/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

interface SearchResult {
  id: string;
  content: string;
  metadata: {
    author: string;
    dateCreated: Date;
    score: number; // Vector similarity score (lower is better for distance)
  };
}

interface FilterCriteria {
  author?: string;
  startDate?: Date;
  endDate?: Date;
  minScore?: number;
}

/**
 * Simulates a vector database query. 
 * In a real scenario, this would be the only part hitting the expensive DB.
 */
async function simulateVectorSearch(
  embedding: number[],
  looseFilter: FilterCriteria,
  topK: number
): Promise<SearchResult[]> {
  console.log(`[Vector DB] Querying top ${topK} with loose filter:`, looseFilter);
  
  // Mocking 50 results
  const mockResults: SearchResult[] = [];
  for (let i = 0; i < 50; i++) {
    mockResults.push({
      id: `doc_${i}`,
      content: `Content snippet ${i}`,
      metadata: {
        author: i % 2 === 0 ? 'John Doe' : 'Jane Smith', // Alternating authors
        dateCreated: new Date(2022 + (i % 3), i % 12, 1), // Dates between 2022-2024
        score: Math.random() * 0.5 // Random similarity score
      }
    });
  }
  
  // Simulate filtering by loose constraints (e.g., DB handles date ranges efficiently)
  const preFiltered = mockResults.filter(r => {
    let match = true;
    if (looseFilter.startDate) match = match && r.metadata.dateCreated >= looseFilter.startDate;
    if (looseFilter.endDate) match = match && r.metadata.dateCreated <= looseFilter.endDate;
    return match;
  });

  // Return top K requested (simulating vector search limit)
  return preFiltered.slice(0, topK);
}

export async function hybridSearch(
  textQuery: string,
  looseFilter: FilterCriteria,
  strictFilter: FilterCriteria,
  topK: number = 10
): Promise<SearchResult[]> {
  const startTime = Date.now();
  
  // 1. Generate embedding (mock)
  const embedding = new Array(1536).fill(0.5);
  
  // 2. Pre-filter: Vector search with loose constraints
  // We fetch a larger set (e.g., 50) to ensure we have enough candidates for strict filtering
  const initialResults = await simulateVectorSearch(embedding, looseFilter, 50);
  const searchTime = Date.now() - startTime;

  // 3. Post-filter: Apply strict constraints in memory
  const postFilterStart = Date.now();
  const filteredResults = initialResults.filter(result => {
    // Check Author (Strict)
    if (strictFilter.author && result.metadata.author !== strictFilter.author) {
      return false;
    }
    
    // Check Date Range (Strict)
    if (strictFilter.startDate && result.metadata.dateCreated < strictFilter.startDate) return false;
    if (strictFilter.endDate && result.metadata.dateCreated > strictFilter.endDate) return false;

    // Check Score (Strict)
    if (strictFilter.minScore && result.metadata.score > strictFilter.minScore) return false;

    return true;
  });
  const filterTime = Date.now() - postFilterStart;

  // 4. Re-rank: Sort by score (ascending distance)
  filteredResults.sort((a, b) => a.metadata.score - b.metadata.score);

  // 5. Return top K
  const finalResults = filteredResults.slice(0, topK);
  
  console.log(`[Hybrid Search] Search Time: ${searchTime}ms, Post-Filter Time: ${filterTime}ms`);
  console.log(`[Hybrid Search] Results: ${finalResults.length}`);
  
  return finalResults;
}

// --- Interactive Challenge Simulation ---

async function runHybridSimulation() {
  console.log("--- Exercise 3 Simulation ---");
  
  // Scenario: We want documents from 2023 (Loose), specifically by 'John Doe' (Strict)
  const looseFilter: FilterCriteria = {
    startDate: new Date('2023-01-01'),
    endDate: new Date('2023-12-31')
  };
  
  const strictFilter: FilterCriteria = {
    author: 'John Doe'
  };

  const results = await hybridSearch('query', looseFilter, strictFilter);
  console.log("Final Output:", results.map(r => ({ id: r.id, author: r.metadata.author, score: r.metadata.score })));
}

// runHybridSimulation();
