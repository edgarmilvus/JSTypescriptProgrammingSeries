/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

interface RAGDocument {
  id: string;
  content: string;
  metadata: {
    author: string;
    dateCreated: Date;
    score: number;
  };
}

interface RetrievalConstraints {
  author?: string;
  dateRange?: {
    start: Date;
    end: Date;
  };
}

/**
 * Mocks a vector DB retrieval for RAG.
 * Returns documents sorted by relevance (score).
 */
async function mockVectorRetrieval(query: string, constraints: RetrievalConstraints): Promise<RAGDocument[]> {
  // Simulate DB hit
  const mockDocs: RAGDocument[] = [
    { id: '1', content: 'The quick brown fox jumps over the lazy dog.', metadata: { author: 'Alice', dateCreated: new Date('2023-01-01'), score: 0.1 } },
    { id: '2', content: 'Artificial Intelligence is transforming the industry.', metadata: { author: 'Bob', dateCreated: new Date('2023-06-01'), score: 0.3 } },
    { id: '3', content: 'Metadata filtering improves search accuracy significantly.', metadata: { author: 'Alice', dateCreated: new Date('2023-02-01'), score: 0.5 } },
    { id: '4', content: 'Retrieval Augmented Generation requires high-quality context.', metadata: { author: 'Charlie', dateCreated: new Date('2023-08-01'), score: 0.8 } },
  ];

  // Filter based on constraints
  return mockDocs.filter(doc => {
    let match = true;
    if (constraints.author) match = match && doc.metadata.author === constraints.author;
    if (constraints.dateRange) {
      match = match && doc.metadata.dateCreated >= constraints.dateRange.start && doc.metadata.dateCreated <= constraints.dateRange.end;
    }
    return match;
  }).sort((a, b) => a.metadata.score - b.metadata.score); // Sort by score (relevance)
}

export async function retrieveForRAG(
  userQuery: string,
  constraints: RetrievalConstraints,
  maxChars: number = 4000
): Promise<string> {
  // 1. Retrieve documents
  const docs = await mockVectorRetrieval(userQuery, constraints);

  // 2. Format documents
  const formattedDocs = docs.map(doc => 
    `[${doc.id}]: ${doc.content} (Author: ${doc.metadata.author}, Date: ${doc.metadata.dateCreated.toISOString().split('T')[0]})`
  );

  // 3. Join into context string
  let context = formattedDocs.join('\n\n');

  // 4. Check Token Limit (Simplified to character count for demo)
  if (context.length > maxChars) {
    console.warn(`Context truncated: ${context.length} chars exceeds limit of ${maxChars}.`);
    
    // Truncate by removing lowest scoring documents first (which are at the top due to sort)
    let truncatedContext = "";
    for (const docStr of formattedDocs) {
      if (truncatedContext.length + docStr.length + 2 > maxChars) break;
      truncatedContext += docStr + "\n\n";
    }
    return truncatedContext.trim();
  }

  return context;
}

// --- Unit Test Logic (Simulated) ---

async function runRAGTests() {
  console.log("--- Exercise 4 Simulation ---");

  // Test 1: Exact Match
  console.log("\n[Test 1] Filter by Author 'Alice':");
  const result1 = await retrieveForRAG('query', { author: 'Alice' }, 1000);
  console.log(result1);

  // Test 2: Range Query
  console.log("\n[Test 2] Filter by Date Range (Mid-2023):");
  const result2 = await retrieveForRAG('query', { 
    dateRange: { start: new Date('2023-05-01'), end: new Date('2023-07-01') } 
  }, 1000);
  console.log(result2);

  // Test 3: Truncation
  // We set a very low limit to force truncation
  console.log("\n[Test 3] Truncation (Limit 50 chars):");
  const result3 = await retrieveForRAG('query', {}, 50);
  console.log(result3);
}

// runRAGTests();
