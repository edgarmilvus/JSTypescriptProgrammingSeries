/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState } from 'react';

interface AggregatedData {
  [key: string]: number; // e.g., { "Engineering": 15, "Sales": 8 }
}

interface Props {
  data: AggregatedData;
  totalDocs: number;
}

export const MetadataDistributionChart: React.FC<Props> = ({ data, totalDocs }) => {
  const [hoveredBar, setHoveredBar] = useState<string | null>(null);

  // Calculate max value for scaling bars
  const maxValue = Math.max(...Object.values(data), 1); // Avoid division by zero
  
  // Colors for bars
  const colors = ['#4F46E5', '#10B981', '#F59E0B', '#EF4444', '#8B5CF6'];

  return (
    <div className="chart-container" style={{ padding: '20px', border: '1px solid #eee', marginTop: '20px' }}>
      <h3>Metadata Distribution</h3>
      <svg width="100%" height={300} viewBox="0 0 500 300">
        {/* Grid lines (optional) */}
        <line x1="50" y1="250" x2="480" y2="250" stroke="#ccc" strokeWidth="1" />

        {Object.entries(data).map(([key, value], index) => {
          const barHeight = (value / maxValue) * 200;
          const x = 60 + index * 60;
          const y = 250 - barHeight;
          const percentage = totalDocs > 0 ? ((value / totalDocs) * 100).toFixed(1) : 0;
          const color = colors[index % colors.length];

          return (
            <g 
              key={key} 
              onMouseEnter={() => setHoveredBar(key)}
              onMouseLeave={() => setHoveredBar(null)}
              style={{ cursor: 'pointer' }}
            >
              {/* Bar */}
              <rect
                x={x}
                y={y}
                width={40}
                height={barHeight}
                fill={color}
                rx="4"
              />
              
              {/* Label (Truncated if long) */}
              <text x={x + 20} y={270} textAnchor="middle" fontSize="10" fill="#333">
                {key.length > 6 ? key.substring(0, 5) + '.' : key}
              </text>

              {/* Tooltip (Conditional Rendering) */}
              {hoveredBar === key && (
                <g>
                  <rect
                    x={x - 10}
                    y={y - 35}
                    width={80}
                    height={30}
                    fill="rgba(0,0,0,0.8)"
                    rx="4"
                  />
                  <text
                    x={x + 30}
                    y={y - 20}
                    textAnchor="middle"
                    fill="white"
                    fontSize="11"
                    fontWeight="bold"
                  >
                    {key}: {value} ({percentage}%)
                  </text>
                </g>
              )}
            </g>
          );
        })}
      </svg>
    </div>
  );
};

// --- Example Usage in a Parent Component (Simulated) ---

const mockData: AggregatedData = {
  "Eng": 15,
  "Sales": 8,
  "HR": 5,
  "Mkt": 12,
};

export const DashboardExample: React.FC = () => {
  const total = Object.values(mockData).reduce((a, b) => a + b, 0);
  return <MetadataDistributionChart data={mockData} totalDocs={total} />;
};
