/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * @fileoverview Basic Re-ranking Example for a SaaS Web App
 * 
 * This script simulates a backend API endpoint that processes a user query.
 * It demonstrates the re-ranking pattern: retrieving documents via vector similarity
 * and refining the order using a Cross-Encoder relevance score.
 */

// --- 1. Mock Data & Types ---

// Simulating a document stored in a vector database (e.g., Pinecone, Qdrant).
interface Document {
    id: string;
    content: string;
    metadata: {
        source: string;
        date: string;
    };
    // In a real scenario, 'score' comes from the vector search (e.g., cosine similarity)
    score: number; 
}

// --- 2. The Re-ranking Service ---

/**
 * Simulates a Cross-Encoder model (e.g., BAAI/bge-reranker-base).
 * In production, this would be an API call to Cohere ReRank or a local ONNX model.
 * 
 * @param query - The user's search query.
 * @param documents - The list of documents to rank.
 * @returns A promise resolving to documents sorted by relevance score (0 to 1).
 */
async function reRankDocuments(
    query: string, 
    documents: Document[]
): Promise<Document[]> {
    console.log(`[Re-ranker] Processing query: "${query}"`);
    
    // SIMULATION: We calculate a mock relevance score.
    // A real Cross-Encoder analyzes the semantic interaction between query and document.
    const ranked = documents.map(doc => {
        let relevanceScore = 0;
        
        // Heuristic simulation for demonstration purposes only:
        if (doc.content.toLowerCase().includes(query.split(' ')[0])) {
            relevanceScore += 0.5;
        }
        if (doc.content.length > 50) relevanceScore += 0.1; // Prefer detailed docs
        
        // Add some randomness to simulate model variance
        relevanceScore += Math.random() * 0.4;
        
        return { ...doc, relevanceScore };
    });

    // Sort descending by the new relevance score
    ranked.sort((a, b) => b.relevanceScore - a.relevanceScore);
    
    // Simulate network latency (Async Tool Handling)
    await new Promise(resolve => setTimeout(resolve, 200)); 
    
    return ranked;
}

// --- 3. The Main Pipeline (Supervisor/Worker Pattern) ---

/**
 * Main entry point simulating an API route handler (e.g., Next.js App Router).
 * This acts as the 'Supervisor' orchestrating the flow.
 * 
 * @param userQuery - The input string from the frontend.
 */
async function runRagPipeline(userQuery: string): Promise<void> {
    console.log(`\n--- Starting Pipeline for: "${userQuery}" ---`);
    
    try {
        // Step 1: Initial Retrieval (Mocking Vector DB Search)
        // In a real app, this is `vectorStore.similaritySearch(query, 10)`
        const initialDocs: Document[] = [
            { id: "1", content: "Top 10 Budget Laptops of 2024", metadata: { source: "tech-blog", date: "2024-01-15" }, score: 0.85 },
            { id: "2", content: "Gaming Laptops vs. Ultrabooks", metadata: { source: "comparison-guide", date: "2023-11-20" }, score: 0.82 },
            { id: "3", content: "How to save money on electronics", metadata: { source: "finance-blog", date: "2024-02-01" }, score: 0.78 },
            { id: "4", content: "Best affordable Chromebooks for students", metadata: { source: "education-tech", date: "2024-03-10" }, score: 0.75 },
        ];
        
        console.log(`[Retrieval] Found ${initialDocs.length} initial candidates.`);

        // Step 2: Re-ranking (The Critical Step)
        // We pass the query and the initial candidates to the re-ranker.
        // This is an asynchronous tool call.
        const rerankedDocs = await reRankDocuments(userQuery, initialDocs);

        // Step 3: Selection (Top K)
        // We select the top 2 documents based on the re-ranked scores.
        const topK = 2;
        const finalContext = rerankedDocs.slice(0, topK);
        
        console.log(`[Re-ranking] Top ${topK} selected:`);
        finalContext.forEach(doc => {
            console.log(`  - ID: ${doc.id} | Relevance: ${doc.relevanceScore?.toFixed(2)} | Content: "${doc.content}"`);
        });

        // Step 4: Generation (Simulated LLM Call)
        const contextString = finalContext.map(d => d.content).join('\n');
        const finalPrompt = `
            Based on the following context, answer the user's question:
            Question: ${userQuery}
            Context:
            ${contextString}
        `;
        
        console.log("\n[Generation] Final Prompt Constructed:");
        console.log(finalPrompt);
        console.log("\n--- Pipeline Complete ---\n");

    } catch (error) {
        console.error("[Error] Pipeline failed:", error);
    }
}

// --- Execution ---

// Simulate a web request
runRagPipeline("best budget laptops");
