/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

/**
 * advanced-rerank-pipeline.ts
 * 
 * A TypeScript implementation of a production-grade re-ranking pipeline 
 * designed for a Next.js API Route.
 * 
 * Concepts: Re-ranking, Immutable State Management, Quantization, Latency vs Accuracy.
 */

import { NextApiRequest, NextApiResponse } from 'next';

// ==========================================
// 1. TYPE DEFINITIONS & INTERFACES
// ==========================================

/**
 * Represents a document in our knowledge base.
 * Includes the raw text and metadata.
 */
export interface Document {
  id: string;
  content: string;
  metadata: {
    source: string;
    lastUpdated: Date;
    category: string;
  };
}

/**
 * Represents a document enriched with a vector embedding.
 * This is typically retrieved from a Vector Database (e.g., Pinecone, Weaviate).
 */
export interface VectorDocument extends Document {
  embedding: number[]; // Float32Array is often better for performance, but number[] is standard JSON
}

/**
 * Represents the initial retrieval result (State A).
 * Contains the document and its geometric similarity score.
 */
export interface InitialCandidate {
  document: Document;
  vectorScore: number; // Cosine similarity (0.0 to 1.0)
}

/**
 * Represents the final result after re-ranking (State B).
 * Contains the document and the semantic relevance score.
 */
export interface RerankedCandidate {
  document: Document;
  relevanceScore: number; // Normalized score (0.0 to 1.0) from Cross-Encoder
  finalRank: number;
}

/**
 * Configuration for the re-ranking service.
 * Includes flags for optimization strategies like Quantization.
 */
export interface ReRankerConfig {
  topK: number;
  useQuantizedModel: boolean; // Simulates switching between FP32 and INT8 models
  apiEndpoint: string;
}

// ==========================================
// 2. MOCK DATA & SERVICES
// ==========================================

/**
 * Simulates a Vector Database (e.g., Pinecone).
 * In production, this would be an async call to a remote store.
 */
class MockVectorDB {
  private documents: VectorDocument[];

  constructor() {
    // Seed mock data
    this.documents = [
      {
        id: "doc_1",
        content: "JavaScript is a high-level, interpreted programming language.",
        metadata: { source: "tech_docs", lastUpdated: new Date(), category: "Programming" },
        embedding: [0.1, 0.2, 0.3] // Placeholder
      },
      {
        id: "doc_2",
        content: "TypeScript adds static typing to JavaScript, enhancing tooling and refactoring.",
        metadata: { source: "tech_docs", lastUpdated: new Date(), category: "Programming" },
        embedding: [0.15, 0.25, 0.35]
      },
      {
        id: "doc_3",
        content: "Java is a class-based, object-oriented programming language designed to have as few implementation dependencies as possible.",
        metadata: { source: "legacy_docs", lastUpdated: new Date(), category: "Programming" },
        embedding: [0.9, 0.8, 0.7] // Geometrically far, but topically related in broad sense
      },
      {
        id: "doc_4",
        content: "The stock market closed with a slight dip today due to inflation concerns.",
        metadata: { source: "news", lastUpdated: new Date(), category: "Finance" },
        embedding: [0.01, 0.02, 0.03]
      }
    ];
  }

  /**
   * Simulates a vector similarity search.
   * Returns top-k candidates based on cosine similarity.
   */
  async search(queryEmbedding: number[], topK: number): Promise<InitialCandidate[]> {
    // In a real app, we'd use a vector math library. Here we simulate a match.
    // We'll manually select docs that look relevant to "JS/TS" for the demo.
    
    const candidates: InitialCandidate[] = [
      { document: this.documents[0], vectorScore: 0.92 }, // JS
      { document: this.documents[1], vectorScore: 0.89 }, // TS
      { document: this.documents[2], vectorScore: 0.45 }, // Java (lower precision)
      { document: this.documents[3], vectorScore: 0.10 }  // Finance (irrelevant)
    ];

    // Simulate network latency
    await new Promise(r => setTimeout(r, 100));
    
    // Sort by vector score descending and slice
    return candidates
      .sort((a, b) => b.vectorScore - a.vectorScore)
      .slice(0, topK);
  }
}

/**
 * Simulates the Cohere ReRank API or a local Cross-Encoder.
 * 
 * UNDER THE HOOD:
 * A Cross-Encoder (e.g., BERT) processes the Query and Document concatenated:
 * [CLS] Query [SEP] Document [SEP]
 * It outputs a raw logit which is sigmoid-activated to a 0-1 relevance score.
 * 
 * QUANTIZATION NOTE:
 * If 'useQuantizedModel' is true, we simulate the inference time reduction 
 * (e.g., INT8 weights) by shaving 20ms off the mock latency.
 */
class ReRankerService {
  private config: ReRankerConfig;

  constructor(config: ReRankerConfig) {
    this.config = config;
  }

  /**
   * Executes the re-ranking logic.
   * @param query The original user query string.
   * @param candidates The immutable list of initial candidates.
   * @returns A new array of candidates, sorted by relevance.
   */
  async rerank(query: string, candidates: InitialCandidate[]): Promise<RerankedCandidate[]> {
    console.log(`[ReRanker] Processing ${candidates.length} candidates...`);
    
    // IMMUTABLE STATE: We map over the candidates to create a new structure.
    // We do not modify 'candidates' in place.
    const scoredPromises = candidates.map(async (candidate) => {
      // Simulate API call to Cross-Encoder
      const relevanceScore = await this.predictRelevance(query, candidate.document.content);
      
      return {
        document: candidate.document,
        relevanceScore: relevanceScore,
        // Initial rank is preserved for debugging/traceability
        initialVectorScore: candidate.vectorScore 
      } as RerankedCandidate & { initialVectorScore: number };
    });

    const scoredResults = await Promise.all(scoredPromises);

    // Sort by the new semantic relevance score
    // Note: The Cross-Encoder score usually overrides the vector score entirely
    // or is used to re-order the list.
    const rankedResults = scoredResults
      .sort((a, b) => b.relevanceScore - a.relevanceScore)
      .map((item, index) => ({
        document: item.document,
        relevanceScore: item.relevanceScore,
        finalRank: index + 1
      }));

    return rankedResults;
  }

  /**
   * Mocks the inference of a Cross-Encoder model.
   * In a real implementation, this would call Cohere's API:
   * fetch('https://api.cohere.ai/v1/rerank', ...)
   */
  private async predictRelevance(query: string, document: string): Promise<number> {
    // Simulate network request
    const latency = this.config.useQuantizedModel ? 50 : 150; // ms
    await new Promise(r => setTimeout(r, latency));

    // Mock Logic: 
    // If doc contains "TypeScript" or "JavaScript" and query asks about it -> High score
    // If doc is "Java" but query is "JS" -> Medium score
    // If doc is "Finance" -> Low score
    
    const queryLower = query.toLowerCase();
    const docLower = document.toLowerCase();

    if (queryLower.includes('typescript') && docLower.includes('typescript')) return 0.95;
    if (queryLower.includes('javascript') && docLower.includes('javascript')) return 0.93;
    if (docLower.includes('javascript') || docLower.includes('typescript')) return 0.60; // Related but not exact
    if (docLower.includes('java')) return 0.30; // Distractor
    
    return 0.05; // Noise
  }
}

// ==========================================
// 3. NEXT.JS API ROUTE HANDLER
// ==========================================

/**
 * Main API Handler for the Search Endpoint.
 * 
 * Logic Flow:
 * 1. Parse Request: Extract query and user preferences.
 * 2. Vector Retrieval: Fetch coarse candidates (State A).
 * 3. Re-ranking: Refine candidates using semantic precision (State B).
 * 4. Response: Return ranked context for LLM or UI display.
 */
export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  const { query, userId, enableQuantization = false } = req.body;

  if (!query) {
    return res.status(400).json({ error: 'Query is required' });
  }

  try {
    // 1. CONFIGURATION
    const config: ReRankerConfig = {
      topK: 4,
      useQuantizedModel: Boolean(enableQuantization),
      apiEndpoint: process.env.COHERE_API_URL || 'https://api.cohere.ai/v1/rerank'
    };

    // 2. VECTOR RETRIEVAL (Stage 1)
    // In a real app, we would generate an embedding for the query here using OpenAI or Cohere Embed.
    const mockQueryEmbedding = [0.1, 0.2, 0.3]; 
    const vectorDB = new MockVectorDB();
    
    const initialCandidates = await vectorDB.search(mockQueryEmbedding, config.topK);

    // IMMUTABILITY CHECK:
    // We freeze the object to ensure the re-ranker cannot mutate the original retrieval.
    // This is crucial for debugging "drift" between retrieval and re-ranking.
    Object.freeze(initialCandidates);

    // 3. RE-RANKING (Stage 2)
    const reRanker = new ReRankerService(config);
    const finalCandidates = await reRanker.rerank(query, initialCandidates);

    // 4. CONSTRUCTION OF CONTEXT FOR LLM
    // We extract the content of the top-ranked documents to form the context window.
    const contextText = finalCandidates
      .slice(0, 3) // Take top 3 for context window limits
      .map(c => `[Source: ${c.document.metadata.source}]\n${c.document.content}`)
      .join('\n\n---\n\n');

    // 5. RESPONSE
    res.status(200).json({
      success: true,
      meta: {
        latency: {
          strategy: config.useQuantizedModel ? 'Quantized (Low Latency)' : 'Standard (High Precision)',
          initialCount: initialCandidates.length,
          finalCount: finalCandidates.length
        }
      },
      data: {
        initialRetrieval: initialCandidates, // Exposed for UI comparison
        rerankedResults: finalCandidates,
        llmContext: contextText
      }
    });

  } catch (error) {
    console.error('Pipeline Error:', error);
    res.status(500).json({ error: 'Internal pipeline failure' });
  }
}

// ==========================================
// 4. CLIENT-SIDE USAGE EXAMPLE (TSX)
// ==========================================
// This component demonstrates how to consume the API and visualize the re-ranking effect.

/*
import { useState } from 'react';

export default function SearchInterface() {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<any>(null);
  const [loading, setLoading] = useState(false);

  const handleSearch = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/advanced-rerank-pipeline', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ query, enableQuantization: false })
      });
      const data = await res.json();
      setResults(data);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div>
      <input 
        value={query} 
        onChange={(e) => setQuery(e.target.value)} 
        placeholder="Ask about JavaScript or TypeScript..."
      />
      <button onClick={handleSearch} disabled={loading}>
        {loading ? 'Processing...' : 'Search'}
      </button>

      {results && (
        <div>
          <h3>Re-ranked Results:</h3>
          {results.data.rerankedResults.map((item: any, idx: number) => (
            <div key={idx} style={{ border: '1px solid #ccc', margin: '8px', padding: '8px' }}>
              <strong>Rank {item.finalRank} (Rel: {item.relevanceScore.toFixed(2)})</strong>
              <p>{item.document.content}</p>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
*/
