/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

import { pipeline, PipelineType, env, Pipeline } from '@xenova/transformers';

// Define the Document interface as specified
interface Document {
    id: string;
    content: string;
    score?: number;
}

// Singleton pattern to cache the model instance
let crossEncoderPipeline: Pipeline | null = null;

/**
 * Ranks documents using a local Cross-Encoder model.
 * @param query The user query string.
 * @param documents Array of documents to rank.
 * @param modelName The Hugging Face model identifier.
 * @returns Promise<Document[]> Sorted documents with scores.
 */
export async function rankDocuments(
    query: string,
    documents: Document[],
    modelName: string = "cross-encoder/ms-marco-MiniLM-L-6-v2"
): Promise<Document[]> {
    try {
        // Initialize the pipeline if it doesn't exist
        if (!crossEncoderPipeline) {
            console.log(`Loading Cross-Encoder model: ${modelName}...`);
            // Use 'feature-extraction' or a specific task if available, 
            // but for cross-encoders, we typically use the 'feature-extraction' pipeline 
            // or a custom implementation. 
            // Note: @xenova/transformers supports 'feature-extraction' for embeddings, 
            // but for Cross-Encoder scoring, we often rely on the 'zero-shot' or 
            // a custom implementation of the pipeline. 
            // However, the library handles Cross-Encoders via the 'feature-extraction' 
            // pipeline type for scoring pairs in recent versions.
            crossEncoderPipeline = await pipeline('feature-extraction', modelName);
        }

        // Prepare pairs [query, document]
        const pairs = documents.map(doc => [query, doc.content]);

        // Run inference
        // The model outputs a tensor (logits). We need to extract the score.
        // For Cross-Encoders like MS MARCO, the output is usually a single float per pair.
        const scores = await crossEncoderPipeline(pairs, { 
            pooling: 'cls', 
            normalize: true 
        });

        // Attach scores to documents
        const rankedDocs = documents.map((doc, index) => ({
            ...doc,
            score: scores.data[index] // Access the raw data from the tensor
        }));

        // Sort in descending order
        rankedDocs.sort((a, b) => (b.score ?? 0) - (a.score ?? 0));

        return rankedDocs;

    } catch (error) {
        console.error("Error during Cross-Encoder ranking:", error);
        // In case of failure, return the original list unsorted
        return documents;
    }
}
