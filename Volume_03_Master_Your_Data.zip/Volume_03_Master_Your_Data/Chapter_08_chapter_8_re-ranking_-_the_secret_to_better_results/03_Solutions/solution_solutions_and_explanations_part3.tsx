/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState } from 'react';

// Interfaces
interface Document {
    id: string;
    content: string;
    initialScore?: number;
    rerankedScore?: number;
}

interface RerankingVisualizerProps {
    initialDocs: Document[];
    rerankedDocs: Document[];
    query: string;
}

// Helper to find rank position
const getRank = (docs: Document[], id: string) => docs.findIndex(d => d.id === id);

const RerankingVisualizer: React.FC<RerankingVisualizerProps> = ({
    initialDocs,
    rerankedDocs,
    query,
}) => {
    const [expandedId, setExpandedId] = useState<string | null>(null);

    const toggleExpand = (id: string) => {
        setExpandedId(prevId => prevId === id ? null : id);
    };

    // Helper to render a document card
    const renderDocCard = (doc: Document, score: number | undefined, isInitial: boolean) => {
        const isExpanded = expandedId === doc.id;
        
        // Calculate rank change if document exists in both lists
        let rankChangeClass = '';
        if (!isInitial) {
            const initialIndex = getRank(initialDocs, doc.id);
            const rerankIndex = getRank(rerankedDocs, doc.id);
            
            if (initialIndex !== -1 && rerankIndex !== -1) {
                if (rerankIndex < initialIndex) rankChangeClass = 'border-l-4 border-green-500'; // Moved up
                else if (rerankIndex > initialIndex) rankChangeClass = 'border-l-4 border-red-500'; // Moved down
            }
        }

        return (
            <div 
                key={doc.id} 
                className={`p-4 mb-2 bg-white border rounded shadow-sm cursor-pointer transition-all hover:bg-gray-50 ${rankChangeClass}`}
                onClick={() => toggleExpand(doc.id)}
            >
                <div className="flex justify-between items-center mb-2">
                    <span className="font-bold text-sm text-gray-700">Score: {score?.toFixed(4)}</span>
                    {!isInitial && rankChangeClass && (
                        <span className={`text-xs font-bold ${rankChangeClass.includes('green') ? 'text-green-600' : 'text-red-600'}`}>
                            {rankChangeClass.includes('green') ? '↑ Improved' : '↓ Dropped'}
                        </span>
                    )}
                </div>
                <p className="text-sm text-gray-800 line-clamp-2">
                    {isExpanded ? doc.content : `${doc.content.substring(0, 100)}...`}
                </p>
            </div>
        );
    };

    return (
        <div className="p-6 bg-gray-100 min-h-screen font-sans">
            <h2 className="text-2xl font-bold mb-4 text-gray-900">Query: <span className="font-normal italic">"{query}"</span></h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {/* Initial Retrieval Column */}
                <div className="bg-white p-4 rounded-lg shadow-md">
                    <h3 className="text-lg font-bold mb-3 text-blue-700 border-b pb-2">Initial Retrieval (Vector Sim)</h3>
                    <div className="space-y-2">
                        {initialDocs.map(doc => renderDocCard(doc, doc.initialScore, true))}
                    </div>
                </div>

                {/* Reranked Results Column */}
                <div className="bg-white p-4 rounded-lg shadow-md">
                    <h3 className="text-lg font-bold mb-3 text-purple-700 border-b pb-2">Reranked Results (Cross-Encoder)</h3>
                    <div className="space-y-2">
                        {rerankedDocs.map(doc => renderDocCard(doc, doc.rerankedScore, false))}
                    </div>
                </div>
            </div>
        </div>
    );
};

export default RerankingVisualizer;
