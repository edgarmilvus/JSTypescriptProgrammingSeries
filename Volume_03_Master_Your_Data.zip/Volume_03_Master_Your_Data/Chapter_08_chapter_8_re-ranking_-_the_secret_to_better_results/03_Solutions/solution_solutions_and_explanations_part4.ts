/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

// Interfaces
interface Document {
    id: string;
    content: string;
    initialScore: number;
}

interface RagPipelineConfig {
    useReranking: boolean;
    rerankerType: 'local-cross-encoder' | 'cohere-api';
    topKAfterReranking: number;
    maxLatencyMs: number;
}

interface PipelineStatus {
    rerankingPerformed: boolean;
    latencyBudgetMet: boolean;
    totalTimeMs: number;
    finalDocs: Document[];
}

// Utility to simulate delay
const delay = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

export class RagStrategyManager {
    constructor(private config: RagPipelineConfig) {}

    /**
     * Simulates the RAG pipeline execution with latency constraints.
     */
    async executePipeline(): Promise<PipelineStatus> {
        const startTime = Date.now();
        let rerankingPerformed = false;

        // Step 1: Simulate Retrieval (Generating dummy docs)
        const initialDocs: Document[] = Array.from({ length: 20 }, (_, i) => ({
            id: `doc-${i}`,
            content: `Content for document ${i} regarding the query.`,
            initialScore: Math.random(), // Random similarity score
        })).sort((a, b) => b.initialScore - a.initialScore); // Sort by initial score

        let finalDocs = initialDocs.slice(0, this.config.topKAfterReranking);

        // Step 2: Conditional Reranking
        if (this.config.useReranking) {
            // Determine latency based on type (simulated)
            const simulatedLatency = this.config.rerankerType === 'local-cross-encoder' ? 50 : 200;
            
            // Simulate the heavy computation
            await delay(simulatedLatency);

            // Simulate re-ranking effect: shuffle scores slightly to mimic reordering
            // In a real scenario, this would be the Cross-Encoder or API call
            const rerankedDocs = initialDocs.map(doc => ({
                ...doc,
                // Randomize score slightly to simulate re-ranking changes
                initialScore: doc.initialScore + (Math.random() * 0.2 - 0.1) 
            })).sort((a, b) => b.initialScore - a.initialScore);

            finalDocs = rerankedDocs.slice(0, this.config.topKAfterReranking);
            rerankingPerformed = true;
        }

        const endTime = Date.now();
        const totalTime = endTime - startTime;

        // Step 3: Latency Check
        const latencyBudgetMet = totalTime <= this.config.maxLatencyMs;

        if (!latencyBudgetMet) {
            console.warn(`⚠️ Latency Budget Exceeded! Config: ${this.config.maxLatencyMs}ms, Actual: ${totalTime}ms.`);
            if (rerankingPerformed) {
                console.warn("Falling back to non-reranked results.");
                // Fallback logic: return top K from initial retrieval
                finalDocs = initialDocs.slice(0, this.config.topKAfterReranking);
            }
        }

        return {
            rerankingPerformed,
            latencyBudgetMet,
            totalTimeMs: totalTime,
            finalDocs
        };
    }
}

// Example Usage:
/*
const config: RagPipelineConfig = {
    useReranking: true,
    rerankerType: 'cohere-api', // Simulates 200ms delay
    topKAfterReranking: 3,
    maxLatencyMs: 150 // Strict budget
};

const manager = new RagStrategyManager(config);
manager.executePipeline().then(console.log);
*/
