/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

import { Client } from 'pg';

// Initialize the pgvector extension in the database first:
// CREATE EXTENSION IF NOT EXISTS vector;

export class VectorDatabaseManager {
    private client: Client;

    constructor(connectionString: string) {
        this.client = new Client({ connectionString });
    }

    async connect() {
        await this.client.connect();
    }

    async end() {
        await this.client.end();
    }

    /**
     * Creates the document_embeddings table if it doesn't exist.
     */
    async initializeTable() {
        const query = `
            CREATE TABLE IF NOT EXISTS document_embeddings (
                id SERIAL PRIMARY KEY,
                content TEXT,
                embedding VECTOR(1536) -- Adjust dimension based on your model (e.g., OpenAI is 1536)
            );
        `;
        await this.client.query(query);
    }

    /**
     * Creates an HNSW index on the embedding column for fast cosine similarity search.
     */
    async createHNSWIndex() {
        // Using vector_ip_ops for inner product (dot product), which is equivalent 
        // to cosine similarity if vectors are normalized. 
        // Alternatively, use vector_cosine_ops.
        const query = `
            CREATE INDEX IF NOT EXISTS document_embeddings_hnsw_idx 
            ON document_embeddings 
            USING hnsw (embedding vector_ip_ops);
        `;
        await this.client.query(query);
    }

    /**
     * Searches for similar documents using the HNSW index.
     * @param embedding The query embedding as a float array.
     * @param limit The number of results to return.
     */
    async searchWithHNSW(embedding: number[], limit: number = 5) {
        // Convert array to Postgres vector string format: '[0.1, 0.2, ...]'
        const vectorString = `[${embedding.join(',')}]`;

        // The '<->' operator calculates the inner product distance.
        // Since we used vector_ip_ops for the index, this query will utilize the HNSW index.
        const query = `
            SELECT content, (embedding <-> $1::vector) as distance
            FROM document_embeddings
            ORDER BY embedding <-> $1::vector
            LIMIT $2;
        `;

        const result = await this.client.query(query, [vectorString, limit]);
        return result.rows;
    }
}

/* 
PERFORMANCE COMPARISON COMMENT:

To measure the difference between HNSW and a brute-force search (exact nearest neighbor):

1.  **Brute Force (No Index):**
    SQL: `SELECT content, embedding <-> $1 as distance FROM document_embeddings ORDER BY embedding <-> $1 LIMIT 5;`
    - This performs a sequential scan. As the table grows (e.g., > 100k rows), query time increases linearly.
    - Metric: Execution time will be high for large datasets.

2.  **HNSW (With Index):**
    SQL: `... ORDER BY embedding <-> $1 ...` (with index present)
    - This performs an index scan. Query time remains relatively constant regardless of table size (logarithmic complexity).
    - Metric: Execution time will be significantly lower.

3.  **Measurement Tool:**
    Use `EXPLAIN ANALYZE` before the query:
    `EXPLAIN ANALYZE SELECT ... ORDER BY embedding <-> $1 ...`
    
    - **Brute Force Output:** Will show "Seq Scan" and high "Execution Time".
    - **HNSW Output:** Will show "Index Scan" using the `document_embeddings_hnsw_idx` and low "Execution Time".
*/
