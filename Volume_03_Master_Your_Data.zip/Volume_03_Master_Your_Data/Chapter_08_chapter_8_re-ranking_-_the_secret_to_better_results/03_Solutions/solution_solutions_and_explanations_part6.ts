/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part6.ts
// Description: Solutions and Explanations
// ==========================================

import { pipeline, Pipeline } from '@xenova/transformers';

// Singleton for the classifier model
let zeroShotPipeline: Pipeline | null = null;

/**
 * Classifies a query into predefined labels using zero-shot learning.
 * @param query The user query string.
 * @param candidateLabels Array of potential intents.
 */
export async function classifyQueryIntent(
    query: string,
    candidateLabels: string[]
): Promise<{ label: string; score: number }[]> {
    try {
        if (!zeroShotPipeline) {
            console.log("Loading Zero-Shot Classification model...");
            // 'zero-shot-classification' is the specific task supported by the library
            zeroShotPipeline = await pipeline('zero-shot-classification', 'Xenova/distilbert-base-uncased-mnli');
        }

        // Run classification
        const result = await zeroShotPipeline(query, {
            candidate_labels: candidateLabels,
            // Optional: multi_label: true if multiple intents can apply
        });

        // The pipeline returns labels and scores arrays
        const labels = result.labels as string[];
        const scores = result.scores as number[];

        // Combine into an array of objects
        return labels.map((label, index) => ({
            label,
            score: scores[index]
        }));

    } catch (error) {
        console.error("Error in zero-shot classification:", error);
        return [];
    }
}

/**
 * Routes a query to a specific collection based on intent.
 * @param query The user query.
 * @returns The collection name string.
 */
export async function routeQuery(query: string): Promise<string> {
    const labels = ["technical support", "billing", "product inquiry"];
    const results = await classifyQueryIntent(query, labels);

    // Handle empty results (model failure)
    if (results.length === 0) {
        return "default_collection";
    }

    // Get the top result
    const topResult = results[0];

    // Check confidence threshold
    if (topResult.score < 0.5) {
        console.log(`Low confidence (${topResult.score}) for intent ${topResult.label}. Using default.`);
        return "default_collection";
    }

    // Route based on label
    switch (topResult.label) {
        case "technical support":
            return "technical_docs";
        case "billing":
            return "billing_docs";
        case "product inquiry":
            return "product_docs";
        default:
            return "default_collection";
    }
}
