/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// pages/api/advanced-search.ts (or app/api/advanced-search/route.ts)
import type { NextApiRequest, NextApiResponse } from 'next';
import { Configuration, OpenAIApi } from 'openai';

// ==========================================
// 1. CONFIGURATION & TYPES
// ==========================================

/**
 * Configuration for the OpenAI client.
 * In production, use environment variables (process.env.OPENAI_API_KEY).
 */
const configuration = new Configuration({
  apiKey: process.env.OPENAI_API_KEY,
});
const openai = new OpenAIApi(configuration);

/**
 * Represents a document retrieved from the vector database.
 */
interface RetrievedDocument {
  id: string;
  content: string;
  score: number;
}

/**
 * Response structure for the API.
 */
interface SearchResponse {
  success: boolean;
  query: string;
  expandedQueries?: string[];
  hypotheticalContext?: string;
  results: RetrievedDocument[];
  error?: string;
}

// ==========================================
// 2. HELPER FUNCTIONS: QUERY EXPANSION
// ==========================================

/**
 * Generates diverse variations of the user's query to broaden the retrieval scope.
 * 
 * @param query - The original user input.
 * @returns Promise<string[]> - An array of expanded query strings.
 * 
 * UNDER THE HOOD:
 * We instruct the LLM to act as a semantic expansion engine. We explicitly ask for
 * variations that cover synonyms, different phrasings, and related concepts.
 * This helps mitigate the "vocabulary mismatch" problem in vector search.
 */
async function expandQuery(query: string): Promise<string[]> {
  try {
    const prompt = `
      You are an expert search query expansion engine.
      Given a user query, generate 3 distinct variations that capture the same intent using different phrasing or synonyms.
      Return ONLY a JSON array of strings.
      
      Original Query: "${query}"
      Variations:
    `;

    const response = await openai.createChatCompletion({
      model: "gpt-3.5-turbo",
      messages: [{ role: "user", content: prompt }],
      temperature: 0.7,
    });

    const content = response.data.choices[0].message?.content;
    // Basic parsing of the LLM output. In production, use a parser like Zod.
    const variations = content ? JSON.parse(content) : [];
    
    // Ensure the original query is included in the search set
    return [query, ...variations];
  } catch (error) {
    console.error("Error in expandQuery:", error);
    return [query]; // Fallback to original query
  }
}

// ==========================================
// 3. HELPER FUNCTIONS: HYPOTHETICAL DOCUMENT EMBEDDINGS (HyDE)
// ==========================================

/**
 * Generates a hypothetical answer (context) to the user query.
 * 
 * @param query - The original user input.
 * @returns Promise<string> - The generated hypothetical document text.
 * 
 * UNDER THE HOOD:
 * Instead of embedding the question "How do I reset password?", we ask the LLM
 * to answer it. The generated text ("To reset your password, navigate to settings...")
 * is semantically closer to the *answer* stored in the database.
 * When we embed this "answer," we bridge the gap between the question space and the answer space.
 */
async function generateHyDEContext(query: string): Promise<string> {
  try {
    const prompt = `
      Write a short, factual answer to the following question.
      Do not use greetings or filler words. Be direct and informative.
      
      Question: "${query}"
      Answer:
    `;

    const response = await openai.createChatCompletion({
      model: "gpt-3.5-turbo",
      messages: [{ role: "user", content: prompt }],
      temperature: 0.5,
      max_tokens: 150,
    });

    return response.data.choices[0]?.message?.content || "";
  } catch (error) {
    console.error("Error in generateHyDEContext:", error);
    return "";
  }
}

// ==========================================
// 4. VECTOR DATABASE MOCK & SEARCH
// ==========================================

/**
 * Mocks a Vector Database query.
 * In a real app, this would be Pinecone, Weaviate, Qdrant, or MongoDB Atlas.
 * 
 * @param textToEmbed - The text to generate an embedding for.
 * @returns Promise<RetrievedDocument[]>
 */
async function queryVectorStore(textToEmbed: string): Promise<RetrievedDocument[]> {
  // 1. Generate Embedding
  const embeddingResponse = await openai.createEmbedding({
    model: "text-embedding-ada-002",
    input: textToEmbed,
  });
  const vector = embeddingResponse.data.data[0].embedding;

  // 2. Simulate Vector Search (Mock Data)
  // In production: client.index('my-index').query({ vector, topK: 5 })
  console.log(`Querying vector store with dimension: ${vector.length}`);
  
  // Mocking results based on semantic similarity logic (simulated)
  return [
    { id: "doc_1", content: "To reset your password, go to Settings > Security > Change Password.", score: 0.92 },
    { id: "doc_2", content: "If you forgot your password, use the 'Forgot Password' link on the login screen.", score: 0.88 },
    { id: "doc_3", content: "Account recovery steps involve email verification and security questions.", score: 0.75 },
  ];
}

// ==========================================
// 5. MAIN API HANDLER
// ==========================================

/**
 * Next.js API Route Handler for Advanced RAG Search.
 * 
 * Logic Flow:
 * 1. Receive user query.
 * 2. Perform Query Expansion (generate variations).
 * 3. Perform HyDE (generate hypothetical context).
 * 4. Embed both expanded queries and HyDE context.
 * 5. Query Vector Store for all embeddings.
 * 6. Deduplicate and rank results.
 * 7. Return enriched response.
 */
export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse<SearchResponse>
) {
  if (req.method !== 'POST') {
    return res.status(405).json({ success: false, results: [], error: "Method Not Allowed" });
  }

  const { query } = req.body;

  if (!query || typeof query !== 'string') {
    return res.status(400).json({ success: false, results: [], error: "Invalid query" });
  }

  try {
    // Step 1: Query Expansion
    const expandedQueries = await expandQuery(query);
    
    // Step 2: HyDE Generation
    const hypotheticalContext = await generateHyDEContext(query);

    // Step 3: Parallel Retrieval
    // We search using the original query, the expanded queries, and the HyDE context.
    const searchPromises = [
      ...expandedQueries.map(q => queryVectorStore(q)),
      queryVectorStore(hypotheticalContext)
    ];

    const resultsArrays = await Promise.all(searchPromises);

    // Step 4: Deduplication & Ranking
    // Flatten results, sort by score, and remove duplicates based on ID
    const allResults = resultsArrays.flat();
    const uniqueResultsMap = new Map<string, RetrievedDocument>();

    allResults.forEach(doc => {
      const existing = uniqueResultsMap.get(doc.id);
      if (!existing || doc.score > existing.score) {
        uniqueResultsMap.set(doc.id, doc);
      }
    });

    // Sort by score descending
    const finalResults = Array.from(uniqueResultsMap.values())
      .sort((a, b) => b.score - a.score)
      .slice(0, 5); // Limit to top 5

    res.status(200).json({
      success: true,
      query,
      expandedQueries,
      hypotheticalContext,
      results: finalResults,
    });

  } catch (error) {
    console.error("Search API Error:", error);
    res.status(500).json({ 
      success: false, 
      results: [], 
      error: "Internal Server Error" 
    });
  }
}
