/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState } from 'react';

// Define the allowed retrieval modes
type RetrievalMode = 'standard' | 'hyde';

export const QueryOptimizerPanel: React.FC = () => {
    const [userQuery, setUserQuery] = useState<string>('');
    const [retrievalMode, setRetrievalMode] = useState<RetrievalMode>('standard');
    const [finalSearchVector, setFinalSearchVector] = useState<string>('');

    const handleGenerate = () => {
        if (!userQuery.trim()) return;

        let vector = '';
        
        // Logic: Determine the vector based on the mode
        if (retrievalMode === 'standard') {
            vector = userQuery;
        } else {
            // Simulate HyDE transformation
            vector = `${userQuery} [Hypothetical Context]`;
        }

        setFinalSearchVector(vector);
    };

    // Basic inline styles for layout
    const containerStyle: React.CSSProperties = {
        display: 'flex',
        flexDirection: 'column',
        gap: '15px',
        maxWidth: '500px',
        margin: '20px',
        padding: '20px',
        border: '1px solid #ddd',
        borderRadius: '8px',
        fontFamily: 'sans-serif'
    };

    const inputStyle: React.CSSProperties = {
        padding: '8px',
        fontSize: '14px'
    };

    const buttonStyle: React.CSSProperties = {
        padding: '10px',
        backgroundColor: '#007bff',
        color: 'white',
        border: 'none',
        borderRadius: '4px',
        cursor: 'pointer'
    };

    const displayStyle: React.CSSProperties = {
        marginTop: '10px',
        padding: '10px',
        backgroundColor: '#f9f9f9',
        border: '1px dashed #ccc',
        minHeight: '50px',
        whiteSpace: 'pre-wrap'
    };

    return (
        <div style={containerStyle}>
            <h3>Query Optimizer Panel</h3>
            
            {/* User Query Input */}
            <input
                type="text"
                placeholder="Enter your query..."
                value={userQuery}
                onChange={(e) => setUserQuery(e.target.value)}
                style={inputStyle}
            />

            {/* Mode Selection */}
            <div>
                <label>
                    <input
                        type="radio"
                        value="standard"
                        checked={retrievalMode === 'standard'}
                        onChange={() => setRetrievalMode('standard')}
                    />
                    Standard Retrieval
                </label>
                <label style={{ marginLeft: '15px' }}>
                    <input
                        type="radio"
                        value="hyde"
                        checked={retrievalMode === 'hyde'}
                        onChange={() => setRetrievalMode('hyde')}
                    />
                    HyDE Retrieval
                </label>
            </div>

            {/* Action Button */}
            <button onClick={handleGenerate} style={buttonStyle}>
                Generate Search Vector
            </button>

            {/* Visualization */}
            {finalSearchVector && (
                <div style={displayStyle}>
                    <strong>Final Search Vector:</strong><br/>
                    {finalSearchVector}
                </div>
            )}
        </div>
    );
};
