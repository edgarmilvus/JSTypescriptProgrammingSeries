/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

// 1. Define the Agent Classes

class QueryExpanderAgent {
    /**
     * Simulates expanding a query.
     * In a real system, this would call the logic from Exercise 1.
     */
    async execute(input: string): Promise<string> {
        // Simulate async work
        await new Promise(r => setTimeout(r, 100));
        return `Expanded: [${input} + related_terms]`;
    }
}

class HyDEAgent {
    /**
     * Simulates generating a hypothetical document.
     * In a real system, this would call the logic from Exercise 2.
     */
    async execute(input: string): Promise<string> {
        // Simulate async work
        await new Promise(r => setTimeout(r, 100));
        return `HyDE Context: [Hypothetical answer for "${input}"]`;
    }
}

// 2. Define the Supervisor Class

class Supervisor {
    private queryExpander: QueryExpanderAgent;
    private hydeAgent: HyDEAgent;

    constructor(expander: QueryExpanderAgent, hyde: HyDEAgent) {
        this.queryExpander = expander;
        this.hydeAgent = hyde;
    }

    /**
     * Orchestrates the pipeline by selecting the appropriate agent.
     */
    async runPipeline(query: string, strategy: 'expansion' | 'hyde'): Promise<string> {
        console.log(`Supervisor: Received query "${query}" with strategy "${strategy}"`);
        
        switch (strategy) {
            case 'expansion':
                return await this.queryExpander.execute(query);
            
            case 'hyde':
                return await this.hydeAgent.execute(query);
            
            default:
                throw new Error(`Unknown strategy: ${strategy}`);
        }
    }
}

// 3. Usage Example (Mocking)

export async function runAgentSimulation() {
    const expander = new QueryExpanderAgent();
    const hyde = new HyDEAgent();
    const supervisor = new Supervisor(expander, hyde);

    const query = "What is the capital of France?";

    // Test Expansion
    const result1 = await supervisor.runPipeline(query, 'expansion');
    console.log("Result:", result1);

    // Test HyDE
    const result2 = await supervisor.runPipeline(query, 'hyde');
    console.log("Result:", result2);
}
