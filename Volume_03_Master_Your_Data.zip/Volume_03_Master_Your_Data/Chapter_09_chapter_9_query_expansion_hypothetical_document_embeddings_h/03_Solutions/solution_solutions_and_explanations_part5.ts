/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

// 1. Mock Database
const mockDB = [
    "Guide to AES encryption standards and cryptography.",
    "Nutritional needs for dogs and canine diet plans.",
    "React component lifecycle and state management.",
    "Secure key management protocols for enterprise.",
    "Data security best practices for 2024."
];

/**
 * Mock KNN function using simple keyword matching.
 * Returns documents that contain any word from the query vector.
 */
function mockKNN(queryVector: string, k: number): string[] {
    // Normalize and split query into keywords
    const keywords = queryVector.toLowerCase().split(/\s+/);
    
    // Score documents based on keyword matches
    const scoredDocs = mockDB.map(doc => {
        const docLower = doc.toLowerCase();
        let score = 0;
        keywords.forEach(word => {
            // Simple check: if keyword is in document
            if (word.length > 3 && docLower.includes(word)) {
                score++;
            }
        });
        return { doc, score };
    });

    // Filter out non-matches, sort by score, and take top k
    return scoredDocs
        .filter(item => item.score > 0)
        .sort((a, b) => b.score - a.score)
        .slice(0, k)
        .map(item => item.doc);
}

// 2. Import/Define dependencies from previous exercises
// (For this standalone snippet, we will define simplified versions of the previous functions)
async function expandQuery(query: string): Promise<string> {
    // Mock expansion
    return `${query} encryption security password`;
}

async function generateHypotheticalAnswer(query: string): Promise<string> {
    // Mock HyDE generation
    return `A hypothetical answer regarding ${query} would likely mention encryption standards, security protocols, and data protection.`;
}

// 3. Main Simulation Function
export async function simulateRetrievalComparison(query: string): Promise<void> {
    console.log(`\n--- Simulation for Query: "${query}" ---`);

    // Strategy 1: Standard
    console.log("\n[Strategy: Standard KNN]");
    const standardResults = mockKNN(query, 3);
    standardResults.forEach((r, i) => console.log(`  ${i + 1}. ${r}`));

    // Strategy 2: Query Expansion
    console.log("\n[Strategy: Query Expansion]");
    const expandedQuery = await expandQuery(query);
    console.log(`  (Generated Vector: "${expandedQuery}")`);
    const expansionResults = mockKNN(expandedQuery, 3);
    expansionResults.forEach((r, i) => console.log(`  ${i + 1}. ${r}`));

    // Strategy 3: HyDE
    console.log("\n[Strategy: HyDE]");
    const hypotheticalDoc = await generateHypotheticalAnswer(query);
    console.log(`  (Generated Hypothetical Doc: "${hypotheticalDoc}")`);
    const hydeResults = mockKNN(hypotheticalDoc, 3);
    hydeResults.forEach((r, i) => console.log(`  ${i + 1}. ${r}`));
    
    console.log("\n--- End Simulation ---");
}

// Example Usage
// simulateRetrievalComparison("data security");
