/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * Parent Document Retrieval Pattern - "Hello World" Example
 * 
 * Context: SaaS Web App (Backend API)
 * Objective: Demonstrate indexing small chunks but retrieving large parents.
 * 
 * To run: Save as parent-retrieval.ts and execute with `npx ts-node parent-retrieval.ts`
 */

// ==========================================
// 1. MOCK INFRASTRUCTURE
// ==========================================

/**
 * Simulates a Vector Database (e.g., Pinecone, Weaviate).
 * In production, this would be an external API call.
 */
class MockVectorDB {
    private index: Array<{ id: string; vector: number[]; parentId: string }> = [];

    /**
     * Adds a child chunk to the vector index.
     * @param id - Unique ID of the chunk
     * @param vector - The embedding vector (simulated as array of numbers)
     * @param parentId - Reference to the original parent document
     */
    public add(id: string, vector: number[], parentId: string) {
        this.index.push({ id, vector, parentId });
    }

    /**
     * Simulates vector similarity search (Cosine Similarity).
     * Returns the ID of the child chunk that is most similar to the query.
     * @param queryVector - The numerical representation of the user question
     * @returns The ID of the best matching child chunk
     */
    public async search(queryVector: number[]): Promise<{ childId: string; parentId: string } | null> {
        if (this.index.length === 0) return null;

        // Simple Euclidean distance for simulation (lower is better)
        // In production, use Cosine Similarity provided by the DB.
        let bestMatch = this.index[0];
        let minDistance = Infinity;

        for (const item of this.index) {
            const distance = item.vector.reduce((acc, val, i) => acc + Math.pow(val - queryVector[i], 2), 0);
            if (distance < minDistance) {
                minDistance = distance;
                bestMatch = item;
            }
        }

        // Threshold to ensure relevance (simulated)
        if (minDistance > 5.0) return null; 

        return { childId: bestMatch.id, parentId: bestMatch.parentId };
    }
}

/**
 * Simulates an Embedding Model (e.g., OpenAI 'text-embedding-ada-002').
 * In production, this calls an external LLM API.
 */
const mockEmbed = async (text: string): Promise<number[]> => {
    // Deterministic "hash" for simulation so results are reproducible
    let hash = 0;
    for (let i = 0; i < text.length; i++) {
        hash = ((hash << 5) - hash) + text.charCodeAt(i);
        hash |= 0;
    }
    
    // Generate a vector of 4 dimensions (simplified for demo)
    // In production, dimensions are usually 1536 or 3072.
    const vector = [];
    for (let i = 0; i < 4; i++) {
        vector.push(Math.abs(Math.sin(hash + i)) * 10); // Randomish numbers 0-10
    }
    return vector;
};

// ==========================================
// 2. DATA STRUCTURES & STRATEGY
// ==========================================

/**
 * Represents a Parent Document (The full context).
 */
interface ParentDocument {
    id: string;
    content: string;
    metadata: { title: string; source: string };
}

/**
 * Represents a Child Chunk (The indexed unit).
 */
interface ChildChunk {
    id: string;
    parentId: string;
    content: string;
}

/**
 * Strategy: Simple Fixed-Size Chunking.
 * Splits text by spaces to approximate token count.
 */
function chunkParentDocument(parent: ParentDocument, maxTokens: number): ChildChunk[] {
    const words = parent.content.split(' ');
    const chunks: ChildChunk[] = [];
    
    for (let i = 0; i < words.length; i += maxTokens) {
        const chunkWords = words.slice(i, i + maxTokens);
        chunks.push({
            id: `${parent.id}_chunk_${Math.floor(i / maxTokens)}`,
            parentId: parent.id,
            content: chunkWords.join(' ')
        });
    }
    return chunks;
}

// ==========================================
// 3. ORCHESTRATION LOGIC
// ==========================================

/**
 * Main Application Logic (The RAG Pipeline)
 */
async function runParentRetrievalPipeline() {
    console.log("🚀 Starting Parent Document Retrieval Demo...\n");

    // --- Step 1: Ingestion (Indexing Phase) ---
    
    // 1a. Define Parent Documents (Source of Truth)
    const parentDocs: ParentDocument[] = [
        {
            id: "doc_001",
            content: "The QuantumLeap SaaS platform offers real-time analytics. It uses a vector database for retrieval. Pricing starts at $99/month.",
            metadata: { title: "Product Overview", source: "website" }
        },
        {
            id: "doc_002",
            content: "To reset your password, go to settings. Click 'Security', then 'Reset Password'. A link will be emailed to you.",
            metadata: { title: "User Guide", source: "docs" }
        }
    ];

    // 1b. Initialize Vector DB
    const vectorDB = new MockVectorDB();
    const dbStore: Record<string, ParentDocument> = {}; // Simulates a document store (e.g., MongoDB/Postgres)

    // 1c. Chunk, Embed, and Index
    console.log("1. Indexing Phase:");
    for (const parent of parentDocs) {
        // Store the parent document in the "Database"
        dbStore[parent.id] = parent;

        // Split into small children (Granular Search)
        const children = chunkParentDocument(parent, 5); // 5 words per chunk
        
        for (const child of children) {
            // Generate embedding for the CHILD
            const vector = await mockEmbed(child.content);
            
            // Add to Vector DB (linking child ID to parent ID)
            vectorDB.add(child.id, vector, child.id); // In real DB, we store metadata { parentId: parent.id }
            
            console.log(`   - Indexed Child: "${child.content.substring(0, 20)}..." -> Parent: ${parent.id}`);
        }
    }
    console.log("\n");

    // --- Step 2: Retrieval (Query Phase) ---

    const userQuery = "How do I reset access?";
    console.log(`2. Retrieval Phase: User asks "${userQuery}"`);

    // 2a. Embed the Query (Must use same model as indexing)
    const queryVector = await mockEmbed(userQuery);
    
    // 2b. Search the Vector DB (Finds the Child)
    const searchResult = await vectorDB.search(queryVector);
    
    if (!searchResult) {
        console.log("   No relevant chunks found.");
        return;
    }

    console.log(`   - Vector Search matched Child ID: ${searchResult.childId}`);

    // 2c. The "Parent Document" Step (The Pattern Core)
    // Instead of using the child text, we fetch the full parent document.
    const retrievedParent = dbStore[searchResult.parentId];
    
    console.log(`   - Fetched Parent Document ID: ${retrievedParent.id}`);
    console.log(`   - Full Context Length: ${retrievedParent.content.length} chars`);

    // --- Step 3: Synthesis (LLM Phase) ---

    console.log("\n3. Synthesis Phase:");
    console.log("   [Sending to LLM]");
    console.log("   Context: " + retrievedParent.content);
    console.log("   Query: " + userQuery);
    console.log("   --------------------------------");
    console.log("   LLM Response: To reset your password, go to settings, click 'Security', then 'Reset Password'.");
}

// Execute the pipeline
runParentRetrievalPipeline().catch(console.error);
