/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

'use server';

import { streamObject } from 'ai';
import { createStreamableValue, createStreamableUI } from 'ai/rsc';
import { z } from 'zod';
import { openai } from '@ai-sdk/openai';
import { ReactNode } from 'react';

// ==========================================
// 1. DATA MODELS & TYPES
// ==========================================

/**
 * Represents a chunk of text stored in the vector database.
 * In a production environment, this would be an entry in Pinecone, Qdrant, or Upstash.
 */
type VectorChunk = {
  id: string;
  embedding: number[]; // Vector representation
  text: string;
  parentId: string; // Link to the parent document
  chunkIndex: number; // Position within the parent
};

/**
 * Represents the full "Parent" document context.
 * In a real app, this is fetched from a standard SQL/NoSQL database.
 */
type ParentDocument = {
  id: string;
  title: string;
  content: string; // The full raw text
  metadata: {
    uploadedAt: Date;
    department: string;
  };
};

// ==========================================
// 2. MOCK DATA STORE (SIMULATED DATABASE)
// ==========================================

// Simulating a Vector Database (Pinecone/Qdrant) and a Document Store (Postgres/Mongo)
const mockParentDocs: ParentDocument[] = [
  {
    id: 'doc_001',
    title: 'Q4 Service Level Agreement (SLA)',
    content: `
      Article 1: Definitions
      "Service Provider" refers to TechCorp Inc.
      
      Article 2: Service Scope
      The provider agrees to maintain 99.9% uptime. Maintenance windows are scheduled for Sundays 0200-0400 UTC.
      
      Article 3: Termination
      Either party may terminate this agreement with 30 days written notice. In the event of a breach, the non-breaching party may terminate immediately.
      
      Article 4: Liability
      The Service Provider shall not be liable for indirect damages. Total liability is capped at the fees paid in the preceding 6 months.
    `,
    metadata: { uploadedAt: new Date(), department: 'Legal' },
  },
];

// Simulating small chunks of text (Child Documents) derived from the Parent
const mockVectorStore: VectorChunk[] = [
  {
    id: 'chunk_01',
    embedding: [0.1, 0.2, 0.3], // Placeholder for actual vector
    text: 'Either party may terminate this agreement with 30 days written notice.',
    parentId: 'doc_001',
    chunkIndex: 2, // Belongs to Article 3
  },
  {
    id: 'chunk_02',
    embedding: [0.4, 0.5, 0.6],
    text: 'In the event of a breach, the non-breaching party may terminate immediately.',
    parentId: 'doc_001',
    chunkIndex: 2, // Belongs to Article 3
  },
  {
    id: 'chunk_03',
    embedding: [0.7, 0.8, 0.9],
    text: 'Total liability is capped at the fees paid in the preceding 6 months.',
    parentId: 'doc_001',
    chunkIndex: 3, // Belongs to Article 4
  },
];

// ==========================================
// 3. CORE LOGIC: PARENT DOCUMENT RETRIEVAL
// ==========================================

/**
 * Simulates a Vector Similarity Search.
 * In production, this would be a query to your vector DB (e.g., Pinecone.query).
 * 
 * Logic:
 * 1. Takes a user query.
 * 2. Converts query to vector (mocked here).
 * 3. Finds the most relevant 'Child Chunk'.
 * 4. Returns the Chunk AND the Parent ID to fetch the full context.
 */
async function retrieveParentContext(query: string): Promise<{
  relevantChunk: VectorChunk;
  parentDoc: ParentDocument;
}> {
  // 1. Mock Embedding Generation (In reality: use OpenAI embedding model)
  console.log(`Generating embedding for query: "${query}"`);
  
  // 2. Mock Vector Search (Simple cosine similarity simulation)
  // We pick the first chunk that matches keywords for this demo
  const relevantChunk = mockVectorStore.find(c => 
    c.text.toLowerCase().includes('terminate') || 
    c.text.toLowerCase().includes('liability')
  ) || mockVectorStore[0];

  // 3. Fetch the Full Parent Document using the link
  const parentDoc = mockParentDocs.find(p => p.id === relevantChunk.parentId);

  if (!parentDoc) throw new Error('Parent document not found in store.');

  return { relevantChunk, parentDoc };
}

/**
 * Extracts the specific section (Article) from the Parent Document based on 
 * the retrieved chunk's index or semantic alignment.
 * 
 * Why do this? The LLM shouldn't read the *entire* 50-page contract, 
 * just the relevant section (e.g., Article 3: Termination).
 */
function extractParentSection(parentDoc: ParentDocument, chunk: VectorChunk): string {
  const articles = parentDoc.content.split('Article');
  // Simple logic: use the chunkIndex to find the correct article
  // Note: index 0 is usually empty or metadata, so we add 1
  const targetArticle = articles[chunk.chunkIndex + 1] || articles[1];
  return `Article ${chunk.chunkIndex}: ${targetArticle.trim()}`;
}

// ==========================================
// 4. STREAMING UI & AI SYNTHESIS (SERVER ACTION)
// ==========================================

/**
 * The main Server Action called from the Next.js Client Component.
 * Implements the 'streamable-ui' pattern.
 */
export async function analyzeContract(query: string) {
  // 1. Create a streamable UI container.
  // This allows us to send React components (like a button) incrementally.
  const uiStream = createStreamableValue<ReactNode>();

  // 2. Create a streamable text value for the raw LLM response.
  const textStream = createStreamableValue<string>();

  // 3. Perform Parent Document Retrieval
  const { relevantChunk, parentDoc } = await retrieveParentContext(query);
  const fullContextSection = extractParentSection(parentDoc, relevantChunk);

  // 4. Start the AI Generation in the background
  (async () => {
    try {
      // Prompt Engineering: We feed the LLM the specific Parent Section, 
      // not just the small child chunk. This preserves context.
      const prompt = `
        You are a legal assistant. 
        Context: ${fullContextSection}
        User Query: ${query}
        Instructions: Summarize the context strictly based on the provided article. 
        Do not invent facts.
      `;

      // Generate the text stream using Vercel AI SDK
      const { textStream: aiTextStream } = await streamText({
        model: openai('gpt-4-turbo-preview'),
        prompt,
      });

      // Pipe AI text to our streamable value
      for await (const chunk of aiTextStream) {
        textStream.update(chunk);
      }
      textStream.done();

      // 5. Inject a Streamable UI Component
      // We wait until the text is done, or we can do it concurrently.
      // Here, we append an interactive component at the end of the response.
      uiStream.update(
        <div className="mt-4 p-3 bg-blue-50 border border-blue-200 rounded-lg">
          <p className="text-sm font-semibold text-blue-800">Source Context Found:</p>
          <p className="text-xs text-blue-600 mb-2">Parent Document: {parentDoc.title}</p>
          <button 
            onClick={() => navigator.clipboard.writeText(fullContextSection)}
            className="px-3 py-1 bg-blue-600 text-white text-xs rounded hover:bg-blue-700 transition"
          >
            Copy Full Article
          </button>
        </div>
      );
      uiStream.done();

    } catch (error) {
      console.error('AI Generation Error:', error);
      textStream.error('Failed to generate analysis.');
      uiStream.error('Failed to load components.');
    }
  })();

  // Return the streams to the client
  return {
    ui: uiStream.value,
    text: textStream.value,
    metadata: {
      sourceDoc: parentDoc.title,
      retrievedSection: `Article ${relevantChunk.chunkIndex}`,
    },
  };
}

// Helper import for the demo (usually imported from 'ai' or 'openai')
// Mocking streamText for the script to be self-contained
async function streamText(opts: any) {
  // In a real app, this is: import { streamText } from 'ai';
  // Here we simulate a stream for the example.
  const mockStream = (async function* () {
    const words = "Based on the provided article, the termination clause allows either party to terminate with 30 days notice, or immediately in case of a breach.".split(' ');
    for (const word of words) {
      yield word + ' ';
      await new Promise(r => setTimeout(r, 50)); // Simulate latency
    }
  })();
  
  return { textStream: mockStream };
}
