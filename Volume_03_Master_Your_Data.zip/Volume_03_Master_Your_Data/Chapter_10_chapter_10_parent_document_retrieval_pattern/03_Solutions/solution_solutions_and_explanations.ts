/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// 1. Define Interfaces
interface ParentDoc {
    id: string;
    content: string;
}

interface ChildChunk {
    id: string;
    parentId: string;
    content: string;
    index: number;
}

/**
 * Generates a mock UUID (for demonstration purposes).
 * In production, use a library like 'uuid'.
 */
function generateUUID(): string {
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
        const r = Math.random() * 16 | 0;
        const v = c === 'x' ? r : (r & 0x3 | 0x8);
        return v.toString(16);
    });
}

// 2. Main Function
async function processDocumentHierarchy(
    text: string, 
    options: { chunkSize: number; overlap: number }
): Promise<{ parent: ParentDoc; children: ChildChunk[] } | null> {
    
    // Simulate resource acquisition (e.g., opening a file stream)
    console.log("Opening file stream and acquiring resources...");
    
    try {
        // Error Handling: Simulate failure conditions
        if (!text || text.length === 0) {
            throw new Error("Input text is empty.");
        }
        if (options.chunkSize <= options.overlap) {
            throw new Error("Chunk size must be greater than overlap.");
        }

        // Generate Parent ID
        const parentId = generateUUID();
        const parentDoc: ParentDoc = {
            id: parentId,
            content: text
        };

        const children: ChildChunk[] = [];
        let currentIdx = 0;
        let chunkIndex = 0;

        // 3. Chunking Logic: Sliding Window
        while (currentIdx < text.length) {
            // Calculate end index for the chunk
            let endIdx = currentIdx + options.chunkSize;
            
            // Ensure we don't go out of bounds
            if (endIdx > text.length) {
                endIdx = text.length;
            }

            const chunkContent = text.substring(currentIdx, endIdx);

            // Create Child Chunk
            const child: ChildChunk = {
                id: generateUUID(),
                parentId: parentId,
                content: chunkContent,
                index: chunkIndex
            };

            children.push(child);
            chunkIndex++;

            // Move the window forward by (chunkSize - overlap)
            currentIdx += (options.chunkSize - options.overlap);
            
            // Safety break if overlap is 0 or logic results in no movement
            if (currentIdx <= endIdx - options.overlap && options.overlap > 0) {
                // Ensure we make progress
                currentIdx = endIdx - options.overlap; 
            } else if (options.overlap === 0) {
                currentIdx = endIdx;
            }
        }

        return { parent: parentDoc, children };

    } catch (error) {
        console.error("Error processing document:", error);
        return null;
    } finally {
        // 4. Cleanup Simulation
        console.log("Closing file stream and releasing memory...");
    }
}

// Example Usage (Commented out for demonstration)
/*
const sampleText = "This is a long document. It contains multiple sentences. We need to chunk it effectively. Overlap helps maintain context.";
processDocumentHierarchy(sampleText, { chunkSize: 30, overlap: 10 })
    .then(result => console.log(JSON.stringify(result, null, 2)));
*/
