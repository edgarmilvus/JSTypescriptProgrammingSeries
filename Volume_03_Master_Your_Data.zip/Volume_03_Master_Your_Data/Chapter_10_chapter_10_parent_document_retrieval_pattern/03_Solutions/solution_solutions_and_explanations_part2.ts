/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

function synthesizeContext(
    retrievedChunks: string[],
    fullParent: string,
    tokenLimit: number
): string {
    // 1. Resilience: Handle invalid inputs
    if (tokenLimit < 0) {
        return "Error: Token limit cannot be negative.";
    }
    
    if (!fullParent && retrievedChunks.length === 0) {
        return ""; // Empty state
    }

    // 2. Logic: Check if Full Parent fits
    // (Treating 1 char = 1 token as per requirements)
    if (fullParent.length <= tokenLimit) {
        return fullParent;
    }

    // 3. Logic: Join unique child chunks
    // Using Set to ensure uniqueness if the same chunk is retrieved multiple times
    const uniqueChunks = Array.from(new Set(retrievedChunks));
    const joinedChildren = uniqueChunks.join(" ");

    if (joinedChildren.length <= tokenLimit) {
        return joinedChildren;
    }

    // 4. Logic: Truncate if neither fits perfectly
    // We slice the string to the limit and add an ellipsis to indicate truncation
    return joinedChildren.substring(0, tokenLimit - 3) + "...";
}

// Example Usage
/*
const parent = "This is a very long parent document that definitely exceeds the token limit.";
const chunks = ["Chunk 1 text.", "Chunk 2 text."];
console.log(synthesizeContext(chunks, parent, 10)); // Output: "Chunk 1..."
*/
