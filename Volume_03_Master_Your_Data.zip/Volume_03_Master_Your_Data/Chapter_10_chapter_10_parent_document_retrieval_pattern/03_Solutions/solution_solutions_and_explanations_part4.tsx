/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState } from 'react';

// 1. Props Interface
interface SearchResultProps {
    id: string;
    highlight: string;
    parentContext: string;
    score: number;
}

export const SearchResultItem: React.FC<SearchResultProps> = ({
    highlight,
    parentContext,
    score
}) => {
    // 2. State Management
    const [isExpanded, setIsExpanded] = useState(false);

    // 3. UX Constraint: Truncate long context
    const MAX_CONTEXT_LENGTH = 500;
    const displayContext = parentContext.length > MAX_CONTEXT_LENGTH 
        ? `${parentContext.substring(0, MAX_CONTEXT_LENGTH)}...` 
        : parentContext;

    return (
        <div className="search-result-item" style={{ border: '1px solid #ddd', padding: '16px', marginBottom: '12px', borderRadius: '8px' }}>
            
            {/* Score Display */}
            <div style={{ fontSize: '0.85rem', color: '#666', marginBottom: '8px' }}>
                Relevance Score: <strong>{score.toFixed(4)}</strong>
            </div>

            {/* Content Display Logic */}
            <div style={{ marginBottom: '12px', lineHeight: '1.5' }}>
                {isExpanded ? (
                    <p>{displayContext}</p>
                ) : (
                    <p>
                        ...<strong style={{ backgroundColor: '#fff3cd', color: '#856404' }}>{highlight}</strong>...
                    </p>
                )}
            </div>

            {/* Toggle Button */}
            <button 
                onClick={() => setIsExpanded(!isExpanded)}
                style={{
                    background: 'none',
                    border: '1px solid #007bff',
                    color: '#007bff',
                    padding: '4px 12px',
                    borderRadius: '4px',
                    cursor: 'pointer'
                }}
            >
                {isExpanded ? 'Show Highlight' : 'Show Full Context'}
            </button>
        </div>
    );
};

// Example Usage (for visualization)
/*
const mockProps: SearchResultProps = {
    id: "doc-123",
    highlight: "specific semantic search term",
    parentContext: "This is the full document content that provides broader context for the LLM. It includes surrounding sentences that might not match the query directly but help understand the topic. ".repeat(10), // Long string
    score: 0.8765
};

// <SearchResultItem {...mockProps} />
*/
