/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

// 1. Mock Dataset
const mockDataset = [
    {
        id: "doc_1",
        content: "The history of computing dates back to ancient abacus. Modern computers use binary logic.",
        chunks: ["history of computing", "dates back to ancient abacus", "modern computers use binary"],
        relevantKeyword: "binary" // Keyword indicating precision
    },
    {
        id: "doc_2",
        content: "Artificial Intelligence is evolving rapidly. Machine learning models require vast data.",
        chunks: ["Artificial Intelligence", "evolving rapidly", "machine learning models"],
        relevantKeyword: "evolving" 
    }
];

// 2. Evaluation Function
function evaluateRetrievalStrategies(query: string) {
    
    // Helper: Simulate Search Relevance
    // In a real system, this would be vector similarity search.
    // Here, we manually assign scores based on keyword matching.
    const getRelevance = (text: string) => {
        if (text.toLowerCase().includes("computing")) return 0.9;
        if (text.toLowerCase().includes("intelligence")) return 0.8;
        return 0.1; // Low relevance for others
    };

    // Helper: Check Precision (Does retrieved text contain the answer?)
    const calculatePrecision = (text: string, targetKeyword: string) => {
        // Simulate "Answer Existence": 1 if keyword present, 0 otherwise
        return text.toLowerCase().includes(targetKeyword.toLowerCase()) ? 1.0 : 0.0;
    };

    // Helper: Calculate Context Score (Richness)
    const calculateContextScore = (text: string) => {
        // Simple metric: Character count normalized
        return text.length;
    };

    // --- STRATEGY 1: CHILD-ONLY ---
    // We search chunks directly.
    const childResults = mockDataset.flatMap(doc => 
        doc.chunks.map(chunk => ({ text: chunk, parentId: doc.id, doc }))
    );
    // Sort by simulated relevance (mock logic)
    const topChild = childResults.sort((a, b) => getRelevance(b.text) - getRelevance(a.text))[0];
    
    const childPrecision = calculatePrecision(topChild.text, topChild.doc.relevantKeyword);
    const childContext = calculateContextScore(topChild.text);

    // --- STRATEGY 2: PARENT-ONLY ---
    // We search parent content directly.
    const parentResults = mockDataset.map(doc => ({ text: doc.content, doc }));
    const topParent = parentResults.sort((a, b) => getRelevance(b.text) - getRelevance(a.text))[0];

    const parentPrecision = calculatePrecision(topParent.text, topParent.doc.relevantKeyword);
    const parentContext = calculateContextScore(topParent.text);

    // --- STRATEGY 3: HYBRID (PARENT DOC RETRIEVAL) ---
    // Search children, but retrieve the full parent.
    // 1. Find best matching child (same as Strategy 1)
    const bestMatchChild = topChild; 
    // 2. Retrieve the associated full parent
    const retrievedFullParent = mockDataset.find(d => d.id === bestMatchChild.parentId)?.content || "";
    
    // Precision is based on the *parent* content containing the keyword
    // (Since we are sending the parent to the LLM)
    const hybridPrecision = calculatePrecision(retrievedFullParent, bestMatchChild.doc.relevantKeyword);
    const hybridContext = calculateContextScore(retrievedFullParent);

    // 5. Output Results
    return {
        strategy_child_only: {
            precision: childPrecision,
            contextScore: childContext,
            retrievedText: topChild.text
        },
        strategy_parent_only: {
            precision: parentPrecision,
            contextScore: parentContext,
            retrievedText: topParent.text.substring(0, 50) + "..."
        },
        strategy_hybrid: {
            precision: hybridPrecision,
            contextScore: hybridContext,
            retrievedText: "Full Parent Document..."
        }
    };
}

// Example Usage
/*
const results = evaluateRetrievalStrategies("computing");
console.log(results);
*/
