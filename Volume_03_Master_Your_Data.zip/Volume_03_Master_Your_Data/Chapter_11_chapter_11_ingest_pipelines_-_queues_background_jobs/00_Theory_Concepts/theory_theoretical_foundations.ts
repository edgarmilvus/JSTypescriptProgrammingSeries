/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: theory_theoretical_foundations.ts
// Description: Theoretical Foundations
// ==========================================

// This is a conceptual type definition, not executable code for this section.
// It illustrates the contract between producer and worker.

/**
 * Represents the data payload for a document ingestion job.
 * This interface is the single source of truth for the data structure
 * that travels across the queue boundary.
 */
interface IngestJobPayload {
  /**
   * A unique identifier for the document being processed.
   * This ID is used to track the document's state throughout the pipeline.
   */
  documentId: string;

  /**
   * The raw text content of the document.
   * For very large documents, this might be a reference to a storage location
   * (e.g., an S3 URI) rather than the full text itself, to keep the job payload small.
   */
  content: string;

  /**
   * Configuration parameters for the ingestion process.
   * This allows for different processing strategies for different document types.
   */
  config: {
    chunkSize: number;
    chunkOverlap: number;
    embeddingModel: string; // e.g., 'text-embedding-ada-002'
    vectorDimension: number;
  };

  /**
   * Metadata about the job's origin.
   */
  metadata: {
    uploadedBy: string;
    uploadTimestamp: Date;
    originalFilename: string;
  };
}
