/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

// =========================================================
// 1. SETUP & IMPORTS
// =========================================================
// We simulate the BullMQ library for this standalone example.
// In a real environment, you would: npm install bullmq ioredis

// --- MOCKING LIBRARY BEHAVIOR (For Demonstration Only) ---
// This allows the code to run without an actual Redis instance.
type JobStatus = 'waiting' | 'completed' | 'failed';
interface JobData { documentId: string; content: string; }
interface JobResult { embedding: number[]; tokenCount: number; }

class MockRedisClient {
  private queue: JobData[] = [];
  async rpush(key: string, item: JobData) { this.queue.push(item); }
  async blpop(key: string): Promise<JobData> {
    // Simulate waiting for a job
    return new Promise(resolve => {
      const check = () => {
        if (this.queue.length > 0) resolve(this.queue.shift()!);
        else setTimeout(check, 100);
      };
      check();
    });
  }
}

class MockQueue {
  constructor(private name: string, private redis: MockRedisClient) {}
  
  /** Adds a job to the queue (Producer side) */
  async add(name: string, data: JobData) {
    await this.redis.rpush(this.name, data);
    console.log(`[Producer] Job queued: ${data.documentId}`);
  }

  /** Waits for a job (Consumer side) */
  async getNextJob(): Promise<JobData> {
    return await this.redis.blpop(this.name);
  }
}

// --- REAL APPLICATION LOGIC ---

/**
 * Simulates AI Inference (Embedding Generation).
 * In production, this would call OpenAI or a local model.
 * SRP: This module ONLY handles vector generation.
 */
async function generateEmbedding(text: string): Promise<number[]> {
  // Simulate network latency
  await new Promise(r => setTimeout(r, 500)); 
  // Return a fake 3-dimensional vector
  return [text.length * 0.1, text.length * 0.2, text.length * 0.3];
}

/**
 * Simulates writing to a Vector Database (e.g., Pinecone, Qdrant).
 * SRP: This module ONLY handles persistence.
 */
async function writeToVectorDB(docId: string, vector: number[]) {
  console.log(`   [DB] Writing vector for ${docId}...`);
  // Simulate DB write latency
  await new Promise(r => setTimeout(r, 200));
  return true;
}

// =========================================================
// 2. THE BACKGROUND WORKER (The "Background Job")
// =========================================================

/**
 * The Worker process. 
 * In a real app, this runs in a separate Node.js process (e.g. `ts-node worker.ts`).
 * It polls the queue and executes the heavy lifting.
 */
async function startWorker(queue: MockQueue) {
  console.log("🚀 Worker started. Waiting for jobs...\n");

  while (true) {
    // 1. Wait (Block) until a job is available in Redis
    const jobData = await queue.getNextJob();

    try {
      console.log(`[Worker] Processing: ${jobData.documentId}`);
      
      // 2. Heavy Lifting: Generate Embeddings (CPU intensive)
      const vector = await generateEmbedding(jobData.content);
      
      // 3. Heavy Lifting: Database Write (I/O intensive)
      await writeToVectorDB(jobData.documentId, vector);

      console.log(`[Worker] ✅ Success: ${jobData.documentId}\n`);
      
    } catch (error) {
      // 4. Fault Tolerance: Catch errors to prevent worker crash
      console.error(`[Worker] ❌ Failed: ${jobData.documentId}`, error);
      // In BullMQ: job.moveToFailed(error)
    }
  }
}

// =========================================================
// 3. THE API PRODUCER (The "Web App")
// =========================================================

/**
 * Simulates an API Endpoint (e.g., POST /api/documents).
 * SRP: This module ONLY handles validation and queueing.
 */
async function handleDocumentUpload(queue: MockQueue, content: string) {
  // Strict Type Discipline: Validate inputs
  if (!content || typeof content !== 'string') {
    throw new Error("Invalid content type");
  }

  const docId = `doc_${Date.now()}`;
  
  // Optimistic UI Pattern (Server-side):
  // We return immediately, acknowledging receipt.
  // The UI can show a "Processing..." state.
  const response = {
    status: "accepted",
    documentId: docId,
    message: "Document received. Background processing started."
  };

  // Push to Queue (Non-blocking)
  await queue.add('process-document', {
    documentId: docId,
    content: content
  });

  return response;
}

// =========================================================
// 4. EXECUTION SIMULATION
// =========================================================

async function main() {
  // Initialize Infrastructure
  const redis = new MockRedisClient();
  const ingestQueue = new MockQueue('ingest-pipeline', redis);

  // Start the Background Worker (Simulating a separate thread/process)
  // We wrap this in a timeout to allow the main thread to log clearly first
  setTimeout(() => startWorker(ingestQueue), 100);

  // Simulate Web App Requests
  console.log("--- APP STARTED ---\n");
  
  // User uploads a document
  const result1 = await handleDocumentUpload(ingestQueue, "Hello World data for RAG.");
  console.log("[API] Response to Client:", result1);

  // User uploads another document immediately
  const result2 = await handleDocumentUpload(ingestQueue, "Mastering JavaScript data pipelines.");
  console.log("[API] Response to Client:", result2);
}

// Run the simulation
main();
