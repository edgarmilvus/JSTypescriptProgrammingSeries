/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

/**
 * FILE: app/api/ingest/route.ts
 * 
 * Context: Book 3, Chapter 11 - Advanced Application Script
 * Concepts: SRP, Strict Type Discipline, Optimistic UI, Async Queues
 */

import { NextRequest, NextResponse } from 'next/server';
import { Queue, Worker, Job } from 'bullmq';
import { z } from 'zod';

// ==========================================
// 1. STRICT TYPE DISCIPLINE & DATA CONTRACTS
// ==========================================

// Using Zod for runtime validation to enforce compile-time types.
// This prevents 'implicit any' and ensures data integrity entering the queue.

const IngestPayloadSchema = z.object({
  userId: z.string().uuid(),
  fileName: z.string().min(1),
  fileContent: z.string().base64(), // Simulating a text file encoded
  metadata: z.record(z.string()).optional(),
});

type IngestPayload = z.infer<typeof IngestPayloadSchema>;

// The shape of the job result (e.g., vector IDs returned by the DB)
type IngestResult = {
  documentId: string;
  chunkCount: number;
  status: 'completed' | 'failed';
};

// ==========================================
// 2. THE API ROUTE (SRP: Entry Point Only)
// ==========================================

/**
 * Handles the initial file upload.
 * Responsibility: Validate input -> Enqueue Job -> Return Job ID immediately.
 * It does NOT process the data.
 */
export async function POST(request: NextRequest) {
  try {
    // Parse and validate the incoming request
    const body = await request.json();
    const parsed = IngestPayloadSchema.safeParse(body);

    if (!parsed.success) {
      return NextResponse.json(
        { error: 'Invalid payload', details: parsed.error.flatten() },
        { status: 400 }
      );
    }

    const { userId, fileName, fileContent, metadata } = parsed.data;

    // Initialize Queue (In production, use a singleton or Redis connection wrapper)
    const queue = new Queue<IngestPayload, IngestResult>('ingest-queue', {
      connection: { host: 'localhost', port: 6379 }, // Redis connection
      defaultJobOptions: {
        attempts: 3, // Retry strategy
        backoff: { type: 'exponential', delay: 1000 },
        removeOnComplete: { age: 3600 }, // Keep results for 1 hour
        removeOnFail: false,
      },
    });

    // Add job to the queue
    // The payload is strictly typed by IngestPayload
    const job = await queue.add('process-document', {
      userId,
      fileName,
      fileContent,
      metadata,
    });

    // Return immediately to the client (Non-blocking)
    // Client receives job.id to poll for status or listen for webhook
    return NextResponse.json(
      { 
        message: 'Ingestion queued successfully', 
        jobId: job.id,
        statusUrl: `/api/status/${job.id}`
      },
      { status: 202 } // 202 Accepted
    );

  } catch (error) {
    console.error('Ingestion API Error:', error);
    return NextResponse.json(
      { error: 'Internal Server Error' },
      { status: 500 }
    );
  }
}

// ==========================================
// 3. THE BACKGROUND WORKER (SRP: Data Processing)
// ==========================================

/**
 * Simulated Background Worker.
 * In a real app, this runs in a separate Node.js process (e.g., `worker.ts`).
 * 
 * Responsibility: 
 * 1. Decode file content.
 * 2. Chunk text (Logic).
 * 3. Generate Embeddings (Simulated AI call).
 * 4. Store in Vector DB (Simulated).
 * 5. Update Job Status.
 */

// Mock Vector DB client
const mockVectorDB = {
  store: async (chunks: string[], metadata: any): Promise<string[]> => {
    // Simulate network latency
    await new Promise(resolve => setTimeout(resolve, 500));
    return chunks.map((_, i) => `vec-${metadata.userId}-${i}`);
  }
};

// Mock AI Embedding Generator
const mockEmbedder = async (text: string): Promise<number[]> => {
  // Simulate AI inference latency
  await new Promise(resolve => setTimeout(resolve, 100));
  // Return a dummy vector
  return Array(1536).fill(0).map(() => Math.random());
};

/**
 * Logic: Chunking text into manageable pieces for RAG.
 * Adheres to SRP by isolating text processing logic.
 */
const chunkText = (text: string, chunkSize: number = 500): string[] => {
  const words = text.split(' ');
  const chunks: string[] = [];
  for (let i = 0; i < words.length; i += chunkSize) {
    chunks.push(words.slice(i, i + chunkSize).join(' '));
  }
  return chunks;
};

// Initialize Worker (Usually in a separate file)
const worker = new Worker<IngestPayload, IngestResult>(
  'ingest-queue',
  async (job: Job<IngestPayload>) => {
    const { fileContent, userId, fileName } = job.data;

    // 1. Decode (Simulated)
    const textContent = Buffer.from(fileContent, 'base64').toString('utf-8');
    
    // 2. Chunk
    const chunks = chunkText(textContent);
    
    // 3. Embed & Store (Sequential to avoid overwhelming the AI API)
    const vectorIds: string[] = [];
    for (const chunk of chunks) {
      await mockEmbedder(chunk); // Generate embedding
      const ids = await mockVectorDB.store([chunk], { userId, fileName }); // Store
      vectorIds.push(...ids);
    }

    // 4. Return Result
    return {
      documentId: `doc-${Date.now()}`,
      chunkCount: chunks.length,
      status: 'completed',
    };
  },
  {
    connection: { host: 'localhost', port: 6379 },
    concurrency: 5, // Process 5 jobs simultaneously
  }
);

worker.on('completed', (job, result) => {
  console.log(`Job ${job.id} completed. Result:`, result);
  // Here you would trigger a webhook to the client to update the UI (Reconciliation)
});

worker.on('failed', (job, err) => {
  console.error(`Job ${job.id} failed:`, err);
});
