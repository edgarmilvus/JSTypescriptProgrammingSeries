/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// ---------------------------------------------------------
// 1. TYPE DEFINITIONS (Strict Type Discipline)
// ---------------------------------------------------------
import { Queue, Worker, Job } from 'bullmq';
import { v4 as uuidv4 } from 'uuid';

// Interfaces for Job Payload and Result
export interface IngestJobPayload {
  fileId: string;
  filePath: string;
  userId: string;
}

export interface IngestJobResult {
  chunksCount: number;
  vectorIds: string[];
  processingTimeMs: number;
}

// Union type for Job Status
export type JobStatus = 'waiting' | 'active' | 'completed' | 'failed' | 'delayed';

// ---------------------------------------------------------
// 2. QUEUE MANAGER
// ---------------------------------------------------------
export class QueueManager {
  private queue: Queue;

  constructor() {
    // Connect to local Redis instance
    this.queue = new Queue<IngestJobPayload>('ingest-queue', {
      connection: { host: '127.0.0.1', port: 6379 },
    });
  }

  /**
   * Adds a new job to the queue.
   */
  public async addJob(payload: IngestJobPayload): Promise<string> {
    const job = await this.queue.add('ingest', payload, {
      // Retry configuration: 3 attempts with exponential backoff
      attempts: 3,
      backoff: {
        type: 'exponential',
        delay: 2000, // 2 seconds initial delay
      },
    });
    return job.id!;
  }

  /**
   * Retrieves a job by ID to check its status.
   */
  public async getJobStatus(jobId: string): Promise<Job<IngestJobPayload> | null> {
    return await this.queue.getJob(jobId);
  }
  
  /**
   * Closes the queue connection.
   */
  public async close(): Promise<void> {
    await this.queue.close();
  }
}

// ---------------------------------------------------------
// 3. WORKER IMPLEMENTATION
// ---------------------------------------------------------
export class IngestWorker {
  private worker: Worker<IngestJobPayload, IngestJobResult>;

  constructor() {
    this.worker = new Worker<IngestJobPayload, IngestJobResult>(
      'ingest-queue',
      async (job: Job<IngestJobPayload>) => {
        // Simulate processing logic (e.g., reading file, generating embeddings)
        console.log(`Processing job ${job.id} for file: ${job.data.fileId}`);
        
        // Simulate work delay (1-3 seconds)
        const processingTime = Math.floor(Math.random() * 2000) + 1000;
        await new Promise(resolve => setTimeout(resolve, processingTime));

        // Simulate transient failure (10% chance)
        if (Math.random() < 0.1) {
          throw new Error('Transient error: Connection to S3 timed out');
        }

        // Return result
        return {
          chunksCount: Math.floor(Math.random() * 50) + 10,
          vectorIds: [uuidv4(), uuidv4(), uuidv4()],
          processingTimeMs: processingTime,
        };
      },
      {
        connection: { host: '127.0.0.1', port: 6379 },
        concurrency: 5, // Process 5 jobs concurrently
        removeOnComplete: { count: 100 }, // Keep last 100 completed jobs
        removeOnFail: { count: 50 }, // Keep last 50 failed jobs
      }
    );

    // Event Listeners for logging
    this.worker.on('completed', (job, result) => {
      console.log(`Job ${job.id} completed with result:`, result);
    });

    this.worker.on('failed', (job, err) => {
      console.error(`Job ${job.id} failed after ${job.attemptsMade} attempts:`, err.message);
    });
  }

  public async close(): Promise<void> {
    await this.worker.close();
  }
}

// ---------------------------------------------------------
// 4. API ENDPOINTS (Express Mock)
// ---------------------------------------------------------
/*
import express, { Request, Response } from 'express';

const app = express();
app.use(express.json());
const manager = new QueueManager();

// 5. Job Status Endpoint
app.post('/ingest', async (req: Request, res: Response) => {
  const { fileId, filePath, userId } = req.body;
  
  // Basic validation
  if (!fileId || !filePath || !userId) {
    return res.status(400).json({ error: 'Missing required fields' });
  }

  const jobId = await manager.addJob({ fileId, filePath, userId });
  res.status(202).json({ jobId, message: 'Job queued successfully' });
});

app.get('/jobs/:id/status', async (req: Request, res: Response) => {
  const { id } = req.params;
  const job = await manager.getJobStatus(id);

  if (!job) {
    return res.status(404).json({ error: 'Job not found' });
  }

  // BullMQ job state returns: 'completed', 'failed', 'active', 'waiting', 'delayed', 'paused'
  const state = await job.getState(); 
  
  res.json({
    id: job.id,
    status: state,
    progress: job.progress(),
    result: job.returnvalue, // Only populated if completed
    failedReason: job.failedReason, // Only populated if failed
  });
});

// Start worker (usually in a separate process, but for demo we start it here)
const worker = new IngestWorker();

// app.listen(3000, () => console.log('Server running on port 3000'));
*/
