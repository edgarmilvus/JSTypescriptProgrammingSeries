/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState, useEffect } from 'react';

// 1. Type Definitions
interface DisplayJob {
  id: string;
  status: 'pending' | 'waiting' | 'active' | 'completed' | 'failed';
  progress: number;
  result?: { chunksCount: number; vectorIds: string[] };
}

// 2. Mock API Service (Simulating backend calls)
const mockApi = {
  // Simulates fetching initial list
  getJobs: async (): Promise<DisplayJob[]> => {
    return new Promise(resolve => setTimeout(() => resolve([
      { id: '101', status: 'completed', progress: 100, result: { chunksCount: 12, vectorIds: ['vec1'] } },
      { id: '102', status: 'active', progress: 45, result: undefined },
    ]), 500));
  },
  
  // Simulates a retry request
  retryJob: async (id: string): Promise<void> => {
    console.log(`Retrying job ${id}...`);
    return new Promise(resolve => setTimeout(resolve, 500));
  }
};

// 3. The Component
const JobQueueMonitor: React.FC = () => {
  const [jobs, setJobs] = useState<DisplayJob[]>([]);
  const [error, setError] = useState<string | null>(null);

  // Fetch initial data on mount
  useEffect(() => {
    const fetchInitialJobs = async () => {
      try {
        const initialJobs = await mockApi.getJobs();
        setJobs(initialJobs);
      } catch (err) {
        setError('Failed to load initial jobs.');
      }
    };
    fetchInitialJobs();
  }, []);

  // Simulate Real-Time Updates (Polling/WebSocket simulation)
  useEffect(() => {
    const interval = setInterval(() => {
      setJobs(prevJobs => {
        if (prevJobs.length === 0) return prevJobs;

        // Randomly update one job to simulate real-time progress
        return prevJobs.map(job => {
          // Don't update pending or completed jobs randomly
          if (job.status === 'pending' || job.status === 'completed') return job;

          // Randomly fail a job for demonstration
          if (job.status === 'active' && Math.random() < 0.05) {
            return { ...job, status: 'failed', progress: 0 };
          }

          // Increment progress for active jobs
          if (job.status === 'active') {
            const newProgress = Math.min(job.progress + 10, 100);
            const newStatus = newProgress === 100 ? 'completed' : 'active';
            const result = newStatus === 'completed' 
              ? { chunksCount: Math.floor(Math.random() * 50), vectorIds: ['vec_x', 'vec_y'] } 
              : undefined;
            
            return { ...job, progress: newProgress, status: newStatus, result };
          }

          // Promote waiting to active
          if (job.status === 'waiting') {
            return { ...job, status: 'active', progress: 10 };
          }

          return job;
        });
      });
    }, 1000); // Update every second

    return () => clearInterval(interval);
  }, []);

  // 4. Optimistic UI: Handle New Job Upload
  const handleUpload = () => {
    const newId = Math.floor(Math.random() * 10000).toString();
    const newJob: DisplayJob = {
      id: newId,
      status: 'pending', // Optimistic state
      progress: 0,
    };

    // Immediately add to UI
    setJobs(prev => [newJob, ...prev]);

    // Simulate API call delay, then transition to 'waiting' (confirmed by server)
    setTimeout(() => {
      setJobs(prev => prev.map(j => 
        j.id === newId ? { ...j, status: 'waiting' } : j
      ));
    }, 1500);
  };

  // 5. Error Handling & Retry
  const handleRetry = async (id: string) => {
    setError(null);
    try {
      await mockApi.retryJob(id);
      // Optimistically update UI to waiting
      setJobs(prev => prev.map(j => 
        j.id === id ? { ...j, status: 'pending', progress: 0 } : j
      ));
    } catch (err) {
      setError('Failed to retry job.');
    }
  };

  return (
    <div style={{ fontFamily: 'sans-serif', padding: '20px' }}>
      <h2>Ingestion Job Monitor</h2>
      
      <button onClick={handleUpload} style={{ marginBottom: '15px', padding: '8px 16px' }}>
        Upload New File (Optimistic)
      </button>

      {error && <div style={{ color: 'red', marginBottom: '10px' }}>{error}</div>}

      <table border={1} cellPadding={10} style={{ width: '100%', borderCollapse: 'collapse' }}>
        <thead>
          <tr style={{ background: '#f0f0f0' }}>
            <th>Job ID</th>
            <th>Status</th>
            <th>Progress</th>
            <th>Result / Actions</th>
          </tr>
        </thead>
        <tbody>
          {jobs.map(job => (
            <tr key={job.id}>
              <td>{job.id}</td>
              <td>
                <span style={{ 
                  fontWeight: 'bold', 
                  color: job.status === 'failed' ? 'red' : job.status === 'completed' ? 'green' : 'black' 
                }}>
                  {job.status.toUpperCase()}
                </span>
              </td>
              <td>
                <div style={{ background: '#ddd', height: '10px', width: '100px', position: 'relative' }}>
                  <div style={{ 
                    background: job.status === 'failed' ? 'red' : 'blue', 
                    width: `${job.progress}%`, 
                    height: '100%' 
                  }}></div>
                </div>
              </td>
              <td>
                {job.status === 'failed' && (
                  <button onClick={() => handleRetry(job.id)}>Retry</button>
                )}
                {job.status === 'completed' && job.result && (
                  <span>Chunks: {job.result.chunksCount}</span>
                )}
                {job.status === 'pending' && <span>(Waiting for server...)</span>}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default JobQueueMonitor;
