/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

// 1. The Generic Interface (Contract)
interface ProcessorModule<TInput, TOutput> {
  process(input: TInput): Promise<TOutput>;
}

// 2. Concrete Module Implementations

// Stage 1: Buffer -> String
class TextExtractorModule implements ProcessorModule<Buffer, string> {
  async process(input: Buffer): Promise<string> {
    console.log('[Module] Extracting text from buffer...');
    // In reality, this might use pdf-parse or similar
    return input.toString('utf-8');
  }
}

// Stage 2: String -> String
class TextCleanerModule implements ProcessorModule<string, string> {
  async process(input: string): Promise<string> {
    console.log('[Module] Cleaning text...');
    // Remove extra whitespace, special chars, etc.
    return input.replace(/\s+/g, ' ').trim();
  }
}

// Stage 3: String -> String[]
class ChunkerModule implements ProcessorModule<string, string[]> {
  async process(input: string): Promise<string[]> {
    console.log('[Module] Chunking text...');
    // Split by sentence or fixed length
    return input.split('.').filter(chunk => chunk.length > 0);
  }
}

// 3. The Orchestrator
class PipelineOrchestrator {
  // We need to store modules in a way that preserves type safety sequentially
  // However, a generic array `ProcessorModule<any, any>[]` loses strict types between steps.
  // For this exercise, we will use a specific sequence or 'any' for simplicity, 
  // but ideally we would use recursive types for strict chaining.
  
  private modules: ProcessorModule<any, any>[] = [];

  // Adds a module to the pipeline
  public use<TInput, TOutput>(module: ProcessorModule<TInput, TOutput>): PipelineOrchestrator {
    this.modules.push(module);
    return this; // Return this for chaining
  }

  // Executes the pipeline
  public async execute<TInput, TOutput>(input: TInput): Promise<TOutput> {
    let currentData: any = input;

    for (let i = 0; i < this.modules.length; i++) {
      const module = this.modules[i];
      try {
        console.log(`--- Step ${i + 1} ---`);
        // Pass current data to the next module
        currentData = await module.process(currentData);
      } catch (err) {
        // Error Propagation with context
        const moduleName = module.constructor.name;
        throw new Error(`Pipeline failed at module [${moduleName}]: ${err.message}`);
      }
    }

    return currentData as TOutput;
  }
}

// 4. Usage Example
async function runPipeline() {
  // Input data
  const rawFileBuffer = Buffer.from("Hello world. This is a test document. It has multiple sentences.");

  // Initialize Orchestrator
  const pipeline = new PipelineOrchestrator();

  // Chain modules (Order matters!)
  pipeline
    .use(new TextExtractorModule()) // Buffer -> string
    .use(new TextCleanerModule())   // string -> string
    .use(new ChunkerModule());      // string -> string[]

  try {
    // Execute
    const result = await pipeline.execute<string[], string[]>(rawFileBuffer); 
    // Note: Input type here is technically Buffer, but TS inference can be tricky in complex chains.
    // Ideally, we cast or ensure the first input matches the first module.
    
    // Correct execution call signature (Input is Buffer, Output is string[]):
    const finalResult = await pipeline.execute<Buffer, string[]>(rawFileBuffer);
    
    console.log('\nPipeline Result:', finalResult);
  } catch (err) {
    console.error(err);
  }
}

// runPipeline();
