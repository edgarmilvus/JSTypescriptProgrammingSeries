/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

import inquirer from 'inquirer';

// 1. Define the structure of a Module for our graph generation
interface GraphModule {
  name: string;
  inputType: string;
  outputType: string;
}

// 2. Initial Pipeline State
const initialPipeline: GraphModule[] = [
  { name: 'TextExtractor', inputType: 'Buffer', outputType: 'string' },
  { name: 'TextCleaner', inputType: 'string', outputType: 'string' },
  { name: 'Chunker', inputType: 'string', outputType: 'string[]' },
];

// 3. Function to generate DOT syntax
function generateDot(pipeline: GraphModule[]): string {
  let dotLines: string[] = [];
  
  // Header
  dotLines.push('digraph Pipeline {');
  dotLines.push('  rankdir=TB;');
  dotLines.push('  node [shape=box];');
  dotLines.push('');

  // Nodes
  pipeline.forEach(mod => {
    const label = `${mod.name}\\n(${mod.inputType} -> ${mod.outputType})`;
    dotLines.push(`  "${mod.name}" [label="${label}"];`);
  });

  dotLines.push('');

  // Edges (Connections)
  for (let i = 0; i < pipeline.length - 1; i++) {
    dotLines.push(`  "${pipeline[i].name}" -> "${pipeline[i+1].name}";`);
  }

  dotLines.push('}');
  return dotLines.join('\n');
}

// 4. Main Interactive Function
async function main() {
  console.log('--- Pipeline Graph Generator ---\n');
  
  // Clone initial state so we can modify it
  let currentPipeline = [...initialPipeline];

  while (true) {
    const answers = await inquirer.prompt([
      {
        type: 'list',
        name: 'action',
        message: 'What would you like to do?',
        choices: ['Add Custom Module', 'View DOT Graph', 'Exit'],
      },
    ]);

    if (answers.action === 'Exit') {
      break;
    }

    if (answers.action === 'View DOT Graph') {
      console.log('\n--- Generated DOT Code ---');
      console.log(generateDot(currentPipeline));
      console.log('--------------------------\n');
    }

    if (answers.action === 'Add Custom Module') {
      const newModuleAnswers = await inquirer.prompt([
        {
          type: 'input',
          name: 'name',
          message: 'Enter module name (e.g., LanguageDetector):',
          validate: (input) => input.length > 0 ? true : 'Name is required',
        },
        {
          type: 'input',
          name: 'inputType',
          message: 'Enter input type (e.g., string):',
          validate: (input) => input.length > 0 ? true : 'Input type is required',
        },
        {
          type: 'input',
          name: 'outputType',
          message: 'Enter output type (e.g., { lang: string }):',
          validate: (input) => input.length > 0 ? true : 'Output type is required',
        },
        {
          type: 'list',
          name: 'position',
          message: 'Where to insert it?',
          choices: [
            { name: 'At the beginning', value: 0 },
            { name: 'After TextCleaner', value: 2 }, // Index of TextCleaner + 1
            { name: 'At the end', value: 'end' },
          ],
        },
      ]);

      const newModule: GraphModule = {
        name: newModuleAnswers.name,
        inputType: newModuleAnswers.inputType,
        outputType: newModuleAnswers.outputType,
      };

      // Insert logic
      if (newModuleAnswers.position === 'end') {
        currentPipeline.push(newModule);
      } else {
        // We need to handle the logic of inserting into the array
        // If we insert at index 2, we shift the existing element at 2 to the right
        currentPipeline.splice(newModuleAnswers.position as number, 0, newModule);
      }

      console.log(`\nAdded ${newModule.name} to pipeline.\n`);
    }
  }
}

// Run the script
// To run this, you would compile it and execute: node ./script.js
// main(); 
