/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * vector_sync_example.ts
 * 
 * A demonstration of handling updates and deletions in Pinecone 
 * for a RAG application.
 * 
 * Prerequisites:
 * - Node.js environment
 * - npm install @pinecone-database/pinecone
 * - Environment variables: PINECONE_API_KEY, PINECONE_ENVIRONMENT, PINECONE_INDEX_NAME
 */

import { Pinecone } from '@pinecone-database/pinecone';

// ============================================================================
// 1. CONFIGURATION & TYPES
// ============================================================================

// Define the shape of our document data
interface DocumentChunk {
  id: string;          // Unique ID (matches Vector ID)
  text: string;        // The actual content
  metadata: Record<string, any>; // Source info, page number, etc.
}

// Mock response from an embedding service (e.g., OpenAI, Cohere)
interface EmbeddingResponse {
  embedding: number[];
}

// ============================================================================
// 2. HELPER: MOCK EMBEDDING SERVICE
// ============================================================================

/**
 * Simulates an external API call to generate vector embeddings.
 * In production, this would be `await openai.embeddings.create(...)`
 * 
 * @param text - The text to embed
 * @returns A Promise resolving to a high-dimensional vector array
 */
async function generateEmbedding(text: string): Promise<number[]> {
  console.log(`[Embedding Service] Generating vector for text: "${text.substring(0, 20)}..."`);
  
  // Simulate network latency
  await new Promise(resolve => setTimeout(resolve, 100));
  
  // Return a dummy 1536-dimensional vector (common for OpenAI text-embedding-ada-002)
  // In a real app, this is a dense array of floats.
  const dummyVector = Array.from({ length: 1536 }, () => Math.random());
  return dummyVector;
}

// ============================================================================
// 3. MAIN LOGIC: VECTOR DB SYNCHRONIZATION
// ============================================================================

/**
 * Orchestrates the update and deletion operations on the Pinecone index.
 */
async function syncVectorDatabase() {
  // --- Initialization ---
  const pinecone = new Pinecone({
    environment: process.env.PINECONE_ENVIRONMENT || 'us-west1-gcp',
    apiKey: process.env.PINECONE_API_KEY || 'placeholder-key',
  });

  const indexName = process.env.PINECONE_INDEX_NAME || 'rag-demo-index';
  const index = pinecone.Index(indexName);

  console.log(`\n🚀 Connected to Pinecone Index: ${indexName}\n`);

  // --- SCENARIO A: UPDATING A DOCUMENT ---
  console.log('--- SCENARIO A: Handling Document Update ---');

  // 1. Identify the document to update (simulating fetching from a DB)
  const documentToUpdate: DocumentChunk = {
    id: 'doc_123_chunk_1', // This ID must match the existing Vector ID in Pinecone
    text: 'The quick brown fox jumps over the lazy dog.', // OLD VERSION
    metadata: { source: 'knowledge_base_v1', lastUpdated: '2023-10-01' }
  };

  console.log(`[App] Processing update for ID: ${documentToUpdate.id}`);
  console.log(`[App] Old Content: "${documentToUpdate.text}"`);

  // 2. Simulate User Edit (New Content)
  const updatedContent = 'The quick brown fox jumps over the lazy cat.'; // NEW VERSION
  documentToUpdate.text = updatedContent;
  documentToUpdate.metadata.lastUpdated = new Date().toISOString();

  // 3. Generate new embedding for the updated text
  // CRITICAL: You cannot simply update metadata; the semantic vector must change 
  // if the text content changes.
  const newVector = await generateEmbedding(documentToUpdate.text);

  // 4. Upsert (Update) the vector in Pinecone
  // Pinecone's `upsert` operation is idempotent. If the ID exists, it overwrites 
  // the vector and metadata. If it doesn't exist, it creates a new one.
  try {
    await index.upsert([
      {
        id: documentToUpdate.id,
        values: newVector,
        metadata: documentToUpdate.metadata
      }
    ]);
    console.log(`✅ [Pinecone] Successfully updated vector ID: ${documentToUpdate.id}`);
  } catch (error) {
    console.error('❌ [Pinecone] Error updating vector:', error);
  }

  // --- SCENARIO B: DELETING A DOCUMENT ---
  console.log('\n--- SCENARIO B: Handling Document Deletion ---');

  // 1. Identify the document to delete
  const documentToDeleteId = 'doc_456_chunk_2';
  console.log(`[App] Request to delete document ID: ${documentToDeleteId}`);

  // 2. Delete the vector from Pinecone
  // This removes the vector and its metadata entirely from the index.
  try {
    await index.deleteOne(documentToDeleteId);
    console.log(`✅ [Pinecone] Successfully deleted vector ID: ${documentToDeleteId}`);
  } catch (error) {
    console.error('❌ [Pinecone] Error deleting vector:', error);
  }

  // --- SCENARIO C: BATCH OPERATIONS (Advanced) ---
  console.log('\n--- SCENARIO C: Batch Upsert (Efficiency) ---');
  
  // When handling multiple updates, avoid sequential loops. Use Promise.all or batch upserts.
  const updates: DocumentChunk[] = [
    { id: 'doc_789_chunk_1', text: 'New content A', metadata: {} },
    { id: 'doc_789_chunk_2', text: 'New content B', metadata: {} },
  ];

  // Map updates to embedding promises
  const embeddingPromises = updates.map(async (doc) => {
    const vector = await generateEmbedding(doc.text);
    return {
      id: doc.id,
      values: vector,
      metadata: doc.metadata
    };
  });

  const vectorsToUpsert = await Promise.all(embeddingPromises);

  // Pinecone allows upserting up to 100 vectors per request
  try {
    await index.upsert(vectorsToUpsert);
    console.log(`✅ [Pinecone] Batch upserted ${vectorsToUpsert.length} vectors.`);
  } catch (error) {
    console.error('❌ [Pinecone] Batch error:', error);
  }
}

// ============================================================================
// 4. EXECUTION WRAPPER
// ============================================================================

// Execute the sync logic
syncVectorDatabase()
  .then(() => console.log('\n🏁 Sync process completed.'))
  .catch((err) => console.error('\n💥 Fatal error:', err));
