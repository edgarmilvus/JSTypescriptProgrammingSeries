/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

/**
 * ADVANCED VECTOR SYNC SCRIPT
 * 
 * Context: Book 3, Chapter 12 - Handling Updates & Deletions in Vector DBs
 * 
 * Objective: Implement a robust synchronization service for a RAG system using pgvector.
 * Features:
 * 1. Upsert logic for updates and new inserts.
 * 2. Soft deletion handling to maintain index integrity.
 * 3. Metadata management for filtering (e.g., user_id, active status).
 */

import { Pool, QueryResult } from 'pg';

// --- 1. CONFIGURATION & TYPES ---

// Configuration for the pgvector connection (Supabase or standard Postgres)
const dbConfig = {
    connectionString: process.env.DATABASE_URL!,
    ssl: { rejectUnauthorized: false }, // Required for cloud providers
};

// Define the structure of our document source
interface SourceDocument {
    id: string; // Unique UUID from primary DB
    content: string;
    userId: string;
    isActive: boolean; // Reflects the state in the source DB
}

// Define the structure of the vector payload
interface VectorPayload {
    id: string; // Matches SourceDocument.id
    embedding: number[]; // The vector array
    metadata: {
        userId: string;
        active: boolean;
        lastSynced: number;
    };
}

// --- 2. DATABASE CLIENT INITIALIZATION ---

const pool = new Pool(dbConfig);

/**
 * Initializes the pgvector extension and table if they don't exist.
 * In a real app, this is usually handled by migrations.
 */
async function initializeVectorStore(): Promise<void> {
    const client = await pool.connect();
    try {
        await client.query('CREATE EXTENSION IF NOT EXISTS vector;');
        
        // Create table with pgvector column type 'vector(1536)' (e.g., for OpenAI text-embedding-ada-002)
        await client.query(`
            CREATE TABLE IF NOT EXISTS document_vectors (
                id UUID PRIMARY KEY,
                embedding vector(1536),
                metadata JSONB,
                created_at TIMESTAMP DEFAULT NOW(),
                updated_at TIMESTAMP DEFAULT NOW()
            );
        `);
        
        // Create an index for HNSW (Hierarchical Navigable Small World) for fast KNN search
        await client.query(`
            CREATE INDEX IF NOT EXISTS idx_document_embedding 
            ON document_vectors 
            USING hnsw (embedding vector_cosine_ops);
        `);
        
        console.log('✅ Vector store initialized.');
    } catch (error) {
        console.error('❌ Error initializing vector store:', error);
    } finally {
        client.release();
    }
}

// --- 3. CORE LOGIC: EMBEDDING & SYNC ---

/**
 * Mock Embedding Function.
 * In production, replace this with a call to OpenAI, Cohere, or a local model.
 * 
 * @param text - The content to vectorize
 * @returns Promise<number[]> - The vector embedding
 */
async function generateEmbedding(text: string): Promise<number[]> {
    // SIMULATION: Generating a random 1536-dimension vector for demonstration
    // In reality: const response = await openai.embeddings.create({ model: 'text-embedding-ada-002', input: text });
    const vector = Array.from({ length: 1536 }, () => Math.random());
    return vector;
}

/**
 * Performs the Upsert (Update or Insert) operation on pgvector.
 * Uses 'ON CONFLICT' to handle the logic atomically.
 * 
 * @param payload - The vector data to sync
 */
async function upsertVector(payload: VectorPayload): Promise<void> {
    const client = await pool.connect();
    
    try {
        const query = `
            INSERT INTO document_vectors (id, embedding, metadata, updated_at)
            VALUES ($1, $2, $3, NOW())
            ON CONFLICT (id) 
            DO UPDATE SET 
                embedding = EXCLUDED.embedding,
                metadata = EXCLUDED.metadata,
                updated_at = NOW();
        `;

        const values = [
            payload.id,
            `[${payload.embedding.join(',')}]`, // pgvector requires array syntax as string for insertion
            JSON.stringify(payload.metadata)
        ];

        await client.query(query, values);
        console.log(`🔄 Upserted vector for ID: ${payload.id} (Active: ${payload.metadata.active})`);

    } catch (error) {
        console.error(`❌ Error upserting vector ${payload.id}:`, error);
    } finally {
        client.release();
    }
}

// --- 4. ORCHESTRATION: THE SYNC PROCESSOR ---

/**
 * Main synchronization function.
 * Compares source state with vector state and applies changes.
 * 
 * @param document - The source document from primary DB
 */
async function processDocumentUpdate(document: SourceDocument): Promise<void> {
    console.log(`\n--- Processing Document: ${document.id} ---`);

    // LOGIC STEP 1: Handle Hard Deletes (Optional)
    // If the source DB has physically deleted the record, we might want to remove it from vectors.
    // However, this script focuses on Soft Deletes (see below).
    
    // LOGIC STEP 2: Determine if we need a new embedding
    // Optimization: Check a hash of the content. If unchanged, skip generation.
    // For this demo, we generate every time to ensure freshness.
    
    let embedding: number[];
    
    if (document.isActive) {
        // Content exists and is active: Generate fresh embedding
        embedding = await generateEmbedding(document.content);
    } else {
        // LOGIC STEP 3: Handling Soft Deletions
        // If the document is marked inactive in the source DB:
        // We keep the vector but update metadata to 'active: false'.
        // This prevents it from appearing in KNN results (if filtered).
        // We can optionally zero out the vector to save space, but keeping it allows re-activation.
        
        // Fetch existing embedding if available (to avoid re-computing for inactive docs)
        // Or generate a zero-vector placeholder.
        embedding = Array(1536).fill(0); 
    }

    // LOGIC STEP 4: Construct Payload
    const payload: VectorPayload = {
        id: document.id,
        embedding: embedding,
        metadata: {
            userId: document.userId,
            active: document.isActive,
            lastSynced: Date.now()
        }
    };

    // LOGIC STEP 5: Execute Upsert
    await upsertVector(payload);
}

// --- 5. SIMULATION & EXECUTION ---

/**
 * Simulates a sequence of database events (Create, Update, Delete).
 * This mimics a webhook receiver in a Next.js API route.
 */
async function runSimulation() {
    await initializeVectorStore();

    // Scenario 1: New Document Created
    const newDoc: SourceDocument = {
        id: '550e8400-e29b-41d4-a716-446655440001',
        content: "The quick brown fox jumps over the lazy dog.",
        userId: 'user_123',
        isActive: true
    };

    // Scenario 2: Existing Document Updated
    const updatedDoc: SourceDocument = {
        id: '550e8400-e29b-41d4-a716-446655440002',
        content: "The lazy dog sleeps in the sun.", // Changed content
        userId: 'user_123',
        isActive: true
    };

    // Scenario 3: Document Soft Deleted
    const deletedDoc: SourceDocument = {
        id: '550e8400-e29b-41d4-a716-446655440003',
        content: "This content is archived.", 
        userId: 'user_123',
        isActive: false // Flagged as inactive in source
    };

    try {
        // Process the batch
        await processDocumentUpdate(newDoc);
        await processDocumentUpdate(updatedDoc);
        await processDocumentUpdate(deletedDoc);

        console.log("\n--- Simulation Complete ---");
        
        // Verify: Query the DB to show current state
        const client = await pool.connect();
        const res = await client.query('SELECT id, metadata FROM document_vectors ORDER BY created_at DESC');
        console.log("\nCurrent Vector DB State:");
        res.rows.forEach(row => {
            console.log(`ID: ${row.id}, Metadata: ${JSON.stringify(row.metadata)}`);
        });
        client.release();

    } catch (error) {
        console.error("Simulation failed:", error);
    } finally {
        await pool.end();
    }
}

// Execute if run directly
if (require.main === module) {
    runSimulation();
}
