/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// File: components/MetadataFilteredSearch.tsx
import { useState, useEffect } from 'react';
import { useChat } from 'ai/react';
import { createClient, SupabaseClient } from '@supabase/supabase-js';

// Initialize Supabase client
const supabase: SupabaseClient = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
);

// Types for Metadata Schema
interface MetadataSchema {
  key: string;
  type: 'enum' | 'string';
  values?: string[]; // For enums
}

interface FilterState {
  [key: string]: string;
}

// Mock function to fetch schema (replace with actual DB call)
const fetchMetadataSchema = async (): Promise<MetadataSchema[]> => {
  // Simulating a DB call to 'document_metadata_schema'
  return [
    { key: 'department', type: 'enum', values: ['Engineering', 'Sales', 'HR'] },
    { key: 'document_type', type: 'enum', values: ['Policy', 'Guide', 'API Doc'] },
    { key: 'author', type: 'string' }
  ];
};

// Function to search with filters
const searchWithFilters = async (query: string, filters: FilterState) => {
  // 1. Generate embedding for the query (using a mock or OpenAI API)
  // In a real app, you'd call OpenAI embeddings API here
  const embeddingResponse = await fetch('/api/embed', { 
    method: 'POST', 
    body: JSON.stringify({ input: query }) 
  });
  const { embedding } = await embeddingResponse.json();

  // 2. Construct pgvector query with metadata filter
  // We assume a Supabase function 'match_documents' exists that accepts a filter JSON
  const { data, error } = await supabase.rpc('match_documents', {
    query_embedding: embedding,
    match_count: 5, // Top-k
    filter: filters // Pass the filter object directly if the DB function supports JSONB
  });

  if (error) {
    console.error("Search error:", error);
    return [];
  }

  return data;
};

export default function MetadataFilteredSearch() {
  const [query, setQuery] = useState('');
  const [filters, setFilters] = useState<FilterState>({});
  const [schema, setSchema] = useState<MetadataSchema[]>([]);
  const [isLoadingSchema, setIsLoadingSchema] = useState(true);
  
  // Vercel AI SDK hook
  const { messages, input, setInput, isLoading, append } = useChat();

  // Fetch schema on mount
  useEffect(() => {
    fetchMetadataSchema().then(setSchema).finally(() => setIsLoadingSchema(false));
  }, []);

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!query.trim()) return;

    // 1. Perform Vector Search with Filters
    const documents = await searchWithFilters(query, filters);
    
    // 2. Construct System Prompt with Context
    const context = documents.map((doc: any) => doc.content).join('\n\n');
    const systemPrompt = `You are a helpful assistant. Answer the question based on the following context:\n\n${context}`;

    // 3. Send to AI
    append({
      role: 'user',
      content: query,
      // Note: Vercel AI SDK handles system prompts differently depending on the provider.
      // For OpenAI, we might construct a message array manually or use the 'api' prop.
      // Here we simulate passing context by prepending it to the user message or using a custom API route.
      // For simplicity in this example, we assume the API route handles the context injection.
    });
    
    setQuery(''); // Clear input
  };

  const handleFilterChange = (key: string, value: string) => {
    setFilters(prev => ({ ...prev, [key]: value }));
  };

  if (isLoadingSchema) return <div>Loading filters...</div>;

  return (
    <div className="flex flex-col h-screen max-w-4xl mx-auto p-4">
      <div className="mb-4 p-4 border rounded bg-gray-50">
        <h2 className="font-bold mb-2">Filter Search</h2>
        <div className="flex gap-4 flex-wrap">
          {schema.map((field) => (
            <div key={field.key} className="flex flex-col">
              <label className="text-sm font-semibold">{field.key}</label>
              {field.type === 'enum' ? (
                <select 
                  onChange={(e) => handleFilterChange(field.key, e.target.value)}
                  className="border p-1 rounded"
                >
                  <option value="">All</option>
                  {field.values?.map(v => <option key={v} value={v}>{v}</option>)}
                </select>
              ) : (
                <input 
                  type="text" 
                  placeholder={`Filter by ${field.key}`}
                  onChange={(e) => handleFilterChange(field.key, e.target.value)}
                  className="border p-1 rounded"
                />
              )}
            </div>
          ))}
        </div>
      </div>

      <div className="flex-1 overflow-y-auto border rounded p-4 mb-4 bg-white">
        {messages.map(m => (
          <div key={m.id} className={`mb-2 ${m.role === 'user' ? 'text-blue-600' : 'text-gray-800'}`}>
            <strong>{m.role === 'user' ? 'You: ' : 'AI: '}</strong>
            {m.content}
          </div>
        ))}
      </div>

      <form onSubmit={handleSearch} className="flex gap-2">
        <input
          className="flex-1 border p-2 rounded"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Ask a question..."
        />
        <button 
          type="submit" 
          disabled={isLoading}
          className="bg-blue-500 text-white px-4 py-2 rounded disabled:bg-gray-300"
        >
          {isLoading ? 'Thinking...' : 'Send'}
        </button>
      </form>
    </div>
  );
}
