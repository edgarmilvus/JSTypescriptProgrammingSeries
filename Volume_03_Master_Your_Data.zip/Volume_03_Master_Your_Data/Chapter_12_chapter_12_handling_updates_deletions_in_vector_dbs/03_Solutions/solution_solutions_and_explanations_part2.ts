/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

// File: utils/db.ts (Database Logic)
import { createClient } from '@supabase/supabase-js';

const supabase = createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!);

// 1. Soft Delete Function
export const softDeleteDocument = async (id: string) => {
  const { error } = await supabase
    .from('documents')
    .update({ is_active: false, deleted_at: new Date().toISOString() })
    .eq('id', id);

  if (error) throw new Error(`Failed to soft delete: ${error.message}`);
  return true;
};

// 2. Restore Function
export const restoreDocument = async (id: string) => {
  const { error } = await supabase
    .from('documents')
    .update({ is_active: true, deleted_at: null })
    .eq('id', id);

  if (error) throw new Error(`Failed to restore: ${error.message}`);
  return true;
};

// 3. Hard Purge Function (for docs deleted > 30 days ago)
export const purgeOldDocuments = async () => {
  const thirtyDaysAgo = new Date();
  thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);

  const { error } = await supabase
    .from('documents')
    .delete()
    .lt('deleted_at', thirtyDaysAgo.toISOString())
    .eq('is_active', false); // Ensure they are already soft deleted

  if (error) throw new Error(`Failed to purge: ${error.message}`);
  return true;
};

// 4. Modified Search Function (Must filter is_active = true)
export const searchDocuments = async (embedding: number[]) => {
  const { data, error } = await supabase.rpc('match_documents', {
    query_embedding: embedding,
    match_count: 5,
    // Assuming the DB function supports a filter object or we modify the SQL directly
    // If the DB function is raw SQL, ensure it has: WHERE is_active = true
    filter: {} 
  });

  if (error) throw error;
  return data;
};

// File: components/DocumentManager.tsx
import { useState, useEffect } from 'react';
import { softDeleteDocument, restoreDocument, purgeOldDocuments } from '../utils/db';

export default function DocumentManager() {
  const [docs, setDocs] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);

  const fetchDocs = async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from('documents')
      .select('id, content, is_active, deleted_at')
      .order('created_at', { ascending: false });
    
    if (!error && data) setDocs(data);
    setLoading(false);
  };

  useEffect(() => { fetchDocs(); }, []);

  const handleDelete = async (id: string) => {
    try {
      await softDeleteDocument(id);
      alert('Document soft deleted.');
      fetchDocs(); // Refresh list
    } catch (err: any) {
      alert(err.message);
    }
  };

  const handleRestore = async (id: string) => {
    try {
      await restoreDocument(id);
      alert('Document restored.');
      fetchDocs();
    } catch (err: any) {
      alert(err.message);
    }
  };

  const handlePurge = async () => {
    if (!confirm("Permanently delete documents older than 30 days?")) return;
    try {
      await purgeOldDocuments();
      alert('Purge complete.');
      fetchDocs();
    } catch (err: any) {
      alert(err.message);
    }
  };

  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-4">
        <h1 className="text-2xl font-bold">Document Manager</h1>
        <button onClick={handlePurge} className="bg-red-600 text-white px-4 py-2 rounded">
          Purge Old Deleted Docs
        </button>
      </div>

      {loading ? <p>Loading...</p> : (
        <table className="w-full border-collapse border">
          <thead>
            <tr className="bg-gray-100">
              <th className="border p-2">ID</th>
              <th className="border p-2">Content Preview</th>
              <th className="border p-2">Status</th>
              <th className="border p-2">Actions</th>
            </tr>
          </thead>
          <tbody>
            {docs.map(doc => (
              <tr key={doc.id} className={doc.is_active ? '' : 'bg-red-50'}>
                <td className="border p-2 text-sm">{doc.id}</td>
                <td className="border p-2">{doc.content.substring(0, 50)}...</td>
                <td className="border p-2 text-center">
                  {doc.is_active ? 'Active' : <span className="text-red-600">Deleted</span>}
                </td>
                <td className="border p-2">
                  {doc.is_active ? (
                    <button onClick={() => handleDelete(doc.id)} className="bg-orange-500 text-white px-2 py-1 rounded text-sm">
                      Delete
                    </button>
                  ) : (
                    <button onClick={() => handleRestore(doc.id)} className="bg-green-500 text-white px-2 py-1 rounded text-sm">
                      Restore
                    </button>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}
