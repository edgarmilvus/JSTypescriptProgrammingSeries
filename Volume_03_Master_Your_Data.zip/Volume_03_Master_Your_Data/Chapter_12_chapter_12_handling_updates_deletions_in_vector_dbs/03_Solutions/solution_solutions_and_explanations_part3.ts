/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

// File: scripts/batchReindex.ts

// 1. Define Types
interface Document {
  id: string;
  content: string;
  last_modified: string;
}

interface ChangeDetectionResult {
  newDocs: Document[];
  updatedDocs: Document[];
  deletedIds: string[];
}

// 2. Change Detection Logic
function detectChanges(
  currentDocs: Document[],
  newDocs: Document[]
): ChangeDetectionResult {
  const currentMap = new Map(currentDocs.map(d => [d.id, d]));
  const newMap = new Map(newDocs.map(d => [d.id, d]));

  const newDocsResult: Document[] = [];
  const updatedDocsResult: Document[] = [];
  const deletedIds: string[] = [];

  // Check for new and updated
  for (const [id, newDoc] of newMap) {
    const currentDoc = currentMap.get(id);
    if (!currentDoc) {
      newDocsResult.push(newDoc);
    } else if (
      currentDoc.content !== newDoc.content || 
      currentDoc.last_modified !== newDoc.last_modified
    ) {
      updatedDocsResult.push(newDoc);
    }
  }

  // Check for deleted
  for (const [id] of currentMap) {
    if (!newMap.has(id)) {
      deletedIds.push(id);
    }
  }

  return { newDocs: newDocsResult, updatedDocs: updatedDocsResult, deletedIds };
}

// 3. Mock Embedding Generator
function generateMockEmbedding(): number[] {
  return Array.from({ length: 1536 }, () => Math.random());
}

// 4. Batch Update/Upsert Function
async function batchUpdateVectors(docs: Document[]) {
  if (docs.length === 0) return;

  console.log(`Upserting ${docs.length} documents...`);
  
  // Prepare data for Supabase bulk upsert
  const payload = docs.map(doc => ({
    id: doc.id,
    content: doc.content,
    embedding: generateMockEmbedding(),
    last_modified: doc.last_modified
  }));

  // Simulate Supabase Upsert
  // const { error } = await supabase.from('documents').upsert(payload);
  console.log('Batch Upsert Complete (Simulated)');
}

// 5. Batch Deletion Function
async function batchDeleteDocuments(ids: string[]) {
  if (ids.length === 0) return;

  console.log(`Deleting ${ids.length} documents...`);
  
  // Simulate Supabase Delete
  // const { error } = await supabase.from('documents').delete().in('id', ids);
  console.log('Batch Delete Complete (Simulated)');
}

// 6. Simulation Runner
async function runSimulation() {
  // Mock Data
  const currentDocs: Document[] = [
    { id: '1', content: 'Old content A', last_modified: '2023-01-01' },
    { id: '2', content: 'Content B (unchanged)', last_modified: '2023-01-01' },
    { id: '3', content: 'Content C (to be deleted)', last_modified: '2023-01-01' },
  ];

  const newDocs: Document[] = [
    { id: '1', content: 'Updated content A', last_modified: '2023-10-27' }, // Updated
    { id: '2', content: 'Content B (unchanged)', last_modified: '2023-01-01' }, // Unchanged
    { id: '4', content: 'New content D', last_modified: '2023-10-27' }, // New
    // ID '3' is missing -> Deleted
  ];

  console.log('--- Starting Change Detection ---');
  const changes = detectChanges(currentDocs, newDocs);
  console.log('Changes Detected:', changes);

  console.log('\n--- Processing Updates ---');
  await batchUpdateVectors([...changes.newDocs, ...changes.updatedDocs]);

  console.log('\n--- Processing Deletions ---');
  await batchDeleteDocuments(changes.deletedIds);

  console.log('\n--- Workflow Complete ---');
}

runSimulation();
