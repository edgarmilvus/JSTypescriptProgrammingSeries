/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

digraph RAG_Update_Pipeline {
    rankdir=TB;
    node [fontname="Arial", shape=box, style="rounded,filled", fillcolor="#E3F2FD"];
    edge [fontname="Arial", fontsize=10];

    // --- Nodes ---
    
    // Source & Detection
    Source [label="Source File\n(Git/FileSystem)", fillcolor="#FFF3E0"];
    Watcher [label="Change Detector\n(Hash/Timestamp)", fillcolor="#FFF9C4"];
    Queue [label="Message Queue\n(BullMQ)", shape="cylinder", fillcolor="#F3E5F5"];
    
    // Processing
    Worker [label="Background Worker", fillcolor="#E8F5E9"];
    Embedder [label="Embedding Model\n(LLM API)", fillcolor="#E0F7FA"];
    
    // DB Operations
    DB_Transaction [label="Database Transaction", shape="component", fillcolor="#FFEBEE"];
    Doc_Table [label="documents\n(Upsert)", shape="note", fillcolor="#FFFFFF"];
    Chunk_Table [label="document_chunks\n(Upsert)", shape="note", fillcolor="#FFFFFF"];
    Version_Table [label="document_versions\n(Insert Old Version)", shape="note", fillcolor="#FFFFFF"];
    
    // Finalization
    Cache [label="Cache Invalidation\n(Redis)", shape="cylinder", fillcolor="#F3E5F5"];
    Success [label="Pipeline Complete\n(Ready for Search)", fillcolor="#C8E6C9", shape="ellipse"];
    
    // Error Handling
    Error [label="Error Detected", fillcolor="#FFCDD2", shape="octagon"];
    Rollback [label="Rollback Action\n(Revert Version)", fillcolor="#FFEBEE"];
    Alert [label="Alert Admin\n(Slack/Email)", fillcolor="#FFEBEE"];

    // --- Edges (Success Path) ---
    Source -> Watcher [label="1. File Modified"];
    Watcher -> Queue [label="2. Enqueue Job\n(Resilient Buffer)"];
    Queue -> Worker [label="3. Worker Consumes Job"];
    Worker -> Embedder [label="4. Generate Embeddings"];
    
    // Database Transaction Subgraph
    subgraph cluster_db {
        label="Database Operations";
        style="dashed";
        node [fillcolor="#FFFFFF"];
        
        Embedder -> DB_Transaction [style="invis"]; // Invisible guide
        Embedder -> Version_Table [label="5a. Archive Old Version", constraint=false];
        Embedder -> Doc_Table [label="5b. Update Main Doc"];
        Embedder -> Chunk_Table [label="5c. Update Chunks"];
        
        // Ensure DB nodes are grouped visually
        { rank=same; Version_Table; Doc_Table; Chunk_Table; }
    }

    Doc_Table -> Cache [label="6. Invalidate Cache Keys"];
    Cache -> Success [label="7. Update Complete"];

    // --- Edges (Error Path) ---
    Worker -> Error [label="Failure", style="dashed", color="red"];
    Error -> Rollback [label="Trigger Rollback", style="dashed", color="red"];
    Error -> Alert [label="Notify", style="dashed", color="red"];
    
    Rollback -> Version_Table [label="Restore Previous State", style="dashed", color="red"];
    Version_Table -> Success [label="Recovery Complete", style="dashed", color="red"];

    // --- Annotations/Comments ---
    // Why Queue? -> Decouples source trigger from processing, allowing retries.
    // Why Transaction? -> Ensures atomicity: either all chunks update or none do.
    // Why Versioning? -> Allows point-in-time recovery and rollback.
}
