/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * @fileoverview Basic In-Memory Session Management for a Chat Application
 * 
 * This TypeScript file demonstrates how to maintain conversation state
 * across multiple HTTP requests using a simple in-memory store.
 * 
 * Dependencies:
 * - express: Web server framework
 * - uuid: For generating unique session IDs
 * - zod: For validating JSON schema output (simulated)
 * 
 * Run this file with: npx ts-node server.ts
 */

import express, { Request, Response } from 'express';
import { v4 as uuidv4 } from 'uuid';

// ============================================================================
// 1. TYPE DEFINITIONS & INTERFACES
// ============================================================================

/**
 * Represents a single message in the chat history.
 * @typedef {object} ChatMessage
 * @property {string} role - 'user' or 'ai'
 * @property {string} content - The text content of the message
 */
interface ChatMessage {
  role: 'user' | 'ai';
  content: string;
}

/**
 * Represents a session's data stored in memory.
 * @typedef {object} SessionData
 * @property {ChatMessage[]} history - The array of messages for this session
 */
interface SessionData {
  history: ChatMessage[];
}

/**
 * The global in-memory store for sessions.
 * Key: Session ID (string), Value: SessionData
 * 
 * NOTE: In a production environment, this would be a Redis cache or a database.
 * Using a simple JS Map here for the "Hello World" demonstration.
 */
const sessionStore = new Map<string, SessionData>();

// ============================================================================
// 2. SERVER SETUP
// ============================================================================

const app = express();
const PORT = 3000;

// Middleware to parse JSON bodies
app.use(express.json());

// ============================================================================
// 3. API ENDPOINTS
// ============================================================================

/**
 * POST /chat
 * 
 * Handles the chat interaction.
 * 
 * Request Body:
 * {
 *   "sessionId": string | null, // If null, a new session is created
 *   "message": string           // The user's input
 * }
 * 
 * Response Body:
 * {
 *   "sessionId": string,
 *   "response": string,         // The AI's simulated response
 *   "history": ChatMessage[]    // The full updated history
 * }
 */
app.post('/chat', (req: Request, res: Response) => {
  const { sessionId, message } = req.body;

  // --- Input Validation (Simulated) ---
  if (!message || typeof message !== 'string') {
    return res.status(400).json({ error: 'Invalid message format' });
  }

  // --- Session Management ---
  let currentSessionId = sessionId;
  let sessionData: SessionData;

  if (!currentSessionId) {
    // Create a new session if no ID is provided
    currentSessionId = uuidv4();
    sessionData = { history: [] };
    console.log(`Created new session: ${currentSessionId}`);
  } else {
    // Retrieve existing session
    const existingSession = sessionStore.get(currentSessionId);
    if (!existingSession) {
      return res.status(404).json({ error: 'Session not found' });
    }
    sessionData = existingSession;
  }

  // --- Memory Retrieval (Short-Term Memory) ---
  // We retrieve the current history. In a real RAG app, this is where
  // we might also query a vector store for long-term memory.
  const currentHistory = sessionData.history;
  console.log(`Retrieved history for ${currentSessionId}:`, currentHistory);

  // --- Append User Message ---
  const userMessage: ChatMessage = {
    role: 'user',
    content: message
  };
  currentHistory.push(userMessage);

  // --- AI Interaction (Simulated) ---
  // In a real app, we would call an LLM here, passing the 'currentHistory'.
  // We simulate the LLM's JSON Schema output capability by generating
  // a structured response string.
  const simulatedAiResponse = `I understand you said: "${message}". This is session ${currentSessionId}.`;
  
  const aiMessage: ChatMessage = {
    role: 'ai',
    content: simulatedAiResponse
  };

  // --- Append AI Response to Memory ---
  currentHistory.push(aiMessage);

  // --- Update State ---
  // Update the store with the new history
  sessionStore.set(currentSessionId, { history: currentHistory });

  // --- Send Response ---
  // We return the session ID (crucial for the client to persist it)
  // and the AI's response.
  res.json({
    sessionId: currentSessionId,
    response: simulatedAiResponse,
    history: currentHistory // Optional: useful for debugging or UI syncing
  });
});

// ============================================================================
// 4. SERVER EXECUTION
// ============================================================================

app.listen(PORT, () => {
  console.log(`Memory & Sessions server running on http://localhost:${PORT}`);
  console.log('Send a POST request to /chat with { "message": "Hello" }');
});
