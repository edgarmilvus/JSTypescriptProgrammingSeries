/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// pages/api/chat.ts
// Next.js API Route for handling persistent document chat sessions.
import type { NextApiRequest, NextApiResponse } from 'next';
import { ChatOpenAI } from '@langchain/openai';
import { ChatMessageHistory } from 'langchain/memory';
import { pgvectorStore } from '../../lib/pgvector-store'; // Assumed initialized pgvector instance
import { RetrievalQAChain } from 'langchain/chains';
import { PromptTemplate } from '@langchain/core/prompts';

// -----------------------------------------------------------------------------
// 1. SESSION MANAGEMENT & STATE PERSISTENCE
// -----------------------------------------------------------------------------
// In a production SaaS, this would be backed by Redis or a SQL database.
// We use a global singleton to persist memory across hot-reloads in dev.
// This acts as our "Short-Term Memory" store for active sessions.

type SessionMemory = {
    history: ChatMessageHistory;
    lastAccessed: Date;
};

const SESSION_STORE = new Map<string, SessionMemory>();

/**
 * Retrieves or initializes a session history.
 * Prunes old sessions to manage memory usage (Headless Inference constraint).
 * @param sessionId - Unique identifier for the user session.
 */
function getSessionHistory(sessionId: string): ChatMessageHistory {
    const now = new Date();
    
    // Cleanup: Remove sessions inactive for > 1 hour
    for (const [key, value] of SESSION_STORE.entries()) {
        const ageInMs = now.getTime() - value.lastAccessed.getTime();
        if (ageInMs > 3600000) {
            SESSION_STORE.delete(key);
        }
    }

    if (!SESSION_STORE.has(sessionId)) {
        SESSION_STORE.set(sessionId, {
            history: new ChatMessageHistory(),
            lastAccessed: now
        });
    }

    // Update access time
    const session = SESSION_STORE.get(sessionId)!;
    session.lastAccessed = now;
    
    return session.history;
}

// -----------------------------------------------------------------------------
// 2. CHAIN SETUP & MEMORY INTEGRATION
// -----------------------------------------------------------------------------
// We define the LLM and the Prompt Template here. 
// The prompt incorporates the 'chat_history' variable required by LangChain's
// conversational retrieval chain.

const model = new ChatOpenAI({
    modelName: 'gpt-4-turbo-preview',
    temperature: 0.7,
    streaming: true // Enable streaming for better UX
});

const QA_PROMPT = PromptTemplate.fromTemplate(
    `You are an AI assistant for a SaaS platform. Use the following context and conversation history to answer the user's question.
    
    Context: {context}
    
    Chat History: {chat_history}
    
    Question: {question}
    
    Answer in a helpful, concise manner. If the context doesn't contain the answer, say so.`
);

/**
 * Core Logic: Process the chat request.
 * 1. Extract Session ID and Message.
 * 2. Retrieve Long-Term Memory (Relevant document chunks).
 * 3. Retrieve Short-Term Memory (Previous messages).
 * 4. Construct LLM Prompt with both memories.
 * 5. Stream response back to client.
 */
export default async function handler(req: NextApiRequest, res: NextApiResponse) {
    if (req.method !== 'POST') {
        return res.status(405).json({ error: 'Method not allowed' });
    }

    const { message, sessionId } = req.body;

    if (!message || !sessionId) {
        return res.status(400).json({ error: 'Missing message or sessionId' });
    }

    try {
        // A. Initialize Session Memory (Short-Term)
        const history = getSessionHistory(sessionId);

        // B. Perform Long-Term Memory Retrieval (Vector Search)
        // We use the user's current message to find relevant documents.
        // In a real scenario, we might also embed the chat history for better context.
        const vectorStore = await pgvectorStore; // Ensure initialization
        const retriever = vectorStore.asRetriever({ k: 3 }); // Retrieve top 3 chunks
        
        // Note: In LangChain, RetrievalQAChain handles the retrieval + LLM call internally.
        // However, for explicit memory control, we can construct the context manually or use specific chains.
        // Here, we use RetrievalQAChain with 'stuff' chain type for simplicity in this script.
        
        const chain = RetrievalQAChain.fromLLM(model, retriever, {
            prompt: QA_PROMPT,
            returnSourceDocuments: true, // Useful for debugging/verification
        });

        // C. Execute the Chain
        // We pass the raw question. The chain handles retrieval and injection.
        // To inject chat history manually into the prompt, we would need a custom chain,
        // but RetrievalQAChain expects { query: string }.
        // For strict adherence to "Memory & Sessions", we will simulate the custom prompt injection
        // by using the `qaChain` but ensuring the prompt template includes `{chat_history}`.
        // *Correction*: Standard RetrievalQAChain doesn't pass `chat_history` by default.
        // We will switch to a `ConversationalRetrievalQAChain` logic manually or use the prompt injection.
        
        // Let's use the prompt injection approach for clarity in this specific script:
        // 1. Get History String
        const historyString = await history.getMessages()
            .then(msgs => msgs.map(m => `${m._getType()}: ${m.content}`).join('\n'));
        
        // 2. Retrieve Context
        const docs = await retriever.getRelevantDocuments(message);
        const context = docs.map(d => d.pageContent).join('\n\n');

        // 3. Format Prompt
        const formattedPrompt = await QA_PROMPT.format({
            context: context,
            chat_history: historyString,
            question: message
        });

        // 4. Call LLM (Streaming)
        res.setHeader('Content-Type', 'text/event-stream');
        res.setHeader('Cache-Control', 'no-cache');
        res.setHeader('Connection', 'keep-alive');

        const stream = await model.stream(formattedPrompt);
        
        let fullResponse = "";
        
        // Stream chunks to client
        for await (const chunk of stream) {
            const content = chunk.content || "";
            fullResponse += content;
            res.write(`data: ${JSON.stringify({ token: content })}\n\n`);
        }

        // D. Update Memory (Short-Term)
        // Save the interaction to the session store
        await history.addUserMessage(message);
        await history.addAIChatMessage(fullResponse);

        res.write('data: [DONE]\n\n');
        res.end();

    } catch (error) {
        console.error("Chat Error:", error);
        res.status(500).json({ error: 'Internal Server Error' });
    }
}
