/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

/**
 * A strictly typed FIFO buffer for managing conversation history.
 * @template T - The type of the messages stored in the buffer.
 */
class ConversationBuffer<T> {
    private messages: T[];
    private readonly maxSize: number;

    /**
     * Initializes the buffer with a maximum size.
     * @param maxSize - The maximum number of messages to keep.
     */
    constructor(maxSize: number) {
        if (maxSize <= 0) {
            throw new Error("maxSize must be a positive integer.");
        }
        this.maxSize = maxSize;
        this.messages = [];
    }

    /**
     * Adds a message to the buffer. If the buffer exceeds maxSize,
     * the oldest message is removed.
     * @param message - The message of type T to add.
     */
    addMessage(message: T): void {
        this.messages.push(message);
        // Enforce FIFO behavior
        if (this.messages.length > this.maxSize) {
            this.messages.shift(); 
        }
    }

    /**
     * Retrieves all messages currently in the buffer.
     * @returns A copy of the array of messages.
     */
    getMessages(): T[] {
        // Return a copy to prevent external mutation
        return [...this.messages];
    }

    /**
     * Empties the buffer.
     */
    clear(): void {
        this.messages = [];
    }
}

// Example Usage with a specific message type
interface ChatMessage {
    role: 'user' | 'assistant';
    content: string;
}

// Initialize buffer with size 3
const buffer = new ConversationBuffer<ChatMessage>(3);

// Add messages
buffer.addMessage({ role: 'user', content: 'Hello' });
buffer.addMessage({ role: 'assistant', content: 'Hi there!' });
buffer.addMessage({ role: 'user', content: 'How does memory work?' });

// This message will cause the oldest ('Hello') to be removed
buffer.addMessage({ role: 'assistant', content: 'It works via buffers and vectors.' });

// Retrieve messages
const currentHistory = buffer.getMessages();
console.log(currentHistory); 
// Output: 
// [
//   { role: 'assistant', content: 'Hi there!' },
//   { role: 'user', content: 'How does memory work?' },
//   { role: 'assistant', content: 'It works via buffers and vectors.' }
// ]

// Type Safety Check (Uncommenting the line below would cause a TS compilation error)
// buffer.addMessage({ content: 'Missing role property' }); 
