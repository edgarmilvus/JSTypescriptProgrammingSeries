/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState, useEffect } from 'react';

// Define a generic interface for the hook's return type
type PersistentStateHook<T> = [T, React.Dispatch<React.SetStateAction<T>>];

/**
 * A custom hook that persists state to localStorage.
 * @param key - The localStorage key.
 * @param initialValue - The initial state value.
 */
function usePersistentSession<T>(key: string, initialValue: T): PersistentStateHook<T> {
    // State to store the value
    const [state, setState] = useState<T>(() => {
        try {
            const item = window.localStorage.getItem(key);
            // Parse the stored json or return initial value if null/invalid
            return item ? JSON.parse(item) : initialValue;
        } catch (error) {
            console.error(`Error reading localStorage key "${key}":`, error);
            return initialValue;
        }
    });

    // Effect to persist state to localStorage whenever it changes
    useEffect(() => {
        try {
            window.localStorage.setItem(key, JSON.stringify(state));
        } catch (error) {
            // Handle QuotaExceededError or other write errors
            if (error instanceof Error && error.name === 'QuotaExceededError') {
                console.warn('Storage quota exceeded. Cannot save session.');
                // Optional: Notify user or clear old data
            } else {
                console.error(`Error saving to localStorage key "${key}":`, error);
            }
        }
    }, [key, state]);

    return [state, setState];
}

// Component Integration
interface Message {
    id: number;
    text: string;
    sender: 'user' | 'bot';
}

const ChatSessionManager: React.FC = () => {
    const [messages, setMessages] = usePersistentSession<Message[]>('chat_session', []);

    const addDummyMessage = () => {
        const newMessage: Message = {
            id: Date.now(),
            text: `Message at ${new Date().toLocaleTimeString()}`,
            sender: 'user'
        };
        setMessages(prev => [...prev, newMessage]);
    };

    const clearSession = () => {
        setMessages([]);
        localStorage.removeItem('chat_session');
    };

    return (
        <div style={{ padding: '20px', fontFamily: 'sans-serif' }}>
            <h3>Chat Session Persistence</h3>
            <div style={{ border: '1px solid #ccc', padding: '10px', minHeight: '150px', marginBottom: '10px' }}>
                {messages.length === 0 ? (
                    <p style={{ color: '#666' }}>No messages yet. Add one!</p>
                ) : (
                    <ul>
                        {messages.map(msg => (
                            <li key={msg.id}>
                                <strong>{msg.sender}:</strong> {msg.text}
                            </li>
                        ))}
                    </ul>
                )}
            </div>
            <button onClick={addDummyMessage} style={{ marginRight: '10px' }}>
                Add Dummy Message
            </button>
            <button onClick={clearSession} style={{ backgroundColor: '#ffcccc' }}>
                Clear Session
            </button>
        </div>
    );
};

export default ChatSessionManager;
