/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

interface MemoryItem {
    id: string;
    content: string;
    embedding: number[];
}

// Mock data: A small vector store of past conversation summaries
const vectorStore: MemoryItem[] = [
    {
        id: "doc_1",
        content: "The capital of France is Paris. It is known for the Eiffel Tower.",
        embedding: [0.1, 0.2, 0.3, 0.4] // Simplified 4D vector for demo
    },
    {
        id: "doc_2",
        content: "Photosynthesis is the process used by plants to convert light energy into chemical energy.",
        embedding: [0.5, 0.6, 0.7, 0.8]
    },
    {
        id: "doc_3",
        content: "Paris is located in the north-central part of France along the Seine River.",
        embedding: [0.12, 0.19, 0.28, 0.41] // Similar to doc_1
    }
];

/**
 * Calculates the cosine similarity between two vectors.
 * Formula: (A . B) / (||A|| * ||B||)
 */
function cosineSimilarity(vecA: number[], vecB: number[]): number {
    if (vecA.length !== vecB.length) {
        throw new Error("Vectors must be of the same dimension");
    }

    let dotProduct = 0;
    let normA = 0;
    let normB = 0;

    for (let i = 0; i < vecA.length; i++) {
        dotProduct += vecA[i] * vecB[i];
        normA += vecA[i] * vecA[i];
        normB += vecB[i] * vecB[i];
    }

    if (normA === 0 || normB === 0) {
        return 0; // Handle zero vectors
    }

    return dotProduct / (Math.sqrt(normA) * Math.sqrt(normB));
}

/**
 * Retrieves top N relevant context strings from the vector store.
 */
async function retrieveLongTermMemory(queryEmbedding: number[], limit: number = 2): Promise<string[]> {
    // Calculate similarity scores for all items
    const scoredItems = vectorStore.map(item => {
        const score = cosineSimilarity(queryEmbedding, item.embedding);
        return {
            content: item.content,
            score: score
        };
    });

    // Sort by score descending
    scoredItems.sort((a, b) => b.score - a.score);

    // Return top N content strings
    return scoredItems.slice(0, limit).map(item => item.content);
}

// Example Usage
const mockQueryEmbedding = [0.1, 0.2, 0.3, 0.4]; // Intentionally matches doc_1 closely

retrieveLongTermMemory(mockQueryEmbedding, 2).then(results => {
    console.log("Retrieved Context:");
    results.forEach(r => console.log(`- ${r}`));
});
