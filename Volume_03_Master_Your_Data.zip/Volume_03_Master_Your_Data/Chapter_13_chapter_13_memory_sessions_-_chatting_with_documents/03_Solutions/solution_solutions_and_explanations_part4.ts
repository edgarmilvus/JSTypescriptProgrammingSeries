/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

// Reusing types and classes from previous exercises
interface ChatMessage {
    role: 'user' | 'assistant';
    content: string;
}

class ConversationBuffer<T> {
    private messages: T[] = [];
    constructor(private maxSize: number) {}
    addMessage(message: T): void {
        this.messages.push(message);
        if (this.messages.length > this.maxSize) this.messages.shift();
    }
    getMessages(): T[] { return [...this.messages]; }
}

// Mock Vector Store (Simplified for this context)
const mockVectorStore = [
    { content: "System memory is managed via RAM.", embedding: [0.9, 0.1, 0.5] },
    { content: "Session cookies store user state on the client.", embedding: [0.8, 0.2, 0.4] }
];

function generateMockEmbedding(text: string): number[] {
    // In a real app, this calls an embedding API. 
    // Here we return a fixed vector based on text length for variety.
    const len = text.length % 10; 
    return [len * 0.1, len * 0.2, len * 0.3]; 
}

// Simplified retrieval logic for the exercise
function simpleRetrieve(queryEmbedding: number[]): string[] {
    // Just returning the first item for simplicity in this mock
    // In reality, we would calculate cosine similarity here
    return [mockVectorStore[0].content]; 
}

async function chatWithDocuments<T extends { role: string; content: string }>(
    userQuery: string,
    historyBuffer: ConversationBuffer<T>
): Promise<string> {
    
    // 1. Check for Greeting (Short-circuit logic)
    const isGreeting = /^(hi|hello|hey)\b/i.test(userQuery);
    const isHistoryEmpty = historyBuffer.getMessages().length === 0;

    if (isHistoryEmpty && isGreeting) {
        return "Hello! How can I assist you with your documents today?";
    }

    // 2. Vector Retrieval (Long-Term Memory)
    const queryEmbedding = generateMockEmbedding(userQuery);
    const relevantContext = simpleRetrieve(queryEmbedding);

    // 3. Retrieve Short-Term Memory
    const history = historyBuffer.getMessages();
    const historyText = history.map(m => `${m.role}: ${m.content}`).join('\n');

    // 4. Prompt Construction
    const prompt = `
[Context]
${relevantContext.join('\n')}

[Recent Conversation History]
${historyText || 'No previous history.'}

[Current Question]
${userQuery}

Please provide an answer based on the context and history.
    `.trim();

    return prompt;
}

// --- Test Run ---
const buffer = new ConversationBuffer<ChatMessage>(3);
buffer.addMessage({ role: 'user', content: 'Tell me about system memory.' });
buffer.addMessage({ role: 'assistant', content: 'System memory refers to RAM.' });

// Test 1: Greeting (Empty Buffer Scenario)
const emptyBuffer = new ConversationBuffer<ChatMessage>(3);
chatWithDocuments("Hello", emptyBuffer).then(console.log);

// Test 2: Context Retrieval Scenario
chatWithDocuments("What about cookies?", buffer).then(console.log);
