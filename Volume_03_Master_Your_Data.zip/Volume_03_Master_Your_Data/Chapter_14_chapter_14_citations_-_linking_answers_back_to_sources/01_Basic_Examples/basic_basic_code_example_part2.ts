/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.ts
// Description: Basic Code Example
// ==========================================

/**
 * ============================================================================
 * 1. TYPE DEFINITIONS
 * ============================================================================
 */

// The structure of the raw data stored in our vector database.
type VectorChunk = {
  id: string;
  content: string;
  metadata: { source: string; page: number };
};

// The structured output we expect from the LLM to ensure citations are handled.
// We instruct the LLM to output JSON matching this interface.
interface LLMStructuredResponse {
  answer: string; // The natural language response
  citations: string[]; // Array of IDs referencing the SourceChunk.id
}

/**
 * ============================================================================
 * 2. MOCK SERVICES (Simulating Vector DB & LLM)
 * ============================================================================
 */

// Mock Vector Database Retrieval
function mockVectorSearch(query: string): VectorChunk[] {
  // In a real app, this queries Pinecone, Weaviate, or Qdrant.
  return [
    {
      id: "chunk_001",
      content: "The sky is blue because of Rayleigh scattering.",
      metadata: { source: "science_manual.pdf", page: 1 },
    },
    {
      id: "chunk_002",
      content: "Photosynthesis requires sunlight, water, and carbon dioxide.",
      metadata: { source: "biology_101.pdf", page: 42 },
    },
  ];
}

// Mock LLM Inference with Citation Generation
async function mockLLMInference(
  query: string,
  context: VectorChunk[]
): Promise<LLMStructuredResponse> {
  // Simulate network delay
  await new Promise((r) => setTimeout(r, 100));

  // In a real scenario, you would send a prompt like:
  // "Answer the question based ONLY on the context below.
  //  Output JSON: { answer: string, citations: string[] }"
  
  // Here, we mock the LLM correctly identifying that the answer 
  // comes from chunk_001.
  return {
    answer: "The sky appears blue due to a phenomenon called Rayleigh scattering.",
    citations: ["chunk_001"], 
  };
}

/**
 * ============================================================================
 * 3. CORE LOGIC: RECONCILING DATA WITH CITATIONS
 * ============================================================================
 */

/**
 * Fetches data, generates an answer, and hydrates the response with source links.
 * This mimics a Next.js Server Action or API Route handler.
 */
async function generateCitedAnswer(userQuery: string) {
  // Step 1: Retrieve relevant chunks from Vector DB
  const retrievedChunks = mockVectorSearch(userQuery);

  // Step 2: Send query + context to LLM to get structured answer + citation IDs
  const llmResponse = await mockLLMInference(userQuery, retrievedChunks);

  // Step 3: Reconciliation (The Citation Step)
  // We map the citation IDs from the LLM back to the full metadata 
  // of the retrieved chunks.
  const sources = llmResponse.citations.map((id) => {
    const foundChunk = retrievedChunks.find((c) => c.id === id);
    
    if (!foundChunk) {
      // This happens if the LLM hallucinates an ID that wasn't retrieved.
      console.warn(`Hallucinated citation ID: ${id}`);
      return null;
    }
    
    return {
      id: foundChunk.id,
      sourceName: foundChunk.metadata.source,
      page: foundChunk.metadata.page,
    };
  }).filter(Boolean); // Remove nulls

  // Step 4: Return the fully hydrated object to the frontend
  return {
    answer: llmResponse.answer,
    sources: sources,
  };
}

/**
 * ============================================================================
 * 4. FRONTEND RENDERING (React Component Simulation)
 * ============================================================================
 */

// Simulating a React Component rendering the result
function renderUI(result: Awaited<ReturnType<typeof generateCitedAnswer>>) {
  console.log("\n--- RENDERED UI ---");
  console.log(`Answer: ${result.answer}`);
  
  if (result.sources.length > 0) {
    console.log("Sources:");
    result.sources.forEach((src) => {
      // In a real React app, this would be: <a href={`/view/${src.id}`}>Source</a>
      console.log(`- [${src.sourceName}, Page ${src.page}] (ID: ${src.id})`);
    });
  }
  console.log("-------------------\n");
}

/**
 * ============================================================================
 * 5. EXECUTION FLOW
 * ============================================================================
 */

(async () => {
  const userQuery = "Why is the sky blue?";
  
  // 1. Fetch and process
  const finalData = await generateCitedAnswer(userQuery);
  
  // 2. Render (Simulate UI update)
  renderUI(finalData);
})();
