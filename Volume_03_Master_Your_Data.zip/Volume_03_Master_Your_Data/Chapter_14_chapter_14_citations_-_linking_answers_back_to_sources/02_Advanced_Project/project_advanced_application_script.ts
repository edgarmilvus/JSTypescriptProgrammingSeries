/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// app/api/chat/route.ts
// Target: Next.js App Router (Server Component / API Route)
// Dependencies: @langchain/langgraph, @langchain/community, langchain, ai, zod

import { NextRequest } from 'next/server';
import { StreamingTextResponse } from 'ai';
import { z } from 'zod';
import { StateGraph, END, MessageSend } from '@langchain/langgraph';
import { HNSWLib } from '@langchain/community/vectorstores/hnswlib';
import { OpenAIEmbeddings, ChatOpenAI } from '@langchain/openai';
import { ChatPromptTemplate } from '@langchain/core/prompts';

// ============================================================================
// 1. INITIALIZATION & STATE DEFINITION
// ============================================================================

/**
 * Defines the state schema for our LangGraph.
 * In a production app, this state is hydrated from the Checkpointer.
 * We include `retrievedDocs` to store metadata (chunkId, source) alongside text.
 */
const StateSchema = z.object({
  input: z.string(),
  retrievedDocs: z.array(z.object({
    pageContent: z.string(),
    metadata: z.object({
      chunkId: z.string(), // Unique identifier for citation
      sourceLink: z.string(), // URL to the specific document section
      sourceName: z.string() // Human-readable name
    })
  })),
  // The final answer with citations injected
  answer: z.string().optional()
});

type AgentState = z.infer<typeof StateSchema>;

/**
 * Mock Data Initialization
 * In production, this would be a connection to a persistent Vector DB (Pinecone, Weaviate).
 * We use HNSWLib here for a self-contained, file-system-based demo.
 */
async function initializeVectorStore(): Promise<HNSWLib> {
  const docs = [
    {
      pageContent: "To reset your password, go to Settings > Security and click 'Reset Password'. You will receive an email verification link.",
      metadata: { chunkId: "doc_101_chunk_1", sourceLink: "/docs/security#reset", sourceName: "Security Guide" }
    },
    {
      pageContent: "API rate limits are tiered. Free tier allows 100 requests/minute. Enterprise tier is unlimited.",
      metadata: { chunkId: "doc_102_chunk_1", sourceLink: "/docs/api#limits", sourceName: "API Reference" }
    },
    {
      pageContent: "If 2FA is locked, contact support immediately. Do not attempt to brute force the login endpoint.",
      metadata: { chunkId: "doc_101_chunk_2", sourceLink: "/docs/security#2fa", sourceName: "Security Guide" }
    }
  ];

  const vectorStore = await HNSWLib.fromDocuments(
    docs,
    new OpenAIEmbeddings({ modelName: "text-embedding-ada-002" })
  );
  return vectorStore;
}

// ============================================================================
// 2. RETRIEVAL NODE
// ============================================================================

/**
 * Performs semantic search and extracts metadata for citation mapping.
 * This is a Non-Blocking operation thanks to the async/await pattern in Node.js.
 * The V8 engine handles the I/O suspension without blocking the main thread.
 */
async function retrieveNode(state: typeof AgentState, vectorStore: HNSWLib): Promise<Partial<AgentState>> {
  const { input } = state;
  
  // Perform similarity search (k=2 for diversity)
  const results = await vectorStore.similaritySearch(input, 2);
  
  // Map results to the expected state structure
  const retrievedDocs = results.map(doc => ({
    pageContent: doc.pageContent,
    metadata: doc.metadata as { chunkId: string; sourceLink: string; sourceName: string }
  }));

  return { retrievedDocs };
}

// ============================================================================
// 3. GENERATION NODE (WITH CITATION INSTRUCTION)
// ============================================================================

/**
 * Generates the final answer.
 * Crucially, it injects the `chunkId` into the prompt so the LLM knows how to cite.
 */
async function generateNode(state: typeof AgentState): Promise<Partial<AgentState>> {
  const llm = new ChatOpenAI({ model: "gpt-4-turbo-preview", streaming: true });

  // Format context with explicit IDs for the LLM to reference
  const context = state.retrievedDocs.map((doc, index) => 
    `[ID:${doc.metadata.chunkId}] ${doc.pageContent}`
  ).join('\n\n');

  const prompt = ChatPromptTemplate.fromMessages([
    ["system", 
      `You are a helpful support assistant. Answer the user's question based ONLY on the provided context.
      CRITICAL: If you use information from a context block, you MUST cite it using the ID provided in brackets.
      Format citations as: [ID:doc_xxx_chunk_y].
      If the answer isn't in the context, say you don't know.`
    ],
    ["user", `Context:\n{context}\n\nQuestion: {input}`]
  ]);

  // Format input for the chain
  const chain = prompt.pipe(llm);
  const stream = await chain.stream({ context, input: state.input });

  // We construct the full answer string here to return to the state
  // In a real streaming app, we might stream directly to the client here.
  let fullAnswer = "";
  for await (const chunk of stream) {
    fullAnswer += chunk.content;
  }

  return { answer: fullAnswer };
}

// ============================================================================
// 4. GRAPH COMPILATION & CHECKPOINTING
// ============================================================================

/**
 * Compiles the LangGraph workflow.
 * We use a simple in-memory checkpointer for this demo.
 */
function createGraph(vectorStore: HNSWLib) {
  const workflow = new StateGraph({
    stateSchema: z.object({
      input: z.string(),
      retrievedDocs: z.any(), // Simplified for demo
      answer: z.string().optional()
    })
  });

  // Define nodes
  workflow.addNode("retrieve", async (state: any) => retrieveNode(state, vectorStore));
  workflow.addNode("generate", generateNode);

  // Define edges
  workflow.setEntryPoint("retrieve");
  workflow.addEdge("retrieve", "generate");
  workflow.addEdge("generate", END);

  // Compile with a checkpointer (using MemorySaver for demo)
  // In production, use RedisCheckpoint or SqliteSaver
  const checkpointerConfig = {
    recursionLimit: 5,
    // checkpointer: new RedisSaver({ ... }) 
  };

  return workflow.compile();
}

// ============================================================================
// 5. MAIN API ROUTE (NON-BLOCKING I/O)
// ============================================================================

export async function POST(req: NextRequest) {
  const { message } = await req.json();

  // Initialize dependencies (in prod, these are singletons)
  const vectorStore = await initializeVectorStore();
  const graph = createGraph(vectorStore);

  // Initial State
  const initialState = {
    input: message,
    retrievedDocs: [],
    answer: ""
  };

  // Execute the graph
  // The streamEvents method provides a stream of events (including node execution)
  // This is non-blocking; the event loop handles other requests while waiting for LLM tokens.
  const stream = await graph.streamEvents(
    initialState,
    { version: "v2" }
  );

  // Transform the raw stream into a clean text stream for the client
  const readableStream = new ReadableStream({
    async start(controller) {
      let citationMap: Record<string, { sourceLink: string; sourceName: string }> = {};

      for await (const event of stream) {
        // Capture metadata from the retrieve node to build a map
        if (event.event === "on_retrieve_end") {
          const docs = event.data.output.retrievedDocs;
          docs.forEach((doc: any) => {
            citationMap[doc.metadata.chunkId] = {
              sourceLink: doc.metadata.sourceLink,
              sourceName: doc.metadata.sourceName
            };
          });
        }

        // Stream tokens from the generate node
        if (event.event === "on_llm_stream" && event.data?.chunk?.content) {
          controller.enqueue(event.data.chunk.content);
        }

        // On end, send the citation map for the frontend to use
        if (event.event === "on_chain_end" && event.name === "generate") {
          controller.enqueue(`\n\n[CITATION_MAP:${JSON.stringify(citationMap)}]`);
        }
      }
      controller.close();
    }
  });

  return new StreamingTextResponse(readableStream);
}
