/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script_part2.tsx
// Description: Advanced Application Script
// ==========================================

// app/components/ChatInterface.tsx
"use client";

import { useChat } from 'ai/react';
import { useEffect, useState } from 'react';

export default function ChatInterface() {
  const { messages, input, handleInputChange, handleSubmit } = useChat();
  const [citationMap, setCitationMap] = useState<Record<string, any> | null>(null);

  // Parse the stream for the citation map at the end
  useEffect(() => {
    if (messages.length > 0) {
      const lastMessage = messages[messages.length - 1];
      
      // Check if the message contains the hidden citation map
      if (lastMessage.content.includes("CITATION_MAP:")) {
        const parts = lastMessage.content.split("CITATION_MAP:");
        const mapString = parts[parts.length - 1].replace(/[\[\]]/g, "").trim();
        
        try {
          const parsedMap = JSON.parse(mapString);
          setCitationMap(parsedMap);
          
          // Clean up the UI text (remove the map from display)
          // In a real app, we'd handle this more elegantly via custom hooks
          lastMessage.content = parts[0];
        } catch (e) {
          console.error("Failed to parse citation map");
        }
      }
    }
  }, [messages]);

  /**
   * Helper to render text with clickable citations.
   * Looks for patterns like [ID:doc_xxx_chunk_y] and replaces them with links.
   */
  const renderCitations = (text: string) => {
    if (!citationMap) return text;

    // Regex to find [ID:chunkId]
    const parts = text.split(/(\[ID:[^\]]+\])/g);

    return parts.map((part, index) => {
      const match = part.match(/\[ID:([^)]+)\]/);
      if (match && citationMap[match[1]]) {
        const meta = citationMap[match[1]];
        return (
          <a 
            key={index} 
            href={meta.sourceLink} 
            target="_blank" 
            rel="noopener noreferrer"
            className="text-blue-600 underline hover:text-blue-800 font-bold"
            title={`Source: ${meta.sourceName}`}
          >
            [{meta.sourceName}]
          </a>
        );
      }
      return <span key={index}>{part}</span>;
    });
  };

  return (
    <div className="flex flex-col w-full max-w-md mx-auto p-4 border rounded-lg">
      <div className="space-y-4 mb-4 h-64 overflow-y-auto">
        {messages.map((m) => (
          <div key={m.id} className={`p-2 rounded ${m.role === 'user' ? 'bg-blue-100' : 'bg-gray-100'}`}>
            <strong>{m.role === 'user' ? 'You: ' : 'AI: '}</strong>
            <div className="mt-1">
              {m.role === 'assistant' ? renderCitations(m.content) : m.content}
            </div>
          </div>
        ))}
      </div>

      <form onSubmit={handleSubmit} className="flex gap-2">
        <input
          className="flex-1 border p-2 rounded"
          value={input}
          onChange={handleInputChange}
          placeholder="Ask about security or API limits..."
        />
        <button type="submit" className="bg-blue-500 text-white p-2 rounded">
          Send
        </button>
      </form>
    </div>
  );
}
