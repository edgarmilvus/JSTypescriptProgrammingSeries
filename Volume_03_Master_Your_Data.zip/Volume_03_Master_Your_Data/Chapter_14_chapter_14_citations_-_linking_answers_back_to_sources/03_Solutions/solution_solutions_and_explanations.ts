/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// types.ts
export type CitationMetadata = {
  sourceId: string;
  chunkId: string;
  startIndex: number;
  endIndex: number;
  sectionTitle: string;
};

export type VectorPayload = {
  vector: number[]; // Simulated embedding
  metadata: CitationMetadata;
};

// chunking.ts
import crypto from 'crypto';
import { CitationMetadata, VectorPayload } from './types';

/**
 * Generates a unique chunk ID based on source ID and index.
 */
function generateChunkId(sourceId: string, index: number): string {
  // Using a simple hash for demonstration. In production, UUIDs are often preferred.
  const hash = crypto.createHash('md5').update(`${sourceId}-${index}`).digest('hex').substring(0, 8);
  return `${sourceId.replace(/[^a-zA-Z0-9]/g, '_')}_chunk${index}_${hash}`;
}

/**
 * Simulates generating an embedding vector for a text chunk.
 * In a real system, this would call an embedding model (e.g., OpenAI, Cohere).
 */
function generateDummyEmbedding(text: string): number[] {
  // Returns a fixed-size array of random numbers between 0 and 1.
  // The seed is based on text length to make it deterministic for this demo.
  const size = 1536; // Common dimension for text-embedding-ada-002
  const seed = text.length;
  const vector = [];
  for (let i = 0; i < size; i++) {
    // Pseudo-random generator based on seed
    const x = Math.sin(seed + i) * 10000;
    vector.push(x - Math.floor(x));
  }
  return vector;
}

/**
 * Splits a Markdown document into chunks based on headers and sentence boundaries.
 * It attempts to keep chunks within a token limit (approximated by character count).
 */
export function chunkDocumentWithMetadata(
  document: string,
  sourceId: string,
  maxChunkSize: number = 800 // Character limit for simplicity
): VectorPayload[] {
  const payloads: VectorPayload[] = [];
  
  // Regex to identify Markdown headers (e.g., "## Section Title")
  const headerRegex = /^(#{1,6})\s+(.+)$/gm;
  
  // Split by headers to maintain semantic sections
  const sections: string[] = [];
  const headerMatches: RegExpMatchArray[] = [];
  
  let lastIndex = 0;
  let match;
  while ((match = headerRegex.exec(document)) !== null) {
    if (match.index > lastIndex) {
      sections.push(document.substring(lastIndex, match.index));
    }
    headerMatches.push(match);
    lastIndex = match.index;
  }
  // Add the final section
  sections.push(document.substring(lastIndex));

  let chunkIndex = 0;
  let currentHeaderTitle = "Introduction"; // Default title

  sections.forEach((sectionContent, index) => {
    // Update current header title if available
    if (headerMatches[index]) {
      currentHeaderTitle = headerMatches[index][2].trim();
    }

    const sectionStartIndex = document.indexOf(sectionContent);
    
    // If the section is small enough, treat it as one chunk
    if (sectionContent.length <= maxChunkSize) {
      const chunkId = generateChunkId(sourceId, chunkIndex++);
      const metadata: CitationMetadata = {
        sourceId,
        chunkId,
        startIndex: sectionStartIndex,
        endIndex: sectionStartIndex + sectionContent.length,
        sectionTitle: currentHeaderTitle,
      };
      
      payloads.push({
        vector: generateDummyEmbedding(sectionContent),
        metadata,
      });
    } else {
      // Split large sections into smaller chunks based on sentence boundaries
      // Look for periods followed by space or newline
      const sentences = sectionContent.split(/(?<=[.!?])\s+/);
      let currentChunkBuffer = "";
      let bufferStartOffset = 0;

      sentences.forEach((sentence) => {
        // If adding the sentence exceeds the limit, flush the current buffer
        if (currentChunkBuffer.length + sentence.length > maxChunkSize && currentChunkBuffer.length > 0) {
          const chunkId = generateChunkId(sourceId, chunkIndex++);
          const metadata: CitationMetadata = {
            sourceId,
            chunkId,
            startIndex: sectionStartIndex + bufferStartOffset,
            endIndex: sectionStartIndex + bufferStartOffset + currentChunkBuffer.length,
            sectionTitle: currentHeaderTitle,
          };

          payloads.push({
            vector: generateDummyEmbedding(currentChunkBuffer),
            metadata,
          });

          // Reset buffer for the next chunk
          bufferStartOffset += currentChunkBuffer.length;
          currentChunkBuffer = "";
        }
        
        // Add sentence to buffer
        currentChunkBuffer += (currentChunkBuffer ? " " : "") + sentence;
      });

      // Flush any remaining text in the buffer
      if (currentChunkBuffer.length > 0) {
        const chunkId = generateChunkId(sourceId, chunkIndex++);
        const metadata: CitationMetadata = {
          sourceId,
          chunkId,
          startIndex: sectionStartIndex + bufferStartOffset,
          endIndex: sectionStartIndex + bufferStartOffset + currentChunkBuffer.length,
          sectionTitle: currentHeaderTitle,
        };

        payloads.push({
          vector: generateDummyEmbedding(currentChunkBuffer),
          metadata,
        });
      }
    }
  });

  return payloads;
}
