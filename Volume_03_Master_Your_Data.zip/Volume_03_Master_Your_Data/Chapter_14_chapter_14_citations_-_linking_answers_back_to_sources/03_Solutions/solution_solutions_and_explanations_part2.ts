/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

// citation-service.ts
import { VectorPayload, CitationMetadata } from './types';

export type CitedResponse = {
  answer: string;
  citations: CitationMetadata[];
};

// Mock database of chunks (simulating a vector store index)
const mockVectorStore: VectorPayload[] = [
  {
    vector: [0.1, 0.2], // Dummy vector
    metadata: {
      sourceId: "doc_123",
      chunkId: "doc_123_chunk_0",
      startIndex: 0,
      endIndex: 450,
      sectionTitle: "Introduction to V8"
    }
  },
  {
    vector: [0.3, 0.4],
    metadata: {
      sourceId: "doc_123",
      chunkId: "doc_123_chunk_1",
      startIndex: 451,
      endIndex: 900,
      sectionTitle: "Node.js Integration"
    }
  },
  {
    vector: [0.5, 0.6],
    metadata: {
      sourceId: "doc_456",
      chunkId: "doc_456_chunk_0",
      startIndex: 0,
      endIndex: 300,
      sectionTitle: "Deno Runtime"
    }
  }
];

/**
 * Simulates a vector similarity search. In a real system, this would compute
 * cosine similarity between the query embedding and stored vectors.
 * Here, we simply return chunks based on keyword matching for demonstration.
 */
export async function mockVectorSearch(query: string): Promise<VectorPayload[]> {
  // Simulate async network delay
  await new Promise(resolve => setTimeout(resolve, 100));

  const lowerQuery = query.toLowerCase();
  
  // Simple heuristic: if query contains "node", return node-related chunks.
  // If "deno", return deno chunks. Otherwise, return first two.
  if (lowerQuery.includes("node")) {
    return mockVectorStore.slice(0, 2);
  } else if (lowerQuery.includes("deno")) {
    return mockVectorStore.slice(2, 3);
  }
  
  return mockVectorStore.slice(0, 2); // Default
}

/**
 * Constructs a prompt for the LLM, instructing it to cite sources.
 */
export function constructRAGPrompt(query: string, chunks: VectorPayload[]): string {
  const context = chunks.map(c => 
    `[Source: ${c.metadata.chunkId} | Section: ${c.metadata.sectionTitle}]\n${c.metadata.sourceId === 'doc_123' ? 'The V8 engine is a JavaScript runtime...' : 'Deno is a secure runtime for JavaScript...'}`
  ).join('\n\n');

  return `You are a helpful assistant. Answer the user query based strictly on the provided context.
  
User Query: ${query}

Context:
${context}

Instructions:
- Answer the question concisely.
- You MUST cite your sources by appending the chunk ID in square brackets immediately after the relevant fact.
- Example: "V8 is written in C++ [doc_123_chunk_0]."

Answer:`;
}

/**
 * Parses the LLM response to find cited chunk IDs and maps them to full metadata.
 */
export function extractCitationsFromResponse(response: string, retrievedChunks: VectorPayload[]): CitedResponse {
  // Regex to find all occurrences of [chunkId]
  const citationRegex = /\[([^\]]+)\]/g;
  const matches = response.matchAll(citationRegex);
  
  const citedChunkIds = new Set<string>();
  for (const match of matches) {
    citedChunkIds.add(match[1]);
  }

  // Map cited IDs to full metadata
  const citations: CitationMetadata[] = [];
  citedChunkIds.forEach(id => {
    const found = retrievedChunks.find(c => c.metadata.chunkId === id);
    if (found) {
      citations.push(found.metadata);
    }
  });

  // Clean the answer text (remove the citation brackets for display)
  const cleanAnswer = response.replace(citationRegex, '').trim();

  return {
    answer: cleanAnswer,
    citations: citations,
  };
}
