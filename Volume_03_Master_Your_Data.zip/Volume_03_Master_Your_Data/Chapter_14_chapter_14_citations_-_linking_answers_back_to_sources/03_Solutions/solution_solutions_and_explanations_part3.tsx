/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

// CitationLink.tsx
import React from 'react';
import { CitationMetadata } from './types';

export function CitationLink({ metadata }: { metadata: CitationMetadata }) {
  // Construct a deep link. In a real app, this might be a PDF viewer or a specific anchor.
  const href = `https://example.com/${metadata.sourceId}#${metadata.chunkId}`;

  return (
    <a 
      href={href} 
      target="_blank" 
      rel="noopener noreferrer"
      style={{
        textDecoration: 'none',
        backgroundColor: '#e0f2fe',
        color: '#0369a1',
        padding: '2px 6px',
        borderRadius: '4px',
        fontSize: '0.8em',
        cursor: 'pointer',
        margin: '0 2px',
        verticalAlign: 'super'
      }}
      title={`Go to source: ${metadata.sectionTitle}`}
    >
      {metadata.sectionTitle ? metadata.sectionTitle.substring(0, 10) : 'Ref'}
    </a>
  );
}

// mock-stream.ts
import { CitationMetadata } from './types';

// Simulates a server-side stream generator
export async function* simulateStreamingResponse() {
  const events = [
    { type: 'text', content: 'Node.js is a runtime environment ' },
    { type: 'text', content: 'that executes JavaScript code outside a web browser.' },
    { type: 'citation', metadata: { sourceId: 'doc_123', chunkId: 'doc_123_chunk_1', sectionTitle: 'Node.js Integration' } as CitationMetadata },
    { type: 'text', content: ' It is built on the V8 engine ' },
    { type: 'citation', metadata: { sourceId: 'doc_123', chunkId: 'doc_123_chunk_0', sectionTitle: 'Introduction to V8' } as CitationMetadata },
    { type: 'text', content: 'and is widely used for backend development.' },
  ];

  for (const event of events) {
    // Simulate network latency
    await new Promise(resolve => setTimeout(resolve, Math.random() * 300 + 100));
    yield event;
  }
}

// StreamingAnswer.tsx
import React, { useState, useEffect, useRef } from 'react';
import { CitationMetadata } from './types';
import { CitationLink } from './CitationLink';
import { simulateStreamingResponse } from './mock-stream';

export function StreamingAnswer() {
  // State holds an array of React nodes (strings or components)
  const [content, setContent] = useState<React.ReactNode[]>([]);
  const [isStreaming, setIsStreaming] = useState(true);
  
  // Ref to track the current text buffer to avoid creating too many state updates
  const textBufferRef = useRef<string>('');

  useEffect(() => {
    let isMounted = true;
    const reader = simulateStreamingResponse();

    const processStream = async () => {
      try {
        while (isMounted) {
          const { value, done } = await reader.next();
          
          if (done) {
            // Flush any remaining text in buffer
            if (textBufferRef.current) {
              setContent(prev => [...prev, textBufferRef.current]);
              textBufferRef.current = '';
            }
            setIsStreaming(false);
            break;
          }

          if (value.type === 'text') {
            // Accumulate text in buffer instead of updating state on every token
            textBufferRef.current += value.content;
            
            // Force a state update to show progress (in a real app, you might throttle this)
            setContent(prev => {
              const lastItem = prev[prev.length - 1];
              // If the last item is a string, update it, otherwise append
              if (typeof lastItem === 'string') {
                const newContent = [...prev.slice(0, -1), textBufferRef.current];
                return newContent;
              }
              return [...prev, textBufferRef.current];
            });
          } else if (value.type === 'citation') {
            // Flush current text buffer first
            if (textBufferRef.current) {
              setContent(prev => [...prev, textBufferRef.current]);
              textBufferRef.current = '';
            }
            
            // Append the citation component
            setContent(prev => [
              ...prev, 
              <CitationLink key={`cite-${value.metadata.chunkId}`} metadata={value.metadata} />
            ]);
          }
        }
      } catch (error) {
        console.error("Stream error:", error);
        setIsStreaming(false);
      }
    };

    processStream();

    return () => {
      isMounted = false;
    };
  }, []);

  return (
    <div style={{ 
      padding: '20px', 
      border: '1px solid #ccc', 
      borderRadius: '8px',
      fontFamily: 'sans-serif',
      lineHeight: '1.6'
    }}>
      <div>
        {content}
        {isStreaming && <span style={{ animation: 'blink 1s infinite' }}>|</span>}
      </div>
    </div>
  );
}
