/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

// evaluation.ts
import { CitationMetadata } from './types';

// Mock database of chunkId -> text content
const mockSourceTextMap: Record<string, string> = {
  'doc_123_chunk_0': 'The V8 engine is a JavaScript runtime written in C++. It compiles JS to native machine code.',
  'doc_123_chunk_1': 'Node.js uses the V8 engine to execute JavaScript on the server. It provides an event-driven architecture.',
  'doc_456_chunk_0': 'Deno is a secure runtime for JavaScript and TypeScript. It was created by the original developer of Node.js.',
};

/**
 * Simulates fetching the original text content for a list of citations.
 */
export async function fetchSourceText(citations: CitationMetadata[]): Promise<string[]> {
  // Simulate async database lookup
  await new Promise(resolve => setTimeout(resolve, 50));
  
  const texts: string[] = [];
  for (const citation of citations) {
    if (mockSourceTextMap[citation.chunkId]) {
      texts.push(mockSourceTextMap[citation.chunkId]);
    }
  }
  return texts;
}

/**
 * Extracts potential key phrases from the answer text.
 * For simplicity, this filters for words longer than 4 characters, 
 * excluding common stop words.
 */
export function extractKeyPhrases(answer: string): string[] {
  const stopWords = new Set(['that', 'with', 'from', 'this', 'then', 'than', 'they', 'them', 'what', 'when', 'where', 'which']);
  
  // Remove punctuation and split by whitespace
  const words = answer.replace(/[.,!?;:]/g, '').split(/\s+/);
  
  // Filter for length and stop words
  const phrases = words
    .filter(word => word.length > 4 && !stopWords.has(word.toLowerCase()))
    .map(word => word.toLowerCase());
    
  return [...new Set(phrases)]; // Return unique phrases
}

/**
 * Calculates the citation recall score.
 */
export async function calculateCitationRecall(
  answer: string, 
  citations: CitationMetadata[]
): Promise<{ supportedPhrases: string[], unsupportedPhrases: string[], recallScore: number }> {
  
  // 1. Fetch source texts
  const sourceTexts = await fetchSourceText(citations);
  const combinedSourceText = sourceTexts.join(' ').toLowerCase();

  // 2. Extract key phrases from the answer
  const keyPhrases = extractKeyPhrases(answer);
  
  const supportedPhrases: string[] = [];
  const unsupportedPhrases: string[] = [];

  // 3. Check presence in source text
  for (const phrase of keyPhrases) {
    if (combinedSourceText.includes(phrase)) {
      supportedPhrases.push(phrase);
    } else {
      unsupportedPhrases.push(phrase);
    }
  }

  // 4. Calculate score
  const totalPhrases = keyPhrases.length;
  const recallScore = totalPhrases > 0 ? supportedPhrases.length / totalPhrases : 0;

  return {
    supportedPhrases,
    unsupportedPhrases,
    recallScore,
  };
}
