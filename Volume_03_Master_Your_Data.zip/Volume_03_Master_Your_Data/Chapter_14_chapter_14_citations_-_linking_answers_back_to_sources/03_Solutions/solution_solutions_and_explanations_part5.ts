/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

// rag-graph.ts
import { StateGraph, END } from '@langchain/langgraph';

// 1. Define the Graph State
export interface GraphState {
  query: string;
  answer: string;
  citations: string[]; // Storing chunkIds for simplicity
  confidence: number;
  stepCount: number;
  shouldContinue: boolean;
  context: string; // Accumulated context from retrieval
}

// Helper function to simulate LLM call
const simulateLLM = async (prompt: string): Promise<{ answer: string; citations: string[] }> => {
  // In a real graph, this would be a separate node calling an LLM API
  return {
    answer: "Node.js uses the V8 engine.",
    citations: ["doc_123_chunk_1"]
  };
};

// Helper function to simulate vector search
const simulateRetrieval = async (query: string): Promise<string> => {
  // Returns text chunks
  return "Context: V8 is the engine. Node.js wraps V8.";
};

// 2. Node Definitions

/**
 * Generate Node: Produces an answer based on current context.
 */
async function generateNode(state: GraphState): Promise<GraphState> {
  console.log(`[Step ${state.stepCount}] Generating...`);
  
  const prompt = `Query: ${state.query}\nContext: ${state.context}\nAnswer:`;
  const llmResult = await simulateLLM(prompt);

  return {
    ...state,
    answer: llmResult.answer,
    citations: llmResult.citations,
    stepCount: state.stepCount + 1,
  };
}

/**
 * Evaluate Node: Checks if the answer is sufficiently supported.
 */
async function evaluateNode(state: GraphState): Promise<GraphState> {
  console.log(`[Step ${state.stepCount}] Evaluating...`);
  
  // Simple heuristic: Confidence increases with more citations.
  // In reality, this might use an LLM-as-judge or a classifier.
  const confidence = state.citations.length * 0.3; // Arbitrary scoring
  const shouldContinue = confidence < 0.6; // Threshold

  return {
    ...state,
    confidence,
    shouldContinue,
  };
}

/**
 * Retrieve Node: Fetches new information to improve the answer.
 */
async function retrieveNode(state: GraphState): Promise<GraphState> {
  console.log(`[Step ${state.stepCount}] Retrieving...`);
  
  // In a real system, the query might be expanded based on the previous answer
  const newContext = await simulateRetrieval(state.query);
  
  // Append new context to existing context
  const updatedContext = `${state.context}\n${newContext}`;

  return {
    ...state,
    context: updatedContext,
    stepCount: state.stepCount + 1,
  };
}

// 3. Cyclical Graph Structure

// Define the graph state schema
const graphState = {
  query: String,
  answer: String,
  citations: Array,
  confidence: Number,
  stepCount: Number,
  shouldContinue: Boolean,
  context: String,
};

// Initialize the graph
const workflow = new StateGraph<GraphState>({
  channels: graphState,
});

// Add nodes
workflow.addNode('generate', generateNode);
workflow.addNode('evaluate', evaluateNode);
workflow.addNode('retrieve', retrieveNode);

// Define edges
workflow.setEntryPoint('generate'); // Start with generation

workflow.addEdge('generate', 'evaluate'); // Always go to evaluate after generate

// Conditional edge from evaluate
workflow.addConditionalEdges(
  'evaluate',
  (state: GraphState) => {
    if (state.shouldContinue) {
      return 'retrieve'; // Loop back to retrieve
    }
    return END; // Terminate
  }
);

// If we retrieve, we must go back to generate
workflow.addEdge('retrieve', 'generate');

// Compile the graph
export const ragGraph = workflow.compile();

// Example Usage:
/*
async function runGraph() {
  const initialState: GraphState = {
    query: "How does Node.js work?",
    answer: "",
    citations: [],
    confidence: 0,
    stepCount: 0,
    shouldContinue: true,
    context: "",
  };

  const finalState = await ragGraph.invoke(initialState);
  console.log("Final Answer:", finalState.answer);
  console.log("Total Steps:", finalState.stepCount);
}
*/
