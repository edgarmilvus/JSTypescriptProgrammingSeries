/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part3.tsx
// Description: Practical Exercises
// ==========================================

// CitationLink.tsx
import { CitationMetadata } from './types';

export function CitationLink({ metadata }: { metadata: CitationMetadata }) {
  // TODO: Implement this component.
  // It should be a clickable element that opens the source document at the specific chunk.
  // The URL should be constructed from the metadata, e.g., `https://example.com/${metadata.sourceId}#${metadata.chunkId}`.
  return <a href="#">CITATION</a>;
}

// StreamingAnswer.tsx
import { CitationMetadata } from './types';
import { CitationLink } from './CitationLink';
import { simulateStreamingResponse } from './mock-stream'; // You will create this mock function

export function StreamingAnswer() {
  // TODO: Implement the component logic.
  // 1. Create a state to hold the streamed content (e.g., an array of React nodes).
  // 2. In a useEffect, create a reader from the `simulateStreamingResponse` generator.
  // 3. Loop through the stream. For 'text' events, append the text to the current node.
  // 4. For 'citation' events, push a <CitationLink> component into your state array.
  // 5. Render the state array.
  return <div>Streaming answer will appear here...</div>;
}
