/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part4.ts
// Description: Practical Exercises
// ==========================================

// evaluation.ts
import { CitationMetadata } from './types';

// Assume this is a mock database of chunkId -> text content
const mockSourceTextMap: Record<string, string> = {
  'doc1_chunk1': 'The V8 engine is a JavaScript runtime written in C++. It compiles JS to native machine code.',
  'doc1_chunk2': 'Node.js uses the V8 engine to execute JavaScript on the server.',
  // ... more chunks
};

// TODO: Implement `fetchSourceText(citations: CitationMetadata[]): Promise<string[]>`
// This function should look up the text for each citation's chunkId from the mockSourceTextMap.

// TODO: Implement `extractKeyPhrases(answer: string): string[]`
// This function should extract a list of key phrases or nouns from the answer text.
// For simplicity, you can split by space and filter for words longer than 4 characters.

// TODO: Implement `calculateCitationRecall(answer: string, citations: CitationMetadata[])`
// This function should use the helper functions to calculate the recall score.
// It must return an object: { supportedPhrases: string[], unsupportedPhrases: string[], recallScore: number }.
