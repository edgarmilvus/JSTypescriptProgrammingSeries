/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

// index.ts
import sharp from 'sharp';
import fs from 'fs';
import path from 'path';

/**
 * @description Represents the structure of a vector database record.
 * @template T - The type of the metadata (e.g., file path, user ID).
 */
interface VectorRecord<T> {
  id: string;
  vector: number[];
  metadata: T;
}

/**
 * @description Metadata specific to our image upload scenario.
 */
interface ImageMetadata {
  filePath: string;
  uploadedAt: Date;
  originalName: string;
}

/**
 * @description Mock interface for a Vector Database (e.g., Pinecone, Qdrant).
 * In a real app, this would be an API client.
 */
interface VectorDatabase {
  upsert(record: VectorRecord<ImageMetadata>): Promise<void>;
  query(vector: number[], topK: number): Promise<VectorRecord<ImageMetadata>[]>;
}

/**
 * @description A simulated Vector Database implementation.
 * It stores data in memory using a Map.
 */
class MockVectorDB implements VectorDatabase {
  private store: Map<string, VectorRecord<ImageMetadata>> = new Map();

  async upsert(record: VectorRecord<ImageMetadata>): Promise<void> {
    this.store.set(record.id, record);
    console.log(`[DB] Indexed vector for ID: ${record.id}`);
  }

  async query(vector: number[], topK: number): Promise<VectorRecord<ImageMetadata>[]> {
    // Calculate Euclidean distance (simplified for demo)
    const scores = Array.from(this.store.values()).map((record) => {
      const distance = Math.sqrt(
        vector.reduce((sum, val, i) => sum + Math.pow(val - record.vector[i], 2), 0)
      );
      return { ...record, score: distance };
    });

    // Sort by lowest distance (closest match)
    return scores.sort((a, b) => a.score - b.score).slice(0, topK);
  }
}

/**
 * @description Simulates a Multimodal Embedding Model (e.g., CLIP).
 * In production, this would call an API (OpenAI, Replicate) or run a local ONNX model.
 * It converts an image buffer into a 512-dimensional vector.
 */
async function generateImageEmbedding(imageBuffer: Buffer): Promise<number[]> {
  console.log('[Model] Generating embedding from image buffer...');
  
  // SIMULATION: In reality, we would pass the buffer to a model.
  // Here, we generate a deterministic pseudo-random vector based on the buffer length
  // to simulate a unique vector for every unique image size/content.
  const seed = imageBuffer.length;
  const vector: number[] = [];
  
  // Generate a 512-dimension vector
  for (let i = 0; i < 512; i++) {
    // Pseudo-random generator based on seed
    const x = Math.sin(seed + i) * 10000;
    vector.push(x - Math.floor(x));
  }

  return vector;
}

/**
 * @description Main processing pipeline.
 * 1. Reads image from disk.
 * 2. Preprocesses (resizes) using Sharp.
 * 3. Generates embedding.
 * 4. Upserts to Vector DB.
 */
async function indexImage(
  imagePath: string, 
  db: VectorDatabase
): Promise<void> {
  try {
    console.log(`\n--- Starting Indexing for: ${path.basename(imagePath)} ---`);

    // 1. Image Preprocessing (Sharp)
    // We resize to ensure consistent input size for the model and reduce memory usage.
    // 'fit: cover' maintains aspect ratio while filling the dimensions.
    const processedImageBuffer = await sharp(imagePath)
      .resize(224, 224, { fit: 'cover' })
      .png() // Normalize format to PNG
      .toBuffer();

    console.log(`[Sharp] Image processed. Buffer size: ${processedImageBuffer.length} bytes`);

    // 2. Embedding Generation
    const embeddingVector = await generateImageEmbedding(processedImageBuffer);

    // 3. Prepare Metadata
    const metadata: ImageMetadata = {
      filePath: imagePath,
      uploadedAt: new Date(),
      originalName: path.basename(imagePath)
    };

    // 4. Vector DB Upsert
    // We use the file path as a unique ID for this demo.
    const record: VectorRecord<ImageMetadata> = {
      id: path.basename(imagePath, path.extname(imagePath)), // e.g., 'sunset'
      vector: embeddingVector,
      metadata: metadata
    };

    await db.upsert(record);
    
    console.log(`--- Indexing Complete ---\n`);
  } catch (error) {
    console.error('Error during indexing pipeline:', error);
    throw error;
  }
}

/**
 * @description Example usage: Simulating a SaaS app processing uploads.
 */
(async () => {
  // Initialize DB
  const vectorDB = new MockVectorDB();

  // Create dummy image files for demonstration purposes
  // In a real app, these would come from an HTTP request (e.g., Multer in Express)
  const mockImages = [
    { name: 'sunset.jpg', content: 'SUNSET_IMAGE_DATA' },
    { name: 'mountain.png', content: 'MOUNTAIN_IMAGE_DATA' },
    { name: 'city_night.jpg', content: 'CITY_NIGHT_DATA' }
  ];

  // Write dummy files to disk
  for (const img of mockImages) {
    fs.writeFileSync(img.name, img.content);
  }

  // Run the indexing pipeline for each image
  for (const img of mockImages) {
    await indexImage(img.name, vectorDB);
  }

  // Cleanup dummy files
  mockImages.forEach(img => fs.unlinkSync(img.name));
})();
