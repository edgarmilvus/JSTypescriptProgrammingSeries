/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// pages/api/multimodal-rag.ts
// Next.js API Route for Multi-modal RAG operations

import { NextApiRequest, NextApiResponse } from 'next';
import { Pinecone } from '@pinecone-database/pinecone';
import { MultiModalClient } from '../../lib/multimodal-client'; // Hypothetical client for CLIP-like models

// ============================================================================
// 1. TYPE DEFINITIONS & GRAPH STATE
// ============================================================================

/**
 * Represents the canonical data structure (Graph State) passed through our pipeline.
 * This ensures type safety and acts as the context for all processing nodes.
 */
interface RagGraphState {
  // Input: The raw data from the request
  inputImageBuffer?: Buffer;
  inputTextQuery?: string;
  
  // Processing: Generated embeddings
  imageEmbedding?: number[];
  textEmbedding?: number[];
  
  // Output: Retrieved results
  matches?: Array<{
    id: string;
    score: number;
    metadata: { description: string; filename: string };
  }>;
}

// ============================================================================
// 2. SERVICE CLIENTS INITIALIZATION
// ============================================================================

// Initialize Pinecone Client
const pc = new Pinecone({
  apiKey: process.env.PINECONE_API_KEY!,
  environment: process.env.PINECONE_ENVIRONMENT!,
});

// Initialize Multimodal AI Client (e.g., wrapping OpenAI or HuggingFace API)
const mmClient = new MultiModalClient({
  apiKey: process.env.MULTIMODAL_API_KEY!,
});

// Target Index for our vector store
const indexName = 'product-catalog-vectors';
const pineconeIndex = pc.index(indexName);

// ============================================================================
// 3. PIPELINE NODES (Logic Breakdown)
// ============================================================================

/**
 * Node 1: Image Processing & Embedding Generation
 * 
 * Why: Images cannot be stored directly in vector databases. They must be converted
 * into numerical vectors (embeddings) that capture semantic meaning.
 * 
 * How: We pass the raw image buffer to a Multimodal LLM (like CLIP).
 * Under the Hood: The model uses a Vision Transformer (ViT) to process pixel data
 * and outputs a high-dimensional vector (e.g., 512 dimensions) representing the image's content.
 */
async function generateImageEmbedding(state: RagGraphState): Promise<RagGraphState> {
  if (!state.inputImageBuffer) throw new Error("No image buffer provided.");
  
  console.log("Generating image embedding...");
  const embedding = await mmClient.createImageEmbedding(state.inputImageBuffer);
  
  return {
    ...state,
    imageEmbedding: embedding,
  };
}

/**
 * Node 2: Text Embedding Generation
 * 
 * Why: To perform semantic search, the text query must be converted into the same
 * vector space as the images.
 * 
 * How: We pass the text string to the Multimodal LLM.
 * Under the Hood: The model uses a Text Transformer (like BERT) to convert the 
 * semantic meaning of the text into a vector. Crucially, CLIP models are trained 
 * so that "dog" text and "dog image" embeddings are mathematically close.
 */
async function generateTextEmbedding(state: RagGraphState): Promise<RagGraphState> {
  if (!state.inputTextQuery) throw new Error("No text query provided.");
  
  console.log("Generating text embedding...");
  const embedding = await mmClient.createTextEmbedding(state.inputTextQuery);
  
  return {
    ...state,
    textEmbedding: embedding,
  };
}

/**
 * Node 3: Vector Storage (Upsert)
 * 
 * Why: We need to persist the image data so it can be retrieved later.
 * 
 * How: We upsert the vector into Pinecone along with metadata.
 * Under the Hood: Pinecone stores the vector in an optimized index (typically HNSW graph)
 * allowing for Approximate Nearest Neighbor (ANN) search at low latency.
 */
async function storeImageVector(state: RagGraphState): Promise<RagGraphState> {
  if (!state.imageEmbedding || !state.inputImageBuffer) return state;

  // In a real app, we would generate a unique ID (e.g., UUID) for the image
  const vectorId = `img_${Date.now()}`;
  
  // Metadata helps filter results later and provides context for the LLM response
  const metadata = {
    filename: 'uploaded_product.jpg',
    description: 'Visual asset stored via multi-modal pipeline',
    timestamp: new Date().toISOString(),
  };

  console.log(`Upserting vector ${vectorId} to Pinecone...`);
  await pineconeIndex.upsert([
    {
      id: vectorId,
      values: state.imageEmbedding,
      metadata: metadata,
    },
  ]);

  return state;
}

/**
 * Node 4: Cross-Modal Retrieval
 * 
 * Why: To find relevant images based on the user's text query.
 * 
 * How: We query the vector database using the text embedding.
 * Under the Hood: The vector database calculates the cosine similarity (or dot product)
 * between the query text vector and all stored image vectors. It returns the top K 
 * matches where the semantic meaning aligns closest.
 */
async function retrieveRelevantImages(state: RagGraphState): Promise<RagGraphState> {
  if (!state.textEmbedding) return state;

  console.log("Querying Pinecone for similar vectors...");
  const queryResponse = await pineconeIndex.query({
    vector: state.textEmbedding,
    topK: 3, // Retrieve top 3 most relevant images
    includeMetadata: true,
  });

  return {
    ...state,
    matches: queryResponse.matches,
  };
}

// ============================================================================
// 4. MAIN EXECUTION HANDLER (The Orchestrator)
// ============================================================================

/**
 * Main API Handler
 * 
 * This function acts as the entry point for the Next.js request.
 * It orchestrates the nodes in a specific order to form the RAG pipeline.
 * 
 * Event Loop Consideration: Since Node.js is single-threaded, we use `await` 
 * to handle asynchronous I/O (file processing, API calls) without blocking 
 * the event loop unnecessarily. For heavy CPU tasks (like local model inference),
 * we would typically offload to a worker thread, but here we rely on external APIs.
 */
export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  // 1. Validate Request Method
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  try {
    // 2. Parse Input
    // In a real Next.js app, you might use 'multer' or 'next-connect' for multipart/form-data
    // For this script, we assume the image buffer is passed in the body (simplified).
    const { imageBuffer, textQuery } = req.body; 

    if (!imageBuffer || !textQuery) {
      return res.status(400).json({ error: 'Missing image or text query' });
    }

    // 3. Initialize Graph State
    let state: RagGraphState = {
      inputImageBuffer: Buffer.from(imageBuffer, 'base64'), // Convert base64 back to buffer
      inputTextQuery: textQuery,
    };

    // 4. Execute Pipeline (Sequential Flow)
    // Note: In a complex graph (LangGraph), these would be conditional edges.
    // Here we execute linearly for clarity.
    
    // A. Process the Image (Store it)
    state = await generateImageEmbedding(state);
    state = await storeImageVector(state);

    // B. Process the Query (Retrieve from it)
    state = await generateTextEmbedding(state);
    state = await retrieveRelevantImages(state);

    // 5. Return Structured Response
    // We return the matches to the frontend to display relevant images.
    return res.status(200).json({
      success: true,
      data: {
        query: textQuery,
        retrievedAssets: state.matches,
      },
    });

  } catch (error) {
    console.error("Pipeline Error:", error);
    return res.status(500).json({ error: 'Internal Server Error during RAG execution' });
  }
}
