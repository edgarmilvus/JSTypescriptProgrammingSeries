/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

import { v4 as uuidv4 } from 'uuid';

// --- Mocks & Types ---
// Assume these are defined from Exercise 1
interface ImageMetadata {
  filename: string;
  caption: string;
  tags: string[];
  embeddingId: string;
  processedAt: string;
}

interface VectorDBRecord {
  id: string;
  values: number[];
  metadata: ImageMetadata;
}

// Mock Vector Database Client
class VectorDBClient {
  async connect() {
    // Simulate connection
    return true;
  }
  async upsert(record: VectorDBRecord) {
    // Simulate DB write
    console.log(`[DB] Upserted vector ${record.id} (dim: ${record.values.length})`);
    return { success: true };
  }
}

// --- Configuration ---
const EMBEDDING_DIMENSION = 1536; // e.g., text-embedding-ada-002
const MAX_RETRIES = 3;
const INITIAL_BACKOFF = 1000; // 1 second

// --- Helper Functions ---

/**
 * Simulates an embedding API call.
 * In reality, use OpenAI embeddings or a local model.
 */
async function generateEmbedding(text: string): Promise<number[]> {
  // Simulate network latency
  await new Promise(resolve => setTimeout(resolve, 200));
  
  // Return a mock vector of appropriate dimension
  return Array.from({ length: EMBEDDING_DIMENSION }, () => Math.random());
}

/**
 * Exponential backoff retry logic.
 */
async function withExponentialBackoff<T>(
  operation: () => Promise<T>,
  retries = MAX_RETRIES,
  delay = INITIAL_BACKOFF
): Promise<T> {
  try {
    return await operation();
  } catch (error) {
    if (retries <= 0) {
      throw new Error(`Operation failed after ${MAX_RETRIES} retries: ${error}`);
    }
    console.warn(`Retrying... ${retries} attempts left. Waiting ${delay}ms`);
    await new Promise(resolve => setTimeout(resolve, delay));
    return withExponentialBackoff(operation, retries - 1, delay * 2);
  }
}

/**
 * Upserts image vector to the database with retry logic.
 */
async function upsertImageVector(
  metadata: ImageMetadata,
  dbClient: VectorDBClient
): Promise<void> {
  // 1. Construct text for embedding
  const textContext = `${metadata.caption}. Tags: ${metadata.tags.join(', ')}`;

  // 2. Generate Embedding
  const vector = await generateEmbedding(textContext);

  // 3. Prepare Payload
  const record: VectorDBRecord = {
    id: metadata.embeddingId, // Must match the ID from Exercise 1
    values: vector,
    metadata: metadata
  };

  // 4. Upsert with Retry Logic
  const operation = async () => {
    // Simulate potential transient failure
    if (Math.random() < 0.2) throw new Error("Transient Network Error");
    return dbClient.upsert(record);
  };

  try {
    await withExponentialBackoff(operation);
    console.log(`Successfully indexed: ${metadata.embeddingId}`);
  } catch (error) {
    console.error(`Failed to index ${metadata.embeddingId}:`, error);
    // Handle dead-letter queue logic here in production
  }
}

// --- Visualization Helper ---
function visualizeDataFlow(metadata: ImageMetadata) {
  console.log(`
    DATA FLOW VISUALIZATION:
    ------------------------
    [1. Raw Image] 
          ↓ (Sharp Resize)
    [2. LMM Inference] → Caption: "${metadata.caption.substring(0, 20)}..."
          ↓ (String Concatenation)
    [3. Text Context] → "${metadata.caption}. Tags: ${metadata.tags.join(', ')}"
          ↓ (Embedding Model)
    [4. Vector Array] → [0.1, 0.9, ..., 0.4] (Dimensions: ${EMBEDDING_DIMENSION})
          ↓ (Retry Logic)
    [5. Vector DB]    → ID: ${metadata.embeddingId}
  `);
}

// --- Execution Example ---
async function runExercise2() {
  // Mock metadata from Exercise 1
  const mockMetadata: ImageMetadata = {
    filename: "mountain.jpg",
    caption: "A scenic view of a mountain landscape.",
    tags: ["nature", "mountains"],
    embeddingId: uuidv4(),
    processedAt: new Date().toISOString(),
  };

  const db = new VectorDBClient();
  await db.connect();

  await upsertImageVector(mockMetadata, db);
  visualizeDataFlow(mockMetadata);
}

// runExercise2(); // Uncomment to run
