/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

// components/MultiModalSearchResults.tsx
'use client';

import React, { useEffect, useState, useRef, useCallback } from 'react';
import { useStreamableValue } from 'ai'; // Assuming Vercel AI SDK

// --- Types ---
interface SearchResult {
  imageUrl: string;
  caption: string;
  score: number;
  id: string;
}

interface MultiModalSearchResultsProps {
  stream: ReadableStream;
  onLoadMore?: () => Promise<void>; // For infinite scroll
}

// --- Components ---

const SkeletonCard = () => (
  <div className="animate-pulse bg-gray-200 rounded-lg h-64 w-full"></div>
);

const ResultCard = ({ result }: { result: SearchResult }) => {
  // Visual indicator for score (0 to 1)
  const scorePercentage = Math.round(result.score * 100);
  const scoreColor = result.score > 0.8 ? 'bg-green-500' : result.score > 0.5 ? 'bg-yellow-500' : 'bg-red-500';

  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-xl transition-shadow duration-300">
      <div className="relative h-48 w-full bg-gray-100">
        {/* In a real app, use next/image with optimization */}
        <img 
          src={result.imageUrl} 
          alt={result.caption} 
          className="object-cover w-full h-full"
          loading="lazy"
        />
      </div>
      <div className="p-4">
        <p className="text-sm text-gray-600 mb-2 line-clamp-2">{result.caption}</p>
        <div className="w-full bg-gray-200 rounded-full h-1.5 mb-1">
          <div 
            className={`${scoreColor} h-1.5 rounded-full`} 
            style={{ width: `${scorePercentage}%` }}
          ></div>
        </div>
        <span className="text-xs text-gray-400">Relevance: {scorePercentage}%</span>
      </div>
    </div>
  );
};

// --- Main Component ---

export function MultiModalSearchResults({ stream, onLoadMore }: MultiModalSearchResultsProps) {
  // 1. Data Handling: Use Vercel AI SDK hook to parse stream
  const [data, error] = useStreamableValue(stream);
  
  // Local state to accumulate results (for infinite scroll)
  const [results, setResults] = useState<SearchResult[]>([]);
  const [isLoadingMore, setIsLoadingMore] = useState(false);
  const observerTarget = useRef<HTMLDivElement>(null);

  // Update results when stream data arrives
  useEffect(() => {
    if (data) {
      // Assuming data is an array of results or a single result chunk
      // Logic might vary based on how the server sends the stream
      setResults(prev => [...prev, ...data]);
    }
  }, [data]);

  // 2. Infinite Scroll Logic
  const handleObserver = useCallback((entries: IntersectionObserverEntry[]) => {
    const [entry] = entries;
    if (entry.isIntersecting && onLoadMore && !isLoadingMore) {
      setIsLoadingMore(true);
      onLoadMore().finally(() => setIsLoadingMore(false));
    }
  }, [onLoadMore, isLoadingMore]);

  useEffect(() => {
    const observer = new IntersectionObserver(handleObserver, { threshold: 0.1 });
    if (observerTarget.current) observer.observe(observerTarget.current);
    return () => observer.disconnect();
  }, [handleObserver]);

  // 3. Loading State
  if (!data && !results.length) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {[1, 2, 3].map(i => <SkeletonCard key={i} />)}
      </div>
    );
  }

  return (
    <div className="relative">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {results.map((result) => (
          <ResultCard key={result.id} result={result} />
        ))}
      </div>
      
      {/* Sentinel for Infinite Scroll */}
      <div ref={observerTarget} className="h-10 w-full mt-4">
        {isLoadingMore && <p className="text-center text-gray-500">Loading more results...</p>}
      </div>
    </div>
  );
}
