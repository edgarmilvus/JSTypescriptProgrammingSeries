/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

import express, { Request, Response } from 'express';
import multer from 'multer';
import sharp from 'sharp';

// --- Setup ---
const app = express();
const upload = multer({ storage: multer.memoryStorage() });

// --- Mocks ---
// Mock Vector DB Client (same interface as Ex 2)
const vectorDB = {
  search: async (vector: number[], topK: number, filter?: any) => {
    // Simulate search results
    return [
      { id: 'doc_1', score: 0.92, type: 'image', content: 'url_to_similar_image.jpg', metadata: { tags: ['cat', 'animal'] } },
      { id: 'doc_2', score: 0.45, type: 'text', content: 'A dog barking loudly', metadata: { tags: ['dog', 'sound'] } }
    ];
  }
};

// --- Helper Functions ---

/**
 * Generates a visual embedding (simulating CLIP).
 * In production, use a library like `onnxruntime-node` with a CLIP model.
 */
async function generateImageEmbedding(buffer: Buffer): Promise<number[]> {
  // Resize for model input
  const resized = await sharp(buffer).resize(224, 224).toBuffer();
  // Mock vector return
  return Array.from({ length: 512 }, () => Math.random()); // CLIP usually 512 dim
}

/**
 * Hybrid Search: Combines Vector Search and Keyword Filtering.
 */
async function hybridSearch(queryVector: number[], keywordFilter?: string[]) {
  // 1. Vector Search
  const vectorResults = await vectorDB.search(queryVector, 5);
  
  // 2. Keyword Filter (if provided)
  if (keywordFilter && keywordFilter.length > 0) {
    // In a real DB, this is a metadata filter. Here we simulate it.
    return vectorResults.filter(r => 
      r.metadata.tags.some(tag => keywordFilter.includes(tag))
    );
  }
  
  return vectorResults;
}

// --- API Endpoint ---

app.post('/api/search/image', upload.single('image'), async (req: Request, res: Response) => {
  try {
    if (!req.file) {
      return res.status(400).json({ error: 'No image file provided' });
    }

    // 1. Image Embedding
    const imageVector = await generateImageEmbedding(req.file.buffer);

    // 2. Initial Vector Search
    let results = await vectorDB.search(imageVector, 5);

    // 3. Query Expansion (Interactive Challenge)
    // If top result score is low, trigger expansion
    const THRESHOLD = 0.75;
    if (results.length > 0 && results[0].score < THRESHOLD) {
      console.log("Low similarity detected. Triggering Query Expansion...");
      
      // Extract keywords from the top (even if low score) result metadata
      const expansionKeywords = results[0].metadata.tags;
      
      // Perform hybrid search with these keywords
      // This "zooms out" by finding items related to the visual context 
      // even if they aren't visually identical.
      const expandedResults = await hybridSearch(imageVector, expansionKeywords);
      
      // Merge and deduplicate (simple implementation)
      const seenIds = new Set();
      results = [...results, ...expandedResults].filter(item => {
        if (seenIds.has(item.id)) return false;
        seenIds.add(item.id);
        return true;
      });
    }

    // 4. Format Response
    const formattedResponse = results.map(r => ({
      type: r.type,
      content: r.content,
      similarityScore: r.score,
      source: r.id
    }));

    return res.json(formattedResponse);

  } catch (error) {
    console.error(error);
    return res.status(500).json({ error: 'Internal Server Error' });
  }
});

// Start server (mock)
// app.listen(3000, () => console.log('Server running on port 3000'));
