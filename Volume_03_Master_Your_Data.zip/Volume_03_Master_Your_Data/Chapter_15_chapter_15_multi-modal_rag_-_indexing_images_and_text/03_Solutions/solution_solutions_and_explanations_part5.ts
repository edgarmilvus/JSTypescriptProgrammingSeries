/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

// --- Types ---
interface RetrievedItem {
  type: 'text' | 'image';
  content: string; // Text content or Image URL
  score: number;
}

interface PromptContext {
  query: string;
  items: RetrievedItem[];
}

// --- Mock Helper ---
// Simulates token counting (1 token ~= 4 chars)
const estimateTokens = (str: string): number => Math.ceil(str.length / 4);

// --- 1. Context Augmentation Function ---

function buildMultimodalPrompt({ query, items }: PromptContext, tokenLimit: number = 3000): string {
  // Separate items by type
  const textItems = items.filter(i => i.type === 'text');
  const imageItems = items.filter(i => i.type === 'image');

  // Sort text by relevance (score) ascending to truncate least relevant first
  textItems.sort((a, b) => a.score - b.score);

  let textContext = "";
  let currentTokens = 0;

  // Truncation Logic
  for (const item of textItems) {
    const itemTokens = estimateTokens(item.content);
    if (currentTokens + itemTokens > tokenLimit) {
      // Truncate this chunk if it pushes over limit
      const remainingSpace = tokenLimit - currentTokens;
      const charsPerToken = 4;
      const allowedChars = Math.floor(remainingSpace * charsPerToken);
      if (allowedChars > 0) {
        textContext += `\n- ${item.content.substring(0, allowedChars)}... (truncated)\n`;
      }
      break; // Stop adding text
    }
    textContext += `\n- ${item.content}\n`;
    currentTokens += itemTokens;
  }

  // Construct Prompt
  const imageContext = imageItems.map((img, idx) => `Image ${idx + 1}: ${img.content}`).join('\n');

  const prompt = `
SYSTEM ROLE:
You are a multimodal research assistant. Analyze the provided text context and image context to answer the user's query accurately. 
If referencing an image, use the format [Figure X] where X is the image number.

TEXT CONTEXT:
${textContext || "No text context available."}

IMAGE CONTEXT:
${imageContext || "No images provided."}

USER QUERY:
${query}

ANSWER:
`;

  return prompt;
}

// --- 2. Streamable UI Challenge (Server Action Simulation) ---

/**
 * Simulates an LLM stream response. In reality, this would be an async generator
 * yielding tokens from an OpenAI stream.
 */
async function* mockLLMStream(prompt: string): AsyncGenerator<string, void, unknown> {
  const response = "Based on Figure 1, the mountain is snowy. Figure 2 shows a lake. The data indicates a 20% increase.";
  for (const char of response) {
    yield char;
    await new Promise(r => setTimeout(r, 50)); // Simulate typing speed
  }
}

/**
 * Server Action that processes the stream and injects UI components.
 * This logic typically runs on the server (Next.js Server Actions).
 */
async function processStreamForUI(query: string, context: RetrievedItem[]) {
  const prompt = buildMultimodalPrompt({ query, context });
  const stream = mockLLMStream(prompt);
  
  // This ReadableStream is what the frontend will consume
  return new ReadableStream({
    async start(controller) {
      let buffer = "";
      for await (const chunk of stream) {
        buffer += chunk;
        
        // Check for keywords to replace
        // Pattern: "Figure X"
        const regex = /Figure (\d+)/g;
        let lastIndex = 0;
        let match;
        
        // We need to be careful not to split chunks mid-match.
        // For simplicity in this exercise, we flush the buffer if a match is found.
        // In production, use a more robust tokenizer or lookbehind logic.
        
        if (buffer.includes("Figure")) {
           // Simple replacement logic for demonstration
           // We replace "Figure 1" with a component tag
           const processed = buffer
            .replace(/Figure 1/g, '<ImagePreview src="url_to_image_1.jpg" />')
            .replace(/Figure 2/g, '<ImagePreview src="url_to_image_2.jpg" />');
          
          // Send the processed HTML string (or JSON structure) to client
          controller.enqueue(JSON.stringify({ type: 'chunk', content: processed }));
          buffer = ""; // Reset buffer
        } else {
          // Just send text
          controller.enqueue(JSON.stringify({ type: 'chunk', content: chunk }));
        }
      }
      controller.close();
    }
  });
}

// --- Usage Example ---

const mockContext: RetrievedItem[] = [
  { type: 'text', content: 'The mountain terrain analysis shows high altitude snow coverage.', score: 0.9 },
  { type: 'image', content: 'https://example.com/mountain.jpg', score: 0.95 },
  { type: 'image', content: 'https://example.com/lake.jpg', score: 0.85 },
];

// 1. Build the prompt
const finalPrompt = buildMultimodalPrompt({ query: "Describe the scenery in the images.", items: mockContext });
console.log("--- Generated Prompt ---");
console.log(finalPrompt);

// 2. Simulate the Streamable UI Server Action
// (This would be called by a Next.js form action)
(async () => {
  console.log("\n--- Streaming UI Simulation ---");
  const uiStream = await processStreamForUI("Describe the scenery", mockContext);
  const reader = uiStream.getReader();
  
  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    const decoded = new TextDecoder().decode(value);
    const parsed = JSON.parse(decoded);
    process.stdout.write(parsed.content);
  }
})();
