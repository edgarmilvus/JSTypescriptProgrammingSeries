/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: theory_theoretical_foundations.ts
// Description: Theoretical Foundations
// ==========================================

// We define the contract for what a valid judgment must look like.
import { z } from 'zod';

// This Zod schema is our runtime guardrail.
const FaithfulnessJudgmentSchema = z.object({
  statement: z.string().min(1),
  is_faithful: z.boolean(),
});

// An array of these judgments is what we expect from the LLM.
const EvaluationResultSchema = z.array(FaithfulnessJudgmentSchema);

// When the LLM responds, we parse it with Zod.
// If the LLM's output doesn't match the schema, Zod throws a clear error.
// This prevents silent failures and ensures our metrics are calculated on valid data.
const llmResponse = '[{"statement": "The sky is blue", "is_faithful": true}]'; // Example LLM output
const parsedResult = EvaluationResultSchema.parse(JSON.parse(llmResponse));
