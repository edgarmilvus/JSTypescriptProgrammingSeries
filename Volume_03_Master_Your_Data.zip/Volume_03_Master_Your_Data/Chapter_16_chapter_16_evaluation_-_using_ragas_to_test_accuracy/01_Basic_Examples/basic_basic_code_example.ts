/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * @fileoverview A basic implementation of RAG evaluation (Faithfulness)
 *               for a TypeScript Web Application context.
 */

// ============================================================================
// 1. TYPE DEFINITIONS
// ============================================================================

/**
 * Represents a single retrieved document chunk.
 * In a real app, this might come from a Vector Database (e.g., Pinecone, Qdrant).
 */
type ContextChunk = {
  content: string;
  score: number; // Similarity score
};

/**
 * The result object returned by our evaluation endpoint.
 */
type EvaluationResult = {
  answer: string;
  metrics: {
    faithfulness: number; // 0.0 to 1.0
    reasoning: string;    // Explanation of the score
  };
};

// ============================================================================
// 2. MOCK DATA & UTILITIES
// ============================================================================

/**
 * Mock database of document chunks.
 * In a production environment, this would be a query to a Vector Store
 * using a Query Vector generated from the user's input.
 */
const MOCK_DOCUMENT_STORE: ContextChunk[] = [
  { content: "The API endpoint /v1/users requires a Bearer token in the header.", score: 0.92 },
  { content: "Rate limits are set to 100 requests per minute for the free tier.", score: 0.85 },
  { content: "Authentication uses JWT (JSON Web Tokens) signed with HS256.", score: 0.78 },
];

/**
 * Simulates a vector similarity search.
 * In a real app, this would involve embedding the query and comparing vectors.
 * @param query - The user's natural language question.
 * @returns - A list of context chunks relevant to the query.
 */
function retrieveContext(query: string): ContextChunk[] {
  // Simple keyword matching simulation for the example
  if (query.toLowerCase().includes("auth") || query.toLowerCase().includes("token")) {
    return [MOCK_DOCUMENT_STORE[0], MOCK_DOCUMENT_STORE[2]]; // Return auth-related chunks
  }
  return [MOCK_DOCUMENT_STORE[1]]; // Default to rate limits
}

/**
 * Simulates an LLM generating an answer based on context.
 * In a real app, this would be a call to OpenAI or a local model.
 * @param query - The user question.
 * @param context - The retrieved chunks.
 * @returns - The generated string answer.
 */
function generateAnswer(query: string, context: ContextChunk[]): string {
  const contextText = context.map(c => c.content).join(" ");
  
  // SIMULATION: We will generate a "Hallucination" here for testing purposes.
  // The context mentions "HS256", but we will force the LLM to say "RSA256".
  if (query.includes("algorithm")) {
    return "Based on the documentation, the authentication algorithm used is RSA256.";
  }
  
  // Standard answer
  return `Answer: ${contextText}`;
}

// ============================================================================
// 3. CORE EVALUATION LOGIC (SIMPLIFIED RAGAS)
// ============================================================================

/**
 * Calculates Faithfulness Score.
 * 
 * Faithfulness measures whether the generated answer contains claims
 * that are supported by the retrieved context.
 * 
 * Implementation Strategy:
 * Since we cannot run a full LLM inside this lightweight TS example,
 * we use a keyword-based heuristic. In a real RAGAS setup, you would
 * send the 'answer' and 'context' to a Python service or a secondary LLM call.
 * 
 * @param answer - The generated answer string.
 * @param context - The list of retrieved context chunks.
 * @returns - A score between 0.0 and 1.0.
 */
function calculateFaithfulness(answer: string, context: ContextChunk[]): number {
  // 1. Flatten context into a single string for checking
  const contextText = context.map(c => c.content.toLowerCase()).join(" ");

  // 2. Extract "claims" from the answer (Simplified: We look for specific nouns/adjectives)
  // In a real scenario, an LLM would decompose the answer into statements.
  // Here, we hardcode a check for the specific hallucination we planted.
  
  const claims = [
    "rsa256", // This is the hallucination
    "hs256",  // This is the truth
    "bearer token",
    "rate limit"
  ];

  let supportedClaims = 0;
  let totalClaims = 0;

  const lowerAnswer = answer.toLowerCase();

  for (const claim of claims) {
    if (lowerAnswer.includes(claim)) {
      totalClaims++;
      if (contextText.includes(claim)) {
        supportedClaims++;
      }
    }
  }

  // 3. Calculate Score
  if (totalClaims === 0) return 1.0; // No claims made implies perfect faithfulness (vacuously true)
  
  return supportedClaims / totalClaims;
}

// ============================================================================
// 4. MAIN EXECUTION FLOW (API ROUTE SIMULATION)
// ============================================================================

/**
 * Simulates a Next.js API Route or Edge Runtime function.
 * 
 * @param query - The user input.
 * @returns - Promise<EvaluationResult>
 */
async function evaluateRagPipeline(query: string): Promise<EvaluationResult> {
  console.log(`\n--- Processing Query: "${query}" ---`);

  // Step 1: Retrieval
  // In a real app, this uses the Query Vector.
  const context = retrieveContext(query);
  console.log("Retrieved Context:", context.map(c => c.content));

  // Step 2: Generation
  const answer = generateAnswer(query, context);
  console.log("Generated Answer:", answer);

  // Step 3: Evaluation
  const faithfulnessScore = calculateFaithfulness(answer, context);

  // Step 4: Construct Result
  const result: EvaluationResult = {
    answer,
    metrics: {
      faithfulness: faithfulnessScore,
      reasoning: faithfulnessScore < 1.0 
        ? "The answer contained claims not found in the retrieved context." 
        : "All claims in the answer are supported by the context."
    }
  };

  return result;
}

// ============================================================================
// 5. EXECUTION (Entry Point)
// ============================================================================

/**
 * Main entry point to run the simulation.
 */
async function main() {
  // Scenario A: Hallucination detected
  const queryA = "What algorithm does the API use for authentication?";
  const resultA = await evaluateRagPipeline(queryA);
  
  console.log("\n=== RESULT A ===");
  console.log(JSON.stringify(resultA, null, 2));

  // Scenario B: Faithful answer
  const queryB = "What is the rate limit?";
  const resultB = await evaluateRagPipeline(queryB);
  
  console.log("\n=== RESULT B ===");
  console.log(JSON.stringify(resultB, null, 2));
}

// Execute if this file is run directly (Node.js environment)
if (require.main === module) {
  main().catch(console.error);
}

export { evaluateRagPipeline, calculateFaithfulness };
