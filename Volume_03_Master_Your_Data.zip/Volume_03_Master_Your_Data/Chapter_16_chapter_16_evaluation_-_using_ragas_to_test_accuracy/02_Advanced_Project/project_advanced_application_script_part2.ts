/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script_part2.ts
// Description: Advanced Application Script
// ==========================================

// lib/evaluation/ragasClient.ts
/**
 * @fileoverview API Client for the RAGAS Evaluation Service.
 * SRP: Solely responsible for network communication and data serialization.
 * 
 * In a real-world scenario, this communicates with a Python microservice 
 * (FastAPI/Flask) that runs the actual RAGAS library logic, as RAGAS is Python-native.
 * We use JSON Schema Output here to ensure the LLM (or backend service) returns 
 * strictly typed data.
 */

import { 
  BatchEvaluationPayload, 
  BatchEvaluationResponse,
  EvaluationResult 
} from './types';

// Mock backend URL - In production, this hits /api/evaluate or an external service
const RAGAS_API_ENDPOINT = 'https://api.ragas-eval.internal/v1/evaluate';

/**
 * Communicates with the RAGAS backend to evaluate a single data point.
 * @param data - The question, context, and generated answer.
 * @returns Promise<EvaluationResult> - The calculated metrics.
 */
export async function evaluateSingleCase(
  data: EvaluationRequest
): Promise<EvaluationResult[]> {
  try {
    // Simulating the network request to the Python backend
    // In a real app, use fetch() or axios here.
    const response = await fetch(RAGAS_API_ENDPOINT, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });

    if (!response.ok) throw new Error('Evaluation failed');

    // The backend is expected to return data matching our JSON Schema expectations
    const result: EvaluationResult[] = await response.json();
    return result;
  } catch (error) {
    console.error('RAGAS Client Error:', error);
    // Fallback or error handling logic
    throw error;
  }
}

/**
 * Handles batch evaluation for a suite of test cases.
 * @param payload - Array of test cases.
 * @returns Promise<BatchEvaluationResponse>
 */
export async function evaluateBatch(
  payload: BatchEvaluationPayload
): Promise<BatchEvaluationResponse> {
  // In a production environment, we might use Promise.allSettled 
  // to handle partial failures in a batch.
  const allResults = await Promise.all(
    payload.testCases.map((testCase) => evaluateSingleCase(testCase))
  );

  // Flatten the results (since each case returns multiple metric scores)
  const flattenedResults = allResults.flat();
  
  // Calculate average score across all metrics
  const totalScore = flattenedResults.reduce((acc, curr) => acc + curr.score, 0);
  const averageScore = totalScore / flattenedResults.length || 0;

  return {
    results: flattenedResults,
    averageScore,
  };
}
