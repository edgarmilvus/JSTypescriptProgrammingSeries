/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script_part4.tsx
// Description: Advanced Application Script
// ==========================================

// components/EvaluationDashboard.tsx
/**
 * @fileoverview Main UI Component for the RAGAS Evaluation Dashboard.
 * SRP: Handles user interaction and visualization of evaluation metrics.
 */

import React, { useState } from 'react';
import { useRAGASEvaluation } from '../hooks/useRAGASEvaluation';
import { BatchEvaluationPayload } from '../lib/evaluation/types';

// Mock initial data representing "Golden Questions" for the SaaS app
const MOCK_GOLDEN_QUESTIONS: BatchEvaluationPayload = {
  testCases: [
    {
      question: "What is the refund policy for Enterprise plans?",
      context: [
        "Enterprise plans offer a 30-day money-back guarantee.",
        "Refunds are processed within 5-7 business days."
      ],
      answer: "Enterprise plans have a 30-day money-back guarantee."
    },
    {
      question: "How do I reset my API key?",
      context: [
        "Navigate to Settings > Security > API Keys.",
        "Click 'Rotate Key' to generate a new one."
      ],
      answer: "You can reset your API key in the Security settings."
    }
  ]
};

const EvaluationDashboard: React.FC = () => {
  const { runEvaluation, results, isLoading, error } = useRAGASEvaluation();
  const [localData, setLocalData] = useState(JSON.stringify(MOCK_GOLDEN_QUESTIONS, null, 2));

  const handleRunEvaluation = async () => {
    try {
      const parsedData = JSON.parse(localData) as BatchEvaluationPayload;
      await runEvaluation(parsedData);
    } catch (e) {
      alert("Invalid JSON format");
    }
  };

  return (
    <div className="p-6 max-w-4xl mx-auto bg-white rounded-lg shadow-md">
      <h1 className="text-2xl font-bold mb-4 text-gray-800">
        RAGAS Evaluation Pipeline
      </h1>
      
      <div className="mb-6">
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Test Cases (JSON)
        </label>
        <textarea
          className="w-full h-40 p-3 border border-gray-300 rounded-md font-mono text-sm"
          value={localData}
          onChange={(e) => setLocalData(e.target.value)}
        />
        <button
          onClick={handleRunEvaluation}
          disabled={isLoading}
          className="mt-3 px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 disabled:opacity-50"
        >
          {isLoading ? 'Evaluating...' : 'Run RAGAS Evaluation'}
        </button>
      </div>

      {error && (
        <div className="mb-4 p-3 bg-red-100 text-red-700 rounded">
          Error: {error}
        </div>
      )}

      {results && (
        <div className="mt-6 border-t pt-4">
          <h2 className="text-xl font-semibold mb-3">Results</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="p-4 bg-green-50 border border-green-200 rounded">
              <h3 className="font-bold text-green-800">Average Score</h3>
              <p className="text-3xl font-mono text-green-600">
                {(results.averageScore * 100).toFixed(1)}%
              </p>
            </div>
          </div>

          <div className="mt-4 space-y-3">
            {results.results.map((res, idx) => (
              <div key={idx} className="p-3 border rounded bg-gray-50">
                <div className="flex justify-between items-center">
                  <span className="font-medium capitalize text-gray-700">
                    {res.metric.replace('_', ' ')}
                  </span>
                  <span className="font-mono font-bold">
                    {res.score.toFixed(3)}
                  </span>
                </div>
                {res.reasoning && (
                  <p className="text-xs text-gray-500 mt-1 italic">
                    "{res.reasoning}"
                  </p>
                )}
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default EvaluationDashboard;
