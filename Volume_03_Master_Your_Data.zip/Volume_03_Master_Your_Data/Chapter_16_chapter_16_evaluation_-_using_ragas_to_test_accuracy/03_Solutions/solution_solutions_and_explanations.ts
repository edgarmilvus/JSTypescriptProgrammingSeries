/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

import { z } from 'zod';

// 1. Define the Zod schema for the RAGAS service response.
// We ensure the score is within [0, 1] and the verdict is strictly one of the two strings.
export const FaithfulnessResponseSchema = z.object({
  faithfulness_score: z.number().min(0).max(1),
  verdict: z.enum(["PASS", "FAIL"]),
});

// 2. Infer the TypeScript type from the schema for type-safe usage.
export type FaithfulnessResult = z.infer<typeof FaithfulnessResponseSchema>;

/**
 * Simulates an external RAGAS service call.
 * In a real application, this would be an fetch or axios call.
 */
async function mockRagasService(
  question: string,
  context: string
): Promise<any> {
  // Simulating network delay
  await new Promise((resolve) => setTimeout(resolve, 100));

  // Mock logic: If context is empty, the service might return an invalid structure
  // to demonstrate error handling.
  if (context.trim() === "") {
    return { error: "Context cannot be empty" };
  }

  // Standard mock response
  return {
    faithfulness_score: 0.95,
    verdict: "PASS",
  };
}

/**
 * Validates the faithfulness of a generated answer against the provided context.
 * @param question - The user's original question.
 * @param context - The retrieved context used to generate the answer.
 * @returns A Promise resolving to a FaithfulnessResult.
 * @throws Error if the service response is invalid or validation fails.
 */
export async function validateFaithfulness(
  question: string,
  context: string
): Promise<FaithfulnessResult> {
  try {
    // 1. Call the mock service
    const rawResponse = await mockRagasService(question, context);

    // 2. Parse and validate the response using Zod
    // This ensures runtime safety and strict typing.
    const validatedResponse = FaithfulnessResponseSchema.parse(rawResponse);

    return validatedResponse;
  } catch (error) {
    // 3. Handle validation errors
    if (error instanceof z.ZodError) {
      // Provide detailed error information from Zod
      const errorMessage = `Faithfulness validation failed: ${JSON.stringify(error.errors)}`;
      throw new Error(errorMessage);
    }
    // Re-throw other unexpected errors
    throw error;
  }
}
