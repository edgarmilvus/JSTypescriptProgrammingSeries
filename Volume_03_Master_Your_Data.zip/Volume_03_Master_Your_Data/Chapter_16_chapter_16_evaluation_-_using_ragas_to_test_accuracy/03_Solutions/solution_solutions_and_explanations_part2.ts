/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

import { z } from 'zod';

// 1. Define input schemas
const ContextInputSchema = z.string().array();
const GroundTruthInputSchema = z.string().array();

// 2. Define output schema
const ContextPrecisionResultSchema = z.object({
  precision_score: z.number(),
  relevant_chunks_count: z.number().int(),
  total_chunks: z.number().int(),
});

// 3. Infer the result type
type ContextPrecisionResult = z.infer<typeof ContextPrecisionResultSchema>;

/**
 * Calculates the Context Precision score.
 * 
 * @param retrievedContext - Array of retrieved context strings.
 * @param groundTruth - Array of ground truth relevant strings.
 * @returns An object containing the precision score and counts.
 * @throws Error if input validation fails.
 */
export function calculateContextPrecision(
  retrievedContext: unknown,
  groundTruth: unknown
): ContextPrecisionResult {
  // 1. Validate inputs using Zod
  const validRetrievedContext = ContextInputSchema.parse(retrievedContext);
  const validGroundTruth = GroundTruthInputSchema.parse(groundTruth);

  // 2. Calculate metrics
  const totalChunks = validRetrievedContext.length;

  // Handle edge case: Empty retrieved context
  if (totalChunks === 0) {
    const result = {
      precision_score: 0,
      relevant_chunks_count: 0,
      total_chunks: 0,
    };
    // Validate the result object before returning (defensive programming)
    return ContextPrecisionResultSchema.parse(result);
  }

  // Find intersection (relevant chunks)
  // We use a Set for O(1) lookups
  const truthSet = new Set(validGroundTruth);
  const relevantChunksCount = validRetrievedContext.filter((chunk) =>
    truthSet.has(chunk)
  ).length;

  // Calculate score
  const precision_score = relevantChunksCount / totalChunks;

  // 3. Construct and validate the result object
  const result = {
    precision_score,
    relevant_chunks_count: relevantChunksCount,
    total_chunks: totalChunks,
  };

  // This final parse ensures the calculated result strictly adheres to the output schema
  return ContextPrecisionResultSchema.parse(result);
}
