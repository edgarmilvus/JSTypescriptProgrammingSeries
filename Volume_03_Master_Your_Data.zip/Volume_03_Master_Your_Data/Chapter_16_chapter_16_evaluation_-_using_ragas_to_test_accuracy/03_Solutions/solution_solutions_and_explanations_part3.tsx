/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState, useMemo } from 'react';
import { z } from 'zod';

// 1. Define the Zod schema for an evaluation record
const EvaluationRecordSchema = z.object({
  id: z.string().uuid(),
  question: z.string(),
  answer: z.string(),
  faithfulness: z.number().min(0).max(1),
  answerRelevance: z.number().min(0).max(1),
  contextPrecision: z.number().min(0).max(1),
});

// 2. Infer the type
type EvaluationRecord = z.infer<typeof EvaluationRecordSchema>;

// 3. Define component props
interface EvaluationDashboardProps {
  evaluations: EvaluationRecord[];
}

const FAILURE_THRESHOLD = 0.7;

const EvaluationDashboard: React.FC<EvaluationDashboardProps> = ({
  evaluations,
}) => {
  // 4. State for filtering
  const [showFailuresOnly, setShowFailuresOnly] = useState(false);

  // 5. Filtering Logic using useMemo for performance
  const filteredEvaluations = useMemo(() => {
    if (!showFailuresOnly) {
      return evaluations;
    }
    // Filter logic: Keep records where ANY metric is below the threshold
    return evaluations.filter(
      (evalRecord) =>
        evalRecord.faithfulness < FAILURE_THRESHOLD ||
        evalRecord.answerRelevance < FAILURE_THRESHOLD ||
        evalRecord.contextPrecision < FAILURE_THRESHOLD
    );
  }, [evaluations, showFailuresOnly]);

  // Helper to style metric cells
  const getMetricStyle = (score: number) => {
    return score < FAILURE_THRESHOLD 
      ? { color: 'red', fontWeight: 'bold' } 
      : { color: 'green' };
  };

  return (
    <div className="evaluation-dashboard">
      {/* 6. UI Control */}
      <div className="controls" style={{ marginBottom: '1rem' }}>
        <label>
          <input
            type="checkbox"
            checked={showFailuresOnly}
            onChange={(e) => setShowFailuresOnly(e.target.checked)}
          />
          <span style={{ marginLeft: '8px' }}>Show Failures Only</span>
        </label>
      </div>

      {/* 7. Table Rendering */}
      <table border={1} cellPadding={8} style={{ width: '100%', borderCollapse: 'collapse' }}>
        <thead>
          <tr>
            <th>Question</th>
            <th>Faithfulness</th>
            <th>Answer Relevance</th>
            <th>Context Precision</th>
          </tr>
        </thead>
        <tbody>
          {filteredEvaluations.length > 0 ? (
            filteredEvaluations.map((record) => (
              <tr key={record.id}>
                <td>{record.question}</td>
                <td style={getMetricStyle(record.faithfulness)}>
                  {record.faithfulness.toFixed(2)}
                </td>
                <td style={getMetricStyle(record.answerRelevance)}>
                  {record.answerRelevance.toFixed(2)}
                </td>
                <td style={getMetricStyle(record.contextPrecision)}>
                  {record.contextPrecision.toFixed(2)}
                </td>
              </tr>
            ))
          ) : (
            <tr>
              <td colSpan={4} style={{ textAlign: 'center', padding: '20px' }}>
                No evaluations found.
              </td>
            </tr>
          )}
        </tbody>
      </table>
    </div>
  );
};

export default EvaluationDashboard;
