/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

import { z } from 'zod';
import * as fs from 'fs/promises';
import * as path from 'path';

// 1. Define the Zod schemas
const EvaluationRecordSchema = z.object({
  id: z.string(),
  question: z.string(),
  answer: z.string(),
  faithfulness: z.number(),
  answerRelevance: z.number(),
  contextPrecision: z.number(),
});

const EvaluationReportSchema = z.object({
  runId: z.string(),
  evaluations: z.array(EvaluationRecordSchema),
  // We define the summary structure but won't rely on it for calculation
  summary: z.object({
    averageFaithfulness: z.number(),
    averageAnswerRelevance: z.number(),
    averageContextPrecision: z.number(),
  }).optional(),
});

// 2. Configuration
const THRESHOLD = 0.75;

/**
 * Main execution function
 */
async function main() {
  // Get file path from command line arguments
  const filePath = process.argv[2];

  if (!filePath) {
    console.error('Error: No file path provided.');
    console.error('Usage: ts-node check-quality.ts <path-to-report.json>');
    process.exit(1);
  }

  try {
    // 3. Read and parse the file
    const fileContent = await fs.readFile(path.resolve(filePath), 'utf-8');
    const jsonContent = JSON.parse(fileContent);

    // 4. Validate against schema
    // If this fails, it throws a ZodError, caught below
    const report = EvaluationReportSchema.parse(jsonContent);

    console.log(`Processing report for Run ID: ${report.runId}`);

    // 5. Calculate averages from the raw evaluations array
    const totalRecords = report.evaluations.length;

    if (totalRecords === 0) {
      console.error('Error: No evaluations found in the report.');
      process.exit(1);
    }

    const sumFaithfulness = report.evaluations.reduce((sum, item) => sum + item.faithfulness, 0);
    const sumAnswerRelevance = report.evaluations.reduce((sum, item) => sum + item.answerRelevance, 0);
    const sumContextPrecision = report.evaluations.reduce((sum, item) => sum + item.contextPrecision, 0);

    const avgFaithfulness = sumFaithfulness / totalRecords;
    const avgAnswerRelevance = sumAnswerRelevance / totalRecords;
    const avgContextPrecision = sumContextPrecision / totalRecords;

    // 6. Compare against threshold
    const metrics = [
      { name: 'Average Faithfulness', value: avgFaithfulness },
      { name: 'Average Answer Relevance', value: avgAnswerRelevance },
      { name: 'Average Context Precision', value: avgContextPrecision },
    ];

    let failed = false;

    for (const metric of metrics) {
      console.log(`${metric.name}: ${metric.value.toFixed(4)}`);
      if (metric.value < THRESHOLD) {
        console.error(`\n❌ Quality Gate Failed: ${metric.name} (${metric.value.toFixed(4)}) is below the threshold (${THRESHOLD}).`);
        failed = true;
      }
    }

    if (failed) {
      process.exit(1); // Fail the pipeline
    } else {
      console.log('\n✅ Quality Gate Passed: All metrics meet the threshold.');
      process.exit(0); // Pass the pipeline
    }

  } catch (error) {
    // 7. Robust error handling
    if (error instanceof z.ZodError) {
      console.error('Validation Error: The input report structure is invalid.');
      console.error(JSON.stringify(error.errors, null, 2));
    } else if (error instanceof SyntaxError) {
      console.error('JSON Parsing Error: The file is not valid JSON.');
    } else if (error instanceof Error) {
      console.error(`System Error: ${error.message}`);
    } else {
      console.error('An unknown error occurred.');
    }
    process.exit(1);
  }
}

// Execute the script
main();
