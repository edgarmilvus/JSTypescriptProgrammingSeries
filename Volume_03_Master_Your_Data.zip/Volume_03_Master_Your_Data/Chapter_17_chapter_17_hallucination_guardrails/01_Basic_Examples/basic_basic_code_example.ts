/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

// npm install zod
import { z } from 'zod';

/**
 * ==========================================
 * 1. DEFINE THE SCHEMA
 * ==========================================
 * We use Zod to define the exact shape of data we expect from the LLM.
 * This acts as our "contract". If the LLM deviates, the guardrail triggers.
 */
const AnalyticsResponseSchema = z.object({
    summary: z.string().min(10, "Summary is too short"), // Ensure meaningful text
    metrics: z.object({
        active_users: z.number().int().positive(), // Must be a positive integer
        revenue: z.number().min(0), // Must be non-negative
        conversion_rate: z.number().min(0).max(1), // Must be between 0 and 1
    }),
    // The LLM should not hallucinate extra fields not defined here
    additional_notes: z.string().optional(),
});

// Infer the TypeScript type for type safety
type AnalyticsResponse = z.infer<typeof AnalyticsResponseSchema>;

/**
 * ==========================================
 * 2. SIMULATED LLM CALL
 * ==========================================
 * In a real app, this would be an API call to OpenAI/Anthropic.
 * Here, we simulate an LLM that generates a JSON string.
 * 
 * @param context - The retrieved documents (simulated)
 * @returns A string containing JSON data
 */
async function callLLM(context: string): Promise<string> {
    console.log(`[System] Retrieving context: "${context}"`);
    
    // Simulating a successful LLM response
    // In reality, you would prompt the LLM with: 
    // "Return ONLY valid JSON matching this schema: { ... }"
    const llmOutput = JSON.stringify({
        summary: "User engagement has increased by 20% this week.",
        metrics: {
            active_users: 1540,
            revenue: 1250.50,
            conversion_rate: 0.15,
        }
    });

    // Simulate a potential hallucination/malformation for demonstration
    // Uncomment the line below to see the guardrail in action:
    // const llmOutput = "{ invalid_json: missing quotes }"; 

    return llmOutput;
}

/**
 * ==========================================
 * 3. THE GUARDRAIL FUNCTION
 * ==========================================
 * This function parses the LLM output against the Zod schema.
 * It acts as the "Validator" node in our diagram.
 * 
 * @param jsonString - The raw string output from the LLM
 * @returns The validated and typed data object
 */
function validateLLMOutput(jsonString: string): AnalyticsResponse {
    try {
        // Step A: Parse the string into a JavaScript object
        const parsedObject = JSON.parse(jsonString);

        // Step B: Validate the object against the Zod schema
        // If valid, it returns the typed data.
        // If invalid, it throws a ZodError with detailed issues.
        const validatedData = AnalyticsResponseSchema.parse(parsedObject);

        console.log("[Guardrail] ✅ Schema validation passed.");
        return validatedData;

    } catch (error) {
        // Step C: Handle validation or parsing errors
        if (error instanceof SyntaxError) {
            console.error("[Guardrail] ❌ JSON Parsing Error:", error.message);
            throw new Error("The model generated invalid JSON syntax.");
        } else if (error instanceof z.ZodError) {
            console.error("[Guardrail] ❌ Schema Validation Error:", error.errors);
            throw new Error("The model violated the expected data structure.");
        }
        throw error;
    }
}

/**
 * ==========================================
 * 4. FALLBACK MECHANISM
 * ==========================================
 * If the guardrail fails, we must provide a safe response to the user
 * rather than exposing the internal error or crashing.
 */
function getFallbackResponse(): AnalyticsResponse {
    return {
        summary: "I encountered an error processing your request. Please try again.",
        metrics: {
            active_users: 0,
            revenue: 0,
            conversion_rate: 0,
        }
    };
}

/**
 * ==========================================
 * 5. MAIN EXECUTION FLOW
 * ==========================================
 * This simulates the API endpoint handler (e.g., Next.js Route Handler).
 */
async function main() {
    const userQuery = "Get me the analytics for last week.";
    
    try {
        // 1. Retrieve Context (Simulated)
        const retrievedContext = "User logs show 1540 active sessions. Revenue $1250.50.";
        
        // 2. Generate Response
        const rawLlmResponse = await callLLM(retrievedContext);

        // 3. Apply Guardrails (Validation)
        const validData = validateLLMOutput(rawLlmResponse);

        // 4. Return to Client
        console.log("\n[API Response] 200 OK:", validData);

    } catch (error) {
        // 5. Trigger Fallback on Guardrail Failure
        console.error("\n[API Response] Guardrail triggered. Returning fallback.");
        const fallbackData = getFallbackResponse();
        console.log("[API Response] 200 OK (Fallback):", fallbackData);
    }
}

// Execute the example
main();
