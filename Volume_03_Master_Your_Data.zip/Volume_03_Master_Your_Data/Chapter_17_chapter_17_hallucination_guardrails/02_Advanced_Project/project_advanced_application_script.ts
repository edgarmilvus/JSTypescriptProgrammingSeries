/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// pages/api/chat.ts
// Next.js API Route: /api/chat
// Implements a Hallucination Guardrail Pipeline for RAG responses.

import type { NextApiRequest, NextApiResponse } from 'next';
import { z } from 'zod'; // For runtime type validation (JSON Schema equivalent)
import { StateGraph, END, Message } from '@langchain/langgraph'; // For cyclical graph logic

// ==========================================
// 1. TYPE DEFINITIONS & GENERICS
// ==========================================

/**
 * Generic interface for a Guardrail Validator.
 * Uses TypeScript Generics to enforce that the input `T` matches the output `T`.
 * This ensures type safety across different validation stages.
 */
interface GuardrailValidator<T> {
  name: string;
  validate(input: T): Promise<{ isValid: boolean; score?: number; error?: string }>;
}

/**
 * Schema for the LLM's structured output.
 * We enforce a strict format to prevent free-form hallucinations.
 */
const ResponseSchema = z.object({
  answer: z.string().min(10, "Answer too short"),
  citations: z.array(z.string()).min(1, "Must cite at least one source"),
  confidence: z.number().min(0).max(1),
});

type LLMOutput = z.infer<typeof ResponseSchema>;

// ==========================================
// 2. DETERMINISTIC VALIDATION MODULE
// ==========================================

/**
 * Validates the LLM output against a JSON Schema (Zod).
 * This prevents data leakage and ensures the response structure is predictable.
 */
class SchemaValidator implements GuardrailValidator<LLMOutput> {
  name = "SchemaValidator";

  async validate(input: LLMOutput) {
    try {
      // Under the hood: Zod parses the object and checks types/values.
      const parsed = ResponseSchema.parse(input);
      return { isValid: true, score: parsed.confidence };
    } catch (error) {
      return { 
        isValid: false, 
        error: error instanceof Error ? error.message : "Schema validation failed" 
      };
    }
  }
}

// ==========================================
// 3. CONTEXT RELEVANCE & FAITHFULNESS CHECK
// ==========================================

/**
 * Simulates a Cross-Encoder check for Faithfulness.
 * In production, this would use a model like 'cross-encoder/ms-marco-MiniLM-L-6-v2'
 * to compute the similarity between the generated answer and the retrieved context.
 */
class FaithfulnessValidator implements GuardrailValidator<{ answer: string; context: string }> {
  name = "FaithfulnessValidator";

  async validate(input: { answer: string; context: string }) {
    // SIMULATION: In a real app, use a vector store or cross-encoder.
    // Here, we use a simple keyword overlap heuristic for demonstration.
    const contextKeywords = input.context.toLowerCase().split(/\s+/).slice(0, 10); // Top 10 tokens
    const answerText = input.answer.toLowerCase();
    
    const matches = contextKeywords.filter(word => answerText.includes(word)).length;
    const score = matches / contextKeywords.length; // 0.0 to 1.0

    const isValid = score > 0.3; // Threshold: 30% overlap required

    return { 
      isValid, 
      score,
      error: isValid ? undefined : "Answer lacks grounding in provided context"
    };
  }
}

// ==========================================
// 4. SELF-CONSISTENCY CHECK (Multi-Query)
// ==========================================

/**
 * Implements Self-Consistency by generating multiple reasoning paths
 * and checking if the core answer remains stable.
 */
class ConsistencyValidator implements GuardrailValidator<{ question: string; answer: string }> {
  name = "ConsistencyValidator";

  async validate(input: { question: string; answer: string }) {
    // SIMULATION: We ask the LLM to rephrase the question and answer again.
    // In a real scenario, this would be an actual LLM call.
    // For this script, we simulate a "drift" in the answer.
    
    const simulatedDrift = Math.random(); // Random drift factor
    
    // If drift is high, we consider the answer inconsistent (simulated failure)
    const isConsistent = simulatedDrift > 0.2; 

    return {
      isValid: isConsistent,
      score: isConsistent ? 0.95 : 0.1,
      error: isConsistent ? undefined : "Answer is inconsistent across multiple reasoning paths"
    };
  }
}

// ==========================================
// 5. LANGGRAPH PIPELINE ORCHESTRATION
// ==========================================

/**
 * Orchestrates the guardrails using a Cyclical Graph Structure.
 * This allows for iterative refinement if a validation fails (e.g., asking the LLM to retry).
 */
class GuardrailPipeline {
  private validators: GuardrailValidator<any>[] = [];

  addValidator(validator: GuardrailValidator<any>) {
    this.validators.push(validator);
  }

  /**
   * Executes the pipeline. 
   * Returns the validated output or throws a detailed error.
   */
  async execute<T>(data: T): Promise<T> {
    console.log(`🚀 Starting Guardrail Pipeline with ${this.validators.length} validators...`);
    
    for (const validator of this.validators) {
      const result = await validator.validate(data);
      
      if (!result.isValid) {
        console.error(`❌ Guardrail Failed: [${validator.name}] - ${result.error}`);
        
        // TRIGGER FALLBACK MECHANISM
        // In a real app, this would return a specific "I don't know" response object.
        throw new Error(`Guardrail Violation: ${result.error}`);
      }
      console.log(`✅ Passed: [${validator.name}] (Score: ${result.score})`);
    }

    return data;
  }
}

// ==========================================
// 6. NEXT.JS API HANDLER (MAIN ENTRY)
// ==========================================

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  // --- Step 1: Setup Pipeline ---
  const pipeline = new GuardrailPipeline();
  
  // We add validators in order of execution.
  // 1. Schema Validation (Fastest, deterministic)
  pipeline.addValidator(new SchemaValidator());
  
  // 2. Faithfulness Check (Requires context comparison)
  // Note: We pass a partial object here; the validator extracts what it needs.
  pipeline.addValidator(new FaithfulnessValidator() as any);
  
  // 3. Consistency Check (Expensive, simulated)
  pipeline.addValidator(new ConsistencyValidator() as any);

  // --- Step 2: Simulate RAG Retrieval & Generation ---
  const { question } = req.body;
  
  // Mock Retrieved Context (from Vector DB)
  const retrievedContext = "The sky is blue due to Rayleigh scattering. The ocean reflects this color.";
  
  // Mock LLM Generation (Structured Output)
  const llmOutput: LLMOutput = {
    answer: "The sky appears blue because of Rayleigh scattering, which affects the scattering of light in the atmosphere.",
    citations: ["Physics Textbook Vol 1"],
    confidence: 0.85,
  };

  // --- Step 3: Execute Guardrails ---
  try {
    // Combine data for validators that need multiple fields
    const validationData = {
      ...llmOutput,
      context: retrievedContext,
      question: question
    };

    // Run the cyclical graph logic (simplified here as a linear pipeline)
    const validatedOutput = await pipeline.execute(validationData);

    // --- Step 4: Fallback Logic (If execution succeeds) ---
    // If confidence is too low despite passing checks, trigger fallback.
    if (validatedOutput.confidence < 0.5) {
        return res.status(200).json({
            response: "I am not confident enough to answer that. Please consult a human agent.",
            source: "fallback"
        });
    }

    return res.status(200).json({
      response: validatedOutput.answer,
      citations: validatedOutput.citations,
      source: "validated_rag"
    });

  } catch (error) {
    // --- Step 5: Fallback Logic (If guardrails fail) ---
    console.error("Pipeline Execution Failed:", error);
    
    // Return a safe "I don't know" response to prevent hallucination leakage
    return res.status(200).json({
      response: "I couldn't find a verified answer in my documentation. Please try rephrasing your question.",
      source: "guardrail_fallback"
    });
  }
}
