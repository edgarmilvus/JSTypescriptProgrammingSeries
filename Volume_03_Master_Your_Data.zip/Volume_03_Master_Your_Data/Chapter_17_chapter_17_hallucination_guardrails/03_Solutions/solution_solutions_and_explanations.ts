/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

import { z } from "zod";

// 1. Define the Schema using Zod
const ResponseSchema = z.object({
  summary: z.string().max(500, "Summary must be 500 characters or less."),
  confidence: z.number().min(0).max(1, "Confidence must be between 0 and 1."),
  sources: z.array(
    z.object({
      title: z.string(),
      url: z.string().url("Source URL must be valid."),
    })
  ),
});

// Infer the TypeScript type for type safety
type ResponseType = z.infer<typeof ResponseSchema>;

// 2. Implement the Validator Function
async function validateResponse(llmOutput: string): Promise<{
  isValid: boolean;
  errors?: string[];
  parsedData?: ResponseType;
}> {
  try {
    // Attempt to parse the raw string as JSON
    const parsedJson = JSON.parse(llmOutput);

    // Validate the parsed object against the Zod schema
    const result = ResponseSchema.safeParse(parsedJson);

    if (result.success) {
      return {
        isValid: true,
        parsedData: result.data,
      };
    } else {
      // Map Zod formatting errors to a clean string array
      const errorMessages = result.error.errors.map(
        (err) => `${err.path.join(".")}: ${err.message}`
      );
      return {
        isValid: false,
        errors: errorMessages,
      };
    }
  } catch (error) {
    // Handle JSON parsing errors specifically
    return {
      isValid: false,
      errors: ["Invalid JSON format: " + (error as Error).message],
    };
  }
}

// Example Usage
const llmOutput = `{
  "summary": "The capital of France is Paris.",
  "confidence": 0.95,
  "sources": [
    { "title": "Wikipedia: France", "url": "https://en.wikipedia.org/wiki/France" }
  ]
}`;

validateResponse(llmOutput).then(console.log);
