/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

// Mock embedding generator (simulated for the exercise)
async function generateEmbedding(text: string): Promise<number[]> {
  // In a real app, this would call an API like OpenAI or a local model
  // Returning a dummy vector of size 5 for demonstration
  return Array.from({ length: 5 }, () => Math.random());
}

// 1. Cosine Similarity Calculation
function calculateCosineSimilarity(vecA: number[], vecB: number[]): number {
  if (vecA.length !== vecB.length) {
    throw new Error("Vectors must be the same length");
  }

  let dotProduct = 0;
  let normA = 0;
  let normB = 0;

  for (let i = 0; i < vecA.length; i++) {
    dotProduct += vecA[i] * vecB[i];
    normA += vecA[i] * vecA[i];
    normB += vecB[i] * vecB[i];
  }

  if (normA === 0 || normB === 0) return 0; // Handle zero vectors
  return dotProduct / (Math.sqrt(normA) * Math.sqrt(normB));
}

// 2. Threshold-Based Guardrail
async function checkContextRelevance(
  context: string,
  answer: string,
  threshold: number = 0.7
): Promise<{ isRelevant: boolean; score: number }> {
  // Handle edge cases for empty input
  if (!context.trim() || !answer.trim()) {
    return { isRelevant: false, score: 0 };
  }

  // Generate embeddings for both inputs
  const [contextEmbedding, answerEmbedding] = await Promise.all([
    generateEmbedding(context),
    generateEmbedding(answer),
  ]);

  // Calculate the similarity score
  const score = calculateCosineSimilarity(contextEmbedding, answerEmbedding);

  // Determine relevance based on threshold
  return {
    isRelevant: score >= threshold,
    score: score,
  };
}

// Example Usage
const context = "Paris is the capital of France and has the Eiffel Tower.";
const answer = "Paris is the capital of France.";

checkContextRelevance(context, answer).then((result) => {
  console.log(`Score: ${result.score}, Relevant: ${result.isRelevant}`);
});
