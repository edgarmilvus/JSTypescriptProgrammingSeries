/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

interface RetrievedDoc {
  content: string;
  score: number; // Retrieval relevance score from vector DB
}

// 1. Context Quality Metric
function calculateContextQuality(retrievedDocs: Array<RetrievedDoc>): number {
  if (!retrievedDocs || retrievedDocs.length === 0) {
    return 0;
  }

  // Calculate a weighted average of retrieval scores.
  // We also factor in content length to penalize empty or very short chunks.
  const totalScore = retrievedDocs.reduce((sum, doc) => {
    const lengthFactor = Math.min(doc.content.length / 100, 1); // Cap at 1.0 for long docs
    return sum + (doc.score * lengthFactor);
  }, 0);

  return totalScore / retrievedDocs.length;
}

// 2. Fallback Response Generator
function generateFallbackResponse(query: string): string {
  return `I couldn't find specific information regarding "${query}" in the provided documents. Please try refining your query.`;
}

// 3. Decision Logic & Integration
async function processQuery(
  query: string,
  retrievedDocs: Array<RetrievedDoc>,
  qualityThreshold: number = 0.5
): Promise<string> {
  // Step A: Calculate quality
  const qualityScore = calculateContextQuality(retrievedDocs);

  // Step B: Decision Gate
  if (qualityScore < qualityThreshold) {
    // Trigger fallback mechanism
    console.warn(`Context quality (${qualityScore}) below threshold. Triggering fallback.`);
    return generateFallbackResponse(query);
  }

  // Step C: Proceed with LLM Generation (Simulated)
  // In a real app, this is where you would call the LLM API
  return `[LLM Generated Answer based on high-quality context: ${query}]`;
}

// Example Usage
const docs = [
  { content: "Paris is the capital.", score: 0.85 },
  { content: "The Eiffel Tower is tall.", score: 0.72 }
];

const lowQualityDocs = [
    { content: "Random text.", score: 0.1 }
];

processQuery("What is the capital of France?", docs).then(console.log); // Generates answer
processQuery("Quantum Physics", lowQualityDocs).then(console.log); // Returns fallback
