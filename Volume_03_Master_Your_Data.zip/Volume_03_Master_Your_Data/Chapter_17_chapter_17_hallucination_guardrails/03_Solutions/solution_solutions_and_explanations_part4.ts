/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

// Mock LLM generator
async function generateAnswer(query: string, promptTemplate: string): Promise<string> {
  // Simulating LLM behavior: 
  // For the sake of the exercise, let's assume the LLM gives consistent answers
  // for "Paris", but potentially inconsistent ones for ambiguous queries.
  if (query.includes("Paris")) {
    return "Paris is the capital of France.";
  }
  return "I am not sure about that."; // Simulated inconsistency
}

// 1. Consistency Comparison (Using a simple semantic check via embeddings)
async function compareAnswers(answer1: string, answer2: string): Promise<number> {
  // Reusing the logic from Exercise 2 for semantic similarity
  // In a real app, we would use embeddings. Here we use a mock similarity.
  
  // Simple normalization for demonstration:
  const normalize = (s: string) => s.toLowerCase().replace(/[^\w\s]/g, '');
  const s1 = normalize(answer1);
  const s2 = normalize(answer2);

  if (s1 === s2) return 1.0;
  
  // Simple overlap heuristic for the exercise (in production, use embedding cosine similarity)
  const words1 = new Set(s1.split(' '));
  const words2 = new Set(s2.split(' '));
  const intersection = new Set([...words1].filter(x => words2.has(x)));
  const union = new Set([...words1, ...words2]);
  
  return intersection.size / union.size;
}

// 2. Consensus Logic
async function checkConsensus(
  query: string,
  similarityThreshold: number = 0.8
): Promise<{ isConsistent: boolean; confidence: number }> {
  
  const promptTemplate1 = (q: string) => `Answer concisely: ${q}`;
  const promptTemplate2 = (q: string) => `Provide a detailed explanation for: ${q}`;

  // Generate two answers
  const [answer1, answer2] = await Promise.all([
    generateAnswer(query, promptTemplate1),
    generateAnswer(query, promptTemplate2),
  ]);

  // Compare them
  const similarityScore = await compareAnswers(answer1, answer2);

  return {
    isConsistent: similarityScore >= similarityThreshold,
    confidence: similarityScore,
  };
}

// Example Usage
checkConsensus("What is the capital of France?").then((result) => {
  console.log(`Consistency Score: ${result.confidence}, Consistent: ${result.isConsistent}`);
});
