/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.tsx
// Description: Solutions and Explanations
// ==========================================

import React from 'react';

// 1. Define the Props Interface
interface GuardrailProps {
  answer: string;
  validationStatus: { isValid: boolean; errors?: string[] };
  relevanceScore: number;
  consistencyScore?: number;
  isLoading: boolean;
}

// Constants for thresholds
const RELEVANCE_THRESHOLD = 0.7;
const CONSISTENCY_THRESHOLD = 0.8;

export const GuardrailResultDisplay: React.FC<GuardrailProps> = ({
  answer,
  validationStatus,
  relevanceScore,
  consistencyScore,
  isLoading,
}) => {
  // 2. State & Logic Calculations
  
  // Determine overall safety status
  const isRelevant = relevanceScore >= RELEVANCE_THRESHOLD;
  const isConsistent = consistencyScore !== undefined && consistencyScore >= CONSISTENCY_THRESHOLD;
  const allChecksPass = validationStatus.isValid && isRelevant && (consistencyScore === undefined || isConsistent);

  // 3. Conditional Rendering
  
  // Loading State
  if (isLoading) {
    return (
      <div className="guardrail-container loading">
        <div className="spinner">Analyzing response safety...</div>
      </div>
    );
  }

  // Failure State (Validation or Relevance)
  if (!allChecksPass) {
    return (
      <div className="guardrail-container warning">
        <h3 style={{ color: '#d9534f' }}>⚠️ Guardrail Check Failed</h3>
        
        {!validationStatus.isValid && (
          <div>
            <strong>Validation Errors:</strong>
            <ul>
              {validationStatus.errors?.map((err, idx) => (
                <li key={idx}>{err}</li>
              ))}
            </ul>
          </div>
        )}

        {!isRelevant && (
          <div>
            <strong>Context Relevance Low:</strong>
            <p>Score: {relevanceScore.toFixed(2)} (Threshold: {RELEVANCE_THRESHOLD})</p>
            <p>The answer may not be supported by the retrieved documents.</p>
          </div>
        )}

        {consistencyScore !== undefined && !isConsistent && (
           <div>
            <strong>Inconsistent Output:</strong>
            <p>Score: {consistencyScore.toFixed(2)} (Threshold: {CONSISTENCY_THRESHOLD})</p>
           </div>
        )}
      </div>
    );
  }

  // Success State
  return (
    <div className="guardrail-container success">
      <div className="answer-display">
        <h3>Response</h3>
        <p>{answer}</p>
      </div>
      
      <div className="metrics" style={{ marginTop: '1rem', fontSize: '0.85rem', color: '#555' }}>
        <span>✅ Validated </span> | 
        <span> Relevance: {(relevanceScore * 100).toFixed(0)}% </span>
        {consistencyScore !== undefined && (
          <span> | Consistency: {(consistencyScore * 100).toFixed(0)}%</span>
        )}
      </div>
    </div>
  );
};

// Example Usage (for context)
/*
const App = () => {
  return (
    <GuardrailResultDisplay 
      answer="Paris is the capital of France."
      validationStatus={{ isValid: true, errors: [] }}
      relevanceScore={0.92}
      consistencyScore={0.88}
      isLoading={false}
    />
  );
};
*/
