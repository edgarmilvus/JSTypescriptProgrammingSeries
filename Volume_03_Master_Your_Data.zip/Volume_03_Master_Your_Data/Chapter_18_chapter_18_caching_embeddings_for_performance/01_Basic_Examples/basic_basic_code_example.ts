/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * EMBEDDING CACHE DEMO (SaaS Context)
 * 
 * Objective: Demonstrate a basic in-memory cache for text embeddings 
 * to reduce latency and API costs in a Node.js backend.
 * 
 * Architecture:
 * - Input: User Query String
 * - Processing: Check Map -> Generate Embedding (Simulated) -> Store in Map
 * - Output: Float32Array (Vector)
 */

// ============================================================================
// 1. TYPE DEFINITIONS
// ============================================================================

/**
 * Represents a text embedding vector.
 * In a real scenario, this would be an array of 1536 dimensions (OpenAI) or 768 (BGE).
 */
type EmbeddingVector = Float32Array;

/**
 * Cache configuration interface.
 */
interface CacheConfig {
    maxSize: number; // Maximum number of items to store
    ttl: number;     // Time to live in milliseconds (e.g., 1 hour)
}

/**
 * Cache entry structure to store the vector and metadata for eviction.
 */
interface CacheEntry {
    vector: EmbeddingVector;
    timestamp: number;
}

// ============================================================================
// 2. THE EMBEDDING CACHE CLASS
// ============================================================================

class EmbeddingCache {
    private cache: Map<string, CacheEntry>;
    private config: CacheConfig;

    constructor(config: CacheConfig) {
        this.cache = new Map();
        this.config = config;
    }

    /**
     * Generates a unique key for the cache based on the input text.
     * In production, this should be a hash (e.g., SHA-256) of the normalized text.
     * For this demo, we use the text itself as the key.
     * 
     * @param text - The input string to hash/key.
     * @returns A string key.
     */
    private generateKey(text: string): string {
        // Normalize text to ensure "Hello" and "hello " hit the same cache entry
        return text.trim().toLowerCase();
    }

    /**
     * Checks if a valid entry exists in the cache.
     * Handles TTL (Time To Live) expiration.
     * 
     * @param key - The cache key.
     * @returns The vector if valid, otherwise null.
     */
    public get(key: string): EmbeddingVector | null {
        const entry = this.cache.get(key);

        if (!entry) {
            console.log(`[Cache] MISS for key: "${key}"`);
            return null;
        }

        // Check TTL
        const now = Date.now();
        if (now - entry.timestamp > this.config.ttl) {
            console.log(`[Cache] EXPIRED for key: "${key}"`);
            this.cache.delete(key); // Clean up expired entry
            return null;
        }

        console.log(`[Cache] HIT for key: "${key}"`);
        return entry.vector;
    }

    /**
     * Stores a new vector in the cache.
     * Implements a simple LRU eviction if the cache exceeds maxSize.
     * 
     * @param key - The cache key.
     * @param vector - The embedding vector.
     */
    public set(key: string, vector: EmbeddingVector): void {
        // Check capacity and evict oldest if necessary (Simplified LRU)
        if (this.cache.size >= this.config.maxSize) {
            const firstKey = this.cache.keys().next().value;
            this.cache.delete(firstKey);
            console.log(`[Cache] EVICTED oldest entry to make space.`);
        }

        this.cache.set(key, {
            vector: vector,
            timestamp: Date.now()
        });
        console.log(`[Cache] STORED key: "${key}"`);
    }

    /**
     * Returns cache statistics.
     */
    public getStats() {
        return {
            size: this.cache.size,
            capacity: this.config.maxSize
        };
    }
}

// ============================================================================
// 3. SIMULATED EMBEDDING SERVICE
// ============================================================================

/**
 * Mocks an external API call (e.g., OpenAI, Pinecone Inference).
 * Simulates network latency and vector generation.
 */
class MockEmbeddingModel {
    async generate(text: string): Promise<EmbeddingVector> {
        // Simulate network delay (100ms - 300ms)
        const delay = Math.random() * 200 + 100;
        await new Promise(resolve => setTimeout(resolve, delay));

        // Generate a dummy vector (e.g., 3 dimensions for brevity)
        // In reality: 1536 dims for text-embedding-ada-002
        const vector = new Float32Array([Math.random(), Math.random(), Math.random()]);
        return vector;
    }
}

// ============================================================================
// 4. MAIN PIPELINE (The "Hello World" Logic)
// ============================================================================

/**
 * Orchestrates the retrieval of embeddings with caching logic.
 * 
 * @param text - User input.
 * @param cache - Instance of EmbeddingCache.
 * @param model - Instance of MockEmbeddingModel.
 * @returns The embedding vector.
 */
async function getEmbeddingWithCache(
    text: string, 
    cache: EmbeddingCache, 
    model: MockEmbeddingModel
): Promise<EmbeddingVector> {
    // 1. Normalize and generate key
    const key = text.trim().toLowerCase();

    // 2. Check Cache
    const cachedVector = cache.get(key);
    if (cachedVector) {
        return cachedVector;
    }

    // 3. Cache Miss: Call External Model
    console.log(`[System] Generating new embedding for: "${text}"...`);
    const newVector = await model.generate(text);

    // 4. Store in Cache
    cache.set(key, newVector);

    return newVector;
}

// ============================================================================
// 5. EXECUTION SIMULATION
// ============================================================================

async function runDemo() {
    console.log("--- SaaS RAG Pipeline: Embedding Cache Demo ---\n");

    // Initialize dependencies
    const cache = new EmbeddingCache({ maxSize: 3, ttl: 60000 }); // 1 minute TTL
    const model = new MockEmbeddingModel();

    // Scenario 1: First request (Cache Miss)
    console.log("1. User sends query: 'What is RAG?'");
    const vec1 = await getEmbeddingWithCache("What is RAG?", cache, model);
    console.log(`   Result: [${vec1[0].toFixed(2)}, ${vec1[1].toFixed(2)}, ...]\n`);

    // Scenario 2: Identical request (Cache Hit)
    console.log("2. User sends same query: 'What is RAG?'");
    const vec2 = await getEmbeddingWithCache("What is RAG?", cache, model);
    console.log(`   Result: [${vec2[0].toFixed(2)}, ${vec2[1].toFixed(2)}, ...]\n`);

    // Scenario 3: Different request (Cache Miss)
    console.log("3. User sends query: 'How does caching work?'");
    const vec3 = await getEmbeddingWithCache("How does caching work?", cache, model);
    console.log(`   Result: [${vec3[0].toFixed(2)}, ${vec3[1].toFixed(2)}, ...]\n`);

    // Scenario 4: Check Stats
    console.log("4. Cache Statistics:", cache.getStats());
}

// Run the simulation
runDemo().catch(console.error);
