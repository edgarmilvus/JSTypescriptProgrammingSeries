/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// File: app/api/chat/advanced-caching/route.ts
// Purpose: Demonstrates a multi-layer caching strategy for embeddings in a Next.js RAG pipeline.

import { NextResponse } from 'next/server';
import NodeCache from 'node-cache'; // In-memory LRU cache
import Redis from 'ioredis'; // Persistent distributed cache
import crypto from 'crypto';
import fs from 'fs/promises';
import path from 'path';

// ==========================================
// 1. CONFIGURATION & TYPES
// ==========================================

/**
 * Configuration for the caching layers.
 * In production, these would be environment variables.
 */
const CACHE_CONFIG = {
  // In-memory cache TTL (Time To Live) in seconds
  MEMORY_TTL: 3600, 
  // Redis TTL in seconds
  REDIS_TTL: 86400, 
  // File cache directory
  FILE_CACHE_DIR: path.join(process.cwd(), '.cache/embeddings'),
  // Current model identifier to detect drift
  MODEL_ID: 'text-embedding-3-small-v2',
};

/**
 * Represents the structure of a cached embedding entry.
 */
interface CachedEmbedding {
  embedding: number[];
  model: string;
  checksum: string;
  timestamp: number;
}

// ==========================================
// 2. SERVICE WORKER ASSET CACHING (Client-Side)
// ==========================================

/**
 * SW_PRECACHE_MANIFEST
 * This object simulates the build-time generation of a Service Worker precache manifest.
 * It instructs the SW to cache critical AI assets (like quantized model weights)
 * during the install phase for instant loading and offline capability.
 */
const SW_PRECACHE_MANIFEST = [
  {
    url: '/models/text-embedding-3-small-quantized.onnx',
    revision: 'a1b2c3d4', // Hash of the file content
    size: '45MB',
    type: 'model',
    priority: 'high',
  },
  {
    url: '/wasm/backends/webgl.wasm',
    revision: 'e5f6g7h8',
    size: '2MB',
    type: 'runtime',
    priority: 'high',
  },
];

/**
 * Generates a Service Worker script string.
 * In a real app, this is injected during the build process.
 */
function getServiceWorkerScript(): string {
  return `
    const CACHE_NAME = 'ai-assets-v1';
    const PRECACHE_MANIFEST = ${JSON.stringify(SW_PRECACHE_MANIFEST)};

    self.addEventListener('install', (event) => {
      console.log('[SW] Installing Service Worker...');
      event.waitUntil(
        caches.open(CACHE_NAME).then((cache) => {
          const urlsToCache = PRECACHE_MANIFEST.map(item => item.url);
          return cache.addAll(urlsToCache);
        })
      );
    });

    self.addEventListener('fetch', (event) => {
      // Strategy: Cache First for Model Weights
      if (event.request.url.includes('/models/') || event.request.url.includes('/wasm/')) {
        event.respondWith(
          caches.match(event.request).then((response) => {
            if (response) {
              return response; // Return cached asset immediately
            }
            return fetch(event.request).then((response) => {
              // Clone and cache the fresh response
              if (response.ok) {
                const responseClone = response.clone();
                caches.open(CACHE_NAME).then((cache) => {
                  cache.put(event.request, responseClone);
                });
              }
              return response;
            });
          })
        );
      }
    });
  `;
}

// ==========================================
// 3. CACHE LAYER IMPLEMENTATIONS
// ==========================================

/**
 * Layer 1: In-Memory Cache (Node.js Map)
 * Ultra-fast, ephemeral, per-instance.
 * Ideal for high-frequency requests within the same server instance.
 */
class MemoryCache {
  private cache: NodeCache;

  constructor(ttlSeconds: number) {
    // Using stdTTL for automatic expiration and checkperiod for cleanup
    this.cache = new NodeCache({ stdTTL: ttlSeconds, checkperiod: 120 });
  }

  /**
   * Retrieves an embedding from memory.
   * @param key - The cache key (usually content hash).
   * @returns The embedding array or null.
   */
  get(key: string): number[] | undefined {
    return this.cache.get<number[]>(key);
  }

  /**
   * Sets an embedding in memory.
   */
  set(key: string, value: number[]): void {
    this.cache.set(key, value);
  }
}

/**
 * Layer 2: Persistent Cache (Redis)
 * Distributed, survives server restarts.
 * Essential for multi-instance deployments (e.g., Vercel Lambdas).
 */
class RedisCache {
  private client: Redis;

  constructor() {
    // Connect to local Redis or Upstash/Redis Cloud in production
    this.client = new Redis(process.env.REDIS_URL || 'redis://localhost:6379');
  }

  async get(key: string): Promise<number[] | null> {
    try {
      const data = await this.client.get(key);
      return data ? JSON.parse(data) : null;
    } catch (error) {
      console.error('Redis connection error:', error);
      return null;
    }
  }

  async set(key: string, value: number[]): Promise<void> {
    try {
      await this.client.set(key, JSON.stringify(value), 'EX', CACHE_CONFIG.REDIS_TTL);
    } catch (error) {
      console.error('Redis set error:', error);
    }
  }
}

/**
 * Layer 3: File-Based Cache with Checksums
 * Handles Model Drift and Versioning.
 * If the embedding model changes, the checksum changes, invalidating old caches.
 */
class FileCache {
  private basePath: string;

  constructor(basePath: string) {
    this.basePath = basePath;
    this.ensureDir();
  }

  private async ensureDir() {
    try {
      await fs.mkdir(this.basePath, { recursive: true });
    } catch (e) {
      // Directory likely exists
    }
  }

  /**
   * Generates a deterministic key based on content and model version.
   */
  private generateKey(content: string, modelId: string): string {
    const hash = crypto.createHash('md5').update(content).digest('hex');
    return `${modelId}_${hash}.json`;
  }

  /**
   * Retrieves from file system if checksum matches current model.
   */
  async get(content: string): Promise<number[] | null> {
    const key = this.generateKey(content, CACHE_CONFIG.MODEL_ID);
    const filePath = path.join(this.basePath, key);

    try {
      const data = await fs.readFile(filePath, 'utf-8');
      const parsed: CachedEmbedding = JSON.parse(data);
      
      // Verify model version hasn't drifted
      if (parsed.model === CACHE_CONFIG.MODEL_ID) {
        return parsed.embedding;
      }
      return null;
    } catch (error) {
      return null;
    }
  }

  /**
   * Saves to file system with metadata for drift detection.
   */
  async set(content: string, embedding: number[]): Promise<void> {
    const key = this.generateKey(content, CACHE_CONFIG.MODEL_ID);
    const filePath = path.join(this.basePath, key);

    const entry: CachedEmbedding = {
      embedding,
      model: CACHE_CONFIG.MODEL_ID,
      checksum: key.split('_')[1], // Extract hash
      timestamp: Date.now(),
    };

    await fs.writeFile(filePath, JSON.stringify(entry));
  }
}

// ==========================================
// 4. ORCHESTRATOR & API ROUTE
// ==========================================

// Initialize Layers
const memoryCache = new MemoryCache(CACHE_CONFIG.MEMORY_TTL);
const redisCache = new RedisCache();
const fileCache = new FileCache(CACHE_CONFIG.FILE_CACHE_DIR);

/**
 * Simulates the expensive OpenAI embedding call.
 * In production, this would be `openai.embeddings.create`.
 */
async function generateEmbedding(text: string): Promise<number[]> {
  // Simulate network latency
  await new Promise(resolve => setTimeout(resolve, 200)); 
  // Return dummy vector (e.g., 1536 dimensions for text-embedding-3-small)
  return Array(1536).fill(0).map(() => Math.random());
}

/**
 * The Core Logic: Multi-Layer Cache Lookup Strategy
 * 1. Check Memory (fastest)
 * 2. Check Redis (fast, distributed)
 * 3. Check File System (persistent, handles drift)
 * 4. Generate & Backfill (slowest)
 */
async function getOrComputeEmbedding(text: string): Promise<number[]> {
  const cacheKey = crypto.createHash('md5').update(text).digest('hex');

  // 1. Memory Layer
  const memHit = memoryCache.get(cacheKey);
  if (memHit) {
    console.log(`[Cache] Memory Hit: ${cacheKey.substring(0, 8)}...`);
    return memHit;
  }

  // 2. Redis Layer
  const redisHit = await redisCache.get(cacheKey);
  if (redisHit) {
    console.log(`[Cache] Redis Hit: ${cacheKey.substring(0, 8)}...`);
    // Backfill memory cache for next time
    memoryCache.set(cacheKey, redisHit);
    return redisHit;
  }

  // 3. File System Layer (Checksum validated)
  const fileHit = await fileCache.get(text);
  if (fileHit) {
    console.log(`[Cache] File Hit: ${cacheKey.substring(0, 8)}...`);
    // Backfill upper layers
    memoryCache.set(cacheKey, fileHit);
    await redisCache.set(cacheKey, fileHit);
    return fileHit;
  }

  // 4. Cache Miss: Compute
  console.log(`[Cache] Miss: Generating embedding for ${text.substring(0, 20)}...`);
  const embedding = await generateEmbedding(text);

  // Backfill all layers
  memoryCache.set(cacheKey, embedding);
  await redisCache.set(cacheKey, embedding);
  await fileCache.set(text, embedding);

  return embedding;
}

/**
 * Next.js API Route Handler
 */
export async function POST(request: Request) {
  try {
    const { text } = await request.json();

    if (!text) {
      return NextResponse.json({ error: 'Text is required' }, { status: 400 });
    }

    const startTime = performance.now();
    const embedding = await getOrComputeEmbedding(text);
    const duration = performance.now() - startTime;

    return NextResponse.json({
      success: true,
      data: {
        embeddingLength: embedding.length,
        latencyMs: Math.round(duration),
        model: CACHE_CONFIG.MODEL_ID,
      },
    });

  } catch (error) {
    console.error('API Error:', error);
    return NextResponse.json({ error: 'Internal Server Error' }, { status: 500 });
  }
}

/**
 * Utility Endpoint: Get Service Worker Config
 * Used by the client to register the SW.
 */
export async function GET() {
  return NextResponse.json({
    swScript: getServiceWorkerScript(),
    precache: SW_PRECACHE_MANIFEST,
  });
}
