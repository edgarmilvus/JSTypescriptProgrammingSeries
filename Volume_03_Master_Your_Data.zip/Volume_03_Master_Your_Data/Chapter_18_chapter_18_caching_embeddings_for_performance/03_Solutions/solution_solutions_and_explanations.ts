/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

/**
 * Represents a node in the doubly linked list for LRU tracking.
 */
class DLinkedNode {
    key: string;
    value: number[];
    prev: DLinkedNode | null;
    next: DLinkedNode | null;
    expiresAt: number | null; // Timestamp in ms for expiration

    constructor(key: string, value: number[], expiresAt: number | null) {
        this.key = key;
        this.value = value;
        this.prev = null;
        this.next = null;
        this.expiresAt = expiresAt;
    }
}

export class EmbeddingCache {
    private capacity: number;
    private cache: Map<string, DLinkedNode>;
    private head: DLinkedNode; // Dummy head (LRU: most recently used)
    private tail: DLinkedNode; // Dummy tail (LRU: least recently used)

    constructor(maxSize: number) {
        this.capacity = maxSize;
        this.cache = new Map();
        // Initialize dummy head and tail
        this.head = new DLinkedNode('dummy-head', [], null);
        this.tail = new DLinkedNode('dummy-tail', [], null);
        this.head.next = this.tail;
        this.tail.prev = this.head;
    }

    /**
     * Helper to remove a node from the linked list.
     */
    private removeNode(node: DLinkedNode): void {
        const prev = node.prev!;
        const next = node.next!;
        prev.next = next;
        next.prev = prev;
    }

    /**
     * Helper to add a node right after the head (most recently used).
     */
    private addToHead(node: DLinkedNode): void {
        node.prev = this.head;
        node.next = this.head.next;
        this.head.next!.prev = node;
        this.head.next = node;
    }

    /**
     * Helper to move an existing node to the head (updates usage).
     */
    private moveToHead(node: DLinkedNode): void {
        this.removeNode(node);
        this.addToHead(node);
    }

    /**
     * Helper to remove the tail node (least recently used) and return its key.
     */
    private popTail(): DLinkedNode | null {
        const res = this.tail.prev;
        if (res === this.head) return null; // Cache is empty
        this.removeNode(res!);
        return res;
    }

    /**
     * Checks if an item is expired based on current time.
     */
    private isExpired(node: DLinkedNode): boolean {
        if (node.expiresAt === null) return false;
        return Date.now() > node.expiresAt;
    }

    /**
     * Retrieves an item. Returns null if not found or expired.
     * Updates the item's position to most recently used.
     */
    get(key: string): number[] | null {
        const node = this.cache.get(key);
        
        if (!node) return null;

        // Check TTL expiration
        if (this.isExpired(node)) {
            this.cache.delete(key);
            this.removeNode(node);
            return null;
        }

        // Move to head (mark as recently used)
        this.moveToHead(node);
        return node.value;
    }

    /**
     * Stores an item. Evicts LRU item if capacity is reached.
     * Optional TTL: time in milliseconds until expiration.
     */
    set(key: string, value: number[], ttlMs?: number): void {
        let node = this.cache.get(key);

        // If key exists, update value and move to head
        if (node) {
            node.value = value;
            // Update TTL if provided, otherwise keep existing or null
            node.expiresAt = ttlMs ? Date.now() + ttlMs : node.expiresAt;
            this.moveToHead(node);
            return;
        }

        // If key doesn't exist, create new node
        const expiresAt = ttlMs ? Date.now() + ttlMs : null;
        const newNode = new DLinkedNode(key, value, expiresAt);

        // Check capacity
        if (this.cache.size >= this.capacity) {
            // Evict LRU (tail)
            const tailNode = this.popTail();
            if (tailNode) {
                this.cache.delete(tailNode.key);
            }
        }

        this.cache.set(key, newNode);
        this.addToHead(newNode);
    }

    /**
     * Checks existence without updating usage or returning value.
     * Returns false if expired.
     */
    has(key: string): boolean {
        const node = this.cache.get(key);
        if (!node) return false;
        if (this.isExpired(node)) {
            // Clean up expired item
            this.cache.delete(key);
            this.removeNode(node);
            return false;
        }
        return true;
    }
}

// --- Usage Example ---
/*
const cache = new EmbeddingCache(2); // Max size 2

cache.set('key1', [1, 2, 3], 5000); // TTL 5s
cache.set('key2', [4, 5, 6]);

console.log(cache.get('key1')); // Returns [1,2,3], moves to head

cache.set('key3', [7, 8, 9]); // Evicts key2 (LRU)

console.log(cache.get('key2')); // Returns null (evicted)

// Wait 5 seconds...
// console.log(cache.get('key1')); // Returns null (expired)
*/
