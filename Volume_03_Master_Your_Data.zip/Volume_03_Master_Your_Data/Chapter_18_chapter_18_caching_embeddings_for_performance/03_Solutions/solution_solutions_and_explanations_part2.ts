/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

import Redis from 'ioredis'; // Assuming ioredis is installed

// Mock Redis client setup
const redis = new Redis({
    host: 'localhost',
    port: 6379,
    // disable offline queue for simple demo purposes
    enableOfflineQueue: false 
});

/**
 * Generates a deterministic cache key based on text, model, and version.
 * Normalizes text by trimming whitespace and lowercasing.
 */
function generateCacheKey(text: string, model: string, version: string): string {
    const normalizedText = text.trim().toLowerCase();
    // In production, use a hash (e.g., SHA-256) of the text to keep keys short.
    // Here we use a simple template string for clarity.
    return `embedding:${version}:${model}:${Buffer.from(normalizedText).toString('base64')}`;
}

/**
 * Retrieves cached embedding or computes a new one.
 * Validates model version to handle drift.
 * 
 * @param text The input text to embed.
 * @param model The model name (e.g., 'text-embedding-ada-002').
 * @param version The semantic version of the model (e.g., 'v1.0').
 * @param computeFn Async function that generates embeddings: (text: string) => Promise<number[]>
 * @returns Promise<number[]>
 */
export async function getOrComputeEmbedding(
    text: string,
    model: string,
    version: string,
    computeFn: (text: string) => Promise<number[]>
): Promise<number[]> {
    const cacheKey = generateCacheKey(text, model, version);
    
    try {
        // 1. Check Redis
        const cachedData = await redis.get(cacheKey);

        if (cachedData) {
            // 2. Parse and Validate
            const parsed = JSON.parse(cachedData);
            
            // Check for version drift (stored version vs requested version)
            if (parsed.version === version) {
                console.log(`Cache HIT for key: ${cacheKey}`);
                return parsed.embedding;
            } else {
                console.log(`Cache version mismatch. Recomputing.`);
            }
        }

        // 3. Compute (Cache Miss or Version Mismatch)
        console.log(`Cache MISS for key: ${cacheKey}`);
        const embedding = await computeFn(text);

        // 4. Store in Redis with TTL (e.g., 1 hour = 3600 seconds)
        const payload = {
            version: version,
            embedding: embedding
        };
        
        await redis.setex(cacheKey, 3600, JSON.stringify(payload));

        return embedding;

    } catch (error) {
        console.error("Redis operation failed:", error);
        // Fallback: compute directly if cache fails
        return computeFn(text);
    }
}

/**
 * Cache Warming Script
 * Pre-computes embeddings for a list of texts in parallel.
 */
export async function warmCache(
    texts: string[],
    model: string,
    version: string,
    computeFn: (text: string) => Promise<number[]>
): Promise<void> {
    console.log(`Starting cache warm-up for ${texts.length} texts...`);
    
    // Create an array of promises for parallel execution
    const promises = texts.map(text => 
        getOrComputeEmbedding(text, model, version, computeFn)
    );

    try {
        await Promise.all(promises);
        console.log("Cache warm-up complete.");
    } catch (error) {
        console.error("Cache warming failed for some items:", error);
    }
}

// --- Mock Usage Example ---
/*
const mockComputeFn = async (text: string): Promise<number[]> => {
    console.log(`[API] Computing embedding for: "${text}"`);
    return [0.1, 0.2, 0.3]; // Dummy vector
};

// Example execution
(async () => {
    const texts = ["Hello world", "AI is great", "Redis caching"];
    
    // Warm the cache
    await warmCache(texts, "ada-002", "v1.0", mockComputeFn);
    
    // Simulate API request (should hit cache)
    const result = await getOrComputeEmbedding("Hello world", "ada-002", "v1.0", mockComputeFn);
    console.log("Result:", result);
    
    redis.quit();
})();
*/
