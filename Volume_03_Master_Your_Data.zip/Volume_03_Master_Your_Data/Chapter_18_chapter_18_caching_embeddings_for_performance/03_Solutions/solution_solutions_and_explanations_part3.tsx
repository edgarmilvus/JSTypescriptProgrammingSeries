/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState, useEffect } from 'react';

interface ChatBubbleProps {
  content: string;           // Final content
  streamingContent?: string[]; // Array of chunks for streaming
  isLoading: boolean;
  isUser: boolean;
}

const ChatBubble: React.FC<ChatBubbleProps> = ({ 
  content, 
  streamingContent, 
  isLoading, 
  isUser 
}) => {
  const [displayedText, setDisplayedText] = useState("");
  const [isStreaming, setIsStreaming] = useState(false);

  // Effect for handling the typing animation
  useEffect(() => {
    // If streaming content is provided, start the animation
    if (streamingContent && streamingContent.length > 0) {
      setIsStreaming(true);
      setDisplayedText(""); // Reset text
      let currentChunkIndex = 0;
      let currentText = "";

      const typeInterval = setInterval(() => {
        if (currentChunkIndex < streamingContent.length) {
          // Append the next chunk
          currentText += streamingContent[currentChunkIndex];
          setDisplayedText(currentText);
          currentChunkIndex++;
        } else {
          // Streaming finished
          clearInterval(typeInterval);
          setIsStreaming(false);
        }
      }, 50); // 50ms delay per chunk

      return () => clearInterval(typeInterval);
    } else if (!isLoading && content) {
      // Static content (non-streaming)
      setDisplayedText(content);
    }
  }, [streamingContent, content, isLoading]);

  // Styles
  const bubbleStyle: React.CSSProperties = {
    maxWidth: '70%',
    padding: '10px 15px',
    borderRadius: '18px',
    marginBottom: '10px',
    fontFamily: 'sans-serif',
    fontSize: '14px',
    lineHeight: '1.4',
    // User vs Bot styling
    alignSelf: isUser ? 'flex-end' : 'flex-start',
    backgroundColor: isUser ? '#007bff' : '#f1f1f1',
    color: isUser ? 'white' : 'black',
    position: 'relative',
  };

  const skeletonStyle: React.CSSProperties = {
    width: '100%',
    height: '20px',
    borderRadius: '4px',
    backgroundColor: isUser ? '#4da3ff' : '#e0e0e0',
    animation: 'pulse 1.5s infinite ease-in-out',
    marginTop: '5px',
  };

  // Container for the chat bubble row
  const containerStyle: React.CSSProperties = {
    display: 'flex',
    width: '100%',
    justifyContent: isUser ? 'flex-end' : 'flex-start',
    marginBottom: '10px',
  };

  // Render Logic
  const renderContent = () => {
    if (isLoading) {
      return (
        <div style={{ display: 'flex', flexDirection: 'column', width: '100%', gap: '4px' }}>
          <div style={skeletonStyle}></div>
          <div style={{ ...skeletonStyle, width: '70%' }}></div>
        </div>
      );
    }
    
    // If we are actively streaming or have static content
    return <span>{displayedText}</span>;
  };

  return (
    <div style={containerStyle}>
      <div style={bubbleStyle}>
        {renderContent()}
      </div>
      {/* Global CSS for pulse animation would typically go in a stylesheet, 
          but included here for single-file completeness */}
      <style>{`
        @keyframes pulse {
          0% { opacity: 0.6; }
          50% { opacity: 1; }
          100% { opacity: 0.6; }
        }
      `}</style>
    </div>
  );
};

export default ChatBubble;
