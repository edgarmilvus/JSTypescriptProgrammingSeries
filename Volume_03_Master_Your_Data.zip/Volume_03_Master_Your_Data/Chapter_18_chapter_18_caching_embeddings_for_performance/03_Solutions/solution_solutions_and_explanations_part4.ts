/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

/**
 * Processes a list of inputs into embeddings using batched concurrency and rate limiting.
 * 
 * @param inputs Array of strings to embed.
 * @param batchSize Max number of items per API call.
 * @param embeddingFn Async function taking array of strings, returning array of vectors.
 * @param requestsPerSecond Rate limit (e.g., 5 req/sec).
 */
export async function batchEmbeddings(
    inputs: string[],
    batchSize: number,
    embeddingFn: (batch: string[]) => Promise<number[][]>,
    requestsPerSecond: number
): Promise<number[][]> {
    // 1. Slice inputs into chunks
    const batches: string[][] = [];
    for (let i = 0; i < inputs.length; i += batchSize) {
        batches.push(inputs.slice(i, i + batchSize));
    }

    const results: number[][] = new Array(inputs.length);
    const delayMs = 1000 / requestsPerSecond; // Calculate delay between batch starts

    // 2. Process batches with rate limiting
    // We use a loop with delays rather than Promise.all on all batches immediately
    // to strictly adhere to the rate limit.
    
    for (let i = 0; i < batches.length; i++) {
        const batch = batches[i];
        const startIndex = i * batchSize;

        // Execute the current batch
        // Note: We don't await inside the loop immediately if we want strict serialization,
        // but since we want to maximize throughput, we fire the request and then wait for the rate limit window.
        const batchPromise = embeddingFn(batch);

        // Handle the result asynchronously to not block the next request start if concurrency allows
        // However, for strict rate limiting of START times, we wait `delayMs`.
        
        batchPromise.then(batchResult => {
            // Map results back to original indices
            batchResult.forEach((vector, idx) => {
                results[startIndex + idx] = vector;
            });
        }).catch(err => {
            // In a real scenario, we might want to retry or handle partial failures
            console.error(`Batch ${i} failed:`, err);
            // Fill with null or throw depending on requirements
        });

        // Rate Limiting: Wait before starting the next batch
        // (Unless it's the last batch)
        if (i < batches.length - 1) {
            await new Promise(resolve => setTimeout(resolve, delayMs));
        }
        
        // Optional: Await the current batch completion before starting next to ensure order?
        // The requirement says "maximize throughput". 
        // If we fire and forget, we risk OOM. 
        // A balanced approach: Start batch N, wait for rate limit, Start batch N+1.
        // We should probably await the promise to ensure memory safety, 
        // but strictly speaking, the rate limiter controls the *start* time.
        // Let's await the promise to ensure we don't have unhandled promises piling up.
        await batchPromise; 
    }

    // Filter out any undefineds (though logic should prevent them) and return
    return results.filter(r => r !== undefined) as number[][];
}

// --- Mock Usage Example ---
/*
const mockEmbeddingFn = async (batch: string[]): Promise<number[][]> => {
    console.log(`Processing batch of size: ${batch.length}`);
    // Simulate network latency
    await new Promise(r => setTimeout(r, 200)); 
    return batch.map(() => [0.1, 0.2, 0.3]);
};

const texts = Array.from({ length: 15 }, (_, i) => `Document ${i + 1}`);

(async () => {
    const embeddings = await batchEmbeddings(texts, 5, mockEmbeddingFn, 2); // 2 req/sec
    console.log(`Generated ${embeddings.length} embeddings.`);
})();
*/
