/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * @fileoverview A basic 'Hello World' example of capturing user feedback in a RAG SaaS app.
 * This simulates a server-side API endpoint or a backend service function.
 */

// --- Type Definitions ---

/**
 * Represents the explicit feedback signal from a user.
 * 1 = Thumbs Up, 0 = Thumbs Down.
 */
type FeedbackSignal = 0 | 1;

/**
 * Represents a single RAG response session, linking a query, retrieved context, and the final answer.
 * In a real system, this would be an entry in a database (e.g., MongoDB, PostgreSQL).
 */
interface RagResponseSession {
  responseId: string;
  userId: string;
  query: string;
  retrievedContext: string; // The text chunks retrieved from the vector DB
  llmAnswer: string;
  feedback: FeedbackSignal | null; // Initially null until user interacts
  timestamp: Date;
}

// --- Simulated Database & Vector Store ---

/**
 * A simple in-memory store to simulate a persistent database or vector metadata store.
 * In production, this would be a connection to a vector DB (e.g., Pinecone, Weaviate) or a relational DB.
 */
const mockDatabase: Map<string, RagResponseSession> = new Map();

/**
 * Simulates the initial creation of a RAG response session before feedback is given.
 * This is what happens when a user first asks a question.
 */
function simulateRagQuery(
  userId: string,
  query: string,
  context: string,
  answer: string
): string {
  const responseId = `resp_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  const session: RagResponseSession = {
    responseId,
    userId,
    query,
    retrievedContext: context,
    llmAnswer: answer,
    feedback: null, // No feedback yet
    timestamp: new Date(),
  };
  mockDatabase.set(responseId, session);
  console.log(`[System] Created RAG Session: ${responseId}`);
  return responseId;
}

// --- Core Feedback Logic ---

/**
 * Captures user feedback and updates the metadata store.
 * 
 * @param responseId - The unique identifier for the RAG response session.
 * @param feedback - The user's signal (1 for thumbs up, 0 for thumbs down).
 * @returns A promise that resolves to the updated session object.
 * @throws Error if the response session is not found.
 */
async function captureUserFeedback(
  responseId: string,
  feedback: FeedbackSignal
): Promise<RagResponseSession> {
  // 1. Retrieve the existing session from the database.
  const session = mockDatabase.get(responseId);

  if (!session) {
    throw new Error(`Session not found for ID: ${responseId}`);
  }

  // 2. Update the session with the new feedback signal.
  // In a real system, this update operation would be atomic and transactional.
  const updatedSession: RagResponseSession = {
    ...session,
    feedback: feedback,
    // Note: We might also update a 'lastModified' timestamp here.
  };

  // 3. Persist the update back to the store.
  mockDatabase.set(responseId, updatedSession);

  // 4. Log the action for observability (e.g., sending to a logging service like Datadog or Sentry).
  console.log(
    `[Feedback Captured] Response ID: ${responseId}, Feedback: ${
      feedback === 1 ? 'Thumbs Up' : 'Thumbs Down'
    }`
  );

  // 5. (Optional) Trigger downstream processes.
  // This is where you would queue a job to update vector store metadata or 
  // send the (query, context, feedback) tuple to a training pipeline.
  await triggerDownstreamProcessing(updatedSession);

  return updatedSession;
}

/**
 * A placeholder function representing the next step in the feedback loop.
 * In production, this might:
 * - Update the vector store's metadata for the specific document chunk (e.g., increment a 'relevance_score').
 * - Send the data to a model fine-tuning queue.
 * - Update a user profile for personalization.
 */
async function triggerDownstreamProcessing(session: RagResponseSession) {
  // Simulate an async operation (e.g., API call to a vector DB or queue).
  await new Promise((resolve) => setTimeout(resolve, 100));
  console.log(`[System] Downstream processing triggered for ${session.responseId}`);
}

// --- Execution Example ---

/**
 * Main function to demonstrate the workflow.
 */
async function main() {
  console.log("--- 1. Simulating Initial RAG Query ---");
  const responseId = simulateRagQuery(
    "user_123",
    "What is the capital of France?",
    "Paris is the capital and most populous city of France.",
    "The capital of France is Paris."
  );

  console.log("\n--- 2. Simulating User Interaction (Thumbs Up) ---");
  try {
    const updatedSession = await captureUserFeedback(responseId, 1); // 1 = Thumbs Up
    console.log("\n--- Final State of Session ---");
    console.log(JSON.stringify(updatedSession, null, 2));
  } catch (error) {
    console.error("An error occurred:", error);
  }
}

// Run the example
if (require.main === module) {
  main();
}
