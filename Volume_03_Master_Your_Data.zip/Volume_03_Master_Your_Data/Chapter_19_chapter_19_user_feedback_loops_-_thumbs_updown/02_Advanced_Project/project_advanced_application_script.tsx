/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.tsx
// Description: Advanced Application Script
// ==========================================

// app/chat/page.tsx
'use server';

import React from 'react';
import { getServerSession } from 'next-auth';
import { prisma } from '@/lib/prisma'; // Assumes a Prisma client setup
import { Chat } from './components/chat';
import { generateEmbeddings } from '@/lib/ai/embeddings'; // Mocked embedding function
import { searchVectorStore } from '@/lib/vector-db'; // Mocked vector DB search

// ----------------------------------------------------------------------------
// 1. Server Component: Initial Data Fetching
// ----------------------------------------------------------------------------
// We fetch initial conversation history and user preferences directly on the server.
// This ensures the page is SEO-friendly and accessible even before hydration.
export default async function ChatPage() {
  const session = await getServerSession();
  
  if (!session?.user?.email) {
    return <div>Please log in to access the chat.</div>;
  }

  // Fetch user-specific feedback history to inform the initial retrieval strategy
  const userFeedback = await prisma.feedback.findMany({
    where: { userEmail: session.user.email },
    select: { documentId: true, rating: true },
    take: 50 // Limit to recent feedback
  });

  // Calculate a "preference vector" based on positive feedback
  // In a real scenario, this might adjust the embedding query or filter parameters
  const preferredTopics = userFeedback
    .filter(f => f.rating === 'UP')
    .map(f => f.documentId);

  return (
    <div className="flex h-screen flex-col p-4">
      <h1 className="text-2xl font-bold mb-4">Enterprise RAG Chat</h1>
      {/* Pass initial data to the client component to avoid waterfalls */}
      <Chat 
        initialHistory={[]} 
        preferredTopics={preferredTopics} 
        userEmail={session.user.email}
      />
    </div>
  );
}
