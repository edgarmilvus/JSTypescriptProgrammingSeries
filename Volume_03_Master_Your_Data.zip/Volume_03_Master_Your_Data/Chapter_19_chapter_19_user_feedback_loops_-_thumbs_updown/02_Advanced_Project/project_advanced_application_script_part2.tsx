/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script_part2.tsx
// Description: Advanced Application Script
// ==========================================

// app/chat/components/chat.tsx
'use client';

import React, { useState } from 'react';
import { useChat } from 'ai/react';
import { experimental_useOptimistic as useOptimistic } from 'react';
import { recordFeedback } from '@/app/actions/feedback'; // The Server Action

// ----------------------------------------------------------------------------
// 2. Client Component: The Conversational Interface
// ----------------------------------------------------------------------------
export function Chat({ initialHistory, preferredTopics, userEmail }: {
  initialHistory: any[];
  preferredTopics: string[];
  userEmail: string;
}) {
  // Vercel AI SDK hook for managing message state and streaming responses
  const { messages, input, handleInputChange, handleSubmit, isLoading } = useChat({
    initialMessages: initialHistory,
    body: {
      // Pass preferences to the API route to influence retrieval
      preferredTopics: preferredTopics.join(','),
    }
  });

  // State to track which messages have been rated
  const [ratings, setRatings] = useState<Record<string, 'UP' | 'DOWN'>>({});

  // Optimistic UI update for ratings
  const [optimisticRatings, addOptimisticRating] = useOptimistic(
    ratings,
    (state, { messageId, rating }: { messageId: string; rating: 'UP' | 'DOWN' }) => ({
      ...state,
      [messageId]: rating,
    })
  );

  // ----------------------------------------------------------------------------
  // 3. Feedback Handler (Client-Side Trigger)
  // ----------------------------------------------------------------------------
  const handleFeedback = async (messageId: string, rating: 'UP' | 'DOWN', documentId?: string) => {
    // 1. Optimistic Update
    addOptimisticRating({ messageId, rating });

    // 2. Server Action Execution
    try {
      await recordFeedback({
        messageId,
        rating,
        documentId, // The specific chunk that generated this response
        userEmail,
        timestamp: new Date(),
      });

      // 3. Update local state on success
      setRatings(prev => ({ ...prev, [messageId]: rating }));
    } catch (error) {
      console.error("Failed to record feedback:", error);
      // In a real app, revert optimistic update here
    }
  };

  return (
    <div className="flex flex-col h-full border rounded-lg p-4 bg-white shadow-sm">
      {/* Message List */}
      <div className="flex-1 overflow-y-auto space-y-4 mb-4">
        {messages.map((msg) => (
          <div key={msg.id} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
            <div className={`max-w-[80%] p-3 rounded-lg ${msg.role === 'user' ? 'bg-blue-100 text-blue-900' : 'bg-gray-100 text-gray-900'}`}>
              <p>{msg.content}</p>
              
              {/* Feedback UI (Only for AI responses) */}
              {msg.role === 'assistant' && (
                <div className="mt-2 flex items-center gap-2 text-sm">
                  <span className="text-gray-500">Was this helpful?</span>
                  <button 
                    onClick={() => handleFeedback(msg.id, 'UP', msg.documentId)}
                    className={`p-1 rounded hover:bg-gray-200 ${optimisticRatings[msg.id] === 'UP' ? 'text-green-600 font-bold' : 'text-gray-400'}`}
                    aria-label="Thumbs Up"
                  >
                    👍
                  </button>
                  <button 
                    onClick={() => handleFeedback(msg.id, 'DOWN', msg.documentId)}
                    className={`p-1 rounded hover:bg-gray-200 ${optimisticRatings[msg.id] === 'DOWN' ? 'text-red-600 font-bold' : 'text-gray-400'}`}
                    aria-label="Thumbs Down"
                  >
                    👎
                  </button>
                </div>
              )}
            </div>
          </div>
        ))}
        {isLoading && <div className="text-gray-400 animate-pulse">Thinking...</div>}
      </div>

      {/* Input Form */}
      <form onSubmit={handleSubmit} className="flex gap-2">
        <input
          type="text"
          value={input}
          onChange={handleInputChange}
          placeholder="Ask a question about your data..."
          className="flex-1 border rounded px-3 py-2 text-black"
          disabled={isLoading}
        />
        <button 
          type="submit" 
          className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 disabled:opacity-50"
          disabled={isLoading}
        >
          Send
        </button>
      </form>
    </div>
  );
}
