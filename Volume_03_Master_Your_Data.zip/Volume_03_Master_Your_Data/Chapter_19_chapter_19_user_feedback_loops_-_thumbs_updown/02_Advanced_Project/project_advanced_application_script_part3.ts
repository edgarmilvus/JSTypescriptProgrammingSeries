/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script_part3.ts
// Description: Advanced Application Script
// ==========================================

// app/actions/feedback.ts
'use server';

import { revalidatePath } from 'next/cache';
import { prisma } from '@/lib/prisma';
import { z } from 'zod';

// ----------------------------------------------------------------------------
// 4. Server Action: Record Feedback & Update Retrieval Strategy
// ----------------------------------------------------------------------------
// This function runs exclusively on the server. It validates input, stores feedback,
// and triggers a background job to update the user's retrieval profile.

const FeedbackSchema = z.object({
  messageId: z.string(),
  rating: z.enum(['UP', 'DOWN']),
  documentId: z.string().optional(), // The ID of the vector chunk used for this response
  userEmail: z.string().email(),
  timestamp: z.date(),
});

export async function recordFeedback(input: z.infer<typeof FeedbackSchema>) {
  // Validate input securely
  const parsed = FeedbackSchema.safeParse(input);
  
  if (!parsed.success) {
    throw new Error('Invalid feedback data');
  }

  const { messageId, rating, documentId, userEmail, timestamp } = parsed.data;

  try {
    // 1. Store the explicit signal in the metadata store
    await prisma.feedback.create({
      data: {
        messageId,
        rating,
        documentId, // Link to specific vector data
        userEmail,
        timestamp,
      },
    });

    // 2. Dynamic Retrieval Adjustment (The "Advanced" Logic)
    // If the rating is negative, we update the user's retrieval profile to 
    // deprioritize this specific document context in future queries.
    if (rating === 'DOWN' && documentId) {
      await prisma.userRetrievalProfile.upsert({
        where: { userEmail },
        update: {
          // Add to a blacklist or adjust similarity threshold
          excludedDocumentIds: {
            push: documentId,
          },
          updatedAt: new Date(),
        },
        create: {
          userEmail,
          excludedDocumentIds: [documentId],
        },
      });
    }

    // 3. Revalidate relevant paths (e.g., if we have a dashboard showing stats)
    revalidatePath('/chat');
    revalidatePath('/dashboard/analytics');

    return { success: true };
  } catch (error) {
    console.error('Error recording feedback:', error);
    return { success: false, error: 'Database error' };
  }
}
