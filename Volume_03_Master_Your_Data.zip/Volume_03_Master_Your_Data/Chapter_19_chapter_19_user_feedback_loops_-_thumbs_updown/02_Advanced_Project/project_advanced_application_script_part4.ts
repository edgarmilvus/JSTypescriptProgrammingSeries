/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script_part4.ts
// Description: Advanced Application Script
// ==========================================

// app/api/chat/route.ts
import { OpenAIStream, StreamingTextResponse } from 'ai';
import { Configuration, OpenAIApi } from 'openai-edge';
import { prisma } from '@/lib/prisma'; // Assuming Prisma setup
import { searchVectorStore } from '@/lib/vector-db'; // Mocked vector search

const config = new Configuration({ apiKey: process.env.OPENAI_API_KEY });
const openai = new OpenAIApi(config);

// ----------------------------------------------------------------------------
// 5. API Route: Adaptive Retrieval Generation
// ----------------------------------------------------------------------------
// This route intercepts the user query, fetches the user's retrieval profile
// (including exclusions from negative feedback), and performs the RAG.
export async function POST(req: Request) {
  const { messages, preferredTopics } = await req.json();
  const userEmail = 'user@example.com'; // In real app, extract from session/jwt

  // 1. Fetch User Retrieval Profile
  // We check for excluded document IDs based on previous "Thumbs Down" feedback.
  const profile = await prisma.userRetrievalProfile.findUnique({
    where: { userEmail },
  });

  const excludedIds = profile?.excludedDocumentIds || [];

  // 2. Generate Embedding for the latest user query
  const latestMessage = messages[messages.length - 1].content;
  const embedding = await generateEmbeddings(latestMessage);

  // 3. Perform Vector Search with Exclusions
  // Filter out chunks that the user previously disliked.
  const relevantDocs = await searchVectorStore(embedding, {
    limit: 5,
    excludeIds: excludedIds, // <--- This is the feedback loop in action
    boost: preferredTopics,  // Boost positive topics
  });

  // 4. Construct Prompt
  const context = relevantDocs.map(doc => doc.content).join('\n\n');
  const systemPrompt = `Context:\n${context}\n\nAnswer the user's question based strictly on the context provided. If the context is irrelevant, say you don't know.`;

  // 5. Stream Response
  const response = await openai.createChatCompletion({
    model: 'gpt-4-turbo-preview',
    stream: true,
    messages: [
      { role: 'system', content: systemPrompt },
      ...messages,
    ],
  });

  const stream = OpenAIStream(response);
  return new StreamingTextResponse(stream);
}
