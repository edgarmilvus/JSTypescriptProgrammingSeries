/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState } from 'react';

// 1. Props Interface Definition
interface FeedbackButtonsProps {
  responseId: string;
  onFeedback: (feedback: { responseId: string; rating: 'up' | 'down' | null }) => void;
}

// 2. Component Implementation
export const FeedbackButtons: React.FC<FeedbackButtonsProps> = ({ responseId, onFeedback }) => {
  // State to track the current selection ('up', 'down', or null)
  const [selection, setSelection] = useState<'up' | 'down' | null>(null);

  const handleFeedback = (rating: 'up' | 'down') => {
    // Logic: If clicking the same button, deselect (toggle off)
    const newRating = selection === rating ? null : rating;
    
    setSelection(newRating);
    
    // Invoke the callback prop with the updated state
    onFeedback({
      responseId,
      rating: newRating,
    });
  };

  return (
    <div className="feedback-container" style={{ display: 'flex', gap: '8px', marginTop: '8px' }}>
      {/* Thumbs Up Button */}
      <button
        onClick={() => handleFeedback('up')}
        aria-label="Thumbs Up"
        style={{
          background: 'none',
          border: 'none',
          cursor: 'pointer',
          color: selection === 'up' ? 'green' : 'gray',
          fontSize: '1.2rem',
        }}
      >
        👍
      </button>

      {/* Thumbs Down Button */}
      <button
        onClick={() => handleFeedback('down')}
        aria-label="Thumbs Down"
        style={{
          background: 'none',
          border: 'none',
          cursor: 'pointer',
          color: selection === 'down' ? 'red' : 'gray',
          fontSize: '1.2rem',
        }}
      >
        👎
      </button>
    </div>
  );
};

// --- Interactive Challenge Extension ---
// Extended Props Interface for the text input requirement
interface ExtendedFeedbackButtonsProps extends FeedbackButtonsProps {
  onFeedback: (feedback: { responseId: string; rating: 'up' | 'down' | null; reason?: string }) => void;
}

export const ExtendedFeedbackButtons: React.FC<ExtendedFeedbackButtonsProps> = ({ responseId, onFeedback }) => {
  const [selection, setSelection] = useState<'up' | 'down' | null>(null);
  const [reason, setReason] = useState<string>('');

  const handleFeedback = (rating: 'up' | 'down') => {
    // If clicking the same button, reset everything
    if (selection === rating) {
      setSelection(null);
      setReason('');
      onFeedback({ responseId, rating: null });
      return;
    }

    setSelection(rating);
    
    // If switching to 'down', we wait for user input. 
    // If switching to 'up', we submit immediately.
    if (rating === 'up') {
      onFeedback({ responseId, rating: 'up' });
    } else {
      // Reset reason if switching from up to down
      setReason('');
      // Don't submit yet, wait for reason or explicit submit
    }
  };

  const handleSubmitReason = () => {
    if (selection === 'down') {
      onFeedback({ responseId, rating: 'down', reason });
    }
  };

  return (
    <div className="feedback-container">
      <div style={{ display: 'flex', gap: '8px', marginBottom: '8px' }}>
        <button
          onClick={() => handleFeedback('up')}
          aria-label="Thumbs Up"
          style={{ color: selection === 'up' ? 'green' : 'gray' }}
        >
          👍
        </button>
        <button
          onClick={() => handleFeedback('down')}
          aria-label="Thumbs Down"
          style={{ color: selection === 'down' ? 'red' : 'gray' }}
        >
          👎
        </button>
      </div>

      {/* Conditional Rendering for Reason Input */}
      {selection === 'down' && (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '4px' }}>
          <textarea
            value={reason}
            onChange={(e) => setReason(e.target.value)}
            placeholder="Briefly explain why (optional)"
            rows={2}
            style={{ width: '100%', padding: '4px' }}
          />
          <button 
            onClick={handleSubmitReason} 
            style={{ alignSelf: 'flex-end', padding: '2px 8px' }}
          >
            Submit
          </button>
        </div>
      )}
    </div>
  );
};
