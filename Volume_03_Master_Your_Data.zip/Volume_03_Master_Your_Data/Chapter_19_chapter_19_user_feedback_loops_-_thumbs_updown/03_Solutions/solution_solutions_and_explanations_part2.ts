/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

import express, { Request, Response } from 'express';
import { z } from 'zod'; // Assuming zod is installed for validation

const app = express();
app.use(express.json());

// 1. Define the Request Body Interface
interface FeedbackRequest {
  responseId: string;
  query: string;
  rating: 'up' | 'down';
  reason?: string;
  timestamp: Date;
}

// 2. In-Memory Storage Simulation
// Using a Map to store feedback indexed by responseId
const feedbackStore = new Map<string, FeedbackRequest>();

// 3. Validation Schema (using Zod)
const feedbackSchema = z.object({
  responseId: z.string().min(1),
  query: z.string().min(1),
  rating: z.enum(['up', 'down']),
  reason: z.string().optional(),
  timestamp: z.coerce.date(), // Coerce ISO string to Date object
});

// 4. POST /api/feedback Endpoint
app.post('/api/feedback', (req: Request, res: Response) => {
  console.log('Incoming feedback request:', req.body);

  // Validate input
  const validation = feedbackSchema.safeParse(req.body);

  if (!validation.success) {
    console.error('Validation failed:', validation.error.errors);
    return res.status(400).json({
      error: 'Invalid feedback data',
      details: validation.error.errors,
    });
  }

  const data: FeedbackRequest = validation.data;

  // Store the feedback
  // In a real scenario, this would be a database write operation
  feedbackStore.set(data.responseId, data);

  console.log(`Stored feedback for ID: ${data.responseId}`);

  return res.status(201).json({
    message: 'Feedback received successfully',
    id: data.responseId,
  });
});

// Start server (optional for this snippet, but usually needed)
// app.listen(3000, () => console.log('Server running on port 3000'));
