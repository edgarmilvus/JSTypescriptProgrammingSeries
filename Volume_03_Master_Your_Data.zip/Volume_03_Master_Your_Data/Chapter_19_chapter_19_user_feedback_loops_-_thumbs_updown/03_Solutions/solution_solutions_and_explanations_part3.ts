/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

// 1. Type Definitions
interface VectorMetadata {
  chunkId: string;
  text: string;
  feedbackScore: number; // e.g., -5 to 5
}

interface VectorSearchResult {
  id: string;
  score: number; // Cosine similarity score (0 to 1)
  metadata: VectorMetadata;
}

interface FinalChunk {
  chunkId: string;
  text: string;
  finalScore: number;
  sourceScore: number;
  feedbackBoost: number;
}

// 2. Mock Vector Database Client
class MockVectorDB {
  // Simulates a vector search that returns raw similarity scores
  async query(embedding: number[], topK: number): Promise<VectorSearchResult[]> {
    // Mock data: Simulating retrieval of 5 chunks
    return [
      { id: '1', score: 0.9, metadata: { chunkId: '1', text: 'Relevant text', feedbackScore: 2 } },
      { id: '2', score: 0.85, metadata: { chunkId: '2', text: 'Good text', feedbackScore: 5 } }, // High feedback
      { id: '3', score: 0.82, metadata: { chunkId: '3', text: 'Irrelevant text', feedbackScore: -3 } },
      { id: '4', score: 0.78, metadata: { chunkId: '4', text: 'Bad text', feedbackScore: -6 } }, // Below threshold
      { id: '5', score: 0.75, metadata: { chunkId: '5', text: 'Okay text', feedbackScore: 0 } },
    ];
  }
}

// 3. Retrieval and Re-ranking Function
async function fetchRelevantChunks(
  embedding: number[],
  vectorClient: MockVectorDB,
  topK: number = 3
): Promise<FinalChunk[]> {
  // Step 1: Retrieve a larger set of candidates to account for filtering
  // We fetch more than topK because we might filter some out
  const candidates = await vectorClient.query(embedding, topK + 5);

  const FEEDBACK_WEIGHT = 0.05; // Weight for the feedback score
  const EXCLUSION_THRESHOLD = -5; // Threshold for negative feedback

  // Step 2: Map, Filter, and Calculate Final Score
  const processedChunks: FinalChunk[] = candidates
    .map((candidate) => {
      const feedbackBoost = candidate.metadata.feedbackScore * FEEDBACK_WEIGHT;
      const finalScore = candidate.score + feedbackBoost;

      return {
        chunkId: candidate.metadata.chunkId,
        text: candidate.metadata.text,
        finalScore,
        sourceScore: candidate.score,
        feedbackBoost,
      };
    })
    // Step 3: Exclude chunks with very low feedback scores
    .filter((chunk) => chunk.metadata.feedbackScore > EXCLUSION_THRESHOLD);

  // Step 4: Sort by the new final score (descending)
  processedChunks.sort((a, b) => b.finalScore - a.finalScore);

  // Step 5: Return the top K results
  return processedChunks.slice(0, topK);
}

// Usage Example (Mocking the execution)
const mockEmbedding = [0.1, 0.2, 0.3]; // Dummy embedding
const db = new MockVectorDB();

fetchRelevantChunks(mockEmbedding, db).then((results) => {
  console.log('Re-ranked Results:', results);
});
