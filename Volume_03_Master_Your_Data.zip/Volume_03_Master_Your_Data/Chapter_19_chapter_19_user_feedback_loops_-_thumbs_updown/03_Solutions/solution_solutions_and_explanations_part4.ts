/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

// The solution is the DOT syntax provided in the prompt, 
// but formatted here for clarity as requested.

const standardWorkflowDot = `
digraph FeedbackLoop {
    rankdir=TB;
    node [shape=box, style="rounded,filled", fillcolor="lightblue"];
    
    // Nodes
    UserInterface [label="User Interface (React)"];
    BackendAPI [label="Backend API (Express)"];
    VectorDB [label="Vector Database\\n(Metadata Store)"];
    RetrievalService [label="Retrieval Service"];
    EmbeddingModel [label="Embedding Model"];
    Reranker [label="Re-ranker"];

    // Edges - Standard Flow
    UserInterface -> BackendAPI [label="1. Clicks Thumbs Up/Down"];
    BackendAPI -> VectorDB [label="2. Stores Feedback & Updates Metadata"];
    VectorDB -> RetrievalService [label="3. Returns Chunks with Metadata"];
    EmbeddingModel -> RetrievalService [label="4. Provides Query Embedding"];
    RetrievalService -> Reranker [label="5. Retrieves & Re-ranks Chunks"];
    Reranker -> UserInterface [label="6. Returns Boosted Response"];

    // Feedback Loop for Model Improvement (Async)
    VectorDB -> EmbeddingModel [label="7. Fine-tunes (Periodic)"];
    VectorDB -> Reranker [label="8. Trains (Periodic)"];
}
`;

// --- Interactive Challenge: Agentic Workflow ---

const agenticWorkflowDot = `
digraph AgenticFeedbackLoop {
    rankdir=TB;
    node [shape=box, style="filled", fillcolor="lightcoral"];
    
    // Nodes
    UserInterface [label="User Interface"];
    SupervisorAgent [label="Supervisor Agent\\n(Orchestrator)"];
    ExecutorAgent [label="Executor Agent\\n(Tool User)"];
    VectorDB [label="Vector Database"];
    ModelTrainingService [label="Model Training Service"];

    // Edges
    UserInterface -> SupervisorAgent [label="Sends Feedback Event"];
    
    SupervisorAgent -> ExecutorAgent [label="1. Delegate: 'Update Metadata'"];
    ExecutorAgent -> VectorDB [label="2. Update Chunk Score"];
    
    SupervisorAgent -> ExecutorAgent [label="3. Delegate: 'Check Threshold'"];
    ExecutorAgent -> SupervisorAgent [label="4. Report: 'Retraining Needed'"];
    
    SupervisorAgent -> ExecutorAgent [label="5. Delegate: 'Trigger Fine-tuning'"];
    ExecutorAgent -> ModelTrainingService [label="6. Start Training Job"];
    
    ModelTrainingService -> VectorDB [label="7. Push Updated Embeddings"];
}
`;

console.log("Standard Workflow DOT:\n", standardWorkflowDot);
console.log("Agentic Workflow DOT:\n", agenticWorkflowDot);
