/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

// 1. Interfaces
interface FeedbackEntry {
  query: string;
  response: string;
  rating: 'up' | 'down';
  retrievalConfidence: number; // 0.0 to 1.0
}

interface FineTuningExample {
  prompt: string;
  completion: string;
  weight?: number; // Optional weight for weighted training
}

interface FineTuningDataset {
  examples: FineTuningExample[];
  stats: {
    positiveCount: number;
    negativeCount: number;
    totalWeight: number;
  };
}

// 2. Preparation Function
function prepareFineTuningData(feedbackData: FeedbackEntry[]): FineTuningDataset {
  const examples: FineTuningExample[] = [];
  let positiveCount = 0;
  let negativeCount = 0;
  let totalWeight = 0;

  // Thresholds for weighting
  const HIGH_CONFIDENCE_THRESHOLD = 0.8;
  const LOW_CONFIDENCE_THRESHOLD = 0.3;

  feedbackData.forEach(entry => {
    let weight = 1.0;

    // --- Interactive Challenge: Weighting Logic ---
    if (entry.rating === 'up') {
      // High confidence positive examples are emphasized
      if (entry.retrievalConfidence >= HIGH_CONFIDENCE_THRESHOLD) {
        weight = 2.0; // Duplicate implicitly by weight
      }
      positiveCount++;
    } else {
      // Low confidence negative examples are down-weighted (noise)
      if (entry.retrievalConfidence < LOW_CONFIDENCE_THRESHOLD) {
        weight = 0.5;
      }
      negativeCount++;
    }

    // Format for Fine-tuning (e.g., OpenAI format: Prompt -> Completion)
    // For RAG fine-tuning, we might train the model to generate the 'response' given the 'query'
    examples.push({
      prompt: entry.query,
      completion: entry.response,
      weight: weight,
    });

    totalWeight += weight;
  });

  // 3. Validation
  // Ensure we have a minimum amount of data to train effectively
  if (examples.length < 10) {
    throw new Error("Dataset too small for fine-tuning. Need at least 10 examples.");
  }

  // Optional: Check balance (Warning only, as unbalanced is common)
  if (positiveCount === 0 || negativeCount === 0) {
    console.warn("Warning: Dataset is heavily imbalanced. Fine-tuning may suffer from mode collapse.");
  }

  return {
    examples,
    stats: {
      positiveCount,
      negativeCount,
      totalWeight: Math.round(totalWeight * 100) / 100, // Round for readability
    },
  };
}

// 4. Mock Data Execution
const mockFeedback: FeedbackEntry[] = [
  { query: "What is AI?", response: "AI is...", rating: 'up', retrievalConfidence: 0.9 },
  { query: "History of Rome", response: "Rome was founded...", rating: 'up', retrievalConfidence: 0.4 },
  { query: "Best pizza?", response: "I don't know.", rating: 'down', retrievalConfidence: 0.2 },
  { query: "Code in JS", response: "console.log()", rating: 'down', retrievalConfidence: 0.9 },
];

const dataset = prepareFineTuningData(mockFeedback);
console.log('Prepared Fine-Tuning Dataset:', JSON.stringify(dataset, null, 2));
