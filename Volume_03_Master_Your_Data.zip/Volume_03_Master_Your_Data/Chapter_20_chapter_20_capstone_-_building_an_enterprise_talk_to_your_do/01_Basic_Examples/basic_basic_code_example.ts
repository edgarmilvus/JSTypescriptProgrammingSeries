/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

// app/api/chat/route.ts
import { openai } from '@ai-sdk/openai';
import { streamText, generateObject } from 'ai';
import { z } from 'zod';

// Allow streaming responses up to 30 seconds
export const maxDuration = 30;

/**
 * POST Handler for the Chat Endpoint.
 * 
 * This function simulates a RAG pipeline:
 * 1. Receives user input.
 * 2. Simulates retrieving context from a vector database.
 * 3. Calls the LLM with the context and a strict JSON schema.
 * 4. Streams the structured response back to the client.
 */
export async function POST(req: Request) {
  const { messages } = await req.json();

  // Get the latest user message
  const lastMessage = messages[messages.length - 1];
  const userQuestion = lastMessage.content;

  // ---------------------------------------------------------
  // STEP 1: Simulate Retrieval (KNN)
  // ---------------------------------------------------------
  // In a real app, you would query Pinecone/Milvus here.
  // We will mock the "K" retrieved documents.
  const retrievedContext = `
    Document ID: 42
    Content: The pricing plan for Enterprise tier is $499/month. 
    Includes dedicated support and SSO integration.
    
    Document ID: 55
    Content: Billing cycles are monthly. Invoices are sent on the 1st of the month.
  `;

  // ---------------------------------------------------------
  // STEP 2: Define the JSON Schema (Zod)
  // ---------------------------------------------------------
  // This instructs the LLM on exactly what structure to return.
  const answerSchema = z.object({
    answer: z.string().describe("The direct answer to the user's question"),
    citations: z.array(z.string()).describe("List of document IDs referenced"),
    confidence: z.number().min(0).max(1).describe("Confidence score of the answer"),
  });

  // ---------------------------------------------------------
  // STEP 3: Stream the LLM Response
  // ---------------------------------------------------------
  // We use streamText to allow real-time UI updates.
  const result = await streamText({
    model: openai('gpt-4-turbo-preview'),
    messages: [
      {
        role: 'system',
        content: `You are a helpful assistant. Answer the user's question based ONLY on the provided context.
        Context: ${retrievedContext}
        
        Format your response as a JSON object matching this schema:
        {
          "answer": "string",
          "citations": ["string"],
          "confidence": number
        }
        
        Do not include markdown formatting or text outside the JSON object.`,
      },
      ...messages,
    ],
    // IMPORTANT: We do not enforce schema validation on the stream itself 
    // to allow token-by-token streaming, but we structure the prompt to enforce it.
    // The client will parse the accumulated stream.
  });

  // ---------------------------------------------------------
  // STEP 4: Return the Stream
  // ---------------------------------------------------------
  return result.toAIStreamResponse();
}
