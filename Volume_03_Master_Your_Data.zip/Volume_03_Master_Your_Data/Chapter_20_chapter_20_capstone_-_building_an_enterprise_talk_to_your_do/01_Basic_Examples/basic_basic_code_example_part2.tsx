/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.tsx
// Description: Basic Code Example
// ==========================================

// app/page.tsx
'use client';

import { useChat } from 'ai/react';
import { useState, useEffect } from 'react';
import { z } from 'zod';

// Define the same schema on the client to validate the stream
const responseSchema = z.object({
  answer: z.string(),
  citations: z.array(z.string()),
  confidence: z.number(),
});

export default function Chat() {
  // useChat hook handles message state, user input, and streaming
  const { messages, input, handleInputChange, handleSubmit, isLoading, stop } = useChat({
    api: '/api/chat',
  });

  // State to hold the parsed structured data
  const [parsedData, setParsedData] = useState<z.infer<typeof responseSchema> | null>(null);

  // ---------------------------------------------------------
  // LOGIC: Parse the stream as it arrives
  // ---------------------------------------------------------
  // The last message contains the full streamed string from the LLM.
  // We attempt to parse it as JSON.
  useEffect(() => {
    if (messages.length > 0) {
      const lastMessage = messages[messages.length - 1];

      if (lastMessage.role === 'assistant' && lastMessage.content) {
        try {
          // Attempt to parse the accumulated content as JSON
          const parsed = JSON.parse(lastMessage.content);
          
          // Validate against our Zod schema
          const validated = responseSchema.parse(parsed);
          
          setParsedData(validated);
        } catch (error) {
          // If parsing fails (e.g., stream is partial), we ignore it.
          // This is expected during streaming.
          console.log("Waiting for complete JSON stream...");
        }
      }
    }
  }, [messages]);

  return (
    <div className="flex flex-col w-full max-w-md mx-auto p-4 space-y-4">
      <div className="border rounded-lg p-4 space-y-2 min-h-[300px]">
        {messages.map((m, index) => (
          <div key={index} className="whitespace-pre-wrap">
            <strong>{m.role === 'user' ? 'User: ' : 'AI: '}</strong>
            {/* 
              If we have parsed data and it's the assistant, show the structured view.
              Otherwise, show raw content (for partial streams or errors).
            */}
            {m.role === 'assistant' && parsedData ? (
              <div className="mt-2 p-2 bg-gray-100 rounded text-sm">
                <p className="font-bold text-blue-600">Answer: {parsedData.answer}</p>
                <p className="text-gray-600">Confidence: {(parsedData.confidence * 100).toFixed(0)}%</p>
                <div className="mt-1">
                  <span className="text-xs font-semibold">Citations:</span>
                  {parsedData.citations.map((c, i) => (
                    <span key={i} className="inline-block bg-blue-100 text-blue-800 text-xs px-1 ml-1 rounded">
                      {c}
                    </span>
                  ))}
                </div>
              </div>
            ) : (
              <span>{m.content}</span>
            )}
          </div>
        ))}
      </div>

      <form onSubmit={handleSubmit} className="flex gap-2">
        <input
          type="text"
          value={input}
          onChange={handleInputChange}
          placeholder="Ask about pricing..."
          className="flex-1 border p-2 rounded"
        />
        <button 
          type="submit" 
          disabled={isLoading} 
          className="bg-black text-white px-4 py-2 rounded disabled:opacity-50"
        >
          {isLoading ? 'Thinking...' : 'Send'}
        </button>
        {isLoading && (
          <button type="button" onClick={stop} className="bg-red-500 text-white px-4 py-2 rounded">
            Stop
          </button>
        )}
      </form>
    </div>
  );
}
