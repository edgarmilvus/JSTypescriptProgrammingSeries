/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// File: app/api/chat/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { Pinecone } from '@pinecone-database/pinecone';
import { OpenAIStream, StreamingTextResponse } from 'ai';
import { OpenAI } from '@ai-sdk/openai';
import { z } from 'zod';

// ==========================================
// 1. CONFIGURATION & VALIDATION
// ==========================================

// Define the structure of the metadata stored in Pinecone.
// This ensures type safety when retrieving context from the vector store.
const DocumentMetadataSchema = z.object({
  source: z.string(), // e.g., "employee-handbook-v2.pdf"
  page: z.number(),   // Page number for citation
  author: z.string(),
  lastModified: z.string(),
});

// ==========================================
// 2. PINECONE CLIENT INITIALIZATION
// ==========================================

// Initialize the Pinecone client. 
// In production, use environment variables for API keys and environment.
const pc = new Pinecone({
  apiKey: process.env.PINECONE_API_KEY!,
});

// Select the specific index. We assume a dimension of 1536 (OpenAI text-embedding-ada-002).
const index = pc.Index('enterprise-docs-index');

// ==========================================
// 3. HELPER: SEMANTIC SEARCH
// ==========================================

/**
 * Queries the Pinecone vector database for relevant document chunks.
 * 
 * @param query - The user's natural language query.
 * @param topK - Number of relevant chunks to retrieve.
 * @returns A formatted string containing the concatenated context.
 */
async function retrieveContext(query: string, topK: number = 4): Promise<string> {
  try {
    // 1. Generate an embedding for the user query using OpenAI.
    // Note: In a high-traffic app, you might use a dedicated embedding model instance.
    const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
    const embeddingResponse = await openai.embeddings.create({
      model: 'text-embedding-ada-002',
      input: query,
    });
    const queryVector = embeddingResponse.data[0].embedding;

    // 2. Perform semantic search (query) against Pinecone.
    const searchResponse = await index.query({
      vector: queryVector,
      topK: topK,
      includeMetadata: true, // We need metadata for citations
    });

    if (!searchResponse.matches || searchResponse.matches.length === 0) {
      return "No relevant context found.";
    }

    // 3. Format the retrieved chunks into a single context string.
    // We use a delimiter to separate distinct document sections.
    const context = searchResponse.matches
      .map((match) => {
        // Validate metadata using Zod to ensure data integrity
        const meta = DocumentMetadataSchema.safeParse(match.metadata);
        
        const sourceInfo = meta.success 
          ? `[Source: ${meta.data.source}, Page: ${meta.data.page}]` 
          : `[Unknown Source]`;

        // Combine metadata with the actual text content
        return `${sourceInfo}: ${match.metadata?.text}`;
      })
      .join('\n\n---\n\n');

    return context;
  } catch (error) {
    console.error('Error retrieving context:', error);
    // Fail gracefully: return empty context rather than crashing
    return "";
  }
}

// ==========================================
// 4. MAIN: NEXT.JS API ROUTE HANDLER
// ==========================================

/**
 * POST /api/chat
 * 
 * Handles incoming chat requests from the client (using useChat hook).
 * Implements the RAG pattern:
 * 1. Receive User Message.
 * 2. Retrieve relevant context from Vector DB.
 * 3. Construct a System Prompt with the context.
 * 4. Stream the LLM response back to the client.
 */
export async function POST(req: NextRequest) {
  // Parse the incoming JSON body (expecting { messages: [] })
  const { messages } = await req.json();

  // Get the most recent user message
  const lastMessage = messages[messages.length - 1];

  if (!lastMessage || lastMessage.role !== 'user') {
    return NextResponse.json({ error: 'Invalid request format' }, { status: 400 });
  }

  // 1. RETRIEVAL STEP: Semantic Search
  const context = await retrieveContext(lastMessage.content);

  // 2. AUGMENTATION STEP: Prompt Engineering
  // We inject the retrieved context into the system prompt.
  // This instructs the LLM to ground its answer strictly in the provided documents.
  const systemPrompt = `
    You are an AI Assistant for an enterprise SaaS platform. 
    Your task is to answer user questions based strictly on the provided context below.
    
    If the answer is not contained in the context, politely state that you cannot find the information in the documentation.
    Do not hallucinate facts.

    Context:
    ${context}

    Current Date: ${new Date().toISOString().split('T')[0]}
  `;

  // 3. GENERATION STEP: Streaming LLM Response
  // We use the Vercel AI SDK's `OpenAIStream` to handle token streaming.
  // This creates a standard ReadableStream that the client `useChat` hook consumes.
  try {
    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${process.env.OPENAI_API_KEY}`,
      },
      body: JSON.stringify({
        model: 'gpt-4-turbo-preview',
        stream: true, // Enable streaming
        messages: [
          { role: 'system', content: systemPrompt },
          ...messages, // Pass conversation history
        ],
      }),
    });

    // Convert the raw response to a stream
    const stream = OpenAIStream(response);
    
    // Return the stream to the client
    return new StreamingTextResponse(stream);
  } catch (error) {
    console.error('Error generating response:', error);
    return new NextResponse('Error generating response', { status: 500 });
  }
}
