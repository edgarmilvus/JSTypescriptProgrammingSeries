/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// types.ts
export interface IngestionResult {
  success: boolean;
  content?: string;
  error?: { code: string; message: string };
}

// ingestion.ts
import * as fs from 'fs'; // Only used if buffer operations require it, typically we work directly with buffer
import * as path from 'path';

export async function ingestDocument(
  buffer: Buffer,
  filename: string
): Promise<IngestionResult> {
  const MAX_SIZE_BYTES = 10 * 1024 * 1024; // 10MB
  const ALLOWED_EXTENSIONS = ['.pdf', '.txt', '.md'];
  const ALLOWED_MIME_TYPES = ['application/pdf', 'text/plain', 'text/markdown'];

  try {
    // 1. Security Check: Magic Bytes (File Signature)
    // We check the first few bytes of the buffer to verify the actual file type
    // rather than trusting the filename extension.
    const magicBytes = buffer.slice(0, 4);
    const hexSignature = magicBytes.toString('hex');

    // Basic signature check (not exhaustive for all types, but demonstrates the concept)
    const isPdf = hexSignature.startsWith('25504446'); // %PDF
    const isText = buffer.subarray(0, 100).includes(0x0A); // Check for newline char in first 100 bytes
    
    // Determine MIME type based on signature
    let detectedMime = '';
    if (isPdf) detectedMime = 'application/pdf';
    else if (isText) detectedMime = 'text/plain'; // Simplified assumption for txt/md

    // 2. File Type Validation
    const ext = path.extname(filename).toLowerCase();
    if (!ALLOWED_EXTENSIONS.includes(ext)) {
      return {
        success: false,
        error: { code: 'INVALID_EXTENSION', message: `File extension ${ext} is not allowed.` }
      };
    }

    // Mitigation: If the detected MIME type doesn't match the extension, reject.
    // In a real scenario, you'd have a more robust MIME mapping.
    if (ext === '.pdf' && detectedMime !== 'application/pdf') {
        return {
            success: false,
            error: { code: 'MISMATCH', message: 'File content does not match the .pdf extension.' }
        };
    }

    // 3. Size Validation
    if (buffer.length > MAX_SIZE_BYTES) {
      return {
        success: false,
        error: { code: 'SIZE_LIMIT', message: 'File exceeds 10MB limit.' }
      };
    }

    // 4. Content Check
    // Convert buffer to string (assuming UTF-8 for text files)
    // Note: For PDFs, we would typically use a parser like pdf-parse here.
    // For this exercise, we handle text-based content extraction.
    let content = '';
    if (ext === '.pdf') {
        // Mocking PDF text extraction for the exercise
        content = '[PDF Content Placeholder]'; 
    } else {
        content = buffer.toString('utf-8');
    }

    if (!content || content.trim().length === 0) {
      return {
        success: false,
        error: { code: 'EMPTY_CONTENT', message: 'File content is empty or whitespace.' }
      };
    }

    // Success
    return {
      success: true,
      content: content.trim()
    };

  } catch (error) {
    return {
      success: false,
      error: { code: 'PROCESSING_ERROR', message: 'An unexpected error occurred during ingestion.' }
    };
  }
}

/*
 * SECURITY COMMENT:
 * Why trusting file extensions is dangerous:
 * A malicious user can rename a dangerous executable (e.g., 'malware.exe') to 'document.pdf'.
 * If the server relies solely on the '.pdf' extension to determine how to process the file,
 * it might attempt to parse it with a PDF library, potentially triggering vulnerabilities,
 * or worse, store it in a location accessible by the web server, leading to remote code execution.
 *
 * Mitigation (Magic Bytes):
 * Magic bytes are specific sequences of bytes at the beginning of a file that identify its format.
 * For example, PDF files always start with "%PDF". By inspecting the Buffer slice (buffer.subarray(0, 4)),
 * we verify the file's true nature before processing. This is a crucial layer of defense-in-depth.
 */
