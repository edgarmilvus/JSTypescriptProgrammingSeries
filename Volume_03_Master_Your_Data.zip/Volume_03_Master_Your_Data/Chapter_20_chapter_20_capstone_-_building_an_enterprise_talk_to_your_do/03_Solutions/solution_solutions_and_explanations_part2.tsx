/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.tsx
// Description: Solutions and Explanations
// ==========================================

// components/MessageStream.tsx
'use client';

import { useChat } from '@ai-sdk/react';
import { useState, useEffect } from 'react';

// Define the expected structure of the LLM response
interface ChatResponse {
  responseText: string;
  citations: string[];
  confidence: number;
}

export default function MessageStream() {
  // Initialize the hook with the specific API route
  const { messages, input, handleInputChange, handleSubmit, isLoading, stop } = useChat({
    api: '/api/chat',
  });

  // State to hold the parsed structured data
  const [parsedResponse, setParsedResponse] = useState<ChatResponse | null>(null);
  const [parsingError, setParsingError] = useState<string | null>(null);

  // Effect to parse the latest message content when it changes
  useEffect(() => {
    const latestMessage = messages[messages.length - 1];
    
    if (latestMessage && latestMessage.role === 'assistant' && !isLoading) {
      try {
        // Attempt to parse the content as JSON
        // Note: In a real streaming scenario with JSON output, the SDK might handle 
        // partial JSON reconstruction. Here we assume the stream finishes and delivers valid JSON.
        const parsed: ChatResponse = JSON.parse(latestMessage.content);
        setParsedResponse(parsed);
        setParsingError(null);
      } catch (e) {
        setParsingError("Failed to parse structured response. Displaying raw text.");
        setParsedResponse(null);
      }
    }
  }, [messages, isLoading]);

  return (
    <div className="flex flex-col w-full max-w-md py-24 mx-auto stretch">
      <div className="space-y-4 mb-4">
        {messages.map((m) => (
          <div key={m.id} className="whitespace-pre-wrap">
            <strong>{m.role === 'user' ? 'User: ' : 'AI: '}</strong>
            
            {/* Conditional Rendering based on Parsing State */}
            {m.role === 'assistant' && parsedResponse && !parsingError ? (
              <div className="p-3 bg-gray-100 rounded-lg mt-2 border border-gray-200">
                <p className="text-gray-800">{parsedResponse.responseText}</p>
                
                {/* Citations */}
                <div className="mt-2">
                  <span className="text-xs font-bold text-gray-500">Sources:</span>
                  <ul className="list-disc list-inside text-sm text-blue-600">
                    {parsedResponse.citations.map((cite, idx) => (
                      <li key={idx} className="cursor-pointer hover:underline">
                        {cite}
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Confidence Bar */}
                <div className="mt-3">
                  <div className="flex justify-between text-xs text-gray-500 mb-1">
                    <span>Confidence</span>
                    <span>{(parsedResponse.confidence * 100).toFixed(0)}%</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2.5">
                    <div 
                      className="bg-blue-600 h-2.5 rounded-full" 
                      style={{ width: `${parsedResponse.confidence * 100}%` }}
                    ></div>
                  </div>
                </div>
              </div>
            ) : (
              // Fallback to raw text if not parsable or still loading
              <div className="p-3 bg-gray-50 rounded-lg">
                {m.content}
                {parsingError && m.role === 'assistant' && (
                  <span className="block text-xs text-red-500 mt-1">{parsingError}</span>
                )}
              </div>
            )}
          </div>
        ))}
      </div>

      <form onSubmit={handleSubmit}>
        <input
          className="fixed bottom-0 w-full max-w-md p-2 mb-8 border border-gray-300 rounded shadow-xl"
          value={input}
          placeholder="Ask about documents..."
          onChange={handleInputChange}
        />
      </form>
    </div>
  );
}
