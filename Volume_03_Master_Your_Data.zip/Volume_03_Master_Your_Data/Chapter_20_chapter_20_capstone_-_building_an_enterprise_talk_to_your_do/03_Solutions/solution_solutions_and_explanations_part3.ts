/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

// agents/types.ts
export type AgentName = 'vectorSearchAgent' | 'webSearchAgent' | 'clarificationAgent';

export interface RoutingDecision {
  agent: AgentName;
  args: Record<string, any>;
}

// agents/supervisor.ts
import { AgentName, RoutingDecision } from './types';

export function supervisorRouter(query: string): RoutingDecision {
  const lowerQuery = query.toLowerCase();

  // 1. Define routing rules (simulating LLM function calling logic)
  
  // Rule: Vector Search (Internal Document Retrieval)
  const documentKeywords = ['document', 'report', 'file', 'summary', 'policy', 'contract', 'pdf'];
  const isDocumentQuery = documentKeywords.some(word => lowerQuery.includes(word));

  // Rule: Web Search (External Real-time Data)
  const webKeywords = ['current', 'stock', 'price', 'news', 'weather', 'internet', 'web'];
  const isWebQuery = webKeywords.some(word => lowerQuery.includes(word));

  // 2. Determine Route
  if (isDocumentQuery) {
    return {
      agent: 'vectorSearchAgent',
      args: { 
        query: query, // The original query for semantic search
        filters: { type: 'document' } 
      }
    };
  }

  if (isWebQuery) {
    return {
      agent: 'webSearchAgent',
      args: { 
        query: query,
        source: 'live_web' 
      }
    };
  }

  // 3. Fallback to Clarification
  // If the query is too short or contains no specific keywords, ask for clarification.
  if (query.split(' ').length < 3 || (!isDocumentQuery && !isWebQuery)) {
    return {
      agent: 'clarificationAgent',
      args: { 
        originalQuery: query,
        message: "Could you specify if you are looking for internal documents or external web data?" 
      }
    };
  }

  // Default fallback (though logic above covers most cases)
  return {
    agent: 'clarificationAgent',
    args: { message: "I am not sure how to route this request." }
  };
}
