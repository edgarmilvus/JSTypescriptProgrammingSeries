/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

// logger.ts
type LogLevel = 'INFO' | 'WARN' | 'ERROR';

export class RAGLogger {
  private service: string;

  constructor(serviceName: string) {
    this.service = serviceName;
  }

  // Helper to handle circular references safely
  private safeStringify(obj: any): string {
    const seen = new WeakSet();
    return JSON.stringify(obj, (key, value) => {
      if (typeof value === "object" && value !== null) {
        if (seen.has(value)) {
          return; // Remove circular reference
        }
        seen.add(value);
      }
      return value;
    });
  }

  private log(level: LogLevel, message: string, metadata: Record<string, any> = {}) {
    const logEntry = {
      timestamp: new Date().toISOString(),
      level: level,
      service: this.service,
      message: message,
      ...metadata // Spread metadata into the root object for easy querying
    };

    // In a real app, this would write to a file or stdout stream
    // We use safeStringify to prevent crashes on complex objects
    console.log(this.safeStringify(logEntry));
  }

  public logRetrieval(query: string, retrievedIds: string[], latencyMs: number, tokenCount: number) {
    this.log('INFO', 'RAG Retrieval Executed', {
      query,
      retrievedIds, // Array of IDs
      latencyMs,
      tokenCount,
      performance: latencyMs > 500 ? 'slow' : 'fast' // Example derived metric
    });
  }
}

// instrumentation.ts
import { RAGLogger } from './logger';

const logger = new RAGLogger('rag-retrieval-service');

export async function instrumentedRagQuery(query: string) {
  const startTime = performance.now();

  // 1. Mock Retrieval Logic
  // Simulate a vector DB query returning IDs
  const mockIds = ['chunk_1', 'chunk_2', 'chunk_3'];
  
  // Simulate processing time
  await new Promise(resolve => setTimeout(resolve, 150)); 

  const endTime = performance.now();
  const latency = endTime - startTime;
  
  // 2. Mock Token Count (e.g., length of text / 4)
  const tokenCount = Math.floor(query.length / 4) + 100; // Rough estimate

  // 3. Log the structured data
  logger.logRetrieval(query, mockIds, latency, tokenCount);
}
