/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * @fileoverview A simple "Hello World" example of an agentic loop using LangGraph.js.
 * This simulates a SaaS web app feature for classifying customer support tickets.
 * It demonstrates StateGraph, a simple ReAct loop, and a Max Iteration Policy guardrail.
 */

import { StateGraph, Annotation } from "@langchain/langgraph";

// 1. DEFINE THE STATE
// The state is the shared memory for the graph. It's mutable and passed between nodes.
// In a real web app, this could be stored in a database or Redis cache.
const GraphState = Annotation.Root({
  // The raw text of the support ticket from the user.
  ticketText: Annotation<string>(),
  // The agent's current reasoning trace. This is the "thought" part of ReAct.
  reasoning: Annotation<string>({
    reducer: (state, update) => `${state}\n${update}`, // Append new reasoning to the history.
    default: () => "Initial analysis starting...",
  }),
  // The final, determined priority level (e.g., "Low", "Medium", "High", "Urgent").
  priority: Annotation<string>({
    default: () => "Unassigned",
  }),
  // A counter to enforce our Max Iteration Policy.
  iterationCount: Annotation<number>({
    reducer: (state, update) => state + update,
    default: () => 0,
  }),
});

// 2. DEFINE THE NODES (COMPUTATIONAL STEPS)
// Nodes are functions that accept the current state and return a partial state update.

/**
 * Node: `analyzeTicket`
 * Simulates an LLM call to reason about the ticket content.
 * This is the "Reasoning" step of the ReAct pattern.
 * @param {typeof GraphState.State} state - The current graph state.
 * @returns {Partial<typeof GraphState.State>} - An update to the state.
 */
const analyzeTicket = async (
  state: typeof GraphState.State
): Promise<Partial<typeof GraphState.State>> => {
  console.log("--- Node: analyzeTicket ---");
  
  // In a real app, you would call an LLM here (e.g., GPT-4).
  // For this example, we use simple logic to simulate the LLM's "thought".
  const text = state.ticketText.toLowerCase();
  let reasoning = "";

  if (text.includes("outage") || text.includes("down")) {
    reasoning = "This ticket mentions 'outage' or 'down', indicating a critical system issue. This requires immediate attention.";
  } else if (text.includes("billing") || text.includes("payment")) {
    reasoning = "This is a billing-related query. Financial issues are important but not typically urgent unless it's about a failed payment.";
  } else {
    reasoning = "This is a general inquiry. It can be handled during standard business hours.";
  }

  return {
    reasoning: `Analysis: ${reasoning}`,
    iterationCount: 1, // Increment the iteration counter on each loop.
  };
};

/**
 * Node: `assignPriority`
 * Simulates the "Acting" step of the ReAct pattern.
 * Based on the reasoning, it assigns a priority.
 * @param {typeof GraphState.State} state - The current graph state.
 * @returns {Partial<typeof GraphState.State>} - An update to the state.
 */
const assignPriority = async (
  state: typeof GraphState.State
): Promise<Partial<typeof GraphState.State>> => {
  console.log("--- Node: assignPriority ---");

  // This logic acts upon the previous analysis.
  const reasoning = state.reasoning.toLowerCase();
  let priority = "Low"; // Default

  if (reasoning.includes("critical") || reasoning.includes("immediate")) {
    priority = "Urgent";
  } else if (reasoning.includes("financial") || reasoning.includes("important")) {
    priority = "High";
  } else if (reasoning.includes("general inquiry")) {
    priority = "Medium";
  }

  return {
    priority: priority,
  };
};

/**
 * Node: `reflectOnPriority`
 * This node introduces the cyclical nature of an agent.
 * It checks if the assigned priority is correct. If not, it forces the graph
 * back to the analysis step. This simulates self-correction.
 * @param {typeof GraphState.State} state - The current graph state.
 * @returns {Partial<typeof GraphState.State>} | null - Returns state update or null to stop.
 */
const reflectOnPriority = async (
  state: typeof GraphState.State
): Promise<Partial<typeof GraphState.State> | null> => {
  console.log("--- Node: reflectOnPriority ---");
  
  // A simple rule: "Urgent" tickets must mention "outage".
  if (state.priority === "Urgent" && !state.ticketText.toLowerCase().includes("outage")) {
    console.log("Reflection: Priority 'Urgent' was assigned incorrectly. Re-analyzing...");
    // Add a reflection note to the reasoning trace.
    return {
      reasoning: "Reflection: Incorrect 'Urgent' assignment detected. Re-triggering analysis.",
      // We do NOT return a new priority here, letting the loop correct it.
    };
  }
  
  // If the priority is correct, we return null to signal the end of this specific path.
  // In LangGraph, a null return from a conditional edge function often means "don't take this edge".
  // For simplicity here, we'll handle the loop logic in the edges.
  console.log("Reflection: Priority seems correct. Proceeding to finalize.");
  return null;
};

// 3. DEFINE THE EDGES (TRANSITIONS)
// Edges determine which node runs next.

/**
 * Edge: `checkIterationLimit`
 * A conditional edge function that implements a Max Iteration Policy.
 * It prevents infinite loops by checking the iteration count.
 * @param {typeof GraphState.State} state - The current graph state.
 * @returns {string} - The name of the next node to call.
 */
const checkIterationLimit = (
  state: typeof GraphState.State
): string => {
  const MAX_ITERATIONS = 3;
  
  if (state.iterationCount >= MAX_ITERATIONS) {
    console.log(`--- Edge: Max Iterations (${MAX_ITERATIONS}) Reached. Aborting. ---`);
    return "__end__"; // Special node to terminate the graph.
  }
  
  // If limit not reached, continue the loop.
  return "analyzeTicket";
};

/**
 * Edge: `determineNextStep`
 * A conditional edge that decides the next action based on reflection.
 * @param {typeof GraphState.State} state - The current graph state.
 * @returns {string} - The name of the next node.
 */
const determineNextStep = (
  state: typeof GraphState.State
): string => {
  // If a reflection was added to reasoning, it means we need to re-analyze.
  if (state.reasoning.includes("Re-triggering analysis")) {
    return "analyzeTicket";
  }
  // Otherwise, proceed to finalize (which in this simple case is just ending).
  return "__end__";
};


// 4. BUILD THE GRAPH
// We use StateGraph to define the structure.

const workflow = new StateGraph(GraphState)
  // Add the nodes to the graph.
  .addNode("analyzeTicket", analyzeTicket)
  .addNode("assignPriority", assignPriority)
  .addNode("reflectOnPriority", reflectOnPriority)
  
  // Define the entry point of the graph.
  .addEdge("__start__", "analyzeTicket")

  // Define standard sequential edges.
  .addEdge("analyzeTicket", "assignPriority")
  .addEdge("assignPriority", "reflectOnPriority")

  // Add the conditional edges for our loop logic.
  // After reflecting, we check the iteration limit.
  .addConditionalEdges(
    "reflectOnPriority",
    checkIterationLimit,
    {
      "analyzeTicket": "analyzeTicket", // Map the return value to the node.
      "__end__": "__end__"
    }
  )
  
  // We also add a conditional edge from the analysis step to handle the loop directly.
  // This is a simplified way to create a cycle: analyze -> assign -> reflect -> (back to analyze or end).
  // Note: In a real LangGraph, you might structure this differently, but this illustrates the concept.
  .addConditionalEdges(
    "assignPriority",
    determineNextStep,
    {
      "analyzeTicket": "analyzeTicket",
      "__end__": "__end__"
    }
  );

// Compile the graph into an executable.
const app = workflow.compile();


// 5. RUN THE AGENT (SIMULATE A WEB APP REQUEST)
// This is the main execution block. In a real web app (e.g., Next.js API route),
// this would be an async function handler.

async function runAgent() {
  console.log("🚀 Starting Web App Agent: Support Ticket Classifier");
  
  // Initial inputs simulating a user submitting a form.
  const initialInputs = {
    ticketText: "The entire payment system is down and customers cannot checkout.",
    // iterationCount starts at 0 due to default.
  };

  console.log("\n📝 Initial Ticket:", initialInputs.ticketText);
  console.log("-----------------------------------------\n");

  // Execute the graph.
  // The `stream` method returns an async iterator, perfect for real-time UI updates.
  const stream = await app.stream(initialInputs);

  // Process the stream of events.
  for await (const output of stream) {
    // `output` contains the node name and the state update.
    const nodeName = Object.keys(output)[0];
    const stateUpdate = output[nodeName];
    
    console.log(`\n--- Stream Output from Node: ${nodeName} ---`);
    
    if (stateUpdate.priority) {
      console.log(`   📌 Priority Assigned: ${stateUpdate.priority}`);
    }
    if (stateUpdate.iterationCount) {
      console.log(`   🔁 Iteration Count: ${stateUpdate.iterationCount}`);
    }
    if (stateUpdate.reasoning) {
      console.log(`   💭 Reasoning: ${stateUpdate.reasoning}`);
    }
  }

  // Get the final state after the stream completes.
  // In a real app, you would query the state store or use the final stream event.
  // For this example, we can infer the final state from the logic.
  console.log("\n-----------------------------------------");
  console.log("✅ Agent Workflow Completed.");
  console.log("Final Output would be sent to the frontend.");
}

// Run the example.
runAgent().catch(console.error);
