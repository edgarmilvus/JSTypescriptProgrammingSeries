/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// ==========================================
// IMPORTS & TYPES
// ==========================================

import { StateGraph, END, START } from "@langchain/langgraph";
import { ChatOpenAI } from "@langchain/openai";
import { ToolNode } from "@langchain/langgraph/prebuilt";

/**
 * @description The state interface for our SaaS Support Agent.
 * This represents the "Memory" of the agent.
 */
interface AgentState {
    messages: Array<{ role: string; content: string }>;
    ticketId: string;
    iterationCount: number;
    maxIterations: number;
    status: "pending" | "resolved" | "escalated";
}

// ==========================================
// 1. TOOLS DEFINITION
// ==========================================
// In a real SaaS app, these would interact with Stripe, Jira, or your Database.

/**
 * @description Mock tool to fetch user subscription details.
 * Simulates an API call to a billing service.
 */
const fetchUserSubscription = async (userId: string) => {
    // Simulate async network delay
    await new Promise((resolve) => setTimeout(resolve, 100));
    return JSON.stringify({ plan: "Pro", status: "Active", overdue: false });
};

/**
 * @description Mock tool to escalate a ticket to a human agent.
 * Simulates an API call to a support desk (e.g., Zendesk).
 */
const escalateToHuman = async (reason: string) => {
    await new Promise((resolve) => setTimeout(resolve, 100));
    return JSON.stringify({ ticketId: "HUMAN-" + Date.now(), assignedTo: "Tier-2-Support" });
};

// ==========================================
// 2. ORCHESTRATION LOGIC (THE LOOP)
// ==========================================

/**
 * @description The "Reason" Node.
 * Uses the LLM to decide the next step based on the current state.
 * This is the Model component of the agent.
 */
const reasonNode = async (state: AgentState): Promise<Partial<AgentState>> => {
    const model = new ChatOpenAI({ model: "gpt-3.5-turbo", temperature: 0 });

    // Construct a prompt that enforces the ReAct pattern (Reasoning and Acting)
    const systemPrompt = `
    You are an AI Support Agent for a SaaS platform.
    Current Ticket ID: ${state.ticketId}
    Current Iteration: ${state.iterationCount}
    
    Available Tools:
    1. fetchUserSubscription(userId: string) - Check if user is on a paid plan.
    2. escalateToHuman(reason: string) - Escalate if the issue is complex or billing-related.

    Analyze the user's message and decide the next step.
    If the issue is resolved, output "FINAL_ANSWER".
    If you need to use a tool, output "TOOL_CALL: [ToolName]:[Args]".
    `;

    const lastMessage = state.messages[state.messages.length - 1].content;
    
    const response = await model.invoke([
        { role: "system", content: systemPrompt },
        { role: "user", content: lastMessage }
    ]);

    const content = response.content as string;
    
    // Update state with the LLM's reasoning trace
    return {
        messages: [...state.messages, { role: "assistant", content }]
    };
};

/**
 * @description The "Act" Node.
 * Parses the LLM output and executes tools if necessary.
 */
const actNode = async (state: AgentState): Promise<Partial<AgentState>> => {
    const lastMessage = state.messages[state.messages.length - 1].content as string;
    
    // Simple parsing logic for demonstration
    if (lastMessage.includes("TOOL_CALL: fetchUserSubscription")) {
        const result = await fetchUserSubscription("user-123");
        return {
            messages: [...state.messages, { role: "tool", content: `Result: ${result}` }]
        };
    }
    
    if (lastMessage.includes("TOOL_CALL: escalateToHuman")) {
        const result = await escalateToHuman("Billing inquiry");
        return {
            messages: [...state.messages, { role: "tool", content: `Escalated: ${result}` }],
            status: "escalated"
        };
    }

    // If no tool call is detected, we assume the LLM is reasoning or finished
    return { messages: state.messages };
};

/**
 * @description The "Router" Node (Conditional Edge).
 * Implements the Cyclical Graph Structure and Max Iteration Policy.
 * Decides whether to loop back to 'reason' or terminate.
 */
const router = (state: AgentState): string => {
    // GUARDRAIL: Max Iteration Policy
    if (state.iterationCount >= state.maxIterations) {
        console.warn(`[Guardrail] Max iterations (${state.maxIterations}) reached. Terminating.`);
        return "end";
    }

    const lastMessage = state.messages[state.messages.length - 1].content as string;

    // Check for termination signals
    if (lastMessage.includes("FINAL_ANSWER")) {
        return "end";
    }

    // Check if a tool was just called (meaning we should loop back to Reason)
    if (state.messages[state.messages.length - 1].role === "tool") {
        // Increment iteration count for the next loop
        state.iterationCount++;
        return "reason"; 
    }

    // If the LLM just reasoned, we need to act
    if (state.messages[state.messages.length - 1].role === "assistant") {
        return "act";
    }

    return "end";
};

// ==========================================
// 3. GRAPH COMPILATION & EXECUTION
// ==========================================

/**
 * @description Main function to build and run the LangGraph.
 */
async function runSupportAgent() {
    console.log("--- Initializing SaaS Support Agent ---");

    // 1. Define the State Graph
    const workflow = new StateGraph<AgentState>({
        channels: {
            messages: { reducer: (state, update) => [...state, ...update], default: () => [] },
            ticketId: { reducer: (state, update) => update, default: () => "TICK-101" },
            iterationCount: { reducer: (state, update) => update, default: () => 0 },
            maxIterations: { reducer: (state, update) => update, default: () => 3 },
            status: { reducer: (state, update) => update, default: () => "pending" }
        }
    });

    // 2. Add Nodes
    workflow.addNode("reason", reasonNode);
    workflow.addNode("act", actNode);
    workflow.addNode("end", (state) => {
        console.log("--- Agent Workflow Completed ---");
        console.log(`Final Status: ${state.status}`);
        console.log(`Total Iterations: ${state.iterationCount}`);
        return state;
    });

    // 3. Define Edges (The Logic Flow)
    workflow.addEdge(START, "reason");
    
    // The conditional edge creates the loop
    workflow.addConditionalEdges(
        "act", 
        router, 
        { "reason": "reason", "end": "end" }
    );
    
    // Also route from reason -> act (unless it finished immediately)
    // In a more complex graph, this would also be a conditional edge
    workflow.addConditionalEdges(
        "reason",
        router,
        { "act": "act", "end": "end" }
    );

    // 4. Compile the Graph
    const app = workflow.compile();

    // 5. Execute
    // Initial user request triggering the loop
    const initialInput: Partial<AgentState> = {
        messages: [{ role: "user", content: "I need to check my subscription status and then talk to billing." }]
    };

    try {
        // .stream() is ideal for real-time UI updates in Next.js
        const stream = await app.stream(initialInput, { recursionLimit: 10 });
        
        for await (const output of stream) {
            // In a Next.js app, you would update React state here
            const node = Object.keys(output)[0];
            const data = output[node];
            console.log(`[Node: ${node}]`, data.status || "Processing...");
        }
    } catch (error) {
        console.error("Agent execution failed:", error);
    }
}

// Execute the script
runSupportAgent();
