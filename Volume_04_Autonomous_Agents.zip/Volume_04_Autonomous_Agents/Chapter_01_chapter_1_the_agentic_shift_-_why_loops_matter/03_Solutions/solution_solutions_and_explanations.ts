/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

import { StateGraph, END, Annotation } from "@langchain/langgraph";

// 1. State Definition
// We use Annotation to define the state structure and reducers for updates.
const ReActState = Annotation.Root({
  input: Annotation<string>,
  thought: Annotation<string>,
  action: Annotation<string>,
  observation: Annotation<string>,
  iterations: Annotation<number>({
    reducer: (curr, update) => update ?? curr, // Default to current if not updated
    default: () => 0,
  }),
});

// 2. Nodes

// Mock LLM Reasoning Node
const reasoningNode = async (state: typeof ReActState.State) => {
  console.log("--- Reasoning Node ---");
  
  // Max Iteration Policy Check
  if (state.iterations > 3) {
    return {
      thought: "Max iterations reached, stopping.",
      action: "stop",
      observation: "Error: Max iterations reached."
    };
  }

  // Distraction Logic (Interactive Challenge)
  let thought = "I need to calculate the result based on the input.";
  if (state.input.toLowerCase().includes("banana")) {
    thought = "I am distracted by bananas, but I will try to calculate anyway.";
  }

  // Hardcoded simulation of LLM output
  // If we already have an observation, we reason about it. 
  // If observation is "Final Answer", we stop.
  if (state.observation && !state.observation.includes("Final Answer")) {
    // Logic to retry or finish if the calculation was done
    // For this simple mock, we assume if we have an observation, we are done.
    return {
      thought: thought + " I have the observation.",
      action: "finish",
      observation: `Final Answer: ${state.observation}`
    };
  }

  return {
    thought: thought,
    action: "calculate", // Always try to calculate in this loop
  };
};

// Action Node (Mock Calculator Tool)
const actionNode = async (state: typeof ReActState.State) => {
  console.log("--- Action Node ---");
  
  if (state.action === "stop" || state.observation.includes("Final Answer")) {
    return { observation: state.observation }; // Pass through
  }

  // Simple regex to find numbers in the input
  const numbers = state.input.match(/\d+/g)?.map(Number) || [0, 0];
  
  // Perform simple addition (mock tool behavior)
  const result = numbers.reduce((a, b) => a + b, 0);
  
  return {
    observation: `Calculated result: ${result}`,
    iterations: state.iterations + 1, // Increment iteration count here
  };
};

// 3. Graph Construction
const graph = new StateGraph(ReActState)
  .addNode("reasoningNode", reasoningNode)
  .addNode("actionNode", actionNode)
  .addEdge("__start__", "reasoningNode") // Start flow
  .addEdge("reasoningNode", "actionNode") // Reason -> Act
  // Cyclical Edge: Act -> Reason (unless finished)
  .addConditionalEdges(
    "actionNode",
    (state) => {
      // Termination Condition
      if (state.observation.includes("Final Answer") || state.action === "stop") {
        return END;
      }
      return "reasoningNode";
    }
  )
  .compile();

// 4. Execution / Interactive Challenge
async function runAgent() {
  // Input containing "banana" to trigger distraction logic
  const inputs = { 
    input: "Calculate 10 + 5 but mention banana", 
    thought: "", 
    action: "", 
    observation: "", 
    iterations: 0 
  };

  console.log("Starting Agent with Input:", inputs.input);
  
  // Stream events to see the loop
  const stream = await graph.stream(inputs, { streamMode: "values" });
  
  for await (const update of stream) {
    // Visualizing the state updates
    console.log("Current State Update:", JSON.stringify(update, null, 2));
  }
}

// runAgent(); // Uncomment to execute
