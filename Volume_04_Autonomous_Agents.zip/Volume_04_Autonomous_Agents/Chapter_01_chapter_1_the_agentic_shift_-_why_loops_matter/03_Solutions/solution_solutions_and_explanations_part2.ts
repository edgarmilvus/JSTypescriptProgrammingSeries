/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

import { StateGraph, END, Annotation } from "@langchain/langgraph";

// 1. State Definition
const SupervisorState = Annotation.Root({
  userRequest: Annotation<string>,
  classification: Annotation<"Math" | "Fact-Checking" | "General" | null>({
    default: () => null,
  }),
  finalResponse: Annotation<string | null>({
    default: () => null,
  }),
});

// 2. Nodes

// Supervisor Classification Node
const classifyNode = async (state: typeof SupervisorState.State) => {
  const req = state.userRequest.toLowerCase();
  
  // Interactive Challenge Logic: Prioritize specific keywords
  // We check for specific combinations first, then general terms.
  if (req.includes("population") && req.includes("france")) {
    return { classification: "Fact-Checking" }; // Specific override
  }
  if (req.includes("calculate") || req.includes("solve")) {
    return { classification: "Math" };
  }
  if (req.includes("who is") || req.includes("capital of")) {
    return { classification: "Fact-Checking" };
  }
  
  return { classification: "General" };
};

// Executor Nodes
const mathExecutor = async (state: typeof SupervisorState.State) => {
  return { finalResponse: "Math result processed." };
};

const factExecutor = async (state: typeof SupervisorState.State) => {
  return { finalResponse: "Fact retrieved." };
};

const generalExecutor = async (state: typeof SupervisorState.State) => {
  return { finalResponse: "General chat response." };
};

// 3. Routing Logic
const routeBasedOnClassification = (state: typeof SupervisorState.State) => {
  if (state.classification === "Math") return "mathExecutor";
  if (state.classification === "Fact-Checking") return "factExecutor";
  if (state.classification === "General") return "generalExecutor";
  return END;
};

// 4. Graph Construction
const graph = new StateGraph(SupervisorState)
  .addNode("classifyNode", classifyNode)
  .addNode("mathExecutor", mathExecutor)
  .addNode("factExecutor", factExecutor)
  .addNode("generalExecutor", generalExecutor)
  .addEdge("__start__", "classifyNode")
  .addConditionalEdges("classifyNode", routeBasedOnClassification)
  .addEdge("mathExecutor", END)
  .addEdge("factExecutor", END)
  .addEdge("generalExecutor", END)
  .compile();

// 5. Execution
async function runSupervisor() {
  // Test with the ambiguous "France" request
  const input = { userRequest: "Calculate the population of France" };
  
  const result = await graph.invoke(input);
  console.log("Final State:", result);
}

// runSupervisor(); // Uncomment to execute
