/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState, useEffect, useRef } from 'react';

// --- Type Definitions ---

// Simplified Graph Definition
interface GraphNode {
  id: string;
  type: 'supervisor' | 'executor' | 'action';
}

interface GraphDefinition {
  nodes: GraphNode[];
}

// Mock Stream Type (Async Iterator)
type AgentStream = AsyncIterable<{ 
  event: 'on_node_start' | 'on_state_update', 
  node?: string, 
  state?: any 
}>;

// Props Interface
interface AgentGraphVisualizerProps {
  graphDefinition: GraphDefinition;
  stream: AgentStream;
}

// --- Component Implementation ---

export const AgentGraphVisualizer: React.FC<AgentGraphVisualizerProps> = ({ 
  graphDefinition, 
  stream 
}) => {
  // State Management
  const [activeNode, setActiveNode] = useState<string | null>(null);
  const [history, setHistory] = useState<any[]>([]);
  const [currentState, setCurrentState] = useState<any>({});
  const [isPaused, setIsPaused] = useState(false);
  
  // Buffer for pause functionality
  const eventBuffer = useRef<any[]>([]);
  const isConsuming = useRef(false);

  // Helper to consume stream
  const consumeStream = async () => {
    if (isConsuming.current) return;
    isConsuming.current = true;

    for await (const event of stream) {
      // Pause Logic: Buffer events instead of processing them
      if (isPaused) {
        eventBuffer.current.push(event);
        continue;
      }

      // Simulate "Slow Motion" (Interactive Challenge)
      await new Promise(resolve => setTimeout(resolve, 500)); 

      if (event.event === 'on_node_start' && event.node) {
        setActiveNode(event.node);
        setHistory(prev => [...prev, { node: event.node, timestamp: Date.now() }]);
      }
      
      if (event.event === 'on_state_update' && event.state) {
        setCurrentState(event.state);
      }
    }
    isConsuming.current = false;
  };

  // Event Handling via useEffect
  useEffect(() => {
    consumeStream();
  }, [stream, isPaused]); // Re-run if stream changes or pause state changes

  // Resume Handler
  const handleResume = () => {
    setIsPaused(false);
    // Process buffered events immediately upon resume
    const buffered = [...eventBuffer.current];
    eventBuffer.current = []; // Clear buffer
    
    buffered.forEach(event => {
      if (event.event === 'on_node_start' && event.node) {
        setActiveNode(event.node);
        setHistory(prev => [...prev, { node: event.node }]);
      }
      if (event.event === 'on_state_update' && event.state) {
        setCurrentState(event.state);
      }
    });
  };

  // Styling Helpers
  const getNodeClass = (nodeId: string) => {
    const node = graphDefinition.nodes.find(n => n.id === nodeId);
    const base = "p-2 border rounded m-1 ";
    if (node?.type === 'supervisor') return base + "bg-purple-200";
    if (node?.type === 'executor') return base + "bg-green-200";
    return base + "bg-gray-200";
  };

  const isActive = (nodeId: string) => nodeId === activeNode ? "ring-4 ring-blue-500 scale-105" : "";

  return (
    <div style={{ display: 'flex', border: '1px solid #ccc', padding: '10px' }}>
      {/* Visual Graph Section */}
      <div style={{ flex: 1, borderRight: '1px solid #eee', paddingRight: '10px' }}>
        <h3>Graph Execution</h3>
        <div style={{ display: 'flex', flexWrap: 'wrap' }}>
          {graphDefinition.nodes.map(node => (
            <div 
              key={node.id} 
              className={`${getNodeClass(node.id)} ${isActive(node.id)}`}
            >
              {node.id}
              {node.id === activeNode && <span> (Active)</span>}
            </div>
          ))}
        </div>
        
        {/* Controls */}
        <div style={{ marginTop: '10px' }}>
          <button 
            onClick={() => setIsPaused(true)} 
            disabled={isPaused}
            style={{ marginRight: '5px', padding: '5px' }}
          >
            Pause
          </button>
          <button 
            onClick={handleResume} 
            disabled={!isPaused}
            style={{ padding: '5px' }}
          >
            Resume
          </button>
        </div>
      </div>

      {/* State Details Section */}
      <div style={{ flex: 1, paddingLeft: '10px' }}>
        <h3>Current State</h3>
        <div style={{ background: '#f5f5f5', padding: '10px', fontFamily: 'monospace' }}>
          <p><strong>Iterations:</strong> {currentState.iterations || 0}</p>
          <p><strong>Thought:</strong> {currentState.thought || '-'}</p>
          <p><strong>Action:</strong> {currentState.action || '-'}</p>
          <p><strong>Observation:</strong> {currentState.observation || '-'}</p>
        </div>

        <h3 style={{ marginTop: '15px' }}>History</h3>
        <ul style={{ maxHeight: '150px', overflowY: 'auto' }}>
          {history.map((h, i) => (
            <li key={i}>{h.node}</li>
          ))}
        </ul>
      </div>
    </div>
  );
};
