/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

import { StateGraph, END, Annotation } from "@langchain/langgraph";

// 1. State Definition
const RefinementState = Annotation.Root({
  topic: Annotation<string>,
  draft: Annotation<string>({ default: () => "" }),
  critique: Annotation<string>({ default: () => "" }),
  refinementCount: Annotation<number>({
    reducer: (curr, update) => update ?? curr,
    default: () => 0,
  }),
});

// 2. Nodes

// Draft Node
const draftNode = async (state: typeof RefinementState.State) => {
  // Uses previous critique to improve (if any)
  const improvement = state.critique ? " (Improved based on critique)" : "";
  const version = `Draft v${state.refinementCount + 1}`;
  
  // Mock generation
  const newDraft = `${version}: A poem about ${state.topic}. ${improvement} Bad.`;
  
  return { 
    draft: newDraft,
    refinementCount: state.refinementCount + 1 
  };
};

// Critique Node (with Hallucination Bug)
const critiqueNode = async (state: typeof RefinementState.State) => {
  // Interactive Challenge: Random Hallucination Bug
  const isHallucination = Math.random() > 0.7; // 30% chance of bug

  if (isHallucination) {
    // Bug: Returns irrelevant string
    return { critique: "The sky is blue." };
  }

  // Logic: Check for "Bad" in draft
  if (state.draft.includes("Bad")) {
    return { critique: "Critique: The draft is boring and cliché." };
  }
  
  return { critique: "Critique: Looks good." };
};

// Check Node (The Fix)
const checkNode = async (state: typeof RefinementState.State) => {
  // Fix for Hallucination Bug: Strict Validation
  const validCritique = state.critique.startsWith("Critique:") || state.critique.startsWith("Looks good");
  
  if (!validCritique) {
    // If hallucinated, treat as error to stop loop or force retry
    return { critique: "Error: Invalid critique format detected." };
  }

  // Standard Logic
  const isPositive = state.critique.includes("Looks good");
  const maxIter = state.refinementCount >= 3;

  if (isPositive) {
    return { critique: "Final: " + state.critique };
  }
  
  if (maxIter) {
    return { critique: "Final: Max refinement iterations reached." };
  }

  // If negative and under limit, return state (loop continues)
  return state;
};

// 3. Graph Construction
const graph = new StateGraph(RefinementState)
  .addNode("draftNode", draftNode)
  .addNode("critiqueNode", critiqueNode)
  .addNode("checkNode", checkNode)
  .addEdge("__start__", "draftNode")
  .addEdge("draftNode", "critiqueNode")
  .addEdge("critiqueNode", "checkNode")
  .addConditionalEdges(
    "checkNode",
    (state) => {
      // If critique starts with "Final:" or is an Error, end.
      if (state.critique.startsWith("Final:") || state.critique.startsWith("Error:")) {
        return END;
      }
      // Otherwise, loop back
      return "draftNode";
    }
  )
  .compile();

// 4. Execution
async function runRefinement() {
  const result = await graph.stream(
    { topic: "The Ocean", refinementCount: 0 }, 
    { streamMode: "values" }
  );

  for await (const update of result) {
    console.log("--- Update ---");
    console.log(`Draft: ${update.draft}`);
    console.log(`Critique: ${update.critique}`);
    console.log(`Count: ${update.refinementCount}`);
  }
}

// runRefinement(); // Uncomment to execute
