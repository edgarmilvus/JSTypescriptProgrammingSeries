/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

import { StateGraph, END, Annotation } from "@langchain/langgraph";

// --- 1. Mock Database & Types ---
interface Checkpoint {
  threadId: string;
  state: any;
  nextNode?: string; // Where to resume
}

const db: { checkpoints: Record<string, Checkpoint> } = { checkpoints: {} };

// Re-use the ReActState from Exercise 1
const ReActState = Annotation.Root({
  input: Annotation<string>,
  thought: Annotation<string>,
  action: Annotation<string>,
  observation: Annotation<string>,
  iterations: Annotation<number>({
    reducer: (curr, update) => update ?? curr,
    default: () => 0,
  }),
  threadId: Annotation<string>, // Added for identification
});

// --- 2. Nodes with Persistence Logic ---

const reasoningNode = async (state: typeof ReActState.State) => {
  // Simple logic to finish if we have an observation
  if (state.observation && !state.observation.includes("Final")) {
    return { thought: "Reasoning to finish", action: "finish" };
  }
  return { thought: "Thinking...", action: "calculate" };
};

const actionNode = async (state: typeof ReActState.State) => {
  // Checkpoint Logic: Save to DB BEFORE returning new state
  if (state.threadId) {
    console.log(`[Checkpoint] Saving state for thread: ${state.threadId} at iteration ${state.iterations}`);
    
    // Update the state that will be saved
    const stateToSave = {
      ...state,
      iterations: state.iterations + 1,
      observation: state.action === "calculate" ? "Result: 42" : "Done"
    };

    db.checkpoints[state.threadId] = {
      threadId: state.threadId,
      state: stateToSave,
      nextNode: "reasoningNode" // We know we loop back here
    };

    return stateToSave;
  }
  return { observation: "Error: No Thread ID" };
};

// --- 3. Graph Definition ---
const graph = new StateGraph(ReActState)
  .addNode("reasoningNode", reasoningNode)
  .addNode("actionNode", actionNode)
  .addEdge("__start__", "reasoningNode")
  .addEdge("reasoningNode", "actionNode")
  .addConditionalEdges("actionNode", (state) => {
    if (state.iterations >= 3) return END; // Stop after 3 checkpoints
    return "reasoningNode";
  })
  .compile();

// --- 4. Resumption Logic ---

// Helper to run partial graph (simulating a resume)
async function runFromNode(nodeName: string, state: any) {
  // In a real scenario, we would compile a subgraph or use the `start` feature.
  // Here, we manually invoke the node logic to simulate the resume.
  console.log(`\n>>> Resuming execution from ${nodeName}...`);
  
  if (nodeName === "reasoningNode") {
    const newState = await reasoningNode(state);
    const merged = { ...state, ...newState };
    const actionRes = await actionNode(merged);
    return { ...merged, ...actionRes };
  }
  return state;
}

async function resumeAgent(threadId: string) {
  const checkpoint = db.checkpoints[threadId];
  
  if (!checkpoint) {
    console.log("No checkpoint found.");
    return;
  }

  console.log("Loaded State:", JSON.stringify(checkpoint.state, null, 2));
  
  // Resume execution
  // Note: In this manual simulation, we run one cycle. 
  // A full LangGraph implementation would use `graph.updateState` and `graph.stream`.
  await runFromNode(checkpoint.nextNode || "reasoningNode", checkpoint.state);
}

// --- 5. Verification Flow ---

async function runPersistenceDemo() {
  const threadId = "session-123";
  
  // 1. Initial Run (Simulate 2 iterations)
  console.log("--- Initial Run (2 iterations) ---");
  
  // Iteration 1
  let state = { input: "Math problem", thought: "", action: "", observation: "", iterations: 0, threadId };
  state = { ...state, ...(await reasoningNode(state)) };
  state = { ...state, ...(await actionNode(state)) }; // Saves to DB
  
  // Iteration 2
  state = { ...state, ...(await reasoningNode(state)) };
  state = { ...state, ...(await actionNode(state)) }; // Saves to DB (Overwrites)

  console.log("Current DB State:", JSON.stringify(db.checkpoints[threadId], null, 2));

  // 2. "Crash" (Process stops, variables lost)

  // 3. Resumption
  await resumeAgent(threadId);
}

// runPersistenceDemo(); // Uncomment to execute
