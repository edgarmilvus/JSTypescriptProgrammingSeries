/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: theory_theoretical_foundations.ts
// Description: Theoretical Foundations
// ==========================================

import { z } from "zod";

// This is the blueprint for our agent's memory.
// It defines what data the agent must track throughout its execution.
const AgentStateSchema = z.object({
  // The original input from the user.
  input: z.string(),

  // An array to store the sequence of thoughts and actions.
  // This is the agent's "chain of thought" or "trace".
  messages: z.array(
    z.object({
      role: z.enum(["agent", "tool", "system"]),
      content: z.string(),
    })
  ),

  // The final, formatted answer to be returned to the user.
  finalAnswer: z.string().optional(),

  // A flag to control the graph's execution flow.
  // This is read by the conditional edge to decide the next step.
  shouldContinue: z.boolean(),

  // A counter to prevent infinite loops.
  iterationCount: z.number().default(0),
});

// In a real implementation, we would use this schema to define the graph's state.
// For now, we just conceptualize it as the "shape" of the data flowing through the graph.
type AgentState = z.infer<typeof AgentStateSchema>;
