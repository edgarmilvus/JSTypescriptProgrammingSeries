/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * SaaS Multi-Agent Workflow: "Hello World" Example
 * 
 * Context: A user submits a request to a SaaS dashboard.
 * Goal: Demonstrate a cyclical ReAct loop using LangGraph.js.
 * 
 * Dependencies: @langchain/core, zod
 */

import { z } from "zod";
import { StateGraph, START, END } from "@langchain/core/graphs/state_graph";
import { Annotation } from "@langchain/core/langgraph";

// ==========================================
// 1. Define the Shared State Schema
// ==========================================

/**
 * We use Zod to define the structure of our Graph State.
 * This ensures type safety across our nodes.
 * 
 * @property {string} input - The original user request.
 * @property {string[]} steps - A log of actions taken by the agents.
 * @property {string} status - Current state of the workflow (e.g., "thinking", "acting", "finished").
 * @property {boolean} shouldContinue - A flag used by conditional edges to decide the next node.
 */
const GraphState = Annotation.Root({
    input: Annotation<string>({
        reducer: (curr, update) => update ?? curr, // Keep existing value if update is undefined
        default: () => "",
    }),
    steps: Annotation<string[]>({
        reducer: (curr, update) => [...curr, update], // Append new steps to the array
        default: () => [],
    }),
    status: Annotation<string>({
        reducer: (curr, update) => update,
        default: () => "idle",
    }),
    shouldContinue: Annotation<boolean>({
        reducer: (curr, update) => update,
        default: () => false,
    }),
});

// ==========================================
// 2. Define Node Logic (Agents)
// ==========================================

/**
 * NODE: Reasoner Agent
 * 
 * This node simulates an LLM analyzing the input and deciding if an action is needed.
 * In a real app, this would call an LLM (e.g., GPT-4).
 * 
 * @param state - The current GraphState
 * @returns Partial<GraphState> - The updated state
 */
const reasonerNode = (state: typeof GraphState.State): Partial<typeof GraphState.State> => {
    console.log("🤖 [Reasoner] Thinking...");

    // Simulate LLM logic:
    // If the input contains "search", we need an action.
    // Otherwise, we might be done.
    const needsAction = state.input.toLowerCase().includes("search");
    const actionDescription = needsAction 
        ? `I need to perform a web search for: "${state.input}"` 
        : `I understand the request: "${state.input}". No external action needed.`;

    return {
        steps: [...state.steps, `Reasoning: ${actionDescription}`],
        status: needsAction ? "acting" : "finished",
        shouldContinue: needsAction, // This flag tells the edge what to do
    };
};

/**
 * NODE: Actor Agent
 * 
 * This node simulates an LLM performing an external action (like a tool call).
 * 
 * @param state - The current GraphState
 * @returns Partial<GraphState> - The updated state
 */
const actorNode = (state: typeof GraphState.State): Partial<typeof GraphState.State> => {
    console.log("⚡ [Actor] Executing action...");

    // Simulate a tool execution (e.g., fetching data from an API)
    // In a real app, this might fetch data from a database or call a 3rd party API.
    const mockApiResult = "Found result: 'LangGraph.js Documentation'";

    return {
        steps: [...state.steps, `Action: ${mockApiResult}`],
        status: "reasoning", // Go back to reasoning to process the result
        shouldContinue: true, // Keep the loop going
    };
};

// ==========================================
// 3. Define Conditional Logic
// ==========================================

/**
 * EDGE CONDITION: decideNextStep
 * 
 * This function inspects the state to determine which node to run next.
 * It enables the cyclical behavior.
 * 
 * @param state - The current GraphState
 * @returns string - The name of the next node (or END)
 */
const decideNextStep = (state: typeof GraphState.State): string => {
    // If the status is "finished", we terminate the graph
    if (state.status === "finished") {
        return END;
    }

    // If the status is "acting", go to the Actor node
    if (state.status === "acting") {
        return "actor_node";
    }

    // Default: Go back to the Reasoner node
    return "reasoner_node";
};

// ==========================================
// 4. Build and Compile the Graph
// ==========================================

/**
 * Main Graph Construction
 */
const workflow = new StateGraph(GraphState);

// Add nodes to the graph
workflow.addNode("reasoner_node", reasonerNode);
workflow.addNode("actor_node", actorNode);

// Define the entry point
workflow.addEdge(START, "reasoner_node");

// Define the conditional edge
// The graph calls 'decideNextStep' after 'actor_node' finishes
workflow.addConditionalEdges(
    "actor_node",
    decideNextStep
);

// Add a standard edge from the reasoner back to the conditional check
// (In this simple loop, we actually just want to check the condition after the actor runs,
// but for a robust ReAct loop, we might check after the reasoner too if it finishes immediately).
// For this specific example, we will route reasoner -> actor directly if action is needed,
// but the conditional edge handles the branching.
// To keep it simple and cyclical:
workflow.addConditionalEdges(
    "reasoner_node",
    (state) => {
        // If reasoner says we should continue (needs action), go to actor.
        // If reasoner says finished (no action needed), go to END.
        return state.shouldContinue ? "actor_node" : END;
    }
);

// Compile the graph into an executable runtime
const app = workflow.compile();

// ==========================================
// 5. Execution
// ==========================================

/**
 * Main function to run the SaaS Workflow
 */
const runSaaSWorkflow = async () => {
    console.log("🚀 SaaS Dashboard: Initializing Agent Workflow...\n");

    // Initial State
    const initialState = {
        input: "Search for latest LangGraph updates",
        steps: [],
        status: "idle",
        shouldContinue: false,
    };

    // Execute the graph stream
    // We use stream to see the step-by-step execution
    const stream = await app.stream({ input: initialState.input });

    for await (const output of stream) {
        // Access the node name from the output keys
        const nodeName = Object.keys(output)[0];
        const nodeState = output[nodeName];

        console.log(`--- Step Executed: ${nodeName} ---`);
        console.log(`Status: ${nodeState.status}`);
        console.log(`Log: ${nodeState.steps[nodeState.steps.length - 1]}`);
        console.log(""); // Empty line for readability
    }

    console.log("✅ Workflow Complete.");
};

// Run the example
runSaaSWorkflow().catch(console.error);
