/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// app/api/support-agent/route.ts
import { NextResponse } from 'next/server';
import { StateGraph, START, END, Annotation } from '@langchain/langgraph';
import { ChatOpenAI } from '@langchain/openai';
import { ToolNode } from '@langchain/langgraph/prebuilt';

// ==========================================
// 1. STATE DEFINITION & SCHEMA
// ==========================================

/**
 * Defines the shared state structure for the graph.
 * Using Zod-like annotations (via LangChain's Annotation) ensures type safety
 * across all nodes. This state persists throughout the ReAct loop.
 */
const StateAnnotation = Annotation.Root({
  // The original user query
  input: Annotation<string>(),
  // The agent's current reasoning step (Thought)
  reasoning: Annotation<string>({
    reducer: (curr, update) => update, // Simply overwrite
    default: () => '',
  }),
  // The tool selected and executed (Action)
  action: Annotation<string>({
    reducer: (curr, update) => update,
    default: () => '',
  }),
  // The result from the tool (Observation)
  observation: Annotation<string>({
    reducer: (curr, update) => update,
    default: () => '',
  }),
  // The final answer to the user
  finalAnswer: Annotation<string>({
    reducer: (curr, update) => update,
    default: () => '',
  }),
});

// ==========================================
// 2. MOCK TOOLS & ASYNC HANDLING
// ==========================================

/**
 * Simulates a Knowledge Base search tool.
 * In a real app, this would query a vector store (e.g., Pinecone).
 * We wrap this in a Promise to simulate network latency and ensure
 * non-blocking execution (Asynchronous Tool Handling).
 */
const searchKnowledgeBase = async (query: string): Promise<string> => {
  console.log(`[Tool] Searching KB for: "${query}"`);
  // Simulate async delay
  await new Promise((resolve) => setTimeout(resolve, 500));
  
  if (query.toLowerCase().includes('password')) {
    return "KB Article #402: To reset password, go to Settings > Security.";
  }
  return "KB Article #101: General features overview.";
};

/**
 * Simulates a Billing API tool.
 * Checks subscription status or processes a refund.
 */
const checkBillingStatus = async (userId: string): Promise<string> {
  console.log(`[Tool] Checking billing for user: ${userId}`);
  await new Promise((resolve) => setTimeout(resolve, 600));
  return "User has active 'Pro' subscription. No outstanding invoices.";
};

// ==========================================
// 3. GRAPH NODES
// ==========================================

/**
 * Node: Reasoning (Thought)
 * Uses an LLM to analyze the current state and decide the next step.
 * It outputs a structured decision: 'search', 'billing', or 'answer'.
 */
const reasoningNode = async (state: typeof StateAnnotation.State) => {
  const model = new ChatOpenAI({ model: 'gpt-3.5-turbo', temperature: 0 });
  
  const prompt = `
    You are a support agent. Analyze the user input and previous context.
    User Input: "${state.input}"
    Previous Observation: "${state.observation}"
    
    Decide the next step:
    1. If the query is about technical help or documentation, use 'search'.
    2. If the query is about account/payment, use 'billing'.
    3. If you have enough info to answer, use 'answer'.
    
    Respond ONLY with the decision word: 'search', 'billing', or 'answer'.
  `;

  const response = await model.invoke(prompt);
  const decision = response.content.toString().trim().toLowerCase();

  return { 
    reasoning: `Decided to action: ${decision}` 
  };
};

/**
 * Node: Action (Tool Execution)
 * Routes the execution to the appropriate tool based on the LLM's decision.
 * This node handles Asynchronous Tool Handling explicitly.
 */
const actionNode = async (state: typeof StateAnnotation.State) => {
  // We parse the reasoning output from the previous step to determine the tool.
  // In a production app, we would use structured output (JSON) from the LLM.
  const decision = state.reasoning.includes('search') ? 'search' 
                 : state.reasoning.includes('billing') ? 'billing' 
                 : 'none';

  let result = '';
  
  if (decision === 'search') {
    result = await searchKnowledgeBase(state.input);
  } else if (decision === 'billing') {
    // Mocking a user ID extraction
    result = await checkBillingStatus('user_12345');
  }

  return {
    action: `Executed: ${decision}`,
    observation: result,
  };
};

/**
 * Node: Decision (Router)
 * Evaluates if the loop should continue or terminate.
 * This logic is often handled by conditional edges, but for explicit
 * control flow in this example, we use a dedicated node logic.
 */
const shouldContinue = (state: typeof StateAnnotation.State): 'continue' | 'end' => {
  // If we have an observation but no final answer, keep going
  if (state.observation && !state.finalAnswer) {
    return 'continue';
  }
  // If the LLM decided to answer (handled in a separate node or logic), end
  if (state.finalAnswer) {
    return 'end';
  }
  return 'continue';
};

/**
 * Node: Final Answer Generator
 * Synthesizes the observation into a human-readable response.
 */
const answerNode = async (state: typeof StateAnnotation.State) => {
  const model = new ChatOpenAI({ model: 'gpt-3.5-turbo', temperature: 0 });
  
  const prompt = `
    Synthesize a helpful response for the user.
    User Input: "${state.input}"
    Relevant Info: "${state.observation}"
    
    Provide a concise answer.
  `;

  const response = await model.invoke(prompt);
  
  return {
    finalAnswer: response.content.toString(),
    // Clear intermediate states for cleanliness
    reasoning: '',
    action: '',
    observation: '',
  };
};

// ==========================================
// 4. GRAPH CONSTRUCTION & EXECUTION
// ==========================================

/**
 * Builds and compiles the LangGraph.
 * This function sets up the nodes and the cyclical edges (ReAct Loop).
 */
function buildSupportGraph() {
  const workflow = new StateGraph(StateAnnotation);

  // Define nodes
  workflow.addNode('reasoning', reasoningNode);
  workflow.addNode('action', actionNode);
  workflow.addNode('answer', answerNode);

  // Define entry point
  workflow.addEdge(START, 'reasoning');

  // Define the ReAct Loop Logic:
  // 1. From 'reasoning', go to 'action' (always)
  workflow.addEdge('reasoning', 'action');

  // 2. From 'action', check the condition using 'shouldContinue'
  workflow.addConditionalEdges(
    'action',
    shouldContinue,
    {
      continue: 'reasoning', // Loop back to reason based on new observation
      end: 'answer',         // Proceed to generate final answer
    }
  );

  // 3. From 'answer', go to END
  workflow.addEdge('answer', END);

  return workflow.compile();
}

/**
 * API Route Handler (Next.js Server Component)
 * Handles the incoming request and executes the graph.
 */
export async function POST(req: Request) {
  try {
    const { query } = await req.json();

    if (!query) {
      return NextResponse.json({ error: 'Query is required' }, { status: 400 });
    }

    // Initialize the graph
    const graph = buildSupportGraph();

    // Execute the graph with initial state
    const inputs = { input: query };
    const finalState = await graph.invoke(inputs);

    return NextResponse.json({
      answer: finalState.finalAnswer,
      // Expose the trace for debugging purposes
      trace: {
        reasoning: finalState.reasoning,
        action: finalState.action,
        observation: finalState.observation,
      }
    });

  } catch (error) {
    console.error('Graph execution failed:', error);
    return NextResponse.json(
      { error: 'Internal Server Error' }, 
      { status: 500 }
    );
  }
}
