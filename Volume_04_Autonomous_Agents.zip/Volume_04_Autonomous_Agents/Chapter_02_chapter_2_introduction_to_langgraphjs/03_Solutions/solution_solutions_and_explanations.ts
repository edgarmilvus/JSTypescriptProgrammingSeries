/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

import { Graph, Node, END, START } from "@langchain/langgraph";
import { z } from "zod";

// 1. Define TaskState schema
const TaskState = z.object({
  originalQuery: z.string(),
  analysis: z.string().default(""),
  plan: z.array(z.string()).default([]),
  stepsCompleted: z.number().default(0),
});

// Infer TypeScript type for state
type TaskState = z.infer<typeof TaskState>;

// 2. Create Nodes
const analyzeNode = new Node<TaskState>({
  name: "analyzeNode",
  action: (state: TaskState) => {
    // Simulate analysis logic
    const analysis = `Analysis: The query "${state.originalQuery}" requires breaking down into research and summarization.`;
    
    return {
      ...state,
      analysis: analysis,
      stepsCompleted: state.stepsCompleted + 1,
    };
  },
});

const planNode = new Node<TaskState>({
  name: "planNode",
  action: (state: TaskState) => {
    // Simulate planning logic
    const plan = [
      "1. Search for current weather data in Tokyo.",
      "2. Summarize findings in 3 bullet points."
    ];

    return {
      ...state,
      plan: plan,
      stepsCompleted: state.stepsCompleted + 1,
    };
  },
});

const endNode = new Node<TaskState>({
  name: "endNode",
  action: (state: TaskState) => {
    console.log(`[End Node] Task processing complete. Steps taken: ${state.stepsCompleted}`);
    return state; // Does not modify state
  },
});

// 3. Define Graph Structure
const graph = new Graph<TaskState>({ 
  schema: TaskState 
})
  .addNode(analyzeNode)
  .addNode(planNode)
  .addNode(endNode)
  .addEdge(START, analyzeNode)
  .addEdge(analyzeNode, planNode)
  .addEdge(planNode, endNode)
  .addEdge(endNode, END);

// 4. Compile and Run
const compiledGraph = graph.compile();

// Initial input
const initialInput = { originalQuery: "Research the weather in Tokyo and summarize it." };

// Execute
(async () => {
  try {
    const result = await compiledGraph.invoke(initialInput);
    console.log("Final State:", result);
  } catch (error) {
    console.error("Graph execution failed:", error);
  }
})();
