/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

import { Graph, Node, END, START } from "@langchain/langgraph";
import { z } from "zod";

// 1. Define ReActState schema
const ReActState = z.object({
  input: z.string(),
  thoughts: z.array(z.string()).default([]),
  actions: z.array(z.string()).default([]),
  iterationCount: z.number().default(0),
});

type ReActState = z.infer<typeof ReActState>;

// 2. Create Reasoning Node
const reasoningNode = new Node<ReActState>({
  name: "reasoningNode",
  action: (state: ReActState) => {
    // Simulate reasoning step
    const newThought = `Thought ${state.iterationCount + 1}: I need to analyze this.`;
    const newAction = `Action ${state.iterationCount + 1}: Search database.`;

    return {
      ...state,
      thoughts: [...state.thoughts, newThought],
      actions: [...state.actions, newAction],
      iterationCount: state.iterationCount + 1,
    };
  },
});

// 3. Implement Conditional Edge Function
const checkIterationLimit = (state: ReActState) => {
  if (state.iterationCount < 3) {
    return "continue"; // Should route to the loop back edge
  }
  return "terminate"; // Should route to END
};

// 4. Define Graph Edges
const graph = new Graph<ReActState>({
  schema: ReActState,
})
  .addNode(reasoningNode)
  // Define the conditional edge mapping
  .addConditionalEdges("reasoningNode", checkIterationLimit, {
    continue: "reasoningNode", // Loop back
    terminate: END,
  })
  .addEdge(START, "reasoningNode");

const compiledGraph = graph.compile();

// Execution
(async () => {
  const input = { input: "Solve the equation." };
  const result = await compiledGraph.invoke(input);
  
  console.log("Execution finished.");
  console.log("Final Iteration Count:", result.iterationCount);
  console.log("Total Thoughts:", result.thoughts.length);
  console.log("Total Actions:", result.actions.length);
})();
