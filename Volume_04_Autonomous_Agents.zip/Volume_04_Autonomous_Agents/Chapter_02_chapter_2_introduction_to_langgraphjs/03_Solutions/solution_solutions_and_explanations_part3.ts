/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

import { Graph, Node, END, START } from "@langchain/langgraph";
import { z } from "zod";

// 1. Define ResearchState schema
const ResearchState = z.object({
  topic: z.string(),
  findings: z.array(z.string()).default([]),
  currentPhase: z.enum(['discovery', 'synthesis', 'finalizing']).default('discovery'),
});

type ResearchState = z.infer<typeof ResearchState>;

// 2. Define Nodes
const discoveryNode = new Node<ResearchState>({
  name: "discovery",
  action: (state) => ({
    ...state,
    findings: [...state.findings, `Discovery: Initial research on ${state.topic}`],
    currentPhase: 'synthesis',
  }),
});

const synthesisNode = new Node<ResearchState>({
  name: "synthesis",
  action: (state) => ({
    ...state,
    findings: [...state.findings, "Synthesis: Connecting concepts."],
    currentPhase: 'finalizing',
  }),
});

const finalizingNode = new Node<ResearchState>({
  name: "finalizing",
  action: (state) => ({
    ...state,
    findings: [...state.findings, "Finalizing: Report generated."],
  }),
});

// 3. Define Graph Logic
// We create a graph that runs discovery, then pauses (interrupts), then continues.
// Note: In a real LangGraph app, we would use `interrupt` after discovery. 
// Here, we simulate the pause by stopping execution manually and saving state.
const graph = new Graph<ResearchState>({ schema: ResearchState })
  .addNode(discoveryNode)
  .addNode(synthesisNode)
  .addNode(finalizingNode)
  .addEdge(START, discoveryNode)
  .addEdge(discoveryNode, synthesisNode)
  .addEdge(synthesisNode, finalizingNode)
  .addEdge(finalizingNode, END);

const compiledGraph = graph.compile();

// 4. Block A: Initial Execution (Run until pause)
(async () => {
  console.log("--- Block A: Initial Run ---");
  const initialInput = { topic: "Quantum Computing" };
  
  // Simulate running until pause (just running discovery node logic manually or via partial execution)
  // For this exercise, we will invoke the graph but stop logic manually to simulate the pause.
  // In a real scenario, we'd use `configurable` and checkpoints.
  
  // Let's simulate the state after discovery node:
  let savedState: ResearchState = {
    topic: "Quantum Computing",
    findings: ["Discovery: Initial research on Quantum Computing"],
    currentPhase: 'synthesis'
  };

  console.log("State saved to persistent store:", savedState);

  // 5. Block B: Hydration and Resume
  console.log("\n--- Block B: Hydration & Resume ---");
  
  // Create a new graph instance
  const newGraphInstance = graph.compile();

  // Hydrate: Pass the saved state as input.
  // Since the graph is linear, we need to determine where to start.
  // In LangGraph, we often use `from` or specific entry points. 
  // Here, we will manually set up the input to effectively start at the next step 
  // or simply run the graph from start but check logic.
  
  // To strictly follow the prompt "resume execution from the synthesis node":
  // We will construct a new graph that starts at synthesis, or we simulate the hydration 
  // by invoking the graph with the saved state.
  
  // Approach: Create a specific "Resume Graph" that starts at synthesis node.
  const resumeGraph = new Graph<ResearchState>({ schema: ResearchState })
    .addNode(synthesisNode)
    .addNode(finalizingNode)
    .addEdge(START, synthesisNode) // Start directly at synthesis
    .addEdge(synthesisNode, finalizingNode)
    .addEdge(finalizingNode, END)
    .compile();

  // Hydrate the graph with the saved state
  const resumedResult = await resumeGraph.invoke(savedState);
  
  console.log("Resumed Result:", resumedResult);
})();
