/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState, useEffect } from 'react';

// 1. Define MarketState type
type MarketState = {
  ticker: string;
  price: string | null;
  news: string[] | null;
  status: 'idle' | 'loading' | 'success' | 'error';
};

// Mock async tools
const fetchPrice = (ticker: string): Promise<string> => 
  new Promise(resolve => setTimeout(() => resolve(`$${(Math.random() * 100).toFixed(2)}`), 2000));

const fetchNews = (ticker: string): Promise<string[]> => 
  new Promise(resolve => setTimeout(() => resolve([`${ticker} hits new high!`, `Analyst upgrade for ${ticker}`]), 3000));

// 2. AgentVisualizer Component
const AgentVisualizer: React.FC = () => {
  // State management
  const [state, setState] = useState<MarketState>({
    ticker: 'AAPL',
    price: null,
    news: null,
    status: 'idle'
  });

  // 4. 'Execute Parallel Tools' Logic
  const executeParallelTools = async () => {
    setState(prev => ({ ...prev, status: 'loading', price: null, news: null }));

    // Simulate parallel execution using Promise.all
    try {
      const [priceResult, newsResult] = await Promise.all([
        fetchPrice(state.ticker),
        fetchNews(state.ticker)
      ]);

      // Update state with results
      setState(prev => ({
        ...prev,
        price: priceResult,
        news: newsResult,
        status: 'success'
      }));
    } catch (error) {
      setState(prev => ({ ...prev, status: 'error' }));
    }
  };

  // 3. & 5. Visual Requirements & Conditional Rendering
  return (
    <div style={{ padding: '20px', fontFamily: 'sans-serif', border: '1px solid #ddd', borderRadius: '8px', maxWidth: '400px' }}>
      <h3>Parallel Tool Execution Visualizer</h3>
      
      <button 
        onClick={executeParallelTools} 
        disabled={state.status === 'loading'}
        style={{ padding: '8px 16px', marginBottom: '20px', cursor: 'pointer' }}
      >
        {state.status === 'loading' ? 'Executing...' : 'Execute Parallel Tools'}
      </button>

      {/* Tool Call Cards */}
      <div style={{ display: 'flex', gap: '10px', marginBottom: '20px' }}>
        
        {/* Price Card */}
        <div style={{ flex: 1, padding: '10px', border: '1px solid #ccc', borderRadius: '4px', background: '#f9f9f9' }}>
          <strong>Price API</strong>
          <div style={{ marginTop: '8px' }}>
            {state.status === 'loading' && state.price === null ? (
              <span style={{ color: '#666' }}>Loading...</span> // Spinner/Skeleton sim
            ) : state.price ? (
              <span style={{ color: 'green', fontWeight: 'bold' }}>{state.price}</span>
            ) : (
              <span style={{ color: '#999' }}>Idle</span>
            )}
          </div>
        </div>

        {/* News Card */}
        <div style={{ flex: 1, padding: '10px', border: '1px solid #ccc', borderRadius: '4px', background: '#f9f9f9' }}>
          <strong>News API</strong>
          <div style={{ marginTop: '8px' }}>
            {state.status === 'loading' && state.news === null ? (
              <span style={{ color: '#666' }}>Loading...</span>
            ) : state.news ? (
              <span style={{ color: 'green', fontWeight: 'bold' }}>Success ({state.news.length} items)</span>
            ) : (
              <span style={{ color: '#999' }}>Idle</span>
            )}
          </div>
        </div>
      </div>

      {/* Synthesis Section */}
      {state.price && state.news && (
        <div style={{ padding: '15px', background: '#e8f5e9', border: '1px solid #4caf50', borderRadius: '4px' }}>
          <h4 style={{ margin: '0 0 10px 0', color: '#2e7d32' }}>Synthesis Complete</h4>
          <p><strong>Ticker:</strong> {state.ticker}</p>
          <p><strong>Current Price:</strong> {state.price}</p>
          <ul>
            {state.news.map((item, index) => <li key={index}>{item}</li>)}
          </ul>
          <p style={{ fontStyle: 'italic', marginTop: '10px' }}>
            Combined analysis generated based on parallel data fetch.
          </p>
        </div>
      )}
    </div>
  );
};

export default AgentVisualizer;
