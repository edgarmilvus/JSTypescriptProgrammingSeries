/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * LangGraph.js Basic Multi-Agent Example
 * 
 * A simple SaaS context: A customer support router that directs queries
 * to the appropriate specialized agent based on the user's initial message.
 * 
 * Dependencies: @langchain/langgraph
 */

import { StateGraph, Annotation, END, START } from "@langchain/langgraph";

// 1. STATE DEFINITION
// =================================================================
/**
 * Defines the shared state for the graph.
 * Think of this as the "database record" for a single conversation.
 * It's passed from node to node, and each node can read or write to it.
 */
const GraphState = Annotation.Root({
  // The user's original query
  input: Annotation<string>({
    reducer: (curr, update) => update, // Simple replacement
    default: () => "",
  }),
  // The agent that ultimately handled the query (e.g., "Billing", "Tech Support")
  route: Annotation<string>({
    reducer: (curr, update) => update,
    default: () => "",
  }),
  // A log of decisions made by the supervisor
  decision_log: Annotation<string[]>({
    reducer: (curr, update) => [...curr, update], // Appends new decisions
    default: () => [],
  }),
});

// 2. NODES (Computational Units)
// =================================================================

/**
 * Supervisor Node: The initial router.
 * In a real app, this would be an LLM call. Here, we simulate the logic.
 * It inspects the state and decides which agent to route to.
 * @param state - The current state of the graph
 * @returns A partial object to update the state
 */
async function supervisorRouter(state: typeof GraphState.State) {
  console.log("--- [Node] Supervisor: Analyzing Query ---");
  const query = state.input.toLowerCase();

  if (query.includes("bill") || query.includes("invoice") || query.includes("charge")) {
    console.log("Decision: Route to Billing Agent");
    return {
      route: "Billing",
      decision_log: "Supervisor routed to Billing Agent based on keywords."
    };
  } else if (query.includes("error") || query.includes("bug") || query.includes("technical")) {
    console.log("Decision: Route to Tech Support");
    return {
      route: "Tech Support",
      decision_log: "Supervisor routed to Tech Support based on keywords."
    };
  } else {
    console.log("Decision: Route to General Support (Default)");
    return {
      route: "General Support",
      decision_log: "Supervisor could not determine a specific route. Defaulting to General Support."
    };
  }
}

/**
 * Billing Agent Node: Handles specific billing-related tasks.
 * @param state - The current state
 */
async function billingAgent(state: typeof GraphState.State) {
  console.log("--- [Node] Billing Agent: Processing ---");
  // In a real app, this would fetch invoices, process refunds, etc.
  return {
    decision_log: `Billing Agent processed the request for: "${state.input}"`
  };
}

/**
 * Tech Support Agent Node: Handles specific technical issues.
 * @param state - The current state
 */
async function techSupportAgent(state: typeof GraphState.State) {
  console.log("--- [Node] Tech Support Agent: Processing ---");
  // In a real app, this would look up logs, run diagnostics, etc.
  return {
    decision_log: `Tech Support Agent investigated the issue for: "${state.input}"`
  };
}

/**
 * General Support Agent Node: A catch-all for unhandled queries.
 * @param state - The current state
 */
async function generalSupportAgent(state: typeof GraphState.State) {
  console.log("--- [Node] General Support Agent: Processing ---");
  return {
    decision_log: `General Support handled the query for: "${state.input}"`
  };
}

// 3. EDGES (Control Flow)
// =================================================================

/**
 * Conditional Edge: The "Traffic Cop" of the graph.
 * It looks at the state and decides which node to go to next.
 * @param state - The current state
 * @returns The name of the next node to call, or END
 */
function routeFromSupervisor(state: typeof GraphState.State) {
  // This function is called after the supervisorRouter node finishes.
  // It inspects the 'route' field that the supervisor just set.
  const route = state.route;

  if (route === "Billing") {
    return "billing_node"; // Go to the billing agent
  }
  if (route === "Tech Support") {
    return "tech_support_node"; // Go to the tech support agent
  }
  if (route === "General Support") {
    return "general_support_node"; // Go to the general agent
  }
  
  // If something goes wrong, end the graph execution.
  return END;
}

// 4. GRAPH ASSEMBLY
// =================================================================

// Initialize the graph with our defined state
const workflow = new StateGraph(GraphState);

// Add the nodes to the graph
workflow.addNode("supervisor", supervisorRouter);
workflow.addNode("billing_node", billingAgent);
workflow.addNode("tech_support_node", techSupportAgent);
workflow.addNode("general_support_node", generalSupportAgent);

// Define the edges (the connections)
// Start -> Supervisor
workflow.addEdge(START, "supervisor");

// Supervisor -> Conditional Routing
// This is the key: the supervisor's output determines the next step.
workflow.addConditionalEdges(
  "supervisor",
  routeFromSupervisor, // The function that makes the decision
  {
    "billing_node": "billing_node", // If routeFromSupervisor returns "billing_node", go to billing_node
    "tech_support_node": "tech_support_node",
    "general_support_node": "general_support_node",
    [END]: END // Map the END symbol
  }
);

// Agent Nodes -> End
// Once an agent is done, the workflow is complete.
workflow.addEdge("billing_node", END);
workflow.addEdge("tech_support_node", END);
workflow.addEdge("general_support_node", END);

// Compile the graph into an executable app
const app = workflow.compile();

// 5. EXECUTION
// =================================================================

/**
 * Main function to run the graph with a user query.
 * @param query The user's message
 */
async function runAgentWorkflow(query: string) {
  console.log(`\n\n=================================================`);
  console.log(`🚀 NEW USER QUERY: "${query}"`);
  console.log(`=================================================`);

  // The initial state input for the graph
  const initialInputs = {
    input: query,
    decision_log: [], // Initialize log
  };

  // Stream the execution. This allows us to see the state evolve in real-time.
  // For a simple "Hello World", we'll just run it and print the final output.
  const finalState = await app.invoke(initialInputs);

  console.log("\n--- ✅ FINAL RESULT ---");
  console.log("Final State:", JSON.stringify(finalState, null, 2));
}

// --- DEMO RUNS ---
(async () => {
  await runAgentWorkflow("My invoice is wrong.");
  await runAgentWorkflow("I am seeing a 404 error on the dashboard.");
  await runAgentWorkflow("How do I change my profile picture?");
})();

