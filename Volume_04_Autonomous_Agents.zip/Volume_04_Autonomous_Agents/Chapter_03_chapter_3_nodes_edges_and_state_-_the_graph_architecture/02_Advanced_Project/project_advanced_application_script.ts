/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// File: lib/agentGraph.ts
// Dependencies: @langchain/core (for GraphState, Node, Edge primitives)

import { z } from 'zod';
import { StateGraph, Annotation, END, START } from '@langchain/langgraph';

// =============================================================================
// 1. STATE DEFINITION
// =============================================================================

/**
 * Defines the shared memory object (State) for the graph.
 * In a real SaaS app, this would be persisted in a database or Redis.
 * 
 * @schema
 * - `content`: The current text being processed.
 * - `drafts`: A history of generated versions (cyclical state).
 * - `qualityScore`: A numeric metric determining if we should loop or exit.
 * - `iterationCount`: Safeguard against infinite loops.
 */
const GraphState = Annotation.Root({
  content: Annotation<string>({
    reducer: (curr, update) => update ?? curr, // Default to current if update is undefined
    default: () => "Initial placeholder content.",
  }),
  drafts: Annotation<string[]>({
    reducer: (curr, update) => [...curr, update], // Append new drafts to history
    default: () => [],
  }),
  qualityScore: Annotation<number>({
    reducer: (curr, update) => update,
    default: () => 0,
  }),
  iterationCount: Annotation<number>({
    reducer: (curr, update) => update,
    default: () => 0,
  }),
});

// Type inference for cleaner node function signatures
type State = typeof GraphState.State;

// =============================================================================
// 2. NODE DEFINITIONS (Computational Units)
// =============================================================================

/**
 * Node: Writer Agent
 * 
 * Simulates an LLM call to generate content based on the current state.
 * In a real implementation, you would use `new ChatOpenAI().invoke()`.
 * 
 * @param state - The current shared state
 * @returns Partial<State> - Updates to merge into the state
 */
const writerNode = async (state: State): Promise<Partial<State>> => {
  console.log("--- Executing Writer Node ---");
  
  // Simulate LLM latency
  await new Promise(resolve => setTimeout(resolve, 500));

  // Simulated generation logic
  const newDraft = `Draft v${state.iterationCount + 1}: Enhanced version of "${state.content}" with improved structure.`;
  
  return {
    content: newDraft,
    drafts: newDraft, // Appends to the drafts array via the reducer
    iterationCount: state.iterationCount + 1,
  };
};

/**
 * Node: Reviewer Agent
 * 
 * Simulates an evaluation step. It assigns a quality score based on 
 * arbitrary logic (e.g., length or iteration depth) to demonstrate conditional flow.
 * 
 * @param state - The current shared state
 * @returns Partial<State> - Updates to merge into the state
 */
const reviewerNode = async (state: State): Promise<Partial<State>> => {
  console.log("--- Executing Reviewer Node ---");
  
  // Simulate processing time
  await new Promise(resolve => setTimeout(resolve, 300));

  // Mock evaluation logic: Score increases with iterations to eventually pass the threshold
  // In a real app, this might use a classifier model or heuristic analysis.
  const score = Math.min(10, state.iterationCount * 3); 
  
  console.log(`Reviewer assigned score: ${score}/10`);

  return {
    qualityScore: score,
  };
};

// =============================================================================
// 3. CONDITIONAL LOGIC (Edges)
// =============================================================================

/**
 * Edge Router: Check Quality
 * 
 * Determines the next step in the graph based on the state.
 * This implements the "Conditional Edge" pattern.
 * 
 * @param state - The current shared state
 * @returns string - The ID of the next node or END
 */
const routeAfterReview = (state: State): string => {
  const THRESHOLD = 9; // High quality requirement

  if (state.qualityScore < THRESHOLD) {
    console.log(`Score ${state.qualityScore} < ${THRESHOLD}. Routing back to Writer...`);
    // Return the ID of the node to execute next
    return 'writer'; 
  }

  console.log(`Score ${state.qualityScore} meets threshold. Routing to End.`);
  return END;
};

// =============================================================================
// 4. GRAPH ASSEMBLY
// =============================================================================

/**
 * Assembles the graph structure.
 * 
 * 1. Initialize Graph with State.
 * 2. Add Nodes (Computational units).
 * 3. Define Edges (Control flow).
 * 4. Compile the executable workflow.
 */
const createAnalysisGraph = () => {
  // Initialize the graph with the defined state schema
  const workflow = new StateGraph(GraphState);

  // Add nodes to the graph
  workflow.addNode('writer', writerNode);
  workflow.addNode('reviewer', reviewerNode);

  // Define the execution path
  
  // Entry point: Start -> Writer
  workflow.addEdge(START, 'writer');

  // Linear flow: Writer -> Reviewer
  workflow.addEdge('writer', 'reviewer');

  // Conditional flow: Reviewer -> (Writer OR End)
  // We use `addConditionalEdges` to inspect the state and route dynamically
  workflow.addConditionalEdges(
    'reviewer',       // The node that triggers the check
    routeAfterReview, // The function that determines the path
    {
      'writer': 'writer', // Map return value to target node ID
      [END]: END          // Map return value to the END constant
    }
  );

  // Compile the graph into an executable application
  return workflow.compile();
};

// =============================================================================
// 5. EXECUTION (Main Logic)
// =============================================================================

/**
 * Main execution function.
 * In a Next.js context, this would be an async API handler.
 */
export const runAgentWorkflow = async () => {
  console.log("🚀 Initializing Multi-Agent Workflow...\n");

  // Compile the graph
  const app = createAnalysisGraph();

  // Initial state configuration
  const initialInput = {
    content: "User submitted a raw blog post idea.",
    iterationCount: 0,
    qualityScore: 0,
    drafts: [],
  };

  // Execute the graph
  // The graph handles the loop internally based on our conditional edges
  const finalState = await app.invoke(initialInput);

  console.log("\n✅ Workflow Complete.");
  console.log("Final Output:", finalState.content);
  console.log("Total Iterations:", finalState.iterationCount);
  console.log("Draft History:", finalState.drafts);
};

// To run this script (if executed directly in a Node environment):
// runAgentWorkflow();
