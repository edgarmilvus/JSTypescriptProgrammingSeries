/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

import { StateGraph, END, Annotation, BaseMessage } from "@langchain/langgraph";
import { RunnableConfig } from "@langchain/core/runnables";

// 1. State Definition
interface ResearchState {
  topic: string;
  query: string | null;
  searchResults: string[];
  summary: string | null;
  history: string[];
}

// Define the State Annotation
const ResearchStateAnnotation = Annotation.Root({
  topic: Annotation<string>(),
  query: Annotation<string | null>({ default: null }),
  searchResults: Annotation<string[]>({ default: [] }),
  summary: Annotation<string | null>({ default: null }),
  history: Annotation<string[]>({ default: [] }),
});

// 2. Node Implementations (Async functions returning new state)

// Node 1: Generate Query
async function generateQueryNode(state: typeof ResearchStateAnnotation.State): Promise<ResearchState> {
  // Simulate LLM call
  const generatedQuery = `Best resources for learning about ${state.topic}`;
  const newHistory = [...state.history, `Query generated: ${generatedQuery}`];

  // Return NEW state object (Immutability)
  return {
    ...state,
    query: generatedQuery,
    history: newHistory,
  };
}

// Node 2: Search
async function searchNode(state: typeof ResearchStateAnnotation.State): Promise<ResearchState> {
  if (!state.query) {
    throw new Error("Query is missing before search.");
  }

  // Simulate search results
  const results = [
    `Article: Advanced concepts in ${state.topic}`,
    `Video: Introduction to ${state.topic}`,
  ];
  const newHistory = [...state.history, "Search completed"];

  return {
    ...state,
    searchResults: results,
    history: newHistory,
  };
}

// Node 3: Summarize
async function summarizeNode(state: typeof ResearchStateAnnotation.State): Promise<ResearchState> {
  if (state.searchResults.length === 0) {
    throw new Error("No search results to summarize.");
  }

  // Simulate summarization
  const summary = `Summary of findings regarding ${state.topic}: Found ${state.searchResults.length} resources.`;
  const newHistory = [...state.history, "Summary generated"];

  return {
    ...state,
    summary: summary,
    history: newHistory,
  };
}

// 3. Graph Assembly
async function runResearchPipeline(topic: string) {
  const workflow = new StateGraph(ResearchStateAnnotation);

  // Add nodes
  workflow.addNode("generateQueryNode", generateQueryNode);
  workflow.addNode("searchNode", searchNode);
  workflow.addNode("summarizeNode", summarizeNode);

  // Define linear edges
  workflow.addEdge("generateQueryNode", "searchNode");
  workflow.addEdge("searchNode", "summarizeNode");
  workflow.addEdge("summarizeNode", END);

  // Set entry point
  workflow.setEntryPoint("generateQueryNode");

  const app = workflow.compile();

  // Initialize state
  const initialState: ResearchState = {
    topic: topic,
    query: null,
    searchResults: [],
    summary: null,
    history: [],
  };

  const result = await app.invoke(initialState);
  return result;
}

// Example Usage
// runResearchPipeline("LangGraph").then(console.log);
