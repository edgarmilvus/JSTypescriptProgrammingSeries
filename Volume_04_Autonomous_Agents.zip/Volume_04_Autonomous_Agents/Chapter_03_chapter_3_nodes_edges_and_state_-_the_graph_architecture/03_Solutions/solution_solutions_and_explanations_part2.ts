/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

import { StateGraph, END, Annotation } from "@langchain/langgraph";

// 1. State Definition
interface ModerationState {
  content: string;
  classification: 'safe' | 'suspicious' | 'unsafe' | null;
  outcome: string | null;
}

const ModerationStateAnnotation = Annotation.Root({
  content: Annotation<string>(),
  classification: Annotation<'safe' | 'suspicious' | 'unsafe' | null>({ default: null }),
  outcome: Annotation<string | null>({ default: null }),
});

// 2. Node Implementations

// Node 1: Classify
async function classifyNode(state: typeof ModerationStateAnnotation.State): Promise<ModerationState> {
  let classification: 'safe' | 'suspicious' | 'unsafe' = 'safe';

  // Simple heuristic for simulation
  if (state.content.includes("error") || state.content.includes("fail")) {
    classification = 'unsafe';
  } else if (state.content.includes("review")) {
    classification = 'suspicious';
  }

  return {
    ...state,
    classification,
  };
}

// Node 2: Publish
async function publishNode(state: typeof ModerationStateAnnotation.State): Promise<ModerationState> {
  return {
    ...state,
    outcome: "Published",
  };
}

// Node 3: Review
async function reviewNode(state: typeof ModerationStateAnnotation.State): Promise<ModerationState> {
  return {
    ...state,
    outcome: "Sent for Review",
  };
}

// Node 4: Reject
async function rejectNode(state: typeof ModerationStateAnnotation.State): Promise<ModerationState> {
  return {
    ...state,
    outcome: "Rejected",
  };
}

// 3. Graph Assembly with Conditional Logic
const workflow = new StateGraph(ModerationStateAnnotation);

workflow.addNode("classifyNode", classifyNode);
workflow.addNode("publishNode", publishNode);
workflow.addNode("reviewNode", reviewNode);
workflow.addNode("rejectNode", rejectNode);

workflow.setEntryPoint("classifyNode");

// Define the routing function
const router = (state: typeof ModerationStateAnnotation.State) => {
  if (state.classification === 'safe') {
    return "publishNode";
  } else if (state.classification === 'suspicious') {
    return "reviewNode";
  } else {
    return "rejectNode";
  }
};

// Add conditional edges from classifyNode
workflow.addConditionalEdges("classifyNode", router, {
  "publishNode": END,
  "reviewNode": END,
  "rejectNode": END,
});

const moderationApp = workflow.compile();

// Example Usage
// moderationApp.invoke({ content: "This is a safe message." });

/* 
   VISUALIZATION (Graphviz DOT Syntax)
   digraph G {
     start [label="Start"];
     classifyNode;
     publishNode;
     reviewNode;
     rejectNode;
     end [label="End"];

     start -> classifyNode;
     classifyNode -> publishNode [label="safe"];
     classifyNode -> reviewNode [label="suspicious"];
     classifyNode -> rejectNode [label="unsafe"];
     publishNode -> end;
     reviewNode -> end;
     rejectNode -> end;
   }
*/
