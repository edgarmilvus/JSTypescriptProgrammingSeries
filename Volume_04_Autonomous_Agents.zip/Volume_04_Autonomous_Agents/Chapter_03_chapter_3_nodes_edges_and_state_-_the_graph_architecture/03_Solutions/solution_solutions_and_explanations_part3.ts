/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

import { StateGraph, END, Annotation } from "@langchain/langgraph";

// 1. State Definition
interface CodeGenState {
  requirement: string;
  generatedCode: string | null;
  lintErrors: string[];
  attemptCount: number;
  maxAttempts: number;
  status?: string;
}

const CodeGenStateAnnotation = Annotation.Root({
  requirement: Annotation<string>(),
  generatedCode: Annotation<string | null>({ default: null }),
  lintErrors: Annotation<string[]>({ default: [] }),
  attemptCount: Annotation<number>({ default: 0 }),
  maxAttempts: Annotation<number>({ default: 3 }), // Constant
  status: Annotation<string | undefined>({ default: undefined }),
});

// 2. Node Implementations

// Node 1: Generate Code
async function generateCodeNode(state: typeof CodeGenStateAnnotation.State): Promise<CodeGenState> {
  // Simulation: First attempt fails, subsequent succeed (or fail randomly)
  // We force a failure on the first attempt to show the loop
  const code = state.attemptCount === 0 
    ? "function broken() { return 1 + 'string'; /* //error */ }" 
    : "function fixed() { return 1; }";

  return {
    ...state,
    generatedCode: code,
    attemptCount: state.attemptCount + 1, // Increment immutably
    lintErrors: [], // Reset errors before linting
  };
}

// Node 2: Lint
async function lintNode(state: typeof CodeGenStateAnnotation.State): Promise<CodeGenState> {
  if (!state.generatedCode) return state;

  const errors: string[] = [];
  // Simulate linting logic
  if (state.generatedCode.includes("//error")) {
    errors.push("SyntaxError: Unexpected token");
  }

  return {
    ...state,
    lintErrors: errors,
  };
}

// Node 3: Finalize
async function finalizeNode(state: typeof CodeGenStateAnnotation.State): Promise<CodeGenState> {
  const finalStatus = state.lintErrors.length === 0 ? "complete" : "failed (max retries)";
  return {
    ...state,
    status: finalStatus,
  };
}

// 3. Graph Assembly with Cyclical Edges
const workflow = new StateGraph(CodeGenStateAnnotation);

workflow.addNode("generateCodeNode", generateCodeNode);
workflow.addNode("lintNode", lintNode);
workflow.addNode("finalizeNode", finalizeNode);

workflow.setEntryPoint("generateCodeNode");
workflow.addEdge("generateCodeNode", "lintNode");

// Conditional edge from Lint Node
const lintRouter = (state: typeof CodeGenStateAnnotation.State) => {
  if (state.lintErrors.length > 0) {
    if (state.attemptCount < state.maxAttempts) {
      return "generateCodeNode"; // Loop back
    }
    return "finalizeNode"; // Max attempts reached
  }
  return "finalizeNode"; // No errors
};

workflow.addConditionalEdges("lintNode", lintRouter);

const codeGenApp = workflow.compile();

// Example Usage
// codeGenApp.invoke({ requirement: "Write a function." }).then(console.log);
