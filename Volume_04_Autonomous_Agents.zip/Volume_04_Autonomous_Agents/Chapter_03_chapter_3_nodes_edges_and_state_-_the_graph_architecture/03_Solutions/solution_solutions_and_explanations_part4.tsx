/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.tsx
// Description: Solutions and Explanations
// ==========================================

import React from 'react';

// 1. Component Interface
interface GraphVisualizerProps {
  currentState: {
    node: string;
    data: Record<string, any>;
    status: 'running' | 'idle' | 'completed' | 'error';
  };
  history: Array<{ node: string; data: Record<string, any> }>;
}

// 2. Component Implementation
export const GraphVisualizer: React.FC<GraphVisualizerProps> = ({ currentState, history }) => {
  
  // 3. Reconciliation Logic (Conceptual)
  /*
    In a real-world scenario, if the user triggers an action (e.g., 'pause' or 'step'),
    we might optimistically update the UI to show a 'paused' state.
    However, the actual LangGraph execution might be asynchronous.
    When the new state arrives from the graph engine, we must reconcile:
    1. Compare the incoming 'currentState.status' with our optimistic local state.
    2. If the graph's actual status differs (e.g., it errored while we showed 'paused'),
       we must override the optimistic state with the confirmed state from the graph.
    3. This ensures the UI always reflects the single source of truth (the graph's state)
       while providing immediate feedback to the user.
    4. We can achieve this by storing the optimistic state in a separate ref or state variable
       and only committing it when the confirmed state matches the expected outcome.
  */

  return (
    <div style={{ fontFamily: 'monospace', padding: '10px', border: '1px solid #ccc' }}>
      {/* Status Header */}
      <div style={{ marginBottom: '10px', fontWeight: 'bold', color: currentState.status === 'running' ? 'blue' : 'green' }}>
        Status: {currentState.status.toUpperCase()}
        {currentState.status === 'running' && <span> (Processing: {currentState.node})</span>}
      </div>

      {/* Current State Data */}
      <div style={{ marginBottom: '20px', backgroundColor: '#f5f5f5', padding: '10px' }}>
        <h4>Current State ({currentState.node})</h4>
        <pre>{JSON.stringify(currentState.data, null, 2)}</pre>
      </div>

      {/* Execution History */}
      <div>
        <h4>Execution History</h4>
        {history.length === 0 ? (
          <p>No steps executed yet.</p>
        ) : (
          <ul style={{ listStyle: 'none', padding: 0 }}>
            {history.map((step, index) => (
              <li key={index} style={{ marginBottom: '5px', padding: '5px', border: '1px solid #eee' }}>
                <strong>{step.node}</strong>: <span style={{ fontSize: '0.9em', color: '#555' }}>{JSON.stringify(step.data)}</span>
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
};
