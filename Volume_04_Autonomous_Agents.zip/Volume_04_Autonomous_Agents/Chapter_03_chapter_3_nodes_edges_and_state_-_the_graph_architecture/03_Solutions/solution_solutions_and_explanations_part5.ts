/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

// 1. Define Complex State Interface
interface AgentSessionState {
  sessionId: string;
  userQuery: string;
  conversationHistory: Array<{ role: 'user' | 'agent'; content: string }>;
  toolResults: Array<{ toolName: string; result: any }>;
  metadata: { createdAt: number; lastUpdated: number };
}

// 2. Serialization Function
function serializeState(state: AgentSessionState): string {
  // Check for circular references (basic check)
  try {
    JSON.stringify(state);
  } catch (error) {
    if (error instanceof TypeError && error.message.includes("circular")) {
      throw new Error("State contains circular references and cannot be serialized.");
    }
    throw error;
  }

  // Ensure non-serializable properties (like Dates or custom Classes) are converted
  // In this specific interface, everything looks standard (strings, numbers, arrays, objects).
  // If we had a Date object in metadata, we would convert it to ISO string here.
  const safeState = {
    ...state,
    metadata: {
      ...state.metadata,
      createdAt: state.metadata.createdAt, // Assuming timestamp number
      lastUpdated: Date.now(), // Update timestamp on save
    }
  };

  return JSON.stringify(safeState);
}

// 3. Deserialization Function
function deserializeState(jsonString: string): AgentSessionState | null {
  try {
    const parsed = JSON.parse(jsonString) as AgentSessionState;

    // Basic Validation
    if (!parsed.sessionId || !parsed.userQuery) {
      console.error("Validation failed: Missing required fields.");
      return null;
    }

    // Ensure arrays exist
    if (!Array.isArray(parsed.conversationHistory)) parsed.conversationHistory = [];
    if (!Array.isArray(parsed.toolResults)) parsed.toolResults = [];

    return parsed;
  } catch (error) {
    console.error("Failed to deserialize state:", error);
    return null;
  }
}

// 4. Integration Example (Mock Persistence Node)
async function persistenceNode(state: AgentSessionState): Promise<AgentSessionState> {
  // 1. Serialize
  const jsonString = serializeState(state);
  
  // 2. Save to Mock Database (e.g., localStorage or file system)
  // In a real app: await db.save(state.sessionId, jsonString);
  console.log(`Saving state for session ${state.sessionId}:`, jsonString);

  // 3. Return state (optionally updated with metadata like lastUpdated)
  // Note: We return the original state object to not disrupt graph flow,
  // but the persistence side-effect has occurred.
  return state;
}

// Example Usage
const mockState: AgentSessionState = {
  sessionId: "sess_123",
  userQuery: "What is the weather?",
  conversationHistory: [{ role: "user", content: "What is the weather?" }],
  toolResults: [{ toolName: "getWeather", result: "Sunny" }],
  metadata: { createdAt: 1690000000000, lastUpdated: 1690000000000 }
};

// const serialized = serializeState(mockState);
// const deserialized = deserializeState(serialized);
