/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

// ==========================================
// 1. TYPE DEFINITIONS & INTERFACES
// ==========================================

/**
 * Represents the state of our agent at any point in the loop.
 * This is the "Memory" of the agent.
 */
interface AgentState {
    input: string;
    conversationHistory: string[];
    context: Record<string, any>; // Stores retrieved data (e.g., user subscription)
    shouldContinue: boolean;
}

/**
 * Defines the structure of a tool the agent can use.
 */
interface Tool {
    name: string;
    description: string;
    // The actual function to execute
    execute: (args: any) => Promise<any>;
}

// ==========================================
// 2. MOCK TOOLS (The "Act" Phase)
// ==========================================

/**
 * Simulates an internal SaaS API to check user subscription status.
 * In a real app, this would connect to a database (Postgres, MongoDB).
 */
const checkSubscriptionTool: Tool = {
    name: "check_subscription",
    description: "Use this to check the user's current subscription plan and status.",
    execute: async (args: { userId: string }) => {
        console.log(`[Tool Execution] Checking subscription for user: ${args.userId}...`);
        
        // Simulate database latency
        await new Promise(resolve => setTimeout(resolve, 100));

        // Mock Data
        if (args.userId === "user_123") {
            return { plan: "Pro", status: "Active", expiresAt: "2024-12-31" };
        }
        return { plan: "Free", status: "Expired", expiresAt: "2023-01-01" };
    }
};

const tools = [checkSubscriptionTool];

// ==========================================
// 3. MOCK LLM (The "Reason" Phase)
// ==========================================

/**
 * Simulates an LLM (like GPT-4) that decides which tool to use.
 * In production, this calls an actual LLM API with a structured output schema.
 * 
 * @returns A string representing the LLM's decision: "TOOL:tool_name:args" or "FINAL:answer".
 */
async function mockLLMReasoning(state: AgentState): Promise<string> {
    const lastMessage = state.conversationHistory[state.conversationHistory.length - 1];
    const contextSummary = JSON.stringify(state.context);

    console.log("\n[LLM Reasoning] Analyzing state...");
    
    // Simple heuristic to simulate LLM logic for this demo
    // Real implementation would use a prompt like:
    // "Given history: X and context: Y, decide the next step."
    
    if (Object.keys(state.context).length === 0) {
        // We have no info yet. Let's ask the tool for data.
        console.log("[LLM Reasoning] No context found. Deciding to call 'check_subscription'.");
        return `TOOL:check_subscription:{"userId": "user_123"}`;
    } 
    
    // We have info. Let's formulate an answer.
    if (state.context.plan === "Pro") {
        console.log("[LLM Reasoning] User is Pro. Formulating final answer.");
        return `FINAL:The user has an active Pro subscription valid until ${state.context.expiresAt}.`;
    } else {
        console.log("[LLM Reasoning] User is not Pro. Formulating final answer.");
        return `FINAL:The user's subscription is ${state.context.status}. Please upgrade to Pro.`;
    }
}

// ==========================================
// 4. THE REACT AGENT (The Orchestrator)
// ==========================================

/**
 * The core ReAct loop implementation.
 * 
 * 1. Initialize State
 * 2. Loop:
 *    a. Reason (LLM decides action)
 *    b. Act (Execute Tool)
 *    c. Observe (Update State)
 * 3. Terminate when final answer is ready.
 */
class ReActAgent {
    private state: AgentState;

    constructor(initialInput: string) {
        this.state = {
            input: initialInput,
            conversationHistory: [initialInput],
            context: {},
            shouldContinue: true
        };
    }

    /**
     * Executes the ReAct loop.
     */
    async run(): Promise<string> {
        console.log("🚀 Starting ReAct Agent Loop...");

        // Loop guard to prevent infinite execution (safety mechanism)
        let steps = 0;
        const MAX_STEPS = 5;

        while (this.state.shouldContinue && steps < MAX_STEPS) {
            steps++;
            console.log(`\n--- Step ${steps} ---`);

            // 1. REASON: Ask LLM what to do
            const llmDecision = await mockLLMReasoning(this.state);

            // 2. ACT & OBSERVE: Parse decision and execute
            if (llmDecision.startsWith("TOOL:")) {
                // Parse: "TOOL:check_subscription:{\"userId\":\"user_123\"}"
                const [_, toolName, argsStr] = llmDecision.split(":");
                
                const tool = tools.find(t => t.name === toolName);
                
                if (tool) {
                    const args = JSON.parse(argsStr);
                    const result = await tool.execute(args);
                    
                    // Update State with Observation
                    this.state.context = result;
                    this.state.conversationHistory.push(`Tool Result: ${JSON.stringify(result)}`);
                } else {
                    throw new Error(`Tool ${toolName} not found.`);
                }
            } 
            else if (llmDecision.startsWith("FINAL:")) {
                // Parse: "FINAL:The user has..."
                const answer = llmDecision.split(":")[1];
                
                this.state.conversationHistory.push(`Final Answer: ${answer}`);
                this.state.shouldContinue = false; // Break the loop
                
                console.log("✅ Task Complete. Returning final answer.");
                return answer;
            }
        }

        if (steps >= MAX_STEPS) {
            return "Error: Agent hit maximum step limit.";
        }

        return "No answer generated.";
    }
}

// ==========================================
// 5. EXECUTION (Simulating a Web App Request)
// ==========================================

/**
 * Main entry point simulating a Next.js API route handler.
 */
async function main() {
    // Simulate an incoming request from a SaaS frontend
    const userQuery = "What is the status of my subscription?";

    const agent = new ReActAgent(userQuery);
    const result = await agent.run();

    console.log("\n========================================");
    console.log("Final Output to Client:", result);
    console.log("========================================");
}

// Execute the simulation
main().catch(console.error);
