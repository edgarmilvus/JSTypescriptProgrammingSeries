/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

/**
 * app/api/support/route.ts
 * 
 * Advanced ReAct Pattern Implementation.
 * 
 * Context: SaaS Customer Support Automation.
 * Objective: Route user queries to the correct internal tools (Knowledge Base vs. Order DB)
 *            and synthesize a natural language response.
 */

import { NextResponse } from 'next/server';
import { z } from 'zod';
import { ToolDefinition } from '@langchain/core/tools';
import { BaseMessage, AIMessage, ToolMessage } from '@langchain/core/messages';
import { StateGraph, END, START } from '@langchain/langgraph';
import { ChatOpenAI } from '@langchain/openai';

// ============================================================================
// 1. TOOL DEFINITIONS (SRP: Isolated Logic)
// ============================================================================

/**
 * Mock Knowledge Base Search Tool.
 * Simulates retrieving documentation or FAQ data.
 * SRP: Handles ONLY knowledge base retrieval logic.
 */
class KnowledgeBaseTool {
  static get name() { return 'knowledge_base_search'; }
  
  static get schema(): z.ZodObject<any> {
    return z.object({
      query: z.string().describe("The specific question to search for in the documentation.")
    });
  }

  static get definition(): ToolDefinition {
    return {
      name: this.name,
      description: 'Use this tool for general inquiries, product features, or company policies.',
      input_schema: this.schema,
    };
  }

  static async invoke(input: z.infer<typeof this.schema>): Promise<string> {
    // Simulate DB/Lookup latency
    await new Promise(r => setTimeout(r, 200));
    
    // Mock data logic
    if (input.query.toLowerCase().includes('refund')) {
      return "Refunds are processed within 5-7 business days. Visit /settings/billing to initiate.";
    }
    if (input.query.toLowerCase().includes('api')) {
      return "Our API documentation is available at docs.example.com. Rate limits are 1000 req/min.";
    }
    return "I found general information regarding your query, but please be more specific.";
  }
}

/**
 * Mock Order Database Tool.
 * Simulates querying a transactional database for PII (Personally Identifiable Information).
 * SRP: Handles ONLY database query logic.
 */
class OrderDatabaseTool {
  static get name() { return 'order_database_lookup'; }
  
  static get schema(): z.ZodObject<any> {
    return z.object({
      orderId: z.string().describe("The alphanumeric order ID, e.g., 'ORD-12345'.")
    });
  }

  static get definition(): ToolDefinition {
    return {
      name: this.name,
      description: 'Use this tool ONLY when the user asks about specific order status, tracking, or shipping.',
      input_schema: this.schema,
    };
  }

  static async invoke(input: z.infer<typeof this.schema>): Promise<string> {
    await new Promise(r => setTimeout(r, 300));
    
    // Mock Security Check: Fail if ID is malformed
    if (!input.orderId.startsWith('ORD-')) {
      return "Error: Invalid Order ID format. Expected format: ORD-XXXXX.";
    }

    // Mock Data
    if (input.orderId === 'ORD-88888') {
      return "Order ORD-88888 status: Shipped. Tracking: UPS-999-XYZ. Arriving tomorrow.";
    }
    return `Status for ${input.orderId}: Processing.`;
  }
}

// ============================================================================
// 2. STATE MANAGEMENT (SRP: Data Structure)
// ============================================================================

/**
 * Defines the state shape for the ReAct graph.
 * SRP: Defines ONLY the data contract, not the behavior.
 */
interface AgentState {
  messages: BaseMessage[];
  // We can add more state keys here (e.g., user_id, context) without breaking the loop logic
}

// ============================================================================
// 3. GRAPH NODES (SRP: Single Actions)
// ============================================================================

/**
 * Node A: The Reasoner (LLM).
 * Decides which tool to use based on the conversation history.
 */
async function agentNode(state: AgentState): Promise<Partial<AgentState>> {
  const model = new ChatOpenAI({ 
    model: "gpt-4-turbo-preview", 
    temperature: 0 
  }).bindTools([
    KnowledgeBaseTool.definition,
    OrderDatabaseTool.definition
  ]);

  const response = await model.invoke(state.messages);
  return { messages: [response] };
}

/**
 * Node B: The Actor (Tool Executor).
 * Executes the tool selected by the LLM.
 */
async function toolNode(state: AgentState): Promise<Partial<AgentState>> {
  const lastMessage = state.messages[state.messages.length - 1] as AIMessage;
  
  if (!lastMessage.tool_calls || lastMessage.tool_calls.length === 0) {
    throw new Error("Tool node called without tool calls in the last message.");
  }

  const toolCalls = lastMessage.tool_calls;
  const results: ToolMessage[] = [];

  for (const call of toolCalls) {
    let result = "";
    try {
      // Route to the correct tool implementation based on name
      if (call.name === KnowledgeBaseTool.name) {
        const args = JSON.parse(call.args as string);
        result = await KnowledgeBaseTool.invoke(args);
      } else if (call.name === OrderDatabaseTool.name) {
        const args = JSON.parse(call.args as string);
        result = await OrderDatabaseTool.invoke(args);
      } else {
        result = `Error: Tool ${call.name} not found.`;
      }
    } catch (e) {
      result = `Error executing tool: ${e}`;
    }

    results.push(new ToolMessage({
      content: result,
      tool_call_id: call.id!,
      name: call.name
    }));
  }

  return { messages: results };
}

/**
 * Node C: The Router (Conditional Edge).
 * Determines if the graph should continue or terminate.
 * Logic: If the last message has tool_calls, go to 'action'. Else, 'end'.
 */
function shouldContinue(state: AgentState): "action" | "end" {
  const lastMessage = state.messages[state.messages.length - 1];
  
  // If the LLM invoked a tool, we must execute it
  if ("tool_calls" in lastMessage && lastMessage.tool_calls?.length) {
    return "action";
  }
  
  // Otherwise, the LLM has generated the final response
  return "end";
}

// ============================================================================
// 4. GRAPH CONSTRUCTION (SRP: Wiring)
// ============================================================================

/**
 * Constructs the ReAct StateGraph.
 * SRP: Responsible ONLY for defining the topology of the execution flow.
 */
function createReActGraph() {
  // Define the state schema (simplified for JS, typically using Zod)
  const workflow = new StateGraph<AgentState>({
    channels: {
      messages: {
        value: (x: BaseMessage[], y: BaseMessage[]) => (y ? x.concat(y) : x),
        default: () => [],
      },
    },
  });

  // Add nodes
  workflow.addNode("agent", agentNode);
  workflow.addNode("action", toolNode);

  // Define edges
  workflow.addEdge(START, "agent");
  
  // Conditional edge: After 'agent', decide where to go
  workflow.addConditionalEdges(
    "agent",
    shouldContinue,
    {
      "action": "action", // Go to tool executor
      "end": END          // Finish
    }
  );

  // The feedback loop: After 'action', always go back to 'agent'
  workflow.addEdge("action", "agent");

  return workflow.compile();
}

// ============================================================================
// 5. API HANDLER (SRP: Interface Layer)
// ============================================================================

/**
 * Next.js API Route Handler.
 * Handles HTTP requests, invokes the graph, and returns the response.
 */
export async function POST(req: Request) {
  try {
    const { message } = await req.json();

    if (!message) {
      return NextResponse.json({ error: "Message is required" }, { status: 400 });
    }

    // Initialize the ReAct Graph
    const graph = createReActGraph();

    // Initial State
    const initialState: AgentState = {
      messages: [new AIMessage(message)] // In a real app, this would likely be HumanMessage
    };

    // Stream execution (or use .invoke() for single shot)
    // Here we invoke to get the final state
    const finalState = await graph.invoke(initialState);

    // Extract the final AI response
    const finalResponse = finalState.messages[finalState.messages.length - 1];

    return NextResponse.json({
      response: finalResponse.content,
      // Optional: Return the full trace for debugging
      trace: finalState.messages.map(m => ({
        type: m.constructor.name,
        content: m.content,
        tool_calls: (m as AIMessage).tool_calls
      }))
    });

  } catch (error) {
    console.error("ReAct Graph Error:", error);
    return NextResponse.json(
      { error: "Internal Agent Error", details: (error as Error).message }, 
      { status: 500 }
    );
  }
}
