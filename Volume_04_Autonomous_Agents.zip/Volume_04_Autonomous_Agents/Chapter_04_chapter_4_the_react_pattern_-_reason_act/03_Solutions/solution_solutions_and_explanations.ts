/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

import { StateGraph, END, Annotation } from "@langchain/langgraph";

// 1. State Management
const CalculatorStateAnnotation = Annotation.Root({
  input: Annotation<string>(),
  thought: Annotation<string>({ reducer: (x, y) => y ?? x, default: () => "" }),
  action: Annotation<string>({ reducer: (x, y) => y ?? x, default: () => "" }),
  actionInput: Annotation<{ a: number; b: number } | null>({
    reducer: (x, y) => y ?? x,
    default: () => null,
  }),
  observation: Annotation<number | null>({
    reducer: (x, y) => y ?? x,
    default: () => null,
  }),
  next: Annotation<"reason" | "act" | "finish">({
    reducer: (x, y) => y ?? x,
    default: () => "reason",
  }),
});

type CalculatorState = typeof CalculatorStateAnnotation.State;

// 2. Tool Integration
const tools = {
  add: (a: number, b: number): number => a + b,
  multiply: (a: number, b: number): number => a * b,
};

const executeTool = (toolName: string, args: { a: number; b: number }) => {
  if (toolName === "add") return tools.add(args.a, args.b);
  if (toolName === "multiply") return tools.multiply(args.a, args.b);
  throw new Error(`Unknown tool: ${toolName}`);
};

// 3. ReAct Node Logic (Reasoning)
const reasoningNode = (state: CalculatorState): CalculatorState => {
  const { input } = state;
  
  // Simulate LLM parsing logic
  let thought = "";
  let action = "";
  let actionInput = null;

  // Regex to extract numbers and operation
  const addMatch = input.match(/add\s+(\d+)\s+and\s+(\d+)/i);
  const multiplyMatch = input.match(/multiply\s+(\d+)\s+and\s+(\d+)/i);

  if (addMatch) {
    thought = `I need to add ${addMatch[1]} and ${addMatch[2]}.`;
    action = "add";
    actionInput = { a: parseInt(addMatch[1]), b: parseInt(addMatch[2]) };
  } else if (multiplyMatch) {
    thought = `I need to multiply ${multiplyMatch[1]} and ${multiplyMatch[2]}.`;
    action = "multiply";
    actionInput = { a: parseInt(multiplyMatch[1]), b: parseInt(multiplyMatch[2]) };
  } else {
    thought = "I don't understand the request.";
    action = "fail";
  }

  return {
    ...state,
    thought,
    action,
    actionInput,
    next: "act",
  };
};

// 4. Action Node Logic
const actionNode = (state: CalculatorState): CalculatorState => {
  if (!state.action || !state.actionInput || state.action === "fail") {
    return {
      ...state,
      observation: null,
      next: "finish",
    };
  }

  try {
    const result = executeTool(state.action, state.actionInput);
    return {
      ...state,
      observation: result,
      next: "finish",
    };
  } catch (error) {
    return {
      ...state,
      observation: null,
      next: "finish",
    };
  }
};

// 5. LangGraph Integration
const workflow = new StateGraph(CalculatorStateAnnotation)
  .addNode("reasoningNode", reasoningNode)
  .addNode("actionNode", actionNode)
  .addEdge("__start__", "reasoningNode")
  .addEdge("reasoningNode", "actionNode")
  .addEdge("actionNode", END);

export const calculatorAgent = workflow.compile();
