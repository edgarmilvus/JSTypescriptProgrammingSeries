/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

import { StateGraph, END, Annotation } from "@langchain/langgraph";

// 1. Expanded State & Tools
const RobustCalculatorStateAnnotation = Annotation.Root({
  input: Annotation<string>(),
  history: Annotation<Array<{ thought: string; action: string; observation: string }>>({
    reducer: (x, y) => [...x, y],
    default: () => [],
  }),
  currentThought: Annotation<string>(),
  currentAction: Annotation<string>(),
  currentActionInput: Annotation<Record<string, any>>(),
  currentObservation: Annotation<string | number>(),
  maxIterations: Annotation<number>({ default: () => 5 }),
  iterationCount: Annotation<number>({ reducer: (x, y) => y, default: () => 0 }),
});

type RobustState = typeof RobustCalculatorStateAnnotation.State;

const tools = {
  add: (a: number, b: number) => a + b,
  multiply: (a: number, b: number) => a * b,
  power: (base: number, exponent: number) => Math.pow(base, exponent),
};

// 2. LLM Simulation
const simulateLLM = (state: RobustState): { thought: string; action: string; input: any } => {
  const inputStr = state.currentObservation ? state.currentObservation.toString() : state.input;

  // Check for error recovery
  if (inputStr.startsWith("Error:")) {
    return {
      thought: "I received an error. I need to clarify or try a different approach.",
      action: "clarify",
      input: {},
    };
  }

  // Parse specific keywords
  if (/power/i.test(inputStr)) {
    const match = inputStr.match(/power\s+(\d+)\s+to\s+(\d+)/i) || inputStr.match(/(\d+)\s*\^\s*(\d+)/);
    if (match) {
      return {
        thought: `I need to calculate the power of ${match[1]} to ${match[2]}.`,
        action: "power",
        input: { base: parseInt(match[1]), exponent: parseInt(match[2]) },
      };
    }
  }
  
  if (/add/i.test(inputStr)) {
     const match = inputStr.match(/add\s+(\d+)\s+and\s+(\d+)/i);
     if (match) {
        return { thought: "Adding numbers", action: "add", input: { a: parseInt(match[1]), b: parseInt(match[2]) } };
     }
  }

  return { thought: "I don't understand.", action: "unknown", input: {} };
};

// 3. Validation & Action Node (Combined for brevity, usually separate)
const actionAndValidationNode = (state: RobustState): RobustState => {
  if (state.iterationCount >= state.maxIterations) {
    return { ...state, currentObservation: "Max iterations reached", iterationCount: state.iterationCount + 1 };
  }

  const llmOutput = simulateLLM(state);
  
  // Handle Clarification
  if (llmOutput.action === "clarify" || llmOutput.action === "unknown") {
    return {
      ...state,
      currentThought: llmOutput.thought,
      currentAction: llmOutput.action,
      currentObservation: `Please clarify your request regarding '${state.input}'`,
      iterationCount: state.iterationCount + 1,
      history: [...state.history, { thought: llmOutput.thought, action: llmOutput.action, observation: `Clarification needed` }],
    };
  }

  // Execute Tool
  try {
    // @ts-ignore: accessing dynamic tool
    if (!tools[llmOutput.action]) throw new Error(`Tool '${llmOutput.action}' not found`);
    
    // @ts-ignore
    const result = tools[llmOutput.action](llmOutput.input.a ?? llmOutput.input.base, llmOutput.input.b ?? llmOutput.input.exponent);
    
    return {
      ...state,
      currentThought: llmOutput.thought,
      currentAction: llmOutput.action,
      currentActionInput: llmOutput.input,
      currentObservation: result,
      iterationCount: state.iterationCount + 1,
      history: [...state.history, { thought: llmOutput.thought, action: llmOutput.action, observation: result.toString() }],
    };
  } catch (error: any) {
    return {
      ...state,
      currentThought: llmOutput.thought,
      currentAction: llmOutput.action,
      currentObservation: `Error: ${error.message}`,
      iterationCount: state.iterationCount + 1,
      history: [...state.history, { thought: llmOutput.thought, action: llmOutput.action, observation: error.message }],
    };
  }
};

// 4. Loop Logic & Graph Construction
const workflow = new StateGraph(RobustCalculatorStateAnnotation)
  .addNode("agent", actionAndValidationNode)
  .addEdge("__start__", "agent");

// Conditional Edge: Check if we have a valid number result or hit max iterations
const shouldContinue = (state: RobustState) => {
  const isDone = typeof state.currentObservation === "number" && !isNaN(state.currentObservation);
  const isMaxed = state.iterationCount >= state.maxIterations;
  
  if (isDone || isMaxed) {
    return END;
  }
  // If we are here, we likely hit an error, so loop back to 'agent'
  return "agent";
};

workflow.addConditionalEdges("agent", shouldContinue);

export const robustCalculatorAgent = workflow.compile();
