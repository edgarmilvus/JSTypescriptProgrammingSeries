/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

// app/components/ResearchAgent.tsx
'use client';

import { useState, useTransition } from 'react';
import { runResearchAgent } from '@/app/actions/researchActions'; // Server Action

// UI Components for streaming
const ThoughtBubble = ({ text }: { text: string }) => (
  <div className="p-2 my-1 bg-blue-100 rounded text-sm text-blue-800">💡 Thought: {text}</div>
);

const ActionBubble = ({ text }: { text: string }) => (
  <div className="p-2 my-1 bg-yellow-100 rounded text-sm text-yellow-800">🔍 Action: {text}</div>
);

const ObservationBubble = ({ text }: { text: string }) => (
  <div className="p-2 my-1 bg-green-100 rounded text-sm text-green-800">✅ Observation: {text}</div>
);

export default function ResearchAgent() {
  const [query, setQuery] = useState('');
  const [output, setOutput] = useState<React.ReactNode[]>([]);
  const [isPending, startTransition] = useTransition();

  const handleRun = () => {
    // Clear previous output
    setOutput([]);
    
    startTransition(async () => {
      try {
        // Trigger the server action
        const stream = await runResearchAgent(query);
        
        // Iterate over the stream (AsyncGenerator)
        for await (const chunk of stream) {
          // Update state with new component
          setOutput((prev) => {
            const newOutput = [...prev];
            if (chunk.type === 'thought') newOutput.push(<ThoughtBubble key={Date.now() + Math.random()} text={chunk.content} />);
            if (chunk.type === 'action') newOutput.push(<ActionBubble key={Date.now() + Math.random()} text={chunk.content} />);
            if (chunk.type === 'observation') newOutput.push(<ObservationBubble key={Date.now() + Math.random()} text={chunk.content} />);
            return newOutput;
          });
          
          // Small delay to visualize streaming if needed
          await new Promise(r => setTimeout(r, 100));
        }
      } catch (error) {
        console.error("Agent failed", error);
      }
    });
  };

  return (
    <div className="p-4 border rounded-lg max-w-2xl mx-auto">
      <div className="flex gap-2 mb-4">
        <input
          type="text"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Ask a research question..."
          className="flex-1 p-2 border rounded"
          disabled={isPending}
        />
        <button
          onClick={handleRun}
          disabled={isPending || !query}
          className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 disabled:opacity-50"
        >
          {isPending ? 'Researching...' : 'Start Research'}
        </button>
      </div>
      <div className="output-log space-y-2 border-t pt-4 min-h-[200px]">
        {output.length === 0 && !isPending && <p className="text-gray-400 text-center">Results will appear here...</p>}
        {output}
      </div>
    </div>
  );
}
