/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

import { StateGraph, Annotation, END, START } from "@langchain/langgraph";

// 1. State Interface with Trace ID
interface TravelAgentState {
  traceId: string;
  destination: string;
  budget: number;
  itinerary: any[];
  flightStatus?: 'searching' | 'available' | 'unavailable';
  weatherData?: any;
  nextStep: string;
  logs?: string[];
}

// 2. Debugging Middleware Structure
const debugMiddleware = (state: TravelAgentState, nodeName: string) => {
  const timestamp = new Date().toISOString();
  const logEntry = `[${timestamp}] Node: ${nodeName} | State: ${JSON.stringify({
    traceId: state.traceId,
    nextStep: state.nextStep,
    flightStatus: state.flightStatus,
    // Avoid logging huge objects in production, just keys
    itineraryLength: state.itinerary?.length 
  })}`;
  
  // In a real app, this might write to a DB, file, or WebSocket
  console.log(logEntry);
  
  // Return modified state if needed, or just pass through
  return { ...state, logs: [...(state.logs || []), logEntry] };
};

// 3. Graph Construction (Conceptual)
const workflow = new StateGraph<TravelAgentState>()
  .addNode("plan_itinerary", (state) => {
    const newState = debugMiddleware(state, "plan_itinerary");
    // Logic to plan...
    return { ...newState, nextStep: "check_flight" };
  })
  .addNode("check_flight_availability", (state) => {
    const newState = debugMiddleware(state, "check_flight_availability");
    // Logic to check flight...
    return { ...newState, flightStatus: "available", nextStep: "check_weather" };
  })
  .addNode("check_weather", (state) => {
    const newState = debugMiddleware(state, "check_weather");
    // Logic to check weather...
    return { ...newState, weatherData: { temp: 72 }, nextStep: "book_flight" };
  })
  .addNode("book_flight", (state) => {
    const newState = debugMiddleware(state, "book_flight");
    // Logic to book...
    return { ...newState, nextStep: "finalize_trip" };
  })
  .addNode("finalize_trip", (state) => {
    const newState = debugMiddleware(state, "finalize_trip");
    return { ...newState, nextStep: "finish" };
  })
  .addEdge(START, "plan_itinerary")
  .addEdge("plan_itinerary", "check_flight_availability")
  .addEdge("check_flight_availability", "check_weather")
  .addEdge("check_weather", "book_flight")
  .addEdge("book_flight", "finalize_trip")
  .addEdge("finalize_trip", END);

export const travelAgent = workflow.compile();

// 4. Graphviz DOT Definition
export const travelGraphViz = `
digraph TravelPlanner {
  rankdir=LR;
  node [shape=box, style="rounded,filled", color="#4F46E5", fontname="Arial"];
  
  start [shape="circle", label="Start", fillcolor="#E0E7FF"];
  finish [shape="doublecircle", label="End", fillcolor="#FEE2E2"];
  
  plan_itinerary [label="Plan Itinerary"];
  check_flight [label="Check Flight Availability"];
  check_weather [label="Check Weather"];
  book_flight [label="Book Flight"];
  finalize_trip [label="Finalize Trip"];

  start -> plan_itinerary;
  plan_itinerary -> check_flight;
  check_flight -> check_weather;
  check_weather -> book_flight;
  book_flight -> finalize_trip;
  finalize_trip -> finish;

  // Conditional Logic Visualization (Conceptual)
  check_flight -> plan_itinerary [label="Flight Unavailable\n(Re-plan)" style="dashed" color="red"];
  check_flight -> check_weather [label="Flight Available" color="green"];
}
`;
