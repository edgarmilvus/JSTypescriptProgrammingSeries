/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part6.tsx
// Description: Solutions and Explanations
// ==========================================

// components/TaskScheduler.tsx
'use client';

import { useState, useTransition, useOptimistic } from 'react';
import { Task, scheduleTasks } from '@/lib/taskAgent'; // Agent logic

export default function TaskScheduler({ initialTasks }: { initialTasks: Task[] }) {
  const [tasks, setTasks] = useState(initialTasks);
  const [logs, setLogs] = useState<string[]>([]);
  const [isPending, startTransition] = useTransition();

  // useOptimistic for immediate UI updates during execution
  const [optimisticTasks, addOptimisticTask] = useOptimistic(
    tasks,
    (state, newStatus: { id: string; status: 'pending' | 'running' | 'completed' | 'error' }) => {
      return state.map(t => 
        t.id === newStatus.id ? { ...t, status: newStatus.status } : t
      );
    }
  );

  const handleRun = () => {
    startTransition(async () => {
      // Run the agent stream
      const stream = scheduleTasks(tasks);
      
      for await (const step of stream) {
        if (step.type === 'thought') {
          setLogs(prev => [...prev, `Agent: ${step.content}`]);
        } else if (step.type === 'act') {
          // Optimistically update UI to show task is running
          addOptimisticTask({ id: step.taskId, status: 'running' });
          setLogs(prev => [...prev, `Executing: ${step.taskId}`]);
        } else if (step.type === 'observation') {
          // Update actual state on completion
          setTasks(prev => prev.map(t => 
            t.id === step.taskId ? { ...t, status: 'completed' } : t
          ));
          setLogs(prev => [...prev, `Completed: ${step.taskId}`]);
        } else if (step.type === 'error') {
          setTasks(prev => prev.map(t => 
            t.id === step.taskId ? { ...t, status: 'error' } : t
          ));
          setLogs(prev => [...prev, `Error: ${step.content}`]);
        }
      }
    });
  };

  return (
    <div className="grid grid-cols-2 gap-4 p-4">
      <div className="border p-4 rounded">
        <h2 className="font-bold mb-2">Tasks</h2>
        <ul className="space-y-2">
          {optimisticTasks.map(task => (
            <li key={task.id} className={`p-2 rounded border ${task.status === 'completed' ? 'bg-green-50' : task.status === 'running' ? 'bg-yellow-50' : 'bg-white'}`}>
              <div className="flex justify-between">
                <span>{task.description}</span>
                <span className="text-xs font-mono uppercase">{task.status || 'pending'}</span>
              </div>
              <div className="text-xs text-gray-500">Priority: {task.priority} | Deps: {task.dependencies.join(', ') || 'None'}</div>
            </li>
          ))}
        </ul>
        <button 
          onClick={handleRun} 
          disabled={isPending}
          className="mt-4 w-full bg-blue-600 text-white py-2 rounded hover:bg-blue-700 disabled:opacity-50"
        >
          {isPending ? 'Scheduling...' : 'Run Scheduler Agent'}
        </button>
      </div>
      
      <div className="border p-4 rounded bg-gray-50 font-mono text-sm overflow-y-auto max-h-[400px]">
        <h2 className="font-bold mb-2">Agent Log</h2>
        {logs.map((log, i) => (
          <div key={i} className="border-b border-gray-200 py-1">{log}</div>
        ))}
      </div>
    </div>
  );
}
