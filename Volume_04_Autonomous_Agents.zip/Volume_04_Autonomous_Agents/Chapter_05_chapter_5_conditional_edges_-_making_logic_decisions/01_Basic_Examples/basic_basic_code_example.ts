/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

import { StateGraph, Annotation, END, START } from "@langchain/langgraph";

/**
 * Represents the shared state of our support ticket workflow.
 * In a real SaaS app, this might be a database row or a Redux/Context store object.
 */
type SupportState = {
  ticketDescription: string;
  assignedDepartment: string | null;
  resolution: string | null;
};

/**
 * Defines the structure of the state using LangGraph's Annotation.
 * This ensures type safety throughout the graph execution.
 */
const StateAnnotation = Annotation.Root({
  ticketDescription: Annotation<string>({
    reducer: (current, update) => update, // Simply overwrite the description
    default: () => "",
  }),
  assignedDepartment: Annotation<string | null>({
    reducer: (current, update) => update, // Overwrite the department
    default: () => null,
  }),
  resolution: Annotation<string | null>({
    reducer: (current, update) => update,
    default: () => null,
  }),
});

/**
 * Node 1: Analyze the ticket content.
 * This simulates an LLM call or a simple keyword search to categorize the ticket.
 * @param state - The current workflow state
 * @returns The updated state with the assigned department
 */
const analyzeTicket = async (state: typeof StateAnnotation.State) => {
  console.log("--- Analyzing Ticket ---");
  const { ticketDescription } = state;
  let department = "General";

  // Simple keyword logic (in a real app, use an LLM)
  const lowerDesc = ticketDescription.toLowerCase();
  if (lowerDesc.includes("invoice") || lowerDesc.includes("payment")) {
    department = "Billing";
  } else if (lowerDesc.includes("api") || lowerDesc.includes("bug")) {
    department = "Technical Support";
  } else if (lowerDesc.includes("pricing") || lowerDesc.includes("plan")) {
    department = "Sales";
  }

  console.log(`Identified Department: ${department}`);
  return { assignedDepartment: department };
};

/**
 * Node 2: Handle Billing Department Logic.
 * @param state - The current workflow state
 * @returns The updated state with a resolution
 */
const handleBilling = async (state: typeof StateAnnotation.State) => {
  console.log("--- Processing in Billing Department ---");
  return { resolution: "Billing issue resolved. Invoice sent." };
};

/**
 * Node 3: Handle Technical Support Logic.
 * @param state - The current workflow state
 * @returns The updated state with a resolution
 */
const handleTechnical = async (state: typeof StateAnnotation.State) => {
  console.log("--- Processing in Technical Support ---");
  return { resolution: "Technical bug fixed. API key regenerated." };
};

/**
 * Node 4: Handle General/Sales Logic (Fallback).
 * @param state - The current workflow state
 * @returns The updated state with a resolution
 */
const handleGeneral = async (state: typeof StateAnnotation.State) => {
  console.log("--- Processing in General/Sales Queue ---");
  return { resolution: "General inquiry answered. Sales follow-up scheduled." };
};

/**
 * Routing Function: Determines the next step based on the assigned department.
 * This is the core logic of conditional edges.
 * @param state - The current workflow state
 * @returns The string key of the next node to execute
 */
const routeTicket = (state: typeof StateAnnotation.State) => {
  // Ensure we have a department assigned
  if (!state.assignedDepartment) {
    throw new Error("Department not assigned. Run 'analyzeTicket' first.");
  }

  console.log(`--- Routing to: ${state.assignedDepartment} ---`);

  switch (state.assignedDepartment) {
    case "Billing":
      return "billingNode";
    case "Technical Support":
      return "technicalNode";
    case "Sales":
    case "General":
      return "generalNode";
    default:
      // Safety fallback
      return "generalNode";
  }
};

// 1. Initialize the Graph with the defined State
const workflow = new StateGraph(StateAnnotation);

// 2. Add Nodes (Computational Steps)
workflow.addNode("analyzeNode", analyzeTicket);
workflow.addNode("billingNode", handleBilling);
workflow.addNode("technicalNode", handleTechnical);
workflow.addNode("generalNode", handleGeneral);

// 3. Define the Flow
// Start at 'analyzeNode'
workflow.addEdge(START, "analyzeNode");

// Add Conditional Edges
// Instead of a fixed destination, we use the 'routeTicket' function
workflow.addConditionalEdges(
  "analyzeNode",      // The node where the decision is made
  routeTicket,        // The function that evaluates the state and returns the next node
  {                   // Map of possible return values to node names (optional but recommended)
    "billingNode": "billingNode",
    "technicalNode": "technicalNode",
    "generalNode": "generalNode"
  }
);

// Add edges from the department nodes to the end of the graph
workflow.addEdge("billingNode", END);
workflow.addEdge("technicalNode", END);
workflow.addEdge("generalNode", END);

// 4. Compile the graph
const app = workflow.compile();

/**
 * Main execution function simulating a user submitting a ticket via a web form.
 */
async function runTicketSystem() {
  // Scenario 1: A technical bug report
  const ticketInput1 = {
    ticketDescription: "I am getting a 500 error on the API endpoint /users.",
  };

  console.log("\n🧪 Running Scenario 1: Technical Ticket");
  const result1 = await app.invoke(ticketInput1);
  console.log("Final Result:", result1);
  // Expected Output: Resolution = "Technical bug fixed..."

  // Scenario 2: A billing inquiry
  const ticketInput2 = {
    ticketDescription: "Where can I find my invoice for last month?",
  };

  console.log("\n🧪 Running Scenario 2: Billing Ticket");
  const result2 = await app.invoke(ticketInput2);
  console.log("Final Result:", result2);
  // Expected Output: Resolution = "Billing issue resolved..."
}

// Execute the system
runTicketSystem().catch(console.error);
