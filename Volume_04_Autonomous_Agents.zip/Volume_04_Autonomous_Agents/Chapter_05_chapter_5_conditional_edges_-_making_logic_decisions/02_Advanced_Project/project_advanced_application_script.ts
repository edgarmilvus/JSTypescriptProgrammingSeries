/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// File: lib/agents/supportRouter.ts
// Purpose: LangGraph implementation for conditional routing in customer support.

import { StateGraph, END, State } from "@langchain/langgraph";
import { ChatOpenAI } from "@langchain/openai";

// --- 1. STATE DEFINITION & TYPE SAFETY ---

/**
 * Defines the shape of the state passed between nodes.
 * Uses TypeScript interfaces for strict typing.
 */
interface SupportState {
  ticketId: string;
  customerQuery: string;
  category: "billing" | "technical" | "general" | null;
  sentiment: "positive" | "neutral" | "negative" | null;
  complexity: "low" | "high" | null;
  resolution: string | null;
}

// --- 2. NODE IMPLEMENTATION (SRP Adherence) ---

/**
 * Node: Classify Ticket
 * Responsibility: Determines the category of the ticket using an LLM.
 * Async/Await pattern simulates an external API call.
 */
async function classifyTicket(state: SupportState): Promise<Partial<SupportState>> {
  console.log(`[Node] Classifying Ticket: ${state.ticketId}`);
  
  // Simulating LLM call for categorization
  // In production, this would be a structured output LLM call
  const mockCategory = state.customerQuery.toLowerCase().includes("invoice") 
    ? "billing" 
    : "technical";
  
  // Simulating async processing delay
  await new Promise(resolve => setTimeout(resolve, 100));

  return { category: mockCategory };
}

/**
 * Node: Analyze Sentiment
 * Responsibility: Detects customer emotion to prioritize urgency.
 */
async function analyzeSentiment(state: SupportState): Promise<Partial<SupportState>> {
  console.log(`[Node] Analyzing Sentiment: ${state.ticketId}`);
  
  // Simulating sentiment analysis API
  const mockSentiment = state.customerQuery.toLowerCase().includes("angry") 
    ? "negative" 
    : "neutral";
  
  await new Promise(resolve => setTimeout(resolve, 100));

  return { sentiment: mockSentiment };
}

/**
 * Node: Assess Complexity
 * Responsibility: Determines if the issue requires Tier 2 support.
 */
async function assessComplexity(state: SupportState): Promise<Partial<SupportState>> {
  console.log(`[Node] Assessing Complexity: ${state.ticketId}`);
  
  // Simple heuristic for complexity
  const mockComplexity = state.customerQuery.length > 100 ? "high" : "low";
  
  await new Promise(resolve => setTimeout(resolve, 100));

  return { complexity: mockComplexity };
}

/**
 * Node: Tier 1 Support (Generic Agent)
 * Responsibility: Handles low complexity or general queries.
 */
async function tier1Support(state: SupportState): Promise<Partial<SupportState>> {
  console.log(`[Agent] Tier 1 Processing Ticket: ${state.ticketId}`);
  return { resolution: "Tier 1: Standard response sent via email." };
}

/**
 * Node: Tier 2 Support (Specialized Agent)
 * Responsibility: Handles high complexity or technical/billing issues.
 */
async function tier2Support(state: SupportState): Promise<Partial<SupportState>> {
  console.log(`[Agent] Tier 2 Processing Ticket: ${state.ticketId}`);
  return { resolution: "Tier 2: Escalated to specialist. Response drafted." };
}

/**
 * Node: Urgent Escalation
 * Responsibility: Handles negative sentiment regardless of complexity.
 */
async function urgentEscalation(state: SupportState): Promise<Partial<SupportState>> {
  console.log(`[Agent] Urgent Escalation for Ticket: ${state.ticketId}`);
  return { resolution: "URGENT: Manager notified. Immediate contact initiated." };
}

// --- 3. CONDITIONAL ROUTING LOGIC ---

/**
 * Router Function: Determines the next path based on state.
 * Implements Type Narrowing implicitly by checking state properties.
 * 
 * @param state - The current state of the graph
 * @returns The key of the next node or END
 */
function router(state: SupportState): "tier1" | "tier2" | "urgent" | typeof END {
  // Type Guard: Ensure required analysis is complete
  if (!state.sentiment || !state.complexity) {
    throw new Error("Routing attempted before analysis complete.");
  }

  // Logic 1: Urgency overrides everything
  if (state.sentiment === "negative") {
    return "urgent";
  }

  // Logic 2: High complexity routes to Tier 2
  if (state.complexity === "high") {
    return "tier2";
  }

  // Logic 3: Default to Tier 1 for low complexity
  return "tier1";
}

// --- 4. GRAPH CONSTRUCTION ---

// Initialize the StateGraph with the defined state interface
const workflow = new StateGraph<SupportState>({
  channels: {
    ticketId: { reducer: (x, y) => y ?? x, default: () => "" },
    customerQuery: { reducer: (x, y) => y ?? x, default: () => "" },
    category: { reducer: (x, y) => y ?? x, default: () => null },
    sentiment: { reducer: (x, y) => y ?? x, default: () => null },
    complexity: { reducer: (x, y) => y ?? x, default: () => null },
    resolution: { reducer: (x, y) => y ?? x, default: () => null },
  },
});

// Define Nodes
workflow.addNode("classify", classifyTicket);
workflow.addNode("analyze", analyzeSentiment);
workflow.addNode("assess", assessComplexity);
workflow.addNode("tier1", tier1Support);
workflow.addNode("tier2", tier2Support);
workflow.addNode("urgent", urgentEscalation);

// Define Edges
// Start -> Classify (Always first)
workflow.addEdge("__start__", "classify");

// After Classification -> Analyze & Assess (Parallel execution simulation)
// Note: In LangGraph, edges define flow. We can fan out to multiple nodes.
// However, for strict parallel execution in a linear state, we chain them 
// or use conditional edges to ensure all analysis is done.
workflow.addEdge("classify", "analyze");
workflow.addEdge("analyze", "assess");

// The Critical Conditional Edge
// We route ONLY after 'assess' is complete.
workflow.addConditionalEdges("assess", router, {
  "tier1": "tier1",
  "tier2": "tier2",
  "urgent": "urgent",
});

// Terminal Nodes -> END
workflow.addEdge("tier1", END);
workflow.addEdge("tier2", END);
workflow.addEdge("urgent", END);

// Compile the graph
const app = workflow.compile();

// --- 5. EXECUTION (Next.js API Route Context) ---

/**
 * Main execution function.
 * Simulates a Next.js API Route handler processing a POST request.
 */
async function processSupportTicket(ticketData: { id: string; query: string }) {
  console.log("\n--- Starting Support Workflow ---");
  
  try {
    // Initial State Setup
    const initialState: SupportState = {
      ticketId: ticketData.id,
      customerQuery: ticketData.query,
      category: null,
      sentiment: null,
      complexity: null,
      resolution: null,
    };

    // Execute the Graph
    // The graph handles the flow: Classify -> Analyze -> Assess -> (Conditional) -> Agent
    const finalState = await app.invoke(initialState);

    console.log("\n--- Workflow Complete ---");
    console.log("Final Resolution:", finalState.resolution);
    return finalState;
  } catch (error) {
    console.error("Workflow failed:", error);
    throw error;
  }
}

// --- Example Usage ---

// Case 1: Low complexity, neutral sentiment
processSupportTicket({
  id: "TICK-101",
  query: "How do I reset my password?",
});

// Case 2: High complexity, negative sentiment (Urgent Escalation)
setTimeout(() => {
  processSupportTicket({
    id: "TICK-102",
    query: "I am angry! The invoice is wrong and the system crashed. Fix it now.",
  });
}, 500);
