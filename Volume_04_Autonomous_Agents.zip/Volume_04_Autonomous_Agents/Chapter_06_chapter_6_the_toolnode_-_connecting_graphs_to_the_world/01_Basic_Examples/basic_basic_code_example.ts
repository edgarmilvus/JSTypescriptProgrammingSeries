/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

import { StateGraph, Annotation, START, END, ToolNode } from "@langchain/langgraph";
import { BaseMessage, AIMessage, ToolMessage } from "@langchain/core/messages";
import { z } from "zod";

/**
 * ============================================================================
 * 1. STATE DEFINITION & TOOLS
 * ============================================================================
 * We define the state of our graph and the tools available to the agent.
 */

/**
 * The state annotation defines the structure of data flowing through the graph.
 * In a SaaS context, we often track conversation history (messages) and 
 * specific business data (like user ID).
 */
const GraphState = Annotation.Root({
  messages: Annotation<BaseMessage[]>({
    reducer: (curr, update) => curr.concat(update),
    default: () => [],
  }),
  // Simulated context passed from the web app (e.g., from auth middleware)
  userId: Annotation<string>({
    reducer: (curr, update) => update ?? curr,
    default: () => "user_12345",
  }),
});

/**
 * TOOL DEFINITION: Fetch Subscription Status
 * 
 * 1. Zod Schema: Defines the strict input structure for the tool.
 *    - This prevents hallucinated parameters from the LLM.
 * 2. Tool Function: The actual logic that executes the API call or DB query.
 */

// Zod schema for the tool input
const subscriptionSchema = z.object({
  userId: z.string().describe("The unique identifier of the SaaS user"),
});

// Type inference from Zod for TypeScript safety
type SubscriptionInput = z.infer<typeof subscriptionSchema>;

/**
 * Simulates a database call to fetch subscription data.
 * In a real app, this would be `await db.query('SELECT * FROM subscriptions...')`
 * 
 * @param input - The validated parameters from the LLM.
 * @returns A string containing the subscription status.
 */
async function getSubscriptionStatus(input: SubscriptionInput): Promise<string> {
  console.log(`[Tool Execution] Fetching status for user: ${input.userId}`);
  
  // Simulate network latency
  await new Promise(resolve => setTimeout(resolve, 100));

  // Mock database response
  const mockDb = {
    "user_12345": { plan: "Pro", status: "Active", expires: "2024-12-31" },
    "user_99999": { plan: "Free", status: "Canceled", expires: "2023-01-01" },
  };

  const user = mockDb[input.userId as keyof typeof mockDb];
  
  if (!user) {
    throw new Error(`User ${input.userId} not found in database.`);
  }

  return JSON.stringify(user);
}

// Register the tool in a format compatible with LangChain/LangGraph
const tools = [
  {
    name: "get_subscription_status",
    description: "Retrieves the current subscription plan and status for a given user ID.",
    schema: subscriptionSchema,
    func: getSubscriptionStatus,
  },
];

/**
 * ============================================================================
 * 2. GRAPH CONSTRUCTION
 * ============================================================================
 * We build the state graph using the ToolNode.
 */

// Initialize the ToolNode with our defined tools
const toolNode = new ToolNode<typeof GraphState.State>(tools);

// Create the graph
const workflow = new StateGraph(GraphState);

// Add the tool node
workflow.addNode("tools", toolNode);

// In a real agent, we would add an LLM node here. 
// For this "Hello World" example, we will simulate the LLM output 
// directly to focus purely on the ToolNode mechanics.
workflow.addNode("simulated_llm", async (state) => {
  // Simulate an LLM deciding to call a tool
  const toolCall = {
    name: "get_subscription_status",
    args: { userId: state.userId }, // The LLM extracts the userId from context
    id: "call_123",
    type: "tool_call",
  };

  return {
    messages: [
      new AIMessage({
        content: "",
        tool_calls: [toolCall],
      }),
    ],
  };
});

// Define edges: Start -> LLM -> Tools -> End
workflow.addEdge(START, "simulated_llm");
workflow.addEdge("tools", END);
workflow.addEdge("simulated_llm", "tools"); 

// Conditional edge: In a real app, we check if the LLM called tools. 
// Here, we know the simulated LLM always calls a tool.
const shouldContinue = (state: typeof GraphState.State) => {
  const lastMessage = state.messages[state.messages.length - 1];
  // If the last message has tool calls, go to tools, otherwise end
  if (lastMessage.additional_kwargs?.tool_calls?.length > 0) {
    return "tools";
  }
  return END;
};

// Re-configure edges with conditional logic (Best Practice)
workflow.addConditionalEdges("simulated_llm", shouldContinue);

// Compile the graph
const app = workflow.compile();

/**
 * ============================================================================
 * 3. EXECUTION
 * ============================================================================
 * Running the graph and observing the flow.
 */

async function runSaaSDashboard() {
  console.log("--- Starting SaaS Support Agent ---");
  
  // Initial state input (simulating a request from a React/Next.js component)
  const initialInput = {
    userId: "user_12345", 
    messages: [] 
  };

  try {
    // Stream the execution
    const stream = await app.stream(initialInput);

    for await (const chunk of stream) {
      // Log the state updates from each node
      const node = Object.keys(chunk)[0];
      const state = chunk[node];
      
      console.log(`\n[Node: ${node}]`);
      
      if (state.messages && state.messages.length > 0) {
        const lastMsg = state.messages[state.messages.length - 1];
        
        if (lastMsg instanceof AIMessage) {
          console.log(`> LLM Output: Tool Call Requested -> ${lastMsg.tool_calls?.[0].name}`);
        } else if (lastMsg instanceof ToolMessage) {
          console.log(`> Tool Output: ${lastMsg.content}`);
        }
      }
    }
  } catch (error) {
    console.error("Error in workflow execution:", error);
  }
}

// Execute the example
runSaaSDashboard();
