/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script_part2.ts
// Description: Advanced Application Script
// ==========================================

// app/api/agent/route.ts
import { NextRequest } from 'next/server';
import { StateGraph, Annotation, toolsCondition, ToolNode } from '@langchain/langgraph';
import { Tool } from '@langchain/core/tools';
import { BaseMessage, AIMessage, ToolMessage } from '@langchain/core/messages';
import { StreamableValue, createStreamableValue } from 'ai/rsc';

// -----------------------------------------------------------------------------
// 1. DEFINITIONS & TYPES
// -----------------------------------------------------------------------------

/**
 * Represents the state of our agentic workflow.
 * @property messages - The conversation history (BaseMessage array).
 * @property processedDocument - Optional string representing the final output.
 */
type AgentState = {
  messages: BaseMessage[];
  processedDocument?: string;
};

// -----------------------------------------------------------------------------
// 2. TOOL DEFINITIONS
// -----------------------------------------------------------------------------

/**
 * Tool: VectorSearchTool
 * Simulates a semantic search against a pgvector database using HNSW indexing.
 * In a real app, this would connect to a PostgreSQL instance via `pg` and `pgvector`.
 */
class VectorSearchTool extends Tool {
  name = 'vector_search';
  description = 'Searches a vector database for document chunks similar to the user query.';

  async _call(query: string): Promise<string> {
    // Simulate HNSW Index Search Latency
    await new Promise(resolve => setTimeout(resolve, 300));
    
    // Simulate retrieval of relevant context
    const mockResults = [
      "Document ID: 42. Section: Pricing. Content: 'Enterprise Plan costs $500/mo with unlimited seats.'",
      "Document ID: 42. Section: Support. Content: 'Support is available 24/7 via chat and email.'"
    ];
    
    // Return formatted results as a string context
    return `Search Results for "${query}":\n- ${mockResults.join('\n- ')}`;
  }
}

/**
 * Tool: SummarizeTool
 * Simulates a call to an LLM endpoint (e.g., GPT-4) to summarize text.
 */
class SummarizeTool extends Tool {
  name = 'summarize_text';
  description = 'Summarizes a block of text into a concise paragraph.';

  async _call(text: string): Promise<string> {
    // Simulate API latency
    await new Promise(resolve => setTimeout(resolve, 400));
    
    // Simulated summary generation
    return `Summary: The document outlines the Enterprise Plan pricing at $500/mo and confirms 24/7 support availability.`;
  }
}

// -----------------------------------------------------------------------------
// 3. GRAPH CONSTRUCTION
// -----------------------------------------------------------------------------

// Define the State Annotation
const StateAnnotation = Annotation.Root({
  messages: Annotation<BaseMessage[]>({
    reducer: (curr, update) => (update instanceof Array ? update : [...curr, update]),
    default: () => [],
  }),
  processedDocument: Annotation<string | undefined>({
    reducer: (curr, update) => update ?? curr,
    default: () => undefined,
  }),
});

// Initialize Tools
const tools = [new VectorSearchTool(), new SummarizeTool()];
const toolNode = new ToolNode<AgentState>(tools);

/**
 * Router Node Logic
 * Decides whether to call a tool or finish based on the last AI message.
 */
async function router(state: typeof StateAnnotation.State) {
  const lastMessage = state.messages[state.messages.length - 1];
  
  // If the last message is an AIMessage with tool_calls, route to tools
  if (lastMessage instanceof AIMessage && lastMessage.tool_calls?.length) {
    return 'tools';
  }
  
  // Otherwise, we are done (or need human input)
  return '__end__';
}

/**
 * Agent Node Logic (Simulated Planner)
 * This acts as the "brain" that decides what tool to use.
 * In a full implementation, this would be an LLM call.
 */
async function planner(state: typeof StateAnnotation.State) {
  const { messages } = state;
  const lastUserMessage = messages[messages.length - 1].content as string;

  // Simple heuristic for demo purposes: 
  // If 'search' is in query, call vector_search. If 'summarize' is in query, call summarize_text.
  // In production, this would be an LLM generating the AIMessage with tool_calls.
  
  let toolName: string;
  let toolArgs: string;

  if (lastUserMessage.toLowerCase().includes('search')) {
    toolName = 'vector_search';
    toolArgs = lastUserMessage;
  } else if (lastUserMessage.toLowerCase().includes('summarize')) {
    toolName = 'summarize_text';
    toolArgs = "This is a sample text to summarize regarding the Enterprise Plan.";
  } else {
    // Fallback if no specific action is detected
    return { messages: [new AIMessage("I can help you search or summarize. Please specify.")] };
  }

  // Construct an AIMessage that requests a tool call
  const aiMsg = new AIMessage({
    content: '',
    tool_calls: [{ name: toolName, args: { input: toolArgs }, id: 'tool_call_id' }],
  });

  return { messages: [aiMsg] };
}

/**
 * Result Processor Node
 * Processes the output of the tools and updates the state.
 */
async function processResult(state: typeof StateAnnotation.State) {
  const lastMessage = state.messages[state.messages.length - 1];
  
  if (lastMessage instanceof ToolMessage) {
    // Extract the tool result and update the state with a final message
    const result = lastMessage.content;
    const finalMessage = new AIMessage(`Task completed. Result: ${result}`);
    
    return { 
      messages: [finalMessage],
      processedDocument: result.toString() // Store in the state for UI consumption
    };
  }
  
  return { messages: [] };
}

// Build the Graph
const workflow = new StateGraph(StateAnnotation)
  .addNode('planner', planner)
  .addNode('tools', toolNode)
  .addNode('processor', processResult)
  .addEdge('__start__', 'planner')
  .addConditionalEdges('planner', router, { tools: 'tools', __end__: '__end__' })
  .addEdge('tools', 'processor')
  .addEdge('processor', 'planner'); // Loop back to planner for next instruction

const app = workflow.compile();

// -----------------------------------------------------------------------------
// 4. NEXT.JS API ROUTE (EDGE RUNTIME)
// -----------------------------------------------------------------------------

export const runtime = 'edge'; // Use Edge Runtime for low latency

/**
 * Main API Handler
 * Receives user input, streams execution state back to the client.
 */
export async function POST(req: NextRequest) {
  const { message } = await req.json();
  
  // Initialize UI State Stream (Vercel AI SDK pattern)
  const stream = createStreamableValue<string>();
  
  // Run the graph in the background
  (async () => {
    try {
      // Initial State setup
      const initialInput = {
        messages: [new AIMessage(message)], // Simulating input injection
        processedDocument: undefined
      };

      // Stream events from the graph
      // Note: .streamEvents is a powerful method to capture intermediate steps
      const eventStream = await app.streamEvents(initialInput, { version: 'v1' });

      for await (const event of eventStream) {
        const eventType = event.event;
        
        // Update UI based on graph events
        if (eventType === 'on_chain_stream') {
          const node = event.metadata?.langgraph_node;
          const output = event.data?.chunk;
          
          if (node === 'planner') {
            stream.update(`[Planner] Deciding next action...`);
          } else if (node === 'tools') {
            stream.update(`[Tools] Executing external function...`);
          } else if (node === 'processor') {
            stream.update(`[Processor] Finalizing results...`);
          }
        }
        
        // Capture final state
        if (eventType === 'on_chain_end') {
           const finalState = event.data.output;
           if (finalState?.processedDocument) {
             stream.update(`[Final] ${finalState.processedDocument}`);
           }
        }
      }
      
      stream.done();
    } catch (error) {
      stream.error(error);
    }
  })();

  // Return the stream to the client
  return new Response(stream.value, {
    headers: { 'Content-Type': 'text/plain; charset=utf-8' },
  });
}
