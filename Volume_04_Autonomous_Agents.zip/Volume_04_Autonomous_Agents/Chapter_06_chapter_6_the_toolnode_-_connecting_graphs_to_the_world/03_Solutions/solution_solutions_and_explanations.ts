/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

import { ToolMessage } from "@langchain/core/messages";

// 1. Tool Definition
// We define the structure of the tool call arguments.
interface WeatherToolArgs {
  location: string;
  unit?: string;
}

// 2. Mock API Implementation
// Simulates an async network request with a random failure rate.
async function fetchWeather(location: string, unit: string = "celsius"): Promise<string> {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      // 10% chance of failure
      if (Math.random() < 0.1) {
        reject(new Error("Network Error: API Timeout"));
        return;
      }

      // Mock data
      const temp = Math.floor(Math.random() * 35);
      const conditions = ["Sunny", "Cloudy", "Rainy", "Windy"];
      const condition = conditions[Math.floor(Math.random() * conditions.length)];
      
      resolve(`${condition}, ${temp}°${unit === "celsius" ? "C" : "F"}`);
    }, 500); // Simulate 500ms latency
  });
}

// 3. ToolNode Implementation
// Handles the state update, tool parsing, and error catching.
function weatherToolNode(state: any) {
  // Inspect state for tool calls
  const toolCalls = state.messages[state.messages.length - 1].tool_calls || [];
  
  // Identify the specific tool call (in this case, we assume only one for simplicity)
  const weatherCall = toolCalls.find((call: any) => call.name === "get_weather");
  
  if (!weatherCall) {
    // If no weather tool call is found, return state unchanged or log warning
    return state; 
  }

  // Parse arguments
  const args = JSON.parse(weatherCall.args) as WeatherToolArgs;
  const location = args.location;
  const unit = args.unit || "celsius";

  try {
    // Execute API request
    const result = await fetchWeather(location, unit);
    
    // Format response
    const toolMessage = new ToolMessage({
      content: result,
      tool_call_id: weatherCall.id,
    });

    return {
      ...state,
      messages: [...state.messages, toolMessage],
    };
  } catch (error) {
    // Handle API failure
    const errorMessage = new ToolMessage({
      content: `Error fetching weather: ${(error as Error).message}`,
      tool_call_id: weatherCall.id,
    });

    return {
      ...state,
      messages: [...state.messages, errorMessage],
    };
  }
}
