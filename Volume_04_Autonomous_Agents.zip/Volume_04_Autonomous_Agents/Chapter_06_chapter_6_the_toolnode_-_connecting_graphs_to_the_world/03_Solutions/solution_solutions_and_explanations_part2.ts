/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

import { AIMessage, BaseMessage } from "@langchain/core/messages";
import { StateGraph, END } from "@langchain/langgraph";

// 1. State Definition
interface AgentState {
  messages: BaseMessage[];
  tool_calls?: any[]; // Optional, to track tool requests
}

// 2. Mock LLM Node
// Deterministically returns a response based on the last message content.
function llmNode(state: AgentState): { messages: AIMessage[] } {
  const lastMessage = state.messages[state.messages.length - 1];
  
  // Simulate reasoning to use a tool
  if (lastMessage.content.toString().includes("weather in Tokyo")) {
    const toolCall = {
      name: "get_weather",
      args: JSON.stringify({ location: "Tokyo" }),
      id: "call_123",
    };
    
    const aiMessage = new AIMessage({
      content: "I need to check the weather.",
      tool_calls: [toolCall],
    });
    
    return { messages: [aiMessage] };
  }

  // Simulate final answer after receiving tool result
  if (lastMessage._getType() === "tool") {
    const aiMessage = new AIMessage({
      content: "The weather is sunny in Tokyo.",
    });
    return { messages: [aiMessage] };
  }

  // Default fallback
  return { messages: [new AIMessage({ content: "I don't know." })] };
}

// 3. Tool Node (Simplified Mock)
// We reuse the logic from Exercise 1, but simplified for this example.
function weatherToolNode(state: AgentState): { messages: BaseMessage[] } {
  const lastMessage = state.messages[state.messages.length - 1] as AIMessage;
  const toolCall = lastMessage.tool_calls![0];
  
  // Mock execution result
  const toolMessage = new ToolMessage({
    content: "25°C, Sunny",
    tool_call_id: toolCall.id,
  });

  return { messages: [toolMessage] };
}

// 4. Router Function
// Determines the next node based on the presence of tool_calls in the last message.
function shouldUseTool(state: AgentState): "tool_node" | "llm_node" | typeof END {
  const lastMessage = state.messages[state.messages.length - 1];
  
  // If the last message is an AI message requesting a tool
  if (lastMessage._getType() === "ai" && (lastMessage as AIMessage).tool_calls?.length) {
    return "tool_node";
  }
  
  // If the last message is a ToolMessage or a generic AI response
  // In a real ReAct loop, we usually go back to the LLM to interpret tool results.
  if (lastMessage._getType() === "tool" || lastMessage._getType() === "ai") {
    return "llm_node";
  }

  return END;
}

// 5. Graph Construction
const graph = new StateGraph<AgentState>({
  channels: {
    messages: {
      value: (x: BaseMessage[], y: BaseMessage[]) => (x ? x : []).concat(y),
      default: () => [],
    },
  },
});

graph.addNode("llm_node", llmNode);
graph.addNode("tool_node", weatherToolNode);
graph.addConditionalEdges("llm_node", shouldUseTool);
graph.addConditionalEdges("tool_node", shouldUseTool);
graph.setEntryPoint("llm_node");

// Compile the graph
const runnable = graph.compile();
