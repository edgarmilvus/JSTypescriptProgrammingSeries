/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

// 1. Mock Embedding Generation
// Simulates generating a 1536-dimension vector.
async function generateEmbedding(text: string): Promise<number[]> {
  // In a real app, this would call OpenAI or another embedding provider.
  // Here we return a deterministic-looking random vector for demo purposes.
  const vector = new Array(1536).fill(0).map((_, i) => {
    // Pseudo-random based on char codes to keep it consistent for the same text
    return Math.sin(text.charCodeAt(0) + i) * 0.5;
  });
  return vector;
}

// 2. Database Query Logic
// Simulates a SQL query execution.
async function performVectorSearch(query: string, limit: number = 3, filterCategory?: string) {
  // Generate the embedding for the query
  const queryEmbedding = await generateEmbedding(query);
  
  // Mock SQL Client (e.g., pg-promise or TypeORM)
  // In a real scenario, this would be a parameterized SQL query.
  let sql = `
    SELECT description, embedding <=> $1 as similarity 
    FROM products 
  `;

  const params: any[] = [queryEmbedding];

  // 3. Interactive Challenge: Filtering
  // If a category filter is provided, inject the WHERE clause.
  if (filterCategory) {
    sql += ` WHERE category = $2`;
    params.push(filterCategory);
  }

  sql += ` ORDER BY similarity ASC LIMIT $${params.length + 1}`;
  params.push(limit);

  console.log(`Executing SQL: ${sql}`);
  console.log(`With Params:`, params);

  // Simulate DB Response
  return [
    { description: "High-performance running shoes", similarity: 0.12 },
    { description: "Lightweight trail runners", similarity: 0.25 },
  ];
}

// 4. Tool Definition
const vectorSearchTool = {
  name: "vector_search",
  description: "Search for products using semantic similarity.",
  parameters: {
    type: "object",
    properties: {
      query_text: { type: "string", description: "The text to search for" },
      limit: { type: "number", description: "Number of results", default: 3 },
      filter_category: { type: "string", description: "Optional category filter" }
    },
    required: ["query_text"],
  },
};

// Example Usage
// performVectorSearch("comfortable shoes for running", 5, "Footwear");
