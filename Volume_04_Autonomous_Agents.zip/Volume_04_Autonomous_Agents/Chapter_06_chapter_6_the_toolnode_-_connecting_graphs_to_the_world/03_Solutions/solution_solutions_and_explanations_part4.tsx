/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState, useEffect } from 'react';
import { BaseMessage } from '@langchain/core/messages';

// 1. State Propagation: Extended AgentState
interface AgentState {
  messages: BaseMessage[];
  status: 'idle' | 'thinking' | 'tool_running';
}

// 2. Graph Updates: Example Node Logic
// This would be inside your graph node definitions (e.g., llmNode)
function updateStateForLLM(state: AgentState): AgentState {
  return {
    ...state,
    status: 'thinking', // Set status to thinking
  };
}

function updateStateForTool(state: AgentState): AgentState {
  return {
    ...state,
    status: 'tool_running', // Set status to tool running
  };
}

// 3. React Component: StatusIndicator
const StatusIndicator: React.FC<{ status: string }> = ({ status }) => {
  if (status === 'idle') return null;

  return (
    <div style={{ padding: '10px', backgroundColor: '#f0f0f0', borderRadius: '4px', marginBottom: '10px' }}>
      {status === 'thinking' && (
        <span>🧠 Thinking... <span className="spinner"></span></span>
      )}
      {status === 'tool_running' && (
        <span>🔍 Searching Database... <span className="spinner"></span></span>
      )}
    </div>
  );
};

// 4. Integration: ChatWindow
const ChatWindow: React.FC = () => {
  const [status, setStatus] = useState<'idle' | 'thinking' | 'tool_running'>('idle');
  const [messages, setMessages] = useState<BaseMessage[]>([]);

  // Mock function to simulate streaming updates from LangGraph
  const simulateStream = async () => {
    // 1. User asks question
    setStatus('thinking'); 
    
    // Simulate LLM delay
    await new Promise(r => setTimeout(r, 1000));
    
    // 2. LLM requests tool
    setStatus('tool_running');
    
    // Simulate Tool delay
    await new Promise(r => setTimeout(r, 1000));
    
    // 3. Tool returns, LLM responds
    setStatus('idle');
  };

  useEffect(() => {
    simulateStream();
  }, []);

  return (
    <div className="chat-container">
      {/* Status Indicator Component */}
      <StatusIndicator status={status} />
      
      {/* Messages List */}
      <div className="messages">
        {messages.map((msg, idx) => (
          <div key={idx}>{msg.content.toString()}</div>
        ))}
      </div>
    </div>
  );
};
