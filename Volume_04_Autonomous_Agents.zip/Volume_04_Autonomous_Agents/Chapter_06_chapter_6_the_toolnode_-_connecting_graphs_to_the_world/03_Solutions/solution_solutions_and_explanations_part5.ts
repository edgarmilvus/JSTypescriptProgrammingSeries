/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

import { AIMessage, ToolMessage } from "@langchain/core/messages";

// 1. Custom Error Type
class ToolExecutionError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "ToolExecutionError";
  }
}

// 2. Updated State Interface
interface AgentState {
  messages: any[];
  tool_calls?: any[];
  error: string | null; // Track errors
}

// 3. Enhanced ToolNode with Error Handling
function weatherToolNode(state: AgentState): AgentState {
  const toolCall = state.messages[state.messages.length - 1].tool_calls[0];
  
  try {
    // Simulate an API call that might fail
    const willFail = Math.random() < 0.5; // 50% failure rate for testing
    if (willFail) {
      throw new ToolExecutionError("WeatherAPIUnavailable");
    }

    // Success path
    const result = "25°C, Sunny";
    const toolMessage = new ToolMessage({
      content: result,
      tool_call_id: toolCall.id,
    });

    return {
      ...state,
      error: null, // Clear previous errors
      messages: [...state.messages, toolMessage],
    };

  } catch (err) {
    // Error path
    const errorMsg = `Error: ${(err as Error).message}`;
    const toolMessage = new ToolMessage({
      content: errorMsg,
      tool_call_id: toolCall.id,
    });

    return {
      ...state,
      error: errorMsg, // Set error state
      messages: [...state.messages, toolMessage],
    };
  }
}

// 4. Conditional Edge for Errors
// Checks if an error occurred during tool execution.
function routeAfterTool(state: AgentState): string {
  // In a complex graph, we might route to a specific "error_handler" node.
  // Here, we route back to the LLM to let it formulate a response to the user
  // about the failure.
  return "llm_node";
}

// 5. Graph Modification (Conceptual)
// const graph = new StateGraph<AgentState>({ ... });
// graph.addNode("tool_node", weatherToolNode);
// graph.addConditionalEdges("tool_node", routeAfterTool);
