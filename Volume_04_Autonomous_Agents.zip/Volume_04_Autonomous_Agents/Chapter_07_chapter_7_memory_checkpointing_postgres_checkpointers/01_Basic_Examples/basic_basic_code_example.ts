/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

// File: src/checkpoint-demo.ts

import { StateGraph, END, MemorySaver } from "@langchain/langgraph";
import { PostgresSaver } from "@langchain/langgraph-checkpoint-postgres";
import { BaseMessage, HumanMessage } from "@langchain/core/messages";
import { z } from "zod";

/**
 * 1. DEFINE STATE SCHEMA
 * We define the shape of the state our agent will hold.
 * In a real app, this might include 'conversationHistory', 'userProfile', etc.
 */
const AgentStateSchema = z.object({
  messages: z.array(z.instanceOf(BaseMessage)),
  stepCount: z.number().default(0),
  status: z.enum(["running", "completed"]).default("running"),
});

type AgentState = z.infer<typeof AgentStateSchema>;

/**
 * 2. DEFINE AGENT NODES (LOGIC)
 * These are the individual steps in our workflow.
 */

/**
 * Node A: Process Input
 * Increments the step count and logs the input.
 */
async function processInput(state: AgentState): Promise<Partial<AgentState>> {
  console.log(`[Node ProcessInput] Current Step Count: ${state.stepCount}`);
  return {
    stepCount: state.stepCount + 1,
    messages: [...state.messages, new HumanMessage("Processing input...")],
  };
}

/**
 * Node B: Finalize
 * Sets status to completed and increments step count.
 */
async function finalize(state: AgentState): Promise<Partial<AgentState>> {
  console.log(`[Node Finalize] Current Step Count: ${state.stepCount}`);
  return {
    stepCount: state.stepCount + 1,
    status: "completed",
    messages: [...state.messages, new HumanMessage("Task completed.")],
  };
}

/**
 * 3. BUILD THE GRAPH
 * We create a workflow that goes: Start -> ProcessInput -> Finalize -> End
 */
function createWorkflow() {
  const workflow = new StateGraph(AgentStateSchema)
    // Define nodes
    .addNode("process_input", processInput)
    .addNode("finalize", finalize)
    // Define edges (workflow logic)
    .addEdge("process_input", "finalize")
    .addEdge("finalize", END)
    // Set the entry point
    .setEntryPoint("process_input");

  return workflow;
}

/**
 * 4. MAIN EXECUTION FUNCTION
 * This function simulates the SaaS backend logic.
 */
async function runCheckpointDemo() {
  // --- CONFIGURATION ---
  // In a real app, use process.env.DATABASE_URL
  const postgresUrl = "postgresql://user:password@localhost:5432/mydb";

  console.log("--- Starting Checkpoint Demo ---");

  // Initialize the Postgres Checkpointer
  // This connects to the DB and prepares the 'langgraph_checkpoint' table
  const checkpointer = new PostgresSaver({
    connectionString: postgresUrl,
  });

  // Wait for the checkpointer to be ready (connection established)
  await checkpointer.setup();

  // Create the workflow
  const app = createWorkflow();

  // Compile the graph with the checkpointer
  const compiledApp = app.compile({
    checkpointer,
    // We set a unique ID for this specific conversation/session
    // In a web app, this would be the userId or chatId
    config: { configurable: { thread_id: "user-session-123" } },
  });

  // --- SCENARIO 1: FIRST RUN (Simulating initial request) ---
  console.log("\n>>> SCENARIO 1: Initial Request");
  const initialInput = {
    messages: [new HumanMessage("Hello, agent!")],
  };

  try {
    // .stream() returns an async iterator. We use for await to process chunks.
    // In a web app, you would stream these chunks to the frontend via Server-Sent Events (SSE).
    const stream = await compiledApp.stream(initialInput);

    for await (const chunk of stream) {
      // Log the update from the specific node
      if (chunk?.process_input) {
        console.log("Stream Update:", {
          stepCount: chunk.process_input.stepCount,
          status: chunk.process_input.status,
        });
      } else if (chunk?.finalize) {
        console.log("Stream Update:", {
          stepCount: chunk.finalize.stepCount,
          status: chunk.finalize.status,
        });
      }
    }

    // Verify state was saved
    // We manually query the checkpointer to show it exists in DB
    const savedState = await checkpointer.get({
      configurable: { thread_id: "user-session-123" },
    });
    console.log(`\n[DB Check] State saved. Final Step Count: ${savedState?.stepCount}`);
  } catch (error) {
    console.error("Error in first run:", error);
  }

  // --- SCENARIO 2: SECOND RUN (Simulating a restart or new request) ---
  // We simulate a "restart" by creating a NEW instance of the compiled app
  // but using the SAME checkpointer and SAME thread_id.
  console.log("\n>>> SCENARIO 2: Server Restart / Follow-up Request");
  
  const app2 = createWorkflow();
  const compiledApp2 = app2.compile({
    checkpointer,
    config: { configurable: { thread_id: "user-session-123" } },
  });

  // Note: We pass an empty object as input because the graph will 
  // automatically load the last saved state for this thread_id.
  const stream2 = await compiledApp2.stream({});

  for await (const chunk of stream2) {
    if (chunk?.process_input) {
      console.log("Stream Update:", {
        stepCount: chunk.process_input.stepCount,
        status: chunk.process_input.status,
      });
    }
  }

  console.log("\n--- Demo Complete ---");
  console.log("Notice how the stepCount continued from 2 to 3, proving state was restored.");
}

// Execute the demo
runCheckpointDemo().catch(console.error);
