/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// File: app/api/research/route.ts
// Framework: Next.js 14+ (App Router) + TypeScript
// Dependencies: @langchain/langgraph, @langchain/community, pg, langchain

import { NextRequest, NextResponse } from 'next/server';
import { StateGraph, Annotation, MemorySaver } from '@langchain/langgraph';
import { PostgresSaver } from '@langchain/community/storage/postgres';
import { BaseMessage, HumanMessage, AIMessage } from '@langchain/core/messages';
import { ChatOpenAI } from '@langchain/openai';
import { RunnableConfig } from '@langchain/core/runnables';

// ============================================================================
// 1. STATE DEFINITION & AGENT LOGIC
// ============================================================================

/**
 * Defines the state schema for our research workflow.
 * @property messages - An array of conversation history (BaseMessage).
 * @property researchTopic - The specific topic to investigate.
 * @property iterationCount - Tracks how many times the Critic has reviewed the work.
 */
const ResearchState = Annotation.Root({
  messages: Annotation<BaseMessage[]>({
    reducer: (curr, update) => (Array.isArray(update) ? [...curr, ...update] : [...curr, update]),
    default: () => [],
  }),
  researchTopic: Annotation<string>({
    reducer: (curr, update) => update ?? curr,
    default: () => '',
  }),
  iterationCount: Annotation<number>({
    reducer: (curr, update) => update,
    default: () => 0,
  }),
});

// Initialize LLM (Simulating a local AI warm start context via API)
const llm = new ChatOpenAI({
  model: 'gpt-3.5-turbo',
  temperature: 0.7,
});

/**
 * Node 1: The Researcher Agent
 * Generates an initial hypothesis or draft based on the topic.
 */
const researchNode = async (state: typeof ResearchState.State) => {
  console.log('--- Executing Researcher Node ---');
  const systemPrompt = `You are a senior research analyst. Based on the topic, generate a concise 3-sentence hypothesis. Topic: ${state.researchTopic}`;
  
  const response = await llm.invoke([
    new HumanMessage(systemPrompt),
    ...state.messages
  ]);

  return {
    messages: [response],
    iterationCount: state.iterationCount + 1
  };
};

/**
 * Node 2: The Critic Agent
 * Reviews the researcher's work and decides if it's sufficient.
 */
const criticNode = async (state: typeof ResearchState.State) => {
  console.log('--- Executing Critic Node ---');
  const lastMessage = state.messages[state.messages.length - 1];
  
  const systemPrompt = `You are a strict editor. Review the following hypothesis. 
  If it is good, respond with "APPROVED". 
  If it needs work, respond with "NEEDS_REVISION: [specific feedback]".`;
  
  const response = await llm.invoke([
    new HumanMessage(systemPrompt),
    lastMessage
  ]);

  const content = response.content as string;
  
  // Logic to determine if we loop or finish
  if (content.includes('APPROVED') || state.iterationCount > 2) {
    return {
      messages: [new AIMessage("Research complete. Hypothesis approved.")],
    };
  } else {
    // Return state to trigger a loop back to the researcher
    return {
      messages: [response],
      iterationCount: state.iterationCount + 1
    };
  }
};

/**
 * Edge Logic: Determine the next step based on the Critic's response.
 */
const routeCritic = (state: typeof ResearchState.State) => {
  const lastMessage = state.messages[state.messages.length - 1];
  const content = lastMessage.content as string;
  
  // If the critic didn't approve and we haven't hit max iterations, go back to researcher
  if (!content.includes('APPROVED') && state.iterationCount < 3) {
    return 'researcher';
  }
  return '__end__';
};

// ============================================================================
// 2. DATABASE & CHECKPOINTING SETUP
// ============================================================================

/**
 * Initializes the PostgresSaver.
 * In a real SaaS, DB_URL comes from environment variables (e.g., Vercel Postgres).
 * We use the PostgresSaver to persist the graph state (messages, counters) to SQL tables.
 */
const initializeCheckpointer = () => {
  const dbUrl = process.env.DATABASE_URL || 'postgresql://user:password@localhost:5432/my_saas_db';
  
  // PostgresSaver handles table creation (langgraph_schema, checkpoints, checkpoint_writes) automatically.
  return PostgresSaver.fromConnectionString(dbUrl);
};

// ============================================================================
// 3. WORKFLOW ORCHESTRATION
// ============================================================================

/**
 * Main API Route Handler (Next.js App Router).
 * Handles POST requests to start or resume a research session.
 */
export async function POST(req: NextRequest) {
  try {
    // 1. Parse Request
    const { topic, threadId } = await req.json();
    
    if (!topic && !threadId) {
      return NextResponse.json(
        { error: 'Either "topic" (for new) or "threadId" (for resume) is required.' },
        { status: 400 }
      );
    }

    // 2. Initialize Checkpointer
    const checkpointer = await initializeCheckpointer();
    
    // 3. Define Graph
    const workflow = new StateGraph(ResearchState)
      .addNode('researcher', researchNode)
      .addNode('critic', criticNode)
      .addEdge('__start__', 'researcher')
      .addEdge('researcher', 'critic')
      .addConditionalEdges('critic', routeCritic)
      .compile({ checkpointer });

    // 4. Configuration
    // thread_id is the unique identifier for a conversation/session in LangGraph.
    const config: RunnableConfig = { 
      configurable: { thread_id: threadId || `research_${Date.now()}` } 
    };

    // 5. Execution Logic
    let result;
    
    if (threadId) {
      // RESUME MODE: We provide an empty input, and the graph resumes from the last checkpoint.
      // The state is automatically loaded from Postgres.
      console.log(`Resuming workflow for thread: ${threadId}`);
      result = await workflow.invoke({ messages: [] }, config);
    } else {
      // NEW MODE: Start fresh with the user's topic.
      console.log(`Starting new workflow for topic: ${topic}`);
      result = await workflow.invoke(
        { researchTopic: topic, messages: [] }, 
        config
      );
    }

    // 6. Cleanup
    await checkpointer.close();

    // Return the final state and the thread ID for future reference
    return NextResponse.json({
      threadId: config.configurable.thread_id,
      finalState: result,
      message: "Workflow executed successfully. State persisted to Postgres."
    });

  } catch (error) {
    console.error('Workflow Error:', error);
    return NextResponse.json(
      { error: 'Internal Server Error', details: (error as Error).message },
      { status: 500 }
    );
  }
}
