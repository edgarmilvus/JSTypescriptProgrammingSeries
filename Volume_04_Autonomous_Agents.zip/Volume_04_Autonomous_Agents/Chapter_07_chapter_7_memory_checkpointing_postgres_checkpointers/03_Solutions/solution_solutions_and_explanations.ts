/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

import { StateGraph, Annotation, StateSendMessage } from "@langchain/langgraph";
import { PostgresSaver } from "@langchain/postgres";
import { Client } from "pg";

// 1. Define State
const StateAnnotation = Annotation.Root({
  messages: Annotation<string[]>({
    reducer: (curr, update) => [...curr, update],
    default: () => [],
  }),
});

// 2. Define Nodes
const agentNode = async (state: typeof StateAnnotation.State) => {
  // Simulate agent logic
  const lastMessage = state.messages[state.messages.length - 1];
  const response = `Acknowledged: "${lastMessage}"`;
  return { messages: [response] };
};

// 3. Initialize Database Connection
// Note: Ensure your Postgres instance is running and accessible.
const dbConfig = {
  connectionString: "postgresql://user:password@localhost:5432/mydb", // Update with your credentials
};

// 4. Initialize Checkpointer
// We create a client to manage the connection pool/transactions
const pgClient = new Client(dbConfig);
await pgClient.connect();

// Initialize PostgresSaver (LangChain handles table creation automatically)
const checkpointer = new PostgresSaver(pgClient);

// 5. Build and Compile Graph
const workflow = new StateGraph(StateAnnotation)
  .addNode("agent", agentNode)
  .addEdge("__start__", "agent")
  .addEdge("agent", "__end__");

const graph = workflow.compile({ checkpointer });

// 6. Run Agent Function
async function runAgent(threadId: string, message: string) {
  const config = {
    configurable: {
      thread_id: threadId,
    },
    // Run ID is optional but helpful for tracking
    runId: `run-${Date.now()}`, 
  };

  // Invoke the graph. 
  // The checkpointer automatically loads the latest state for the thread_id
  // and saves the new state after execution.
  const result = await graph.invoke(
    { messages: [message] }, 
    config
  );

  console.log(`[Thread: ${threadId}] Result:`, result.messages);
  return result;
}

// 7. Verification Script
async function main() {
  try {
    console.log("Starting conversation simulation...");

    // Conversation 1
    await runAgent("thread_001", "Hello");
    await runAgent("thread_001", "How are you?");
    await runAgent("thread_001", "Tell me a joke");

    // Conversation 2
    await runAgent("thread_002", "Good morning");
    await runAgent("thread_002", "What is the weather?");
    await runAgent("thread_002", "Thanks");

    console.log("\n--- Simulation Complete ---");
    console.log("Please query the database to verify:");
    console.log("SELECT * FROM checkpoint_blobs WHERE thread_id = 'thread_001';");
    console.log("SELECT * FROM checkpoint_blobs WHERE thread_id = 'thread_002';");
    
  } catch (error) {
    console.error("Error during execution:", error);
  } finally {
    await pgClient.end();
  }
}

main();
