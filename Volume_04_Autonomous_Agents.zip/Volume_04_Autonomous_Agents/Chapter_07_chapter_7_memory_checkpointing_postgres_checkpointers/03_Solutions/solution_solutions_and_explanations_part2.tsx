/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState, useEffect } from 'react';

// Interface definitions
interface Checkpoint {
  checkpoint_id: string;
  parent_checkpoint_id?: string;
  timestamp: Date;
  state: Record<string, any>;
}

interface CheckpointExplorerProps {
  threadId: string;
  apiEndpoint: string;
}

export const CheckpointExplorer: React.FC<CheckpointExplorerProps> = ({ threadId, apiEndpoint }) => {
  const [checkpoints, setCheckpoints] = useState<Checkpoint[]>([]);
  const [selectedCheckpoint, setSelectedCheckpoint] = useState<Checkpoint | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const [toast, setToast] = useState<string | null>(null);

  // 1. Fetch checkpoints on mount or threadId change
  useEffect(() => {
    const fetchCheckpoints = async () => {
      setLoading(true);
      setError(null);
      try {
        // Assuming backend endpoint: /api/checkpoints/:threadId
        const response = await fetch(`${apiEndpoint}/${threadId}`);
        if (!response.ok) throw new Error('Failed to fetch checkpoints');
        const data: Checkpoint[] = await response.json();
        
        // Sort by timestamp to ensure chronological order
        data.sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime());
        setCheckpoints(data);
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Unknown error');
      } finally {
        setLoading(false);
      }
    };

    if (threadId) fetchCheckpoints();
  }, [threadId, apiEndpoint]);

  // 2. Handle Restore Action
  const handleRestore = async (checkpointId: string) => {
    try {
      // Assuming backend endpoint: /api/checkpoints/restore
      const response = await fetch(`${apiEndpoint}/restore`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ threadId, checkpointId }),
      });

      if (!response.ok) throw new Error('Restore failed');
      
      setToast(`Successfully restored to checkpoint ${checkpointId}`);
      setTimeout(() => setToast(null), 3000);
      
      // Optional: Refresh list or update local state if needed
    } catch (err) {
      setToast(`Error: ${err instanceof Error ? err.message : 'Restore failed'}`);
      setTimeout(() => setToast(null), 3000);
    }
  };

  if (loading) return <div>Loading checkpoints...</div>;
  if (error) return <div style={{ color: 'red' }}>Error: {error}</div>;

  // Determine the latest checkpoint (simple logic: last in sorted array)
  const latestCheckpointId = checkpoints.length > 0 
    ? checkpoints[checkpoints.length - 1].checkpoint_id 
    : null;

  return (
    <div className="checkpoint-explorer" style={{ display: 'flex', gap: '20px', padding: '20px' }}>
      {/* Timeline View */}
      <div className="timeline" style={{ width: '40%', borderRight: '1px solid #ccc', paddingRight: '20px' }}>
        <h3>Timeline (Thread: {threadId})</h3>
        <ul style={{ listStyle: 'none', padding: 0 }}>
          {checkpoints.map((cp) => (
            <li 
              key={cp.checkpoint_id} 
              style={{ 
                marginBottom: '10px', 
                padding: '10px', 
                border: '1px solid #eee', 
                borderRadius: '4px',
                backgroundColor: cp.checkpoint_id === latestCheckpointId ? '#e6fffa' : '#f9f9f9'
              }}
            >
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <strong>ID: {cp.checkpoint_id.substring(0, 8)}...</strong>
                <span style={{ fontSize: '0.8em', color: '#666' }}>
                  {new Date(cp.timestamp).toLocaleTimeString()}
                </span>
              </div>
              <div style={{ marginTop: '5px' }}>
                <button onClick={() => setSelectedCheckpoint(cp)}>Inspect</button>
                <button 
                  onClick={() => handleRestore(cp.checkpoint_id)}
                  style={{ marginLeft: '5px', color: 'blue', cursor: 'pointer' }}
                >
                  Restore to this Point
                </button>
              </div>
            </li>
          ))}
        </ul>
      </div>

      {/* State Inspector */}
      <div className="inspector" style={{ width: '60%' }}>
        <h3>State Inspector</h3>
        {selectedCheckpoint ? (
          <div>
            <p><strong>Selected ID:</strong> {selectedCheckpoint.checkpoint_id}</p>
            <pre 
              style={{ 
                background: '#f4f4f4', 
                padding: '10px', 
                borderRadius: '4px', 
                overflow: 'auto',
                maxHeight: '400px'
              }}
            >
              {JSON.stringify(selectedCheckpoint.state, null, 2)}
            </pre>
          </div>
        ) : (
          <p>Click a checkpoint to view its state.</p>
        )}
      </div>

      {/* Toast Notification */}
      {toast && (
        <div style={{
          position: 'fixed', bottom: '20px', right: '20px',
          background: '#333', color: '#fff', padding: '10px 20px',
          borderRadius: '4px', zIndex: 1000
        }}>
          {toast}
        </div>
      )}
    </div>
  );
};
