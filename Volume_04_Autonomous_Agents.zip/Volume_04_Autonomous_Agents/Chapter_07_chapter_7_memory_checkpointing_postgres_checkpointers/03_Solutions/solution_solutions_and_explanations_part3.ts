/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

import { StateGraph, Annotation } from "@langchain/langgraph";
import { PostgresSaver, Serializer } from "@langchain/postgres";
import { Client } from "pg";

// 1. Define State Interface
interface AgentState {
  messages: string[];
  inventory: Map<string, number>;
}

// 2. Define Custom Serializer
class InventorySerializer implements Serializer {
  // Serialize: Convert Map to Array of arrays for JSON storage
  serialize(state: AgentState): string {
    const serializableState = {
      ...state,
      inventory: Array.from(state.inventory.entries()), // Convert Map to [[key, val], ...]
    };
    return JSON.stringify(serializableState);
  }

  // Deserialize: Convert Array of arrays back to Map
  deserialize(data: string): AgentState {
    const parsed = JSON.parse(data) as {
      messages: string[];
      inventory: [string, number][];
    };
    
    return {
      messages: parsed.messages,
      inventory: new Map(parsed.inventory), // Reconstruct Map
    };
  }
}

// 3. Graph Setup
const StateAnnotation = Annotation.Root({
  messages: Annotation<string[]>({
    reducer: (curr, update) => [...curr, update],
    default: () => [],
  }),
  inventory: Annotation<Map<string, number>>({
    reducer: (curr, update) => {
      // Simple merge logic for the map
      const newMap = new Map(curr);
      update.forEach((val, key) => newMap.set(key, val));
      return newMap;
    },
    default: () => new Map(),
  }),
});

const updateInventoryNode = async (state: AgentState) => {
  // Simulate adding an item
  const newInventory = new Map(state.inventory);
  const item = "Potion";
  const count = (newInventory.get(item) || 0) + 1;
  newInventory.set(item, count);
  
  return { 
    messages: [`Added ${item} to inventory. Total: ${count}`],
    inventory: newInventory 
  };
};

// 4. Initialization with Custom Serializer
const dbConfig = {
  connectionString: "postgresql://user:password@localhost:5432/mydb",
};

async function runTest() {
  const pgClient = new Client(dbConfig);
  await pgClient.connect();

  // Initialize checkpointer with the custom serializer
  const checkpointer = new PostgresSaver(pgClient, {
    serializer: new InventorySerializer(),
  });

  const workflow = new StateGraph(StateAnnotation)
    .addNode("inventory_node", updateInventoryNode)
    .addEdge("__start__", "inventory_node")
    .addEdge("inventory_node", "__end__");

  const graph = workflow.compile({ checkpointer });

  const threadId = "inventory_test_01";
  const config = { configurable: { thread_id: threadId } };

  // --- First Run (Simulating process start) ---
  console.log("Step 1: Running graph to add items...");
  await graph.invoke({ messages: ["Start"], inventory: new Map() }, config);
  
  // --- Second Run (Simulating process restart) ---
  console.log("Step 2: Simulating restart...");
  
  // Clear graph instance (conceptual)
  // In reality, we just create a new graph instance connected to the same DB
  const workflow2 = new StateGraph(StateAnnotation)
    .addNode("inventory_node", updateInventoryNode)
    .addEdge("__start__", "inventory_node")
    .addEdge("inventory_node", "__end__");
    
  const graph2 = workflow2.compile({ checkpointer: new PostgresSaver(pgClient, { serializer: new InventorySerializer() }) });

  // Invoke again. The checkpointer loads the previous state (including the Map)
  const result = await graph2.invoke(undefined, config);

  // 5. Verification
  console.log("Final State:", result);
  console.log("Is inventory a Map?", result.inventory instanceof Map);
  console.log("Inventory contents:", result.inventory);

  await pgClient.end();
}

runTest().catch(console.error);
