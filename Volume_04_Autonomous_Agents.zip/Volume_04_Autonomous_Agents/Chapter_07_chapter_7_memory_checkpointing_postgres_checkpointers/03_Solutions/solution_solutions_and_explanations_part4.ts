/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

import { parentPort, workerData } from "worker_threads";
import { PostgresSaver } from "@langchain/postgres";
import { Client } from "pg";

// Worker receives shared buffer, mutex array, threadId, and db config
const { sharedBuffer, mutexBuffer, threadId, dbConfig, iterations } = workerData;

// Wrap shared buffer as Int32Array for Atomics
const counterView = new Int32Array(sharedBuffer);
const mutexView = new Int32Array(mutexBuffer);

// Connect to DB
const pgClient = new Client(dbConfig);
await pgClient.connect();
const checkpointer = new PostgresSaver(pgClient);

async function performUpdate() {
  for (let i = 0; i < iterations; i++) {
    // --- CRITICAL SECTION START ---
    
    // 1. Acquire Lock (Wait if mutex is 1, then set to 1)
    while (Atomics.compareExchange(mutexView, 0, 0, 1) !== 0) {
      // Spin wait or yield
      // In a real app, we might use Atomics.wait here, but that requires async handling
      // or a separate listener. For simplicity, we spin.
    }

    try {
      // 2. Read Shared State
      const currentCount = Atomics.load(counterView, 0);
      
      // 3. Increment
      const newCount = currentCount + 1;
      Atomics.store(counterView, 0, newCount);

      // 4. Save Checkpoint (Simulated DB write)
      // In a real scenario, we might load the full state from DB, merge, then save.
      // Here we just save the new count to verify atomicity.
      const config = { configurable: { thread_id: threadId } };
      
      // We use a dummy graph state structure for this example
      const state = { count: newCount };
      
      // Note: PostgresSaver.put handles transactions internally, 
      // but we are ensuring the application-level logic is atomic.
      await checkpointer.put(
        config,
        { v: 1, ts: new Date().toISOString(), pending: null, values: state },
        config.configurable.thread_id,
        undefined // parent checkpoint ID logic handled by LangGraph internally
      );

    } finally {
      // 5. Release Lock
      Atomics.store(mutexView, 0, 0);
      Atomics.notify(mutexView, 0, 1); // Wake up one waiting thread
    }
    // --- CRITICAL SECTION END ---
  }
}

performUpdate().then(() => {
  pgClient.end();
  if (parentPort) parentPort.postMessage("Done");
}).catch(err => console.error(err));
