/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

import { Worker } from "worker_threads";
import path from "path";
import { Client } from "pg";

// Configuration
const THREAD_ID = "concurrent_test_01";
const DB_CONFIG = { connectionString: "postgresql://user:password@localhost:5432/mydb" };

// Shared Memory
// Buffer for the counter (1 Int32)
const sharedBuffer = new SharedArrayBuffer(4); 
// Buffer for the mutex (1 Int32, 0=unlocked, 1=locked)
const mutexBuffer = new SharedArrayBuffer(4);

// Initialize counter to 0
new Int32Array(sharedBuffer)[0] = 0;
// Initialize mutex to 0 (unlocked)
new Int32Array(mutexBuffer)[0] = 0;

async function main() {
  console.log("Starting concurrent workers...");

  const worker1 = new Worker(path.join(__dirname, "worker.js"), {
    workerData: {
      sharedBuffer,
      mutexBuffer,
      threadId: THREAD_ID,
      dbConfig: DB_CONFIG,
      iterations: 100
    }
  });

  const worker2 = new Worker(path.join(__dirname, "worker.js"), {
    workerData: {
      sharedBuffer,
      mutexBuffer,
      threadId: THREAD_ID,
      dbConfig: DB_CONFIG,
      iterations: 100
    }
  });

  await Promise.all([
    new Promise(resolve => worker1.on("message", resolve)),
    new Promise(resolve => worker2.on("message", resolve))
  ]);

  console.log("Workers finished.");

  // Verification
  const finalCounter = new Int32Array(sharedBuffer)[0];
  console.log(`Final Shared Counter Value: ${finalCounter}`);

  // Check Database
  const client = new Client(DB_CONFIG);
  await client.connect();
  
  // Query the latest checkpoint for the thread
  // Note: This query depends on the exact schema of PostgresSaver
  // We are looking for the state snapshot associated with the last step
  const res = await client.query(
    `SELECT * FROM checkpoint_blobs WHERE thread_id = $1 ORDER BY created_at DESC LIMIT 1`,
    [THREAD_ID]
  );

  if (res.rows.length > 0) {
    // The state is stored in a 'value' column (often JSONB)
    // Depending on the version of LangChain, it might be 'checkpoint_blob'
    const state = res.rows[0].checkpoint_blob || res.rows[0].value; 
    console.log("Latest DB State:", state);
  }

  await client.end();
  
  if (finalCounter !== 200) {
    console.error(`FAILURE: Expected 200, got ${finalCounter}. Race condition detected!`);
  } else {
    console.log("SUCCESS: Counter is exactly 200. Mutex worked.");
  }
}

main().catch(console.error);
