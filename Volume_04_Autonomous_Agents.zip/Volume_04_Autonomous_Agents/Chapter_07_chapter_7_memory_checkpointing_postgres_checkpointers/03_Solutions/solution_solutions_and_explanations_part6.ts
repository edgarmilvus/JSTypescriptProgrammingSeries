/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part6.ts
// Description: Solutions and Explanations
// ==========================================

import { PostgresSaver } from "@langchain/postgres";
import { Client } from "pg";
import { v4 as uuidv4 } from "uuid";

/**
 * Branches the execution from a specific checkpoint.
 * @param checkpointer The initialized PostgresSaver instance.
 * @param threadId The ID of the conversation thread.
 * @param checkpointId The ID of the checkpoint to branch from.
 * @param newInput New input to inject at the start of the branch.
 */
async function branchFromCheckpoint(
  checkpointer: PostgresSaver,
  threadId: string,
  checkpointId: string,
  newInput: string
): Promise<void> {
  
  // 1. Retrieve the specific checkpoint config
  const config = {
    configurable: {
      thread_id: threadId,
      checkpoint_id: checkpointId,
    },
  };

  // 2. Get the state snapshot from the database
  // The checkpointer's get method retrieves the full state and metadata
  const snapshot = await checkpointer.get(config);
  
  if (!snapshot) {
    throw new Error(`Checkpoint ${checkpointId} not found for thread ${threadId}`);
  }

  console.log(`Branching from checkpoint ${checkpointId}...`);
  console.log("Parent State:", snapshot);

  // 3. Prepare the new state for the branch
  // We take the parent state and append the new input
  // Note: This assumes the state structure has a 'messages' array
  const currentState = snapshot.values as { messages: string[] };
  const branchedState = {
    ...currentState,
    messages: [...currentState.messages, newInput],
  };

  // 4. Create a new checkpoint for the branch
  // We generate a new UUID for the branch point
  const newCheckpointId = uuidv4();
  
  // The parent_checkpoint_id is explicitly set to the source checkpoint
  // This links the new node to the old graph structure
  const newConfig = {
    configurable: {
      thread_id: threadId,
      checkpoint_id: newCheckpointId,
      // Important: Explicitly setting parent ensures graph lineage
      parent_checkpoint_id: checkpointId, 
    },
  };

  // 5. Save the new checkpoint
  // We use 'put' to write the state at this new config point.
  // LangGraph's checkpointer handles the insertion into checkpoint_blobs.
  await checkpointer.put(
    newConfig,
    {
      v: 1,
      ts: new Date().toISOString(),
      pending: null,
      values: branchedState,
    },
    newConfig.configurable.thread_id,
    newConfig.configurable.checkpoint_id
  );

  console.log(`Created new branch checkpoint: ${newCheckpointId}`);
}

// --- Verification Script ---
async function verifyBranching() {
  const pgClient = new Client({ connectionString: "postgresql://user:password@localhost:5432/mydb" });
  await pgClient.connect();
  const checkpointer = new PostgresSaver(pgClient);

  const THREAD_ID = "time_travel_test";
  
  // Setup: Create a linear chain C1 -> C2 -> C3
  // (Assuming previous exercises or manual setup created these)
  // For this example, we assume C3 exists.
  const C3_ID = "target_checkpoint_c3"; 

  try {
    // Execute the branch function
    await branchFromCheckpoint(checkpointer, THREAD_ID, C3_ID, "This is a branched input!");

    // Verify: Query the database to see the graph structure
    console.log("\n--- Database Verification ---");
    
    // Query all checkpoints for this thread
    const result = await pgClient.query(
      `SELECT checkpoint_id, parent_checkpoint_id FROM checkpoint_blobs WHERE thread_id = $1 ORDER BY created_at`,
      [THREAD_ID]
    );

    console.log("Checkpoint Graph Structure:");
    result.rows.forEach(row => {
      console.log(`ID: ${row.checkpoint_id} | Parent: ${row.parent_checkpoint_id || 'ROOT'}`);
    });

    // Logic check:
    // We should see the original chain (C1, C2, C3)
    // And we should see C3 as the parent of the new checkpoint (NewBranchID)
    // C4 and C5 (if they existed) should still point to C3, but the "head" might be the new branch.
    
  } catch (error) {
    console.error("Verification failed:", error);
  } finally {
    await pgClient.end();
  }
}

// Run verification if this file is executed directly
// verifyBranching();
