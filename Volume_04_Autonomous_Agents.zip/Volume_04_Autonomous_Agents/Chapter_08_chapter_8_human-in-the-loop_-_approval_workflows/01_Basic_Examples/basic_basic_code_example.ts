/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

// Import necessary modules from LangGraph and LangChain
import { StateGraph, Annotation, END, START } from "@langchain/langgraph";
import { ChatOpenAI } from "@langchain/openai";
import { ToolNode } from "@langchain/langgraph/prebuilt";
import { z } from "zod";

// --- 1. DEFINE STATE & TOOLS ---

/**
 * Defines the state structure for the moderation agent.
 * @property {string} input - The user-generated content to moderate.
 * @property {string} [decision] - The agent's proposed action (e.g., "APPROVE", "FLAG").
 * @property {string} [reasoning] - The agent's internal thought process.
 * @property {string} [finalStatus] - The outcome after human approval/rejection.
 */
const StateAnnotation = Annotation.Root({
  input: Annotation<string>(),
  decision: Annotation<string>(),
  reasoning: Annotation<string>(),
  finalStatus: Annotation<string>(),
});

// Define a tool for the agent to use (simulating an external API check)
const contentAnalysisTool = z.object({
  sentiment: z.enum(["positive", "neutral", "negative"]).describe("The sentiment of the content"),
  toxicity: z.number().min(0).max(1).describe("Toxicity score from 0.0 to 1.0"),
});
const analyzeContent = async (input: { content: string }) => {
  // Simulating an async API call to a moderation service
  console.log(`[Tool] Analyzing content: "${input.content}"`);
  const isNegative = input.content.toLowerCase().includes("hate");
  return {
    sentiment: isNegative ? "negative" : "positive",
    toxicity: isNegative ? 0.95 : 0.1,
  };
};

// --- 2. DEFINE AGENT NODES ---

/**
 * Node 1: The Reasoning Node (LLM).
 * Uses an LLM to decide what action to take based on the input and tool results.
 * Note: In a real app, we would pass tool results back to the LLM. 
 * For this "Hello World" example, we simplify the logic to just deciding based on input.
 */
const reasonNode = async (state: typeof StateAnnotation.State) => {
  console.log("--- [Node] Reasoning ---");
  const llm = new ChatOpenAI({ model: "gpt-3.5-turbo" }); // Ensure OPENAI_API_KEY is set
  
  // Simple prompt to decide on moderation
  const prompt = `The user content is: "${state.input}". 
  Based on standard moderation guidelines, should we PUBLISH or FLAG this content? 
  Provide a brief reasoning.`;
  
  const response = await llm.invoke(prompt);
  
  // Parse the LLM response (simplified for demo)
  const content = response.content.toString();
  const decision = content.includes("FLAG") ? "FLAG" : "PUBLISH";
  
  return {
    decision: decision,
    reasoning: content,
  };
};

/**
 * Node 2: The Human Approval Node (Interrupt).
 * This node pauses the graph. In a real web app, this corresponds to 
 * saving the state to a database and waiting for a webhook from the frontend.
 */
const humanApprovalNode = async (state: typeof StateAnnotation.State) => {
  console.log("--- [Node] Human Approval Required ---");
  console.log(`Decision Proposed: ${state.decision}`);
  console.log(`Reasoning: ${state.reasoning}`);
  
  // In LangGraph, we use `interrupt` to pause execution.
  // When this graph is run via `graph.stream({ ... }, { ... })`, it will stop here
  // and yield an interrupt event.
  // The application logic (the Event Loop) then waits for user input.
  // For this code snippet, we simulate the pause logic by throwing a specific error
  // that a wrapper function would catch, or simply logging instructions.
  
  // NOTE: In a real LangGraph implementation with a frontend:
  // 1. We call `await graph.invoke(initialState, { ... })`.
  // 2. The graph hits this node.
  // 3. We save the state to a DB (e.g., `await saveStateToDb(state)`).
  // 4. We return the state to the frontend.
  // 5. The frontend shows a "Approve/Reject" button.
  // 6. On click, we call `await graph.invoke(null, { ... })` to resume.
  
  console.log("⏸️  GRAPH PAUSED. Waiting for Human Input...");
  console.log("In a real app, this would return the state to the client and wait.");
  
  // Simulating the pause by returning the state as is.
  // The `interrupt` mechanism in LangGraph handles the actual halting.
  return state;
};

/**
 * Node 3: The Execution Node.
 * Performs the final action (e.g., publishes the post) if approved.
 */
const executeNode = async (state: typeof StateAnnotation.State) => {
  console.log("--- [Node] Executing Final Action ---");
  const action = state.decision === "PUBLISH" ? "PUBLISHED" : "FLAGGED";
  console.log(`✅ Content successfully ${action}.`);
  return {
    finalStatus: `Completed: ${action}`,
  };
};

/**
 * Node 4: Fallback Node.
 * Handles rejection or errors.
 */
const fallbackNode = async (state: typeof StateAnnotation.State) => {
  console.log("--- [Node] Fallback / Rejection ---");
  console.log("❌ Action rejected by human or failed validation.");
  return {
    finalStatus: "Rejected by Moderator",
  };
};

// --- 3. BUILD THE GRAPH ---

/**
 * Initialize the State Graph.
 */
const workflow = new StateGraph(StateAnnotation);

// Add nodes to the graph
workflow.addNode("reasoner", reasonNode);
workflow.addNode("human_approval", humanApprovalNode);
workflow.addNode("executor", executeNode);
workflow.addNode("rejector", fallbackNode);

// Define edges (Control Flow)
// 1. Start -> Reasoner
workflow.addEdge(START, "reasoner");

// 2. Reasoner -> Human Approval
workflow.addEdge("reasoner", "human_approval");

// 3. Human Approval -> Conditional Edge (Approve or Reject)
// We define a conditional function to check the state.
// Since we are simulating, we will manually set the decision in the state
// before resuming the graph in the "Main Execution" section below.
const decideNextStep = (state: typeof StateAnnotation.State) => {
  if (state.decision === "PUBLISH") {
    return "executor";
  }
  return "rejector";
};

workflow.addConditionalEdges("human_approval", decideNextStep, {
  executor: "executor",
  rejector: "rejector",
});

// 4. End nodes -> END
workflow.addEdge("executor", END);
workflow.addEdge("rejector", END);

// Compile the graph
const app = workflow.compile();

// --- 4. MAIN EXECUTION (SIMULATION) ---

/**
 * This function simulates the SaaS Web App Event Loop.
 * It handles the async nature of waiting for user input.
 */
async function runModerationWorkflow() {
  console.log("🚀 Starting Moderation Workflow...\n");

  // Initial State: User submits a post
  const initialState = {
    input: "I absolutely hate this new feature!",
    // decision: undefined, // Initially unknown
    // reasoning: undefined,
  };

  // --- PHASE 1: Autonomous Reasoning ---
  // The graph runs until it hits the interrupt (human_approval node)
  console.log("Phase 1: Agent is reasoning...");
  
  // Note: In a real app using `interrupt`, we would use `app.stream` or `app.invoke`.
  // For this demo, we will manually step through the nodes to simulate the flow
  // because we don't have a live UI to provide input during the script execution.
  
  // 1. Run Reasoner
  const reasonerResult = await app.invoke({ ...initialState }, { 
    configurable: { 
      // We target specific nodes to simulate the flow
      // In a real scenario, we just invoke the whole graph
    } 
  });
  
  // Note: The code above assumes a linear flow for simplicity. 
  // To truly demonstrate the interrupt in a script without a UI, 
  // we simulate the steps:
  
  // Step A: Run up to the interrupt
  // (LangGraph's `interrupt` feature is best visualized in a web server context.
  // Here, we simulate the logic flow manually for clarity).
  
  // Let's manually invoke the Reasoner Node
  const stateAfterReasoning = await reasonNode(initialState);
  const combinedState = { ...initialState, ...stateAfterReasoning };
  
  console.log("\nState after Reasoning:", combinedState);
  
  // --- PHASE 2: The Interrupt (Human Decision) ---
  // In a SaaS app, the server sends `combinedState` to the frontend.
  // The user clicks "Approve".
  // The frontend sends a request back to the server: "Resume graph with decision: PUBLISH".
  
  console.log("\n--- 🛑 SIMULATING USER INPUT 🛑 ---");
  console.log("User clicked 'Approve' in the Web Dashboard.");
  
  // We update the state with the human decision
  const stateAfterApproval = {
    ...combinedState,
    decision: "PUBLISH", // User overrides or confirms agent's suggestion
  };
  
  // --- PHASE 3: Resuming Execution ---
  console.log("\n--- ▶️  RESUMING WORKFLOW ---");
  
  // We now check the conditional edge logic
  const nextNode = decideNextStep(stateAfterApproval);
  
  if (nextNode === "executor") {
    const finalState = await executeNode(stateAfterApproval);
    console.log("\nFinal State:", finalState);
  } else {
    const finalState = await fallbackNode(stateAfterApproval);
    console.log("\nFinal State:", finalState);
  }
}

// Run the simulation
runModerationWorkflow().catch(console.error);
