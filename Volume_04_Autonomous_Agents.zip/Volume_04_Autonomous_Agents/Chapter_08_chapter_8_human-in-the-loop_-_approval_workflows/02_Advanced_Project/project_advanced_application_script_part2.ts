/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script_part2.ts
// Description: Advanced Application Script
// ==========================================

import { StateGraph, END, Annotation, interrupt, NodeInterrupt } from "@langchain/langgraph";
import { z } from "zod";

// ==========================================
// 1. State Definition & Types
// ==========================================

/**
 * Defines the schema for the agent's state.
 * We use Zod for runtime validation of the state shape.
 */
const AgentStateSchema = z.object({
    draft: z.string().optional().describe("The generated email draft content."),
    status: z.enum(["DRAFTING", "PENDING_APPROVAL", "APPROVED", "REJECTED", "SENT"]).default("DRAFTING"),
    feedback: z.string().optional().describe("Human feedback if rejected."),
    attemptCount: z.number().default(0),
});

// Infer TypeScript type from Zod schema
type AgentState = z.infer<typeof AgentStateSchema>;

// ==========================================
// 2. Node Functions (The Logic)
// ==========================================

/**
 * Node: Generate Draft
 * Simulates an LLM generating a marketing email.
 * In a real app, this would call an LLM (e.g., GPT-4).
 */
async function generateDraftNode(state: AgentState): Promise<Partial<AgentState>> {
    console.log("🤖 [Node] Generating draft...");
    
    // Simulate LLM generation
    const baseDraft = "Subject: Exclusive Offer Inside!\n\nHi there, check out our new features.";
    const feedbackContext = state.feedback ? `\n\n(Incorporating feedback: ${state.feedback})` : "";
    
    // Increment attempt count
    const newCount = state.attemptCount + 1;

    return {
        draft: `${baseDraft}${feedbackContext}`,
        status: "PENDING_APPROVAL",
        attemptCount: newCount,
    };
}

/**
 * Node: Validate Approval
 * Checks the human input stored in the state.
 * Throws a NodeInterrupt if the status is not 'APPROVED',
 * effectively pausing the graph until the condition is met.
 */
async function validateApprovalNode(state: AgentState): Promise<Partial<AgentState>> {
    console.log("🔍 [Node] Validating approval status...");

    if (state.status !== "APPROVED") {
        // If rejected, we loop back to generation, but we must clear the interrupt first.
        // If pending, we interrupt again to wait for input.
        if (state.status === "REJECTED") {
             console.log("❌ Status is REJECTED. Returning to drafting phase.");
             return { status: "DRAFTING" }; // Signal to route back to generate
        }
        
        // This is the core HITL mechanism. It pauses execution.
        throw new NodeInterrupt("Waiting for human approval.");
    }

    return { status: "APPROVED" };
}

/**
 * Node: Send Email
 * Final execution step. Only runs if approved.
 */
async function sendEmailNode(state: AgentState): Promise<Partial<AgentState>> {
    console.log("✅ [Node] Sending email...", state.draft);
    // Simulate API call to email service
    return { status: "SENT" };
}

// ==========================================
// 3. Graph Definition & Compilation
// ==========================================

/**
 * Defines the workflow graph structure.
 * We use a cyclical graph to allow for iterative refinement (Regenerate -> Approve -> Send).
 */
function createWorkflowGraph() {
    // Define the state annotation
    const StateAnnotation = Annotation.Root({
        draft: Annotation<string>({ reducer: (x, y) => y ?? x, default: () => "" }),
        status: Annotation<"DRAFTING" | "PENDING_APPROVAL" | "APPROVED" | "REJECTED" | "SENT">({
            reducer: (x, y) => y ?? x,
            default: () => "DRAFTING",
        }),
        feedback: Annotation<string>({ reducer: (x, y) => y ?? x, default: () => "" }),
        attemptCount: Annotation<number>({ reducer: (x, y) => y, default: () => 0 }),
    });

    // Initialize graph
    const workflow = new StateGraph(StateAnnotation);

    // Add nodes
    workflow.addNode("generate_draft", generateDraftNode);
    workflow.addNode("validate_approval", validateApprovalNode);
    workflow.addNode("send_email", sendEmailNode);

    // Define conditional edges (Routing Logic)
    const router = (state: AgentState) => {
        if (state.status === "SENT") return END;
        
        // If we just finished validation and are approved, go to send
        if (state.status === "APPROVED") return "send_email";
        
        // If we are drafting or rejected (needs retry), go to generate
        if (state.status === "DRAFTING" || state.status === "REJECTED") return "generate_draft";
        
        // If pending, we go to validate (which will interrupt)
        return "validate_approval";
    };

    // Set entry point
    workflow.setEntryPoint("generate_draft");

    // Define edges
    workflow.addConditionalEdges("generate_draft", router);
    workflow.addConditionalEdges("validate_approval", router);
    workflow.addConditionalEdges("send_email", router);

    return workflow.compile();
}

// ==========================================
// 4. Execution & Simulation (The "Server")
// ==========================================

/**
 * Simulates the lifecycle of the workflow.
 * In a real Next.js app, `resumeWorkflow` would be an API Route (POST /api/workflow/resume).
 */
class WorkflowRunner {
    private graph: any;

    constructor() {
        this.graph = createWorkflowGraph();
    }

    /**
     * Starts or resumes the workflow.
     * @param input - Initial state or updates from human input.
     * @param previousState - The snapshot of state before interruption.
     */
    async run(input: Partial<AgentState>, previousState?: any) {
        console.log("\n--- Step: Processing Request ---");
        
        // If we have a previous state, we are resuming from an interrupt
        const config = { configurable: { thread_id: "session_123" } };
        
        try {
            // Run the graph
            // If previousState exists, we pass it as the second argument to resume
            const stream = previousState 
                ? await this.graph.invoke(input, { ...config, checkpoint: previousState })
                : await this.graph.stream(input, config);

            // Process stream events
            for await (const event of stream) {
                // In a real app, we would send these events to the frontend via WebSocket/SSE
                console.log("Stream Event:", JSON.stringify(event, null, 2));
            }
            
            console.log("Workflow finished or interrupted.");
            return stream;

        } catch (error) {
            if (error instanceof NodeInterrupt) {
                console.log("⏸️  WORKFLOW INTERRUPTED:", error.message);
                // In a real app, we would save the current checkpoint here and return 
                // a 202 Accepted response to the client.
                return { interrupted: true, message: error.message };
            }
            throw error;
        }
    }
}

// ==========================================
// 5. Simulation of User Interaction
// ==========================================

/**
 * Main execution block simulating a user session.
 */
async function main() {
    const runner = new WorkflowRunner();
    
    // 1. User initiates the workflow (e.g., clicks "Generate Email")
    console.log(">>> 1. User initiates generation.");
    await runner.run({ status: "DRAFTING" });

    // SIMULATION NOTE:
    // In a real web app, the process stops here. The server saves the graph state (checkpoint).
    // The client (browser) receives a response: "Draft ready for review".
    
    // 2. Simulate Human Review: User REJECTS the draft.
    // The client sends a POST request to the backend with feedback.
    console.log("\n>>> 2. User reviews draft and REJECTS it.");
    const rejectionInput = { 
        status: "REJECTED", 
        feedback: "Make the tone more professional." 
    };
    
    // We simulate resuming the graph with the rejection input.
    // Note: In a real implementation, we would retrieve the saved checkpoint here.
    await runner.run(rejectionInput);

    // 3. Simulate Human Review: User APPROVES the new draft.
    console.log("\n>>> 3. User reviews new draft and APPROVES it.");
    const approvalInput = { status: "APPROVED" };
    
    await runner.run(approvalInput);
}

// Execute the simulation
main().catch(console.error);
