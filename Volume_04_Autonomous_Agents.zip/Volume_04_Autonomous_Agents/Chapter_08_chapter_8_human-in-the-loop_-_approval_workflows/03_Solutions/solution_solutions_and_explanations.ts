/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

import { StateGraph, StateGraphArgs, START, END } from "@langchain/langgraph";

// 1. Define the State Interface
interface ExpenseReportState {
  reportId: string;
  amount: number;
  status: 'draft' | 'pending_approval' | 'approved' | 'rejected';
  managerNotes?: string;
}

// Define state annotation
const graphState: StateGraphArgs<ExpenseReportState>['channels'] = {
  reportId: { value: null, default: () => null },
  amount: { value: 0, default: () => 0 },
  status: { value: 'draft', default: () => 'draft' },
  managerNotes: { value: null, default: () => null },
};

// 2. Define Nodes
const generateReport = (state: ExpenseReportState): Partial<ExpenseReportState> => {
  console.log("Generating report...");
  // Simulate generation
  return { status: 'draft' };
};

const checkThreshold = (state: ExpenseReportState): Partial<ExpenseReportState> => {
  console.log(`Checking threshold for amount: ${state.amount}`);
  // This node doesn't change state, but directs flow via conditional edges
  return {};
};

const humanApproval = (state: ExpenseReportState): Partial<ExpenseReportState> => {
  console.log("Pausing for human approval...");
  // Simulate human decision (e.g., random or input-based)
  // In a real app, this node would likely be an interrupt point
  const isApproved = Math.random() > 0.2; // 80% chance of approval for simulation
  
  if (isApproved) {
    return { status: 'approved', managerNotes: 'Approved by manager.' };
  } else {
    return { status: 'rejected', managerNotes: 'Too expensive.' };
  }
};

const autoApprove = (state: ExpenseReportState): Partial<ExpenseReportState> => {
  console.log("Auto-approving low amount.");
  return { status: 'approved', managerNotes: 'Auto-approved.' };
};

const submitToAccounting = (state: ExpenseReportState): Partial<ExpenseReportState> => {
  console.log("Submitting to accounting database...");
  // Simulation of external API call
  return { status: 'submitted' }; // Or keep as approved
};

// 3. Build the Graph
const workflow = new StateGraph<ExpenseReportState>({ channels: graphState })
  .addNode("generateReport", generateReport)
  .addNode("checkThreshold", checkThreshold)
  .addNode("humanApproval", humanApproval)
  .addNode("autoApprove", autoApprove)
  .addNode("submitToAccounting", submitToAccounting)

  // Edges
  .addEdge(START, "generateReport")
  .addEdge("generateReport", "checkThreshold")
  
  // Conditional routing from checkThreshold
  .addConditionalEdges(
    "checkThreshold",
    (state: ExpenseReportState) => {
      if (state.amount > 500) {
        return "humanApproval";
      } else {
        return "autoApprove";
      }
    }
  )
  
  // Converge to submitToAccounting only if approved
  .addConditionalEdges(
    "humanApproval",
    (state: ExpenseReportState) => {
      if (state.status === "approved") {
        return "submitToAccounting";
      }
      return "end"; // Defined below
    }
  )
  .addConditionalEdges(
    "autoApprove",
    (state: ExpenseReportState) => {
      if (state.status === "approved") {
        return "submitToAccounting";
      }
      return "end";
    }
  )
  
  // Final edges
  .addEdge("submitToAccounting", END);

// Add a terminal node for rejected cases (optional, but good practice)
workflow.addNode("end", () => ({})); // No-op node
workflow.addEdge("end", END);

// Compile the graph
const app = workflow.compile();

// 4. Execution Simulation
const runSimulation = async () => {
  const highAmountState = { reportId: "R001", amount: 750, status: 'draft' };
  const lowAmountState = { reportId: "R002", amount: 200, status: 'draft' };

  console.log("--- Running High Amount Report ---");
  const resultHigh = await app.invoke(highAmountState);
  console.log("Final State:", resultHigh);

  console.log("\n--- Running Low Amount Report ---");
  const resultLow = await app.invoke(lowAmountState);
  console.log("Final State:", resultLow);
};

// runSimulation(); // Uncomment to execute
