/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

import { StateGraph, StateGraphArgs, START, END } from "@langchain/langgraph";

// 1. Define State Interface
interface ReActState {
  input: string;
  thoughts: string[];
  actions: Array<{ tool: string; args: any }>;
  observations: string[];
  pendingActionIndex: number | null;
  humanApproval: boolean | null;
}

const reactState: StateGraphArgs<ReActState>['channels'] = {
  input: { value: null, default: () => "" },
  thoughts: { value: null, default: () => [] },
  actions: { value: null, default: () => [] },
  observations: { value: null, default: () => [] },
  pendingActionIndex: { value: null, default: () => null },
  humanApproval: { value: null, default: () => null },
};

// 2. Define Nodes
const reasoning = (state: ReActState): Partial<ReActState> => {
  // Simulate LLM reasoning
  const lastObs = state.observations[state.observations.length - 1];
  const thought = `I need to perform an action based on: ${lastObs || state.input}`;
  
  // Simulate tool selection: Randomly pick a tool
  const isDangerous = Math.random() > 0.5;
  const tool = isDangerous ? "delete_file" : "read_file";
  const args = { filename: "data.txt" };

  return {
    thoughts: [...state.thoughts, thought],
    actions: [...state.actions, { tool, args }],
  };
};

const approvalCheck = (state: ReActState): Partial<ReActState> => {
  const lastActionIndex = state.actions.length - 1;
  const lastAction = state.actions[lastActionIndex];

  // Check if tool is dangerous
  const isDangerous = lastAction.tool.startsWith("delete_") || lastAction.tool.startsWith("send_");

  if (isDangerous) {
    console.log(`⚠️ DANGER DETECTED: ${lastAction.tool}. Pausing for approval.`);
    return {
      pendingActionIndex: lastActionIndex,
      humanApproval: null, // Reset approval status
    };
  } else {
    console.log(`Safe tool: ${lastAction.tool}. Auto-executing.`);
    return { pendingActionIndex: null, humanApproval: true };
  }
};

const executeTool = (state: ReActState): Partial<ReActState> => {
  if (state.humanApproval !== true) {
    // If not approved, we shouldn't be here (or we handle denial)
    return {};
  }

  const action = state.actions[state.actions.length - 1];
  console.log(`Executing tool: ${action.tool} with args:`, action.args);
  
  // Simulate result
  const result = `Result of ${action.tool}`;
  return {
    observations: [...state.observations, result],
    pendingActionIndex: null, // Clear pending
    humanApproval: null, // Reset for next loop
  };
};

// 3. Helper for Human Decision
export function handleHumanDecision(state: ReActState, decision: boolean): ReActState {
  // This function represents the external input resuming the graph
  if (state.pendingActionIndex === null) return state;

  return {
    ...state,
    humanApproval: decision,
    pendingActionIndex: null, // Clear immediately to allow graph to proceed
  };
}

// 4. Build Graph
const workflow = new StateGraph<ReActState>({ channels: reactState })
  .addNode("reasoning", reasoning)
  .addNode("approvalCheck", approvalCheck)
  .addNode("executeTool", executeTool)

  .addEdge(START, "reasoning")
  .addEdge("reasoning", "approvalCheck")
  
  // Conditional edge: If pending approval, interrupt (stop). 
  // In a real graph, we would use .addNode("interrupt", interruptFn) and an interrupt edge.
  // Here, we simulate the logic flow.
  .addConditionalEdges(
    "approvalCheck",
    (state: ReActState) => {
      if (state.pendingActionIndex !== null) {
        return "interrupt_node"; // Virtual node representing pause
      }
      return "executeTool";
    }
  )
  
  // Loop back to reasoning after execution
  .addEdge("executeTool", "reasoning");

// Add a virtual interrupt node for visualization/logic
workflow.addNode("interrupt_node", (state) => {
  console.log("Graph Interrupted. Waiting for human input...");
  return state;
});
// Note: In a real implementation, the graph stops here. 
// Resuming requires calling `app.invoke(null, { ...config, resume: true })` or similar API.

// Compile
const app = workflow.compile();

// Simulation
const runSimulation = async () => {
  const initialState: ReActState = {
    input: "Delete the sensitive file.",
    thoughts: [],
    actions: [],
    observations: [],
    pendingActionIndex: null,
    humanApproval: null,
  };

  // Run 1: Generate action
  let currentState = await app.invoke(initialState);
  console.log("State after reasoning/check:", currentState);

  // Run 2: Simulate Human Approval (Resume)
  if (currentState.pendingActionIndex !== null) {
    console.log("--- Human Approving ---");
    const resumedState = handleHumanDecision(currentState, true);
    // In a real graph, we would pass this state back to the graph execution context.
    // For this simulation, we manually step the next node.
    const finalState = await app.invoke(resumedState);
    console.log("Final State:", finalState);
  }
};

// runSimulation();
