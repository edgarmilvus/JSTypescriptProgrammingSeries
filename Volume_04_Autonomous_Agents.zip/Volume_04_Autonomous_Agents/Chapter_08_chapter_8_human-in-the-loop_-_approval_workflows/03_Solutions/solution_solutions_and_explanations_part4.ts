/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

import { StateGraph, StateGraphArgs, START, END } from "@langchain/langgraph";

// 1. Define State Interface
interface BlogPostState {
  draft: string;
  editorFeedback: string;
  revisionCount: number;
  isApproved: boolean;
}

const blogState: StateGraphArgs<BlogPostState>['channels'] = {
  draft: { value: null, default: () => "" },
  editorFeedback: { value: null, default: () => "" },
  revisionCount: { value: 0, default: () => 0 },
  isApproved: { value: false, default: () => false },
};

// 2. Define Nodes
const writeDraft = (state: BlogPostState): Partial<BlogPostState> => {
  console.log("Writing initial draft...");
  return { draft: "This is the initial draft content." };
};

const editorReview = (state: BlogPostState): Partial<BlogPostState> => {
  console.log(`Editor reviewing draft (Revision ${state.revisionCount})...`);
  
  // Simulate editor decision
  // Approve only after 3 revisions
  const approved = state.revisionCount >= 3;
  
  const feedback = approved 
    ? "Looks great!" 
    : `Needs improvement. Make it more concise. (Attempt ${state.revisionCount + 1})`;

  return {
    editorFeedback: feedback,
    revisionCount: state.revisionCount + 1,
    isApproved: approved,
  };
};

const incorporateFeedback = (state: BlogPostState): Partial<BlogPostState> => {
  console.log("Agent incorporating feedback...");
  // Simulate rewriting
  return { draft: `${state.draft} [Revised based on: ${state.editorFeedback}]` };
};

const publish = (state: BlogPostState): Partial<BlogPostState> => {
  console.log("Publishing blog post!");
  return { draft: `[PUBLISHED] ${state.draft}` };
};

// 3. Build Graph
const workflow = new StateGraph<BlogPostState>({ channels: blogState })
  .addNode("writeDraft", writeDraft)
  .addNode("editorReview", editorReview)
  .addNode("incorporateFeedback", incorporateFeedback)
  .addNode("publish", publish)

  .addEdge(START, "writeDraft")
  .addEdge("writeDraft", "editorReview")
  
  // Conditional Edge: Check Approval
  .addConditionalEdges(
    "editorReview",
    (state: BlogPostState) => {
      if (state.isApproved) {
        return "publish";
      } else {
        return "incorporateFeedback";
      }
    }
  )
  
  // Loop back to editor after incorporating feedback
  .addEdge("incorporateFeedback", "editorReview")
  
  .addEdge("publish", END);

// Compile
const app = workflow.compile();

// Simulation
const runSimulation = async () => {
  // Start with empty state
  const result = await app.invoke({
    draft: "",
    editorFeedback: "",
    revisionCount: 0,
    isApproved: false,
  });
  console.log("Final Result:", result);
};

// runSimulation();
