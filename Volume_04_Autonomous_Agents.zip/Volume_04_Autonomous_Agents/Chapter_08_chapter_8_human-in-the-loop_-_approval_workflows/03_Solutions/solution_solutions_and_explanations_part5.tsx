/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState } from 'react';

// 1. Define the Interface
interface ApprovalTask {
  taskId: string;
  title: string;
  description: string;
  payload: Record<string, any>;
  onApprove: (taskId: string, notes?: string) => void;
  onReject: (taskId: string, reason: string) => void;
}

// 2. Implement the Component
export const ApprovalCard: React.FC<ApprovalTask> = ({
  taskId,
  title,
  description,
  payload,
  onApprove,
  onReject,
}) => {
  const [notes, setNotes] = useState('');
  const [rejectReason, setRejectReason] = useState('');

  const handleApprove = () => {
    onApprove(taskId, notes);
  };

  const handleReject = () => {
    if (!rejectReason.trim()) {
      alert("Rejection reason is required.");
      return;
    }
    onReject(taskId, rejectReason);
  };

  return (
    <div style={{ border: '1px solid #ccc', padding: '16px', borderRadius: '8px', maxWidth: '500px', margin: '20px auto' }}>
      <h3>{title}</h3>
      <p>{description}</p>
      
      {/* JSON Viewer */}
      <div style={{ background: '#f5f5f5', padding: '10px', marginBottom: '15px', overflow: 'auto', maxHeight: '200px' }}>
        <pre>{JSON.stringify(payload, null, 2)}</pre>
      </div>

      {/* Notes Input (Optional for Approve, Required for Reject) */}
      <textarea
        placeholder="Add notes or feedback..."
        value={notes}
        onChange={(e) => setNotes(e.target.value)}
        style={{ width: '100%', marginBottom: '10px', padding: '8px' }}
      />

      {/* Rejection Reason Input (Shown only if needed or separate) 
          For this UI, we use the same textarea for simplicity, 
          but in a real app, distinct fields might be used. 
          Here we enforce validation on Reject. */}
      
      <div style={{ display: 'flex', gap: '10px', justifyContent: 'flex-end' }}>
        <button 
          onClick={handleReject} 
          style={{ backgroundColor: '#ff4d4f', color: 'white', border: 'none', padding: '8px 16px', borderRadius: '4px' }}
        >
          Reject
        </button>
        <button 
          onClick={handleApprove} 
          style={{ backgroundColor: '#1890ff', color: 'white', border: 'none', padding: '8px 16px', borderRadius: '4px' }}
        >
          Approve
        </button>
      </div>
    </div>
  );
};

// 3. Usage Example (Parent Component Logic)
/*
const ParentComponent = () => {
  // Assume this data comes from a backend subscription (e.g., WebSocket)
  const task: ApprovalTask = {
    taskId: "task_123",
    title: "Expense Approval",
    description: "Review the generated expense report.",
    payload: { amount: 750, category: "Travel" },
    onApprove: async (id, notes) => {
      console.log(`Approving ${id} with notes: ${notes}`);
      // Integration Context:
      // Call backend API to resume the graph
      await fetch('/api/langgraph/resume', {
        method: 'POST',
        body: JSON.stringify({ 
            thread_id: id, 
            decision: 'approve', 
            notes 
        })
      });
    },
    onReject: async (id, reason) => {
      console.log(`Rejecting ${id} with reason: ${reason}`);
      await fetch('/api/langgraph/resume', {
        method: 'POST',
        body: JSON.stringify({ 
            thread_id: id, 
            decision: 'reject', 
            reason 
        })
      });
    }
  };

  return <ApprovalCard {...task} />;
};
*/
