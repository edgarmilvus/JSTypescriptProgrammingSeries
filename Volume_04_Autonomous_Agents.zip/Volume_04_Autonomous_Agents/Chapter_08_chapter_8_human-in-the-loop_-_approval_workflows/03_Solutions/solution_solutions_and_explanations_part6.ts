/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part6.ts
// Description: Solutions and Explanations
// ==========================================

import { StateGraph, StateGraphArgs, START, END } from "@langchain/langgraph";

// 1. Define State Interface
interface SupportState {
  query: string;
  generatedAnswer: string;
  confidenceScore: number;
  userFeedback: 'yes' | 'no' | null;
  escalated: boolean;
}

const supportState: StateGraphArgs<SupportState>['channels'] = {
  query: { value: null, default: () => "" },
  generatedAnswer: { value: null, default: () => "" },
  confidenceScore: { value: 0, default: () => 0 },
  userFeedback: { value: null, default: () => null },
  escalated: { value: false, default: () => false },
};

// 2. Define Nodes
const generateAnswer = (state: SupportState): Partial<SupportState> => {
  console.log("Generating answer from knowledge base...");
  // Simulate generation and confidence
  // Random confidence between 0.3 and 0.9
  const confidence = Math.random() * 0.6 + 0.3;
  return {
    generatedAnswer: "Here is the answer regarding your account.",
    confidenceScore: confidence
  };
};

const evaluateConfidence = (state: SupportState): Partial<SupportState> => {
  console.log(`Evaluating confidence: ${state.confidenceScore}`);
  return {};
};

const requestUserFeedback = (state: SupportState): Partial<SupportState> => {
  console.log("Low confidence detected. Interrupting to ask user...");
  // In a real app, this pauses execution. 
  // We simulate the state waiting for input.
  return { userFeedback: null }; 
};

const escalateToHuman = (state: SupportState): Partial<SupportState> => {
  console.log("User unhappy. Escalating to human agent.");
  return { escalated: true };
};

const logSuccess = (state: SupportState): Partial<SupportState> => {
  console.log("User satisfied. Logging success.");
  return { escalated: false };
};

// 3. Interactive Simulation Helper
export function simulateUserInteraction(state: SupportState, feedback: 'yes' | 'no'): SupportState {
  console.log(`User input received: ${feedback}`);
  return {
    ...state,
    userFeedback: feedback
  };
}

// 4. Build Graph
const workflow = new StateGraph<SupportState>({ channels: supportState })
  .addNode("generateAnswer", generateAnswer)
  .addNode("evaluateConfidence", evaluateConfidence)
  .addNode("requestUserFeedback", requestUserFeedback)
  .addNode("escalateToHuman", escalateToHuman)
  .addNode("logSuccess", logSuccess)

  .addEdge(START, "generateAnswer")
  .addEdge("generateAnswer", "evaluateConfidence")

  // Conditional: Check confidence
  .addConditionalEdges(
    "evaluateConfidence",
    (state: SupportState) => {
      if (state.confidenceScore < 0.7) {
        return "requestUserFeedback";
      }
      return "logSuccess"; // High confidence bypasses user check
    }
  )

  // Conditional: Check User Feedback
  .addConditionalEdges(
    "requestUserFeedback",
    (state: SupportState) => {
      if (state.userFeedback === "yes") {
        return "logSuccess";
      } else if (state.userFeedback === "no") {
        return "escalateToHuman";
      }
      return "requestUserFeedback"; // Loop if null (waiting)
    }
  )
  
  .addEdge("logSuccess", END)
  .addEdge("escalateToHuman", END);

const app = workflow.compile();

// Simulation
const runSimulation = async () => {
  // 1. Initial run
  let state: SupportState = await app.invoke({
    query: "Help me with my account.",
    generatedAnswer: "",
    confidenceScore: 0,
    userFeedback: null,
    escalated: false,
  });

  console.log("State after generation/eval:", state);

  // 2. If low confidence, simulate user interaction
  if (state.confidenceScore < 0.7) {
    // Simulate User saying "No"
    state = simulateUserInteraction(state, "no");
    
    // Resume graph (in this simulation, we invoke again)
    state = await app.invoke(state);
  }
  
  console.log("Final State:", state);
};

// runSimulation();
