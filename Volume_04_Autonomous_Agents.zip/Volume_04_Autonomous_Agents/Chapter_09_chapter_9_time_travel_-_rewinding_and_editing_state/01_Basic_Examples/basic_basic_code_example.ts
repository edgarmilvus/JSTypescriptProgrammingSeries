/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

// Import necessary types and classes from LangGraph
import {
  StateGraph,
  Annotation,
  MemorySaver,
  BaseCheckpointSaver,
} from "@langchain/langgraph";

// Define the state interface for strict type discipline
interface AgentState {
  input: string;
  plan?: string;
  executionResult?: string;
  messages: string[];
}

// 1. Define the State Annotation
// We use `Annotation.Root` to define the structure of our state.
// This ensures that every node receives a typed object.
const StateAnnotation = Annotation.Root({
  input: Annotation<string>({
    reducer: (state, update) => update, // Simply overwrite
    default: () => "",
  }),
  plan: Annotation<string | undefined>({
    reducer: (state, update) => update,
    default: () => undefined,
  }),
  executionResult: Annotation<string | undefined>({
    reducer: (state, update) => update,
    default: () => undefined,
  }),
  messages: Annotation<string[]>({
    reducer: (state, update) => [...state, ...update], // Append messages
    default: () => [],
  }),
});

// 2. Define the Nodes (Agent Logic)
// In a real app, these would call LLMs or APIs. Here, we simulate logic.

/**
 * Simulates a planning step. It takes the input and generates a plan.
 * @param state The current state of the graph.
 * @returns Partial updates to the state.
 */
const planNode = async (state: typeof StateAnnotation.State) => {
  console.log("--- Executing Plan Node ---");
  const plan = `Plan: Analyze input "${state.input}" and prepare a response.`;
  return {
    plan,
    messages: [`[System] Plan generated: ${plan}`],
  };
};

/**
 * Simulates an execution step. It uses the plan to generate a result.
 * @param state The current state of the graph.
 * @returns Partial updates to the state.
 */
const executeNode = async (state: typeof StateAnnotation.State) => {
  console.log("--- Executing Execution Node ---");
  // Simulate a potential error or hallucination here
  const result = `Result: Based on plan "${state.plan}", here is the output.`;
  return {
    executionResult: result,
    messages: [`[System] Execution finished: ${result}`],
  };
};

// 3. Build the Graph
// We instantiate the graph, add nodes, and define the edges.
const workflow = new StateGraph(StateAnnotation)
  .addNode("plan_node", planNode)
  .addNode("execute_node", executeNode)
  .addEdge("__start__", "plan_node") // Connect start to the first node
  .addEdge("plan_node", "execute_node") // Connect plan to execute
  .addEdge("execute_node", "__end__"); // Connect execute to end

// 4. Compile with a Checkpointer
// CRITICAL: We use MemorySaver for this example. In production (Vercel/Edge),
// this would be a database connection (e.g., Redis, Postgres).
const checkpointer: BaseCheckpointSaver = new MemorySaver();
const app = workflow.compile({ checkpointer });

// 5. The "Time Travel" Logic
async function runTimeTravelDemo() {
  // CONFIG: We need a thread_id to identify the session (like a conversation ID)
  const config = { configurable: { thread_id: "demo-thread-1" } };

  console.log("=== STEP 1: INITIAL RUN ===");
  // Run the graph from the beginning
  const initialResult = await app.invoke(
    { input: "Hello World" },
    config
  );
  console.log("Initial Result:", initialResult);
  // Output: { input: "Hello World", plan: "...", executionResult: "...", messages: [...] }

  console.log("\n=== STEP 2: REWIND (Time Travel) ===");
  // We want to go back to the state *after* the plan_node but *before* the execute_node.
  // `getPreviousState` retrieves the checkpoint immediately preceding the current one.
  const previousState = await app.getPreviousState(config);
  
  if (previousState) {
    console.log("Rewound to previous state:", previousState);
    // Note: previousState will have the 'plan' but NOT the 'executionResult'
  }

  console.log("\n=== STEP 3: EDIT STATE ===");
  // Let's modify the state to correct a hypothetical error.
  // We create a new state object based on the previous one.
  const editedState = {
    ...previousState,
    plan: "Plan: [EDITED] Analyze input 'Hello World' and provide a CORRECTED response.",
    messages: [
      ...previousState.messages,
      "[User] I corrected the plan manually via Time Travel.",
    ],
  };

  // We update the graph's state with our edited version.
  // `update` allows us to patch the state at the current checkpoint.
  await app.update(editedState, config);
  console.log("State updated with corrected plan.");

  console.log("\n=== STEP 4: RESUME (Replay) ===");
  // We resume the graph. Because we updated the state at the previous checkpoint,
  // the graph will now execute the 'execute_node' using the *edited* plan.
  // We pass `null` as the input because we are resuming from existing state.
  const finalResult = await app.invoke(null, config);
  
  console.log("Final Result (Corrected):", finalResult);
  console.log("Check the executionResult - it should reference the corrected plan.");
}

// Execute the demo
runTimeTravelDemo().catch(console.error);
