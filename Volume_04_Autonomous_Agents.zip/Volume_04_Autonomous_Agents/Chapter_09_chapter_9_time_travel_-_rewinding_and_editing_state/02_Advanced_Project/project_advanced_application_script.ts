/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

/**
 * Advanced Application: Time Travel & State Hydration in LangGraph.js
 * 
 * Scenario: A SaaS Customer Insights Dashboard.
 * Problem: The agent fails during data analysis due to corrupted data.
 * Solution: We use a Checkpointer to rewind, edit the state, and resume.
 * 
 * Dependencies: @langchain/langgraph, @langchain/core
 */

import { StateGraph, END, Annotation, BaseCheckpointSaver, MemorySaver } from "@langchain/langgraph";
import { BaseMessage, HumanMessage } from "@langchain/core/messages";

// ==========================================
// 1. STATE DEFINITION
// ==========================================

/**
 * Defines the structure of our agent's state.
 * We track the conversation history, raw data, analysis results, and status.
 */
const GraphState = Annotation.Root({
  // The conversation history (list of messages)
  messages: Annotation<BaseMessage[]>({
    reducer: (curr, update) => curr.concat(update),
    default: () => [],
  }),
  // The raw data fetched from the "API"
  rawData: Annotation<string>({
    reducer: (curr, update) => update ?? curr, // Simple overwrite
    default: () => "",
  }),
  // The analyzed result
  analysis: Annotation<string>({
    reducer: (curr, update) => update ?? curr,
    default: () => "",
  }),
  // Status flag to track workflow progress
  status: Annotation<string>({
    reducer: (curr, update) => update ?? curr,
    default: () => "idle",
  }),
});

// ==========================================
// 2. NODE DEFINITIONS
// ==========================================

/**
 * Node 1: Data Fetcher
 * Simulates fetching raw customer data from an external API.
 */
const fetchData = async (state: typeof GraphState.State): Promise<Partial<typeof GraphState.State>> => {
  console.log("🔄 [Node] Fetching Data...");
  // Simulate API delay
  await new Promise(resolve => setTimeout(resolve, 100));
  
  return {
    rawData: "Customer ID: 12345; Spend: $5000; Region: NA",
    status: "data_fetched",
    messages: [new HumanMessage("Raw data retrieved successfully.")],
  };
};

/**
 * Node 2: Analyzer
 * Simulates processing the data. 
 * CRITICAL: This node is designed to fail if 'rawData' is corrupted or empty.
 */
const analyzeData = async (state: typeof GraphState.State): Promise<Partial<typeof GraphState.State>> => {
  console.log("🧠 [Node] Analyzing Data...");
  
  // SIMULATED ERROR TRIGGER
  // If the rawData contains "CORRUPTED", we throw an error.
  // In the main flow, we will inject this string during state editing.
  if (state.rawData.includes("CORRUPTED")) {
    console.error("❌ [Node] Error: Corrupted data detected! Analysis aborted.");
    throw new Error("Analysis failed due to data corruption.");
  }

  // Simulate processing logic
  await new Promise(resolve => setTimeout(resolve, 100));
  
  // Calculate a simple metric
  const spend = parseInt(state.rawData.match(/\$(\d+)/)?.[1] || "0");
  const tier = spend > 4000 ? "Platinum" : "Gold";

  return {
    analysis: `Analysis Complete. Customer Tier: ${tier}.`,
    status: "analyzed",
    messages: [new HumanMessage("Analysis completed without errors.")],
  };
};

/**
 * Node 3: Reporter
 * Generates the final output for the dashboard.
 */
const generateReport = async (state: typeof GraphState.State): Promise<Partial<typeof GraphState.State>> => {
  console.log("📄 [Node] Generating Report...");
  
  const report = `
    === CUSTOMER INSIGHT REPORT ===
    Status: ${state.status}
    Analysis: ${state.analysis}
    ===============================
  `;

  return {
    messages: [new HumanMessage(report)],
    status: "completed",
  };
};

// ==========================================
// 3. GRAPH COMPILATION
// ==========================================

/**
 * Builds the LangGraph workflow.
 * We use a MemorySaver to simulate a persistent database (Redis/Postgres).
 */
const createWorkflow = (checkpointer: BaseCheckpointSaver) => {
  const workflow = new StateGraph(GraphState)
    .addNode("fetch_data", fetchData)
    .addNode("analyze_data", analyzeData)
    .addNode("generate_report", generateReport)
    .addEdge("__start__", "fetch_data")
    .addEdge("fetch_data", "analyze_data")
    .addEdge("analyze_data", "generate_report")
    .addEdge("generate_report", END);

  // Compile the graph with the checkpointer
  return workflow.compile({ checkpointer });
};

// ==========================================
// 4. MAIN EXECUTION FLOW (TIME TRAVEL DEMO)
// ==========================================

/**
 * Main function to demonstrate Time Travel capabilities.
 */
async function runTimeTravelDemo() {
  console.log("🚀 Starting Time Travel Demo...\n");

  // 1. Initialize Checkpointer (Simulates Redis/SQL)
  const checkpointer = new MemorySaver();
  const graph = createWorkflow(checkpointer);

  // Configuration for the agent (Thread ID is crucial for persistence)
  const config = { configurable: { thread_id: "customer_insights_001" } };

  // ---------------------------------------------------------
  // SCENARIO A: Initial Run (Simulating Failure)
  // ---------------------------------------------------------
  console.log("--- SCENARIO A: Initial Run (Expecting Failure) ---");
  
  try {
    // We start the graph. It will fetch data and then fail at analysis.
    // Note: We are NOT injecting "CORRUPTED" yet, so this run should actually succeed 
    // initially. To demonstrate the "Rewind and Edit" capability, we need to 
    // simulate a state where the data *becomes* corrupted or we want to change logic.
    
    // Let's artificially force a failure for the demo logic:
    // We will execute the first node, then manually inject bad state into the checkpointer
    // to simulate a scenario where the data was bad from the start.
    
    // Execute just the first step
    let currentState = await graph.invoke(
      { messages: [new HumanMessage("Start analysis")] },
      config
    );

    // Simulate a database update that corrupted the data (e.g., a bad write)
    // In a real app, this might happen due to a race condition or external data source issue.
    console.log("⚠️  Simulating Data Corruption in Database...");
    
    // We manually update the checkpoint in the memory saver to simulate 
    // a bad state being saved.
    const checkpoints = await checkpointer.list(config);
    const lastCheckpoint = checkpoints.next[0];
    
    if (lastCheckpoint) {
        // Retrieve the full state
        const fullState = await checkpointer.get(lastCheckpoint.config);
        
        // Mutate the state to inject corruption
        if (fullState && fullState.pendingWrites) {
            // We are modifying the saved state to include "CORRUPTED"
            // This simulates a failure that happened *after* the node executed
            // but before the next node started.
            fullState.pendingWrites.push({
                task: "corrupt_data",
                write: { rawData: "CORRUPTED_DATA_STRING" }
            });
            
            // In a real DB, we would update the row. Here we rely on MemorySaver's internal map.
            // However, MemorySaver doesn't support direct update of existing checkpoint easily 
            // without re-writing. Let's simulate this by running the graph again with the bad state.
        }
    }

    // Now, let's try to run the full flow with the corrupted data injected.
    // We will invoke the graph starting from the beginning, but with bad data.
    // (For the sake of the script, we will simply invoke the graph with bad initial state)
    console.log("\n--- Attempting Full Run with Bad Data ---");
    await graph.invoke(
      { 
        messages: [new HumanMessage("Start analysis")],
        rawData: "CORRUPTED_CUSTOMER_DATA" // Injecting bad data directly
      }, 
      config
    );
  } catch (error: any) {
    console.log(`\n🛑 Workflow halted: ${error.message}`);
    console.log("State is persisted. Ready for Time Travel intervention.\n");
  }

  // ---------------------------------------------------------
  // SCENARIO B: Time Travel - Inspection & Rewind
  // ---------------------------------------------------------
  console.log("--- SCENARIO B: Time Travel - Inspection ---");

  // 1. List all available checkpoints (History)
  const checkpoints = await checkpointer.list(config);
  console.log(`Found ${checkpoints.length} checkpoint(s).`);

  // 2. Retrieve the specific state before the failure
  // We look for the last successful checkpoint
  const history = [];
  for await (const checkpoint of checkpoints) {
    history.push(checkpoint);
  }
  
  // Get the state of the most recent checkpoint
  const targetCheckpoint = history[history.length - 1];
  const historicalState = await checkpointer.get(targetCheckpoint.config);

  console.log("\n🔍 Inspecting Historical State:");
  console.log(`   - Status: ${historicalState?.state?.status}`);
  console.log(`   - Raw Data: ${historicalState?.state?.rawData}`);

  // ---------------------------------------------------------
  // SCENARIO C: State Editing & Resume
  // ---------------------------------------------------------
  console.log("\n--- SCENARIO C: State Editing & Resume ---");

  // 1. Edit the State
  // We want to fix the corrupted data and provide the correct value.
  const correctedState = {
    ...historicalState?.state,
    rawData: "Customer ID: 12345; Spend: $5000; Region: NA", // Fixed data
    status: "data_fetched", // Reset status to allow re-processing
    messages: [...historicalState?.state.messages, new HumanMessage("Data corrected via Time Travel.")],
  };

  console.log("🛠️  Editing State: Injecting clean data...");

  // 2. Hydrate the Graph
  // We use `graph.updateState` to inject our corrected state into the specific checkpoint.
  // This effectively "rewinds" time and changes the future.
  await graph.updateState(
    config,
    correctedState,
    // We use the ID of the checkpoint we are editing
    { asNode: "fetch_data" } // We treat this update as coming from the 'fetch_data' node
  );

  console.log("✅ State updated. Resuming workflow...");

  // 3. Resume Execution
  // The graph will pick up from the last checkpoint (which we just edited).
  // It will see the 'status' is 'data_fetched' and proceed to 'analyze_data'.
  const finalResult = await graph.invoke(null, config);

  console.log("\n🎉 Final Result after Time Travel:");
  console.log(finalResult.analysis);
  console.log(finalResult.messages[finalResult.messages.length - 1].content);
}

// Execute the demo
runTimeTravelDemo().catch(console.error);
