/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

import { MemorySaver } from "@langchain/langgraph";
import { z } from "zod";

// 1. Define the GraphState interface with strictNullChecks in mind
interface GraphState {
  messages: string[];
  metadata: {
    timestamp: number;
    requestId: string;
  };
}

// 2. Define the Zod schema for runtime validation
const GraphStateSchema = z.object({
  messages: z.array(z.string()),
  metadata: z.object({
    timestamp: z.number(),
    requestId: z.string(),
  }),
});

export class StateHistoryManager {
  private checkpointer: MemorySaver;

  constructor() {
    // Initialize the MemorySaver
    this.checkpointer = new MemorySaver();
  }

  // Helper to get the checkpointer (useful for saving new states elsewhere)
  getCheckpointer() {
    return this.checkpointer;
  }

  /**
   * Rewinds to a specific checkpoint and returns the validated state.
   * @param checkpointId - The ID of the checkpoint to retrieve.
   * @returns The validated GraphState or null if not found.
   */
  async rewind(checkpointId: string): Promise<GraphState | null> {
    // In a real app, we would need a threadId. For this isolated exercise,
    // we assume a generic thread or we query all. 
    // However, MemorySaver.get() requires a config object.
    // We will simulate a lookup. In a real scenario, we'd iterate or know the threadId.
    
    // Note: MemorySaver does not have a direct "get by ID only" method without thread context.
    // We will assume a generic thread_id "default" for the sake of the exercise structure,
    // or we would need to list all checkpoints.
    
    const config = {
      configurable: {
        thread_id: "default", // Assuming a default thread for this exercise
        checkpoint_id: checkpointId,
      },
    };

    // Retrieve the raw state from the checkpointer
    const rawState = await this.checkpointer.get(config);

    if (!rawState) {
      return null;
    }

    // 3. Validate the state using Zod
    // The checkpointer returns the state object (often nested under `[KEY]` or just the object)
    // We assume the state is the direct value here for simplicity.
    const parsed = GraphStateSchema.safeParse(rawState);

    if (!parsed.success) {
      // 4. Throw a descriptive error if validation fails
      throw new Error(
        `Validation failed for checkpoint ${checkpointId}: ${JSON.stringify(
          parsed.error.errors
        )}`
      );
    }

    return parsed.data;
  }
}
