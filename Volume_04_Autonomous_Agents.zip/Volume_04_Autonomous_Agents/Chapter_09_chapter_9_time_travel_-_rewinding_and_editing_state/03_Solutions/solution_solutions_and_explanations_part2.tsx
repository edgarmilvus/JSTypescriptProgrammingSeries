/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState } from 'react';

// Define types for the history items
type HistoryItem = {
  id: string;
  timestamp: number;
  state: unknown;
};

interface TimeTravelControlsProps {
  history: HistoryItem[];
  onRewind: (checkpointId: string) => void;
}

// Type guard to safely extract messages from unknown state
const getMessagesFromState = (state: unknown): string[] => {
  if (
    state &&
    typeof state === 'object' &&
    'messages' in state &&
    Array.isArray(state.messages) &&
    state.messages.every((item) => typeof item === 'string')
  ) {
    return state.messages;
  }
  return [];
};

export const TimeTravelControls: React.FC<TimeTravelControlsProps> = ({
  history,
  onRewind,
}) => {
  // State to track the currently selected index from the slider
  const [selectedIndex, setSelectedIndex] = useState<number>(0);

  // Ensure history is sorted by timestamp if not guaranteed
  const sortedHistory = [...history].sort((a, b) => a.timestamp - b.timestamp);

  const handleSliderChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSelectedIndex(Number(e.target.value));
  };

  const handleRevert = () => {
    if (sortedHistory[selectedIndex]) {
      onRewind(sortedHistory[selectedIndex].id);
    }
  };

  const currentItem = sortedHistory[selectedIndex];

  return (
    <div style={{ padding: '20px', border: '1px solid #ccc' }}>
      <h3>Time Travel Debugger</h3>
      
      {/* Slider UI */}
      {sortedHistory.length > 0 ? (
        <>
          <input
            type="range"
            min="0"
            max={sortedHistory.length - 1}
            value={selectedIndex}
            onChange={handleSliderChange}
            style={{ width: '100%' }}
          />
          <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.8em', color: '#666' }}>
            <span>Start</span>
            <span>End</span>
          </div>
        </>
      ) : (
        <p>No history available.</p>
      )}

      {/* Visualization of Selected Step */}
      {currentItem && (
        <div style={{ marginTop: '20px', padding: '10px', backgroundColor: '#f5f5f5' }}>
          <h4>Step {selectedIndex + 1}</h4>
          <p><strong>ID:</strong> {currentItem.id}</p>
          <p><strong>Time:</strong> {new Date(currentItem.timestamp).toLocaleTimeString()}</p>
          
          <div>
            <strong>Messages:</strong>
            <ul>
              {getMessagesFromState(currentItem.state).map((msg, idx) => (
                <li key={idx}>{msg}</li>
              ))}
            </ul>
          </div>

          <button onClick={handleRevert} style={{ marginTop: '10px' }}>
            Revert to this Step
          </button>
        </div>
      )}
    </div>
  );
};
