/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

import { StateGraph, END, MemorySaver } from "@langchain/langgraph";

// Reuse GraphState interface from Exercise 1
interface GraphState {
  messages: string[];
  metadata: {
    timestamp: number;
    requestId: string;
  };
}

// 1. State Modification Function
export function modifyState(state: GraphState, newMessage: string): GraphState {
  return {
    ...state,
    messages: [...state.messages, newMessage],
    metadata: {
      ...state.metadata,
      timestamp: Date.now(), // Update timestamp for the fork
    },
  };
}

// 2. Forking Execution Function
export async function editAndFork(
  historyManager: any, // Assuming StateHistoryManager from Ex 1
  checkpointId: string,
  modification: string,
  graphDefinition: StateGraph<any> // The compiled graph or definition
) {
  // Retrieve the historical state
  const historicalState = await historyManager.rewind(checkpointId);
  
  if (!historicalState) {
    throw new Error(`Checkpoint ${checkpointId} not found.`);
  }

  // Create the modified state (the new branch)
  const modifiedState = modifyState(historicalState, modification);

  // Prepare the config to target the specific checkpoint for the update
  const config = {
    configurable: {
      thread_id: "default", // Must match the thread where the checkpoint exists
      checkpoint_id: checkpointId,
    },
  };

  // 3. Update the graph state to create the fork
  // Note: In LangGraph, updateState creates a new checkpoint branching off the specified one.
  // We need the graph instance to call updateState.
  
  // Assuming we have access to the graph instance (e.g., compiled graph)
  // graphDefinition.updateState(config, modifiedState, { asNode: "some_node" });
  
  // For the purpose of this code snippet, we simulate the logic:
  // The 'asNode' parameter must be a string matching a node name in the graph.
  const validNodeName = "rewrite_node"; 
  
  // Type checking for asNode (simulated as TypeScript validation)
  if (typeof validNodeName !== "string") {
    throw new Error("asNode must be a string identifier of a graph node.");
  }

  // Execute the update (mocking the graph call since we don't have a full graph setup here)
  // await graphDefinition.updateState(config, modifiedState, { asNode: validNodeName });
  
  console.log(`Forked state from ${checkpointId} with modification: ${modification}`);
  return modifiedState;
}
