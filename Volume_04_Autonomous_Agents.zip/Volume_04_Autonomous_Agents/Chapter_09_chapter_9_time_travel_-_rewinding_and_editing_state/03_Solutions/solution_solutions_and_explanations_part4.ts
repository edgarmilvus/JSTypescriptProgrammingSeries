/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

import { z } from "zod";
import { GraphState } from "./exercise1"; // Assuming shared interface

// 1. Zod Schema for WeatherReport
const WeatherReportSchema = z.object({
  location: z.string(),
  temperature: z.number(),
  condition: z.enum(["sunny", "rainy", "cloudy"]),
});

type WeatherReport = z.infer<typeof WeatherReportSchema>;

// 2. Validation Node Function
export async function validationNode(state: GraphState): Promise<GraphState & { isValid: boolean; error?: any }> {
  const lastMessage = state.messages[state.messages.length - 1];

  try {
    // Attempt to parse the last message as JSON
    const parsedData = JSON.parse(lastMessage);

    // Validate against schema
    const result = WeatherReportSchema.safeParse(parsedData);

    if (result.success) {
      // 3. Success Case
      return {
        ...state,
        isValid: true,
      };
    } else {
      // 4. Failure Case (Zod errors)
      return {
        ...state,
        isValid: false,
        error: result.error.errors,
      };
    }
  } catch (e) {
    // Handle JSON parse errors specifically
    return {
      ...state,
      isValid: false,
      error: "Invalid JSON format",
    };
  }
}

// 5. Graph Integration Logic (Sketch)
// This represents how the node connects to the graph
export const defineGraph = (graph: any) => {
  // ... define nodes ...
  
  // Conditional Edge Logic
  const routeDecision = (state: GraphState & { isValid?: boolean }) => {
    if (state.isValid === false) {
      return "handleError"; // ID of the error handling node
    }
    return "nextStep"; // ID of the next logical node
  };

  // graph.addConditionalEdges("validationNode", routeDecision);
};
