/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

import express, { Request, Response } from "express";
import { z } from "zod";
import { MemorySaver } from "@langchain/langgraph";

// Simulate persistent storage
const storage = new Map<string, any>();

// 1. Hydration Function
export async function hydrateGraphState(threadId: string, checkpointId: string): Promise<any> {
  // In a real scenario, we query the database or MemorySaver.
  // Here we simulate checking our global storage map.
  
  // Construct the key or query logic
  const config = {
    configurable: {
      thread_id: threadId,
      checkpoint_id: checkpointId,
    },
  };

  // Simulate retrieval (In real MemorySaver, we'd use await checkpointer.get(config))
  // We check if the storage has this specific checkpoint context
  const storedState = storage.get(`${threadId}_${checkpointId}`);

  if (!storedState) {
    // 4. Resilience: Return specific error object instead of throwing
    return Promise.reject({ status: 404, message: "Checkpoint not found" });
  }

  return config; // Return the config needed to resume
}

// 2. Express Route Setup
const app = express();
app.use(express.json());

// 3. Input Validation Schema
const ResumeRequestSchema = z.object({
  threadId: z.string().uuid(), // Strict UUID check
  checkpointId: z.string(), // Assuming checkpoint IDs are strings (often UUIDs)
});

app.post("/resume", async (req: Request, res: Response) => {
  // Validate Input
  const parsedBody = ResumeRequestSchema.safeParse(req.body);

  if (!parsedBody.success) {
    return res.status(400).json({
      error: "Invalid request body",
      details: parsedBody.error.errors,
    });
  }

  const { threadId, checkpointId } = parsedBody.data;

  try {
    // Attempt hydration
    const config = await hydrateGraphState(threadId, checkpointId);
    
    // Logic to resume the graph run would go here
    // await graph.invoke(null, config);
    
    res.json({ message: "Graph resumed successfully", config });
  } catch (error: any) {
    // Handle the specific rejection from hydrateGraphState
    if (error.status === 404) {
      return res.status(404).json({ message: error.message });
    }
    // Handle generic errors
    res.status(500).json({ message: "Internal server error" });
  }
});

// Export app for testing or running
export { app };
