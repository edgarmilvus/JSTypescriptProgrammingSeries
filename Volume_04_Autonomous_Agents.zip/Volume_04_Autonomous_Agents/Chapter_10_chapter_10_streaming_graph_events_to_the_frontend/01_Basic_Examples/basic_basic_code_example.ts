/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

import express, { Request, Response } from 'express';
import { StateGraph, END, START } from '@langchain/langgraph';
import { BaseMessage, HumanMessage } from '@langchain/core/messages';

// Define the state interface for our graph
interface AgentState {
  messages: BaseMessage[];
  currentTool?: string;
  toolResult?: string;
}

// Define a custom tool handler with the correct signature
// This function simulates an external API call (e.g., fetching user data)
/**
 * @param {string} query - The input parameter derived from the LLM or user.
 * @returns {Promise<string>} - The result of the tool call.
 */
const fetchUserData = async (query: string): Promise<string> => {
  // Simulate network latency
  await new Promise(resolve => setTimeout(resolve, 1000));
  return `User data for '${query}': ID=123, Status=Active`;
};

// Initialize the Express app
const app = express();
app.use(express.json());

/**
 * Stream endpoint: Handles SSE connection and streams graph events.
 * This is the entry point for the frontend client.
 */
app.get('/stream', (req: Request, res: Response) => {
  // Set headers for Server-Sent Events (SSE)
  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache');
  res.setHeader('Connection', 'keep-alive');

  // Helper function to send data to the client
  const sendEvent = (event: string, data: object) => {
    res.write(`event: ${event}\n`);
    res.write(`data: ${JSON.stringify(data)}\n\n`);
  };

  // 1. Define the StateGraph
  // We use `AgentState` as the generic type for state management
  const graph = new StateGraph<AgentState>({
    channels: {
      messages: {
        value: (x: BaseMessage[], y: BaseMessage[]) => (y ? x.concat(y) : x),
        default: () => [],
      },
      currentTool: {
        value: (x?: string, y?: string) => y ?? x,
        default: () => undefined,
      },
      toolResult: {
        value: (x?: string, y?: string) => y ?? x,
        default: () => undefined,
      },
    },
  });

  // 2. Define Nodes
  // Node A: The "Tool" node that performs an action
  const toolNode = async (state: AgentState) => {
    // Stream event: Node Start
    sendEvent('node_start', { node: 'ToolNode', timestamp: Date.now() });

    // Simulate streaming tokens (e.g., "Thinking...")
    sendEvent('token', { content: 'Thinking...' });
    await new Promise(resolve => setTimeout(resolve, 500)); // Simulate thinking time

    // Execute the actual tool (asynchronous handling)
    const query = state.messages[state.messages.length - 1].content as string;
    const result = await fetchUserData(query);

    // Stream event: Node End
    sendEvent('node_end', { node: 'ToolNode', result, timestamp: Date.now() });

    return {
      currentTool: 'fetchUserData',
      toolResult: result,
    };
  };

  // Node B: The "Finalizer" node
  const finalizerNode = async (state: AgentState) => {
    sendEvent('node_start', { node: 'FinalizerNode', timestamp: Date.now() });

    const finalResponse = `Agent finished. Tool used: ${state.currentTool}. Result: ${state.toolResult}`;
    
    // Stream final tokens
    sendEvent('token', { content: finalResponse });
    
    sendEvent('node_end', { node: 'FinalizerNode', timestamp: Date.now() });

    return {
      messages: [new HumanMessage(finalResponse)],
    };
  };

  // 3. Add Nodes and Edges
  graph.addNode('tool_node', toolNode);
  graph.addNode('finalizer_node', finalizerNode);

  // Define the control flow
  graph.addEdge(START, 'tool_node');
  graph.addEdge('tool_node', 'finalizer_node');
  graph.addEdge('finalizer_node', END);

  // 4. Compile the Graph
  const runnable = graph.compile();

  // 5. Execute the Graph
  // We wrap execution in an async IIFE to handle promises cleanly
  (async () => {
    try {
      // Initial input state
      const initialInput = {
        messages: [new HumanMessage('Find user profile for "Alice"')],
      };

      // Execute the graph. 
      // Note: We are NOT awaiting the final result here. 
      // We rely on the internal `sendEvent` calls inside the nodes to stream data.
      await runnable.invoke(initialInput);

      // Signal end of stream
      res.write('event: end\ndata: {}\n\n');
      res.end();
    } catch (error) {
      console.error('Graph execution error:', error);
      sendEvent('error', { message: 'Internal Server Error' });
      res.end();
    }
  })();

  // Handle client disconnect
  req.on('close', () => {
    res.end();
  });
});

// Start server
const PORT = 3000;
app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
  console.log(`Open http://localhost:${PORT}/public/index.html to view the client.`);
});
