/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// app/api/chat/route.ts
import { NextResponse } from 'next/server';
import { StateGraph, Annotation, MemorySaver } from '@langchain/langgraph';
import { ChatOpenAI } from '@langchain/openai';
import { ToolNode } from '@langchain/langgraph/prebuilt';
import { tool } from '@langchain/core/tools';
import { z } from 'zod';

// 1. Define the Tool (SaaS Context: Fetch User Analytics)
// This demonstrates the "Tool Invocation Signature". The LLM outputs arguments matching this schema.
const fetchUserRevenue = tool(
  async (args: { userId: string; metric: 'mrr' | 'arr' }) => {
    // Simulate an async database/API call
    await new Promise(resolve => setTimeout(resolve, 1500)); 
    return JSON.stringify({
      userId: args.userId,
      metric: args.metric,
      value: args.metric === 'mrr' ? 12500 : 150000,
      currency: 'USD'
    });
  },
  {
    name: 'fetch_user_revenue',
    description: 'Fetches revenue metrics for a specific user ID.',
    schema: z.object({
      userId: z.string().describe('The unique identifier for the user'),
      metric: z.enum(['mrr', 'arr']).describe('The metric to fetch')
    })
  }
);

// 2. Define State Annotation
// We track the messages (for the LLM) and a 'status' field for the UI loading states.
const GraphState = Annotation.Root({
  messages: Annotation({
    reducer: (state, update) => (state ?? []).concat(update),
    default: () => [],
  }),
  status: Annotation<string>({
    reducer: (state, update) => update,
    default: () => 'idle',
  }),
});

// 3. Node Functions
// These represent the logic steps in our graph.
async function agentNode(state: typeof GraphState.State) {
  const model = new ChatOpenAI({ model: 'gpt-4-turbo-preview', temperature: 0 });
  // Bind tools to the model
  const boundModel = model.bindTools([fetchUserRevenue]);
  
  // Update status for streaming (custom event)
  // Note: We don't return this from the node, but we can emit it via config
  // However, standard LangGraph node returns are what flow to the next node.
  // To stream UI status, we rely on the `streamEvents` API below.
  
  const result = await boundModel.invoke(state.messages);
  return { messages: [result] };
}

const toolNode = new ToolNode([fetchUserRevenue]);

// 4. Conditional Edge Logic
function shouldCallTool(state: typeof GraphState.State) {
  const lastMessage = state.messages[state.messages.length - 1];
  // If the LLM requests a tool call, route to 'tools' node
  if (lastMessage?.tool_calls?.length) {
    return 'tools';
  }
  return 'agent'; // Or 'end' if we are done
}

// 5. Graph Construction
const workflow = new StateGraph(GraphState)
  .addNode('agent', agentNode)
  .addNode('tools', toolNode)
  .addEdge('__start__', 'agent')
  .addConditionalEdges('agent', shouldCallTool, {
    tools: 'tools',
    agent: 'agent', // Loop back if more actions needed
  })
  .addEdge('tools', 'agent'); // Return to agent after tool execution

// Compile with a checkpointer (required for streaming state management)
const checkpointer = new MemorySaver();
const app = workflow.compile({ checkpointer });

// 6. API Route Handler (Next.js App Router)
export async function POST(req: Request) {
  const { message, threadId } = await req.json();

  // Create a TransformStream to pipe LangGraph events to SSE
  const { readable, writable } = new TransformStream();
  const writer = writable.getWriter();
  const encoder = new TextEncoder();

  // Run the graph in the background
  (async () => {
    try {
      // streamEvents is the magic method for real-time visibility
      // We filter for specific events to reduce noise
      const stream = await app.streamEvents(
        {
          messages: [{ role: 'user', content: message }],
          status: 'starting'
        },
        {
          version: 'v2',
          configurable: { thread_id: threadId },
          // Filter to specific events to stream to frontend
          // 'updates' = node return values
          // 'tokens' = LLM streaming chunks
          // 'custom' = explicit emits
        }
      );

      for await (const event of stream) {
        const { event: eventType, data } = event;

        // Filter logic: We only want to send specific data to the client
        let payload: any = null;

        if (eventType === 'on_chat_model_stream') {
          // Stream LLM tokens in real-time
          payload = { type: 'token', content: data.chunk?.content };
        } 
        else if (eventType === 'on_tool_start') {
          payload = { type: 'status', content: 'Fetching data...' };
        }
        else if (eventType === 'on_tool_end') {
          payload = { type: 'status', content: 'Data received.' };
        }
        else if (eventType === 'on_chain_end' && data.output?.status) {
          // Our custom status update from the state
          payload = { type: 'status', content: data.output.status };
        }

        if (payload) {
          // Write to SSE stream
          await writer.write(
            encoder.encode(`data: ${JSON.stringify(payload)}\n\n`)
          );
        }
      }
      
      // Signal end of stream
      await writer.write(encoder.encode('event: end\ndata: {}\n\n'));
      await writer.close();
    } catch (error) {
      // Handle errors in the stream
      const errorMsg = { type: 'error', content: (error as Error).message };
      await writer.write(
        encoder.encode(`data: ${JSON.stringify(errorMsg)}\n\n`)
      );
      await writer.close();
    }
  })();

  // Return the SSE response
  return new Response(readable, {
    headers: {
      'Content-Type': 'text/event-stream',
      'Cache-Control': 'no-cache',
      'Connection': 'keep-alive',
    },
  });
}
