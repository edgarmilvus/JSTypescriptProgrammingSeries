/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script_part2.tsx
// Description: Advanced Application Script
// ==========================================

// app/components/ChatInterface.tsx
'use client';

import { useState, useEffect, useRef } from 'react';

// Define types for our streamed events
type StreamEvent = 
  | { type: 'token'; content: string }
  | { type: 'status'; content: string }
  | { type: 'error'; content: string };

export default function ChatInterface() {
  const [input, setInput] = useState('');
  const [messages, setMessages] = useState<{ role: string; content: string }[]>([]);
  const [isStreaming, setIsStreaming] = useState(false);
  const [status, setStatus] = useState('');
  
  // Ref to hold the EventSource instance
  const eventSourceRef = useRef<EventSource | null>(null);

  // 1. Cleanup effect for SSE connection
  useEffect(() => {
    return () => {
      if (eventSourceRef.current) {
        eventSourceRef.current.close();
      }
    };
  }, []);

  const sendMessage = async () => {
    if (!input) return;

    // Add user message immediately
    setMessages(prev => [...prev, { role: 'user', content: input }]);
    setIsStreaming(true);
    setStatus('Thinking...');
    
    // Reset assistant response buffer
    setMessages(prev => [...prev, { role: 'assistant', content: '' }]);
    
    // 2. Establish SSE Connection
    const threadId = crypto.randomUUID(); // Persist this in real apps
    
    // Note: In a real Next.js app, this would be the API route defined above
    const res = await fetch('/api/chat', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ message: input, threadId }),
    });

    // 3. Stream Reading Logic
    const reader = res.body!.getReader();
    const decoder = new TextDecoder();
    
    // We read the stream manually to handle backpressure
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;

      const chunk = decoder.decode(value, { stream: true });
      
      // Parse SSE format (data: {json}\n\n)
      // Note: A robust parser would handle multi-line chunks, but this is the core logic
      const lines = chunk.split('\n').filter(line => line.startsWith('data:'));
      
      for (const line of lines) {
        try {
          const jsonStr = line.replace('data: ', '');
          if (!jsonStr) continue;
          
          const event: StreamEvent = JSON.parse(jsonStr);

          // 4. Update State based on Event Type
          if (event.type === 'token') {
            // Append token to the last assistant message
            setMessages(prev => {
              const newMsgs = [...prev];
              const lastMsg = newMsgs[newMsgs.length - 1];
              if (lastMsg.role === 'assistant') {
                lastMsg.content += event.content;
              }
              return newMsgs;
            });
          } else if (event.type === 'status') {
            setStatus(event.content);
          } else if (event.type === 'error') {
            setStatus('Error: ' + event.content);
            setIsStreaming(false);
          }
        } catch (e) {
          // Ignore JSON parse errors for partial chunks
        }
      }
    }

    setStatus('Done.');
    setIsStreaming(false);
  };

  return (
    <div className="max-w-2xl mx-auto p-6 bg-white shadow-lg rounded-lg">
      <div className="border-b pb-4 mb-4 h-64 overflow-y-auto space-y-3">
        {messages.map((msg, i) => (
          <div key={i} className={`p-3 rounded ${msg.role === 'user' ? 'bg-blue-100 text-right' : 'bg-gray-100'}`}>
            <p className="text-sm font-semibold">{msg.role.toUpperCase()}</p>
            <p className="mt-1 whitespace-pre-wrap">{msg.content || <span className="animate-pulse">...</span>}</p>
          </div>
        ))}
      </div>
      
      <div className="text-xs text-gray-500 mb-2">
        Status: {status}
      </div>

      <div className="flex gap-2">
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          className="flex-1 border rounded px-3 py-2"
          placeholder="Ask about revenue..."
          disabled={isStreaming}
          onKeyDown={(e) => e.key === 'Enter' && sendMessage()}
        />
        <button 
          onClick={sendMessage} 
          disabled={isStreaming}
          className={`px-4 py-2 rounded text-white ${isStreaming ? 'bg-gray-400' : 'bg-blue-600 hover:bg-blue-700'}`}
        >
          {isStreaming ? 'Waiting...' : 'Send'}
        </button>
      </div>
    </div>
  );
}
