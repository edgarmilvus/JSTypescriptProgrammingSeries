/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// /api/agent/stream/route.ts
import { NextRequest } from 'next/server';
import { AgentGraph } from '@/lib/agents'; // Hypothetical agent definition

export const runtime = 'edge';

export async function POST(req: NextRequest) {
  const { query } = await req.json();

  // Create a ReadableStream for the response
  const stream = new ReadableStream({
    async start(controller) {
      try {
        // 1. Instantiate your LangGraph agent
        const agent = new AgentGraph();

        // 2. Stream the graph execution
        // Note: The actual API for streaming might differ slightly based on LangGraph.js version
        // We assume agent.stream() returns an AsyncIterable
        const eventStream = await agent.stream({ input: query });

        // 3. Iterate over events and enqueue them
        for await (const event of eventStream) {
          // event might be { name: 'node_start', data: {...} }
          // Ensure we handle potential circular references or complex objects
          // by converting to a plain object if necessary, though JSON.stringify 
          // usually handles simple objects fine.
          const data = JSON.stringify(event);
          
          // Format as SSE: "data: {json}\n\n"
          controller.enqueue(`data: ${data}\n\n`);
        }

        controller.close();
      } catch (error) {
        // 4. Handle errors
        const errorData = JSON.stringify({ 
          type: 'error', 
          message: 'Execution failed', 
          details: String(error) 
        });
        controller.enqueue(`data: ${errorData}\n\n`);
        controller.close();
      }
    },
  });

  return new Response(stream, {
    headers: {
      'Content-Type': 'text/event-stream',
      'Cache-Control': 'no-cache',
      'Connection': 'keep-alive',
    },
  });
}
