/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

// hooks/useAgentStream.ts
import { useState, useEffect, useCallback } from 'react';

export interface AgentEvent {
  type: string; // e.g., 'node_start', 'tool_call', 'llm_token'
  data: any;
  metadata?: any;
}

export function useAgentStream(query: string) {
  const [events, setEvents] = useState<AgentEvent[]>([]);
  const [status, setStatus] = useState<'idle' | 'connecting' | 'streaming' | 'error'>('idle');
  const [currentNode, setCurrentNode] = useState<string | null>(null);

  const startStream = useCallback(() => {
    if (!query) return;

    setStatus('connecting');
    // Note: Using GET with query params is simple, but for large inputs or security, 
    // a POST request via fetch with ReadableStream is better. 
    // However, EventSource only supports GET. For this exercise, we stick to GET.
    const eventSource = new EventSource(`/api/agent/stream?query=${encodeURIComponent(query)}`);

    eventSource.onmessage = (event) => {
      try {
        const parsedData: AgentEvent = JSON.parse(event.data);
        
        // Update events list
        setEvents(prev => [...prev, parsedData]);
        
        // specific logic to track current node
        if (parsedData.type === 'node_start') {
            setCurrentNode(parsedData.data?.name || 'Unknown');
        }

        setStatus('streaming');
      } catch (e) {
        console.error('Failed to parse event data', e);
      }
    };

    eventSource.onerror = () => {
      setStatus('error');
      eventSource.close();
    };

    // Cleanup function
    return () => {
      eventSource.close();
      setStatus('idle');
    };
  }, [query]);

  useEffect(() => {
    if (query) {
      const cleanup = startStream();
      return cleanup;
    }
  }, [query, startStream]);

  return { events, status, currentNode };
}
