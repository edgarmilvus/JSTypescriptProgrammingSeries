/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

// components/GraphVisualizer.tsx
import React, { useEffect, useState } from 'react';
import { Node, Edge } from 'react-flow-renderer';

interface GraphVisualizerProps {
  events: any[]; 
  currentNode?: string | null;
}

// Static graph definition
const initialNodes: Node[] = [
  { id: 'start', type: 'input', data: { label: 'Start' }, position: { x: 0, y: 0 } },
  { id: 'supervisor', data: { label: 'Supervisor' }, position: { x: 150, y: 0 } },
  { id: 'worker1', data: { label: 'Worker 1' }, position: { x: 300, y: -50 } },
  { id: 'worker2', data: { label: 'Worker 2' }, position: { x: 300, y: 50 } },
  { id: 'end', type: 'output', data: { label: 'End' }, position: { x: 450, y: 0 } },
];

const initialEdges: Edge[] = [
  { id: 'e1', source: 'start', target: 'supervisor' },
  { id: 'e2', source: 'supervisor', target: 'worker1' },
  { id: 'e3', source: 'supervisor', target: 'worker2' },
  { id: 'e4', source: 'worker1', target: 'end' },
  { id: 'e5', source: 'worker2', target: 'end' },
];

export function GraphVisualizer({ events, currentNode }: GraphVisualizerProps) {
  const [nodes, setNodes] = useState<Node[]>(initialNodes);
  const [edges, setEdges] = useState<Edge[]>(initialEdges);

  useEffect(() => {
    // Identify completed nodes from past events
    const completedNodeNames = events
      .filter(e => e.type === 'node_end')
      .map(e => e.data?.name);

    // Update node styles based on current execution and completion status
    setNodes(prevNodes => prevNodes.map(node => {
      const isActive = node.id === currentNode;
      const isCompleted = completedNodeNames.includes(node.id);
      
      let style = {
        border: '1px solid #ccc',
        backgroundColor: '#fff',
        color: '#000',
      };

      if (isActive) {
        style = {
          border: '2px solid #00ff00',
          backgroundColor: '#e0ffe0',
          color: '#006600',
        };
      } else if (isCompleted) {
        style = {
          border: '1px solid #00aa00',
          backgroundColor: '#f0fff0',
          color: '#555',
        };
      }

      return {
        ...node,
        style,
      };
    }));
  }, [currentNode, events]);

  // In a real implementation, you would use react-flow here
  // For this example, we render a simple HTML representation
  return (
    <div style={{ padding: '20px', border: '1px solid #eee', borderRadius: '8px' }}>
      <h3>Agent Execution Graph</h3>
      <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
        {nodes.map(node => (
          <div key={node.id} style={{
            padding: '10px',
            border: node.style?.border || '1px solid #ccc',
            backgroundColor: node.style?.backgroundColor || '#fff',
            color: node.style?.color || '#000',
            fontWeight: node.id === currentNode ? 'bold' : 'normal',
            transition: 'all 0.3s ease',
            opacity: node.id === currentNode ? 1 : 0.8
          }}>
            {node.data.label} {node.id === currentNode && <span> (Active)</span>}
          </div>
        ))}
      </div>
    </div>
  );
}
