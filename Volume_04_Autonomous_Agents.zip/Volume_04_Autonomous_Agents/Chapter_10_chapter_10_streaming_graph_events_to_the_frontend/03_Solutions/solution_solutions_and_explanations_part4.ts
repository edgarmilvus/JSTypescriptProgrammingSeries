/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

// hooks/useAgentStreamWithReconnect.ts
import { useState, useEffect, useCallback, useRef } from 'react';

export function useAgentStreamWithReconnect(query: string) {
  const [events, setEvents] = useState<any[]>([]);
  const [status, setStatus] = useState<'idle' | 'connecting' | 'streaming' | 'error' | 'reconnecting'>('idle');
  
  const eventSourceRef = useRef<EventSource | null>(null);
  const retryCountRef = useRef(0);
  const maxRetries = 5;

  const connect = useCallback(() => {
    if (eventSourceRef.current) {
      eventSourceRef.current.close();
    }

    // Determine status based on retry count
    setStatus(retryCountRef.current > 0 ? 'reconnecting' : 'connecting');
    
    // Establish connection
    const es = new EventSource(`/api/agent/stream?query=${encodeURIComponent(query)}`);
    eventSourceRef.current = es;

    es.onmessage = (event) => {
      try {
        const parsedData = JSON.parse(event.data);
        setEvents(prev => [...prev, parsedData]);
        setStatus('streaming');
        // Reset retry count on successful message
        retryCountRef.current = 0;
      } catch (e) {
        console.error('Parse error', e);
      }
    };

    es.onerror = () => {
      setStatus('error');
      es.close();
      eventSourceRef.current = null;

      // Exponential backoff reconnection logic
      if (retryCountRef.current < maxRetries) {
        const delay = Math.pow(2, retryCountRef.current) * 1000; // 1s, 2s, 4s...
        retryCountRef.current += 1;
        console.log(`Connection lost. Reconnecting in ${delay}ms...`);
        setTimeout(connect, delay);
      }
    };
  }, [query]);

  useEffect(() => {
    if (query) {
      // Initial connect
      connect();
    }
    return () => {
      if (eventSourceRef.current) {
        eventSourceRef.current.close();
      }
    };
  }, [query, connect]);

  const manualReconnect = () => {
    retryCountRef.current = 0;
    connect();
  };

  return { events, status, manualReconnect };
}
