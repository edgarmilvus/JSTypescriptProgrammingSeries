/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.tsx
// Description: Solutions and Explanations
// ==========================================

// components/StreamingTokens.tsx
import React, { useEffect, useState, useRef } from 'react';

interface StreamingTokensProps {
  events: any[]; 
  tokenEventName?: string; 
}

export function StreamingTokens({ events, tokenEventName = 'llm_token' }: StreamingTokensProps) {
  const [displayedText, setDisplayedText] = useState('');
  const [pendingTokens, setPendingTokens] = useState<string[]>([]);
  const containerRef = useRef<HTMLDivElement>(null);

  // 1. Filter events for tokens and extract them
  useEffect(() => {
    const newTokens = events
      // We only look at events added since the last render
      // (In a real optimized app, we might track index, but filtering all is okay for small arrays)
      .filter(event => event.type === tokenEventName && event.data?.token)
      .map(event => event.data.token);
    
    if (newTokens.length > 0) {
      // We append new tokens to the pending queue
      setPendingTokens(prev => [...prev, ...newTokens]);
    }
  }, [events, tokenEventName]);

  // 2. Process tokens with a typewriter effect
  useEffect(() => {
    if (pendingTokens.length > 0) {
      const timer = setTimeout(() => {
        const [nextToken, ...rest] = pendingTokens;
        setDisplayedText(prev => prev + nextToken);
        setPendingTokens(rest);
        
        // Optional: Scroll to bottom
        if (containerRef.current) {
            containerRef.current.scrollTop = containerRef.current.scrollHeight;
        }
      }, 30); // Fast typing speed

      return () => clearTimeout(timer);
    }
  }, [pendingTokens]);

  return (
    <div className="streaming-tokens-container" style={{ 
        fontFamily: 'monospace', 
        padding: '10px', 
        backgroundColor: '#f5f5f5', 
        borderRadius: '4px',
        maxHeight: '200px',
        overflowY: 'auto'
    }} ref={containerRef}>
      <h4 style={{ margin: '0 0 10px 0', fontSize: '14px', color: '#666' }}>LLM Streaming Output:</h4>
      <div className="token-display">
        {displayedText}
        <span className="cursor" style={{ animation: 'blink 1s infinite' }}>|</span>
      </div>
    </div>
  );
}
