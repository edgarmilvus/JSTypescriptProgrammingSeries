/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part6.ts
// Description: Solutions and Explanations
// ==========================================

// hooks/useAgentSessionReducer.ts
import { useReducer } from 'react';

// Define the state interface
interface AgentSessionState {
  conversation: { role: 'user' | 'agent'; content: string }[];
  agentStatus: string;
  graphState: Record<string, any>;
  toolCalls: any[];
}

type AgentAction =
  | { type: 'NODE_START'; payload: { nodeName: string } }
  | { type: 'TOOL_CALL'; payload: { toolName: string; args: any } }
  | { type: 'LLM_TOKEN'; payload: { token: string } }
  | { type: 'RESET' };

const initialState: AgentSessionState = {
  conversation: [],
  agentStatus: 'idle',
  graphState: {},
  toolCalls: [],
};

function agentReducer(state: AgentSessionState, action: AgentAction): AgentSessionState {
  // We do not mutate 'state'. We return a new object.
  switch (action.type) {
    case 'NODE_START':
      return {
        ...state,
        agentStatus: `Running: ${action.payload.nodeName}`,
        graphState: {
          ...state.graphState,
          currentNode: action.payload.nodeName,
        },
      };
    
    case 'TOOL_CALL':
      return {
        ...state,
        // Immutable array update: copy old array, append new item
        toolCalls: [...state.toolCalls, action.payload],
      };
    
    case 'LLM_TOKEN':
      // Handle appending to the last agent message or creating a new one
      const lastMessageIndex = state.conversation.length - 1;
      const isLastAgent = lastMessageIndex >= 0 && state.conversation[lastMessageIndex].role === 'agent';

      if (isLastAgent) {
        // Update existing message
        const updatedConversation = [...state.conversation];
        updatedConversation[lastMessageIndex] = {
          ...updatedConversation[lastMessageIndex],
          content: updatedConversation[lastMessageIndex].content + action.payload.token,
        };
        return {
          ...state,
          conversation: updatedConversation,
        };
      } else {
        // Create new message
        return {
          ...state,
          conversation: [
            ...state.conversation,
            { role: 'agent', content: action.payload.token }
          ],
        };
      }

    case 'RESET':
      return initialState;
      
    default:
      return state;
  }
}

export function useAgentSession() {
  const [state, dispatch] = useReducer(agentReducer, initialState);
  return { state, dispatch };
}
