/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part7.ts
// Description: Solutions and Explanations
// ==========================================

// lib/eventTransformer.ts

// 1. Define the Standardized Event Interface
export interface StandardizedEvent {
  eventId: string; 
  timestamp: number; 
  type: string; 
  data: Record<string, any>; 
  metadata: {
    graphRunId?: string;
    nodeName?: string;
  };
}

// 2. Transformation Function
export function transformGraphEvent(rawEvent: any, runId: string): StandardizedEvent {
  let type: string = 'unknown';
  let data: Record<string, any> = {};
  let nodeName: string | undefined;

  // Mapping raw LangGraph/LangChain callback events to our schema
  // Note: These keys ('on_chain_start', etc.) depend on your LangGraph version and callback setup
  if (rawEvent.event === 'on_chain_start') {
    type = 'node_start';
    nodeName = rawEvent.metadata?.name;
    data = { name: nodeName };
  } else if (rawEvent.event === 'on_tool_start') {
    type = 'tool_call';
    data = { 
      toolName: rawEvent.name, 
      input: rawEvent.inputs 
    };
    nodeName = rawEvent.metadata?.name;
  } else if (rawEvent.event === 'on_llm_stream') {
    type = 'llm_token';
    // Extract token from the chunk (structure varies by LLM provider)
    const token = rawEvent.chunk?.text || rawEvent.data?.chunk || '';
    data = { token };
  } else if (rawEvent.event === 'on_chain_end') {
    type = 'node_end';
    nodeName = rawEvent.metadata?.name;
    data = { name: nodeName, output: rawEvent.outputs };
  }

  // 3. Construct the standardized payload
  const standardizedEvent: StandardizedEvent = {
    // In Edge runtime, crypto.randomUUID() is available
    eventId: crypto.randomUUID(), 
    timestamp: Date.now(),
    type,
    data,
    metadata: {
      graphRunId: runId,
      nodeName,
    },
  };

  return standardizedEvent;
}
