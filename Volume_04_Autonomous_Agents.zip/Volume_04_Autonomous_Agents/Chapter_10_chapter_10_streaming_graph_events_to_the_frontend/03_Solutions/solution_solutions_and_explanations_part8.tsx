/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part8.tsx
// Description: Solutions and Explanations
// ==========================================

// components/MultiAgentVisualizer.tsx
import React, { useEffect, useState } from 'react';

interface MultiAgentVisualizerProps {
  events: any[];
}

// Define graph structure
const graph = {
  nodes: [
    { id: 'supervisor', label: 'Supervisor', type: 'supervisor' },
    { id: 'workerA', label: 'Worker A', type: 'worker' },
    { id: 'workerB', label: 'Worker B', type: 'worker' },
    { id: 'workerC', label: 'Worker C', type: 'worker' },
  ],
  edges: [
    { source: 'supervisor', target: 'workerA' },
    { source: 'supervisor', target: 'workerB' },
    { source: 'supervisor', target: 'workerC' },
  ],
};

export function MultiAgentVisualizer({ events }: MultiAgentVisualizerProps) {
  const [activeNode, setActiveNode] = useState<string | null>(null);
  const [activeEdge, setActiveEdge] = useState<{ source: string; target: string } | null>(null);
  const [completedNodes, setCompletedNodes] = useState<Set<string>>(new Set());

  useEffect(() => {
    // Only process the latest event to update state
    const latestEvent = events[events.length - 1];
    if (!latestEvent) return;

    switch (latestEvent.type) {
      case 'supervisor_decision':
        // Highlight the edge from supervisor to the chosen worker
        const chosenWorker = latestEvent.data.selectedWorker;
        setActiveEdge({ source: 'supervisor', target: chosenWorker });
        break;
      
      case 'node_start':
        // If the node is a worker, set it as active
        if (latestEvent.data.name?.startsWith('worker')) {
          setActiveNode(latestEvent.data.name);
        }
        break;
      
      case 'node_end':
        if (latestEvent.data.name) {
          // Add to completed set
          setCompletedNodes(prev => new Set(prev).add(latestEvent.data.name));
          // Clear active node if it matches
          if (activeNode === latestEvent.data.name) {
            setActiveNode(null);
          }
        }
        break;
    }
  }, [events]); // Dependency on full events array ensures we process history on mount/reconnect

  return (
    <div style={{ padding: '20px', fontFamily: 'sans-serif' }}>
      <h3>Multi-Agent Supervisor Flow</h3>
      
      <div style={{ display: 'flex', alignItems: 'center', gap: '15px', padding: '20px', background: '#f9f9f9', borderRadius: '8px' }}>
        
        {/* Supervisor Node */}
        <div style={{ 
          padding: '15px', 
          border: '2px solid #333', 
          borderRadius: '8px',
          backgroundColor: completedNodes.has('supervisor') ? '#d4edda' : '#fff',
          fontWeight: 'bold',
          minWidth: '100px',
          textAlign: 'center'
        }}>
          Supervisor
        </div>

        {/* Visual Connector (Edge) */}
        <div style={{ 
          flex: 1, 
          height: '4px', 
          backgroundColor: activeEdge ? '#007bff' : '#e0e0e0',
          transition: 'background-color 0.5s ease',
          position: 'relative'
        }}>
          {activeEdge && (
            <div style={{
                position: 'absolute',
                right: '0',
                top: '-6px',
                width: '0', 
                height: '0', 
                borderLeft: '10px solid #007bff',
                borderTop: '8px solid transparent',
                borderBottom: '8px solid transparent'
            }}></div>
          )}
        </div>

        {/* Worker Nodes */}
        <div style={{ display: 'flex', gap: '10px' }}>
          {graph.nodes.filter(n => n.type === 'worker').map(worker => {
            const isActive = activeNode === worker.id;
            const isCompleted = completedNodes.has(worker.id);
            
            return (
              <div key={worker.id} style={{
                padding: '15px',
                border: `2px solid ${isActive ? '#28a745' : (isCompleted ? '#28a745' : '#ccc')}`,
                borderRadius: '8px',
                backgroundColor: isActive ? '#e8f5e9' : (isCompleted ? '#d4edda' : '#fff'),
                opacity: activeEdge?.target === worker.id || isActive ? 1 : 0.5,
                fontWeight: isActive ? 'bold' : 'normal',
                minWidth: '80px',
                textAlign: 'center',
                transition: 'all 0.3s ease'
              }}>
                {worker.label}
                {isActive && <div style={{ fontSize: '12px', color: '#28a745' }}>Running...</div>}
              </div>
            );
          })}
        </div>

      </div>
    </div>
  );
}
