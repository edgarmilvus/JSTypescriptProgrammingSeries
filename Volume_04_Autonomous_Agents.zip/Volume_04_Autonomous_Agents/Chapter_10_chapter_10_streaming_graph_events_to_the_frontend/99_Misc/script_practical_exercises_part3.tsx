/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part3.tsx
// Description: Practical Exercises
// ==========================================

// Example structure for the Graph Visualizer Component
// components/GraphVisualizer.tsx
import React, { useEffect, useState } from 'react';
import { Node, Edge, Position } from 'react-flow-renderer';

interface GraphVisualizerProps {
  events: any[]; // Array of events from the stream
  currentNode?: string;
}

const initialNodes: Node[] = [
  { id: 'start', type: 'input', data: { label: 'Start' }, position: { x: 0, y: 0 } },
  { id: 'supervisor', data: { label: 'Supervisor' }, position: { x: 150, y: 0 } },
  { id: 'worker1', data: { label: 'Worker 1' }, position: { x: 300, y: -50 } },
  { id: 'worker2', data: { label: 'Worker 2' }, position: { x: 300, y: 50 } },
  { id: 'end', type: 'output', data: { label: 'End' }, position: { x: 450, y: 0 } },
];

const initialEdges: Edge[] = [
  { id: 'e1', source: 'start', target: 'supervisor' },
  { id: 'e2', source: 'supervisor', target: 'worker1' },
  { id: 'e3', source: 'supervisor', target: 'worker2' },
  { id: 'e4', source: 'worker1', target: 'end' },
  { id: 'e5', source: 'worker2', target: 'end' },
];

export function GraphVisualizer({ events, currentNode }: GraphVisualizerProps) {
  const [nodes, setNodes] = useState<Node[]>(initialNodes);
  const [edges, setEdges] = useState<Edge[]>(initialEdges);

  useEffect(() => {
    if (currentNode) {
      // Update node styles based on current execution
      setNodes(prevNodes => prevNodes.map(node => ({
        ...node,
        style: {
          ...node.style,
          border: node.id === currentNode ? '2px solid #00ff00' : '1px solid #ccc',
          backgroundColor: node.id === currentNode ? '#e0ffe0' : '#fff',
        }
      })));
    }
  }, [currentNode]);

  // In a real implementation, you would use react-flow here
  // For this example, we'll just log the state updates
  console.log('Graph Visualizer State:', { nodes, edges, events });

  return (
    <div>
      <h3>Agent Execution Graph</h3>
      {/* 
        <ReactFlow nodes={nodes} edges={edges} />
      */}
      <p>Visual representation would appear here. Current Node: {currentNode || 'None'}</p>
    </div>
  );
}
