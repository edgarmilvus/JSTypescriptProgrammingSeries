/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part6.ts
// Description: Practical Exercises
// ==========================================

// Example structure for the Reducer and State Management
// hooks/useAgentSessionReducer.ts
import { useReducer } from 'react';

// Define the state interface
interface AgentSessionState {
  conversation: { role: 'user' | 'agent'; content: string }[];
  agentStatus: string;
  graphState: Record<string, any>;
  toolCalls: any[];
}

type AgentAction =
  | { type: 'NODE_START'; payload: { nodeName: string } }
  | { type: 'TOOL_CALL'; payload: { toolName: string; args: any } }
  | { type: 'LLM_TOKEN'; payload: { token: string } }
  | { type: 'RESET' };

const initialState: AgentSessionState = {
  conversation: [],
  agentStatus: 'idle',
  graphState: {},
  toolCalls: [],
};

function agentReducer(state: AgentSessionState, action: AgentAction): AgentSessionState {
  console.log('Previous State:', JSON.parse(JSON.stringify(state))); // Deep copy for logging
  let nextState: AgentSessionState;

  switch (action.type) {
    case 'NODE_START':
      nextState = {
        ...state,
        agentStatus: `Running: ${action.payload.nodeName}`,
        graphState: {
          ...state.graphState,
          currentNode: action.payload.nodeName,
        },
      };
      break;
    case 'TOOL_CALL':
      nextState = {
        ...state,
        toolCalls: [...state.toolCalls, action.payload], // Immutable array update
      };
      break;
    case 'LLM_TOKEN':
      // Assuming we are appending to a streaming message in conversation
      const lastMessage = state.conversation[state.conversation.length - 1];
      const updatedConversation = [...state.conversation];
      if (lastMessage && lastMessage.role === 'agent') {
        updatedConversation[updatedConversation.length - 1] = {
          ...lastMessage,
          content: lastMessage.content + action.payload.token,
        };
      } else {
        updatedConversation.push({ role: 'agent', content: action.payload.token });
      }
      nextState = {
        ...state,
        conversation: updatedConversation,
      };
      break;
    case 'RESET':
      nextState = initialState;
      break;
    default:
      nextState = state;
  }
  
  console.log('Next State:', nextState);
  return nextState;
}

export function useAgentSession() {
  const [state, dispatch] = useReducer(agentReducer, initialState);
  return { state, dispatch };
}
