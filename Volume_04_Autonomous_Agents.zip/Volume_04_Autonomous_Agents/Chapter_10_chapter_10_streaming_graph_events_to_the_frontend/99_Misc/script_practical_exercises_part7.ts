/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part7.ts
// Description: Practical Exercises
// ==========================================

// Example structure for the Event Transformer
// lib/eventTransformer.ts

// 1. Define the Standardized Event Interface
export interface StandardizedEvent {
  eventId: string; // UUID or similar
  timestamp: number; // Unix timestamp
  type: string; // 'node_start', 'node_end', 'tool_call', 'llm_token', 'error'
  data: Record<string, any>; // Event-specific payload
  metadata: {
    graphRunId?: string;
    nodeName?: string;
  };
}

// 2. Transformation Function
export function transformGraphEvent(rawEvent: any, runId: string): StandardizedEvent {
  // Example logic for different raw event types
  // Note: The actual structure of `rawEvent` depends on LangGraph.js internals
  let type: string = 'unknown';
  let data: Record<string, any> = {};
  let nodeName: string | undefined;

  if (rawEvent.event === 'on_chain_start') {
    type = 'node_start';
    nodeName = rawEvent.metadata?.name;
    data = { name: nodeName };
  } else if (rawEvent.event === 'on_tool_start') {
    type = 'tool_call';
    data = { 
      toolName: rawEvent.name, 
      input: rawEvent.inputs 
    };
    nodeName = rawEvent.metadata?.name;
  } else if (rawEvent.event === 'on_llm_stream') {
    type = 'llm_token';
    // Assuming the token is in a specific part of the chunk
    data = { token: rawEvent.chunk?.text || '' };
  } else if (rawEvent.event === 'on_chain_end') {
    type = 'node_end';
    nodeName = rawEvent.metadata?.name;
    data = { name: nodeName, output: rawEvent.outputs };
  }

  // 3. Construct the standardized payload
  const standardizedEvent: StandardizedEvent = {
    eventId: crypto.randomUUID(), // Use a UUID generator
    timestamp: Date.now(),
    type,
    data,
    metadata: {
      graphRunId: runId,
      nodeName,
    },
  };

  return standardizedEvent;
}

// 4. Usage in the API Route (conceptual)
// Inside the stream loop:
// const standardized = transformGraphEvent(event, graphRunId);
// controller.enqueue(`data: ${JSON.stringify(standardized)}\n\n`);
