/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part8.tsx
// Description: Practical Exercises
// ==========================================

// Example structure for the Multi-Agent Visualizer
// components/MultiAgentVisualizer.tsx
import React, { useEffect, useState } from 'react';

interface MultiAgentVisualizerProps {
  events: any[];
}

// Define graph structure
const graph = {
  nodes: [
    { id: 'supervisor', label: 'Supervisor', type: 'supervisor' },
    { id: 'workerA', label: 'Worker A', type: 'worker' },
    { id: 'workerB', label: 'Worker B', type: 'worker' },
    { id: 'workerC', label: 'Worker C', type: 'worker' },
  ],
  edges: [
    { source: 'supervisor', target: 'workerA' },
    { source: 'supervisor', target: 'workerB' },
    { source: 'supervisor', target: 'workerC' },
  ],
};

export function MultiAgentVisualizer({ events }: MultiAgentVisualizerProps) {
  const [activeNode, setActiveNode] = useState<string | null>(null);
  const [activeEdge, setActiveEdge] = useState<{ source: string; target: string } | null>(null);
  const [completedNodes, setCompletedNodes] = useState<Set<string>>(new Set());

  useEffect(() => {
    const latestEvent = events[events.length - 1];
    if (!latestEvent) return;

    switch (latestEvent.type) {
      case 'supervisor_decision':
        // Highlight the edge from supervisor to the chosen worker
        const chosenWorker = latestEvent.data.selectedWorker;
        setActiveEdge({ source: 'supervisor', target: chosenWorker });
        break;
      case 'node_start':
        if (latestEvent.data.name?.startsWith('worker')) {
          setActiveNode(latestEvent.data.name);
        }
        break;
      case 'node_end':
        if (latestEvent.data.name) {
          setCompletedNodes(prev => new Set(prev).add(latestEvent.data.name));
          setActiveNode(null); // Clear active node
        }
        break;
    }
  }, [events]);

  return (
    <div>
      <h3>Multi-Agent Supervisor Flow</h3>
      <div style={{ display: 'flex', gap: '20px', alignItems: 'center' }}>
        {/* Supervisor Node */}
        <div style={{ 
          padding: '10px', 
          border: '2px solid #000', 
          backgroundColor: '#eee',
          fontWeight: 'bold'
        }}>
          Supervisor
        </div>

        {/* Visual Connector */}
        <div style={{ height: '2px', width: '50px', backgroundColor: activeEdge ? 'blue' : '#ccc' }}></div>

        {/* Worker Nodes */}
        {graph.nodes.filter(n => n.type === 'worker').map(worker => (
          <div key={worker.id} style={{
            padding: '10px',
            border: `2px solid ${activeNode === worker.id ? 'green' : '#ccc'}`,
            backgroundColor: completedNodes.has(worker.id) ? '#d4edda' : '#fff',
            opacity: activeEdge?.target === worker.id || activeNode === worker.id ? 1 : 0.5
          }}>
            {worker.label}
          </div>
        ))}
      </div>
    </div>
  );
}
