/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.ts
// Description: Basic Code Example
// ==========================================

// app/api/router/route.ts
// This is a Next.js App Router API endpoint.
// It uses TypeScript for type safety and LangGraph.js for state management.

import { NextResponse } from 'next/server';
import { StateGraph, END, START } from '@langchain/langgraph';
import { ChatOpenAI } from '@langchain/openai';
import { z } from 'zod';

// ---------------------------------------------------------------------------
// 1. TYPE DEFINITIONS
// ---------------------------------------------------------------------------

/**
 * The shared state passed between nodes in our LangGraph.
 * @typedef {Object} RouterState
 * @property {string} input - The raw user query.
 * @property {string} [route] - The classified intent (e.g., 'summarize', 'sentiment').
 * @property {string} [result] - The final output from the agent.
 */
interface RouterState {
  input: string;
  route?: string;
  result?: string;
}

// ---------------------------------------------------------------------------
// 2. AGENT DEFINITIONS (Simulated)
// ---------------------------------------------------------------------------

/**
 * Simulates a Summarizer Agent.
 * In a real app, this would call an LLM to summarize text.
 */
const summarizeAgent = async (state: RouterState): Promise<Partial<RouterState>> => {
  console.log(`[Agent] Routing to Summarizer with input: "${state.input}"`);
  // Simulate processing time (Non-blocking I/O context)
  await new Promise(resolve => setTimeout(resolve, 100));
  return { result: `Summary: ${state.input.substring(0, 50)}... (truncated)` };
};

/**
 * Simulates a Sentiment Analysis Agent.
 */
const sentimentAgent = async (state: RouterState): Promise<Partial<RouterState>> => {
  console.log(`[Agent] Routing to Sentiment Analysis with input: "${state.input}"`);
  await new Promise(resolve => setTimeout(resolve, 100));
  return { result: `Sentiment: Positive (based on keywords in "${state.input}")` };
};

/**
 * Fallback handler for unclassified requests.
 */
const fallbackHandler = async (state: RouterState): Promise<Partial<RouterState>> => {
  console.log(`[Agent] Routing to Fallback`);
  return { result: "I'm sorry, I don't know how to handle that request." };
};

// ---------------------------------------------------------------------------
// 3. INTENT CLASSIFICATION NODE
// ---------------------------------------------------------------------------

/**
 * The Core Router Logic.
 * Uses an LLM to classify the input and output a JSON schema.
 * This demonstrates "Dynamic Tool Selection" via intent classification.
 */
const classifyIntent = async (state: RouterState): Promise<Partial<RouterState>> => {
  // Initialize the LLM (Requires OPENAI_API_KEY in env)
  const model = new ChatOpenAI({ 
    model: 'gpt-3.5-turbo', 
    temperature: 0 // Deterministic output for routing
  });

  // Define a strict schema using Zod to enforce JSON output.
  // This prevents LLM hallucinations of free-form text.
  const schema = z.object({
    route: z.enum(['summarize', 'sentiment', 'unknown']).describe('The intent of the user request.'),
  });

  // Bind the schema to the model (Tool calling)
  const structuredModel = model.withStructuredOutput(schema);

  // Construct the prompt
  const prompt = `Classify the following user request into one of the available categories: 'summarize', 'sentiment', or 'unknown'.
  
  User Request: "${state.input}"

  Respond only with valid JSON.`;

  try {
    // Execute the LLM call (Non-blocking I/O)
    const response = await structuredModel.invoke(prompt);
    
    // Return the classification result to update the state
    return { route: response.route };
  } catch (error) {
    console.error("LLM Classification Error:", error);
    // If the LLM fails or hallucinates, default to unknown to trigger fallback
    return { route: 'unknown' };
  }
};

// ---------------------------------------------------------------------------
// 4. LANGGRAPH CONSTRUCTION
// ---------------------------------------------------------------------------

/**
 * Builds the routing graph using LangGraph.js.
 */
const createRouterGraph = () => {
  // Define the state schema for the graph
  const graphState = {
    input: { value: null }, // Initial input
    route: { value: null }, // Classification result
    result: { value: null }, // Final output
  };

  // Initialize the graph
  const workflow = new StateGraph(graphState);

  // Add the Classification Node
  workflow.addNode('classify', classifyIntent);

  // Add Agent Nodes
  workflow.addNode('summarizer', summarizeAgent);
  workflow.addNode('sentiment', sentimentAgent);
  workflow.addNode('fallback', fallbackHandler);

  // Define Routing Logic (Conditional Edges)
  // We inspect the state 'route' to decide the next step.
  const router = (state: RouterState) => {
    if (state.route === 'summarize') return 'summarizer';
    if (state.route === 'sentiment') return 'sentiment';
    return 'fallback';
  };

  // Set the entry point
  workflow.addEdge(START, 'classify');

  // Add conditional edges from the classifier to the agents
  workflow.addConditionalEdges('classify', router);

  // All agents go to END
  workflow.addEdge('summarizer', END);
  workflow.addEdge('sentiment', END);
  workflow.addEdge('fallback', END);

  return workflow.compile();
};

// ---------------------------------------------------------------------------
// 5. API ROUTE HANDLER (Next.js)
// ---------------------------------------------------------------------------

/**
 * POST Handler for the API Route.
 * Receives JSON: { "input": "user text" }
 */
export async function POST(req: Request) {
  // Parse the incoming request
  const { input } = await req.json();

  if (!input) {
    return NextResponse.json({ error: 'Input is required' }, { status: 400 });
  }

  // Initialize the graph
  const graph = createRouterGraph();

  // Execute the graph
  // This runs the nodes in sequence: Classify -> Router -> Agent
  const results = await graph.invoke({ input });

  // Return the final result
  return NextResponse.json({
    input: results.input,
    detectedIntent: results.route,
    response: results.result,
  });
}
