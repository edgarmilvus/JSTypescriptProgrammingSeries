/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.tsx
// Description: Advanced Application Script
// ==========================================

// app/components/RouterWorkflow.tsx
'use server';

import React from 'react';
import { z } from 'zod';
import { StateGraph, START, END, Annotation } from '@langchain/langgraph';
import { Suspense } from 'react';

// =============================================================================
// 1. RUNTIME VALIDATION (ZOD)
// =============================================================================

/**
 * Defines the schema for incoming requests. 
 * Why: We cannot trust client-side data. Zod ensures the input has the 
 * expected structure (e.g., 'message' is a non-empty string) at runtime.
 */
const InputSchema = z.object({
  message: z.string().min(1, "Message cannot be empty"),
  userId: z.string().uuid().optional(),
});

type InputType = z.infer<typeof InputSchema>;

// =============================================================================
// 2. STATE DEFINITION (LANGGRAPH ANNOTATION)
// =============================================================================

/**
 * Defines the shared state across the graph nodes.
 * 'route' determines where the request is sent.
 * 'response' holds the final output from the agent.
 */
const GraphState = Annotation.Root({
  message: Annotation<string>({
    reducer: (state, update) => update ?? state,
    default: () => '',
  }),
  route: Annotation<'billing' | 'tech' | 'fallback' | null>({
    reducer: (state, update) => update ?? state,
    default: () => null,
  }),
  response: Annotation<string>({
    reducer: (state, update) => update ?? state,
    default: () => '',
  }),
});

// =============================================================================
// 3. AGENT NODES (SPECIALIZED LOGIC)
// =============================================================================

/**
 * Node: Intent Classifier
 * Analyzes the message content to determine the routing destination.
 * Heuristic approach for demonstration (in production, use an LLM or NLP model).
 */
const classifyIntent = async (state: typeof GraphState.State) => {
  const text = state.message.toLowerCase();
  
  let route: 'billing' | 'tech' | 'fallback' = 'fallback';

  // Keyword matching for routing logic
  if (text.match(/invoice|payment|bill|refund|charge/)) {
    route = 'billing';
  } else if (text.match(/error|bug|crash|login|password|technical/)) {
    route = 'tech';
  }

  return { route };
};

/**
 * Node: Billing Agent
 * Handles specific billing-related logic.
 */
const billingAgent = async (state: typeof GraphState.State) => {
  // Simulate database lookup or API call
  const mockInvoiceId = 'INV-' + Math.floor(Math.random() * 10000);
  return { 
    response: `[Billing Agent]: I've located your recent invoice (${mockInvoiceId}). How can I assist you with it?` 
  };
};

/**
 * Node: Technical Support Agent
 * Handles specific technical issues.
 */
const techSupportAgent = async (state: typeof GraphState.State) => {
  // Simulate troubleshooting steps
  return { 
    response: `[Tech Support]: I see you're experiencing: "${state.message}". Have you tried clearing your cache?` 
  };
};

/**
 * Node: Fallback Handler
 * Triggered when intent is ambiguous or no specific agent matches.
 */
const fallbackHandler = async (state: typeof GraphState.State) => {
  return { 
    response: `[System]: I'm not sure how to help with that. I've escalated your request to a human specialist.` 
  };
};

// =============================================================================
// 4. GRAPH COMPILATION
// =============================================================================

/**
 * Compiles the LangGraph workflow.
 * Defines edges (conditional routing) to direct traffic based on the 'route' state.
 */
const compileRouterGraph = () => {
  const workflow = new StateGraph(GraphState)
    // Define nodes
    .addNode('classifier', classifyIntent)
    .addNode('billing_agent', billingAgent)
    .addNode('tech_agent', techSupportAgent)
    .addNode('fallback_agent', fallbackHandler)
    
    // Define entry point
    .addEdge(START, 'classifier')

    // Define conditional routing logic
    // The 'classifier' node updates the 'route' key in state.
    // We inspect that key to decide the next node.
    .addConditionalEdges('classifier', (state) => {
      switch (state.route) {
        case 'billing': return 'billing_agent';
        case 'tech': return 'tech_agent';
        default: return 'fallback_agent';
      }
    })

    // Define exit points
    .addEdge('billing_agent', END)
    .addEdge('tech_agent', END)
    .addEdge('fallback_agent', END);

  return workflow.compile();
};

// =============================================================================
// 5. SERVER COMPONENT & ORCHESTRATION
// =============================================================================

/**
 * Main Server Component.
 * Validates input -> Compiles Graph -> Executes Stream -> Renders UI.
 */
export default async function RouterWorkflow({ query }: { query: string }) {
  
  // A. Runtime Validation
  // We parse the input against the Zod schema. If invalid, we catch the error.
  const validation = InputSchema.safeParse({ message: query });

  if (!validation.success) {
    return (
      <div className="p-4 bg-red-50 text-red-700 rounded border border-red-200">
        <strong>Validation Error:</strong> {validation.error.errors[0].message}
      </div>
    );
  }

  // B. Graph Execution
  const graph = compileRouterGraph();
  
  // In a real scenario, we would stream events. Here we invoke for simplicity.
  // The input is passed as the initial state.
  const finalState = await graph.invoke({
    message: validation.data.message,
    response: '',
    route: null,
  });

  // C. Rendering with Suspense
  // While we await the graph execution (simulated), Suspense handles the loading state.
  return (
    <Suspense fallback={<div className="animate-pulse text-gray-500">Analyzing request...</div>}>
      <div className="mt-4 p-4 border rounded-lg bg-gray-50 shadow-sm">
        <div className="text-xs font-bold uppercase text-gray-400 mb-1">
          Router Output: {finalState.route}
        </div>
        <p className="text-gray-800 font-medium">
          {finalState.response}
        </p>
      </div>
    </Suspense>
  );
}
