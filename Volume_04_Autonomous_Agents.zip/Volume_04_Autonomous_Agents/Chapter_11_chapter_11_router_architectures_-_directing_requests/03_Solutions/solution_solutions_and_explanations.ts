/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

import { z } from 'zod';

// 1. Define the Zod Schema
// We define an enum schema for the standard intents.
const IntentEnum = z.enum(['billing', 'technical', 'general']);

// The base schema for the classification result.
const ClassificationSchema = z.object({
  intent: IntentEnum,
  confidence: z.number().min(0).max(1),
  reasoning: z.string(),
});

// Type inference helper
type ClassificationResult = z.infer<typeof ClassificationSchema>;

/**
 * Simulates an intent classification logic using keyword matching.
 * @param input - The raw user query string.
 * @returns A Promise resolving to a validated ClassificationResult.
 */
async function classifyIntent(input: string): Promise<ClassificationResult> {
  // Normalize input
  const lowerInput = input.toLowerCase();
  
  let intent: 'billing' | 'technical' | 'general' = 'general';
  let confidence = 0.5;
  let reasoning = 'No specific keywords detected.';

  // Keyword matching logic
  const billingKeywords = ['invoice', 'bill', 'payment', 'charge', 'subscription'];
  const technicalKeywords = ['error', 'bug', 'crash', 'not working', 'glitch'];

  const hasBilling = billingKeywords.some(k => lowerInput.includes(k));
  const hasTechnical = technicalKeywords.some(k => lowerInput.includes(k));

  if (hasBilling && !hasTechnical) {
    intent = 'billing';
    confidence = 0.95;
    reasoning = 'Detected billing-related keywords (e.g., invoice, payment).';
  } else if (hasTechnical && !hasBilling) {
    intent = 'technical';
    confidence = 0.95;
    reasoning = 'Detected technical-related keywords (e.g., error, bug).';
  } else if (hasBilling && hasTechnical) {
    // Ambiguous case
    intent = 'general'; // Default, but confidence will be low
    confidence = 0.4;
    reasoning = 'Mixed keywords detected (billing and technical).';
  }

  // Construct the raw result object
  const rawResult = {
    intent,
    confidence,
    reasoning,
  };

  // 2. Runtime Validation
  // Parse the result against the Zod schema to ensure validity.
  return ClassificationSchema.parse(rawResult);
}

// --- Interactive Challenge: Handling Ambiguity ---

// Extended Schema to include 'escalate'
const ExtendedSchema = z.object({
  intent: z.enum(['billing', 'technical', 'general', 'escalate']), // Added 'escalate'
  confidence: z.number().min(0).max(1),
  reasoning: z.string(),
});

type ExtendedResult = z.infer<typeof ExtendedSchema>;

async function classifyIntentWithEscalation(input: string): Promise<ExtendedResult> {
  // Reuse the base logic
  const baseResult = await classifyIntent(input);
  
  // Apply the ambiguity rule
  if (baseResult.confidence < 0.6) {
    return ExtendedSchema.parse({
      ...baseResult,
      intent: 'escalate', // Override intent
      reasoning: `Low confidence (${baseResult.confidence}). ${baseResult.reasoning} Escalating.`,
    });
  }

  return ExtendedSchema.parse(baseResult);
}

// --- LangGraph Integration Sketch (Conceptual) ---

/*
import { StateGraph, END, START } from "@langchain/langgraph";

// 1. Define State Interface
interface AgentState {
  query: string;
  classification?: ExtendedResult;
  // ... other state properties
}

// 2. Define Nodes
const classifyNode = async (state: AgentState) => {
  const result = await classifyIntentWithEscalation(state.query);
  return { classification: result };
};

const billingNode = async (state: AgentState) => { /* handle billing */ };
const technicalNode = async (state: AgentState) => { /* handle tech */ };
const generalNode = async (state: AgentState) => { /* handle general */ };
const escalateNode = async (state: AgentState) => { /* escalate to human */ };

// 3. Define Conditional Edges (Routing)
const router = (state: AgentState) => {
  if (!state.classification) return START;
  
  switch (state.classification.intent) {
    case 'billing': return 'billing_node';
    case 'technical': return 'technical_node';
    case 'general': return 'general_node';
    case 'escalate': return 'escalate_node';
    default: return END;
  }
};

// 4. Build Graph
const workflow = new StateGraph<AgentState>()
  .addNode('classify_node', classifyNode)
  .addNode('billing_node', billingNode)
  .addNode('technical_node', technicalNode)
  .addNode('general_node', generalNode)
  .addNode('escalate_node', escalateNode)
  .addEdge(START, 'classify_node')
  .addConditionalEdges('classify_node', router)
  .addEdge('billing_node', END)
  .addEdge('technical_node', END)
  .addEdge('general_node', END)
  .addEdge('escalate_node', END);
*/
