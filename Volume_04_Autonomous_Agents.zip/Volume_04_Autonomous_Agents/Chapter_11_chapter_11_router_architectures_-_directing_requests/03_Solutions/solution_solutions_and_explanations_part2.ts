/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

import { z } from 'zod';

// 1. Tool Definitions & Zod Schemas
const CalculateToolSchema = z.object({
  expression: z.string().regex(/^[\d\s+\-*/().]+$/, "Invalid math expression"),
});

const WeatherToolSchema = z.object({
  location: z.string().min(1, "Location is required"),
  date: z.string().date(), // Validates ISO date format
});

type CalculateTool = z.infer<typeof CalculateToolSchema>;
type WeatherTool = z.infer<typeof WeatherToolSchema>;

// 2. Discriminated Union for Router Output
type ToolSelection = 
  | { type: 'calculate'; payload: CalculateTool }
  | { type: 'weather'; payload: WeatherTool }
  | { type: 'unknown'; payload: null };

/**
 * Analyzes input and routes to the appropriate tool schema.
 */
function routeToTool(input: string): ToolSelection {
  const lowerInput = input.toLowerCase();

  // Route: Calculate
  if (lowerInput.includes('what is') || lowerInput.match(/[\d\+\-\*\/]/)) {
    // Extract expression (simplified logic for demo)
    const expression = input.replace(/what is/i, '').trim();
    
    // Validate with Zod
    const result = CalculateToolSchema.safeParse({ expression });
    if (result.success) {
      return { type: 'calculate', payload: result.data };
    }
  }

  // Route: Weather
  if (lowerInput.includes('weather') || lowerInput.includes('forecast')) {
    // Extract location (simplified)
    const location = input.replace(/weather in|forecast for/i, '').trim() || 'Unknown';
    const date = new Date().toISOString().split('T')[0]; // Default to today

    // Validate with Zod
    const result = WeatherToolSchema.safeParse({ location, date });
    if (result.success) {
      return { type: 'weather', payload: result.data };
    }
  }

  // Fallback
  return { type: 'unknown', payload: null };
}

// 3. Graphviz DOT Diagram
const graphvizDOT = `
digraph G {
    rankdir=LR;
    node [shape=box, style="rounded,filled", fillcolor="lightgrey"];
    
    Router [fillcolor="lightblue"];
    CalculateNode [fillcolor="lightgreen"];
    WeatherNode [fillcolor="lightgreen"];
    ResponseNode [fillcolor="orange"];
    UnknownNode [fillcolor="pink"];

    Router -> CalculateNode [label="type='calculate'"];
    Router -> WeatherNode [label="type='weather'"];
    Router -> UnknownNode [label="type='unknown'"];
    
    CalculateNode -> ResponseNode;
    WeatherNode -> ResponseNode;
    UnknownNode -> ResponseNode;
    
    // Styling for clarity
    { rank=same; CalculateNode; WeatherNode; UnknownNode }
}
`;

console.log("Graphviz DOT Code:\n", graphvizDOT);
