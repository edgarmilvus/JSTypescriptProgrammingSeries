/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

'use client';

import React, { useState, useEffect } from 'react';
import { z } from 'zod';

// 1. Zod Schema for Stream Validation
const StepSchema = z.object({
  node: z.string(),
  status: z.enum(['running', 'complete', 'error']),
  result: z.string().optional(),
});

type Step = z.infer<typeof StepSchema>;

// 2. Mock Async Generator
async function* simulateRoutingStream(query: string): AsyncGenerator<Step> {
  yield { node: 'Classifier', status: 'running' };
  await new Promise(r => setTimeout(r, 500)); // Simulate network delay
  
  yield { node: 'Classifier', status: 'complete', result: 'billing' };
  await new Promise(r => setTimeout(r, 500));

  yield { node: 'BillingNode', status: 'running' };
  await new Promise(r => setTimeout(r, 800));

  yield { node: 'BillingNode', status: 'complete', result: 'Invoice #123 sent' };
}

// 3. The React Component
export default function RouterUI({ query }: { query: string }) {
  const [steps, setSteps] = useState<Step[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const consumeStream = async () => {
      const stream = simulateRoutingStream(query);
      
      for await (const chunk of stream) {
        // 4. Runtime Validation of Stream Chunk
        try {
          const validatedStep = StepSchema.parse(chunk);
          setSteps(prev => [...prev, validatedStep]);
        } catch (err) {
          setError("Routing Error: Received invalid data stream.");
          // Stop processing on invalid data
          break;
        }
      }
      setLoading(false);
    };

    consumeStream();
  }, [query]);

  if (loading && steps.length === 0) {
    // Suspense-like loading state
    return (
      <div className="p-4 border rounded-lg bg-gray-50">
        <div className="animate-pulse flex space-x-4">
          <div className="rounded-full bg-slate-200 h-10 w-10"></div>
          <div className="flex-1 space-y-2 py-1">
            <div className="h-2 bg-slate-200 rounded"></div>
          </div>
        </div>
        <p className="mt-2 text-sm text-gray-500">Initializing Router...</p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="p-4 border border-red-500 bg-red-50 text-red-700 rounded-lg">
        {error}
      </div>
    );
  }

  return (
    <div className="p-4 border rounded-lg bg-white shadow-sm max-w-md">
      <h3 className="font-bold mb-3 text-gray-800">Routing Execution</h3>
      <ul className="space-y-3">
        {steps.map((step, index) => (
          <li key={index} className="flex items-center gap-3">
            {/* Status Indicator */}
            <div 
              className={`w-3 h-3 rounded-full ${
                step.status === 'running' 
                  ? 'bg-yellow-400 animate-pulse' 
                  : step.status === 'complete' 
                  ? 'bg-green-500' 
                  : 'bg-red-500'
              }`}
            ></div>
            
            {/* Step Details */}
            <div className="flex-1">
              <div className="text-sm font-medium text-gray-900">
                Node: {step.node}
              </div>
              <div className="text-xs text-gray-500 capitalize">
                Status: {step.status}
              </div>
              {step.result && (
                <div className="text-xs text-blue-600 mt-1">
                  Result: {step.result}
                </div>
              )}
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
}

// Usage Example (Parent Component)
// <RouterUI query="Check billing for invoice 123" />
