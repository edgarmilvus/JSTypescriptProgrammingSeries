/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

import { z } from 'zod';

// 1. State Management Interface
interface RouterState {
  currentTier: 'Tier1' | 'Tier2' | 'Escalated';
  retryCount: number;
  resolutionStatus: 'pending' | 'resolved' | 'failed';
  originalRequest: string;
}

// 2. Escalation Payload Schema
const EscalationSchema = z.object({
  originalRequest: z.string().min(1),
  retryHistory: z.array(z.number()), // Array of retry timestamps or counts
  reason: z.string(),
  priority: z.enum(['High', 'Medium', 'Low']),
});

type EscalationPayload = z.infer<typeof EscalationSchema>;

/**
 * 3. Calculates Escalation Priority based on state.
 */
function calculateEscalationPriority(state: RouterState): 'High' | 'Medium' | 'Low' {
  const inputLength = state.originalRequest.length;
  
  // Logic: High priority if many retries OR very long input (complex issue)
  if (state.retryCount >= 3) return 'High';
  if (inputLength > 200 && state.retryCount > 1) return 'Medium';
  return 'Low';
}

/**
 * Simulates the routing logic for a single step.
 */
function processRequestStep(state: RouterState): RouterState | EscalationPayload {
  // --- Routing Logic ---
  
  // Case 1: Tier 1 Success
  if (state.currentTier === 'Tier1' && state.resolutionStatus === 'resolved') {
    console.log("Tier 1 Resolved. Ending workflow.");
    return state; // End state
  }

  // Case 2: Tier 2 Retry Loop
  if (state.currentTier === 'Tier2' && state.resolutionStatus === 'failed') {
    if (state.retryCount < 3) {
      // Retry: Increment count and reset status for next loop
      console.log(`Retrying Tier 2 request (Attempt ${state.retryCount + 1})...`);
      return {
        ...state,
        retryCount: state.retryCount + 1,
        resolutionStatus: 'pending', // Reset to pending to process again
      };
    }
  }

  // Case 3: Escalation (Tier 2 failed and retries exhausted)
  if (state.currentTier === 'Tier2' && state.resolutionStatus === 'failed' && state.retryCount >= 3) {
    console.log("Max retries reached. Escalating...");
    
    const priority = calculateEscalationPriority(state);
    
    const payload = {
      originalRequest: state.originalRequest,
      retryHistory: Array.from({ length: state.retryCount }, (_, i) => i + 1),
      reason: "Failed to resolve Tier 2 request after 3 attempts.",
      priority: priority,
    };

    // Validate Payload before sending
    try {
      const validatedPayload = EscalationSchema.parse(payload);
      return validatedPayload; // This would be sent to the Human Agent system
    } catch (error) {
      throw new Error(`Escalation payload validation failed: ${error}`);
    }
  }

  return state;
}

// Example Usage Simulation
const initialState: RouterState = {
  currentTier: 'Tier2',
  retryCount: 2, // Already tried twice
  resolutionStatus: 'failed',
  originalRequest: "System crash on login page with error code 500.",
};

// Run the step (this should trigger the 3rd retry)
const result = processRequestStep(initialState);

if ('priority' in result) {
  console.log("Escalation Object:", result);
} else {
  console.log("Updated State:", result);
}
