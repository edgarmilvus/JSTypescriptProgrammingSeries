/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

import { z } from 'zod';

// 1. State Definition
interface ContentState {
  step: 'outline' | 'draft' | 'review' | 'final';
  content: {
    outline?: string;
    draft?: string;
    feedback?: string;
  };
  revisionCount: number;
}

// 2. User Input Validation Schema
const UserInputSchema = z.string().min(1, "User input cannot be empty");

/**
 * 3. Router Function to determine next step.
 */
function determineNextStep(currentState: ContentState, userInput?: string): ContentState {
  const nextState = { ...currentState };

  // Validate Input if required
  if (['review'].includes(currentState.step)) {
    if (!userInput) throw new Error("Feedback required for review step.");
    
    const validation = UserInputSchema.safeParse(userInput);
    if (!validation.success) {
      // Handle validation error (e.g., return state with error flag)
      console.error(validation.error);
      return currentState; 
    }
  }

  // --- Routing Logic ---

  // Transition: Outline -> Draft
  if (currentState.step === 'outline') {
    nextState.step = 'draft';
    nextState.content.draft = `Generated Draft based on outline: ${currentState.content.outline}`;
    console.log("Generated Draft.");
    return nextState;
  }

  // Transition: Draft -> Review
  if (currentState.step === 'draft') {
    nextState.step = 'review';
    console.log("Moved to Review.");
    return nextState;
  }

  // Transition: Review -> Final OR Review -> Draft (Loop)
  if (currentState.step === 'review' && userInput) {
    const lowerInput = userInput.toLowerCase();

    if (lowerInput.includes("approve")) {
      // Exit Condition: Approved
      nextState.step = 'final';
      console.log("Approved. Moving to Final.");
      return nextState;
    }

    if (lowerInput.includes("revise")) {
      // Loop Condition: Revision requested
      if (currentState.revisionCount > 2) {
        // Exit Condition: Max revisions reached
        nextState.step = 'final';
        nextState.content.feedback = "Warning: Max revisions reached. Forced to final.";
        console.log("Max revisions exceeded. Forced Final.");
      } else {
        // Loop back to Draft
        nextState.step = 'draft';
        nextState.revisionCount += 1;
        nextState.content.feedback = userInput;
        console.log(`Revision requested. Looping back to Draft (Count: ${nextState.revisionCount}).`);
      }
      return nextState;
    }
  }

  return nextState;
}

// 4. Graph Visualization (DOT)
const workflowDOT = `
digraph G {
    rankdir=TB;
    node [shape=box, style="rounded,filled", fillcolor="lightgrey"];
    
    Start [label="Start (Outline)", fillcolor="lightblue"];
    Draft [fillcolor="lightyellow"];
    Review [fillcolor="lightcyan"];
    Final [fillcolor="lightgreen", shape="doublecircle"];
    End [label="End", shape="point"];

    Start -> Draft [label="Generate"];
    Draft -> Review [label="Submit"];
    
    // The Loop
    Review -> Draft [label="Feedback: 'Revise' \n (RevisionCount < 3)"];
    
    // Exits
    Review -> Final [label="Feedback: 'Approve'"];
    Review -> Final [label="RevisionCount > 2 \n (Forced Final)"];
    
    Final -> End;
}
`;

console.log("Workflow DOT Code:\n", workflowDOT);
