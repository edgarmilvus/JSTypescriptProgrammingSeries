/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

// Import necessary modules from LangGraph and LangChain
import { StateGraph, Annotation, END, START } from "@langchain/langgraph";
import { ChatOpenAI } from "@langchain/openai";

// ==========================================
// 1. Define the Shared State Interface
// ==========================================

/**
 * Represents the shared state flowing through the graph.
 * @property {string} userRequest - The raw input from the SaaS dashboard.
 * @property {string} nextAgent - The decision made by the supervisor (e.g., 'billing', 'tech_support', 'FINISH').
 * @property {string} finalResponse - The aggregated result from the worker agents.
 */
const StateAnnotation = Annotation.Root({
  userRequest: Annotation<string>({
    reducer: (curr, update) => update, // Simply replace with the new request
    default: () => "",
  }),
  nextAgent: Annotation<string>({
    reducer: (curr, update) => update,
    default: () => "",
  }),
  finalResponse: Annotation<string>({
    reducer: (curr, update) => curr + "\n" + update, // Accumulate responses if needed
    default: () => "",
  }),
});

// Initialize the LLM (Ensure OPENAI_API_KEY is in your environment)
const llm = new ChatOpenAI({ model: "gpt-3.5-turbo", temperature: 0 });

// ==========================================
// 2. Define the Supervisor Node (The Router)
// ==========================================

/**
 * Supervisor Node: Analyzes the request and decides which worker to invoke.
 * It uses function calling (or structured output) to enforce a valid JSON decision.
 */
const supervisorNode = async (state: typeof StateAnnotation.State) => {
  // System prompt defining the supervisor's role and available tools
  const systemPrompt = `
    You are a supervisor managing a SaaS customer support team. 
    You are responsible for routing the user's request to the correct agent.
    
    Available Agents:
    1. billing: Handles refunds, invoice generation, and payment issues.
    2. tech_support: Handles login errors, bugs, and feature requests.
    3. FINISH: Use this if the request is a general greeting or doesn't fit the above categories.

    The user request is: "${state.userRequest}"

    Respond strictly with JSON containing the key "nextAgent" with the value being the name of the agent or "FINISH".
    Example: { "nextAgent": "billing" }
  `;

  const response = await llm.invoke(systemPrompt);

  // Parse the LLM response to extract the decision
  // NOTE: In production, use .bindTools() or structured output parsing for reliability.
  // For this "Hello World", we parse the string content.
  let content = response.content as string;
  
  try {
    // Clean up potential markdown code blocks from LLM response
    const jsonMatch = content.match(/\{.*\}/s);
    if (jsonMatch) {
      const decision = JSON.parse(jsonMatch[0]);
      return { nextAgent: decision.nextAgent };
    }
    // Fallback if JSON parsing fails
    return { nextAgent: "FINISH" };
  } catch (e) {
    console.error("Supervisor failed to parse JSON:", e);
    return { nextAgent: "FINISH" };
  }
};

// ==========================================
// 3. Define Worker Nodes
// ==========================================

/**
 * Billing Agent: Simulates processing a billing request.
 */
const billingNode = async (state: typeof StateAnnotation.State) => {
  // Simulate an API call or database lookup
  const response = `[Billing System]: Processed refund for request: "${state.userRequest}". Transaction ID: TX-9921.`;
  return { finalResponse: response };
};

/**
 * Technical Support Agent: Simulates processing a technical issue.
 */
const techSupportNode = async (state: typeof StateAnnotation.State) => {
  // Simulate a diagnostic tool call
  const response = `[Tech Support]: Diagnosed issue for request: "${state.userRequest}". Solution: Clear cache and retry login.`;
  return { finalResponse: response };
};

// ==========================================
// 4. Define Conditional Edges (Routing Logic)
// ==========================================

/**
 * Determines the next node based on the supervisor's decision.
 * This is the logic that connects the Supervisor to the correct Worker.
 */
const routeSupervisorDecision = (state: typeof StateAnnotation.State) => {
  const decision = state.nextAgent;
  
  if (decision === "billing") {
    return "billing_agent";
  } else if (decision === "tech_support") {
    return "tech_support_agent";
  }
  
  // If decision is 'FINISH' or unrecognized, go to END
  return END;
};

// ==========================================
// 5. Construct the Graph
// ==========================================

// Initialize the graph with the shared state
const workflow = new StateGraph(StateAnnotation);

// Add nodes
workflow.addNode("supervisor", supervisorNode);
workflow.addNode("billing_agent", billingNode);
workflow.addNode("tech_support_agent", techSupportNode);

// Define the entry point
workflow.addEdge(START, "supervisor");

// Add conditional edges from the supervisor
// The supervisor node does not have a direct edge to END or other nodes.
// Instead, we use a conditional edge function to route dynamically.
workflow.addConditionalEdges(
  "supervisor",
  routeSupervisorDecision,
  {
    "billing_agent": "billing_agent",
    "tech_support_agent": "tech_support_agent",
    [END]: END
  }
);

// Add edges from workers back to END (Terminal nodes)
workflow.addEdge("billing_agent", END);
workflow.addEdge("tech_support_agent", END);

// Compile the graph
const app = workflow.compile();

// ==========================================
// 6. Execution (SaaS API Handler Simulation)
// ==========================================

/**
 * Main function simulating an API endpoint (e.g., POST /api/chat).
 */
async function runSaaSWorkflow(userInput: string) {
  console.log(`\n--- Processing Request: "${userInput}" ---`);
  
  // Initial state setup
  const initialState = {
    userRequest: userInput,
    nextAgent: "",
    finalResponse: "",
  };

  // Stream execution for real-time updates (common in Vercel/AI SDK apps)
  const stream = await app.streamEvents(initialState, { version: "v2" });

  for await (const event of stream) {
    const eventType = event.event;
    const nodeName = event.metadata?.langgraph_node;
    
    // Log supervisor decisions
    if (nodeName === "supervisor" && eventType === "on_chain_end") {
      console.log(`[Supervisor]: Decided to route to -> ${event.data.output.nextAgent}`);
    }
    
    // Log worker responses
    if ((nodeName === "billing_agent" || nodeName === "tech_support_agent") && eventType === "on_chain_end") {
      console.log(`[Worker ${nodeName}]: ${event.data.output.finalResponse}`);
    }
  }
}

// --- Run Examples ---

// Example 1: Billing Request
runSaaSWorkflow("I want a refund for my order #12345");

// Example 2: Technical Request
// (Uncomment to run)
// runSaaSWorkflow("My login button is not working.");
