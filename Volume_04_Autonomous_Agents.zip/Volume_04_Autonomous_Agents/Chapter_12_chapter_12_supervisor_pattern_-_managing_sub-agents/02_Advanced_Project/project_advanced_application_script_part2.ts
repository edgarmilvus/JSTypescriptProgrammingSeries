/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script_part2.ts
// Description: Advanced Application Script
// ==========================================

// app/api/chat/route.ts
import { NextRequest } from 'next/server';
import { StreamData, StreamingTextResponse } from 'ai';
import { ChatOpenAI } from '@langchain/openai';
import { StateGraph, START, END, Annotation, addConditionalEdges } from '@langchain/langgraph';
import { z } from 'zod';

// ============================================================================
// 1. STATE DEFINITION
// ============================================================================

/**
 * Defines the shared state structure for the graph.
 * This allows every node (agent) to access and modify the conversation context.
 */
const StateAnnotation = Annotation.Root({
  // The full history of messages in the conversation
  messages: Annotation<string[]>({
    reducer: (curr, update) => [...curr, ...update],
    default: () => [],
  }),
  // The decision made by the supervisor: 'billing', 'technical', or 'final'
  nextAgent: Annotation<'billing' | 'technical' | 'final' | null>({
    reducer: (curr, update) => update ?? curr,
    default: () => null,
  }),
});

// Initialize the LLM (GPT-4 Turbo)
const llm = new ChatOpenAI({
  model: 'gpt-4-turbo-preview',
  temperature: 0,
});

// ============================================================================
// 2. AGENT NODES
// ============================================================================

/**
 * Supervisor Node: Analyzes the user's intent and routes the task.
 * It uses function calling (or structured output) to decide the next step.
 */
async function supervisorNode(state: typeof StateAnnotation.State) {
  const systemPrompt = `
    You are a customer support supervisor. Analyze the user's latest request.
    Determine if it is related to 'Billing' or 'Technical Support'.
    If the request is a simple greeting or closing, route to 'final'.
    Respond ONLY with the name of the agent to route to: 'billing', 'technical', or 'final'.
  `;

  const response = await llm.invoke([
    { role: 'system', content: systemPrompt },
    { role: 'user', content: state.messages[state.messages.length - 1] }
  ]);

  // Extract the decision (cleaning up the response string)
  const decision = response.content.toString().toLowerCase().trim();
  
  let next: 'billing' | 'technical' | 'final' = 'final';
  if (decision.includes('billing')) next = 'billing';
  else if (decision.includes('technical')) next = 'technical';

  return { nextAgent: next };
}

/**
 * Billing Agent Node: Handles specific billing logic.
 * In a real app, this would query a database or payment API.
 */
async function billingAgent(state: typeof StateAnnotation.State) {
  const lastMessage = state.messages[state.messages.length - 1];
  
  // Simulate fetching billing data
  const billingContext = "User has an outstanding invoice #12345 for $50.00.";
  
  const response = await llm.invoke([
    { role: 'system', content: `You are a Billing Agent. Context: ${billingContext}. Answer the user's question concisely.` },
    { role: 'user', content: lastMessage }
  ]);

  return { messages: [response.content.toString()] };
}

/**
 * Technical Support Agent Node: Handles specific technical issues.
 * In a real app, this might query logs or documentation.
 */
async function technicalAgent(state: typeof StateAnnotation.State) {
  const lastMessage = state.messages[state.messages.length - 1];
  
  // Simulate fetching technical documentation
  const techContext = "Known issue: Error 500 occurs if the API key is expired.";
  
  const response = await llm.invoke([
    { role: 'system', content: `You are a Technical Support Agent. Context: ${techContext}. Answer the user's question concisely.` },
    { role: 'user', content: lastMessage }
  ]);

  return { messages: [response.content.toString()] };
}

/**
 * Finalizer Node: Formats the response for the user.
 * This is useful for cleaning up internal logic before sending to the client.
 */
async function finalizerNode(state: typeof StateAnnotation.State) {
  const lastMessage = state.messages[state.messages.length - 1];
  
  // If we came from a specialized agent, we might want to add a sign-off.
  const response = await llm.invoke([
    { role: 'system', content: "Summarize the previous answer into a friendly, final customer support response." },
    { role: 'user', content: lastMessage }
  ]);

  return { messages: [response.content.toString()] };
}

// ============================================================================
// 3. GRAPH CONSTRUCTION
// ============================================================================

// Initialize the StateGraph
const workflow = new StateGraph(StateAnnotation);

// Add nodes to the graph
workflow.addNode('supervisor', supervisorNode);
workflow.addNode('billing', billingAgent);
workflow.addNode('technical', technicalAgent);
workflow.addNode('final', finalizerNode);

// Define the control flow
workflow.addEdge(START, 'supervisor');

// Conditional Edge Logic: Where to go next based on 'nextAgent' in state
const router = (state: typeof StateAnnotation.State) => {
  if (state.nextAgent === 'billing') return 'billing';
  if (state.nextAgent === 'technical') return 'technical';
  if (state.nextAgent === 'final') return 'final';
  return END; // Fallback
};

// Connect supervisor to the appropriate agents
workflow.addConditionalEdges('supervisor', router);

// Once agents finish, route back to the supervisor (or end) to handle next user input
// In a continuous chat, we usually loop back to supervisor to analyze the next turn.
workflow.addEdge('billing', 'supervisor');
workflow.addEdge('technical', 'supervisor');
workflow.addEdge('final', END);

// Compile the graph
const app = workflow.compile();

// ============================================================================
// 4. NEXT.JS API ROUTE HANDLER
// ============================================================================

export async function POST(req: NextRequest) {
  const { messages } = await req.json();

  // Initialize StreamData for metadata
  const streamData = new StreamData();
  
  // Prepare initial state (append new user message)
  const initialState = {
    messages: [messages[messages.length - 1].content], // Only sending latest for this demo
    nextAgent: null,
  };

  try {
    // Run the graph stream
    const stream = await app.streamEvents(initialState, {
      version: 'v2',
    });

    const textEncoder = new TextEncoder();
    const readableStream = new ReadableStream({
      async start(controller) {
        for await (const event of stream) {
          // We only want to stream the final text output to the user
          if (event.event === 'on_chat_model_end') {
            // Check if this is the finalizer node or the specialized agent
            // In this setup, we stream the content from the 'final' node
            const content = event.data.output.content;
            if (content) {
              controller.enqueue(textEncoder.encode(content));
            }
          }
        }
        controller.close();
        streamData.close();
      },
    });

    return new StreamingTextResponse(readableStream, {}, streamData);
  } catch (error) {
    console.error('Supervisor Graph Error:', error);
    return new Response('Error processing request', { status: 500 });
  }
}
