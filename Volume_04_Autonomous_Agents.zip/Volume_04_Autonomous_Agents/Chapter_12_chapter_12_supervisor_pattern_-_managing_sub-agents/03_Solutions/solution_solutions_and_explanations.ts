/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

import { StateGraph, Annotation, END, START, LangGraphRunnableConfig } from "@langchain/langgraph";
import { ChatOpenAI } from "@langchain/openai";

// 1. Define State and Worker Agents
const StateAnnotation = Annotation.Root({
  userQuery: Annotation<string>,
  // The supervisor will populate this
  routingDecision: Annotation<{
    target_agent: "BillingAgent" | "TechnicalSupportAgent" | "GeneralInfoAgent";
    reasoning: string;
    parameters: { user_query: string; priority: "low" | "medium" | "high" };
  } | null>,
  // The worker agents will populate this
  finalResponse: Annotation<string>
});

const llm = new ChatOpenAI({ model: "gpt-4o-mini" });

// Worker Agents
const billingAgent = async (state: typeof StateAnnotation.State) => {
  console.log("-> Billing Agent Processing...");
  // Simulate processing
  return { finalResponse: `Billing Resolution: Processed query "${state.routingDecision?.parameters.user_query}" with priority ${state.routingDecision?.parameters.priority}.` };
};

const techSupportAgent = async (state: typeof StateAnnotation.State) => {
  console.log("-> Tech Support Agent Processing...");
  return { finalResponse: `Tech Support Resolution: Addressed technical issue "${state.routingDecision?.parameters.user_query}".` };
};

const generalInfoAgent = async (state: typeof StateAnnotation.State) => {
  console.log("-> General Info Agent Processing...");
  return { finalResponse: `General Info: Provided information regarding "${state.routingDecision?.parameters.user_query}".` };
};

// 2. Supervisor Node (Structured Output)
const supervisorNode = async (state: typeof StateAnnotation.State, config: LangGraphRunnableConfig) => {
  // Define the JSON schema for structured output
  const structuredLlm = llm.withStructuredOutput({
    name: "routing_decision",
    description: "Routes the user query to the appropriate agent.",
    parameters: {
      type: "object",
      properties: {
        target_agent: {
          type: "string",
          enum: ["BillingAgent", "TechnicalSupportAgent", "GeneralInfoAgent"]
        },
        reasoning: { type: "string" },
        parameters: {
          type: "object",
          properties: {
            user_query: { type: "string" },
            priority: { type: "string", enum: ["low", "medium", "high"] }
          },
          required: ["user_query", "priority"]
        }
      },
      required: ["target_agent", "reasoning", "parameters"]
    }
  });

  const prompt = `Classify the following user query: "${state.userQuery}". Determine priority and target agent.`;
  
  const decision = await structuredLlm.invoke(prompt);
  
  return { routingDecision: decision };
};

// 3. Conditional Edges
const router = (state: typeof StateAnnotation.State) => {
  if (!state.routingDecision) return END;
  const target = state.routingDecision.target_agent;
  
  if (target === "BillingAgent") return "billingAgent";
  if (target === "TechnicalSupportAgent") return "techSupportAgent";
  if (target === "GeneralInfoAgent") return "generalInfoAgent";
  
  return END;
};

// 4. Graph Construction
const graph = new StateGraph(StateAnnotation)
  .addNode("supervisor", supervisorNode)
  .addNode("billingAgent", billingAgent)
  .addNode("techSupportAgent", techSupportAgent)
  .addNode("generalInfoAgent", generalInfoAgent)
  .addEdge(START, "supervisor")
  .addConditionalEdges("supervisor", router)
  .addEdge("billingAgent", END)
  .addEdge("techSupportAgent", END)
  .addEdge("generalInfoAgent", END)
  .compile();

// Example Execution
(async () => {
  const result = await graph.invoke({ userQuery: "I need to dispute a charge on my credit card immediately." });
  console.log("\nFinal State:", result.finalResponse);
})();
