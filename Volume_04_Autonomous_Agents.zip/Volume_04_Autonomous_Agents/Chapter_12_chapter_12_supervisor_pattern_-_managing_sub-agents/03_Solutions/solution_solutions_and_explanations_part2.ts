/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

import { StateGraph, Annotation, END, START } from "@langchain/langgraph";

// 1. Define State
const StateAnnotation = Annotation.Root({
  draft: Annotation<string>,
  feedback: Annotation<string>,
  score: Annotation<number>,
  iteration: Annotation<number>({ default: 0 }),
  maxIterations: Annotation<number>({ default: 3 }) // Safety limit
});

// 2. Worker Agents (Simulated)
const writerAgent = async (state: typeof StateAnnotation.State) => {
  const context = state.feedback ? `Previous feedback: ${state.feedback}.` : "Write a creative intro.";
  console.log(`[Writer] Iteration ${state.iteration + 1}: Generating draft...`);
  // In a real scenario, this calls an LLM
  return { draft: `Draft v${state.iteration + 1} based on: ${context}`, iteration: state.iteration + 1 };
};

const editorAgent = async (state: typeof StateAnnotation.State) => {
  console.log("[Editor] Reviewing draft...");
  // Simulate logic: score decreases slightly each iteration to force a loop, then improves
  const score = state.iteration === 1 ? 5 : 9; 
  
  if (score >= 8) {
    return { score: score, feedback: "Approved." };
  } else {
    return { score: score, feedback: "Needs more detail and better flow." };
  }
};

// 3. Conditional Edges
const qualityCheck = (state: typeof StateAnnotation.State) => {
  // Safety Break: Check iteration limit first
  if (state.iteration >= state.maxIterations) {
    console.log("Max iterations reached. Forcing exit.");
    return "finalizer";
  }

  if (state.score < 8) {
    return "writerAgent"; // Loop back
  }
  return "finalizer";
};

// 4. Finalizer Node
const finalizerAgent = async (state: typeof StateAnnotation.State) => {
  return { draft: `[FINAL] ${state.draft} (Score: ${state.score})` };
};

// 5. Graph Construction
const graph = new StateGraph(StateAnnotation)
  .addNode("writerAgent", writerAgent)
  .addNode("editorAgent", editorAgent)
  .addNode("finalizer", finalizerAgent)
  .addEdge(START, "writerAgent")
  .addEdge("writerAgent", "editorAgent")
  .addConditionalEdges("editorAgent", qualityCheck)
  .addEdge("finalizer", END)
  .compile();

// Execution
(async () => {
  const result = await graph.invoke({ draft: "", feedback: "", score: 0, iteration: 0 });
  console.log("\nFinal Result:", result.draft);
})();
