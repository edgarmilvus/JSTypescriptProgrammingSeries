/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState } from 'react';

// Types
interface SupervisorDecision {
  target_agent: string;
  reasoning: string;
  parameters: { user_query: string; priority: string };
}

interface ChatState {
  query: string;
  supervisorDecision: SupervisorDecision | null;
  workerResponse: string | null;
  status: 'idle' | 'processing' | 'finished';
}

export default function SupervisorChat() {
  const [state, setState] = useState<ChatState>({
    query: "",
    supervisorDecision: null,
    workerResponse: null,
    status: 'idle'
  });

  // 4. Interactive Challenge: Simulate Supervisor Logic
  const handleSimulate = async () => {
    if (!state.query) return;

    // Reset
    setState(prev => ({ ...prev, status: 'processing', supervisorDecision: null, workerResponse: null }));

    // Step 1: Simulate Supervisor Thinking (Structured Output)
    await new Promise(r => setTimeout(r, 800)); // Fake network delay
    
    const mockDecision: SupervisorDecision = {
      target_agent: "BillingAgent",
      reasoning: "User mentioned 'charge' and 'credit card', indicating a billing issue.",
      parameters: { user_query: state.query, priority: "high" }
    };

    setState(prev => ({ ...prev, supervisorDecision: mockDecision }));

    // Step 2: Simulate Worker Agent Response
    await new Promise(r => setTimeout(r, 1000)); // Worker processing time
    
    setState(prev => ({ 
      ...prev, 
      workerResponse: "BillingAgent: I have located the disputed charge. Initiating refund process.",
      status: 'finished'
    }));
  };

  return (
    <div style={{ padding: '20px', fontFamily: 'sans-serif' }}>
      <h3>Supervisor Pattern Visualization</h3>
      
      {/* Input */}
      <div style={{ marginBottom: '20px' }}>
        <input 
          type="text" 
          placeholder="Enter user query..."
          value={state.query}
          onChange={(e) => setState(prev => ({ ...prev, query: e.target.value }))}
          style={{ padding: '8px', width: '300px' }}
        />
        <button 
          onClick={handleSimulate} 
          disabled={state.status === 'processing'}
          style={{ marginLeft: '10px', padding: '8px 16px' }}
        >
          {state.status === 'processing' ? 'Thinking...' : 'Simulate Supervisor'}
        </button>
      </div>

      {/* 3. Decision Card Rendering */}
      {state.supervisorDecision && (
        <div style={{ border: '1px solid #ccc', padding: '15px', borderRadius: '8px', background: '#f9f9f9', marginBottom: '10px' }}>
          <h4 style={{ margin: '0 0 10px 0', color: '#333' }}>Supervisor Decision</h4>
          <div style={{ display: 'grid', gridTemplateColumns: '120px 1fr', gap: '10px', fontSize: '14px' }}>
            <strong>Target:</strong> <span style={{ color: 'blue' }}>{state.supervisorDecision.target_agent}</span>
            <strong>Reasoning:</strong> <span>{state.supervisorDecision.reasoning}</span>
            <strong>Priority:</strong> <span>{state.supervisorDecision.parameters.priority}</span>
          </div>
        </div>
      )}

      {/* 3. Worker Response & Status Indicator */}
      {state.status === 'processing' && !state.workerResponse && (
        <div style={{ color: '#666', fontStyle: 'italic' }}>
          Waiting for Worker Agent response...
        </div>
      )}

      {state.workerResponse && (
        <div style={{ border: '1px solid #4CAF50', padding: '15px', borderRadius: '8px', background: '#e8f5e9' }}>
          <strong>Worker Response:</strong>
          <p>{state.workerResponse}</p>
        </div>
      )}
    </div>
  );
}
