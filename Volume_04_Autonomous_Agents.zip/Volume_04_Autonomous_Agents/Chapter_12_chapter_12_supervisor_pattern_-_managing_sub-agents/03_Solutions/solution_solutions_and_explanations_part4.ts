/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

import { StateGraph, Annotation, END, START, LangGraphRunnableConfig } from "@langchain/langgraph";
import { ChatOpenAI } from "@langchain/openai";

// 1. Global State
const GlobalStateAnnotation = Annotation.Root({
  userQuery: Annotation<string>,
  rawData: Annotation<Array<{ date: string, value: number }>>,
  analysisResults: Annotation<string>,
  chartConfig: Annotation<{ type: string, title: string }>
});

// 2. Worker Agents (Accepting specific Context)
const dataAnalysisAgent = async (state: { rawData: Array<{ date: string, value: number }> }) => {
  // This agent only knows about data, not the query or chart config
  const sum = state.rawData.reduce((acc, curr) => acc + curr.value, 0);
  return { analysisResults: `Calculated sum of values: ${sum}` };
};

const visualizationAgent = async (state: { analysisResults: string, chartConfig: { type: string, title: string } }) => {
  // This agent knows results and config, but not raw data
  return { chartConfig: { ...state.chartConfig, title: `${state.chartConfig.title} - Processed` } };
};

// 3. Supervisor Node (Context Extraction)
const supervisorNode = async (state: typeof GlobalStateAnnotation.State, config: LangGraphRunnableConfig) => {
  const llm = new ChatOpenAI({ model: "gpt-4o-mini" });
  
  // Determine intent
  const intentCheck = await llm.invoke(`Is this query about analysis or visualization? Query: "${state.userQuery}"`);
  const isAnalysis = intentCheck.content.toString().toLowerCase().includes("analysis");

  if (isAnalysis) {
    // Route to Analysis, passing ONLY rawData
    // In a real graph, we might return a special property like `_context` 
    // that the graph builder uses to construct the next node input.
    // Here, we simulate by returning a flag that the router uses to trigger the node.
    return { next: "dataAnalysisAgent", context: { rawData: state.rawData } };
  } else {
    // Route to Visualization, passing AnalysisResults + Config
    return { next: "visualizationAgent", context: { analysisResults: state.analysisResults, chartConfig: state.chartConfig } };
  }
};

// 4. Graph Construction with Context Injection
// Note: LangGraph nodes receive the full state by default. 
// To isolate, we wrap the agents to extract what they need before calling them.
const wrappedAnalysisAgent = async (state: typeof GlobalStateAnnotation.State) => {
  // Isolation: Extract only what is needed
  return await dataAnalysisAgent({ rawData: state.rawData });
};

const wrappedVisualizationAgent = async (state: typeof GlobalStateAnnotation.State) => {
  // Isolation: Extract only what is needed
  return await visualizationAgent({ analysisResults: state.analysisResults, chartConfig: state.chartConfig });
};

// Router logic
const router = (state: typeof GlobalStateAnnotation.State) => {
  if (state.analysisResults) return "visualizationAgent";
  return "dataAnalysisAgent";
};

const graph = new StateGraph(GlobalStateAnnotation)
  .addNode("dataAnalysisAgent", wrappedAnalysisAgent)
  .addNode("visualizationAgent", wrappedVisualizationAgent)
  .addEdge(START, "dataAnalysisAgent") // Simplified entry for demo
  .addEdge("dataAnalysisAgent", "visualizationAgent")
  .addEdge("visualizationAgent", END)
  .compile();

// Execution
(async () => {
  const result = await graph.invoke({
    userQuery: "Analyze data and visualize it",
    rawData: [{ date: "2023-01", value: 100 }, { date: "2023-02", value: 200 }],
    analysisResults: "", // Empty initially
    chartConfig: { type: "bar", title: "Sales" }
  });
  console.log("Final Analysis:", result.analysisResults);
  console.log("Final Chart Config:", result.chartConfig);
})();
