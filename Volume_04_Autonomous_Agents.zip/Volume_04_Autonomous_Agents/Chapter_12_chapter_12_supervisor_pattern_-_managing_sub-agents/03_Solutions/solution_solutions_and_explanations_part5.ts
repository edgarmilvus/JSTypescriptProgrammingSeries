/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

import { StateGraph, Annotation, END, START } from "@langchain/langgraph";

// 1. Define State with Error Tracking
const StateAnnotation = Annotation.Root({
  input: Annotation<string>,
  result: Annotation<string>,
  error: Annotation<string | null>,
  retryCount: Annotation<number>({ default: 0 }),
  maxRetries: Annotation<number>({ default: 2 })
});

// 2. Worker Agent (Simulates Failure)
const unstableWorker = async (state: typeof StateAnnotation.State) => {
  // Fail if retry count is less than max (simulating eventual success)
  if (state.retryCount < state.maxRetries) {
    // Simulate an API error or invalid output
    throw new Error("API Timeout: Service unavailable");
  }
  
  // Success case
  return { result: `Success after ${state.retryCount} retries.` };
};

// 3. Supervisor/Router Node (Error Handler)
const errorHandlerNode = async (state: typeof StateAnnotation.State) => {
  // We enter this node because the previous edge detected an error or exception
  console.log(`[ErrorHandler] Caught error: ${state.error}. Retry attempt: ${state.retryCount}`);

  if (state.retryCount < state.maxRetries) {
    // Decision: Retry
    console.log("Decision: Retrying...");
    return { 
      retryCount: state.retryCount + 1, 
      error: null, // Reset error for the next attempt
      result: null 
    };
  } else {
    // Decision: Fallback
    console.log("Decision: Max retries reached. Fallback to FallbackAgent.");
    return { result: "Fallback Response: System busy, please try again later." };
  }
};

// 4. Conditional Edges (The Circuit Breaker Logic)
const router = (state: typeof StateAnnotation.State) => {
  // If we have a result, we are done
  if (state.result) return END;
  
  // If we have an error, route to the Error Handler
  if (state.error) return "errorHandler";

  // Otherwise, route to the Worker
  return "unstableWorker";
};

// 5. Graph Construction
// Note: In LangGraph, if a node throws an exception, we need a way to catch it 
// and update state. In newer versions, we can use `catch` mechanisms or 
// wrap the node. For this exercise, we simulate the error being caught 
// by a wrapper that updates state, rather than crashing the graph.

const safeWorkerWrapper = async (state: typeof StateAnnotation.State) => {
  try {
    return await unstableWorker(state);
  } catch (err: any) {
    // Capture the error into the state
    return { error: err.message };
  }
};

const graph = new StateGraph(StateAnnotation)
  .addNode("unstableWorker", safeWorkerWrapper)
  .addNode("errorHandler", errorHandlerNode)
  .addEdge(START, "unstableWorker")
  .addConditionalEdges("unstableWorker", router)
  .addConditionalEdges("errorHandler", router)
  .compile();

// Execution
(async () => {
  // Start with input and default retry count (0)
  const result = await graph.invoke({ input: "Process this", retryCount: 0, maxRetries: 2 });
  console.log("\nFinal State:", result);
})();
