/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * Collaborative Agents: Researcher & Writer Example
 * 
 * Context: SaaS Content Generation Service
 * Framework: LangGraph.js (simulated structure for clarity)
 * Language: TypeScript
 */

// 1. Define Shared State
// The state is the "source of truth" passed between nodes.
interface AgentState {
  topic: string;
  researchData: string | null;
  draft: string | null;
  feedback: string | null;
  iterationCount: number;
}

// 2. Mock LLM Service
// In a real app, this would be an API call to OpenAI/Anthropic.
// We simulate deterministic behavior for this example.
const mockLLM = async (prompt: string, role: "researcher" | "writer"): Promise<string> => {
  console.log(`\n[LLM Call - ${role.toUpperCase()}]: Processing...`);
  // Simulate network delay
  await new Promise(resolve => setTimeout(resolve, 500));
  
  if (role === "researcher") {
    return `Research Summary for "${prompt}": 
    - Key Point 1: LangGraph enables cyclic workflows.
    - Key Point 2: State management is crucial for agent memory.
    - Key Point 3: Conditional edges handle logic branching.`;
  } else {
    // Writer logic depends on context (simulated via prompt string check)
    if (prompt.includes("Needs Revision")) {
      return `Refined Article: A deep dive into LangGraph cyclic workflows. 
      State management ensures continuity. Conditional edges allow dynamic routing.`;
    }
    return `Draft Article: LangGraph is a tool. It enables cyclic workflows.`;
  }
};

// 3. Node Functions
// Each node performs a specific transformation of the state.

/**
 * Researcher Node: Gathers raw data based on the topic.
 */
async function researchNode(state: AgentState): Promise<Partial<AgentState>> {
  const researchData = await mockLLM(state.topic, "researcher");
  return { researchData };
}

/**
 * Writer Node: Creates content based on research data and optional feedback.
 */
async function writerNode(state: AgentState): Promise<Partial<AgentState>> {
  let prompt = "";
  
  if (state.feedback) {
    // Incorporate feedback into the prompt for iterative refinement
    prompt = `Previous Feedback: "${state.feedback}"\nResearch Data: ${state.researchData}`;
  } else {
    // First pass: simple writing based on research
    prompt = `Research Data: ${state.researchData}`;
  }

  const draft = await mockLLM(prompt, "writer");
  return { draft, iterationCount: state.iterationCount + 1 };
}

/**
 * Supervisor Node: Reviews the draft and decides the next step.
 * This implements the "Consensus Mechanism" (in a simplified form) by 
 * evaluating the output against a standard.
 */
async function supervisorNode(state: AgentState): Promise<Partial<AgentState>> {
  // Simple heuristic: If the draft is short, request a revision.
  // In a real app, this would be an LLM call judging quality.
  const isQualityMet = (state.draft?.length || 0) > 60;

  if (!isQualityMet) {
    console.log("[Supervisor]: Draft too short. Requesting revision.");
    return { feedback: "Please expand on the concepts and ensure the tone is professional." };
  }

  console.log("[Supervisor]: Content approved.");
  return { feedback: null }; // Clear feedback to signal completion
}

// 4. Conditional Edge Logic
// Determines the path based on the state after the Supervisor node.

function shouldContinue(state: AgentState): "writer" | "end" {
  // If feedback exists, loop back to the writer.
  // If feedback is null, the workflow is complete.
  return state.feedback ? "writer" : "end";
}

// 5. Graph Definition (Simulated)
// In a real LangGraph implementation, you would use `new StateGraph(...)`.
// Here, we simulate the graph execution logic to make it runnable without dependencies.

async function runWorkflow(topic: string) {
  console.log(`--- Starting Workflow for Topic: "${topic}" ---`);
  
  // Initialize State
  let currentState: AgentState = {
    topic,
    researchData: null,
    draft: null,
    feedback: null,
    iterationCount: 0,
  };

  // Execution Loop (Simulating the Graph Runtime)
  // 1. Start -> Researcher
  console.log("\n[Step 1] Executing Researcher Node...");
  const researchUpdate = await researchNode(currentState);
  currentState = { ...currentState, ...researchUpdate };

  // 2. Researcher -> Writer
  console.log("\n[Step 2] Executing Writer Node...");
  const writeUpdate = await writerNode(currentState);
  currentState = { ...currentState, ...writeUpdate };

  // 3. Writer -> Supervisor (and Conditional Loop)
  let loop = true;
  while (loop) {
    console.log("\n[Step 3] Executing Supervisor Node...");
    const supervisorUpdate = await supervisorNode(currentState);
    currentState = { ...currentState, ...supervisorUpdate };

    // Check Conditional Edge
    const decision = shouldContinue(currentState);
    
    if (decision === "writer") {
      console.log("\n[Loop] Routing back to Writer Node...");
      const revisionUpdate = await writerNode(currentState);
      currentState = { ...currentState, ...revisionUpdate };
      // Loop continues to Supervisor again
    } else {
      console.log("\n[End] Workflow Complete.");
      loop = false;
    }
  }

  // Final Output
  console.log("\n=== FINAL DRAFT ===");
  console.log(currentState.draft);
  console.log("===================");
  console.log(`Total Iterations: ${currentState.iterationCount}`);
}

// 6. Execution Entry Point
// Run the application
(async () => {
  await runWorkflow("The benefits of LangGraph.js");
})();
