/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// /app/api/generate-brief.ts
// Next.js API Route for Multi-Agent Orchestration

import { NextResponse } from 'next/server';
import { StateGraph, Annotation, StateSendMessage } from '@langchain/langgraph';
import { ChatOpenAI } from '@langchain/openai';
import { z } from 'zod';

// =============================================================================
// 1. SHARED STATE DEFINITION & UTILITY TYPES
// =============================================================================

/**
 * Defines the shape of the shared state passed between agent nodes.
 * We use Zod for runtime validation, ensuring data integrity across the graph.
 */
const AgentStateSchema = z.object({
  topic: z.string(),
  draft: z.string().default(''),
  feedback: z.string().default(''),
  researchData: z.string().default(''),
  iterations: z.number().default(0),
  // A utility type transformation: 'status' is a literal union type
  status: z.enum(['researching', 'writing', 'reviewing', 'finished']).default('researching'),
});

// Infer TypeScript type from Zod schema for type safety
type AgentState = z.infer<typeof AgentStateSchema>;

/**
 * Annotation is used to define the state schema for LangGraph.
 * This allows the graph to track the 'draft' and 'researchData' as it flows.
 */
const StateAnnotation = Annotation.Root({
  topic: Annotation<string>(),
  draft: Annotation<string>(),
  feedback: Annotation<string>(),
  researchData: Annotation<string>(),
  iterations: Annotation<number>(),
  status: Annotation<string>(),
});

// =============================================================================
// 2. AGENT NODE LOGIC
// =============================================================================

const llm = new ChatOpenAI({
  model: 'gpt-4-turbo-preview',
  temperature: 0.7,
});

/**
 * RESEARCHER NODE
 * Gathers raw data and synthesizes it into key points.
 * In a real SaaS app, this would query vector databases or search APIs.
 */
const researchNode = async (state: typeof StateAnnotation.State): Promise<Partial<AgentState>> => {
  console.log(`[Researcher] Starting research on: ${state.topic}`);

  // Few-Shot Prompting: Providing examples within the system prompt to guide style
  const systemPrompt = `
    You are a Senior Market Researcher. 
    Your task is to synthesize data for a SaaS product brief.
    
    Example Output Format:
    "Market: AI Writing Tools. Key Competitors: Jasper, Copy.ai. Trend: Long-form content generation is shifting to agentic workflows."

    Current Topic: ${state.topic}
    ${state.feedback ? `Previous Feedback to address: ${state.feedback}` : ''}
  `;

  const response = await llm.invoke(systemPrompt);

  return {
    researchData: response.content as string,
    status: 'writing',
    iterations: state.iterations + 1,
  };
};

/**
 * WRITER NODE
 * Transforms the raw research data into a coherent narrative draft.
 */
const writerNode = async (state: typeof StateAnnotation.State): Promise<Partial<AgentState>> => {
  console.log('[Writer] Generating draft...');

  const systemPrompt = `
    You are a Technical Content Writer. 
    Convert the raw research data into a professional Market Insight Brief.
    
    Research Data: ${state.researchData}
    ${state.feedback ? `Critique to refine: ${state.feedback}` : ''}
    
    Output a comprehensive markdown draft.
  `;

  const response = await llm.invoke(systemPrompt);

  return {
    draft: response.content as string,
    status: 'reviewing',
  };
};

/**
 * REVIEWER NODE (Conditional Logic)
 * Determines if the draft meets quality standards or needs refinement.
 * This acts as the "Conditional Edge" logic handler.
 */
const reviewerNode = async (state: typeof StateAnnotation.State): Promise<Partial<AgentState>> => {
  console.log('[Reviewer] Checking quality...');

  const systemPrompt = `
    You are a strict Editor. Review the following draft for the topic: "${state.topic}".
    
    Draft: ${state.draft}
    
    Is this draft comprehensive and high quality? 
    If not, provide specific feedback on what is missing.
    
    Respond strictly with JSON: { "approved": boolean, "feedback": string }
  `;

  const response = await llm.invoke(systemPrompt);
  
  // Parse the LLM response (simplified for this example)
  const content = response.content as string;
  const isApproved = content.toLowerCase().includes('approved: true') || content.includes('"approved": true');
  
  if (isApproved) {
    return { status: 'finished' };
  } else {
    // Extract feedback (mocked extraction for brevity)
    return { 
      status: 'researching', // Loop back to researcher
      feedback: "Expand on competitor analysis and include specific metrics."
    };
  }
};

// =============================================================================
// 3. GRAPH ORCHESTRATION (LANGGRAPH)
// =============================================================================

/**
 * Builds and executes the Multi-Agent Workflow.
 */
async function runWorkflow(topic: string) {
  // Initialize the graph with the shared state schema
  const workflow = new StateGraph(StateAnnotation);

  // Define nodes
  workflow.addNode('researcher', researchNode);
  workflow.addNode('writer', writerNode);
  workflow.addNode('reviewer', reviewerNode);

  // Define Edges
  // 1. Entry point
  workflow.setEntryPoint('researcher');

  // 2. Sequential flow
  workflow.addEdge('researcher', 'writer');
  workflow.addEdge('writer', 'reviewer');

  // 3. Conditional Edge (The Feedback Loop)
  // The 'reviewer' node updates the 'status' field. 
  // We route based on that value.
  workflow.addConditionalEdges(
    'reviewer',
    (state: typeof StateAnnotation.State) => {
      if (state.status === 'finished') {
        return 'finish'; // End the graph
      }
      // If not finished, loop back to researcher for refinement
      return 'researcher'; 
    }
  );

  // 4. Define the final state
  workflow.setFinishPoint('reviewer'); // Technically 'reviewer' leads to finish

  // Compile the graph
  const app = workflow.compile();

  // Execute
  const initialInput = {
    topic: topic,
    iterations: 0,
    feedback: '',
  };

  // Run the graph stream
  const finalState = await app.invoke(initialInput);
  
  return finalState;
}

// =============================================================================
// 4. NEXT.JS API ROUTE HANDLER
// =============================================================================

export async function POST(req: Request) {
  try {
    const { topic } = await req.json();

    if (!topic) {
      return NextResponse.json({ error: 'Topic is required' }, { status: 400 });
    }

    // Execute the multi-agent workflow
    const result = await runWorkflow(topic);

    return NextResponse.json({
      success: true,
      data: {
        topic: result.topic,
        finalDraft: result.draft,
        iterations: result.iterations,
        researchSummary: result.researchData,
      },
    });

  } catch (error) {
    console.error('Workflow Error:', error);
    return NextResponse.json(
      { error: 'Failed to generate brief' }, 
      { status: 500 }
    );
  }
}
