/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// 1. Define the base interfaces and state
interface SearchResult {
    title: string;
    url: string;
    snippet: string;
}

interface ResearcherState {
    searchQuery: string;
    searchResults: SearchResult[];
    synthesizedNotes: string;
    draftOutline: string;
    confidenceScore: number;
}

// 2. Use Pick to select specific properties for the search phase
// We only need the query and the results returned from the search tool.
type SearchState = Pick<ResearcherState, 'searchQuery' | 'searchResults'>;

// 3. Use Omit to exclude properties relevant only to the initial search
// The synthesis phase doesn't need the raw query, just the results and existing notes.
type SynthesisState = Omit<ResearcherState, 'searchQuery'>;

// 4. Use Partial to make all properties optional
// Useful for initializing state or when updating fields incrementally.
type DraftState = Partial<ResearcherState>;

// 5. Function demonstrating type safety with the derived type
function processSynthesis(state: SynthesisState) {
    // We can safely access properties defined in SynthesisState
    console.log(`Processing ${state.searchResults.length} search results.`);
    console.log(`Existing notes: ${state.synthesizedNotes}`);

    // The following line would cause a TypeScript error because 'searchQuery' is omitted:
    // console.log(state.searchQuery); // Error: Property 'searchQuery' does not exist on type 'SynthesisState'.
    
    // We can also modify properties that exist in SynthesisState
    const updatedNotes = state.synthesizedNotes + "\nAdding new synthesis...";
    
    // Note: Since SynthesisState is not strictly immutable, we can reassign properties
    // if the function is designed to update the state object in place.
    return { ...state, synthesizedNotes: updatedNotes };
}
