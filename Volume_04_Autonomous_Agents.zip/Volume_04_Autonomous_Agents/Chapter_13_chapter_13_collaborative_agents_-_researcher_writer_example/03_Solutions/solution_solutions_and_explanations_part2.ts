/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

// 1. Define the base WriterState
interface WriterState {
    draft: string;
    revisionCount: number;
}

// 2. Define ReviewerState extending WriterState
interface ReviewerState extends WriterState {
    reviewScore: number;
    feedback: string;
}

// 3. & 4. Conditional edge function
function shouldRevise(state: ReviewerState): 'writer' | 'publisher' {
    // Check if the score is below the threshold AND we haven't exceeded the max revision limit.
    // This logic ensures the agent improves iteratively without getting stuck.
    if (state.reviewScore < 7 && state.revisionCount < 3) {
        return 'writer'; // Loop back to writer
    }
    
    // If score is acceptable OR max revisions reached, proceed to publisher.
    // (Note: In a real system, you might want to handle the "max revisions" case 
    // differently, perhaps marking it as "Needs Manual Review", but here we proceed to publish).
    return 'publisher';
}

// 5. Explanation:
// This function acts as the gatekeeper for the feedback loop.
// By checking both score and revision count, we ensure the agent improves
// the content iteratively without getting stuck in an infinite cycle.
