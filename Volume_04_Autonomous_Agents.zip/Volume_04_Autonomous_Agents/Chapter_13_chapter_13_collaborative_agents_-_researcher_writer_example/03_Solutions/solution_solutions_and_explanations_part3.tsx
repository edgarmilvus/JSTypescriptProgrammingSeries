/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

import React from 'react';

// 1. Define the interface for a workflow node
interface WorkflowNode {
    id: string;
    label: string;
    status: 'idle' | 'active' | 'completed' | 'error';
}

interface WorkflowGraphProps {
    nodes: WorkflowNode[];
    edges: { from: string; to: string; }[];
}

// 2. React Component
const WorkflowGraph: React.FC<WorkflowGraphProps> = ({ nodes, edges }) => {
    // 4. Calculate positions (Simplified layout algorithm)
    // In a real app, you would use a library like Dagre or D3 for this.
    const nodePositions: Record<string, { x: number; y: number }> = {};
    nodes.forEach((node, index) => {
        nodePositions[node.id] = { x: 50 + (index * 150), y: 50 };
    });

    return (
        <div style={{ position: 'relative', width: '800px', height: '200px', border: '1px solid #ccc', padding: '10px' }}>
            {/* SVG Layer for Edges */}
            <svg style={{ position: 'absolute', top: 0, left: 0, width: '100%', height: '100%', pointerEvents: 'none' }}>
                {edges.map((edge, i) => {
                    const start = nodePositions[edge.from];
                    const end = nodePositions[edge.to];
                    if (!start || !end) return null;
                    
                    // Draw a line from the right side of start node to left side of end node
                    return (
                        <line
                            key={i}
                            x1={start.x + 80} // Offset by node width
                            y1={start.y + 20} // Offset by half node height
                            x2={end.x}
                            y2={end.y + 20}
                            stroke="#555"
                            strokeWidth="2"
                            markerEnd="url(#arrowhead)" // You would define this in <defs>
                        />
                    );
                })}
            </svg>

            {/* Nodes Layer */}
            {nodes.map((node) => {
                const pos = nodePositions[node.id];
                if (!pos) return null;
                
                // 3. & 5. Dynamic styling based on status
                const getStyle = (status: WorkflowNode['status']): React.CSSProperties => {
                    const baseStyle: React.CSSProperties = {
                        position: 'absolute',
                        left: `${pos.x}px`,
                        top: `${pos.y}px`,
                        width: '80px',
                        height: '40px',
                        border: '2px solid',
                        borderRadius: '8px',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        fontWeight: 'bold',
                        fontSize: '12px',
                        transition: 'all 0.3s ease',
                        zIndex: 10,
                    };

                    switch (status) {
                        case 'active':
                            return { ...baseStyle, borderColor: '#10b981', backgroundColor: '#d1fae5', color: '#065f46' }; // Green
                        case 'completed':
                            return { ...baseStyle, borderColor: '#3b82f6', backgroundColor: '#dbeafe', color: '#1e40af' }; // Blue
                        case 'error':
                            return { ...baseStyle, borderColor: '#ef4444', backgroundColor: '#fee2e2', color: '#991b1b' }; // Red
                        default: // idle
                            return { ...baseStyle, borderColor: '#9ca3af', backgroundColor: '#f3f4f6', color: '#374151' }; // Gray
                    }
                };

                return (
                    <div key={node.id} style={getStyle(node.status)}>
                        {node.label}
                    </div>
                );
            })}
        </div>
    );
};

export default WorkflowGraph;
