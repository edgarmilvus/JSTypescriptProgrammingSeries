/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

// 1. Define interface for a research report
interface ResearchReport {
    agentType: string;
    keyPoints: string[];
}

// 2. Synthesis function
function synthesizeReports(reports: ResearchReport[]): { summary: string; consolidatedPoints: string[] } {
    // 3. Collect all points using flatMap and remove duplicates using a Set
    // flatMap transforms the array of reports into an array of key points
    const allPoints = reports.flatMap(r => r.keyPoints);
    
    // A Set automatically stores only unique values
    const uniquePoints = [...new Set(allPoints)];
    
    // 4. Select the top 3 unique points
    // slice(0, 3) grabs the first 3 elements. If there are fewer, it grabs what exists.
    const consolidatedPoints = uniquePoints.slice(0, 3);
    
    // 5. Construct the summary string
    // We map over the points to create a bulleted list format
    const bulletPoints = consolidatedPoints.map(point => `- ${point}`).join('\n');
    const summary = `Consolidated Research Report:\n${bulletPoints}`;
    
    return { summary, consolidatedPoints };
}

// 6. Mock data demonstration
const mockReports: ResearchReport[] = [
    { agentType: "Technical", keyPoints: ["Uses LangGraph for cycles", "Built on Node.js", "Supports TypeScript"] },
    { agentType: "Business", keyPoints: ["Reduces development time", "Scalable architecture", "Cost-effective"] },
    { agentType: "Ethical", keyPoints: ["Requires oversight", "Bias mitigation needed", "Built on Node.js"] } // "Built on Node.js" is a duplicate
];

// Execution
// const result = synthesizeReports(mockReports);
// console.log(result.summary);
// Output:
// Consolidated Research Report:
// - Uses LangGraph for cycles
// - Built on Node.js
// - Supports TypeScript
