/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part6.ts
// Description: Solutions and Explanations
// ==========================================

// 1. Function definition
function generateWorkflowDot(currentNode: string, revisionCount: number): string {
    // 2. Node definitions
    // We define the nodes with their base labels.
    const nodes = [
        'Researcher [label="Researcher"];',
        'Writer [label="Writer"];',
        'Reviewer [label="Reviewer"];',
        'Publisher [label="Publisher"];'
    ];

    // 3. Style the current node
    // We map over the nodes and inject Graphviz attributes if the node matches the current node.
    const styledNodes = nodes.map(nodeDef => {
        // Extract node name from definition string (e.g., "Writer [label="Writer"];" -> "Writer")
        const nodeName = nodeDef.split(' ')[0];
        
        if (nodeName === currentNode) {
            // Remove the closing bracket to append styling attributes
            const base = nodeDef.replace('];', '');
            return `${base}, style=filled, fillcolor=lightblue];`;
        }
        return nodeDef;
    });

    // 4. Edge definitions
    // Define the static edges and the conditional edges with labels.
    const edges = [
        'Researcher -> Writer;',
        'Writer -> Reviewer;',
        'Reviewer -> Writer [label="Low Score (< 7)", fontcolor="red", color="red"];',
        'Reviewer -> Publisher [label="Approved"];'
    ];

    // 5. Construct DOT string
    const dotString = `digraph Workflow {
    rankdir=TB;
    node [shape=box, style=rounded];
    
    // Nodes
    ${styledNodes.join('\n    ')}
    
    // Edges
    ${edges.join('\n    ')}
}`;

    return dotString;
}

// 6. Example usage
// const dotOutput = generateWorkflowDot('Writer', 2);
// console.log(dotOutput);

/*
Output for generateWorkflowDot('Writer', 2):

digraph Workflow {
    rankdir=TB;
    node [shape=box, style=rounded];
    
    // Nodes
    Researcher [label="Researcher"];
    Writer [label="Writer", style=filled, fillcolor=lightblue];
    Reviewer [label="Reviewer"];
    Publisher [label="Publisher"];
    
    // Edges
    Researcher -> Writer;
    Writer -> Reviewer;
    Reviewer -> Writer [label="Low Score (< 7)", fontcolor="red", color="red"];
    Reviewer -> Publisher [label="Approved"];
}
*/
