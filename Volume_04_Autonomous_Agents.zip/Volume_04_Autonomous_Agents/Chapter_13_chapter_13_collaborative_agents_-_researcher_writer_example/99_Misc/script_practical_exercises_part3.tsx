/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part3.tsx
// Description: Practical Exercises
// ==========================================

// Placeholder for your code implementation
import React from 'react';

// 1. Define the interface
interface WorkflowNode {
    id: string;
    label: string;
    status: 'idle' | 'active' | 'completed' | 'error';
}

interface WorkflowGraphProps {
    nodes: WorkflowNode[];
    edges: { from: string; to: string; }[];
}

// 2. React Component
const WorkflowGraph: React.FC<WorkflowGraphProps> = ({ nodes, edges }) => {
    // 3. & 4. Render logic
    // Calculate positions (simplified for this exercise)
    const nodePositions: Record<string, { x: number; y: number }> = {};
    nodes.forEach((node, index) => {
        nodePositions[node.id] = { x: 50 + (index * 150), y: 50 };
    });

    return (
        <div style={{ position: 'relative', width: '600px', height: '200px', border: '1px solid #ccc' }}>
            {/* SVG for edges */}
            <svg style={{ position: 'absolute', top: 0, left: 0, width: '100%', height: '100%', pointerEvents: 'none' }}>
                {edges.map((edge, i) => {
                    const start = nodePositions[edge.from];
                    const end = nodePositions[edge.to];
                    if (!start || !end) return null;
                    return (
                        <line
                            key={i}
                            x1={start.x + 40} // Offset for node width
                            y1={start.y + 20}
                            x2={end.x}
                            y2={end.y + 20}
                            stroke="black"
                            strokeWidth="2"
                        />
                    );
                })}
            </svg>

            {/* Nodes */}
            {nodes.map((node) => {
                const pos = nodePositions[node.id];
                if (!pos) return null;
                
                const style: React.CSSProperties = {
                    position: 'absolute',
                    left: `${pos.x}px`,
                    top: `${pos.y}px`,
                    width: '80px',
                    height: '40px',
                    border: '2px solid',
                    borderRadius: '5px',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    fontWeight: 'bold',
                    transition: 'all 0.3s ease',
                };

                // 3. Status styling
                switch (node.status) {
                    case 'active':
                        style.borderColor = '#10b981'; // Green
                        style.backgroundColor = '#d1fae5';
                        break;
                    case 'completed':
                        style.borderColor = '#3b82f6'; // Blue
                        style.backgroundColor = '#dbeafe';
                        break;
                    case 'error':
                        style.borderColor = '#ef4444'; // Red
                        style.backgroundColor = '#fee2e2';
                        break;
                    default:
                        style.borderColor = '#9ca3af'; // Gray
                        style.backgroundColor = '#f3f4f6';
                }

                return (
                    <div key={node.id} style={style}>
                        {node.label}
                    </div>
                );
            })}
        </div>
    );
};

export default WorkflowGraph;
