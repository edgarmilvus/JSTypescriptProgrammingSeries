/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

import { StateGraph, Annotation, StateSendMessage, StateSend } from "@langchain/langgraph";
import { z } from "zod";

// ==========================================
// 1. Define State and Schemas
// ==========================================

/**
 * The shared Graph State. This object is passed between nodes.
 * In a real app, this would contain user session data, conversation history, etc.
 */
type GraphState = {
  userRequest: string;
  route: string | null; // The decision made by the Supervisor
  finalResponse: string | null; // The result from the worker
};

// Schema for the Supervisor's decision.
// The Supervisor MUST output JSON matching this schema.
const SupervisorDecisionSchema = z.object({
  route: z.enum(["billing", "technical"]).describe("The worker to delegate the task to."),
  reasoning: z.string().describe("Why this route was chosen."),
});

// ==========================================
// 2. Define Agent Nodes
// ==========================================

/**
 * Supervisor Node: Analyzes the state and decides which worker to invoke.
 * In a real scenario, this would call an LLM (e.g., GPT-4) with a structured output prompt.
 * Here, we mock the logic for clarity and reliability.
 */
async function supervisorNode(state: GraphState): Promise<Partial<GraphState>> {
  console.log(`[Supervisor] Analyzing: "${state.userRequest}"`);

  // Mock LLM decision logic based on keywords
  let decision: z.infer<typeof SupervisorDecisionSchema>;
  
  if (state.userRequest.toLowerCase().includes("bill") || state.userRequest.toLowerCase().includes("charge")) {
    decision = { route: "billing", reasoning: "User mentioned billing terms." };
  } else if (state.userRequest.toLowerCase().includes("bug") || state.userRequest.toLowerCase().includes("error")) {
    decision = { route: "technical", reasoning: "User mentioned technical issues." };
  } else {
    // Default fallback
    decision = { route: "technical", reasoning: "Unclear request, defaulting to technical support." };
  }

  // Validate the output against the schema (Defensive Programming)
  const validatedDecision = SupervisorDecisionSchema.parse(decision);
  
  console.log(`[Supervisor] Decision: Route to ${validatedDecision.route}`);

  // Update state with the decision
  return { route: validatedDecision.route };
}

/**
 * Worker Node: Billing Specialist.
 * Handles specific logic related to invoices and payments.
 */
async function billingWorker(state: GraphState): Promise<Partial<GraphState>> {
  console.log(`[Billing Worker] Processing request...`);
  // Simulate database lookup or API call
  const response = `Billing Report: Your last invoice #12345 was paid successfully. No issues found regarding "${state.userRequest}".`;
  return { finalResponse: response };
}

/**
 * Worker Node: Technical Support.
 * Handles bugs, errors, and system functionality.
 */
async function technicalWorker(state: GraphState): Promise<Partial<GraphState>> {
  console.log(`[Technical Worker] Processing request...`);
  // Simulate debugging logic
  const response = `Technical Analysis: We investigated the error regarding "${state.userRequest}". A patch has been deployed.`;
  return { finalResponse: response };
}

// ==========================================
// 3. Define Routing Logic (Edges)
// ==========================================

/**
 * Conditional Edge: Determines the next step based on the Supervisor's decision.
 * This is the "Delegation Strategy".
 */
function routeDecision(state: GraphState): string | typeof StateSendMessage {
  if (!state.route) {
    // If the supervisor hasn't decided yet, stay on the supervisor (loop prevention)
    return "supervisor"; 
  }

  // Route to the specific worker node based on the 'route' field in state
  if (state.route === "billing") {
    return "billing_worker";
  } else if (state.route === "technical") {
    return "technical_worker";
  }

  // If we reach here, the state is invalid or unknown
  return StateSendMessage("Invalid routing decision detected.");
}

// ==========================================
// 4. Construct the Graph
// ==========================================

/**
 * Initialize the State Graph.
 * We use a mutable state object where nodes update specific fields.
 */
const workflow = new StateGraph<GraphState>({
  // Define the schema of the state (optional in JS, but good for TS inference)
  stateSchema: {
    userRequest: { value: null, reducer: (prev, next) => next ?? prev },
    route: { value: null, reducer: (prev, next) => next ?? prev },
    finalResponse: { value: null, reducer: (prev, next) => next ?? prev },
  },
});

// Add nodes to the graph
workflow.addNode("supervisor", supervisorNode);
workflow.addNode("billing_worker", billingWorker);
workflow.addNode("technical_worker", technicalWorker);

// Define the entry point
workflow.setEntryPoint("supervisor");

// Define conditional edges from the supervisor
// "supervisor" node -> checks routeDecision -> goes to "billing_worker" or "technical_worker"
workflow.addConditionalEdges("supervisor", routeDecision);

// Define terminal edges (workers go to END)
workflow.addEdge("billing_worker", StateSendMessage("END"));
workflow.addEdge("technical_worker", StateSendMessage("END"));

// Compile the graph
const app = workflow.compile();

// ==========================================
// 5. Execution
// ==========================================

/**
 * Helper to run the graph and log results.
 */
async function runTest(request: string) {
  console.log("\n----------------------------------------");
  console.log(`Starting Execution: "${request}"`);
  console.log("----------------------------------------");

  const initialState: GraphState = {
    userRequest: request,
    route: null,
    finalResponse: null,
  };

  // Stream events to see the flow in real-time
  const stream = await app.stream(initialState);

  for await (const event of stream) {
    // The stream yields updates from nodes
    const nodeName = Object.keys(event)[0];
    const nodeState = event[nodeName];
    
    if (nodeState.finalResponse) {
      console.log(`\n>>> FINAL OUTPUT: ${nodeState.finalResponse}`);
    }
  }
}

// Run simulations
(async () => {
  // Test Case 1: Billing Issue
  await runTest("I think there is a problem with my invoice charge.");

  // Test Case 2: Technical Issue
  await runTest("The dashboard is throwing a 500 error.");
})();
