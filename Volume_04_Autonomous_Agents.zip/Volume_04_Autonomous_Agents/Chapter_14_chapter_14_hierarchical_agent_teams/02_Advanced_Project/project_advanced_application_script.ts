/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// app/api/insights/route.ts

import { NextResponse } from 'next/server';
import { StateGraph, Annotation, StateSendMessage, END } from '@langchain/langgraph';

/**
 * ============================================================================
 * 1. STATE DEFINITION
 * ============================================================================
 * Defines the shared state passed between the Supervisor and Worker Agents.
 */
const GraphState = Annotation.Root({
  // The original user query (e.g., "Show me sales trends for Q3")
  query: Annotation<string>,
  
  // The current agent handling the task (e.g., "supervisor", "sql_worker", "chart_worker")
  currentAgent: Annotation<string>,
  
  // The generated output (SQL query or Chart config)
  result: Annotation<string>,
  
  // Execution status: 'pending', 'running', 'completed', 'error'
  status: Annotation<string>,
  
  // Conversation history for context
  messages: Annotation<Array<{ role: string; content: string }>>,
});

/**
 * ============================================================================
 * 2. WORKER AGENT POOL
 * ============================================================================
 * Specialized agents designed for single-purpose tasks.
 */

/**
 * SQL Generator Worker
 * Simulates an LLM call to convert natural language into a pgvector-ready SQL query.
 * In a real app, this would connect to a database schema context.
 */
const sqlWorker = async (state: typeof GraphState.State): Promise<Partial<typeof GraphState.State>> => {
  console.log(`[SQL Worker] Processing: "${state.query}"`);
  
  // Simulate LLM generation logic
  const sqlQuery = `
    SELECT 
      DATE_TRUNC('month', order_date) as period,
      SUM(total_amount) as revenue,
      COUNT(DISTINCT user_id) as unique_users
    FROM orders 
    WHERE order_date >= '2023-07-01' AND order_date <= '2023-09-30'
    GROUP BY 1
    ORDER BY 1;
  `.trim();

  return {
    currentAgent: 'sql_worker',
    result: sqlQuery,
    status: 'completed',
    messages: [
      ...state.messages,
      { role: 'assistant', content: `Generated SQL: ${sqlQuery}` }
    ]
  };
};

/**
 * Chart Generator Worker
 * Analyzes the data intent and returns a JSON configuration for a frontend chart.
 */
const chartWorker = async (state: typeof GraphState.State): Promise<Partial<typeof GraphState.State>> => {
  console.log(`[Chart Worker] Processing: "${state.query}"`);
  
  // Simulate LLM generation logic
  const chartConfig = JSON.stringify({
    type: 'line',
    data: {
      labels: ['July', 'August', 'September'],
      datasets: [
        {
          label: 'Revenue ($)',
          data: [12000, 19000, 15000],
          borderColor: 'rgb(75, 192, 192)',
          tension: 0.1
        }
      ]
    },
    options: { responsive: true }
  });

  return {
    currentAgent: 'chart_worker',
    result: chartConfig,
    status: 'completed',
    messages: [
      ...state.messages,
      { role: 'assistant', content: `Generated Chart Config: ${chartConfig}` }
    ]
  };
};

/**
 * ============================================================================
 * 3. SUPERVISOR NODE
 * ============================================================================
 * The router. It analyzes the state and decides which worker to invoke next.
 * In production, this uses an LLM (e.g., GPT-4) with a structured output schema.
 */
const supervisorNode = async (state: typeof GraphState.State): Promise<Partial<typeof GraphState.State>> => {
  console.log(`[Supervisor] Analyzing query: "${state.query}"`);

  // --- SIMULATED LLM LOGIC ---
  // In a real app, we would pass `state.query` to an LLM with a system prompt
  // defining the available tools (workers).
  const query = state.query.toLowerCase();
  
  let nextAgent = 'sql_worker'; // Default fallback
  
  if (query.includes('trend') || query.includes('graph') || query.includes('chart')) {
    nextAgent = 'chart_worker';
  } else if (query.includes('fetch') || query.includes('select') || query.includes('data')) {
    nextAgent = 'sql_worker';
  }
  // ---------------------------

  return {
    currentAgent: nextAgent,
    status: 'running',
    messages: [
      ...state.messages,
      { role: 'assistant', content: `Supervisor decided to route to: ${nextAgent}` }
    ]
  };
};

/**
 * ============================================================================
 * 4. GRAPH ORCHESTRATION
 * ============================================================================
 * Using LangGraph to define the control flow.
 */

// Initialize the graph
const workflow = new StateGraph(GraphState);

// Add nodes
workflow.addNode('supervisor', supervisorNode);
workflow.addNode('sql_worker', sqlWorker);
workflow.addNode('chart_worker', chartWorker);

// Define the routing logic (Conditional Edges)
// The supervisor node always runs first to determine the next step.
workflow.addConditionalEdges(
  'supervisor',
  (state: typeof GraphState.State) => {
    // Return the node ID to go to next based on the supervisor's decision
    if (state.currentAgent === 'sql_worker') return 'sql_worker';
    if (state.currentAgent === 'chart_worker') return 'chart_worker';
    return END;
  }
);

// Worker nodes always return to the supervisor for review (or end)
workflow.addEdge('sql_worker', 'supervisor'); 
workflow.addEdge('chart_worker', 'supervisor');

// Set the entry point
workflow.setEntryPoint('supervisor');

// Compile the graph
const app = workflow.compile();

/**
 * ============================================================================
 * 5. NEXT.JS API ROUTE HANDLER
 * ============================================================================
 * The entry point for the web application.
 */
export async function POST(req: Request) {
  try {
    const { query } = await req.json();

    if (!query) {
      return NextResponse.json({ error: 'Query is required' }, { status: 400 });
    }

    // Initial State
    const initialState = {
      query: query,
      messages: [{ role: 'user', content: query }],
      status: 'pending',
      currentAgent: 'supervisor',
      result: '',
    };

    // Execute the graph
    // We stream the events. For this demo, we'll await the final state.
    const finalState = await app.invoke(initialState);

    return NextResponse.json({
      status: 'success',
      agent_used: finalState.currentAgent,
      result: finalState.result,
      history: finalState.messages,
    });

  } catch (error) {
    console.error('Error processing insights:', error);
    return NextResponse.json(
      { error: 'Internal Server Error' }, 
      { status: 500 }
    );
  }
}
