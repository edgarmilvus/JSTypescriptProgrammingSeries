/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

import { StateGraph, Annotation, END, START } from "@langchain/langgraph";
import { BaseMessage, HumanMessage } from "@langchain/core/messages";

// 1. Define the State Interface
const SupportStateAnnotation = Annotation.Root({
  userQuery: Annotation<string>,
  conversationHistory: Annotation<Array<{ role: string; content: string }>>({
    reducer: (curr, update) => [...curr, ...update],
    default: () => [],
  }),
  nextAgent: Annotation<string | undefined>,
  supervisorReasoning: Annotation<string | undefined>,
  agentResponse: Annotation<string | undefined>,
});

type SupportState = typeof SupportStateAnnotation.State;

// 2. Supervisor Node Logic
async function supervisorNode(state: SupportState): Promise<SupportState> {
  const { userQuery } = state;
  const lowerQuery = userQuery.toLowerCase();
  
  let nextAgent = "Supervisor"; // Default to self for clarification
  let reasoning = "";

  // 3. Routing Logic (Keyword Detection)
  if (lowerQuery.includes("invoice") || lowerQuery.includes("payment") || lowerQuery.includes("billing")) {
    nextAgent = "BillingAgent";
    reasoning = "Query contains billing-related keywords.";
  } else if (lowerQuery.includes("bug") || lowerQuery.includes("error") || lowerQuery.includes("api")) {
    nextAgent = "TechnicalSupportAgent";
    reasoning = "Query indicates a technical issue or bug.";
  } else if (lowerQuery.includes("info") || lowerQuery.includes("product") || lowerQuery.includes("faq")) {
    nextAgent = "GeneralInfoAgent";
    reasoning = "Query is informational.";
  } else {
    // Ambiguous case
    reasoning = "Query is ambiguous. Asking clarifying question.";
  }

  return {
    ...state,
    nextAgent,
    supervisorReasoning: reasoning,
    conversationHistory: [{ role: "supervisor", content: `Routing to ${nextAgent}: ${reasoning}` }],
  };
}

// Worker Nodes (Simulated for the graph)
async function billingAgent(state: SupportState): Promise<SupportState> {
  return { 
    ...state, 
    agentResponse: "Here is your invoice #12345.",
    conversationHistory: [{ role: "assistant", content: "Billing response sent." }]
  };
}

async function technicalAgent(state: SupportState): Promise<SupportState> {
  return { 
    ...state, 
    agentResponse: "Please restart your server to clear the cache.",
    conversationHistory: [{ role: "assistant", content: "Technical advice sent." }]
  };
}

async function generalInfoAgent(state: SupportState): Promise<SupportState> {
  return { 
    ...state, 
    agentResponse: "Our product is a SaaS platform.",
    conversationHistory: [{ role: "assistant", content: "Info sent." }]
  };
}

// 4. Construct the LangGraph
const graph = new StateGraph(SupportStateAnnotation)
  .addNode("Supervisor", supervisorNode)
  .addNode("BillingAgent", billingAgent)
  .addNode("TechnicalSupportAgent", technicalAgent)
  .addNode("GeneralInfoAgent", generalInfoAgent)
  // 5. Conditional Edges
  .addConditionalEdges(
    "Supervisor",
    (state: SupportState) => {
      if (state.nextAgent === "Supervisor") return "Supervisor"; // Loop back for clarification
      if (state.nextAgent === "BillingAgent") return "BillingAgent";
      if (state.nextAgent === "TechnicalSupportAgent") return "TechnicalSupportAgent";
      if (state.nextAgent === "GeneralInfoAgent") return "GeneralInfoAgent";
      return END;
    }
  )
  // Worker nodes always go back to Supervisor or End (here we route back to Supervisor to keep conversation going)
  .addEdge("BillingAgent", "Supervisor")
  .addEdge("TechnicalSupportAgent", "Supervisor")
  .addEdge("GeneralInfoAgent", "Supervisor")
  .addEdge(START, "Supervisor");

export const supportGraph = graph.compile();

// Usage Example:
// const result = await supportGraph.invoke({ userQuery: "I have a bug in my API" });
