/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

import { StateGraph, Annotation, END, START, MemorySaver } from "@langchain/langgraph";

// 1. Define State with approval flag
const WorkflowStateAnnotation = Annotation.Root({
  researchData: Annotation<string>({ default: () => "" }),
  reportDraft: Annotation<string>({ default: () => "" }),
  needsApproval: Annotation<boolean>({ default: () => false }),
  stepCounter: Annotation<number>({ default: () => 0 }),
});

type WorkflowState = typeof WorkflowStateAnnotation.State;

// 2. Agent Nodes
async function researcherNode(state: WorkflowState): Promise<WorkflowState> {
  console.log("Researcher running...");
  return {
    ...state,
    researchData: "Found data: X=10, Y=20.",
    stepCounter: state.stepCounter + 1,
    // Simulate needing approval after research
    needsApproval: true, 
  };
}

async function writerNode(state: WorkflowState): Promise<WorkflowState> {
  console.log("Writer running...");
  return {
    ...state,
    reportDraft: `Report based on: ${state.researchData}`,
    stepCounter: state.stepCounter + 1,
    needsApproval: false,
  };
}

// 3. Human Intervention Node (The Interrupt)
async function humanInterventionNode(state: WorkflowState): Promise<WorkflowState> {
  if (state.needsApproval) {
    console.log("--- INTERRUPT: Waiting for human approval ---");
    // In a real app, we might throw a specific error or return a special signal
    // LangGraph handles this via the 'interrupt' mechanism
    throw new Error("INTERRUPT_WAIT"); 
  }
  return state;
}

// 4. Configure Checkpointer
const checkpointer = new MemorySaver();

// Build Graph
const builder = new StateGraph(WorkflowStateAnnotation)
  .addNode("Researcher", researcherNode)
  .addNode("Writer", writerNode)
  .addNode("HumanIntervention", humanInterventionNode)
  .addEdge(START, "Researcher")
  // Researcher -> Human Intervention
  .addEdge("Researcher", "HumanIntervention")
  // Human Intervention -> Writer (conditional, but simplified here for flow)
  .addConditionalEdges(
    "HumanIntervention",
    (state) => {
      if (state.needsApproval) return "HumanIntervention"; // Keep looping if still waiting
      return "Writer";
    }
  )
  .addEdge("Writer", END);

// Compile with checkpointer
const workflowGraph = builder.compile({
  checkpointer,
  interruptBefore: ["HumanIntervention"] // LangGraph native way to pause
});

// --- SIMULATION OF WORKFLOW ---

// 5. Initial Run (Will pause)
async function runInitialWorkflow(threadId: string) {
  console.log(`\n--- Starting Workflow: ${threadId} ---`);
  
  // We use a config object to provide the thread_id and checkpointer
  const config = { configurable: { thread_id: threadId } };

  // Run until interrupt
  const initialResult = await workflowGraph.invoke(
    { researchData: "", needsApproval: false },
    config
  );
  
  console.log("Graph paused. State saved:", {
    researchData: initialResult.researchData,
    needsApproval: initialResult.needsApproval
  });
}

// 6. Resume Workflow Function
async function resumeWorkflow(threadId: string) {
  console.log(`\n--- Resuming Workflow: ${threadId} ---`);
  
  const config = { configurable: { thread_id: threadId } };

  // To resume, we first need to update the state to remove the approval flag
  // (Simulating the human clicking 'Approve' in the UI)
  await workflowGraph.updateState(config, { needsApproval: false });

  // Now we stream again. It will pick up from the saved state.
  const finalResult = await workflowGraph.stream(null, config);
  
  for await (const event of finalResult) {
    // Log events to see progress
  }
  
  console.log("Workflow Complete.");
}

// Execute
// await runInitialWorkflow("thread-001");
// await resumeWorkflow("thread-001");
