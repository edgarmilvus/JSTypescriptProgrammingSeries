/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

import { StateGraph, Annotation, END, START } from "@langchain/langgraph";

// 1. Define the Dynamic Registry
class WorkerRegistry {
  private agents: Map<string, (state: any) => Promise<any>> = new Map();

  register(name: string, node: (state: any) => Promise<any>) {
    this.agents.set(name, node);
  }

  getCapabilities(): string[] {
    return Array.from(this.agents.keys());
  }

  getAgent(name: string) {
    return this.agents.get(name);
  }
}

// Global Registry Instance
const registry = new WorkerRegistry();

// 2. Define Dynamic State
const DynamicStateAnnotation = Annotation.Root({
  userQuery: Annotation<string>,
  nextAgent: Annotation<string | undefined>,
  capabilities: Annotation<string[]>({ default: () => [] }),
  response: Annotation<string | undefined>,
});

type DynamicState = typeof DynamicStateAnnotation.State;

// 3. Dynamic Supervisor Node
async function dynamicSupervisor(state: DynamicState): Promise<DynamicState> {
  // Get current capabilities from registry
  const capabilities = registry.getCapabilities();
  
  // Logic to select an agent (Simulated LLM decision)
  // In a real scenario, you would pass 'capabilities' to an LLM prompt.
  // Here, we simulate picking the first matching keyword.
  
  const query = state.userQuery.toLowerCase();
  let nextAgent = "Supervisor"; // Default to clarification

  // Simple logic that works against dynamic list
  if (query.includes("search") && capabilities.includes("SearchAgent")) {
    nextAgent = "SearchAgent";
  } else if (query.includes("db") && capabilities.includes("DbAgent")) {
    nextAgent = "DbAgent";
  } else if (capabilities.length > 0) {
    // Fallback to first available if no match
    nextAgent = capabilities[0];
  }

  return {
    ...state,
    nextAgent,
    capabilities, // Pass capabilities down for logging/debugging
  };
}

// 4. Generic Worker Node Wrapper
// This node looks up the actual worker logic in the registry
async function genericWorkerNode(state: DynamicState): Promise<DynamicState> {
  if (!state.nextAgent) return state;
  
  const agentFunc = registry.getAgent(state.nextAgent);
  if (!agentFunc) {
    return { ...state, response: `Error: Agent ${state.nextAgent} not found.` };
  }

  // Execute the dynamic agent
  const result = await agentFunc(state);
  return {
    ...state,
    response: result.response || "Done",
  };
}

// 5. Graph Construction
const builder = new StateGraph(DynamicStateAnnotation)
  .addNode("Supervisor", dynamicSupervisor)
  .addNode("Worker", genericWorkerNode) // Single node handles all dynamic agents
  .addEdge(START, "Supervisor")
  .addEdge("Worker", END);

// Conditional edge from Supervisor to Worker
builder.addConditionalEdges(
  "Supervisor",
  (state: DynamicState) => {
    if (state.nextAgent === "Supervisor") return "Supervisor";
    return "Worker";
  }
);

const dynamicGraph = builder.compile();

// --- USAGE & EXTENSIBILITY ---

// Define some agents
registry.register("SearchAgent", async (state) => ({ 
  response: "Searching web for: " + state.userQuery 
}));

registry.register("DbAgent", async (state) => ({ 
  response: "Querying DB for user data..." 
}));

// To add a new agent, we just register it. No graph modification needed.
// registry.register("EmailAgent", async (state) => ({ response: "Email sent." }));

// Test
// await dynamicGraph.invoke({ userQuery: "Please search for something" });

