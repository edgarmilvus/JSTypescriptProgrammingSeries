/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useEffect, useState } from 'react';

// 1. Props Interface
interface WorkflowVisualizerProps {
  graphState: {
    userQuery: string;
    activeAgent: string;
    status: 'running' | 'completed' | 'paused';
  };
}

// 2. DOT Diagram String (Static representation of the graph structure)
const graphDOT = `
digraph G {
  rankdir=TB;
  node [fontname="Arial"];
  
  Supervisor [shape=box, style=filled, fillcolor=lightblue, color=blue, penwidth=2];
  BillingAgent [shape=ellipse, style=filled, fillcolor=lightgreen, color=green];
  TechnicalSupportAgent [shape=ellipse, style=filled, fillcolor=lightgreen, color=green];
  GeneralInfoAgent [shape=ellipse, style=filled, fillcolor=lightgreen, color=green];

  Supervisor -> BillingAgent [label="Billing"];
  Supervisor -> TechnicalSupportAgent [label="Bug/Error"];
  Supervisor -> GeneralInfoAgent [label="Info"];
}
`;

export const WorkflowVisualizer: React.FC<WorkflowVisualizerProps> = ({ graphState }) => {
  const { activeAgent, status } = graphState;
  const [highlightedNode, setHighlightedNode] = useState<string | null>(null);

  // 3. useEffect to update visual state
  useEffect(() => {
    if (status === 'running') {
      setHighlightedNode(activeAgent);
    } else if (status === 'completed') {
      setHighlightedNode(null);
    }
    // If status is 'paused', we keep the last active node highlighted
  }, [activeAgent, status]);

  // Helper to modify DOT string to highlight active node
  // Note: In a real app, you might use a library like 'react-graph-vis' or 'viz.js'
  // Here we simulate highlighting by string manipulation for the exercise.
  const getRenderedDOT = () => {
    if (!highlightedNode) return graphDOT;
    
    // Simple regex to add a bold border to the active node in the DOT string
    // This is a visual hack for the exercise; real implementations usually parse the graph.
    const highlightRegex = new RegExp(`(${highlightedNode}\\s*\\[)`, 'g');
    return graphDOT.replace(highlightRegex, `$1 penwidth=5, color=red, fontcolor=red;`);
  };

  return (
    <div style={{ fontFamily: 'sans-serif', padding: '20px', border: '1px solid #ddd', borderRadius: '8px' }}>
      <h3>Workflow Visualizer</h3>
      
      {/* Status Bar */}
      <div style={{ marginBottom: '10px', padding: '10px', background: status === 'paused' ? '#fff3cd' : '#e3f2fd', borderRadius: '4px' }}>
        <strong>Status:</strong> {status.toUpperCase()} 
        {status === 'paused' && <span style={{ marginLeft: '10px', fontWeight: 'bold', color: '#856404' }}>⏸ Waiting for Input</span>}
      </div>

      <div style={{ display: 'flex', gap: '20px', alignItems: 'flex-start' }}>
        {/* Text Representation (Accessible) */}
        <div style={{ flex: 1 }}>
          <p><strong>Current Node:</strong> {activeAgent || 'None'}</p>
          <p><strong>User Query:</strong> {graphState.userQuery}</p>
        </div>

        {/* Visual Diagram Representation */}
        <div style={{ flex: 2, border: '1px solid #ccc', padding: '10px', borderRadius: '4px', position: 'relative' }}>
          <div style={{ fontSize: '12px', color: '#666', marginBottom: '5px' }}>Graph Structure (DOT)</div>
          
          {/* 
            In a real React app, you would use a library like 'react-graph-vis' or 'viz.js' 
            to render the DOT string. For this exercise, we display the code 
            but style the active node in the text list below to show the logic.
          */}
          
          <div style={{ display: 'flex', flexDirection: 'column', gap: '5px' }}>
            <div style={{ 
              padding: '8px', 
              border: highlightedNode === 'Supervisor' ? '3px solid red' : '1px solid lightblue',
              backgroundColor: highlightedNode === 'Supervisor' ? '#ffebee' : '#e3f2fd',
              fontWeight: highlightedNode === 'Supervisor' ? 'bold' : 'normal'
            }}>
              Supervisor {highlightedNode === 'Supervisor' ? '🔴' : ''}
            </div>
            
            <div style={{ paddingLeft: '20px', borderLeft: '2px dashed #ccc' }}>
              {['BillingAgent', 'TechnicalSupportAgent', 'GeneralInfoAgent'].map((worker) => (
                <div key={worker} style={{ 
                  padding: '5px', 
                  margin: '2px 0',
                  border: highlightedNode === worker ? '3px solid red' : '1px solid lightgreen',
                  backgroundColor: highlightedNode === worker ? '#e8f5e9' : '#f1f8e9',
                  fontWeight: highlightedNode === worker ? 'bold' : 'normal'
                }}>
                  {worker} {highlightedNode === worker ? '🔴' : ''}
                </div>
              ))}
            </div>
          </div>

          {/* Overlay for Paused State */}
          {status === 'paused' && (
            <div style={{
              position: 'absolute',
              top: 0, left: 0, right: 0, bottom: 0,
              backgroundColor: 'rgba(255, 255, 255, 0.8)',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              fontSize: '1.5rem', fontWeight: 'bold', color: '#d32f2f'
            }}>
              ⏸ PAUSED
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
