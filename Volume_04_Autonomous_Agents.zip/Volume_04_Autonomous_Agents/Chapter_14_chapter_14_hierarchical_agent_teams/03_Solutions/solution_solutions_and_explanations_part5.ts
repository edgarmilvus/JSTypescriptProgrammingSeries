/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

import { StateGraph, Annotation, END, START } from "@langchain/langgraph";

// 1. Mock Tool
const checkSyntax = (code: string): string => {
  // Simulates a syntax check
  if (code.includes("function") && code.includes("return")) {
    return "Valid Syntax";
  }
  return "Syntax Error: Missing function definition or return statement";
};

// 2. Extended State Interface
const CodeGenStateAnnotation = Annotation.Root({
  userRequest: Annotation<string>,
  plan: Annotation<string[]>({ default: () => [] }),
  currentStep: Annotation<number>({ default: () => 0 }),
  toolResults: Annotation<string[]>({ default: () => [] }),
  generatedCode: Annotation<string>({ default: () => "" }),
  isDone: Annotation<boolean>({ default: () => false }),
});

type CodeGenState = typeof CodeGenStateAnnotation.State;

// 3. ReAct Loop Nodes

// Step A: Planner (Thought)
async function plannerNode(state: CodeGenState): Promise<CodeGenState> {
  console.log("--- Planning Phase ---");
  // Simulated LLM planning
  const plan = [
    "Step 1: Define function signature based on request.",
    "Step 2: Implement logic body.",
    "Step 3: Check syntax using tool.",
    "Step 4: Finalize code."
  ];
  
  // If we already have a plan, skip re-planning
  if (state.plan.length > 0) {
    return state;
  }

  return {
    ...state,
    plan: plan,
    currentStep: 0,
  };
}

// Step B: Executor (Action & Observation)
async function executorNode(state: CodeGenState): Promise<CodeGenState> {
  const stepIndex = state.currentStep;
  
  // Check if plan is finished
  if (stepIndex >= state.plan.length) {
    return { ...state, isDone: true };
  }

  const step = state.plan[stepIndex];
  console.log(`Executing Step ${stepIndex + 1}: ${step}`);

  let newCode = state.generatedCode;
  let newToolResults = [...state.toolResults];

  // Simulated Action based on step content
  if (step.includes("Define function")) {
    newCode += "function myFunc() { ";
  } else if (step.includes("Implement logic")) {
    newCode += "return 'Hello World'; }";
  } else if (step.includes("Check syntax")) {
    const syntaxResult = checkSyntax(newCode);
    newToolResults.push(`Tool: checkSyntax -> ${syntaxResult}`);
    
    // Hallucination Handling / Error Recovery Logic
    if (syntaxResult.includes("Error")) {
      // In a real ReAct loop, we might append this observation to the prompt
      // and ask the LLM to fix it. Here, we simulate a fix.
      console.log("Syntax failed! Auto-correcting...");
      newCode = "function myFunc() { return 'Hello World'; }"; 
      newToolResults.push("System: Auto-corrected syntax.");
    }
  }

  return {
    ...state,
    generatedCode: newCode,
    toolResults: newToolResults,
    currentStep: stepIndex + 1,
  };
}

// 4. Supervisor for the Worker (Router for the ReAct Loop)
async function codeWorkerSupervisor(state: CodeGenState): Promise<CodeGenState> {
  // This node decides if the loop continues or ends
  if (state.currentStep >= state.plan.length && state.plan.length > 0) {
    return { ...state, isDone: true };
  }
  return { ...state, isDone: false };
}

// 5. Build the Subgraph (The Worker)
const codeWorkerGraph = new StateGraph(CodeGenStateAnnotation)
  .addNode("Planner", plannerNode)
  .addNode("Executor", executorNode)
  .addNode("Supervisor", codeWorkerSupervisor)
  .addEdge(START, "Planner")
  .addEdge("Planner", "Executor")
  .addConditionalEdges(
    "Executor",
    (state: CodeGenState) => {
      if (state.isDone) return "Finalize";
      return "Supervisor";
    }
  )
  .addConditionalEdges(
    "Supervisor",
    (state: CodeGenState) => {
      if (state.isDone) return END;
      return "Executor"; // Loop back
    }
  );

const codeWorker = codeWorkerGraph.compile();

// 6. Usage Wrapper (To fit into the main graph)
async function runCodeWorker(request: string) {
  console.log(`\nStarting Code Worker for: "${request}"`);
  
  const result = await codeWorker.invoke({ 
    userRequest: request,
    // Initial state
  });

  // Clean output for Supervisor
  return result.generatedCode;
}

// Test
// runCodeWorker("Create a function that returns Hello World").then(console.log);
