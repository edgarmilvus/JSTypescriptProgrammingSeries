/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

// lib/langgraph-shared-state.ts
// ==========================================
// SHARED STATE ARCHITECTURE
// ==========================================

import { StateGraph, Annotation, MemorySaver } from "@langchain/langgraph";

/**
 * Shared State Annotation.
 * Defines the structure of the state object accessible by ALL nodes in the graph.
 * In a SaaS context, this represents a centralized database record or a global cache.
 */
const SharedStateAnnotation = Annotation.Root({
  project_id: Annotation<string>,
  task_description: Annotation<string>,
  developer_feedback: Annotation<string[]>({
    reducer: (curr, update) => [...curr, ...update], // Appends feedback from multiple agents
    default: () => [],
  }),
  status: Annotation<"pending" | "completed">({
    default: () => "pending",
  }),
});

/**
 * Node 1: Project Manager (Orchestrator)
 * Updates the shared state with a task description.
 */
const projectManagerNode = async (state: typeof SharedStateAnnotation.State) => {
  console.log("[Shared] Manager processing task:", state.task_description);
  // Logic: Manager decides the task.
  return {
    status: "completed",
    developer_feedback: ["Manager: Task defined and delegated."],
  };
};

/**
 * Node 2: Developer Agent
 * Reads the shared state and appends feedback.
 */
const developerNode = async (state: typeof SharedStateAnnotation.State) => {
  console.log("[Shared] Developer reading project:", state.project_id);
  // Logic: Developer acts based on the shared context.
  return {
    developer_feedback: [`Developer: Implemented feature for ${state.project_id}.`],
  };
};

// Define the Shared State Graph
const sharedGraph = new StateGraph(SharedStateAnnotation)
  .addNode("manager", projectManagerNode)
  .addNode("developer", developerNode)
  // Edges define the flow. In a real app, this might be conditional.
  .addEdge("__start__", "manager")
  .addEdge("manager", "developer")
  .compile();

// ==========================================
// ISOLATED STATE ARCHITECTURE
// ==========================================

/**
 * Isolated State Annotation (Manager).
 * Only the Manager node can access/modify this specific state slice.
 */
const ManagerStateAnnotation = Annotation.Root({
  project_id: Annotation<string>,
  task_description: Annotation<string>,
  manager_status: Annotation<"active" | "done">,
});

/**
 * Isolated State Annotation (Developer).
 * Only the Developer node can access/modify this specific state slice.
 * This prevents the developer from accidentally overwriting manager metadata.
 */
const DeveloperStateAnnotation = Annotation.Root({
  developer_id: Annotation<string>,
  code_snippet: Annotation<string>,
  bugs_found: Annotation<number>,
});

/**
 * Node 1: Manager (Isolated Context)
 * Returns a state object that is MERGED into the Manager's specific state store.
 */
const isolatedManagerNode = async (state: typeof ManagerStateAnnotation.State) => {
  console.log("[Isolated] Manager working alone:", state.project_id);
  return {
    manager_status: "done",
  };
};

/**
 * Node 2: Developer (Isolated Context)
 * Returns a state object that is MERGED into the Developer's specific state store.
 */
const isolatedDeveloperNode = async (state: typeof DeveloperStateAnnotation.State) => {
  console.log("[Isolated] Developer working alone:", state.developer_id);
  return {
    bugs_found: 2,
    code_snippet: "console.log('Hello World');",
  };
};

// Define the Isolated State Graph
// Note: LangGraph typically handles a single state schema per graph. 
// To simulate true isolation in a single graph, we often use "Private" state keys 
// or separate graph instances. For this example, we simulate isolation by 
// having distinct state schemas that do not overlap.
const isolatedGraph = new StateGraph(ManagerStateAnnotation)
  .addNode("manager", isolatedManagerNode)
  // In a real multi-agent system, isolated graphs often run in parallel 
  // and communicate via a message queue (e.g., RabbitMQ or Redis).
  .addEdge("__start__", "manager")
  .compile();

/**
 * Main Execution Function (Simulating a Next.js API Route)
 * This function demonstrates how to switch between patterns.
 */
export async function runAgentWorkflow(type: "shared" | "isolated") {
  const memory = new MemorySaver(); // Checkpointing for state persistence

  if (type === "shared") {
    // Initial state injection
    const initialState = {
      project_id: "proj-123",
      task_description: "Build the login page",
    };

    // Execute the graph
    const result = await sharedGraph.invoke(initialState, {
      configurable: { thread_id: "session-1" },
      checkpointers: [memory],
    });

    return result;
  } else {
    // Initial state injection for isolated manager
    const initialManagerState = {
      project_id: "proj-456",
      task_description: "Refactor database",
      manager_status: "active" as const,
    };

    const result = await isolatedGraph.invoke(initialManagerState, {
      configurable: { thread_id: "session-2" },
      checkpointers: [memory],
    });

    return result;
  }
}
