/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// File: app/api/workflow/route.ts
// Next.js 14+ Route Handler using TypeScript

import { StateGraph, Annotation, START, END } from "@langchain/langgraph";
import { ChatOpenAI } from "@langchain/openai";
import { BaseMessage, HumanMessage, AIMessage } from "@langchain/core/messages";
import { ToolNode } from "@langchain/langgraph/prebuilt";

// ==========================================
// 1. SHARED STATE DEFINITION
// ==========================================

/**
 * Defines the centralized state accessible by all nodes (agents).
 * This is the "Shared State" pattern from Chapter 15.
 * 
 * Why Shared State?
 * - Allows the Supervisor to track the status of all sub-tasks.
 * - Enables Workers to read previous results (e.g., Data Analyst reads user input).
 * - Simplifies debugging by having a single state object to inspect.
 */
const GraphState = Annotation.Root({
  // The raw user request
  userRequest: Annotation<string>({
    reducer: (curr, update) => update ?? curr,
    default: () => "",
  }),

  // Tracks which specific worker agents have completed their tasks
  completedTasks: Annotation<string[]>({
    reducer: (curr, update) => [...curr, update],
    default: () => [],
  }),

  // Accumulates data findings from the Data Analyst
  analysisResults: Annotation<string>({
    reducer: (curr, update) => `${curr}\n${update}`,
    default: () => "",
  }),

  // Accumulates the drafted content from the Writer
  draftContent: Annotation<string>({
    reducer: (curr, update) => `${curr}\n${update}`,
    default: () => "",
  }),

  // The final output to be sent back to the user
  finalOutput: Annotation<string>({
    reducer: (curr, update) => update ?? curr,
    default: () => "",
  }),

  // Messages for conversation history (useful for LLM context)
  messages: Annotation<BaseMessage[]>({
    reducer: (curr, update) => curr.concat(update),
    default: () => [],
  }),
});

// ==========================================
// 2. WORKER AGENT LOGIC
// ==========================================

/**
 * Node: Data Analyst Worker
 * Logic: Reads `userRequest` from shared state, performs "analysis", 
 * and writes to `analysisResults`.
 */
async function dataAnalystNode(state: typeof GraphState.State) {
  const llm = new ChatOpenAI({ model: "gpt-3.5-turbo", temperature: 0 });
  
  // Simulating complex analysis logic based on shared state
  const prompt = `You are a Data Analyst. Analyze the following request and extract key data points needed for a report: "${state.userRequest}"`;
  
  const response = await llm.invoke([
    new HumanMessage(prompt)
  ]);

  return {
    analysisResults: `ANALYSIS: Extracted metrics for: ${state.userRequest}. Key finding: Revenue increased by 12%.`,
    completedTasks: "Data Analysis",
    messages: [new AIMessage(response.content as string)]
  };
}

/**
 * Node: Content Writer Worker
 * Logic: Reads `userRequest` AND `analysisResults` from shared state.
 * Writes to `draftContent`.
 * 
 * This demonstrates the power of Shared State: The Writer depends on the Analyst's output.
 */
async function contentWriterNode(state: typeof GraphState.State) {
  const llm = new ChatOpenAI({ model: "gpt-3.5-turbo", temperature: 0.7 });

  const prompt = `
    You are a Content Writer. Based on the user request and the data analysis provided below, draft a professional email summary.
    
    User Request: ${state.userRequest}
    Analysis Data: ${state.analysisResults}
  `;

  const response = await llm.invoke([new HumanMessage(prompt)]);

  return {
    draftContent: `DRAFT EMAIL: Subject: Q3 Update\n\nBody: ${response.content}`,
    completedTasks: "Content Writing",
    messages: [new AIMessage(response.content as string)]
  };
}

/**
 * Node: Supervisor Agent
 * Logic: Analyzes the state to decide the next step.
 * This is a "Router" node. It does not perform the task; it delegates.
 */
async function supervisorNode(state: typeof GraphState.State) {
  const llm = new ChatOpenAI({ model: "gpt-3.5-turbo", temperature: 0 });

  // Supervisor prompt to determine routing based on state progress
  const systemPrompt = `
    You are a supervisor managing a team of agents (DataAnalyst, ContentWriter, Finisher).
    Review the current state of the workflow:
    - Completed Tasks: ${state.completedTasks.join(", ") || "None"}
    - User Request: ${state.userRequest}
    
    Instructions:
    1. If data analysis is missing, route to "DataAnalyst".
    2. If data exists but draft is missing, route to "ContentWriter".
    3. If both are done, route to "Finisher".
    Respond ONLY with the name of the next agent to invoke.
  `;

  const response = await llm.invoke([new HumanMessage(systemPrompt)]);
  
  // Simple string parsing to determine next node
  const nextStep = response.content as string;
  
  if (nextStep.includes("DataAnalyst")) return { next: "dataAnalyst" };
  if (nextStep.includes("ContentWriter")) return { next: "contentWriter" };
  
  return { next: "finisher" };
}

/**
 * Node: Finisher
 * Logic: Compiles the final output from shared state and marks the task complete.
 */
async function finisherNode(state: typeof GraphState.State) {
  return {
    finalOutput: `TASK COMPLETE.\n\nAnalysis: ${state.analysisResults}\n\nDraft: ${state.draftContent}`,
    completedTasks: "Finished"
  };
}

// ==========================================
// 3. GRAPH COMPILATION & EXECUTION
// ==========================================

/**
 * Builds the StateGraph.
 * 
 * Architecture Note:
 * - We use a "Shared State" object (`GraphState`) that is passed between nodes.
 * - The Supervisor Node acts as the decision-maker, inspecting the shared state
 *   to route traffic.
 * - This differs from "Isolated State" where agents would pass messages blindly
 *   without a central memory context.
 */
function createWorkflow() {
  const workflow = new StateGraph(GraphState);

  // Define Edges
  // The Supervisor is the Entry Point Node for decision logic
  workflow.addNode("supervisor", supervisorNode);
  workflow.addNode("dataAnalyst", dataAnalystNode);
  workflow.addNode("contentWriter", contentWriterNode);
  workflow.addNode("finisher", finisherNode);

  // Entry Point Logic
  workflow.addEdge(START, "supervisor");

  // Conditional Edges based on Supervisor Output
  // The 'supervisor' node returns { next: string }, which we use to route
  workflow.addConditionalEdges(
    "supervisor",
    (state: any) => state.next, // The key to look at in the state
    {
      dataAnalyst: "dataAnalyst",
      contentWriter: "contentWriter",
      finisher: "finisher"
    }
  );

  // Worker nodes always return to the supervisor for re-evaluation
  workflow.addEdge("dataAnalyst", "supervisor");
  workflow.addEdge("contentWriter", "supervisor");
  
  // Finisher ends the graph
  workflow.addEdge("finisher", END);

  return workflow.compile();
}

/**
 * API Route Handler (Next.js)
 * Accepts a POST request with a user task.
 */
export async function POST(req: Request) {
  const { task } = await req.json();

  if (!task) {
    return new Response(JSON.stringify({ error: "Task is required" }), { status: 400 });
  }

  const graph = createWorkflow();

  // Initialize the shared state with the user request
  const initialInput = {
    userRequest: task,
    messages: [new HumanMessage(task)]
  };

  try {
    // Execute the graph
    const result = await graph.invoke(initialInput);

    return new Response(
      JSON.stringify({ 
        result: result.finalOutput,
        stateTrace: result.completedTasks 
      }), 
      { status: 200 }
    );
  } catch (error) {
    console.error("Workflow Error:", error);
    return new Response(JSON.stringify({ error: "Workflow execution failed" }), { status: 500 });
  }
}
