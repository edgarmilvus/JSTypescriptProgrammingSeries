/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

// Define the isolated state interfaces
type EmailState = { rawData: string; cleanedData: string };
type PhoneState = { rawData: string; cleanedData: string };
type ZipState = { rawData: string; cleanedData: string };
type CombinedState = { email: string; phone: string; zip: string };

// Define the node functions
async function cleanEmailNode(state: EmailState): Promise<EmailState> {
    if (!state.rawData) throw new Error("EmailNode: Empty rawData");
    // Simple cleaning: trim whitespace
    return {
        ...state,
        cleanedData: state.rawData.trim()
    };
}

async function cleanPhoneNode(state: PhoneState): Promise<PhoneState> {
    if (!state.rawData) throw new Error("PhoneNode: Empty rawData");
    // Simple cleaning: remove non-numeric characters
    return {
        ...state,
        cleanedData: state.rawData.replace(/\D/g, '')
    };
}

async function cleanZipNode(state: ZipState): Promise<ZipState> {
    if (!state.rawData) throw new Error("ZipNode: Empty rawData");
    // Simple cleaning: trim and take first 5 characters
    return {
        ...state,
        cleanedData: state.rawData.trim().substring(0, 5)
    };
}

// Define the mergeNode
// Note: In a parallel execution context (like NodeGroup), the mergeNode would receive a state object containing results from all branches.
async function mergeNode(states: { email: EmailState; phone: PhoneState; zip: ZipState }): Promise<CombinedState> {
    // This node aggregates the cleaned data from the isolated states
    return {
        email: states.email.cleanedData,
        phone: states.phone.cleanedData,
        zip: states.zip.cleanedData
    };
}

// Example of how the graph would handle a failure in one branch:
// If cleanPhoneNode throws an error (e.g., due to empty rawData), the parallel execution group
// would catch this error. The graph's error handling strategy (e.g., fallback or partial completion)
// would determine if mergeNode still runs with the successful results from email and zip nodes,
// or if the entire process is halted. This isolation prevents the PhoneNode error from
// corrupting the EmailState or ZipState.
