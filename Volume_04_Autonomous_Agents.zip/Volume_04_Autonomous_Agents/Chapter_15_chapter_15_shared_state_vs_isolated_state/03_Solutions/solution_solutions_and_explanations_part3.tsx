/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

// ResearchAssistant.tsx
import React, { useState, useEffect } from 'react';

type GraphState = {
  query: string;
  findings: { source: string; data: any }[];
  status: 'idle' | 'searching' | 'complete' | 'error';
};

export default function ResearchAssistant() {
  // Shared State (simulating GraphState)
  const [graphState, setGraphState] = useState<GraphState>({ 
    query: '', 
    findings: [], 
    status: 'idle' 
  });

  // Isolated Local States for API handling
  const [newsLoading, setNewsLoading] = useState(false);
  const [academicError, setAcademicError] = useState<string | null>(null);
  const [socialMediaData, setSocialMediaData] = useState<any[]>([]);

  // Mock LangGraph execution hook
  const useLangGraph = (state: GraphState) => {
    // This is a mock implementation. In a real scenario, this would be a library call.
    const execute = async () => {
      setGraphState(prev => ({ ...prev, status: 'searching' }));
      
      // Simulate parallel API calls with isolated state management
      try {
        // Mock News API call
        setNewsLoading(true);
        await new Promise(resolve => setTimeout(resolve, 1000)); // Simulate network delay
        const newsData = { source: 'NewsAPI', data: 'Breaking News...' };
        setNewsLoading(false);

        // Mock Academic API call (with potential error)
        setAcademicError(null);
        await new Promise((resolve, reject) => setTimeout(() => reject(new Error('Academic API Timeout')), 1500));
      } catch (err: any) {
        setAcademicError(err.message);
      }

      // Mock Social Media API call
      setSocialMediaData([{ id: 1, content: 'Tweet...' }]);

      // Update shared state with findings
      setGraphState(prev => ({
        ...prev,
        findings: [newsData, { source: 'SocialMedia', data: socialMediaData }],
        status: 'complete'
      }));
    };
    return { execute };
  };

  const { execute } = useLangGraph(graphState);

  const handleSearch = () => {
    // Reset states before starting a new search
    setGraphState({ query: 'Sample Research Query', findings: [], status: 'idle' });
    setAcademicError(null);
    setSocialMediaData([]);
    execute();
  };

  return (
    <div style={{ padding: '20px', fontFamily: 'sans-serif' }}>
      <h1>Research Assistant</h1>
      <button onClick={handleSearch} disabled={graphState.status === 'searching'}>
        {graphState.status === 'searching' ? 'Searching...' : 'Start Research'}
      </button>

      <div style={{ marginTop: '20px' }}>
        <h3>Shared Graph State:</h3>
        <p><strong>Status:</strong> {graphState.status}</p>
        <p><strong>Query:</strong> {graphState.query}</p>
        <div>
          <strong>Findings:</strong>
          <ul>
            {graphState.findings.map((f, i) => (
              <li key={i}>{f.source}: {JSON.stringify(f.data)}</li>
            ))}
          </ul>
        </div>
      </div>

      <div style={{ marginTop: '20px', border: '1px solid #ccc', padding: '10px' }}>
        <h3>Isolated API States:</h3>
        <p>News API Loading: {newsLoading ? 'Yes' : 'No'}</p>
        <p>Academic API Error: {academicError || 'None'}</p>
        <p>Social Media Data Count: {socialMediaData.length}</p>
      </div>
    </div>
  );
}

// Hydration Explanation for Next.js:
// For a Next.js Server Component, the initial `graphState` could be fetched on the server and passed as a prop.
// The component would then use `useState` to hydrate this initial value.
// Example: `const [graphState, setGraphState] = useState<GraphState>(initialGraphStateFromServer);`
// The isolated states (`newsLoading`, `academicError`, etc.) are purely client-side concerns and would remain managed by `useState` without server-side hydration,
// as they are dynamic and depend on user interaction and client-side API calls.
