/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * @fileoverview A minimal Plan-and-Execute agent implementation using LangGraph.js.
 * This example simulates a SaaS backend workflow for planning a trip.
 * 
 * Dependencies: @langchain/core, langgraph
 */

// ============================================================================
// 1. IMPORTS & SETUP
// ============================================================================

import { StateGraph, Annotation, END, START } from "@langchain/core/graphs";
import { BaseMessage, HumanMessage, AIMessage } from "@langchain/core/messages";

// ============================================================================
// 2. STATE DEFINITION
// ============================================================================

/**
 * Defines the structure of the graph's state.
 * 
 * @property plan - An array of strings representing the steps to execute.
 * @property currentStepIndex - The index of the step currently being executed.
 * @property pastSteps - An array of tuples [step, result] capturing execution history.
 * @property response - The final aggregated output string.
 */
const GraphState = Annotation.Root({
  plan: Annotation<string[]>({
    reducer: (state, update) => update, // Overwrite the plan
    default: () => [],
  }),
  currentStepIndex: Annotation<number>({
    reducer: (state, update) => update, // Overwrite index
    default: () => 0,
  }),
  pastSteps: Annotation<Array<[string, string]>>({
    reducer: (state, update) => [...state, update], // Append history
    default: () => [],
  }),
  response: Annotation<string>({
    reducer: (state, update) => update, // Overwrite response
    default: () => "",
  }),
});

// ============================================================================
// 3. TOOL SIMULATION (EXECUTION LOGIC)
// ============================================================================

/**
 * Simulates an external tool call (e.g., booking API, database query).
 * In a real app, this would be a Server Action or external API fetch.
 * 
 * @param step - The description of the step to perform.
 * @returns A promise resolving to the result string.
 */
async function executeTool(step: string): Promise<string> {
  // Simulate network latency
  await new Promise((resolve) => setTimeout(resolve, 100));

  // Simple keyword matching to simulate different outcomes
  if (step.toLowerCase().includes("flight")) {
    return "Flight to Paris booked successfully (Ref: AF1234).";
  }
  if (step.toLowerCase().includes("hotel")) {
    return "Hotel reservation confirmed at 'Le Grand Hotel' (Ref: H-5678).";
  }
  if (step.toLowerCase().includes("museum")) {
    return "Louvre Museum tickets purchased online.";
  }
  return `Executed step: ${step}`;
}

// ============================================================================
// 4. NODES (LOGICAL BLOCKS)
// ============================================================================

/**
 * Node 1: Planner
 * Generates the high-level plan based on the user's initial request.
 * 
 * In a real scenario, this would call an LLM. Here, we hardcode a response
 * for determinism in this "Hello World" example.
 */
const plannerNode = async (state: typeof GraphState.State) => {
  console.log("🤖 [Planner] Generating plan...");
  
  // Simulated LLM output
  const steps = [
    "Book flight to Paris",
    "Reserve hotel accommodation",
    "Purchase Louvre Museum tickets"
  ];

  return {
    plan: steps,
  };
};

/**
 * Node 2: Executor
 * Executes the specific step at `currentStepIndex`.
 * 
 * This node retrieves the step from the plan, calls the tool,
 * and updates the state with the result.
 */
const executorNode = async (state: typeof GraphState.State) => {
  const { plan, currentStepIndex } = state;

  // Safety check: ensure we have a plan and valid index
  if (currentStepIndex >= plan.length) {
    return { response: "No more steps to execute." };
  }

  const stepToExecute = plan[currentStepIndex];
  console.log(`⚡ [Executor] Executing step ${currentStepIndex + 1}: "${stepToExecute}"`);

  // Call the simulated tool
  const result = await executeTool(stepToExecute);

  return {
    pastSteps: [stepToExecute, result] as [string, string],
  };
};

/**
 * Node 3: Reflector (Router)
 * Determines if the execution is complete or if we need to loop back.
 * 
 * This node acts as a conditional router. It checks the index against
 * the plan length. While we handle the conditional logic in the edges
 * for this specific example, this node prepares the data for the next step.
 */
const reflectNode = async (state: typeof GraphState.State) => {
  const { plan, currentStepIndex, pastSteps } = state;
  
  console.log("🔍 [Reflector] Checking progress...");

  // If we have completed all steps, format the final response
  if (currentStepIndex >= plan.length - 1) {
    const summary = pastSteps
      .map(([step, result]) => `- ${step}: ${result}`)
      .join("\n");
    
    return {
      response: `Trip Planning Complete!\n\nSummary:\n${summary}`,
    };
  }

  // Otherwise, increment the step index for the next loop
  return {
    currentStepIndex: currentStepIndex + 1,
  };
};

// ============================================================================
// 5. GRAPH CONSTRUCTION
// ============================================================================

/**
 * Constructs the LangGraph workflow.
 */
function createWorkflow() {
  const workflow = new StateGraph(GraphState)
    // Define Nodes
    .addNode("planner", plannerNode)
    .addNode("executor", executorNode)
    .addNode("reflector", reflectNode)
    // Define Edges
    .addEdge(START, "planner") // Start -> Planner
    .addEdge("planner", "executor") // Planner -> Executor
    
    // Conditional Edge: Reflector -> Executor OR End
    .addConditionalEdges(
      "reflector",
      (state: typeof GraphState.State) => {
        // Logic: If we have a response (meaning we finished), go to END.
        // Otherwise, loop back to executor.
        if (state.response && state.response.length > 0) {
          return END;
        }
        return "executor";
      }
    );

  return workflow.compile();
}

// ============================================================================
// 6. EXECUTION (SIMULATED SERVER ACTION)
// ============================================================================

/**
 * Main entry point.
 * Simulates a Server Action handling a request from a Next.js frontend.
 */
async function runTripPlanner() {
  const app = createWorkflow();
  
  // Initial user input
  const initialInput = {
    // Note: In a real app, we might pass the user query here and let the planner parse it.
    // For this simple example, the planner ignores input and returns a fixed plan.
  };

  console.log("🚀 Starting Plan-and-Execute Workflow...\n");

  // Stream execution events
  const stream = await app.stream(initialInput);

  // Process stream for visualization
  for await (const step of stream) {
    const nodeName = Object.keys(step)[0];
    const state = step[nodeName];
    
    // Log current state snapshot
    if (state.plan?.length > 0) {
      console.log(`   -> Plan updated: [${state.plan.join(", ")}]`);
    }
    if (state.pastSteps?.length > 0) {
      const lastStep = state.pastSteps[state.pastSteps.length - 1];
      console.log(`   -> Result: ${lastStep[1]}`);
    }
    if (state.response) {
      console.log(`   -> Final Response: ${state.response}`);
    }
    console.log(""); // Empty line for readability
  }
}

// Execute the function
runTripPlanner().catch(console.error);
