/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

/**
 * Defines the structure of the state object for the Plan-and-Execute agent.
 */
export interface PlanExecuteState {
  input: string;
  plan: string[];
  currentStepIndex: number;
  executionResults: Array<{ step: string; result: string }>;
  finalOutput: string | null;
}

/**
 * Creates a new state object initialized for a specific user query.
 * @param query - The original user request.
 * @returns A new PlanExecuteState object.
 */
export function initializeState(query: string): PlanExecuteState {
  return {
    input: query,
    plan: [], // Initially empty; populated by the Planner node
    currentStepIndex: 0,
    executionResults: [],
    finalOutput: null,
  };
}

/**
 * Updates the state immutably after a step has been executed.
 * @param state - The current state.
 * @param stepResult - The string result of the executed step.
 * @returns A new state object with updated execution history and index.
 */
export function updateStateAfterStep(
  state: PlanExecuteState,
  stepResult: string
): PlanExecuteState {
  // Get the step string from the current index
  const currentStep = state.plan[state.currentStepIndex];

  // Return a new state object (immutability)
  return {
    ...state,
    executionResults: [
      ...state.executionResults,
      { step: currentStep, result: stepResult },
    ],
    currentStepIndex: state.currentStepIndex + 1,
  };
}
