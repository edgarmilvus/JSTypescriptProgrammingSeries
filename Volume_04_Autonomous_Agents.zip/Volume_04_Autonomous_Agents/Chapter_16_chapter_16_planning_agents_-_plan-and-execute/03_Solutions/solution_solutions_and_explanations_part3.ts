/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

import { PlanExecuteState, updateStateAfterStep } from './Exercise1'; // Assuming previous exercise types

/**
 * Simulates the execution of a single step in the plan.
 * @param state - The current state.
 * @returns A Promise resolving to the updated state with the step result logged.
 * @throws Error if the current step index is out of bounds.
 */
export async function executorNode(state: PlanExecuteState): Promise<PlanExecuteState> {
  // 1. Check if we have reached the end of the plan
  if (state.currentStepIndex >= state.plan.length) {
    // In a real graph, this node shouldn't be called, but we handle it defensively.
    // Returning state unchanged signals completion to the graph logic.
    return state; 
  }

  // 2. Retrieve the current step
  const currentStep = state.plan[state.currentStepIndex];

  // 3. Simulate execution logic based on step content
  let result: string;
  
  if (currentStep.includes("weather")) {
    result = "Simulated API call: Temperature 72°F, Condition: Sunny.";
  } else if (currentStep.includes("forecast")) {
    result = "Simulated API call: 5-day forecast retrieved.";
  } else if (currentStep.includes("Draft") || currentStep.includes("Write")) {
    result = "Simulated generation: Text content created successfully.";
  } else {
    result = `Simulated execution for step: ${currentStep}`;
  }

  // 4. Update state immutably
  return updateStateAfterStep(state, result);
}
