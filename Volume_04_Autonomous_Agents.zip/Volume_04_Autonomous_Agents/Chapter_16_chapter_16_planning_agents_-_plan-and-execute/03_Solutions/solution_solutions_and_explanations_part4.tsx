/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.tsx
// Description: Solutions and Explanations
// ==========================================

import React from 'react';
import { PlanExecuteState } from './Exercise1';

interface PlanGraphVisualizerProps {
  state: PlanExecuteState;
}

const PlanGraphVisualizer: React.FC<PlanGraphVisualizerProps> = ({ state }) => {
  // Helper to escape labels for DOT syntax
  const escapeLabel = (text: string) => text.replace(/"/g, '\\"');

  // Generate the DOT string dynamically
  const generateDot = () => {
    let dot = `digraph G {\n  rankdir=TB;\n  node [shape=box, style=rounded];\n\n`;
    
    // Input Node
    dot += `  Input [label="Input: ${escapeLabel(state.input)}", shape=ellipse, fillcolor="#e0e0e0", style=filled];\n\n`;

    // Plan Nodes
    if (state.plan.length > 0) {
      state.plan.forEach((step, index) => {
        const stepName = `Step${index}`;
        let style = 'fillcolor="#f0f0f0", style=filled'; // Default gray (Pending)

        // Check if step is completed
        const isCompleted = state.executionResults.some(r => r.step === step);
        
        // Check if this is the current step (only if not completed)
        const isCurrent = index === state.currentStepIndex && !isCompleted;

        if (isCompleted) {
          style = 'fillcolor="#d4edda", style=filled, color="#155724"'; // Green
        } else if (isCurrent) {
          style = 'fillcolor="#fff3cd", style=filled, color="#856404"'; // Yellow
        }

        dot += `  ${stepName} [label="${index + 1}. ${escapeLabel(step)}", ${style}];\n`;
      });

      // Edges
      dot += `  Input -> Step0;\n`;
      for (let i = 0; i < state.plan.length - 1; i++) {
        dot += `  Step${i} -> Step${i + 1};\n`;
      }
    } else {
      dot += `  PlanStatus [label="Planning...", shape=note, fillcolor="#fff3cd", style=filled];\n`;
      dot += `  Input -> PlanStatus;\n`;
    }

    // Final Output Node
    if (state.finalOutput) {
      dot += `\n  Output [label="Output", shape=ellipse, fillcolor="#cce5ff", style=filled];\n`;
      const lastStepIndex = state.plan.length - 1;
      if (lastStepIndex >= 0) {
        dot += `  Step${lastStepIndex} -> Output;\n`;
      }
    }

    dot += `}`;
    return dot;
  };

  const dotString = generateDot();

  return (
    <div className="graph-visualizer">
      <h3>Workflow Graph</h3>
      {/* In a real app, use a library like react-graphviz. 
          Here we render the DOT string for clarity. */}
      <pre style={{ background: '#f5f5f5', padding: '10px', borderRadius: '5px', overflowX: 'auto' }}>
        {dotString}
      </pre>
    </div>
  );
};

export default PlanGraphVisualizer;
