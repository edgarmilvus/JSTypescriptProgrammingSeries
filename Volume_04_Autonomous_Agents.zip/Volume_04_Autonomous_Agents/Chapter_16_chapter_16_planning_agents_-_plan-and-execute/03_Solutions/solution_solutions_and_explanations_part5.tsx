/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.tsx
// Description: Solutions and Explanations
// ==========================================

import React from 'react';
import { PlanExecuteState } from './Exercise1';

interface WorkflowProgressBarProps {
  state: PlanExecuteState;
}

const WorkflowProgressBar: React.FC<WorkflowProgressBarProps> = ({ state }) => {
  const { plan, executionResults, currentStepIndex } = state;

  // Edge case: Plan is empty (Planning phase)
  if (!plan || plan.length === 0) {
    return (
      <div className="workflow-progress-bar">
        <div className="status-message">Planning in progress...</div>
        <div className="bar-container">
          <div className="segment pending" style={{ width: '100%' }}></div>
        </div>
      </div>
    );
  }

  const totalSteps = plan.length;

  return (
    <div className="workflow-progress-bar">
      <div className="bar-container" style={{ display: 'flex', width: '100%', height: '30px', border: '1px solid #ccc', borderRadius: '5px', overflow: 'hidden' }}>
        {plan.map((step, index) => {
          let statusClass = '';
          let content = `${index + 1}`;

          // Determine status
          const isCompleted = executionResults.some(r => r.step === step);
          const isCurrent = index === currentStepIndex;

          if (isCompleted) {
            statusClass = 'completed';
            content = '✓'; // Checkmark
          } else if (isCurrent) {
            statusClass = 'in-progress';
            content = '...'; // Pulse indicator
          } else {
            statusClass = 'pending';
          }

          return (
            <div
              key={index}
              className={`segment ${statusClass}`}
              title={step} // Tooltip for full text
              style={{
                flex: 1,
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                fontWeight: 'bold',
                fontSize: '0.9rem',
                color: '#333',
                borderRight: index < totalSteps - 1 ? '1px solid #fff' : 'none',
                // Inline styles for demonstration (normally CSS classes)
                backgroundColor: 
                  statusClass === 'completed' ? '#28a745' : 
                  statusClass === 'in-progress' ? '#007bff' : 
                  '#e9ecef'
              }}
            >
              {content}
            </div>
          );
        })}
      </div>
      <div style={{ marginTop: '5px', fontSize: '0.8rem', color: '#666' }}>
        {currentStepIndex < totalSteps 
          ? `Current: ${plan[currentStepIndex]}` 
          : "Workflow Complete"
        }
      </div>
    </div>
  );
};

export default WorkflowProgressBar;
