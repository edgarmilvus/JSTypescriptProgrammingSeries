/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * Reflection Agent: Self-Correction Loop
 * 
 * Context: SaaS AI Assistant for generating task summaries.
 * Objective: Ensure the generated summary is not "too vague" before finalizing.
 */

// 1. Define the State Interface
// This represents the data flowing through the graph.
interface AgentState {
    request: string;          // The user's original request
    draftSummary: string;     // The current draft of the summary
    critique: string;         // The feedback from the reflection node
    shouldRefine: boolean;    // Boolean flag for the conditional edge
    finalOutput: string;      // The final polished response
}

// 2. Mock LLM Function (Simulating an API Call)
// In a real app, this would be an OpenAI or Anthropic SDK call.
const mockLLMCall = async (prompt: string): Promise<string> => {
    // Simulate network latency
    await new Promise(resolve => setTimeout(resolve, 100));

    // Logic to simulate different outputs based on the prompt context
    if (prompt.includes("Critique the following summary")) {
        // The "Reflection" LLM call
        if (prompt.includes("Buy milk and eggs")) {
            return "The summary is too vague. It lacks context on why the items are needed or the deadline.";
        }
        return "The summary is clear and actionable.";
    } else {
        // The "Generation" LLM call
        if (prompt.includes("Buy milk and eggs for dinner tonight")) {
            return "Task: Purchase groceries. Items: Milk, Eggs. Deadline: Tonight.";
        }
        // Simulating a vague initial generation
        return "Buy milk and eggs";
    }
};

/**
 * Node A: Generate Initial Draft
 * Takes the user request and creates a first pass at the response.
 */
async function generateDraft(state: AgentState): Promise<AgentState> {
    console.log("🤖 [Node] Generating initial draft...");
    const prompt = `Summarize this request concisely: "${state.request}"`;
    const draft = await mockLLMCall(prompt);
    
    return {
        ...state,
        draftSummary: draft,
    };
}

/**
 * Node B: Reflect (Critique)
 * Analyzes the draft against quality criteria (e.g., vagueness).
 */
async function reflectOnDraft(state: AgentState): Promise<AgentState> {
    console.log("🔍 [Node] Reflecting on draft quality...");
    const prompt = `Critique the following summary for clarity and specificity: "${state.draftSummary}"`;
    const critique = await mockLLMCall(prompt);
    
    // Determine if refinement is needed based on the critique text
    const needsRefinement = critique.toLowerCase().includes("vague");

    return {
        ...state,
        critique: critique,
        shouldRefine: needsRefinement,
    };
}

/**
 * Node C: Refine (Regenerate)
 * Uses the critique to generate a better version of the draft.
 */
async function refineDraft(state: AgentState): Promise<AgentState> {
    console.log("✨ [Node] Refining draft based on critique...");
    const prompt = `Original Request: "${state.request}". Previous Summary: "${state.draftSummary}". Critique: "${state.critique}". Please rewrite the summary to address the critique.`;
    const refinedDraft = await mockLLMCall(prompt);
    
    return {
        ...state,
        draftSummary: refinedDraft,
        // Reset critique for the next iteration (optional, but good practice)
        critique: "", 
    };
}

/**
 * Node D: Finalize Output
 * Prepares the final response for the user.
 */
async function finalizeOutput(state: AgentState): Promise<AgentState> {
    console.log("✅ [Node] Finalizing output...");
    return {
        ...state,
        finalOutput: `Final Summary: ${state.draftSummary}`
    };
}

/**
 * Conditional Edge: Router
 * Determines the next step based on the reflection result.
 */
function router(state: AgentState): "refine" | "finalize" {
    if (state.shouldRefine) {
        return "refine";
    }
    return "finalize";
}

/**
 * Main Execution Loop
 * Simulates the LangGraph execution flow without the library dependencies.
 */
async function runReflectionAgent(userRequest: string) {
    // Initialize State
    let state: AgentState = {
        request: userRequest,
        draftSummary: "",
        critique: "",
        shouldRefine: false,
        finalOutput: "",
    };

    console.log(`\n--- Starting Session: "${userRequest}" ---\n`);

    // 1. Generate Initial Draft
    state = await generateDraft(state);
    console.log(`   Draft: "${state.draftSummary}"`);

    // 2. Reflect on the Draft
    state = await reflectOnDraft(state);
    console.log(`   Critique: "${state.critique}"`);
    console.log(`   Decision: ${state.shouldRefine ? "Refine" : "Finalize"}`);

    // 3. Conditional Loop (Simulating Graph Edges)
    const decision = router(state);
    
    if (decision === "refine") {
        // Loop back: Refine -> Reflect
        state = await refineDraft(state);
        console.log(`   Refined Draft: "${state.draftSummary}"`);
        
        // Run reflection again to verify the fix
        state = await reflectOnDraft(state);
        console.log(`   Second Critique: "${state.critique}"`);
    }

    // 4. Finalize
    state = await finalizeOutput(state);
    
    console.log(`\n--- Final Result ---`);
    console.log(state.finalOutput);
    console.log(`---------------------\n`);
}

// --- Execution ---

// Scenario 1: Initial draft is vague, triggers refinement
runReflectionAgent("Buy milk and eggs for dinner tonight");

// Scenario 2: Initial draft is sufficient (Run this separately to test)
// runReflectionAgent("Please reset my password via email");
