/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// pages/api/review-code.ts
// Next.js API Route implementing the Reflection Pattern with LangGraph.js

import { NextApiRequest, NextApiResponse } from 'next';
import { StateGraph, END, Message, StateAnnotation } from '@langchain/langgraph';

// --- 1. State Definition ---
// We define the state that will be passed between nodes in our graph.
interface CodeReviewState {
  prompt: string;             // The user's request
  generatedCode: string;      // The current code draft
  critique: string;           // The feedback from the reflection agent
  iteration: number;          // Track loops to prevent infinite runs
  finalCode: string;          // The approved output
}

// LangGraph's StateAnnotation creates a typed reducer for managing state updates.
const GraphState = StateAnnotation({
  prompt: null,
  generatedCode: null,
  critique: null,
  iteration: 0,
  finalCode: null,
});

// --- 2. Mock LLM Calls (Simulated for Demo) ---
// In a real app, these would be calls to OpenAI/Gemini via Vercel AI SDK or LangChain.

/**
 * Simulates a "Junior Developer" agent generating initial code.
 * This represents the 'Worker Agent' specialized in creation.
 */
async function generateCodeNode(state: typeof GraphState.State): Promise<Partial<CodeReviewState>> {
  console.log(`[Node] Generate (Iteration ${state.iteration + 1})`);
  
  // Simulate LLM generation based on the prompt
  // In a real scenario, we might inject previous critique to avoid repeating mistakes
  const { prompt } = state;
  
  // Mock output: Intentionally including a security flaw for demonstration
  const generatedCode = `
// Generated Code for: ${prompt}
function getUserData(userId) {
  // WARNING: Vulnerable to SQL Injection (Simulated)
  const query = "SELECT * FROM users WHERE id = " + userId; 
  return db.execute(query);
}
`;
  
  return { 
    generatedCode, 
    iteration: state.iteration + 1 
  };
}

/**
 * Simulates a "Senior Developer" reflection agent.
 * This node critiques the output and determines if it meets quality gates.
 */
async function critiqueNode(state: typeof GraphState.State): Promise<Partial<CodeReviewState>> {
  console.log(`[Node] Critique (Iteration ${state.iteration})`);
  
  const { generatedCode } = state;
  let critique = "";
  let isApproved = false;

  // Simple reflection logic (simulating LLM analysis)
  if (generatedCode.includes("SQL Injection")) {
    critique = "CRITICAL: Code contains potential SQL Injection vulnerability. Use parameterized queries.";
    isApproved = false;
  } else if (state.iteration >= 3) {
    // Quality Gate: Max iterations
    critique = "Max iterations reached. Forcing approval.";
    isApproved = true;
  } else {
    critique = "Code looks secure and follows best practices.";
    isApproved = true;
  }

  return { critique, isApproved };
}

/**
 * Finalizes the code if the critique passes.
 */
async function finalizeNode(state: typeof GraphState.State): Promise<Partial<CodeReviewState>> {
  console.log("[Node] Finalize");
  return { 
    finalCode: state.generatedCode,
    critique: "APPROVED: " + state.critique
  };
}

// --- 3. Graph Construction ---

// Initialize the graph with our state definition
const workflow = new StateGraph(GraphState);

// Add nodes to the graph
workflow.addNode("generate", async (state) => generateCodeNode(state));
workflow.addNode("critique", async (state) => critiqueNode(state));
workflow.addNode("finalize", async (state) => finalizeNode(state));

// Define the control flow (Edges)

// 1. Start -> Generate
workflow.setEntryPoint("generate");

// 2. Generate -> Critique (Always follows generation)
workflow.addEdge("generate", "critique");

// 3. Critique -> Decision (Conditional Edge)
// This is the heart of the Reflection Pattern.
workflow.addConditionalEdges(
  "critique",
  (state: typeof GraphState.State) => {
    // If the critique approves OR we hit max iterations -> Go to Finalize
    if (state.iteration >= 3 || state.isApproved) {
      return "finalize";
    }
    // Otherwise, loop back to Generate for refinement
    return "generate";
  }
);

// 4. Finalize -> End
workflow.addEdge("finalize", END);

// Compile the graph
const app = workflow.compile();

// --- 4. Next.js API Route ---

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  const { prompt } = req.body;

  if (!prompt) {
    return res.status(400).json({ error: 'Prompt is required' });
  }

  try {
    // Initialize the state with the user prompt
    const initialState = {
      prompt,
      generatedCode: "",
      critique: "",
      iteration: 0,
      finalCode: "",
    };

    // Execute the graph stream
    // Note: In a real production app, you might use .streamEvents for real-time UI updates
    const finalState = await app.invoke(initialState);

    // Return the result to the client
    res.status(200).json({
      success: true,
      iterations: finalState.iteration,
      critique: finalState.critique,
      code: finalState.finalCode,
    });

  } catch (error) {
    console.error("Graph execution error:", error);
    res.status(500).json({ error: "Internal server error" });
  }
}
