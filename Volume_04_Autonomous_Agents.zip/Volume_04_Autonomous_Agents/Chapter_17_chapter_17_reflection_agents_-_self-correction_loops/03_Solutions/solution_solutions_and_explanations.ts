/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

import { StateGraph, Annotation, END, START } from "@langchain/langgraph";
import { ChatOpenAI } from "@langchain/openai";

// 1. State Definition
const DraftingState = Annotation.Root({
  topic: Annotation<string>(),
  draft: Annotation<string>({
    reducer: (state, update) => update, // Simply replace
    default: () => "",
  }),
  critique: Annotation<string>({
    reducer: (state, update) => update,
    default: () => "",
  }),
  iteration: Annotation<number>({
    reducer: (state, update) => update,
    default: () => 0,
  }),
  status: Annotation<'drafting' | 'critiquing' | 'refining' | 'complete'>({
    reducer: (state, update) => update,
    default: () => 'drafting',
  }),
});

// Initialize LLM
const llm = new ChatOpenAI({ model: "gpt-4o-mini", temperature: 0.7 });

// 2. Graph Nodes
const generateDraft = async (state: typeof DraftingState.State) => {
  console.log("--- Generating Draft ---");
  const prompt = `Write a short, coherent paragraph on the topic: "${state.topic}".`;
  const response = await llm.invoke(prompt);
  
  return {
    draft: response.content as string,
    iteration: state.iteration + 1,
    status: 'critiquing' as const,
  };
};

const critiqueDraft = async (state: typeof DraftingState.State) => {
  console.log("--- Critiquing Draft ---");
  const prompt = `Critique the following draft for clarity, coherence, and relevance to the topic "${state.topic}". 
  Provide a boolean flag 'is_satisfactory'. If the draft is good enough, set it to true. Otherwise, false.
  
  Draft: "${state.draft}"
  
  Format your response as JSON: { "critique": "string", "is_satisfactory": boolean }`;
  
  const response = await llm.invoke(prompt);
  // Note: In production, use output parsers. For this exercise, we parse manually or assume structured output.
  // Simulating parsed response for the sake of the exercise logic:
  const isSatisfactory = (response.content as string).toLowerCase().includes("satisfactory: true"); 
  const critiqueText = response.content as string;

  return {
    critique: critiqueText,
    status: 'refining' as const,
    // We do not update 'is_satisfactory' in state here, we use it for conditional routing
  };
};

const refineDraft = async (state: typeof DraftingState.State) => {
  console.log("--- Refining Draft ---");
  const prompt = `Refine the following draft based on the critique provided. 
  Original Topic: "${state.topic}"
  Draft: "${state.draft}"
  Critique: "${state.critique}"
  
  Provide the improved version.`;
  
  const response = await llm.invoke(prompt);

  return {
    draft: response.content as string,
    iteration: state.iteration + 1,
    status: 'critiquing' as const,
  };
};

// 3. Graph Structure
const workflow = new StateGraph(DraftingState)
  .addNode("generateDraft", generateDraft)
  .addNode("critiqueDraft", critiqueDraft)
  .addNode("refineDraft", refineDraft)
  .addEdge(START, "generateDraft")
  .addEdge("generateDraft", "critiqueDraft")
  .addEdge("refineDraft", "critiqueDraft");

// 4. Cyclical Logic
const MAX_ITERATIONS = 3;

const routeCritique = (state: typeof DraftingState.State) => {
  // Helper to extract boolean (simulated logic)
  const isSatisfactory = state.critique.includes("satisfactory: true");
  
  if (isSatisfactory || state.iteration >= MAX_ITERATIONS) {
    return END;
  }
  return "refineDraft";
};

workflow.addConditionalEdges("critiqueDraft", routeCritique);

const app = workflow.compile();

// Example Usage (Mocked for context)
// const inputs = { topic: "The impact of AI on modern software development" };
// const finalState = await app.invoke(inputs);
