/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.tsx
// Description: Solutions and Explanations
// ==========================================

import React from 'react';

// Define the state interface matching Exercise 1
interface DraftingState {
  topic: string;
  draft: string;
  critique: string;
  iteration: number;
  status: 'drafting' | 'critiquing' | 'refining' | 'complete';
}

interface ReflectionVisualizerProps {
  state: DraftingState;
}

const MAX_ITERATIONS = 3;

const ReflectionVisualizer: React.FC<ReflectionVisualizerProps> = ({ state }) => {
  // Helper for status styling
  const getStatusColor = (status: string) => {
    switch (status) {
      case 'drafting': return '#3498db'; // Blue
      case 'critiquing': return '#f39c12'; // Orange
      case 'refining': return '#9b59b6'; // Purple
      case 'complete': return '#2ecc71'; // Green
      default: return '#7f8c8d'; // Gray
    }
  };

  // Calculate progress percentage
  const progress = (state.iteration / MAX_ITERATIONS) * 100;

  return (
    <div style={styles.container}>
      {/* Status Indicator */}
      <div style={{ ...styles.statusBadge, backgroundColor: getStatusColor(state.status) }}>
        {state.status.toUpperCase()}
      </div>

      {/* Iteration Counter */}
      <div style={styles.iterationDisplay}>
        Iteration: {state.iteration} / {MAX_ITERATIONS}
      </div>

      {/* Progress Bar */}
      <div style={styles.progressBarContainer}>
        <div 
          style={{ 
            ...styles.progressBarFill, 
            width: `${Math.min(progress, 100)}%` 
          }} 
        />
      </div>

      {/* Text Panels */}
      <div style={styles.panelContainer}>
        <div style={styles.panel}>
          <strong>Topic:</strong>
          <p>{state.topic}</p>
        </div>

        <div style={styles.panel}>
          <strong>Draft:</strong>
          <pre style={styles.textArea}>
            {state.draft || "Generating draft..."}
          </pre>
        </div>

        <div style={styles.panel}>
          <strong>Critique:</strong>
          <pre style={styles.textArea}>
            {state.critique || "Waiting for critique..."}
          </pre>
        </div>
      </div>
    </div>
  );
};

// Basic CSS-in-JS styles for a clean look
const styles: Record<string, React.CSSProperties> = {
  container: {
    fontFamily: 'Arial, sans-serif',
    border: '1px solid #ddd',
    borderRadius: '8px',
    padding: '20px',
    maxWidth: '600px',
    margin: '20px auto',
    boxShadow: '0 2px 4px rgba(0,0,0,0.1)',
    backgroundColor: '#f9f9f9',
  },
  statusBadge: {
    display: 'inline-block',
    padding: '5px 10px',
    borderRadius: '4px',
    color: 'white',
    fontWeight: 'bold',
    marginBottom: '10px',
  },
  iterationDisplay: {
    fontSize: '1.1em',
    marginBottom: '10px',
    fontWeight: 'bold',
  },
  progressBarContainer: {
    height: '10px',
    backgroundColor: '#e0e0e0',
    borderRadius: '5px',
    marginBottom: '20px',
    overflow: 'hidden',
  },
  progressBarFill: {
    height: '100%',
    backgroundColor: '#2ecc71',
    transition: 'width 0.3s ease',
  },
  panelContainer: {
    display: 'flex',
    flexDirection: 'column',
    gap: '15px',
  },
  panel: {
    padding: '10px',
    backgroundColor: 'white',
    border: '1px solid #eee',
    borderRadius: '4px',
  },
  textArea: {
    whiteSpace: 'pre-wrap',
    marginTop: '5px',
    fontFamily: 'monospace',
    fontSize: '0.9em',
    backgroundColor: '#f4f4f4',
    padding: '8px',
    borderRadius: '4px',
    minHeight: '50px',
  }
};

export default ReflectionVisualizer;
