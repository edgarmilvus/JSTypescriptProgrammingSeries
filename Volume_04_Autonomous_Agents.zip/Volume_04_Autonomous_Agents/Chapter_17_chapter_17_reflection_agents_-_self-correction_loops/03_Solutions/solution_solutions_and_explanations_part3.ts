/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

import { StateGraph, Annotation, END, START } from "@langchain/langgraph";
import { ChatOpenAI } from "@langchain/openai";

// 1. State Definition
const CodeReviewState = Annotation.Root({
  userRequest: Annotation<string>(),
  generatedCode: Annotation<string>({
    reducer: (state, update) => update,
    default: () => "",
  }),
  reviewComments: Annotation<string>({
    reducer: (state, update) => update,
    default: () => "",
  }),
  iteration: Annotation<number>({
    reducer: (state, update) => update,
    default: () => 0,
  }),
  isApproved: Annotation<boolean>({
    reducer: (state, update) => update,
    default: () => false,
  }),
});

const llm = new ChatOpenAI({ model: "gpt-4o-mini", temperature: 0.3 });

// 2. Agent Nodes
const codeGeneratorNode = async (state: typeof CodeReviewState.State) => {
  console.log("--- Code Generator Running ---");
  // The prompt incorporates previous review comments if they exist
  const prompt = `You are a Python expert. Write a clean, efficient Python function that fulfills the following request: "${state.userRequest}".
  
  ${state.reviewComments ? `Previous Review Comments: "${state.reviewComments}". Please incorporate these changes.` : ''}
  
  Return ONLY the code block.`;

  const response = await llm.invoke(prompt);
  
  return {
    generatedCode: response.content as string,
    iteration: state.iteration + 1,
  };
};

const codeReviewerNode = async (state: typeof CodeReviewState.State) => {
  console.log("--- Code Reviewer Running ---");
  const prompt = `You are a meticulous code reviewer. Analyze the following Python code for bugs, style issues (PEP 8), and inefficiencies. 
  Provide a detailed critique. If the code is perfect and meets all requirements, state 'APPROVED' at the end of your critique.
  
  Code: "${state.generatedCode}"
  
  Review:`;

  const response = await llm.invoke(prompt);
  const comments = response.content as string;
  const isApproved = comments.includes("APPROVED");

  return {
    reviewComments: comments,
    isApproved: isApproved,
  };
};

// 3. Graph Structure
const workflow = new StateGraph(CodeReviewState)
  .addNode("codeGeneratorNode", codeGeneratorNode)
  .addNode("codeReviewerNode", codeReviewerNode)
  .addEdge(START, "codeGeneratorNode")
  .addEdge("codeGeneratorNode", "codeReviewerNode");

// 4. Supervisor Logic (Conditional Edge)
const routeReview = (state: typeof CodeReviewState.State) => {
  if (state.isApproved) {
    console.log("--- Code Approved. Ending Process. ---");
    return END;
  }
  console.log("--- Code Rejected. Looping back to Generator. ---");
  return "codeGeneratorNode";
};

workflow.addConditionalEdges("codeReviewerNode", routeReview);

const app = workflow.compile();

// Example Usage (Mocked)
// const inputs = { userRequest: "Write a function to calculate factorial" };
// const finalState = await app.invoke(inputs);
