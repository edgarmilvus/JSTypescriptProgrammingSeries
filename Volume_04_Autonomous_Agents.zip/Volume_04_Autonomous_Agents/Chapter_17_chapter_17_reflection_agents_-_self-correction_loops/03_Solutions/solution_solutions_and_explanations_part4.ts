/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

import { StateGraph, Annotation, END, START } from "@langchain/langgraph";
import { ChatOpenAI } from "@langchain/openai";

// 1. Enhanced State Definition
const DynamicDraftingState = Annotation.Root({
  topic: Annotation<string>(),
  criteria: Annotation<string[]>({
    reducer: (state, update) => update,
    default: () => [],
  }),
  draft: Annotation<string>({
    reducer: (state, update) => update,
    default: () => "",
  }),
  critique: Annotation<string>({
    reducer: (state, update) => update,
    default: () => "",
  }),
  score: Annotation<number>({
    reducer: (state, update) => update,
    default: () => 0,
  }),
  iteration: Annotation<number>({
    reducer: (state, update) => update,
    default: () => 0,
  }),
});

const llm = new ChatOpenAI({ model: "gpt-4o-mini", temperature: 0.7 });

// 2. Dynamic Nodes
const generateDraft = async (state: typeof DynamicDraftingState.State) => {
  const prompt = `Write a short paragraph on the topic: "${state.topic}".`;
  const response = await llm.invoke(prompt);
  return {
    draft: response.content as string,
    iteration: state.iteration + 1,
  };
};

const critiqueDraft = async (state: typeof DynamicDraftingState.State) => {
  // Convert array of criteria to a string for the prompt
  const criteriaList = state.criteria.map((c, i) => `${i + 1}. ${c}`).join("\n");
  
  const prompt = `Critique the following draft based on these specific user criteria:
  ${criteriaList}
  
  Draft: "${state.draft}"
  
  1. Provide a numerical score (0-100) based on how well the draft meets the criteria.
  2. Provide specific feedback.
  3. Format your response as JSON: { "score": number, "critique": "string" }`;

  const response = await llm.invoke(prompt);
  
  // Simulate parsing the JSON response (in a real app, use a parser)
  // For this exercise, we assume the LLM returns a structured string we can parse
  // Mocking the parsed result for the logic to work:
  const parsedResponse = {
    score: 90, // Mocked high score
    critique: (response.content as string) // Actual LLM content
  };

  return {
    score: parsedResponse.score,
    critique: parsedResponse.critique,
  };
};

const refineDraft = async (state: typeof DynamicDraftingState.State) => {
  const prompt = `Refine the draft based on the critique: "${state.critique}".\nDraft: "${state.draft}"`;
  const response = await llm.invoke(prompt);
  return {
    draft: response.content as string,
    iteration: state.iteration + 1,
  };
};

// 3. Graph Setup
const workflow = new StateGraph(DynamicDraftingState)
  .addNode("generateDraft", generateDraft)
  .addNode("critiqueDraft", critiqueDraft)
  .addNode("refineDraft", refineDraft)
  .addEdge(START, "generateDraft")
  .addEdge("generateDraft", "critiqueDraft")
  .addEdge("refineDraft", "critiqueDraft");

// 4. Dynamic Conditional Logic
const MAX_ITERATIONS = 3;
const PASSING_THRESHOLD = 85;

const routeCritique = (state: typeof DynamicDraftingState.State) => {
  // Check score against the dynamic threshold
  if (state.score >= PASSING_THRESHOLD || state.iteration >= MAX_ITERATIONS) {
    return END;
  }
  return "refineDraft";
};

workflow.addConditionalEdges("critiqueDraft", routeCritique);

const app = workflow.compile();

// --- Interactive Prompt Response: Initial State Object ---
const initialMarketingState = {
  topic: "New Product Launch: Smart Coffee Mug",
  criteria: [
    "Create a sense of urgency",
    "Highlight the unique 'temperature control' feature",
    "Include a discount code 'LAUNCH15'"
  ],
  draft: "", // Empty initially
  critique: "",
  score: 0,
  iteration: 0,
};

// Example Usage:
// const finalState = await app.invoke(initialMarketingState);
