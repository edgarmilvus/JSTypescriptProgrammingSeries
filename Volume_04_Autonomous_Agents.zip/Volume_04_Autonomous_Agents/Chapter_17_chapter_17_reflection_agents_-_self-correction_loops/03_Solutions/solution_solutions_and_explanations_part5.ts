/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

import { StateGraph, Annotation, END, START } from "@langchain/langgraph";
import { ChatOpenAI } from "@langchain/openai";

// 1. Enhanced State Definition
const RobustDraftingState = Annotation.Root({
  topic: Annotation<string>(),
  draft: Annotation<string>({
    reducer: (state, update) => update,
    default: () => "",
  }),
  critique: Annotation<string>({
    reducer: (state, update) => update,
    default: () => "",
  }),
  iteration: Annotation<number>({
    reducer: (state, update) => update,
    default: () => 0,
  }),
  failureCount: Annotation<number>({
    reducer: (state, update) => update,
    default: () => 0,
  }),
  status: Annotation<'drafting' | 'critiquing' | 'refining' | 'complete' | 'failed'>({
    reducer: (state, update) => update,
    default: () => 'drafting',
  }),
});

const llm = new ChatOpenAI({ model: "gpt-4o-mini", temperature: 0.7 });

// 2. Nodes
const generateDraft = async (state: typeof RobustDraftingState.State) => {
  const prompt = `Write a paragraph on: "${state.topic}".`;
  const response = await llm.invoke(prompt);
  return {
    draft: response.content as string,
    iteration: state.iteration + 1,
    status: 'critiquing' as const,
  };
};

const critiqueDraft = async (state: typeof RobustDraftingState.State) => {
  const prompt = `Critique the draft: "${state.draft}". Is it satisfactory? Respond with "SATISFACTORY" or "FAIL".`;
  const response = await llm.invoke(prompt);
  const isFail = !(response.content as string).includes("SATISFACTORY");
  
  // Logic: Increment failure count if fail, reset if satisfactory
  const newFailureCount = isFail ? state.failureCount + 1 : 0;

  return {
    critique: response.content as string,
    failureCount: newFailureCount,
    status: isFail ? 'refining' : 'complete',
  };
};

const refineDraft = async (state: typeof RobustDraftingState.State) => {
  const prompt = `Refine the draft: "${state.draft}" based on critique: "${state.critique}"`;
  const response = await llm.invoke(prompt);
  return {
    draft: response.content as string,
    status: 'critiquing' as const,
  };
};

const fallbackNode = async (state: typeof RobustDraftingState.State) => {
  console.log("--- Entering Fallback Mode ---");
  return {
    status: 'failed' as const,
    critique: "System Error: Unable to generate satisfactory draft after 3 consecutive failures. Please revise topic or criteria.",
  };
};

// 3. Graph Structure
const workflow = new StateGraph(RobustDraftingState)
  .addNode("generateDraft", generateDraft)
  .addNode("critiqueDraft", critiqueDraft)
  .addNode("refineDraft", refineDraft)
  .addNode("fallbackNode", fallbackNode)
  .addEdge(START, "generateDraft")
  .addEdge("generateDraft", "critiqueDraft")
  .addEdge("refineDraft", "critiqueDraft");

// 4. Complex Conditional Edges
const routeCritique = (state: typeof RobustDraftingState.State) => {
  // Extract satisfaction from critique response (mocked logic)
  const isSatisfactory = state.critique.includes("SATISFACTORY");

  if (isSatisfactory) {
    return END;
  }

  // Check failure count. 
  // Note: state.failureCount was already incremented in the node logic
  if (state.failureCount >= 3) {
    return "fallbackNode";
  }

  return "refineDraft";
};

workflow.addConditionalEdges("critiqueDraft", routeCritique);
// Fallback node goes to END
workflow.addEdge("fallbackNode", END);

const app = workflow.compile();
