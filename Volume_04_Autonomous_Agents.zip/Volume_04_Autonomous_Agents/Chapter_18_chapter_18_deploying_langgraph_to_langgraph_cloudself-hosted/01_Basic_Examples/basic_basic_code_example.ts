/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * @fileoverview A basic LangGraph example for a SaaS feature request workflow.
 * This file defines the graph state, nodes, and the graph structure.
 * It is designed to be deployed via langgraph.json.
 */

// 1. IMPORTS
// ---------------------------------------------------------------------------
// We import the necessary classes from the LangGraph library.
import { StateGraph, Annotation } from "@langchain/langgraph";

// 2. DEFINE THE GRAPH STATE
// ---------------------------------------------------------------------------
// The Graph State is the single source of truth for the workflow.
// It holds data that persists between nodes.
// We use TypeScript's type inference for safety.

const GraphState = Annotation.Root({
  // The raw input from the user (e.g., "Add dark mode to the dashboard").
  userInput: Annotation<string>({
    reducer: (curr, update) => update, // Simple replacement logic
    default: () => "",
  }),

  // The result of the validation step.
  isValid: Annotation<boolean>({
    reducer: (curr, update) => update,
    default: () => false,
  }),

  // The final routing decision (e.g., "development" or "feedback").
  route: Annotation<string>({
    reducer: (curr, update) => update,
    default: () => "",
  }),
});

// 3. DEFINE NODES
// ---------------------------------------------------------------------------
// Nodes are the computational units of the graph.
// Each node is an async function that accepts the current state and returns a partial state update.

/**
 * Entry Point Node: Validates the user's feature request.
 * This is the first step executed in the workflow.
 * @param state - The current Graph State containing the user input.
 * @returns - An object containing the validation result.
 */
async function validateRequest(
  state: typeof GraphState.State
): Promise<Partial<typeof GraphState.State>> {
  console.log("--- Node: Validating Request ---");
  
  // Simulate validation logic (e.g., checking length or keywords).
  const input = state.userInput;
  const isValid = input.length > 5 && input.includes("feature");
  
  // Return the update to the state.
  return {
    isValid: isValid,
  };
}

/**
 * Decision Node: Determines where the request should go.
 * This node acts as a router based on the validation result.
 * @param state - The current Graph State containing validation status.
 * @returns - The routing decision.
 */
async function decideRoute(
  state: typeof GraphState.State
): Promise<Partial<typeof GraphState.State>> {
  console.log("--- Node: Deciding Route ---");

  if (state.isValid) {
    console.log("Request is valid. Routing to Development.");
    return { route: "development" };
  } else {
    console.log("Request is invalid. Routing to Feedback.");
    return { route: "feedback" };
  }
}

// 4. BUILD THE GRAPH
// ---------------------------------------------------------------------------
// We instantiate the StateGraph, add nodes, and define edges (transitions).

// Initialize the graph with the defined state schema.
const workflow = new StateGraph(GraphState);

// Add the nodes to the graph.
// The string key is the unique identifier for the node.
workflow.addNode("validate_node", validateRequest);
workflow.addNode("route_node", decideRoute);

// Define the edges (control flow).
// 1. Set the Entry Point: The execution always starts here.
workflow.setEntryPoint("validate_node");

// 2. Define the transition from Entry Point to the next node.
// After 'validate_node' completes, move to 'route_node'.
workflow.addEdge("validate_node", "route_node");

// 3. Define the Exit Point (End).
// Once 'route_node' finishes, the graph execution stops.
workflow.setFinishPoint("route_node");

// 5. COMPILE THE GRAPH
// ---------------------------------------------------------------------------
// Compiling the graph creates the executable runtime object.
// This compiled object is what LangGraph Cloud or LangServe exposes as an API.
const app = workflow.compile();

// Export the compiled app for deployment.
export { app as graph };
