/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script_part2.ts
// Description: Advanced Application Script
// ==========================================

// app/api/chat/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';

// ============================================================================
// 1. CONFIGURATION & TYPES
// ============================================================================

/**
 * Configuration for the Edge-First deployment.
 * In a real scenario, these would be pulled from process.env.
 */
const LANGGRAPH_ENDPOINT = process.env.LANGGRAPH_SELF_HOSTED_URL || "http://localhost:8000";
const API_KEY = process.env.LANGGRAPH_API_KEY;

/**
 * Schema for the incoming request from the client (Web App/SaaS).
 * Validates payload before processing.
 */
const RequestSchema = z.object({
  userId: z.string().uuid(),
  query: z.string().min(1).max(1000),
  threadId: z.string().uuid().optional(), // For resuming conversations
});

/**
 * Types for the Graph State managed by the Checkpointer.
 * This represents the "Source of Truth" persisted in Redis/SQL.
 */
export interface SupportGraphState {
  messages: Array<{ role: 'user' | 'assistant' | 'system'; content: string }>;
  classification: 'billing' | 'technical' | 'general' | null;
  escalated: boolean;
  metadata: {
    timestamp: number;
    source: 'web_app';
  };
}

// ============================================================================
// 2. EDGE-FIRST VALIDATION & PRE-PROCESSING
// ============================================================================

/**
 * Entry Point: Next.js API Route (Edge Runtime).
 * 
 * Why Edge Runtime?
 * - Reduces cold starts.
 * - Runs physically closer to the user.
 * - Handles lightweight logic (validation, auth, initial routing) instantly.
 */
export const runtime = 'edge';

export async function POST(req: NextRequest) {
  try {
    // --- Step A: Edge Validation ---
    // We validate the schema at the edge to prevent invalid requests 
    // from ever reaching the LangGraph backend (Cost saving).
    const body = await req.json();
    const validation = RequestSchema.safeParse(body);

    if (!validation.success) {
      return NextResponse.json(
        { error: "Invalid Input", details: validation.error.flatten() },
        { status: 400 }
      );
    }

    const { userId, query, threadId } = validation.data;

    // --- Step B: Lightweight Classification (The "Edge" Logic) ---
    // Instead of sending raw data to the LLM immediately, we use a simple 
    // keyword heuristic or a tiny model to route traffic.
    // This is the "Edge-First" philosophy: filter and route cheaply.
    const initialClassification = classifyQueryAtEdge(query);

    // --- Step C: Prepare State for LangGraph ---
    // If we have a threadId, we are resuming. If not, we initialize state.
    const initialState: SupportGraphState = {
      messages: [{ role: 'user', content: query }],
      classification: initialClassification,
      escalated: false,
      metadata: {
        timestamp: Date.now(),
        source: 'web_app',
      },
    };

    // --- Step D: Invoke LangGraph Backend ---
    // We delegate the heavy lifting (LLM calls, complex conditional edges) 
    // to the self-hosted LangGraph instance.
    const graphResponse = await fetch(`${LANGGRAPH_ENDPOINT}/invoke`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${API_KEY}`,
      },
      body: JSON.stringify({
        input: initialState,
        config: {
          configurable: {
            // Passing the thread_id enables the Checkpointer to hydrate previous state
            thread_id: threadId || crypto.randomUUID(),
          },
        },
      }),
    });

    if (!graphResponse.ok) {
      throw new Error(`LangGraph Error: ${graphResponse.statusText}`);
    }

    const result = await graphResponse.json();

    // --- Step E: Post-Processing & Response ---
    // We format the final output back to the client.
    const finalOutput = {
      response: result.output?.messages?.at(-1)?.content || "Process completed.",
      threadId: result.thread_id,
      classification: result.output?.classification,
    };

    return NextResponse.json(finalOutput, { status: 200 });

  } catch (error) {
    console.error("Edge Processing Error:", error);
    return NextResponse.json(
      { error: "Internal Server Error" },
      { status: 500 }
    );
  }
}

// ============================================================================
// 3. HELPER: EDGE CLASSIFICATION LOGIC
// ============================================================================

/**
 * Simulates a lightweight classification function running at the Edge.
 * 
 * Logic:
 * - Checks for specific keywords to route traffic.
 * - Avoids LLM calls here to maintain low latency.
 * 
 * @param query - The user's input string
 * @returns The initial classification label
 */
function classifyQueryAtEdge(query: string): SupportGraphState['classification'] {
  const lowerQuery = query.toLowerCase();

  if (lowerQuery.includes('refund') || lowerQuery.includes('invoice') || lowerQuery.includes('charge')) {
    return 'billing';
  }
  
  if (lowerQuery.includes('bug') || lowerQuery.includes('error') || lowerQuery.includes('crash')) {
    return 'technical';
  }

  return 'general';
}
