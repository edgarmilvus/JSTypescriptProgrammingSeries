/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script_part3.ts
// Description: Advanced Application Script
// ==========================================

// src/app/api/chat/graph.ts
import { StateGraph, START, END } from "@langchain/langgraph";
import { MemorySaver } from "@langchain/langgraph";
import { SupportGraphState } from "./route";

// 1. Define the Checkpointer (Redis/SQL in production)
const checkpointer = new MemorySaver();

// 2. Define Nodes (LLM Calls, API Calls)
const billingNode = async (state: SupportGraphState) => {
  // Simulate LLM call for billing
  return { 
    messages: [...state.messages, { role: 'assistant', content: "I see your invoice. Let's process that refund." }] 
  };
};

const technicalNode = async (state: SupportGraphState) => {
  // Simulate LLM call for technical support
  return { 
    messages: [...state.messages, { role: 'assistant', content: "Please try clearing your cache. If that fails, I will escalate to engineering." }] 
  };
};

const generalNode = async (state: SupportGraphState) => {
  return { 
    messages: [...state.messages, { role: 'assistant', content: "How else can I help you today?" }] 
  };
};

// 3. Define Conditional Edge (The Routing Logic)
const router = (state: SupportGraphState) => {
  if (state.classification === 'billing') return 'billing_node';
  if (state.classification === 'technical') return 'technical_node';
  return 'general_node';
};

// 4. Construct the Graph
const workflow = new StateGraph<SupportGraphState>({
  channels: {
    messages: { reducer: (state, update) => [...state, ...update], default: () => [] },
    classification: { reducer: (state, update) => update ?? state, default: () => null },
    escalated: { reducer: (state, update) => update ?? state, default: () => false },
    metadata: { reducer: (state, update) => ({ ...state, ...update }), default: () => ({}) },
  }
})
  .addNode('billing_node', billingNode)
  .addNode('technical_node', technicalNode)
  .addNode('general_node', generalNode)
  .addEdge(START, 'router')
  .addConditionalEdges('router', router)
  .addEdge('billing_node', END)
  .addEdge('technical_node', END)
  .addEdge('general_node', END);

// 5. Compile with Checkpointer
export const workflowWithCheckpointer = workflow.compile({ checkpointer });
