/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

import { StateGraph, START, END, MemorySaver } from "@langchain/langgraph";

// 1. Define the State Interface
interface SupportState {
  conversation_id: string;
  user_query: string;
  agent_response: string;
  status: 'pending' | 'approved' | 'rejected';
  messages: any[];
}

// Define the graph channels (state reducers)
const channels = {
  conversation_id: { reducer: (state: string, update: string) => update, default: () => "" },
  user_query: { reducer: (state: string, update: string) => update, default: () => "" },
  agent_response: { reducer: (state: string, update: string) => update, default: () => "" },
  status: { 
    reducer: (state: 'pending' | 'approved' | 'rejected', update: 'pending' | 'approved' | 'rejected') => update, 
    default: () => 'pending' 
  },
  messages: { reducer: (state: any[], update: any[]) => [...state, ...update], default: () => [] },
};

// 2. Initialize Checkpointer
const checkpointer = new MemorySaver();

// Define Nodes
const generateResponse = async (state: SupportState) => {
  // Simulate LLM call
  console.log("Generating response...");
  return { 
    agent_response: "I can help with that. Awaiting approval.", 
    status: 'pending' // Set status to pending to trigger pause
  };
};

const waitForApproval = async (state: SupportState) => {
  // This node acts as a breakpoint. 
  // If state.status is 'pending', the graph pauses here.
  // If 'approved', it effectively skips this logic or passes through.
  console.log("Waiting for approval...");
  return { status: state.status };
};

const finalResponse = async (state: SupportState) => {
  console.log("Finalizing...");
  return { agent_response: "Request processed successfully." };
};

// 3. Build Graph with Conditional Edges
const graph = new StateGraph<SupportState>({ channels })
  .addNode("generate", generateResponse)
  .addNode("wait", waitForApproval)
  .addNode("finalize", finalResponse)
  .addEdge(START, "generate")
  // Conditional edge: If status is 'pending', go to 'wait'. Otherwise, go to 'finalize'.
  .addConditionalEdges("generate", (state) => {
    if (state.status === 'pending') return "wait";
    return "finalize";
  })
  .addEdge("wait", "finalize")
  .addEdge("finalize", END);

// Compile with the checkpointer
export const app = graph.compile({ checkpointer });

// --- Usage Logic ---

// Function to resume conversation
async function resumeConversation(threadId: string, newStatus: 'approved' | 'rejected') {
  const config = { configurable: { thread_id: threadId } };
  
  // 1. Retrieve current state (implicitly done by invoking with the same thread_id)
  // 2. Update the state with the approval decision
  // We use updateState to inject the approval without re-running the 'generate' node
  await app.updateState(config, { status: newStatus });
  
  // 3. Continue execution from the last known checkpoint
  // Passing null as the input tells the graph to resume from where it left off
  const result = await app.invoke(null, config);
  return result;
}

// Example Execution Flow
async function runExample() {
  const config = { configurable: { thread_id: "conv_123" } };
  
  // Initial Run (Will pause at 'wait')
  await app.invoke({ 
    conversation_id: "conv_123", 
    user_query: "Help me reset my password" 
  }, config);

  // Resume Run (Simulating human approval)
  await resumeConversation("conv_123", 'approved');
}

// runExample();
