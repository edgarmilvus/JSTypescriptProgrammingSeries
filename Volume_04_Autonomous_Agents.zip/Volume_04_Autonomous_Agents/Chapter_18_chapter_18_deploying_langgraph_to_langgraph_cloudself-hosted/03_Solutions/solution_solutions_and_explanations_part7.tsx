/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part7.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState, useEffect } from 'react';

// Types
interface DeploymentStatus {
  status: 'building' | 'deploying' | 'ready' | 'error';
  errorMessage?: string;
}

interface DeploymentStatusMonitorProps {
  deploymentId: string;
}

const DeploymentStatusMonitor: React.FC<DeploymentStatusMonitorProps> = ({ deploymentId }) => {
  const [statusData, setStatusData] = useState<DeploymentStatus | null>(null);
  const [polling, setPolling] = useState(true);

  useEffect(() => {
    let intervalId: NodeJS.Timeout;

    const fetchStatus = async () => {
      try {
        // Mocking API call
        // const response = await fetch(`/api/deployments/${deploymentId}`);
        // const data: DeploymentStatus = await response.json();
        
        // --- MOCK DATA FOR DEMONSTRATION ---
        // Simulating state changes for the sake of the exercise
        const mockData: DeploymentStatus = (() => {
            // This logic simulates the server returning different states over time
            // In a real app, this comes from the backend
            const now = Date.now();
            if (now % 3 === 0) return { status: 'building' };
            if (now % 3 === 1) return { status: 'deploying' };
            if (now % 3 === 2) return { status: 'ready' };
            return { status: 'building' };
        })();
        // ------------------------------------

        setStatusData(mockData);

        // Stop polling if the deployment is finished or errored
        if (mockData.status === 'ready' || mockData.status === 'error') {
          setPolling(false);
        }
      } catch (error) {
        setStatusData({ status: 'error', errorMessage: 'Network error' });
        setPolling(false);
      }
    };

    if (polling) {
      fetchStatus(); // Fetch immediately
      intervalId = setInterval(fetchStatus, 3000); // Poll every 3s
    }

    // Cleanup interval on unmount or when polling stops
    return () => {
      if (intervalId) clearInterval(intervalId);
    };
  }, [deploymentId, polling]);

  // Calculate Progress Bar Width
  const getProgressWidth = (stage: string) => {
    switch (stage) {
      case 'building': return '33%';
      case 'deploying': return '66%';
      case 'ready': return '100%';
      default: return '0%';
    }
  };

  if (!statusData) return <div>Loading status...</div>;

  return (
    <div style={{ padding: '20px', border: '1px solid #ccc', borderRadius: '8px', maxWidth: '400px' }}>
      <h3>Deployment Status: {statusData.status.toUpperCase()}</h3>
      
      {/* Progress Bar Visualization */}
      {statusData.status !== 'error' && (
        <div style={{ width: '100%', backgroundColor: '#e0e0e0', borderRadius: '4px', height: '20px', overflow: 'hidden' }}>
          <div 
            style={{ 
              width: getProgressWidth(statusData.status), 
              backgroundColor: '#4caf50', 
              height: '100%', 
              transition: 'width 0.5s ease' 
            }} 
          />
        </div>
      )}

      {/* Error Alert */}
      {statusData.status === 'error' && (
        <div style={{ 
          backgroundColor: '#ffebee', 
          color: '#c62828', 
          padding: '10px', 
          marginTop: '10px', 
          border: '1px solid #ef9a9a',
          borderRadius: '4px'
        }}>
          <strong>Error:</strong> {statusData.errorMessage}
        </div>
      )}
    </div>
  );
};

export default DeploymentStatusMonitor;
