/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part4.ts
// Description: Practical Exercises
// ==========================================

import { StateGraph, START, END, MemorySaver } from "@langchain/langgraph";

interface SupportState {
  conversation_id: string;
  user_query: string;
  agent_response: string;
  status: 'pending' | 'approved' | 'rejected';
  messages: any[];
}

// Define the graph channels
const channels = {
  conversation_id: {
    reducer: (state: string, update: string) => update,
    default: () => "",
  },
  user_query: {
    reducer: (state: string, update: string) => update,
    default: () => "",
  },
  agent_response: {
    reducer: (state: string, update: string) => update,
    default: () => "",
  },
  status: {
    reducer: (state: 'pending' | 'approved' | 'rejected', update: 'pending' | 'approved' | 'rejected') => update,
    default: () => 'pending',
  },
  messages: {
    reducer: (state: any[], update: any[]) => [...state, ...update],
    default: () => [],
  },
};

// Initialize checkpointer
const checkpointer = new MemorySaver();

// Define nodes
const generateResponse = async (state: SupportState) => {
  // Simulate LLM call
  return { agent_response: "I can help with that.", status: 'pending' };
};

const waitForApproval = async (state: SupportState) => {
  // This node acts as a breakpoint
  return { status: state.status };
};

const finalResponse = async (state: SupportState) => {
  return { agent_response: "Request processed successfully." };
};

// Build Graph
const graph = new StateGraph<SupportState>({ channels })
  .addNode("generate", generateResponse)
  .addNode("wait", waitForApproval)
  .addNode("finalize", finalResponse)
  .addEdge(START, "generate")
  .addConditionalEdges("generate", (state) => state.status === 'pending' ? "wait" : "finalize")
  .addEdge("wait", "finalize")
  .addEdge("finalize", END);

export const app = graph.compile({ checkpointer });

// Usage Example
// const config = { configurable: { thread_id: "conv_123" } };
// await app.invoke({ conversation_id: "conv_123", user_query: "Help me" }, config);
// await app.updateState(config, { status: 'approved' }); // Simulating approval
// await app.invoke(null, config);
