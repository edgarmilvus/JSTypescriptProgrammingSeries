/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * Simulated LangGraph Execution Result
 * Represents the structured response from the backend agent system.
 */
type AgentResponse = {
    nodeId: string; // The specific worker node that executed (e.g., "writer")
    content: string; // The actual generated text
    status: 'success' | 'error';
    timestamp: number;
};

/**
 * Simulated Frontend State for the Chat UI
 * Tracks messages, loading status, and potential errors.
 */
interface ChatState {
    messages: Array<{ role: 'user' | 'agent'; content: string }>;
    isStreaming: boolean; // True while the optimistic update is active
    error: string | null; // Populated if the backend execution fails
}

/**
 * Mock Backend API Call
 * Simulates a network request to a LangGraph.js server endpoint.
 * Introduces a delay to mimic LLM processing time.
 * @param query The user's input text.
 * @returns Promise<AgentResponse>
 */
async function callLangGraphAgent(query: string): Promise<AgentResponse> {
    // Simulate network latency (1.5 seconds)
    await new Promise(resolve => setTimeout(resolve, 1500));

    // Simulate a random failure (10% chance) to demonstrate rollback
    if (Math.random() < 0.1) {
        throw new Error("Tool execution timeout: Research API unavailable.");
    }

    // Simulate a successful response from the Supervisor/Worker
    return {
        nodeId: "writer",
        content: `Processed query: "${query}". I have synthesized the information.`,
        status: 'success',
        timestamp: Date.now()
    };
}

/**
 * Main Application Logic
 * Handles optimistic updates and state management.
 */
class ChatApp {
    private state: ChatState;

    constructor() {
        this.state = {
            messages: [],
            isStreaming: false,
            error: null
        };
        this.render(); // Initial render
    }

    /**
     * Handles the user submitting a message.
     * 1. Updates UI immediately (Optimistic).
     * 2. Calls the backend agent.
     * 3. Handles success or failure (Rollback).
     */
    async sendMessage(userInput: string) {
        if (!userInput.trim()) return;

        // --- STEP 1: OPTIMISTIC UPDATE ---
        // We immediately add the user message and a "pending" agent message.
        // This makes the UI feel instant.
        this.state.messages.push({ role: 'user', content: userInput });
        
        // Add a placeholder for the agent response
        this.state.messages.push({ role: 'agent', content: 'Thinking...' }); 
        
        this.state.isStreaming = true;
        this.state.error = null; // Clear previous errors
        this.render();

        try {
            // --- STEP 2: AWAIT BACKEND EXECUTION ---
            const result = await callLangGraphAgent(userInput);

            // --- STEP 3: COMMIT STATE ---
            // Replace the "Thinking..." placeholder with the actual result.
            // Note: In a real app, we might stream tokens here, 
            // updating the content incrementally.
            const lastMessageIndex = this.state.messages.length - 1;
            if (this.state.messages[lastMessageIndex].role === 'agent') {
                this.state.messages[lastMessageIndex].content = result.content;
            }
        } catch (error: any) {
            // --- STEP 4: ROLLBACK ON FAILURE ---
            // If the agent fails, we must remove the optimistic "Thinking..." message
            // to keep the UI consistent with the actual execution state.
            this.state.messages.pop(); 
            
            // Set the error state to show the user what happened
            this.state.error = error.message;
        } finally {
            // Reset loading state regardless of outcome
            this.state.isStreaming = false;
            this.render();
        }
    }

    /**
     * A simple render function to simulate updating the DOM.
     * In a real React app, this would be replaced by state setters triggering JSX re-renders.
     */
    private render() {
        const container = document.getElementById('chat-container') || { innerHTML: '' };
        
        // Generate HTML based on current state
        let html = `<div class="chat-window">`;
        
        // Render Messages
        this.state.messages.forEach(msg => {
            const alignment = msg.role === 'user' ? 'flex-end' : 'flex-start';
            const bg = msg.role === 'user' ? '#007bff' : '#e9ecef';
            const color = msg.role === 'user' ? 'white' : 'black';
            
            html += `
                <div style="display: flex; justify-content: ${alignment}; margin: 5px;">
                    <div style="background: ${bg}; color: ${color}; padding: 10px; border-radius: 10px; max-width: 80%;">
                        ${msg.content}
                        ${msg.content === 'Thinking...' ? ' <span class="loader"></span>' : ''}
                    </div>
                </div>
            `;
        });

        // Render Error State
        if (this.state.error) {
            html += `
                <div style="color: red; background: #ffeeba; padding: 10px; margin-top: 10px;">
                    <strong>Error:</strong> ${this.state.error}
                    <br><small>UI has rolled back to last known good state.</small>
                </div>
            `;
        }

        html += `</div>`;
        
        // Update DOM (Simulated)
        console.log("--- UI Render ---");
        console.log(JSON.stringify(this.state, null, 2));
        // In a real browser environment:
        // container.innerHTML = html;
    }
}

// --- USAGE EXAMPLE ---

// Initialize the app
const app = new ChatApp();

// Simulate user interactions
(async () => {
    console.log("1. User sends 'Hello'");
    await app.sendMessage("Hello");

    console.log("\n2. User sends 'Research AI trends'");
    await app.sendMessage("Research AI trends");
    
    console.log("\n3. User sends 'Fail me' (Triggers random failure)");
    await app.sendMessage("Fail me");
})();
