/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.tsx
// Description: Advanced Application Script
// ==========================================

import React, { useState, useRef, useEffect } from 'react';

// ==========================================
// 1. TYPE DEFINITIONS & INTERFACES
// ==========================================

/**
 * Represents a single message in the chat interface.
 * @property isUser - True if the message originated from the user.
 * @property content - The text content of the message.
 * @property status - The current rendering state (optimistic vs. processed).
 */
interface ChatMessage {
  id: string;
  isUser: boolean;
  content: string;
  status: 'pending' | 'streaming' | 'done' | 'error';
  // Optional: Tracks the specific agent (Supervisor vs. Executor) for UI distinction
  agentRole?: 'supervisor' | 'executor' | 'tool';
}

/**
 * Simulated event stream from the LangGraph backend.
 * In a real app, this would come from an SSE endpoint.
 */
interface AgentStreamEvent {
  type: 'thought' | 'tool_call' | 'final_answer' | 'error';
  payload: any;
  timestamp: number;
}

// ==========================================
// 2. MOCK BACKEND SERVICE (Simulating LangGraph)
// ==========================================

/**
 * Simulates a LangGraph execution flow.
 * In a real implementation, this would be a Next.js API Route
 * calling `await graph.streamEvents(...)` with `streamMode: "updates"`.
 */
const mockLangGraphExecution = async function* (userInput: string): AsyncGenerator<AgentStreamEvent, void, unknown> {
  // Simulate network latency
  await new Promise(resolve => setTimeout(resolve, 800));

  // Step 1: Supervisor receives the request
  yield {
    type: 'thought',
    payload: { role: 'supervisor', content: 'Received request. Analyzing intent...' },
    timestamp: Date.now()
  };

  // Step 2: Supervisor delegates to "Researcher" sub-agent
  yield {
    type: 'thought',
    payload: { role: 'supervisor', content: 'Delegating to Researcher Agent...' },
    timestamp: Date.now()
  };

  // Simulate sub-agent processing time
  await new Promise(resolve => setTimeout(resolve, 1200));

  // Step 3: Researcher calls a tool (e.g., SearchAPI)
  yield {
    type: 'tool_call',
    payload: { role: 'executor', tool: 'SearchAPI', query: userInput },
    timestamp: Date.now()
  };

  // Step 4: Researcher returns findings
  yield {
    type: 'thought',
    payload: { role: 'executor', content: 'Found relevant data. Synthesizing response...' },
    timestamp: Date.now()
  };

  // Step 5: Supervisor generates final answer
  await new Promise(resolve => setTimeout(resolve, 1000));
  
  // Simulate a random failure for rollback demonstration (10% chance)
  if (Math.random() < 0.1) {
    throw new Error('Tool Timeout: SearchAPI failed to respond.');
  }

  yield {
    type: 'final_answer',
    payload: { content: `Based on my research regarding "${userInput}", here is a summary of the findings...` },
    timestamp: Date.now()
  };
};

// ==========================================
// 3. REACT COMPONENT: AgentChatInterface
// ==========================================

export default function AgentChatInterface() {
  // State for the chat history
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  // State for the current user input
  const [input, setInput] = useState('');
  // State to track if an agent is currently running
  const [isProcessing, setIsProcessing] = useState(false);
  
  // Ref to store the state before optimistic updates for rollback capability
  const stateSnapshotRef = useRef<ChatMessage[] | null>(null);

  /**
   * Handles the user submitting a message.
   * Implements the Optimistic UI pattern.
   */
  const handleSendMessage = async () => {
    if (!input.trim() || isProcessing) return;

    const userMessageId = `msg_${Date.now()}`;
    const userMessage: ChatMessage = {
      id: userMessageId,
      isUser: true,
      content: input,
      status: 'done' // User messages are instantly 'done'
    };

    // 1. OPTIMISTIC UPDATE: Update UI immediately
    setMessages((prev) => [...prev, userMessage]);
    setInput('');
    setIsProcessing(true);

    // 2. SNAPSHOT: Save current state for potential rollback
    stateSnapshotRef.current = [...messages, userMessage];

    // Placeholder for the agent's response
    const agentMessageId = `agent_${Date.now()}`;
    const pendingAgentMessage: ChatMessage = {
      id: agentMessageId,
      isUser: false,
      content: 'Thinking...', // Initial loading text
      status: 'pending',
      agentRole: 'supervisor'
    };

    // Append the agent's placeholder to the UI
    setMessages((prev) => [...prev, pendingAgentMessage]);

    try {
      // 3. EXECUTION: Start the LangGraph stream
      const stream = mockLangGraphExecution(input);
      let accumulatedContent = '';

      // 4. STREAMING: Process events as they arrive
      for await (const event of stream) {
        if (event.type === 'thought' || event.type === 'tool_call') {
          // Update the agent message with intermediate thoughts
          const roleLabel = event.payload.role === 'supervisor' ? '[Supervisor]' : '[Researcher]';
          const detail = event.type === 'tool_call' 
            ? `Calling tool: ${event.payload.tool}...` 
            : event.payload.content;
          
          accumulatedContent += `${roleLabel} ${detail}\n`;
          
          setMessages((prev) => 
            prev.map((msg) => 
              msg.id === agentMessageId 
                ? { ...msg, content: accumulatedContent, status: 'streaming', agentRole: event.payload.role }
                : msg
            )
          );
        } else if (event.type === 'final_answer') {
          // Finalize the message
          setMessages((prev) => 
            prev.map((msg) => 
              msg.id === agentMessageId 
                ? { ...msg, content: event.payload.content, status: 'done' }
                : msg
            )
          );
        }
      }
    } catch (error: any) {
      // 5. ROLLBACK MECHANISM: Handle failures gracefully
      console.error('Agent Execution Failed:', error);
      
      // Revert UI to the snapshot state
      if (stateSnapshotRef.current) {
        setMessages(stateSnapshotRef.current);
      }

      // Show an error toast or message instead
      setMessages((prev) => [...prev, {
        id: `error_${Date.now()}`,
        isUser: false,
        content: `Error: ${error.message}. State rolled back.`,
        status: 'error'
      }]);
    } finally {
      setIsProcessing(false);
      stateSnapshotRef.current = null;
    }
  };

  return (
    <div style={styles.container}>
      <div style={styles.chatWindow}>
        {messages.map((msg) => (
          <div key={msg.id} style={msg.isUser ? styles.userBubble : styles.agentBubble}>
            {/* Status Indicator */}
            {msg.status === 'pending' && <span style={styles.spinner}>⏳</span>}
            {msg.status === 'error' && <span style={styles.errorIcon}>⚠️</span>}
            
            {/* Content */}
            <div style={styles.text}>
              {msg.content.split('\n').map((line, i) => (
                <div key={i} style={msg.agentRole === 'supervisor' ? styles.supervisorText : styles.executorText}>
                  {line}
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>

      <div style={styles.inputArea}>
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && handleSendMessage()}
          placeholder="Ask the agent (e.g., 'Research LangGraph.js')"
          style={styles.input}
          disabled={isProcessing}
        />
        <button onClick={handleSendMessage} style={styles.button} disabled={isProcessing}>
          {isProcessing ? 'Processing...' : 'Send'}
        </button>
      </div>
    </div>
  );
}

// ==========================================
// 4. STYLES (Inline for portability)
// ==========================================

const styles: { [key: string]: React.CSSProperties } = {
  container: {
    maxWidth: '600px',
    margin: '0 auto',
    fontFamily: 'system-ui, sans-serif',
    border: '1px solid #e0e0e0',
    borderRadius: '8px',
    overflow: 'hidden',
    display: 'flex',
    flexDirection: 'column',
    height: '600px',
    backgroundColor: '#f9f9f9'
  },
  chatWindow: {
    flex: 1,
    padding: '16px',
    overflowY: 'auto',
    display: 'flex',
    flexDirection: 'column',
    gap: '12px'
  },
  userBubble: {
    alignSelf: 'flex-end',
    backgroundColor: '#007bff',
    color: 'white',
    padding: '10px 14px',
    borderRadius: '12px 12px 0 12px',
    maxWidth: '80%',
    whiteSpace: 'pre-wrap'
  },
  agentBubble: {
    alignSelf: 'flex-start',
    backgroundColor: '#ffffff',
    border: '1px solid #ddd',
    padding: '10px 14px',
    borderRadius: '12px 12px 12px 0',
    maxWidth: '80%',
    whiteSpace: 'pre-wrap'
  },
  text: {
    fontSize: '14px',
    lineHeight: '1.5'
  },
  supervisorText: {
    fontWeight: 'bold',
    color: '#2c3e50',
    marginBottom: '4px'
  },
  executorText: {
    color: '#555',
    fontStyle: 'italic',
    paddingLeft: '10px'
  },
  spinner: {
    marginRight: '8px',
    fontSize: '12px'
  },
  errorIcon: {
    marginRight: '8px',
    color: '#d32f2f'
  },
  inputArea: {
    borderTop: '1px solid #e0e0e0',
    padding: '12px',
    backgroundColor: 'white',
    display: 'flex',
    gap: '8px'
  },
  input: {
    flex: 1,
    padding: '8px 12px',
    border: '1px solid #ccc',
    borderRadius: '4px',
    fontSize: '14px'
  },
  button: {
    padding: '8px 16px',
    backgroundColor: '#007bff',
    color: 'white',
    border: 'none',
    borderRadius: '4px',
    cursor: 'pointer'
  }
};
