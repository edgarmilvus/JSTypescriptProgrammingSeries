/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState, useRef, useEffect } from 'react';

// Types
interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  isStreaming?: boolean;
}

interface StreamingSession {
  messageId: string;
  controller: AbortController;
}

const OptimisticChatInterface: React.FC = () => {
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputValue, setInputValue] = useState('');
  const [activeSessions, setActiveSessions] = useState<StreamingSession[]>([]);
  const inputRef = useRef<HTMLInputElement>(null);

  // Simulate backend agent call with token streaming
  const simulateAgentResponse = async (
    userMessage: string,
    messageId: string,
    abortSignal: AbortSignal
  ): Promise<void> => {
    // Simulate initial delay (thinking time)
    await new Promise(resolve => setTimeout(resolve, 800));

    if (abortSignal.aborted) {
      throw new Error('Request cancelled');
    }

    // Generate a mock response based on user input
    const fullResponse = `I understand you said: "${userMessage}". This is a simulated response that will stream token by token. Each token represents a word or part of a sentence.`;
    const tokens = fullResponse.split(' ');

    // Stream tokens one by one
    for (let i = 0; i < tokens.length; i++) {
      if (abortSignal.aborted) {
        throw new Error('Request cancelled');
      }

      // Simulate network delay between tokens
      await new Promise(resolve => setTimeout(resolve, 100));

      // Update the specific message with new content
      setMessages(prev => prev.map(msg => {
        if (msg.id === messageId) {
          return {
            ...msg,
            content: tokens.slice(0, i + 1).join(' ')
          };
        }
        return msg;
      }));
    }

    // Mark streaming as complete
    setMessages(prev => prev.map(msg => 
      msg.id === messageId ? { ...msg, isStreaming: false } : msg
    ));

    // Remove from active sessions
    setActiveSessions(prev => prev.filter(s => s.messageId !== messageId));
  };

  const handleSendMessage = () => {
    if (!inputValue.trim()) return;

    const userMessageId = `msg-${Date.now()}-user`;
    const assistantMessageId = `msg-${Date.now()}-assistant`;

    // 1. Immediately append user message (optimistic)
    const userMessage: Message = {
      id: userMessageId,
      role: 'user',
      content: inputValue
    };

    // 2. Immediately append placeholder assistant message
    const assistantMessage: Message = {
      id: assistantMessageId,
      role: 'assistant',
      content: '',
      isStreaming: true
    };

    setMessages(prev => [...prev, userMessage, assistantMessage]);
    setInputValue('');

    // 3. Create abort controller for this specific request
    const controller = new AbortController();
    
    // 4. Track this streaming session
    setActiveSessions(prev => [...prev, { messageId: assistantMessageId, controller }]);

    // 5. Start streaming simulation
    simulateAgentResponse(inputValue, assistantMessageId, controller.signal)
      .catch(error => {
        if (error.message !== 'Request cancelled') {
          // Handle unexpected errors
          setMessages(prev => prev.map(msg => 
            msg.id === assistantMessageId 
              ? { ...msg, content: 'Error generating response', isStreaming: false }
              : msg
          ));
        }
      });
  };

  const handleCancelStreaming = (messageId: string) => {
    const session = activeSessions.find(s => s.messageId === messageId);
    if (session) {
      session.controller.abort();
      setActiveSessions(prev => prev.filter(s => s.messageId !== messageId));
      
      // Update message to show it was cancelled
      setMessages(prev => prev.map(msg => 
        msg.id === messageId 
          ? { ...msg, content: '[Response cancelled]', isStreaming: false }
          : msg
      ));
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  return (
    <div style={{ maxWidth: '600px', margin: '0 auto', padding: '20px' }}>
      <h2>Optimistic Chat Interface</h2>
      
      {/* Message List */}
      <div style={{ 
        border: '1px solid #ccc', 
        borderRadius: '8px', 
        padding: '16px', 
        height: '400px', 
        overflowY: 'auto',
        marginBottom: '16px'
      }}>
        {messages.map(message => (
          <div 
            key={message.id}
            style={{
              marginBottom: '12px',
              padding: '8px 12px',
              borderRadius: '8px',
              backgroundColor: message.role === 'user' ? '#e3f2fd' : '#f5f5f5',
              marginLeft: message.role === 'user' ? '40px' : '0',
              marginRight: message.role === 'assistant' ? '40px' : '0',
              position: 'relative'
            }}
          >
            <div style={{ fontWeight: 'bold', fontSize: '12px', marginBottom: '4px' }}>
              {message.role === 'user' ? 'You' : 'Assistant'}
            </div>
            <div style={{ whiteSpace: 'pre-wrap' }}>
              {message.content || (
                <span style={{ color: '#999' }}>
                  <span className="typing-indicator">
                    <span style={{ animation: 'blink 1s infinite' }}>●</span>
                    <span style={{ animation: 'blink 1s infinite 0.2s' }}>●</span>
                    <span style={{ animation: 'blink 1s infinite 0.4s' }}>●</span>
                  </span>
                </span>
              )}
            </div>
            {message.isStreaming && (
              <button 
                onClick={() => handleCancelStreaming(message.id)}
                style={{ 
                  position: 'absolute', 
                  top: '4px', 
                  right: '4px',
                  fontSize: '10px',
                  padding: '2px 6px'
                }}
              >
                Cancel
              </button>
            )}
          </div>
        ))}
      </div>

      {/* Input Area */}
      <div style={{ display: 'flex', gap: '8px' }}>
        <input
          ref={inputRef}
          type="text"
          value={inputValue}
          onChange={(e) => setInputValue(e.target.value)}
          onKeyDown={handleKeyDown}
          placeholder="Type your message..."
          style={{
            flex: 1,
            padding: '8px 12px',
            border: '1px solid #ccc',
            borderRadius: '4px'
          }}
        />
        <button 
          onClick={handleSendMessage}
          disabled={!inputValue.trim()}
          style={{
            padding: '8px 16px',
            backgroundColor: inputValue.trim() ? '#2196f3' : '#ccc',
            color: 'white',
            border: 'none',
            borderRadius: '4px',
            cursor: inputValue.trim() ? 'pointer' : 'not-allowed'
          }}
        >
          Send
        </button>
      </div>

      {/* Status Indicator */}
      {activeSessions.length > 0 && (
        <div style={{ marginTop: '8px', fontSize: '12px', color: '#666' }}>
          {activeSessions.length} response(s) streaming...
        </div>
      )}

      <style>{`
        @keyframes blink {
          0%, 100% { opacity: 0.3; }
          50% { opacity: 1; }
        }
        .typing-indicator span {
          display: inline-block;
          margin: 0 1px;
        }
      `}</style>
    </div>
  );
};

export default OptimisticChatInterface;
