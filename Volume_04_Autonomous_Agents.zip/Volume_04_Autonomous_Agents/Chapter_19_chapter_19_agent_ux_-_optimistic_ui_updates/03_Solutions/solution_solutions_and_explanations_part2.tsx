/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState, useEffect } from 'react';

// Types
type ToolStatus = 'idle' | 'executing' | 'completed' | 'error';

interface ToolDefinition {
  id: string;
  name: string;
  description: string;
}

interface ToolExecutionCardProps {
  toolName: string;
  initialStatus?: ToolStatus;
  onExecute?: () => Promise<string>;
}

interface ToolResult {
  toolName: string;
  result: string;
  status: ToolStatus;
}

// Skeleton Loader Component
const SkeletonLoader: React.FC = () => (
  <div style={{
    height: '80px',
    background: '#f0f0f0',
    borderRadius: '8px',
    overflow: 'hidden',
    position: 'relative'
  }}>
    <div style={{
      width: '100%',
      height: '100%',
      background: 'linear-gradient(90deg, #f0f0f0 25%, #e0e0e0 50%, #f0f0f0 75%)',
      backgroundSize: '200% 100%',
      animation: 'pulse 1.5s infinite'
    }} />
  </div>
);

// Single Tool Execution Card
const ToolExecutionCard: React.FC<ToolExecutionCardProps> = ({
  toolName,
  initialStatus = 'idle',
  onExecute
}) => {
  const [status, setStatus] = useState<ToolStatus>(initialStatus);
  const [result, setResult] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  // Simulate tool execution with random failure
  const executeTool = async (): Promise<void> => {
    setStatus('executing');
    setError(null);
    setResult(null);

    try {
      // Simulate execution delay (1-3 seconds)
      const delay = Math.random() * 2000 + 1000;
      await new Promise(resolve => setTimeout(resolve, delay));

      // 10% chance of failure
      if (Math.random() < 0.1) {
        throw new Error(`Tool ${toolName} failed to execute`);
      }

      // Simulate tool result
      const simulatedResult = JSON.stringify({
        tool: toolName,
        timestamp: new Date().toISOString(),
        data: `Result from ${toolName}`
      }, null, 2);

      setResult(simulatedResult);
      setStatus('completed');
    } catch (err) {
      setStatus('error');
      setError(err instanceof Error ? err.message : 'Unknown error');
    }
  };

  // Auto-execute on mount if initial status is idle
  useEffect(() => {
    if (initialStatus === 'idle' && onExecute) {
      executeTool();
    }
  }, [toolName]);

  const handleRetry = () => {
    executeTool();
  };

  const getStatusColor = (s: ToolStatus): string => {
    switch (s) {
      case 'idle': return '#9e9e9e';
      case 'executing': return '#2196f3';
      case 'completed': return '#4caf50';
      case 'error': return '#f44336';
      default: return '#9e9e9e';
    }
  };

  return (
    <div style={{
      border: `2px solid ${getStatusColor(status)}`,
      borderRadius: '8px',
      padding: '12px',
      marginBottom: '12px',
      backgroundColor: '#fafafa'
    }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '8px' }}>
        <h4 style={{ margin: 0 }}>{toolName}</h4>
        <span style={{ 
          fontSize: '12px', 
          padding: '2px 8px', 
          borderRadius: '12px',
          backgroundColor: getStatusColor(status),
          color: 'white'
        }}>
          {status.toUpperCase()}
        </span>
      </div>

      {status === 'executing' && <SkeletonLoader />}

      {status === 'completed' && result && (
        <pre style={{ 
          fontSize: '11px', 
          backgroundColor: '#e8f5e9', 
          padding: '8px', 
          borderRadius: '4px',
          overflow: 'auto',
          maxHeight: '100px'
        }}>
          {result}
        </pre>
      )}

      {status === 'error' && (
        <div style={{ backgroundColor: '#ffebee', padding: '8px', borderRadius: '4px' }}>
          <p style={{ margin: '0 0 8px 0', color: '#c62828', fontSize: '12px' }}>
            {error}
          </p>
          <button 
            onClick={handleRetry}
            style={{
              padding: '4px 12px',
              backgroundColor: '#f44336',
              color: 'white',
              border: 'none',
              borderRadius: '4px',
              cursor: 'pointer'
            }}
          >
            Retry
          </button>
        </div>
      )}
    </div>
  );
};

// Parent Workflow Visualizer
const AgentWorkflowVisualizer: React.FC = () => {
  const [tools, setTools] = useState<ToolDefinition[]>([
    { id: '1', name: 'Search', description: 'Search for information' },
    { id: '2', name: 'Analyze', description: 'Analyze search results' },
    { id: '3', name: 'Synthesize', description: 'Synthesize final answer' }
  ]);

  const [toolResults, setToolResults] = useState<ToolResult[]>([]);
  const [workflowStatus, setWorkflowStatus] = useState<'idle' | 'running' | 'completed' | 'error'>('idle');

  const startWorkflow = async () => {
    setWorkflowStatus('running');
    setToolResults([]);

    // Simulate parallel execution with random delays
    const executionPromises = tools.map(tool => {
      return new Promise<ToolResult>((resolve) => {
        const delay = Math.random() * 2000 + 1000;
        const shouldFail = Math.random() < 0.15;

        setTimeout(() => {
          if (shouldFail) {
            resolve({
              toolName: tool.name,
              result: '',
              status: 'error'
            });
          } else {
            resolve({
              toolName: tool.name,
              result: JSON.stringify({
                tool: tool.name,
                data: `Result from ${tool.name} at ${new Date().toISOString()}`
              }, null, 2),
              status: 'completed'
            });
          }
        }, delay);
      });
    });

    const results = await Promise.all(executionPromises);
    setToolResults(results);
    setWorkflowStatus('completed');
  };

  const rollbackWorkflow = () => {
    setToolResults([]);
    setWorkflowStatus('idle');
  };

  const addTool = () => {
    const newToolName = `Tool ${tools.length + 1}`;
    const newTool: ToolDefinition = {
      id: Date.now().toString(),
      name: newToolName,
      description: `New tool ${newToolName}`
    };
    setTools(prev => [...prev, newTool]);
  };

  const removeTool = (id: string) => {
    setTools(prev => prev.filter(tool => tool.id !== id));
    setToolResults(prev => prev.filter(r => r.toolName !== tools.find(t => t.id === id)?.name));
  };

  return (
    <div style={{ maxWidth: '800px', margin: '0 auto', padding: '20px' }}>
      <h2>Agent Workflow Visualizer</h2>
      
      {/* Controls */}
      <div style={{ marginBottom: '16px', display: 'flex', gap: '8px', flexWrap: 'wrap' }}>
        <button 
          onClick={startWorkflow}
          disabled={workflowStatus === 'running'}
          style={{
            padding: '8px 16px',
            backgroundColor: workflowStatus === 'running' ? '#ccc' : '#4caf50',
            color: 'white',
            border: 'none',
            borderRadius: '4px',
            cursor: workflowStatus === 'running' ? 'not-allowed' : 'pointer'
          }}
        >
          Start Workflow
        </button>
        
        <button 
          onClick={rollbackWorkflow}
          style={{
            padding: '8px 16px',
            backgroundColor: '#ff9800',
            color: 'white',
            border: 'none',
            borderRadius: '4px',
            cursor: 'pointer'
          }}
        >
          Rollback
        </button>

        <button 
          onClick={addTool}
          style={{
            padding: '8px 16px',
            backgroundColor: '#2196f3',
            color: 'white',
            border: 'none',
            borderRadius: '4px',
            cursor: 'pointer'
          }}
        >
          Add Tool
        </button>
      </div>

      {/* Workflow Status */}
      {workflowStatus !== 'idle' && (
        <div style={{ 
          padding: '8px 12px', 
          backgroundColor: workflowStatus === 'running' ? '#e3f2fd' : '#e8f5e9',
          borderRadius: '4px',
          marginBottom: '16px',
          fontWeight: 'bold'
        }}>
          Workflow Status: {workflowStatus.toUpperCase()}
        </div>
      )}

      {/* Tool Cards */}
      <div style={{ marginBottom: '16px' }}>
        <h3>Tools ({tools.length})</h3>
        {tools.map(tool => {
          const result = toolResults.find(r => r.toolName === tool.name);
          return (
            <div key={tool.id} style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
              <div style={{ flex: 1 }}>
                <ToolExecutionCard
                  toolName={tool.name}
                  initialStatus={result ? result.status : 'idle'}
                />
              </div>
              <button 
                onClick={() => removeTool(tool.id)}
                style={{
                  padding: '4px 8px',
                  backgroundColor: '#f44336',
                  color: 'white',
                  border: 'none',
                  borderRadius: '4px',
                  cursor: 'pointer',
                  fontSize: '12px'
                }}
              >
                Remove
              </button>
            </div>
          );
        })}
      </div>

      {/* Combined Results */}
      {toolResults.length > 0 && (
        <div style={{ 
          padding: '12px', 
          backgroundColor: '#f5f5f5',
          borderRadius: '8px'
        }}>
          <h3>Combined Results</h3>
          {toolResults.filter(r => r.status === 'completed').map((result, idx) => (
            <div key={idx} style={{ marginBottom: '8px' }}>
              <strong>{result.toolName}:</strong>
              <pre style={{ 
                fontSize: '11px', 
                backgroundColor: '#e8f5e9', 
                padding: '6px', 
                borderRadius: '4px',
                marginTop: '4px',
                overflow: 'auto'
              }}>
                {result.result}
              </pre>
            </div>
          ))}
          {toolResults.some(r => r.status === 'error') && (
            <div style={{ 
              marginTop: '8px', 
              padding: '8px', 
              backgroundColor: '#ffebee', 
              borderRadius: '4px',
              color: '#c62828'
            }}>
              ⚠️ Some tools failed. Partial results shown above.
            </div>
          )}
        </div>
      )}

      <style>{`
        @keyframes pulse {
          0% { background-position: 200% 0; }
          100% { background-position: -200% 0; }
        }
      `}</style>
    </div>
  );
};

export default AgentWorkflowVisualizer;
