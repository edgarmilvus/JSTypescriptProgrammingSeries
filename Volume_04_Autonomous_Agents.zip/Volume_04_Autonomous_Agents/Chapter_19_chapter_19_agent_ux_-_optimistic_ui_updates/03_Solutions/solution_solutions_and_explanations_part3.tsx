/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState, useRef, useEffect } from 'react';

// Types
interface NotesState {
  content: string;
  lastSaved: Date | null;
}

interface SaveOperation {
  id: string;
  content: string;
  status: 'pending' | 'success' | 'failed';
  timestamp: Date;
  error?: string;
}

interface OptimisticSaveAgentProps {
  initialContent?: string;
  saveDelay?: number;
  failureRate?: number;
}

const OptimisticSaveAgent: React.FC<OptimisticSaveAgentProps> = ({
  initialContent = '',
  saveDelay = 2000,
  failureRate = 0.2
}) => {
  const [notes, setNotes] = useState<NotesState>({
    content: initialContent,
    lastSaved: null
  });
  
  const [isSaving, setIsSaving] = useState(false);
  const [saveOperations, setSaveOperations] = useState<SaveOperation[]>([]);
  const [error, setError] = useState<string | null>(null);

  // Ref to store previous state for rollback
  const previousStateRef = useRef<NotesState>({ content: initialContent, lastSaved: null });
  
  // Ref to store the current save operation ID
  const currentSaveIdRef = useRef<string | null>(null);

  // Simulate backend save operation
  const simulateBackendSave = async (content: string): Promise<void> => {
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        // Random failure based on failureRate
        if (Math.random() < failureRate) {
          reject(new Error('Save failed: Network error'));
        } else {
          resolve();
        }
      }, saveDelay);
    });
  };

  const handleSave = async () => {
    if (isSaving) return; // Prevent duplicate saves

    const saveId = `save-${Date.now()}`;
    currentSaveIdRef.current = saveId;

    // 1. Store previous state for potential rollback
    previousStateRef.current = { ...notes };

    // 2. Optimistically update UI
    setNotes(prev => ({ ...prev, content: prev.content }));
    setIsSaving(true);
    setError(null);

    // 3. Add to save operations queue
    const newOperation: SaveOperation = {
      id: saveId,
      content: notes.content,
      status: 'pending',
      timestamp: new Date()
    };
    setSaveOperations(prev => [...prev, newOperation]);

    try {
      // 4. Call backend
      await simulateBackendSave(notes.content);

      // 5. On success: Update timestamp and mark operation as success
      const successTime = new Date();
      setNotes(prev => ({ ...prev, lastSaved: successTime }));
      setIsSaving(false);
      setError(null);

      // Update operation status
      setSaveOperations(prev => prev.map(op => 
        op.id === saveId 
          ? { ...op, status: 'success', timestamp: successTime }
          : op
      ));

      // Clear current save ID
      if (currentSaveIdRef.current === saveId) {
        currentSaveIdRef.current = null;
      }

    } catch (err) {
      // 6. On failure: Rollback and show error
      const errorMessage = err instanceof Error ? err.message : 'Save failed';
      
      // Rollback to previous state
      setNotes({ ...previousStateRef.current });
      setIsSaving(false);
      setError(errorMessage);

      // Update operation status
      setSaveOperations(prev => prev.map(op => 
        op.id === saveId 
          ? { ...op, status: 'failed', error: errorMessage }
          : op
      ));

      // Clear current save ID
      if (currentSaveIdRef.current === saveId) {
        currentSaveIdRef.current = null;
      }
    }
  };

  const handleRetry = async (operationId: string) => {
    const operation = saveOperations.find(op => op.id === operationId);
    if (!operation || operation.status !== 'failed') return;

    // 1. Update operation to pending
    setSaveOperations(prev => prev.map(op => 
      op.id === operationId 
        ? { ...op, status: 'pending', error: undefined }
        : op
    ));

    // 2. Store current state as previous for this retry
    previousStateRef.current = { ...notes };

    // 3. Optimistically update UI (if not already saving)
    if (!isSaving) {
      setIsSaving(true);
      setError(null);
    }

    try {
      // 4. Retry the save
      await simulateBackendSave(operation.content);

      // 5. On success: Update notes and operation status
      const successTime = new Date();
      setNotes(prev => ({ ...prev, content: operation.content, lastSaved: successTime }));
      setIsSaving(false);
      setError(null);

      setSaveOperations(prev => prev.map(op => 
        op.id === operationId 
          ? { ...op, status: 'success', timestamp: successTime }
          : op
      ));

    } catch (err) {
      // 6. On failure: Rollback and show error
      const errorMessage = err instanceof Error ? err.message : 'Save failed';
      
      setNotes({ ...previousStateRef.current });
      setIsSaving(false);
      setError(errorMessage);

      setSaveOperations(prev => prev.map(op => 
        op.id === operationId 
          ? { ...op, status: 'failed', error: errorMessage }
          : op
      ));
    }
  };

  const handleCancel = (operationId: string) => {
    // Cancel a pending save operation
    setSaveOperations(prev => prev.filter(op => op.id !== operationId));
    
    // If this was the current save, reset saving state
    if (currentSaveIdRef.current === operationId) {
      setIsSaving(false);
      setError(null);
      // Rollback to previous state
      setNotes({ ...previousStateRef.current });
      currentSaveIdRef.current = null;
    }
  };

  const handleClearHistory = () => {
    setSaveOperations([]);
  };

  return (
    <div style={{ maxWidth: '800px', margin: '0 auto', padding: '20px' }}>
      <h2>Optimistic Save Agent</h2>

      {/* Main Editor */}
      <div style={{ marginBottom: '20px' }}>
        <div style={{ marginBottom: '8px', display: 'flex', justifyContent: 'space-between' }}>
          <strong>Notes:</strong>
          {notes.lastSaved && (
            <span style={{ fontSize: '12px', color: '#666' }}>
              Last saved: {notes.lastSaved.toLocaleTimeString()}
            </span>
          )}
        </div>
        <textarea
          value={notes.content}
          onChange={(e) => setNotes(prev => ({ ...prev, content: e.target.value }))}
          placeholder="Enter your notes here..."
          rows={6}
          style={{
            width: '100%',
            padding: '12px',
            border: '1px solid #ccc',
            borderRadius: '4px',
            resize: 'vertical',
            fontFamily: 'monospace'
          }}
        />
        
        <div style={{ marginTop: '12px', display: 'flex', gap: '8px', alignItems: 'center' }}>
          <button 
            onClick={handleSave}
            disabled={isSaving}
            style={{
              padding: '8px 16px',
              backgroundColor: isSaving ? '#ccc' : '#4caf50',
              color: 'white',
              border: 'none',
              borderRadius: '4px',
              cursor: isSaving ? 'not-allowed' : 'pointer'
            }}
          >
            {isSaving ? 'Saving...' : 'Save'}
          </button>

          {error && (
            <span style={{ color: '#f44336', fontSize: '12px' }}>
              ⚠️ {error}
            </span>
          )}

          {isSaving && (
            <span style={{ fontSize: '12px', color: '#666' }}>
              <span style={{ animation: 'blink 1s infinite' }}>●</span> Saving...
            </span>
          )}
        </div>
      </div>

      {/* Save Operations Queue */}
      <div style={{ marginBottom: '20px' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '8px' }}>
          <strong>Save Operations ({saveOperations.length}):</strong>
          {saveOperations.length > 0 && (
            <button 
              onClick={handleClearHistory}
              style={{
                padding: '4px 8px',
                fontSize: '12px',
                backgroundColor: '#9e9e9e',
                color: 'white',
                border: 'none',
                borderRadius: '4px',
                cursor: 'pointer'
              }}
            >
              Clear History
            </button>
          )}
        </div>

        {saveOperations.length === 0 ? (
          <div style={{ padding: '12px', backgroundColor: '#f5f5f5', borderRadius: '4px', textAlign: 'center', color: '#666' }}>
            No save operations yet
          </div>
        ) : (
          <div style={{ maxHeight: '300px', overflowY: 'auto' }}>
            {saveOperations.map(op => (
              <div 
                key={op.id}
                style={{
                  padding: '8px 12px',
                  marginBottom: '6px',
                  borderLeft: `4px solid ${
                    op.status === 'success' ? '#4caf50' :
                    op.status === 'failed' ? '#f44336' :
                    '#2196f3'
                  }`,
                  backgroundColor: op.status === 'pending' ? '#e3f2fd' : '#f5f5f5',
                  borderRadius: '4px'
                }}
              >
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <div>
                    <span style={{ fontWeight: 'bold', fontSize: '12px' }}>
                      {op.status.toUpperCase()}
                    </span>
                    <span style={{ fontSize: '11px', color: '#666', marginLeft: '8px' }}>
                      {op.timestamp.toLocaleTimeString()}
                    </span>
                  </div>
                  <div>
                    {op.status === 'failed' && (
                      <button 
                        onClick={() => handleRetry(op.id)}
                        style={{
                          padding: '2px 8px',
                          fontSize: '11px',
                          backgroundColor: '#f44336',
                          color: 'white',
                          border: 'none',
                          borderRadius: '4px',
                          cursor: 'pointer',
                          marginRight: '4px'
                        }}
                      >
                        Retry
                      </button>
                    )}
                    {op.status === 'pending' && (
                      <button 
                        onClick={() => handleCancel(op.id)}
                        style={{
                          padding: '2px 8px',
                          fontSize: '11px',
                          backgroundColor: '#ff9800',
                          color: 'white',
                          border: 'none',
                          borderRadius: '4px',
                          cursor: 'pointer'
                        }}
                      >
                        Cancel
                      </button>
                    )}
                  </div>
                </div>
                {op.error && (
                  <div style={{ fontSize: '11px', color: '#c62828', marginTop: '4px' }}>
                    {op.error}
                  </div>
                )}
                <div style={{ fontSize: '10px', color: '#999', marginTop: '4px', fontFamily: 'monospace' }}>
                  Content: "{op.content.substring(0, 50)}{op.content.length > 50 ? '...' : ''}"
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Current State Display */}
      <div style={{ padding: '12px', backgroundColor: '#f5f5f5', borderRadius: '4px' }}>
        <strong>Current State:</strong>
        <pre style={{ fontSize: '11px', marginTop: '4px', fontFamily: 'monospace' }}>
          {JSON.stringify({
            content: notes.content,
            lastSaved: notes.lastSaved ? notes.lastSaved.toISOString() : null
          }, null, 2)}
        </pre>
      </div>

      <style>{`
        @keyframes blink {
          0%, 100% { opacity: 0.3; }
          50% { opacity: 1; }
        }
      `}</style>
    </div>
  );
};

export default OptimisticSaveAgent;
