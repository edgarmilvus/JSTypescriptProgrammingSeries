/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState, useRef } from 'react';

// Types
type ToolStatus = 'idle' | 'running' | 'completed' | 'error' | 'cancelled';

interface ToolDefinition {
  id: string;
  name: string;
  description: string;
}

interface ToolExecution {
  id: string;
  status: ToolStatus;
  result?: string;
  error?: string;
  startTime?: Date;
  endTime?: Date;
}

interface ParallelToolExecutorProps {
  initialTools?: ToolDefinition[];
}

const ParallelToolExecutor: React.FC<ParallelToolExecutorProps> = ({
  initialTools = []
}) => {
  const [tools, setTools] = useState<ToolDefinition[]>(initialTools);
  const [executions, setExecutions] = useState<ToolExecution[]>([]);
  const [isExecuting, setIsExecuting] = useState(false);
  const [combinedResult, setCombinedResult] = useState<string | null>(null);
  
  // Refs to track active promises for cancellation
  const abortControllersRef = useRef<Map<string, AbortController>>(new Map());
  const [newToolName, setNewToolName] = useState('');

  // Simulate tool execution with random delay and failure
  const simulateToolExecution = async (
    tool: ToolDefinition,
    abortSignal: AbortSignal
  ): Promise<ToolExecution> => {
    const execution: ToolExecution = {
      id: tool.id,
      status: 'running',
      startTime: new Date()
    };

    // Update execution status to running
    setExecutions(prev => prev.map(e => 
      e.id === tool.id ? execution : e
    ));

    // Simulate random delay (1-3 seconds)
    const delay = Math.random() * 2000 + 1000;
    
    // Check for cancellation before starting
    if (abortSignal.aborted) {
      return {
        ...execution,
        status: 'cancelled',
        endTime: new Date(),
        error: 'Execution cancelled by user'
      };
    }

    // Create a promise that can be cancelled
    const executionPromise = new Promise<ToolExecution>((resolve) => {
      const timeoutId = setTimeout(() => {
        // Check for cancellation after delay
        if (abortSignal.aborted) {
          resolve({
            ...execution,
            status: 'cancelled',
            endTime: new Date(),
            error: 'Execution cancelled by user'
          });
          return;
        }

        // 15% chance of failure
        if (Math.random() < 0.15) {
          resolve({
            ...execution,
            status: 'error',
            endTime: new Date(),
            error: `Tool ${tool.name} failed during execution`
          });
        } else {
          // Success - generate result
          const result = JSON.stringify({
            tool: tool.name,
            timestamp: new Date().toISOString(),
            data: `Successful result from ${tool.name}`
          }, null, 2);
          
          resolve({
            ...execution,
            status: 'completed',
            result,
            endTime: new Date()
          });
        }
      }, delay);
    });

    // Store abort controller for this tool
    const controller = new AbortController();
    abortControllersRef.current.set(tool.id, controller);

    // Listen for abort signal
    abortSignal.addEventListener('abort', () => controller.abort());

    return executionPromise;
  };

  const executeParallelTools = async () => {
    if (tools.length === 0) return;

    setIsExecuting(true);
    setCombinedResult(null);
    setExecutions(tools.map(tool => ({
      id: tool.id,
      status: 'idle'
    })));

    // Create a master abort controller for the entire batch
    const masterController = new AbortController();
    const executionPromises = tools.map(tool => 
      simulateToolExecution(tool, masterController.signal)
    );

    try {
      // Wait for all tools to settle (either complete or fail)
      const results = await Promise.all(executionPromises);
      
      // Update all executions with final results
      setExecutions(results);

      // Aggregate successful results
      const successfulResults = results
        .filter(r => r.status === 'completed' && r.result)
        .map(r => r.result);

      if (successfulResults.length > 0) {
        const aggregated = successfulResults.join('\n\n---\n\n');
        setCombinedResult(aggregated);
      } else if (results.some(r => r.status === 'cancelled')) {
        setCombinedResult('Execution was cancelled.');
      } else {
        setCombinedResult('All tools failed or were cancelled.');
      }

    } catch (error) {
      console.error('Parallel execution error:', error);
      setCombinedResult('Unexpected error during execution.');
    } finally {
      setIsExecuting(false);
      abortControllersRef.current.clear();
    }
  };

  const addTool = () => {
    if (!newToolName.trim()) return;

    const newTool: ToolDefinition = {
      id: `tool-${Date.now()}`,
      name: newToolName.trim(),
      description: `User-added tool: ${newToolName.trim()}`
    };

    setTools(prev => [...prev, newTool]);
    setNewToolName('');
  };

  const removeTool = (id: string) => {
    setTools(prev => prev.filter(tool => tool.id !== id));
    setExecutions(prev => prev.filter(e => e.id !== id));
  };

  const cancelAllExecutions = () => {
    // Abort all active executions
    abortControllersRef.current.forEach(controller => {
      controller.abort();
    });
    
    // Update status of running executions to cancelled
    setExecutions(prev => prev.map(e => 
      e.status === 'running' 
        ? { ...e, status: 'cancelled', endTime: new Date(), error: 'Cancelled by user' }
        : e
    ));

    setIsExecuting(false);
    abortControllersRef.current.clear();
  };

  const resetAll = () => {
    setExecutions([]);
    setCombinedResult(null);
    setIsExecuting(false);
    abortControllersRef.current.clear();
  };

  const getStatusIcon = (status: ToolStatus) => {
    switch (status) {
      case 'idle': return '⏸️';
      case 'running': return '⏳';
      case 'completed': return '✅';
      case 'error': return '❌';
      case 'cancelled': return '⛔';
      default: return '❓';
    }
  };

  const getStatusColor = (status: ToolStatus) => {
    switch (status) {
      case 'idle': return '#9e9e9e';
      case 'running': return '#2196f3';
      case 'completed': return '#4caf50';
      case 'error': return '#f44336';
      case 'cancelled': return '#ff9800';
      default: return '#9e9e9e';
    }
  };

  return (
    <div style={{ maxWidth: '900px', margin: '0 auto', padding: '20px' }}>
      <h2>Parallel Tool Executor</h2>

      {/* Controls */}
      <div style={{ marginBottom: '16px', display: 'flex', gap: '8px', flexWrap: 'wrap' }}>
        <button 
          onClick={executeParallelTools}
          disabled={isExecuting || tools.length === 0}
          style={{
            padding: '8px 16px',
            backgroundColor: isExecuting ? '#ccc' : '#4caf50',
            color: 'white',
            border: 'none',
            borderRadius: '4px',
            cursor: isExecuting || tools.length === 0 ? 'not-allowed' : 'pointer'
          }}
        >
          Execute All
        </button>

        <button 
          onClick={cancelAllExecutions}
          disabled={!isExecuting}
          style={{
            padding: '8px 16px',
            backgroundColor: !isExecuting ? '#ccc' : '#ff9800',
            color: 'white',
            border: 'none',
            borderRadius: '4px',
            cursor: !isExecuting ? 'not-allowed' : 'pointer'
          }}
        >
          Cancel All
        </button>

        <button 
          onClick={resetAll}
          style={{
            padding: '8px 16px',
            backgroundColor: '#9e9e9e',
            color: 'white',
            border: 'none',
            borderRadius: '4px',
            cursor: 'pointer'
          }}
        >
          Reset
        </button>
      </div>

      {/* Dynamic Tool Addition */}
      <div style={{ marginBottom: '16px', display: 'flex', gap: '8px' }}>
        <input
          type="text"
          value={newToolName}
          onChange={(e) => setNewToolName(e.target.value)}
          placeholder="Enter new tool name..."
          style={{
            flex: 1,
            padding: '8px 12px',
            border: '1px solid #ccc',
            borderRadius: '4px'
          }}
        />
        <button 
          onClick={addTool}
          disabled={!newToolName.trim()}
          style={{
            padding: '8px 16px',
            backgroundColor: newToolName.trim() ? '#2196f3' : '#ccc',
            color: 'white',
            border: 'none',
            borderRadius: '4px',
            cursor: newToolName.trim() ? 'pointer' : 'not-allowed'
          }}
        >
          Add Tool
        </button>
      </div>

      {/* Tool Cards */}
      <div style={{ marginBottom: '16px' }}>
        <h3>Tools ({tools.length})</h3>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))', gap: '12px' }}>
          {tools.map(tool => {
            const execution = executions.find(e => e.id === tool.id);
            const status = execution?.status || 'idle';
            
            return (
              <div 
                key={tool.id}
                style={{
                  border: `2px solid ${getStatusColor(status)}`,
                  borderRadius: '8px',
                  padding: '12px',
                  backgroundColor: '#fafafa',
                  position: 'relative'
                }}
              >
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '8px' }}>
                  <div>
                    <strong>{tool.name}</strong>
                    <div style={{ fontSize: '11px', color: '#666', marginTop: '2px' }}>
                      {tool.description}
                    </div>
                  </div>
                  <div style={{ fontSize: '20px' }}>
                    {getStatusIcon(status)}
                  </div>
                </div>

                <div style={{ fontSize: '12px', marginBottom: '6px' }}>
                  Status: <span style={{ color: getStatusColor(status), fontWeight: 'bold' }}>
                    {status.toUpperCase()}
                  </span>
                </div>

                {execution?.startTime && (
                  <div style={{ fontSize: '10px', color: '#999', marginBottom: '4px' }}>
                    Started: {execution.startTime.toLocaleTimeString()}
                  </div>
                )}

                {execution?.endTime && (
                  <div style={{ fontSize: '10px', color: '#999', marginBottom: '4px' }}>
                    Ended: {execution.endTime.toLocaleTimeString()}
                  </div>
                )}

                {execution?.error && (
                  <div style={{ 
                    fontSize: '11px', 
                    color: getStatusColor(status),
                    backgroundColor: '#ffebee',
                    padding: '4px 8px',
                    borderRadius: '4px',
                    marginTop: '4px'
                  }}>
                    {execution.error}
                  </div>
                )}

                {execution?.result && (
                  <pre style={{ 
                    fontSize: '10px', 
                    backgroundColor: '#e8f5e9', 
                    padding: '6px', 
                    borderRadius: '4px',
                    marginTop: '6px',
                    maxHeight: '60px',
                    overflow: 'auto'
                  }}>
                    {execution.result.substring(0, 100)}...
                  </pre>
                )}

                <button 
                  onClick={() => removeTool(tool.id)}
                  style={{
                    position: 'absolute',
                    top: '4px',
                    right: '4px',
                    padding: '2px 6px',
                    fontSize: '10px',
                    backgroundColor: '#f44336',
                    color: 'white',
                    border: 'none',
                    borderRadius: '4px',
                    cursor: 'pointer',
                    opacity: isExecuting ? '0.5' : '1'
                  }}
                  disabled={isExecuting}
                >
                  ×
                </button>
              </div>
            );
          })}
        </div>
      </div>

      {/* Combined Results */}
      {combinedResult && (
        <div style={{ 
          padding: '12px', 
          backgroundColor: '#f5f5f5',
          borderRadius: '8px',
          marginTop: '16px'
        }}>
          <h3>Combined Results</h3>
          <pre style={{ 
            fontSize: '11px', 
            backgroundColor: 'white', 
            padding: '8px', 
            borderRadius: '4px',
            overflow: 'auto',
            maxHeight: '200px',
            fontFamily: 'monospace'
          }}>
            {combinedResult}
          </pre>
        </div>
      )}

      {/* Execution Status */}
      {isExecuting && (
        <div style={{ 
          padding: '8px 12px', 
          backgroundColor: '#e3f2fd',
          borderRadius: '4px',
          marginTop: '12px',
          fontWeight: 'bold',
          textAlign: 'center'
        }}>
          ⏳ Executing {tools.length} tool(s) in parallel...
        </div>
      )}
    </div>
  );
};

export default ParallelToolExecutor;
