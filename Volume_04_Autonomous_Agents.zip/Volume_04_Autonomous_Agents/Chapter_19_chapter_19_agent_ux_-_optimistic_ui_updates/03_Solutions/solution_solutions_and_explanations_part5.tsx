/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState, useRef, useEffect } from 'react';

// Types
type AgentStatus = 'idle' | 'thinking' | 'executing_tool' | 'completed' | 'failed' | 'cancelled';

interface Agent {
  id: string;
  name: string;
  status: AgentStatus;
  lastUpdate: Date | null;
  error?: string;
}

interface AgentExecution {
  agentId: string;
  controller: AbortController;
  timeoutId?: NodeJS.Timeout;
  intermediateTimeoutId?: NodeJS.Timeout;
}

interface AgentStatusDashboardProps {
  initialAgents?: Agent[];
}

const AgentStatusDashboard: React.FC<AgentStatusDashboardProps> = ({
  initialAgents = []
}) => {
  const [agents, setAgents] = useState<Agent[]>(initialAgents);
  const [isBulkExecuting, setIsBulkExecuting] = useState(false);
  const [notification, setNotification] = useState<string | null>(null);

  // Refs to track active executions for cancellation
  const executionRefs = useRef<Map<string, AgentExecution>>(new Map());

  // Simulate backend LangGraph execution
  const runAgentSimulation = async (
    agentId: string,
    abortSignal: AbortSignal
  ): Promise<AgentStatus> => {
    return new Promise<AgentStatus>((resolve, reject) => {
      // Random delay between 1-5 seconds
      const totalDelay = Math.random() * 4000 + 1000;
      
      // Set up intermediate state change (executing_tool) after 1 second
      const intermediateTimeoutId = setTimeout(() => {
        if (!abortSignal.aborted) {
          setAgents(prev => prev.map(agent => 
            agent.id === agentId 
              ? { ...agent, status: 'executing_tool', lastUpdate: new Date() }
              : agent
          ));
        }
      }, 1000);

      // Set up final completion
      const finalTimeoutId = setTimeout(() => {
        if (abortSignal.aborted) {
          reject(new Error('Execution cancelled'));
          return;
        }

        // 20% chance of failure
        if (Math.random() < 0.2) {
          resolve('failed');
        } else {
          resolve('completed');
        }
      }, totalDelay);

      // Store timeout IDs for cleanup
      const execution = executionRefs.current.get(agentId);
      if (execution) {
        execution.timeoutId = finalTimeoutId;
        execution.intermediateTimeoutId = intermediateTimeoutId;
      }
    });
  };

  const startAgent = async (agentId: string) => {
    // Optimistically update status to 'thinking'
    setAgents(prev => prev.map(agent => 
      agent.id === agentId 
        ? { ...agent, status: 'thinking', lastUpdate: new Date(), error: undefined }
        : agent
    ));

    // Create abort controller for this agent
    const controller = new AbortController();
    const execution: AgentExecution = { agentId, controller };
    executionRefs.current.set(agentId, execution);

    try {
      // Call backend simulation
      const finalStatus = await runAgentSimulation(agentId, controller.signal);
      
      // Update with final status
      setAgents(prev => prev.map(agent => 
        agent.id === agentId 
          ? { ...agent, status: finalStatus, lastUpdate: new Date() }
          : agent
      ));

    } catch (error) {
      // Handle cancellation or unexpected error
      if (error instanceof Error && error.message === 'Execution cancelled') {
        setAgents(prev => prev.map(agent => 
          agent.id === agentId 
            ? { ...agent, status: 'cancelled', lastUpdate: new Date(), error: 'Cancelled by user' }
            : agent
        ));
      } else {
        // Rollback on failure
        setAgents(prev => prev.map(agent => 
          agent.id === agentId 
            ? { ...agent, status: 'idle', lastUpdate: new Date(), error: 'Execution failed' }
            : agent
        ));
      }
    } finally {
      // Clean up execution refs
      const execution = executionRefs.current.get(agentId);
      if (execution) {
        if (execution.timeoutId) clearTimeout(execution.timeoutId);
        if (execution.intermediateTimeoutId) clearTimeout(execution.intermediateTimeoutId);
        executionRefs.current.delete(agentId);
      }
    }
  };

  const startAllAgents = async () => {
    const idleAgents = agents.filter(a => a.status === 'idle');
    if (idleAgents.length === 0) return;

    setIsBulkExecuting(true);
    setNotification(`Starting ${idleAgents.length} agent(s)...`);

    // Start all idle agents simultaneously
    const startPromises = idleAgents.map(agent => startAgent(agent.id));
    await Promise.all(startPromises);

    setIsBulkExecuting(false);
    setNotification(null);
  };

  const cancelAllAgents = () => {
    let cancelledCount = 0;
    
    executionRefs.current.forEach((execution, agentId) => {
      // Abort the controller
      execution.controller.abort();
      
      // Clear any pending timeouts
      if (execution.timeoutId) clearTimeout(execution.timeoutId);
      if (execution.intermediateTimeoutId) clearTimeout(execution.intermediateTimeoutId);
      
      cancelledCount++;
    });

    // Update all running agents to cancelled
    setAgents(prev => prev.map(agent => 
      agent.status === 'thinking' || agent.status === 'executing_tool'
        ? { ...agent, status: 'cancelled', lastUpdate: new Date(), error: 'Cancelled by user' }
        : agent
    ));

    // Clear execution refs
    executionRefs.current.clear();
    setIsBulkExecuting(false);
    setNotification(`Cancelled ${cancelledCount} agent(s)`);

    // Clear notification after delay
    setTimeout(() => setNotification(null), 3000);
  };

  const addAgent = () => {
    const newAgent: Agent = {
      id: `agent-${Date.now()}`,
      name: `Agent ${agents.length + 1}`,
      status: 'idle',
      lastUpdate: null
    };
    setAgents(prev => [...prev, newAgent]);
  };

  const resetAgent = (agentId: string) => {
    // Cancel any ongoing execution
    const execution = executionRefs.current.get(agentId);
    if (execution) {
      execution.controller.abort();
      if (execution.timeoutId) clearTimeout(execution.timeoutId);
      if (execution.intermediateTimeoutId) clearTimeout(execution.intermediateTimeoutId);
      executionRefs.current.delete(agentId);
    }

    // Reset agent to idle
    setAgents(prev => prev.map(agent => 
      agent.id === agentId 
        ? { ...agent, status: 'idle', lastUpdate: new Date(), error: undefined }
        : agent
    ));
  };

  const getStatusColor = (status: AgentStatus): string => {
    switch (status) {
      case 'idle': return '#9e9e9e';
      case 'thinking': return '#2196f3';
      case 'executing_tool': return '#00bcd4';
      case 'completed': return '#4caf50';
      case 'failed': return '#f44336';
      case 'cancelled': return '#ff9800';
      default: return '#9e9e9e';
    }
  };

  const getStatusIcon = (status: AgentStatus): string => {
    switch (status) {
      case 'idle': return '⏸️';
      case 'thinking': return '🧠';
      case 'executing_tool': return '⚙️';
      case 'completed': return '✅';
      case 'failed': return '❌';
      case 'cancelled': return '⛔';
      default: return '❓';
    }
  };

  // Auto-cleanup on unmount
  useEffect(() => {
    return () => {
      executionRefs.current.forEach(execution => {
        execution.controller.abort();
        if (execution.timeoutId) clearTimeout(execution.timeoutId);
        if (execution.intermediateTimeoutId) clearTimeout(execution.intermediateTimeoutId);
      });
      executionRefs.current.clear();
    };
  }, []);

  return (
    <div style={{ maxWidth: '1200px', margin: '0 auto', padding: '20px' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px' }}>
        <h2>Agent Status Dashboard</h2>
        <div style={{ display: 'flex', gap: '8px' }}>
          <button 
            onClick={addAgent}
            style={{
              padding: '8px 16px',
              backgroundColor: '#2196f3',
              color: 'white',
              border: 'none',
              borderRadius: '4px',
              cursor: 'pointer'
            }}
          >
            + Add Agent
          </button>
        </div>
      </div>

      {/* Notification Bar */}
      {notification && (
        <div style={{
          padding: '8px 12px',
          backgroundColor: '#e3f2fd',
          borderRadius: '4px',
          marginBottom: '16px',
          fontWeight: 'bold',
          textAlign: 'center'
        }}>
          {notification}
        </div>
      )}

      {/* Bulk Actions */}
      <div style={{ marginBottom: '16px', display: 'flex', gap: '8px', flexWrap: 'wrap' }}>
        <button 
          onClick={startAllAgents}
          disabled={isBulkExecuting || agents.filter(a => a.status === 'idle').length === 0}
          style={{
            padding: '8px 16px',
            backgroundColor: isBulkExecuting ? '#ccc' : '#4caf50',
            color: 'white',
            border: 'none',
            borderRadius: '4px',
            cursor: isBulkExecuting || agents.filter(a => a.status === 'idle').length === 0 ? 'not-allowed' : 'pointer'
          }}
        >
          Start All Idle Agents
        </button>

        <button 
          onClick={cancelAllAgents}
          disabled={!isBulkExecuting}
          style={{
            padding: '8px 16px',
            backgroundColor: !isBulkExecuting ? '#ccc' : '#ff9800',
            color: 'white',
            border: 'none',
            borderRadius: '4px',
            cursor: !isBulkExecuting ? 'not-allowed' : 'pointer'
          }}
        >
          Cancel All
        </button>

        <div style={{ fontSize: '12px', color: '#666', alignSelf: 'center' }}>
          Idle: {agents.filter(a => a.status === 'idle').length} | 
          Running: {agents.filter(a => a.status === 'thinking' || a.status === 'executing_tool').length} | 
          Completed: {agents.filter(a => a.status === 'completed').length} | 
          Failed: {agents.filter(a => a.status === 'failed').length} | 
          Cancelled: {agents.filter(a => a.status === 'cancelled').length}
        </div>
      </div>

      {/* Agent Grid */}
      <div style={{ 
        display: 'grid', 
        gridTemplateColumns: 'repeat(auto-fill, minmax(300px, 1fr))', 
        gap: '12px' 
      }}>
        {agents.map(agent => {
          const isRunning = agent.status === 'thinking' || agent.status === 'executing_tool';
          
          return (
            <div 
              key={agent.id}
              style={{
                border: `2px solid ${getStatusColor(agent.status)}`,
                borderRadius: '8px',
                padding: '12px',
                backgroundColor: '#fafafa',
                position: 'relative',
                overflow: 'hidden'
              }}
            >
              {/* Pulsing border for running agents */}
              {isRunning && (
                <div style={{
                  position: 'absolute',
                  top: 0,
                  left: 0,
                  right: 0,
                  bottom: 0,
                  border: `2px solid ${getStatusColor(agent.status)}`,
                  borderRadius: '6px',
                  animation: 'pulse-border 1.5s infinite',
                  pointerEvents: 'none'
                }} />
              )}

              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '8px', position: 'relative' }}>
                <div>
                  <strong style={{ fontSize: '14px' }}>{agent.name}</strong>
                  <div style={{ fontSize: '11px', color: '#666', marginTop: '2px' }}>
                    ID: {agent.id.substring(0, 8)}...
                  </div>
                </div>
                <div style={{ fontSize: '24px', position: 'relative' }}>
                  {getStatusIcon(agent.status)}
                  {isRunning && (
                    <span style={{
                      position: 'absolute',
                      top: '-4px',
                      right: '-4px',
                      width: '8px',
                      height: '8px',
                      backgroundColor: getStatusColor(agent.status),
                      borderRadius: '50%',
                      animation: 'blink 1s infinite'
                    }} />
                  )}
                </div>
              </div>

              {/* Status Badge */}
              <div style={{ 
                marginBottom: '8px',
                padding: '4px 8px',
                backgroundColor: getStatusColor(agent.status),
                color: 'white',
                borderRadius: '12px',
                fontSize: '11px',
                fontWeight: 'bold',
                display: 'inline-block'
              }}>
                {agent.status.toUpperCase()}
              </div>

              {/* Last Update */}
              {agent.lastUpdate && (
                <div style={{ fontSize: '10px', color: '#999', marginBottom: '8px' }}>
                  Last update: {agent.lastUpdate.toLocaleTimeString()}
                </div>
              )}

              {/* Error Message */}
              {agent.error && (
                <div style={{ 
                  fontSize: '11px', 
                  color: '#c62828',
                  backgroundColor: '#ffebee',
                  padding: '6px 8px',
                  borderRadius: '4px',
                  marginBottom: '8px'
                }}>
                  ⚠️ {agent.error}
                </div>
              )}

              {/* Action Buttons */}
              <div style={{ display: 'flex', gap: '6px', position: 'relative' }}>
                {agent.status === 'idle' && (
                  <button 
                    onClick={() => startAgent(agent.id)}
                    style={{
                      flex: 1,
                      padding: '6px 12px',
                      backgroundColor: '#4caf50',
                      color: 'white',
                      border: 'none',
                      borderRadius: '4px',
                      cursor: 'pointer',
                      fontSize: '12px'
                    }}
                  >
                    Start
                  </button>
                )}

                {isRunning && (
                  <button 
                    onClick={() => resetAgent(agent.id)}
                    style={{
                      flex: 1,
                      padding: '6px 12px',
                      backgroundColor: '#ff9800',
                      color: 'white',
                      border: 'none',
                      borderRadius: '4px',
                      cursor: 'pointer',
                      fontSize: '12px'
                    }}
                  >
                    Cancel
                  </button>
                )}

                {(agent.status === 'completed' || agent.status === 'failed' || agent.status === 'cancelled') && (
                  <button 
                    onClick={() => resetAgent(agent.id)}
                    style={{
                      flex: 1,
                      padding: '6px 12px',
                      backgroundColor: '#9e9e9e',
                      color: 'white',
                      border: 'none',
                      borderRadius: '4px',
                      cursor: 'pointer',
                      fontSize: '12px'
                    }}
                  >
                    Reset
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Empty State */}
      {agents.length === 0 && (
        <div style={{ 
          padding: '40px', 
          textAlign: 'center', 
          color: '#999',
          backgroundColor: '#f5f5f5',
          borderRadius: '8px'
        }}>
          <div style={{ fontSize: '48px', marginBottom: '12px' }}>🤖</div>
          <div>No agents added yet. Click "Add Agent" to get started.</div>
        </div>
      )}

      <style>{`
        @keyframes pulse-border {
          0%, 100% { opacity: 0.3; transform: scale(1); }
          50% { opacity: 0.6; transform: scale(1.02); }
        }
        @keyframes blink {
          0%, 100% { opacity: 0.3; }
          50% { opacity: 1; }
        }
      `}</style>
    </div>
  );
};

export default AgentStatusDashboard;
