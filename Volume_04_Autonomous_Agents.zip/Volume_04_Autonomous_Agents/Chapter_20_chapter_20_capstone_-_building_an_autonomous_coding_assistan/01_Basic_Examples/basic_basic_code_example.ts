/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

import { StateGraph, Annotation, StateSnapshot } from "@langchain/langgraph";
import { z } from "zod";

// ==========================================
// 1. STATE DEFINITION & SCHEMAS
// ==========================================

/**
 * Defines the shared state across all agents.
 * Using Zod for runtime validation simulates the robustness of JSON Schema Output,
 * ensuring the LLM's structured response is predictable.
 */
const AgentState = Annotation.Root({
  request: Annotation<string>({
    reducer: (state, update) => update, // Overwrites the request
    default: () => "",
  }),
  plan: Annotation<string>({
    reducer: (state, update) => update,
    default: () => "",
  }),
  generatedCode: Annotation<string>({
    reducer: (state, update) => update,
    default: () => "",
  }),
  testCode: Annotation<string>({
    reducer: (state, update) => update,
    default: () => "",
  }),
  testResult: Annotation<{
    success: boolean;
    output: string;
  }>({
    reducer: (state, update) => update,
    default: () => ({ success: false, output: "" }),
  }),
  iterationCount: Annotation<number>({
    reducer: (state, update) => state + 1, // Increment on every loop
    default: () => 0,
  }),
});

// Schema for the Planner's output (simulating LLM structured output)
const PlanSchema = z.object({
  steps: z.array(z.string()).describe("A list of steps to implement the request."),
});

// Schema for the Coder's output
const CodeSchema = z.object({
  code: z.string().describe("The TypeScript code block."),
  language: z.string().describe("The programming language."),
});

// Schema for the Tester's output
const TestSchema = z.object({
  testCode: z.string().describe("The Jest-style test code."),
});

// ==========================================
// 2. AGENT NODES (TOOL EXECUTION)
// ==========================================

/**
 * Node 1: Planner Agent
 * Analyzes the request and generates a plan.
 * In a real app, this would call an LLM with the PlanSchema.
 */
async function plannerNode(state: typeof AgentState.State): Promise<Partial<typeof AgentState.State>> {
  console.log(`[Planner] Analyzing request: "${state.request}"`);
  
  // Simulated LLM response based on the schema
  const simulatedResponse = {
    steps: [
      "Create a function named 'factorial'.",
      "Handle base case: if n is 0 or 1, return 1.",
      "Handle recursive case: return n * factorial(n - 1).",
    ],
  };

  // Validate against schema (crucial for reliability)
  const parsed = PlanSchema.parse(simulatedResponse);
  
  return {
    plan: parsed.steps.join("\n"),
  };
}

/**
 * Node 2: Coder Agent
 * Generates code based on the plan.
 * In a real app, this would call an LLM with the CodeSchema.
 */
async function coderNode(state: typeof AgentState.State): Promise<Partial<typeof AgentState.State>> {
  console.log(`[Coder] Generating code based on plan...`);

  // Simulated LLM response
  const simulatedResponse = {
    code: `
/**
 * Calculates the factorial of a number.
 * @param n - The input number
 * @returns The factorial
 */
export function factorial(n: number): number {
  if (n < 0) throw new Error("Input must be non-negative");
  if (n === 0 || n === 1) return 1;
  return n * factorial(n - 1);
}
`,
    language: "typescript",
  };

  const parsed = CodeSchema.parse(simulatedResponse);

  return {
    generatedCode: parsed.code,
  };
}

/**
 * Node 3: Tester Agent
 * Writes a test file and executes it using the Node.js child_process API.
 * This simulates the autonomous execution of terminal commands.
 */
async function testerNode(state: typeof AgentState.State): Promise<Partial<typeof AgentState.State>> {
  console.log(`[Tester] Writing and executing tests...`);

  // Simulated LLM response for test code
  const simulatedResponse = {
    testCode: `
import { factorial } from './code';

// Test cases
const testCases = [
  { input: 0, expected: 1 },
  { input: 1, expected: 1 },
  { input: 5, expected: 120 },
];

let passed = true;
let output = "";

try {
  testCases.forEach(({ input, expected }) => {
    const result = factorial(input);
    if (result !== expected) {
      passed = false;
      output += \`FAIL: factorial(\${input}) returned \${result}, expected \${expected}\\n\`;
    } else {
      output += \`PASS: factorial(\${input}) returned \${result}\\n\`;
    }
  });
} catch (err) {
  passed = false;
  output = \`ERROR: \${err.message}\`;
}

// In a real scenario, we would write these files to disk.
// For this example, we simulate the execution result.
console.log(output);
`,
  };

  const parsed = TestSchema.parse(simulatedResponse);

  // SIMULATION: We cannot actually write files or run child processes in this environment.
  // Instead, we simulate the execution result based on the generated code.
  // If the generated code contains the correct logic, the test passes.
  
  const isCorrect = state.generatedCode.includes("n * factorial(n - 1)");
  
  const testResult = isCorrect 
    ? { success: true, output: "PASS: All tests passed." }
    : { success: false, output: "FAIL: Logic error detected in generated code." };

  return {
    testCode: parsed.testCode,
    testResult: testResult,
  };
}

// ==========================================
// 3. CONTROL FLOW (EDGES)
// ==========================================

/**
 * Router: Determines the next step based on test results.
 * If tests pass, the graph finishes.
 * If tests fail, the graph loops back to the Coder with feedback.
 */
function router(state: typeof AgentState.State): string {
  // Prevent infinite loops (Safety Guardrail)
  if (state.iterationCount > 3) {
    console.log("[System] Max iterations reached. Aborting.");
    return "__end__";
  }

  if (state.testResult.success) {
    return "__end__";
  } else {
    console.log(`[System] Tests failed. Looping back to Coder. Iteration: ${state.iterationCount}`);
    return "coder";
  }
}

// ==========================================
// 4. GRAPH COMPILATION & EXECUTION
// ==========================================

/**
 * Main execution function.
 * Builds the graph, compiles it, and invokes the workflow.
 */
async function runWorkflow() {
  // Define the graph
  const workflow = new StateGraph(AgentState)
    // Add Nodes
    .addNode("planner", plannerNode)
    .addNode("coder", coderNode)
    .addNode("tester", testerNode)
    // Define Edges
    .addEdge("__start__", "planner")
    .addEdge("planner", "coder")
    .addEdge("coder", "tester")
    // Conditional Edge (Router)
    .addConditionalEdges("tester", router, {
      "coder": "coder", // If router returns "coder", go to coder node
      "__end__": "__end__", // If router returns "__end__", finish
    });

  const app = workflow.compile();

  // Initial State
  const initialState = {
    request: "Create a utility function to calculate the factorial of a number.",
  };

  console.log("🚀 Starting Autonomous Coding Workflow...\n");

  // Stream execution results (useful for real-time UI updates)
  const stream = await app.stream(initialState);
  
  for await (const chunk of stream) {
    // Log the node that just executed
    const nodeName = Object.keys(chunk)[0];
    console.log(`\n--- Step: ${nodeName} ---`);
    console.log(JSON.stringify(chunk[nodeName], null, 2));
  }

  console.log("\n✅ Workflow Completed.");
}

// Execute the workflow
runWorkflow().catch(console.error);
