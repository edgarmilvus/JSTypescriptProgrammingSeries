/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

/**
 * File: app/api/autodoc/route.ts
 * Description: Next.js Route Handler implementing an autonomous multi-agent workflow
 *              to generate API documentation from TypeScript source code.
 * Context: Chapter 20: Capstone - Building an Autonomous Coding Assistant
 */

import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import { ChatOpenAI } from '@langchain/openai';
import { StateGraph, END, START } from '@langchain/langgraph';
import { ToolNode } from '@langchain/langgraph/prebuilt';
import { BaseMessage, HumanMessage, AIMessage } from '@langchain/core/messages';
import { ToolDefinition } from '@langchain/core/language_models/base';

// ============================================================================
// 1. DEFINITIONS & SCHEMAS
// ============================================================================

/**
 * JSON Schema for the output documentation.
 * Ensures the LLM produces predictable, parseable structure.
 */
const ApiDocSchema = z.object({
  functionName: z.string().describe("The name of the function."),
  description: z.string().describe("A brief explanation of what the function does."),
  parameters: z.array(
    z.object({
      name: z.string(),
      type: z.string(),
      description: z.string(),
      required: z.boolean(),
    })
  ).describe("List of input parameters."),
  returns: z.object({
    type: z.string(),
    description: z.string(),
  }).describe("The return type and description."),
  usageExample: z.string().describe("A concise code snippet showing how to use the function."),
});

// TypeScript representation of the schema for type safety
type ApiDoc = z.infer<typeof ApiDocSchema>;

/**
 * The State Interface for the LangGraph.
 * Defines what data flows between nodes.
 */
interface AgentState {
  messages: BaseMessage[];
  sourceCode: string;
  documentation?: ApiDoc;
  isValidated: boolean;
  retryCount: number;
}

// ============================================================================
// 2. TOOLS (FUNCTIONAL NODES)
// ============================================================================

/**
 * Tool: Code Analyzer
 * Simulates an AST parser. In a real scenario, this would use libraries like TypeScript Compiler API.
 * It extracts function signatures from the raw source code string.
 */
const analyzeCode = (state: AgentState): Partial<AgentState> => {
  console.log("🤖 [Tool] Analyzing Source Code...");
  
  // Simple regex extraction for demonstration purposes
  const funcMatch = state.sourceCode.match(/function\s+(\w+)\s*\((.*?)\)\s*:\s*(\w+)\s*{([\s\S]*?)}/);
  
  if (!funcMatch) {
    return {
      messages: [
        ...state.messages,
        new AIMessage("Error: Could not parse function signature. Ensure code is valid TypeScript.")
      ]
    };
  }

  const [, name, paramsStr, returnType, body] = funcMatch;
  
  // Parse parameters
  const parameters = paramsStr.split(',').map(p => {
    const [n, t] = p.split(':').map(s => s.trim());
    return { name: n || 'unknown', type: t || 'any', description: 'Parameter provided.', required: true };
  }).filter(p => p.name !== 'unknown');

  // We inject this raw data into the state context for the next agent
  // Note: In a real graph, we might pass this as a structured message or context object
  const analysisContext = `
    FUNCTION_NAME: ${name}
    PARAMETERS: ${JSON.stringify(parameters)}
    RETURN_TYPE: ${returnType}
    BODY_LOGIC: ${body.trim().substring(0, 200)}...
  `;

  return {
    messages: [...state.messages, new AIMessage(`Analysis complete. Context: ${analysisContext}`)],
  };
};

/**
 * Tool: Documentation Generator
 * Uses the LLM to generate the final JSON object based on the analysis context.
 * This node interacts with the LLM with specific JSON Schema output instructions.
 */
const generateDocumentation = async (state: AgentState): Promise<Partial<AgentState>> => {
  console.log("🤖 [Tool] Generating Documentation via LLM...");
  
  const model = new ChatOpenAI({ model: "gpt-4-turbo-preview", temperature: 0 });
  
  // We construct a prompt using the previous analysis context
  const lastMessage = state.messages[state.messages.length - 1].content as string;
  
  const response = await model.invoke([
    new HumanMessage(
      `Based on the following code analysis, generate API documentation strictly adhering to the provided JSON Schema.
       Analysis Context: ${lastMessage}
       
       JSON Schema: ${JSON.stringify(ApiDocSchema.shape)}
       
       Return ONLY valid JSON. No markdown formatting.
      `
    )
  ]);

  try {
    // Parse the LLM response
    const parsedContent = JSON.parse(response.content as string);
    
    // Validate against Zod schema (Safety Guardrail)
    const validatedDoc = ApiDocSchema.parse(parsedContent);
    
    return {
      messages: [...state.messages, response],
      documentation: validatedDoc,
    };
  } catch (e) {
    console.error("Documentation generation failed validation:", e);
    return {
      messages: [
        ...state.messages, 
        new AIMessage("Documentation generation failed validation. Triggering retry.")
      ]
    };
  }
};

/**
 * Tool: Reviewer / Validator
 * Checks if the generated documentation is valid. If not, increments retry count.
 */
const reviewDocumentation = (state: AgentState): string => {
  console.log("🤖 [Tool] Reviewing Documentation...");
  
  if (!state.documentation) {
    return "retry";
  }

  // Basic semantic check (Safety Guardrail)
  if (state.documentation.description.length < 10) {
    console.warn("Description too short, likely hallucinated.");
    return "retry";
  }

  // Check if all parameters in code are documented
  // (Simplified logic for demo)
  return "finish";
};

// ============================================================================
// 3. GRAPH CONSTRUCTION
// ============================================================================

/**
 * Initializes the LangGraph workflow.
 */
function createWorkflow() {
  const workflow = new StateGraph<AgentState>({
    channels: {
      messages: { reducer: (x, y) => x.concat(y), default: () => [] },
      sourceCode: { reducer: (x, y) => y, default: () => "" }, // Overwrite
      documentation: { reducer: (x, y) => y ?? x, default: () => undefined },
      isValidated: { reducer: (x, y) => y, default: () => false },
      retryCount: { reducer: (x, y) => x + y, default: () => 0 },
    }
  });

  // Define Nodes
  workflow.addNode("analyze_node", analyzeCode);
  workflow.addNode("generate_node", generateDocumentation);
  workflow.addNode("review_node", reviewDocumentation);

  // Define Edges (Control Flow)
  workflow.addEdge(START, "analyze_node");
  workflow.addEdge("analyze_node", "generate_node");
  workflow.addEdge("generate_node", "review_node");

  // Conditional Edge: Retry Logic
  workflow.addConditionalEdges(
    "review_node",
    (state) => {
      // Access the result of reviewDocumentation (stored in messages or separate state field in full impl)
      // Here we simulate checking state for retry trigger
      const lastMsg = state.messages[state.messages.length - 1].content as string;
      if (lastMsg.includes("Triggering retry") || state.retryCount < 3) {
        if (state.retryCount >= 3) return "fail"; // Safety stop
        return "retry_path";
      }
      return "finish_path";
    },
    {
      retry_path: "generate_node", // Loop back to generation
      finish_path: END,
      fail_path: END
    }
  );

  return workflow.compile();
}

// ============================================================================
// 4. NEXT.JS API ROUTE HANDLER
// ============================================================================

/**
 * POST Handler: Receives source code, executes the agent workflow, returns docs.
 * This acts as the entry point for the SaaS frontend.
 */
export async function POST(req: NextRequest) {
  try {
    const { sourceCode } = await req.json();

    if (!sourceCode) {
      return NextResponse.json(
        { error: "Source code is required." },
        { status: 400 }
      );
    }

    // Initialize the LangGraph
    const app = createWorkflow();

    // Set up initial state
    const initialState: AgentState = {
      messages: [new HumanMessage("Please document this code.")],
      sourceCode: sourceCode,
      isValidated: false,
      retryCount: 0,
    };

    // Execute the graph (Streaming is supported but we await full execution here for simplicity)
    // In a real SaaS app, you might stream tokens back to the client using AIStream parsers.
    const finalState = await app.invoke(initialState);

    // Extract the final documentation
    const result = finalState.documentation;

    if (!result) {
      return NextResponse.json(
        { error: "Failed to generate documentation after retries." },
        { status: 500 }
      );
    }

    return NextResponse.json({
      success: true,
      data: result,
      trace: finalState.messages.map(m => m.content).slice(-3) // Debug trace
    });

  } catch (error) {
    console.error("Workflow Error:", error);
    return NextResponse.json(
      { error: "Internal Server Error" },
      { status: 500 }
    );
  }
}
