/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// types.ts
import { z } from 'zod';

// 1. Define the CodeArtifact interface (implicitly via Zod)
// While the prompt asks for an interface, using Zod infers the type automatically.
// We export the inferred type to match the requirement.
export interface CodeArtifact {
  filePath: string;
  codeContent: string;
  dependencies: string[];
  description: string;
}

// 2. Define the codeArtifactSchema using Zod
export const codeArtifactSchema = z.object({
  filePath: z.string().refine(
    (val) => /\.(ts|js|tsx)$/.test(val),
    { message: "File path must end with .ts, .js, or .tsx" }
  ),
  codeContent: z.string(),
  dependencies: z.array(z.string()),
  description: z.string(),
});

// 3. Implement the parseLLMResponse function
export function parseLLMResponse(rawResponse: string): CodeArtifact {
  try {
    // Attempt to parse the raw string as JSON
    const parsedJson = JSON.parse(rawResponse);

    // Validate the parsed JSON against the Zod schema
    const validatedData = codeArtifactSchema.parse(parsedJson);

    return validatedData;
  } catch (error) {
    if (error instanceof z.ZodError) {
      // Throw a detailed error object on validation failure
      const formattedErrors = error.errors.map((err) => ({
        field: err.path.join('.'),
        message: err.message,
      }));
      throw new Error(`Validation failed: ${JSON.stringify(formattedErrors)}`);
    }
    if (error instanceof SyntaxError) {
      throw new Error(`JSON parsing failed: ${error.message}`);
    }
    // Re-throw unknown errors
    throw error;
  }
}
