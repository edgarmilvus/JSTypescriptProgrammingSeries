/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part6.tsx
// Description: Solutions and Explanations
// ==========================================

// CodingAssistantChat.tsx
import React from 'react';
import { useChat } from '@ai-sdk/react';

export const CodingAssistantChat: React.FC = () => {
  // 1. Initialize the useChat hook
  const { 
    messages, 
    input, 
    handleInputChange, 
    handleSubmit, 
    isLoading 
  } = useChat({
    api: '/api/agent', // Hypothetical endpoint
  });

  return (
    <div className="chat-container" style={{ display: 'flex', flexDirection: 'column', height: '100vh', padding: '20px' }}>
      
      {/* 2. Message List */}
      <div className="message-list" style={{ flex: 1, overflowY: 'auto', marginBottom: '20px' }}>
        {messages.map((message) => (
          <div 
            key={message.id} 
            className={`message ${message.role}`}
            style={{
              marginBottom: '10px',
              padding: '10px',
              borderRadius: '8px',
              backgroundColor: message.role === 'user' ? '#e3f2fd' : '#f5f5f5',
              textAlign: message.role === 'user' ? 'right' : 'left',
            }}
          >
            {/* 3. Conditional Rendering for Assistant */}
            {message.role === 'assistant' ? (
              // Render code blocks for assistant
              <pre style={{ 
                fontFamily: 'monospace', 
                backgroundColor: '#2d2d2d', 
                color: '#fff', 
                padding: '10px', 
                borderRadius: '4px',
                textAlign: 'left',
                whiteSpace: 'pre-wrap'
              }}>
                {message.content}
              </pre>
            ) : (
              // Render plain text for user
              <span>{message.content}</span>
            )}
          </div>
        ))}
        
        {/* Loading Indicator */}
        {isLoading && (
          <div style={{ fontStyle: 'italic', color: '#666' }}>
            Agent is thinking...
          </div>
        )}
      </div>

      {/* 4. Input Form */}
      <form onSubmit={handleSubmit} style={{ display: 'flex', gap: '10px' }}>
        <input
          type="text"
          value={input}
          onChange={handleInputChange}
          placeholder="Describe the coding task..."
          style={{ flex: 1, padding: '10px', borderRadius: '4px', border: '1px solid #ccc' }}
        />
        <button 
          type="submit" 
          disabled={isLoading}
          style={{ padding: '10px 20px', cursor: isLoading ? 'not-allowed' : 'pointer' }}
        >
          Send
        </button>
      </form>
    </div>
  );
};
