/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part7.ts
// Description: Solutions and Explanations
// ==========================================

// sandbox.ts

// 1. Define the ToolCall type
type ToolCall = {
  tool: 'write_file' | 'execute_command' | 'read_file';
  args: Record<string, any>;
};

// 2. Implement the validateToolCall function
export function validateToolCall(call: ToolCall): { allowed: boolean; reason?: string } {
  const { tool, args } = call;

  switch (tool) {
    case 'write_file':
      // Rule: No absolute paths (starting with /)
      if (args.path.startsWith('/')) {
        return { allowed: false, reason: "Absolute paths are not allowed." };
      }
      // Rule: No directory traversal (containing ..)
      if (args.path.includes('..')) {
        return { allowed: false, reason: "Directory traversal detected (..)." };
      }
      return { allowed: true };

    case 'execute_command':
      // Rule: Strictly forbidden
      return { allowed: false, reason: "Command execution is disabled in this sandbox." };

    case 'read_file':
      // Rule: Must be within ./project/ directory
      if (!args.path.startsWith('./project/')) {
        return { allowed: false, reason: "Read access restricted to ./project/ directory." };
      }
      return { allowed: true };

    default:
      return { allowed: false, reason: "Unknown tool." };
  }
}

// 3. Test Case
function testSandbox() {
  console.log("--- Running Sandbox Tests ---");

  // Test 1: Valid Write
  const validWrite: ToolCall = { tool: 'write_file', args: { path: './project/src/main.ts' } };
  const result1 = validateToolCall(validWrite);
  console.log(`Valid Write: ${result1.allowed ? "PASS" : "FAIL"}`);
  if (!result1.allowed) console.error("Unexpected failure:", result1.reason);

  // Test 2: Invalid Write (Absolute Path)
  const invalidAbs: ToolCall = { tool: 'write_file', args: { path: '/etc/passwd' } };
  const result2 = validateToolCall(invalidAbs);
  console.log(`Invalid Abs Path: ${result2.allowed ? "FAIL" : "PASS"} - Reason: ${result2.reason}`);

  // Test 3: Invalid Write (Directory Traversal)
  const invalidTraversal: ToolCall = { tool: 'write_file', args: { path: '../../secrets.txt' } };
  const result3 = validateToolCall(invalidTraversal);
  console.log(`Invalid Traversal: ${result3.allowed ? "FAIL" : "PASS"} - Reason: ${result3.reason}`);

  // Test 4: Forbidden Command
  const forbiddenCmd: ToolCall = { tool: 'execute_command', args: { cmd: 'rm -rf /' } };
  const result4 = validateToolCall(forbiddenCmd);
  console.log(`Forbidden Command: ${result4.allowed ? "FAIL" : "PASS"} - Reason: ${result4.reason}`);

  // Test 5: Valid Read
  const validRead: ToolCall = { tool: 'read_file', args: { path: './project/config.json' } };
  const result5 = validateToolCall(validRead);
  console.log(`Valid Read: ${result5.allowed ? "PASS" : "FAIL"}`);

  // Test 6: Invalid Read (Outside project)
  const invalidRead: ToolCall = { tool: 'read_file', args: { path: './.env' } };
  const result6 = validateToolCall(invalidRead);
  console.log(`Invalid Read: ${result6.allowed ? "FAIL" : "PASS"} - Reason: ${result6.reason}`);
}

// Run tests
testSandbox();
