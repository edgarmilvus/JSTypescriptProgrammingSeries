/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * @fileoverview A self-contained demonstration of client-side AI inference
 * using the WebGPU API. This mimics the forward pass of a transformer layer.
 */

// -----------------------------------------------------------------------------
// 1. TYPE DEFINITIONS
// -----------------------------------------------------------------------------

/**
 * Represents a Tensor (a multi-dimensional array) stored in GPU memory.
 * In a real library (like ONNX Runtime), this handles memory layout and binding.
 */
interface GPUTensor {
    buffer: GPUBuffer;
    shape: [number, number]; // [rows, cols]
}

// -----------------------------------------------------------------------------
// 2. WEBGPU INITIALIZER
// -----------------------------------------------------------------------------

/**
 * Initializes the WebGPU adapter and device.
 * This is the equivalent of `torch.cuda.set_device()`.
 */
async function initWebGPU(): Promise<GPUDevice> {
    if (!navigator.gpu) {
        throw new Error("WebGPU is not supported in this browser.");
    }

    const adapter = await navigator.gpu.requestAdapter();
    if (!adapter) {
        throw new Error("No WebGPU adapter found.");
    }

    const device = await adapter.requestDevice();
    return device;
}

// -----------------------------------------------------------------------------
// 3. SHADER CODE (The "Kernel")
// -----------------------------------------------------------------------------

/**
 * WGSL (WebGPU Shading Language) code for Matrix Multiplication.
 * This runs on the GPU. It is highly parallelized.
 * We are simulating a dense linear layer: Y = X * W + B
 */
const shaderCode = `
    @group(0) @binding(0) var<storage, read> matrixA: array<f32>;
    @group(0) @binding(1) var<storage, read> matrixB: array<f32>;
    @group(0) @binding(2) var<storage, read_write> resultMatrix: array<f32>;

    @compute @workgroup_size(8, 8)
    fn main(@builtin(global_invocation_id) global_id: vec3<u32>) {
        let row = global_id.x;
        let col = global_id.y;
        
        // Assuming square matrices for simplicity in this demo
        let dim = 64u; 
        
        if (row >= dim || col >= dim) {
            return;
        }

        var sum = 0.0;
        for (var k = 0u; k < dim; k = k + 1u) {
            // Standard matrix multiplication: C[i][j] += A[i][k] * B[k][j]
            sum = sum + matrixA[row * dim + k] * matrixB[k * dim + col];
        }

        resultMatrix[row * dim + col] = sum;
    }
`;

// -----------------------------------------------------------------------------
// 4. THE INFERENCE ENGINE
// -----------------------------------------------------------------------------

/**
 * Orchestrates the client-side inference pipeline.
 */
class LocalInferenceEngine {
    private device: GPUDevice;
    private pipeline: GPUComputePipeline;
    private bindGroupLayout: GPUBindGroupLayout;

    constructor(device: GPUDevice) {
        this.device = device;
        
        // Create the compute pipeline
        const module = this.device.createShaderModule({ code: shaderCode });
        
        this.pipeline = this.device.createComputePipeline({
            layout: 'auto',
            compute: {
                module,
                entryPoint: "main",
            },
        });

        this.bindGroupLayout = this.pipeline.getBindGroupLayout(0);
    }

    /**
     * Performs the inference step.
     * @param inputMatrix - Flattened array of input data (e.g., text embeddings)
     * @param weightMatrix - Flattened array of model weights
     */
    async runInference(inputMatrix: Float32Array, weightMatrix: Float32Array): Promise<Float32Array> {
        // --- A. ALLOCATE MEMORY ON GPU ---
        // Create input buffer (Read Only)
        const inputBuffer = this.device.createBuffer({
            size: inputMatrix.byteLength,
            usage: GPUBufferUsage.STORAGE | GPUBufferUsage.COPY_DST,
        });
        this.device.queue.writeBuffer(inputBuffer, 0, inputMatrix);

        // Create weights buffer (Read Only)
        const weightBuffer = this.device.createBuffer({
            size: weightMatrix.byteLength,
            usage: GPUBufferUsage.STORAGE | GPUBufferUsage.COPY_DST,
        });
        this.device.queue.writeBuffer(weightBuffer, 0, weightMatrix);

        // Create result buffer (Read/Write)
        const resultBufferSize = inputMatrix.byteLength; // Assuming square matrices
        const resultBuffer = this.device.createBuffer({
            size: resultBufferSize,
            usage: GPUBufferUsage.STORAGE | GPUBufferUsage.COPY_SRC,
        });

        // --- B. BIND RESOURCES TO SHADER ---
        const bindGroup = this.device.createBindGroup({
            layout: this.bindGroupLayout,
            entries: [
                { binding: 0, resource: { buffer: inputBuffer } },
                { binding: 1, resource: { buffer: weightBuffer } },
                { binding: 2, resource: { buffer: resultBuffer } },
            ],
        });

        // --- C. ENCODE COMMANDS ---
        const commandEncoder = this.device.createCommandEncoder();
        const passEncoder = commandEncoder.beginComputePass();
        
        passEncoder.setPipeline(this.pipeline);
        passEncoder.setBindGroup(0, bindGroup);
        
        // Dispatch work: 64x64 threads (8x8 workgroup size -> 8x8 groups)
        passEncoder.dispatchWorkgroups(8, 8); 
        passEncoder.end();

        // --- D. SUBMIT TO GPU QUEUE ---
        this.device.queue.submit([commandEncoder.finish()]);

        // --- E. READBACK RESULTS (Async) ---
        // Map the result buffer to read it back to the CPU
        const readbackBuffer = this.device.createBuffer({
            size: resultBufferSize,
            usage: GPUBufferUsage.COPY_DST | GPUBufferUsage.MAP_READ,
        });

        // Copy from GPU storage buffer to readback buffer
        commandEncoder.copyBufferToBuffer(resultBuffer, 0, readbackBuffer, 0, resultBufferSize);
        
        // Submit the copy command
        this.device.queue.submit([commandEncoder.finish()]);

        // Wait for GPU to finish and map memory
        await readbackBuffer.mapAsync(GPUMapMode.READ);
        const arrayBuffer = readbackBuffer.getMappedRange();
        const result = new Float32Array(arrayBuffer);

        // Cleanup
        inputBuffer.destroy();
        weightBuffer.destroy();
        resultBuffer.destroy();
        readbackBuffer.unmap();
        readbackBuffer.destroy();

        return result;
    }
}

// -----------------------------------------------------------------------------
// 5. MAIN EXECUTION FLOW
// -----------------------------------------------------------------------------

/**
 * Simulates the main application entry point.
 * In a real app, 'inputMatrix' would be tokenized text, 
 * and 'weightMatrix' would be loaded from a .bin or .safetensors file.
 */
async function main() {
    console.log("🚀 Initializing Local AI Engine (WebGPU)...");
    
    try {
        const device = await initWebGPU();
        const engine = new LocalInferenceEngine(device);

        // Define Matrix Dimensions (64x64)
        const DIM = 64;
        const SIZE = DIM * DIM;

        // Generate Mock Data
        // In a real scenario, these are Float32Arrays loaded from a model file
        const inputMatrix = new Float32Array(SIZE).fill(1.0); 
        const weightMatrix = new Float32Array(SIZE).fill(0.5); 

        console.log("⏳ Running inference on GPU...");
        const startTime = performance.now();

        // Execute the compute shader
        const result = await engine.runInference(inputMatrix, weightMatrix);

        const endTime = performance.now();
        
        console.log(`✅ Inference complete in ${(endTime - startTime).toFixed(2)}ms`);
        console.log("Result (First 5 values):", result.slice(0, 5));
        
        // Verify logic: 1.0 * 0.5 * 64 (sum of dot product) = 32.0
        console.log(`Expected value: 32.0, Actual: ${result[0]}`);

    } catch (error) {
        console.error("❌ Error running local inference:", error);
    }
}

// Run the main function
// main(); // Uncomment to execute in a browser environment
