/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.tsx
// Description: Advanced Application Script
// ==========================================

// app/components/LocalSummarizer.tsx
'use client';

import React, { useState, useEffect, useRef } from 'react';
import * as webllm from '@mlc-ai/web-llm';

/**
 * LocalSummarizer Component
 * 
 * A React component that loads a Large Language Model (LLM) locally in the browser
 * using WebLLM (built on top of WebGPU/Transformers.js) to summarize text.
 * 
 * Key Features:
 * 1. **Privacy**: Text is processed entirely on the client-side. No data is sent to an API.
 * 2. **Latency**: Once loaded, inference is near-instant as it runs on local hardware.
 * 3. **Performance**: Utilizes WebGPU for parallel computation of transformer layers.
 */
export default function LocalSummarizer() {
  // State for managing the loading progress of the model (weights downloading, compiling)
  const [loadingProgress, setLoadingProgress] = useState<string>('Idle');
  // State for the user's input text
  const [inputText, setInputText] = useState<string>('');
  // State for the generated summary
  const [summary, setSummary] = useState<string>('');
  // State to track if the model is ready for inference
  const [isModelReady, setIsModelReady] = useState<boolean>(false);
  // State for any runtime errors
  const [error, setError] = useState<string | null>(null);

  // Ref to hold the ChatModule instance from WebLLM to persist across re-renders
  const chatModuleRef = useRef<webllm.ChatModule | null>(null);

  /**
   * Initialize the AI Model
   * 
   * We use a useEffect hook to handle the asynchronous model loading process.
   * This mimics the "Service Worker Caching" concept by leveraging WebLLM's built-in
   * IndexedDB caching mechanism. Once downloaded, model weights are stored locally
   * and retrieved instantly on subsequent loads.
   */
  useEffect(() => {
    const initModel = async () => {
      if (isModelReady) return; // Prevent re-initialization

      try {
        setLoadingProgress('Initializing engine...');
        
        // Initialize the ChatModule
        // Under the hood, this sets up the WebGPU device and the execution graph.
        const chatModule = new webllm.ChatModule();

        // Define progress callback to update UI during weight download
        chatModule.setInitProgressCallback((report) => {
          setLoadingProgress(report);
        });

        setLoadingProgress('Loading model weights (approx 1-2GB)...');
        
        // Select a model optimized for WebGPU (distilled for edge performance)
        // We use a smaller model (e.g., Phi-2 or Llama-3-8B) to ensure reasonable load times.
        const selectedModel = 'Phi-3.5-mini-instruct'; 

        // Load the model. This checks IndexedDB first (caching), then downloads if missing.
        await chatModule.reload(selectedModel);

        chatModuleRef.current = chatModule;
        setIsModelReady(true);
        setLoadingProgress('Model Ready');
        
      } catch (err) {
        console.error(err);
        setError('Failed to load model. Ensure your browser supports WebGPU.');
        setLoadingProgress('Error');
      }
    };

    initModel();

    // Cleanup function to dispose of the model if the component unmounts
    return () => {
      if (chatModuleRef.current) {
        chatModuleRef.current.runtimeDispose();
      }
    };
  }, [isModelReady]);

  /**
   * Handle Summarization Request
   * 
   * 1. Constructs a prompt instructing the local model to summarize.
   * 2. Calls the `generate` method on the local model instance.
   * 3. Streams the output token-by-token for low perceived latency.
   */
  const handleSummarize = async () => {
    if (!inputText.trim()) return;
    if (!chatModuleRef.current) return;

    setSummary('');
    setError(null);

    const prompt = `Summarize the following text in 3 bullet points:\n\n${inputText}\n\nSummary:`;

    try {
      // Streaming callback: Updates UI as tokens are generated locally
      const streamCallback = (msg: webllm.GenerateResponse) => {
        setSummary((prev) => prev + msg);
      };

      // Generate response using the local model
      // This runs the transformer forward pass on the WebGPU compute shader.
      await chatModuleRef.current.generate(
        { prompt, stream_callback: streamCallback },
        { temperature: 0.7, max_gen_len: 256 }
      );

    } catch (err) {
      console.error(err);
      setError('Inference failed. Try reducing input length.');
    }
  };

  return (
    <div className="max-w-4xl mx-auto p-6 bg-white shadow-lg rounded-lg border border-gray-200">
      <header className="mb-6">
        <h1 className="text-2xl font-bold text-gray-900">Local AI Summarizer</h1>
        <p className="text-sm text-gray-600 mt-1">
          Powered by WebGPU. Your data stays on this device.
        </p>
      </header>

      {/* Status Indicator */}
      <div className="mb-4 p-3 rounded-md bg-gray-50 text-sm font-mono text-gray-700 border border-gray-200">
        <span className="font-semibold">Status:</span> {loadingProgress}
        {isModelReady && (
          <span className="ml-2 text-green-600">● Ready</span>
        )}
      </div>

      {error && (
        <div className="mb-4 p-3 bg-red-50 text-red-700 rounded border border-red-200">
          {error}
        </div>
      )}

      {/* Input Area */}
      <div className="space-y-4">
        <textarea
          className="w-full h-40 p-3 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:outline-none disabled:bg-gray-100"
          placeholder="Paste text to summarize locally..."
          value={inputText}
          onChange={(e) => setInputText(e.target.value)}
          disabled={!isModelReady}
        />
        
        <button
          onClick={handleSummarize}
          disabled={!isModelReady || !inputText.trim()}
          className={`px-6 py-2 rounded-md text-white font-medium transition-colors ${
            isModelReady && inputText.trim()
              ? 'bg-blue-600 hover:bg-blue-700'
              : 'bg-gray-400 cursor-not-allowed'
          }`}
        >
          {isModelReady ? 'Summarize Locally' : 'Loading Model...'}
        </button>
      </div>

      {/* Output Area */}
      {summary && (
        <div className="mt-6 p-4 bg-gray-50 rounded-md border border-gray-200">
          <h3 className="text-lg font-semibold text-gray-800 mb-2">Local Summary</h3>
          <div className="whitespace-pre-wrap text-gray-700">{summary}</div>
        </div>
      )}
    </div>
  );
}
