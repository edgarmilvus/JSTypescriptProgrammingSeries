/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.tsx
// Description: Solutions and Explanations
// ==========================================

// File: components/BenchmarkTool.tsx
import React, { useState } from 'react';

interface BenchmarkMetrics {
  ttft: number | null;
  totalTime: number | null;
  tps: number | null;
  status: string;
  isRunning: boolean;
  tokens: number;
}

export default function BenchmarkTool() {
  const [metrics, setMetrics] = useState<BenchmarkMetrics>({
    ttft: null,
    totalTime: null,
    tps: null,
    status: 'Idle',
    isRunning: false,
    tokens: 0,
  });

  // Simulate a streaming response from a local model
  const simulateInference = async (onChunk: (token: string) => void) => {
    const prompt = "Explain quantum computing in one sentence.";
    const responseTokens = [
      "Quantum", " computing", " leverages", " quantum", " mechanics", 
      " to", " solve", " problems", " too", " complex", " for", " classical", " computers."
    ];
    
    // Simulate network latency before first token
    await new Promise(resolve => setTimeout(resolve, 200 + Math.random() * 100));

    for (const token of responseTokens) {
      onChunk(token);
      // Simulate token generation delay
      await new Promise(resolve => setTimeout(resolve, 50 + Math.random() * 20));
    }
  };

  const runBenchmark = async () => {
    if (metrics.isRunning) return;

    setMetrics({
      ttft: null,
      totalTime: null,
      tps: null,
      status: 'Generating',
      isRunning: true,
      tokens: 0,
    });

    const startTime = performance.now();
    let firstTokenTime = 0;
    let tokenCount = 0;

    try {
      await simulateInference((token) => {
        tokenCount++;
        
        // Capture TTFT on the very first chunk
        if (firstTokenTime === 0) {
          firstTokenTime = performance.now();
        }

        // In a real app, we would update UI here. 
        // For benchmarking, we just track the count.
      });

      const endTime = performance.now();
      
      const ttft = firstTokenTime - startTime;
      const totalTime = endTime - startTime;
      const tps = tokenCount / (totalTime / 1000); // Tokens per second

      setMetrics({
        ttft: parseFloat(ttft.toFixed(2)),
        totalTime: parseFloat(totalTime.toFixed(2)),
        tps: parseFloat(tps.toFixed(2)),
        status: 'Complete',
        isRunning: false,
        tokens: tokenCount,
      });

    } catch (error) {
      setMetrics(prev => ({ ...prev, status: 'Error', isRunning: false }));
    }
  };

  return (
    <div className="p-6 border rounded-lg shadow-sm bg-white max-w-md mx-auto">
      <h2 className="text-xl font-bold mb-4 text-gray-800">Local AI Latency Benchmark</h2>
      
      <div className="space-y-4">
        <button
          onClick={runBenchmark}
          disabled={metrics.isRunning}
          className={`w-full py-2 px-4 rounded font-semibold text-white transition-colors ${
            metrics.isRunning 
              ? 'bg-gray-400 cursor-not-allowed' 
              : 'bg-blue-600 hover:bg-blue-700'
          }`}
        >
          {metrics.isRunning ? 'Running...' : 'Run Benchmark'}
        </button>

        <div className="p-4 bg-gray-50 rounded border">
          <div className="flex justify-between items-center mb-2">
            <span className="font-medium text-gray-600">Status:</span>
            <span className="font-bold text-blue-600">{metrics.status}</span>
          </div>
          
          <div className="grid grid-cols-2 gap-4 text-sm">
            <div className="bg-white p-2 rounded border">
              <div className="text-gray-500">TTFT (ms)</div>
              <div className="text-lg font-mono font-bold">
                {metrics.ttft ?? '-'}
              </div>
            </div>
            <div className="bg-white p-2 rounded border">
              <div className="text-gray-500">Total Time (ms)</div>
              <div className="text-lg font-mono font-bold">
                {metrics.totalTime ?? '-'}
              </div>
            </div>
            <div className="bg-white p-2 rounded border">
              <div className="text-gray-500">TPS</div>
              <div className="text-lg font-mono font-bold">
                {metrics.tps ?? '-'}
              </div>
            </div>
            <div className="bg-white p-2 rounded border">
              <div className="text-gray-500">Tokens</div>
              <div className="text-lg font-mono font-bold">
                {metrics.tokens}
              </div>
            </div>
          </div>
        </div>

        {metrics.isRunning && (
          <div className="w-full bg-gray-200 rounded-full h-2.5">
            <div className="bg-blue-600 h-2.5 rounded-full animate-pulse" style={{ width: '100%' }}></div>
          </div>
        )}
      </div>
    </div>
  );
}
