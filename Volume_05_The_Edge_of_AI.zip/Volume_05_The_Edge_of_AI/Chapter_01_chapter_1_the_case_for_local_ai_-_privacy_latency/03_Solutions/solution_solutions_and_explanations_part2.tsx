/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.tsx
// Description: Solutions and Explanations
// ==========================================

// File: components/LocalChat.tsx
import React, { useState, useRef, useEffect } from 'react';

interface Message {
  role: 'user' | 'assistant';
  content: string;
}

// Simulate a local model inference engine
const mockInference = async (prompt: string): Promise<string> => {
  // Rule-based simulation for responsiveness
  if (prompt.toLowerCase().includes("weather")) {
    return "Based on local sensors, the weather is sunny with a slight breeze.";
  }
  if (prompt.toLowerCase().includes("time")) {
    return "Local system time is " + new Date().toLocaleTimeString();
  }
  
  // Generic response
  const genericResponses = [
    "That's an interesting thought. Locally processed.",
    "I understand. Here is a summary based on your context.",
    "Processing complete. Here is the result.",
  ];
  return genericResponses[Math.floor(Math.random() * genericResponses.length)];
};

// Helper to simulate streaming chunks
const streamText = async (text: string, onChunk: (chunk: string) => void) => {
  const words = text.split(' ');
  for (const word of words) {
    await new Promise(resolve => setTimeout(resolve, 50)); // Simulate typing speed
    onChunk(word + ' ');
  }
};

export default function LocalChat() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [isThinking, setIsThinking] = useState(false);
  const [privacyStatus, setPrivacyStatus] = useState<'idle' | 'local'>('idle');
  
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim() || isThinking) return;

    // 1. Add User Message
    const userMessage: Message = { role: 'user', content: input };
    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setIsThinking(true);
    setPrivacyStatus('local');

    // 2. Prepare Assistant Message (Streaming placeholder)
    const assistantMessageId = Date.now();
    setMessages(prev => [...prev, { role: 'assistant', content: '' }]);

    // 3. Run Local Inference
    const response = await mockInference(input);

    // 4. Stream the response into the UI
    let accumulatedContent = '';
    await streamText(response, (chunk) => {
      accumulatedContent += chunk;
      setMessages(prev => prev.map(msg => 
        msg.role === 'assistant' && msg.content.length === 0 // Target the empty assistant message
          ? { ...msg, content: accumulatedContent }
          : msg
      ));
    });

    setIsThinking(false);
    setPrivacyStatus('idle');
  };

  return (
    <div className="flex flex-col h-[500px] max-w-2xl mx-auto border rounded-lg shadow-lg bg-white overflow-hidden">
      {/* Header / Privacy Indicator */}
      <div className="bg-gray-50 border-b p-3 flex items-center justify-between">
        <span className="font-semibold text-gray-700">Local Chat</span>
        <div className={`flex items-center gap-2 px-3 py-1 rounded-full text-xs font-medium transition-colors ${
          privacyStatus === 'local' 
            ? 'bg-green-100 text-green-700 animate-pulse' 
            : 'bg-gray-200 text-gray-600'
        }`}>
          <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
          </svg>
          {privacyStatus === 'local' ? 'Local Processing' : 'Idle'}
        </div>
      </div>

      {/* Chat History */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-white">
        {messages.map((msg, index) => (
          <div key={index} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
            <div className={`max-w-[80%] px-4 py-2 rounded-lg ${
              msg.role === 'user' 
                ? 'bg-blue-600 text-white rounded-br-none' 
                : 'bg-gray-100 text-gray-800 rounded-bl-none'
            }`}>
              {msg.content || (msg.role === 'assistant' ? '...' : '')}
            </div>
          </div>
        ))}
        <div ref={messagesEndRef} />
      </div>

      {/* Input Area */}
      <div className="p-3 border-t bg-gray-50">
        <div className="flex gap-2">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSend()}
            disabled={isThinking}
            placeholder="Ask something local..."
            className="flex-1 px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 disabled:bg-gray-200"
          />
          <button
            onClick={handleSend}
            disabled={isThinking}
            className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 disabled:bg-gray-400 transition-colors"
          >
            Send
          </button>
        </div>
      </div>
    </div>
  );
}
