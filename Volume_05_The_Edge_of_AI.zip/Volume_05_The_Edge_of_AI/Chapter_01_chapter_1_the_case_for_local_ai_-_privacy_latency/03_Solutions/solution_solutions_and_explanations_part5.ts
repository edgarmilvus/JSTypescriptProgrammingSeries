/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

// File: utils/inferenceRouter.ts

interface DeviceCapabilities {
  hasWebGPU: boolean;
  memoryGB: number;
}

interface NetworkStatus {
  effectiveType: 'slow-2g' | '2g' | '3g' | '4g' | '5g' | 'wifi';
  saveData: boolean;
}

interface UserPreferences {
  prioritizePrivacy: boolean;
  allowHeavyProcessing: boolean;
}

interface UserContext {
  deviceCapabilities: DeviceCapabilities;
  networkStatus: NetworkStatus;
  userPreferences: UserPreferences;
}

type Feature = 'summarization' | 'grammar_check';
type Route = 'client' | 'edge' | 'cloud';

export function decideInferenceRoute(feature: Feature, context: UserContext): Route {
  const { deviceCapabilities, networkStatus, userPreferences } = context;

  // 1. Grammar Check (Low Compute)
  if (feature === 'grammar_check') {
    // If user prioritizes privacy, run locally if possible
    if (userPreferences.prioritizePrivacy) {
      // Even low-end devices can usually handle small grammar models
      return 'client';
    }
    
    // If network is excellent and device is weak, offload to Edge for speed
    if (networkStatus.effectiveType === '5g' || networkStatus.effectiveType === 'wifi') {
      return 'edge';
    }

    // Default to Client for low compute tasks
    return 'client';
  }

  // 2. Summarization (High Compute)
  if (feature === 'summarization') {
    // Strict Privacy Requirement
    if (userPreferences.prioritizePrivacy) {
      // Check hardware viability
      if (deviceCapabilities.hasWebGPU && deviceCapabilities.memoryGB >= 8) {
        return 'client'; // Powerful enough to handle 7B model locally
      } else {
        // Hardware insufficient, but privacy is key.
        // Fallback: Edge with encryption (Trusted Execution Environment concept)
        return 'edge'; 
      }
    }

    // Performance / Cost Optimization
    if (!userPreferences.allowHeavyProcessing) {
      return 'cloud'; // Offload cost to server
    }

    // Default Hybrid Strategy
    if (deviceCapabilities.hasWebGPU && networkStatus.effectiveType === 'wifi') {
      return 'client'; // Fast local processing
    } else if (networkStatus.effectiveType === '4g' || networkStatus.effectiveType === '5g') {
      return 'edge'; // Reliable network, low latency
    } else {
      // Slow network, fallback to cloud (optimized bandwidth) or local if desperate
      return 'cloud';
    }
  }

  return 'edge'; // Safe default
}
