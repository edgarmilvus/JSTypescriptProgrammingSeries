/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part6.ts
// Description: Solutions and Explanations
// ==========================================

digraph DecisionTree {
    rankdir=TB;
    node [shape=diamond, style=filled, color=lightblue];
    
    Start [label="Request Inference"];
    
    node [shape=box, style=filled, color=lightgrey];
    Client [label="Route: Client\n(Local GPU/CPU)"];
    Edge [label="Route: Edge\n(Regional Server)"];
    Cloud [label="Route: Cloud\n(Central Server)"];
    
    node [shape=diamond, style=filled, color=orange];
    
    // Summarization Logic
    SumFeature [label="Feature: Summarization?"];
    PrivacyCheck [label="Prioritize Privacy?"];
    HardwareCheck [label="WebGPU & >8GB RAM?"];
    NetworkCheck [label="Network: WiFi/4G/5G?"];
    BatteryCheck [label="Battery OK & Heavy Allowed?"];
    
    // Connections
    Start -> SumFeature;
    
    SumFeature -> PrivacyCheck [label="Yes"];
    SumFeature -> GrammarLogic [label="No (Grammar Check)"];
    
    PrivacyCheck -> HardwareCheck [label="Yes"];
    PrivacyCheck -> BatteryCheck [label="No"];
    
    HardwareCheck -> Client [label="Yes"];
    HardwareCheck -> Edge [label="No (Weak Hardware)"];
    
    BatteryCheck -> NetworkCheck [label="Yes"];
    BatteryCheck -> Cloud [label="No (Low Battery/Restricted)"];
    
    NetworkCheck -> Client [label="WiFi"];
    NetworkCheck -> Edge [label="4G/5G"];
    NetworkCheck -> Cloud [label="Slow (3G)"];
    
    // Grammar Logic Subgraph
    GrammarLogic [label="Grammar Check"];
    GrammarPrivacy [label="Prioritize Privacy?"];
    
    GrammarLogic -> GrammarPrivacy;
    GrammarPrivacy -> Client [label="Yes"];
    GrammarPrivacy -> Edge [label="No (Fast Net)"];
    
    // Styling
    Client [shape=ellipse, color="#a7f3d0"];
    Edge [shape=ellipse, color="#fde68a"];
    Cloud [shape=ellipse, color="#fca5a5"];
}
