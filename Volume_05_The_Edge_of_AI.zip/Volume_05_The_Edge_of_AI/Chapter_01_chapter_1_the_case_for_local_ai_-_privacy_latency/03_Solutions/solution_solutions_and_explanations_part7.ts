/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part7.ts
// Description: Solutions and Explanations
// ==========================================

// File: hooks/useWebGPUInference.ts
import { useState, useEffect, useCallback } from 'react';

type Status = 'unavailable' | 'initializing' | 'ready' | 'computing' | 'error';

interface WebGPUState {
  status: Status;
  inference: (prompt: string) => Promise<string>;
  gpuInfo?: string;
}

export default function useWebGPUInference(): WebGPUState {
  const [status, setStatus] = useState<Status>('unavailable');
  const [gpuInfo, setGpuInfo] = useState<string | undefined>();

  // Simulate WebGPU Initialization (since we can't access real GPU in this environment)
  const initializeWebGPU = useCallback(async () => {
    setStatus('initializing');
    
    // Simulate async adapter request
    await new Promise(resolve => setTimeout(resolve, 1000));

    // Check if WebGPU exists in browser (real check)
    if (typeof navigator !== 'undefined' && (navigator as any).gpu) {
      // In a real app, we would do: const adapter = await navigator.gpu.requestAdapter();
      // const device = await adapter.requestDevice();
      setGpuInfo("Simulated Adapter (e.g., Apple M2, NVIDIA RTX)");
      setStatus('ready');
    } else {
      // Fallback simulation for environments without WebGPU (like this text editor)
      // We simulate "success" for the exercise logic, but in reality, this would fail.
      // For this exercise, we will force 'ready' after delay to demonstrate the hook usage.
      setGpuInfo("Simulated Adapter (Fallback Mode)");
      setStatus('ready');
    }
  }, []);

  useEffect(() => {
    initializeWebGPU();
  }, [initializeWebGPU]);

  const inference = useCallback(async (prompt: string): Promise<string> => {
    if (status !== 'ready') {
      throw new Error("WebGPU not ready");
    }

    setStatus('computing');

    try {
      // Simulate GPU Compute Dispatch
      console.log("Submitting buffer to GPU queue...");
      
      // Simulate compute shader execution time
      await new Promise(resolve => setTimeout(resolve, 800 + Math.random() * 400));
      
      setStatus('ready');
      return `GPU Accelerated Result for: "${prompt}"`;
    } catch (e) {
      setStatus('error');
      return "Inference failed";
    }
  }, [status]);

  return {
    status,
    inference,
    gpuInfo,
  };
}
