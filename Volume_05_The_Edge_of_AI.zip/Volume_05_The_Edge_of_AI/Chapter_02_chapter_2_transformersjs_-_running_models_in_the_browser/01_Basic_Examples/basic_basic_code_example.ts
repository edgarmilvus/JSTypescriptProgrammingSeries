/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * @fileoverview A "Hello World" example for Transformers.js running in the browser.
 * This script loads a sentiment analysis model from Hugging Face Hub and classifies text.
 * 
 * @requires transformers@latest (Imported via CDN in the HTML context or npm)
 * 
 * @example
 * <script type="module" src="./sentiment-analysis.ts"></script>
 */

// 1. Import the specific pipeline function from the Transformers.js library.
// In a real project, this would be: import { pipeline, env } from '@xenova/transformers';
// For this standalone example, we assume the library is loaded via CDN, exposing 'transformers' globally.
const { pipeline, env } = window.transformers;

// 2. Configuration: Configure the environment for browser execution.
// We disable local model loading to force fetching from the Hugging Face Hub.
// We also set the logging level to 'error' to keep the console clean during normal operation.
env.allowRemoteModels = true;
env.useBrowserCache = true; // Enable browser caching to speed up subsequent loads
env.loggingLevel = 'error';

/**
 * Main entry point for the application.
 * Initializes the model and triggers the inference logic.
 */
async function main() {
    try {
        console.log("Initializing Sentiment Analysis Pipeline...");

        // 3. Initialize the pipeline.
        // We specify 'sentiment-analysis' as the task.
        // We provide a specific model identifier to ensure we use a lightweight, optimized model.
        // 'Xenova/distilbert-base-uncased-finetuned-sst-2-english' is ~260MB (quantized).
        const classifier = await pipeline('sentiment-analysis', {
            model: 'Xenova/distilbert-base-uncased-finetuned-sst-2-english',
            // Optional: Specify the execution provider. 'wasm' is the most compatible fallback if WebGPU isn't available.
            // However, Transformers.js defaults to the best available backend.
        });

        console.log("Model loaded successfully.");

        // 4. Define input data.
        const texts = [
            "I absolutely love learning about AI in the browser!",
            "The server is down and I cannot access my data.",
            "This is a neutral statement."
        ];

        // 5. Run inference.
        // The pipeline handles tokenization, model execution, and post-processing.
        const results = await classifier(texts);

        // 6. Display results.
        console.log("--- Inference Results ---");
        results.forEach((result, index) => {
            console.log(`Input: "${texts[index]}"`);
            console.log(`Label: ${result.label}, Score: ${result.score.toFixed(4)}`);
            console.log("-------------------------");
        });

    } catch (error) {
        console.error("Error during execution:", error);
        console.warn("Note: Ensure you are running this on a local server (e.g., 'npx serve') with COOP/COEP headers enabled.");
    }
}

// 7. Execute the main function when the DOM is ready.
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', main);
} else {
    main();
}
