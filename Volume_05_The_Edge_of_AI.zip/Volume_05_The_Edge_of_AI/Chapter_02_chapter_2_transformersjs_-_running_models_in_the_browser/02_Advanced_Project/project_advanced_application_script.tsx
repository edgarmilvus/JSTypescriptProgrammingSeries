/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.tsx
// Description: Advanced Application Script
// ==========================================

'use client';

import React, { useState, useEffect, useRef, useCallback } from 'react';
import { pipeline, PipelineType, Pipeline, env } from '@xenova/transformers';

// ============================================================================
// 1. TYPE DEFINITIONS & INTERFACES
// ============================================================================

/**
 * Represents the structured output of our sentiment analysis.
 * While the model returns logits, we map them to this interface for the UI.
 * This mimics the JSON Schema Output pattern used when prompting LLMs.
 */
interface SentimentResult {
  label: 'POSITIVE' | 'NEGATIVE';
  score: number;
}

/**
 * Application State Management.
 * Combines loading status, analysis results, and error handling.
 */
interface AppState {
  status: 'idle' | 'loading_model' | 'analyzing' | 'ready' | 'error';
  result: SentimentResult | null;
  error: string | null;
}

// ============================================================================
// 2. CONFIGURATION & CONSTANTS
// ============================================================================

/**
 * Configuration for the Transformers.js pipeline.
 * We use DistilBERT for its balance of speed and accuracy, ideal for browser environments.
 */
const MODEL_CONFIG = {
  model: 'Xenova/distilbert-base-uncased-finetuned-sst-2-english',
  task: 'text-classification' as PipelineType,
};

/**
 * Optimization: Debounce delay (ms) to prevent model thrashing while typing.
 */
const DEBOUNCE_DELAY = 500;

// ============================================================================
// 3. COMPONENT IMPLEMENTATION
// ============================================================================

/**
 * SentimentAnalyzer Component
 * 
 * A self-contained SaaS widget for analyzing text sentiment in real-time.
 * Handles model loading, inference, and UI state transitions.
 */
export default function SentimentAnalyzer() {
  // State initialization
  const [state, setState] = useState<AppState>({
    status: 'idle',
    result: null,
    error: null,
  });

  // Ref to store the pipeline instance (prevents re-initialization on re-renders)
  const classifierRef = useRef<Pipeline | null>(null);

  // -------------------------------------------------------------------------
  // 3.1 Model Initialization (The "Under the Hood" Logic)
  // -------------------------------------------------------------------------
  
  /**
   * Initializes the Transformers.js pipeline.
   * 
   * Why use a separate function inside useEffect?
   * - It encapsulates the complexity of loading the ONNX model.
   * - It handles the WebAssembly (WASM) or WebGPU backend setup.
   * - It utilizes the browser's Cache API to store model weights locally.
   */
  useEffect(() => {
    let isMounted = true;

    const loadModel = async () => {
      try {
        setState((prev) => ({ ...prev, status: 'loading_model' }));

        // OPTIMIZATION: Enable local caching to speed up subsequent loads.
        // This mimics a "Service Worker" strategy for AI models.
        env.allowLocalModels = true;
        env.useBrowserCache = true;

        // Initialize the pipeline
        const classifier = await pipeline(
          MODEL_CONFIG.task,
          MODEL_CONFIG.model
        );

        if (isMounted) {
          classifierRef.current = classifier;
          setState((prev) => ({ ...prev, status: 'ready' }));
        }
      } catch (err) {
        if (isMounted) {
          console.error("Model Loading Error:", err);
          setState((prev) => ({
            ...prev,
            status: 'error',
            error: 'Failed to load AI model. Check network connection.',
          }));
        }
      }
    };

    loadModel();

    // Cleanup function to free memory when component unmounts
    return () => {
      isMounted = false;
      if (classifierRef.current) {
        classifierRef.current.dispose(); // Releases WASM/WebGPU memory
        classifierRef.current = null;
      }
    };
  }, []);

  // -------------------------------------------------------------------------
  // 3.2 Inference Logic & Debouncing
  // -------------------------------------------------------------------------

  /**
   * Handles text analysis with debouncing.
   * 
   * @param text - The user input string
   */
  const analyzeText = useCallback(
    async (text: string) => {
      if (!classifierRef.current || state.status === 'loading_model') return;

      // Empty input handling
      if (!text.trim()) {
        setState((prev) => ({ ...prev, result: null, status: 'ready' }));
        return;
      }

      setState((prev) => ({ ...prev, status: 'analyzing' }));

      try {
        // Perform Inference
        const startTime = performance.now();
        const response = await classifierRef.current(text, {
          topk: 1, // We only need the best result
        });
        const endTime = performance.now();

        console.log(`Inference time: ${(endTime - startTime).toFixed(2)}ms`);

        // Map raw model output to our strict interface
        const rawResult = response[0]; // Access first element of array
        const structuredResult: SentimentResult = {
          label: rawResult.label, // 'POSITIVE' or 'NEGATIVE'
          score: Number(rawResult.score.toFixed(4)),
        };

        setState((prev) => ({
          ...prev,
          status: 'ready',
          result: structuredResult,
        }));
      } catch (err) {
        console.error("Inference Error:", err);
        setState((prev) => ({ ...prev, status: 'error', error: 'Analysis failed.' }));
      }
    },
    [state.status]
  );

  // Debounce wrapper for input handling
  const handleInputChange = useCallback(
    (e: React.ChangeEvent<HTMLTextAreaElement>) => {
      const text = e.target.value;
      
      // Clear previous timeout (simple debounce implementation)
      if (window.timeoutId) clearTimeout(window.timeoutId);

      window.timeoutId = setTimeout(() => {
        analyzeText(text);
      }, DEBOUNCE_DELAY);
    },
    [analyzeText]
  );

  // -------------------------------------------------------------------------
  // 3.3 UI Rendering
  // -------------------------------------------------------------------------

  return (
    <div className="max-w-2xl mx-auto p-6 bg-white rounded-lg shadow-lg border border-gray-200">
      <header className="mb-6">
        <h2 className="text-2xl font-bold text-gray-800">Sentiment Analysis SaaS</h2>
        <p className="text-sm text-gray-500 mt-1">
          Powered by Transformers.js (Client-Side) • No Server Required
        </p>
      </header>

      {/* Status Indicators */}
      <div className="mb-4 flex items-center gap-2">
        <StatusBadge status={state.status} />
        {state.status === 'loading_model' && (
          <span className="text-xs text-gray-500 italic">Downloading model weights (~260MB)...</span>
        )}
      </div>

      {/* Input Area */}
      <div className="relative">
        <textarea
          className="w-full h-32 p-4 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition resize-y"
          placeholder="Enter text to analyze (e.g., 'I absolutely love this product!')..."
          onChange={handleInputChange}
          disabled={state.status === 'loading_model' || state.status === 'analyzing'}
          aria-label="Text input for sentiment analysis"
        />
        {state.status === 'analyzing' && (
          <div className="absolute bottom-2 right-2 animate-spin rounded-full h-5 w-5 border-b-2 border-blue-600"></div>
        )}
      </div>

      {/* Results Display */}
      <div className="mt-6 min-h-[80px]">
        {state.result && (
          <div className="p-4 bg-gray-50 rounded-md border border-gray-200 animate-fade-in">
            <div className="flex justify-between items-center">
              <span className="text-sm font-semibold text-gray-600">Result:</span>
              <span 
                className={`px-3 py-1 rounded-full text-sm font-bold ${
                  state.result.label === 'POSITIVE' 
                    ? 'bg-green-100 text-green-800' 
                    : 'bg-red-100 text-red-800'
                }`}
              >
                {state.result.label}
              </span>
            </div>
            <div className="mt-2 w-full bg-gray-200 rounded-full h-2.5">
              <div 
                className={`h-2.5 rounded-full ${
                  state.result.label === 'POSITIVE' ? 'bg-green-500' : 'bg-red-500'
                }`}
                style={{ width: `${state.result.score * 100}%` }}
              ></div>
            </div>
            <p className="text-xs text-gray-400 mt-1 text-right">
              Confidence: {(state.result.score * 100).toFixed(1)}%
            </p>
          </div>
        )}

        {state.error && (
          <div className="p-3 bg-red-50 text-red-700 rounded-md border border-red-200">
            Error: {state.error}
          </div>
        )}

        {state.status === 'idle' && !state.result && (
          <div className="p-3 text-gray-400 text-center text-sm italic">
            Waiting for input...
          </div>
        )}
      </div>
    </div>
  );
}

// Helper Component for Status
const StatusBadge = ({ status }: { status: AppState['status'] }) => {
  const styles = {
    idle: 'bg-gray-100 text-gray-600',
    loading_model: 'bg-yellow-100 text-yellow-700',
    analyzing: 'bg-blue-100 text-blue-700',
    ready: 'bg-green-100 text-green-700',
    error: 'bg-red-100 text-red-700',
  };

  return (
    <span className={`px-2 py-1 rounded text-xs font-semibold uppercase tracking-wide ${styles[status]}`}>
      {status.replace('_', ' ')}
    </span>
  );
};

// Global timeout helper for debounce
declare global {
  interface Window {
    timeoutId: NodeJS.Timeout | null;
  }
}
