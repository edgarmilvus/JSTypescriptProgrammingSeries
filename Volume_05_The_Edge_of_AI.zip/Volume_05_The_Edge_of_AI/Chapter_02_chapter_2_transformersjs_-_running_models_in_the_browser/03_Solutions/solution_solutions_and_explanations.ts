/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// File: sentimentAnalyzer.ts
import { pipeline, env, Pipeline } from '@xenova/transformers';

// Configure environment settings for local execution
// env.allowRemoteModels = false; 
// env.localModelPath = '/models/'; 

// Define the type for the sentiment result
type SentimentResult = {
    label: string;
    score: number;
};

// Global variable to store the pipeline instance to avoid reloading
let sentimentPipeline: Pipeline | null = null;

/**
 * Initializes the sentiment analysis pipeline.
 * Uses WebGPU if available, falls back to WASM.
 * Logs model details upon initialization.
 */
export async function initializePipeline(): Promise<Pipeline> {
    if (sentimentPipeline) return sentimentPipeline;

    console.log("Loading model...");
    
    // We prefer WebGPU for performance, but the pipeline function handles fallbacks automatically
    // based on browser support if we don't strictly enforce a specific backend.
    // However, to satisfy the requirement, we can check env.backends or set preferences.
    if (await env.backends?.webgpu) {
        console.log("WebGPU is available. Using WebGPU backend.");
    } else {
        console.log("WebGPU not available. Falling back to WASM.");
    }

    try {
        sentimentPipeline = await pipeline('sentiment-analysis', 'Xenova/distilbert-base-uncased-finetuned-sst-2-english', {
            quantized: true, // Use quantized model for faster loading
        });

        // Log configuration and tokenizer details
        if (sentimentPipeline) {
            console.log("Model Config:", sentimentPipeline.model.config);
            console.log("Tokenizer:", sentimentPipeline.tokenizer);
        }

        return sentimentPipeline;
    } catch (error) {
        console.error("Failed to load pipeline:", error);
        throw error;
    }
}

/**
 * Analyzes the sentiment of the provided text.
 * @param text - The input string to analyze.
 * @returns A Promise resolving to the sentiment result.
 */
export async function analyzeSentiment(text: string): Promise<SentimentResult> {
    if (!text || text.trim() === "") {
        return { label: "NEUTRAL", score: 0.0 };
    }

    // Ensure pipeline is loaded
    const pipe = await initializePipeline();
    
    // Run inference
    // The pipeline returns an array of results, we take the first one
    const result = await pipe(text);
    
    // Cast result to our expected type
    return result[0] as SentimentResult;
}
