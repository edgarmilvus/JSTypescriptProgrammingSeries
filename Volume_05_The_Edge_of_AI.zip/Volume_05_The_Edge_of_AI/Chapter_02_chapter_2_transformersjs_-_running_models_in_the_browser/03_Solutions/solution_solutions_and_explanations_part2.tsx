/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.tsx
// Description: Solutions and Explanations
// ==========================================

// File: TextSummarizer.tsx
import React, { useState, useEffect, useCallback } from 'react';
import { pipeline, Pipeline } from '@xenova/transformers';

interface TextSummarizerProps {
  inputText: string;
  onSummaryComplete: (summary: string) => void;
  maxLength?: number;
}

type ComponentState = 'idle' | 'loading_model' | 'processing' | 'error' | 'ready';

export const TextSummarizer: React.FC<TextSummarizerProps> = ({
  inputText,
  onSummaryComplete,
  maxLength = 50,
}) => {
  const [state, setState] = useState<ComponentState>('idle');
  const [summary, setSummary] = useState<string>('');
  const [summarizer, setSummarizer] = useState<Pipeline | null>(null);
  const [error, setError] = useState<string | null>(null);

  // Initialize pipeline on mount
  useEffect(() => {
    let isMounted = true;

    const loadModel = async () => {
      setState('loading_model');
      try {
        const pipe = await pipeline('summarization', 'Xenova/bart-large-cnn');
        if (isMounted) {
          setSummarizer(() => pipe); // Store pipeline
          setState('ready');
        }
      } catch (err) {
        if (isMounted) {
          setState('error');
          setError(err instanceof Error ? err.message : 'Failed to load model');
        }
      }
    };

    loadModel();

    // Cleanup function
    return () => {
      isMounted = false;
      if (summarizer) {
        // Note: Transformers.js pipelines don't have an explicit 'release' method in all versions,
        // but we can clear references to help garbage collection.
        setSummarizer(null);
      }
    };
  }, []); // Run once on mount

  const handleSummarize = useCallback(async () => {
    if (!summarizer || !inputText) return;

    setState('processing');
    try {
      const result = await summarizer(inputText, { max_length: maxLength });
      const generatedText = result[0]?.summary_text || '';
      setSummary(generatedText);
      onSummaryComplete(generatedText);
      setState('ready');
    } catch (err) {
      setState('error');
      setError(err instanceof Error ? err.message : 'Inference failed');
    }
  }, [summarizer, inputText, maxLength, onSummaryComplete]);

  // Render UI based on state
  return (
    <div className="summarizer-container">
      <h3>Text Summarizer</h3>
      
      {state === 'loading_model' && <p>Initializing Model...</p>}
      {state === 'error' && <p style={{ color: 'red' }}>Error: {error}</p>}
      
      <button 
        onClick={handleSummarize} 
        disabled={state !== 'ready' || !inputText}
      >
        {state === 'processing' ? 'Processing...' : 'Summarize'}
      </button>

      {summary && (
        <div className="summary-result">
          <h4>Result:</h4>
          <p>{summary}</p>
        </div>
      )}
    </div>
  );
};
