/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

// File: benchmark.ts
import { pipeline, env } from '@xenova/transformers';

interface BenchmarkResult {
    backend: 'wasm' | 'webgpu';
    averageInferenceTime: number;
    memoryUsage?: number;
}

const PROMPT = "The quick brown fox jumps over the";
const ITERATIONS = 10;

/**
 * Generates a DOT diagram string for visualization.
 * This represents the logical flow of data.
 */
function generateDotDiagram(backend: 'wasm' | 'webgpu') {
    const processingUnit = backend === 'webgpu' ? "GPU (Compute Shaders)" : "CPU (WASM Binary)";
    const dot = `
    digraph DataFlow {
        rankdir=LR;
        node [shape=box, style=filled, color=lightblue];
        
        Input [label="Input Prompt:\n'${PROMPT}'"];
        Tokenizer [label="Tokenizer\n(String -> IDs)"];
        Backend [label="Backend: ${backend.toUpperCase()}\n(${processingUnit})"];
        Inference [label="Model Inference\n(Matrix Multiplication)"];
        Output [label="Generated Text"];

        Input -> Tokenizer -> Backend -> Inference -> Output;
        
        label = "Execution Flow for ${backend.toUpperCase()} Backend";
        labelloc = "t";
    }
    `;
    console.log(`\n--- DOT Diagram for ${backend} ---`);
    console.log(dot);
    console.log('---------------------------\n');
}

async function runBenchmark(backend: 'wasm' | 'webgpu'): Promise<BenchmarkResult> {
    // 1. Set backend environment
    // Note: In newer versions, env.backends is an object. 
    // We simulate setting the preference here, though the pipeline often auto-selects.
    if (backend === 'webgpu') {
        if (!(await env.backends?.webgpu)) {
            console.warn("WebGPU not supported. Fallback to WASM.");
            // If strict requirement, we might throw, but here we fallback gracefully
            // or return a specific result indicating failure.
            // For this exercise, we will proceed with WASM but log the warning.
        }
    }
    
    // 2. Initialize pipeline
    console.log(`Initializing ${backend} pipeline...`);
    const startInit = performance.now();
    const pipe = await pipeline('text-generation', 'Xenova/sshleifer2bart-small', {
        // We can force backend via quantization or specific backend config if supported
        // For this exercise, we rely on env setting
    });
    const endInit = performance.now();
    console.log(`Initialization took ${(endInit - startInit).toFixed(2)}ms`);

    // 3. Run Inference
    let totalTime = 0;
    
    // Check if performance.memory is available (Chrome specific API)
    const memBefore = (performance as any).memory ? (performance as any).memory.usedJSHeapSize : 0;

    for (let i = 0; i < ITERATIONS; i++) {
        const start = performance.now();
        await pipe(PROMPT, { max_new_tokens: 10 });
        const end = performance.now();
        totalTime += (end - start);
    }

    const memAfter = (performance as any).memory ? (performance as any).memory.usedJSHeapSize : 0;
    const memoryUsageMB = ((memAfter - memBefore) / 1024 / 1024);

    // 4. Visualize
    generateDotDiagram(backend);

    return {
        backend,
        averageInferenceTime: totalTime / ITERATIONS,
        memoryUsage: memoryUsageMB > 0 ? memoryUsageMB : undefined
    };
}

// Execution Logic
(async () => {
    console.log("Starting Benchmarks...");
    
    // Run WASM
    const wasmResult = await runBenchmark('wasm');
    
    // Run WebGPU (if supported, otherwise it will warn)
    const webGpuResult = await runBenchmark('webgpu');

    console.log("\n=== Benchmark Results ===");
    console.log(JSON.stringify([wasmResult, webGpuResult], null, 2));
})();
