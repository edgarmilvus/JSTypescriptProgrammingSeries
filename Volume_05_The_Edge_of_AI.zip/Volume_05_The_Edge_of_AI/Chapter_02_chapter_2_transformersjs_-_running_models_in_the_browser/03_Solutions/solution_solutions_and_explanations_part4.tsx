/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.tsx
// Description: Solutions and Explanations
// ==========================================

// File: TokenizerVisualizer.tsx
import React, { useState, useEffect, useRef } from 'react';
import { AutoTokenizer } from '@xenova/transformers';

export const TokenizerVisualizer = () => {
  const [input, setInput] = useState('');
  const [tokens, setTokens] = useState<string[]>([]);
  const [ids, setIds] = useState<number[]>([]);
  const [tokenizer, setTokenizer] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  
  // Debounce timer reference
  const debounceRef = useRef<NodeJS.Timeout | null>(null);

  // Load tokenizer on mount
  useEffect(() => {
    const load = async () => {
      try {
        const tk = await AutoTokenizer.from_pretrained('Xenova/bert-base-uncased');
        setTokenizer(tk);
        setLoading(false);
      } catch (e) {
        console.error("Failed to load tokenizer", e);
      }
    };
    load();
  }, []);

  // Input handler with debouncing
  useEffect(() => {
    if (!tokenizer) return;

    // Clear previous timer
    if (debounceRef.current) {
      clearTimeout(debounceRef.current);
    }

    // Set new timer (500ms debounce)
    debounceRef.current = setTimeout(async () => {
      if (input.length === 0) {
        setTokens([]);
        setIds([]);
        return;
      }
      
      try {
        // Encode the input
        const encoding = await tokenizer(input);
        // Extract tokens and IDs
        const tokenStrings = encoding.tokens || [];
        const idArray = encoding.input_ids.data || [];
        
        setTokens(tokenStrings);
        setIds(Array.from(idArray));
      } catch (e) {
        console.error("Tokenization error", e);
      }
    }, 500);

    return () => {
      if (debounceRef.current) clearTimeout(debounceRef.current);
    };
  }, [input, tokenizer]);

  // Logic for hover interaction
  const handleHoverToken = (token: string) => {
    // In a real scenario, we might map token indices back to string offsets.
    // Here we will just log metadata for simplicity as requested.
    if (token.startsWith('[') && token.endsWith(']')) {
      console.log(`Metadata: Special Token - ${token}`);
    } else {
      console.log(`Metadata: Standard Token - ${token}`);
    }
  };

  const tokenLimit = 512;
  const isOverLimit = tokens.length > tokenLimit;

  if (loading) return <div>Loading Tokenizer...</div>;

  return (
    <div style={{ padding: '20px', fontFamily: 'sans-serif' }}>
      <h3>Tokenizer Visualizer (BERT)</h3>
      
      <input
        type="text"
        value={input}
        onChange={(e) => setInput(e.target.value)}
        placeholder="Type text to tokenize..."
        style={{ width: '100%', padding: '8px', marginBottom: '10px' }}
      />

      <div style={{ marginBottom: '10px' }}>
        <strong>Token Count: </strong>
        <span style={{ color: isOverLimit ? 'red' : 'black', fontWeight: 'bold' }}>
          {tokens.length}
        </span>
        {isOverLimit && <span style={{ color: 'red', marginLeft: '5px' }}> (Limit Exceeded!)</span>}
      </div>

      <div style={{ display: 'flex', gap: '20px' }}>
        {/* Tokens Section */}
        <div style={{ flex: 1 }}>
          <h4>Tokens</h4>
          <div style={{ 
            border: '1px solid #ccc', 
            padding: '10px', 
            height: '300px', 
            overflowY: 'auto',
            fontSize: '0.9em'
          }}>
            {tokens.map((t, i) => (
              <span 
                key={i} 
                style={{ 
                  display: 'inline-block', 
                  padding: '2px 4px', 
                  margin: '2px', 
                  background: '#f0f0f0', 
                  borderRadius: '3px',
                  cursor: 'help'
                }}
                onMouseEnter={() => handleHoverToken(t)}
                title={t.startsWith('[') ? 'Special Token' : 'Standard Token'}
              >
                {t}
              </span>
            ))}
          </div>
        </div>

        {/* IDs Section */}
        <div style={{ flex: 1 }}>
          <h4>IDs</h4>
          <div style={{ 
            border: '1px solid #ccc', 
            padding: '10px', 
            height: '300px', 
            overflowY: 'auto',
            fontFamily: 'monospace'
          }}>
            {ids.join(', ')}
          </div>
        </div>
      </div>
    </div>
  );
};
