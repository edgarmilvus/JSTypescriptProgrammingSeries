/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

// File: modelCache.ts
import { pipeline, env } from '@xenova/transformers';

// --- Mock IndexedDB Interface (Simplified for Solution) ---
// In a real app, you would implement the full IDB API or use a wrapper like idb.
interface ModelData {
    name: string;
    config: ArrayBuffer;
    weights: ArrayBuffer;
}

const mockDB: Map<string, ModelData> = new Map(); // Simulating IndexedDB

const mockIndexedDB = {
    save: async (name: string, data: ModelData) => {
        mockDB.set(name, data);
        console.log(`[IDB] Saved model: ${name}`);
    },
    get: async (name: string): Promise<ModelData | null> => {
        return mockDB.get(name) || null;
    },
    has: async (name: string): Promise<boolean> => {
        return mockDB.has(name);
    }
};
// ---------------------------------------------------------

async function cacheModel(modelName: string): Promise<void> {
    console.log(`Checking cache for: ${modelName}`);
    
    // 1. Check IndexedDB
    const isCached = await mockIndexedDB.has(modelName);
    if (isCached) {
        console.log("Model found in cache.");
        return;
    }

    console.log("Model not in cache. Downloading...");
    
    // 2. Simulate fetching model data (Weights/Config)
    // In reality, we would fetch the specific .bin and config.json files
    try {
        // Mock fetch delay
        await new Promise(r => setTimeout(r, 1000)); 
        
        // Mock data buffers
        const configData = new ArrayBuffer(100); 
        const weightsData = new ArrayBuffer(1024 * 1024); // 1MB mock weight

        // 3. Save to DB
        await mockIndexedDB.save(modelName, {
            name: modelName,
            config: configData,
            weights: weightsData
        });

    } catch (error) {
        throw new Error("Network error: Failed to download model.");
    }
}

async function loadModelWithCache(modelName: string) {
    // 1. Attempt to load from cache
    const cachedData = await mockIndexedDB.get(modelName);

    if (cachedData) {
        console.log("Loading model from IndexedDB cache...");
        
        // Note: Transformers.js `pipeline` expects a model ID string or URL.
        // To use raw ArrayBuffers, we typically need to create a custom LocalModel object
        // or override the fetch function in `env`.
        
        // For this exercise, we demonstrate the logic of retrieving the cached data.
        // In a real implementation, you would pass this data to a LocalModel loader.
        return { source: 'cache', data: cachedData };
    } else {
        // 2. Fallback to network if cache misses
        console.log("Cache miss. Attempting network load...");
        
        // Check if network is available (simulated check)
        const isOnline = navigator.onLine; 
        if (!isOnline) {
            throw new Error("OFFLINE_ERROR: Model not found in cache and network unavailable.");
        }

        // If online, we would usually download and cache, then load.
        // For this function, we return a flag indicating it needs standard pipeline loading.
        return { source: 'network' };
    }
}

// Wrapper to initialize pipeline using the cache logic
export async function initPipelineWithCache(modelName: string, task: string) {
    try {
        const loadResult = await loadModelWithCache(modelName);

        if (loadResult.source === 'cache') {
            // Here we would initialize pipeline with the cached buffers
            // env.allowRemoteModels = false; // Enforce local usage
            // env.localModelPath = ... (pointing to IDB wrapper)
            console.log("Pipeline initialized with Cached Data.");
            // return pipeline(task, { model: loadResult.data }); // Pseudo-code
        } else {
            // Standard network load
            // We also trigger caching in the background for next time
            cacheModel(modelName).catch(e => console.warn("Background caching failed", e));
            
            console.log("Pipeline initialized from Network.");
            return pipeline(task, modelName);
        }
    } catch (error) {
        if (error instanceof Error && error.message.includes("OFFLINE_ERROR")) {
            console.error("Cannot load model: Offline and not cached.");
            throw error;
        }
        throw error;
    }
}
