/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example_part3.ts
// Description: Basic Code Example
// ==========================================

/**
 * @file app.ts
 * @description A TypeScript example demonstrating WebAssembly integration 
 *              for high-performance computation in a SaaS web application.
 */

// Define the shape of our WASM module imports.
// This interface ensures type safety when interacting with the WASM glue code.
interface WasmModule {
  calculate_heavy_computation: (a: number, b: number) => number;
}

/**
 * Loads the WebAssembly module dynamically.
 * In a production SaaS environment, you might bundle this differently,
 * but dynamic imports are excellent for code splitting.
 */
async function loadWasmModule(): Promise<WasmModule> {
  try {
    // Note: In a real app, the path would point to your built 'pkg' directory.
    // We use a dynamic import here to load the WASM file.
    // The 'init' function is usually exported by wasm-pack to initialize the module.
    const wasm = await import('./pkg/my_wasm_project.js'); // Hypothetical path
    
    // Initialize the WASM module (required by wasm-pack)
    await wasm.default();
    
    return wasm;
  } catch (error) {
    console.error("Failed to load WebAssembly module:", error);
    throw new Error("WASM Initialization Failed");
  }
}

/**
 * Main application logic.
 * Connects UI events to WASM computations.
 */
async function runApp() {
  console.log("Initializing SaaS Client-Side Engine...");
  
  const wasmModule = await loadWasmModule();
  
  // Simulate user input from a SaaS dashboard
  const inputA = 42.5;
  const inputB = 3.14;
  
  console.log(`Computing heavy task for inputs: ${inputA}, ${inputB}`);
  
  // Call the WASM function directly.
  // This executes in the browser's WebAssembly runtime, bypassing JS interpreter overhead.
  const startTime = performance.now();
  const result = wasmModule.calculate_heavy_computation(inputA, inputB);
  const endTime = performance.now();
  
  console.log(`Result: ${result}`);
  console.log(`Execution time: ${(endTime - startTime).toFixed(4)}ms`);
  
  // Update the DOM (Simulation)
  const outputElement = document.getElementById('output');
  if (outputElement) {
    outputElement.textContent = `WASM Result: ${result} (Calculated in ${(endTime - startTime).toFixed(2)}ms)`;
  }
}

// Execute the application when the DOM is ready
if (typeof window !== 'undefined') {
  document.addEventListener('DOMContentLoaded', runApp);
}
