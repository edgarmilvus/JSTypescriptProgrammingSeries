/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.tsx
// Description: Advanced Application Script
// ==========================================

// pages/image-analyzer.tsx (or app/image-analyzer/page.tsx in Next.js App Router)
import React, { useState, useRef, useEffect } from 'react';
import { InferenceSession, Tensor, executionProviders } from 'onnxruntime-web';

/**
 * TYPE DEFINITIONS
 * Strict typing for model inputs/outputs ensures type safety across the WASM boundary.
 */
type ModelInput = {
  data: Float32Array;
  dims: number[]; // [batch, channels, height, width]
};

type InferenceResult = {
  label: string;
  probability: number;
};

/**
 * CONFIGURATION
 * In a production SaaS app, these would be fetched from a config API or environment variables.
 */
const MODEL_URL = 'https://huggingface.co/microsoft/mobilevit-small/resolve/main/mobilevit-small.onnx';
const CLASS_LABELS = ['Cat', 'Dog', 'Car', 'Person', 'Tree']; // Simplified for demo

/**
 * HOOK: useWebGPUInference
 * Manages the lifecycle of the ONNX session and WebGPU context.
 * 
 * @returns {Object} - State and handlers for the UI.
 */
const useWebGPUInference = () => {
  const [isReady, setIsReady] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<InferenceResult | null>(null);
  
  // Reference to hold the ONNX session instance (prevents re-initialization)
  const sessionRef = useRef<InferenceSession | null>(null);

  /**
   * 1. INITIALIZATION
   * Checks for WebGPU support and initializes the ONNX Runtime session.
   * This addresses the "Cold Start" by handling async loading.
   */
  useEffect(() => {
    const initializeSession = async () => {
      if (!navigator.gpu) {
        setError('WebGPU is not supported in this browser. Please use Chrome 113+ or Edge.');
        return;
      }

      try {
        setIsLoading(true);
        
        // Configure execution providers. 'webgpu' triggers hardware acceleration.
        // 'wasm' is used as a fallback for CPU execution if GPU is unavailable.
        const executionProvider: executionProviders = 'webgpu';
        
        sessionRef.current = await InferenceSession.create(MODEL_URL, {
          executionProviders: [executionProvider],
          graphOptimizationLevel: 'all', // Enables WASM optimizations
        });

        setIsReady(true);
      } catch (err) {
        setError(`Failed to load model: ${err instanceof Error ? err.message : 'Unknown error'}`);
      } finally {
        setIsLoading(false);
      }
    };

    initializeSession();

    // Cleanup function to release WebGPU resources
    return () => {
      sessionRef.current?.release();
    };
  }, []);

  /**
   * 2. INFERENCE LOGIC
   * Accepts an HTMLCanvasElement, processes it, and runs inference.
   */
  const runInference = async (canvas: HTMLCanvasElement) => {
    if (!sessionRef.current || !isReady) {
      setError('Model not initialized yet.');
      return;
    }

    setIsLoading(true);
    setError(null);

    try {
      // A. Pre-processing (CPU)
      // In a heavy app, this would be moved to a Web Worker to avoid blocking the UI thread.
      // We extract pixel data and normalize it to Float32 range [-1, 1].
      const ctx = canvas.getContext('2d');
      if (!ctx) throw new Error('Canvas context not found');

      const imageData = ctx.getImageData(0, 0, 224, 224); // Assuming model expects 224x224
      const float32Data = new Float32Array(imageData.data.length);
      
      // Normalize RGB: (PixelValue / 127.5) - 1.0
      for (let i = 0; i < imageData.data.length; i += 4) {
        float32Data[i] = (imageData.data[i] / 127.5) - 1.0;       // R
        float32Data[i + 1] = (imageData.data[i + 1] / 127.5) - 1.0; // G
        float32Data[i + 2] = (imageData.data[i + 2] / 127.5) - 1.0; // B
        // Alpha channel is usually ignored in classification models
      }

      // B. Tensor Creation
      // Format: [Batch, Channels, Height, Width] (NCHW)
      const inputTensor = new Tensor('float32', float32Data, [1, 3, 224, 224]);

      // C. Execution (WebGPU)
      // The session.run() call triggers the WebGPU shader dispatch.
      const feeds: Record<string, Tensor> = {};
      // Note: 'input' is the default input name for MobileNet. 
      // In production, inspect session.inputNames.
      feeds[sessionRef.current.inputNames[0]] = inputTensor;

      const outputMap = await sessionRef.current.run(feeds);
      const outputTensor = outputMap[sessionRef.current.outputNames[0]];

      // D. Post-processing
      // Find the index with the highest probability (Softmax output).
      const data = outputTensor.data as Float32Array;
      let maxIndex = 0;
      let maxProb = -Infinity;

      for (let i = 0; i < data.length; i++) {
        if (data[i] > maxProb) {
          maxProb = data[i];
          maxIndex = i;
        }
      }

      setResult({
        label: CLASS_LABELS[maxIndex % CLASS_LABELS.length] || `Class ${maxIndex}`,
        probability: maxProb
      });

    } catch (err) {
      setError(`Inference failed: ${err instanceof Error ? err.message : 'Unknown error'}`);
    } finally {
      setIsLoading(false);
    }
  };

  return { isReady, isLoading, error, result, runInference };
};

/**
 * COMPONENT: ImageAnalyzer
 * A Next.js Server Component wrapper.
 */
export default function ImageAnalyzer() {
  const { isReady, isLoading, error, result, runInference } = useWebGPUInference();
  const canvasRef = useRef<HTMLCanvasElement>(null);

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !canvasRef.current) return;

    const img = new Image();
    img.onload = () => {
      const canvas = canvasRef.current!;
      const ctx = canvas.getContext('2d')!;
      
      // Resize to 224x224 for the model
      ctx.drawImage(img, 0, 0, 224, 224);
      
      // Trigger inference
      runInference(canvas);
    };
    img.src = URL.createObjectURL(file);
  };

  return (
    <div style={{ padding: '2rem', fontFamily: 'sans-serif', maxWidth: '600px', margin: '0 auto' }}>
      <h1>Real-Time Image Classifier (WebGPU)</h1>
      
      <div style={{ marginBottom: '1rem', padding: '1rem', border: '1px solid #eee', borderRadius: '8px' }}>
        <strong>Status: </strong>
        {isLoading ? 'Processing...' : isReady ? 'Ready (WebGPU Active)' : 'Initializing...'}
        {error && <span style={{ color: 'red' }}> - {error}</span>}
      </div>

      <div style={{ marginBottom: '1rem' }}>
        <input 
          type="file" 
          accept="image/*" 
          onChange={handleImageUpload} 
          disabled={!isReady || isLoading}
        />
      </div>

      {/* Hidden canvas for image processing */}
      <canvas 
        ref={canvasRef} 
        width={224} 
        height={224} 
        style={{ display: 'none' }} 
      />

      {/* Display Area */}
      <div style={{ marginTop: '2rem' }}>
        {result && (
          <div style={{ 
            padding: '1.5rem', 
            backgroundColor: '#f0fdf4', 
            border: '1px solid #bbf7d0',
            borderRadius: '8px',
            textAlign: 'center'
          }}>
            <h2 style={{ margin: 0, color: '#166534' }}>Prediction</h2>
            <p style={{ fontSize: '1.5rem', fontWeight: 'bold', margin: '0.5rem 0' }}>
              {result.label}
            </p>
            <p style={{ color: '#15803d' }}>
              Confidence: {(result.probability * 100).toFixed(2)}%
            </p>
          </div>
        )}
      </div>

      {/* Visualization of the Architecture */}
      <div style={{ marginTop: '2rem', fontSize: '0.85rem', color: '#555' }}>
        <h3>Architecture Flow</h3>
        <p>This component uses ONNX Runtime Web with the WebGPU execution provider. The image is normalized on the CPU, uploaded to a GPU buffer, and computed via WebGPU shaders.</p>
      </div>
    </div>
  );
}
