/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// This solution assumes a modern browser with WebGPU support.
// It is written as a self-contained script to be included in an HTML file.

// 1. Matrix Data Preparation
const MATRIX_SIZE = 4;
const matrixAData = new Float32Array(MATRIX_SIZE * MATRIX_SIZE);
const matrixBData = new Float32Array(MATRIX_SIZE * MATRIX_SIZE);

// Initialize with sequential numbers for verification
for (let i = 0; i < matrixAData.length; i++) {
    matrixAData[i] = i + 1;
    matrixBData[i] = i + 1;
}

// 2. WGSL Shader Code
const shaderCode = `
struct Matrix {
    size: vec2<u32>,
    numbers: array<f32>,
};

@group(0) @binding(0) var<storage, read> matrixA: Matrix;
@group(0) @binding(1) var<storage, read> matrixB: Matrix;
@group(0) @binding(2) var<storage, read_write> resultMatrix: Matrix;

@compute @workgroup_size(4, 4)
fn main(@builtin(global_invocation_id) global_id: vec3<u32>) {
    // Ensure we don't go out of bounds
    if (global_id.x >= resultMatrix.size.x || global_id.y >= resultMatrix.size.y) {
        return;
    }

    var sum = 0.0;
    for (var i = 0u; i < matrixA.size.x; i = i + 1u) {
        let a = matrixA.numbers[global_id.y * matrixA.size.x + i];
        let b = matrixB.numbers[i * matrixB.size.x + global_id.x];
        sum = sum + a * b;
    }

    let index = global_id.y * resultMatrix.size.x + global_id.x;
    resultMatrix.numbers[index] = sum;
}
`;

// 3. Main Initialization Function
async function initWebGPU() {
    if (!navigator.gpu) {
        throw new Error("WebGPU not supported on this browser.");
    }

    // Request adapter and device
    const adapter = await navigator.gpu.requestAdapter();
    if (!adapter) {
        throw new Error("No appropriate GPUAdapter found.");
    }
    const device = await adapter.requestDevice();

    // Configure canvas context (required for WebGPU context, even if we don't draw to screen)
    const canvas = document.getElementById('canvas') as HTMLCanvasElement;
    const context = canvas.getContext('webgpu');
    const canvasFormat = navigator.gpu.getPreferredCanvasFormat();
    context.configure({
        device: device,
        format: canvasFormat,
    });

    return { device, canvas, context };
}

// 4. Buffer Creation Helper
function createBuffer(device: GPUDevice, data: Float32Array, usage: GPUBufferUsageFlags) {
    const buffer = device.createBuffer({
        size: data.byteLength,
        usage: usage,
        mappedAtCreation: true,
    });
    new Float32Array(buffer.getMappedRange()).set(data);
    buffer.unmap();
    return buffer;
}

// 5. Execution Logic
async function runMatrixMultiplication() {
    try {
        const { device } = await initWebGPU();
        console.log("WebGPU Initialized.");

        // Define Matrix Structure Size (vec2<u32> + array<f32>)
        // We need 2 floats for size (width, height) + 16 floats for data = 18 floats
        const matrixStructSize = 2 + (MATRIX_SIZE * MATRIX_SIZE); 
        
        // Create Input Buffers (Read Only)
        // We need to pack the size into the buffer as well
        const matrixAPacked = new Float32Array(matrixStructSize);
        matrixAPacked[0] = MATRIX_SIZE; // width
        matrixAPacked[1] = MATRIX_SIZE; // height
        matrixAPacked.set(matrixAData, 2);

        const matrixBPacked = new Float32Array(matrixStructSize);
        matrixBPacked[0] = MATRIX_SIZE;
        matrixBPacked[1] = MATRIX_SIZE;
        matrixBPacked.set(matrixBData, 2);

        const bufferA = createBuffer(device, matrixAPacked, GPUBufferUsage.STORAGE | GPUBufferUsage.COPY_DST);
        const bufferB = createBuffer(device, matrixBPacked, GPUBufferUsage.STORAGE | GPUBufferUsage.COPY_DST);

        // Create Output Buffer (Read Write)
        const resultBuffer = device.createBuffer({
            size: matrixStructSize * 4, // 4 bytes per float
            usage: GPUBufferUsage.STORAGE | GPUBufferUsage.COPY_SRC
        });

        // Create Bind Group Layout
        const bindGroupLayout = device.createBindGroupLayout({
            entries: [
                { binding: 0, visibility: GPUShaderStage.COMPUTE, buffer: { type: 'read-only-storage' } },
                { binding: 1, visibility: GPUShaderStage.COMPUTE, buffer: { type: 'read-only-storage' } },
                { binding: 2, visibility: GPUShaderStage.COMPUTE, buffer: { type: 'storage' } },
            ],
        });

        // Create Bind Group
        const bindGroup = device.createBindGroup({
            layout: bindGroupLayout,
            entries: [
                { binding: 0, resource: { buffer: bufferA } },
                { binding: 1, resource: { buffer: bufferB } },
                { binding: 2, resource: { buffer: resultBuffer } },
            ],
        });

        // Create Compute Pipeline
        const pipeline = device.createComputePipeline({
            layout: device.createPipelineLayout({ bindGroupLayouts: [bindGroupLayout] }),
            compute: {
                module: device.createShaderModule({ code: shaderCode }),
                entryPoint: 'main',
            },
        });

        // Command Encoding and Dispatch
        const commandEncoder = device.createCommandEncoder();
        const passEncoder = commandEncoder.beginComputePass();
        passEncoder.setPipeline(pipeline);
        passEncoder.setBindGroup(0, bindGroup);
        passEncoder.dispatchWorkgroups(1, 1, 1); // Dispatch 1 workgroup (4x4 threads)
        passEncoder.end();

        // 6. Readback
        // Create a staging buffer to copy the result to for reading
        const stagingBuffer = device.createBuffer({
            size: matrixStructSize * 4,
            usage: GPUBufferUsage.COPY_DST | GPUBufferUsage.MAP_READ,
        });

        // Copy from storage buffer to staging buffer
        commandEncoder.copyBufferToBuffer(
            resultBuffer, 0,
            stagingBuffer, 0,
            matrixStructSize * 4
        );

        // Submit commands
        const commands = commandEncoder.finish();
        device.queue.submit([commands]);

        // Map and read
        await stagingBuffer.mapAsync(GPUMapMode.READ);
        const resultArray = new Float32Array(stagingBuffer.getMappedRange());
        
        // Extract the matrix data (skipping the size header)
        const resultMatrix = resultArray.slice(2);
        console.log("Result Matrix:", resultMatrix);
        
        // Verify result (Expected for sequential 1..16 multiplication)
        // [1, 2, 3...] * [1, 2, 3...] = specific dot products.
        // Example: (0,0) = 1*1 + 2*5 + 3*9 + 4*13 = 1 + 10 + 27 + 52 = 90
        console.log("Expected value at (0,0): 90. Actual:", resultMatrix[0]);

        stagingBuffer.unmap();

    } catch (error) {
        console.error("Error running WebGPU:", error);
    }
}

// Run the function
runMatrixMultiplication();
