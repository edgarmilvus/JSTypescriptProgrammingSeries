/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState, useEffect, useRef } from 'react';
import * as ort from 'onnxruntime-web';

// Define types for the component state
interface Prediction {
    label: string;
    probability: number;
}

const ImageClassifier: React.FC = () => {
    const [modelLoaded, setModelLoaded] = useState<boolean>(false);
    const [isLoading, setIsLoading] = useState<boolean>(false);
    const [predictions, setPredictions] = useState<Prediction[]>([]);
    const [inferenceTime, setInferenceTime] = useState<number>(0);
    const [backend, setBackend] = useState<'webgpu' | 'wasm'>('webgpu');
    const [error, setError] = useState<string | null>(null);

    const sessionRef = useRef<ort.InferenceSession | null>(null);
    const canvasRef = useRef<HTMLCanvasElement>(null);

    // 1. Model Initialization
    useEffect(() => {
        const loadModel = async () => {
            setIsLoading(true);
            setError(null);
            try {
                // Determine execution provider based on state
                const executionProviders: ('webgpu' | 'wasm')[] = [backend];
                
                console.log(`Loading model with backend: ${backend}`);
                
                // Load the model (assuming 'model.onnx' is in public folder)
                // Note: In a real app, you might need to configure wasm/wgsl paths via ort.env.wasm
                sessionRef.current = await ort.InferenceSession.create(
                    './model.onnx', 
                    { 
                        executionProviders: executionProviders,
                        // Enable graph optimization for better performance
                        graphOptimizationLevel: 'all' 
                    }
                );
                
                setModelLoaded(true);
                console.log("Model loaded successfully.");
            } catch (err) {
                console.error("Failed to load model:", err);
                setError(`Failed to load model with ${backend}. Falling back...`);
                
                // Fallback logic
                if (backend === 'webgpu') {
                    setBackend('wasm'); // Trigger re-render to load WASM
                } else {
                    setError("Critical: Could not load model on any backend.");
                }
            } finally {
                setIsLoading(false);
            }
        };

        // Only load if session doesn't exist or backend changed
        if (!sessionRef.current || (backend === 'wasm' && sessionRef.current?.executionProvider !== 'wasm')) {
            loadModel();
        }

        // Cleanup on unmount
        return () => {
            if (sessionRef.current) {
                sessionRef.current.release();
            }
        };
    }, [backend]); // Re-run effect when backend changes

    // 2. Image Preprocessing and Inference
    const handleImageUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
        const file = event.target.files?.[0];
        if (!file || !sessionRef.current || !canvasRef.current) return;

        setIsLoading(true);
        setPredictions([]);
        setError(null);

        try {
            // Load image
            const img = new Image();
            img.src = URL.createObjectURL(file);
            await new Promise(resolve => img.onload = resolve);

            // Preprocess: Resize to 224x224 (MobileNetV2 standard)
            const canvas = canvasRef.current;
            const ctx = canvas.getContext('2d')!;
            canvas.width = 224;
            canvas.height = 224;
            ctx.drawImage(img, 0, 0, 224, 224);

            // Get pixel data and normalize
            const imageData = ctx.getImageData(0, 0, 224, 224);
            const float32Data = new Float32Array(3 * 224 * 224); // CHW format (Channels x Height x Width)

            // Normalize to [0, 1] and reorder from RGBA (NHWC) to CHW
            for (let i = 0; i < 224 * 224; i++) {
                const r = imageData.data[i * 4] / 255;
                const g = imageData.data[i * 4 + 1] / 255;
                const b = imageData.data[i * 4 + 2] / 255;
                
                // MobileNet expects input in CHW format
                float32Data[i] = r;                   // R channel
                float32Data[i + 224 * 224] = g;       // G channel
                float32Data[i + 2 * 224 * 224] = b;   // B channel
            }

            // Create Tensor
            const inputTensor = new ort.Tensor('float32', float32Data, [1, 3, 224, 224]);
            
            // Run Inference
            const startTime = performance.now();
            const feeds: Record<string, ort.Tensor> = {};
            // Note: 'input' is the typical input name for MobileNet, but this varies by model
            feeds[sessionRef.current.inputNames[0]] = inputTensor;
            
            const results = await sessionRef.current.run(feeds);
            const endTime = performance.now();
            
            setInferenceTime(endTime - startTime);

            // Process Output
            const outputTensor = results[sessionRef.current.outputNames[0]];
            const outputData = outputTensor.data as Float32Array;
            
            // Softmax & Top 3
            const softmax = Array.from(outputData).map(x => Math.exp(x));
            const sumExp = softmax.reduce((a, b) => a + b, 0);
            const probabilities = softmax.map(x => x / sumExp);

            // Map indices to labels (Mock labels for demo purposes)
            const top3 = probabilities
                .map((prob, index) => ({ label: `Class ${index}`, probability: prob }))
                .sort((a, b) => b.probability - a.probability)
                .slice(0, 3);

            setPredictions(top3);

        } catch (err) {
            console.error("Inference error:", err);
            setError("Error during inference. Check console.");
        } finally {
            setIsLoading(false);
        }
    };

    const toggleBackend = () => {
        setBackend(prev => prev === 'webgpu' ? 'wasm' : 'webgpu');
        // Reset session to force reload
        sessionRef.current = null;
    };

    return (
        <div style={{ padding: '20px', fontFamily: 'sans-serif' }}>
            <h2>Image Classifier (Backend: {backend.toUpperCase()})</h2>
            
            <div style={{ marginBottom: '10px' }}>
                <button onClick={toggleBackend} disabled={isLoading}>
                    Switch to {backend === 'webgpu' ? 'WASM' : 'WebGPU'}
                </button>
            </div>

            <input type="file" accept="image/*" onChange={handleImageUpload} disabled={!modelLoaded || isLoading} />
            
            <div style={{ marginTop: '20px' }}>
                <canvas ref={canvasRef} style={{ border: '1px solid #ccc', maxWidth: '224px' }} />
            </div>

            {isLoading && <p>Loading model or processing...</p>}
            {error && <p style={{ color: 'red' }}>{error}</p>}
            
            {inferenceTime > 0 && (
                <p><strong>Inference Time:</strong> {inferenceTime.toFixed(2)} ms</p>
            )}

            {predictions.length > 0 && (
                <div>
                    <h3>Top Predictions:</h3>
                    <ul>
                        {predictions.map((p, i) => (
                            <li key={i}>
                                {p.label}: {(p.probability * 100).toFixed(2)}%
                            </li>
                        ))}
                    </ul>
                </div>
            )}
        </div>
    );
};

export default ImageClassifier;
