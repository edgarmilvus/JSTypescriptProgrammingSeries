/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

import { WebGPUContext } from './webgpu-context'; // Assuming a helper class for WebGPU setup

const FRAME_COUNT = 100;
const DATA_SIZE = 1024 * 1024; // 1MB of data per frame
const WORKGROUP_SIZE = 64;

// Simple compute shader to simulate work (e.g., add 1 to every number)
const shaderCode = `
@group(0) @binding(0) var<storage, read_write> data: array<f32>;
@compute @workgroup_size(64)
fn main(@builtin(global_invocation_id) global_id: vec3<u32>) {
    if (global_id.x < arrayLength(&data)) {
        data[global_id.x] = data[global_id.x] + 1.0;
    }
}
`;

async function benchmarkMemoryStrategies() {
    const context = await WebGPUContext.init();
    const { device } = context;

    // Helper to create buffer
    const createBuffer = (size: number) => device.createBuffer({
        size,
        usage: GPUBufferUsage.STORAGE | GPUBufferUsage.COPY_SRC | GPUBufferUsage.COPY_DST,
    });

    // ---------------------------------------------------------
    // 1. NAIVE APPROACH (Create/Map/Read per frame)
    // ---------------------------------------------------------
    console.log("Starting Naive Benchmark...");
    const startNaive = performance.now();

    for (let i = 0; i < FRAME_COUNT; i++) {
        // A. Create new buffer for input data (Simulating upload)
        const inputBuffer = createBuffer(DATA_SIZE);
        
        // B. Create output buffer
        const outputBuffer = createBuffer(DATA_SIZE);

        // C. Run Compute (Simplified pipeline setup for brevity)
        // ... (Bind groups, dispatch commands) ...
        
        // D. Synchronous Readback (The Bottleneck)
        // We must map, wait, read, then unmap.
        // In a real scenario, we would copy to a staging buffer first.
        const stagingBuffer = device.createBuffer({
            size: DATA_SIZE,
            usage: GPUBufferUsage.COPY_DST | GPUBufferUsage.MAP_READ
        });

        const commandEncoder = device.createCommandEncoder();
        commandEncoder.copyBufferToBuffer(outputBuffer, 0, stagingBuffer, 0, DATA_SIZE);
        device.queue.submit([commandEncoder.finish()]);

        // E. CPU STALL: Wait for GPU to finish
        await stagingBuffer.mapAsync(GPUMapMode.READ);
        const data = new Float32Array(stagingBuffer.getMappedRange());
        // Do something with data to prevent optimization removal
        if (data[0] === -999) console.log("Never happens");
        
        stagingBuffer.unmap();
        
        // Cleanup
        inputBuffer.destroy();
        outputBuffer.destroy();
        stagingBuffer.destroy();
    }
    
    const endNaive = performance.now();
    console.log(`Naive Time: ${(endNaive - startNaive).toFixed(2)}ms`);

    // ---------------------------------------------------------
    // 2. OPTIMIZED APPROACH (Ping-Pong + Async)
    // ---------------------------------------------------------
    console.log("Starting Optimized Benchmark...");
    const startOpt = performance.now();

    // A. Setup Ping-Pong Buffers (Reuse across frames)
    const buffersA = {
        input: createBuffer(DATA_SIZE),
        output: createBuffer(DATA_SIZE),
    };
    const buffersB = {
        input: createBuffer(DATA_SIZE),
        output: createBuffer(DATA_SIZE),
    };
    
    // Staging buffer for async readback (only need one if we read sequentially)
    const stagingBuffer = device.createBuffer({
        size: DATA_SIZE,
        usage: GPUBufferUsage.COPY_DST | GPUBufferUsage.MAP_READ
    });

    let currentFrame = 0;
    let pendingReadPromise: Promise<void> | null = null;

    // B. Loop through frames
    for (let i = 0; i < FRAME_COUNT; i++) {
        // Toggle buffers
        const isFrameA = (i % 2 === 0);
        const inputBuffer = isFrameA ? buffersA.input : buffersB.input;
        const outputBuffer = isFrameA ? buffersA.output : buffersB.output;

        // 1. Upload data to next input buffer (CPU work)
        // In real app, this would be queue.writeBuffer
        // device.queue.writeBuffer(inputBuffer, 0, ...);

        // 2. Wait for previous readback to complete if necessary
        if (pendingReadPromise) {
            await pendingReadPromise;
            pendingReadPromise = null;
        }

        // 3. Dispatch Compute
        const commandEncoder = device.createCommandEncoder();
        // ... (Setup bind groups with inputBuffer/outputBuffer) ...
        
        // Copy current output to staging buffer for reading in the NEXT frame
        // or at the end of the loop.
        commandEncoder.copyBufferToBuffer(outputBuffer, 0, stagingBuffer, 0, DATA_SIZE);
        device.queue.submit([commandEncoder.finish()]);

        // 4. Schedule Asynchronous Readback
        // We don't await here immediately. We queue the await for the *next* iteration
        // or the end of the loop.
        pendingReadPromise = stagingBuffer.mapAsync(GPUMapMode.READ).then(() => {
            const data = new Float32Array(stagingBuffer.getMappedRange());
            // Process data...
            stagingBuffer.unmap();
        });
    }

    // Wait for the final frame's readback
    if (pendingReadPromise) await pendingReadPromise;

    const endOpt = performance.now();
    console.log(`Optimized Time: ${(endOpt - startOpt).toFixed(2)}ms`);

    // Cleanup
    buffersA.input.destroy(); buffersA.output.destroy();
    buffersB.input.destroy(); buffersB.output.destroy();
    stagingBuffer.destroy();
}

benchmarkMemoryStrategies();
