/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

// 1. Tiled WGSL Shader Code
const tiledShaderCode = `
struct Matrix {
    size: vec2<u32>,
    numbers: array<f32>,
};

// Binding same as Exercise 1
@group(0) @binding(0) var<storage, read> matrixA: Matrix;
@group(0) @binding(1) var<storage, read> matrixB: Matrix;
@group(0) @binding(2) var<storage, read_write> resultMatrix: Matrix;

// TILE_SIZE must match workgroup_size
const TILE_SIZE: u32 = 16;

// Declare Shared Memory (On-chip cache)
var<workgroup> tileA: array<f32, TILE_SIZE * TILE_SIZE>;
var<workgroup> tileB: array<f32, TILE_SIZE * TILE_SIZE>;

@compute @workgroup_size(TILE_SIZE, TILE_SIZE)
fn main(@builtin(global_invocation_id) global_id: vec3<u32>, 
        @builtin(local_invocation_id) local_id: vec3<u32>) {
    
    // Ensure we don't compute out of bounds
    if (global_id.x >= resultMatrix.size.x || global_id.y >= resultMatrix.size.y) {
        return;
    }

    let row = global_id.y;
    let col = global_id.x;
    var sum = 0.0;

    // Calculate number of tiles needed to traverse the matrices
    let numTiles = (matrixA.size.x + TILE_SIZE - 1) / TILE_SIZE;

    for (var t: u32 = 0u; t < numTiles; t = t + 1u) {
        // 1. LOAD DATA INTO SHARED MEMORY
        // Each thread in the workgroup loads one element
        let sharedX = local_id.x;
        let sharedY = local_id.y;
        
        let globalRowA = row; // Row of A doesn't change for the tile
        let globalColA = t * TILE_SIZE + sharedX;
        
        let globalRowB = t * TILE_SIZE + sharedY;
        let globalColB = col; // Col of B doesn't change for the tile

        // Check bounds for loading
        if (globalColA < matrixA.size.x && globalRowA < matrixA.size.y) {
            tileA[sharedY * TILE_SIZE + sharedX] = 
                matrixA.numbers[globalRowA * matrixA.size.x + globalColA];
        } else {
            tileA[sharedY * TILE_SIZE + sharedX] = 0.0;
        }

        if (globalRowB < matrixB.size.y && globalColB < matrixB.size.x) {
            tileB[sharedY * TILE_SIZE + sharedX] = 
                matrixB.numbers[globalRowB * matrixB.size.x + globalColB];
        } else {
            tileB[sharedY * TILE_SIZE + sharedX] = 0.0;
        }

        // 2. SYNCHRONIZATION BARRIER
        // Wait until ALL threads in the workgroup have loaded their data
        workgroupBarrier();

        // 3. COMPUTE PARTIAL DOT PRODUCT
        // Compute using data from fast shared memory
        for (var k: u32 = 0u; k < TILE_SIZE; k = k + 1u) {
            sum = sum + tileA[sharedY * TILE_SIZE + k] * tileB[k * TILE_SIZE + sharedX];
        }

        // 4. ANOTHER BARRIER
        // Ensure no thread starts the next iteration (loading new data) 
        // before others finish reading the current tile.
        workgroupBarrier();
    }

    // Write final result to global memory
    let index = row * resultMatrix.size.x + col;
    resultMatrix.numbers[index] = sum;
}
`;

// 2. Explanation of Efficiency
const explanation = `
**Why the Tiled Algorithm is More Efficient:**

The primary bottleneck in GPU computing is memory latency—specifically, the time it takes to fetch data from global VRAM (Device Memory). Global memory is large but located off-chip, resulting in high latency (hundreds of clock cycles).

In the naive matrix multiplication shader (Exercise 1), every thread reads directly from global memory for every multiplication step. For a large matrix, this means the same row of Matrix A and column of Matrix B are fetched from VRAM repeatedly by different threads, wasting bandwidth and stalling the pipeline.

The tiled algorithm utilizes **Shared Memory** (Workgroup Memory), which is a small, user-managed cache located directly on the GPU die. It has extremely low latency (similar to L1 cache).

**The Optimization:**
1.  **Reuse:** By loading a tile (e.g., 16x16) of Matrix A and Matrix B into shared memory, all threads in the workgroup can access that data multiple times (for the dot product loop) at high speed without touching slow VRAM.
2.  **Bandwidth:** We reduce the global memory traffic from O(N^3) in naive implementations to something much more efficient (roughly O(N^3 / TILE_SIZE)).
3.  **Latency Hiding:** While the compute units are crunching numbers from the fast shared memory, the memory controller can be prefetching the *next* tile from global memory in the background.

This technique is the standard for high-performance matrix multiplication (SGEMM) on GPUs and is used in libraries like cuBLAS and TensorFlow.
`;
