/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * ==============================================================================
 * 1. UI THREAD (main.ts)
 * ==============================================================================
 * This file simulates the main browser thread logic. It registers the Service Worker
 * and handles user interaction.
 */

// Define the structure of messages sent between UI and Worker
interface WorkerMessage {
    type: 'ANALYZE_TEXT';
    payload: string;
}

interface WorkerResponse {
    type: 'RESULT';
    payload: {
        text: string;
        sentiment: 'POSITIVE' | 'NEGATIVE' | 'NEUTRAL';
        confidence: number;
    };
}

/**
 * Registers the Service Worker and sets up the message listener.
 * In a real app, this would be in your main application entry point.
 */
async function setupAIWorker() {
    // Check for Service Worker support
    if ('serviceWorker' in navigator) {
        try {
            // Register the worker script (assuming it's served from the same origin)
            const registration = await navigator.serviceWorker.register('/ai-worker.js');
            console.log('Service Worker registered:', registration);

            // Listen for messages from the Service Worker
            navigator.serviceWorker.addEventListener('message', (event) => {
                // Ensure we only process messages from our trusted worker
                if (event.source instanceof ServiceWorker) {
                    const response: WorkerResponse = event.data;
                    
                    if (response.type === 'RESULT') {
                        handleAIResult(response.payload);
                    }
                }
            });

            // Simulate user input
            const userText = "I absolutely love how fast and responsive this app feels!";
            console.log(`[UI] Sending text for analysis: "${userText}"`);

            // Send message to the Service Worker
            const message: WorkerMessage = {
                type: 'ANALYZE_TEXT',
                payload: userText
            };

            // We use `navigator.serviceWorker.controller` to send a message to the active worker.
            // If the controller is null (e.g., first load), we might need to wait.
            if (navigator.serviceWorker.controller) {
                navigator.serviceWorker.controller.postMessage(message);
            } else {
                console.warn('Service Worker controller is not active yet. Retrying...');
                // In a real app, you might queue the message or wait for the 'controllerchange' event
                setTimeout(() => navigator.serviceWorker.controller?.postMessage(message), 1000);
            }

        } catch (error) {
            console.error('Service Worker registration failed:', error);
        }
    }
}

/**
 * Handles the result returned from the AI inference.
 * This simulates Optimistic UI Reconciliation.
 * @param result - The payload from the worker
 */
function handleAIResult(result: WorkerResponse['payload']) {
    const uiElement = document.getElementById('sentiment-result') as HTMLDivElement;
    
    // Update UI with the confirmed state
    if (uiElement) {
        uiElement.innerText = `Sentiment: ${result.sentiment} (Confidence: ${(result.confidence * 100).toFixed(2)}%)`;
        uiElement.style.color = result.sentiment === 'POSITIVE' ? 'green' : 'red';
    }
    
    console.log(`[UI] Received AI Result:`, result);
}

// Initialize
setupAIWorker();
