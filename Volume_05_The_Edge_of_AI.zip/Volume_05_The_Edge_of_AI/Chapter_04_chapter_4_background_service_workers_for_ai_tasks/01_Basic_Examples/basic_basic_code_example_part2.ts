/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.ts
// Description: Basic Code Example
// ==========================================

/**
 * ==============================================================================
 * 2. BACKGROUND THREAD (ai-worker.ts)
 * ==============================================================================
 * This file simulates the Service Worker logic. In a real scenario, this would
 * be a separate file served as 'ai-worker.js'.
 */

/**
 * Mocked Transformers.js Interface
 * In a real implementation, you would import { pipeline } from '@xenova/transformers'.
 * We mock this to keep the example runnable without external dependencies.
 */
const MockTransformers = {
    pipeline: async (task: string, model: string) => {
        console.log(`[Worker] Loading model: ${model} for task: ${task}`);
        
        // Simulate async model loading delay
        await new Promise(r => setTimeout(r, 500)); 

        return {
            // Simulate the inference function
            analyze: async (text: string) => {
                // Simple logic to mock sentiment analysis
                const lowerText = text.toLowerCase();
                let sentiment = 'NEUTRAL';
                let score = 0.5;

                if (lowerText.includes('love') || lowerText.includes('great')) {
                    sentiment = 'POSITIVE';
                    score = 0.95;
                } else if (lowerText.includes('hate') || lowerText.includes('bad')) {
                    sentiment = 'NEGATIVE';
                    score = 0.90;
                }

                // Simulate processing time
                await new Promise(r => setTimeout(r, 200));

                return { label: sentiment, score: score };
            }
        };
    }
};

// Global variable to hold the loaded model
let sentimentModel: any = null;

/**
 * Initializes the AI model within the Service Worker.
 * This follows the "Model Lifecycle Management" strategy.
 */
async function initializeModel() {
    if (!sentimentModel) {
        // Load the model once and cache it in the worker's scope
        sentimentModel = await MockTransformers.pipeline('sentiment-analysis', 'distilbert-base-uncased-finetuned-sst-2-english');
        console.log('[Worker] Model loaded and cached.');
    }
}

/**
 * Main Event Listener for the Service Worker.
 * Handles 'install', 'activate', and 'message' events.
 */
self.addEventListener('install', (event: ExtendableEvent) => {
    // Force the worker to activate immediately and skip waiting
    self.skipWaiting();
});

self.addEventListener('activate', (event: ExtendableEvent) => {
    // Claim clients so the worker can control open pages immediately
    event.waitUntil(self.clients.claim());
});

self.addEventListener('message', (event: MessageEvent) => {
    // Check if the message is from the UI
    if (event.source && event.data) {
        const message: WorkerMessage = event.data;

        if (message.type === 'ANALYZE_TEXT') {
            // Process the request asynchronously
            processAIRequest(message.payload, event.source);
        }
    }
});

/**
 * Core Logic: Handles the AI inference and sends the result back.
 * @param text - The text to analyze
 * @param source - The client (UI) that sent the message
 */
async function processAIRequest(text: string, source: Client | ServiceWorker) {
    try {
        // 1. Ensure model is loaded
        await initializeModel();

        // 2. Run Inference (Off the main thread)
        const result = await sentimentModel.analyze(text);

        // 3. Prepare the response
        const response: WorkerResponse = {
            type: 'RESULT',
            payload: {
                text: text,
                sentiment: result.label,
                confidence: result.score
            }
        };

        // 4. Send result back to the specific client
        // Note: In a Service Worker, we use `source.postMessage` or `self.clients.matchAll()`
        if (source instanceof MessagePort || source instanceof ServiceWorker) {
            // Standard postMessage
            source.postMessage(response);
        } else {
            // If source is a Client object (from event.source)
            (source as Client).postMessage(response);
        }

    } catch (error) {
        console.error('[Worker] AI Processing Error:', error);
    }
}
