/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.tsx
// Description: Advanced Application Script
// ==========================================

// File: lib/ai-worker-service.ts
/**
 * @fileoverview AI Worker Service Manager.
 * Handles the registration and communication with a background Service Worker
 * dedicated to running Transformers.js inference.
 */

// -----------------------------------------------------------------------------
// 1. Worker Definition (Inlined for Single-File Example)
// -----------------------------------------------------------------------------
// In a real production app, this would be a separate file (e.g., 'ai.worker.ts')
// loaded via Webpack or Vite worker loaders.
const workerScript = `
    importScripts('https://cdn.jsdelivr.net/npm/@xenova/transformers@2.13.4/dist/transformers.min.js');

    // Global state to hold the model instance (lazy loaded)
    let pipeline = null;
    let tokenizer = null;
    let model = null;

    // WebGPU Support Check
    const hasWebGPU = typeof navigator !== 'undefined' && 'gpu' in navigator;

    self.onmessage = async (event) => {
        const { id, type, payload } = event.data;

        try {
            if (type === 'INITIALIZE') {
                // Initialize the pipeline with WebGPU acceleration if available
                // Using 'Xenova/quantized-gpt2' for lightweight demonstration
                const { pipeline: pipe, AutoTokenizer } = transformers;
                
                console.log(\`Worker: Initializing pipeline. WebGPU: \${hasWebGPU}\`);
                
                tokenizer = await AutoTokenizer.from_pretrained('Xenova/quantized-gpt2');
                pipeline = await pipe('text-generation', 'Xenova/quantized-gpt2', {
                    quantized: true,
                    use_webgpu: hasWebGPU, // Attempt WebGPU acceleration
                    progress_callback: (data) => {
                        // Forward progress to main thread
                        self.postMessage({ id, type: 'PROGRESS', payload: data });
                    }
                });

                self.postMessage({ id, type: 'READY', payload: { hasWebGPU } });
            
            } else if (type === 'INFERENCE') {
                if (!pipeline) throw new Error('Pipeline not initialized');

                const { prompt, max_length = 50 } = payload;
                
                // Run inference
                const output = await pipeline(prompt, {
                    max_new_tokens: max_length,
                    do_sample: false, // Deterministic for summarization
                });

                // Return only the generated text
                const result = output[0]?.generated_text || '';
                
                self.postMessage({ id, type: 'COMPLETE', payload: result });
            }
        } catch (error) {
            self.postMessage({ id, type: 'ERROR', payload: error.message });
        }
    };
`;

// -----------------------------------------------------------------------------
// 2. Service Worker Proxy Class
// -----------------------------------------------------------------------------
/**
 * Manages the lifecycle of the Service Worker and handles message passing.
 * Uses a Promise-based architecture to mimic async/await on the main thread.
 */
class AIWorkerService {
    private worker: Worker | null = null;
    private pendingRequests: Map<string, { resolve: Function; reject: Function }> = new Map();
    private isInitialized = false;

    /**
     * Registers the worker using a Blob URL (useful for single-file distribution).
     * In production, register a physical file at '/ai-worker.js'.
     */
    async register() {
        if (this.worker) return; // Already registered

        const blob = new Blob([workerScript], { type: 'application/javascript' });
        const workerUrl = URL.createObjectURL(blob);
        
        this.worker = new Worker(workerUrl);
        
        this.worker.onmessage = this.handleMessage.bind(this);
        this.worker.onerror = (err) => console.error('Worker Error:', err);

        // Initialize the model immediately upon registration
        return this.initializeModel();
    }

    /**
     * Sends the initialization command to the worker.
     */
    private initializeModel(): Promise<void> {
        return this.postMessage('INITIALIZE', {});
    }

    /**
     * Public API: Request a summarization/inference task.
     * @param prompt - The text to process.
     * @param max_length - Token limit.
     */
    public generate(prompt: string, max_length?: number): Promise<string> {
        if (!this.worker) throw new Error('Worker not registered');
        return this.postMessage('INFERENCE', { prompt, max_length });
    }

    /**
     * Core messaging primitive. Wraps postMessage in a Promise.
     */
    private postMessage(type: string, payload: any): Promise<any> {
        return new Promise((resolve, reject) => {
            if (!this.worker) return reject(new Error('No worker available'));

            const id = crypto.randomUUID(); // Unique ID for this request
            this.pendingRequests.set(id, { resolve, reject });

            // Transfer data to worker
            this.worker.postMessage({ id, type, payload });
        });
    }

    /**
     * Handles incoming messages from the Worker.
     */
    private handleMessage(event: MessageEvent) {
        const { id, type, payload } = event.data;
        const request = this.pendingRequests.get(id);

        if (!request) {
            console.warn('Received message for unknown request ID:', id);
            return;
        }

        // Handle lifecycle events (Progress, Ready)
        if (type === 'PROGRESS') {
            console.log('Loading Model:', payload?.status);
            return; // Don't resolve the promise yet
        }

        // Clean up pending request
        this.pendingRequests.delete(id);

        if (type === 'ERROR') {
            request.reject(new Error(payload));
        } else if (type === 'COMPLETE' || type === 'READY') {
            request.resolve(payload);
        }
    }

    /**
     * Cleanup method.
     */
    public terminate() {
        if (this.worker) {
            this.worker.terminate();
            this.worker = null;
            this.pendingRequests.clear();
        }
    }
}

// Singleton instance export
export const aiService = new AIWorkerService();

// -----------------------------------------------------------------------------
// File: components/SummarizationDashboard.tsx
// -----------------------------------------------------------------------------
/**
 * @fileoverview React Component for the SaaS Dashboard.
 * Uses the `useCompletion` hook pattern (custom implementation) to manage
 * streaming or complete text generation state.
 */

import React, { useState, useEffect } from 'react';
import { aiService } from '../lib/ai-worker-service';

export const SummarizationDashboard: React.FC = () => {
    // State management mimicking Vercel AI SDK's useCompletion
    const [input, setInput] = useState<string>('');
    const [output, setOutput] = useState<string>('');
    const [status, setStatus] = useState<'idle' | 'loading' | 'generating' | 'error'>('idle');
    const [progress, setProgress] = useState<string>('');

    // Initialize the Service Worker on component mount
    useEffect(() => {
        let isMounted = true;

        const init = async () => {
            setStatus('loading');
            try {
                await aiService.register();
                if (isMounted) setStatus('idle');
            } catch (err) {
                if (isMounted) setStatus('error');
            }
        };

        init();

        return () => {
            isMounted = false;
            // Note: In a SPA, we usually don't terminate the worker immediately
            // to allow background processing for other components.
            // aiService.terminate(); 
        };
    }, []);

    /**
     * Handler for the Summarize button.
     * Delegates the heavy lifting to the background worker.
     */
    const handleSummarize = async () => {
        if (!input.trim()) return;

        setStatus('generating');
        setOutput(''); // Clear previous output

        try {
            // Construct a few-shot prompt to guide the model behavior
            const systemPrompt = `
                Summarize the following text in 3 concise bullet points:
                
                Text: "The quick brown fox jumps over the lazy dog."
                Summary: 
                1. A fox is described.
                2. It jumps over a dog.
                3. The dog is lazy.
                
                Text: "${input}"
                Summary:
            `;

            // Execute the background task
            const result = await aiService.generate(systemPrompt, 100);
            
            // Post-process the result (remove the input echo if model repeats it)
            const cleanResult = result.replace(input, '').trim();
            
            setOutput(cleanResult);
            setStatus('idle');
        } catch (err) {
            console.error(err);
            setStatus('error');
        }
    };

    return (
        <div style={{ padding: '20px', fontFamily: 'sans-serif', maxWidth: '800px', margin: '0 auto' }}>
            <h1>AI Background Summarizer</h1>
            
            <div style={{ marginBottom: '10px', color: '#666' }}>
                Status: {status} {status === 'loading' && <span>(Downloading Model ~500MB...)</span>}
            </div>

            <textarea
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder="Paste your long text here..."
                rows={8}
                style={{ width: '100%', padding: '10px', marginBottom: '10px' }}
                disabled={status === 'generating'}
            />

            <button 
                onClick={handleSummarize} 
                disabled={status === 'generating' || status === 'loading'}
                style={{ padding: '10px 20px', cursor: 'pointer' }}
            >
                {status === 'generating' ? 'Processing in Background...' : 'Summarize (Background Worker)'}
            </button>

            {output && (
                <div style={{ marginTop: '20px', padding: '15px', backgroundColor: '#f0f8ff', borderRadius: '5px' }}>
                    <h3>Result:</h3>
                    <p style={{ whiteSpace: 'pre-wrap' }}>{output}</p>
                </div>
            )}

            {status === 'error' && (
                <div style={{ marginTop: '10px', color: 'red' }}>
                    Error occurred. Check console for details.
                </div>
            )}
        </div>
    );
};
