/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// sw.ts
// Define the cache name and static assets to cache during installation.
const CACHE_NAME = 'ai-model-cache-v1';
const MODEL_URL = '/model.onnx'; // Assumed path to the model
const STATIC_ASSETS = [
    '/',
    '/index.html',
    '/main.js', // Bundled app code
    '/styles.css',
    MODEL_URL
];

// 1. Install Event: Cache static assets before activation.
self.addEventListener('install', (event: ExtendableEvent) => {
    console.log('[Service Worker] Installing...');
    // Force this service worker to become active immediately.
    self.skipWaiting();
    
    event.waitUntil(
        caches.open(CACHE_NAME)
            .then((cache) => {
                console.log('[Service Worker] Caching static assets');
                return cache.addAll(STATIC_ASSETS);
            })
            .catch((err) => console.error('Cache failed:', err))
    );
});

// 2. Activate Event: Clean up old caches.
self.addEventListener('activate', (event: ExtendableEvent) => {
    console.log('[Service Worker] Activating...');
    event.waitUntil(
        caches.keys().then((cacheNames) => {
            return Promise.all(
                cacheNames.map((cache) => {
                    // Delete caches that do not match the current version
                    if (cache !== CACHE_NAME) {
                        console.log('[Service Worker] Deleting old cache:', cache);
                        return caches.delete(cache);
                    }
                })
            );
        })
    );
    // Take control of all open clients (tabs/windows) immediately.
    return self.clients.claim();
});

// 3. Fetch Event: Implement Cache-First Strategy for the Model.
self.addEventListener('fetch', (event: FetchEvent) => {
    // Only handle GET requests for the specific model URL
    if (event.request.method !== 'GET') return;
    
    // Specific strategy for the large model file
    if (event.request.url.endsWith(MODEL_URL) || event.request.url.includes('model.onnx')) {
        event.respondWith(
            caches.match(event.request).then((cachedResponse) => {
                // Cache Hit: Return immediately
                if (cachedResponse) {
                    console.log('[Service Worker] Serving model from cache');
                    return cachedResponse;
                }

                // Cache Miss: Fetch from network, cache it, then return it
                console.log('[Service Worker] Fetching model from network...');
                return fetch(event.request).then((networkResponse) => {
                    // Check if we received a valid response
                    if (!networkResponse || networkResponse.status !== 200 || networkResponse.type !== 'basic') {
                        return networkResponse;
                    }

                    // Clone the response because responses are streams and can be consumed once only
                    const responseToCache = networkResponse.clone();

                    caches.open(CACHE_NAME).then((cache) => {
                        cache.put(event.request, responseToCache);
                    });

                    return networkResponse;
                });
            })
        );
    }
});
