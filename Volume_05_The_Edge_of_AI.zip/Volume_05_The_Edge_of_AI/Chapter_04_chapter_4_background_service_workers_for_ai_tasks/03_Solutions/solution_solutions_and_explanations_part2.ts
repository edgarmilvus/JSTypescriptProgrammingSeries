/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

// inference.worker.ts
import { pipeline, type PipelineType } from '@xenova/transformers';

// Define the worker context
declare const self: DedicatedWorkerGlobalScope;

// Model configuration
const MODEL_NAME = 'Xenova/distilbert-base-uncased-finetuned-sst-2-english';
let classifier: any = null;

// Load model once on worker initialization
async function loadModel() {
    if (!classifier) {
        console.log('[Worker] Loading model...');
        // @ts-ignore: Type definitions for pipeline might need specific casting
        classifier = await pipeline('sentiment-analysis', { 
            model: MODEL_NAME,
            progress_callback: (data: any) => {
                // Send progress updates to main thread if needed
                self.postMessage({ type: 'LOADING_PROGRESS', payload: data });
            }
        });
        console.log('[Worker] Model loaded.');
    }
    return classifier;
}

self.addEventListener('message', async (event) => {
    const { type, payload } = event.data;

    if (type === 'INFERENCE_REQUEST') {
        try {
            const model = await loadModel();
            const result = await model(payload); // Run inference
            
            // Transformers.js returns an array of results
            const bestResult = Array.isArray(result) ? result[0] : result;

            self.postMessage({
                type: 'INFERENCE_RESULT',
                payload: {
                    label: bestResult.label,
                    score: bestResult.score
                }
            });
        } catch (error) {
            self.postMessage({
                type: 'INFERENCE_ERROR',
                payload: (error as Error).message
            });
        }
    } else if (type === 'DISPOSE') {
        // Memory management: Explicitly dispose of the model
        if (classifier) {
            classifier.dispose();
            classifier = null;
            console.log('[Worker] Model disposed.');
        }
    }
});

// Handle worker termination/cleanup
self.addEventListener('close', () => {
    if (classifier) {
        classifier.dispose();
    }
});
