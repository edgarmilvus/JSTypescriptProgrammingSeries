/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

// ChatComponent.tsx
import React, { useState, useRef } from 'react';

type MessageStatus = 'pending' | 'confirmed' | 'error';

interface Message {
    id: string;
    role: 'user' | 'assistant';
    content: string;
    status: MessageStatus;
}

export const ChatComponent = () => {
    const [messages, setMessages] = useState<Message[]>([]);
    const workerRef = useRef<Worker | null>(null);

    // Initialize Worker (simplified for example)
    if (!workerRef.current) {
        workerRef.current = new Worker(new URL('./inference.worker.ts', import.meta.url));
        workerRef.current.onmessage = handleWorkerMessage;
    }

    const handleWorkerMessage = (e: MessageEvent) => {
        const { type, payload } = e.data;
        
        if (type === 'INFERENCE_RESULT') {
            // Reconciliation: Update the pending message with real data
            setMessages((prev) => 
                prev.map((msg) => 
                    msg.status === 'pending' 
                        ? { ...msg, content: payload.label, status: 'confirmed' } 
                        : msg
                )
            );
        } else if (type === 'INFERENCE_ERROR') {
            // Error Handling: Mark pending message as error
            setMessages((prev) =>
                prev.map((msg) =>
                    msg.status === 'pending'
                        ? { ...msg, content: 'Failed to generate response', status: 'error' }
                        : msg
                )
            );
        }
    };

    const sendMessage = (text: string) => {
        const userMsg: Message = {
            id: Date.now().toString(),
            role: 'user',
            content: text,
            status: 'confirmed'
        };

        const pendingAiMsg: Message = {
            id: (Date.now() + 1).toString(),
            role: 'assistant',
            content: 'Thinking...', // Placeholder
            status: 'pending'
        };

        // 1. Optimistic Update: Add both messages immediately
        setMessages((prev) => [...prev, userMsg, pendingAiMsg]);

        // 2. Background Processing: Send to worker
        workerRef.current?.postMessage({ type: 'INFERENCE_REQUEST', payload: text });
    };

    const retryMessage = (failedMsgId: string) => {
        // Find the failed message
        const msgToRetry = messages.find(m => m.id === failedMsgId);
        if (!msgToRetry) return;

        // Reset status to pending to show loading indicator
        setMessages((prev) => 
            prev.map(m => 
                m.id === failedMsgId 
                    ? { ...m, status: 'pending', content: 'Retrying...' } 
                    : m
            )
        );

        // Re-send request
        workerRef.current?.postMessage({ type: 'INFERENCE_REQUEST', payload: msgToRetry.content });
    };

    return (
        <div>
            {messages.map((msg) => (
                <div key={msg.id} className={`message ${msg.role}`}>
                    <p>{msg.content}</p>
                    {msg.status === 'pending' && <span> (Loading...)</span>}
                    {msg.status === 'error' && (
                        <button onClick={() => retryMessage(msg.id)}>Retry</button>
                    )}
                </div>
            ))}
            <button onClick={() => sendMessage("Hello AI")}>Send</button>
        </div>
    );
};
