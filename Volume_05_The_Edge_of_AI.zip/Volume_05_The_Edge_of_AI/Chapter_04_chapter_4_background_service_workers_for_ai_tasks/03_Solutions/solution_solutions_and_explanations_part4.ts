/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

// profilingUtils.ts
import { pipeline } from '@xenova/transformers';

type BackendType = 'webgpu' | 'wasm';

// 1. Capability Detection
export const detectBackend = (): BackendType => {
    // @ts-ignore: WebGPU API is still experimental in some contexts
    if (typeof navigator !== 'undefined' && navigator.gpu) {
        return 'webgpu';
    }
    return 'wasm';
};

// 2. Warm-up Function (Silent Run)
const warmUpModel = async (modelId: string, backend: BackendType) => {
    try {
        const pipe = await pipeline('sentiment-analysis', modelId, { 
            backend: backend, // Force specific backend
            quantized: true 
        });
        // Run a dummy inference
        await pipe('warm up');
        // Dispose immediately to free memory for the real test
        pipe.dispose();
    } catch (e) {
        console.warn("Warm-up failed (expected on some setups):", e);
    }
};

// 3. Profiling Function
export const runInferenceWithProfiling = async (
    text: string, 
    modelId: string, 
    backend: BackendType
): Promise<{ result: any; duration: number; backend: BackendType }> => {
    
    // Ensure warm-up (only needed once per session, but placed here for simplicity)
    // In a real app, track if warm-up is done globally.
    await warmUpModel(modelId, backend);

    const startTime = performance.now();
    
    // Initialize pipeline with specific backend
    const pipe = await pipeline('sentiment-analysis', modelId, { 
        backend: backend,
        quantized: true 
    });

    // Run actual inference
    const result = await pipe(text);
    
    const endTime = performance.now();
    const duration = endTime - startTime;

    // Cleanup
    pipe.dispose();

    return {
        result: result[0],
        duration: Math.round(duration), // ms
        backend
    };
};
