/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.tsx
// Description: Solutions and Explanations
// ==========================================

// CachedAIModel.tsx
import React, { useState, useEffect, useRef } from 'react';

// --- Types ---
type ModelStatus = 'idle' | 'loading' | 'cached' | 'error';
type InferenceStatus = 'idle' | 'processing' | 'success' | 'failed';

interface Props {
    modelUrl: string;
    inferenceFn: (input: string) => Promise<string>;
    children: (props: {
        result: string | null;
        isLoading: boolean;
        error: string | null;
        execute: (input: string) => void;
    }) => React.ReactNode;
}

export const CachedAIModel: React.FC<Props> = ({ modelUrl, inferenceFn, children }) => {
    // --- State ---
    const [modelStatus, setModelStatus] = useState<ModelStatus>('idle');
    const [inferenceState, setInferenceState] = useState<InferenceStatus>('idle');
    const [result, setResult] = useState<string | null>(null);
    const [error, setError] = useState<string | null>(null);

    // Ref to track current inference to handle race conditions
    const abortControllerRef = useRef<AbortController | null>(null);

    // --- 1. Service Worker Integration / Model Caching ---
    useEffect(() => {
        let isMounted = true;

        const fetchAndCacheModel = async () => {
            setModelStatus('loading');
            try {
                // This fetch request will be intercepted by the Service Worker (Exercise 1)
                // If cached, it returns instantly. If not, it downloads and caches.
                const response = await fetch(modelUrl);
                
                if (!response.ok) throw new Error('Failed to fetch model');
                
                if (isMounted) {
                    setModelStatus('cached');
                }
            } catch (err) {
                if (isMounted) setModelStatus('error');
            }
        };

        fetchAndCacheModel();

        return () => { isMounted = false; };
    }, [modelUrl]);

    // --- 2. Optimistic Execution & Reconciliation ---
    const execute = async (input: string) => {
        // Cancel previous request if pending (Reconciliation requirement)
        if (abortControllerRef.current) {
            abortControllerRef.current.abort();
        }

        const controller = new AbortController();
        abortControllerRef.current = controller;

        // Optimistic UI update
        setInferenceState('processing');
        setError(null);
        setResult(null); // Optional: Clear previous result

        try {
            // Execute the provided inference function (which handles worker comms)
            const data = await inferenceFn(input);
            
            if (controller.signal.aborted) return; // Ignore result if cancelled

            // Reconciliation: Update state with success
            setResult(data);
            setInferenceState('success');
        } catch (err) {
            if (controller.signal.aborted) return;
            
            // Error Handling
            setError(err instanceof Error ? err.message : 'Unknown error');
            setInferenceState('failed');
        }
    };

    // --- 3. Cleanup on Prop Change ---
    useEffect(() => {
        // If inferenceFn changes (model switch), reset state
        setInferenceState('idle');
        setResult(null);
        setError(null);
        
        // Cancel any pending operations
        if (abortControllerRef.current) {
            abortControllerRef.current.abort();
        }
    }, [inferenceFn]);

    // --- Render ---
    return (
        <div>
            {children({
                result,
                isLoading: inferenceState === 'processing' || modelStatus === 'loading',
                error,
                execute
            })}
        </div>
    );
};
