/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * @fileoverview A basic "Hello World" web app for interacting with a local SLM via Ollama.
 * @requires TypeScript
 */

// --- Type Definitions ---

/**
 * Represents the structure of a message in the chat history.
 */
type ChatMessage = {
    role: 'user' | 'assistant';
    content: string;
};

/**
 * Represents the payload sent to the Ollama API for generating a response.
 */
interface OllamaGenerateRequest {
    model: string;
    prompt: string;
    stream: boolean; // We will use streaming for a better UX
    options?: {
        temperature?: number;
        num_ctx?: number;
    };
}

/**
 * Represents a chunk of response data from the Ollama API (when streaming).
 */
interface OllamaResponseChunk {
    response?: string;
    done: boolean;
    context?: number[];
    total_duration?: number;
    // Additional fields omitted for brevity
}

// --- Configuration ---

const CONFIG = {
    OLLAMA_API_URL: 'http://localhost:11434/api/generate',
    DEFAULT_MODEL: 'phi3:mini', // Using Phi-3 Mini as a lightweight example
    MAX_RETRIES: 3,
};

// --- State Management ---

const state: {
    chatHistory: ChatMessage[];
    isGenerating: boolean;
} = {
    chatHistory: [],
    isGenerating: false,
};

// --- DOM Elements ---

const elements = {
    chatContainer: document.getElementById('chat-container') as HTMLDivElement,
    userInput: document.getElementById('user-input') as HTMLTextAreaElement,
    sendButton: document.getElementById('send-button') as HTMLButtonElement,
    statusIndicator: document.getElementById('status') as HTMLSpanElement,
};

// --- Core Logic ---

/**
 * Sends a prompt to the local Ollama instance and handles the streaming response.
 * @param prompt - The user's input text.
 * @returns A Promise that resolves when the stream is complete.
 */
async function sendPromptToOllama(prompt: string): Promise<void> {
    if (state.isGenerating) return;

    state.isGenerating = true;
    updateUIStatus('Generating...');

    const requestBody: OllamaGenerateRequest = {
        model: CONFIG.DEFAULT_MODEL,
        prompt: prompt,
        stream: true, // Enable streaming for real-time updates
        options: {
            temperature: 0.7, // Controls randomness
        },
    };

    try {
        const response = await fetch(CONFIG.OLLAMA_API_URL, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(requestBody),
        });

        if (!response.ok) {
            throw new Error(`Ollama API error: ${response.statusText}`);
        }

        // Handle Streaming Response
        const reader = response.body?.getReader();
        if (!reader) throw new Error('No response body');

        const decoder = new TextDecoder();
        let fullResponse = '';

        while (true) {
            const { done, value } = await reader.read();
            if (done) break;

            const chunkText = decoder.decode(value, { stream: true });
            const lines = chunkText.split('\n').filter(line => line.trim() !== '');

            for (const line of lines) {
                try {
                    const json: OllamaResponseChunk = JSON.parse(line);
                    if (json.response) {
                        fullResponse += json.response;
                        // Update UI incrementally
                        updateChatDisplay('assistant', fullResponse, true);
                    }
                    if (json.done) {
                        // Finalize the message
                        state.chatHistory.push({ role: 'assistant', content: fullResponse });
                        renderChatHistory();
                    }
                } catch (e) {
                    // Ignore incomplete JSON chunks during streaming
                    console.warn('Skipped incomplete JSON chunk');
                }
            }
        }
    } catch (error) {
        console.error('Error communicating with Ollama:', error);
        updateChatDisplay('assistant', `Error: ${error.message}`, false);
    } finally {
        state.isGenerating = false;
        updateUIStatus('Ready');
        elements.userInput.disabled = false;
        elements.sendButton.disabled = false;
        elements.userInput.focus();
    }
}

// --- UI Helper Functions ---

/**
 * Renders the chat history to the DOM.
 */
function renderChatHistory(): void {
    elements.chatContainer.innerHTML = ''; // Clear current view
    
    state.chatHistory.forEach(msg => {
        const msgDiv = document.createElement('div');
        msgDiv.className = `message ${msg.role}`;
        msgDiv.textContent = msg.content;
        elements.chatContainer.appendChild(msgDiv);
    });

    // Scroll to bottom
    elements.chatContainer.scrollTop = elements.chatContainer.scrollHeight;
}

/**
 * Updates the chat display dynamically (for streaming).
 * @param role - The role of the message sender.
 * @param content - The current content string.
 * @param isStreaming - Whether this is an incremental update.
 */
function updateChatDisplay(role: 'assistant', content: string, isStreaming: boolean): void {
    // If streaming, we either update the last message or append a new one
    let lastMsg = elements.chatContainer.lastElementChild;
    
    // Check if the last element is an assistant message (for streaming continuity)
    if (isStreaming && lastMsg && lastMsg.classList.contains('assistant')) {
        lastMsg.textContent = content;
    } else if (!isStreaming) {
        // For non-streaming or errors, standard append
        const msgDiv = document.createElement('div');
        msgDiv.className = `message ${role}`;
        msgDiv.textContent = content;
        elements.chatContainer.appendChild(msgDiv);
    }
    
    elements.chatContainer.scrollTop = elements.chatContainer.scrollHeight;
}

/**
 * Updates the status indicator in the UI.
 * @param status - The text to display.
 */
function updateUIStatus(status: string): void {
    elements.statusIndicator.textContent = status;
    if (status === 'Generating...') {
        elements.statusIndicator.style.color = '#f59e0b'; // Orange
    } else {
        elements.statusIndicator.style.color = '#10b981'; // Green
    }
}

// --- Event Listeners ---

function handleSend(): void {
    const prompt = elements.userInput.value.trim();
    if (!prompt || state.isGenerating) return;

    // Add user message to history and UI immediately
    state.chatHistory.push({ role: 'user', content: prompt });
    renderChatHistory();

    // Clear input
    elements.userInput.value = '';
    elements.userInput.disabled = true;
    elements.sendButton.disabled = true;

    // Trigger API call
    sendPromptToOllama(prompt);
}

// Initialize
elements.sendButton.addEventListener('click', handleSend);
elements.userInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        handleSend();
    }
});

updateUIStatus('Ready');
