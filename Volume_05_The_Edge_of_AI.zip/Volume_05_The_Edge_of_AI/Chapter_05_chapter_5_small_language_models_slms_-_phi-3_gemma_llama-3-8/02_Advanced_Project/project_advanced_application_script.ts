/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// pages/api/chat.ts
// Next.js API Route for handling AI document queries with Tool Calling and Few-Shot Prompting.

import type { NextApiRequest, NextApiResponse } from 'next';
import { Ollama } from 'ollama';

// ==========================================
// 1. UTILITY TYPES & INTERFACES
// ==========================================

/**
 * Represents a chunk of text from a document.
 * Using 'Pick' utility type to strictly define the shape of stored data.
 */
export type DocumentChunk = Pick<{
  id: string;
  content: string;
  metadata: { page: number; source: string };
}, 'id' | 'content' | 'metadata'>;

/**
 * Represents the state of the chat session.
 * 'Partial' makes all properties optional, useful for initialization or patches.
 */
export interface ChatSessionState {
  history: Array<{ role: 'user' | 'assistant'; content: string }>;
  documentContext: DocumentChunk[];
}

/**
 * Defines the structure for the tool call expected from the LLM.
 * We expect the LLM to output a JSON string that matches this interface.
 */
export interface ToolCallRequest {
  tool_name: 'retrieve_document_chunk';
  arguments: {
    query: string;
    limit: number;
  };
}

// ==========================================
// 2. MOCK DOCUMENT DATA (SIMULATED DATABASE)
// ==========================================

const MOCK_DOCUMENT: DocumentChunk[] = [
  { id: '1', content: "The Q3 financial report indicates a 15% increase in revenue driven by the new AI division.", metadata: { page: 1, source: 'report.pdf' } },
  { id: '2', content: "Employee satisfaction scores dropped to 78% in September, citing remote work policies.", metadata: { page: 2, source: 'report.pdf' } },
  { id: '3', content: "The engineering team successfully deployed the Phi-3 small language model to production.", metadata: { page: 3, source: 'report.pdf' } },
  { id: '4', content: "Marketing budget allocation for Q4 is set at $2M, focusing on social media campaigns.", metadata: { page: 4, source: 'report.pdf' } },
];

// ==========================================
// 3. FEW-SHOT PROMPTING ENGINE
// ==========================================

/**
 * Constructs a system prompt using Few-Shot Prompting.
 * This guides the SLM (Phi-3, Gemma, Llama-3-8B) to output structured JSON
 * instead of natural language text when a tool is needed.
 */
const buildSystemPrompt = (documentContext: string): string => {
  return `
You are a precise document analysis assistant. You have access to a document. 
Your goal is to answer user questions accurately.

**DOCUMENT CONTENT:**
${documentContext}

**INSTRUCTIONS:**
1. Analyze the user's question.
2. If the question requires specific data from the document that you cannot recall perfectly, you MUST call the 'retrieve_document_chunk' tool.
3. Output ONLY valid JSON matching the ToolCallRequest interface if a tool is needed.
4. If you have the answer directly, output a plain text response.

**FEW-SHOT EXAMPLES:**

User: "What does the report say about revenue?"
Assistant: 
{
  "tool_name": "retrieve_document_chunk",
  "arguments": { "query": "revenue", "limit": 2 }
}

User: "Who is the CEO?"
Assistant:
I cannot find information about the CEO in the provided document.

User: "Summarize the Q3 findings."
Assistant:
The Q3 report highlights a 15% revenue increase and the deployment of the Phi-3 model.
`;
};

// ==========================================
// 4. TOOL EXECUTION LOGIC
// ==========================================

/**
 * Simulates a vector search or keyword retrieval tool.
 * In a real app, this would query a vector database (e.g., pgvector, Pinecone).
 * @param query - The semantic search query.
 * @param limit - Max chunks to retrieve.
 * @returns Promise<DocumentChunk[]>
 */
async function retrieve_document_chunk(query: string, limit: number = 2): Promise<DocumentChunk[]> {
  console.log(`[Tool Exec] Retrieving chunks for query: "${query}"`);
  
  // Simple keyword matching simulation for the demo
  const results = MOCK_DOCUMENT.filter(chunk => 
    chunk.content.toLowerCase().includes(query.toLowerCase())
  ).slice(0, limit);

  // Simulate network latency
  await new Promise(resolve => setTimeout(resolve, 300));
  
  return results;
}

// ==========================================
// 5. NEXT.JS API HANDLER
// ==========================================

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  const { message, documentChunks }: { message: string; documentChunks?: DocumentChunk[] } = req.body;
  
  // Initialize Ollama client (pointing to local instance)
  const ollama = new Ollama({ host: 'http://localhost:11434' });
  
  // Use provided chunks or default to mock data
  const contextDocs = documentChunks || MOCK_DOCUMENT;
  const contextText = contextDocs.map(c => `[ID:${c.id}] ${c.content}`).join('\n');

  try {
    // 1. Construct the prompt with Few-Shot examples
    const systemPrompt = buildSystemPrompt(contextText);
    
    // 2. Initial Call to LLM
    // We stream the response to handle potential tool calls or final answers
    const response = await ollama.chat({
      model: 'phi3', // Using Phi-3 as it's a robust SLM
      stream: false, // For simplicity in this script, we use non-stream for the first pass
      messages: [
        { role: 'system', content: systemPrompt },
        { role: 'user', content: message }
      ],
    });

    const llmOutput = response.message.content.trim();
    console.log("LLM Raw Output:", llmOutput);

    // 3. Parse Output: Check if it's a Tool Call (JSON) or a Final Answer
    let finalResponseText = '';
    let sources: DocumentChunk[] = [];

    try {
      // Attempt to parse as JSON (Tool Call)
      const potentialJson = JSON.parse(llmOutput);
      
      // Validate structure (simplified check)
      if (potentialJson.tool_name && potentialJson.arguments) {
        const toolReq = potentialJson as ToolCallRequest;
        
        // Execute the Tool
        const toolResult = await retrieve_document_chunk(
          toolReq.arguments.query, 
          toolReq.arguments.limit
        );
        
        sources = toolResult;

        // 4. Second Pass: Contextualize Tool Result
        // Now that we have precise data, ask the LLM to generate the final answer
        const contextPrompt = `
          Original Question: "${message}"
          Retrieved Data: ${JSON.stringify(toolResult)}
          
          Please synthesize an answer based strictly on the retrieved data.
        `;

        const finalResponse = await ollama.chat({
          model: 'phi3',
          messages: [
            { role: 'system', content: 'You are a helpful assistant. Answer the question based on the provided data.' },
            { role: 'user', content: contextPrompt }
          ]
        });

        finalResponseText = finalResponse.message.content;
      } else {
        // It wasn't a JSON tool call, just a text response
        finalResponseText = llmOutput;
      }
    } catch (e) {
      // LLM returned non-JSON text
      finalResponseText = llmOutput;
    }

    // 5. Return structured response to frontend
    res.status(200).json({
      answer: finalResponseText,
      sources: sources, // Useful for frontend citations
      timestamp: new Date().toISOString()
    });

  } catch (error) {
    console.error('API Error:', error);
    res.status(500).json({ error: 'Failed to process request with local LLM' });
  }
}
