/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState } from 'react';

// Types for chat history and routing
type ChatRole = 'user' | 'assistant' | 'router';
interface ChatMessage {
  role: ChatRole;
  content: string;
}

const SmartRouterChat: React.FC = () => {
  const [userInput, setUserInput] = useState<string>('');
  const [chatHistory, setChatHistory] = useState<ChatMessage[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(false);

  // Helper to interact with Ollama
  const queryOllama = async (model: string, prompt: string): Promise<string> => {
    const response = await fetch('http://localhost:11434/api/generate', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ model, prompt, stream: false }),
    });
    const data = await response.json();
    return data.response;
  };

  const handleSend = async () => {
    if (!userInput.trim()) return;

    // 1. Add user input to history immediately
    const userMessage: ChatMessage = { role: 'user', content: userInput };
    setChatHistory(prev => [...prev, userMessage]);
    setUserInput('');
    setIsLoading(true);

    try {
      // 2. Pre-processing: Classify intent using Phi-3
      const classificationPrompt = `Classify the following user query as either "technical" or "creative". Only output the single word classification.\n\nQuery: "${userInput}"`;
      const classification = await queryOllama('phi-3', classificationPrompt);
      
      const intent = classification.toLowerCase().includes('technical') ? 'technical' : 'creative';

      // 3. Add routing decision to UI
      const routingMessage: ChatMessage = { 
        role: 'router', 
        content: `Routing to ${intent === 'technical' ? 'Llama-3-8B' : 'Gemma'} for ${intent} accuracy...` 
      };
      setChatHistory(prev => [...prev, routingMessage]);

      // 4. Route to appropriate model
      const targetModel = intent === 'technical' ? 'llama-3-8b' : 'gemma';
      const finalResponse = await queryOllama(targetModel, userInput);

      // 5. Add final response to history
      const assistantMessage: ChatMessage = { role: 'assistant', content: finalResponse };
      setChatHistory(prev => [...prev, assistantMessage]);

    } catch (error) {
      console.error("Routing failed:", error);
      setChatHistory(prev => [...prev, { role: 'assistant', content: "Error processing request." }]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div style={{ padding: '20px', maxWidth: '600px', margin: '0 auto' }}>
      <h3>Smart Router Chat</h3>
      <div style={{ border: '1px solid #ccc', height: '300px', overflowY: 'auto', padding: '10px', marginBottom: '10px' }}>
        {chatHistory.map((msg, index) => (
          <div key={index} style={{ 
            textAlign: msg.role === 'user' ? 'right' : 'left',
            margin: '5px 0',
            color: msg.role === 'router' ? 'gray' : 'black',
            fontStyle: msg.role === 'router' ? 'italic' : 'normal'
          }}>
            <strong>{msg.role.toUpperCase()}:</strong> {msg.content}
          </div>
        ))}
        {isLoading && <div style={{ color: 'blue' }}>Thinking...</div>}
      </div>
      <div style={{ display: 'flex', gap: '10px' }}>
        <input 
          type="text" 
          value={userInput} 
          onChange={(e) => setUserInput(e.target.value)} 
          onKeyDown={(e) => e.key === 'Enter' && handleSend()}
          style={{ flex: 1, padding: '8px' }}
          placeholder="Ask a question..."
        />
        <button onClick={handleSend} disabled={isLoading} style={{ padding: '8px 16px' }}>
          Send
        </button>
      </div>
    </div>
  );
};

export default SmartRouterChat;
