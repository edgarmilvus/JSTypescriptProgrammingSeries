/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

/**
 * Converts unstructured notes into a specific "Action Item" format
 * using Few-Shot prompting with the Gemma model.
 * 
 * @param notes - The raw user notes to format.
 * @returns The formatted action item string.
 */
async function formatActionItems(notes: string): Promise<string> {
  const ollamaUrl = "http://localhost:11434/api/generate";
  const modelName = "gemma";

  // Define the system role and Few-Shot examples
  const systemRole = `You are a task management assistant. Convert user notes into a specific format: "[Priority] Task Name @DueDate".
  - Priority: High, Medium, Low
  - Task Name: A concise description
  - DueDate: The specific day or date mentioned
  `;

  const fewShotExamples = `
  Example 1:
  Input: "Meeting with engineering on Friday about the API."
  Output: "[High] Meeting with engineering @Friday"

  Example 2:
  Input: "Draft the Q3 report by next Tuesday."
  Output: "[Medium] Draft Q3 report @Tuesday"

  Example 3:
  Input: "Review the pull request when you have time."
  Output: "[Low] Review pull request @NoDate"
  `;

  // Construct the full prompt
  const prompt = `${systemRole}\n\n${fewShotExamples}\n\nActual Note:\nInput: "${notes}"\nOutput:`;

  try {
    const response = await fetch(ollamaUrl, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        model: modelName,
        prompt: prompt,
        stream: false,
      }),
    });

    if (!response.ok) {
      throw new Error(`Ollama API error: ${response.statusText}`);
    }

    const data = await response.json();
    
    // Return the raw string response as requested
    return data.response.trim();

  } catch (error) {
    console.error("Formatting failed:", error);
    throw error;
  }
}

// Example usage:
/*
formatActionItems("Buy milk and eggs on Saturday")
  .then(formatted => console.log(formatted)); 
  // Expected Output: "[Medium] Buy milk and eggs @Saturday"
*/
