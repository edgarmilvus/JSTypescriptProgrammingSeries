/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

// Note: This solution assumes the environment has access to the 
// @huggingface/transformers library (loaded via CDN or bundler).

import { pipeline, TextGenerationOutput } from '@huggingface/transformers';

/**
 * Runs a benchmark for text generation on a specific backend.
 * 
 * @param backend - The backend to use ('wasm' or 'webgpu').
 * @returns A Promise resolving to the time taken in milliseconds.
 */
async function runBenchmark(backend: 'wasm' | 'webgpu'): Promise<number> {
  console.log(`Starting benchmark for backend: ${backend}`);

  // Select a small model suitable for client-side inference
  // 'Xenova/phi-2' is a good small model, but let's use a tiny one for speed.
  const modelId = 'Xenova/phi-2'; 

  try {
    const startLoad = performance.now();
    
    // Initialize the pipeline
    const generator = await pipeline('text-generation', modelId, {
      // Configuration specific to the backend
      device: backend, 
      // quantization might be needed for WASM to be fast enough
      quantized: true, 
    });
    
    const endLoad = performance.now();
    console.log(`Model loaded in ${endLoad - startLoad}ms`);

    const prompt = "The meaning of life is";
    
    // Measure inference time
    const startGen = performance.now();
    
    // Run generation
    const output = await generator(prompt, { 
      max_new_tokens: 10, 
      do_sample: false 
    });
    
    const endGen = performance.now();
    const inferenceTime = endGen - startGen;

    console.log(`Generated: ${output[0].generated_text}`);
    
    // Clean up memory (optional but good practice in loops)
    if (generator.dispose) await generator.dispose();

    return inferenceTime;

  } catch (error) {
    console.error(`Benchmark failed for ${backend}:`, error);
    
    // Check if it's a WebGPU specific error
    if (backend === 'webgpu' && (error as Error).message.includes('webgpu')) {
      throw new Error("WebGPU not supported on this hardware.");
    }
    throw error;
  }
}

/**
 * Main function to run the race and display results.
 */
async function runPerformanceRace() {
  const resultsDiv = document.createElement('div');
  resultsDiv.style.cssText = "position: fixed; top: 20px; right: 20px; background: white; border: 2px solid black; padding: 20px; z-index: 1000;";
  document.body.appendChild(resultsDiv);

  const updateUI = (msg: string) => {
    resultsDiv.innerHTML += `<p>${msg}</p>`;
  };

  updateUI("Initializing benchmarks...");

  // 1. Run CPU (WASM) Benchmark
  try {
    const cpuTime = await runBenchmark('wasm');
    updateUI(`CPU (WASM) Time: ${cpuTime.toFixed(2)}ms`);
  } catch (e) {
    updateUI(`CPU Benchmark Error: ${(e as Error).message}`);
  }

  // 2. Run WebGPU Benchmark
  try {
    const gpuTime = await runBenchmark('webgpu');
    updateUI(`WebGPU Time: ${gpuTime.toFixed(2)}ms`);
  } catch (e) {
    // Graceful handling as per requirements
    if ((e as Error).message.includes("not supported")) {
      updateUI("WebGPU not supported on this hardware.");
    } else {
      updateUI(`WebGPU Benchmark Error: ${(e as Error).message}`);
    }
  }
}

// Execute if running in a browser context
// runPerformanceRace();
