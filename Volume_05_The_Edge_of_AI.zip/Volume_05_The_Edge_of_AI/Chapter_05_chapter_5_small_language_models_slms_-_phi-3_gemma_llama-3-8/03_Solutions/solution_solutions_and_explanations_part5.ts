/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

// Main Thread Code

// Define the worker script content as a string (for single-file solution)
// In a real app, this would be a separate 'worker.ts' file.
const workerScript = `
  // Inside Web Worker
  importScripts('https://cdn.jsdelivr.net/npm/@huggingface/transformers@latest/dist/transformers.min.js');

  self.onmessage = async (event) => {
    const { id, prompt } = event.data;
    
    // Notify start
    self.postMessage({ id, status: 'started' });

    try {
      // Initialize pipeline inside the worker
      // Note: Transformers.js handles Worker context well
      const generator = await pipeline('text-generation', 'Xenova/phi-2', {
        device: 'wasm', // Ensure it runs on CPU/WASM
        quantized: true
      });

      const output = await generator(prompt, { max_new_tokens: 20 });
      
      // Notify completion
      self.postMessage({ 
        id, 
        status: 'finished', 
        result: output[0].generated_text 
      });

      // Cleanup
      if (generator.dispose) await generator.dispose();

    } catch (error) {
      self.postMessage({ id, status: 'error', error: error.message });
    }
  };
`;

/**
 * Spawns parallel inference tasks using Web Workers.
 * 
 * @param prompts - Array of strings to process.
 */
async function parallelInference(prompts: string[]) {
  console.log(`Starting parallel processing for ${prompts.length} prompts...`);

  // Create a Blob from the worker script string to avoid external file dependency
  const blob = new Blob([workerScript], { type: 'application/javascript' });
  const workerUrl = URL.createObjectURL(blob);

  const workers: Worker[] = [];
  const completedPromises: Promise<void>[] = [];

  prompts.forEach((prompt, index) => {
    const worker = new Worker(workerUrl);
    workers.push(worker);

    const promise = new Promise<void>((resolve) => {
      worker.onmessage = (event) => {
        const { id, status, result, error } = event.data;
        
        if (status === 'started') {
          console.log(\`Worker \${id} started processing.\`);
        } else if (status === 'finished') {
          console.log(\`Worker \${id} finished. Result: \${result}\`);
          worker.terminate(); // Kill worker after done
          resolve();
        } else if (status === 'error') {
          console.error(\`Worker \${id} failed: \${error}\`);
          worker.terminate();
          resolve();
        }
      };
    });

    completedPromises.push(promise);

    // Send the prompt to the worker
    // We simulate SharedArrayBuffer behavior via message passing (postMessage)
    worker.postMessage({ id: index + 1, prompt });
  });

  // Wait for all workers to complete
  await Promise.all(completedPromises);
  
  // Cleanup blob URL
  URL.revokeObjectURL(workerUrl);
  console.log("All parallel tasks completed.");
}

// Example Usage:
/*
const samplePrompts = [
  "The capital of France is",
  "To bake a cake you need",
  "In quantum physics, light behaves"
];

parallelInference(samplePrompts);
*/
