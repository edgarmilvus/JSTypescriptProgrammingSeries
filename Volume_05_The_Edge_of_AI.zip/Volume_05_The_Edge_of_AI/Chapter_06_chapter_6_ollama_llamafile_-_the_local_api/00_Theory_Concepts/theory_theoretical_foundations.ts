/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: theory_theoretical_foundations.ts
// Description: Theoretical Foundations
// ==========================================

digraph Architecture {
    rankdir=TB;
    node [shape=box, style=filled, fillcolor="#f0f0f0", color="#333333"];

    subgraph cluster_app {
        label="Application Layer";
        style=invis;
        App [label="Web App / IDE / CLI", fillcolor="#e1f5fe"];
    }

    subgraph cluster_ollama {
        label="Ollama (Containerized)";
        style=dashed;
        color=blue;

        Ollama_API [label="OpenAI Compatible API\n(REST/HTTP)", fillcolor="#bbdefb"];
        Ollama_Manager [label="Go Management Layer\n(Daemon, Model Router)", fillcolor="#90caf9"];
        Ollama_Engine [label="llama.cpp (C++)\nInference Engine", fillcolor="#64b5f6"];
        Ollama_Models [label="Model Weights (.gguf)\n(Dynamic Loading)", fillcolor="#42a5f5"];
    }

    subgraph cluster_llamafile {
        label="Llamafile (Executable)";
        style=dashed;
        color=green;

        Llamafile_API [label="OpenAI Compatible API\n(REST/HTTP)", fillcolor="#c8e6c9"];
        Llamafile_Binary [label="Single Executable\n(Static Binary)", fillcolor="#a5d6a7"];
        Llamafile_Engine [label="llama.cpp (C++)\nInference Engine", fillcolor="#81c784"];
        Llamafile_Models [label="Embedded Weights\n(Static Linking)", fillcolor="#66bb6a"];
    }

    App -> Ollama_API [label="JSON Request"];
    App -> Llamafile_API [label="JSON Request"];

    Ollama_API -> Ollama_Manager;
    Ollama_Manager -> Ollama_Engine;
    Ollama_Engine -> Ollama_Models;

    Llamafile_API -> Llamafile_Binary;
    Llamafile_Binary -> Llamafile_Engine;
    Llamafile_Binary -> Llamafile_Models;

    {rank=same; Ollama_API; Llamafile_API}
}
