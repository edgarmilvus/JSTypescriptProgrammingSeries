/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * Types for our application state and API responses.
 * This ensures type safety when handling optimistic updates.
 */

// The shape of the data we send to the UI immediately
interface OptimisticMessage {
  id: string;
  content: string; // Initially "Thinking..."
  isOptimistic: boolean;
  status: 'pending' | 'success' | 'error';
}

// The shape of the response expected from Ollama
interface OllamaResponse {
  model: string;
  created_at: string;
  response: string; // Token stream content
  done: boolean;    // Indicates end of stream
  total_duration: number;
}

/**
 * Simulates a generic UI State Manager (like a Redux store or React Context).
 * In a real app, this would trigger component re-renders.
 */
class UIManager {
  private messages: OptimisticMessage[] = [];

  /**
   * Adds a message to the local state and logs it.
   * In a real app, this would update the DOM/React State.
   */
  addMessage(msg: OptimisticMessage) {
    this.messages.push(msg);
    console.log(`[UI Update] ID: ${msg.id} | Status: ${msg.status} | Content: "${msg.content}"`);
  }

  /**
   * Updates an existing message (Reconciliation step).
   */
  updateMessage(id: string, newContent: string, status: 'success' | 'error') {
    const msgIndex = this.messages.findIndex(m => m.id === id);
    if (msgIndex !== -1) {
      this.messages[msgIndex].content = newContent;
      this.messages[msgIndex].status = status;
      this.messages[msgIndex].isOptimistic = false; // No longer optimistic
      console.log(`[Reconciliation] ID: ${id} | New Status: ${status} | Final Content: "${newContent}"`);
    }
  }
}

/**
 * The core function handling the Optimistic UI flow.
 * 
 * 1. Generates an Optimistic ID.
 * 2. Updates UI immediately (Optimistic Render).
 * 3. Fetches from Local Ollama API (Background Process).
 * 4. Reconciles the result (Updates UI with actual data).
 */
async function handleChatRequest(
  prompt: string, 
  uiManager: UIManager
): Promise<void> {
  
  // --- Step 1: Prepare Optimistic State ---
  // We generate a unique ID to track this specific request through the async flow.
  const optimisticId = `msg_${Date.now()}`;
  
  // --- Step 2: Optimistic UI Update ---
  // We DO NOT await here. We update the UI immediately.
  // The user sees "Thinking..." instantly.
  uiManager.addMessage({
    id: optimisticId,
    content: "Thinking...", 
    isOptimistic: true,
    status: 'pending'
  });

  try {
    // --- Step 3: Background Computation (Local AI) ---
    // We send the prompt to the local Ollama API.
    // Note: We are using the /api/generate endpoint which streams tokens.
    const response = await fetch('http://localhost:11434/api/generate', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model: 'llama2', // Ensure you have this model pulled in Ollama
        prompt: prompt,
        stream: false,    // For simplicity in this example, we disable streaming
      }),
    });

    if (!response.ok) {
      throw new Error(`HTTP Error: ${response.status}`);
    }

    const data: OllamaResponse = await response.json();

    // --- Step 4: Reconciliation ---
    // The background process is done. We now compare the actual result
    // with our optimistic state and update the UI to match reality.
    if (data.response) {
      uiManager.updateMessage(optimisticId, data.response, 'success');
    } else {
      throw new Error("Empty response from AI");
    }

  } catch (error) {
    // Error Handling: If the background process fails, we must update
    // the UI to reflect the error, otherwise the user sees "Thinking..." forever.
    const errorMessage = error instanceof Error ? error.message : "Unknown Error";
    uiManager.updateMessage(optimisticId, `Error: ${errorMessage}`, 'error');
    console.error("Background process failed:", error);
  }
}

// --- Execution Simulation ---

// 1. Initialize the UI Manager
const appUI = new UIManager();

// 2. Run the function (Simulating a user clicking "Send")
// Note: This assumes Ollama is running locally on port 11434.
console.log("--- Starting Optimistic UI Flow ---");

handleChatRequest("Explain WebGPU in one sentence.", appUI)
  .then(() => console.log("--- Flow Complete ---"))
  .catch(err => console.error("Critical Failure:", err));

// 3. To allow the async function to finish in this Node environment:
setTimeout(() => {}, 2000); 
