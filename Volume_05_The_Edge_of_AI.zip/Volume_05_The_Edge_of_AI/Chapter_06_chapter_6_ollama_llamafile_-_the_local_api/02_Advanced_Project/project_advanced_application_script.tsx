/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.tsx
// Description: Advanced Application Script
// ==========================================

// app/components/LocalAIChat.tsx
'use client';

import React, { useState, useRef, useEffect } from 'react';

/**
 * @interface ChatMessage
 * @description Defines the structure for a single chat message.
 * @property {string} role - 'user' or 'assistant'
 * @property {string} content - The text content of the message.
 */
interface ChatMessage {
  role: 'user' | 'assistant';
  content: string;
}

/**
 * @interface OllamaRequest
 * @description Payload structure for the Ollama API (OpenAI compatible).
 * @property {string} model - The model name (e.g., 'llama2').
 * @property {ChatMessage[]} messages - Array of conversation history.
 * @property {boolean} stream - Whether to stream the response.
 */
interface OllamaRequest {
  model: string;
  messages: ChatMessage[];
  stream: boolean;
}

/**
 * @interface OllamaResponse
 * @description Structure of the response chunk from Ollama.
 * @property {string} content - The incremental text content.
 * @property {string} role - The role of the responder.
 * @property {string} finish_reason - Indicates if the generation is complete.
 */
interface OllamaResponse {
  choices: Array<{
    delta: {
      content?: string;
      role?: string;
    };
    finish_reason: string | null;
  }>;
}

/**
 * @component LocalAIChat
 * @description A Next.js client component that connects to a local Ollama instance.
 * It implements connection retry logic, streaming responses, and basic error handling.
 */
export default function LocalAIChat() {
  // State for managing the chat history
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  // State for the current user input
  const [input, setInput] = useState('');
  // State for connection status and errors
  const [status, setStatus] = useState<'disconnected' | 'connecting' | 'connected' | 'error'>('disconnected');
  // State for loading indicators during inference
  const [isLoading, setIsLoading] = useState(false);
  
  // Ref to the chat container for auto-scrolling
  const chatEndRef = useRef<HTMLDivElement>(null);

  // Configuration for the local backend
  const OLLAMA_API_URL = 'http://localhost:11434';
  const MODEL_NAME = 'llama2'; // Ensure this model is pulled in Ollama

  /**
   * @function scrollToBottom
   * @description Scrolls the chat window to the latest message.
   */
  const scrollToBottom = () => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  /**
   * @function checkConnection
   * @description Verifies if the local Ollama service is reachable.
   * This is crucial for UX to handle "Cold Start" scenarios where the user
   * might need to start the Ollama desktop app or CLI.
   */
  const checkConnection = async () => {
    try {
      setStatus('connecting');
      // We hit the root endpoint or a specific model endpoint to verify availability
      const response = await fetch(`${OLLAMA_API_URL}/api/tags`);
      if (!response.ok) throw new Error('Service not available');
      setStatus('connected');
    } catch (error) {
      setStatus('error');
      console.error('Connection failed:', error);
    }
  };

  // Initial connection check on mount
  useEffect(() => {
    checkConnection();
  }, []);

  /**
   * @function handleSubmit
   * @description Handles the form submission, sends the prompt to Ollama,
   * and processes the streaming response.
   */
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || status !== 'connected') return;

    // 1. Update UI immediately for user feedback
    const userMessage: ChatMessage = { role: 'user', content: input };
    const newMessages = [...messages, userMessage];
    setMessages(newMessages);
    setInput('');
    setIsLoading(true);

    // 2. Prepare the request payload
    const payload: OllamaRequest = {
      model: MODEL_NAME,
      messages: newMessages,
      stream: true, // Enable streaming for better UX
    };

    try {
      // 3. Fetch the streaming response
      const response = await fetch(`${OLLAMA_API_URL}/v1/chat/completions`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(payload),
      });

      if (!response.body) {
        throw new Error('No response body received');
      }

      // 4. Process the stream (TextDecoder)
      const reader = response.body.getReader();
      const decoder = new TextDecoder();
      
      // Temporary state for the accumulating assistant message
      let assistantContent = '';
      
      // Add a placeholder for the assistant message to update in real-time
      setMessages((prev) => [...prev, { role: 'assistant', content: '' }]);

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        const chunk = decoder.decode(value, { stream: true });
        
        // 5. Parse Server-Sent Events (SSE) format
        // Ollama streams in SSE format: "data: {json}\n\n"
        const lines = chunk.split('\n').filter((line) => line.startsWith('data: '));

        for (const line of lines) {
          try {
            const data = JSON.parse(line.replace('data: ', '')) as OllamaResponse;
            const delta = data.choices[0]?.delta?.content;
            
            if (delta) {
              assistantContent += delta;
              // 6. Optimistic UI Update: Append tokens as they arrive
              setMessages((prev) => {
                const newMsgs = [...prev];
                // Update the last message (the assistant's placeholder)
                newMsgs[newMsgs.length - 1] = { role: 'assistant', content: assistantContent };
                return newMsgs;
              });
            }
          } catch (parseError) {
            // Ignore malformed JSON chunks (often keep-alive signals)
            console.warn('Failed to parse chunk:', parseError);
          }
        }
      }
    } catch (error) {
      console.error('Inference error:', error);
      setMessages((prev) => [
        ...prev,
        { role: 'assistant', content: 'Error: Could not connect to local model.' }
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="flex flex-col h-full max-w-4xl mx-auto p-4 bg-white shadow-lg rounded-lg">
      {/* Connection Status Header */}
      <div className="flex justify-between items-center mb-4 pb-2 border-b">
        <h2 className="text-xl font-bold text-gray-800">Local AI Chat</h2>
        <div className="flex items-center gap-2">
          <span className={`w-3 h-3 rounded-full ${
            status === 'connected' ? 'bg-green-500' : 
            status === 'connecting' ? 'bg-yellow-500' : 'bg-red-500'
          }`}></span>
          <span className="text-sm text-gray-600 capitalize">{status}</span>
          {status === 'error' && (
            <button 
              onClick={checkConnection}
              className="text-xs bg-blue-500 text-white px-2 py-1 rounded hover:bg-blue-600"
            >
              Retry
            </button>
          )}
        </div>
      </div>

      {/* Chat Log Area */}
      <div className="flex-1 overflow-y-auto space-y-4 mb-4 p-2 bg-gray-50 rounded min-h-[300px] max-h-[500px]">
        {messages.length === 0 && (
          <div className="text-center text-gray-400 mt-10">
            Start a conversation with your local model.
          </div>
        )}
        
        {messages.map((msg, index) => (
          <div key={index} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
            <div className={`max-w-[80%] p-3 rounded-lg ${
              msg.role === 'user' 
                ? 'bg-blue-600 text-white rounded-br-none' 
                : 'bg-gray-200 text-gray-800 rounded-bl-none'
            }`}>
              <p className="whitespace-pre-wrap text-sm">{msg.content || 'Thinking...'}</p>
            </div>
          </div>
        ))}
        <div ref={chatEndRef} />
      </div>

      {/* Input Area */}
      <form onSubmit={handleSubmit} className="flex gap-2">
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          disabled={status !== 'connected' || isLoading}
          placeholder={
            status === 'connected' 
              ? 'Type your message...' 
              : 'Waiting for local Ollama service...'
          }
          className="flex-1 p-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 disabled:bg-gray-100"
        />
        <button
          type="submit"
          disabled={status !== 'connected' || isLoading || !input.trim()}
          className="px-6 py-3 bg-blue-600 text-white rounded-lg font-semibold hover:bg-blue-700 disabled:bg-gray-400 disabled:cursor-not-allowed transition-colors"
        >
          {isLoading ? 'Generating...' : 'Send'}
        </button>
      </form>
    </div>
  );
}
