/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState, useRef, useEffect } from 'react';

// Define the shape of a message in our chat
interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  isPending?: boolean; // Flag for the temporary placeholder
}

export const LocalChat: React.FC = () => {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  
  // Ref to store the AbortController for the current request
  const abortControllerRef = useRef<AbortController | null>(null);

  // Function to handle streaming response
  const streamResponse = async (userMessage: Message, tempMessageId: string) => {
    try {
      const response = await fetch('http://localhost:11434/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          model: 'llama2', // Assuming a default model
          messages: [{ role: 'user', content: userMessage.content }],
          stream: true, // Crucial for streaming
        }),
        signal: abortControllerRef.current?.signal,
      });

      if (!response.ok) throw new Error('API Error');

      const reader = response.body?.getReader();
      if (!reader) throw new Error('No readable stream');

      const decoder = new TextDecoder();
      let accumulatedContent = '';

      // Read the stream
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        const chunk = decoder.decode(value, { stream: true });
        const lines = chunk.split('\n').filter(line => line.trim() !== '');

        for (const line of lines) {
          try {
            const data = JSON.parse(line);
            if (data.message && data.message.content) {
              accumulatedContent += data.message.content;
              
              // Update state: Replace the temporary placeholder with new content
              setMessages(prev => prev.map(msg => 
                msg.id === tempMessageId 
                  ? { ...msg, content: accumulatedContent, isPending: true } 
                  : msg
              ));
            }
          } catch (e) {
            // Ignore JSON parse errors for incomplete lines
          }
        }
      }

      // Finalize: Remove pending flag
      setMessages(prev => prev.map(msg => 
        msg.id === tempMessageId ? { ...msg, isPending: false } : msg
      ));

    } catch (error) {
      if (error.name === 'AbortError') {
        console.log('Request aborted');
      } else {
        // Revert optimistic updates on error
        setMessages(prev => prev.filter(msg => msg.id !== tempMessageId));
        alert('Error: Could not connect to Ollama. Ensure it is running on localhost:11434.');
      }
    } finally {
      setIsLoading(false);
    }
  };

  const handleSend = async () => {
    if (!input.trim() || isLoading) return;

    const userMsgId = `user-${Date.now()}`;
    const tempMsgId = `ai-${Date.now()}`;
    
    // 1. Optimistic UI: Add User Message immediately
    const userMsg: Message = { id: userMsgId, role: 'user', content: input };
    const tempMsg: Message = { id: tempMsgId, role: 'assistant', content: '...', isPending: true };

    setMessages(prev => [...prev, userMsg, tempMsg]);
    setInput('');
    setIsLoading(true);

    // 2. Start background fetch
    await streamResponse(userMsg, tempMsgId);
  };

  const handleAbort = () => {
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
      setIsLoading(false);
    }
  };

  // Initialize AbortController on mount or request start
  useEffect(() => {
    abortControllerRef.current = new AbortController();
    return () => abortControllerRef.current?.abort();
  }, []);

  return (
    <div style={{ padding: '20px', maxWidth: '600px', margin: '0 auto' }}>
      <div style={{ border: '1px solid #ccc', height: '400px', overflowY: 'scroll', padding: '10px', marginBottom: '10px' }}>
        {messages.map(msg => (
          <div key={msg.id} style={{ textAlign: msg.role === 'user' ? 'right' : 'left', marginBottom: '8px' }}>
            <span style={{ 
              background: msg.role === 'user' ? '#007bff' : '#e9ecef', 
              color: msg.role === 'user' ? 'white' : 'black',
              padding: '8px 12px', 
              borderRadius: '12px',
              display: 'inline-block',
              opacity: msg.isPending ? 0.7 : 1
            }}>
              {msg.content}
            </span>
          </div>
        ))}
      </div>
      
      <div style={{ display: 'flex', gap: '10px' }}>
        <input 
          type="text" 
          value={input} 
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && handleSend()}
          style={{ flex: 1, padding: '8px' }}
          placeholder="Type a message..."
          disabled={isLoading}
        />
        {isLoading ? (
          <button onClick={handleAbort} style={{ background: '#dc3545', color: 'white', border: 'none', padding: '8px 16px' }}>Stop</button>
        ) : (
          <button onClick={handleSend} style={{ background: '#28a745', color: 'white', border: 'none', padding: '8px 16px' }}>Send</button>
        )}
      </div>
    </div>
  );
};
