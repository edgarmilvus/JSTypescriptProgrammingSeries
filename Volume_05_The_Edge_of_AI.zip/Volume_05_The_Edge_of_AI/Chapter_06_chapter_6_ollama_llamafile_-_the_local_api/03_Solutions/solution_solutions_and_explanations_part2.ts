/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

import { useState, useRef } from 'react';

// Define the shape of the metrics returned by the hook
interface InferenceMetrics {
  duration: number; // in seconds
  isWarmStart: boolean;
  tokensPerSecond: number;
  totalTokens: number;
}

// Define the callback type for the inference logic
type InferenceCallback = () => Promise<string>;

export const useInferenceMetrics = () => {
  const [metrics, setMetrics] = useState<InferenceMetrics | null>(null);
  const [isMeasuring, setIsMeasuring] = useState(false);

  // Store the baseline "cold start" duration (initial request)
  // We use useRef to persist this across renders without triggering re-renders
  const coldStartBaselineRef = useRef<number | null>(null);

  const measure = async (inferenceFn: InferenceCallback): Promise<string> => {
    setIsMeasuring(true);
    const startTime = performance.now();
    
    let result = '';
    let errorOccurred = false;

    try {
      // Execute the actual inference (fetch call)
      result = await inferenceFn();
    } catch (error) {
      errorOccurred = true;
      throw error;
    } finally {
      const endTime = performance.now();
      setIsMeasuring(false);

      if (!errorOccurred) {
        const durationSec = (endTime - startTime) / 1000;
        const tokenCount = result.length; // Approximation (character count)
        
        // Calculate Tokens Per Second (TPS)
        // Note: Real TPS usually counts tokens, but we approximate with chars/4 for this exercise
        const estimatedTokens = Math.floor(tokenCount / 4); 
        const tps = estimatedTokens / durationSec;

        // Warm Start Logic
        let isWarmStart = false;
        
        if (coldStartBaselineRef.current === null) {
          // This is the first request (Cold Start)
          coldStartBaselineRef.current = durationSec;
        } else {
          // Check if current duration is significantly lower than baseline
          // Threshold: < 50% of the initial cold start time
          if (durationSec < (coldStartBaselineRef.current * 0.5)) {
            isWarmStart = true;
          }
        }

        setMetrics({
          duration: durationSec,
          isWarmStart,
          tokensPerSecond: tps,
          totalTokens: estimatedTokens
        });
      }
    }

    return result;
  };

  return { measure, metrics, isMeasuring };
};

// --- Usage Example in a Component ---
/*
import { useInferenceMetrics } from './useInferenceMetrics';

const PerformanceDashboard = () => {
  const { measure, metrics, isMeasuring } = useInferenceMetrics();

  const handleRun = async () => {
    const callback = async () => {
      const res = await fetch('http://localhost:11434/api/chat', {
        method: 'POST',
        body: JSON.stringify({ model: 'llama2', messages: [{role: 'user', content: 'Hello'}], stream: false })
      });
      const data = await res.json();
      return data.message.content;
    };

    try {
      await measure(callback);
    } catch (e) {
      console.error(e);
    }
  };

  return (
    <div>
      <button onClick={handleRun} disabled={isMeasuring}>
        {isMeasuring ? 'Measuring...' : 'Run Inference'}
      </button>
      {metrics && (
        <div style={{ marginTop: '10px', border: '1px solid #ccc', padding: '10px' }}>
          <h3>Performance Dashboard</h3>
          <p>Duration: {metrics.duration.toFixed(2)}s</p>
          <p>TPS: {metrics.tokensPerSecond.toFixed(2)}</p>
          <p>Status: <strong style={{ color: metrics.isWarmStart ? 'green' : 'orange' }}>
            {metrics.isWarmStart ? 'WARM START' : 'COLD START'}
          </strong></p>
        </div>
      )}
    </div>
  );
};
*/
