/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState, useEffect, useRef } from 'react';

interface Model {
  name: string;
  details: any;
}

export const ModelSelector: React.FC = () => {
  const [models, setModels] = useState<Model[]>([]);
  const [selectedModel, setSelectedModel] = useState<string>('llama2');
  const [isSwitching, setIsSwitching] = useState(false);
  
  // We need a way to signal the chat component to abort
  // In a real app, this might be a context or global state manager
  // For this exercise, we simulate the abort logic here
  const abortControllerRef = useRef<AbortController | null>(null);

  // 1. Fetch available models
  useEffect(() => {
    const fetchModels = async () => {
      try {
        const res = await fetch('http://localhost:11434/api/tags');
        const data = await res.json();
        setModels(data.models || []);
      } catch (err) {
        console.error("Failed to fetch models", err);
      }
    };
    fetchModels();
  }, []);

  // 2. Handle Model Switch
  const handleModelSwitch = async (newModelName: string) => {
    if (newModelName === selectedModel) return;

    setIsSwitching(true);
    console.log(`Switching model from ${selectedModel} to ${newModelName}...`);

    // CRITICAL: Abort existing request
    if (abortControllerRef.current) {
      console.log("Aborting active inference stream...");
      abortControllerRef.current.abort();
      
      // Wait a tick to ensure the abort signal propagates and cleanup happens
      await new Promise(resolve => setTimeout(resolve, 50));
    }

    // 3. Reconcile State
    // In a real chat app, you would clear the chat history or append a system message here
    // e.g., setMessages([]) or setMessages(prev => [...prev, { role: 'system', content: 'Model switched to ' + newModelName }]);
    console.log("State reconciled: Active streams cleared.");

    // 4. Update State
    setSelectedModel(newModelName);
    
    // Create a new AbortController for the next request
    abortControllerRef.current = new AbortController();
    
    setIsSwitching(false);
  };

  // Helper to simulate a chat request (so we can demonstrate aborting it)
  const simulateChatRequest = async () => {
    if (!abortControllerRef.current) {
      abortControllerRef.current = new AbortController();
    }

    console.log(`Sending request to ${selectedModel}...`);
    
    try {
      const res = await fetch('http://localhost:11434/api/chat', {
        method: 'POST',
        body: JSON.stringify({
          model: selectedModel,
          messages: [{ role: 'user', content: 'Why is the sky blue?' }],
          stream: true
        }),
        signal: abortControllerRef.current.signal
      });

      if (!res.body) return;
      
      const reader = res.body.getReader();
      while (true) {
        const { done } = await reader.read();
        if (done) break;
        // Simulate processing
      }
      console.log("Request completed successfully.");
    } catch (error) {
      if (error.name === 'AbortError') {
        console.warn("Request was aborted by user action (Model Switch).");
      } else {
        console.error("Request failed:", error);
      }
    }
  };

  return (
    <div style={{ padding: '20px' }}>
      <h3>Model Management</h3>
      
      <div style={{ marginBottom: '10px' }}>
        <label>Current Model: </label>
        <select 
          value={selectedModel} 
          onChange={(e) => handleModelSwitch(e.target.value)}
          disabled={isSwitching}
        >
          {models.length > 0 ? (
            models.map(m => <option key={m.name} value={m.name}>{m.name}</option>)
          ) : (
            <option>Loading models...</option>
          )}
        </select>
        {isSwitching && <span style={{ color: 'orange', marginLeft: '10px' }}>Switching...</span>}
      </div>

      <div style={{ marginTop: '20px', border: '1px solid #ddd', padding: '10px' }}>
        <h4>Simulate Chat</h4>
        <p>Current Model: <strong>{selectedModel}</strong></p>
        <button onClick={simulateChatRequest} disabled={isSwitching}>
          Send Test Prompt
        </button>
        <p style={{ fontSize: '0.8em', color: 'gray' }}>
          (Open Console to see abort logs. Click "Send Test Prompt", then switch models immediately to see Abort logic in action).
        </p>
      </div>
    </div>
  );
};
