/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

// InferenceEngine.ts

// Define the supported backends
type BackendType = 'webgpu' | 'wasm';

// Unified interface for the engine
interface InferenceEngine {
  backend: BackendType;
  initialize: () => Promise<void>;
  runInference: (prompt: string) => Promise<string>;
}

// Mock implementation of a Transformer Library (e.g., Transformers.js)
// This represents the external library we would import
const MockTransformerLib = {
  setBackend: async (backend: BackendType) => {
    console.log(`[Lib] Configuring backend: ${backend.toUpperCase()}`);
    // Simulate async loading of weights
    await new Promise(r => setTimeout(r, 500)); 
  },
  generate: async (prompt: string): Promise<string> => {
    // Simulate inference delay
    await new Promise(r => setTimeout(r, 200));
    return `Generated response via backend using prompt: ${prompt}`;
  }
};

export class WebGPUOrchestrator implements InferenceEngine {
  public backend: BackendType = 'wasm'; // Default

  /**
   * Detects WebGPU support and initializes the appropriate backend.
   */
  async initialize(): Promise<void> {
    // 1. Feature Detection
    if (typeof window !== 'undefined' && (window as any).navigator?.gpu) {
      this.backend = 'webgpu';
      console.log("✅ WebGPU is supported.");
    } else {
      this.backend = 'wasm';
      console.warn("⚠️ WebGPU not supported. Falling back to WASM.");
    }

    // 2. Configuration
    await MockTransformerLib.setBackend(this.backend);
  }

  /**
   * Generic inference function abstracting the backend.
   */
  async runInference(prompt: string): Promise<string> {
    if (!this.backend) {
      throw new Error("Engine not initialized. Call initialize() first.");
    }

    // The application logic doesn't care which backend is running
    const result = await MockTransformerLib.generate(prompt);
    
    // Append backend info for demonstration
    return `[Backend: ${this.backend.toUpperCase()}] ${result}`;
  }
}

/**
 * MEMORY MANAGEMENT & WARM START EXPLANATION:
 * 
 * 1. WebGPU (GPU Memory):
 *    - Model weights are loaded into VRAM (Video RAM) on the graphics card.
 *    - Warm Start: Extremely fast. Once weights are in VRAM, they stay there as long as 
 *      the browser context or GPU process is alive. Subsequent inferences just utilize 
 *      the existing memory pointers.
 *    - Cold Start: Slow. Requires PCIe transfer of gigabytes of data from System RAM to VRAM.
 * 
 * 2. WASM (CPU Memory):
 *    - Model weights are loaded into System RAM.
 *    - Warm Start: Moderate. The data is in RAM, but the CPU must still execute matrix 
 *      multiplications serially or with limited SIMD instructions.
 *    - Cold Start: Slow. Requires loading from disk to RAM.
 * 
 * The "Warm Start" definition in Exercise 2 (duration < 50% of baseline) is valid for both, 
 * but the *magnitude* of the speedup will be much more drastic for WebGPU cold-to-warm transitions 
 * due to the massive bandwidth difference between PCIe (GPU load) and System Bus (CPU load).
 */

// Usage Example:
/*
const engine = new WebGPUOrchestrator();

async function app() {
  await engine.initialize();
  const response = await engine.runInference("Explain quantum physics.");
  console.log(response);
}
*/
