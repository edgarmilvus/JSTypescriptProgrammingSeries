/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

// RequestQueue.ts

interface QueuedRequest {
  prompt: string;
  resolve: (value: string) => void;
  reject: (reason?: any) => void;
}

export class RequestQueue {
  private queue: QueuedRequest[] = [];
  private isProcessing = false;
  private bufferWindow: number; // ms to wait for batching
  private batchSize: number;

  constructor(bufferWindow: number = 100, batchSize: number = 3) {
    this.bufferWindow = bufferWindow;
    this.batchSize = batchSize;
  }

  /**
   * Enqueues a request. Returns a Promise that resolves with the inference result.
   */
  public enqueue(prompt: string): Promise<string> {
    return new Promise((resolve, reject) => {
      this.queue.push({ prompt, resolve, reject });
      
      // Trigger processing logic if not already running
      if (!this.isProcessing) {
        this.processQueue();
      }
    });
  }

  private async processQueue() {
    if (this.queue.length === 0) {
      this.isProcessing = false;
      return;
    }

    this.isProcessing = true;

    // 1. Buffering Logic (Simulation of Batching)
    // Wait for the buffer window to see if more requests arrive
    await new Promise(resolve => setTimeout(resolve, this.bufferWindow));

    // 2. Batch Construction
    // Grab up to 'batchSize' items from the front of the queue
    const batch: QueuedRequest[] = [];
    while (this.queue.length > 0 && batch.length < this.batchSize) {
      batch.push(this.queue.shift()!);
    }

    // 3. Concurrency Control & Execution
    // We only allow one "batch" to be processed at a time.
    // In a real Ollama scenario, we cannot send a batch of different prompts to the standard /api/chat
    // endpoint efficiently. We would usually loop here or send to a specific batch endpoint.
    // For this simulation, we will process the batch sequentially but "as a group" 
    // (simulating that the overhead of waking up the model is shared).
    
    console.log(`[Queue] Processing batch of ${batch.length} items...`);
    
    try {
      // SIMULATION: In reality, you would construct a payload containing the array of prompts.
      // Here, we simulate the result for the example.
      const simulatedBatchResult = await this.mockOllamaBatchCall(batch.map(b => b.prompt));

      // Distribute results back to the original callers
      batch.forEach((req, index) => {
        // In a real batch, we might map index to result
        req.resolve(simulatedBatchResult); 
      });
    } catch (error) {
      // If the batch fails, reject all in the batch
      batch.forEach(req => req.reject(error));
    }

    // 4. Recursive Drain
    // If more items arrived during processing, continue
    await this.processQueue();
  }

  /**
   * MOCK: Represents the actual fetch call to Ollama.
   * In a real scenario, this would be a fetch() with a body containing an array of messages.
   */
  private async mockOllamaBatchCall(prompts: string[]): Promise<string> {
    // Simulate network latency + inference time
    await new Promise(r => setTimeout(r, 500));
    return `Batch processed ${prompts.length} prompts. Result: [Mocked Data]`;
  }
}

/**
 * TEST SCENARIO COMMENTARY:
 * 
 * Naive Approach:
 * User types "Hello" -> Fetch 1 (Takes 2s)
 * User types "How are you?" -> Fetch 2 (Takes 2s)
 * User types "Tell me a joke" -> Fetch 3 (Takes 2s)
 * Total Time: 6 seconds. 
 * Overhead: 3 separate TCP handshakes, 3 model wake-ups (if sleeping).
 * 
 * Queue Approach (Buffer 100ms, Batch 3):
 * T=0ms: "Hello" enqueued. Queue starts processing.
 * T=100ms: Buffer window closes. Batch = ["Hello"].
 * T=500ms: "How are you?" arrives (during processing).
 * T=600ms: "Tell me a joke" arrives (during processing).
 * T=1000ms: "Hello" finishes. Queue sees new items.
 * T=1100ms: Buffer window closes. Batch = ["How are you?", "Tell me a joke"].
 * T=1600ms: Batch finishes.
 * Total Time: ~1.6 seconds.
 * 
 * Benefit: Reduced context switching overhead and fewer model loads, 
 * significantly improving perceived responsiveness under heavy load.
 */
