/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

// src/ollama-langchain-basic.ts

import { OllamaEmbeddings } from "@langchain/community/embeddings/ollama";
import { Ollama } from "@langchain/community/llms/ollama";
import { MemoryVectorStore } from "langchain/vectorstores/memory";
import { Document } from "langchain/document";

/**
 * 1. CONFIGURATION & INITIALIZATION
 * --------------------------------------------------
 * We configure the Ollama client to connect to the local instance.
 * 'nomic-embed-text' is a lightweight model suitable for semantic search.
 * 'llama3.1' is used here for text generation (optional for this specific retrieval example,
 * but included to show the full LLM integration).
 */
const embeddings = new OllamaEmbeddings({
  model: "nomic-embed-text",
  baseUrl: "http://localhost:11434", // Default Ollama port
});

const llm = new Ollama({
  model: "llama3.1",
  baseUrl: "http://localhost:11434",
});

/**
 * 2. DATA PREPARATION (SIMULATED DATABASE)
 * --------------------------------------------------
 * In a real SaaS app, this data would come from a database (PostgreSQL, MongoDB).
 * We create an array of Documents. Each document contains page content (text)
 * and metadata (useful for filtering).
 */
const documents: Document[] = [
  new Document({
    pageContent: "The QuickStart Pro running shoes feature advanced cushioning technology for long-distance runners.",
    metadata: { category: "Footwear", price: 120, id: "prod_001" },
  }),
  new Document({
    pageContent: "Ergonomic wireless mouse designed for productivity, with customizable buttons and long battery life.",
    metadata: { category: "Electronics", price: 45, id: "prod_002" },
  }),
  new Document({
    pageContent: "Organic cotton t-shirt, breathable and sustainable, available in multiple colors.",
    metadata: { category: "Apparel", price: 25, id: "prod_003" },
  }),
  new Document({
    pageContent: "Noise-cancelling over-ear headphones with immersive sound quality and 20-hour battery life.",
    metadata: { category: "Electronics", price: 299, id: "prod_004" },
  }),
];

/**
 * 3. CORE LOGIC: SEMANTIC SEARCH
 * --------------------------------------------------
 * This function simulates an API route handler (e.g., Next.js API Route).
 * It performs the following steps:
 * a. Loads documents into a vector store.
 * b. Embeds the user query.
 * c. Performs similarity search.
 * d. Returns the results.
 *
 * @param query - The user's natural language search string.
 * @returns Promise<Document[]> - The top matching documents.
 */
async function searchProducts(query: string): Promise<Document[]> {
  console.log(`\n[1] Processing Query: "${query}"`);

  // Step A: Initialize Vector Store with in-memory storage
  // In production, use Pinecone, Weaviate, or pgvector.
  const vectorStore = await MemoryVectorStore.fromDocuments(
    documents,
    embeddings
  );

  // Step B: Perform Similarity Search (k=2 returns top 2 results)
  // This internally calls the Ollama embedding API to vectorize the query,
  // then calculates cosine similarity against stored vectors.
  const searchResults = await vectorStore.similaritySearch(query, 2);

  console.log(`[2] Found ${searchResults.length} relevant documents.`);
  
  return searchResults;
}

/**
 * 4. GENERATION: AUGMENTING RETRIEVAL
 * --------------------------------------------------
 * This function demonstrates how to pass the retrieved context to an LLM
 * to generate a natural language response (RAG - Retrieval Augmented Generation).
 *
 * @param query - The original user question.
 * @param context - The documents retrieved from the vector store.
 */
async function generateResponse(query: string, context: Document[]) {
  // Format context into a single string for the LLM
  const contextText = context
    .map((doc) => `Product: ${doc.pageContent} (Price: $${doc.metadata.price})`)
    .join("\n");

  const prompt = `
    User Question: ${query}
    
    Context Products:
    ${contextText}
    
    Based on the context above, recommend the best product for the user.
    Be concise and friendly.
  `;

  console.log(`\n[3] Generating response with LLM...`);
  
  // Call the local LLM
  const response = await llm.invoke(prompt);
  
  return response;
}

/**
 * 5. EXECUTION (SIMULATED REQUEST)
 * --------------------------------------------------
 * Main entry point to run the example.
 */
async function main() {
  try {
    const userQuery = "I need shoes for running marathons";
    
    // Step 1: Retrieve
    const relevantDocs = await searchProducts(userQuery);
    
    // Step 2: Generate
    const aiResponse = await generateResponse(userQuery, relevantDocs);
    
    console.log("\n=== FINAL RESULT ===");
    console.log("Recommended Product:", aiResponse);
    console.log("====================\n");
    
  } catch (error) {
    console.error("Error during execution:", error);
  }
}

// Execute the main function
main();
