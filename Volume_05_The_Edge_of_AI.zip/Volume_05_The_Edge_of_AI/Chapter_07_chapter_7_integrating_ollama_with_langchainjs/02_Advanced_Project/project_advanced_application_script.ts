/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

'use server';

import { NextRequest } from 'next/server';
import { createClient } from '@supabase/supabase-js';
import { OllamaEmbeddings } from '@langchain/community/embeddings/ollama';
import { Ollama } from '@langchain/community/llms/ollama';
import { PromptTemplate } from '@langchain/core/prompts';
import { Document } from '@langchain/core/documents';

// ============================================================================
// 1. CONFIGURATION & TYPE DEFINITIONS
// ============================================================================

// Environment variables (ensure these are set in your .env.local file)
const SUPABASE_URL = process.env.SUPABASE_URL!;
const SUPABASE_SERVICE_KEY = process.env.SUPABASE_SERVICE_KEY!;
const OLLAMA_HOST = process.env.OLLAMA_HOST || 'http://localhost:11434';

// Initialize Supabase client for pgvector operations
const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_KEY, {
  auth: { persistSession: false }, // Server-side only
});

/**
 * Defines the structure of a document stored in our pgvector database.
 * The 'embedding' field is a vector array (e.g., float32[]).
 */
interface DbDocument {
  id: string;
  content: string;
  embedding: number[];
  metadata: Record<string, any>;
}

/**
 * Defines the expected response shape from the server action.
 */
export interface SearchResult {
  answer: string;
  sources: string[];
  processingTime: number;
}

// ============================================================================
// 2. EMBEDDING GENERATION & VECTOR SEARCH
// ============================================================================

/**
 * Generates a vector embedding for a given text query using Ollama.
 * We use the 'nomic-embed-text' model as it offers excellent performance
 * for semantic search and is lightweight enough for local execution.
 */
async function generateEmbedding(text: string): Promise<number[]> {
  const embeddings = new OllamaEmbeddings({
    model: 'nomic-embed-text',
    baseUrl: OLLAMA_HOST,
    // Optimization: Lower dimensionality models (768d) are faster to index
    // but ensure your pgvector column matches the model's output dimension.
  });

  // Under the hood: This sends a request to the local Ollama API
  // /api/embeddings endpoint, returning a high-dimensional vector.
  const vector = await embeddings.embedQuery(text);
  return vector;
}

/**
 * Performs a semantic search against the Supabase 'documents' table.
 * Uses the pgvector extension (<-> operator) for cosine similarity.
 */
async function semanticSearch(queryEmbedding: number[], limit: number = 3) {
  // Note: The 'documents' table must have a column 'embedding' of type 'vector(768)'
  // and a trigger to auto-generate embeddings on insert.
  const { data: documents, error } = await supabase
    .rpc('match_documents', { // Using a Supabase RPC function for cleaner queries
      query_embedding: queryEmbedding,
      match_threshold: 0.78, // Cosine similarity threshold (0 to 1)
      match_count: limit,
    });

  if (error) {
    console.error('pgvector search error:', error);
    throw new Error('Failed to retrieve documents from vector database.');
  }

  return documents as DbDocument[];
}

// ============================================================================
// 3. RETRIEVAL AUGMENTED GENERATION (RAG) CHAIN
// ============================================================================

/**
 * Orchestrates the LLM inference using Ollama with retrieved context.
 * This function constructs a dynamic prompt and queries the local LLM.
 */
async function generateResponse(query: string, contextDocs: DbDocument[]): Promise<string> {
  // 1. Prepare the context string from retrieved documents
  const context = contextDocs.map(doc => doc.content).join('\n\n---\n\n');
  
  // 2. Define a robust prompt template for RAG
  const ragPrompt = new PromptTemplate({
    template: `
      You are an AI assistant designed to answer questions based strictly on the provided context.
      If the answer is not found in the context, state clearly that you do not know.
      
      Context:
      {context}
      
      Question: {question}
      
      Answer:
    `,
    inputVariables: ['context', 'question'],
  });

  // 3. Initialize Ollama LLM
  // Optimization: We use 'llama2' (7B) for speed. For better quality, use 'llama3'.
  // 'temperature: 0' ensures deterministic outputs for factual retrieval.
  const llm = new Ollama({
    baseUrl: OLLAMA_HOST,
    model: 'llama2',
    temperature: 0,
    // GPU Acceleration: If WebGPU or CUDA is configured locally, 
    // Ollama handles this automatically. No JS code changes needed.
  });

  // 4. Format the prompt
  const formattedPrompt = await ragPrompt.format({
    context: context,
    question: query,
  });

  // 5. Invoke the model
  // Under the hood: This streams tokens from the local Ollama API /api/generate endpoint.
  const response = await llm.invoke(formattedPrompt);

  return response;
}

// ============================================================================
// 4. SERVER ACTION (ENTRY POINT)
// ============================================================================

/**
 * Server Action: Handles the full RAG pipeline.
 * 
 * @param prevState - Used by useFormState (not utilized here for simplicity).
 * @param formData - FormData object containing the 'query' input.
 * @returns Promise<SearchResult>
 */
export async function performRagSearch(
  prevState: any,
  formData: FormData
): Promise<SearchResult> {
  const startTime = performance.now();
  const query = formData.get('query') as string;

  if (!query || query.trim().length === 0) {
    throw new Error('Query cannot be empty.');
  }

  try {
    // Step 1: Convert text query to vector
    const queryEmbedding = await generateEmbedding(query);

    // Step 2: Retrieve relevant documents from pgvector
    const relevantDocs = await semanticSearch(queryEmbedding, 3);

    if (relevantDocs.length === 0) {
      return {
        answer: "I couldn't find any relevant information in the database.",
        sources: [],
        processingTime: performance.now() - startTime,
      };
    }

    // Step 3: Generate answer using Ollama with context
    const answer = await generateResponse(query, relevantDocs);

    const endTime = performance.now();

    return {
      answer: answer,
      sources: relevantDocs.map(d => d.content.substring(0, 100) + '...'), // Preview
      processingTime: endTime - startTime,
    };
  } catch (error) {
    console.error('RAG Pipeline Error:', error);
    throw new Error('An error occurred during processing.');
  }
}
