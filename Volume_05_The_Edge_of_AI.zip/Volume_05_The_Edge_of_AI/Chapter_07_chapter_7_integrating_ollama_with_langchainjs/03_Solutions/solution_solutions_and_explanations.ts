/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// utils/ragPipeline.ts
// Note: In a real Next.js app, heavy operations like embedding generation 
// should ideally happen in Server Components/Actions to avoid blocking the UI thread.
// This solution demonstrates the logic for a purely client-side implementation.

import { OllamaEmbeddings } from "@langchain/ollama";
import { RecursiveCharacterTextSplitter } from "langchain/text_splitter";

// 1. Define the structure of our stored data
interface DocumentChunk {
  text: string;
  embedding: number[];
  index: number; // To track original order for clustering
}

// 2. State management (simulated store)
let documentStore: DocumentChunk[] = [];

// 3. Document Ingestion & Embedding Generation
export async function ingestDocument(rawText: string) {
  // Initialize Ollama Embeddings (using nomic-embed-text as requested)
  const embeddings = new OllamaEmbeddings({
    model: "nomic-embed-text",
    baseUrl: "http://localhost:11434",
  });

  // Split text into chunks
  const splitter = new RecursiveCharacterTextSplitter({
    chunkSize: 500,
    chunkOverlap: 50,
  });

  const docs = await splitter.createDocuments([rawText]);

  // Generate embeddings for each chunk
  // Note: In a real app, use Promise.all with caution to avoid overwhelming Ollama
  const chunks: DocumentChunk[] = [];
  for (let i = 0; i < docs.length; i++) {
    const embedding = await embeddings.embedQuery(docs[i].pageContent);
    chunks.push({
      text: docs[i].pageContent,
      embedding: embedding,
      index: i,
    });
  }

  documentStore = chunks;
  return chunks.length;
}

// 4. Semantic Search (Cosine Similarity)
function cosineSimilarity(vecA: number[], vecB: number[]): number {
  const dotProduct = vecA.reduce((acc, val, i) => acc + val * vecB[i], 0);
  const magA = Math.sqrt(vecA.reduce((acc, val) => acc + val * val, 0));
  const magB = Math.sqrt(vecB.reduce((acc, val) => acc + val * val, 0));
  return dotProduct / (magA * magB);
}

// 5. Sliding Window / Clustering Search
export async function searchClusters(query: string, k: number = 3) {
  if (documentStore.length === 0) throw new Error("No document ingested.");

  const embeddings = new OllamaEmbeddings({
    model: "nomic-embed-text",
    baseUrl: "http://localhost:11434",
  });

  const queryEmbedding = await embeddings.embedQuery(query);

  // Calculate scores
  const scoredChunks = documentStore.map(chunk => ({
    ...chunk,
    score: cosineSimilarity(queryEmbedding, chunk.embedding),
  }));

  // Sort by relevance
  scoredChunks.sort((a, b) => b.score - a.score);

  // CLUSTERING LOGIC:
  // Instead of taking top k, we take top k * windowSize, then group consecutive indices.
  // This simulates retrieving coherent blocks.
  const topCandidates = scoredChunks.slice(0, k * 3); // Grab a wider pool
  
  // Sort candidates by original document index to find sequences
  topCandidates.sort((a, b) => a.index - b.index);

  const clusters: { start: number; end: number; text: string }[] = [];
  let currentCluster: DocumentChunk[] = [];

  for (const chunk of topCandidates) {
    if (currentCluster.length === 0) {
      currentCluster.push(chunk);
    } else {
      const lastChunk = currentCluster[currentCluster.length - 1];
      // If consecutive (gap of 1 or 0 overlap), add to cluster
      if (chunk.index - lastChunk.index <= 2) {
        currentCluster.push(chunk);
      } else {
        // Close current cluster
        clusters.push({
          start: currentCluster[0].index,
          end: currentCluster[currentCluster.length - 1].index,
          text: currentCluster.map(c => c.text).join(" "),
        });
        currentCluster = [chunk];
      }
    }
  }
  
  // Push final cluster
  if (currentCluster.length > 0) {
    clusters.push({
      start: currentCluster[0].index,
      end: currentCluster[currentCluster.length - 1].index,
      text: currentCluster.map(c => c.text).join(" "),
    });
  }

  // Return top k clusters by combined score or just the first k found
  return clusters.slice(0, k);
}

// 6. Response Generation
export async function generateRagResponse(query: string, contextChunks: string[]) {
  const { Ollama } = await import("@langchain/ollama");
  
  const llm = new Ollama({
    model: "llama3.2",
    baseUrl: "http://localhost:11434",
  });

  const context = contextChunks.join("\n\n");
  
  const prompt = `
    Context: ${context}
    
    Question: ${query}
    
    Answer the question based ONLY on the provided context. 
    If the context does not contain the answer, say "I don't know based on the provided context."
    Be concise.
  `;

  return await llm.invoke(prompt);
}
