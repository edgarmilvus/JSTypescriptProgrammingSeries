/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

// components/StreamComponent.tsx
"use client";

import { useReducer, useRef } from "react";

interface State {
  output: string;
  isLoading: boolean;
  error: string | null;
}

type Action =
  | { type: "START" }
  | { type: "APPEND"; payload: string }
  | { type: "FINISH" }
  | { type: "ERROR"; payload: string };

const initialState: State = {
  output: "",
  isLoading: false,
  error: null,
};

function reducer(state: State, action: Action): State {
  switch (action.type) {
    case "START":
      return { ...state, isLoading: true, output: "", error: null };
    case "APPEND":
      // IMMUTABLE UPDATE: Create a new string
      return { ...state, output: state.output + action.payload };
    case "FINISH":
      return { ...state, isLoading: false };
    case "ERROR":
      return { ...state, isLoading: false, error: action.payload };
    default:
      return state;
  }
}

export default function StreamComponent() {
  const [state, dispatch] = useReducer(reducer, initialState);
  const abortControllerRef = useRef<AbortController | null>(null);

  const handleStream = async (prompt: string) => {
    dispatch({ type: "START" });
    
    // Initialize AbortController for cancellation
    abortControllerRef.current = new AbortController();
    const signal = abortControllerRef.current.signal;

    try {
      // Call the Server Action
      const response = await fetch("/api/generate-stream", {
        method: "POST",
        body: JSON.stringify({ prompt }),
        signal, // Attach abort signal
      });

      if (!response.body) return;

      const reader = response.body.getReader();
      const decoder = new TextDecoder();

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        
        const textChunk = decoder.decode(value);
        dispatch({ type: "APPEND", payload: textChunk });
      }

      dispatch({ type: "FINISH" });
    } catch (error: any) {
      if (error.name === "AbortError") {
        dispatch({ type: "ERROR", payload: "Request cancelled." });
      } else {
        dispatch({ type: "ERROR", payload: error.message });
      }
    }
  };

  const handleCancel = () => {
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
    }
  };

  return (
    <div>
      <button onClick={() => handleStream("Tell me a story")}>
        Generate
      </button>
      <button onClick={handleCancel} disabled={!state.isLoading}>
        Cancel
      </button>
      {state.isLoading && <span>Thinking...</span>}
      {state.error && <div className="text-red-500">{state.error}</div>}
      <div>{state.output}</div>
    </div>
  );
}
