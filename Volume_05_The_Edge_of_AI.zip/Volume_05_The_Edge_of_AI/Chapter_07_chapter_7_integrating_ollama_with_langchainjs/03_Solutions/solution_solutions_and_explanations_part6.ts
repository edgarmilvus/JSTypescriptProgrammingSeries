/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part6.ts
// Description: Solutions and Explanations
// ==========================================

// components/StructuredExtractor.tsx
"use client";

import { useState } from "react";
import { extractData } from "@/app/actions/extractData";
import { z } from "zod";

// Define the Zod schema for validation
const extractionSchema = z.object({
  sentiment: z.enum(["positive", "negative", "neutral"]),
  rating: z.number().min(1).max(5),
  topics: z.array(z.string()),
});

type ExtractionResult = z.infer<typeof extractionSchema>;

export default function StructuredExtractor() {
  const [input, setInput] = useState("");
  const [result, setResult] = useState<ExtractionResult | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [useValidation, setUseValidation] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);
    setResult(null);

    try {
      const actionResult = await extractData(input);

      if (!actionResult.success) {
        setError(actionResult.error || "Unknown error");
        return;
      }

      // Parse the JSON string returned by the model
      const parsed = JSON.parse(actionResult.data);

      // Optional Client-Side Schema Validation
      if (useValidation) {
        const validation = extractionSchema.safeParse(parsed);
        if (!validation.success) {
          setError("Model Hallucination Detected: Schema validation failed.");
          console.error(validation.error);
          return;
        }
        setResult(validation.data);
      } else {
        // Basic type assertion if not validating
        setResult(parsed as ExtractionResult);
      }
    } catch (err) {
      setError("Failed to parse JSON from model.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-md mx-auto p-4 border rounded shadow">
      <h2 className="text-xl font-bold mb-4">Structured Extractor</h2>
      
      <form onSubmit={handleSubmit} className="flex flex-col gap-3">
        <textarea
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Paste product review here..."
          rows={4}
          className="border p-2 rounded"
          disabled={loading}
        />
        
        <label className="flex items-center gap-2">
          <input 
            type="checkbox" 
            checked={useValidation}
            onChange={(e) => setUseValidation(e.target.checked)}
          />
          <span>Enable Zod Schema Validation</span>
        </label>

        <button 
          type="submit" 
          disabled={loading || !input}
          className="bg-blue-600 text-white py-2 rounded disabled:bg-gray-400"
        >
          {loading ? "Extracting..." : "Extract Data"}
        </button>
      </form>

      {error && (
        <div className="mt-4 p-2 bg-red-100 text-red-700 border border-red-300 rounded">
          {error}
        </div>
      )}

      {result && (
        <div className="mt-4 p-3 bg-green-50 border border-green-200 rounded">
          <h3 className="font-semibold text-green-800">Result:</h3>
          <div className="text-sm text-green-700 mt-1">
            <p><strong>Sentiment:</strong> {result.sentiment}</p>
            <p><strong>Rating:</strong> {result.rating}/5</p>
            <p><strong>Topics:</strong> {result.topics.join(", ")}</p>
          </div>
        </div>
      )}
    </div>
  );
}
