/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part7.ts
// Description: Solutions and Explanations
// ==========================================

// utils/embeddingOptimizer.ts
import { OllamaEmbeddings } from "@langchain/ollama";

// 1. Simple LRU Cache Implementation
class LRUCache {
  private cache: Map<string, number[]>;
  private capacity: number;

  constructor(capacity: number) {
    this.cache = new Map();
    this.capacity = capacity;
  }

  get(key: string): number[] | undefined {
    if (!this.cache.has(key)) return undefined;
    
    const value = this.cache.get(key)!;
    // Update position (most recently used)
    this.cache.delete(key);
    this.cache.set(key, value);
    return value;
  }

  put(key: string, value: number[]) {
    if (this.cache.has(key)) {
      this.cache.delete(key);
    } else if (this.cache.size >= this.capacity) {
      // Remove least recently used (first item in Map)
      const firstKey = this.cache.keys().next().value;
      this.cache.delete(firstKey);
    }
    this.cache.set(key, value);
  }
}

// Initialize cache (limit 100 entries)
const embeddingCache = new LRUCache(100);

// 2. Batching & Parallel Execution
export async function batchEmbedQueries(queries: string[]) {
  const embeddings = new OllamaEmbeddings({
    model: "nomic-embed-text",
    baseUrl: "http://localhost:11434",
  });

  const uncachedQueries: string[] = [];
  const results: Record<string, number[]> = {};

  // Check cache first
  queries.forEach((q) => {
    const cached = embeddingCache.get(q);
    if (cached) {
      results[q] = cached;
    } else {
      uncachedQueries.push(q);
    }
  });

  // If there are uncached queries, fetch them in parallel
  if (uncachedQueries.length > 0) {
    // Note: LangChain's embedDocuments typically handles batching internally,
    // but for manual Promise.all control:
    const promises = uncachedQueries.map((q) => 
      embeddings.embedQuery(q)
        .then((vec) => {
          embeddingCache.put(q, vec); // Cache the result
          return { q, vec };
        })
    );

    // Execute all in parallel
    const newResults = await Promise.all(promises);

    newResults.forEach(({ q, vec }) => {
      results[q] = vec;
    });
  }

  return results;
}

// 3. Benchmarking Function
export async function benchmarkEmbeddings(queries: string[]) {
  const embeddings = new OllamaEmbeddings({
    model: "nomic-embed-text",
    baseUrl: "http://localhost:11434",
  });

  // Clear cache for a fair test of "Cached" vs "Uncached"
  embeddingCache.cache.clear();

  // 1. Sequential
  const startSeq = performance.now();
  for (const q of queries) {
    await embeddings.embedQuery(q);
  }
  const endSeq = performance.now();

  // 2. Parallel (Promise.all)
  const startPar = performance.now();
  await Promise.all(queries.map(q => embeddings.embedQuery(q)));
  const endPar = performance.now();

  // 3. Cached (Run again immediately)
  const startCache = performance.now();
  for (const q of queries) {
    embeddingCache.get(q); // Should be instant
  }
  const endCache = performance.now();

  return {
    sequential: endSeq - startSeq,
    parallel: endPar - startPar,
    cached: endCache - startCache,
  };
}
