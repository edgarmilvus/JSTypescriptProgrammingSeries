/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// pages/api/assist/code.ts
// Next.js API Route for the Smart Code Assistant

import type { NextApiRequest, NextApiResponse } from 'next';

/**
 * Types and Interfaces
 * --------------------
 * Defining the strict contract for our API.
 */

// The expected shape of the incoming request payload
interface CodeRequest {
  prompt: string;
  domain: 'general' | 'internal-ui' | 'data-modeling';
}

// The shape of the response returned by the Ollama API
interface OllamaResponse {
  response: string;
  done: boolean;
}

// The structured output of our assistant
interface AssistantOutput {
  code: string;
  domain: string;
  metadata: {
    model: string;
    tokensUsed: number;
    source: 'fine-tuned' | 'few-shot';
  };
}

/**
 * Constants & Configuration
 * -------------------------
 * Configuration for the local LLM instance.
 */
const OLLAMA_ENDPOINT = process.env.OLLAMA_API_URL || 'http://localhost:11434/api/generate';
const MODEL_NAME = 'codellama:7b'; // Base model
const ADAPTER_NAME = 'internal-ui-lora'; // Simulated LoRA adapter name

/**
 * FEW-SHOT EXAMPLES
 * -----------------
 * High-quality examples used to guide the model without fine-tuning.
 * In a real scenario, these would be retrieved from a vector database or injected dynamically.
 */
const FEW_SHOT_PROMPTS = {
  'internal-ui': `
    // Example of how to use the internal 'XButton' component:
    import { XButton } from '@internal/ui';
    
    export default function Page() {
      return (
        <XButton variant="primary" onClick={() => alert('Clicked')}>
          Submit
        </XButton>
      );
    }
    
    // Task: Generate a login form using 'XButton' and 'XInput'.
  `,
  'data-modeling': `
    // Example of defining a Prisma schema for a User:
    model User {
      id        Int      @id @default(autoincrement())
      email     String   @unique
      createdAt DateTime @default(now())
    }
    
    // Task: Generate a schema for a 'Post' related to the User.
  `
};

/**
 * CORE LOGIC BLOCKS
 * -----------------
 */

/**
 * 1. Type Narrowing & Validation
 * ------------------------------
 * Uses a Type Guard to narrow unknown input to a specific CodeRequest.
 * This prevents runtime errors by ensuring the data structure is correct before processing.
 */
function isCodeRequest(payload: unknown): payload is CodeRequest {
  const req = payload as CodeRequest;
  return (
    typeof req === 'object' &&
    req !== null &&
    typeof req.prompt === 'string' &&
    ['general', 'internal-ui', 'data-modeling'].includes(req.domain)
  );
}

/**
 * 2. Prompt Engineering (Few-Shot & Context)
 * ------------------------------------------
 * Constructs the final prompt sent to the LLM.
 * This simulates the "Fine-Tuning" effect by providing context in the prompt window.
 */
function buildSystemPrompt(domain: CodeRequest['domain']): string {
  const baseSystem = `You are an expert TypeScript code generator. Output ONLY valid TypeScript code. No explanations.`;

  // If the domain has specific examples, inject them (Few-Shot Prompting)
  if (domain !== 'general' && FEW_SHOT_PROMPTS[domain]) {
    return `${baseSystem}\n\nHere are examples of the expected code style:\n${FEW_SHOT_PROMPTS[domain]}`;
  }

  return baseSystem;
}

/**
 * 3. LLM Interaction (Simulating Fine-Tuned Inference)
 * -----------------------------------------------------
 * Calls the local Ollama instance. 
 * In a real deployment, passing the 'adapter' parameter would load the LoRA weights.
 */
async function callLocalLLM(prompt: string, domain: CodeRequest['domain']): Promise<string> {
  const systemPrompt = buildSystemPrompt(domain);
  const fullPrompt = `${systemPrompt}\n\nUser Request: ${prompt}\n\nGenerated Code:`;

  try {
    const response = await fetch(OLLAMA_ENDPOINT, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model: MODEL_NAME,
        prompt: fullPrompt,
        stream: false,
        // SIMULATION: In Ollama, you can pass 'adapter' for LoRA.
        // Here we log it to demonstrate the concept.
        options: { 
          adapter: domain !== 'general' ? ADAPTER_NAME : undefined 
        }
      }),
    });

    if (!response.ok) {
      throw new Error(`Ollama error: ${response.statusText}`);
    }

    const data: OllamaResponse = await response.json();
    return data.response.trim();
  } catch (error) {
    console.error("LLM Call Failed:", error);
    throw new Error("Failed to generate code.");
  }
}

/**
 * 4. Conditional Edge Logic
 * --------------------------
 * A simplified state machine to route logic based on the domain.
 * This mimics a LangGraph Conditional Edge where the next step depends on the state.
 */
async function executeDomainWorkflow(domain: CodeRequest['domain'], prompt: string): Promise<string> {
  // State: 'general' -> Route to standard inference
  if (domain === 'general') {
    return callLocalLLM(prompt, 'general');
  }

  // State: 'internal-ui' -> Route to fine-tuned adapter simulation
  if (domain === 'internal-ui') {
    // In a real graph, this might branch to a "Validation Node" specific to UI
    return callLocalLLM(prompt, 'internal-ui');
  }

  // State: 'data-modeling' -> Route to database schema logic
  if (domain === 'data-modeling') {
    // In a real graph, this might branch to a "SQL Generation Node"
    return callLocalLLM(prompt, 'data-modeling');
  }

  // Fallback
  return "// Error: Domain not recognized.";
}

/**
 * API HANDLER
 * -----------
 * Main entry point for the Next.js route.
 */
export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse<AssistantOutput | { error: string }>
) {
  // Only allow POST requests
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method Not Allowed' });
  }

  try {
    // 1. Type Narrowing Check
    if (!isCodeRequest(req.body)) {
      // The compiler narrows req.body to 'never' inside this block if we didn't return,
      // but we return early to handle the runtime error.
      return res.status(400).json({ error: 'Invalid request payload structure.' });
    }

    const { prompt, domain } = req.body;

    // 2. Execute Conditional Workflow
    // This routes the request based on the domain "state"
    const generatedCode = await executeDomainWorkflow(domain, prompt);

    // 3. Construct Response
    const result: AssistantOutput = {
      code: generatedCode,
      domain: domain,
      metadata: {
        model: MODEL_NAME,
        tokensUsed: generatedCode.length, // Approximation
        source: domain === 'general' ? 'few-shot' : 'fine-tuned'
      }
    };

    // 4. Return JSON
    res.status(200).json(result);

  } catch (error) {
    // Global Error Handling
    console.error(error);
    res.status(500).json({ error: 'Internal Server Error during code generation.' });
  }
}
