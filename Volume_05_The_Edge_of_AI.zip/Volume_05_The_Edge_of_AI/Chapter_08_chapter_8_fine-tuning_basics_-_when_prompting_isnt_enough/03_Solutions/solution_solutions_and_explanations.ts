/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

import fs from 'fs/promises';
import path from 'path';
import { createWriteStream } from 'fs';
import { Readable } from 'stream';

/**
 * Processes a directory of Markdown files to generate a JSONL dataset.
 * 
 * @param inputDir - Directory containing .md files.
 * @param outputFile - Path for the output .jsonl file.
 * @param contextFileName - Optional filename for context (e.g., 'context.txt').
 */
async function createDataset(
    inputDir: string, 
    outputFile: string, 
    contextFileName: string = 'context.txt'
) {
    const writeStream = createWriteStream(outputFile);
    const files = await fs.readdir(inputDir);
    const mdFiles = files.filter(f => f.endsWith('.md'));
    
    // Check for context file once
    let contextContent = '';
    const contextPath = path.join(inputDir, contextFileName);
    try {
        contextContent = await fs.readFile(contextPath, 'utf-8');
    } catch {
        // Context file is optional
    }

    console.log(`Processing ${mdFiles.length} files...`);

    for (const file of mdFiles) {
        const filePath = path.join(inputDir, file);
        try {
            const content = await fs.readFile(filePath, 'utf-8');
            
            // Format: filename (without extension) becomes the instruction
            const instruction = path.parse(file).name.replace(/-/g, ' ');
            
            const jsonLine = JSON.stringify({
                instruction: instruction,
                input: contextContent, // Empty string if context file missing
                output: content
            });

            // Write line to stream
            await new Promise<void>((resolve, reject) => {
                writeStream.write(jsonLine + '\n', (err) => {
                    if (err) reject(err);
                    else resolve();
                });
            });
            
            console.log(`Processed: ${file}`);
        } catch (error) {
            console.error(`Error processing file ${file}:`, error);
            // Skip file and continue
        }
    }

    writeStream.end();
    console.log(`Dataset created at ${outputFile}`);
}

// Usage Example (assuming files exist in './docs')
// createDataset('./docs', 'training_data.jsonl');
