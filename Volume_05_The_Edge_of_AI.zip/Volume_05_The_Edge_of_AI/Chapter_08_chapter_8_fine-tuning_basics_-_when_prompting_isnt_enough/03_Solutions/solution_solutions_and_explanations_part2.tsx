/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.tsx
// Description: Solutions and Explanations
// ==========================================

'use client';

import { useState, useEffect, useRef } from 'react';
import { getTrainingLogs, stopTraining } from './actions'; // Assume these Server Actions exist

// --- Server Action Simulation (Conceptual) ---
// export async function getTrainingLogs(jobId: string) { ... }
// export async function stopTraining(jobId: string) { ... }

export default function TrainingStatus({ jobId }: { jobId: string }) {
  const [logs, setLogs] = useState<string[]>([]);
  const [status, setStatus] = useState<'running' | 'terminating' | 'stopped'>('running');
  const logsEndRef = useRef<HTMLDivElement>(null);

  // Scroll to bottom effect
  useEffect(() => {
    logsEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [logs]);

  // Streaming Effect
  useEffect(() => {
    if (status !== 'running') return;

    let isMounted = true;

    const streamLogs = async () => {
      try {
        const stream = await getTrainingLogs(jobId);
        for await (const chunk of stream) {
          if (!isMounted) break;
          setLogs((prev) => [...prev, chunk]);
        }
      } catch (error) {
        console.error("Stream error:", error);
      }
    };

    streamLogs();

    return () => {
      isMounted = false;
    };
  }, [jobId, status]);

  const handleStop = async () => {
    setStatus('terminating');
    await stopTraining(jobId);
    // The stream loop will naturally break when the server closes the connection
    setStatus('stopped');
  };

  return (
    <div className="border rounded p-4 max-h-64 flex flex-col">
      <div className="flex justify-between items-center mb-2">
        <h3 className="font-bold">Training Logs (Job: {jobId})</h3>
        <button 
          onClick={handleStop}
          disabled={status !== 'running'}
          className={`px-3 py-1 rounded text-white text-sm ${status === 'running' ? 'bg-red-500 hover:bg-red-600' : 'bg-gray-400 cursor-not-allowed'}`}
        >
          {status === 'running' ? 'Stop Training' : 'Terminating...'}
        </button>
      </div>
      
      <div className="flex-1 overflow-y-auto border rounded p-2 bg-gray-50 font-mono text-sm">
        {logs.length === 0 && status === 'running' && (
           <div className="text-gray-500">Initializing training...</div>
        )}
        {logs.map((log, i) => (
          <div key={i}>{log}</div>
        ))}
        <div ref={logsEndRef} />
      </div>
      
      <div className="mt-2 text-xs text-gray-500">
        Status: {status === 'running' ? 'Active' : 'Terminated'}
      </div>
    </div>
  );
}
