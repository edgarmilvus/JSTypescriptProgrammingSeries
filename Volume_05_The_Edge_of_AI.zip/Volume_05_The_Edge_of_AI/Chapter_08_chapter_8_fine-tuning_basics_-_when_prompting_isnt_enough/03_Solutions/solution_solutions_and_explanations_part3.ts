/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

import { AutoModelForCausalLM, AutoTokenizer } from '@huggingface/transformers';

// Global cache for the base model to enable hot-swapping
let loadedModel: any = null;
let loadedTokenizer: any = null;

/**
 * Loads the base model and tokenizer once.
 * Caches them in memory for subsequent adapter swaps.
 */
async function initializeBaseModel(modelId: string) {
    if (!loadedModel) {
        console.log(`Loading base model: ${modelId}...`);
        loadedTokenizer = await AutoTokenizer.from_pretrained(modelId);
        loadedModel = await AutoModelForCausalLM.from_pretrained(modelId, {
            // Quantization settings usually go here
            quantized: true 
        });
    }
    return { model: loadedModel, tokenizer: loadedTokenizer };
}

/**
 * Applies LoRA weights to the model.
 * Note: Transformers.js specific API usage may vary by version.
 * This simulates the logic of merging or applying adapter weights.
 */
async function applyAdapter(model: any, adapterUrl: string) {
    console.log(`Applying adapter from: ${adapterUrl}`);
    // In a real scenario, fetch the .safetensors file, parse it,
    // and update specific layer weights (e.g., 'q_proj.lora_A', 'v_proj.lora_B').
    // For this exercise, we simulate the update.
    
    // Example of how one might iterate layers (pseudo-code):
    /*
    for (const [name, param] of model.named_parameters()) {
        if (name.includes('lora')) {
            // Load new weights into param.data
        }
    }
    */
    
    // Simulating a delay for network fetch/merge
    await new Promise(r => setTimeout(r, 500));
    console.log("Adapter applied successfully.");
}

/**
 * Hot-swap function: Replaces the current adapter with a new one.
 * Only reloads the adapter weights, not the base model.
 */
export async function swapAdapter(newAdapterUrl: string) {
    if (!loadedModel) {
        throw new Error("Base model not loaded. Call initializeBaseModel first.");
    }
    await applyAdapter(loadedModel, newAdapterUrl);
}

/**
 * Main pipeline: Load base, apply adapter, run inference.
 */
export async function runFineTunedInference(baseModelId: string, adapterUrl: string, prompt: string) {
    // 1. Load Base (Cached)
    const { model, tokenizer } = await initializeBaseModel(baseModelId);

    // 2. Apply Adapter (Hot-swappable)
    await swapAdapter(adapterUrl);

    // 3. Generate
    console.log(`Generating for prompt: "${prompt}"`);
    const inputs = tokenizer(prompt);
    const output = await model.generate(inputs, {
        max_new_tokens: 20,
        do_sample: true,
    });
    
    const decoded = tokenizer.decode(output[0], { skip_special_tokens: true });
    console.log("Output:", decoded);
    return decoded;
}

// Usage Example:
// runFineTunedInference('Xenova/Phi-3-mini-4k-instruct', 'https://example.com/lora.safetensors', 'The capital of France is');
