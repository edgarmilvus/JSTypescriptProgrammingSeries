/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

import yargs from 'yargs';
import { hideBin } from 'yargs/helpers';

interface TrainingConfig {
    modelSizeGB: number;
    batchSize: number;
    seqLength: number;
    quantizationBits: 4 | 8;
}

/**
 * Estimates VRAM usage in GB.
 * Formula: (Quantized Weights) + (Gradients/Optimizer) + (Activations)
 */
function calculateVRAM(config: TrainingConfig): number {
    const { modelSizeGB, batchSize, seqLength, quantizationBits } = config;

    // 1. Quantized Model Weights
    // Base size * (bits / 8 bytes)
    const weightMemory = modelSizeGB * (quantizationBits / 8);

    // 2. Gradients & Optimizer States (LoRA overhead)
    // Approx 20% of base model size for LoRA parameters + Adam states
    const loraOverhead = weightMemory * 0.20;

    // 3. Activations (Batch Size * Seq Length * Model Size factor)
    // This is a rough approximation for transformer memory requirements
    const activationFactor = 0.0005; // Tuned for rough estimation
    const activationMemory = batchSize * seqLength * activationFactor;

    return weightMemory + loraOverhead + activationMemory;
}

function generateModelfile(config: TrainingConfig, vramLimitGB: number): string {
    // Adjust parameters if exceeding limit
    let adjustedConfig = { ...config };
    let warnings: string[] = [];

    if (calculateVRAM(adjustedConfig) > vramLimitGB) {
        // Strategy: Reduce Batch Size first (safest for convergence)
        while (calculateVRAM(adjustedConfig) > vramLimitGB && adjustedConfig.batchSize > 1) {
            adjustedConfig.batchSize--;
            warnings.push(`Reduced batch size to ${adjustedConfig.batchSize}`);
        }
        
        // If still over limit, reduce context length
        if (calculateVRAM(adjustedConfig) > vramLimitGB) {
            while (calculateVRAM(adjustedConfig) > vramLimitGB && adjustedConfig.seqLength > 256) {
                adjustedConfig.seqLength = Math.floor(adjustedConfig.seqLength / 2);
                warnings.push(`Reduced context length to ${adjustedConfig.seqLength}`);
            }
        }
    }

    const finalVram = calculateVRAM(adjustedConfig);
    
    return `
# Ollama Modelfile for QLoRA
# Estimated VRAM Usage: ${finalVram.toFixed(2)} GB
# Warnings: ${warnings.join(', ') || 'None'}

FROM ${adjustedConfig.quantizationBits === 4 ? 'hf.co/bartowski/Llama-3.2-1B-Instruct-GGUF' : 'base-model.gguf'}

# Training Parameters
PARAMETER num_epochs 3
PARAMETER learning_rate 0.0002
PARAMETER batch_size ${adjustedConfig.batchSize}
PARAMETER context_length ${adjustedConfig.seqLength}
PARAMETER lora_r 8
PARAMETER lora_alpha 16

# System Prompt (Optional)
SYSTEM "You are a helpful assistant."
`;
}

// CLI Logic using yargs
yargs(hideBin(process.argv))
    .command('generate', 'Generate Modelfile based on constraints', {
        modelSize: { type: 'number', demandOption: true, describe: 'Base model size in GB' },
        batchSize: { type: 'number', default: 4 },
        seqLength: { type: 'number', default: 2048 },
        vramLimit: { type: 'number', default: 6.0, describe: 'Max VRAM in GB' },
        quant: { choices: [4, 8] as const, default: 4 }
    }, (args) => {
        const config: TrainingConfig = {
            modelSizeGB: args.modelSize,
            batchSize: args.batchSize,
            seqLength: args.seqLength,
            quantizationBits: args.quant
        };

        console.log(`Calculating VRAM for config:`, config);
        const estimated = calculateVRAM(config);
        console.log(`Estimated VRAM: ${estimated.toFixed(2)} GB`);

        const modelfile = generateModelfile(config, args.vramLimit);
        console.log("\n--- Generated Modelfile ---");
        console.log(modelfile);
    })
    .parse();
