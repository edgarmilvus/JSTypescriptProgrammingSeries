/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

import { StateGraph, Annotation, END, START } from '@langchain/langgraph';

// 1. State Definition
const StateAnnotation = Annotation.Root({
    logs: Annotation<string[]>({
        reducer: (curr, update) => [...curr, ...update],
        default: () => [],
    }),
    iteration_count: Annotation<number>({
        reducer: (curr, update) => curr + update,
        default: () => 0,
    }),
    status: Annotation<'running' | 'finished' | 'failed'>({
        reducer: (curr, update) => update,
        default: () => 'running',
    }),
});

// 2. Nodes
const analyzeLogs = async (state: typeof StateAnnotation.State) => {
    console.log(`[Node] Analyzing logs... Iteration: ${state.iteration_count}`);
    
    // Simulate checking logs for errors
    const hasOOMError = state.logs.some(log => log.includes("CUDA out of memory"));
    
    if (hasOOMError) {
        console.log("Detected OOM Error. Triggering adjustment.");
        return { 
            logs: ["Error detected: CUDA out of memory"], 
            status: 'running' 
        };
    } else {
        console.log("No errors detected. Finishing.");
        return { status: 'finished' };
    }
};

const adjustHyperparameters = async (state: typeof StateAnnotation.State) => {
    console.log(`[Node] Adjusting hyperparameters...`);
    // Simulate adjustment logic (e.g., lowering learning rate)
    return { 
        logs: ["Adjusted batch size to 2"], 
        iteration_count: 1 // Increment counter
    };
};

const terminateNode = async (state: typeof StateAnnotation.State) => {
    console.log(`[Node] Max iterations reached. Terminating.`);
    return { status: 'failed' };
};

// 3. Conditional Edge (Max Iteration Policy)
const shouldContinue = (state: typeof StateAnnotation.State) => {
    // Policy: If iteration count >= 5, stop.
    if (state.iteration_count >= 5) {
        return 'terminate_node';
    }
    
    // If status is finished, stop.
    if (state.status === 'finished') {
        return END;
    }

    // Otherwise, continue the loop
    return 'adjust_hyperparameters';
};

// 4. Graph Construction
const workflow = new StateGraph(StateAnnotation)
    .addNode('analyze_logs', analyzeLogs)
    .addNode('adjust_hyperparameters', adjustHyperparameters)
    .addNode('terminate_node', terminateNode)

    // Entry point
    .addEdge(START, 'analyze_logs')

    // Conditional edges from analysis
    .addConditionalEdges(
        'analyze_logs',
        should_continue,
        {
            'adjust_hyperparameters': 'adjust_hyperparameters',
            'terminate_node': 'terminate_node',
            [END]: END
        }
    )

    // Loop back to analysis after adjustment
    .addEdge('adjust_hyperparameters', 'analyze_logs');

// Compile the graph
export const app = workflow.compile();

// --- Execution Simulation ---
async function runDebugger() {
    // Initial state: Logs contain an OOM error
    const initialLogs = ["Epoch 1 started...", "CUDA out of memory at step 5"];
    
    const inputs = { 
        logs: initialLogs,
        iteration_count: 0,
        status: 'running'
    };

    console.log("--- Starting LangGraph Workflow ---");
    
    // Stream execution
    for await (const snapshot of await app.stream(inputs, { recursionLimit: 10 })) {
        const nodeName = Object.keys(snapshot)[0];
        const nodeState = snapshot[nodeName];
        
        if (nodeName !== '__end__') {
            console.log(`\n--- Step: ${nodeName} ---`);
            console.log("State:", nodeState);
        }
        
        if (nodeState.status === 'failed' || nodeState.status === 'finished') {
            console.log(`\nWorkflow ended with status: ${nodeState.status}`);
            break;
        }
    }
}

// To run: uncomment below
// runDebugger();
