/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script_part2.ts
// Description: Advanced Application Script
// ==========================================

/**
 * synthetic-data-generator.ts
 * 
 * A TypeScript script demonstrating an advanced synthetic data generation pipeline.
 * It uses a simulated ReAct loop to iteratively generate and refine instruction-response
 * pairs suitable for fine-tuning local models (e.g., Ollama).
 * 
 * Context: Chapter 9 - Generating Synthetic Data for Fine-Tuning
 */

import fs from 'fs/promises';
import path from 'path';

// --- TYPE DEFINITIONS ---

/**
 * Represents a single synthetic data point.
 * Structure is optimized for instruction-tuning formats (e.g., Alpaca, ShareGPT).
 */
interface SyntheticDataPoint {
  instruction: string;
  input?: string; // Optional context for the instruction
  output: string; // The desired model response
  category: string;
}

/**
 * State management for the ReAct loop.
 * Tracks the iteration count and quality validation status.
 */
interface GenerationState {
  attempts: number;
  maxAttempts: number;
  dataset: SyntheticDataPoint[];
  isQualitySatisfied: boolean;
}

// --- MOCK LLM CLIENT (SIMULATING TEACHER MODEL) ---

/**
 * Mocks a call to a large Teacher Model (e.g., GPT-4).
 * In a real scenario, this would use the OpenAI SDK or a local Ollama endpoint.
 * 
 * @param prompt - The system instruction for data generation.
 * @returns A promise resolving to a JSON string of synthetic data.
 */
async function callTeacherModel(prompt: string): Promise<string> {
  console.log(`[Teacher Model] Generating with prompt length: ${prompt.length} chars...`);
  
  // Simulating network latency
  await new Promise(resolve => setTimeout(resolve, 800));

  // Mock Response: Simulating a structured JSON output from the LLM
  // In reality, we would parse the raw text response.
  const mockResponse: SyntheticDataPoint[] = [
    {
      instruction: "Explain the concept of 'WebGPU' to a 5-year-old.",
      output: "Imagine your computer has a super fast drawing helper called WebGPU. It helps the browser draw games and pictures really, really quickly, like magic!",
      category: "Technical Explanation"
    },
    {
      instruction: "Write a Python function to calculate the Fibonacci sequence.",
      input: "Use recursion.",
      output: "