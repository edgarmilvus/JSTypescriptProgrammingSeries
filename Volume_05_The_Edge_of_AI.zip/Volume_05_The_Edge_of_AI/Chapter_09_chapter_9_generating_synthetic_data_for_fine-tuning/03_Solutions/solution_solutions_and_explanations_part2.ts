/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

// pipeline.ts
import { StateGraph, END, Annotation } from '@langchain/langgraph';
import { SyntheticData, SyntheticDataSchema } from './types'; 

// 1. Define the GraphState using LangGraph's Annotation
const GraphState = Annotation.Root({
  topic: Annotation<string>({
    reducer: (state, update) => update, // Replace strategy
    default: () => "",
  }),
  rawLLMOutput: Annotation<string>({
    reducer: (state, update) => update,
    default: () => "",
  }),
  validatedData: Annotation<SyntheticData | null>({
    reducer: (state, update) => update,
    default: () => null,
  }),
  status: Annotation<string>({
    reducer: (state, update) => update,
    default: () => "idle",
  }),
});

// 2. Initialize the StateGraph
const workflow = new StateGraph(GraphState);

// 3. Define the nodes
async function generateNode(state: typeof GraphState.State): Promise<Partial<typeof GraphState.State>> {
  // Simulate LLM call returning a hardcoded JSON string
  const mockLLMResponse = JSON.stringify({
    instruction: `Generate a fact about ${state.topic}.`,
    output: `${state.topic} is fascinating.`,
    category: "reasoning",
    difficulty: 2
  });
  
  return { 
    rawLLMOutput: mockLLMResponse, 
    status: "generating" 
  };
}

function validateNode(state: typeof GraphState.State): Partial<typeof GraphState.State> {
  // Simulate validation logic (assuming validateAndParse is imported)
  // For this example, we manually parse to keep it self-contained
  try {
    const data = JSON.parse(state.rawLLMOutput);
    const validated = SyntheticDataSchema.parse(data);
    return { 
      validatedData: validated, 
      status: "validating" 
    };
  } catch (e) {
    return { 
      validatedData: null, 
      status: "validation_failed" 
    };
  }
}

function formatNode(state: typeof GraphState.State): Partial<typeof GraphState.State> {
  if (!state.validatedData) {
    return { status: "formatting_failed" };
  }
  
  const formattedString = `### Instruction: ${state.validatedData.instruction}\n### Response: ${state.validatedData.output}`;
  
  // In a real app, we might save this string, but here we just update status
  console.log("Formatted Output:", formattedString);
  
  return { status: "completed" };
}

// 4. Define edges and compile
workflow.addNode("generateNode", generateNode);
workflow.addNode("validateNode", validateNode);
workflow.addNode("formatNode", formatNode);

workflow.setStartPoint("generateNode");
workflow.addEdge("generateNode", "validateNode");
workflow.addEdge("validateNode", "formatNode");
workflow.addEdge("formatNode", END);

// 5. Compile the graph
export const graph = workflow.compile();
