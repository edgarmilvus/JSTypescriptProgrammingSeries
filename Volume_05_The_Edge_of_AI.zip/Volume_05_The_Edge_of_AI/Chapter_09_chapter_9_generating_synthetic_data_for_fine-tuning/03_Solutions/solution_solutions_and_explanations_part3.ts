/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

// interactive-gate.ts
import { validateAndParse, SyntheticData } from './types';

// Helper to simulate delay
const sleep = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

// 1. Implement the generateAndProcess function
async function generateAndProcess(topic: string): Promise<{ success: boolean; data: SyntheticData | null; attempts: number }> {
  let attempts = 0;
  const maxRetries = 3;

  while (attempts < maxRetries) {
    attempts++;
    console.log(`Attempt ${attempts} for topic: "${topic}"`);

    // Step 1: Simulate teacher model output (Randomly valid or invalid)
    let rawOutput: string;
    const random = Math.random();

    if (random < 0.4) {
      // 40% chance: Valid JSON
      rawOutput = JSON.stringify({
        instruction: `Analyze ${topic}`,
        output: `Analysis of ${topic}: It is complex.`,
        category: "reasoning",
        difficulty: 3
      });
    } else if (random < 0.7) {
      // 30% chance: Valid JSON but missing fields
      rawOutput = JSON.stringify({
        instruction: `Incomplete task about ${topic}`,
        category: "reasoning"
        // Missing 'output' field
      });
    } else {
      // 30% chance: Malformed JSON
      rawOutput = "{ malformed json ";
    }

    // Step 2: Attempt to parse and validate
    const result = validateAndParse(rawOutput);

    if (result !== null) {
      // Success
      return {
        success: true,
        data: result,
        attempts: attempts
      };
    }

    // Step 3: Retry logic (if not the last attempt)
    if (attempts < maxRetries) {
      console.log("Validation failed. Retrying in 1 second...");
      await sleep(1000);
    }
  }

  // Failed after all retries
  return {
    success: false,
    data: null,
    attempts: attempts
  };
}

// 3. Test case
async function test() {
  console.log("--- Starting Interactive Gate Test ---");
  const result = await generateAndProcess("Quantum Computing Basics");
  console.log("\n--- Final Result ---");
  console.log(result);
}

// Run the test
test();
