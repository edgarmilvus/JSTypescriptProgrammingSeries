/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.tsx
// Description: Solutions and Explanations
// ==========================================

// DatasetViewer.tsx
import React, { useState, useMemo } from 'react';
import { SyntheticData } from './types';

interface DatasetViewerProps {
  data: SyntheticData[];
}

const DatasetViewer: React.FC<DatasetViewerProps> = ({ data }) => {
  // 2. State for filters
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [minDifficulty, setMinDifficulty] = useState<number>(1);

  // Extract unique categories for the dropdown
  const categories = useMemo(() => {
    const cats = new Set(data.map(item => item.category));
    return ['all', ...Array.from(cats)];
  }, [data]);

  // 3. Logic to filter data based on state
  const filteredData = useMemo(() => {
    return data.filter(item => {
      const matchesCategory = selectedCategory === 'all' || item.category === selectedCategory;
      const matchesDifficulty = item.difficulty >= minDifficulty;
      return matchesCategory && matchesDifficulty;
    });
  }, [data, selectedCategory, minDifficulty]);

  // 1. Render the table and filters
  return (
    <div style={{ padding: '20px', fontFamily: 'sans-serif' }}>
      <h2>Synthetic Dataset Viewer</h2>
      
      {/* Filter Controls */}
      <div style={{ marginBottom: '20px', display: 'flex', gap: '20px', alignItems: 'center' }}>
        <label>
          Category:
          <select 
            value={selectedCategory} 
            onChange={(e) => setSelectedCategory(e.target.value)}
          >
            {categories.map(cat => (
              <option key={cat} value={cat}>{cat}</option>
            ))}
          </select>
        </label>

        <label>
          Min Difficulty ({minDifficulty}):
          <input 
            type="range" 
            min="1" 
            max="5" 
            value={minDifficulty} 
            onChange={(e) => setMinDifficulty(Number(e.target.value))}
            style={{ verticalAlign: 'middle', marginLeft: '8px' }}
          />
        </label>
      </div>

      {/* Data Table */}
      <table border={1} cellPadding={10} style={{ width: '100%', borderCollapse: 'collapse' }}>
        <thead>
          <tr style={{ backgroundColor: '#f4f4f4' }}>
            <th>Instruction</th>
            <th>Category</th>
            <th>Difficulty</th>
          </tr>
        </thead>
        <tbody>
          {filteredData.length > 0 ? (
            filteredData.map((item, index) => (
              <tr key={index}>
                <td>{item.instruction}</td>
                <td>{item.category}</td>
                <td>{item.difficulty}</td>
              </tr>
            ))
          ) : (
            <tr>
              <td colSpan={3} style={{ textAlign: 'center', color: '#666' }}>
                No data matches the current filters.
              </td>
            </tr>
          )}
        </tbody>
      </table>
    </div>
  );
};

export default DatasetViewer;
