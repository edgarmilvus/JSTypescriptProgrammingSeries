/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part6.ts
// Description: Solutions and Explanations
// ==========================================

digraph PipelineFlow {
    rankdir=TB; // Top-to-Bottom layout
    node [shape=box, style=filled, fillcolor="#e0e0e0"];
    
    // Define Nodes
    UserTopic [label="UserTopic\n(Input)", shape=ellipse, fillcolor="#b3d9ff"];
    PromptEngine [label="PromptEngine\n(Construct Prompt)"];
    TeacherModel [label="TeacherModel\n(LLM Generation)", fillcolor="#fff2cc"];
    ValidationGate [label="ValidationGate\n(Zod Schema Check)", shape=diamond, fillcolor="#d5e8d4"];
    RetryLoop [label="Retry Loop\n(Attempts < 3?)", shape=diamond, fillcolor="#ffe6cc"];
    DataStore [label="DataStore\n(Fine-tuning Dataset)", shape=cylinder, fillcolor="#d5e8d4"];
    DeadLetterQueue [label="DeadLetterQueue\n(Failed Data)", shape=cylinder, fillcolor="#f8cecc"];

    // Define Edges
    UserTopic -> PromptEngine [label="Topic"];
    PromptEngine -> TeacherModel [label="Prompt String"];
    TeacherModel -> ValidationGate [label="Raw LLM Output"];
    
    // Validation Logic
    ValidationGate -> RetryLoop [label="Validation Result"];
    
    // Success Path
    RetryLoop -> DataStore [label="Valid"];
    
    // Failure / Retry Path
    RetryLoop -> TeacherModel [label="Invalid\n(Retry)", style=dashed, color=red];
    
    // Exhausted Retries Path
    RetryLoop -> DeadLetterQueue [label="Max Retries\nExceeded", style=dashed, color=red];

    // Styling for clarity
    { rank=same; DataStore; DeadLetterQueue }
}
