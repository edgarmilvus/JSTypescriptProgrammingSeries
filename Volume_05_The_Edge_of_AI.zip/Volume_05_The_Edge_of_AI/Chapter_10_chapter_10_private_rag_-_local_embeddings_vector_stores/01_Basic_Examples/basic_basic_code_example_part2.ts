/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.ts
// Description: Basic Code Example
// ==========================================

/**
 * ============================================================================
 * PART 1: DATA STRUCTURES & STATE MANAGEMENT
 * ============================================================================
 */

/**
 * Represents a single vector embedding with its associated metadata.
 * We use Immutable State Management: once created, the object properties are read-only.
 */
type DocumentChunk = {
  id: string;
  text: string;
  embedding: number[]; // The high-dimensional vector
};

/**
 * A simple in-memory vector store for demonstration.
 * In production, this would be replaced by ChromaDB, LanceDB, or pgvector.
 */
class LocalVectorStore {
  private documents: DocumentChunk[] = [];

  /**
   * Adds a document to the store.
   * Returns a new array (immutability) rather than mutating the existing one.
   */
  async addDocument(text: string, embedding: number[]): Promise<DocumentChunk[]> {
    const newDoc: DocumentChunk = {
      id: `doc_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      text,
      embedding,
    };

    // Create a new array to preserve immutability
    this.documents = [...this.documents, newDoc];
    return this.documents;
  }

  /**
   * Performs a similarity search (Cosine Similarity).
   * @param queryEmbedding - The vector representation of the user's query.
   * @param topK - Number of top results to return.
   * @returns The top K matching documents.
   */
  async search(queryEmbedding: number[], topK: number = 1): Promise<DocumentChunk[]> {
    // Calculate cosine similarity for each document
    const scoredDocs = this.documents.map((doc) => {
      const similarity = cosineSimilarity(queryEmbedding, doc.embedding);
      return { ...doc, score: similarity };
    });

    // Sort by score descending and slice top K
    return scoredDocs
      .sort((a, b) => b.score - a.score)
      .slice(0, topK)
      .map(({ score, ...rest }) => rest); // Remove score from final output
  }
}

/**
 * ============================================================================
 * PART 2: MATH UTILITIES (UNDER THE HOOD)
 * ============================================================================
 */

/**
 * Calculates the cosine similarity between two vectors.
 * Formula: dot(A, B) / (||A|| * ||B||)
 * Used to measure how "close" two vectors are in semantic space.
 */
function cosineSimilarity(vecA: number[], vecB: number[]): number {
  if (vecA.length !== vecB.length) {
    throw new Error('Vectors must be of the same dimension');
  }

  let dotProduct = 0;
  let normA = 0;
  let normB = 0;

  for (let i = 0; i < vecA.length; i++) {
    dotProduct += vecA[i] * vecB[i];
    normA += vecA[i] * vecA[i];
    normB += vecB[i] * vecB[i];
  }

  return dotProduct / (Math.sqrt(normA) * Math.sqrt(normB));
}

/**
 * ============================================================================
 * PART 3: MAIN APPLICATION LOGIC
 * ============================================================================
 */

/**
 * The main entry point of the RAG pipeline.
 */
async function runRagPipeline() {
  console.log('🚀 Initializing Local RAG Pipeline...');

  // 1. Initialize the Embedding Pipeline
  // We use 'Xenova/all-MiniLM-L6-v2' - a small, fast model perfect for browser environments.
  // This downloads the model weights (via WASM) on first run.
  const embedder = await pipeline('feature-extraction', 'Xenova/all-MiniLM-L6-v2');

  // 2. Initialize the Local Vector Store
  const vectorStore = new LocalVectorStore();

  // 3. Ingest Knowledge Base (Simulated Database)
  const knowledgeBase = [
    "Artificial Intelligence is the simulation of human intelligence processes by machines.",
    "Machine Learning is a subset of AI that focuses on training algorithms to learn patterns.",
    "Deep Learning uses neural networks with many layers to analyze various factors of data.",
    "The weather today is sunny and warm, perfect for hiking."
  ];

  console.log('📝 Ingesting documents into local vector store...');
  
  // Generate embeddings for each document and store them
  // Note: We process sequentially for simplicity, but parallel processing is faster.
  for (const text of knowledgeBase) {
    // The embedding model returns a Tensor; we extract the data array.
    const output = await embedder(text, { pooling: 'mean', normalize: true });
    const embedding = Array.from(output.data); // Convert TypedArray to standard Array
    await vectorStore.addDocument(text, embedding);
  }

  // 4. User Query
  const userQuery = "What is AI?";
  console.log(`\n🔍 User Query: "${userQuery}"`);

  // 5. Generate Query Embedding
  console.log('🧠 Generating query embedding...');
  const queryOutput = await embedder(userQuery, { pooling: 'mean', normalize: true });
  const queryEmbedding = Array.from(queryOutput.data);

  // 6. Retrieve Relevant Context
  console.log('🔎 Searching vector store...');
  const relevantDocs = await vectorStore.search(queryEmbedding, 1);

  // 7. Output Results
  console.log('\n✅ Retrieved Context:');
  relevantDocs.forEach((doc, idx) => {
    console.log(`   [${idx + 1}] ${doc.text}`);
  });

  // In a real app, you would now pass this context to a local LLM (via Ollama) 
  // to generate the final answer.
  console.log('\n🏁 Pipeline Complete. Ready for LLM inference.');
}

// Execute the pipeline
// We wrap this in a try-catch to handle network/model loading errors gracefully.
runRagPipeline().catch(console.error);
