/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// /api/rag/query.ts
// Next.js API Route for Local RAG Pipeline
import type { NextApiRequest, NextApiResponse } from 'next';
import { ollama } from 'ollama-ai-provider'; // Assuming a provider wrapper for Ollama
import * as lancedb from '@lancedb/lancedb'; // LanceDB Node.js binding
import * as tf from '@tensorflow/tfjs-node'; // For tensor operations (fallback if needed)
import { WebGPU } from '@tensorflow/tfjs-backend-webgpu'; // WebGPU backend registration

// --- TYPE DEFINITIONS ---

type RagRequest = {
  type: 'ingest' | 'query';
  payload: {
    text?: string; // For ingestion
    metadata?: Record<string, any>; // e.g., { author: 'Smith', category: 'Tech' }
    query?: string; // For querying
    filter?: Record<string, any>; // Metadata filter criteria
    topK?: number; // Number of results to retrieve
  };
};

type RagResponse = {
  message: string;
  data?: {
    context: string[];
    embeddings?: number[][];
    latency?: number;
  };
  error?: string;
};

// --- CONFIGURATION ---

const EMBEDDING_MODEL = 'nomic-embed-text'; // Lightweight embedding model from Ollama
const LANCE_DB_URI = './local_db'; // Local directory for persistence
const TABLE_NAME = 'document_vectors';

// --- UTILITY: WEBGPU INITIALIZATION ---
/**
 * Initializes the WebGPU backend for TensorFlow.js to accelerate tensor operations.
 * This is crucial for performance optimization in local inference scenarios.
 */
async function initWebGPU() {
  if (typeof navigator !== 'undefined' && 'gpu' in navigator) {
    try {
      await tf.setBackend('webgpu');
      await tf.ready();
      console.log('WebGPU backend initialized successfully.');
    } catch (err) {
      console.warn('WebGPU initialization failed, falling back to CPU/WASM:', err);
      await tf.setBackend('wasm'); // Fallback to WASM SIMD
    }
  }
}

// --- CORE LOGIC ---

/**
 * Generates a vector embedding for a given text string using a local Ollama model.
 * @param text - The input text to embed.
 * @returns A Promise resolving to a Float32Array of vector embeddings.
 */
async function generateEmbedding(text: string): Promise<Float32Array> {
  // In a real implementation, we would call the Ollama API directly
  // or use the 'ollama-ai-provider' which abstracts this.
  // For this script, we simulate the response structure.
  
  // NOTE: In a production environment, this call looks like:
  // const response = await ollama.embeddings({ model: EMBEDDING_MODEL, prompt: text });
  // return new Float32Array(response.embedding);
  
  // SIMULATION: Returning a dummy vector for demonstration purposes (1536 dimensions)
  // This ensures the script runs conceptually without a running Ollama instance.
  const vector = new Float32Array(1536);
  for (let i = 0; i < vector.length; i++) {
    vector[i] = Math.random(); // Simulating normalized vector data
  }
  return vector;
}

/**
 * Ingests a document, generates its embedding, and stores it in LanceDB.
 * @param text - The document content.
 * @param metadata - Key-value pairs for filtering (e.g., { author: 'John Doe' }).
 */
async function ingestDocument(text: string, metadata: Record<string, any>) {
  try {
    // 1. Connect to Local LanceDB
    const db = await lancedb.connect(LANCE_DB_URI);
    
    // 2. Generate Embedding
    const vector = await generateEmbedding(text);
    
    // 3. Create or Open Table
    // LanceDB schema is dynamic, but we define a structure for clarity.
    let table = await db.openTable(TABLE_NAME);
    
    // If table doesn't exist, create it with a schema
    if (!table) {
      table = await db.createTable(TABLE_NAME, [
        { name: 'id', type: 'string' }, // Unique ID for the document
        { name: 'text', type: 'string' }, // The raw text
        { name: 'vector', type: 'fixed_size_list:1536:float32' }, // The embedding vector
        { name: 'metadata', type: 'map<string, string>' }, // Metadata map
      ]);
    }

    // 4. Insert Data
    // We use a timestamp ID for uniqueness in this demo.
    const record = {
      id: `doc_${Date.now()}`,
      text: text,
      vector: Array.from(vector), // LanceDB expects JS Arrays for insertion
      metadata: metadata
    };

    await table.add([record]);
    console.log(`Document ingested into LanceDB. ID: ${record.id}`);

  } catch (error) {
    console.error('Ingestion failed:', error);
    throw new Error('Failed to ingest document.');
  }
}

/**
 * Queries the vector store for relevant context based on user input.
 * Supports metadata filtering to narrow the search space (e.g., by author).
 * @param query - The user's question.
 * @param filter - Metadata constraints.
 * @param topK - Number of results to return.
 * @returns The top K relevant text chunks.
 */
async function queryVectorStore(
  query: string, 
  filter?: Record<string, any>, 
  topK: number = 3
): Promise<string[]> {
  try {
    const db = await lancedb.connect(LANCE_DB_URI);
    const table = await db.openTable(TABLE_NAME);

    if (!table) {
      return []; // No data available
    }

    // 1. Generate Query Embedding
    const queryVector = await generateEmbedding(query);

    // 2. Perform Vector Search with Metadata Filtering
    // LanceDB allows pre-filtering using SQL-like syntax or JS objects.
    // This is "Metadata Filtering" - reducing the search space before vector similarity calc.
    let searchQuery = table.search(queryVector);

    if (filter && Object.keys(filter).length > 0) {
      // Apply scalar filters. 
      // Example: 'metadata.author = "Smith"'
      // Note: Syntax may vary slightly based on LanceDB version, but conceptually:
      searchQuery = searchQuery.where(filter); 
    }

    // 3. Limit results and execute
    const results = await searchQuery.limit(topK).execute();

    // 4. Extract text content
    // 'text' is the column name we defined during ingestion.
    const context = results.map((res: any) => res.text);
    
    return context;

  } catch (error) {
    console.error('Query failed:', error);
    return [];
  }
}

// --- NEXT.JS API HANDLER ---

export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse<RagResponse>
) {
  // Initialize WebGPU for potential LLM acceleration on the server side (Node/Edge)
  // Note: WebGPU in Node.js is experimental; this is a forward-looking implementation.
  await initWebGPU();

  if (req.method !== 'POST') {
    return res.status(405).json({ message: 'Method Not Allowed' });
  }

  const { type, payload } = req.body as RagRequest;

  try {
    if (type === 'ingest') {
      if (!payload.text) {
        return res.status(400).json({ message: 'Text payload required.' });
      }
      
      // Ingest the document
      await ingestDocument(payload.text, payload.metadata || {});
      
      return res.status(200).json({ 
        message: 'Document successfully embedded and stored locally.' 
      });

    } else if (type === 'query') {
      if (!payload.query) {
        return res.status(400).json({ message: 'Query payload required.' });
      }

      const startTime = performance.now();
      
      // Retrieve context from vector store
      const context = await queryVectorStore(
        payload.query, 
        payload.filter, 
        payload.topK
      );

      const endTime = performance.now();
      const latency = endTime - startTime;

      if (context.length === 0) {
        return res.status(200).json({
          message: 'No relevant context found in local vector store.',
          data: { context: [], latency }
        });
      }

      // In a full RAG app, you would now pass this 'context' + 'query' 
      // to a local LLM (e.g., via Ollama) to generate the final answer.
      // For this script, we return the context to demonstrate the retrieval step.
      
      return res.status(200).json({
        message: 'Retrieval successful. Context ready for LLM generation.',
        data: {
          context: context,
          latency: latency
        }
      });

    } else {
      return res.status(400).json({ message: 'Invalid request type.' });
    }

  } catch (error) {
    console.error(error);
    return res.status(500).json({ 
      message: 'Internal Server Error', 
      error: (error as Error).message 
    });
  }
}
