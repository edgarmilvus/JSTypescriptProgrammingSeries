/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// embedding-service.ts
import fetch from 'node-fetch'; // Or use global fetch in Node 18+

// Interfaces defined in the prompt
export interface OllamaEmbeddingRequest {
  model: string;
  input: string | string[];
  options?: {
    temperature?: number;
    num_ctx?: number;
  };
}

export interface OllamaEmbeddingResponse {
  embedding: number[];
  model: string;
  prompt_eval_count?: number;
}

/**
 * Generates embeddings for a list of text chunks using Ollama.
 * Batches requests if the chunk count exceeds 50.
 * 
 * @param chunks - Array of text strings to embed
 * @returns Promise resolving to a 2D array of embeddings
 */
export async function generateEmbeddings(chunks: string[]): Promise<number[][]> {
  const OLLAMA_URL = 'http://localhost:11434/api/embed';
  const MODEL = 'all-minilm:l6-v2';
  const BATCH_SIZE = 50;

  const allEmbeddings: number[][] = [];

  // Helper to process a single batch
  const processBatch = async (batch: string[]) => {
    const payload: OllamaEmbeddingRequest = {
      model: MODEL,
      input: batch,
      // Optional: specific options for the model
      options: {
        temperature: 0.0, // Usually fixed for embeddings
      }
    };

    try {
      const response = await fetch(OLLAMA_URL, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });

      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`Ollama API Error: ${response.status} - ${errorText}`);
      }

      const data = (await response.json()) as OllamaEmbeddingResponse;
      
      // Ollama returns a single embedding array for a single string input,
      // or an array of embeddings for an array of strings.
      // Since we send an array (batch), we expect data.embedding to be number[][]
      if (Array.isArray(data.embedding)) {
        // Check if the result is a flat array (single item) or nested (batch)
        if (Array.isArray(data.embedding[0])) {
           allEmbeddings.push(...(data.embedding as number[][]));
        } else {
           // If batch size was 1, Ollama might return flat array
           allEmbeddings.push(data.embedding as number[]);
        }
      }
    } catch (error) {
      if (error instanceof Error) {
        throw new Error(`Failed to generate embeddings for batch: ${error.message}`);
      } else {
        throw new Error('Unknown error during embedding generation');
      }
    }
  };

  // Batching Logic
  for (let i = 0; i < chunks.length; i += BATCH_SIZE) {
    const batch = chunks.slice(i, i + BATCH_SIZE);
    console.log(`Processing batch ${Math.floor(i / BATCH_SIZE) + 1}...`);
    
    // Optional: Add a small delay to prevent overwhelming the local CPU
    if (i > 0) await new Promise(resolve => setTimeout(resolve, 100));
    
    await processBatch(batch);
  }

  return allEmbeddings;
}

// Example usage (commented out):
/*
(async () => {
  const chunks = ["Hello world", "Test embedding", "Another chunk"];
  try {
    const embeddings = await generateEmbeddings(chunks);
    console.log(`Generated ${embeddings.length} embeddings.`);
  } catch (err) {
    console.error(err);
  }
})();
*/
