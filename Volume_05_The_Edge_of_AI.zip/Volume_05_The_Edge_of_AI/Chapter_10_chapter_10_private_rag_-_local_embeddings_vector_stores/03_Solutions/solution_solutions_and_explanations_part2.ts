/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

// vector-store.ts
import * as lancedb from '@lancedb/lancedb';
import * as arrow from 'apache-arrow';

export interface DocumentRecord {
  id: string;
  text: string;
  embedding: number[];
}

export class LocalVectorStore {
  private db: lancedb.Connection;

  constructor(dbPath: string = './vector_db') {
    // Initialize connection to the local directory
    this.db = lancedb.connect(dbPath);
  }

  /**
   * Creates a new table with the defined schema.
   * If the table exists, it will be opened.
   */
  async createTable(tableName: string): Promise<lancedb.Table> {
    try {
      // Define the schema using Arrow types
      // VectorSize must match the model output (e.g., 384 for all-minilm:l6-v2)
      const schema = new arrow.Schema([
        new arrow.Field('id', new arrow.Utf8()),
        new arrow.Field('text', new arrow.Utf8()),
        new arrow.Field('embedding', new arrow.Float32Vector(), { vectorSize: 384 }),
      ]);

      // Create table with the schema
      const table = await this.db.createTable(tableName, schema, { mode: 'create' });
      console.log(`Table '${tableName}' created or opened successfully.`);
      return table;
    } catch (error) {
      // If table exists, LanceDB throws. We can open it instead.
      if (error instanceof Error && error.message.includes('already exists')) {
        console.log(`Table '${tableName}' already exists. Opening...`);
        return this.db.openTable(tableName);
      }
      throw error;
    }
  }

  /**
   * Inserts records into the specified table.
   */
  async insertData(tableName: string, data: DocumentRecord[]): Promise<void> {
    if (data.length === 0) return;

    const table = await this.db.openTable(tableName);
    
    // LanceDB expects data in a specific format (often Arrow Tables or array of objects)
    // We convert our array of objects to a format compatible with the JS client
    await table.add(data);
    console.log(`Inserted ${data.length} records into '${tableName}'.`);
  }

  /**
   * Performs a vector similarity search (Cosine Similarity by default in LanceDB).
   */
  async search(tableName: string, queryEmbedding: number[], limit: number = 3): Promise<DocumentRecord[]> {
    const table = await this.db.openTable(tableName);
    
    // LanceDB JS client allows searching with a vector directly
    // It defaults to cosine distance for vector columns
    const results = await table
      .search(queryEmbedding)
      .limit(limit)
      .execute();

    // The result is an array of objects matching the schema
    // We cast it to our DocumentRecord interface for type safety
    return results as DocumentRecord[];
  }
}
