/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

// RAGChatInterface.tsx
import React, { useState, FormEvent, ChangeEvent } from 'react';

interface Message {
  role: 'user' | 'assistant';
  content: string;
  context?: string[]; // Retrieved documents
}

export const RAGChatInterface: React.FC = () => {
  const [userQuery, setUserQuery] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [conversationHistory, setConversationHistory] = useState<Message[]>([]);
  const [error, setError] = useState<string | null>(null);

  const handleInputChange = (e: ChangeEvent<HTMLInputElement>) => {
    setUserQuery(e.target.value);
  };

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if (!userQuery.trim()) return;

    // Add user message to history immediately
    const newUserMessage: Message = { role: 'user', content: userQuery };
    setConversationHistory(prev => [...prev, newUserMessage]);
    setUserQuery('');
    setIsLoading(true);
    setError(null);

    try {
      // Call the hypothetical backend API
      const response = await fetch('http://localhost:3000/api/rag-query', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ query: newUserMessage.content }),
      });

      if (!response.ok) throw new Error('Backend request failed');

      // Handle streaming or JSON response
      // For this example, we assume a standard JSON response for simplicity
      const data = await response.json(); 
      
      // Assuming backend returns: { answer: string, context: string[] }
      const assistantMessage: Message = {
        role: 'assistant',
        content: data.answer,
        context: data.context
      };

      setConversationHistory(prev => [...prev, assistantMessage]);

    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unknown error');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="rag-container" style={{ padding: '20px', maxWidth: '600px', margin: '0 auto' }}>
      <div className="chat-window" style={{ border: '1px solid #ccc', height: '400px', overflowY: 'auto', padding: '10px', marginBottom: '10px' }}>
        {conversationHistory.map((msg, index) => (
          <div key={index} style={{ marginBottom: '10px', textAlign: msg.role === 'user' ? 'right' : 'left' }}>
            <strong>{msg.role === 'user' ? 'You' : 'Assistant'}:</strong>
            <div style={{ 
              background: msg.role === 'user' ? '#e3f2fd' : '#f5f5f5', 
              padding: '8px', 
              borderRadius: '8px', 
              display: 'inline-block', 
              marginTop: '4px' 
            }}>
              {msg.content}
            </div>
            
            {/* Collapsible Context Section */}
            {msg.context && msg.context.length > 0 && (
              <details style={{ fontSize: '0.8rem', marginTop: '5px', color: '#666' }}>
                <summary>Retrieved Context</summary>
                <ul style={{ textAlign: 'left', paddingLeft: '20px' }}>
                  {msg.context.map((chunk, i) => (
                    <li key={i} style={{ marginBottom: '4px' }}>{chunk}</li>
                  ))}
                </ul>
              </details>
            )}
          </div>
        ))}
        {isLoading && <div>Thinking...</div>}
        {error && <div style={{ color: 'red' }}>Error: {error}</div>}
      </div>

      <form onSubmit={handleSubmit} style={{ display: 'flex', gap: '10px' }}>
        <input
          type="text"
          value={userQuery}
          onChange={handleInputChange}
          placeholder="Ask a question..."
          disabled={isLoading}
          style={{ flex: 1, padding: '8px' }}
        />
        <button type="submit" disabled={isLoading} style={{ padding: '8px 16px' }}>
          {isLoading ? 'Sending...' : 'Send'}
        </button>
      </form>
    </div>
  );
};
