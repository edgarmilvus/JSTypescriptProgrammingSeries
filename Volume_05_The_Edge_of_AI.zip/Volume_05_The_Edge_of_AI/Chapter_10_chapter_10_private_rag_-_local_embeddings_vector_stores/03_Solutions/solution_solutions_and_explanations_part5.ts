/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

// main-thread-benchmark.ts
import { Worker } from 'worker_threads';
import * as path from 'path';

function runWorkerBenchmark() {
  return new Promise<void>((resolve, reject) => {
    const worker = new Worker(path.resolve(__dirname, './worker.js')); // Assuming compiled JS

    worker.on('message', async (msg) => {
      if (msg.type === 'ready') {
        console.log(`[Main] Model initialized: ${JSON.stringify(msg.data)}`);
        console.log('--- Starting Benchmark ---');
        
        // 1. Cold Start Request
        const coldStart = performance.now();
        worker.postMessage({ type: 'embed' });
        
        // Wait for the cold start result (handled in 'message' listener below)
      } else if (msg.type === 'result') {
        // Determine if this is the first result (cold) or subsequent (warm)
        if (!worker['warmStartsStarted']) {
          const coldDuration = performance.now() - (worker['startTime'] || 0);
          console.log(`[Benchmark] Cold Start Request: ${coldDuration.toFixed(2)}ms`);
          
          worker['warmStartsStarted'] = true;
          
          // Start Warm Requests
          console.log('Sending 9 warm requests...');
          for (let i = 0; i < 9; i++) {
            // Small delay to ensure sequential processing
            setTimeout(() => {
              worker['startTime'] = performance.now();
              worker.postMessage({ type: 'embed' });
            }, i * 100);
          }
        } else {
          const warmDuration = performance.now() - (worker['startTime'] || 0);
          console.log(`[Benchmark] Warm Start Request: ${warmDuration.toFixed(2)}ms`);
        }

        // Check if benchmark is complete
        const currentCount = (worker['completedCount'] || 0) + 1;
        worker['completedCount'] = currentCount;
        
        if (currentCount === 10) { // 1 cold + 9 warm
          console.log('--- Benchmark Complete ---');
          worker.terminate();
          resolve();
        }
      }
    });

    worker.on('error', reject);
    worker.on('exit', (code) => {
      if (code !== 0) reject(new Error(`Worker stopped with exit code ${code}`));
    });

    // Trigger initialization
    console.log('[Main] Sending init command...');
    worker['startTime'] = performance.now();
    worker.postMessage({ type: 'init' });
  });
}

runWorkerBenchmark().catch(console.error);
