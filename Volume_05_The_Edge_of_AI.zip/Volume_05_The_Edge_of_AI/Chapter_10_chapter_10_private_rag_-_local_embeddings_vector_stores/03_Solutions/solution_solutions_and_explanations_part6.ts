/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part6.ts
// Description: Solutions and Explanations
// ==========================================

// pipeline.ts
import * as fs from 'fs/promises';
import * as path from 'path';
import * as readline from 'readline';
import { LocalVectorStore, DocumentRecord } from './vector-store';
import { generateEmbeddings } from './embedding-service';

// Configuration
const DATA_FILE = './data/constitution.txt'; // Example file
const CHUNK_SIZE = 500;
const OVERLAP_SIZE = 50;
const DB_PATH = './vector_db';
const TABLE_NAME = 'documents';

// Helper: Chunk text with overlap
function chunkText(text: string): string[] {
  const chunks: string[] = [];
  let start = 0;
  while (start < text.length) {
    let end = start + CHUNK_SIZE;
    // Try to break at a space near the end if possible
    if (end < text.length) {
      const lastSpace = text.lastIndexOf(' ', end);
      if (lastSpace > start) end = lastSpace;
    }
    chunks.push(text.substring(start, end));
    start = end - OVERLAP_SIZE; // Move forward by chunk size minus overlap
    if (start < 0) start = end; // Prevent negative start
  }
  return chunks;
}

async function runRAGPipeline() {
  const vectorStore = new LocalVectorStore(DB_PATH);

  // 1. Data Ingestion & Chunking
  console.log('1. Loading and chunking document...');
  let chunks: string[] = [];
  try {
    const rawText = await fs.readFile(path.resolve(__dirname, DATA_FILE), 'utf-8');
    chunks = chunkText(rawText);
    console.log(`   Generated ${chunks.length} chunks.`);
  } catch (error) {
    console.error('   Error reading file. Skipping ingestion step.');
  }

  // 2. Embedding & Storage
  if (chunks.length > 0) {
    console.log('2. Generating embeddings...');
    try {
      const embeddings = await generateEmbeddings(chunks);
      
      console.log('3. Storing in LanceDB...');
      const records: DocumentRecord[] = chunks.map((text, index) => ({
        id: `doc_${index}`,
        text: text,
        embedding: embeddings[index]
      }));
      
      // Create table and insert data
      await vectorStore.createTable(TABLE_NAME);
      await vectorStore.insertData(TABLE_NAME, records);
    } catch (error) {
      console.error('   Error in embedding/storage pipeline:', error);
      return;
    }
  }

  // 4. Query Loop
  console.log('4. Starting Query Interface...');
  const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
  });

  const askQuestion = (): Promise<string> => {
    return new Promise((resolve) => rl.question('Enter your query (or "exit" to quit): ', resolve));
  };

  // eslint-disable-next-line no-constant-condition
  while (true) {
    const query = await askQuestion();
    if (query.toLowerCase() === 'exit') break;

    try {
      // A. Generate Query Embedding
      console.log('   Generating query embedding...');
      const queryEmbeddings = await generateEmbeddings([query]);
      const queryVector = queryEmbeddings[0];

      // B. Search Vector Store
      console.log('   Searching vector store...');
      const results = await vectorStore.search(TABLE_NAME, queryVector, 3);
      const context = results.map(r => r.text).join('\n\n');

      // C. Synthesis (LLM Call)
      if (results.length === 0) {
        console.log('   No relevant context found.');
        continue;
      }

      console.log('   Generating answer via Ollama...');
      const prompt = `Context: ${context}\n\nQuestion: ${query}\n\nAnswer concisely:`;
      
      // Call Ollama Generate API (Simplified for brevity)
      const response = await fetch('http://localhost:11434/api/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          model: 'llama2', // Or any local model you have
          prompt: prompt,
          stream: false
        })
      });

      const data = await response.json();
      console.log(`\nANSWER: ${data.response}\n`);

    } catch (err) {
      console.error('   Error during query processing:', err);
    }
  }

  rl.close();
  console.log('Pipeline terminated.');
}

runRAGPipeline();
