/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: theory_theoretical_foundations.ts
// Description: Theoretical Foundations
// ==========================================

// Theoretical Type Definitions for Observability Events
type BaseEvent = {
  timestamp: Date;
  runId: string;
};

type LLMCallEvent = BaseEvent & {
  type: 'llm_call';
  prompt: string;
  model: string;
};

type MetricEvent = BaseEvent & {
  type: 'metric';
  name: 'latency' | 'token_count';
  value: number;
};

type ObservabilityEvent = LLMCallEvent | MetricEvent;

// A Type Guard function
function isLLMCallEvent(event: ObservabilityEvent): event is LLMCallEvent {
  return event.type === 'llm_call';
}

// Usage in the observability pipeline
function logEvent(event: ObservabilityEvent) {
  // We cannot access 'prompt' safely without a guard
  // if (event.type === 'llm_call') { ... } // This is a runtime check
  
  // Using the Type Guard allows the compiler to narrow the scope
  if (isLLMCallEvent(event)) {
    // Inside this block, TypeScript knows 'event' is LLMCallEvent
    console.log(`Sending prompt to LangSmith: ${event.prompt}`);
    sendToBackend(event); 
  }
}
