/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// app/api/chat/observability/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { Client as LangSmithClient } from 'langsmith';
import { v4 as uuidv4 } from 'uuid';

/**
 * @interface ObservabilityPayload
 * @description Standardized structure for sending metrics to Helicone and LangSmith.
 */
interface ObservabilityPayload {
  runId: string;
  model: string;
  promptTokens: number;
  completionTokens: number;
  latencyMs: number;
  status: 'success' | 'error';
  coldStartMs?: number;
}

/**
 * @interface OllamaStreamChunk
 * @description Expected format from a local Ollama streaming response.
 */
interface OllamaStreamChunk {
  model: string;
  created_at: string;
  response?: string;
  done: boolean;
  total_duration?: number; // Nanoseconds
  prompt_eval_count?: number;
  eval_count?: number;
}

/**
 * @function POST
 * @description Main API Route Handler.
 * Orchestrates local LLM inference, streams response to client, 
 * and dispatches observability data asynchronously.
 */
export async function POST(req: NextRequest) {
  const startTime = process.hrtime.bigint();
  const runId = uuidv4(); // Unique ID for this trace
  const { prompt } = await req.json();

  // 1. Initialize Observability Clients (Simulated for brevity)
  // In production, these would be initialized with API keys from env vars.
  const langSmithClient = new LangSmithClient({
    apiUrl: process.env.LANGSMITH_ENDPOINT,
    apiKey: process.env.LANGSMITH_API_KEY,
  });

  // 2. Define the Streaming Transform
  // We create a custom ReadableStream to intercept data flowing from Ollama.
  const stream = new ReadableStream({
    async start(controller) {
      let firstTokenTime: bigint | null = null;
      let responseBuffer = '';
      let promptTokens = 0;
      let completionTokens = 0;

      try {
        // 3. Fetch from Local Ollama Instance
        // Note: We assume Ollama is running on localhost:11434
        const ollamaRes = await fetch('http://localhost:11434/api/generate', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            model: 'llama2', // Local model name
            prompt: prompt,
            stream: true,
          }),
        });

        if (!ollamaRes.body) {
          throw new Error('No response body from Ollama');
        }

        // 4. Process the Stream
        // We read the Ollama response line-by-line (NDJSON format).
        const reader = ollamaRes.body.getReader();
        const decoder = new TextDecoder();

        while (true) {
          const { done, value } = await reader.read();
          if (done) break;

          const chunkText = decoder.decode(value, { stream: true });
          const lines = chunkText.split('\n').filter((line) => line.trim() !== '');

          for (const line of lines) {
            try {
              const data: OllamaStreamChunk = JSON.parse(line);

              // Capture Cold Start (Time to First Token)
              if (data.response && !firstTokenTime) {
                firstTokenTime = process.hrtime.bigint();
              }

              // Buffer completion tokens
              if (data.response) {
                responseBuffer += data.response;
                controller.enqueue(data.response); // Stream to client immediately
              }

              // Capture final metrics when stream finishes
              if (data.done) {
                completionTokens = data.eval_count || 0;
                promptTokens = data.prompt_eval_count || 0;
                
                // Calculate Latency
                const endTime = process.hrtime.bigint();
                const latencyMs = Number(endTime - startTime) / 1_000_000;
                const coldStartMs = firstTokenTime 
                  ? Number(firstTokenTime - startTime) / 1_000_000 
                  : undefined;

                // 5. Asynchronous Observability Dispatch
                // We fire-and-forget this promise to avoid blocking the stream response.
                dispatchObservability({
                  runId,
                  model: data.model,
                  promptTokens,
                  completionTokens,
                  latencyMs,
                  status: 'success',
                  coldStartMs,
                  langSmithClient,
                });
              }
            } catch (e) {
              console.error('Error parsing Ollama chunk:', e);
            }
          }
        }
      } catch (error) {
        console.error('Inference Error:', error);
        controller.error(error);
      } finally {
        controller.close();
      }
    },
  });

  // Return the stream to the client immediately
  return new Response(stream, {
    headers: { 'Content-Type': 'text/plain' },
  });
}

/**
 * @function dispatchObservability
 * @description Sends metrics to LangSmith (Tracing) and Helicone (Metrics).
 * Runs asynchronously to minimize impact on user-facing latency.
 */
async function dispatchObservability(
  payload: ObservabilityPayload & { langSmithClient: LangSmithClient }
) {
  const { runId, model, promptTokens, completionTokens, latencyMs, coldStartMs, langSmithClient } = payload;

  // --- LANGSMITH TRACING ---
  // We create a "Run" in LangSmith to visualize the execution path.
  // This is crucial for debugging agentic workflows where multiple LLM calls occur.
  try {
    await langSmithClient.createRun({
      name: `local-llama2-inference-${runId}`,
      run_type: 'llm',
      inputs: { prompt: "User input (truncated for privacy)" }, 
      outputs: { response_length: completionTokens },
      start_time: new Date().toISOString(),
      end_time: new Date().toISOString(),
      extra: {
        metadata: {
          model: model,
          hardware: 'local-webgpu', // Hypothetical tag
          cold_start_ms: coldStartMs,
        }
      }
    });
  } catch (e) {
    // Fail silently for observability to not break the main app
    console.warn('LangSmith logging failed:', e);
  }

  // --- HELICONE METRICS ---
  // Helicone typically acts as a proxy, but for local models, we can send 
  // custom metrics via their REST API to track "virtual" costs.
  try {
    const heliconePayload = {
      projectId: process.env.HELICONE_PROJECT_ID,
      metrics: {
        latency: latencyMs,
        prompt_tokens: promptTokens,
        completion_tokens: completionTokens,
        // Calculate a "virtual cost" based on local hardware depreciation
        cost: (completionTokens / 1_000_000) * 0.002, 
      },
      customProperties: {
        runId: runId,
        environment: 'development',
      }
    };

    // Fire and forget
    await fetch('https://api.helicone.ai/v1/usage', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${process.env.HELICONE_API_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(heliconePayload),
    });
  } catch (e) {
    console.warn('Helicone logging failed:', e);
  }
}
