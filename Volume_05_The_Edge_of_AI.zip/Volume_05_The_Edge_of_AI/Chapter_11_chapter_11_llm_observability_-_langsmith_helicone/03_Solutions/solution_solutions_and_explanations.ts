/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

import { Client } from "langsmith";

// Initialize LangSmith client (assumed to be configured via env vars)
const langsmithClient = new Client();

/**
 * Simulates a local Ollama API call. In a real scenario, this would be a fetch request to http://localhost:11434/api/generate
 * Returns a stream of text chunks.
 */
async function* mockOllamaStream(prompt: string, modelName: string): AsyncGenerator<string> {
    const responseText = "This is a simulated response from the local LLM model.";
    for (const char of responseText) {
        yield char;
        // Simulate network delay
        await new Promise(resolve => setTimeout(resolve, 50));
    }
}

export async function callLocalLLMWithTracing(prompt: string, modelName: string): Promise<string> {
    const startTime = Date.now();
    let accumulatedText = "";
    let tokenCount = 0;

    // 1. Start the LLM call
    const stream = mockOllamaStream(prompt, modelName);

    // 2. Process stream and accumulate data
    for await (const chunk of stream) {
        accumulatedText += chunk;
        // Simple heuristic: 1 chunk ≈ 1 token for simulation
        tokenCount++;
    }

    const endTime = Date.now();
    const totalLatencyMs = endTime - startTime;
    const totalLatencySec = totalLatencyMs / 1000;
    
    // Calculate metrics
    const tokensPerSecond = totalLatencySec > 0 ? tokenCount / totalLatencySec : 0;
    const hardwareUtilization = Math.floor(Math.random() * 30 + 40); // Simulated 40-70%

    // 3. Asynchronously send trace to LangSmith (non-blocking)
    // We wrap this in a promise that we don't await to ensure UI responsiveness
    (async () => {
        try {
            // Using runOnIterable is ideal for streaming, but for a post-execution trace:
            const traceData = {
                name: "Local LLM Call",
                inputs: { prompt },
                outputs: { response: accumulatedText },
                metadata: {
                    model_name: modelName,
                    execution_environment: "local",
                    hardware: "RTX 3090",
                },
                metrics: {
                    latency_ms: totalLatencyMs,
                    tokens_per_second: tokensPerSecond,
                    hardware_utilization_percent: hardwareUtilization,
                }
            };
            
            // In a real LangSmith implementation, you might use `client.trace` or `client.runOnIterable`
            // Here we simulate the logging call
            console.log("Sending Trace to LangSmith:", traceData);
            // await langsmithClient.createTrace(traceData); 
        } catch (error) {
            console.error("Failed to send trace to LangSmith:", error);
        }
    })();

    return accumulatedText;
}

// Example Usage
(async () => {
    const result = await callLocalLLMWithTracing("Explain quantum physics", "llama2:7b");
    console.log("UI receives:", result);
})();
