/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

import { z } from "zod";
import { zodToJsonSchema } from "zod-to-json-schema";

// 1. Define the Zod Schema
const MeetingInsightsSchema = z.object({
    attendees: z.array(z.string()).describe("List of attendee names"),
    actionItems: z.array(
        z.object({
            task: z.string(),
            assignee: z.string(),
        })
    ).describe("List of tasks and who is responsible"),
    sentiment: z.enum(["Positive", "Negative", "Neutral"]).describe("Overall sentiment of the meeting"),
});

type MeetingInsights = z.infer<typeof MeetingInsightsSchema>;

// 2. Mock LLM Call that accepts a JSON schema
async function mockLLMWithJsonMode(prompt: string, schemaDefinition: any): Promise<string> {
    // In a real scenario (e.g., Ollama with JSON mode or OpenAI), we pass the schema.
    // Here, we simulate a successful response adhering to the schema.
    const mockResponse = {
        attendees: ["Alice", "Bob", "Charlie"],
        actionItems: [
            { task: "Review Q3 budget", assignee: "Alice" },
            { task: "Deploy new feature", assignee: "Bob" }
        ],
        sentiment: "Positive"
    };
    return JSON.stringify(mockResponse);
}

export async function extractMeetingInsights(transcript: string): Promise<MeetingInsights> {
    // Convert Zod schema to JSON Schema format for the LLM
    const jsonSchema = zodToJsonSchema(MeetingInsightsSchema);

    // Call the LLM (simulated)
    const rawOutput = await mockLLMWithJsonMode(transcript, jsonSchema);

    // 3. Validate and Parse
    try {
        const parsedJson = JSON.parse(rawOutput);
        const validatedData = MeetingInsightsSchema.parse(parsedJson);
        return validatedData;
    } catch (error) {
        if (error instanceof z.ZodError) {
            // 4. Detailed Error Handling
            const fieldErrors = error.errors.map(e => `${e.path.join('.')}: ${e.message}`).join(', ');
            throw new Error(`LLM output validation failed: ${fieldErrors}`);
        }
        throw new Error("Failed to parse LLM output as JSON");
    }
}

// Example Usage
(async () => {
    try {
        const insights = await extractMeetingInsights("Meeting transcript...");
        console.log("Extracted Data:", insights);
        // Access with type safety: insights.attendees[0].toUpperCase()
    } catch (err) {
        console.error(err);
    }
})();
