/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState, useTransition, useState } from 'react';

// Mock function simulating a heavy local LLM analysis (3 seconds)
const mockAnalyzeCode = (code: string): Promise<string> => {
    return new Promise((resolve) => {
        setTimeout(() => {
            resolve(`Refactoring Plan for ${code.length} lines of code:\n1. Extract function.\n2. Remove dead code.`);
        }, 3000);
    });
};

export const CodeAnalysisTrigger: React.FC = () => {
    const [inputCode, setInputCode] = useState("");
    const [result, setResult] = useState<string | null>(null);
    
    // useTransition hook returns [isPending, startTransition]
    const [isPending, startTransition] = useTransition();

    const handleAnalyze = () => {
        // Reset previous result
        setResult(null);

        // Wrap the state update in startTransition
        startTransition(async () => {
            const analysis = await mockAnalyzeCode(inputCode);
            setResult(analysis);
        });
    };

    return (
        <div style={{ padding: '20px', fontFamily: 'sans-serif' }}>
            <h2>Code Analysis Dashboard</h2>
            
            <textarea
                value={inputCode}
                onChange={(e) => setInputCode(e.target.value)}
                placeholder="Paste code here..."
                rows={10}
                style={{ width: '100%', marginBottom: '10px' }}
                disabled={isPending} // Optional: disable input during processing
            />
            
            <div style={{ marginBottom: '20px' }}>
                <button 
                    onClick={handleAnalyze} 
                    disabled={isPending || !inputCode}
                    style={{ padding: '10px 20px', cursor: 'pointer' }}
                >
                    {isPending ? 'Analyzing...' : 'Analyze Code'}
                </button>
            </div>

            {/* Sidebar or other UI elements that should remain responsive */}
            <div style={{ border: '1px solid #ccc', padding: '10px', marginTop: '20px' }}>
                <h3>Sidebar (Should remain interactive)</h3>
                <p>Status: {isPending ? "Background processing..." : "Ready"}</p>
            </div>

            {/* Result Display */}
            {result && (
                <div style={{ marginTop: '20px', whiteSpace: 'pre-wrap', background: '#f5f5f5', padding: '10px' }}>
                    <strong>Analysis Result:</strong>
                    {result}
                </div>
            )}
        </div>
    );
};
