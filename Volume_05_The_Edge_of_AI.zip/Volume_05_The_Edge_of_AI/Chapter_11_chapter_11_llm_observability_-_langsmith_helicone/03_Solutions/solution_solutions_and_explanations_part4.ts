/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

// 1. Define Types
interface Document {
    id: string;
    content: string;
    embedding: number[];
    metadata: {
        year: number;
        jurisdiction: string;
        [key: string]: any;
    };
}

// 2. Simulate Vector Store
const vectorStore: Document[] = [
    { id: "1", content: "Contract terms for 2021...", embedding: [0.1, 0.2, 0.8], metadata: { year: 2021, jurisdiction: "US" } },
    { id: "2", content: "Legal dispute in UK 2019...", embedding: [0.9, 0.1, 0.1], metadata: { year: 2019, jurisdiction: "UK" } },
    { id: "3", content: "Breach of contract 2022...", embedding: [0.15, 0.25, 0.75], metadata: { year: 2022, jurisdiction: "US" } },
    { id: "4", content: "Corporate law 2020...", embedding: [0.5, 0.5, 0.5], metadata: { year: 2020, jurisdiction: "US" } },
];

// Helper: Cosine Similarity
function cosineSimilarity(vecA: number[], vecB: number[]): number {
    const dotProduct = vecA.reduce((acc, val, i) => acc + val * vecB[i], 0);
    const magA = Math.sqrt(vecA.reduce((acc, val) => acc + val * val, 0));
    const magB = Math.sqrt(vecB.reduce((acc, val) => acc + val * val, 0));
    return dotProduct / (magA * magB);
}

// 3. Search Function
export function searchWithMetadataFilter(
    queryEmbedding: number[],
    filter: { year: number; jurisdiction: string },
    store: Document[] = vectorStore
): Document[] {
    // Step A: Filter by Metadata
    const filteredDocs = store.filter(doc => {
        return doc.metadata.year >= filter.year && doc.metadata.jurisdiction === filter.jurisdiction;
    });

    // Step B: Calculate Similarity on filtered subset
    const scoredDocs = filteredDocs.map(doc => {
        const similarity = cosineSimilarity(queryEmbedding, doc.embedding);
        return { ...doc, similarity };
    });

    // Step C: Sort and Return Top K (3)
    return scoredDocs
        .sort((a, b) => b.similarity - a.similarity)
        .slice(0, 3);
}

// Example Usage
const query = [0.1, 0.2, 0.8]; // Simulated embedding for "contract breach"
const results = searchWithMetadataFilter(query, { year: 2020, jurisdiction: "US" });
console.log("Retrieved Docs:", results.map(d => ({ id: d.id, year: d.metadata.year, sim: d.similarity })));
