/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState } from 'react';

// 1. Define Data Structure
interface LLMTrace {
    id: string;
    timestamp: Date;
    latency: number; // ms
    tokensPerSecond: number;
    cost: number; // Simulated dollars
}

// Helper to generate random traces
const generateRandomTrace = (): LLMTrace => {
    return {
        id: Math.random().toString(36).substr(2, 9),
        timestamp: new Date(),
        latency: Math.floor(Math.random() * (2000 - 500) + 500), // 500ms - 2000ms
        tokensPerSecond: Math.floor(Math.random() * (100 - 10) + 10), // 10 - 100 tps
        cost: parseFloat((Math.random() * 0.05).toFixed(4)), // 0 - 0.05 dollars
    };
};

export const ObservabilityDashboard: React.FC = () => {
    // 2. State Management
    const [traces, setTraces] = useState<LLMTrace[]>([
        generateRandomTrace(),
        generateRandomTrace(),
        generateRandomTrace(),
    ]);

    // 3. Metrics Calculation
    const avgLatency = traces.length > 0
        ? traces.reduce((acc, t) => acc + t.latency, 0) / traces.length
        : 0;

    const totalCost = traces.reduce((acc, t) => acc + t.cost, 0);

    const handleSimulate = () => {
        const newTrace = generateRandomTrace();
        setTraces(prev => [newTrace, ...prev]); // Add to top
    };

    // 4. Visualization Helper (Simple CSS Bar Chart)
    const maxLatency = Math.max(...traces.map(t => t.latency), 1); // Avoid div by zero

    return (
        <div style={{ padding: '20px', fontFamily: 'Arial, sans-serif', border: '1px solid #e0e0e0', borderRadius: '8px', maxWidth: '800px', margin: '0 auto' }}>
            <h2>Observability Dashboard</h2>
            
            {/* Summary Cards */}
            <div style={{ display: 'flex', gap: '20px', marginBottom: '20px' }}>
                <div style={{ flex: 1, background: '#f0f8ff', padding: '15px', borderRadius: '8px', textAlign: 'center' }}>
                    <h4>Avg Latency</h4>
                    <p style={{ fontSize: '1.5em', fontWeight: 'bold' }}>{Math.round(avgLatency)}ms</p>
                </div>
                <div style={{ flex: 1, background: '#fff0f0', padding: '15px', borderRadius: '8px', textAlign: 'center' }}>
                    <h4>Total Simulated Cost</h4>
                    <p style={{ fontSize: '1.5em', fontWeight: 'bold' }}>${totalCost.toFixed(4)}</p>
                </div>
            </div>

            <button 
                onClick={handleSimulate} 
                style={{ padding: '10px 20px', marginBottom: '20px', cursor: 'pointer', background: '#007bff', color: '#fff', border: 'none', borderRadius: '4px' }}
            >
                Simulate New Trace
            </button>

            <h3>Recent Traces</h3>
            
            {/* List & Chart */}
            <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
                {traces.map((trace) => (
                    <div key={trace.id} style={{ display: 'flex', alignItems: 'center', gap: '10px', padding: '8px', borderBottom: '1px solid #eee' }}>
                        <div style={{ width: '60px', fontSize: '0.8em', color: '#666' }}>
                            {trace.id}
                        </div>
                        
                        {/* CSS Bar Chart Visualization */}
                        <div style={{ flex: 1, background: '#eee', height: '20px', borderRadius: '4px', overflow: 'hidden', position: 'relative' }}>
                            <div 
                                style={{ 
                                    width: `${(trace.latency / maxLatency) * 100}%`, 
                                    background: trace.latency > 1500 ? '#ff4d4d' : '#4caf50', 
                                    height: '100%' 
                                }} 
                            />
                        </div>

                        <div style={{ width: '100px', textAlign: 'right', fontWeight: 'bold' }}>
                            {trace.latency}ms
                        </div>
                        <div style={{ width: '80px', textAlign: 'right', color: '#888' }}>
                            ${trace.cost.toFixed(3)}
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
};
