/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * @fileoverview A simple Token Bucket Rate Limiter with integrated Cost Tracking.
 * Designed for a Node.js backend managing access to a local LLM (e.g., Ollama).
 */

/**
 * Configuration interface for the Token Bucket.
 */
interface RateLimiterConfig {
    capacity: number;       // Max tokens in the bucket (burst size)
    refillRate: number;     // Tokens added per second
    costPerRequest: number; // Tokens deducted per API call
}

/**
 * Result interface for cost tracking metrics.
 */
interface CostMetrics {
    tokensUsed: number;
    inferenceTimeMs: number;
    timestamp: Date;
    status: 'ALLOWED' | 'THROTTLED';
}

/**
 * Simulates an LLM inference call.
 * In a real app, this would be `ollama.generate()` or `transformers.js` call.
 */
async function mockLLMInference(prompt: string): Promise<{ response: string; tokens: number }> {
    // Simulate network latency and processing time (100ms - 500ms)
    const latency = Math.random() * 400 + 100;
    await new Promise(resolve => setTimeout(resolve, latency));
    
    // Estimate tokens based on prompt length (rough heuristic)
    const estimatedTokens = Math.ceil(prompt.length / 4); 
    
    return {
        response: `Processed: ${prompt}`,
        tokens: estimatedTokens
    };
}

/**
 * Token Bucket implementation for Rate Limiting.
 */
class TokenBucket {
    private tokens: number;
    private lastRefill: number;
    private config: RateLimiterConfig;

    constructor(config: RateLimiterConfig) {
        this.config = config;
        this.tokens = config.capacity; // Start full
        this.lastRefill = Date.now();
    }

    /**
     * Attempt to consume tokens.
     * Returns true if request is allowed, false if throttled.
     */
    tryConsume(): boolean {
        this.refill();
        if (this.tokens >= this.config.costPerRequest) {
            this.tokens -= this.config.costPerRequest;
            return true;
        }
        return false;
    }

    /**
     * Refills the bucket based on time elapsed since last refill.
     */
    private refill(): void {
        const now = Date.now();
        const timePassed = (now - this.lastRefill) / 1000; // Convert to seconds
        const tokensToAdd = timePassed * this.config.refillRate;

        if (tokensToAdd > 0) {
            this.tokens = Math.min(this.config.capacity, this.tokens + tokensToAdd);
            this.lastRefill = now;
        }
    }

    /**
     * Returns current bucket state for monitoring.
     */
    getStats() {
        return {
            currentTokens: this.tokens,
            capacity: this.config.capacity,
            refillRate: this.config.refillRate
        };
    }
}

/**
 * Main Application Logic: Handles the request lifecycle.
 */
async function handleRequest(prompt: string, rateLimiter: TokenBucket): Promise<CostMetrics> {
    const startTime = Date.now();

    // 1. Check Rate Limit
    const isAllowed = rateLimiter.tryConsume();

    if (!isAllowed) {
        // Return immediate throttling metrics
        return {
            tokensUsed: 0,
            inferenceTimeMs: Date.now() - startTime,
            timestamp: new Date(),
            status: 'THROTTLED'
        };
    }

    // 2. Execute LLM Inference (if allowed)
    try {
        const result = await mockLLMInference(prompt);
        const inferenceTime = Date.now() - startTime;

        // 3. Track Cost (Tokens + Latency)
        return {
            tokensUsed: result.tokens,
            inferenceTimeMs: inferenceTime,
            timestamp: new Date(),
            status: 'ALLOWED'
        };
    } catch (error) {
        console.error("LLM Inference Error:", error);
        throw error;
    }
}

// --- Usage Simulation ---

// Initialize Limiter: 10 token capacity, refills 2 tokens/sec, costs 1 token/request
const limiter = new TokenBucket({
    capacity: 10,
    refillRate: 2,
    costPerRequest: 1
});

// Simulate a burst of requests
async function simulateTraffic() {
    console.log("--- Starting Traffic Simulation ---");
    const prompts = [
        "Hello, world!", 
        "Explain WebGPU.", 
        "What is WASM SIMD?", 
        "Tell me a joke.", 
        "Code a tokenizer.", 
        "Debug this error.", 
        "Optimize my code.", 
        "What is RAG?", 
        "Explain transformers.", 
        "Summarize this text.", // 10th request
        "This should fail.",     // 11th request (burst limit)
        "And this too."          // 12th request
    ];

    // Fire requests rapidly to test burst capacity
    const promises = prompts.map((p, i) => 
        handleRequest(p, limiter).then(res => {
            console.log(`Request ${i + 1}: [${res.status}] - Tokens: ${res.tokensUsed}, Latency: ${res.inferenceTimeMs}ms`);
        })
    );

    await Promise.all(promises);
    
    // Wait for refill and try again
    console.log("\n--- Waiting for Refill (3 seconds)... ---\n");
    await new Promise(resolve => setTimeout(resolve, 3000));
    
    const refillCheck = await handleRequest("Request after refill", limiter);
    console.log(`Refill Check: [${refillCheck.status}] - Tokens: ${refillCheck.tokensUsed}`);
}

simulateTraffic();
