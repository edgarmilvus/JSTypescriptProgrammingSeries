/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// pages/api/chat.ts
// Next.js API Route Handler
// Target: Node.js 18+ environment

import { NextApiRequest, NextApiResponse } from 'next';

/**
 * ============================================================================
 * 1. INTERFACES & TYPES (Immutable State Management)
 * ============================================================================
 * Defines the shape of our data without mutable side effects.
 */

// Configuration for the Token Bucket algorithm
interface RateLimiterConfig {
  capacity: number;      // Max tokens (requests) allowed in the bucket
  refillRate: number;    // Tokens added per second
  costPerRequest: number // Tokens consumed per request (weighted by complexity)
}

// The immutable state snapshot of the rate limiter
interface RateLimiterState {
  tokens: number;
  lastRefill: number; // Timestamp in ms
}

// Metrics for cost tracking
interface CostMetrics {
  promptTokens: number;
  completionTokens: number;
  latencyMs: number;
  estimatedComputeCost: number; // Arbitrary dollar value for demo
}

// The core payload expected by the API
interface ChatRequestPayload {
  query: string;
  userId: string;
}

/**
 * ============================================================================
 * 2. CONFIGURATION & HARDWARE LIMITS
 * ============================================================================
 * Defining constraints based on local hardware (Ollama/Transformers.js).
 */

const CONFIG: RateLimiterConfig = {
  capacity: 10,          // Allow burst of 10 requests
  refillRate: 2,         // Add 2 tokens per second
  costPerRequest: 1,     // Standard request costs 1 token
};

// Simulated hardware overhead (VRAM usage tracking simulation)
const HARDWARE_LIMITS = {
  maxConcurrentInferences: 2, // Simulating a GPU with limited parallel capacity
  contextWindow: 4096,         // Token limit
};

/**
 * ============================================================================
 * 3. STATE MANAGEMENT STORE
 * ============================================================================
 * A lightweight in-memory store. In production, use Redis or Upstash.
 * We treat state as immutable: updates return new objects, never mutate existing ones.
 */

const userStates = new Map<string, RateLimiterState>();

/**
 * Calculates the number of tokens to refill based on elapsed time.
 * Pure function: No side effects.
 * 
 * @param state - Current immutable state
 * @param now - Current timestamp
 * @param config - Rate limiter configuration
 * @returns New state with updated token count
 */
const refillTokens = (
  state: RateLimiterState, 
  now: number, 
  config: RateLimiterConfig
): RateLimiterState => {
  const elapsed = (now - state.lastRefill) / 1000; // Convert to seconds
  const tokensToAdd = Math.floor(elapsed * config.refillRate);
  
  if (tokensToAdd <= 0) return state; // No change needed

  const newTokenCount = Math.min(config.capacity, state.tokens + tokensToAdd);
  
  // Return a NEW state object (Immutable State Management)
  return {
    tokens: newTokenCount,
    lastRefill: now, // Reset refill clock to now
  };
};

/**
 * Attempts to consume tokens from the bucket.
 * 
 * @param userId - Unique identifier
 * @param cost - Token cost of the request
 * @returns Object containing allowed boolean and remaining tokens
 */
const consumeTokens = (
  userId: string, 
  cost: number
): { allowed: boolean; remaining: number } => {
  const now = Date.now();
  
  // Retrieve or initialize state immutably
  const currentState = userStates.get(userId) || { 
    tokens: CONFIG.capacity, 
    lastRefill: now 
  };

  // Apply refill logic (creates new state)
  const refilledState = refillTokens(currentState, now, CONFIG);

  // Check if we have enough tokens
  if (refilledState.tokens >= cost) {
    // Deduct cost and create final new state
    const newState = {
      ...refilledState,
      tokens: refilledState.tokens - cost,
    };
    
    // Persist the new immutable state
    userStates.set(userId, newState);
    
    return { allowed: true, remaining: newState.tokens };
  }

  // If not allowed, we still update the state (to track time) but don't deduct
  userStates.set(userId, refilledState);
  return { allowed: false, remaining: refilledState.tokens };
};

/**
 * ============================================================================
 * 4. COST TRACKING & METRICS
 * ============================================================================
 * Middleware logic to measure hardware overhead and token usage.
 */

/**
 * Simulates the actual AI inference call (Ollama/Transformers.js).
 * In a real app, this would be an async fetch to localhost:11434/api/generate.
 * 
 * @param query - User input
 * @returns Promise resolving to simulated inference data
 */
const mockInference = async (query: string): Promise<{ response: string; tokens: number }> => {
  // Simulate processing latency (CPU/GPU bound)
  const processingTime = Math.random() * 500 + 100; // 100ms to 600ms
  
  // Simulate VRAM pressure (conceptual)
  if (Math.random() > 0.9) {
    // Simulate a hardware spike
    console.warn('[Hardware Monitor] VRAM Spike detected');
  }

  await new Promise(resolve => setTimeout(resolve, processingTime));
  
  // Estimate token count (rough heuristic: 4 chars per token)
  const estimatedTokens = Math.ceil(query.length / 4);
  
  return {
    response: `Processed: ${query}`,
    tokens: estimatedTokens,
  };
};

/**
 * Calculates the financial cost of the request based on latency and simulated compute units.
 * 
 * @param metrics - Latency and token counts
 * @returns Estimated cost in dollars
 */
const calculateComputeCost = (metrics: Omit<CostMetrics, 'estimatedComputeCost'>): number => {
  // Base cost per 1k tokens
  const COST_PER_1K_TOKENS = 0.0005; 
  // Cost per second of GPU time (simulated)
  const COST_PER_SECOND_GPU = 0.002;

  const tokenCost = (metrics.promptTokens + metrics.completionTokens) / 1000 * COST_PER_1K_TOKENS;
  const latencyCost = (metrics.latencyMs / 1000) * COST_PER_SECOND_GPU;

  return parseFloat((tokenCost + latencyCost).toFixed(4));
};

/**
 * ============================================================================
 * 5. API HANDLER (Next.js Entry Point)
 * ============================================================================
 * Orchestrates Rate Limiting -> Inference -> Cost Tracking -> Response.
 */

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  // 1. Validate Request Method
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method Not Allowed' });
  }

  // 2. Parse Payload
  const { query, userId } = req.body as ChatRequestPayload;
  
  if (!query || !userId) {
    return res.status(400).json({ error: 'Missing query or userId' });
  }

  // 3. Rate Limiting Check (Token Bucket)
  const rateLimit = consumeTokens(userId, CONFIG.costPerRequest);

  if (!rateLimit.allowed) {
    // Track this as a "cost" event (denied requests still consume resources)
    console.log(`[Rate Limit] User ${userId} denied. Remaining: ${rateLimit.remaining}`);
    return res.status(429).json({ 
      error: 'Too Many Requests', 
      retryAfter: 1, // Simple retry hint
      remainingTokens: rateLimit.remaining 
    });
  }

  // 4. Execute Inference & Track Metrics
  const startTime = performance.now();
  
  try {
    const inferenceResult = await mockInference(query);
    const endTime = performance.now();
    const latency = endTime - startTime;

    // 5. Calculate Costs
    const costMetrics: CostMetrics = {
      promptTokens: Math.ceil(query.length / 4),
      completionTokens: inferenceResult.tokens,
      latencyMs: latency,
      estimatedComputeCost: 0, // Will be calculated
    };
    
    // Finalize cost calculation
    costMetrics.estimatedComputeCost = calculateComputeCost(costMetrics);

    // 6. Log Metrics (Cost Tracking)
    // In production, send this to Datadog, Prometheus, or a logging DB.
    console.log(`[Cost Tracker] User: ${userId} | Latency: ${latency.toFixed(2)}ms | Cost: $${costMetrics.estimatedComputeCost}`);

    // 7. Return Response
    return res.status(200).json({
      response: inferenceResult.response,
      metrics: {
        tokensUsed: costMetrics.promptTokens + costMetrics.completionTokens,
        latency: costMetrics.latencyMs,
        cost: costMetrics.estimatedComputeCost,
        rateLimitRemaining: rateLimit.remaining
      }
    });

  } catch (error) {
    console.error('[Inference Error]', error);
    return res.status(500).json({ error: 'Internal Server Error' });
  }
}
