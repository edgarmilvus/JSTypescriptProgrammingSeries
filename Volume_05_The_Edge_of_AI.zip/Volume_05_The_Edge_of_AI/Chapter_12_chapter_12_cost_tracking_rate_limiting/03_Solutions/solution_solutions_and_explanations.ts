/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

interface RateLimiterOptions {
    maxTokens: number;
    refillRate: number; // Tokens per second
}

export class RateLimiter {
    private tokens: number;
    private readonly maxTokens: number;
    private readonly refillRate: number;
    private lastRefillTimestamp: number;
    // Mutex lock to ensure thread-safety for concurrent access in Node.js
    private mutex: Promise<void> = Promise.resolve();

    constructor(options: RateLimiterOptions) {
        this.maxTokens = options.maxTokens;
        this.refillRate = options.refillRate;
        this.tokens = options.maxTokens;
        this.lastRefillTimestamp = performance.now();
    }

    /**
     * Consumes a token if available.
     * @param tokens - Number of tokens to consume (default 1)
     * @returns Promise<boolean> - true if consumed, false if insufficient tokens
     */
    async consume(tokens = 1): Promise<boolean> {
        // Acquire lock
        const release = await this.acquireLock();
        
        try {
            this.refill();
            
            if (this.tokens >= tokens) {
                this.tokens -= tokens;
                return true;
            }
            return false;
        } finally {
            // Release lock
            release();
        }
    }

    /**
     * Internal method to refill tokens based on time elapsed.
     */
    private refill(): void {
        const now = performance.now();
        const elapsedSeconds = (now - this.lastRefillTimestamp) / 1000;
        
        if (elapsedSeconds > 0) {
            const tokensToAdd = elapsedSeconds * this.refillRate;
            this.tokens = Math.min(this.maxTokens, this.tokens + tokensToAdd);
            this.lastRefillTimestamp = now;
        }
    }

    /**
     * Simple async mutex implementation for thread safety.
     */
    private async acquireLock(): Promise<() => void> {
        let release!: () => void;
        const nextLock = this.mutex.then(() => {
            release = () => {
                resolveNext();
            };
        });
        
        // Create a promise for the *next* state
        let resolveNext: () => void;
        const newPromise = new Promise<void>((resolve) => {
            resolveNext = resolve;
        });

        this.mutex = this.mutex.then(() => newPromise);

        await nextLock;
        return release!;
    }
}

// Example Usage
// const limiter = new RateLimiter({ maxTokens: 10, refillRate: 2 });
// (async () => {
//     if (await limiter.consume()) { console.log("Allowed"); } else { console.log("Rejected"); }
// })();
