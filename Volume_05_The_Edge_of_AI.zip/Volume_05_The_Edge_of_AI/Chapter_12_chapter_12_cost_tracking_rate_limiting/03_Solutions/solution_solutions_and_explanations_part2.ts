/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

export interface InferenceMetrics {
    inputTokens: number;
    outputTokens: number;
    latencyMs: number;
    peakMemoryUsage: number; // in MB
}

export class CostTracker {
    /**
     * Tracks the cost of an inference operation.
     * @param inferenceFn The async function to execute (e.g., model.predict)
     * @param input The input string for the model
     * @returns A promise resolving to an object containing the result and metrics
     */
    async trackInference<T>(
        inferenceFn: (input: string) => Promise<T>,
        input: string
    ): Promise<{ result: T; metrics: InferenceMetrics & { computeUnits: number } }> {
        // 1. Measure Input Tokens (Simple space-based estimation)
        const inputTokens = input.trim() === "" ? 0 : input.split(/\s+/).length;

        // 2. Measure Memory Before
        const startMemory = process.memoryUsage().heapUsed;

        // 3. Measure Time Before
        const startTime = performance.now();

        // 4. Execute Inference
        const result = await inferenceFn(input);

        // 5. Measure Time After
        const endTime = performance.now();
        const latencyMs = endTime - startTime;

        // 6. Measure Memory After
        const endMemory = process.memoryUsage().heapUsed;
        const peakMemoryUsage = (endMemory - startMemory) / (1024 * 1024); // Convert to MB

        // 7. Estimate Output Tokens (Simulated ratio for this exercise)
        // In a real scenario, this would come from the model's tokenizer.
        const outputTokens = Math.floor(inputTokens * 1.5); 

        // 8. Calculate Compute Units
        // Formula: (input + output) * (latency in seconds)
        const computeUnits = (inputTokens + outputTokens) * (latencyMs / 1000);

        const metrics: InferenceMetrics = {
            inputTokens,
            outputTokens,
            latencyMs,
            peakMemoryUsage
        };

        return {
            result,
            metrics: {
                ...metrics,
                computeUnits
            }
        };
    }
}

// Example Usage
// const tracker = new CostTracker();
// const res = await tracker.trackInference(async (inp) => `Processed: ${inp}`, "Hello AI");
// console.log(res.metrics);
