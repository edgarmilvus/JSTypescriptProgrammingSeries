/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState } from 'react';

// Types
interface InferenceMetrics {
  latencyMs: number;
  inputTokens: number;
  outputTokens: number;
}

interface GPUMetricsDashboardProps {
  initialMetrics?: InferenceMetrics[];
}

const GPUMetricsDashboard: React.FC<GPUMetricsDashboardProps> = ({ initialMetrics = [] }) => {
  const [metricsHistory, setMetricsHistory] = useState<InferenceMetrics[]>(initialMetrics);

  // Helper to generate random mock data
  const generateMockMetrics = (): InferenceMetrics => {
    const latency = Math.floor(Math.random() * 3000) + 100; // 100ms to 3100ms
    return {
      latencyMs: latency,
      inputTokens: Math.floor(Math.random() * 50) + 10,
      outputTokens: Math.floor(Math.random() * 50) + 10,
    };
  };

  const handleSimulate = () => {
    // Simulate network delay
    setTimeout(() => {
      const newMetric = generateMockMetrics();
      // Update state immutably
      setMetricsHistory((prev) => [...prev, newMetric].slice(-20)); // Keep last 20
    }, 500);
  };

  // Calculate Average Latency of last 5 requests
  const lastFive = metricsHistory.slice(-5);
  const avgLatency = lastFive.length > 0 
    ? lastFive.reduce((sum, m) => sum + m.latencyMs, 0) / lastFive.length 
    : 0;
  
  const isOverloaded = avgLatency > 2000;

  // Calculate Totals
  const totalInput = metricsHistory.reduce((sum, m) => sum + m.inputTokens, 0);
  const totalOutput = metricsHistory.reduce((sum, m) => sum + m.outputTokens, 0);

  // Styles
  const dashboardStyle: React.CSSProperties = {
    padding: '20px',
    border: '1px solid #ccc',
    borderRadius: '8px',
    backgroundColor: isOverloaded ? '#ffe6e6' : '#f9f9f9',
    transition: 'background-color 0.3s ease',
    fontFamily: 'sans-serif',
  };

  const barContainerStyle: React.CSSProperties = {
    display: 'flex',
    alignItems: 'flex-end',
    height: '100px',
    gap: '2px',
    marginTop: '10px',
    marginBottom: '20px',
    borderBottom: '1px solid #ddd',
  };

  const barStyle = (latency: number): React.CSSProperties => ({
    width: '10px',
    backgroundColor: latency > 2000 ? 'red' : '#4caf50',
    height: `${Math.min(latency / 30, 100)}%`, // Scale for visualization
    title: `${latency}ms`,
  });

  return (
    <div style={dashboardStyle}>
      <h3>GPU Metrics Dashboard</h3>
      
      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '10px' }}>
        <div>Total Input Tokens: {totalInput}</div>
        <div>Total Output Tokens: {totalOutput}</div>
      </div>

      <div>
        <strong>Last 10 Latencies (ms):</strong>
        <div style={barContainerStyle}>
          {metricsHistory.slice(-10).map((m, idx) => (
            <div 
              key={idx} 
              style={barStyle(m.latencyMs)} 
              title={`${m.latencyMs}ms`} // Tooltip
            />
          ))}
        </div>
      </div>

      <div>
        <strong>Status:</strong> {isOverloaded ? `OVERLOADED (Avg: ${avgLatency.toFixed(0)}ms)` : "Healthy"}
      </div>

      <button onClick={handleSimulate} style={{ marginTop: '10px', padding: '8px 16px' }}>
        Simulate Inference
      </button>
    </div>
  );
};

export default GPUMetricsDashboard;
