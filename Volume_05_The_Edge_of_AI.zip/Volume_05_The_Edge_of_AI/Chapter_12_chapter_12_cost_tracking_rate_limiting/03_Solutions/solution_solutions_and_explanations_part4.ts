/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

/**
 * Batches prompts based on token count limits.
 * @param prompts Array of string prompts
 * @param tokenEstimator Function to estimate token count for a string
 * @param maxContextLength Maximum tokens allowed per batch
 * @returns Array of batches (arrays of strings)
 */
export function batchRequests(
    prompts: string[],
    tokenEstimator: (text: string) => number,
    maxContextLength: number
): string[][] {
    const batches: string[][] = [];
    let currentBatch: string[] = [];
    let currentBatchTokenCount = 0;

    for (const prompt of prompts) {
        const tokenCount = tokenEstimator(prompt);

        // If the prompt itself exceeds the limit, we might handle it specially,
        // but for this exercise, we assume prompts are generally smaller than the limit.
        // If the current batch is empty, we must add it (even if it exceeds limit) 
        // to avoid infinite loops, or throw an error. Here we add it to a new batch.
        if (tokenCount > maxContextLength) {
            // Push any existing batch first
            if (currentBatch.length > 0) {
                batches.push(currentBatch);
                currentBatch = [];
                currentBatchTokenCount = 0;
            }
            // Create a batch for the oversized prompt alone
            batches.push([prompt]);
            continue;
        }

        // Check if adding this prompt exceeds the limit
        if (currentBatchTokenCount + tokenCount > maxContextLength) {
            // Close the current batch and start a new one
            batches.push(currentBatch);
            currentBatch = [prompt];
            currentBatchTokenCount = tokenCount;
        } else {
            // Add to current batch
            currentBatch.push(prompt);
            currentBatchTokenCount += tokenCount;
        }
    }

    // Push the final batch if it contains items
    if (currentBatch.length > 0) {
        batches.push(currentBatch);
    }

    return batches;
}

// Example Usage
// const prompts = ["Hello", "What is the capital of France?", "Explain quantum physics in one sentence."];
// const estimator = (s: string) => s.split(' ').length;
// const batches = batchRequests(prompts, estimator, 10);
// console.log(batches); 
// Output: [ ["Hello", "What is the capital of France?"], ["Explain quantum physics in one sentence."] ]
