/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

// Mock WebGPU types for TypeScript environment (since we can't run real WebGPU here)
type GPUBuffer = { size: number; usage: number; label?: string };

/**
 * Represents immutable model weights. 
 * It holds a reference to a GPUBuffer but provides no methods to modify it.
 */
class ImmutableModelWeights {
    constructor(public readonly buffer: GPUBuffer) {}

    // Expose binding information without allowing modification
    getBinding(): GPUBuffer {
        return this.buffer;
    }
}

/**
 * Manages a mutable GPUBuffer for activations.
 * The reference is updated immutably via the swap method.
 */
class MutableActivationBuffer {
    constructor(private buffer: GPUBuffer) {}

    get bufferRef(): GPUBuffer {
        return this.buffer;
    }

    /**
     * Updates the internal reference to a new buffer.
     * In a real implementation, this might handle reference counting 
     * for the old buffer to allow garbage collection or reuse.
     */
    swap(newBuffer: GPUBuffer): void {
        this.buffer = newBuffer;
    }
}

export class WebGPUInferencePipeline {
    private weights: ImmutableModelWeights;
    private currentActivations: MutableActivationBuffer;
    private activeBuffers: Set<GPUBuffer> = new Set();
    // private device: GPUDevice; // Would be injected in real app

    constructor(weightsBuffer: GPUBuffer, initialActivationBuffer: GPUBuffer) {
        this.weights = new ImmutableModelWeights(weightsBuffer);
        this.currentActivations = new MutableActivationBuffer(initialActivationBuffer);
        
        // Track initial VRAM usage
        this.activeBuffers.add(weightsBuffer);
        this.activeBuffers.add(initialActivationBuffer);
    }

    /**
     * Simulates executing a compute shader step.
     */
    async executeStep(inputBuffer: GPUBuffer): Promise<GPUBuffer> {
        // In a real WebGPU app, we would:
        // 1. Create a command encoder
        // 2. Begin a compute pass
        // 3. Bind bindGroups (weights, current activations, input)
        // 4. Dispatch workgroups
        // 5. Submit commands
        
        // SIMULATION:
        // 1. Create a new buffer for the output (result of computation)
        const outputBufferSize = 1024 * 4; // Example size (e.g., 1024 floats)
        const outputBuffer: GPUBuffer = { 
            size: outputBufferSize, 
            usage: 0x89, // Storage | CopySrc
            label: "Step Output"
        };

        // 2. Update State
        // The previous activation buffer is no longer needed as the "current" state,
        // but in a real pipeline, we might keep it for residual connections or 
        // manage it via a pool. Here we simulate the swap.
        this.currentActivations.swap(outputBuffer);

        // 3. Update VRAM Tracker
        // We add the new output buffer.
        this.activeBuffers.add(outputBuffer);
        
        // (Optional) Logic to remove old buffers if they are truly orphaned
        // For this exercise, we assume we keep history or the pipeline handles cleanup.
        // To prevent infinite memory growth in this simulation, we might remove the input:
        if (inputBuffer.label !== "Initial Input") {
            this.activeBuffers.delete(inputBuffer);
        }

        return outputBuffer;
    }

    /**
     * Calculates total VRAM usage in bytes.
     */
    getVRAMUsage(): number {
        let totalBytes = 0;
        for (const buffer of this.activeBuffers) {
            totalBytes += buffer.size;
        }
        return totalBytes;
    }
}

// Example Usage
// const weights: GPUBuffer = { size: 1000000, usage: 1, label: "Weights" };
// const initAct: GPUBuffer = { size: 1024, usage: 1, label: "Initial Act" };
// const pipeline = new WebGPUInferencePipeline(weights, initAct);
// const input: GPUBuffer = { size: 1024, usage: 1, label: "Input" };
// pipeline.executeStep(input).then(() => {
//     console.log(`VRAM Usage: ${pipeline.getVRAMUsage()} bytes`);
// });
