/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * @fileoverview A basic unit test example for validating LLM prompt outputs.
 * This simulates a SaaS feature where we generate a summary for a support ticket.
 * 
 * Dependencies: None (Native Node.js APIs used for demonstration).
 * In production, you would import an LLM client (e.g., `ollama-js` or `openai`).
 */

// ==========================================
// 1. Types & Interfaces
// ==========================================

/**
 * Represents the input data for our prompt.
 */
interface SupportTicket {
  id: string;
  subject: string;
  description: string;
  priority: 'low' | 'medium' | 'high';
}

/**
 * Represents the expected structured output from the LLM.
 * We enforce this schema to prevent hallucinations.
 */
interface TicketSummary {
  summary: string;
  sentiment: 'positive' | 'neutral' | 'negative';
  suggestedAction: string;
}

// ==========================================
// 2. The Prompt Logic (The "System")
// ==========================================

/**
 * Generates a system prompt for the LLM based on the ticket data.
 * 
 * @param ticket - The support ticket object.
 * @returns A formatted string prompt.
 */
function createPrompt(ticket: SupportTicket): string {
  return `
    You are a helpful support assistant. 
    Analyze the following support ticket and provide a JSON summary.
    
    Ticket ID: ${ticket.id}
    Subject: ${ticket.subject}
    Description: ${ticket.description}
    Priority: ${ticket.priority}

    Respond ONLY with valid JSON in the following format:
    {
      "summary": "A brief 1-sentence summary of the issue.",
      "sentiment": "positive" | "neutral" | "negative",
      "suggestedAction": "One specific action to take."
    }
  `.trim();
}

/**
 * Mocks the LLM call. 
 * In a real app, this would be `await ollama.generate({ model: 'llama2', prompt: ... })`
 * 
 * For this deterministic test, we return a fixed response that matches our expected schema.
 * 
 * @param prompt - The generated prompt string.
 * @returns A promise resolving to a JSON string.
 */
async function callLLM(prompt: string): Promise<string> {
  // Simulate network latency
  await new Promise(resolve => setTimeout(resolve, 100));

  // In a real test, this might return different variations based on the input.
  // Here, we return a "happy path" response.
  const mockResponse = {
    summary: "User is experiencing login failures due to expired credentials.",
    sentiment: "negative",
    suggestedAction: "Send a password reset link immediately."
  };
  
  return JSON.stringify(mockResponse);
}

// ==========================================
// 3. The Unit Test Logic
// ==========================================

/**
 * Executes the prompt generation and validates the LLM output.
 * This function represents the core logic of our unit test.
 * 
 * @param ticket - The input ticket data.
 * @returns An object containing validation results and the parsed output.
 */
async function runPromptTest(ticket: SupportTicket) {
  // Step 1: Generate the prompt
  const prompt = createPrompt(ticket);
  
  // Step 2: Call the LLM (Mocked for this example)
  const rawOutput = await callLLM(prompt);
  
  // Step 3: Parse and Validate
  let parsedOutput: TicketSummary;
  let isValidJSON = false;
  let hasRequiredFields = false;
  let semanticCheckPass = false;

  try {
    // A. Syntax Validation: Check if output is valid JSON
    parsedOutput = JSON.parse(rawOutput);
    isValidJSON = true;

    // B. Schema Validation: Check if required fields exist
    const requiredKeys = ['summary', 'sentiment', 'suggestedAction'];
    hasRequiredFields = requiredKeys.every(key => key in parsedOutput);

    if (hasRequiredFields) {
      // C. Semantic Validation: Check if sentiment matches the priority context
      // (Simple heuristic: High priority tickets usually imply negative sentiment)
      if (ticket.priority === 'high' && parsedOutput.sentiment === 'negative') {
        semanticCheckPass = true;
      } else if (ticket.priority !== 'high') {
        // For low/medium, any sentiment is acceptable in this simple logic
        semanticCheckPass = true;
      }
    }
  } catch (error) {
    // JSON parsing failed
    isValidJSON = false;
  }

  return {
    input: ticket,
    output: parsedOutput,
    validation: {
      isValidJSON,
      hasRequiredFields,
      semanticCheckPass,
      overallPass: isValidJSON && hasRequiredFields && semanticCheckPass
    }
  };
}

// ==========================================
// 4. Execution & Assertions (Simulating a Test Runner)
// ==========================================

/**
 * Main entry point to run the test suite.
 */
async function main() {
  console.log("🧪 Running Unit Test: Support Ticket Summary\n");

  // Test Case 1: High Priority Ticket (Expecting 'negative' sentiment)
  const highPriorityTicket: SupportTicket = {
    id: "T-1001",
    subject: "Critical System Outage",
    description: "The server is down and we cannot access the database.",
    priority: "high"
  };

  const result1 = await runPromptTest(highPriorityTicket);

  console.log("--- Test Case 1: High Priority ---");
  console.log("Input:", JSON.stringify(result1.input, null, 2));
  console.log("Output:", JSON.stringify(result1.output, null, 2));
  console.log("Validation Result:", result1.validation);
  
  // Assertion
  if (!result1.validation.overallPass) {
    console.error("❌ Test Case 1 FAILED");
    process.exit(1); // Fail the CI/CD pipeline
  } else {
    console.log("✅ Test Case 1 PASSED\n");
  }

  // Test Case 2: Low Priority Ticket (Expecting structure adherence)
  const lowPriorityTicket: SupportTicket = {
    id: "T-1002",
    subject: "Feature Request",
    description: "It would be nice to have dark mode.",
    priority: "low"
  };

  // To test failure, we can simulate a bad response (e.g., hallucinated JSON)
  // Let's temporarily mock the LLM to return garbage
  const originalCallLLM = callLLM;
  (global as any).callLLM = async () => "{ 'summary': 'Bad JSON', "; // Intentional syntax error

  const result2 = await runPromptTest(lowPriorityTicket);

  console.log("--- Test Case 2: Invalid JSON Handling ---");
  console.log("Validation Result:", result2.validation);

  if (result2.validation.overallPass) {
    console.error("❌ Test Case 2 FAILED (Should have caught bad JSON)");
    process.exit(1);
  } else {
    console.log("✅ Test Case 2 PASSED (Correctly detected invalid output)\n");
  }

  console.log("🎉 All tests completed successfully.");
}

// Run the main function
if (require.main === module) {
  main();
}
