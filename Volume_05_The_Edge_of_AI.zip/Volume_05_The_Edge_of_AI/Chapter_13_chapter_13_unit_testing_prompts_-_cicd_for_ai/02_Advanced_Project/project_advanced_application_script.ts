/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

/**
 * ============================================================================
 * ADVANCED APPLICATION SCRIPT: CI/CD PROMPT VALIDATION FRAMEWORK
 * ============================================================================
 *
 * CONTEXT:
 * This script demonstrates a production-grade implementation of prompt unit testing
 * within a Next.js application. It focuses on validating LLM outputs for a
 * "Customer Support Intent Classifier" SaaS feature.
 *
 * PROBLEM STATEMENT:
 * When updating the underlying model (e.g., switching from Ollama 7B to 13B) or
 * tweaking the system prompt, we risk "regression" where the model's output format
 * or semantic accuracy degrades. This script automates that validation.
 *
 * ARCHITECTURAL PILLARS:
 * 1. Deterministic Assertions: Checking strict JSON structure and key-value presence.
 * 2. Semantic Similarity: Using embeddings to verify intent classification accuracy
 *    even if phrasing differs (e.g., "I can't login" vs "Login is broken").
 * 3. Edge Runtime: Running these tests in a high-performance environment (Vercel Edge)
 *    to minimize latency during CI/CD pipelines.
 * 4. Data Fetching in Server Components: Pre-fetching the system prompt and test
 *    dataset on the server to avoid client-side waterfalls.
 */

import { NextResponse } from 'next/server';
import type { NextRequest } from 'next/server';

// -----------------------------------------------------------------------------
// 1. CONFIGURATION & TYPES
// -----------------------------------------------------------------------------

/**
 * Represents the structure of the LLM's expected output.
 * We enforce strict typing to ensure the model adheres to our API contract.
 */
interface ClassificationResult {
  intent: 'billing' | 'technical' | 'general';
  confidence: number; // 0.0 to 1.0
  summary: string;
}

/**
 * Configuration for the test suite.
 * In a real app, these might be fetched from a database or feature flags.
 */
const TEST_CONFIG = {
  // The system prompt defining the model's behavior
  systemPrompt: `You are an expert customer support classifier. Analyze the user query and output a JSON object strictly following this schema: 
  { "intent": "billing" | "technical" | "general", "confidence": number, "summary": "string" }.
  Do not include any markdown formatting or text outside the JSON object.`,
  
  // The dataset used for validation
  testData: [
    {
      input: "My invoice is wrong, I was charged twice.",
      expectedIntent: "billing",
      expectedKeywords: ["invoice", "charged"]
    },
    {
      input: "The app crashes when I click settings.",
      expectedIntent: "technical",
      expectedKeywords: ["crashes", "settings"]
    },
    {
      input: "How do I reset my password?",
      expectedIntent: "technical", // Often categorized as technical support
      expectedKeywords: ["reset", "password"]
    }
  ]
};

// -----------------------------------------------------------------------------
// 2. MOCK LLM CLIENT (Simulating Ollama/Transformers.js)
// -----------------------------------------------------------------------------

/**
 * Mocks a call to a local LLM (like Ollama) or a cloud provider.
 * In production, this would be replaced by `fetch('http://localhost:11434/api/generate')`
 * or the Transformers.js runtime.
 * 
 * @param prompt - The full conversation context
 * @returns A Promise resolving to the raw string response from the LLM
 */
async function callLLM(prompt: string): Promise<string> {
  // Simulate network latency
  await new Promise(resolve => setTimeout(resolve, 150));
  
  // Simulate a deterministic mock response for testing purposes.
  // In a real CI/CD test, we might use a fixed seed or a specific model snapshot.
  if (prompt.includes("invoice is wrong")) {
    return `{ "intent": "billing", "confidence": 0.95, "summary": "User reports duplicate charges on invoice." }`;
  }
  if (prompt.includes("app crashes")) {
    return `{ "intent": "technical", "confidence": 0.92, "summary": "App crash on settings page." }`;
  }
  if (prompt.includes("reset my password")) {
    return `{ "intent": "technical", "confidence": 0.88, "summary": "Password reset inquiry." }`;
  }
  
  return `{ "intent": "general", "confidence": 0.5, "summary": "Unknown query." }`;
}

// -----------------------------------------------------------------------------
// 3. SEMANTIC VALIDATION UTILITIES
// -----------------------------------------------------------------------------

/**
 * Parses the raw LLM string output into a typed object.
 * Handles JSON parsing errors gracefully.
 * 
 * @param rawOutput - The string output from the LLM
 * @returns The parsed ClassificationResult or null if parsing fails
 */
function parseOutput(rawOutput: string): ClassificationResult | null {
  try {
    // Remove potential markdown code blocks (e.g., 