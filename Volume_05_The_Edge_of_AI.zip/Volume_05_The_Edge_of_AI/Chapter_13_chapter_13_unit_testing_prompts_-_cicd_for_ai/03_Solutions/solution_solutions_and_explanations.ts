/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// types.ts
type ValidationRule = 
  | { type: 'regex'; pattern: RegExp; description: string }
  | { type: 'length'; min?: number; max?: number }
  | { type: 'contains'; substrings: string[] };

type ValidationResult = {
  isValid: boolean;
  failures: Array<{ rule: ValidationRule; reason: string }>;
};

// validator.ts
export function validateOutput(output: string, rules: ValidationRule[]): ValidationResult {
  const failures: Array<{ rule: ValidationRule; reason: string }> = [];

  for (const rule of rules) {
    switch (rule.type) {
      case 'regex':
        if (!rule.pattern.test(output)) {
          failures.push({
            rule,
            reason: `Output did not match the required pattern: ${rule.description}`,
          });
        }
        break;

      case 'length':
        // Acknowledgment: In production, we might estimate tokens (e.g., Math.ceil(output.length / 4))
        // instead of raw character count, as LLMs tokenize text.
        const len = output.length;
        if (rule.min !== undefined && len < rule.min) {
          failures.push({
            rule,
            reason: `Length ${len} is less than minimum ${rule.min}`,
          });
        }
        if (rule.max !== undefined && len > rule.max) {
          failures.push({
            rule,
            reason: `Length ${len} exceeds maximum ${rule.max}`,
          });
        }
        break;

      case 'contains':
        const missingSubstrings = rule.substrings.filter((sub) => !output.includes(sub));
        if (missingSubstrings.length > 0) {
          failures.push({
            rule,
            reason: `Output is missing required substrings: ${missingSubstrings.join(', ')}`,
          });
        }
        break;
    }
  }

  return {
    isValid: failures.length === 0,
    failures,
  };
}
