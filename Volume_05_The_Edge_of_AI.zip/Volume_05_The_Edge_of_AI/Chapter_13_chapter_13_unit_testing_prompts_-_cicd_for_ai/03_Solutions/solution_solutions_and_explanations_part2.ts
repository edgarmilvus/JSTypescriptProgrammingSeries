/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

// semanticTester.ts
// Assume 'pipeline' and 'cosineSimilarity' are imported from '@xenova/transformers'
import { pipeline, cosineSimilarity } from '@xenova/transformers';

export class SemanticTester {
  private embeddingModel: any = null;
  private embeddingCache: Map<string, number[]> = new Map();

  async loadModel() {
    if (this.embeddingModel) return;
    
    console.log("Loading embedding model...");
    // Initialize the feature extraction pipeline
    this.embeddingModel = await pipeline('feature-extraction', 'Xenova/all-MiniLM-L6-v2');
    console.log("Model loaded.");
  }

  async calculateSemanticSimilarity(candidate: string, reference: string): Promise<number> {
    // Ensure the model is loaded before proceeding
    if (!this.embeddingModel) {
      await this.loadModel();
    }

    // Helper to get embedding with caching
    const getEmbedding = async (text: string): Promise<number[]> => {
      if (this.embeddingCache.has(text)) {
        return this.embeddingCache.get(text)!;
      }
      
      // Generate embedding
      // The pipeline returns a Tensor; we extract the data and average pool if needed.
      // For all-MiniLM-L6-v2, the output is typically already pooled.
      const result = await this.embeddingModel(text, { pooling: 'mean', normalize: true });
      const embedding = Array.from(result.data) as number[];
      
      this.embeddingCache.set(text, embedding);
      return embedding;
    };

    const [candidateEmbedding, referenceEmbedding] = await Promise.all([
      getEmbedding(candidate),
      getEmbedding(reference),
    ]);

    // Calculate cosine similarity
    return cosineSimilarity(candidateEmbedding, referenceEmbedding);
  }
}
