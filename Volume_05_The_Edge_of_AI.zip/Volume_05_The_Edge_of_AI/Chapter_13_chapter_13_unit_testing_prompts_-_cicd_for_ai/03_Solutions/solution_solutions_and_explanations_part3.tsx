/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

// TestResultCard.tsx
import React, { useState } from 'react';

interface TestCase {
  id: string;
  prompt: string;
  expectedOutput: string;
  actualOutput: string;
  deterministicPass: boolean;
  semanticScore: number;
}

interface TestResultCardProps {
  testCase: TestCase;
}

export const TestResultCard: React.FC<TestResultCardProps> = ({ testCase }) => {
  const [isExpanded, setIsExpanded] = useState(false);

  // Determine status badge color and text
  const getStatus = () => {
    if (!testCase.deterministicPass) {
      return { color: 'red', text: 'FAILED' };
    }
    if (testCase.semanticScore > 0.9) {
      return { color: 'green', text: 'PASS (HIGH CONFIDENCE)' };
    }
    if (testCase.semanticScore < 0.7) {
      return { color: 'yellow', text: 'PASS (LOW CONFIDENCE)' };
    }
    return { color: 'green', text: 'PASS' };
  };

  const status = getStatus();

  return (
    <div style={{ border: '1px solid #ccc', padding: '16px', margin: '8px', borderRadius: '8px' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <div>
          <strong>Test ID:</strong> {testCase.id}
        </div>
        <div style={{ 
          backgroundColor: status.color, 
          color: 'white', 
          padding: '4px 8px', 
          borderRadius: '4px',
          fontWeight: 'bold'
        }}>
          {status.text}
        </div>
      </div>

      <div style={{ marginTop: '12px' }}>
        <strong>Prompt:</strong>
        <p style={{ backgroundColor: '#f5f5f5', padding: '8px', borderRadius: '4px' }}>{testCase.prompt}</p>
      </div>

      <div style={{ marginTop: '8px' }}>
        <strong>Actual Output:</strong>
        <p style={{ backgroundColor: '#f0f8ff', padding: '8px', borderRadius: '4px' }}>{testCase.actualOutput}</p>
      </div>

      <div style={{ marginTop: '12px' }}>
        <strong>Semantic Score: {testCase.semanticScore.toFixed(2)}</strong>
        <div style={{ backgroundColor: '#e0e0e0', height: '10px', borderRadius: '5px', marginTop: '4px' }}>
          <div 
            style={{ 
              backgroundColor: '#4caf50', 
              width: `${testCase.semanticScore * 100}%`, 
              height: '100%', 
              borderRadius: '5px' 
            }} 
          />
        </div>
      </div>

      <button 
        onClick={() => setIsExpanded(!isExpanded)}
        style={{ marginTop: '12px', padding: '6px 12px', cursor: 'pointer' }}
      >
        {isExpanded ? 'Hide Details' : 'Show Details'}
      </button>

      {isExpanded && (
        <div style={{ marginTop: '12px', display: 'flex', gap: '16px' }}>
          <div style={{ flex: 1 }}>
            <strong>Expected Output:</strong>
            <pre style={{ backgroundColor: '#f9f9f9', padding: '8px', borderRadius: '4px', whiteSpace: 'pre-wrap' }}>
              {testCase.expectedOutput}
            </pre>
          </div>
          <div style={{ flex: 1 }}>
            <strong>Actual Output:</strong>
            <pre style={{ backgroundColor: '#f9f9f9', padding: '8px', borderRadius: '4px', whiteSpace: 'pre-wrap' }}>
              {testCase.actualOutput}
            </pre>
          </div>
        </div>
      )}
    </div>
  );
};
