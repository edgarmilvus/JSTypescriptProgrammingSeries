/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

// ciRunner.ts

interface TestDefinition {
  id: string;
  prompt: string;
  expectedPattern: RegExp;
}

// Mock function to simulate an Ollama API call
async function mockOllamaGenerate(prompt: string): Promise<string> {
  // Simulate network/processing delay (100-300ms)
  const delay = Math.random() * 200 + 100;
  await new Promise(resolve => setTimeout(resolve, delay));

  // Simulate variability: append a processed tag and slightly modify the prompt
  // This ensures some tests might pass and others might fail based on the regex
  return `Processed: ${prompt.toUpperCase()} [ID: ${Math.floor(Math.random() * 1000)}]`;
}

export async function runTestSuite(tests: TestDefinition[]) {
  console.log(`Starting test suite with ${tests.length} tests...`);
  console.time('Suite Duration');

  let allPassed = true;

  for (const test of tests) {
    try {
      console.log(`\nRunning test: ${test.id}`);
      console.log(`Prompt: "${test.prompt}"`);

      const result = await mockOllamaGenerate(test.prompt);
      console.log(`Received: "${result}"`);

      if (test.expectedPattern.test(result)) {
        console.log(`✅ Test ${test.id} PASSED`);
      } else {
        console.error(`❌ Test ${test.id} FAILED - Output did not match pattern.`);
        allPassed = false;
      }
    } catch (error) {
      console.error(`💥 Test ${test.id} ERROR -`, error);
      allPassed = false;
    }
  }

  console.timeEnd('Suite Duration');

  if (allPassed) {
    console.log('\n🎉 All tests passed! Exiting with code 0.');
    process.exit(0);
  } else {
    console.error('\n❌ Some tests failed. Exiting with code 1.');
    process.exit(1);
  }
}

// Example usage (if run directly)
/*
runTestSuite([
  { id: 'T1', prompt: 'hello', expectedPattern: /^Processed: HELLO \[ID: \d+\]$/ },
  { id: 'T2', prompt: 'test', expectedPattern: /^Processed: TEST \[ID: \d+\]$/ },
  { id: 'T3', prompt: 'fail', expectedPattern: /^This will not match$/ }, // This one will fail
]);
*/
