/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

// optimizer.ts

export function checkTokenBudget(
  prompt: string,
  maxInputTokens: number,
  maxOutputTokens: number
): void {
  // Heuristic: 1 token ~= 4 characters. This is a rough estimate for English text.
  const estimatedInputTokens = Math.ceil(prompt.length / 4);

  if (estimatedInputTokens > maxInputTokens) {
    throw new Error(
      `Token budget exceeded. Prompt estimated at ${estimatedInputTokens} tokens, ` +
      `which is over the limit of ${maxInputTokens}.`
    );
  }
  
  // We can also log the output budget for context, though it's not used for validation here.
  console.log(`Token Budget Check: Input ~${estimatedInputTokens}/${maxInputTokens}, Output Limit: ${maxOutputTokens}`);
}

// In a browser environment, navigator.gpu is available.
// For Node.js, we might mock this check or check for specific modules.
export function getInferenceBackend(): string {
  // Check for WebGPU (Browser context)
  if (typeof navigator !== 'undefined' && (navigator as any).gpu) {
    return 'WebGPU';
  }
  
  // Check for Node.js environment
  if (typeof process !== 'undefined' && process.versions && process.versions.node) {
    // In Node.js, inference often falls back to CPU or WASM depending on the library (e.g., onnxruntime-node)
    // For this simulation, we assume WASM/CPU is the fallback.
    return 'WASM/CPU (Node.js)';
  }

  // Default fallback for other environments (e.g., older browsers)
  return 'CPU';
}

export function createTestBatches<T>(tests: T[], batchSize: number): T[][] {
  const batches: T[][] = [];
  
  for (let i = 0; i < tests.length; i += batchSize) {
    // Slice the array from the current index to the next batch boundary
    const batch = tests.slice(i, i + batchSize);
    batches.push(batch);
  }
  
  return batches;
}
