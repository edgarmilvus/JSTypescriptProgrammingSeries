/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// types.ts
interface Message {
  role: 'system' | 'user' | 'assistant';
  content: string;
}

/**
 * Estimates the number of tokens in a string by splitting on spaces.
 * NOTE: This is a naive estimator for demonstration purposes. 
 * Real-world tokenization (e.g., for LLMs) uses byte-pair encoding (BPE) 
 * or WordPiece, which is more complex.
 * @param text The string to tokenize.
 * @returns The estimated token count.
 */
function estimateTokenCount(text: string): number {
  if (!text) return 0;
  // Split by whitespace and filter out empty strings
  return text.trim().split(/\s+/).length;
}

/**
 * Truncates a conversation history to ensure it fits within a max token limit,
 * preserving the system prompt at the start.
 * 
 * @param messages - Array of conversation messages.
 * @param maxTokens - The maximum allowed token count.
 * @returns The truncated message array.
 */
export function truncateConversation(messages: Message[], maxTokens: number): Message[] {
  // 1. Separate the system prompt from the rest of the history
  const systemPrompt = messages.find(m => m.role === 'system');
  const history = messages.filter(m => m.role !== 'system');

  // 2. Calculate tokens for the system prompt (if it exists)
  let systemTokens = 0;
  if (systemPrompt) {
    systemTokens = estimateTokenCount(systemPrompt.content);
  }

  // 3. Check if the system prompt alone exceeds the limit
  if (systemTokens > maxTokens) {
    // If the system prompt is too big, we cannot truncate further safely.
    // Return just the system prompt (truncated logic omitted for simplicity).
    return systemPrompt ? [systemPrompt] : [];
  }

  // 4. Iterate through history from newest to oldest to keep context
  // We need to fit: SystemTokens + HistoryTokens <= maxTokens
  const remainingCapacity = maxTokens - systemTokens;
  let currentTokenCount = 0;
  const keptHistory: Message[] = [];

  // Iterate backwards (reverse) to prioritize recent messages
  for (let i = history.length - 1; i >= 0; i--) {
    const message = history[i];
    const tokens = estimateTokenCount(message.content);

    if (currentTokenCount + tokens <= remainingCapacity) {
      keptHistory.unshift(message); // Add to beginning to restore order
      currentTokenCount += tokens;
    } else {
      // Stop adding once we hit the limit
      break;
    }
  }

  // 5. Reconstruct the array: System Prompt + Kept History
  return systemPrompt ? [systemPrompt, ...keptHistory] : keptHistory;
}

// Example Usage:
// const longMessages: Message[] = [
//   { role: 'system', content: 'You are helpful.' }, // 4 tokens
//   { role: 'user', content: 'Hello' }, // 1 token
//   { role: 'assistant', content: 'Hi' }, // 1 token
//   { role: 'user', content: 'Tell me a long story' } // 4 tokens
// ];
// truncateConversation(longMessages, 8); 
// Result: Keeps system + recent messages fitting within 8 tokens.
