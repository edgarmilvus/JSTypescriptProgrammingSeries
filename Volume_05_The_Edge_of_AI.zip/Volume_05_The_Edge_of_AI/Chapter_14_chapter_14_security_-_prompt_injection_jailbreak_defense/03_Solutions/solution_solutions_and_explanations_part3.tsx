/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

// SafeLLMInput.tsx
import React, { useState } from 'react';

const BLOCKED_PHRASES = ['ignore previous', 'system prompt override'];
const MAX_CHAR_LENGTH = 500;

// Mock function to simulate the API call
const sendToLLM = (input: string) => {
  console.log("Sending to LLM:", input);
  alert("Message sent successfully!");
};

export const SafeLLMInput: React.FC = () => {
  const [inputText, setInputText] = useState<string>('');

  const handleChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setInputText(e.target.value);
  };

  const handleSubmit = () => {
    // 1. Length Check
    if (inputText.length > MAX_CHAR_LENGTH) {
      alert("Input too long.");
      return;
    }

    // 2. Keyword Check (Case insensitive check recommended)
    const hasBlockedPhrase = BLOCKED_PHRASES.some(phrase => 
      inputText.toLowerCase().includes(phrase.toLowerCase())
    );

    if (hasBlockedPhrase) {
      alert("Unsafe input detected.");
      return;
    }

    // 3. Pass checks and send
    sendToLLM(inputText);
  };

  return (
    <div style={{ padding: '20px', fontFamily: 'sans-serif' }}>
      <h3>Safe LLM Chat Interface</h3>
      <textarea
        value={inputText}
        onChange={handleChange}
        rows={5}
        cols={50}
        placeholder="Type your message here..."
        style={{ width: '100%', marginBottom: '10px' }}
      />
      <div style={{ fontSize: '12px', color: '#666', marginBottom: '10px' }}>
        Characters: {inputText.length} / {MAX_CHAR_LENGTH}
      </div>
      <button onClick={handleSubmit} disabled={!inputText.trim()}>
        Send
      </button>
    </div>
  );
};
