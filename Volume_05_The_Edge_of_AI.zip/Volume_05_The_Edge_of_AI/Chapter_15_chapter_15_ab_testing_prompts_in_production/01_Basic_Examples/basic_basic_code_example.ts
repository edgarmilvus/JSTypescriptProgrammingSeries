/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

// Import necessary modules
import express, { Request, Response } from 'express';
import axios from 'axios';

// --- Configuration & Types ---

/**
 * Defines the structure of a prompt variation.
 * @property id - Unique identifier for the variation (e.g., 'A', 'B').
 * @property prompt - The actual text prompt template.
 * @property weight - The probability weight for routing (e.g., 0.5 for 50%).
 */
interface PromptVariation {
  id: string;
  prompt: string;
  weight: number;
}

/**
 * Configuration for the A/B test.
 * We are testing two summarization prompts.
 */
const PROMPT_VARIATIONS: PromptVariation[] = [
  {
    id: 'A',
    prompt: 'Summarize the following text in a single sentence: {text}',
    weight: 0.5,
  },
  {
    id: 'B',
    prompt: 'Extract the main point of this text in 10 words or less: {text}',
    weight: 0.5,
  },
];

// --- Core Logic: Weighted Routing ---

/**
 * Selects a prompt variation based on weighted random probability.
 * 
 * Algorithm:
 * 1. Generate a random number between 0 and 1.
 * 2. Iterate through variations, accumulating weights.
 * 3. Return the variation where the accumulated weight exceeds the random number.
 * 
 * @param variations - Array of prompt variations with weights.
 * @returns The selected variation object.
 */
function selectPromptVariation(variations: PromptVariation[]): PromptVariation {
  const totalWeight = variations.reduce((sum, v) => sum + v.weight, 0);
  const random = Math.random() * totalWeight;
  
  let accumulated = 0;
  for (const variation of variations) {
    accumulated += variation.weight;
    if (random < accumulated) {
      return variation;
    }
  }
  
  // Fallback (should not happen if weights sum to 1)
  return variations[0];
}

// --- LLM Integration (Ollama) ---

/**
 * Calls the local Ollama instance to generate text.
 * 
 * @param prompt - The formatted prompt string.
 * @returns The generated text response.
 */
async function callLocalLLM(prompt: string): Promise<string> {
  const OLLAMA_URL = 'http://localhost:11434/api/generate';
  
  try {
    const response = await axios.post(OLLAMA_URL, {
      model: 'llama3.2', // Ensure this model is pulled in Ollama
      prompt: prompt,
      stream: false, // We want the full response at once for this simple example
    });

    // Ollama returns a response object containing the generated text
    return response.data.response;
  } catch (error) {
    console.error('Error calling Ollama:', error);
    throw new Error('LLM inference failed');
  }
}

// --- Express Server Setup ---

const app = express();
app.use(express.json());

/**
 * Route: POST /summarize
 * 
 * Body: { "text": "The text to summarize..." }
 * 
 * Logic:
 * 1. Receive text input.
 * 2. Select prompt variation (A or B).
 * 3. Format prompt with input text.
 * 4. Call LLM.
 * 5. Return result along with the variation ID for tracking.
 */
app.post('/summarize', async (req: Request, res: Response) => {
  const { text } = req.body;

  if (!text) {
    return res.status(400).json({ error: 'Text field is required' });
  }

  try {
    // 1. A/B Test Routing
    const variation = selectPromptVariation(PROMPT_VARIATIONS);
    
    // 2. Prompt Formatting
    const finalPrompt = variation.prompt.replace('{text}', text);

    // 3. Inference
    const result = await callLocalLLM(finalPrompt);

    // 4. Response with Metadata
    res.json({
      summary: result,
      variationId: variation.id, // Crucial for logging and analysis
      promptUsed: finalPrompt,  // Optional: useful for debugging
    });
  } catch (error) {
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Start Server
const PORT = 3000;
app.listen(PORT, () => {
  console.log(`A/B Testing Server running on http://localhost:${PORT}`);
});
