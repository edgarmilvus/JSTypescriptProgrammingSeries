/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// File: app/api/summarize/route.ts
import { NextResponse } from 'next/server';

export const runtime = 'edge';

// Helper function to generate a deterministic hash (djb2 algorithm) from a string
// and normalize it to a value between 0 and 1.
function getDeterministicHash(input: string): number {
  let hash = 5381;
  for (let i = 0; i < input.length; i++) {
    hash = (hash * 33) ^ input.charCodeAt(i);
  }
  // Convert to unsigned 32-bit integer and normalize to 0-1 range
  return (hash >>> 0) / 4294967295;
}

function determinePromptVariant(userId: string): 'brevity' | 'detail' {
  const hashValue = getDeterministicHash(userId);
  // 70% threshold for 'brevity'
  return hashValue < 0.7 ? 'brevity' : 'detail';
}

export async function POST(request: Request) {
  // 1. Extract userId and text from the request
  const { userId, text } = await request.json();

  if (!userId || !text) {
    return new NextResponse('Missing userId or text', { status: 400 });
  }

  // 2. Implement the weighted routing logic
  const variant = determinePromptVariant(userId);

  // 3. Construct the appropriate system prompt
  let systemPrompt: string;
  if (variant === 'brevity') {
    systemPrompt = "You are a summarization assistant. Provide a summary in under 50 words.";
  } else {
    systemPrompt = "You are a summarization assistant. Provide a summary that includes all key entities and actions.";
  }

  // 4. Stream the response from Ollama (Simulated via fetch for this example)
  // In a real scenario, you would fetch from your local Ollama instance
  // e.g., fetch('http://localhost:11434/api/generate', { ... })
  
  // Simulating a streaming response for the sake of the exercise structure
  const encoder = new TextEncoder();
  const stream = new ReadableStream({
    async start(controller) {
      const mockResponse = `Generated summary for variant '${variant}': ${text.substring(0, 50)}...`;
      controller.enqueue(encoder.encode(mockResponse));
      controller.close();
    },
  });

  return new Response(stream, {
    headers: {
      'Content-Type': 'text/plain; charset=utf-8',
      // Optional: Pass variant info for client-side logging
      'X-AB-Variant': variant,
    },
  });
}
