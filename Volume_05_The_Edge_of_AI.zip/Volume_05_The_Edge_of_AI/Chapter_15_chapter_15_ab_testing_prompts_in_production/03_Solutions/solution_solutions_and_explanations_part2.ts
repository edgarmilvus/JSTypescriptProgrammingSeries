/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

// File: components/BatchInference.tsx
'use client';

import { pipeline, env } from '@xenova/transformers';
import { useEffect, useState } from 'react';

// Configure environment for WebGPU
env.allowLocalModels = false;
env.useBrowserCache = true;

interface Result {
  variant: string;
  output: string;
  time: number;
}

export default function BatchInference({ inputText }: { inputText: string }) {
  const [results, setResults] = useState<Result[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const runInference = async () => {
      try {
        // 1. Load model with WebGPU backend
        // We use a small model like distilgpt2 for speed
        const generator = await pipeline('text-generation', 'distilgpt2', { 
          backend: 'webgpu' // Request WebGPU backend
        });

        // 2. Define prompt templates
        const prompts = [
          { name: 'Brevity', text: `Summarize briefly: ${inputText}` },
          { name: 'Detail', text: `Summarize with key details: ${inputText}` }
        ];

        // 3. Execute batch inference (Concurrent execution using Promise.all)
        const startTime = performance.now();
        
        const promises = prompts.map(async (p) => {
          const t0 = performance.now();
          const output = await generator(p.text, { max_length: 50, do_sample: false });
          const t1 = performance.now();
          return {
            variant: p.name,
            output: output[0].generated_text,
            time: t1 - t0
          };
        });

        const generatedResults = await Promise.all(promises);
        const totalTime = performance.now() - startTime;

        setResults(generatedResults);
        console.log(`Total concurrent time (WebGPU): ${totalTime}ms`);
        generatedResults.forEach(r => console.log(`${r.variant}: ${r.time}ms`));

      } catch (error) {
        console.error("WebGPU failed or not supported, falling back to CPU", error);
        // Fallback logic (omitted for brevity, would involve setting backend: 'wasm')
      } finally {
        setLoading(false);
      }
    };

    if (inputText) runInference();
  }, [inputText]);

  if (loading) return <div>Running inference...</div>;

  return (
    <div>
      <h3>Comparison Results:</h3>
      {results.map((r, idx) => (
        <div key={idx} style={{ border: '1px solid #ccc', margin: '10px', padding: '10px' }}>
          <strong>{r.variant} Variant:</strong>
          <p>{r.output}</p>
          <small>Time: {r.time.toFixed(2)}ms</small>
        </div>
      ))}
    </div>
  );
}
