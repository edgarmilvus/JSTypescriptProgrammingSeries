/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

// File: lib/stats.ts

interface ABTestResult {
  zScore: number;
  pValue: number;
  isSignificant: boolean;
}

// Approximation of the Cumulative Distribution Function (CDF) for the Normal distribution
function normalCDF(x: number): number {
  // Constants for the approximation
  const t = 1 / (1 + 0.2316419 * Math.abs(x));
  const d = 0.3989423 * Math.exp(-x * x / 2);
  let prob = d * t * (0.3193815 + t * (-0.3565638 + t * (1.781478 + t * (-1.821256 + t * 1.330274))));
  if (x > 0) prob = 1 - prob;
  return prob;
}

export function calculateSignificance(
  nA: number,
  xA: number,
  nB: number,
  xB: number
): ABTestResult {
  // 1. Calculate proportions
  const pA = xA / nA;
  const pB = xB / nB;

  // 2. Calculate pooled proportion
  const pPool = (xA + xB) / (nA + nB);

  // 3. Calculate standard error
  const se = Math.sqrt(pPool * (1 - pPool) * (1 / nA + 1 / nB));

  // 4. Calculate Z-score
  const zScore = (pB - pA) / se;

  // 5. Calculate p-value (two-tailed test)
  // We use the absolute value of zScore for the CDF
  const pValue = 2 * (1 - normalCDF(Math.abs(zScore)));

  // 6. Return result
  return {
    zScore,
    pValue,
    isSignificant: pValue < 0.05
  };
}
