/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part6.ts
// Description: Solutions and Explanations
// ==========================================

// File: components/ABTestChart.tsx
import React, { useMemo } from 'react';

// Updated interface to handle multiple metrics (union type or nested object)
interface MetricDataPoint {
  timestamp: number;
  metrics: {
    conversionRate: number;
    latency: number; // Added for the interactive challenge
  };
}

interface ABTestChartProps {
  variantAName: string;
  variantBName: string;
  data: Array<{
    timestamp: number;
    conversionA: number;
    conversionB: number;
    latencyA?: number; // Optional for backward compatibility
    latencyB?: number;
  }>;
  metricType: 'conversion' | 'latency'; // Switch between views
}

const ABTestChart: React.FC<ABTestChartProps> = React.memo(({
  variantAName,
  variantBName,
  data,
  metricType = 'conversion'
}) => {
  // Chart dimensions
  const width = 600;
  const height = 300;
  const padding = 40;

  // Calculate scales
  const maxVal = useMemo(() => {
    if (data.length === 0) return 1;
    if (metricType === 'latency') {
      return Math.max(...data.map(d => Math.max(d.latencyA || 0, d.latencyB || 0))) * 1.1;
    }
    return 1; // Conversion rate is 0-1
  }, [data, metricType]);

  // Generate SVG paths or bars
  // For simplicity, we render a line chart for latency and bar chart for conversion
  const renderBars = () => {
    const barWidth = (width - padding * 2) / data.length / 2 - 5;
    
    return data.map((d, i) => {
      const x = padding + i * ((width - padding * 2) / data.length);
      
      // Variant A
      const valA = metricType === 'conversion' ? d.conversionA : (d.latencyA || 0) / maxVal;
      const heightA = valA * (height - padding * 2);
      const yA = height - padding - heightA;

      // Variant B
      const valB = metricType === 'conversion' ? d.conversionB : (d.latencyB || 0) / maxVal;
      const heightB = valB * (height - padding * 2);
      const yB = height - padding - heightB;

      return (
        <g key={i}>
          <rect 
            x={x} 
            y={yA} 
            width={barWidth} 
            height={heightA} 
            fill="#3b82f6" 
            aria-label={`${variantAName} at ${d.timestamp}: ${valA.toFixed(2)}`}
          />
          <rect 
            x={x + barWidth + 5} 
            y={yB} 
            width={barWidth} 
            height={heightB} 
            fill="#ef4444" 
            aria-label={`${variantBName} at ${d.timestamp}: ${valB.toFixed(2)}`}
          />
        </g>
      );
    });
  };

  return (
    <svg width={width} height={height} role="img" aria-label={`A/B Test Chart comparing ${variantAName} and ${variantBName}`}>
      <title>{metricType === 'conversion' ? 'Conversion Rate Comparison' : 'Latency Comparison'}</title>
      
      {/* Axes */}
      <line x1={padding} y1={height - padding} x2={width - padding} y2={height - padding} stroke="black" />
      <line x1={padding} y1={padding} x2={padding} y2={height - padding} stroke="black" />

      {/* Bars */}
      {renderBars()}
      
      {/* Legend */}
      <rect x={width - 150} y={10} width={15} height={15} fill="#3b82f6" />
      <text x={width - 130} y={22} fontSize="12">{variantAName}</text>
      <rect x={width - 80} y={10} width={15} height={15} fill="#ef4444" />
      <text x={width - 60} y={22} fontSize="12">{variantBName}</text>
    </svg>
  );
});

export default ABTestChart;
