/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// app/api/chat/route.ts
import { WebSocketServer } from 'ws';
import { createServer } from 'http';
import { NextApiRequest, NextApiResponse } from 'next';

// Define the structure of the audio chunks received from the client
interface AudioChunk {
    type: 'audio_chunk' | 'end_of_speech';
    data: Buffer; // Raw PCM audio data
    sampleRate: number;
}

// Define the structure of the response from the local AI model
interface AIResponse {
    text: string;
    audioBuffer?: Buffer;
}

/**
 * WebSocket Server Handler for Voice-to-Voice Communication.
 * This function initializes a WebSocket server on top of a Next.js API route.
 * 
 * @param req - The incoming Next.js request object
 * @param res - The outgoing Next.js response object (used for upgrading)
 */
export default async function handler(req: NextApiRequest, res: NextApiResponse) {
    // 1. Check if the request is a WebSocket upgrade request
    if (req.headers.upgrade !== 'websocket') {
        res.writeHead(405, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: 'Method Not Allowed' }));
        return;
    }

    // 2. Initialize WebSocket Server (WSS) using the underlying HTTP server
    const server = createServer();
    const wss = new WebSocketServer({ noServer: true });

    // 3. Handle the WebSocket Upgrade
    server.on('upgrade', (request, socket, head) => {
        wss.handleUpgrade(request, socket, head, (ws) => {
            wss.emit('connection', ws, request);
        });
    });

    // 4. Connection Logic
    wss.on('connection', (ws) => {
        console.log('Client connected via WebSocket');

        // Buffer to accumulate audio chunks before processing
        let audioBuffer: Buffer[] = [];
        let bufferDuration = 0;
        const TARGET_CHUNK_DURATION = 1.0; // Process every 1 second of audio

        // Event: Message from Client (Audio Data)
        ws.on('message', async (message: Buffer) => {
            try {
                // Parse the incoming message (assuming JSON + Binary hybrid or pure binary)
                // For simplicity, we assume a JSON wrapper with a binary payload in a real scenario.
                // Here we simulate receiving raw audio chunks.
                
                const chunk: AudioChunk = JSON.parse(message.toString());
                
                if (chunk.type === 'audio_chunk') {
                    // Accumulate chunks
                    audioBuffer.push(chunk.data);
                    
                    // Estimate duration based on sample rate and buffer size
                    // (Simplified calculation for demonstration)
                    bufferDuration += chunk.data.length / chunk.sampleRate;

                    // 5. Buffer Management & Inference Trigger
                    // If we have enough audio, process it (Voice Activity Detection logic omitted for brevity)
                    if (bufferDuration >= TARGET_CHUNK_DURATION) {
                        const combinedAudio = Buffer.concat(audioBuffer);
                        
                        // Reset buffer
                        audioBuffer = [];
                        bufferDuration = 0;

                        // --- PROCESSING PIPELINE ---
                        
                        // A. Speech-to-Text (STT) - Integration with Ollama/Transformers.js
                        const transcribedText = await mockSTTInference(combinedAudio);
                        console.log(`Transcribed: ${transcribedText}`);

                        if (transcribedText.trim().length > 0) {
                            // B. LLM Processing (Optional, can be skipped for simple echo)
                            const llmResponse = await mockLLMResponse(transcribedText);

                            // C. Text-to-Speech (TTS) - Synthesis
                            const audioResponse = await mockTTSInference(llmResponse);

                            // D. Stream Audio Back to Client
                            // We split the audio into smaller chunks to simulate streaming
                            const CHUNK_SIZE = 4096; // Bytes
                            for (let i = 0; i < audioResponse.length; i += CHUNK_SIZE) {
                                const chunkData = audioResponse.slice(i, i + CHUNK_SIZE);
                                ws.send(JSON.stringify({
                                    type: 'audio_response',
                                    data: chunkData,
                                    isFinal: (i + CHUNK_SIZE) >= audioResponse.length
                                }));
                            }
                        }
                    }
                }
            } catch (error) {
                console.error('Error processing message:', error);
                ws.send(JSON.stringify({ type: 'error', message: 'Processing failed' }));
            }
        });

        // Event: Client Disconnect
        ws.on('close', () => {
            console.log('Client disconnected');
            audioBuffer = []; // Clear buffer
        });
    });

    // Start the server
    server.listen(3001); // Note: Next.js typically runs on 3000, we use a separate port or hook into the existing server
    res.end(); // End the initial HTTP response
}

/**
 * MOCK: Speech-to-Text Inference
 * In production, this would call Ollama API or run a Transformers.js model.
 * @param audioBuffer - Raw audio data
 * @returns Promise<string> - Transcribed text
 */
async function mockSTTInference(audioBuffer: Buffer): Promise<string> {
    // Simulate network/processing delay
    await new Promise(r => setTimeout(r, 200)); 
    // Simulate transcription result
    return "Hello, this is a test of the voice system.";
}

/**
 * MOCK: LLM Response Generation
 * @param inputText - User input
 * @returns Promise<string> - AI response
 */
async function mockLLMResponse(inputText: string): Promise<string> {
    // Simulate LLM generation delay
    await new Promise(r => setTimeout(r, 300));
    return `You said: "${inputText}". I am processing this in real-time.`;
}

/**
 * MOCK: Text-to-Speech Inference
 * In production, this would call a local TTS model or API.
 * @param text - Text to synthesize
 * @returns Promise<Buffer> - Audio data (WAV/MP3)
 */
async function mockTTSInference(text: string): Promise<Buffer> {
    // Simulate TTS generation delay
    await new Promise(r => setTimeout(r, 400));
    // Return a dummy buffer (simulating audio data)
    return Buffer.alloc(16000, 'audio-data'); 
}
