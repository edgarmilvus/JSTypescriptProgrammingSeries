/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// types.ts
export interface AudioChunk {
  data: Int16Array; // PCM data
  timestamp: number;
  sequenceId: number; // Added for tracking
}

export type AudioCaptureCallback = (chunk: AudioChunk) => void;

// AudioCaptureService.ts
export class AudioCaptureService {
  private audioContext: AudioContext | null = null;
  private mediaStream: MediaStream | null = null;
  private processor: ScriptProcessorNode | null = null;
  private onAudioData: AudioCaptureCallback | null = null;
  private sequenceCounter = 0;

  constructor(private sampleRate: number = 16000) {}

  async start(onAudioData: AudioCaptureCallback): Promise<void> {
    this.onAudioData = onAudioData;

    try {
      // 1. Request Microphone Access
      this.mediaStream = await navigator.mediaDevices.getUserMedia({
        audio: {
          channelCount: 1,
          echoCancellation: true,
          noiseSuppression: true,
          sampleRate: this.sampleRate,
        },
      });

      // 2. Setup AudioContext and Nodes
      this.audioContext = new (window.AudioContext || (window as any).webkitAudioContext)({
        sampleRate: this.sampleRate,
      });

      const source = this.audioContext.createMediaStreamSource(this.mediaStream);
      
      // ScriptProcessorNode is deprecated but widely supported; AudioWorklet is preferred for production
      // Buffer size 4096, 1 input channel, 1 output channel
      this.processor = this.audioContext.createScriptProcessor(4096, 1, 1);

      // 3. Define the audio processing callback
      this.processor.onaudioprocess = (event: AudioProcessingEvent) => {
        // Get raw Float32 data
        const inputData = event.inputBuffer.getChannelData(0);
        
        // Convert Float32 (-1.0 to 1.0) to Int16 (-32768 to 32767)
        const pcmData = new Int16Array(inputData.length);
        for (let i = 0; i < inputData.length; i++) {
          let s = Math.max(-1, Math.min(1, inputData[i]));
          pcmData[i] = s < 0 ? s * 0x8000 : s * 0x7FFF;
        }

        // Emit event
        if (this.onAudioData) {
          this.onAudioData({
            data: pcmData,
            timestamp: Date.now(),
            sequenceId: this.sequenceCounter++,
          });
        }
      };

      // Connect nodes
      source.connect(this.processor);
      this.processor.connect(this.audioContext.destination); // Necessary for script processor to function

    } catch (error) {
      console.error("Audio capture failed:", error);
      throw error;
    }
  }

  stop(): void {
    if (this.processor) {
      this.processor.disconnect();
      this.processor.onaudioprocess = null;
      this.processor = null;
    }

    if (this.mediaStream) {
      this.mediaStream.getTracks().forEach(track => track.stop());
      this.mediaStream = null;
    }

    if (this.audioContext) {
      this.audioContext.close();
      this.audioContext = null;
    }

    this.onAudioData = null;
  }
}
