/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

// WebSocketAudioClient.ts
interface WebSocketConfig {
  url: string;
  maxBufferSize: number; // in chunks
  reconnectAttempts: number;
  reconnectInterval: number; // base interval in ms
}

export enum ConnectionState {
  CONNECTING = 'CONNECTING',
  OPEN = 'OPEN',
  CLOSED = 'CLOSED',
  ERROR = 'ERROR'
}

export class WebSocketAudioClient {
  private ws: WebSocket | null = null;
  private buffer: AudioChunk[] = [];
  private reconnectCount = 0;
  private state: ConnectionState = ConnectionState.CLOSED;
  private reconnectTimer: NodeJS.Timeout | null = null;

  constructor(private config: WebSocketConfig) {}

  connect(): void {
    if (this.state === ConnectionState.CONNECTING || this.state === ConnectionState.OPEN) return;

    this.state = ConnectionState.CONNECTING;
    console.log(`Connecting... (Attempt ${this.reconnectCount + 1})`);

    this.ws = new WebSocket(this.config.url);

    this.ws.onopen = () => {
      this.state = ConnectionState.OPEN;
      this.reconnectCount = 0; // Reset on successful connection
      console.log("WebSocket Connected");
      this.flushBuffer();
    };

    this.ws.onclose = () => {
      this.state = ConnectionState.CLOSED;
      this.handleReconnection();
    };

    this.ws.onerror = () => {
      this.state = ConnectionState.ERROR;
      if (this.ws) this.ws.close(); // Trigger onclose logic
    };

    this.ws.onmessage = (event) => {
      // Handle incoming messages (e.g., transcription)
      // In a real app, we might emit an event here for the UI
      console.log("Received:", event.data);
    };
  }

  disconnect(): void {
    this.state = ConnectionState.CLOSED;
    this.reconnectCount = 0;
    if (this.reconnectTimer) clearTimeout(this.reconnectTimer);
    if (this.ws) {
      this.ws.close();
      this.ws = null;
    }
    this.buffer = [];
  }

  sendAudio(chunk: AudioChunk): void {
    // 1. Check connection state
    if (this.state !== ConnectionState.OPEN) {
      // If not open, we might still buffer if we are reconnecting, 
      // but for this exercise, we buffer only if reconnecting or connecting.
      // If closed completely, we drop data.
      if (this.state === ConnectionState.CLOSED) return; 
    }

    // 2. Backpressure Handling: Drop oldest if full
    if (this.buffer.length >= this.config.maxBufferSize) {
      this.buffer.shift(); // Remove oldest
      console.warn("Buffer full: Dropped oldest audio chunk");
    }

    // 3. Push new chunk
    this.buffer.push(chunk);

    // 4. Flush if connected
    if (this.state === ConnectionState.OPEN) {
      this.flushBuffer();
    }
  }

  private flushBuffer(): void {
    if (!this.ws || this.ws.readyState !== WebSocket.OPEN) return;

    while (this.buffer.length > 0) {
      const chunk = this.buffer.shift();
      if (chunk) {
        // We send the raw Int16Array buffer. 
        // Note: In a real binary protocol, you might wrap this with a header (timestamp, seqId).
        // For simplicity here, we assume the backend expects just the PCM data or we send JSON (slow).
        // Sending binary is more efficient:
        this.ws.send(chunk.data.buffer); 
      }
    }
  }

  private handleReconnection(): void {
    if (this.reconnectCount >= this.config.reconnectAttempts) {
      console.error("Max reconnection attempts reached.");
      return;
    }

    const delay = this.config.reconnectInterval * Math.pow(2, this.reconnectCount);
    this.reconnectCount++;

    console.log(`Reconnecting in ${delay}ms...`);
    this.reconnectTimer = setTimeout(() => {
      this.connect();
    }, delay);
  }
}
