/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

// LatencyProfiler.ts
export class LatencyProfiler {
  private startTimes: Map<string, number> = new Map();
  private latencies: number[] = []; 
  private readonly MAX_HISTORY = 100; // Limit stored latencies

  startTrace(id: string): void {
    // Use performance.now() for high-precision timing
    this.startTimes.set(id, performance.now());
  }

  endTrace(id: string): number | null {
    const startTime = this.startTimes.get(id);
    if (!startTime) return null;

    const endTime = performance.now();
    const latency = endTime - startTime;
    
    // Store latency
    this.latencies.push(latency);
    if (this.latencies.length > this.MAX_HISTORY) {
      this.latencies.shift(); // Keep array size bounded
    }

    // Cleanup map
    this.startTimes.delete(id);
    return latency;
  }

  getAverageLatency(): number {
    if (this.latencies.length === 0) return 0;
    const sum = this.latencies.reduce((a, b) => a + b, 0);
    return sum / this.latencies.length;
  }

  // Helper to get data for visualization
  getRecentLatencies(): number[] {
    return [...this.latencies];
  }
}

// WebSocketAudioClient.ts (Integration Snippet)
// Assuming we modify the class to accept the profiler
export class WebSocketAudioClient {
  private profiler: LatencyProfiler | null = null;

  setProfiler(profiler: LatencyProfiler) {
    this.profiler = profiler;
  }

  // ... inside sendAudio ...
  sendAudio(chunk: AudioChunk): void {
    // Inject ID into chunk if not present, or track it externally
    // For this exercise, we assume AudioChunk has a sequenceId or unique ID
    if (this.profiler && chunk.sequenceId !== undefined) {
        this.profiler.startTrace(chunk.sequenceId.toString());
    }
    // ... existing buffer logic ...
  }

  // ... inside onmessage ...
  // handleServerMessage(event) {
  //   const data = JSON.parse(event.data);
  //   // Assuming backend echoes the sequenceId
  //   if (this.profiler && data.sequenceId) {
  //      const latency = this.profiler.endTrace(data.sequenceId.toString());
  //      if (latency) this.updateGraph(latency);
  //   }
  // }

  private updateGraph(latency: number) {
    // Logic to draw to Canvas (omitted for brevity, see analysis)
  }
}

// Visualization Logic (Canvas)
function drawLatencyGraph(canvas: HTMLCanvasElement, latencies: number[]) {
  const ctx = canvas.getContext('2d');
  if (!ctx) return;

  const width = canvas.width;
  const height = canvas.height;
  ctx.clearRect(0, 0, width, height);

  if (latencies.length < 2) return;

  ctx.beginPath();
  ctx.strokeStyle = '#00ff00';
  ctx.lineWidth = 2;

  const maxLatency = Math.max(...latencies, 100); // Min scale 100ms
  const xStep = width / (latencies.length - 1);

  latencies.forEach((lat, i) => {
    const x = i * xStep;
    const y = height - (lat / maxLatency) * height; // Invert Y
    if (i === 0) ctx.moveTo(x, y);
    else ctx.lineTo(x, y);
  });

  ctx.stroke();
}
