/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

// audioProcessor.worker.ts
// This file needs to be compiled separately or loaded via a blob URL

interface WorkerMessage {
  type: 'process';
  buffer: Float32Array;
  sequenceId: number;
}

interface WorkerResult {
  type: 'result';
  data: Int16Array;
  sequenceId: number;
}

self.onmessage = (event: MessageEvent<WorkerMessage>) => {
  const { buffer, sequenceId } = event.data;

  // 1. Perform Float32 to Int16 conversion
  const pcmData = new Int16Array(buffer.length);
  for (let i = 0; i < buffer.length; i++) {
    // Clamp values to prevent clipping
    let s = Math.max(-1, Math.min(1, buffer[i]));
    pcmData[i] = s < 0 ? s * 0x8000 : s * 0x7FFF;
  }

  // 2. Post message back to main thread
  // We transfer the buffer to avoid copying memory
  const message: WorkerResult = {
    type: 'result',
    data: pcmData,
    sequenceId: sequenceId
  };
  
  // Transfer the underlying buffer of the Int16Array
  self.postMessage(message, [pcmData.buffer]);
};

// AudioCaptureService.ts (Modified)
export class AudioCaptureService {
  private worker: Worker | null = null;
  // ... other properties ...

  constructor(private sampleRate: number = 16000) {
    this.initWorker();
  }

  private initWorker() {
    // In a real build environment (Webpack/Vite), we can use new URL syntax
    // For this standalone example, we assume the worker file is accessible
    // or we create a blob URL. Here we assume a path.
    try {
      this.worker = new Worker('audioProcessor.worker.js'); 
      
      this.worker.onmessage = (event: MessageEvent<WorkerResult>) => {
        const { data, sequenceId } = event.data;
        // Re-construct the AudioChunk interface expected by the consumer
        if (this.onAudioData) {
            this.onAudioData({
                data: data, // Int16Array
                timestamp: Date.now(),
                sequenceId: sequenceId
            });
        }
      };
    } catch (e) {
      console.error("Worker initialization failed:", e);
    }
  }

  async start(onAudioData: AudioCaptureCallback): Promise<void> {
    this.onAudioData = onAudioData;
    // ... AudioContext setup (same as Ex 1) ...

    // Modify the processor callback
    this.processor.onaudioprocess = (event: AudioProcessingEvent) => {
        const inputData = event.inputBuffer.getChannelData(0);
        
        // We need to copy the data because we are transferring ownership 
        // of the buffer to the worker. The inputBuffer from Web Audio API 
        // is managed by the browser and cannot be transferred directly 
        // without copying, but we can copy to a new Float32Array to transfer.
        const bufferCopy = new Float32Array(inputData);
        
        if (this.worker) {
            this.worker.postMessage({
                type: 'process',
                buffer: bufferCopy,
                sequenceId: this.sequenceCounter++
            }, [bufferCopy.buffer]); // Transferable
        }
    };
    // ... connect nodes ...
  }

  stop(): void {
    // ... existing cleanup ...
    if (this.worker) {
      this.worker.terminate();
      this.worker = null;
    }
  }
}
