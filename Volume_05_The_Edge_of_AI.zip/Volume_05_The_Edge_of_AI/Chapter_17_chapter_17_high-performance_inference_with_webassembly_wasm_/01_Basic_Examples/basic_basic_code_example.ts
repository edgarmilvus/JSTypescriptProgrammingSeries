/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * @fileoverview Browser-based AI Inference using WebAssembly (WASM) and ONNX.
 * Context: SaaS Web Application (Client-Side Sentiment Analysis)
 * Dependencies: onnxruntime-web
 */

// Import the ONNX Runtime Web library.
// This library automatically loads the WASM binaries required for execution.
import * as ort from 'onnxruntime-web';

// --- Configuration ---
// In a real SaaS app, this URL would point to a Supabase Storage bucket
// or a CDN edge location hosting the model.
const MODEL_URL = 'https://huggingface.co/onnx-community/distilbert-base-uncased-finetuned-sst-2-english/resolve/main/model.onnx';

// --- Type Definitions ---

/**
 * Represents the input tensor shape for our model.
 * [Batch Size (1), Sequence Length (variable)]
 */
type InputTensor = ort.Tensor;

/**
 * Represents the output tensor shape.
 * [Batch Size (1), Number of Labels (2)]
 */
type OutputTensor = ort.Tensor;

/**
 * A simple interface for the inference result.
 */
interface InferenceResult {
  label: 'POSITIVE' | 'NEGATIVE';
  confidence: number;
}

// --- Main Logic ---

/**
 * 1. Model Initialization
 * Loads the ONNX model into the WASM runtime.
 * This is a heavy operation; in a SaaS app, this should be cached or pre-loaded.
 */
async function loadModel(): Promise<ort.InferenceSession> {
  console.log('Loading ONNX model via WASM...');
  
  // Configure execution providers. 'wasm' is the default for browsers.
  const sessionOptions: ort.InferenceSession.SessionOptions = {
    executionProviders: ['wasm'],
    graphOptimizationLevel: 'all', // Enable all graph optimizations
  };

  try {
    // Create the inference session
    const session = await ort.InferenceSession.create(MODEL_URL, sessionOptions);
    console.log('Model loaded successfully.');
    return session;
  } catch (error) {
    console.error('Failed to load model:', error);
    throw new Error('Model initialization failed. Check network connectivity and WASM support.');
  }
}

/**
 * 2. Pre-processing (Tokenization Simulation)
 * Converts raw text into numeric IDs for the model.
 * NOTE: Real-world apps require a tokenizer (e.g., HuggingFace Tokenizers.js).
 * For this demo, we simulate a simple mapping.
 */
function preprocess(text: string): { inputIds: number[]; attentionMask: number[] } {
  // Simulated vocabulary mapping (simplified for demo)
  const vocab: Record<string, number> = { 
    'hello': 101, 'world': 102, 'good': 2054, 'bad': 2055, 'great': 2056 
  };
  
  // Tokenize text (split by space)
  const tokens = text.toLowerCase().split(' ');
  
  // Map tokens to IDs
  const inputIds = tokens.map(token => vocab[token] || 100); // 100 = [UNK]
  
  // Create attention mask (1 for real tokens, 0 for padding)
  const attentionMask = inputIds.map(() => 1);
  
  // Pad to a fixed length for the model (e.g., 128)
  const maxLength = 128;
  while (inputIds.length < maxLength) {
    inputIds.push(0); // 0 = [PAD]
    attentionMask.push(0);
  }

  return { inputIds, attentionMask };
}

/**
 * 3. Inference Execution
 * Runs the model using the WASM runtime.
 */
async function runInference(session: ort.InferenceSession, text: string): Promise<InferenceResult> {
  // Pre-process the text
  const { inputIds, attentionMask } = preprocess(text);

  // Create ONNX Tensors
  // Input shape: [1, sequence_length]
  const inputTensor = new ort.Tensor(
    'int64', 
    BigInt64Array.from(inputIds.map(BigInt)), 
    [1, inputIds.length]
  );
  
  const attentionMaskTensor = new ort.Tensor(
    'int64', 
    BigInt64Array.from(attentionMask.map(BigInt)), 
    [1, attentionMask.length]
  );

  // Prepare feeds (inputs) mapping to model input names
  // Note: Input names depend on how the model was exported.
  const feeds = {
    input_ids: inputTensor,
    attention_mask: attentionMaskTensor,
  };

  // Run the session
  console.log('Running inference...');
  const results = await session.run(feeds);

  // Extract output (usually named 'logits' or 'output')
  const outputKey = Object.keys(results)[0];
  const outputTensor = results[outputKey] as OutputTensor;
  
  // Post-process: Convert logits to probabilities using Softmax
  const logits = Array.from(outputTensor.data as Float32Array);
  const exps = logits.map(Math.exp);
  const sumExps = exps.reduce((a, b) => a + b, 0);
  const probabilities = exps.map(e => e / sumExps);

  // Determine label (0: Negative, 1: Positive for SST-2)
  const maxProb = Math.max(...probabilities);
  const labelIndex = probabilities.indexOf(maxProb);
  const label = labelIndex === 1 ? 'POSITIVE' : 'NEGATIVE';

  return {
    label,
    confidence: maxProb,
  };
}

// --- Execution Wrapper ---

/**
 * 4. Main Application Entry Point
 * Simulates a user interaction in a SaaS dashboard.
 */
export async function analyzeSentiment(text: string): Promise<InferenceResult> {
  try {
    // In a real app, session caching is crucial to avoid re-loading WASM
    const session = await loadModel();
    const result = await runInference(session, text);
    
    // Cleanup (optional, but good for memory management in long-lived sessions)
    // await session.release(); 
    
    return result;
  } catch (error) {
    // Error handling for the specific WASM context
    if (error instanceof Error && error.message.includes('wasm')) {
      console.error('WASM Runtime Error. Ensure browser supports WebAssembly.');
    }
    throw error;
  }
}

// --- Usage Example (Simulated) ---
// (async () => {
//   const text = "The product interface is great but the support was bad.";
//   const result = await analyzeSentiment(text);
//   console.log(`Input: "${text}"`);
//   console.log(`Result: ${result.label} (Confidence: ${result.confidence.toFixed(4)})`);
// })();
