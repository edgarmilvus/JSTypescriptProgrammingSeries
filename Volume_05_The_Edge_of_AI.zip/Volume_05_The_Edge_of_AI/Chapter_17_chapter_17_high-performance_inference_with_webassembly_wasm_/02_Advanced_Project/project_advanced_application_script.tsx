/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.tsx
// Description: Advanced Application Script
// ==========================================

'use client';

import React, { useState, useTransition } from 'react';
import * as ort from 'onnxruntime-web';

/**
 * WASM Inference Component for Client-Side Image Classification.
 * 
 * This component demonstrates loading an ONNX model via WASM and performing
 * inference without server-side GPU dependencies.
 */
export default function WasmInferenceComponent() {
  // State to hold the uploaded image preview
  const [imageSrc, setImageSrc] = useState<string | null>(null);
  
  // State to hold the inference result (e.g., "Golden Retriever: 98%")
  const [prediction, setPrediction] = useState<string>('');
  
  // State to manage loading indicators
  const [isLoading, setIsLoading] = useState<boolean>(false);

  // useTransition allows us to mark the inference update as non-urgent.
  // This keeps the UI responsive even if the WASM thread is heavy.
  const [isPending, startTransition] = useTransition();

  // Configuration for the ONNX model
  const MODEL_URL = 'https://huggingface.co/microsoft/mobilebert-uncased/resolve/main/onnx/model.onnx'; 
  // Note: In a real scenario, use an image classification model like MobileNetV2.
  // For this demo script, we simulate the tensor logic if the model structure varies.
  
  /**
   * Handles the image file input change.
   * Reads the file as a DataURL for preview.
   */
  const handleImageUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (e) => {
      if (e.target?.result) {
        setImageSrc(e.target.result as string);
        setPrediction(''); // Clear previous results
      }
    };
    reader.readAsDataURL(file);
  };

  /**
   * Preprocesses the HTMLImageElement into a Float32Array Tensor.
   * 
   * @param img - The HTMLImageElement source
   * @param width - Target width (e.g., 224)
   * @param height - Target height (e.g., 224)
   * @returns {Float32Array} Normalized tensor data
   */
  const preprocessImage = async (img: HTMLImageElement, width: number, height: number): Promise<Float32Array> => {
    // Create an offscreen canvas to manipulate pixel data
    const canvas = document.createElement('canvas');
    canvas.width = width;
    canvas.height = height;
    const ctx = canvas.getContext('2d');
    
    if (!ctx) throw new Error('Canvas context not supported');

    // Draw image resized to model input dimensions
    ctx.drawImage(img, 0, 0, width, height);

    // Get raw pixel data (RGBA)
    const imageData = ctx.getImageData(0, 0, width, height);
    const data = imageData.data;

    // Allocate memory for the tensor (3 channels: RGB)
    // Shape: [1, 3, 224, 224] usually required by CNNs
    const float32Data = new Float32Array(3 * width * height);

    // Normalize pixel values (0-255) to (0-1) or (-1, 1) depending on model requirements
    // MobileNet usually expects [0, 1] or standardized values.
    for (let i = 0; i < width * height; i++) {
      const r = data[i * 4] / 255.0;
      const g = data[i * 4 + 1] / 255.0;
      const b = data[i * 4 + 2] / 255.0;

      // CHW Format (Channel, Height, Width) - Common in ONNX
      float32Data[i] = r;          // Red channel
      float32Data[i + width * height] = g; // Green channel
      float32Data[i + 2 * width * height] = b; // Blue channel
    }

    return float32Data;
  };

  /**
   * Main Inference Trigger.
   * Wrapped in startTransition to prevent UI blocking.
   */
  const runInference = async () => {
    if (!imageSrc) return;

    setIsLoading(true);

    // Use transition to update state without blocking the main thread
    startTransition(async () => {
      try {
        // 1. Load the image into an HTML element
        const img = new Image();
        img.src = imageSrc;
        await new Promise((resolve) => { img.onload = resolve; });

        // 2. Preprocess: Convert Image -> Tensor (Float32Array)
        // Standard input size for MobileNet is 224x224
        const tensorData = await preprocessImage(img, 224, 224);

        // 3. Initialize ONNX Runtime Session
        // In a real app, caching this session is crucial for performance.
        const session = await ort.InferenceSession.create(MODEL_URL, {
          executionProviders: ['wasm'], // Force WASM backend
          graphOptimizationLevel: 'all', // Enable ORT optimizations
        });

        // 4. Create the Tensor object
        // Note: 'input' is the default name for many models. Check your .onnx model with Netron.
        const inputTensor = new ort.Tensor('float32', tensorData, [1, 3, 224, 224]);

        // 5. Run inference
        const feeds: Record<string, ort.Tensor> = {};
        feeds[session.inputNames[0]] = inputTensor; // Map input tensor to input name
        
        const outputData = await session.run(feeds);
        
        // 6. Process Output
        // Get the first output tensor
        const outputName = session.outputNames[0];
        const outputTensor = outputData[outputName] as ort.Tensor;
        const probabilities = outputTensor.data as Float32Array;

        // Find max probability (Mocking a class lookup for demo brevity)
        let maxIndex = 0;
        let maxVal = 0;
        for (let i = 0; i < probabilities.length; i++) {
          if (probabilities[i] > maxVal) {
            maxVal = probabilities[i];
            maxIndex = i;
          }
        }

        // Simulate a class label map for demonstration
        // In production, fetch a labels.json file
        const labels = ['Cat', 'Dog', 'Car', 'Person', 'Tree'];
        const predictedLabel = labels[maxIndex % labels.length] || `Class ${maxIndex}`;

        setPrediction(`${predictedLabel} (${(maxVal * 100).toFixed(2)}%)`);

      } catch (error) {
        console.error('Inference Failed:', error);
        setPrediction('Error during inference. Check console.');
      } finally {
        setIsLoading(false);
      }
    });
  };

  return (
    <div style={{ padding: '20px', fontFamily: 'sans-serif', maxWidth: '600px', margin: '0 auto' }}>
      <h2>WASM Image Classifier</h2>
      
      {/* File Input */}
      <input 
        type="file" 
        accept="image/*" 
        onChange={handleImageUpload} 
        disabled={isPending}
      />

      {/* Image Preview */}
      {imageSrc && (
        <div style={{ marginTop: '20px' }}>
          <img 
            src={imageSrc} 
            alt="Preview" 
            style={{ maxWidth: '100%', height: 'auto', borderRadius: '8px' }} 
          />
        </div>
      )}

      {/* Inference Button */}
      <div style={{ marginTop: '20px' }}>
        <button 
          onClick={runInference}
          disabled={!imageSrc || isPending}
          style={{
            padding: '10px 20px',
            backgroundColor: isPending ? '#ccc' : '#3b82f6',
            color: 'white',
            border: 'none',
            borderRadius: '6px',
            cursor: isPending ? 'not-allowed' : 'pointer'
          }}
        >
          {isPending ? 'Analyzing...' : 'Analyze Image'}
        </button>
      </div>

      {/* Results */}
      {(isPending || prediction) && (
        <div style={{ marginTop: '20px', padding: '15px', backgroundColor: '#f3f4f6', borderRadius: '8px' }}>
          <h3>Result:</h3>
          {isPending ? (
            <p>Running WASM inference... (UI remains responsive)</p>
          ) : (
            <p style={{ fontSize: '1.2rem', fontWeight: 'bold', color: '#1f2937' }}>
              {prediction}
            </p>
          )}
        </div>
      )}
    </div>
  );
}
