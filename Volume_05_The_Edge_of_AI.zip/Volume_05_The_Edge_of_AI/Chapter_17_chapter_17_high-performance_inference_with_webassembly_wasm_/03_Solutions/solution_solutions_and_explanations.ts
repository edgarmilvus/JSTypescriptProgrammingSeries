/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// setup.ts
import * as fs from 'fs';
import * as path from 'path';
import { InferenceSession } from 'onnxruntime-node';

// Configuration
const MODEL_PATH = path.join(__dirname, 'text-embedding-3-small.onnx');
const WASM_SOURCE_DIR = path.join(__dirname, 'node_modules', 'onnxruntime-web', 'dist');
const PUBLIC_WASM_DIR = path.join(__dirname, 'public', 'wasm');

async function setupEnvironment() {
    try {
        console.log('🔍 Starting environment setup...');

        // 1. Check if model exists
        if (!fs.existsSync(MODEL_PATH)) {
            throw new Error(`Model file not found at: ${MODEL_PATH}`);
        }
        console.log(`✅ Model found: ${MODEL_PATH}`);

        // 2. Load model and inspect metadata using ONNX Runtime Node.js bindings
        console.log('🧠 Loading model to inspect metadata...');
        const session = await InferenceSession.create(MODEL_PATH);
        
        console.log('✅ Model loaded successfully.');
        console.log(`   - Input Names: ${session.inputNames.join(', ')}`);
        console.log(`   - Output Names: ${session.outputNames.join(', ')}`);
        
        // Log input dimensions (dynamic axes might show as 'null' or '?', but we check structure)
        const inputDetails = session.inputMetadata;
        for (const [name, meta] of Object.entries(inputDetails)) {
            console.log(`   - Input '${name}' shape: ${JSON.stringify(meta.dims)}`);
        }

        // 3. Prepare WASM files for the browser
        console.log('⚙️  Preparing WASM runtime files...');
        
        // Create public directory if it doesn't exist
        if (!fs.existsSync(PUBLIC_WASM_DIR)) {
            fs.mkdirSync(PUBLIC_WASM_DIR, { recursive: true });
        }

        // Define required WASM files (core runtime + multi-threading if needed)
        const wasmFiles = ['onnxruntime-wasm.wasm', 'onnxruntime-wasm-threaded.wasm'];
        
        wasmFiles.forEach(file => {
            const sourcePath = path.join(WASM_SOURCE_DIR, file);
            const destPath = path.join(PUBLIC_WASM_DIR, file);

            if (fs.existsSync(sourcePath)) {
                fs.copyFileSync(sourcePath, destPath);
                console.log(`   - Copied ${file} to public directory.`);
            } else {
                console.warn(`   ⚠️  Warning: ${file} not found in node_modules (might be optional).`);
            }
        });

        console.log('\n🚀 Setup Complete! The model and WASM runtime are ready for the browser.');
        console.log(`   Ensure your web server serves the 'public' directory.`);

    } catch (error) {
        console.error('❌ Setup failed:', error);
        process.exit(1);
    }
}

setupEnvironment();
