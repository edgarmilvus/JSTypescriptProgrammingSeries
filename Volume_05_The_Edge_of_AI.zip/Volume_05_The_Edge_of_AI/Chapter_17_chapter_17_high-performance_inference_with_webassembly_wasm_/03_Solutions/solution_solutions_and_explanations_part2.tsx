/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.tsx
// Description: Solutions and Explanations
// ==========================================

// EdgeEmbedder.tsx
import React, { useState, useEffect } from 'react';
import * as ort from 'onnxruntime-web';

const EdgeEmbedder: React.FC = () => {
    const [inputText, setInputText] = useState<string>('');
    const [embedding, setEmbedding] = useState<number[] | null>(null);
    const [isLoading, setIsLoading] = useState<boolean>(false);
    const [error, setError] = useState<string | null>(null);
    const [session, setSession] = useState<ort.InferenceSession | null>(null);

    // 1. Load the model on component mount
    useEffect(() => {
        const loadModel = async () => {
            setIsLoading(true);
            try {
                // Note: The path points to the public directory where setup.ts copied the model
                // We configure the wasm paths explicitly to point to /public/wasm
                const newSession = await ort.InferenceSession.create(
                    './text-embedding-3-small.onnx', 
                    {
                        executionProviders: ['wasm'],
                        graphOptimizationLevel: 'all',
                        // Explicitly setting paths helps if the file structure is complex
                        // However, onnxruntime-web usually looks in the same origin by default.
                    }
                );
                setSession(newSession);
                setError(null);
            } catch (e) {
                setError(e instanceof Error ? e.message : 'Failed to load model');
            } finally {
                setIsLoading(false);
            }
        };

        loadModel();

        // Cleanup on unmount
        return () => {
            if (session) session.release();
        };
    }, []);

    // 2. Inference Logic
    const generateEmbedding = async () => {
        if (!session || !inputText.trim()) return;

        setIsLoading(true);
        setError(null);
        setEmbedding(null);

        try {
            // MOCK TOKENIZATION: 
            // In a real scenario, you would use a tokenizer library (e.g., HuggingFace Tokenizers.js).
            // Here, we simulate a fixed-size input tensor (e.g., 1x128) with random integers
            // to represent token IDs, as the actual text logic is too heavy for this snippet.
            const seqLength = 128;
            const inputIds = new Int32Array(seqLength).fill(0);
            
            // Fill with dummy data based on text length just to vary input
            for(let i=0; i<Math.min(inputText.length, seqLength); i++) {
                inputIds[i] = inputText.charCodeAt(i) % 100; 
            }

            // Create input tensor (shape: [1, seq_length])
            const inputTensor = new ort.Tensor('int32', inputIds, [1, seqLength]);

            // Prepare inputs map
            const feeds: Record<string, ort.Tensor> = {};
            // Use the input name found in Exercise 1 (usually 'input_ids' or similar)
            // Fallback to 'input_ids' if unknown
            const inputName = session.inputNames[0] || 'input_ids';
            feeds[inputName] = inputTensor;

            // Run inference
            const outputMap = await session.run(feeds);
            
            // Extract result
            const outputName = session.outputNames[0];
            const outputTensor = outputMap[outputName] as ort.Tensor;
            
            // Convert Float32Array to standard number array for state
            setEmbedding(Array.from(outputTensor.data as Float32Array));
        } catch (e) {
            setError(e instanceof Error ? e.message : 'Inference failed');
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <div style={{ padding: '20px', maxWidth: '600px', margin: '0 auto' }}>
            <h3>Edge Embedder (WASM)</h3>
            
            <textarea
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                placeholder="Enter text to embed..."
                rows={4}
                style={{ width: '100%', marginBottom: '10px' }}
                disabled={isLoading}
            />

            <button onClick={generateEmbedding} disabled={isLoading || !session}>
                {isLoading ? 'Processing...' : 'Generate Embedding'}
            </button>

            {error && (
                <div style={{ color: 'red', marginTop: '10px' }}>
                    Error: {error}
                </div>
            )}

            {embedding && (
                <div style={{ marginTop: '10px' }}>
                    <strong>Result (First 5 dimensions):</strong>
                    <div style={{ fontFamily: 'monospace', background: '#f0f0f0', padding: '5px', marginTop: '5px' }}>
                        [{embedding.slice(0, 5).map(n => n.toFixed(4)).join(', ')}, ...]
                    </div>
                    <small>Total dimensions: {embedding.length}</small>
                </div>
            )}
        </div>
    );
};

export default EdgeEmbedder;
