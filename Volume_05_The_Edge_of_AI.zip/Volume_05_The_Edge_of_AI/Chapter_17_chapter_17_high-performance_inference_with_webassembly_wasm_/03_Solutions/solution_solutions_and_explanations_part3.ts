/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

// inference.worker.ts
import * as ort from 'onnxruntime-web';

// Define the message types for type safety
export type WorkerMessage = 
    | { type: 'init'; modelPath: string }
    | { type: 'inference'; text: string };

let session: ort.InferenceSession | null = null;

self.onmessage = async (event: MessageEvent<WorkerMessage>) => {
    const { type, modelPath, text } = event.data;

    try {
        if (type === 'init') {
            if (!modelPath) throw new Error("Model path required");
            
            // Initialize the ONNX session inside the worker
            session = await ort.InferenceSession.create(modelPath, {
                executionProviders: ['wasm']
            });
            
            self.postMessage({ type: 'ready' });
        }

        if (type === 'inference') {
            if (!session) throw new Error("Session not initialized");

            // Mock tokenization (same as Exercise 2)
            const seqLength = 128;
            const inputIds = new Int32Array(seqLength).fill(0);
            for(let i=0; i<Math.min(text.length, seqLength); i++) {
                inputIds[i] = text.charCodeAt(i) % 100; 
            }

            const inputTensor = new ort.Tensor('int32', inputIds, [1, seqLength]);
            const feeds: Record<string, ort.Tensor> = {};
            const inputName = session.inputNames[0] || 'input_ids';
            feeds[inputName] = inputTensor;

            // Run inference
            const outputMap = await session.run(feeds);
            const outputName = session.outputNames[0];
            const outputTensor = outputMap[outputName] as ort.Tensor;

            // Send result back to main thread
            self.postMessage({ 
                type: 'result', 
                embedding: Array.from(outputTensor.data as Float32Array) 
            });
        }
    } catch (error) {
        self.postMessage({ 
            type: 'error', 
            message: error instanceof Error ? error.message : String(error) 
        });
    }
};
