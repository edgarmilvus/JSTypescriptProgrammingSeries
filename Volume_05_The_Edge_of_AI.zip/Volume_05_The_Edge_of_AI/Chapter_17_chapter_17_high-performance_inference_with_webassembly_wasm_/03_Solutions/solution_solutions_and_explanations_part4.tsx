/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.tsx
// Description: Solutions and Explanations
// ==========================================

// EdgeEmbedderOptimized.tsx
import React, { useState, useEffect, useRef, useCallback } from 'react';
import { WorkerMessage } from './inference.worker'; // Import types

// Helper to debounce
function debounce<F extends (...args: any[]) => any>(func: F, waitFor: number) {
    let timeout: NodeJS.Timeout;
    return (...args: Parameters<F>): Promise<ReturnType<F>> => {
        return new Promise(resolve => {
            if (timeout) clearTimeout(timeout);
            timeout = setTimeout(() => resolve(func(...args)), waitFor);
        });
    };
}

const EdgeEmbedderOptimized: React.FC = () => {
    const [inputText, setInputText] = useState<string>('');
    const [embedding, setEmbedding] = useState<number[] | null>(null);
    const [status, setStatus] = useState<'idle' | 'loading' | 'processing'>('idle');
    const [error, setError] = useState<string | null>(null);

    // Worker reference
    const workerRef = useRef<Worker | null>(null);

    // Initialize Worker
    useEffect(() => {
        // Note: Depending on your bundler (Webpack/Vite), you might need 
        // specific syntax to load worker files (e.g., new Worker(new URL(..., import.meta.url)))
        const worker = new Worker(new URL('./inference.worker.ts', import.meta.url), {
            type: 'module'
        });

        workerRef.current = worker;

        worker.onmessage = (event: MessageEvent) => {
            const data = event.data;
            if (data.type === 'ready') {
                console.log('Worker ready');
                setStatus('idle');
            } else if (data.type === 'result') {
                setEmbedding(data.embedding);
                setStatus('idle');
            } else if (data.type === 'error') {
                setError(data.message);
                setStatus('idle');
            }
        };

        // Send init message
        setStatus('loading');
        worker.postMessage({ type: 'init', modelPath: './text-embedding-3-small.onnx' });

        return () => {
            worker.terminate();
        };
    }, []);

    // Debounced Inference Handler
    // We wrap the inference call in a debounce to prevent flooding the worker
    const debouncedInference = useCallback(
        debounce((text: string) => {
            if (workerRef.current && text.trim()) {
                setStatus('processing');
                workerRef.current.postMessage({ type: 'inference', text });
            }
        }, 500), // 500ms delay
        []
    );

    // Handle Input Change
    const handleInputChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
        const text = e.target.value;
        setInputText(text);
        
        // Trigger debounced inference
        if (text.trim()) {
            debouncedInference(text);
        } else {
            setEmbedding(null);
            setStatus('idle');
        }
    };

    return (
        <div style={{ padding: '20px', maxWidth: '600px', margin: '0 auto' }}>
            <h3>Optimized Edge Embedder (Worker + Debounce)</h3>
            
            <textarea
                value={inputText}
                onChange={handleInputChange}
                placeholder="Type to generate embedding (debounced)..."
                rows={4}
                style={{ width: '100%', marginBottom: '10px' }}
                disabled={status === 'loading'}
            />

            <div style={{ minHeight: '20px', marginBottom: '10px' }}>
                {status === 'loading' && <span>Initializing WASM Runtime...</span>}
                {status === 'processing' && <span>🧠 Computing in Worker...</span>}
            </div>

            {error && <div style={{ color: 'red' }}>Error: {error}</div>}

            {/* Skeleton / Optimistic UI */}
            {status === 'processing' && !embedding && (
                <div style={{ background: '#eee', height: '20px', width: '100%', animation: 'pulse 1s infinite' }}></div>
            )}

            {embedding && (
                <div style={{ marginTop: '10px', border: '1px solid #ddd', padding: '10px' }}>
                    <strong>Embedding Generated:</strong>
                    <div style={{ fontSize: '0.8em', wordBreak: 'break-all' }}>
                        [{embedding.slice(0, 5).map(n => n.toFixed(4)).join(', ')}...]
                    </div>
                </div>
            )}
        </div>
    );
};

export default EdgeEmbedderOptimized;
