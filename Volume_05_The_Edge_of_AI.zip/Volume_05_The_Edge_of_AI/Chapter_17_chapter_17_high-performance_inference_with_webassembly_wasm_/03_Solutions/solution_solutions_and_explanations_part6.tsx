/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part6.tsx
// Description: Solutions and Explanations
// ==========================================

// ArchitectureVisualizer.tsx
import React, { useMemo } from 'react';

// Props
interface Props {
    mode: 'client' | 'server';
}

const ArchitectureVisualizer: React.FC<Props> = ({ mode }) => {
    
    // Generate DOT string dynamically based on mode
    const dotString = useMemo(() => {
        // Define common nodes
        const userNode = 'User [label="User Input", shape=box, style=filled, fillcolor="#E3F2FD"];';
        const resultNode = 'Result [label="Result", shape=box, style=filled, fillcolor="#E8F5E9"];';

        // Define mode-specific nodes and edges
        let coreNodes = '';
        let coreEdges = '';
        let styling = '';

        if (mode === 'client') {
            // Client Side Path (Green theme)
            coreNodes = `
                Browser [label="Browser", shape=component, fillcolor="#FFF", color="#4CAF50"]
                WASM [label="WASM Runtime\n(ONNX Runtime)", shape=cylinder, style=filled, fillcolor="#C8E6C9", color="#2E7D32"]
                Model [label="Local ONNX Model", shape=database, style=filled, fillcolor="#A5D6A7", color="#1B5E20"]
            `;
            coreEdges = `
                User -> Browser [label="DOM Event"]
                Browser -> WASM [label="Initialize Session"]
                WASM -> Model [label="Load Weights"]
                WASM -> Result [label="Inference Output"]
            `;
        } else {
            // Server Side Path (Blue theme)
            coreNodes = `
                Browser [label="Browser", shape=component, fillcolor="#FFF", color="#1976D2"]
                Network [label="Network Request", shape=parallelogram, style=filled, fillcolor="#BBDEFB", color="#0D47A1"]
                API [label="Cloud API / GPU", shape=Mcircle, style=filled, fillcolor="#90CAF9", color="#1565C0"]
                HeavyModel [label="Heavy Model\n(FP16/INT8)", shape=database3d, style=filled, fillcolor="#64B5F6", color="#0D47A1"]
            `;
            coreEdges = `
                User -> Browser [label="User Action"]
                Browser -> Network [label="HTTP POST"]
                Network -> API [label="Load Balancer"]
                API -> HeavyModel [label="GPU Inference"]
                API -> Browser [label="JSON Response"]
                Browser -> Result [label="Render Data"]
            `;
        }

        // Construct full DOT graph
        return `
digraph G {
    rankdir=LR;
    node [fontname="Arial", fontsize=10];
    edge [fontname="Arial", fontsize=8];

    // Common Nodes
    ${userNode}
    ${resultNode}

    // Dynamic Path
    ${coreNodes}

    // Connections
    ${coreEdges}

    // Highlight active path visually (Optional visual cue)
    ${mode === 'client' ? 'Browser -> WASM [color="#2E7D32", penwidth=2.0];' : 'Browser -> Network [color="#0D47A1", penwidth=2.0];'}
}
        `;
    }, [mode]);

    return (
        <div style={{ padding: '20px', fontFamily: 'sans-serif' }}>
            <div style={{ 
                border: '1px solid #ccc', 
                borderRadius: '8px', 
                padding: '15px', 
                backgroundColor: '#f9f9f9' 
            }}>
                <h4 style={{ marginTop: 0, textAlign: 'center' }}>
                    Architecture Mode: {mode === 'client' ? '🔒 Client-Side (Edge Privacy)' : '☁️ Server-Side (Cloud Power)'}
                </h4>
                
                {/* 
                    NOTE: In a production app, we would use a library like 'react-graph-vis' 
                    or '@graphviz/react' to render this string into an SVG.
                    For this exercise, we display the raw DOT code to demonstrate 
                    the dynamic string generation logic required for the visualization.
                */}
                <div style={{ 
                    backgroundColor: '#fff', 
                    border: '1px dashed #ddd', 
                    padding: '10px', 
                    overflowX: 'auto',
                    fontFamily: 'monospace',
                    fontSize: '12px'
                }}>
                    <pre>{dotString}</pre>
                </div>

                <div style={{ marginTop: '10px', fontSize: '12px', color: '#555' }}>
                    <strong>Logic:</strong> 
                    {mode === 'client' 
                        ? ' Data never leaves the device. WASM handles inference locally.' 
                        : ' Data is sent to a server with powerful GPUs for processing.'}
                </div>
            </div>
        </div>
    );
};

export default ArchitectureVisualizer;
