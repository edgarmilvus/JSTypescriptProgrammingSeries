/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part2.tsx
// Description: Practical Exercises
// ==========================================

// EdgeEmbedder.tsx
import React, { useState, useEffect } from 'react';
// 1. Import onnxruntime-web types and InferenceSession.

// 2. Define the EdgeEmbedder component.
const EdgeEmbedder: React.FC = () => {
    // 3. Initialize state variables (inputText, embedding, isLoading, error, session).
    
    // 4. useEffect for loading the ONNX model on mount.
    //    - Use InferenceSession.create with the path to the .onnx model and backend config.
    //    - Handle loading state and potential errors.

    // 5. Define generateEmbedding function.
    //    - It should be async.
    //    - Create input tensors from the text (mock tokenization if needed).
    //    - Run session.run(input).
    //    - Extract the output tensor data.
    //    - Update state.

    // 6. Return JSX:
    //    - Textarea for input.
    //    - Button to call generateEmbedding (disabled if loading).
    //    - Conditional rendering for loading spinner or embedding result.
    //    - Error display.
};

export default EdgeEmbedder;
