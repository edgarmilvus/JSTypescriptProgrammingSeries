/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * MODULE: vector-storage.ts
 * 
 * This file demonstrates SRP by strictly separating data validation, 
 * storage logic, and ID generation.
 */

// ============================================================================
// 1. Data Types and Interfaces
// ============================================================================

/**
 * Represents a single chunk of text and its metadata.
 * The `id` is the Vector ID, crucial for tracking the source chunk.
 */
export interface StoredChunk {
  id: string; // Vector ID (UUID)
  content: string;
  metadata: {
    source: string;
    timestamp: number;
    isVerified: boolean; // Ethical flag
  };
}

/**
 * Input structure for the ingestion pipeline.
 */
export interface IngestionInput {
  content: string;
  source: string;
}

// ============================================================================
// 2. The Single Responsibility Modules
// ============================================================================

/**
 * RESPONSIBILITY: ID Generation and Lineage Tracking.
 * 
 * This module has one reason to change: If the algorithm for generating
 * unique identifiers changes (e.g., switching from Math.random to UUID v4).
 */
class VectorIdGenerator {
  /**
   * Generates a unique Vector ID for a chunk.
   * In a real scenario, this might be a UUID library.
   */
  public generateId(): string {
    // Simulating a UUID generation for the Vector ID
    return `vec_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`;
  }
}

/**
 * RESPONSIBILITY: Ethical Data Validation.
 * 
 * This module has one reason to change: If the ethical guidelines or 
 * content filters need updating. It does not care where the data goes,
 * only if it is allowed to proceed.
 */
class EthicalValidator {
  private forbiddenPatterns = ['hate speech', 'malicious code'];

  /**
   * Validates content against ethical guidelines.
   * @throws Error if content violates policies.
   */
  public validate(content: string): void {
    const lowerContent = content.toLowerCase();
    for (const pattern of this.forbiddenPatterns) {
      if (lowerContent.includes(pattern)) {
        throw new Error(`Ethical Violation: Content contains forbidden pattern: "${pattern}"`);
      }
    }
  }
}

/**
 * RESPONSIBILITY: Persistence Logic.
 * 
 * This module has one reason to change: If the underlying database 
 * technology changes (e.g., moving from In-Memory to Redis or PostgreSQL).
 */
class VectorStorage {
  // Simulating a local database (e.g., a JSON file or SQLite)
  private db: Map<string, StoredChunk> = new Map();

  /**
   * Saves a validated chunk to the store.
   */
  public async save(chunk: StoredChunk): Promise<void> {
    // Simulate async I/O operation (typical for DBs)
    await new Promise(resolve => setTimeout(resolve, 50)); 
    this.db.set(chunk.id, chunk);
    console.log(`[Storage] Saved Vector ID: ${chunk.id}`);
  }

  /**
   * Retrieves a chunk by its Vector ID.
   */
  public async get(id: string): Promise<StoredChunk | null> {
    await new Promise(resolve => setTimeout(resolve, 20));
    return this.db.get(id) || null;
  }
}

// ============================================================================
// 3. The Orchestrator (Composition over Inheritance)
// ============================================================================

/**
 * RESPONSIBILITY: Orchestration.
 * 
 * This class composes the other modules. It does not implement logic itself;
 * it delegates to the specialized classes. This is the "Facade" or "Service"
 * layer.
 */
export class EthicalIngestionService {
  private idGenerator = new VectorIdGenerator();
  private validator = new EthicalValidator();
  private storage = new VectorStorage();

  /**
   * The main entry point for the SaaS Web App to ingest data.
   * 
   * @param input - The raw data from the user
   * @returns The assigned Vector ID
   */
  public async ingestData(input: IngestionInput): Promise<string> {
    // 1. Validate (Ethical Check)
    // This separates the "Safety" concern from the "Storage" concern.
    this.validator.validate(input.content);

    // 2. Generate ID (Lineage)
    // This separates the "Identity" concern.
    const vectorId = this.idGenerator.generateId();

    // 3. Construct Object
    const chunk: StoredChunk = {
      id: vectorId,
      content: input.content,
      metadata: {
        source: input.source,
        timestamp: Date.now(),
        isVerified: true
      }
    };

    // 4. Persist (Storage)
    // This separates the "I/O" concern.
    await this.storage.save(chunk);

    return vectorId;
  }

  /**
   * Retrieves data using the Vector ID.
   */
  public async retrieveData(vectorId: string): Promise<StoredChunk | null> {
    return await this.storage.get(vectorId);
  }
}

// ============================================================================
// 4. Usage Example (Simulating a Web App Route)
// ============================================================================

/**
 * Simulates an API Route (e.g., Next.js API Router).
 * This function is pure glue code.
 */
async function appRouteHandler() {
  const service = new EthicalIngestionService();

  try {
    console.log("--- Starting Ingestion Pipeline ---");
    
    // Simulate User Input
    const userInput: IngestionInput = {
      content: "Hello World, this is a safe prompt.",
      source: "web-ui-v1"
    };

    // Execute Pipeline
    const vectorId = await service.ingestData(userInput);
    console.log(`Success! Assigned Vector ID: ${vectorId}`);

    // Retrieve to verify
    const retrieved = await service.retrieveData(vectorId);
    console.log("Retrieved Data:", retrieved);

    // Simulate Ethical Violation
    console.log("\n--- Testing Ethical Guardrails ---");
    const badInput: IngestionInput = {
      content: "This is hate speech content.",
      source: "web-ui-v1"
    };
    
    await service.ingestData(badInput);

  } catch (error: any) {
    console.error(`[API Error]: ${error.message}`);
  }
}

// Execute if run directly (for Node.js)
if (require.main === module) {
  appRouteHandler();
}
