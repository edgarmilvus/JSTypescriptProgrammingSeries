/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// File: app/api/ethical-ollama/route.ts
// Target: Next.js 14+ (App Router)
// Dependencies: None (Native Fetch API used for Ollama)

import { NextResponse } from 'next/server';

// ---------------------------------------------------------------------
// 1. TYPE DEFINITIONS & GENERICS
// ---------------------------------------------------------------------

/**
 * Generic type for the standard Ollama API request payload.
 * Using Generics here allows us to extend this for different models
 * while maintaining strict typing for the input prompt.
 */
interface OllamaRequest<T = string> {
  model: string;
  prompt: T;
  stream?: boolean;
}

/**
 * Standard response shape from Ollama.
 */
interface OllamaResponse {
  model: string;
  response: string;
  done: boolean;
  total_duration: number; // Measuring Inference Latency
}

/**
 * Internal type for PII detection results.
 */
interface PiiScanResult {
  isClean: boolean;
  redactedContent: string;
  detectedTypes: string[];
}

// ---------------------------------------------------------------------
// 2. SRP MODULE: THE SAFETY LAYER
// ---------------------------------------------------------------------

/**
 * Responsibility: Data Sanitization & Output Validation.
 * It has no knowledge of the network transport or the specific AI model.
 */
class EthicalGuardrail {
  private piiPatterns: Record<string, RegExp> = {
    email: /\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b/g,
    phone: /\b\d{3}[-.]?\d{3}[-.]?\d{4}\b/g,
    ssn: /\b\d{3}-\d{2}-\d{4}\b/g,
  };

  private forbiddenKeywords: string[] = ['hate', 'violence', 'illegal', 'dangerous'];

  /**
   * Scans input for PII and redacts it before sending to the model.
   * @param input - The raw user prompt.
   * @returns PiiScanResult
   */
  public sanitizeInput(input: string): PiiScanResult {
    let clean = input;
    const detected: string[] = [];

    for (const [type, regex] of Object.entries(this.piiPatterns)) {
      if (regex.test(clean)) {
        detected.push(type);
        clean = clean.replace(regex, `[REDACTED_${type.toUpperCase()}]`);
      }
    }

    return {
      isClean: true, // Always true in this logic, but could block if strict
      redactedContent: clean,
      detectedTypes: detected,
    };
  }

  /**
   * Analyzes the model output for safety violations.
   * @param output - The generated text from the LLM.
   * @returns boolean - True if safe, False if blocked.
   */
  public validateOutput(output: string): boolean {
    const lowerOutput = output.toLowerCase();
    return !this.forbiddenKeywords.some((keyword) => lowerOutput.includes(keyword));
  }
}

// ---------------------------------------------------------------------
// 3. SRP MODULE: THE INFERENCE CLIENT
// ---------------------------------------------------------------------

/**
 * Responsibility: Communicating with the Local LLM.
 * Handles network latency and error parsing.
 */
class LocalOllamaClient {
  private readonly endpoint: string = 'http://localhost:11434/api/generate';

  /**
   * Calls the local Ollama instance.
   * Measures Inference Latency explicitly.
   */
  async generate(
    request: OllamaRequest
  ): Promise<{ data: OllamaResponse | null; latencyMs: number }> {
    const startTime = performance.now();
    
    try {
      // In a real scenario, we might use a streaming parser, 
      // but for this guardrail example we assume a single JSON response.
      const response = await fetch(this.endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...request, stream: false }),
      });

      if (!response.ok) {
        throw new Error(`Ollama Error: ${response.statusText}`);
      }

      const data = (await response.json()) as OllamaResponse;
      const latencyMs = performance.now() - startTime;

      return { data, latencyMs };
    } catch (error) {
      console.error('Inference Client Error:', error);
      return { data: null, latencyMs: performance.now() - startTime };
    }
  }
}

// ---------------------------------------------------------------------
// 4. MAIN HANDLER: NEXT.JS API ROUTE
// ---------------------------------------------------------------------

/**
 * POST /api/ethical-ollama
 * 
 * Orchestrates the ethical flow:
 * 1. Validates Request.
 * 2. Sanitizes Input (SRP: Safety Layer).
 * 3. Performs Inference (SRP: Inference Layer).
 * 4. Validates Output (SRP: Safety Layer).
 * 5. Returns Safe Response.
 */
export async function POST(req: Request) {
  try {
    // Parse Input
    const body = await req.json();
    const { prompt, model = 'llama2' } = body as OllamaRequest;

    if (!prompt) {
      return NextResponse.json({ error: 'Prompt is required' }, { status: 400 });
    }

    // 1. Initialize SRP Modules
    const guardrail = new EthicalGuardrail();
    const ollamaClient = new LocalOllamaClient();

    // 2. Input Sanitization (Privacy Protection)
    const piiScan = guardrail.sanitizeInput(prompt);
    
    // Optional: Log the detection without the sensitive data for audit trails
    if (piiScan.detectedTypes.length > 0) {
      console.warn(`[AUDIT] PII Detected in request: ${piiScan.detectedTypes.join(', ')}`);
    }

    // 3. Inference Execution (Performance Optimization)
    const { data, latencyMs } = await ollamaClient.generate({
      model,
      prompt: piiScan.redactedContent,
    });

    if (!data) {
      return NextResponse.json({ error: 'Inference failed' }, { status: 500 });
    }

    // 4. Output Validation (Safety Check)
    const isSafe = guardrail.validateOutput(data.response);

    if (!isSafe) {
      // Log the violation attempt
      console.error('[SECURITY] Model generated unsafe content.');
      return NextResponse.json(
        { 
          response: "I cannot fulfill this request as it violates safety guidelines.", 
          safe: false,
          latency: latencyMs 
        }, 
        { status: 200 } // Return 200 to handle gracefully in UI
      );
    }

    // 5. Success Response (Stripping sensitive metadata if needed)
    return NextResponse.json({
      response: data.response,
      safe: true,
      latency: latencyMs, // Expose latency for performance monitoring
      model: data.model,
    });

  } catch (error) {
    console.error('API Route Error:', error);
    return NextResponse.json({ error: 'Internal Server Error' }, { status: 500 });
  }
}
