/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState } from 'react';

// Define the interface for type safety
interface InferenceMetrics {
  tokensPerSecond: number;
  duration: number;
  gpuActive: boolean;
}

// Helper function to calculate carbon footprint
const calculateCarbonFootprint = (durationSec: number, gpuActive: boolean): string => {
  // Simplified formula: (duration * factor) grams CO2
  const emissionFactor = gpuActive ? 0.05 : 0.02; 
  const totalGrams = durationSec * emissionFactor;
  return `${totalGrams.toFixed(2)} g CO2`;
};

export const LocalLLMMonitor: React.FC = () => {
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [metrics, setMetrics] = useState<InferenceMetrics | null>(null);

  const triggerInference = async () => {
    setIsLoading(true);
    setMetrics(null);

    // Simulate inference process
    const startTime = performance.now();
    await new Promise(resolve => setTimeout(resolve, 2000)); // 2 second mock inference
    const endTime = performance.now();

    // Mock metrics generation
    const durationSec = (endTime - startTime) / 1000;
    const mockMetrics: InferenceMetrics = {
      tokensPerSecond: Math.floor(Math.random() * 20) + 10, // Random 10-30 tps
      duration: durationSec,
      gpuActive: true // Assuming GPU is active for this demo
    };

    setMetrics(mockMetrics);
    setIsLoading(false);
  };

  return (
    <div style={{ padding: '20px', fontFamily: 'Arial, sans-serif', border: '1px solid #ccc', borderRadius: '8px', maxWidth: '400px' }}>
      <h3>Local LLM Monitor</h3>
      
      <button 
        onClick={triggerInference} 
        disabled={isLoading}
        style={{ padding: '10px 15px', cursor: isLoading ? 'not-allowed' : 'pointer' }}
      >
        {isLoading ? 'Running Inference...' : 'Start Inference'}
      </button>

      {isLoading && (
        <div style={{ marginTop: '10px' }}>
          <span>Loading... </span>
          <span role="img" aria-label="loading">⏳</span>
        </div>
      )}

      {metrics && !isLoading && (
        <div style={{ marginTop: '15px', padding: '10px', backgroundColor: '#f9f9f9', borderRadius: '4px' }}>
          <h4>Performance Dashboard</h4>
          <p><strong>Tokens/Sec:</strong> {metrics.tokensPerSecond}</p>
          <p><strong>Duration:</strong> {metrics.duration.toFixed(2)}s</p>
          <p><strong>Hardware:</strong> {metrics.gpuActive ? 'GPU (High Power)' : 'CPU (Low Power)'}</p>
          <hr />
          <p><strong>Carbon Footprint:</strong> {calculateCarbonFootprint(metrics.duration, metrics.gpuActive)}</p>
        </div>
      )}
    </div>
  );
};
