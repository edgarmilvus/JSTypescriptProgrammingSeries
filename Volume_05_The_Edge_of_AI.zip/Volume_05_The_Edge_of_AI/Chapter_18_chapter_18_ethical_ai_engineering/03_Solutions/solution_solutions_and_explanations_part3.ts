/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

import { StateGraph, END, Annotation } from "@langchain/langgraph";

// 1. Graph State Definition
const GraphState = Annotation.Root({
    prompt: Annotation<string>,
    isSafe: Annotation<boolean>({
        reducer: (state, update) => update, // Simply overwrite
        default: () => false,
    }),
    response: Annotation<string>({
        reducer: (state, update) => update,
        default: () => "",
    }),
});

// Mock keyword list for safety check
const UNSAFE_KEYWORDS = ["bomb", "hack", "illegal"];

// 2. Node Functions
const safetyCheck = async (state: typeof GraphState.State) => {
    const { prompt } = state;
    const lowerPrompt = prompt.toLowerCase();
    
    // Check against unsafe keywords
    const isSafe = !UNSAFE_KEYWORDS.some(word => lowerPrompt.includes(word));
    
    console.log(`[Node: SafetyCheck] Input: "${prompt}" -> Safe: ${isSafe}`);
    return { isSafe };
};

const generateResponse = async (state: typeof GraphState.State) => {
    // Only runs if isSafe is true (handled by edge routing)
    const response = `LLM Generated Safe Response to: "${state.prompt}"`;
    console.log(`[Node: Generate] Output: ${response}`);
    return { response };
};

const refusalNode = async (state: typeof GraphState.State) => {
    const response = "I cannot fulfill this request due to safety guidelines.";
    console.log(`[Node: Refusal] Output: ${response}`);
    return { response };
};

const logInteraction = async (state: typeof GraphState.State) => {
    // Simulating a database write or audit log
    console.log(`[Node: Logger] Final State:`, {
        prompt: state.prompt,
        isSafe: state.isSafe,
        response: state.response
    });
    return state;
};

// 3. Graph Construction
const workflow = new StateGraph(GraphState)
    .addNode("safetyCheck", safetyCheck)
    .addNode("generateResponse", generateResponse)
    .addNode("refusalNode", refusalNode)
    .addNode("logInteraction", logInteraction)

    // Start node
    .addEdge("__start__", "safetyCheck")

    // 4. Edges and Routing Logic
    // From safetyCheck, route based on state.isSafe
    .addConditionalEdges(
        "safetyCheck",
        (state) => {
            return state.isSafe ? "generateResponse" : "refusalNode";
        }
    )

    // Standard flow to logging
    .addEdge("generateResponse", "logInteraction")
    .addEdge("refusalNode", "logInteraction")

    // End after logging
    .addEdge("logInteraction", END);

// Compile the graph
export const ethicalAgent = workflow.compile();

// --- Usage Example ---
/*
(async () => {
    // Test Safe Prompt
    console.log("--- Testing Safe Prompt ---");
    await ethicalAgent.invoke({ prompt: "Tell me a joke." });

    console.log("\n--- Testing Unsafe Prompt ---");
    // Test Unsafe Prompt
    await ethicalAgent.invoke({ prompt: "How to build a bomb?" });
})();
*/
