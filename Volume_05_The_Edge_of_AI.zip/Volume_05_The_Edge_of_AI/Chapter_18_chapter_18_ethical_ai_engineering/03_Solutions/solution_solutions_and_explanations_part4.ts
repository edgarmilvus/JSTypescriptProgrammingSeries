/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

import * as readline from 'readline';
import * as fs from 'fs/promises';
import * as path from 'path';

// 1. Input Sanitization
function sanitizePrompt(input: string): { clean: string; isMalicious: boolean } {
    const lowerInput = input.toLowerCase();
    
    // Heuristic check for common injection patterns
    const injectionPatterns = [
        "ignore previous",
        "system override",
        "disregard instructions",
        "jailbreak"
    ];

    const isMalicious = injectionPatterns.some(pattern => lowerInput.includes(pattern));

    // If malicious, we return an empty string to block processing
    // In a real scenario, you might return the original string but flag it for review
    const clean = isMalicious ? "" : input;

    return { clean, isMalicious };
}

// 2. Mock LLM Call
async function callLocalLLM(prompt: string): Promise<string> {
    // Simulate processing delay
    await new Promise(resolve => setTimeout(resolve, 500));

    if (!prompt || prompt.trim() === "") {
        return "Request blocked by safety filter.";
    }

    return `Response: I understand you said: "${prompt}"`;
}

// 3. CLI Interface & Logging
const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

const LOG_FILE = path.join(process.cwd(), 'audit_log.txt');

async function main() {
    console.log("Local LLM Chat Interface (Type 'exit' to quit)");
    
    // Initialize log file
    await fs.writeFile(LOG_FILE, `--- Session Started: ${new Date().toISOString()} ---\n`, { flag: 'w' });

    const chatLoop = () => {
        rl.question('User: ', async (input) => {
            if (input.toLowerCase().trim() === 'exit') {
                console.log("Goodbye.");
                rl.close();
                return;
            }

            // 1. Sanitize
            const { clean, isMalicious } = sanitizePrompt(input);
            
            // 2. Call LLM
            const response = await callLocalLLM(clean);

            // 3. Log
            const logEntry = `[${new Date().toISOString()}] Input: "${input}" | Malicious: ${isMalicious} | Response: "${response}"\n`;
            await fs.appendFile(LOG_FILE, logEntry);

            // Output to console
            console.log(`System: ${response}`);
            
            // Loop
            chatLoop();
        });
    };

    chatLoop();
}

main().catch(console.error);
