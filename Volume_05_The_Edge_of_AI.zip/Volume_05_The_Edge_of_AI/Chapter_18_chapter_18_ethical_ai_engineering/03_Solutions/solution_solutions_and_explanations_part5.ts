/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

// Mock functions simulating external dependencies
const biasFilter = async (text: string): Promise<string> => {
    // Simulate async check (e.g., API call to a moderation service)
    await new Promise(resolve => setTimeout(resolve, 100)); 
    // Mock logic: remove specific words
    return text.replace(/badword/gi, '[REDACTED]');
};

const embed = async (text: string): Promise<number[]> => {
    // Simulate vectorization delay
    await new Promise(resolve => setTimeout(resolve, 50));
    // Return a mock vector of size 3
    return text.split('').map(() => Math.random());
};

// 1. Sequential Baseline
export async function generateEmbeddingsSequential(chunks: string[]): Promise<number[][]> {
    const embeddings: number[][] = [];
    
    for (const chunk of chunks) {
        // Ethical check happens first
        const filtered = await biasFilter(chunk);
        // Then embedding generation
        const vector = await embed(filtered);
        embeddings.push(vector);
    }
    
    return embeddings;
}

// 2. Parallel Optimization
export async function generateEmbeddingsParallel(chunks: string[]): Promise<number[][]> {
    // We map each chunk to a promise that handles the full pipeline for that chunk
    const promises = chunks.map(async (chunk) => {
        // Ethical check (happens concurrently for all chunks)
        const filtered = await biasFilter(chunk);
        // Embedding generation
        return await embed(filtered);
    });

    // Wait for all promises to resolve
    return Promise.all(promises);
}

// 3. Benchmarking Script
async function runBenchmark() {
    const testChunks = Array(10).fill("This is a sample text containing badword for testing.");
    
    console.log("Starting benchmark...");
    
    // Benchmark Sequential
    const startSeq = performance.now();
    await generateEmbeddingsSequential(testChunks);
    const endSeq = performance.now();
    const timeSeq = endSeq - startSeq;
    
    // Benchmark Parallel
    const startPar = performance.now();
    await generateEmbeddingsParallel(testChunks);
    const endPar = performance.now();
    const timePar = endPar - startPar;

    console.log(`\nResults for ${testChunks.length} chunks:`);
    console.log(`Sequential Time: ${timeSeq.toFixed(2)}ms`);
    console.log(`Parallel Time:   ${timePar.toFixed(2)}ms`);
    console.log(`Speedup Factor:  ${(timeSeq / timePar).toFixed(2)}x`);
    
    // Verify Integrity Check (Mock assertion)
    // In a real test, we would assert that the output contains "[REDACTED]"
    console.log("\nIntegrity Check: Bias filter applied in parallel path? Yes (verified by code structure).");
}

// Execute benchmark
// runBenchmark();
