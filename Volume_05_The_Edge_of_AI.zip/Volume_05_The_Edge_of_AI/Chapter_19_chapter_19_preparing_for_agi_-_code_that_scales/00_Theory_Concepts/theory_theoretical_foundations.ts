/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: theory_theoretical_foundations.ts
// Description: Theoretical Foundations
// ==========================================

// A theoretical interface for an embedding service.
// This abstracts away the underlying model (e.g., a local Ollama model or a remote API).
interface EmbeddingService {
    // The generate method returns a Promise, signifying an asynchronous operation.
    // This is crucial for non-blocking behavior within the Node.js Event Loop.
    generate(text: string): Promise<number[]>;
}

// A mock implementation for demonstration purposes.
class LocalModelEmbeddingService implements EmbeddingService {
    async generate(text: string): Promise<number[]> {
        // In a real scenario, this would be an API call to a local model (e.g., via Ollama's API)
        // or a more complex computation. The key is that it's an I/O-bound operation.
        // We simulate a delay to represent network latency or model inference time.
        return new Promise(resolve => {
            setTimeout(() => {
                // A dummy 384-dimensional vector for demonstration.
                const vector: number[] = new Array(384).fill(0).map(() => Math.random());
                console.log(`Generated embedding for text of length ${text.length}`);
                resolve(vector);
            }, 100); // Simulates 100ms latency
        });
    }
}

// --- Usage in a larger application ---
const embeddingService = new LocalModelEmbeddingService();
const textChunk = "AGI architectures must be designed for scalability and fault tolerance.";

// We "fire and forget" the embedding generation, allowing the main thread to continue.
// The Promise is handled by the Event Loop.
const embeddingPromise: Promise<number[]> = embeddingService.generate(textChunk);

// We can attach .then() to handle the result when it's ready, without blocking.
embeddingPromise.then(vector => {
    console.log("Embedding is ready! Vector dimension:", vector.length);
    // This callback will be placed on the Task Queue and executed by the Event Loop
    // once the embedding generation is complete.
});

// The main thread is free to continue executing other code immediately.
console.log("Main thread is not blocked. Continuing with other tasks...");
