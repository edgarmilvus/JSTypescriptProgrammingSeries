/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part2.ts
// Description: Theoretical Foundations
// ==========================================

// Define possible types for a data chunk in our pipeline.
type TextChunk = string;
interface RichTextChunk {
    content: string;
    metadata: {
        source: string;
        chunkId: number;
    };
}

// A variable that could be one of several types.
type IncomingData = TextChunk | RichTextChunk;

function processChunk(data: IncomingData) {
    // At this point, TypeScript only knows `data` is `IncomingData`.
    // We cannot safely access `data.metadata` because it might not exist on a string.

    // --- TYPE NARROWING IN ACTION ---
    // We perform a runtime check using `typeof` and `in`.
    if (typeof data === 'string') {
        // Inside this block, TypeScript has NARROWED the type of `data` to `string`.
        // It knows `data.metadata` is not accessible here.
        const upperCaseContent = data.toUpperCase();
        console.log("Processing simple text chunk:", upperCaseContent);
    } else if ('metadata' in data) {
        // Inside this block, TypeScript has NARROWED the type to `RichTextChunk`.
        // It now allows safe access to `data.metadata` and `data.content`.
        console.log(`Processing rich chunk ${data.metadata.chunkId} from ${data.metadata.source}`);
        const upperCaseContent = data.content.toUpperCase();
    } else {
        // This branch handles any other unexpected shapes, making the system robust.
        console.error("Unknown data format received:", data);
    }
}

// Example usage
processChunk("This is a simple text chunk.");
processChunk({
    content: "This is a rich text chunk.",
    metadata: { source: "document.pdf", chunkId: 42 }
});
