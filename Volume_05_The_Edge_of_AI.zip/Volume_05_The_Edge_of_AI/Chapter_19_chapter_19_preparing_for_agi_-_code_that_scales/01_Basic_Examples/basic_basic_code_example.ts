/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

// lib/graph.ts
import { StateGraph, Annotation, Node } from "@langchain/langgraph";

/**
 * @description Graph State Interface
 * Defines the canonical data structure passed between nodes.
 * This adheres to the "Graph State" definition: singular, canonical, and persistent.
 */
export interface AgentState {
  input: string;
  processedOutput?: string;
  finalOutput?: string;
  error?: string;
}

/**
 * @description State Annotation
 * Defines the reducer for the state. In a complex app, this handles merging updates.
 * For this "Hello World", we simply overwrite keys.
 */
const StateAnnotation = Annotation.Root({
  input: Annotation<string>,
  processedOutput: Annotation<string | undefined>,
  finalOutput: Annotation<string | undefined>,
  error: Annotation<string | undefined>,
});

/**
 * @description Node 1: Input Validator
 * Adheres to SRP: Only concerns itself with validating the input string.
 * @param state - The current graph state
 * @returns - The updated state (or throws an error to trigger graph failure)
 */
const validateInput = async (state: typeof StateAnnotation.State) => {
  console.log("Node: Validating input...");
  if (!state.input || state.input.trim().length === 0) {
    // In LangGraph, throwing an error typically interrupts the graph execution
    // or routes it to an error node if configured.
    throw new Error("Input cannot be empty.");
  }
  // Return state to pass to next node
  return { input: state.input };
};

/**
 * @description Node 2: Mock AI Processor
 * Adheres to SRP: Only concerns itself with the "AI" transformation logic.
 * Simulates an async LLM call.
 * @param state - The current graph state
 * @returns - The updated state with processed output
 */
const processWithAI = async (state: typeof StateAnnotation.State) => {
  console.log("Node: Processing with AI...");
  // Simulate network latency
  await new Promise((resolve) => setTimeout(resolve, 500));
  
  // Mock transformation
  const processed = `AI Processed: ${state.input.toUpperCase()}`;
  
  return { processedOutput: processed };
};

/**
 * @description Node 3: Formatter
 * Adheres to SRP: Only concerns itself with formatting the final response.
 * @param state - The current graph state
 * @returns - The updated state with final output
 */
const formatResponse = async (state: typeof StateAnnotation.State) => {
  console.log("Node: Formatting response...");
  if (!state.processedOutput) {
    throw new Error("Missing processed output.");
  }
  
  const formatted = `Result: ${state.processedOutput} | Timestamp: ${new Date().toISOString()}`;
  return { finalOutput: formatted };
};

/**
 * @description Graph Construction
 * We build the graph using the StateGraph class.
 * This separates the workflow definition from the execution logic.
 */
export const createHelloWorldGraph = () => {
  // Initialize the graph with our State Annotation
  const workflow = new StateGraph(StateAnnotation);

  // Define nodes
  // Note: In newer LangGraph versions, nodes are functions or objects.
  // We wrap our functions in a simple object structure if required, 
  // but function nodes are standard.
  workflow.addNode("validate_node", validateInput);
  workflow.addNode("process_node", processWithAI);
  workflow.addNode("format_node", formatResponse);

  // Define edges (Workflow Logic)
  // Start -> Validate
  workflow.addEdge("__start__", "validate_node");
  
  // Validate -> Process (if valid)
  workflow.addEdge("validate_node", "process_node");
  
  // Process -> Format
  workflow.addEdge("process_node", "format_node");

  // Return the compiled graph
  return workflow.compile();
};
