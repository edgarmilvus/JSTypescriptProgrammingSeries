/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.ts
// Description: Basic Code Example
// ==========================================

// app/api/hello-world/route.ts
import { NextRequest, NextResponse } from "next/server";
import { createHelloWorldGraph } from "@/lib/graph";

/**
 * @description POST Handler
 * Handles incoming requests to execute the agent workflow.
 * 
 * @param request - The incoming HTTP request object
 * @returns A JSON response containing the final output or error details
 */
export async function POST(request: NextRequest) {
  try {
    // 1. Parse the incoming JSON body
    const body = await request.json();
    const { input } = body;

    // 2. Initialize the Graph
    // We create a new instance for this request to ensure state isolation.
    const graph = createHelloWorldGraph();

    // 3. Execute the Graph
    // We pass the initial state (input) to the graph's stream method.
    // LangGraph handles the traversal of nodes (validate -> process -> format).
    const stream = await graph.stream({
      input: input,
    });

    // 4. Iterate through the stream to get the final state
    // LangGraph streams updates for every node. We want the last one.
    let finalState = null;
    for await (const step of stream) {
      // The key is the node name, the value is the state update
      const [nodeName, stateUpdate] = Object.entries(step)[0];
      console.log(`Step completed: ${nodeName}`);
      
      // Update our reference to the latest state
      // Note: In a real scenario, we might merge state more carefully.
      // For this example, we just track the latest object.
      finalState = { ...finalState, ...stateUpdate };
    }

    // 5. Return the result
    if (finalState?.finalOutput) {
      return NextResponse.json(
        { 
          success: true, 
          output: finalState.finalOutput 
        },
        { status: 200 }
      );
    } else {
      // Handle case where graph finished but didn't produce expected output
      return NextResponse.json(
        { 
          success: false, 
          error: "Workflow completed but no output generated." 
        },
        { status: 500 }
      );
    }

  } catch (error) {
    // 6. Error Handling
    // Captures errors from validation or processing nodes.
    console.error("Graph execution failed:", error);
    
    const errorMessage = error instanceof Error ? error.message : "Unknown error";
    
    return NextResponse.json(
      { 
        success: false, 
        error: errorMessage 
      },
      { status: 400 } // 400 Bad Request is appropriate for validation errors
    );
  }
}
