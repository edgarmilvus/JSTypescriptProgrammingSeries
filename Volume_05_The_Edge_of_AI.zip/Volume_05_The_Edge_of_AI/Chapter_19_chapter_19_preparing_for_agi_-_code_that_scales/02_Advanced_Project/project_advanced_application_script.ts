/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// app/api/inference/route.ts

/**
 * ============================================================================
 * IMPORTS & DEPENDENCIES
 * ============================================================================
 */
import { NextResponse } from 'next/server';
import { z } from 'zod';

/**
 * ============================================================================
 * 1. ZOD SCHEMA DEFINITION (Runtime Validation)
 * ============================================================================
 * 
 * Why: External inputs (API requests) cannot be trusted. Zod defines the 
 * contract at runtime, ensuring data integrity before it touches our 
 * inference logic.
 * 
 * How: We define a schema that describes the expected shape of the incoming
 * JSON body. This schema is also used to infer the TypeScript type below.
 */
const InferenceRequestSchema = z.object({
  prompt: z.string().min(1, "Prompt cannot be empty.").max(2048),
  model: z.enum(['llama2', 'mistral', 'phi2']).default('llama2'),
  temperature: z.number().min(0).max(1).default(0.7),
  // Strict type discipline: We explicitly define this as an optional array of strings
  contextIds: z.array(z.string()).optional().default([]),
});

// Infer the TypeScript type from the Zod schema for compile-time safety
type InferenceRequest = z.infer<typeof InferenceRequestSchema>;

/**
 * ============================================================================
 * 2. MOCK INFERENCE ENGINE (Simulating Local LLM)
 * ============================================================================
 * 
 * Why: In a real scenario, this would interface with Ollama or Transformers.js.
 * Here, we simulate the latency and potential failure modes of a heavy 
 * computation.
 * 
 * How: We use a Promise with a random delay to simulate network/processing time.
 */
async function callLocalLLM(
  prompt: string, 
  model: string, 
  temp: number
): Promise<{ response: string; tokens: number }> {
  // Simulate compute latency (100ms - 500ms)
  const latency = Math.floor(Math.random() * 400) + 100;
  await new Promise((resolve) => setTimeout(resolve, latency));

  // Simulate a potential random failure (5% chance) to test error handling
  if (Math.random() < 0.05) {
    throw new Error(`[Model ${model}] Inference engine timeout.`);
  }

  // Mock response generation
  const mockResponse = `Processed: "${prompt}" (Model: ${model}, Temp: ${temp})`;
  
  return {
    response: mockResponse,
    tokens: mockResponse.length, // Approximate token count
  };
}

/**
 * ============================================================================
 * 3. ASYNC PIPELINE MANAGER
 * ============================================================================
 * 
 * Why: AGI systems require fault tolerance. If one part of the context 
 * retrieval fails, the core generation should ideally continue or fail gracefully.
 * 
 * How: We process the optional context IDs asynchronously. If any fail, we 
 * log them but don't necessarily crash the entire request, depending on 
 * business logic.
 */
async function retrieveContext(contextIds: string[]) {
  // Simulate vector database lookup
  const contextPromises = contextIds.map(async (id) => {
    // Simulate network latency
    await new Promise(r => setTimeout(r, 50));
    return `Context[${id}]: Retrieved relevant data...`;
  });

  try {
    const results = await Promise.all(contextPromises);
    return results.join('\n');
  } catch (error) {
    console.error("Context retrieval partial failure:", error);
    return ""; // Return empty context on failure to allow generation to proceed
  }
}

/**
 * ============================================================================
 * 4. NEXT.JS API ROUTE HANDLER
 * ============================================================================
 * 
 * The entry point. Handles the HTTP request lifecycle.
 */
export async function POST(req: Request) {
  try {
    // A. Parse and Validate Input
    // We cannot trust req.json() without validation.
    const rawBody = await req.json();
    const parsedBody = InferenceRequestSchema.safeParse(rawBody);

    if (!parsedBody.success) {
      // Return structured error details for client-side debugging
      return NextResponse.json(
        { 
          error: "Validation Failed", 
          details: parsedBody.error.flatten() 
        }, 
        { status: 400 }
      );
    }

    const { prompt, model, temperature, contextIds } = parsedBody.data;

    // B. Execute Asynchronous Pipeline
    // We run context retrieval and model inference in parallel where possible
    // to minimize total latency (Fan-out pattern).
    const [context, llmResult] = await Promise.all([
      retrieveContext(contextIds),
      callLocalLLM(prompt, model, temperature),
    ]);

    // C. Construct Final Output
    // Combine context and generation. In a real app, this might stream tokens.
    const finalResponse = {
      id: crypto.randomUUID(), // Strict type usage: string
      timestamp: new Date().toISOString(),
      model: model,
      input: {
        prompt,
        context: context, // Will be empty string if retrieval failed gracefully
      },
      output: llmResult.response,
      usage: {
        tokens: llmResult.tokens,
        contextLength: context.length,
      },
      metadata: {
        system: "AGI-Gateway-v1.0",
        optimized: true,
      },
    };

    // D. Return Success
    return NextResponse.json(finalResponse, { status: 200 });

  } catch (error) {
    // E. Global Error Handler
    // Catches runtime errors (e.g., Model timeout) that validation didn't catch.
    console.error("Critical Inference Error:", error);

    // Ensure we never return a raw error object to the client (security risk)
    const errorMessage = error instanceof Error ? error.message : "Unknown internal error";
    
    return NextResponse.json(
      { 
        error: "Inference Failed", 
        message: "The local model encountered an error. Please retry.",
        details: process.env.NODE_ENV === 'development' ? errorMessage : undefined
      }, 
      { status: 500 }
    );
  }
}
