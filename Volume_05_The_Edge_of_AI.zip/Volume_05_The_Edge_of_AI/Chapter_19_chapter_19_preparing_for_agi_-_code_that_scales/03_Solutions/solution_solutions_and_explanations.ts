/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// 1. Define the generic interface
// T represents the shape of the metadata associated with each vector.
export interface VectorStore<T> {
  insert(id: string, vector: number[], metadata: T): Promise<void>;
  query(vector: number[], k: number): Promise<Array<{ id: string; score: number; metadata: T }>>;
  delete(id: string): Promise<void>;
}

// 2. Mock Supabase types for demonstration purposes
// In a real app, you would import these from '@supabase/supabase-js'
type SupabaseClient = any; 

// 3. Implement the SupabaseVectorStore class
export class SupabaseVectorStore<T> implements VectorStore<T> {
  private client: SupabaseClient;
  private tableName: string;

  constructor(client: SupabaseClient, tableName: string) {
    this.client = client;
    this.tableName = tableName;
  }

  async insert(id: string, vector: number[], metadata: T): Promise<void> {
    // We assume the table has columns: id (text), embedding (vector), and metadata (jsonb)
    const { error } = await this.client
      .from(this.tableName)
      .insert([{ id, embedding: vector, metadata }]);

    if (error) {
      throw new Error(`Failed to insert vector: ${error.message}`);
    }
  }

  async query(vector: number[], k: number): Promise<Array<{ id: string; score: number; metadata: T }>> {
    // Using pgvector's <#> operator for inner product distance (lower is better)
    // Note: Depending on the distance metric, you might need to adjust the ordering.
    const { data, error } = await this.client
      .from(this.tableName)
      .select('id, metadata, embedding')
      .order('embedding', { 
        ascending: true, 
        // @ts-ignore - Supabase specific RPC syntax for vector distance
        foreignTable: this.tableName 
      })
      .limit(k);

    if (error) {
      throw new Error(`Failed to query vectors: ${error.message}`);
    }

    // Map the raw results to the expected format
    // In a real implementation, the distance score would be calculated by the DB
    return data.map((row: any) => ({
      id: row.id,
      metadata: row.metadata,
      score: 0.95 // Mock score, as actual distance calculation depends on DB config
    }));
  }

  async delete(id: string): Promise<void> {
    const { error } = await this.client
      .from(this.tableName)
      .delete()
      .eq('id', id);

    if (error) {
      throw new Error(`Failed to delete vector: ${error.message}`);
    }
  }
}

// 4. Example usage instantiation
type DocumentMetadata = { title: string; page: number };

// Mock client instance
const mockSupabaseClient = {}; 

// Instantiate the store with specific metadata type
const documentStore = new SupabaseVectorStore<DocumentMetadata>(
  mockSupabaseClient, 
  'document_embeddings'
);

// Usage example (commented out as it requires a real client)
/*
await documentStore.insert(
  'doc-123', 
  [0.1, 0.5, 0.3], 
  { title: "AGI Scaling Guide", page: 1 }
);
*/
