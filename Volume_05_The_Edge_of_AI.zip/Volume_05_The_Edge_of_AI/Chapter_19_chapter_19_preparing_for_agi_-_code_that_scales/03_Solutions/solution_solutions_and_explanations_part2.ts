/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

'use server';

import { VectorStore } from './exercise-1'; // Assuming interface is in this file

// Helper function to simulate embedding generation
const generateEmbedding = async (text: string): Promise<number[]> => {
  // Simulate network latency for embedding API (e.g., OpenAI)
  await new Promise(resolve => setTimeout(resolve, 100)); 
  // Return a dummy vector of dimension 1536
  return new Array(1536).fill(0).map(() => Math.random());
};

// Helper function to process a batch of documents
async function processBatch(
  batch: Array<{ id: string; text: string }>,
  vectorStore: VectorStore<any>
): Promise<{ success: boolean; id?: string; error?: string }[]> {
  return Promise.all(
    batch.map(async (doc) => {
      try {
        // 1. Mock embedding generation
        const embedding = await generateEmbedding(doc.text);
        
        // 2. Insert into vector store
        // Metadata is empty object {} in this example, but could be extended
        await vectorStore.insert(doc.id, embedding, {});
        
        return { success: true, id: doc.id };
      } catch (error) {
        return { 
          success: false, 
          id: doc.id, 
          error: error instanceof Error ? error.message : 'Unknown error' 
        };
      }
    })
  );
}

export async function ingestDocuments(
  documents: Array<{ id: string; text: string }>,
  vectorStore: VectorStore<any>
) {
  const BATCH_SIZE = 5;
  const errors: Array<{ id: string; error: string }> = [];
  let successCount = 0;

  // Process documents in chunks to avoid overwhelming the system
  for (let i = 0; i < documents.length; i += BATCH_SIZE) {
    const batch = documents.slice(i, i + BATCH_SIZE);
    
    // Process the current batch concurrently
    const results = await processBatch(batch, vectorStore);

    // Aggregate results
    results.forEach((result) => {
      if (result.success) {
        successCount++;
      } else {
        errors.push({ id: result.id!, error: result.error! });
      }
    });
  }

  return { successCount, errors };
}
