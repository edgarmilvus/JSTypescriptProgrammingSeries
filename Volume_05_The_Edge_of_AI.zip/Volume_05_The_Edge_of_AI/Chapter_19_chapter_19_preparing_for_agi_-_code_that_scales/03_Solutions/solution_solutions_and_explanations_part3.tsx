/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

import { useState } from 'react';

// 1. Define generic Message type
export type Message<T = {}> = {
  role: 'user' | 'assistant' | 'loading';
  content: string;
  metadata?: T;
};

// 2. Define the hook with a generic parameter T for metadata
export function useChatOptimistic<T>() {
  const [messages, setMessages] = useState<Message<T>[]>([]);

  // Simulate a server response (e.g., an API call or Server Action)
  const mockServerResponse = async (text: string): Promise<Message<T>> => {
    await new Promise(resolve => setTimeout(resolve, 1500)); // Simulate delay
    return {
      role: 'assistant',
      content: `Response to: ${text}`,
      metadata: { sources: ['doc_1.pdf'] } as T // Casting for demo
    };
  };

  const sendMessage = async (content: string) => {
    // 1. Create User Message
    const userMessage: Message<T> = { role: 'user', content };
    
    // 2. Optimistic Update: Add user message immediately
    setMessages((prev) => [...prev, userMessage]);

    // 3. Create Loading Placeholder
    const loadingMessage: Message<T> = { 
      role: 'loading', 
      content: 'Thinking...', 
    };

    // 4. Add Loading message to state
    setMessages((prev) => [...prev, loadingMessage]);

    try {
      // 5. Await Server Response
      const response = await mockServerResponse(content);

      // 6. Replace loading message with actual response
      setMessages((prev) => 
        prev.map((msg) => (msg.role === 'loading' ? response : msg))
      );
    } catch (error) {
      // Handle error by removing loading message and showing error
      setMessages((prev) => prev.filter((msg) => msg.role !== 'loading'));
      console.error("Chat failed:", error);
    }
  };

  return { messages, sendMessage };
}

// Usage Example Component
/*
export function ChatComponent() {
  const { messages, sendMessage } = useChatOptimistic<{ sources: string[] }>();
  
  return (
    <div>
      {messages.map((msg, idx) => (
        <div key={idx}>
          <strong>{msg.role}: </strong>
          {msg.content}
          {msg.metadata && <span> (Sources: {msg.metadata.sources.join(', ')})</span>}
        </div>
      ))}
      <button onClick={() => sendMessage("Hello AI")}>Send</button>
    </div>
  );
}
*/
