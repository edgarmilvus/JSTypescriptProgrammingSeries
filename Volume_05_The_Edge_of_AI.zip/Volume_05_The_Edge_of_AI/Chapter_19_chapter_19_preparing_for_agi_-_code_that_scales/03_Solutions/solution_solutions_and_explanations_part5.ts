/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

/**
 * A generic fetcher with exponential backoff retry logic.
 * @param url - The URL to fetch.
 * @param options - Standard fetch options.
 * @param retries - Number of times to retry.
 * @param delay - Initial delay in milliseconds.
 */
export async function fetchWithRetry<T>(
  url: string,
  options: RequestInit,
  retries: number,
  delay: number
): Promise<T> {
  try {
    const response = await fetch(url, options);

    if (!response.ok) {
      // Simulate a network error for non-200 responses
      throw new Error(`HTTP Error: ${response.status}`);
    }

    const data = (await response.json()) as T;
    return data;
  } catch (error) {
    // If no retries left, throw the error
    if (retries <= 0) {
      console.error("All retries exhausted. Last error:", error);
      throw error;
    }

    console.log(`Request failed. Retrying in ${delay}ms... (${retries} retries left)`);
    
    // Wait for the specified delay
    await new Promise(resolve => setTimeout(resolve, delay));

    // Recursive call with reduced retries and doubled delay
    return fetchWithRetry<T>(url, options, retries - 1, delay * 2);
  }
}

// --- Interactive Test Case ---

// Mock fetch to simulate failures
global.fetch = jest.fn() // Assuming Jest environment, or use a manual mock
  .mockImplementationOnce(() => Promise.reject(new Error("Network Down"))) // Fail 1
  .mockImplementationOnce(() => Promise.reject(new Error("Network Down"))) // Fail 2
  .mockImplementationOnce(() => Promise.resolve({ 
    ok: true, 
    json: () => Promise.resolve({ success: true, data: "AGI Data" }) 
  })); // Success 3

async function testResilientFetcher() {
  const start = Date.now();
  
  try {
    const result = await fetchWithRetry<{ success: boolean; data: string }>(
      "https://api.agi-system.com/data",
      {},
      2, // Retries
      100 // Initial Delay (100ms)
    );
    
    const elapsed = Date.now() - start;
    console.log("Success:", result);
    console.log(`Total time elapsed: ${elapsed}ms`);
    
    // Expected Logic:
    // Attempt 1: Fail immediately
    // Wait 100ms
    // Attempt 2: Fail immediately
    // Wait 200ms (100 * 2)
    // Attempt 3: Success
    // Total expected wait: 100ms + 200ms = 300ms (plus execution overhead)
    
  } catch (err) {
    console.error("Test failed:", err);
  }
}

// Run the test
// testResilientFetcher();
