/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * @fileoverview Basic Hybrid Router for Local-First AI Workspace.
 * Demonstrates routing tasks between browser-local (WebGPU) and local server (Ollama).
 */

// --- 1. Type Definitions ---

/**
 * Represents the capabilities of the execution environment.
 * 'webgpu' implies browser acceleration is available.
 * 'ollama' implies a local server is reachable.
 */
type EnvironmentCapability = 'webgpu' | 'ollama';

/**
 * Defines the structure of an AI task request.
 */
interface AiTask {
    id: string;
    prompt: string;
    // Metadata to help the router decide (e.g., model size requirements)
    complexity: 'low' | 'high'; 
    // Optional: specific model requested (e.g., 'llama2', 'all-MiniLM-L6-v2')
    model?: string;
}

/**
 * Defines the structure of the task result.
 */
interface AiResult {
    taskId: string;
    source: 'browser' | 'server';
    output: string;
    timestamp: number;
}

// --- 2. Mock Implementations (Simulating External Libraries) ---

/**
 * Simulates Transformers.js running in the browser.
 * In a real app, this would be an async import() of the library.
 */
class BrowserLocalModel {
    /**
     * Simulates running a small model (e.g., a quantized BERT or Phi-2) via WebGPU.
     * @param prompt - The input text.
     * @returns Promise<string> - The generated response.
     */
    async run(prompt: string): Promise<string> {
        // Simulate WebGPU compilation delay (Cold Start)
        console.log("⚡ [Browser] Initializing WebGPU pipeline...");
        await new Promise(resolve => setTimeout(resolve, 100)); 
        
        console.log("⚡ [Browser] Running inference locally...");
        // Simulate processing time
        await new Promise(resolve => setTimeout(resolve, 50)); 
        
        return `[Local GPU]: Processed "${prompt.substring(0, 20)}..."`;
    }
}

/**
 * Simulates the Ollama API client.
 * In a real app, this would use `fetch` to hit `http://localhost:11434/api/generate`.
 */
class OllamaClient {
    private baseUrl: string;

    constructor(baseUrl: string = "http://localhost:11434") {
        this.baseUrl = baseUrl;
    }

    /**
     * Simulates sending a request to the Ollama server.
     * @param prompt - The input text.
     * @param model - The model identifier (e.g., 'llama2').
     * @returns Promise<string> - The generated response.
     */
    async generate(prompt: string, model: string = "llama2"): Promise<string> {
        console.log(`🧠 [Server] Sending request to Ollama (${model})...`);
        
        // Simulate network latency and server processing
        await new Promise(resolve => setTimeout(resolve, 300)); 
        
        return `[Ollama/${model}]: Generated response for prompt: "${prompt}"`;
    }
}

// --- 3. The Core Router Logic ---

/**
 * The Router class decides where to execute the AI task based on 
 * available capabilities and task requirements.
 */
class LocalFirstRouter {
    private capabilities: Set<EnvironmentCapability>;
    private browserModel: BrowserLocalModel;
    private ollamaClient: OllamaClient;

    constructor(capabilities: EnvironmentCapability[]) {
        this.capabilities = new Set(capabilities);
        this.browserModel = new BrowserLocalModel();
        this.ollamaClient = new OllamaClient();
    }

    /**
     * Main entry point for processing a task.
     * Implements the hybrid routing logic.
     */
    public async processTask(task: AiTask): Promise<AiResult> {
        const startTime = Date.now();
        
        // Decision Logic: Route based on complexity and available capabilities
        const destination = this.decideDestination(task);

        let output: string;

        try {
            if (destination === 'browser') {
                output = await this.browserModel.run(task.prompt);
            } else {
                // Fallback to Ollama if browser isn't suitable
                const model = task.model || 'llama2'; // Default model
                output = await this.ollamaClient.generate(task.prompt, model);
            }
        } catch (error) {
            console.error("Execution failed:", error);
            throw new Error("Task processing failed.");
        }

        return {
            taskId: task.id,
            source: destination,
            output: output,
            timestamp: Date.now() - startTime
        };
    }

    /**
     * Determines the optimal execution environment.
     * 
     * Logic:
     * 1. If task is 'low' complexity AND browser has 'webgpu', use Browser.
     * 2. If task is 'high' complexity OR browser lacks 'webgpu', use Ollama.
     * 3. If Ollama is unavailable, fallback to browser (if possible) or throw error.
     */
    private decideDestination(task: AiTask): 'browser' | 'server' {
        // Rule 1: High complexity tasks always go to the server (Ollama)
        if (task.complexity === 'high') {
            if (this.capabilities.has('ollama')) {
                return 'server';
            }
            // Fallback warning if server is missing
            console.warn("⚠️ High complexity task requested, but Ollama is not available.");
        }

        // Rule 2: Low complexity tasks prefer browser (WebGPU) for responsiveness
        if (task.complexity === 'low' && this.capabilities.has('webgpu')) {
            return 'browser';
        }

        // Rule 3: Default to server if browser isn't capable or preferred
        if (this.capabilities.has('ollama')) {
            return 'server';
        }

        throw new Error("No capable environment found for this task.");
    }
}

// --- 4. Usage Example (Simulated Main Thread) ---

/**
 * Simulates the application lifecycle.
 */
async function main() {
    console.log("--- Starting Local-First AI Workspace ---");

    // Detect capabilities (In a real app, this checks `navigator.gpu` and fetch health checks)
    const availableCapabilities: EnvironmentCapability[] = ['webgpu', 'ollama'];
    
    const router = new LocalFirstRouter(availableCapabilities);

    // Scenario A: Lightweight task (Syntax check / Summarization)
    // Expected: Routed to Browser (WebGPU) for speed.
    const lowComplexityTask: AiTask = {
        id: "task-001",
        prompt: "Check syntax of: const x = 10;",
        complexity: "low"
    };

    // Scenario B: Heavy task (Generation / Reasoning)
    // Expected: Routed to Ollama (Server) for power.
    const highComplexityTask: AiTask = {
        id: "task-002",
        prompt: "Write a detailed essay on the history of AI.",
        complexity: "high",
        model: "llama2"
    };

    try {
        // Execute tasks concurrently
        const [resultA, resultB] = await Promise.all([
            router.processTask(lowComplexityTask),
            router.processTask(highComplexityTask)
        ]);

        console.log("\n--- Results ---");
        console.log(`Task A (${resultA.source}): ${resultA.output} (Time: ${resultA.timestamp}ms)`);
        console.log(`Task B (${resultB.source}): ${resultB.output} (Time: ${resultB.timestamp}ms)`);

    } catch (err) {
        console.error("Fatal Error:", err);
    }
}

// Run the simulation
main();
