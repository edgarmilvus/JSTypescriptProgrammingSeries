/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.tsx
// Description: Advanced Application Script
// ==========================================

// src/components/HybridAIWorkspace.tsx
import React, { useState, useEffect, useRef, useCallback } from 'react';

// ============================================================================
// 1. TYPE DEFINITIONS & INTERFACES
// ============================================================================

/**
 * Defines the source of the AI inference.
 * - 'browser': Runs locally in the client using Transformers.js (WebGPU/WASM).
 * - 'server': Runs locally via Ollama (Node.js backend).
 */
type InferenceSource = 'browser' | 'server';

/**
 * Defines the status of the AI model lifecycle.
 * - 'idle': No processing.
 * - 'loading': Downloading weights or connecting to backend.
 * - 'ready': Model is warm and ready for inference.
 * - 'error': Something went wrong.
 */
type AIStatus = 'idle' | 'loading' | 'ready' | 'error';

interface AIResult {
  source: InferenceSource;
  output: string;
  latency: number; // in ms
  timestamp: Date;
}

// ============================================================================
// 2. UTILITY: MOCKING EXTERNAL LIBRARIES
// ============================================================================

/**
 * NOTE: In a real environment, you would import:
 * import { pipeline } from '@xenova/transformers';
 * 
 * For this standalone script, we mock the Transformers.js API to demonstrate
 * the architecture without requiring actual heavy model downloads.
 */
const mockTransformers = {
  pipeline: async (task: string, model: string) => {
    // Simulate "Cold Start" delay for browser model initialization
    await new Promise(r => setTimeout(r, 1500)); 
    return {
      // Simulate inference execution
      __call__: async (input: string) => {
        await new Promise(r => setTimeout(r, 200)); // Fast inference
        return `[Browser/${model}]: Processed "${input}" locally via WebGPU.`;
      }
    };
  }
};

/**
 * Mock for Ollama API client.
 * In production, this would use `fetch` to hit http://localhost:11434/api/generate
 */
const mockOllamaClient = {
  generate: async (model: string, prompt: string) => {
    // Simulate network latency and processing time
    await new Promise(r => setTimeout(r, 800)); 
    return `[Ollama/${model}]: Analyzed "${prompt}" via local backend.`;
  }
};

// ============================================================================
// 3. CUSTOM HOOK: useLocalAI
// ============================================================================

/**
 * The core logic controller for the Local-First AI Workspace.
 * Handles dependency resolution (loading models) and routing logic.
 */
const useLocalAI = () => {
  // Browser Model State (Warm Start)
  const [browserStatus, setBrowserStatus] = useState<AIStatus>('idle');
  const browserPipelineRef = useRef<any>(null);

  // Server/Ollama State (Cold Start)
  const [serverStatus, setServerStatus] = useState<AIStatus>('idle');
  
  // Results History
  const [history, setHistory] = useState<AIResult[]>([]);

  /**
   * Dependency Resolution: Pre-load the browser model.
   * This mimics the initialization phase of a Next.js app or a useEffect mount.
   * We do this to avoid latency during user interaction (Warm Start strategy).
   */
  useEffect(() => {
    const initBrowserAI = async () => {
      try {
        setBrowserStatus('loading');
        // In production, this resolves actual WASM binaries and model weights
        const pipeline = await mockTransformers.pipeline('text-generation', 'Xenova/gpt2');
        browserPipelineRef.current = pipeline;
        setBrowserStatus('ready');
      } catch (err) {
        console.error("Browser AI Init Failed:", err);
        setBrowserStatus('error');
      }
    };

    initBrowserAI();
  }, []);

  /**
   * Routing Logic: Decides where to run the inference.
   * 
   * Strategy:
   * 1. If the browser model is 'ready' and the task is lightweight -> Route to Browser (WebGPU).
   * 2. If the task is heavy/complex, or browser is unavailable -> Route to Ollama.
   */
  const executeTask = useCallback(async (input: string, complexity: 'low' | 'high') => {
    const startTime = performance.now();
    let resultText = '';
    let source: InferenceSource = 'browser';

    try {
      // Decision Matrix
      if (complexity === 'low' && browserStatus === 'ready' && browserPipelineRef.current) {
        // ROUTE 1: Browser Inference (WebGPU/WASM)
        // Best for: Auto-complete, simple classification, immediate feedback.
        source = 'browser';
        resultText = await browserPipelineRef.current.__call__(input);
      } else {
        // ROUTE 2: Ollama Inference (Local Backend)
        // Best for: Summarization, complex reasoning, heavy RAG.
        // Triggers a "Cold Start" if Ollama isn't running, or simply network latency.
        source = 'server';
        setServerStatus('loading');
        resultText = await mockOllamaClient.generate('llama2', input);
        setServerStatus('ready');
      }

      const endTime = performance.now();
      const newResult: AIResult = {
        source,
        output: resultText,
        latency: Math.round(endTime - startTime),
        timestamp: new Date()
      };

      setHistory(prev => [newResult, ...prev]);

    } catch (err) {
      console.error("Inference Error:", err);
      // Fallback logic: If browser fails, try server
      if (source === 'browser') {
        // Recursive call with forced server route
        // (Omitted for brevity, but implies resilience)
      }
    }
  }, [browserStatus]);

  return { browserStatus, serverStatus, history, executeTask };
};

// ============================================================================
// 4. REACT COMPONENT: HybridAIWorkspace
// ============================================================================

/**
 * Main UI Component for the Capstone Workspace.
 */
export const HybridAIWorkspace: React.FC = () => {
  const { browserStatus, serverStatus, history, executeTask } = useLocalAI();
  const [inputText, setInputText] = useState('');

  /**
   * Handles form submission and determines complexity based on input length.
   * In a real app, this complexity check would be a dedicated classifier model.
   */
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim()) return;

    const complexity = inputText.length > 50 ? 'high' : 'low';
    await executeTask(inputText, complexity);
    setInputText('');
  };

  return (
    <div className="max-w-4xl mx-auto p-6 bg-gray-50 min-h-screen">
      {/* Header: Status Indicators */}
      <header className="mb-8 flex justify-between items-center border-b pb-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-800">Local-First AI Workspace</h1>
          <p className="text-sm text-gray-500">Hybrid Routing: Browser (WebGPU) ↔ Ollama (Local)</p>
        </div>
        <div className="flex gap-4 text-xs font-mono">
          <div className={`px-3 py-1 rounded ${browserStatus === 'ready' ? 'bg-green-100 text-green-700' : 'bg-yellow-100 text-yellow-700'}`}>
            BROWSER: {browserStatus.toUpperCase()}
          </div>
          <div className={`px-3 py-1 rounded ${serverStatus === 'ready' ? 'bg-blue-100 text-blue-700' : 'bg-gray-200 text-gray-600'}`}>
            OLLAMA: {serverStatus.toUpperCase()}
          </div>
        </div>
      </header>

      {/* Main Input Area */}
      <main className="bg-white shadow-lg rounded-lg p-6 mb-6">
        <form onSubmit={handleSubmit} className="flex gap-4">
          <input
            type="text"
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            placeholder="Type a prompt (Short=Browser, Long=Ollama)..."
            className="flex-1 border border-gray-300 rounded px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
            disabled={browserStatus === 'loading'}
          />
          <button
            type="submit"
            className="bg-blue-600 text-white px-6 py-2 rounded hover:bg-blue-700 disabled:opacity-50"
            disabled={browserStatus === 'loading'}
          >
            Run Task
          </button>
        </form>
        <div className="mt-3 text-xs text-gray-400">
          <span className="mr-2">• Low Complexity → Browser (Fast/Warm)</span>
          <span>• High Complexity → Ollama (Heavy/Cold)</span>
        </div>
      </main>

      {/* Results History Feed */}
      <section>
        <h2 className="text-lg font-semibold mb-4 text-gray-700">Execution History</h2>
        {history.length === 0 ? (
          <div className="text-center text-gray-400 py-10">No tasks executed yet.</div>
        ) : (
          <div className="space-y-4">
            {history.map((item, idx) => (
              <div 
                key={idx} 
                className={`p-4 rounded border-l-4 ${
                  item.source === 'browser' 
                    ? 'border-green-500 bg-green-50' 
                    : 'border-blue-500 bg-blue-50'
                }`}
              >
                <div className="flex justify-between items-start mb-2">
                  <span className="font-bold text-sm uppercase tracking-wide">
                    {item.source === 'browser' ? '⚡ Browser (WebGPU)' : '🧠 Ollama (Local)'}
                  </span>
                  <span className="text-xs font-mono bg-white px-2 py-1 rounded border">
                    {item.latency}ms
                  </span>
                </div>
                <p className="text-gray-800 text-sm">{item.output}</p>
                <div className="mt-2 text-xs text-gray-500 text-right">
                  {item.timestamp.toLocaleTimeString()}
                </div>
              </div>
            ))}
          </div>
        )}
      </section>
    </div>
  );
};
