/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState, FormEvent, ChangeEvent } from 'react';

interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  isOptimistic: boolean;
}

// Helper to generate unique IDs
const generateId = () => Math.random().toString(36).substr(2, 9);

// Mock Ollama API call with high latency
const mockOllamaCall = async (prompt: string): Promise<string> => {
  // Simulate 2000ms network latency
  await new Promise(resolve => setTimeout(resolve, 2000));
  return `This is a simulated response from Ollama regarding: "${prompt}"`;
};

export const OptimisticChatInterface = () => {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [isPending, setIsPending] = useState(false);

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if (!input.trim() || isPending) return;

    const userMessageId = generateId();
    const optimisticMessageId = generateId();
    const userContent = input;

    // 1. Append User Message
    const userMessage: Message = {
      id: userMessageId,
      role: 'user',
      content: userContent,
      isOptimistic: false,
    };

    // 2. Append Optimistic Assistant Message
    const optimisticMessage: Message = {
      id: optimisticMessageId,
      role: 'assistant',
      content: "Thinking about that...", // Placeholder
      isOptimistic: true,
    };

    setMessages(prev => [...prev, userMessage, optimisticMessage]);
    setInput('');
    setIsPending(true);

    try {
      // 3. Trigger Async Call
      const response = await mockOllamaCall(userContent);

      // 4. Reconciliation Logic
      setMessages(prev => prev.map(msg => {
        if (msg.id === optimisticMessageId) {
          // Replace optimistic content with real response
          return { ...msg, content: response, isOptimistic: false };
        }
        return msg;
      }));
    } catch (error) {
      // Handle error by removing the optimistic message or showing an error state
      console.error("Ollama API error:", error);
      setMessages(prev => prev.filter(msg => msg.id !== optimisticMessageId));
    } finally {
      setIsPending(false);
    }
  };

  return (
    <div style={{ padding: '20px', maxWidth: '600px', margin: '0 auto', fontFamily: 'sans-serif' }}>
      <h2>Optimistic Chat Interface</h2>
      
      <div style={{ border: '1px solid #ccc', height: '400px', overflowY: 'auto', padding: '10px', marginBottom: '10px' }}>
        {messages.map(msg => (
          <div key={msg.id} style={{ 
            marginBottom: '10px', 
            padding: '8px', 
            borderRadius: '8px',
            backgroundColor: msg.role === 'user' ? '#e3f2fd' : '#f5f5f5',
            marginLeft: msg.role === 'user' ? '20%' : '0',
            marginRight: msg.role === 'assistant' ? '20%' : '0',
            // Visual indicator for optimistic state
            border: msg.isOptimistic ? '2px dashed #ff9800' : 'none',
            opacity: msg.isOptimistic ? 0.7 : 1
          }}>
            <strong>{msg.role === 'user' ? 'You' : 'AI'}:</strong>
            <p style={{ margin: '5px 0 0 0' }}>{msg.content}</p>
          </div>
        ))}
      </div>

      <form onSubmit={handleSubmit} style={{ display: 'flex', gap: '10px' }}>
        <input
          type="text"
          value={input}
          onChange={(e: ChangeEvent<HTMLInputElement>) => setInput(e.target.value)}
          placeholder="Type a message..."
          style={{ flex: 1, padding: '8px' }}
          disabled={isPending}
        />
        <button type="submit" disabled={isPending} style={{ padding: '8px 16px' }}>
          {isPending ? 'Sending...' : 'Send'}
        </button>
      </form>
    </div>
  );
};
