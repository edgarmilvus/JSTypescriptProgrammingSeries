/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState, useRef } from 'react';
// Note: In a real project, ensure @xenova/transformers is installed and configured via Webpack/ESBuild
// import { pipeline } from '@xenova/transformers';

// Mocking the pipeline for demonstration purposes (since actual import requires bundler config)
const mockPipeline = async (task: string, model: string, options: any) => {
  // Simulate model loading delay
  await new Promise(r => setTimeout(r, 1500));
  
  return {
    // Mock inference function
    __call__: async (text: string, candidate_labels: string[]) => {
      // Simulate inference delay
      await new Promise(r => setTimeout(r, 500));
      
      // Return dummy scores
      return candidate_labels.map(label => ({
        label: label,
        score: Math.random() // Random score between 0 and 1
      })).sort((a, b) => b.score - a.score);
    }
  };
};

export const ZeroShotClassifier = () => {
  const [text, setText] = useState('');
  const [labels, setLabels] = useState('Technology, Health, Finance');
  const [results, setResults] = useState<any[]>([]);
  const [status, setStatus] = useState('');
  const [perf, setPerf] = useState({ load: 0, inference: 0 });
  
  // Using ref to cache the model instance (simplified memory management)
  const classifierRef = useRef<any>(null);

  const checkWebGPU = () => {
    return 'gpu' in navigator;
  };

  const handleClassify = async () => {
    const startTime = performance.now();
    setStatus('Loading model...');
    
    const useWebGPU = checkWebGPU();
    const device = useWebGPU ? 'WebGPU' : 'WASM/CPU';
    
    try {
      // Initialize Model (Mocked)
      if (!classifierRef.current) {
        // In real implementation: classifierRef.current = await pipeline('zero-shot-classification', 'Xenova/distilbert-base-uncased-mnli', { device });
        classifierRef.current = await mockPipeline('zero-shot-classification', 'model', { device: useWebGPU ? 'webgpu' : 'wasm' });
        const loadTime = performance.now() - startTime;
        setStatus(`Model loaded on ${device}. Load time: ${loadTime.toFixed(0)}ms`);
        setPerf(prev => ({ ...prev, load: loadTime }));
      }

      const inferenceStart = performance.now();
      setStatus('Classifying...');
      
      const labelList = labels.split(',').map(l => l.trim()).filter(l => l);
      
      // Run Inference
      // In real implementation: const output = await classifierRef.current(text, labelList);
      const output = await classifierRef.current.__call__(text, labelList);
      
      const inferenceTime = performance.now() - inferenceStart;
      
      setResults(output);
      setPerf(prev => ({ ...prev, inference: inferenceTime }));
      setStatus(`Done on ${device}. Inference: ${inferenceTime.toFixed(0)}ms`);

    } catch (error) {
      console.error(error);
      setStatus('Error running classification.');
    }
  };

  return (
    <div style={{ padding: '20px', maxWidth: '600px', margin: '0 auto' }}>
      <h3>Zero-Shot Local Classifier</h3>
      
      <div style={{ marginBottom: '10px', padding: '10px', background: '#f0f8ff', borderRadius: '4px' }}>
        <strong>Device Detected:</strong> {checkWebGPU() ? 'WebGPU (Accelerated)' : 'WASM/CPU (Fallback)'}
      </div>

      <textarea
        value={text}
        onChange={(e) => setText(e.target.value)}
        placeholder="Enter text to classify..."
        rows={3}
        style={{ width: '100%', marginBottom: '10px', padding: '8px' }}
      />
      
      <input
        value={labels}
        onChange={(e) => setLabels(e.target.value)}
        placeholder="Comma-separated labels (e.g., Tech, Health)"
        style={{ width: '100%', marginBottom: '10px', padding: '8px' }}
      />

      <button onClick={handleClassify} disabled={status.includes('Loading') || status.includes('Classifying')}>
        Classify Locally
      </button>

      <div style={{ marginTop: '20px' }}>
        <p><strong>Status:</strong> {status}</p>
        {results.length > 0 && (
          <div>
            <h4>Results:</h4>
            <ul>
              {results.map((r, i) => (
                <li key={i} style={{ marginBottom: '5px' }}>
                  <span style={{ fontWeight: 'bold' }}>{r.label}:</span> 
                  <div style={{ 
                    width: `${r.score * 100}%`, 
                    background: 'linear-gradient(90deg, #4caf50, #81c784)', 
                    height: '10px', 
                    marginTop: '2px',
                    borderRadius: '2px'
                  }}></div>
                  {(r.score * 100).toFixed(1)}%
                </li>
              ))}
            </ul>
          </div>
        )}
      </div>
    </div>
  );
};
