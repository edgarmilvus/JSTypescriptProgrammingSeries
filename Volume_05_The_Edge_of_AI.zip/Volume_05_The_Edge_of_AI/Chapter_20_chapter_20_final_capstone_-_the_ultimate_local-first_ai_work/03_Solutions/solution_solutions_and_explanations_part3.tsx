/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState } from 'react';

interface ReviewResult {
  agent: string;
  feedback: string;
  status: 'pending' | 'done' | 'error';
}

// Mock Ollama Call for a specific agent
const callAgent = async (code: string, role: string, systemPrompt: string): Promise<string> => {
  // Simulate parallel processing delay (randomized to show variance)
  const delay = Math.floor(Math.random() * 1000) + 1000; 
  await new Promise(r => setTimeout(r, delay));
  return `[${role} Review]: Based on your code, I suggest improvements regarding ${role.toLowerCase()}. System prompt used: ${systemPrompt.substring(0, 20)}...`;
};

export const CodeReviewConsensus = () => {
  const [code, setCode] = useState('function add(a, b) { return a + b; }');
  const [reviews, setReviews] = useState<ReviewResult[]>([]);
  const [consensus, setConsensus] = useState('');
  const [isReviewing, setIsReviewing] = useState(false);

  const agents = [
    { name: 'Security Agent', prompt: 'You are a security auditor. Check for vulnerabilities.' },
    { name: 'Performance Agent', prompt: 'You are a performance engineer. Check for bottlenecks.' },
    { name: 'Readability Agent', prompt: 'You are a senior dev. Check for code clarity and style.' }
  ];

  const startReview = async () => {
    setIsReviewing(true);
    setConsensus('');
    setReviews(agents.map(a => ({ agent: a.name, feedback: '', status: 'pending' })));

    try {
      // 1. Parallel Execution
      const reviewPromises = agents.map(async (agent) => {
        const feedback = await callAgent(code, agent.name, agent.prompt);
        // Update individual agent status immediately upon completion
        setReviews(prev => prev.map(r => 
          r.agent === agent.name ? { ...r, feedback, status: 'done' } : r
        ));
        return { agent: agent.name, feedback };
      });

      const results = await Promise.all(reviewPromises);

      // 2. Synthesis Step (Supervisor)
      setConsensus('Synthesizing reports...');
      const synthesisPrompt = `Create a unified report based on these reviews:\n${results.map(r => r.feedback).join('\n')}`;
      
      // Simulate Synthesis Call
      const finalReport = await callAgent(code, 'Supervisor', synthesisPrompt);
      
      // Remove the "Supervisor" prefix for cleaner display
      setConsensus(finalReport.replace('[Supervisor Review]: ', ''));

    } catch (error) {
      setConsensus('Error during consensus generation.');
    } finally {
      setIsReviewing(false);
    }
  };

  return (
    <div style={{ padding: '20px', maxWidth: '800px', margin: '0 auto' }}>
      <h3>Multi-Agent Code Review Consensus</h3>
      
      <div style={{ marginBottom: '15px' }}>
        <label style={{ display: 'block', marginBottom: '5px' }}>Code to Review:</label>
        <textarea 
          value={code} 
          onChange={(e) => setCode(e.target.value)} 
          rows={5} 
          style={{ width: '100%', fontFamily: 'monospace' }}
        />
      </div>

      <button onClick={startReview} disabled={isReviewing} style={{ padding: '8px 16px' }}>
        {isReviewing ? 'Agents Working...' : 'Request Consensus Review'}
      </button>

      <div style={{ display: 'flex', gap: '20px', marginTop: '20px' }}>
        {/* Individual Agent Panels */}
        <div style={{ flex: 1 }}>
          <h4>Individual Agents</h4>
          {reviews.map((r, i) => (
            <div key={i} style={{ 
              border: '1px solid #ddd', 
              padding: '10px', 
              marginBottom: '10px', 
              borderRadius: '4px',
              opacity: r.status === 'pending' ? 0.5 : 1 
            }}>
              <strong>{r.agent}</strong> 
              {r.status === 'pending' && <span style={{ color: 'orange', float: 'right' }}>Thinking...</span>}
              <p style={{ fontSize: '0.9em', marginTop: '5px' }}>{r.feedback || 'Waiting...'}</p>
            </div>
          ))}
        </div>

        {/* Synthesis Panel */}
        <div style={{ flex: 1, borderLeft: '2px solid #333', paddingLeft: '20px' }}>
          <h4>Supervisor Consensus</h4>
          {consensus ? (
            <div style={{ background: '#e8f5e9', padding: '15px', borderRadius: '4px' }}>
              {consensus}
            </div>
          ) : (
            <p style={{ color: '#666' }}>Waiting for agents to complete...</p>
          )}
        </div>
      </div>
    </div>
  );
};
