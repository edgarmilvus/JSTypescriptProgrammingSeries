/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

// ModelManager.ts

interface CachedModel {
  instance: any; // The actual model object
  lastAccessed: number;
}

export class ModelManager {
  private cache: Map<string, CachedModel>;
  private maxModels: number;

  constructor(maxModels: number = 3) {
    this.cache = new Map();
    this.maxModels = maxModels;
  }

  // Helper to simulate model disposal
  private async disposeModel(modelName: string): Promise<void> {
    const model = this.cache.get(modelName);
    if (model && model.instance && typeof model.instance.dispose === 'function') {
      // In real Transformers.js: await model.instance.dispose();
      console.log(`[Memory] Disposing model: ${modelName}`);
    }
    this.cache.delete(modelName);
  }

  // Main method to get a model
  async getModel(modelName: string): Promise<any> {
    const now = Date.now();

    if (this.cache.has(modelName)) {
      // Model exists: Update timestamp (LRU hit)
      const entry = this.cache.get(modelName)!;
      entry.lastAccessed = now;
      // Re-set the entry to update position in Map (though Map preserves insertion order, 
      // we usually track order explicitly or use a LinkedHashMap. 
      // For JS Map, we delete and re-insert to simulate "move to end" for LRU logic if iterating keys).
      this.cache.delete(modelName);
      this.cache.set(modelName, entry);
      
      console.log(`[Memory] Loaded ${modelName} from cache.`);
      return entry.instance;
    }

    // Model does not exist: Load it
    console.log(`[Memory] Loading ${modelName} from source...`);
    
    // SIMULATION: Replace this with actual model loading logic
    const instance = await this.loadModelInstance(modelName);

    // Check capacity and evict LRU if needed
    if (this.cache.size >= this.maxModels) {
      const lruKey = this.getLRUKey();
      if (lruKey) {
        await this.disposeModel(lruKey);
      }
    }

    // Add to cache
    this.cache.set(modelName, { instance, lastAccessed: now });
    return instance;
  }

  // Simulated model loader
  private async loadModelInstance(name: string): Promise<any> {
    return new Promise(resolve => setTimeout(() => resolve({ name, dispose: () => console.log(`Disposed ${name}`) }), 100));
  }

  // Find the least recently used key
  private getLRUKey(): string | null {
    let lruKey: string | null = null;
    let minTime = Infinity;

    for (const [key, value] of this.cache.entries()) {
      if (value.lastAccessed < minTime) {
        minTime = value.lastAccessed;
        lruKey = key;
      }
    }
    return lruKey;
  }

  // Public method to force cleanup (e.g., on component unmount)
  async disposeAll(): Promise<void> {
    const keys = Array.from(this.cache.keys());
    for (const key of keys) {
      await this.disposeModel(key);
    }
  }
}

// React Context Integration Example (Snippet)
import React, { createContext, useContext } from 'react';

const ModelContext = createContext<ModelManager | null>(null);

export const ModelProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const manager = new ModelManager(2); // Limit cache to 2 models
  
  return (
    <ModelContext.Provider value={manager}>
      {children}
    </ModelContext.Provider>
  );
};

export const useModelManager = () => {
  const ctx = useContext(ModelContext);
  if (!ctx) throw new Error('useModelManager must be used within ModelProvider');
  return ctx;
};
