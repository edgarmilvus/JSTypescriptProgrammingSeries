/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.tsx
// Description: Solutions and Explanations
// ==========================================

// TaskRouter.ts

interface RoutingDecision {
  target: 'browser' | 'server';
  model: string;
  reason: string;
}

export class TaskRouter {
  private hasWebGPU: boolean;
  private deviceSpeedScore: number = 0; // 0 to 100 (100 is fast)

  constructor() {
    this.hasWebGPU = 'gpu' in navigator;
    this.estimateDeviceSpeed();
  }

  // Benchmark device capability (simplified)
  private async estimateDeviceSpeed() {
    if (!this.hasWebGPU) {
      this.deviceSpeedScore = 10; // Low score for CPU/WASM
      return;
    }
    // Simulate a micro-benchmark
    const start = performance.now();
    // A tiny operation to check overhead
    for(let i=0; i<1000; i++) Math.sqrt(i); 
    const end = performance.now();
    
    // Inverse relationship: lower time = higher score
    this.deviceSpeedScore = Math.max(10, 100 - (end * 10)); 
  }

  async route(taskType: string, input: any): Promise<RoutingDecision> {
    // Ensure speed score is ready
    if (this.deviceSpeedScore === 0) await this.estimateDeviceSpeed();

    // Rule 1: Fallback for unsupported hardware
    if (!this.hasWebGPU) {
      return {
        target: 'server',
        model: 'ollama:generic',
        reason: 'WebGPU not supported'
      };
    }

    // Rule 2: Heavyweight tasks always go to server
    // Example: Code generation or long context summarization
    if (taskType === 'code_generation' && input.length > 300) {
      return {
        target: 'server',
        model: 'ollama:codellama',
        reason: 'Task too heavy for browser'
      };
    }

    // Rule 3: Lightweight tasks to browser (WebGPU)
    // Example: Sentiment Analysis, Short Summarization
    if (taskType === 'sentiment' || taskType === 'short_summarize') {
      return {
        target: 'browser',
        model: 'transformers.js:distilbert',
        reason: 'Lightweight task, WebGPU available'
      };
    }

    // Default fallback
    return {
      target: 'server',
      model: 'ollama:default',
      reason: 'Default routing'
    };
  }
}

// --- Interactive Challenge Component: SmartTextArea ---

import React, { useState, useEffect, useRef } from 'react';

export const SmartTextArea = () => {
  const [input, setInput] = useState('');
  const [output, setOutput] = useState('');
  const [routeInfo, setRouteInfo] = useState<RoutingDecision | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  
  const router = useRef(new TaskRouter()).current;
  const timeoutRef = useRef<NodeJS.Timeout>();

  // Debounce logic
  useEffect(() => {
    if (timeoutRef.current) clearTimeout(timeoutRef.current);

    if (input.length > 0) {
      timeoutRef.current = setTimeout(() => {
        processInput(input);
      }, 500); // 500ms pause
    } else {
      setOutput('');
    }

    return () => { if (timeoutRef.current) clearTimeout(timeoutRef.current); };
  }, [input]);

  const processInput = async (text: string) => {
    setIsProcessing(true);
    
    // Determine routing
    const taskType = text.length < 50 ? 'short_summarize' : 'code_generation';
    const decision = await router.route(taskType, text);
    setRouteInfo(decision);

    // Simulate Processing
    let result = '';
    if (decision.target === 'browser') {
      // Simulate fast local inference
      await new Promise(r => setTimeout(r, 300));
      result = `[Local Browser]: Summary of "${text.substring(0, 20)}..."`;
    } else {
      // Simulate slower server roundtrip
      await new Promise(r => setTimeout(r, 1200));
      result = `[Ollama Server]: Detailed analysis of "${text.substring(0, 20)}..."`;
    }
    
    setOutput(result);
    setIsProcessing(false);
  };

  return (
    <div style={{ padding: '20px', maxWidth: '600px', margin: '0 auto', fontFamily: 'sans-serif' }}>
      <h3>Smart Hybrid TextArea</h3>
      <p style={{ fontSize: '0.9em', color: '#666' }}>
        Type a short sentence (local) or long paragraph (server). Wait 500ms after typing.
      </p>
      
      <textarea
        value={input}
        onChange={(e) => setInput(e.target.value)}
        placeholder="Start typing..."
        rows={4}
        style={{ width: '100%', padding: '10px', fontSize: '1em' }}
      />

      <div style={{ marginTop: '15px', minHeight: '60px', padding: '10px', background: '#f9f9f9', borderRadius: '4px' }}>
        {isProcessing ? (
          <em>Processing...</em>
        ) : output ? (
          <div>
            <div style={{ fontWeight: 'bold', marginBottom: '5px' }}>{output}</div>
            {routeInfo && (
              <div style={{ fontSize: '0.8em', color: '#555', display: 'flex', alignItems: 'center', gap: '5px' }}>
                <span style={{ 
                  padding: '2px 6px', 
                  borderRadius: '4px', 
                  background: routeInfo.target === 'browser' ? '#e3f2fd' : '#fff3e0',
                  color: routeInfo.target === 'browser' ? '#1565c0' : '#ef6c00',
                  fontWeight: 'bold'
                }}>
                  {routeInfo.target.toUpperCase()}
                </span>
                <span>Reason: {routeInfo.reason}</span>
              </div>
            )}
          </div>
        ) : null}
      </div>
    </div>
  );
};
