/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// FILE: lib/ai-document-processor.ts
// REQUIRES: @supabase/supabase-js, openai, pgvector (in DB)

import { createClient, SupabaseClient } from '@supabase/supabase-js';
import OpenAI from 'openai';

// ============================================================================
// 1. CONFIGURATION & TYPES
// ============================================================================

// Type definition for the document chunk stored in the database.
// We store the original text, the embedding vector, and a reference ID.
type DocumentChunk = {
  id: string;
  content: string;
  embedding: number[];
  metadata?: Record<string, any>;
};

// Environment variable validation (Critical for SaaS security)
const SUPABASE_URL = process.env.NEXT_PUBLIC_SUPABASE_URL!;
const SUPABASE_SERVICE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY!;
const OPENAI_API_KEY = process.env.OPENAI_API_KEY!;

// Initialize Clients
const openai = new OpenAI({ apiKey: OPENAI_API_KEY });
const supabase: SupabaseClient = createClient(SUPABASE_URL, SUPABASE_SERVICE_KEY);

// ============================================================================
// 2. LOGIC BLOCKS
// ============================================================================

/**
 * Generates vector embeddings for a given text string using OpenAI.
 * 
 * Why: Text cannot be compared mathematically in its raw string form. 
 * We convert semantic meaning into a vector space (a list of floating point numbers)
 * where 'closeness' implies semantic similarity.
 * 
 * @param text - The text to vectorize.
 * @returns A Promise resolving to an array of numbers (the embedding).
 */
async function generateEmbedding(text: string): Promise<number[]> {
  try {
    const response = await openai.embeddings.create({
      model: 'text-embedding-3-small', // Efficient model for production SaaS
      input: text,
      dimensions: 1536 // Standard dimension for this model
    });

    return response.data[0].embedding;
  } catch (error) {
    console.error("Error generating embedding:", error);
    throw new Error("Failed to generate vector embedding via OpenAI.");
  }
}

/**
 * Ingests a raw document, chunks it, and stores it in Supabase.
 * 
 * Why: LLMs have context limits. Storing a whole book as one vector is imprecise.
 * We split text into logical chunks (sentences/paragraphs) to maintain semantic precision.
 * 
 * How:
 * 1. Splits text by double newlines (approximate paragraph split).
 * 2. Generates an embedding for EACH chunk.
 * 3. Inserts chunks and embeddings into 'documents' table in Supabase.
 * 
 * @param rawText - The content of the document.
 * @param docId - Unique identifier for the document.
 */
export async function processAndStoreDocument(rawText: string, docId: string) {
  // Step A: Chunking Logic (Simplified for boilerplate)
  // In production, use recursive splitting or semantic splitting.
  const chunks = rawText.split(/\n\n+/).filter((c) => c.trim().length > 0);

  console.log(`Processing ${chunks.length} chunks for document ${docId}...`);

  // Step B: Parallel Embedding Generation
  // We use Promise.all to optimize latency. In a serverless function, watch for timeouts.
  const processingPromises = chunks.map(async (chunkText, index) => {
    const embedding = await generateEmbedding(chunkText);
    
    return {
      content: chunkText,
      embedding: embedding,
      doc_id: docId,
      chunk_index: index
    };
  });

  const documentsToInsert = await Promise.all(processingPromises);

  // Step C: Database Insertion (Vector Storage)
  // The table 'documents' must have a column 'embedding' of type 'vector(1536)'
  const { error } = await supabase
    .from('documents')
    .insert(documentsToInsert);

  if (error) {
    console.error("Supabase Insert Error:", error);
    throw new Error("Failed to store document chunks in database.");
  }

  console.log("✅ Document successfully indexed.");
}

/**
 * Performs a semantic search against the vector database.
 * 
 * Why: Keyword search fails on synonyms and conceptual queries. 
 * Vector search finds results based on meaning, not just matching words.
 * 
 * Under the Hood:
 * Uses the '<=>' operator (cosine distance) provided by pgvector.
 * 0 distance means identical meaning, 1 means completely different.
 * 
 * @param query - The user's natural language question.
 * @param matchThreshold - Minimum similarity score (0.0 - 1.0).
 * @returns The top matching text chunks.
 */
export async function semanticSearch(query: string, matchThreshold: number = 0.7) {
  // 1. Convert the query to a vector
  const queryEmbedding = await generateEmbedding(query);

  // 2. Perform Vector Search in Supabase
  // We select the content and a calculated 'similarity' score.
  // The 'rpc' (Remote Procedure Call) or direct SQL is often used for vector ops,
  // but here we assume a standard query using the embedding column.
  const { data: matches, error } = await supabase
    .rpc('match_documents', { // Assuming a Postgres function is created for cleaner queries
      query_embedding: queryEmbedding,
      match_threshold: matchThreshold,
      match_count: 3 // Limit to top 3 results
    });

  if (error) {
    console.error("Search Error:", error);
    return [];
  }

  return matches; // Returns [{ content, similarity }, ...]
}

/**
 * Orchestrator: Search + LLM Synthesis (RAG Pattern)
 * 
 * This represents the "AI-Native" workflow:
 * 1. Retrieve relevant context (Vector Search).
 * 2. Inject context into System Prompt.
 * 3. Call LLM to generate an answer based strictly on the retrieved context.
 */
export async function askQuestionWithContext(userQuestion: string) {
  console.log(`\n🤔 User Query: "${userQuestion}"`);

  // 1. Retrieve Context
  const contextDocs = await semanticSearch(userQuestion);
  
  if (contextDocs.length === 0) {
    return "I couldn't find any relevant information in the database for your query.";
  }

  // 2. Format Context for the LLM
  const contextText = contextDocs
    .map((doc: any) => `Source: [Chunk ${doc.chunk_index}]\n${doc.content}`)
    .join('\n\n---\n\n');

  console.log(`\n🔍 Retrieved Context:\n${contextText}`);

  // 3. Call OpenAI Chat Completions with the retrieved context
  const completion = await openai.chat.completions.create({
    model: 'gpt-4-turbo-preview',
    messages: [
      {
        role: 'system',
        content: `You are a helpful assistant. Answer the question based EXCLUSIVELY on the provided context. If the context doesn't contain the answer, say "I don't have that information".`
      },
      {
        role: 'user',
        content: `Context:\n${contextText}\n\nQuestion: ${userQuestion}`
      }
    ],
    temperature: 0.2 // Low temp for factual consistency
  });

  return completion.choices[0].message.content;
}

// ============================================================================
// 3. USAGE EXAMPLE (Mock Execution)
// ============================================================================

/*
// Example Usage:
const rawDocument = `
  The Quick Brown Fox jumps over the lazy dog.
  Artificial Intelligence is transforming SaaS products.
  WebAssembly allows near-native performance in the browser.
  Supabase provides a Postgres database with vector support.
`;

// 1. Index Data
// await processAndStoreDocument(rawDocument, 'doc-tech-001');

// 2. Query Data
// const answer = await askQuestionWithContext("How can we speed up web apps?");
// console.log("\n🤖 AI Answer:", answer);
*/
