/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// File: app/api/documents/upload/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { createClient } from '@supabase/supabase-js';
import OpenAI from 'openai';

// Initialize clients (ensure env variables are set)
const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY! // Use service role for server-side operations
);
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

// Helper: Generate embeddings
async function getEmbedding(text: string): Promise<number[]> {
  try {
    const response = await openai.embeddings.create({
      model: 'text-embedding-ada-002',
      input: text.replace(/\n/g, ' '), // Replace newlines to optimize for tokenization
    });
    return response.data[0].embedding;
  } catch (error) {
    console.error('Error generating embedding:', error);
    throw new Error('Failed to generate embedding');
  }
}

// Helper: Simple text chunking
function chunkText(text: string, chunkSize: number = 500, overlap: number = 50): string[] {
  const chunks: string[] = [];
  let start = 0;
  
  while (start < text.length) {
    let end = start + chunkSize;
    // If we are near the end, just take the rest of the text
    if (end > text.length) {
      end = text.length;
    } else {
      // Try to find a space near the end to avoid splitting words
      const lastSpace = text.lastIndexOf(' ', end);
      if (lastSpace > start) {
        end = lastSpace;
      }
    }
    
    chunks.push(text.slice(start, end));
    start = end - overlap; // Move start forward by chunk size minus overlap
    if (start < 0) start = 0; // Prevent negative start
    if (start >= end) break; // Prevent infinite loop
  }
  
  return chunks;
}

export async function POST(request: NextRequest) {
  // 1. Authentication Check
  const { data: { user } } = await supabase.auth.getUser(request);
  if (!user) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  const formData = await request.formData();
  const file = formData.get('file') as File;
  
  if (!file) {
    return NextResponse.json({ error: 'No file uploaded' }, { status: 400 });
  }

  try {
    // 2. Text Extraction (Simulated for .txt files)
    const text = await file.text();
    
    // 3. Chunking
    const chunks = chunkText(text);
    
    // 4. Vectorization & Storage Loop
    // Note: In a real app, use a background job (e.g., Vercel Cron, Inngest) for large files
    for (let i = 0; i < chunks.length; i++) {
      const chunk = chunks[i];
      
      // Generate embedding
      const embedding = await getEmbedding(chunk);
      
      // Insert into Supabase
      const { error } = await supabase.from('document_chunks').insert({
        content: chunk,
        embedding: embedding,
        user_id: user.id,
        document_id: 'simulated-doc-id', // In real app, create a 'documents' entry first
      });

      if (error) throw error;
      
      // Log progress (simulating real-time feedback)
      const progress = Math.round(((i + 1) / chunks.length) * 100);
      console.log(`Processing chunk ${i + 1}/${chunks.length}: ${progress}%`);
    }

    return NextResponse.json({ 
      success: true, 
      chunksCreated: chunks.length,
      message: 'Document processed successfully' 
    });

  } catch (error) {
    console.error('Processing error:', error);
    return NextResponse.json({ error: 'Failed to process document' }, { status: 500 });
  }
}
