/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

// File: hooks/useAIStream.ts
import { useState, useRef, useEffect } from 'react';

export const useAIStream = (endpoint: string) => {
  const [fullResponse, setFullResponse] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  
  // Ref to store the EventSource instance
  const eventSourceRef = useRef<EventSource | null>(null);

  const stopGeneration = () => {
    if (eventSourceRef.current) {
      eventSourceRef.current.close();
      eventSourceRef.current = null;
      setIsLoading(false);
    }
  };

  const sendMessage = async (message: string) => {
    // Reset state
    setFullResponse('');
    setError(null);
    setIsLoading(true);

    // Close any existing connection
    stopGeneration();

    // Create new connection
    const es = new EventSource(`${endpoint}?message=${encodeURIComponent(message)}`);
    eventSourceRef.current = es;

    es.onmessage = (event) => {
      setFullResponse((prev) => prev + event.data);
    };

    es.onerror = () => {
      setError('Stream interrupted or failed.');
      stopGeneration();
      es.close();
    };

    // Note: We assume the stream closes naturally. 
    // For a POST request via EventSource (which is usually GET), 
    // a common pattern is using a Fetch stream reader, but SSE via GET is standard for simple streams.
    // However, to strictly follow the "POST" route defined above, we might use Fetch with a reader.
    // BUT, the prompt specifically asked for `EventSource`. 
    // EventSource only supports GET. To use the POST route, we'd typically use `fetch` + `Response.body.getReader()`.
    // Below is the `fetch` implementation which aligns better with the POST route defined above.
  };
  
  // Re-implementing sendMessage to strictly support the POST route defined in step 1
  const sendMessagePost = async (message: string) => {
    setFullResponse('');
    setError(null);
    setIsLoading(true);
    
    try {
      const response = await fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message }),
      });

      if (!response.ok) throw new Error('Network response was not ok');

      const reader = response.body!.getReader();
      const decoder = new TextDecoder();

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        const chunk = decoder.decode(value, { stream: true });
        setFullResponse((prev) => prev + chunk);
      }
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Unknown error');
    } finally {
      setIsLoading(false);
    }
  };

  // Return the POST version for the defined API route
  return { fullResponse, isLoading, error, sendMessage: sendMessagePost, stopGeneration };
};
