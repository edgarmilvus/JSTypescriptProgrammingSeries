/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part6.ts
// Description: Solutions and Explanations
// ==========================================

// File: app/api/search/route.ts
import { NextRequest, NextResponse } from 'next/server';
import OpenAI from 'openai';
import { createClient } from '@supabase/supabase-js';

const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
);

export async function POST(request: NextRequest) {
  // Auth Check
  const { data: { user } } = await supabase.auth.getUser(request);
  if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  const { query, maxResults = 3 } = await request.json();

  try {
    // 1. Generate Embedding for Query
    const response = await openai.embeddings.create({
      model: 'text-embedding-ada-002',
      input: query,
    });
    const embedding = response.data[0].embedding;

    // 2. Perform Vector Similarity Search (Cosine Distance)
    // Note: Ensure pgvector extension is enabled in Supabase
    const { data: chunks, error } = await supabase
      .rpc('match_document_chunks', { // Assuming a Postgres function is created for matching
        query_embedding: embedding,
        match_count: maxResults,
        user_id: user.id // Pass user_id for RLS/security
      });
    
    // Alternative raw SQL if function isn't set up:
    /*
    const { data: chunks, error } = await supabase
      .from('document_chunks')
      .select('content')
      .eq('user_id', user.id)
      .order('embedding <-> ' + JSON.stringify(embedding), { ascending: true })
      .limit(maxResults);
    */

    if (error) throw error;

    return NextResponse.json({ results: chunks || [] });
  } catch (error) {
    console.error('Search error:', error);
    return NextResponse.json({ error: 'Search failed' }, { status: 500 });
  }
}
