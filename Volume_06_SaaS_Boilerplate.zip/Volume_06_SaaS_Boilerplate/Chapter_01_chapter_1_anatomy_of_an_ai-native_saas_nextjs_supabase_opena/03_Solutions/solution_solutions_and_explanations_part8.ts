/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part8.ts
// Description: Solutions and Explanations
// ==========================================

digraph Architecture {
    rankdir=TB;
    splines=ortho;
    node [shape=box, style=filled, fillcolor="#f0f0f0", fontname="Helvetica"];

    // Define Subgraphs for logical grouping
    subgraph cluster_client {
        label="Client Environment";
        style=dashed;
        fillcolor="#e6f3ff";
        Client [shape=ellipse, fillcolor="#cce5ff", label="User Browser (Next.js Frontend)"];
    }

    subgraph cluster_backend {
        label="Server Environment";
        style=dashed;
        fillcolor="#fff0e6";
        NextJS [shape=cylinder, fillcolor="#ffdb99", label="Next.js Backend (API Routes)"];
    }

    subgraph cluster_external {
        label="External Services";
        style=dashed;
        fillcolor="#e6ffe6";
        OpenAI [shape=component, fillcolor="#d9ed92", label="OpenAI API\n(Embeddings & Chat)"];
        Stripe [shape=component, fillcolor="#d9ed92", label="Stripe API\n(Payments & Webhooks)"];
    }

    subgraph cluster_infra {
        label="Infrastructure";
        style=dashed;
        fillcolor="#f9e6ff";
        Supabase [shape=database, fillcolor="#e6ccff", label="Supabase\n(PostgreSQL + pgvector + Auth)"];
    }

    // Security Layer Node
    Security [shape=note, fillcolor="#ffcccc", label="Security Layer\n(JWT Validation, Stripe Signature Check)"];

    // Connections & Flows
    
    // 1. Document Upload Flow
    Client -> NextJS [label="1. Upload Document\n& Trigger Processing"];
    NextJS -> OpenAI [label="2. Request Embeddings"];
    NextJS -> Supabase [label="3. Store Vectors\n(document_chunks table)"];
    
    // 2. Payment Flow
    Client -> NextJS [label="4. Select Plan & Create Session"];
    NextJS -> Stripe [label="5. Redirect to Checkout"];
    Stripe -> NextJS [label="6. Webhook: Payment Success"];
    
    // 3. Chat/Stream Flow
    Client -> NextJS [label="7. Send Chat Message"];
    NextJS <-> OpenAI [label="8. Stream Tokens (SSE)"];

    // 4. Search Flow
    Client -> NextJS [label="9. Semantic Query"];
    NextJS -> Supabase [label="10. Vector Similarity Search"];

    // Security Connections (Visualizing the protection)
    Security -> Client [style=dotted, label="Protects"];
    Security -> NextJS [style=dotted, label="Protects"];
    
    // Specific Security Constraints
    Client -> NextJS [label="Auth Check (JWT)", style=dashed, color=red, penwidth=2];
    Stripe -> NextJS [label="Verify Signature", style=dashed, color=red, penwidth=2];

    // Ensure layout ordering
    { rank = same; Client; }
    { rank = same; NextJS; }
    { rank = same; Supabase; OpenAI; Stripe; }
}
