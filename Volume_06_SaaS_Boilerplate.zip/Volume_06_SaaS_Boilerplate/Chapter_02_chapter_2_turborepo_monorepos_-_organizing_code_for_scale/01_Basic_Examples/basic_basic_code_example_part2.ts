/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.ts
// Description: Basic Code Example
// ==========================================

/**
 * @file apps/api/src/routes/login.ts
 * @description Mock login route using shared types.
 */

// Import types from the local monorepo package
// In a real TurboRepo setup, this is mapped via tsconfig.json or package.json workspaces
import { LoginResponse, User, isUser } from "@repo/auth-types";

/**
 * Simulates a database fetch and login process.
 * 
 * @returns {Promise<LoginResponse>} The login response payload.
 */
async function handleLogin(): Promise<LoginResponse> {
  // 1. Mock database user record
  const dbRecord = {
    id: "usr_123456",
    email: "developer@example.com",
    avatarUrl: "https://avatar.com/dev.png",
    createdAt: new Date(),
  };

  // 2. Type Inference in Action
  // TypeScript infers 'dbRecord' matches the 'User' type structure automatically.
  // However, we can use our runtime guard for extra safety if the data comes from an external source.
  if (!isUser(dbRecord)) {
    throw new Error("Invalid user data structure from database.");
  }

  // 3. Construct the typed response
  const response: LoginResponse = {
    user: dbRecord, // Type-safe assignment
    token: "jwt_xyz_abc",
    expiresIn: 3600,
  };

  return response;
}

// Export the handler for the API server
export { handleLogin };
