/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example_part3.tsx
// Description: Basic Code Example
// ==========================================

/**
 * @file apps/web/src/components/UserProfile.tsx
 * @description A React component displaying user data using shared types.
 */

import { useState, useEffect } from "react";
import { User, LoginResponse } from "@repo/auth-types";

export function UserProfile() {
  // 1. State initialization with strict typing
  // Type Inference automatically sets the initial state to 'null' as User | null
  const [user, setUser] = useState<User | null>(null);

  useEffect(() => {
    async function fetchUser() {
      // Simulate an API call to the backend
      const res = await fetch("/api/login");
      const data: LoginResponse = await res.json();

      // 2. Type Safety
      // We can access 'data.user.email' directly without checking if 'user' exists
      // because 'LoginResponse' guarantees it.
      setUser(data.user);
    }
    fetchUser();
  }, []);

  if (!user) {
    return <div>Loading...</div>;
  }

  // 3. Rendering
  // TypeScript knows 'user' is not null here due to the check above.
  return (
    <div>
      <h1>Welcome, {user.email}</h1>
      {user.avatarUrl && <img src={user.avatarUrl} alt="Avatar" />}
      <p>Member since: {user.createdAt.toDateString()}</p>
    </div>
  );
}
