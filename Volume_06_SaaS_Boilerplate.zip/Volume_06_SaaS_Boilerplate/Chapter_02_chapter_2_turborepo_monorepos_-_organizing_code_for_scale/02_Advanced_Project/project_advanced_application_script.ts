/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

/**
 * packages/ai-orchestrator/src/job-orchestrator.ts
 * 
 * A robust, type-safe job processing module designed for a TurboRepo SaaS.
 * Handles AI inference tasks with strict runtime type validation.
 */

// ============================================================================
// 1. SHARED TYPES & GENERICS
// ============================================================================

/**
 * Represents the distinct types of AI models supported by our SaaS.
 * In a monorepo, this enum is imported by both the frontend (for UI logic)
 * and the backend (for routing logic).
 */
export enum AIModelType {
  IMAGE_GENERATION = 'image_generation',
  TEXT_SUMMARIZATION = 'text_summarization',
  AUDIO_TRANSCRIPTION = 'audio_transcription',
}

/**
 * The core Generic interface for any AI Job.
 * 
 * Why Generics? 
 * By using <T extends AIModelType>, we link the 'type' property to the 
 * specific shapes of 'input' and 'output'. This prevents a developer from
 * passing a string prompt to an image generation model expecting a file buffer.
 */
export interface AIJob<T extends AIModelType> {
  id: string;
  type: T;
  input: T extends AIModelType.IMAGE_GENERATION 
    ? { prompt: string; dimensions: { w: number; h: number } }
    : T extends AIModelType.TEXT_SUMMARIZATION
    ? { text: string; maxLength: number }
    : T extends AIModelType.AUDIO_TRANSCRIPTION
    ? { audioUrl: string; language: string }
    : never;
  status: 'pending' | 'processing' | 'completed' | 'failed';
}

/**
 * The Generic Result interface.
 * Mirrors the input generic to ensure the output matches the input type.
 */
export interface AIResult<T extends AIModelType> {
  jobId: string;
  success: boolean;
  output: T extends AIModelType.IMAGE_GENERATION
    ? { imageUrl: string; seed: number }
    : T extends AIModelType.TEXT_SUMMARIZATION
    ? { summary: string; wordCount: number }
    : T extends AIModelType.AUDIO_TRANSCRIPTION
    ? { transcript: string; duration: number }
    : never;
  error?: string;
}

// ============================================================================
// 2. TYPE GUARDS (RUNTIME SAFETY)
// ============================================================================

/**
 * User-Defined Type Guard for Image Generation Results.
 * 
 * How it works:
 * The return type `result is AIResult<AIModelType.IMAGE_GENERATION>` tells
 * the TypeScript compiler: "If this function returns true, the variable
 * passed in is strictly an Image Result."
 * 
 * Why needed? 
 * Even with Generics, runtime data (e.g., from an API or WASM thread)
 * arrives as 'unknown'. We must narrow the type before accessing properties
 * like `.seed` or `.imageUrl`.
 */
function isImageResult(
  result: AIResult<AIModelType>
): result is AIResult<AIModelType.IMAGE_GENERATION> {
  return (
    result.success &&
    typeof (result.output as any).imageUrl === 'string' &&
    typeof (result.output as any).seed === 'number'
  );
}

/**
 * Type Guard for Text Summarization Results.
 */
function isTextResult(
  result: AIResult<AIModelType>
): result is AIResult<AIModelType.TEXT_SUMMARIZATION> {
  return (
    result.success &&
    typeof (result.output as any).summary === 'string' &&
    typeof (result.output as any).wordCount === 'number'
  );
}

// ============================================================================
// 3. THE ORCHESTRATOR LOGIC
// ============================================================================

/**
 * Simulates the heavy lifting of AI inference.
 * In a real TurboRepo setup, this function would act as the bridge
 * to a WASM Thread pool.
 * 
 * @param job - The generic job input
 * @returns A Promise resolving to the specific result type
 */
async function executeInference<T extends AIModelType>(
  job: AIJob<T>
): Promise<AIResult<T>> {
  // SIMULATION: In a real app, we would post a message to a Web Worker
  // or invoke a WASM module here.
  console.log(`[WASM Thread] Processing ${job.type}...`);

  // Simulate async delay for computation
  await new Promise((r) => setTimeout(r, 100));

  // Mock logic based on type
  if (job.type === AIModelType.IMAGE_GENERATION) {
    return {
      jobId: job.id,
      success: true,
      output: {
        imageUrl: `https://saas-cdn.com/gen/${job.id}.png`,
        seed: Math.floor(Math.random() * 1000),
      },
    } as AIResult<T>;
  }

  if (job.type === AIModelType.TEXT_SUMMARIZATION) {
    return {
      jobId: job.id,
      success: true,
      output: {
        summary: `[Summary of: ${job.input.text.substring(0, 20)}...]`,
        wordCount: job.input.text.split(' ').length,
      },
    } as AIResult<T>;
  }

  // Fallback for unknown types
  throw new Error(`Unsupported model type: ${job.type}`);
}

/**
 * The main entry point for the orchestrator.
 * Accepts a generic job, processes it, and routes the result
 * based on the validated type.
 */
export async function processJob<T extends AIModelType>(
  job: AIJob<T>
): Promise<void> {
  try {
    // 1. Update status to processing (Database write would happen here)
    console.log(`Job ${job.id} started.`);

    // 2. Execute the heavy computation
    const result = await executeInference(job);

    // 3. ROUTING LOGIC using Type Guards
    // This is where the monorepo logic shines: handling different
    // data shapes in a type-safe manner without casting.
    
    if (isImageResult(result)) {
      // TypeScript now knows 'result.output' has 'imageUrl' and 'seed'
      console.log(
        `✅ Image Generated: ${result.output.imageUrl} (Seed: ${result.output.seed})`
      );
      // Logic: Upload to S3, update DB record with image_url
    } 
    else if (isTextResult(result)) {
      // TypeScript now knows 'result.output' has 'summary' and 'wordCount'
      console.log(
        `✅ Text Summarized: ${result.output.wordCount} words -> ${result.output.summary}`
      );
      // Logic: Save summary to vector database for RAG context
    } 
    else {
      // Exhaustiveness check
      console.error('❌ Received a valid result but type could not be narrowed.');
    }

  } catch (error) {
    console.error(`❌ Job ${job.id} failed:`, error);
    // Logic: Update DB status to 'failed', alert Sentry
  }
}

// ============================================================================
// 4. USAGE EXAMPLE (Simulating Main Execution)
// ============================================================================

/**
 * Demonstrates the usage within the SaaS application context.
 */
async function main() {
  // Example 1: Image Generation Job
  const imageJob: AIJob<AIModelType.IMAGE_GENERATION> = {
    id: 'job_img_001',
    type: AIModelType.IMAGE_GENERATION,
    input: { prompt: 'A cyberpunk city', dimensions: { w: 1024, h: 1024 } },
    status: 'pending',
  };

  // Example 2: Text Summarization Job
  const textJob: AIJob<AIModelType.TEXT_SUMMARIZATION> = {
    id: 'job_txt_001',
    type: AIModelType.TEXT_SUMMARIZATION,
    input: { 
      text: 'TypeScript is a typed superset of JavaScript that compiles to plain JavaScript.', 
      maxLength: 10 
    },
    status: 'pending',
  };

  // Process both jobs
  await processJob(imageJob);
  await processJob(textJob);
}

// Execute if running directly
if (require.main === module) {
  main();
}
