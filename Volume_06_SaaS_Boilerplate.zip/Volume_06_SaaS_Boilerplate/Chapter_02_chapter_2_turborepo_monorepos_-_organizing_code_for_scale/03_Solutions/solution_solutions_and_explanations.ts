/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// packages/types/src/index.ts
export interface User {
  id: string;
  email: string;
  role: 'admin' | 'user';
  createdAt: Date;
  metadata?: Record<string, any>;
}

// packages/auth/src/utils/sanitizeUser.ts (assuming 'auth' is the backend package)
import { User } from '@boilerplate/types';

/**
 * Sanitizes a User object for client-side consumption.
 * Removes sensitive internal fields (if any) and ensures the data structure
 * matches what the frontend expects.
 */
export function sanitizeUserForClient(user: User): Omit<User, 'metadata'> {
  // Destructure to remove 'metadata' (assuming it's sensitive or large)
  // and return the remaining properties.
  // In a real scenario, you might also scrub PII or internal flags.
  const { metadata, ...safeUser } = user;
  return safeUser;
}
