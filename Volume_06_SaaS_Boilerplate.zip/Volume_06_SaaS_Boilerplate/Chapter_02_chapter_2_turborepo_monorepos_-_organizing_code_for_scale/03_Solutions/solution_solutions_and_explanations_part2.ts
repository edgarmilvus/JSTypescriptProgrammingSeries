/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

// packages/types/src/api.ts

export interface SuccessResponse<T> {
  status: 'success';
  data: T;
}

export interface ErrorResponse {
  status: 'error';
  message: string;
  code: number;
}

export type ApiResponse<T> = SuccessResponse<T> | ErrorResponse;

// Type guard function
export function isSuccessResponse<T>(response: ApiResponse<T>): response is SuccessResponse<T> {
  return response.status === 'success';
}

// Usage demonstration
export function processApiResponse(response: ApiResponse<string>): string {
  // Using the type guard for control flow analysis
  if (isSuccessResponse(response)) {
    // TypeScript now knows 'response' is SuccessResponse<string>
    // so 'data' is accessible and typed as string
    return `Data received: ${response.data}`;
  } else {
    // TypeScript knows 'response' is ErrorResponse here
    return `Error ${response.code}: ${response.message}`;
  }
}

// Explanation comment:
// A type guard is necessary because TypeScript's control flow analysis 
// narrows types based on property equality checks only when the check 
// is performed on a discriminant property directly within the scope 
// of the check. While `if (response.status === 'success')` often works 
// for simple unions, user-defined type guards (`response is SuccessResponse<T>`)
// provide explicit, reusable logic for complex runtime checks (e.g., 
// checking nested properties or validating data shapes) that the 
// compiler cannot infer on its own. It guarantees type safety across 
// module boundaries.
