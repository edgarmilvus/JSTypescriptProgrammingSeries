/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

// dependency_graph.dot
digraph G {
  rankdir=TB; // Top to Bottom layout
  node [fontname="Arial"];

  // Subgraph for Apps (Visual distinction)
  subgraph cluster_apps {
    label = "Apps";
    style = dashed;
    node [shape=box, style=filled, fillcolor="#e1f5fe"];
    
    "apps/web" [label="apps/web"];
    "apps/admin" [label="apps/admin"];
  }

  // Subgraph for Packages
  subgraph cluster_packages {
    label = "Packages";
    style = dashed;
    node [shape=ellipse, style=filled, fillcolor="#f3e5f5"];
    
    "packages/ui" [label="@boilerplate/ui"];
    "packages/auth" [label="@boilerplate/auth"];
    "packages/types" [label="@boilerplate/types"];
    "packages/db" [label="@boilerplate/db"];
  }

  // Dependency Edges
  // Apps depending on Packages
  "apps/web" -> "packages/ui";
  "apps/web" -> "packages/auth";
  
  "apps/admin" -> "packages/ui";
  "apps/admin" -> "packages/types";

  // Packages depending on Packages
  "packages/ui" -> "packages/types";
  "packages/auth" -> "packages/types";
  "packages/auth" -> "packages/db";
  "packages/db" -> "packages/types";

  // Note on Circular Dependencies
  // If 'packages/types' were to depend on 'packages/ui' (creating a cycle),
  // the graph would indicate a loop. In a monorepo, circular dependencies 
  // between packages cause build failures (e.g., TypeScript cannot resolve 
  // types or Webpack enters an infinite loop). The 'tsc' compiler would 
  // likely throw error TS2449 (Circular dependency detected).
}
