/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.tsx
// Description: Advanced Application Script
// ==========================================

import React, { useState, useTransition } from 'react';
import { Send, Loader2, Bot, User, Sun, Moon } from 'lucide-react';
import { useTheme } from 'next-themes';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { ScrollArea } from '@/components/ui/scroll-area';
import { cn } from '@/lib/utils';

// --- Type Definitions ---

/**
 * Represents a single message in the chat history.
 * Immutable by design: new messages are appended, existing ones are never modified.
 */
type ChatMessage = {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
};

// --- Main Component ---

/**
 * A theming-aware AI Chatbot component.
 * 
 * Architecture Highlights:
 * 1. Theming: Uses `useTheme` from next-themes to toggle light/dark modes, 
 *    affecting Shadcn/UI components via CSS variables.
 * 2. State Management: Employs immutable patterns. The `messages` array is 
 *    never mutated; new arrays are created for updates.
 * 3. Transitions: Wraps state updates for AI responses with `useTransition` 
 *    to maintain UI responsiveness.
 * 4. Security: All logic is contained within the client component, but in a 
 *    real SaaS app, the `handleAIResponse` function would be a Server Action.
 */
export function AIBotChat() {
  // --- 1. Theme Management ---
  // `useTheme` provides the current theme and a function to toggle it.
  // This integrates with Shadcn/UI's CSS variables for instant theming.
  const { theme, setTheme } = useTheme();

  // --- 2. State Management (Immutable) ---
  // Initialize with an empty array. We will never mutate this array directly.
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState('');

  // --- 3. Transition & Pending State ---
  // `useTransition` returns a boolean `isPending` and a `startTransition` function.
  // When `isPending` is true, we can show a loading indicator.
  const [isPending, startTransition] = useTransition();

  /**
   * Handles the submission of a user's message.
   * 
   * Logic:
   * 1. Prevent empty submissions.
   * 2. Create a new user message object (immutable creation).
   * 3. Update the state with the new message (creates a new array).
   * 4. Start a transition to handle the AI response asynchronously.
   * 5. Simulate an AI response after a delay.
   * 6. Update the state again with the AI's response.
   */
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || isPending) return;

    // Create the user message object.
    const userMessage: ChatMessage = {
      id: `msg-${Date.now()}`,
      role: 'user',
      content: input,
      timestamp: new Date(),
    };

    // Clear input immediately for better UX.
    setInput('');

    // Start the transition for the AI response.
    startTransition(async () => {
      // --- IMMUTABLE STATE UPDATE ---
      // We create a new array by spreading the previous messages and adding the new one.
      // This is a core principle of immutable state management.
      setMessages((prev) => [...prev, userMessage]);

      // Simulate an API call to an AI model (e.g., OpenAI, Anthropic).
      // In a real SaaS app, this would be a Server Action call.
      const aiResponse = await simulateAIResponse(userMessage.content);

      // Create the AI message object.
      const aiMessage: ChatMessage = {
        id: `msg-${Date.now() + 1}`,
        role: 'assistant',
        content: aiResponse,
        timestamp: new Date(),
      };

      // --- IMMUTABLE STATE UPDATE ---
      // Append the AI's response to the history.
      setMessages((prev) => [...prev, aiMessage]);
    });
  };

  /**
   * Simulates an AI model's response.
   * In a real application, this function would be replaced by a Server Action
   * that securely interacts with an LLM provider.
   */
  const simulateAIResponse = async (userInput: string): Promise<string> => {
    // Simulate network latency
    await new Promise((resolve) => setTimeout(resolve, 1500));
    
    // Simple keyword-based response for demonstration
    const lowerInput = userInput.toLowerCase();
    if (lowerInput.includes('theme') || lowerInput.includes('dark')) {
      return "I see you're interested in theming! Our platform uses Shadcn/UI and CSS variables for a fully customizable experience. You can toggle the theme using the button in the header.";
    }
    if (lowerInput.includes('database') || lowerInput.includes('vector')) {
      return "For vector support, we recommend using PostgreSQL with the pgvector extension. It allows for efficient similarity search directly within your relational database.";
    }
    return "I'm an AI assistant integrated into this SaaS boilerplate. I can help you with questions about our architecture, styling, or database setup. Try asking about theming or vector databases!";
  };

  // --- 4. Render Logic ---

  return (
    <Card className="w-full max-w-2xl mx-auto shadow-lg">
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-3">
        <CardTitle className="text-lg font-semibold flex items-center gap-2">
          <Bot className="h-5 w-5 text-primary" />
          AI Assistant
        </CardTitle>
        <Button
          variant="ghost"
          size="icon"
          onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
          aria-label="Toggle theme"
        >
          <Sun className="h-4 w-4 rotate-0 scale-100 transition-all dark:-rotate-90 dark:scale-0" />
          <Moon className="absolute h-4 w-4 rotate-90 scale-0 transition-all dark:rotate-0 dark:scale-100" />
          <span className="sr-only">Toggle theme</span>
        </Button>
      </CardHeader>
      
      <CardContent>
        <ScrollArea className="h-[300px] pr-4">
          <div className="flex flex-col gap-4">
            {messages.length === 0 ? (
              <div className="text-center text-muted-foreground py-10">
                Start a conversation with the AI.
              </div>
            ) : (
              messages.map((msg) => (
                <div
                  key={msg.id}
                  className={cn(
                    'flex w-max max-w-[75%] flex-col gap-2 rounded-lg px-3 py-2 text-sm',
                    msg.role === 'user'
                      ? 'ml-auto bg-primary text-primary-foreground'
                      : 'bg-muted text-muted-foreground'
                  )}
                >
                  <div className="flex items-center gap-2">
                    {msg.role === 'user' ? (
                      <User className="h-4 w-4" />
                    ) : (
                      <Bot className="h-4 w-4" />
                    )}
                    <span className="font-medium capitalize">{msg.role}</span>
                  </div>
                  <p>{msg.content}</p>
                </div>
              ))
            )}
            {/* Show a loading indicator during the transition */}
            {isPending && (
              <div className="flex items-center gap-2 text-muted-foreground text-sm">
                <Loader2 className="h-4 w-4 animate-spin" />
                <span>Thinking...</span>
              </div>
            )}
          </div>
        </ScrollArea>
      </CardContent>

      <CardFooter>
        <form onSubmit={handleSubmit} className="flex w-full gap-2">
          <Input
            type="text"
            placeholder="Ask about the boilerplate..."
            value={input}
            onChange={(e) => setInput(e.target.value)}
            disabled={isPending}
            className="flex-1"
          />
          <Button type="submit" disabled={isPending}>
            <Send className="h-4 w-4" />
            <span className="sr-only">Send message</span>
          </Button>
        </form>
      </CardFooter>
    </Card>
  );
}
