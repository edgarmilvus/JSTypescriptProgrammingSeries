/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

// File: components/ThemeProvider.tsx
"use client"

import * as React from "react"
import { ThemeProvider as NextThemesProvider } from "next-themes"
import { type ThemeProviderProps } from "next-themes/dist/types"

export function ThemeProvider({ children, ...props }: ThemeProviderProps) {
  return (
    <NextThemesProvider
      attribute="class"
      defaultTheme="system"
      enableSystem
      disableTransitionOnChange
      {...props}
    >
      {children}
    </NextThemesProvider>
  )
}

/*
 * INSTRUCTOR NOTE ON HYDRATION WARNINGS:
 * 
 * When using Next.js with Server Components, the HTML is rendered on the server and sent to the client.
 * The 'next-themes' library requires access to 'localStorage' and the 'window' object to determine the user's theme preference.
 * These APIs are not available during server-side rendering (SSR).
 * 
 * If we try to render the theme immediately, the server might send HTML for "light" mode, but the client 
 * might prefer "dark" mode based on 'localStorage'. This mismatch causes a hydration error.
 * 
 * The 'next-themes' library handles this internally by:
 * 1. Initially rendering the theme as 'undefined' or the default system value on the server.
 * 2. Waiting for the client-side hydration to complete.
 * 3. Reading 'localStorage' and updating the DOM class (e.g., adding 'dark' to the <html> element) only after the component mounts.
 * 
 * However, to prevent a "Flash of Unstyled Content" (FOUC), 'next-themes' injects a tiny script in the <head> 
 * of the document to set the class on the <html> element immediately, before the React hydration starts.
 * 
 * While 'next-themes' manages the internal logic, wrapping the application in this provider ensures that 
 * the context is available to all client components without manual state management.
 */
