/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

// File: components/ui/Card.tsx
import * as React from "react"
import { cn } from "@/lib/utils" // Assuming utility helper

// ... CardHeader, CardContent, etc. definitions remain standard ...

const Card = React.forwardRef<
  HTMLDivElement,
  React.HTMLAttributes<HTMLDivElement>
>(({ className, ...props }, ref) => (
  <div
    ref={ref}
    className={cn(
      // Standard Shadcn classes
      "rounded-xl border bg-card text-card-foreground shadow-sm",
      
      // Custom Branding & Glassmorphism
      // 1. Using the custom 'xl' radius defined in tailwind.config.js
      "rounded-xl",
      
      // 2. Glassmorphism background (opacity + blur)
      "bg-white/50 dark:bg-black/50 backdrop-blur-md",
      
      // 3. Using the custom 'glow' shadow (optional aesthetic)
      "dark:shadow-glow",
      
      className
    )}
    {...props}
  />
))
Card.displayName = "Card"

export { Card }
