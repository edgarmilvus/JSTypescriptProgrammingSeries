/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part6.ts
// Description: Solutions and Explanations
// ==========================================

// File: components/ui/CustomInput.tsx
import * as React from "react"
import { cn } from "@/lib/utils"

export interface CustomInputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  validationState?: 'default' | 'error' | 'success';
  startIcon?: React.ReactNode;
  endIcon?: React.ReactNode;
}

const CustomInput = React.forwardRef<HTMLInputElement, CustomInputProps>(
  ({ className, type, validationState = 'default', startIcon, endIcon, ...props }, ref) => {
    
    // Map validation states to specific Tailwind border colors
    const validationClasses = {
      default: "border-input focus:border-primary",
      error: "border-destructive focus:border-destructive",
      success: "border-green-500 focus:border-green-500",
    }[validationState];

    return (
      <div className="relative flex items-center w-full">
        {/* Start Icon Rendering */}
        {startIcon && (
          <span className="absolute left-3 text-muted-foreground pointer-events-none">
            {startIcon}
          </span>
        )}
        
        <input
          type={type}
          className={cn(
            "flex h-10 w-full rounded-md border bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50 transition-colors",
            
            // Apply validation border color
            validationClasses,
            
            // Adjust padding if icons are present to prevent text overlap
            startIcon && "pl-9",
            endIcon && "pr-9",
            
            className
          )}
          ref={ref}
          {...props}
        />
        
        {/* End Icon Rendering */}
        {endIcon && (
          <span className="absolute right-3 text-muted-foreground pointer-events-none">
            {endIcon}
          </span>
        )}
      </div>
    );
  }
);
CustomInput.displayName = "CustomInput";

export { CustomInput };
