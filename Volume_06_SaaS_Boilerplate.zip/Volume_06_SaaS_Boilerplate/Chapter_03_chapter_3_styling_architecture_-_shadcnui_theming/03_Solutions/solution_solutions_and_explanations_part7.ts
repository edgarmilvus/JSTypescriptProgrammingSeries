/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part7.ts
// Description: Solutions and Explanations
// ==========================================

digraph ThemeArchitecture {
    rankdir=LR;
    node [shape=box, style="rounded,filled", fontname="Helvetica"];

    // Define Nodes
    User [label="User Interaction\n(Click Toggle)", fillcolor="#e1f5fe"];
    Toggle [label="ThemeToggle Component", fillcolor="#fff3e0"];
    Context [label="next-themes Context", fillcolor="#f3e5f5"];
    Storage [label="localStorage", shape="cylinder", fillcolor="#e8f5e9"];
    DOM [label="Browser DOM\n(html class)", fillcolor="#ffebee"];
    Server [label="Next.js Server\n(Static HTML)", fillcolor="#e0e0e0"];

    // Define Edges (Data Flow)
    User -> Toggle [label="1. Event Trigger"];
    Toggle -> Context [label="2. setTheme()"];
    Context -> Storage [label="3. Persist Preference"];
    Context -> DOM [label="4. Update Class\n(dark/light)"];
    
    // Hydration Flow
    Server -> DOM [label="Initial Render\n(Flash of Unstyled Content Prevention)", style="dashed"];
    Server -> Toggle [label="Hydration\n(Attach React Logic)", style="dashed"];

    // Feedback Loop
    Storage -> Context [label="Read on Init\n(Prevent FOUC)", style="dotted"];
}
