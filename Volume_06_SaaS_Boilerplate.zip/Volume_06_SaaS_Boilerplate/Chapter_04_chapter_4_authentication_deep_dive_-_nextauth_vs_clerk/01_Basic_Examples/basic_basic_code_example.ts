/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

// File: pages/api/auth/[...nextauth].ts
// This is a Next.js API route that catches all requests to /api/auth/*.
// It configures NextAuth.js with a custom Credentials provider for demonstration.

import NextAuth, { NextAuthOptions, Session, User } from "next-auth";
import CredentialsProvider from "next-auth/providers/credentials";

// --- 1. MOCK DATABASE & USER DATA ---
// In a real SaaS, this would be a Prisma, Drizzle, or TypeORM model connected to PostgreSQL/MySQL.
// Here, we simulate a user store for this self-contained example.
const mockUsers: { id: string; email: string; password: string; name: string }[] = [
  {
    id: "clx123456789",
    email: "user@example.com",
    password: "password123", // NEVER store plaintext passwords. This is for demo only.
    name: "SaaS User",
  },
];

/**
 * The main NextAuth configuration object.
 * This is where we define providers, callbacks, and session options.
 */
const authOptions: NextAuthOptions = {
  // --- 2. AUTHENTICATION PROVIDERS ---
  // We use the Credentials provider for a simple email/password login.
  // In a production SaaS, you would likely add OAuth providers like Google, GitHub, etc.
  providers: [
    CredentialsProvider({
      // The name displayed on the sign-in page form.
      name: "Credentials",
      // The credentials input fields.
      credentials: {
        email: { label: "Email", type: "email", placeholder: "user@example.com" },
        password: { label: "Password", type: "password" },
      },
      /**
       * The authorize function is called when the user submits the form.
       * It's responsible for validating the credentials against your database.
       * @param credentials - The user's input from the form.
       * @returns A User object if successful, or null if authentication fails.
       */
      async authorize(credentials) {
        // Find the user in our mock database by email.
        const user = mockUsers.find((u) => u.email === credentials?.email);

        // Check if user exists and password matches (in a real app, use bcrypt.compare).
        if (user && user.password === credentials?.password) {
          // If successful, return the user object. This object will be passed to the JWT callback.
          return user;
        }
        // Return null if authentication fails.
        return null;
      },
    }),
  ],

  // --- 3. SESSION STRATEGY ---
  // We use JWT for stateless sessions. This is efficient and scales well.
  // The alternative is 'database', which stores session data in your DB.
  session: {
    strategy: "jwt",
  },

  // --- 4. CALLBACKS ---
  // Callbacks allow you to customize the JWT and session objects.
  callbacks: {
    /**
     * The JWT callback is called whenever a JWT is created or updated.
     * This is where you add custom claims to the JWT token.
     * @param token - The JWT token object.
     * @param user - The user object from the authorize function (only on sign-in).
     * @returns The modified token.
     */
    async jwt({ token, user }) {
      // On initial sign-in, the user object is available.
      // We add the user's ID and name to the JWT token.
      if (user) {
        token.id = user.id;
        token.name = user.name;
      }
      return token;
    },

    /**
     * The session callback is called whenever a session is accessed.
     * It receives the JWT token and allows you to add properties to the session object.
     * @param session - The session object that will be sent to the client.
     * @param token - The JWT token containing the user's claims.
     * @returns The modified session object.
     */
    async session({ session, token }) => {
      // We add the user's ID from the JWT token to the session object.
      // This makes the user ID available on the client-side via `useSession()`.
      if (session.user) {
        session.user.id = token.id as string;
        session.user.name = token.name as string;
      }
      return session;
    },
  },

  // --- 5. PAGES (OPTIONAL) ---
  // You can override the default authentication pages.
  // For this example, we'll use the default pages, but in a SaaS, you'd
  // point these to your custom branded login and signup pages.
  pages: {
    signIn: "/auth/signin", // Custom sign-in page URL
  },
};

// --- 6. HANDLER EXPORT ---
// Export the NextAuth handler, configured with our authOptions.
// This single handler manages all authentication-related routes (e.g., /api/auth/signin, /api/auth/session, etc.).
export default NextAuth(authOptions);
