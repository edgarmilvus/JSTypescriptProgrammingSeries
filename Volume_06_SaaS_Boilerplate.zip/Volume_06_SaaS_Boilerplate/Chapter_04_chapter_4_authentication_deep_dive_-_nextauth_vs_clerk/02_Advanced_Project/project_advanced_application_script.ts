/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// File: src/middleware.ts
import { withAuth } from "next-auth/middleware";
import { NextResponse } from "next/server";

/**
 * Defines the allowed roles for specific route patterns.
 * In a real SaaS, this maps to subscription tiers (Free, Pro, Enterprise).
 */
type UserRole = "free" | "pro" | "enterprise";

/**
 * Middleware configuration for NextAuth.
 * 
 * Logic Flow:
 * 1. Intercept incoming request.
 * 2. Check if the user is authenticated (has a valid JWT).
 * 3. If authenticated, check the user's role against the required role for the route.
 * 4. Allow access if authorized; redirect to login or upgrade page if not.
 */
export default withAuth(
  function middleware(req) {
    // Extract the user's role from the token attached to the request
    const token = req.nextauth.token;
    const userRole = token?.userRole as UserRole | undefined;
    const path = req.nextUrl.pathname;

    // Security Rule: Protect Admin Dashboard
    // Only 'enterprise' users can access the advanced analytics dashboard
    if (path.startsWith("/dashboard/admin")) {
      if (userRole !== "enterprise") {
        // Redirect to a "Upgrade Plan" page instead of generic login
        return NextResponse.redirect(new URL("/dashboard/upgrade", req.url));
      }
    }

    // Security Rule: Protect Pro Features
    // 'pro' and 'enterprise' users can access vector search tools
    if (path.startsWith("/dashboard/vector-search")) {
      if (userRole !== "pro" && userRole !== "enterprise") {
        return NextResponse.redirect(new URL("/dashboard/pricing", req.url));
      }
    }

    // Allow request to proceed if checks pass
    return NextResponse.next();
  },
  {
    callbacks: {
      // The middleware callback determines if the user is authorized.
      // We rely on the JWT having been populated with a 'userRole' claim.
      authorized: ({ token }) => !!token, // User is authorized if token exists
    },
  }
);

// Apply middleware to specific routes
export const config = {
  matcher: ["/dashboard/:path*", "/api/protected/:path*"],
};
