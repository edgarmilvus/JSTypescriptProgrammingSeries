/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script_part2.ts
// Description: Advanced Application Script
// ==========================================

// File: src/app/api/auth/[...nextauth]/route.ts
import NextAuth, { AuthOptions } from "next-auth";
import CredentialsProvider from "next-auth/providers/credentials";
import { verifyPassword } from "@/lib/auth-utils"; // Hypothetical utility
import { getUserByEmail } from "@/lib/db"; // Hypothetical DB call

/**
 * NextAuth Options Configuration
 * 
 * This is where we implement the "JWT Augmentation" logic.
 */
export const authOptions: AuthOptions = {
  providers: [
    CredentialsProvider({
      name: "Credentials",
      credentials: {
        email: { label: "Email", type: "text" },
        password: { label: "Password", type: "password" },
      },
      async authorize(credentials) {
        // 1. Fetch user from database
        const user = await getUserByEmail(credentials?.email || "");
        
        if (!user) return null;

        // 2. Verify password
        const isValid = await verifyPassword(credentials?.password || "", user.password);
        if (!isValid) return null;

        // 3. Return user object with custom role (fetched from DB)
        return {
          id: user.id,
          email: user.email,
          name: user.name,
          // CRITICAL: Attach the subscription role to the user object
          // This will be passed to the JWT callback
          userRole: user.subscriptionTier, // e.g., "pro"
        };
      },
    }),
  ],
  callbacks: {
    /**
     * JWT Callback: Runs before the token is signed.
     * Use this to persist database user ID and custom roles into the JWT.
     */
    async jwt({ token, user }) {
      // 'user' is only available on the first call (sign-in)
      if (user) {
        token.userRole = user.userRole;
        token.sub = user.id; // Ensure the ID is in the token
      }
      return token;
    },
    /**
     * Session Callback: Runs when the client requests a session.
     * Use this to expose the custom role to the client-side (e.g., for UI toggles).
     */
    async session({ session, token }) {
      if (session.user) {
        // Map the JWT claim to the session object
        session.user.id = token.sub as string;
        session.user.role = token.userRole as string;
      }
      return session;
    },
  },
  pages: {
    signIn: "/auth/signin",
    error: "/auth/error",
  },
};

const handler = NextAuth(authOptions);
export { handler as GET, handler as POST };
