/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script_part3.ts
// Description: Advanced Application Script
// ==========================================

// File: src/components/FeatureGate.tsx
'use client';

import { useSession } from "next-auth/react";

/**
 * Props for the FeatureGate component.
 * @property requiredRole - The minimum role needed to view the children.
 * @property children - The React nodes to render if access is granted.
 */
interface FeatureGateProps {
  requiredRole: "free" | "pro" | "enterprise";
  children: React.ReactNode;
}

/**
 * FeatureGate Component
 * 
 * Client-side component to conditionally render UI elements based on user role.
 * This prevents the UI from displaying buttons/features the user cannot access.
 * 
 * Note: This is client-side protection only. Always verify permissions on the server.
 */
export const FeatureGate: React.FC<FeatureGateProps> = ({ requiredRole, children }) => {
  const { data: session, status } = useSession();
  
  // Loading state
  if (status === "loading") {
    return <div className="animate-pulse bg-gray-200 h-8 w-full rounded"></div>;
  }

  // No active session
  if (!session) return null;

  // Role Hierarchy Definition
  const roleHierarchy: Record<string, number> = {
    "free": 0,
    "pro": 1,
    "enterprise": 2,
  };

  const userRole = session.user?.role as string;
  
  // Check if user's role meets or exceeds the required role
  const hasAccess = roleHierarchy[userRole] >= roleHierarchy[requiredRole];

  if (!hasAccess) {
    // Instead of rendering nothing, we might render a "Locked" UI state
    return (
      <div className="opacity-50 pointer-events-none relative">
        {children}
        <div className="absolute inset-0 flex items-center justify-center bg-gray-900/30 rounded">
          <span className="bg-black text-white text-xs px-2 py-1 rounded">
            Upgrade to Pro
          </span>
        </div>
      </div>
    );
  }

  return <>{children}</>;
};
