/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script_part4.ts
// Description: Advanced Application Script
// ==========================================

// File: src/app/dashboard/page.tsx
import { getServerSession } from "next-auth";
import { authOptions } from "@/app/api/auth/[...nextauth]/route";
import { FeatureGate } from "@/components/FeatureGate";

/**
 * Dashboard Page (Server Component)
 * 
 * Demonstrates how to fetch data securely on the server using the session.
 */
export default async function DashboardPage() {
  // 1. Retrieve session on the server
  const session = await getServerSession(authOptions);

  if (!session) {
    return <div>Please sign in to access the dashboard.</div>;
  }

  return (
    <div className="p-6 space-y-6">
      <h1 className="text-2xl font-bold">Welcome, {session.user?.name}</h1>
      
      {/* Standard Feature: Available to all logged in users */}
      <section className="p-4 border rounded">
        <h2 className="text-xl">Basic Analytics</h2>
        <p>Usage stats for {session.user?.email}</p>
      </section>

      {/* Protected Feature: Vector Search (Pro/Enterprise Only) */}
      <FeatureGate requiredRole="pro">
        <section className="p-4 border rounded bg-blue-50">
          <h2 className="text-xl font-semibold text-blue-800">Vector Search</h2>
          <p>Advanced RAG capabilities powered by K-Nearest Neighbors.</p>
          {/* This content is visually obscured or blocked if user is 'free' */}
        </section>
      </FeatureGate>

      {/* Protected Feature: Admin Tools (Enterprise Only) */}
      <FeatureGate requiredRole="enterprise">
        <section className="p-4 border rounded bg-purple-50">
          <h2 className="text-xl font-semibold text-purple-800">Admin Panel</h2>
          <p>Manage team members and billing settings.</p>
        </section>
      </FeatureGate>
    </div>
  );
}
