/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part10.ts
// Description: Solutions and Explanations
// ==========================================

// app/api/protected/user-data/route.ts
import { NextRequest, NextResponse } from "next/server";
import { getToken } from "next-auth/jwt";
import { prisma } from "@/lib/prisma"; // Assuming Prisma is used

export async function GET(req: NextRequest) {
  try {
    // 1. Extract and Verify Token
    // getToken automatically looks for the 'next-auth.session-token' cookie
    // and verifies it using the NEXTAUTH_SECRET.
    const token = await getToken({ req, secret: process.env.NEXTAUTH_SECRET });

    if (!token) {
      // Token is missing or invalid (expired/tampered)
      return NextResponse.json(
        { error: "Unauthorized: No valid session token found." },
        { status: 401 }
      );
    }

    // 2. Check Role (Optional but recommended for API security)
    // Even if the endpoint is for a generic user, you might want to block banned users.
    if (token.role === "BANNED") {
       return NextResponse.json(
        { error: "Forbidden: User is banned." },
        { status: 403 }
      );
    }

    // 3. Fetch Data using Token Subject (sub) -> User ID
    // The 'sub' claim in the JWT contains the user's unique ID.
    const userId = token.sub;

    if (!userId) {
      return NextResponse.json(
        { error: "Invalid token structure." },
        { status: 400 }
      );
    }

    // Fetch sensitive user data from DB
    const userData = await prisma.user.findUnique({
      where: { id: userId },
      select: {
        id: true,
        email: true,
        billingInfo: true, // Sensitive data
        role: true,
        // DO NOT select passwordHash here
      },
    });

    if (!userData) {
      return NextResponse.json(
        { error: "User not found." },
        { status: 404 }
      );
    }

    // 4. Return Data
    return NextResponse.json({ data: userData }, { status: 200 });

  } catch (error) {
    console.error("API Error:", error);
    return NextResponse.json(
      { error: "Internal Server Error" },
      { status: 500 }
    );
  }
}
