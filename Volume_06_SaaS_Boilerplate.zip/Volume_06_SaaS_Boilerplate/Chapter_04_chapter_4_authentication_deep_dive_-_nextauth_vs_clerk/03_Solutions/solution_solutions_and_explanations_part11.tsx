/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part11.tsx
// Description: Solutions and Explanations
// ==========================================

"use client";

import React, { useState, useEffect } from "react";
import { signIn } from "next-auth/react"; // NextAuth
import { SignIn, SignUp } from "@clerk/nextjs"; // Clerk

// 1. Environment Detection
const getAuthProvider = (): 'nextauth' | 'clerk' => {
  if (process.env.NEXT_PUBLIC_CLERK_PUBLISHABLE_KEY) {
    return 'clerk';
  }
  return 'nextauth';
};

// 2. Type Definitions
interface AuthModalProps {
  mode: 'signin' | 'signup';
}

export const AuthModal: React.FC<AuthModalProps> = ({ mode }) => {
  const [provider, setProvider] = useState<'nextauth' | 'clerk' | null>(null);

  // Detect provider on mount (or hydration)
  useEffect(() => {
    setProvider(getAuthProvider());
  }, []);

  // 3. NextAuth Implementation
  if (provider === 'nextauth') {
    return (
      <div className="auth-modal nextauth-modal">
        <h2>{mode === 'signin' ? 'Sign In' : 'Sign Up'}</h2>
        <form 
          onSubmit={(e) => {
            e.preventDefault();
            const formData = new FormData(e.currentTarget);
            const email = formData.get('email') as string;
            const password = formData.get('password') as string;
            
            // Call NextAuth signIn
            signIn('credentials', { 
              email, 
              password, 
              callbackUrl: '/dashboard' 
            });
          }}
          className="flex flex-col gap-4"
        >
          <input name="email" type="email" placeholder="Email" required />
          <input name="password" type="password" placeholder="Password" required />
          <button type="submit" className="bg-blue-500 text-white p-2 rounded">
            {mode === 'signin' ? 'Login' : 'Register'}
          </button>
        </form>
      </div>
    );
  }

  // 4. Clerk Implementation
  if (provider === 'clerk') {
    return (
      <div className="auth-modal clerk-modal">
        {/* Clerk handles the UI, theming, and logic internally */}
        {mode === 'signin' ? (
          <SignIn routing="hash" signUpUrl="/#signup" />
        ) : (
          <SignUp routing="hash" signInUrl="/#signin" />
        )}
      </div>
    );
  }

  // 5. Loading State
  return (
    <div className="auth-modal loading">
      <p>Detecting authentication provider...</p>
    </div>
  );
};
