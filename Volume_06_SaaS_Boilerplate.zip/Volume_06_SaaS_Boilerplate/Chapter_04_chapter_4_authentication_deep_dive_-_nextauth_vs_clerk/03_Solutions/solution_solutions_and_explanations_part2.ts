/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

    import NextAuth, { NextAuthOptions } from "next-auth";
    import CredentialsProvider from "next-auth/providers/credentials";
    import { PrismaAdapter } from "@auth/prisma-adapter";
    import { prisma } from "./lib/prisma";
    import bcrypt from "bcryptjs";

    export const authOptions: NextAuthOptions = {
      adapter: PrismaAdapter(prisma),
      providers: [
        CredentialsProvider({
          name: "Credentials",
          credentials: {
            email: { label: "Email", type: "text" },
            password: { label: "Password", type: "password" }
          },
          async authorize(credentials) {
            if (!credentials?.email || !credentials?.password) return null;
            
            const user = await prisma.user.findUnique({
              where: { email: credentials.email }
            });

            if (user && bcrypt.compareSync(credentials.password, user.passwordHash!)) {
              return user;
            }
            return null;
          }
        })
      ],
      callbacks: {
        // 1. Attach role to JWT token
        async jwt({ token, user }) {
          // 'user' is only passed on the first sign in
          if (user) {
            // Fetch fresh role from DB to ensure token is always up to date
            const dbUser = await prisma.user.findUnique({ where: { id: user.id } });
            token.role = dbUser?.role || "USER";
            token.sub = user.id;
          }
          return token;
        },
        // 2. Expose role to the client-side session object
        async session({ session, token }) {
          if (token.sub && session.user) {
            session.user.id = token.sub;
            // Cast the role from the token to the session
            session.user.role = token.role as string;
          }
          return session;
        },
      },
      pages: {
        signIn: "/login",
      },
    };

    export const handler = NextAuth(authOptions);
    