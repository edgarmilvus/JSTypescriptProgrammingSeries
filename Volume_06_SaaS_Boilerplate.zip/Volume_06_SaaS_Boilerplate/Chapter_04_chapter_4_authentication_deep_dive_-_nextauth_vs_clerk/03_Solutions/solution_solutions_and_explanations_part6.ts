/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part6.ts
// Description: Solutions and Explanations
// ==========================================

    "use client";

    import { useSession as useNextAuthSession } from "next-auth/react";
    import { useUser as useClerkUser, useClerk } from "@clerk/nextjs";
    import { getAuthProvider } from "./lib/auth-config";

    // Standardized types
    interface AuthUser {
      id: string;
      email: string | null;
      name: string | null;
    }

    interface AuthState {
      user: AuthUser | null;
      status: 'loading' | 'authenticated' | 'unauthenticated';
      signOut: () => void;
    }

    export function useAuth(): AuthState {
      const provider = getAuthProvider();

      // NextAuth Implementation
      if (provider === 'nextauth') {
        const { data: session, status } = useNextAuthSession();
        
        return {
          user: session?.user ? {
            id: session.user.id || '',
            email: session.user.email,
            name: session.user.name,
          } : null,
          status,
          signOut: () => window.location.href = '/api/auth/signout', // Standard NextAuth signout
        };
      }

      // Clerk Implementation
      if (provider === 'clerk') {
        const { user, isLoaded } = useClerkUser();
        const { signOut } = useClerk();

        // Map Clerk status to our standardized status
        const status = isLoaded 
          ? (user ? 'authenticated' : 'unauthenticated') 
          : 'loading';

        return {
          user: user ? {
            id: user.id,
            email: user.emailAddresses[0]?.emailAddress || null,
            name: user.fullName || user.username || null,
          } : null,
          status,
          signOut: () => signOut(),
        };
      }

      // Fallback
      return { user: null, status: 'loading', signOut: () => {} };
    }
    