/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part9.ts
// Description: Solutions and Explanations
// ==========================================

    "use client";

    import { useSession } from "next-auth/react";
    import { useEffect, useState } from "react";

    export function SecureDataFetcher() {
      const { data: session, status } = useSession();
      const [data, setData] = useState(null);
      const [error, setError] = useState<string | null>(null);

      useEffect(() => {
        // FIX: Only fetch if status is 'authenticated'
        if (status === 'authenticated') {
          const fetchData = async () => {
            try {
              // NextAuth automatically attaches the token to the request 
              // via the session cookie if using fetch on the client.
              // No need to manually add headers unless using a custom token strategy.
              const res = await fetch("/api/protected/user-data");
              
              if (res.status === 401) {
                throw new Error("Unauthorized");
              }
              
              if (!res.ok) {
                throw new Error("Network response was not ok");
              }
              
              const result = await res.json();
              setData(result);
            } catch (err: any) {
              setError(err.message);
            }
          };

          fetchData();
        }
      }, [status]); // Dependency is the status, not the session object itself

      // Render Logic
      if (status === "loading") {
        return <div className="skeleton-loader">Loading user data...</div>;
      }

      if (status === "unauthenticated") {
        return <div>Please log in to view this data.</div>;
      }

      return (
        <div>
          <h3>Protected Data</h3>
          {error && <p className="error">Error: {error}</p>}
          {data && <div className="data-view">{JSON.stringify(data)}</div>}
        </div>
      );
    }
    