/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: theory_theoretical_foundations.ts
// Description: Theoretical Foundations
// ==========================================

// config.ts
// This file defines the schema for our environment variables.
// It does NOT contain the values; it only defines the structure and validation.

import { z } from 'zod';

// We define a schema for each environment.
// Notice how 'required' fields change based on the environment.
const BaseConfigSchema = z.object({
  NODE_ENV: z.enum(['development', 'preview', 'production']),
  DATABASE_URL: z.string().url(),
});

const DevelopmentConfigSchema = BaseConfigSchema.extend({
  // Local dev allows for relaxed security for ease of use
  JWT_SECRET: z.string().default('dev-secret-do-not-use-in-prod'),
  // Local vector DB port
  VECTOR_DB_URL: z.string().default('postgresql://localhost:5432/vectors'),
});

const ProductionConfigSchema = BaseConfigSchema.extend({
  // Production requires strict secrets managed externally
  JWT_SECRET: z.string().min(32), // Enforce strong secrets
  VECTOR_DB_URL: z.string().url(), // Must be a valid managed URL
  PAYMENT_WEBHOOK_SECRET: z.string(), // Critical for revenue
});

// The loader function acts as the "Gatekeeper"
export const loadConfig = () => {
  const env = process.env.NODE_ENV || 'development';

  // 1. Load variables from .env files (handled by dotenv)
  // 2. Validate against the schema for the current environment
  try {
    if (env === 'production') {
      return ProductionConfigSchema.parse(process.env);
    }
    // Fallback to development schema for local and preview
    return DevelopmentConfigSchema.parse(process.env);
  } catch (error) {
    // If validation fails (e.g., missing JWT_SECRET in prod), crash immediately.
    // This is the "Fail Fast" principle.
    console.error('Invalid configuration:', error);
    process.exit(1);
  }
};
