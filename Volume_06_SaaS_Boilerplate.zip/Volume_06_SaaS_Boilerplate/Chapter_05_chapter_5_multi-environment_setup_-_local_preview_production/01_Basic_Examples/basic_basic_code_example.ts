/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

# docker-compose.yml
version: '3.8'

services:
  # 1. The Application Service
  app:
    build:
      context: .
      dockerfile: Dockerfile.local # Specific Dockerfile for local dev with hot-reload
    ports:
      - "3000:3000" # Map host port 3000 to container port 3000
    environment:
      - NODE_ENV=development
      - DATABASE_URL=postgresql://user:password@db:5432/saas_db
      - REDIS_URL=redis://redis:6379
    volumes:
      - .:/app # Mount current directory to /app inside container
      - /app/node_modules # Anonymous volume to prevent host node_modules from overwriting container's
    depends_on:
      - db
      - redis
    command: npm run dev # Start Next.js in dev mode

  # 2. The Database Service (PostgreSQL + pgvector)
  db:
    image: pgvector/pgvector:pg15 # Image pre-installed with vector extension
    environment:
      POSTGRES_USER: user
      POSTGRES_PASSWORD: password
      POSTGRES_DB: saas_db
    ports:
      - "5432:5432" # Expose port for external DB clients (e.g., TablePlus, Prisma Studio)
    volumes:
      - db_data:/var/lib/postgresql/data # Persist data across restarts

  # 3. The Cache Service
  redis:
    image: redis:alpine
    ports:
      - "6379:6379"
    volumes:
      - redis_data:/data

volumes:
  db_data:
  redis_data:
