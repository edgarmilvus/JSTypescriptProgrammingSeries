/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useReducer, useEffect, useRef } from 'react';

// 1. State Management: Define types and reducer
type State = {
  status: 'idle' | 'generating' | 'success' | 'error';
  displayValue: string;
  pendingId: number; // Tracks the latest input ID to handle race conditions
};

type Action =
  | { type: 'START_GENERATION'; payload: { input: string; id: number } }
  | { type: 'CONFIRM_RESULT'; payload: { result: string; id: number } }
  | { type: 'RESET' };

const initialState: State = {
  status: 'idle',
  displayValue: '',
  pendingId: -1,
};

function reducer(state: State, action: Action): State {
  switch (action.type) {
    case 'START_GENERATION':
      return {
        ...state,
        status: 'generating',
        displayValue: action.payload.input, // Optimistic update
        pendingId: action.payload.id,
      };
    case 'CONFIRM_RESULT':
      // Only update if this result matches the latest pending ID
      if (action.payload.id !== state.pendingId) {
        return state; // Discard stale result
      }
      return {
        ...state,
        status: 'success',
        displayValue: action.payload.result,
      };
    case 'RESET':
      return initialState;
    default:
      return state;
  }
}

// 2. Simulated Inference
const simulateLocalInference = (input: string): Promise<string> => {
  return new Promise((resolve) => {
    const delay = Math.random() * 2000 + 2000; // 2-4 seconds
    setTimeout(() => {
      resolve(`Generated: ${input.toUpperCase()}`);
    }, delay);
  });
};

// 3. Hook Implementation
export function useOptimisticGenerator() {
  const [state, dispatch] = useReducer(reducer, initialState);
  const idRef = useRef(0); // Used to track the sequence of requests

  const generate = async (input: string) => {
    if (!input.trim()) return;
    
    const currentId = ++idRef.current;
    
    // Immediately update UI (Optimistic)
    dispatch({ 
      type: 'START_GENERATION', 
      payload: { input, id: currentId } 
    });

    try {
      // Run heavy computation in background
      const result = await simulateLocalInference(input);
      
      // On completion, reconcile
      dispatch({ 
        type: 'CONFIRM_RESULT', 
        payload: { result, id: currentId } 
      });
    } catch (error) {
      // Handle errors only if this request is still relevant
      if (currentId === state.pendingId) {
         // In a real app, you might dispatch an error state
         console.error(error);
      }
    }
  };

  return { state, generate };
}

// 4. UI Component
export function GeneratorComponent() {
  const { state, generate } = useOptimisticGenerator();
  const [input, setInput] = React.useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    generate(input);
  };

  // Visual Indicators
  const borderStyle = 
    state.status === 'generating' 
      ? '2px dashed orange' 
      : state.status === 'success' 
      ? '2px solid green' 
      : '1px solid gray';

  return (
    <div style={{ padding: '20px', fontFamily: 'sans-serif' }}>
      <form onSubmit={handleSubmit}>
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Type something to generate..."
          style={{ marginRight: '10px' }}
        />
        <button type="submit">Generate</button>
      </form>

      {/* Visual Feedback */}
      <div 
        style={{ 
          marginTop: '20px', 
          padding: '20px', 
          border: borderStyle,
          borderRadius: '8px',
          transition: 'all 0.3s ease',
          backgroundColor: state.status === 'generating' ? '#fff3e0' : '#f9f9f9'
        }}
      >
        <strong>Status:</strong> {state.status.toUpperCase()}
        <br />
        <span style={{ color: state.status === 'generating' ? '#666' : '#000' }}>
          {state.displayValue || '...'}
        </span>
      </div>
    </div>
  );
}
