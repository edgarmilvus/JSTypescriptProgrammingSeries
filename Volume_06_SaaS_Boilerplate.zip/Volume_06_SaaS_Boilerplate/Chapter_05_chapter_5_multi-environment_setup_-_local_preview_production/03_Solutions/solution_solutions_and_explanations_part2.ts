/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

import { z } from 'zod';

// 1. Define the Schema
// We define a base schema for variables required everywhere.
const BaseSchema = z.object({
  DATABASE_URL: z.string().min(1, "DATABASE_URL is required"),
});

// Environment specific extensions
const ClientPreviewSchema = z.object({
  NEXT_PUBLIC_APP_URL: z.string().url("NEXT_PUBLIC_APP_URL must be a valid URL"),
});

const ProductionSchema = z.object({
  STRIPE_SECRET_KEY: z.string().min(1, "STRIPE_SECRET_KEY is required in Production"),
});

const LocalSchema = z.object({
  OAUTH_CLIENT_SECRET: z.string().min(1, "OAUTH_CLIENT_SECRET is required in Local"),
});

// 2. Dynamic Schema Construction
export const getConfig = () => {
  const nodeEnv = process.env.NODE_ENV;
  const vercelEnv = process.env.VERCEL_ENV; // Assuming Vercel sets this for Preview

  // Determine environment type
  const isProduction = nodeEnv === 'production';
  const isPreview = vercelEnv === 'preview' || nodeEnv === 'preview';
  const isLocal = !isProduction && !isPreview;

  // Merge schemas based on environment
  let envSchema = BaseSchema;

  if (isProduction) {
    // Production requires DB, Stripe, and OAUTH
    envSchema = envSchema.merge(ProductionSchema).merge(LocalSchema); 
    // Note: OAUTH is required in Local AND Production per requirements
  } else if (isPreview) {
    // Preview requires DB and App URL, OAUTH is optional (mocked)
    envSchema = envSchema.merge(ClientPreviewSchema);
  } else {
    // Local requires DB and OAUTH
    envSchema = envSchema.merge(LocalSchema);
  }

  // 3. Validation and Fail-Fast
  const result = envSchema.safeParse(process.env);

  if (!result.success) {
    const errorMessages = result.error.errors.map(err => err.message).join('\n');
    console.error('❌ Environment Validation Failed:');
    console.error(errorMessages);
    throw new Error(`Configuration Error: \n${errorMessages}`);
  }

  // 4. Return Strictly Typed Object
  return result.data as z.infer<typeof envSchema>;
};

// Usage Example:
// const config = getConfig();
// console.log(config.DATABASE_URL); // Type-safe access
