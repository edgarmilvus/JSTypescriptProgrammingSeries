/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

type TrafficSplit = {
  blue: number;
  green: number;
};

type Strategy = 'blue-green' | 'canary';

export function simulateDeployment(strategy: Strategy): TrafficSplit[] {
  const steps: TrafficSplit[] = [];

  // Simulate Health Check (Implicit in the delay between steps in a real system)
  
  if (strategy === 'blue-green') {
    // 1. Start: 100% Blue
    steps.push({ blue: 100, green: 0 });
    
    // 2. Switch: 100% Green (Instant switchover after health check)
    steps.push({ blue: 0, green: 100 });
    
  } else if (strategy === 'canary') {
    // 1. Start: 100% Blue
    steps.push({ blue: 100, green: 0 });
    
    // 2. Initial Canary: 90% Blue, 10% Green
    steps.push({ blue: 90, green: 10 });
    
    // 3. Half & Half: 50% Blue, 50% Green
    steps.push({ blue: 50, green: 50 });
    
    // 4. Full Rollout: 0% Blue, 100% Green
    steps.push({ blue: 0, green: 100 });
  }

  return steps;
}

// Example Usage:
// console.log(simulateDeployment('canary'));
// Output: [{blue:100, green:0}, {blue:90, green:10}, {blue:50, green:50}, {blue:0, green:100}]
