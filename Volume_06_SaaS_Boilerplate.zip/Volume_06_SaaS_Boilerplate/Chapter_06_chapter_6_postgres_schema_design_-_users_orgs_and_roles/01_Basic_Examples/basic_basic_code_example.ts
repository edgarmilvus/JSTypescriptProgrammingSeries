/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

// file: delegation-example.ts

import { z } from 'zod';

// ============================================================================
// 1. DEFINING THE ZOD SCHEMA
// ============================================================================

/**
 * Represents the expected shape of a delegation request.
 * This schema enforces runtime validation for the incoming payload.
 * 
 * @schema
 * @property {string} taskId - A unique identifier for the task (UUID format).
 * @property {string} workerType - The specific worker agent to handle the task (e.g., 'embedding-generator').
 * @property {object} payload - The data required by the worker.
 * @property {number} priority - A numeric priority level (1-10).
 */
const DelegationRequestSchema = z.object({
  taskId: z.string().uuid({ message: "Task ID must be a valid UUID." }),
  workerType: z.enum(['embedding-generator', 'data-processor', 'report-builder']),
  payload: z.record(z.unknown()), // Flexible object for arbitrary data
  priority: z.number().min(1).max(10).default(5),
});

// Infer the TypeScript type directly from the Zod schema for compile-time safety
type DelegationRequest = z.infer<typeof DelegationRequestSchema>;

// ============================================================================
// 2. THE DELEGATION LOGIC (SIMULATED SUPERVISOR NODE)
// ============================================================================

/**
 * Simulates the Supervisor Node processing a delegation request.
 * 
 * @param input - The raw JSON object received from the API.
 * @returns A structured result indicating success or failure.
 */
function processDelegation(input: unknown) {
  // Step A: Validate the input against the Zod schema
  const validationResult = DelegationRequestSchema.safeParse(input);

  // Step B: Handle validation failure
  if (!validationResult.success) {
    // Map Zod errors to a clean API response format
    const formattedErrors = validationResult.error.flatten().fieldErrors;
    
    return {
      status: 'error' as const,
      message: 'Invalid delegation request.',
      errors: formattedErrors,
    };
  }

  // Step C: Extract typed data (TypeScript now knows the shape is correct)
  const { data } = validationResult;
  
  // Step D: Construct the delegation instruction for the Worker
  const delegationInstruction = {
    id: data.taskId,
    target: data.workerType,
    data: data.payload,
    urgency: data.priority,
    timestamp: new Date().toISOString(),
  };

  // In a real app, we would send this instruction to a queue (e.g., Redis/BullMQ)
  console.log(`[Supervisor] Delegating task ${data.taskId} to ${data.workerType}`);

  return {
    status: 'success' as const,
    message: 'Task delegated successfully.',
    instruction: delegationInstruction,
  };
}

// ============================================================================
// 3. EXAMPLE USAGE (SIMULATING API CALLS)
// ============================================================================

// Example 1: Valid Request
const validPayload = {
  taskId: '550e8400-e29b-41d4-a716-446655440000',
  workerType: 'embedding-generator',
  payload: { text: 'Hello World' },
  priority: 8,
};

// Example 2: Invalid Request (Wrong UUID format, missing priority)
const invalidPayload = {
  taskId: 'not-a-uuid',
  workerType: 'unknown-worker',
  payload: null,
};

// Execute simulation
console.log('--- Processing Valid Request ---');
console.log(JSON.stringify(processDelegation(validPayload), null, 2));

console.log('\n--- Processing Invalid Request ---');
console.log(JSON.stringify(processDelegation(invalidPayload), null, 2));
