/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// pages/api/org/[orgId]/search.ts
// Next.js API Route for Delegated Semantic Search

import { createClient } from '@supabase/supabase-js'
import { NextApiRequest, NextApiResponse } from 'next'

// Define the structure of the request payload.
// This represents the "Delegation Strategy" parameters.
interface SearchRequest {
  query_embedding: number[] // The vector representation of the user's text query
  similarity_threshold: number // Minimum cosine similarity score (e.g., 0.7)
  match_count: number // Limit the number of results
}

// Define the structure of the returned document record.
interface Document {
  id: string
  content: string
  similarity: number // Returned by the pgvector cosine similarity operator (<=>)
}

// Initialize Supabase Client.
// In a real app, these come from environment variables.
const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL!
const supabaseServiceRoleKey = process.env.SUPABASE_SERVICE_ROLE_KEY!

// We use the Service Role Key here to act as the "Supervisor".
// This bypasses RLS for the initial connection but we will manually enforce
// RLS context by setting Postgres session variables (request.jwt.claim.org_id).
const supabase = createClient(supabaseUrl, supabaseServiceRoleKey)

/**
 * API Handler: POST /api/org/[orgId]/search
 * 
 * Objective: Perform a semantic search on documents belonging to a specific organization.
 * 
 * Delegation Logic:
 * 1. Extract the Organization ID from the URL path (Context).
 * 2. Extract the User ID from the authenticated session (Context).
 * 3. Construct a query that utilizes pgvector operators.
 * 4. RLS Enforcement: Use `rpc` (Remote Procedure Call) or set session variables
 *    to ensure the database filters results based on the `org_id` column.
 */
export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  // 1. VALIDATION: Ensure the request is a POST request.
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method Not Allowed' })
  }

  // 2. CONTEXT EXTRACTION (The Supervisor's Job).
  // We extract the organization ID from the dynamic route segment.
  const { orgId } = req.query as { orgId: string }
  
  // In a real app, we would validate the user's session via cookies or headers
  // to ensure they actually belong to the requested orgId.
  // For this demo, we assume the user is authenticated.
  const userId = 'fake-user-id-from-session' 

  // 3. PARSE PAYLOAD.
  const body: SearchRequest = req.body
  const { query_embedding, similarity_threshold = 0.7, match_count = 5 } = body

  if (!query_embedding || !Array.isArray(query_embedding)) {
    return res.status(400).json({ error: 'Invalid or missing query_embedding' })
  }

  try {
    // 4. DELEGATION STRATEGY: Setting the Security Context.
    // We are using the Service Role key, which has admin privileges.
    // However, to enforce RLS logic manually (simulating a standard user client),
    // we set the Postgres session variables. 
    // The RLS policy `documents_rls` will look for `request.jwt.claim.org_id`.
    const { error: sessionError } = await supabase.rpc('set_config', {
      // We are manually setting the JWT claims that RLS policies inspect.
      // This mimics: supabase.auth.setAuth(token)
      // But allows the Service Role client to act on behalf of a specific org context.
      config_name: 'request.jwt.claim.org_id',
      config_value: orgId
    })

    if (sessionError) throw sessionError

    // 5. EXECUTE THE WORKER QUERY.
    // We use a Remote Procedure Call (rpc) to a Postgres function named `match_documents`.
    // This function encapsulates the pgvector logic:
    // SELECT content, 1 - (embedding <=> query_embedding) AS similarity
    // FROM documents
    // WHERE 1 - (embedding <=> query_embedding) > similarity_threshold
    // ORDER BY similarity DESC
    // LIMIT match_count;
    const { data: documents, error: searchError } = await supabase.rpc(
      'match_documents',
      {
        query_embedding: query_embedding,
        similarity_threshold: similarity_threshold,
        match_count: match_count
      }
    )

    if (searchError) {
      console.error('Search Error:', searchError)
      return res.status(500).json({ error: 'Failed to execute vector search' })
    }

    // 6. RETURN RESULTS.
    // The database has already filtered documents belonging to the org_id
    // via the RLS policy attached to the `documents` table or the function itself.
    return res.status(200).json({ 
      results: documents as Document[],
      metadata: {
        orgId: orgId,
        count: documents?.length || 0
      }
    })

  } catch (error) {
    console.error('API Error:', error)
    return res.status(500).json({ error: 'Internal Server Error' })
  }
}
