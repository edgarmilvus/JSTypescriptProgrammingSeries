/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// This solution provides the SQL migration commands required to set up the schema and RLS.
// In a Supabase project, these would be placed in a migration file (e.g., 0001_init_schema.sql).
// Since this is a schema definition exercise, the "TypeScript" context is the SQL executed via the Supabase client or CLI.

const sqlMigration = `
-- 1. Create Organizations Table
CREATE TABLE public.organizations (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  owner_id UUID NOT NULL
);

-- 2. Create Users Table (Extension of auth.users)
CREATE TABLE public.users (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  auth_id UUID UNIQUE NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  email TEXT NOT NULL,
  full_name TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 3. Create Enum for Roles
CREATE TYPE public.member_role AS ENUM ('admin', 'member');

-- 4. Create Organization Members Join Table
CREATE TABLE public.organization_members (
  organization_id UUID REFERENCES public.organizations(id) ON DELETE CASCADE,
  user_id UUID REFERENCES public.users(id) ON DELETE CASCADE,
  role public.member_role NOT NULL DEFAULT 'member',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  PRIMARY KEY (organization_id, user_id)
);

-- 5. Enable Row Level Security (RLS) on all tables
ALTER TABLE public.organizations ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.users ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.organization_members ENABLE ROW LEVEL SECURITY;

-- 6. RLS Policies

-- Users Table: Users can only view their own profile
CREATE POLICY "Users can view own profile"
ON public.users FOR SELECT
USING (auth.uid() = auth_id);

-- Organizations Table: Users can view orgs they are members of
CREATE POLICY "Users can view member organizations"
ON public.organizations FOR SELECT
USING (
  auth.uid() IN (
    SELECT user_id FROM public.organization_members
    WHERE organization_members.organization_id = organizations.id
  )
);

-- Organization Members Table: Users can view members of their own orgs
CREATE POLICY "Users can view org members"
ON public.organization_members FOR SELECT
USING (
  auth.uid() IN (
    SELECT user_id FROM public.organization_members AS om
    WHERE om.organization_id = organization_members.organization_id
  )
);

-- Organization Members Table: Admins can insert new members
CREATE POLICY "Admins can insert members"
ON public.organization_members FOR INSERT
WITH CHECK (
  auth.uid() IN (
    SELECT user_id FROM public.organization_members AS om
    WHERE om.organization_id = organization_members.organization_id
    AND om.role = 'admin'
  )
);

-- Organization Members Table: Admins can update member roles
CREATE POLICY "Admins can update member roles"
ON public.organization_members FOR UPDATE
USING (
  auth.uid() IN (
    SELECT user_id FROM public.organization_members AS om
    WHERE om.organization_id = organization_members.organization_id
    AND om.role = 'admin'
  )
);
`;

// Note: In a real application, you would execute this SQL string using
// supabase.rpc('exec_sql', { query: sqlMigration }) or via the Supabase CLI.
