/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useEffect, useState } from 'react';
import { createClient, Session, User } from '@supabase/supabase-js';

// Initialize Supabase Client (Assume environment variables are set)
const supabaseUrl = process.env.REACT_APP_SUPABASE_URL;
const supabaseAnonKey = process.env.REACT_APP_SUPABASE_ANON_KEY;
const supabase = createClient(supabaseUrl, supabaseAnonKey);

// Define types for our data
interface Organization {
  id: string;
  name: string;
  role: string; // Joined from organization_members
}

interface OrganizationSwitcherProps {
  onOrganizationSelect: (org: Organization) => void;
}

export const OrganizationSwitcher: React.FC<OrganizationSwitcherProps> = ({ onOrganizationSelect }) => {
  const [organizations, setOrganizations] = useState<Organization[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const [session, setSession] = useState<Session | null>(null);

  useEffect(() => {
    // Fetch initial session
    const fetchSession = async () => {
      const { data } = await supabase.auth.getSession();
      setSession(data.session);
    };

    fetchSession();

    // Listen for auth changes
    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      setSession(session);
    });

    return () => subscription.unsubscribe();
  }, []);

  useEffect(() => {
    if (!session) {
      setLoading(false);
      return;
    }

    const fetchOrganizations = async () => {
      setLoading(true);
      setError(null);

      // Query: Join organizations with organization_members to get the user's role
      // RLS on the backend will automatically filter for the current user
      const { data, error: fetchError } = await supabase
        .from('organization_members')
        .select(`
          role,
          organizations (
            id,
            name
          )
        `);

      if (fetchError) {
        setError(fetchError.message);
        setLoading(false);
        return;
      }

      // Flatten the data structure returned by the join
      // Filter out any null organizations (defensive coding)
      const orgs: Organization[] = data
        .filter(item => item.organizations !== null)
        .map(item => ({
          id: item.organizations.id,
          name: item.organizations.name,
          role: item.role
        }));

      setOrganizations(orgs);
      setLoading(false);
    };

    fetchOrganizations();
  }, [session]);

  const handleOrgClick = (org: Organization) => {
    // Set the current organization in the parent context/state
    onOrganizationSelect(org);
  };

  if (!session) {
    return <div>Please log in to view organizations.</div>;
  }

  if (loading) return <div>Loading organizations...</div>;
  if (error) return <div style={{ color: 'red' }}>Error: {error}</div>;

  return (
    <div className="organization-switcher">
      <h3>My Organizations</h3>
      {organizations.length === 0 ? (
        <p>You are not a member of any organization.</p>
      ) : (
        <ul>
          {organizations.map((org) => (
            <li 
              key={org.id} 
              onClick={() => handleOrgClick(org)}
              style={{ cursor: 'pointer', padding: '5px', borderBottom: '1px solid #eee' }}
            >
              {org.name} <small>({org.role})</small>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
};
