/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

-- 1. The Flaw Analysis
/*
 * The original policy contains a logical error in the subquery's WHERE clause.
 * 
 * Original Code:
 * WHERE organization_members.organization_id = organizations.id
 * 
 * The issue is that the subquery is checking the 'organization_members' table 
 * against the 'organizations' table. However, the 'organization_members' table 
 * in the subquery is independent of the outer query. It is looking for a match 
 * between the join table and the outer table, but the intent is to find if 
 * the *current user* is a member of the specific organization being evaluated.
 * 
 * The correct logic requires filtering the subquery by the organization ID 
 * of the row currently being evaluated (organizations.id) AND ensuring 
 * the user_id matches the authenticated user (auth.uid()).
 */

-- 2. Corrected SQL Policy
CREATE POLICY "Users can view their orgs (Fixed)"
ON public.organizations FOR SELECT
USING (
  EXISTS (
    SELECT 1 FROM public.organization_members
    WHERE organization_members.organization_id = organizations.id
    AND organization_members.user_id = auth.uid()
  )
);

-- 3. Test Query using SET LOCAL
/*
 * To test this, we simulate a database session. We assume the existence of:
 * - A user 'auth_user_1' (UUID: 11111111-1111-1111-1111-111111111111)
 * - An organization 'Org A' (UUID: 22222222-2222-2222-2222-222222222222)
 * - An organization 'Org B' (UUID: 33333333-3333-3333-3333-333333333333)
 * - A membership linking 'auth_user_1' to 'Org A'
 */

-- Enable RLS for the test session
SET ROLE authenticated;

-- Simulate the authenticated user context
SET LOCAL request.jwt.claim.sub = '11111111-1111-1111-1111-111111111111';

-- Test 1: Query should return 'Org A'
SELECT id, name FROM public.organizations 
WHERE name = 'Org A';

-- Test 2: Query should return 0 rows for 'Org B' (user is not a member)
SELECT id, name FROM public.organizations 
WHERE name = 'Org B';

-- Reset role
RESET ROLE;
