/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

// The following string contains the Graphviz DOT syntax.
// This can be rendered using any Graphviz renderer (e.g., graphviz.org, VS Code extensions).

const graphvizCode = `
digraph SecurityArchitecture {
    rankdir=TB;
    node [shape=box, style="rounded,filled", color="#4a90e2", fontname="Helvetica"];
    edge [color="#333333"];

    // Frontend Layer
    subgraph cluster_frontend {
        label = "Frontend (Browser)";
        style = "filled";
        color = "#f0f0f0";
        
        ReactComp [label="React Component\n(OrganizationSwitcher)", fillcolor="#61dafb"];
        SupabaseClient [label="Supabase JS Client", fillcolor="#3ecf8e"];
    }

    // Backend Layer
    subgraph cluster_backend {
        label = "Backend (Supabase/Postgres)";
        style = "filled";
        color = "#f0f0f0";

        // Database Schema
        AuthUsers [label="auth.users", shape="cylinder", fillcolor="#ffffff"];
        PublicUsers [label="public.users", shape="cylinder", fillcolor="#ffffff"];
        Orgs [label="public.organizations", shape="cylinder", fillcolor="#ffffff"];
        Members [label="public.organization_members", shape="cylinder", fillcolor="#ffffff"];
        
        // Security Layer
        RLS_Gate [label="Row Level Security (RLS)\nPolicies act as a gatekeeper", shape="diamond", fillcolor="#ffcc00", width=2.5];
    }

    // Data Flow & Relationships
    ReactComp -> SupabaseClient [label="1. Query Request\n(e.g., .select('orgs'))"];
    SupabaseClient -> RLS_Gate [label="2. Authenticated Request\n(JWT Token included)"];
    
    // RLS Logic
    RLS_Gate -> AuthUsers [label="Checks auth.uid()", style="dashed"];
    RLS_Gate -> Members [label="Verifies Membership\nAND Role = 'admin' (for writes)", style="dashed"];

    // Database Access
    RLS_Gate -> Orgs [label="3. Allowed Access", color="green", fontcolor="green"];
    RLS_Gate -> PublicUsers [label="Allowed Access", color="green", fontcolor="green"];
    
    // Result Flow
    Orgs -> Members [label="FK Relationship", dir="both", style="dotted"];
    Members -> SupabaseClient [label="4. Filtered Results\n(Only user's orgs)", dir="back", color="green"];
    SupabaseClient -> ReactComp [label="5. Data Rendered"];

    // Foreign Key Visuals (Logical)
    AuthUsers -> PublicUsers [label="auth_id (FK)", style="dotted", dir="both"];
    PublicUsers -> Members [label="user_id (FK)", style="dotted", dir="both"];
    Orgs -> Members [label="org_id (FK)", style="dotted", dir="both"];
}
`;

/*
 * [ERROR: Failed to render diagram.]
 * 
 * Note to Instructor: The error message above is a placeholder as requested by the prompt.
 * In a real Markdown environment supporting Mermaid or Graphviz rendering, the code block 
 * above would generate a diagram. Below is a textual description of the visualization.
 * 
 * VISUALIZATION DESCRIPTION:
 * 1. Top Layer: The React Component sends a request to the Supabase Client.
 * 2. Middle Layer: The request hits the Supabase API, which routes it to Postgres.
 * 3. Security Gate: Before the query touches the tables, the RLS Policy (represented as a Diamond)
 *    intercepts it. It checks the JWT (auth.uid) against the 'organization_members' table.
 * 4. Database Layer: If the check passes, the query executes against 'organizations' and 'users'.
 * 5. Return Path: Data flows back through the RLS gate (filtered), to the client, and finally to the UI.
 */
