/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: theory_theoretical_foundations.ts
// Description: Theoretical Foundations
// ==========================================

// This is a conceptual example of a Drizzle schema definition.
// It is declarative, readable, and serves as the blueprint for everything.

import { pgTable, serial, varchar, timestamp, vector } from 'drizzle-orm/pg-core';

// 1. Define the 'users' table.
// This is the blueprint for user data in our application.
export const users = pgTable('users', {
  id: serial('id').primaryKey(), // A unique, auto-incrementing identifier.
  email: varchar('email', { length: 256 }).notNull().unique(), // User's email, required and unique.
  passwordHash: varchar('password_hash', { length: 256 }).notNull(), // Hashed password, never plain text.
  createdAt: timestamp('created_at').defaultNow(), // Timestamp of account creation.
});

// 2. Define the 'documents' table for our AI features.
// This blueprint includes a vector column, which is crucial for our "AI-Ready" boilerplate.
export const documents = pgTable('documents', {
  id: serial('id').primaryKey(),
  userId: integer('user_id').references(() => users.id), // Foreign key relationship.
  content: text('content').notNull(), // The raw text of the document.
  embedding: vector('embedding', { dimensions: 1536 }), // A 1536-dimensional vector (e.g., for OpenAI embeddings).
  createdAt: timestamp('created_at').defaultNow(),
});
