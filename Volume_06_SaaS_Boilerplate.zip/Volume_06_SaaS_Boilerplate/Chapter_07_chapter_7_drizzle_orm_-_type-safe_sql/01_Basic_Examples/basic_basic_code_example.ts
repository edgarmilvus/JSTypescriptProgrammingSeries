/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * @fileoverview A self-contained example demonstrating Drizzle ORM schemas,
 * Zod validation, Generics, and Utility Types in a SaaS context.
 * 
 * Dependencies: 
 * - drizzle-orm (for schema definitions)
 * - zod (for runtime validation)
 * 
 * Note: This code is conceptual and assumes a standard Node.js environment.
 */

import { pgTable, serial, varchar, timestamp, boolean } from 'drizzle-orm/pg-core';
import { z } from 'zod';

// ==========================================
// 1. Database Schema Definition (Drizzle)
// ==========================================

/**
 * Defines the 'users' table in the PostgreSQL database.
 * We use Drizzle's schema-first approach to define the shape of our data.
 */
export const users = pgTable('users', {
  id: serial('id').primaryKey(), // Auto-incrementing primary key
  email: varchar('email', { length: 256 }).notNull().unique(), // User email
  name: varchar('name', { length: 256 }).notNull(), // User display name
  role: varchar('role', { length: 50 }).$type<'admin' | 'user'>().notNull(), // User role
  isVerified: boolean('is_verified').default(false), // Email verification status
  createdAt: timestamp('created_at').defaultNow(), // Timestamp of creation
});

// ==========================================
// 2. Zod Schema for Validation
// ==========================================

/**
 * Zod schema for validating incoming user data (e.g., from a registration form).
 * This ensures runtime safety and acts as the source of truth for our types.
 */
export const UserRegistrationSchema = z.object({
  email: z.string().email("Invalid email address"),
  name: z.string().min(1, "Name is required"),
  role: z.enum(['admin', 'user']).default('user'),
  isVerified: z.boolean().optional().default(false),
});

// Infer the TypeScript type from the Zod schema
export type UserRegistration = z.infer<typeof UserRegistrationSchema>;

// ==========================================
// 3. Utility Types in Action
// ==========================================

/**
 * We create a 'PublicUser' type by using the TypeScript 'Pick' utility.
 * We take only specific fields from our inferred type to expose publicly.
 * This prevents leaking sensitive or internal data (like internal IDs or flags).
 */
export type PublicUser = Pick<UserRegistration, 'email' | 'name' | 'role'>;

// ==========================================
// 4. Generic Data Fetcher
// ==========================================

/**
 * A generic function to fetch a user by ID from the database.
 * 
 * Why Generics? 
 * We want this function to work with any Drizzle table schema, but we also want 
 * strict type safety for the return value based on the table passed in.
 * 
 * @param table - The Drizzle table schema (e.g., users table).
 * @param id - The ID of the record to fetch.
 * @returns A promise resolving to the user object or null if not found.
 */
async function fetchUserById<T extends { id: any }>(
  table: T, 
  id: number
): Promise<T | null> {
  // In a real app, this would be a Drizzle query like:
  // const result = await db.select().from(table).where(eq(table.id, id));
  
  // Mocking the database response for this example:
  console.log(`Fetching from table: ${table.name} with ID: ${id}`);
  
  // Simulating a database hit
  if (id === 1) {
    return {
      id: 1,
      email: 'sarah@example.com',
      name: 'Sarah Connor',
      role: 'admin',
      isVerified: true,
      createdAt: new Date(),
    } as unknown as T; // Casting for the sake of the mock
  }
  
  return null;
}

// ==========================================
// 5. Usage Example
// ==========================================

/**
 * Demonstrates the flow: Validate Input -> Generate Type -> Fetch Data.
 */
async function main() {
  // A. Validate incoming data (e.g., from an API POST request)
  const rawData = {
    email: 'john.doe@example.com',
    name: 'John Doe',
    role: 'user',
  };

  try {
    // Zod validates at runtime and throws if invalid
    const validatedData = UserRegistrationSchema.parse(rawData);
    
    // B. Use the inferred type for type-safe operations
    const newUser: UserRegistration = validatedData;
    
    console.log('Validated User:', newUser);

    // C. Fetch data using our Generic function
    // We pass the 'users' table schema. TypeScript infers the return type automatically.
    const fetchedUser = await fetchUserById(users, 1);

    if (fetchedUser) {
      // TypeScript knows the shape of 'fetchedUser' based on the 'users' table
      console.log('Fetched User Email:', fetchedUser.email);
    }

    // D. Using Utility Types for Public Exposure
    const publicProfile: PublicUser = {
      email: newUser.email,
      name: newUser.name,
      role: newUser.role,
    };
    
    console.log('Public Profile:', publicProfile);

  } catch (error) {
    console.error('Validation or Fetch Error:', error);
  }
}

// Execute the example
// main(); // Uncomment to run in a Node environment
