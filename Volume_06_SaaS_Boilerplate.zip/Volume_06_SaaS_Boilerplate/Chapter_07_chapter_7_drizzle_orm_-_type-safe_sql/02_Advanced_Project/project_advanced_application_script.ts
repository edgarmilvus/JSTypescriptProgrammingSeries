/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// src/app/api/advanced-subscriptions/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import { pgTable, serial, varchar, timestamp, pgEnum, jsonb } from 'drizzle-orm/pg-core';
import { eq } from 'drizzle-orm';
import { drizzle } from 'drizzle-orm/node-postgres';
import { Pool } from 'pg';

/**
 * ------------------------------------------------------------------
 * 1. DATABASE SCHEMA DEFINITION (Drizzle ORM)
 * ------------------------------------------------------------------
 * We define the schema using Drizzle's column builders.
 * Note the use of `pgEnum` for type safety on the 'status' column
 * and `jsonb` for storing flexible payment metadata.
 */

// Define an enum for subscription status to ensure DB-level consistency
export const subscriptionStatusEnum = pgEnum('subscription_status', [
  'active',
  'canceled',
  'incomplete',
  'past_due',
]);

// Define the subscriptions table
export const subscriptions = pgTable('subscriptions', {
  id: serial('id').primaryKey(),
  // Link to a user ID (simplified for this example)
  userId: varchar('user_id', { length: 255 }).notNull(),
  // The Stripe Subscription ID
  stripeSubscriptionId: varchar('stripe_subscription_id', { length: 255 }).notNull().unique(),
  // Current status of the subscription
  status: subscriptionStatusEnum('status').notNull(),
  // JSONB column for storing flexible metadata (e.g., Stripe plan details)
  metadata: jsonb('metadata').$type<Record<string, any>>(),
  createdAt: timestamp('created_at').defaultNow(),
  updatedAt: timestamp('updated_at').defaultNow(),
});

// Infer the TypeScript type for the Subscription table
// This allows us to reference the shape of the DB row in our TS code
export type DbSubscription = typeof subscriptions.$inferSelect;

/**
 * ------------------------------------------------------------------
 * 2. ZOD SCHEMA & RUNTIME VALIDATION
 * ------------------------------------------------------------------
 * We define a Zod schema to validate incoming webhook payloads.
 * This ensures that external data conforms to our expected shape
 * before we attempt to write it to the database.
 */

const StripeWebhookSchema = z.object({
  id: z.string().startsWith('sub_'),
  customer: z.string(),
  status: z.enum(['active', 'canceled', 'incomplete', 'past_due']),
  metadata: z.record(z.string(), z.any()).optional(),
});

// Infer the TypeScript type from the Zod schema
// This bridges runtime validation with compile-time type safety
type StripeWebhookPayload = z.infer<typeof StripeWebhookSchema>;

/**
 * ------------------------------------------------------------------
 * 3. DATABASE CONFIGURATION
 * ------------------------------------------------------------------
 * Initialize the Drizzle ORM instance.
 * In a real app, connection pooling and environment variables are handled here.
 */

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
});

export const db = drizzle(pool);

/**
 * ------------------------------------------------------------------
 * 4. UTILITY: GENERIC DOMAIN MAPPER
 * ------------------------------------------------------------------
 * This function uses TypeScript Generics to safely map a database record
 * to a domain-specific object. It ensures that the input `T` (DB record)
 * and output `U` (Domain object) are related, preventing mismatched data.
 * 
 * @param record - The database record (T)
 * @param mapper - A function that transforms T into U
 * @returns The mapped domain object (U)
 */
function mapDbRecordToDomain<T, U>(
  record: T | undefined, 
  mapper: (record: T) => U
): U | null {
  if (!record) return null;
  return mapper(record);
}

/**
 * ------------------------------------------------------------------
 * 5. LOGIC: SUBSCRIPTION MANAGEMENT
 * ------------------------------------------------------------------
 * This function demonstrates the full flow: validating input,
 * inserting into the database, and retrieving data with strict typing.
 */

/**
 * Handles the creation of a subscription based on a Stripe webhook.
 * Uses Zod for validation and Drizzle for type-safe insertion.
 */
async function createSubscriptionFromWebhook(payload: unknown) {
  // 1. Validate the incoming payload using Zod
  const parsedPayload = StripeWebhookSchema.safeParse(payload);

  if (!parsedPayload.success) {
    console.error('Invalid webhook payload:', parsedPayload.error);
    throw new Error('Validation failed');
  }

  const { id, customer, status, metadata } = parsedPayload.data;

  // 2. Prepare the insert data using the inferred type from Drizzle schema
  // Drizzle ensures we only insert valid columns defined in `subscriptions`
  const newSubscription = {
    userId: customer, // Mapping Stripe customer to our userId
    stripeSubscriptionId: id,
    status: status,
    metadata: metadata || {},
  };

  // 3. Execute the type-safe insert query
  // Drizzle generates the SQL and validates the types at compile time
  const result = await db.insert(subscriptions).values(newSubscription).returning();

  return result[0]; // Returns the inserted row
}

/**
 * Retrieves a subscription by ID and maps it to a domain object.
 * Demonstrates generic utility usage and safe type narrowing.
 */
async function getSubscriptionDetails(subscriptionId: number) {
  // 1. Build the type-safe query using Drizzle's `eq` operator
  const query = db.select().from(subscriptions).where(eq(subscriptions.id, subscriptionId));

  // 2. Execute the query
  const rows = await query.execute();
  const record = rows[0];

  // 3. Map the DB record to a Domain Object using the generic utility
  // We define the Domain type explicitly here for clarity
  type SubscriptionDomain = {
    id: number;
    stripeId: string;
    isActive: boolean;
  };

  const domainObject = mapDbRecordToDomain(record, (dbRec) => {
    // Inside the mapper, TypeScript knows `dbRec` is of type `DbSubscription`
    return {
      id: dbRec.id,
      stripeId: dbRec.stripeSubscriptionId,
      // Simple logic to determine active status
      isActive: dbRec.status === 'active',
    };
  });

  return domainObject;
}

/**
 * ------------------------------------------------------------------
 * 6. NEXT.JS API ROUTE HANDLER
 * ------------------------------------------------------------------
 * This is the entry point for the Next.js application.
 */

export async function POST(request: NextRequest) {
  try {
    const payload = await request.json();

    // 1. Create the subscription
    const createdSubscription = await createSubscriptionFromWebhook(payload);

    // 2. Retrieve the details using the generic mapper
    const subscriptionDetails = await getSubscriptionDetails(createdSubscription.id);

    if (!subscriptionDetails) {
      return NextResponse.json({ error: 'Subscription not found after creation' }, { status: 404 });
    }

    // 3. Return the mapped domain object
    return NextResponse.json({
      success: true,
      data: subscriptionDetails,
    });

  } catch (error) {
    console.error('Error processing subscription:', error);
    return NextResponse.json({ error: 'Internal Server Error' }, { status: 500 });
  }
}
