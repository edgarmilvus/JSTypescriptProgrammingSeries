/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// schema.ts
import {
  pgTable,
  uuid,
  text,
  timestamp,
  pgEnum,
  jsonb,
} from 'drizzle-orm/pg-core';
import { InferSelectModel, InferInsertModel } from 'drizzle-orm';
import { vector } from 'drizzle-orm/pg-core'; // Assuming a custom type or extension wrapper

// 1. Define the Documents Table
export const documents = pgTable('documents', {
  id: uuid('id').primaryKey().defaultRandom(),
  content: text('content').notNull(),
  // Using a custom 'vector' type for pgvector. 
  // Note: Drizzle doesn't have a built-in 'vector' type in core, 
  // so we often define a custom type or use a helper from a library like 'drizzle-pgvector'.
  // For this exercise, we assume a custom type definition exists:
  embedding: vector('embedding', { dimensions: 1536 }), 
  userId: uuid('user_id').references(() => users.id), // Assuming users table exists
  createdAt: timestamp('created_at', { withTimezone: true }).defaultNow(),
  // Interactive Challenge: Adding JSON metadata
  metadata: jsonb('metadata').$type<Record<string, any>>().notNull(),
});

// Assuming a users table exists for the foreign key reference
export const users = pgTable('users', {
  id: uuid('id').primaryKey().defaultRandom(),
  email: text('email').notNull().unique(),
});

// 2. Type Inference
// Type for selecting data (reads from DB)
export type DocumentSelect = InferSelectModel<typeof documents>;
// Type for inserting data (writes to DB)
export type DocumentInsert = InferInsertModel<typeof documents>;

// 3. Query Construction (No Execution)

// Select content and embedding for a specific userId
// db is the Drizzle database connection instance
const getDocumentsByUser = (db: any, userId: string) => {
  return db.select({
    content: documents.content,
    embedding: documents.embedding,
  }).from(documents).where(eq(documents.userId, userId));
};

// Insert a new document chunk
const insertDocument = (db: any, doc: DocumentInsert) => {
  return db.insert(documents).values(doc);
};
