/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

// schema.ts
import { pgTable, uuid, text, timestamp, varchar } from 'drizzle-orm/pg-core';
import { relations } from 'drizzle-orm';

export const users = pgTable('users', {
  id: uuid('id').primaryKey().defaultRandom(),
  email: text('email').notNull(),
  name: text('name'),
});

export const subscriptions = pgTable('subscriptions', {
  id: uuid('id').primaryKey().defaultRandom(),
  userId: uuid('user_id').notNull().references(() => users.id),
  plan: varchar('plan', { length: 50 }).notNull(),
  status: varchar('status', { length: 20 }).notNull(), // e.g., 'active', 'canceled'
  createdAt: timestamp('created_at').defaultNow(),
});

// 1. Define Relations
export const usersRelations = relations(users, ({ many }) => ({
  subscriptions: many(subscriptions),
}));

export const subscriptionsRelations = relations(subscriptions, ({ one }) => ({
  user: one(users, { fields: [subscriptions.userId], references: [users.id] }),
}));

// 2. Construct the Query (Assuming 'db' is the Drizzle connection)
// We use the relational query syntax (db.query.users.findMany) for nested data.

const fetchActiveUsersWithSubs = async (db: any) => {
  const result = await db.query.users.findMany({
    where: (users: any, { exists }: any) => 
      exists(
        db.select().from(subscriptions)
          .where(
            and(
              eq(subscriptions.userId, users.id),
              eq(subscriptions.status, 'active')
            )
          )
      ),
    with: {
      subscriptions: {
        columns: {
          status: true,
          plan: true,
        },
      },
    },
  });
  return result;
};

// 3. Type Safety Explanation
// The return type of fetchActiveUsersWithSubs is inferred automatically.
// It will be an array of objects: { id: string, email: string, name: string | null, subscriptions: { status: string, plan: string }[] }
// Drizzle uses the schema definitions to build these complex nested types at compile time.

// Interactive Challenge: Reverse Query
const fetchSubscriptionsWithUser = async (db: any) => {
  return await db.query.subscriptions.findMany({
    with: {
      user: {
        columns: {
          email: true,
          name: true,
        },
      },
    },
  });
};
