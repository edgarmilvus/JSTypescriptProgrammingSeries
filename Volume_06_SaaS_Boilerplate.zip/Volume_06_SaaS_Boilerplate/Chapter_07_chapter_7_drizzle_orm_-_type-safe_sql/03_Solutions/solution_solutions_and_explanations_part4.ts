/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

// schema.ts
import { pgTable, uuid, varchar, integer, timestamp } from 'drizzle-orm/pg-core';

export const subscriptions = pgTable('subscriptions', {
  id: uuid('id').primaryKey().defaultRandom(),
  userId: uuid('user_id').notNull(),
  plan: varchar('plan').notNull(),
  status: varchar('status').notNull(), // 'pending', 'active'
});

export const payments = pgTable('payments', {
  id: uuid('id').primaryKey().defaultRandom(),
  subscriptionId: uuid('subscription_id').notNull().references(() => subscriptions.id),
  amount: integer('amount').notNull(), // Storing cents
  status: varchar('status').notNull(), // 'processing', 'completed'
  createdAt: timestamp('created_at').defaultNow(),
});

// 1. Transaction Setup
// db is the Drizzle database connection
const upgradeUserPlan = async (db: any, userId: string, plan: string, amount: number) => {
  try {
    // Start transaction
    const result = await db.transaction(async (tx: any) => {
      // Insert Subscription
      const [newSubscription] = await tx
        .insert(subscriptions)
        .values({
          userId,
          plan,
          status: 'pending',
        })
        .returning(); // Capture the inserted row

      // Simulate Failure
      if (amount > 10000) {
        throw new Error('Payment amount too high simulated failure');
      }

      // Insert Payment
      const [newPayment] = await tx
        .insert(payments)
        .values({
          subscriptionId: newSubscription.id,
          amount,
          status: 'processing',
        })
        .returning();

      // 3. Type-Safe Return
      // The transaction returns an object containing both results
      return { subscription: newSubscription, payment: newPayment };
    });

    return result;
  } catch (error) {
    // 2. Error Handling
    console.error('Transaction failed:', error);
    // Transaction is automatically rolled back here
    throw error;
  }
};

// Interactive Challenge: Idempotency
// schema for payment_events
export const paymentEvents = pgTable('payment_events', {
  eventId: varchar('event_id').primaryKey(), // Unique ID from provider
  payload: jsonb('payload').notNull(),
  processedAt: timestamp('processed_at').defaultNow(),
});

const handleWebhook = async (db: any, eventId: string, payload: any) => {
  await db.insert(paymentEvents)
    .values({
      eventId,
      payload,
    })
    .onConflictDoNothing(); // Ignores if eventId already exists
};
