/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

// schema.ts
import { pgTable, uuid, text, vector } from 'drizzle-orm/pg-core';
import { sql } from 'drizzle-orm';

export const documents = pgTable('documents', {
  id: uuid('id').primaryKey().defaultRandom(),
  content: text('content').notNull(),
  embedding: vector('embedding', { dimensions: 1536 }),
});

// 1. Vector Search Query
const semanticSearch = async (db: any, queryVector: number[]) => {
  // We use the 'sql' tag to inject raw SQL expressions for vector operations
  // as Drizzle doesn't have a built-in 'cosineSimilarity' function in core.
  
  const similarity = sql`${documents.embedding} <=> ${sql.placeholder('queryVector')}`;
  // '<=>' is the PostgreSQL operator for cosine distance (1 - cosine similarity).
  // To get similarity (0 to 2), we calculate distance. 
  // Usually, we order by distance ASC (closest first).

  const results = await db
    .select({
      id: documents.id,
      content: documents.content,
      // Calculate distance explicitly
      distance: sql<number>`${documents.embedding} <=> ${sql.placeholder('queryVector')}`,
    })
    .from(documents)
    .orderBy(sql`${documents.embedding} <=> ${sql.placeholder('queryVector')}`)
    .limit(5)
    .offset(0);

  return results;
};

// 2. Performance Considerations / Indexing
// To optimize this, we need an index on the embedding column.
// In a migration file, you would typically run:
// CREATE INDEX ON documents USING ivfflat (embedding vector_cosine_ops) WITH (lists = 100);
// Or for higher accuracy (but slower build): HNSW index.

// Drizzle allows defining indexes in the schema definition:
/*
export const documents = pgTable('documents', {
  // ... columns ...
}, (table) => ({
  // IVFFlat Index for cosine similarity
  idx_embedding: index('idx_embedding').using('ivfflat', table.embedding).op('vector_cosine_ops'),
}));
*/

// 3. Type-Safe Results
// The result type is inferred as:
// type SearchResult = { id: string, content: string, distance: number }[]

// Interactive Challenge: Hybrid Search
const hybridSearch = async (db: any, queryVector: number[], keyword: string) => {
  return await db
    .select({
      id: documents.id,
      content: documents.content,
      distance: sql<number>`${documents.embedding} <=> ${sql.placeholder('queryVector')}`,
    })
    .from(documents)
    .where(sql`${documents.content} ILIKE ${'%' + keyword + '%'}`) // Keyword filter
    .orderBy(sql`${documents.embedding} <=> ${sql.placeholder('queryVector')}`)
    .limit(5);
};
