/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.ts
// Description: Basic Code Example
// ==========================================

// Import the Supabase client library
import { createClient, SupabaseClient } from '@supabase/supabase-js';

/**
 * Configuration for the Supabase client.
 * In a production SaaS app, these should be loaded from environment variables (.env).
 */
const SUPABASE_URL = 'https://your-project-ref.supabase.co';
const SUPABASE_ANON_KEY = 'your-anon-public-key';

// Initialize the Supabase client
const supabase: SupabaseClient = createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

/**
 * Represents a document record in the database.
 */
interface Document {
  id: number;
  content: string;
  embedding: number[]; // pgvector is returned as a number array in JS
}

/**
 * Step 1: Verify the pgvector extension is active.
 * This is a safety check to ensure the database is ready for vector operations.
 */
async function verifyPgVectorExtension(): Promise<void> {
  console.log('🔍 Checking pgvector extension status...');
  
  // We query the PostgreSQL system catalog 'pg_extension'
  const { data, error } = await supabase
    .rpc('check_extension', { extname: 'vector' }); // Assumes a helper function or use raw SQL

  // Note: In a real scenario, you might execute raw SQL if you haven't created an RPC function:
  // const { data, error } = await supabase.rpc('check_extension', { extname: 'vector' });
  
  if (error) {
    // Fallback check via raw SQL execution if RPC isn't set up
    const { data: rawCheck, error: rawError } = await supabase
      .from('pg_extension')
      .select('extname')
      .eq('extname', 'vector')
      .single();

    if (rawError || !rawCheck) {
      console.error('❌ Error: pgvector extension is NOT installed in the database.');
      throw new Error('pgvector extension missing');
    }
  }
  
  console.log('✅ pgvector extension is active.');
}

/**
 * Step 2: Insert a document with its vector embedding.
 * @param content - The text content to store.
 * @param embedding - The vector array (e.g., from OpenAI embedding API).
 */
async function insertDocument(content: string, embedding: number[]): Promise<void> {
  console.log(`📝 Inserting document: "${content.substring(0, 20)}..."`);

  const { error } = await supabase
    .from('documents')
    .insert([
      {
        content: content,
        embedding: embedding, // This vector is automatically handled by pgvector
      },
    ]);

  if (error) {
    console.error('❌ Error inserting document:', error.message);
    throw error;
  }

  console.log('✅ Document inserted successfully.');
}

/**
 * Step 3: Perform a similarity search using Cosine Distance.
 * This finds the document most similar to the query vector.
 * @param queryEmbedding - The vector representation of the user's query.
 * @returns The most relevant document content.
 */
async function searchSimilarDocuments(queryEmbedding: number[]): Promise<Document | null> {
  console.log('🔎 Searching for similar documents...');

  // Postgres Operator: <-> (Cosine Distance)
  // 1. Select columns 'id' and 'content'.
  // 2. Order by the cosine distance between the stored 'embedding' and the input 'queryEmbedding'.
  // 3. Limit to the top 1 result.
  const { data, error } = await supabase
    .from('documents')
    .select('id, content, embedding')
    .order('embedding', {
      ascending: true, // Lower distance = higher similarity
      // PostgREST syntax for embedding distance calculation is often handled via a computed column or raw SQL.
      // However, standard PostgREST doesn't support operators like <-> directly in .order().
      // We will use a filter approach or a Postgres function.
    })
    // Since .order() with vectors is tricky in standard PostgREST, we often use a filter or a specific RPC.
    // For this example, we will assume a helper function `match_documents` exists in DB:
    // CREATE OR REPLACE FUNCTION match_documents(query_embedding vector(1536), match_threshold float)
    // RETURNS TABLE (id bigint, content text, similarity float) ...
    
    // Alternatively, using the `rpc` method for direct SQL operator access:
    .rpc('match_documents', {
      query_embedding: queryEmbedding,
      match_threshold: 0.5, // Cosine similarity threshold (0 to 1)
    });

  if (error) {
    console.error('❌ Error searching documents:', error.message);
    throw error;
  }

  if (!data || data.length === 0) {
    console.log('⚠️ No matching documents found.');
    return null;
  }

  // Assuming the RPC returns the top match
  const topMatch = data[0]; 
  console.log(`✅ Found match (ID: ${topMatch.id}): "${topMatch.content}"`);
  return topMatch;
}

/**
 * Main Execution Flow
 * Simulates a user asking a question and retrieving context.
 */
async function main() {
  try {
    // 1. Verify Database Setup
    await verifyPgVectorExtension();

    // 2. Mock Data: Simulating an embedding generation step (usually done via OpenAI API)
    // In a real app, you would fetch this from an LLM provider.
    // Dimensions: 1536 (OpenAI Ada-002)
    const mockEmbeddingA: number[] = Array(1536).fill(0).map((_, i) => Math.sin(i * 0.1));
    const mockEmbeddingB: number[] = Array(1536).fill(0).map((_, i) => Math.cos(i * 0.1));
    
    // 3. Insert dummy data
    await insertDocument('Supabase uses PostgreSQL as its core database.', mockEmbeddingA);
    await insertDocument('Vector embeddings are arrays of floating point numbers.', mockEmbeddingB);

    // 4. Simulate a user query
    // This vector should be mathematically closer to 'mockEmbeddingA'
    const userQueryEmbedding: number[] = Array(1536).fill(0).map((_, i) => Math.sin(i * 0.1) + 0.001); 

    // 5. Search
    await searchSimilarDocuments(userQueryEmbedding);

  } catch (err) {
    console.error('Execution failed:', err);
  }
}

// Execute the main function
// main(); // Uncomment to run if executing in a Node environment
