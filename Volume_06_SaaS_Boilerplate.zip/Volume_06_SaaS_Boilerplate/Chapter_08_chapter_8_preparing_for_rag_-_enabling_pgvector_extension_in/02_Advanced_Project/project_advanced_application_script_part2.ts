/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script_part2.ts
// Description: Advanced Application Script
// ==========================================

/**
 * Node 1: Chunking
 * Splits raw text into overlapping chunks for better context retention.
 */
const chunkNode = async (state: AppState): Promise<Partial<AppState>> => {
  console.log(`[Node] Chunking document: ${state.documentId}`);
  
  const text = state.rawText;
  const chunks: string[] = [];
  
  // Simple text splitter logic
  for (let i = 0; i < text.length; i += CONFIG.CHUNK_SIZE - CONFIG.OVERLAP) {
    const chunk = text.substring(i, i + CONFIG.CHUNK_SIZE);
    chunks.push(chunk);
  }

  return {
    chunks,
    status: "chunked",
  };
};

/**
 * Node 2: Embedding
 * Generates vector embeddings for each text chunk using OpenAI.
 */
const embedNode = async (state: AppState): Promise<Partial<AppState>> => {
  if (!state.chunks || state.chunks.length === 0) {
    throw new Error("No chunks found to embed.");
  }

  console.log(`[Node] Generating embeddings for ${state.chunks.length} chunks...`);
  
  const embeddings = new OpenAIEmbeddings({
    model: CONFIG.OPENAI_MODEL,
  });

  try {
    // Generate vectors (this is an async operation)
    const vectors = await embeddings.embedDocuments(state.chunks);
    
    return {
      vectors,
      status: "embedded",
    };
  } catch (error) {
    console.error("Embedding failed:", error);
    return { status: "error" };
  }
};

/**
 * Node 3: Storage
 * Inserts data into Supabase PostgreSQL with pgvector.
 * Note: This assumes a table named 'document_chunks' with a 'embedding' column of type vector(1536).
 */
const storeNode = async (state: AppState): Promise<Partial<AppState>> => {
  if (!state.vectors || state.vectors.length === 0) {
    throw new Error("No vectors found to store.");
  }

  console.log(`[Node] Storing ${state.vectors.length} vectors in Supabase...`);

  // Mock Supabase Client Interaction
  // In production: import { createClient } from '@supabase/supabase-js'
  const supabaseMock = {
    from: (table: string) => ({
      insert: async (data: any[]) => {
        console.log(`[DB] Inserting into ${table}:`, data.length, "rows");
        // Simulate DB latency
        await new Promise(r => setTimeout(r, 500));
        return { error: null }; 
      }
    })
  };

  const dataToInsert = state.chunks.map((chunk, index) => ({
    document_id: state.documentId,
    content: chunk,
    embedding: state.vectors[index], // pgvector accepts arrays directly
  }));

  // Execute insert
  const { error } = await supabaseMock.from("document_chunks").insert(dataToInsert);

  if (error) {
    console.error("Storage failed:", error);
    return { status: "error" };
  }

  return { status: "stored" };
};
