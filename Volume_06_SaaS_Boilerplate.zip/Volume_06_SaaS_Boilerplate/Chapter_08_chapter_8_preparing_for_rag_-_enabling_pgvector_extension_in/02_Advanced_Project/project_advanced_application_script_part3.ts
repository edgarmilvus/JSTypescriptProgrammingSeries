/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script_part3.ts
// Description: Advanced Application Script
// ==========================================

/**
 * Conditional Edge: Router
 * Inspects the state status to determine the execution path.
 * @param {AppState} state - The current graph state.
 * @returns {string} - The name of the next node or 'END'.
 */
const routeDocument = (state: AppState): string => {
  switch (state.status) {
    case "pending":
      return "chunkNode";
    case "chunked":
      return "embedNode";
    case "embedded":
      return "storeNode";
    case "stored":
      console.log("✅ Pipeline Complete: Document is RAG-ready.");
      return END;
    case "error":
      console.error("❌ Pipeline Failed: Stopping execution.");
      return END;
    default:
      return END;
  }
};

/**
 * Initializes and compiles the LangGraph pipeline.
 */
export const createRAGPipeline = () => {
  const workflow = new StateGraph<AppState>({
    channels: {
      documentId: { value: null },
      rawText: { value: null },
      chunks: { value: null },
      vectors: { value: null },
      status: { value: "pending" },
    },
  });

  // Define nodes
  workflow.addNode("chunkNode", chunkNode);
  workflow.addNode("embedNode", embedNode);
  workflow.addNode("storeNode", storeNode);

  // Define conditional edges
  // We use a single starting point and route dynamically based on state
  workflow.addConditionalEdges(
    "chunkNode", // Source node (or we can use a virtual start node)
    routeDocument
  );
  
  // Ensure the graph knows where to start
  workflow.setEntryPoint("chunkNode"); // In a real app, this might be a 'start' node

  return workflow.compile({ checkpointer });
};
