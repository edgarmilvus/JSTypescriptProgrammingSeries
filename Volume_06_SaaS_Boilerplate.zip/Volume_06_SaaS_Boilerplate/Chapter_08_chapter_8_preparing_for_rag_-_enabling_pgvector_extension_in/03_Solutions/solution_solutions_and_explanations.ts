/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

import { SupabaseClient } from '@supabase/supabase-js';

// 1. Define the TypeScript interface for type safety
export interface DocumentChunk {
  id?: string; // Optional for insertion, required for retrieval
  content: string;
  embedding: number[]; // Array of numbers matching vector dimension
  metadata: Record<string, any>; // Flexible JSON object
}

// 2. Function to check if pgvector extension is installed and enabled
export async function checkPgVectorExtension(supabase: SupabaseClient): Promise<boolean> {
  // We query the pg_available_extensions catalog to check for 'vector'
  const { data, error } = await supabase
    .rpc('check_extension_exists', { ext_name: 'vector' }); 
  // Note: You might need to create this RPC function or use raw SQL if you have admin access.
  // Alternatively, try creating a vector type to test availability (will fail if extension missing).
  
  if (error) {
    console.error("Error checking extension:", error);
    return false;
  }
  
  // If using a direct SQL query via `supabase.rpc` that returns a boolean or row count:
  return !!data; 
}

// 3. SQL Schema for creating the table (to be executed via Supabase SQL Editor or Migration)
export const CREATE_DOCUMENT_CHUNKS_TABLE_SQL = `
  -- Enable the extension if not already enabled
  CREATE EXTENSION IF NOT EXISTS vector;

  -- Create the table
  CREATE TABLE IF NOT EXISTS document_chunks (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    content TEXT NOT NULL,
    embedding vector(1536) NOT NULL, -- 1536 dimensions for text-embedding-ada-002
    metadata JSONB
  );
`;
