/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

import { SupabaseClient } from '@supabase/supabase-js';
import { DocumentChunk } from './exercise-1'; // Assuming previous interface is imported

// 1. Batch Insertion Function
export async function insertChunks(
  supabase: SupabaseClient, 
  chunks: Omit<DocumentChunk, 'id'>[]
): Promise<{ error: any | null }> {
  // The Supabase client handles JSON array insertion automatically
  const { error } = await supabase
    .from('document_chunks')
    .insert(chunks);

  return { error };
}

// 2. Similarity Search Function
export async function semanticSearch(
  supabase: SupabaseClient,
  queryEmbedding: number[],
  filterMetadata?: { key: string; value: string } // Optional for later exercises
): Promise<{ data: (DocumentChunk & { similarity: number })[] | null; error: any | null }> {
  
  // Construct the query using PostgREST syntax or RPC for complex SQL
  // Using RPC is often cleaner for custom SQL logic, but we can use the query builder for this.
  // Note: PostgREST v10+ supports vector operations directly.
  
  let query = supabase
    .from('document_chunks')
    .select('id, content, metadata, embedding, similarity: embedding <=> $1', {
      count: 'exact'
    })
    .order('similarity', { ascending: true }) // Cosine distance: 0 is identical, 2 is opposite
    .limit(3);

  // Add the embedding parameter
  query = query.eq('embedding', queryEmbedding); // This syntax depends on supabase-js version support for vectors
  // Alternatively, use a raw RPC call for guaranteed compatibility:
  
  const { data, error } = await supabase.rpc('match_documents', {
    query_embedding: queryEmbedding,
    match_threshold: 0.0, // Optional: Filter out low similarity
    match_count: 3
  });

  return { data, error };
}

// SQL for RPC Function (match_documents) required for the search above:
/*
CREATE OR REPLACE FUNCTION match_documents(
  query_embedding vector(1536),
  match_threshold float,
  match_count int
)
RETURNS TABLE (
  id UUID,
  content text,
  metadata jsonb,
  similarity float
)
LANGUAGE plpgsql
AS $$
BEGIN
  RETURN query
  SELECT 
    dc.id,
    dc.content,
    dc.metadata,
    1 - (dc.embedding <=> query_embedding) AS similarity
  FROM document_chunks dc
  WHERE 1 - (dc.embedding <=> query_embedding) > match_threshold
  ORDER BY dc.embedding <=> query_embedding
  LIMIT match_count;
END;
$$;
*/
