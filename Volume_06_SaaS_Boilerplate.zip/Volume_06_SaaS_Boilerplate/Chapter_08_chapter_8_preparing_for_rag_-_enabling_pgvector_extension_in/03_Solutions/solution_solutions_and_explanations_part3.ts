/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

import { SupabaseClient } from '@supabase/supabase-js';

// 1. SQL for Index Creation (Idempotent)
export const CREATE_HNSW_INDEX_SQL = `
  CREATE INDEX IF NOT EXISTS document_chunks_embedding_idx 
  ON document_chunks 
  USING hnsw (embedding vector_cosine_ops);
`;

// 2. Function to Explain Search Query
export async function explainSearchQuery(
  supabase: SupabaseClient,
  queryEmbedding: number[]
): Promise<{ data: any | null; error: any | null }> {
  
  // We use a raw SQL query via supabase.rpc or supabase.query to run EXPLAIN ANALYZE
  // Note: Supabase RPC is the safest way to run complex SQL commands like EXPLAIN.
  
  const { data, error } = await supabase.rpc('explain_match_documents', {
    query_embedding: queryEmbedding
  });

  return { data, error };
}

// SQL for RPC Function (explain_match_documents) required for the analysis above:
/*
CREATE OR REPLACE FUNCTION explain_match_documents(query_embedding vector(1536))
RETURNS TABLE (explain_plan text)
LANGUAGE plpgsql
AS $$
BEGIN
  RETURN QUERY
  EXPLAIN ANALYZE
  SELECT id, content, metadata
  FROM document_chunks
  ORDER BY embedding <=> query_embedding
  LIMIT 3;
END;
$$;
*/

// 3. Optimization Analysis (Comment in code or documentation)
/*
  When analyzing the EXPLAIN ANALYZE output, look for the following indicators of effective indexing:
  
  1.  **Index Scan vs. Seq Scan**: The output should explicitly say "Index Scan using document_chunks_embedding_idx" 
      or "Index Scan using..." instead of "Seq Scan on document_chunks".
  
  2.  **Execution Time**: Look for a significantly lower "Execution Time" (in milliseconds) compared to 
      the execution time before the index was created.
      
  3.  **Rows Removed by Filter**: With a proper index, the database should not need to load all rows 
      into memory to sort them. The "Planning Time" might increase slightly (as the planner calculates 
      the index usage), but "Execution Time" should drop drastically.
      
  4.  **Vector Operators**: Ensure the plan utilizes the `<=>` operator efficiently. The HNSW index 
      specifically accelerates the `ORDER BY ... <=>` clause.
*/
