/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState } from 'react';
import { SupabaseClient } from '@supabase/supabase-js';
import { semanticSearch } from './exercise-2'; // Import the search logic
import { DocumentChunk } from './exercise-1';

// Mock function to simulate embedding generation (since we don't have a real AI model in the browser)
const generateMockEmbedding = (text: string): number[] => {
  // Returns a random vector of 1536 dimensions for demonstration
  return Array.from({ length: 1536 }, () => Math.random());
};

interface VectorSearchUIProps {
  supabase: SupabaseClient;
}

export const VectorSearchUI: React.FC<VectorSearchUIProps> = ({ supabase }) => {
  const [query, setQuery] = useState('');
  const [filterSource, setFilterSource] = useState('');
  const [results, setResults] = useState<(DocumentChunk & { similarity: number })[]>([]);
  const [loading, setLoading] = useState(false);

  const handleSearch = async () => {
    if (!query.trim()) return;

    setLoading(true);
    
    // 1. Simulate embedding generation
    const embedding = generateMockEmbedding(query);

    // 2. Call the semantic search function
    // Note: We need to update semanticSearch to accept metadata filters or use a new function.
    // For this example, we will assume we modified semanticSearch or use a direct query.
    // Here is a direct implementation for the component context:
    
    let searchQuery = supabase
      .from('document_chunks')
      .select('id, content, metadata, similarity: embedding <=> $1', { count: 'exact' })
      .order('similarity', { ascending: true })
      .limit(5)
      .eq('embedding', embedding);

    // Apply Metadata Filter if present
    if (filterSource) {
      // PostgREST allows filtering JSONB fields using ->> (string extraction)
      searchQuery = searchQuery.filter('metadata->>source', 'eq', filterSource);
    }

    const { data, error } = await searchQuery;

    if (error) {
      console.error(error);
      setResults([]);
    } else {
      // PostgREST returns distance as 'similarity' (mapped in select), but it's actually distance.
      // We convert distance to similarity score (1 - distance) for display if needed, 
      // or just display the distance (lower is better).
      // Let's keep it as raw distance for clarity (0 is perfect match).
      setResults(data || []);
    }

    setLoading(false);
  };

  return (
    <div className="vector-search-ui">
      <h3>Smart Document Search</h3>
      
      <div className="search-controls">
        <input
          type="text"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Enter your query..."
          disabled={loading}
        />
        <input
          type="text"
          value={filterSource}
          onChange={(e) => setFilterSource(e.target.value)}
          placeholder="Filter by Source (e.g., 'manual.pdf')"
          disabled={loading}
        />
        <button onClick={handleSearch} disabled={loading}>
          {loading ? 'Searching...' : 'Search'}
        </button>
      </div>

      <div className="results-list">
        {results.length === 0 && !loading && <p>No results found.</p>}
        {results.map((result) => (
          <div key={result.id} className="result-item" style={{ border: '1px solid #ccc', margin: '5px', padding: '10px' }}>
            <p><strong>Content:</strong> {result.content}</p>
            <p><strong>Source:</strong> {result.metadata?.source || 'Unknown'}</p>
            <p><strong>Distance:</strong> {result.similarity.toFixed(4)} (Lower is better)</p>
          </div>
        ))}
      </div>
    </div>
  );
};
