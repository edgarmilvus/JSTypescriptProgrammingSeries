/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

import { SupabaseClient } from '@supabase/supabase-js';

// 1. SQL Schema Update for Hybrid Search
export const UPDATE_SCHEMA_HYBRID_SQL = `
  -- Add a generated tsvector column
  ALTER TABLE document_chunks 
  ADD COLUMN content_tsvector tsvector 
  GENERATED ALWAYS AS (to_tsvector('english', content)) STORED;

  -- Create a GIN index on the tsvector column for fast full-text search
  CREATE INDEX IF NOT EXISTS document_chunks_tsvector_idx 
  ON document_chunks 
  USING GIN (content_tsvector);
`;

// 2. TypeScript Function for Hybrid Search
export async function hybridSearch(
  supabase: SupabaseClient,
  textQuery: string,
  queryEmbedding: number[],
  weights: { semantic: number; fullText: number } = { semantic: 0.7, fullText: 0.3 }
): Promise<{ data: any[] | null; error: any | null }> {

  // We use an RPC function to handle the complex SQL logic safely
  const { data, error } = await supabase.rpc('hybrid_search_rpc', {
    text_query: textQuery, // Used for full-text search
    query_embedding: queryEmbedding, // Used for vector search
    w_semantic: weights.semantic,
    w_fulltext: weights.fullText
  });

  return { data, error };
}

// SQL for RPC Function (hybrid_search_rpc) required for the search above:
/*
CREATE OR REPLACE FUNCTION hybrid_search_rpc(
  text_query text,
  query_embedding vector(1536),
  w_semantic float,
  w_fulltext float
)
RETURNS TABLE (
  id UUID,
  content text,
  metadata jsonb,
  combined_score float
)
LANGUAGE plpgsql
AS $$
BEGIN
  RETURN query
  SELECT 
    dc.id,
    dc.content,
    dc.metadata,
    -- Weighted sum: 
    -- 1. Vector Similarity (1 - distance) normalized roughly to 0-1
    -- 2. Full Text Rank (ts_rank) normalized by dividing by max possible rank or fixed divisor
    (w_semantic * (1 - (dc.embedding <=> query_embedding))) + 
    (w_fulltext * ts_rank(dc.content_tsvector, websearch_to_tsquery('english', text_query))) 
    AS combined_score
  FROM document_chunks dc
  WHERE dc.content_tsvector @@ websearch_to_tsquery('english', text_query) -- Filter by text match first
     OR (dc.embedding <=> query_embedding) < 1.5 -- Optional: Broad vector filter
  ORDER BY combined_score DESC
  LIMIT 5;
END;
$$;
*/

// 3. Safe Parameterization Note:
/*
  The Supabase `.rpc()` method automatically handles parameterization, preventing SQL injection.
  It maps the TypeScript arguments (text_query, query_embedding) to the PostgreSQL function arguments
  securely. We avoid concatenating strings directly into the SQL query, which is the primary vector
  for injection attacks.
*/
