/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

// Import necessary SDKs
import { createClient, SupabaseClient } from '@supabase/supabase-js';
import { Database } from './database.types'; // Assume generated types exist

// 1. CONFIGURATION
// Initialize Supabase client with the Project URL and anon key.
// In a real app, these come from environment variables.
const SUPABASE_URL = process.env.SUPABASE_URL!;
const SUPABASE_ANON_KEY = process.env.SUPABASE_ANON_KEY!;

const supabase: SupabaseClient<Database> = createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

/**
 * Performs a secure vector similarity search.
 * 
 * @param userToken - The JWT access token retrieved from the client's auth session.
 * @param queryText - The natural language text to search for.
 * @returns A promise resolving to matching rows, or throws an error if unauthorized.
 */
export async function secureVectorSearch(userToken: string, queryText: string) {
    
    // 2. AUTHENTICATION CONTEXT
    // We must set the Auth context for the database session.
    // This allows the RLS policy to access `auth.uid()` (the current user's ID).
    supabase.auth.setAuth(userToken);

    // 3. MOCK EMBEDDING GENERATION
    // In production, this calls an AI model (e.g., OpenAI 'text-embedding-ada-002').
    // We return a fixed array here for demonstration.
    // Format: [0.1, 0.2, ...]
    const embedding: number[] = await generateMockEmbedding(queryText);

    // 4. SECURE QUERY EXECUTION
    // This is the critical SQL operation.
    // Note: We do NOT pass a user_id filter manually. The DB handles it via RLS.
    // The query compares the provided embedding against the 'content_embedding' column.
    const { data: matches, error } = await supabase
        .rpc('match_documents', { // Using a Database Function (RPC)
            query_embedding: embedding,
            match_threshold: 0.7, // Cosine similarity threshold
            match_count: 5        // Limit results
        });

    // 5. ERROR HANDLING
    if (error) {
        console.error("Vector Search Error:", error);
        // If the error is a 403 (Forbidden), the user is likely trying to access 
        // data that RLS blocked. Do not leak DB structure details to the client.
        if (error.code === '42501' || error.status === 403) {
            throw new Error("Unauthorized: You do not have permission to view these records.");
        }
        throw new Error("Database query failed.");
    }

    return matches;
}

/**
 * Mock function to simulate an AI Embedding API call.
 * Replaces real OpenAI or Cohere calls.
 */
async function generateMockEmbedding(text: string): Promise<number[]> {
    // Simulate async network delay
    await new Promise(r => setTimeout(r, 100));
    
    // Return a dummy 1536-dimension vector (standard for OpenAI)
    // In reality, the numbers vary based on the text content.
    return Array(1536).fill(0).map((_, i) => (text.length + i) % 10 * 0.1);
}
