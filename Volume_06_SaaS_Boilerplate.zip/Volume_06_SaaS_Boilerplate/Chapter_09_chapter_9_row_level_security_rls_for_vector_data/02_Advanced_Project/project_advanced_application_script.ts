/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// pages/api/search.ts (or app/api/search/route.ts in Next.js App Router)
import type { NextApiRequest, NextApiResponse } from 'next';
import { Pool } from 'pg';
import { v4 as uuidv4 } from 'uuid';

// ==========================================
// 1. CONFIGURATION & TYPES
// ==========================================

/**
 * Configuration for the database connection.
 * In production, these should be loaded from environment variables.
 */
const dbConfig = {
  host: process.env.DB_HOST,
  port: Number(process.env.DB_PORT) || 5432,
  database: process.env.DB_NAME,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  ssl: { rejectUnauthorized: false }, // Required for many cloud providers
};

/**
 * Type definition for the request body.
 * Expects a query string and assumes the user is authenticated via session/JWT.
 */
interface SearchRequest {
  query: string;
}

/**
 * Type definition for a document chunk returned from the database.
 */
interface DocumentChunk {
  id: string;
  content: string;
  similarity: number; // Calculated by the database (e.g., 1 - cosine distance)
}

// Initialize PostgreSQL Pool
const pool = new Pool(dbConfig);

// ==========================================
// 2. ASYNC EMBEDDING GENERATION (MOCK)
// ==========================================

/**
 * Mocks an external AI service call to generate a vector embedding.
 * In a real application, this would call an API like OpenAI's embedding endpoint.
 * 
 * @param text - The text to embed
 * @returns A Promise resolving to a float array (vector)
 */
async function generateEmbedding(text: string): Promise<number[]> {
  // Simulating network delay
  await new Promise(resolve => setTimeout(resolve, 100));
  
  // In reality: const response = await openai.createEmbedding({ model: 'text-embedding-ada-002', input: text });
  // Returning a dummy 1536-dimension vector for demonstration
  return Array(1536).fill(0).map((_, i) => (text.length + i) % 100 / 100);
}

// ==========================================
// 3. THE API HANDLER
// ==========================================

/**
 * Next.js API Route Handler for Secure Vector Search.
 * 
 * Security Features:
 * 1. RLS Enforcement: The SQL query relies on the database's RLS policy to filter rows by user_id.
 * 2. Async Processing: Uses async/await for non-blocking I/O during embedding generation and DB queries.
 * 3. Immutable State: Uses functional patterns to construct the SQL query safely.
 * 
 * @param req - NextApiRequest
 * @param res - NextApiResponse
 */
export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  // Only allow POST requests
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method Not Allowed' });
  }

  // Extract user ID from the authentication context (e.g., JWT token, NextAuth session)
  // For this example, we simulate a user ID extracted from a secure header or session.
  const userId = req.headers['x-user-id'] as string; 

  if (!userId) {
    return res.status(401).json({ error: 'Unauthorized: Missing User ID' });
  }

  const { query } = req.body as SearchRequest;

  if (!query || typeof query !== 'string') {
    return res.status(400).json({ error: 'Bad Request: Invalid query' });
  }

  let client;
  try {
    // Acquire a database client connection
    client = await pool.connect();

    // Step 1: Generate the vector embedding for the user's query
    // This is an asynchronous operation (I/O bound)
    const queryVector = await generateEmbedding(query);

    // Step 2: Construct the SQL Query
    // CRITICAL: Notice we do NOT filter by user_id in the WHERE clause.
    // Instead, we rely on the database's Row Level Security policy attached to the table.
    // The RLS policy automatically appends `WHERE user_id = 'authenticated_user_id'`.
    // We pass the authenticated user ID via the session variable `app.current_user_id`.
    
    const searchQuery = `
      SET app.current_user_id = $1;
      
      SELECT 
        id, 
        content, 
        1 - (embedding <=> $2::vector) AS similarity
      FROM document_chunks
      WHERE 1 - (embedding <=> $2::vector) > 0.7 -- Filter by similarity threshold
      ORDER BY similarity DESC
      LIMIT 5;
    `;

    // Step 3: Execute the query
    // We use parameterized queries to prevent SQL injection.
    // The vector is passed as a stringified array format compatible with pgvector.
    const vectorString = `[${queryVector.join(',')}]`;
    
    const result = await client.query(searchQuery, [userId, vectorString]);

    // Step 4: Process results (Immutable State Management)
    // Map the database rows to a clean response object.
    const results: DocumentChunk[] = result.rows.map((row) => ({
      id: row.id,
      content: row.content,
      similarity: parseFloat(row.similarity),
    }));

    // Return the secure results
    res.status(200).json({ results });

  } catch (error) {
    console.error('Search error:', error);
    res.status(500).json({ error: 'Internal Server Error' });
  } finally {
    // Ensure the client is released back to the pool
    if (client) client.release();
  }
}
