/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

import { createClient } from '@supabase/supabase-js';

export async function fetchRelevantContext(queryEmbedding: number[]) {
  // 1. Initialize Supabase client
  // Note: In a real Server Component, we would typically use cookies() to get the user's session.
  // For this example, we assume the client is initialized with the user's auth token.
  const supabase = createClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY! // Use anon key to enforce RLS
  );

  // 2. Validate input
  if (!Array.isArray(queryEmbedding) || queryEmbedding.length === 0) {
    throw new Error("Invalid query embedding provided.");
  }

  // 3. Perform the vector search
  // The RLS policy on 'documents' (user_id = auth.uid()) is automatically applied by Supabase
  // because we are using the authenticated client (anon key).
  const { data, error } = await supabase
    .from('documents')
    .select('id, content')
    .order('embedding', { 
      // Use the pgvector cosine distance operator (<=>) for similarity
      // Note: Supabase JS client syntax might vary for custom operators. 
      // Often, raw SQL is preferred for complex vector ops, or specific RPC functions.
      // Here we use a standard order on a computed column or rely on RPC for strict <-> syntax.
      // Assuming a setup where the client handles vector order:
      ascending: true, 
      // In a direct SQL query, this would be: ORDER BY embedding <-> '[...]'
    })
    // Simulating the distance filter logic (often done inside the query or RPC)
    .limit(5);

  if (error) {
    throw new Error(`Database error: ${error.message}`);
  }

  return data;
}
