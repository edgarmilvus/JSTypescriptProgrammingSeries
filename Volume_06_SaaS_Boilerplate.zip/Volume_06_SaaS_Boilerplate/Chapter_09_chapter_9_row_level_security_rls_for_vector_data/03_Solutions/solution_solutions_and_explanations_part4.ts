/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

import { z } from 'zod';
import { createClient } from '@supabase/supabase-js';

// 1. Zod Schema for Search Request
const searchSchema = z.object({
  query_embedding: z.array(z.number().float()).min(1),
  filters: z.record(z.string(), z.any()).optional(), // e.g., { category: 'finance', status: 'active' }
});

type SearchInput = z.infer<typeof searchSchema>;

// 2. Secure Vector Search Function
export async function secureVectorSearch(input: SearchInput) {
  // Validate input
  const parsed = searchSchema.safeParse(input);
  if (!parsed.success) {
    throw new Error(`Validation failed: ${JSON.stringify(parsed.error.errors)}`);
  }

  const { query_embedding, filters } = parsed.data;

  const supabase = createClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
  );

  // 3. Construct Query
  // We use a PostgreSQL function (RPC) for complex vector operations to ensure security and performance.
  // Alternatively, we can use the JS client's filtering capabilities.
  
  let query = supabase
    .from('documents')
    .select('id, content, category') // Select fields
    .order('embedding', { 
        // Note: In standard SQL: ORDER BY embedding <-> 'query_embedding' 
        // This requires a specific RPC setup or handling in Supabase SQL functions.
        // Here we assume the client handles the distance calculation or we rely on a pre-defined RPC.
        // For this example, we will filter by metadata first.
    })
    .limit(5);

  // Apply metadata filters dynamically
  if (filters) {
    for (const [key, value] of Object.entries(filters)) {
      query = query.eq(key, value); // or .gt, .lt, etc. based on filter type
    }
  }

  // Execute
  const { data, error } = await query;

  if (error) throw new Error(`Search failed: ${error.message}`);
  
  // In a real scenario, the vector distance calculation happens in the DB.
  // If using standard JS client without RPC, we might need to post-process or 
  // ensure the DB view handles the <-> operator.
  return data;
}
