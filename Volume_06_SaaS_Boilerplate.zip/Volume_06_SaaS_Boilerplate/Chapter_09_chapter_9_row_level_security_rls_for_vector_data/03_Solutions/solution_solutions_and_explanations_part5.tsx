/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState } from 'react';

// Define the shape of the document result
interface DocumentResult {
  id: string;
  content: string;
}

export default function SecureDocumentRetriever() {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<DocumentResult[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSearch = async () => {
    if (!query.trim()) return;

    setIsLoading(true);
    setError(null);
    setResults([]);

    try {
      // 1. Convert text to embedding via hypothetical API endpoint
      const embedResponse = await fetch('/api/embed', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text: query }),
      });

      if (!embedResponse.ok) throw new Error('Failed to generate embedding.');
      
      const { embedding } = await embedResponse.json();

      // 2. Call secure search API (which uses the logic from Exercise 3)
      const searchResponse = await fetch('/api/search', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
            query_embedding: embedding,
            filters: {} // Optional metadata filters could be added here
        }),
      });

      if (!searchResponse.ok) throw new Error('Search failed. Ensure you are logged in.');

      const data = await searchResponse.json();
      
      // 3. Update state
      setResults(data || []);

    } catch (err: any) {
      // Security Note: We log a generic error to the UI to avoid leaking system details
      console.error(err);
      setError('An error occurred while fetching documents. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div style={{ padding: '20px', maxWidth: '600px', margin: '0 auto' }}>
      <h2>Secure Document Retriever</h2>
      
      <div style={{ marginBottom: '10px' }}>
        <input
          type="text"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Enter your query..."
          style={{ width: '70%', padding: '8px', marginRight: '10px' }}
        />
        <button onClick={handleSearch} disabled={isLoading} style={{ padding: '8px 16px' }}>
          {isLoading ? 'Searching...' : 'Search'}
        </button>
      </div>

      {error && <div style={{ color: 'red', marginBottom: '10px' }}>{error}</div>}

      <div>
        {results.length > 0 ? (
          results.map((doc) => (
            <div key={doc.id} style={{ border: '1px solid #ccc', padding: '10px', marginBottom: '10px' }}>
              <strong>Doc ID: {doc.id}</strong>
              <p>{doc.content}</p>
            </div>
          ))
        ) : (
          !isLoading && <p>No documents found.</p>
        )}
      </div>
    </div>
  );
}
