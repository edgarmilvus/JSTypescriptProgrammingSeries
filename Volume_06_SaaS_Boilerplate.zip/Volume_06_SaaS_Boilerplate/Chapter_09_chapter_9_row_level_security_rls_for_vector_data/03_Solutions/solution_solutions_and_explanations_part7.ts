/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part7.ts
// Description: Solutions and Explanations
// ==========================================

-- Assuming the database session is set with the user ID (e.g., SET app.current_user_id = '...')
-- RLS Policy on documents: CREATE POLICY ... USING (user_id = current_setting('app.current_user_id')::uuid);

-- 1. Optimize by limiting the search space or using the index implicitly
-- 2. Ensure the subquery on 'queries' also respects RLS if needed
-- 3. Use a CTE or direct filtering to ensure user isolation is explicit in the logic if RLS is bypassed (not recommended, but for debugging)

-- Corrected Query (assuming RLS is active on both tables):
SELECT id, content, embedding
FROM documents
-- The RLS policy on 'documents' automatically filters rows here
WHERE embedding <=> (SELECT embedding FROM queries WHERE id = 1) < 0.5
ORDER BY embedding <=> (SELECT embedding FROM queries WHERE id = 1)
LIMIT 10;

-- If RLS is not working due to context issues, you must manually filter:
SELECT id, content, embedding
FROM documents
WHERE user_id = auth.uid() -- Explicit check if RLS is disabled/bypassed
  AND embedding <=> (SELECT embedding FROM queries WHERE id = 1) < 0.5
ORDER BY embedding <=> (SELECT embedding FROM queries WHERE id = 1)
LIMIT 10;
