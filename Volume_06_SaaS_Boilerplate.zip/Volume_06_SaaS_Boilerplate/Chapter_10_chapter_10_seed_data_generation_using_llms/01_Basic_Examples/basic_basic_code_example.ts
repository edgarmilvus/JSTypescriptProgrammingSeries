/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * @file seed.ts
 * @description A self-contained script to generate relational seed data using LLMs.
 *              Simulates a SaaS boilerplate with User and Profile tables.
 *              Uses OpenAI's GPT-4o-mini for structured data generation.
 */

// --- IMPORTS ---
import OpenAI from 'openai';

// --- CONFIGURATION ---
// In a real app, load from environment variables (e.g., process.env.OPENAI_API_KEY)
const OPENAI_API_KEY = 'sk-...'; // Placeholder: Replace with a real key for execution
const openai = new OpenAI({ apiKey: OPENAI_API_KEY });

// --- TYPE DEFINITIONS ---
/**
 * Represents a User entity in the SaaS database.
 * @property id - Unique identifier (UUID string).
 * @property email - User's email address.
 * @property name - User's full name.
 */
type User = {
  id: string;
  email: string;
  name: string;
};

/**
 * Represents a Profile entity linked to a User.
 * @property id - Unique identifier (UUID string).
 * @property userId - Foreign key referencing User.id.
 * @property bio - User's biography text.
 * @property avatarUrl - URL to a placeholder avatar image.
 */
type Profile = {
  id: string;
  userId: string; // Foreign key for referential integrity
  bio: string;
  avatarUrl: string;
};

/**
 * Structured JSON response format for LLM generation.
 * Enforces a schema to ensure reliable parsing.
 */
type LLMResponse<T> = {
  data: T[];
};

// --- HELPER FUNCTIONS ---

/**
 * Generates a list of synthetic users using an LLM.
 * The prompt is engineered to produce structured JSON matching the `User` type.
 * @param count - Number of users to generate.
 * @returns A Promise resolving to an array of User objects.
 */
async function generateUsers(count: number): Promise<User[]> {
  const prompt = `
    You are a data generator for a SaaS application.
    Generate ${count} unique, realistic user records.
    Return ONLY valid JSON, no markdown code blocks.
    The JSON must be an object with a "data" key, containing an array of users.
    Each user must have: "id" (UUID v4 string), "email" (realistic), "name" (full name).
    Example: { "data": [{ "id": "123e4567-e89b-12d3-a456-426614174000", "email": "user@example.com", "name": "John Doe" }] }
  `;

  const response = await openai.chat.completions.create({
    model: 'gpt-4o-mini',
    messages: [
      { role: 'system', content: 'You are a structured JSON data generator.' },
      { role: 'user', content: prompt },
    ],
    response_format: { type: 'json_object' }, // Enforce JSON output
    temperature: 0.7, // Introduce some variability
  });

  const content = response.choices[0].message.content;
  if (!content) throw new Error('LLM returned empty content for users.');

  const parsed = JSON.parse(content) as LLMResponse<User>;
  return parsed.data;
}

/**
 * Generates profiles for existing users, enforcing referential integrity.
 * The LLM is given the list of users to ensure profile.userId matches a real user.id.
 * @param users - Array of existing users to generate profiles for.
 * @returns A Promise resolving to an array of Profile objects.
 */
async function generateProfiles(users: User[]): Promise<Profile[]> {
  const userContext = JSON.stringify(users, null, 2);
  const prompt = `
    You are a data generator for a SaaS application.
    Generate a profile for EACH user in the provided list.
    Return ONLY valid JSON, no markdown code blocks.
    The JSON must be an object with a "data" key, containing an array of profiles.
    For each user, create a profile with:
      - "id": A new UUID v4 string.
      - "userId": MUST be the exact "id" of the user from the input list. This is critical for database integrity.
      - "bio": A short, realistic biography (1-2 sentences).
      - "avatarUrl": A placeholder image URL (e.g., from https://api.dicebear.com).
    Input Users:
    ${userContext}
  `;

  const response = await openai.chat.completions.create({
    model: 'gpt-4o-mini',
    messages: [
      { role: 'system', content: 'You are a structured JSON data generator.' },
      { role: 'user', content: prompt },
    ],
    response_format: { type: 'json_object' },
    temperature: 0.7,
  });

  const content = response.choices[0].message.content;
  if (!content) throw new Error('LLM returned empty content for profiles.');

  const parsed = JSON.parse(content) as LLMResponse<Profile>;
  return parsed.data;
}

/**
 * Simulates an upsert operation into a database.
 * In a real SaaS boilerplate, this would use an ORM like Prisma or Drizzle.
 * @param users - Array of users to seed.
 * @param profiles - Array of profiles to seed.
 */
async function seedDatabase(users: User[], profiles: Profile[]): Promise<void> {
  console.log('--- SEEDING DATABASE ---');
  
  // Simulate User Upsert
  console.log(`Seeding ${users.length} users...`);
  for (const user of users) {
    // In a real app: await prisma.user.upsert({ where: { id: user.id }, update: user, create: user });
    console.log(`  [USER] ID: ${user.id} | Email: ${user.email} | Name: ${user.name}`);
  }

  // Simulate Profile Upsert
  console.log(`Seeding ${profiles.length} profiles...`);
  for (const profile of profiles) {
    // In a real app: await prisma.profile.upsert({ where: { id: profile.id }, update: profile, create: profile });
    console.log(`  [PROFILE] ID: ${profile.id} | User: ${profile.userId} | Bio: ${profile.bio.substring(0, 30)}...`);
  }

  console.log('--- SEEDING COMPLETE ---');
}

// --- MAIN EXECUTION LOGIC ---

/**
 * Orchestrates the seed data generation pipeline.
 * 1. Generates users.
 * 2. Generates profiles linked to users.
 * 3. Seeds the simulated database.
 */
async function main() {
  try {
    console.log('Starting seed data generation...');
    
    const USER_COUNT = 3; // Small number for "Hello World" demonstration
    
    // Step 1: Generate Users
    const users = await generateUsers(USER_COUNT);
    
    // Step 2: Generate Profiles (with referential integrity)
    const profiles = await generateProfiles(users);
    
    // Step 3: Seed Database
    await seedDatabase(users, profiles);
    
  } catch (error) {
    console.error('Error during seed generation:', error);
    // In a real SaaS app, this should trigger alerts or logging (e.g., Sentry)
  }
}

// Execute if run directly
if (require.main === module) {
  // Check for API Key warning
  if (OPENAI_API_KEY === 'sk-...') {
    console.warn('WARNING: OPENAI_API_KEY is not set. The script will fail if executed.');
    console.warn('Please set the OPENAI_API_KEY environment variable or update the placeholder.');
  }
  main();
}

export { generateUsers, generateProfiles, seedDatabase };
