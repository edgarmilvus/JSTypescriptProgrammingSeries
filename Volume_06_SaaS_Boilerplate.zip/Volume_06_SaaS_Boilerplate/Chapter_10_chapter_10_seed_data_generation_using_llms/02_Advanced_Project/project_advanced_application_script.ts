/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

/**
 * advanced-seed-script.ts
 * 
 * A robust TypeScript script for seeding a SaaS database with relational data
 * and generating corresponding vector embeddings for semantic search.
 * 
 * Target: Next.js API Route or standalone Node.js script.
 * Dependencies: Prisma (ORM), Pinecone (Vector DB), OpenAI (LLM).
 */

// ============================================================================
// 1. MOCKED DEPENDENCIES & TYPES
// In a real implementation, import these from your project's node_modules.
// ============================================================================

// Mock Prisma Client (Represents your ORM)
const prisma = {
  user: { findMany: async () => [], create: async (data: any) => ({ id: `u_${Math.random().toString(36).substr(2, 9)}`, ...data }) },
  project: { create: async (data: any) => ({ id: `p_${Math.random().toString(36).substr(2, 9)}`, ...data }) },
  task: { create: async (data: any) => ({ id: `t_${Math.random().toString(36).substr(2, 9)}`, ...data }) },
  document: { create: async (data: any) => ({ id: `d_${Math.random().toString(36).substr(2, 9)}`, ...data }) },
};

// Mock Pinecone Client (Represents Vector DB)
const pinecone = {
  index: (indexName: string) => ({
    namespace: (ns: string) => ({
      upsert: async (vectors: Array<{ id: string; values: number[]; metadata: any }>) => {
        console.log(`[Pinecone] Upserting ${vectors.length} vectors into namespace '${ns}'`);
        return { success: true };
      },
    }),
  }),
};

// Mock OpenAI Client (Represents LLM)
const openai = {
  chat: {
    completions: {
      create: async (params: any) => {
        // Simulating LLM response for structured data generation
        if (params.messages[0].content.includes("Generate 3 project names")) {
          return {
            choices: [{
              message: {
                content: JSON.stringify([
                  { name: "Website Redesign", description: "Overhaul the main marketing site." },
                  { name: "Mobile App V2", description: "New features for iOS and Android." },
                  { name: "Backend Migration", description: "Move from monolith to microservices." }
                ])
              }
            }]
          };
        }
        // Simulating LLM response for document content generation
        if (params.messages[0].content.includes("Generate a technical document")) {
          return {
            choices: [{
              message: {
                content: "Technical Specification: Ensure responsive design using Tailwind CSS. Implement server-side rendering for SEO."
              }
            }]
          };
        }
        return { choices: [{ message: { content: "Generic response" } }] };
      }
    }
  }
};

// Types
type User = { id: string; email: string; name: string };
type Project = { id: string; name: string; description: string; ownerId: string };
type Task = { id: string; title: string; projectId: string };
type Document = { id: string; content: string; taskId: string };

// ============================================================================
// 2. CONFIGURATION & CONSTANTS
// ============================================================================

const CONFIG = {
  SEED_COUNT: {
    USERS: 2,
    PROJECTS_PER_USER: 3,
    TASKS_PER_PROJECT: 2,
    DOCS_PER_TASK: 1,
  },
  VECTOR_DIMENSION: 1536, // Standard for OpenAI text-embedding-ada-002
  PINECONE_INDEX: "saas-production",
  NAMESPACES: {
    DOCUMENTS: "documents",
    PROJECTS: "projects",
  }
};

// ============================================================================
// 3. CORE GENERATION LOGIC
// ============================================================================

/**
 * Generates a synthetic embedding vector.
 * In production, this would call OpenAI Embeddings API.
 * Here we simulate it for the script's standalone execution.
 */
function generateMockEmbedding(): number[] {
  return Array.from({ length: CONFIG.VECTOR_DIMENSION }, () => Math.random());
}

/**
 * Generates realistic seed data using an LLM.
 * @param promptType - The type of data to generate.
 * @param context - Optional context for the generation (e.g., project name).
 */
async function generateContent(promptType: 'projects' | 'documents', context?: string): Promise<any> {
  let prompt = "";
  
  if (promptType === 'projects') {
    prompt = "Generate 3 realistic project management project names and descriptions as a JSON array. Format: [{ name, description }]";
  } else if (promptType === 'documents') {
    prompt = `Generate a technical document snippet related to "${context}". Keep it under 100 tokens.`;
  }

  try {
    const completion = await openai.chat.completions.create({
      model: "gpt-3.5-turbo",
      messages: [{ role: "user", content: prompt }],
      temperature: 0.7,
    });

    const content = completion.choices[0].message.content;
    return promptType === 'projects' ? JSON.parse(content) : content;
  } catch (error) {
    console.error("LLM Generation failed, falling back to mock data.", error);
    return [];
  }
}

/**
 * Orchestrates the seeding process.
 * 1. Creates Users.
 * 2. Generates Projects (LLM) linked to Users.
 * 3. Generates Tasks linked to Projects.
 * 4. Generates Documents (LLM) linked to Tasks.
 * 5. Upserts Document content to Pinecone (Vector DB).
 */
async function seedDatabase() {
  console.log("🚀 Starting Advanced Seed Generation...");

  // --- STEP 1: Clean Slate (Optional for idempotency) ---
  // In production, use Prisma deleteMany or truncate commands carefully.
  console.log("🧹 Ensuring clean state...");

  // --- STEP 2: Generate Users ---
  // We generate users first to establish the root of the relational tree.
  const users: User[] = [];
  for (let i = 0; i < CONFIG.SEED_COUNT.USERS; i++) {
    const user = await prisma.user.create({
      data: {
        email: `user${i}@example.com`,
        name: `User ${i}`,
      },
    });
    users.push(user);
  }
  console.log(`✅ Created ${users.length} users.`);

  // --- STEP 3: Generate Projects (Relational + LLM) ---
  const projects: Project[] = [];
  for (const user of users) {
    // LLM Call: Generate project names and descriptions
    const projectData = await generateContent('projects');
    
    for (const pData of projectData.slice(0, CONFIG.SEED_COUNT.PROJECTS_PER_USER)) {
      const project = await prisma.project.create({
        data: {
          name: pData.name,
          description: pData.description,
          ownerId: user.id, // Referential Integrity
        },
      });
      projects.push(project);
    }
  }
  console.log(`✅ Created ${projects.length} projects.`);

  // --- STEP 4: Generate Tasks & Documents (Deep Relational + Vector) ---
  // This is the critical section where we bridge SQL and Vector DB.
  
  const pineconeIndex = pinecone.index(CONFIG.PINECONE_INDEX);
  const documentNamespace = pineconeIndex.namespace(CONFIG.NAMESPACES.DOCUMENTS);
  const vectorsToUpsert: any[] = [];

  for (const project of projects) {
    for (let t = 0; t < CONFIG.SEED_COUNT.TASKS_PER_PROJECT; t++) {
      const task = await prisma.task.create({
        data: {
          title: `Task ${t + 1} for ${project.name}`,
          projectId: project.id, // Referential Integrity
        },
      });

      // Generate Documents for this Task
      for (let d = 0; d < CONFIG.SEED_COUNT.DOCS_PER_TASK; d++) {
        // LLM Call: Generate specific content based on project context
        const content = await generateContent('documents', project.name);
        
        const document = await prisma.document.create({
          data: {
            content: content,
            taskId: task.id, // Referential Integrity
          },
        });

        // Vector Generation: Create embedding for the document
        // In a real app, we'd batch this to optimize API calls.
        const embedding = generateMockEmbedding();
        
        // Prepare vector for Pinecone
        vectorsToUpsert.push({
          id: document.id, // Vector ID matches Database ID
          values: embedding,
          metadata: {
            projectId: project.id,
            taskId: task.id,
            contentPreview: content.substring(0, 50) + "...",
          }
        });
      }
    }
  }

  console.log(`✅ Created ${vectorsToUpsert.length} documents.`);

  // --- STEP 5: Batch Upsert to Vector Database ---
  // Pinecone allows batch upserts (max 1000 per batch).
  // We chunk the array to ensure we don't hit limits.
  const BATCH_SIZE = 50;
  for (let i = 0; i < vectorsToUpsert.length; i += BATCH_SIZE) {
    const batch = vectorsToUpsert.slice(i, i + BATCH_SIZE);
    await documentNamespace.upsert(batch);
    console.log(`📦 Upserted vector batch ${i / BATCH_SIZE + 1}`);
  }

  console.log("🎉 Seed Generation Complete.");
  console.log(`📊 Summary: ${users.length} Users, ${projects.length} Projects, ${vectorsToUpsert.length} Documents (with Vectors).`);
}

// ============================================================================
// 4. EXECUTION HANDLER
// ============================================================================

/**
 * Main entry point. 
 * In a Next.js app, this would be an API route handler.
 * For this script, we run it directly.
 */
async function main() {
  try {
    await seedDatabase();
  } catch (error) {
    console.error("❌ Fatal error during seeding:", error);
    process.exit(1);
  }
}

// Execute if run directly (Node.js environment)
if (require.main === module) {
  main();
}

export { seedDatabase };
