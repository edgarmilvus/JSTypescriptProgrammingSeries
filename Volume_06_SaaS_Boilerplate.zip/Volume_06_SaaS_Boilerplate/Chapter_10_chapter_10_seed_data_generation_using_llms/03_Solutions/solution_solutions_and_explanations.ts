/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// seed-users.ts
import { PrismaClient } from '@prisma/client';
import { z } from 'zod';
import OpenAI from 'openai';

const prisma = new PrismaClient();
const openai = new OpenAI();

// Define the Zod schema matching the Prisma User model
const UserSchema = z.object({
  name: z.string().min(1),
  email: z.string().email(),
});

type UserInput = z.infer<typeof UserSchema>;

// Helper to extract JSON from LLM response string
function extractJSONFromString(text: string): any[] {
  const jsonStart = text.indexOf('[');
  const jsonEnd = text.lastIndexOf(']') + 1;
  if (jsonStart === -1 || jsonEnd === 0) {
    throw new Error("No JSON array found in response");
  }
  const jsonString = text.substring(jsonStart, jsonEnd);
  return JSON.parse(jsonString);
}

async function generateUserSeedData(count: number): Promise<UserInput[]> {
  // 1. Construct prompt with schema context
  const prompt = `
    You are a data generator. Generate ${count} realistic users.
    The output must be a JSON array of objects.
    Each object must strictly match this schema:
    {
      "name": "string (non-empty)",
      "email": "string (valid email format)"
    }
    Ensure emails are unique and valid.
    Return ONLY the JSON array, no markdown formatting.
  `;

  // 2. Call LLM
  const completion = await openai.chat.completions.create({
    model: 'gpt-3.5-turbo',
    messages: [{ role: 'user', content: prompt }],
    temperature: 0.8,
  });

  const rawResponse = completion.choices[0].message.content || '';

  // 3. Parse response string to extract JSON
  const parsedData = extractJSONFromString(rawResponse);

  // 4. Validate against UserSchema
  // We map over the data and parse each item. Zod will throw if invalid.
  return parsedData.map((item) => UserSchema.parse(item));
}

async function main() {
  try {
    const users = await generateUserSeedData(10);
    console.log(`Generated ${users.length} users.`);
    
    // Insert into database
    await prisma.user.createMany({
      data: users,
      skipDuplicates: true, // Optional: handles unique constraint conflicts
    });
    console.log('Users inserted successfully.');
  } catch (error) {
    console.error('Error generating or inserting users:', error);
  }
}

main()
  .catch(console.error)
  .finally(() => prisma.$disconnect());
