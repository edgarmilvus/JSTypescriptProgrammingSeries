/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

// seed-posts.ts
import { PrismaClient } from '@prisma/client';
import { z } from 'zod';
import OpenAI from 'openai';

const prisma = new PrismaClient();
const openai = new OpenAI();

const PostSchema = z.object({
  title: z.string().min(5),
  content: z.string().min(20),
  authorId: z.number().int(),
});

type PostInput = z.infer<typeof PostSchema>;

async function generatePostsForExistingUsers(count: number): Promise<PostInput[]> {
  // 1. Fetch existing user IDs
  const users = await prisma.user.findMany({
    select: { id: true },
    take: 50, // Limit to avoid overly large prompts
  });

  if (users.length === 0) {
    throw new Error("No users found in database. Seed users first.");
  }

  const userIds = users.map(u => u.id);
  const userIdsString = userIds.join(', ');

  // 2. Construct prompt with userIds list
  const prompt = `
    You are a data generator. Generate ${count} blog posts.
    The output must be a JSON array of objects.
    Each object must match this schema:
    {
      "title": "string (min 5 chars)",
      "content": "string (min 20 chars)",
      "authorId": "integer"
    }
    CRITICAL: The "authorId" must be one of the following IDs: ${userIdsString}.
    Return ONLY the JSON array.
  `;

  // 3. Call LLM
  const completion = await openai.chat.completions.create({
    model: 'gpt-3.5-turbo',
    messages: [{ role: 'user', content: prompt }],
  });

  const rawResponse = completion.choices[0].message.content || '';
  
  // Parse JSON (assuming similar structure to Ex 1)
  const jsonStart = rawResponse.indexOf('[');
  const jsonEnd = rawResponse.lastIndexOf(']') + 1;
  const parsedData = JSON.parse(rawResponse.substring(jsonStart, jsonEnd));

  // 4. Parse and validate
  const validPosts: PostInput[] = [];
  
  for (const item of parsedData) {
    try {
      // Validate structure
      const validated = PostSchema.parse(item);
      
      // Validate referential integrity (Fallback mechanism)
      if (userIds.includes(validated.authorId)) {
        validPosts.push(validated);
      } else {
        console.warn(`Filtered out post with invalid authorId: ${validated.authorId}`);
      }
    } catch (e) {
      console.warn('Filtered out invalid post structure:', item);
    }
  }

  return validPosts;
}

async function main() {
  try {
    const posts = await generatePostsForExistingUsers(20);
    console.log(`Generated ${posts.length} valid posts.`);

    if (posts.length > 0) {
      await prisma.post.createMany({
        data: posts,
      });
      console.log('Posts inserted successfully.');
    }
  } catch (error) {
    console.error('Error:', error);
  }
}

main().catch(console.error).finally(() => prisma.$disconnect());
