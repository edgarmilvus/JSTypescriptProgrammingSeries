/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

// seed-vectors.ts
import { PrismaClient } from '@prisma/client';
import { OpenAI } from 'openai';

const prisma = new PrismaClient();
const openai = new OpenAI();

interface SyntheticDocument {
  content: string;
  embedding: number[];
}

async function generateAndEmbed(count: number): Promise<SyntheticDocument[]> {
  // 1. Prompt LLM to generate diverse text snippets
  const prompt = `
    Generate ${count} diverse text snippets suitable for vector search testing.
    Examples: Technical documentation, customer support tickets, creative writing.
    Return ONLY a JSON array of strings.
  `;

  const completion = await openai.chat.completions.create({
    model: 'gpt-3.5-turbo',
    messages: [{ role: 'user', content: prompt }],
  });

  const rawResponse = completion.choices[0].message.content || '';
  const jsonStart = rawResponse.indexOf('[');
  const jsonEnd = rawResponse.lastIndexOf(']') + 1;
  const texts: string[] = JSON.parse(rawResponse.substring(jsonStart, jsonEnd));

  // 2. For each snippet, call openai.embeddings.create
  // Note: Batching embeddings is more efficient, but we loop for clarity
  const documents: SyntheticDocument[] = [];

  for (const text of texts) {
    try {
      const embeddingResponse = await openai.embeddings.create({
        model: 'text-embedding-ada-002',
        input: text,
      });

      documents.push({
        content: text,
        embedding: embeddingResponse.data[0].embedding,
      });
    } catch (e) {
      console.error("Failed to generate embedding for text:", text, e);
    }
  }

  return documents;
}

async function main() {
  try {
    const docs = await generateAndEmbed(10);
    console.log(`Generated ${docs.length} documents with embeddings.`);

    // 3. Insert into DB using raw SQL (Prisma $executeRaw)
    // Note: Syntax depends on DB (PostgreSQL with pgvector used here)
    if (docs.length > 0) {
      // Construct a bulk insert query
      const values = docs.map((doc) => 
        `('${doc.content.replace(/'/g, "''")}', '[${doc.embedding.join(',')}]')`
      ).join(', ');

      const query = `
        INSERT INTO "Document" (content, vector)
        VALUES ${values};
      `;

      await prisma.$executeRawUnsafe(query);
      console.log('Documents with vectors inserted successfully.');
    }
  } catch (error) {
    console.error('Error:', error);
  }
}

main().catch(console.error).finally(() => prisma.$disconnect());
