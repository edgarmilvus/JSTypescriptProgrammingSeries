/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

// interactive-seed.ts
import readline from 'readline';
import { OpenAI } from 'openai';

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

const openai = new OpenAI();

// Helper to extract JSON
function extractJSONFromString(text: string): any {
  try {
    const jsonStart = text.indexOf('{');
    const jsonEnd = text.lastIndexOf('}') + 1;
    if (jsonStart === -1 || jsonEnd === 0) return null;
    return JSON.parse(text.substring(jsonStart, jsonEnd));
  } catch (e) {
    return null;
  }
}

async function main() {
  // 1. Ask for entity type and count
  rl.question('What entity set do you want to generate? (e.g., "Customers and Orders"): ', (entitySet) => {
    rl.question('How many records per entity? (e.g., 5): ', async (countStr) => {
      const count = parseInt(countStr, 10);
      
      if (!entitySet || isNaN(count)) {
        console.log('Invalid input.');
        rl.close();
        return;
      }

      // 2. Construct complex prompt
      const prompt = `
        You are a data generator. Generate a relational dataset for ${entitySet}.
        Generate ${count} Customers and ${count * 2} Orders.
        
        Rules:
        1. Assign a unique integer ID to every Customer and Order starting from 1.
        2. Every Order must have a "customerId" that matches the ID of a generated Customer.
        3. Output must be a single JSON object with two keys: "customers" and "orders".
        
        Example Output Format:
        {
          "customers": [
            { "id": 1, "name": "Alice" },
            { "id": 2, "name": "Bob" }
          ],
          "orders": [
            { "id": 101, "customerId": 1, "total": 50.00 },
            { "id": 102, "customerId": 2, "total": 120.00 }
          ]
        }
        
        Return ONLY the JSON object, no markdown.
      `;

      try {
        console.log('Generating data...');
        const completion = await openai.chat.completions.create({
          model: 'gpt-3.5-turbo',
          messages: [{ role: 'user', content: prompt }],
        });

        const rawResponse = completion.choices[0].message.content || '';
        
        // 3. Parse multi-table JSON
        const data = extractJSONFromString(rawResponse);

        if (!data || !data.customers || !data.orders) {
          console.error("Failed to parse valid structure from LLM.");
          rl.close();
          return;
        }

        // 4. Validate relationships
        const customerIds = data.customers.map((c: any) => c.id);
        const validOrders = data.orders.filter((o: any) => customerIds.includes(o.customerId));
        const invalidOrders = data.orders.filter((o: any) => !customerIds.includes(o.customerId));

        // 5. Print summary
        console.log('\n--- Generation Summary ---');
        console.log(`Generated Customers: ${data.customers.length}`);
        console.log(`Generated Orders: ${data.orders.length}`);
        console.log(`Valid Orders (linked to customers): ${validOrders.length}`);
        
        if (invalidOrders.length > 0) {
          console.log(`Filtered out ${invalidOrders.length} orders with invalid customer references.`);
        }

        console.log('\n--- Relationship Sample ---');
        if (validOrders.length > 0) {
          const sample = validOrders[0];
          console.log(`Order #${sample.id} belongs to Customer #${sample.customerId}`);
        }

        // In a real scenario, you would now insert data using Prisma
        // await prisma.customer.createMany({ data: data.customers });
        // await prisma.order.createMany({ data: validOrders });

      } catch (error) {
        console.error('Error during generation:', error);
      } finally {
        rl.close();
      }
    });
  });
}

main();
