/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part6.tsx
// Description: Solutions and Explanations
// ==========================================

'use client';

import { useState } from 'react';

export default function SeedGenerator() {
  const [prompt, setPrompt] = useState('Users with names and emails');
  const [count, setCount] = useState(5);
  const [data, setData] = useState<string>(''); // Store streamed text
  const [isGenerating, setIsGenerating] = useState(false);

  const handleGenerate = async () => {
    setIsGenerating(true);
    setData('');

    try {
      const response = await fetch('/api/admin/generate-seed', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt, count }),
      });

      if (!response.body) {
        throw new Error('No response body');
      }

      const reader = response.body.getReader();
      const decoder = new TextDecoder();

      // Read the stream
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        // Decode and append to state
        const chunk = decoder.decode(value, { stream: true });
        setData((prev) => prev + chunk);
      }
    } catch (error) {
      console.error('Stream error:', error);
      setData('Error generating data.');
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <div className="p-6 border rounded-lg shadow-sm bg-white max-w-2xl mx-auto mt-4">
      <h2 className="text-xl font-bold mb-4">Seed Data Generator</h2>
      
      <div className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-gray-700">Description</label>
          <input 
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm border p-2"
            value={prompt} 
            onChange={(e) => setPrompt(e.target.value)} 
            placeholder="Describe data to generate..."
          />
        </div>
        
        <div>
          <label className="block text-sm font-medium text-gray-700">Count</label>
          <input 
            type="number"
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm border p-2"
            value={count} 
            onChange={(e) => setCount(parseInt(e.target.value) || 0)} 
          />
        </div>

        <button 
          onClick={handleGenerate} 
          disabled={isGenerating}
          className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:bg-gray-400"
        >
          {isGenerating ? 'Generating...' : 'Generate Seed Data'}
        </button>
      </div>

      <div className="mt-6">
        <h3 className="text-lg font-medium text-gray-900">Generated Output:</h3>
        <div className="mt-2 p-4 bg-gray-50 rounded-md h-64 overflow-y-auto font-mono text-sm">
          {isGenerating && !data ? (
            <span className="animate-pulse">Initializing stream...</span>
          ) : (
            data
          )}
        </div>
      </div>
    </div>
  );
}
