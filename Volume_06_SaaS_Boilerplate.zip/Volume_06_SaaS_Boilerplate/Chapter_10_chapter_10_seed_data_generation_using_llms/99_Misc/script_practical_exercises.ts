/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises.ts
// Description: Practical Exercises
// ==========================================

// seed-users.ts
import { PrismaClient } from '@prisma/client';
import { z } from 'zod';

const prisma = new PrismaClient();

// Define the Zod schema matching your Prisma User model
const UserSchema = z.object({
  name: z.string().min(1),
  email: z.string().email(),
  // Add other fields as needed
});

type UserInput = z.infer<typeof UserSchema>;

async function generateUserSeedData(count: number): Promise<UserInput[]> {
  // TODO: Implement LLM call and parsing logic here.
  // 1. Construct prompt with schema context.
  // 2. Call LLM (e.g., via OpenAI API).
  // 3. Parse response string to extract JSON.
  // 4. Validate against UserSchema.
  return [];
}

async function main() {
  const users = await generateUserSeedData(10);
  console.log(`Generated ${users.length} users.`);
  // TODO: Insert into database using prisma.user.createMany()
}

main()
  .catch(console.error)
  .finally(() => prisma.$disconnect());
