/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part3.ts
// Description: Practical Exercises
// ==========================================

// seed-vectors.ts
import { PrismaClient } from '@prisma/client';
import { OpenAI } from 'openai'; // Assuming OpenAI SDK

const prisma = new PrismaClient();
const openai = new OpenAI();

interface SyntheticDocument {
  content: string;
  embedding: number[];
}

async function generateAndEmbed(count: number): Promise<SyntheticDocument[]> {
  // TODO: Implement
  // 1. Prompt LLM to generate 'count' diverse text snippets.
  // 2. For each snippet, call openai.embeddings.create.
  // 3. Map response to { content, embedding }.
  return [];
}

async function main() {
  const docs = await generateAndEmbed(10);
  // TODO: Insert into DB. 
  // Note: You may need to use raw SQL for vector columns (e.g., Prisma.$executeRaw`INSERT INTO ...`)
}

main().catch(console.error).finally(() => prisma.$disconnect());
