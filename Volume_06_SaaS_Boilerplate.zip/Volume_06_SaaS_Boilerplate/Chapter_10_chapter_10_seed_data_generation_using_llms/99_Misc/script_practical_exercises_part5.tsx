/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part5.tsx
// Description: Practical Exercises
// ==========================================

// components/SeedGenerator.tsx
'use client';

import { useState, useEffect } from 'react';

export default function SeedGenerator() {
  const [prompt, setPrompt] = useState('');
  const [count, setCount] = useState(5);
  const [data, setData] = useState<any[]>([]);
  const [isGenerating, setIsGenerating] = useState(false);

  const handleGenerate = async () => {
    setIsGenerating(true);
    setData([]);
    
    // TODO: Implement streaming fetch
    // 1. fetch('/api/admin/generate-seed', { method: 'POST', body: JSON.stringify({ prompt, count }) })
    // 2. Get reader from response.body
    // 3. Loop: await reader.read()
    // 4. Decode chunk (TextDecoder) and parse JSON
    // 5. Update state: setData(prev => [...prev, parsedChunk])
    
    setIsGenerating(false);
  };

  return (
    <div className="p-4 border rounded">
      <input 
        value={prompt} 
        onChange={(e) => setPrompt(e.target.value)} 
        placeholder="Describe data to generate..."
      />
      <input 
        type="number" 
        value={count} 
        onChange={(e) => setCount(parseInt(e.target.value))} 
      />
      <button onClick={handleGenerate} disabled={isGenerating}>
        {isGenerating ? 'Generating...' : 'Generate Seed Data'}
      </button>

      {/* TODO: Wrap this list in Suspense if needed for initial load */}
      <ul>
        {data.map((item, idx) => (
          <li key={idx}>{JSON.stringify(item)}</li>
        ))}
      </ul>
    </div>
  );
}
