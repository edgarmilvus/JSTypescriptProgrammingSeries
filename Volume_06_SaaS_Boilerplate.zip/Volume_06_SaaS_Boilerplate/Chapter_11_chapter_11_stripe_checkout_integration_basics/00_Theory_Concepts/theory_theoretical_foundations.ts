/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: theory_theoretical_foundations.ts
// Description: Theoretical Foundations
// ==========================================

digraph PaymentFlow {
    rankdir=TB;
    node [shape=box, style="rounded,filled", fillcolor="#e3f2fd", fontname="Helvetica"];

    Client [label="Client (Browser)\nNext.js Frontend"];
    StripeHost [label="Stripe Hosted Checkout\n(PCI-DSS Compliant)", fillcolor="#fff3e0"];
    Server [label="Server API Route\n(Node.js/Next.js)", fillcolor="#e8f5e9"];
    Database [label="Database (PostgreSQL)\nSource of Truth", fillcolor="#f3e5f5"];
    Webhook [label="Stripe Webhook\n(External Trigger)", fillcolor="#ffebee"];

    // Flow 1: Initiation
    Client -> Server [label="1. Request Checkout Session", color="#1976d2", fontcolor="#1976d2"];
    
    // Flow 2: Session Creation & Redirect
    Server -> StripeHost [label="2. Create Session ID\n& Redirect URL", color="#ff9800", fontcolor="#ff9800"];
    StripeHost -> Client [label="3. User Redirected\n(Payment Form)", color="#ff9800", fontcolor="#ff9800"];

    // Flow 3: The Async Webhook (The Critical Path)
    StripeHost -> Webhook [label="4. Payment Success", color="#d32f2f", fontcolor="#d32f2f"];
    Webhook -> Server [label="5. POST /api/webhook/stripe", color="#d32f2f", fontcolor="#d32f2f"];
    
    // Flow 4: Fulfillment
    Server -> Database [label="6. Update User Status\n(Provision Access)", color="#388e3c", fontcolor="#388e3c"];
}
