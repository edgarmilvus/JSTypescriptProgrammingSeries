/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part2.ts
// Description: Theoretical Foundations
// ==========================================

// File: /app/api/webhook/stripe/route.ts

import { NextRequest, NextResponse } from 'next/server';
import Stripe from 'stripe';

// Initialize Stripe with the secret key (Server-side only)
const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!);

export async function POST(request: NextRequest) {
  const payload = await request.text();
  const signature = request.headers.get('stripe-signature')!;

  let event: Stripe.Event;

  try {
    // Step 1: Verification (The Security Check)
    // This ensures the payload hasn't been tampered with.
    event = stripe.webhooks.constructEvent(
      payload,
      signature,
      process.env.STRIPE_WEBHOOK_SECRET!
    );
  } catch (err) {
    // If verification fails, we reject the request immediately.
    return new NextResponse(`Webhook Error: ${err.message}`, { status: 400 });
  }

  // Step 2: Event Filtering (The Logic Branch)
  // We only care about the 'checkout.session.completed' event for fulfillment.
  if (event.type === 'checkout.session.completed') {
    const session = event.data.object as Stripe.Checkout.Session;
    
    // Step 3: Idempotency & Fulfillment
    // We extract the metadata passed during session creation.
    const userId = session.metadata?.userId;
    
    if (!userId) {
      return new NextResponse('Missing userId in metadata', { status: 400 });
    }

    // Step 4: State Update (The Database Transaction)
    // Here, we would update the database (from Chapter 4) to grant access.
    // This logic must be idempotent.
    await provisionUserAccess(userId, session.id);
  }

  // Step 5: Acknowledgement
  // Return 200 OK to tell Stripe the event was handled.
  return new NextResponse(JSON.stringify({ received: true }), { status: 200 });
}

// Theoretical helper function
async function provisionUserAccess(userId: string, stripeEventId: string) {
  // 1. Check if 'stripeEventId' has already been processed (Idempotency check)
  // 2. If not, update the 'users' table to set 'is_pro' = true
  // 3. Log the 'stripeEventId' to the processed_events table
  console.log(`Provisioning access for user ${userId}`);
}
