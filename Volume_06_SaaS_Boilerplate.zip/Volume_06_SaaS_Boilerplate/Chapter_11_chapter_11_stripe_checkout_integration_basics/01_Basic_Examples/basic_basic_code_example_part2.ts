/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.ts
// Description: Basic Code Example
// ==========================================

// File: app/api/webhooks/stripe/route.ts
import { NextResponse } from 'next/server';
import Stripe from 'stripe';

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY as string, {
  apiVersion: '2023-10-16',
});

/**
 * POST /api/webhooks/stripe
 * Listens for Stripe events (e.g., payment success).
 * IMPORTANT: This endpoint must be raw-body parsable. 
 * Next.js App Router handles this via the `request` object.
 */
export async function POST(request: Request) {
  const payload = await request.text(); // Get raw body as text
  const signature = request.headers.get('stripe-signature') as string;

  // 1. Verify the event came from Stripe
  let event: Stripe.Event;
  try {
    event = stripe.webhooks.constructEvent(
      payload,
      signature,
      process.env.STRIPE_WEBHOOK_SECRET as string
    );
  } catch (err) {
    const errorMessage = err instanceof Error ? err.message : 'Unknown error';
    console.error(`Webhook Signature Verification Failed:`, errorMessage);
    return NextResponse.json(
      { error: `Webhook Error: ${errorMessage}` },
      { status: 400 }
    );
  }

  // 2. Handle the specific event type
  switch (event.type) {
    case 'checkout.session.completed': {
      // Type guard to ensure we are working with the correct object structure
      const session = event.data.object as Stripe.Checkout.Session;
      
      // Extract metadata (user ID, plan)
      const userId = session.metadata?.userId;
      const plan = session.metadata?.plan;

      console.log(`Payment successful for user: ${userId}, plan: ${plan}`);

      // 3. FULFILLMENT LOGIC (The "Hello World" of SaaS activation)
      // This is where you update your database.
      // Example: await db.user.update({ where: { id: userId }, set: { plan: 'pro' } });
      
      break;
    }
    case 'invoice.payment_succeeded':
      // Handle recurring subscription payments here
      break;
    default:
      console.log(`Unhandled event type: ${event.type}`);
  }

  // 4. Return a 200 response to acknowledge receipt of the event
  return NextResponse.json({ received: true });
}
