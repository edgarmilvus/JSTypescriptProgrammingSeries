/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// /app/api/checkout/create/route.ts
import { NextResponse, NextRequest } from 'next/server';
import Stripe from 'stripe';
import { getServerSession } from 'next-auth/next';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/prisma';

// Initialize Stripe with the secret key from environment variables
const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, {
  apiVersion: '2023-10-16', // Ensure compatibility with your Stripe version
});

/**
 * POST /api/checkout/create
 * 
 * Creates a Stripe Checkout Session for a Pro subscription upgrade.
 * 
 * Flow:
 * 1. Retrieve the authenticated user session (NextAuth).
 * 2. Check if the user is already a Pro member to prevent duplicate charges.
 * 3. Create a Stripe Checkout Session with a recurring price ID.
 * 4. Return the session URL to the client for redirection.
 */
export async function POST(req: NextRequest) {
  try {
    // 1. Get User Session
    const session = await getServerSession(authOptions);
    
    if (!session || !session.user?.email) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    // 2. Check User Status (Database Query)
    const user = await prisma.user.findUnique({
      where: { email: session.user.email },
    });

    if (!user) {
      return NextResponse.json({ error: 'User not found' }, { status: 404 });
    }

    // Prevent users who are already subscribed from creating a new session
    if (user.stripeCustomerId && user.subscriptionStatus === 'active') {
      return NextResponse.json({ error: 'User is already subscribed' }, { status: 400 });
    }

    // 3. Create Stripe Checkout Session
    // We use `mode: 'subscription'` for recurring payments.
    // `customer_email` pre-fills the checkout form if the customer ID isn't set.
    const sessionParams: Stripe.Checkout.SessionCreateParams = {
      payment_method_types: ['card'],
      line_items: [
        {
          price: process.env.STRIPE_PRO_PRICE_ID!, // ID from Stripe Dashboard (e.g., price_1234...)
          quantity: 1,
        },
      ],
      mode: 'subscription',
      success_url: `${process.env.NEXT_PUBLIC_APP_URL}/dashboard?session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: `${process.env.NEXT_PUBLIC_APP_URL}/dashboard`,
      customer_email: user.stripeCustomerId ? undefined : user.email,
      // If the user has a Stripe ID, attach the subscription to the existing customer
      customer: user.stripeCustomerId || undefined,
    };

    const checkoutSession = await stripe.checkout.sessions.create(sessionParams);

    // 4. Update Database (Optional but recommended: Save session ID to track initiation)
    await prisma.user.update({
      where: { id: user.id },
      data: {
        stripeCheckoutSessionId: checkoutSession.id,
      },
    });

    return NextResponse.json({ url: checkoutSession.url });

  } catch (error) {
    console.error('Error creating checkout session:', error);
    return NextResponse.json(
      { error: 'Internal Server Error' }, 
      { status: 500 }
    );
  }
}
