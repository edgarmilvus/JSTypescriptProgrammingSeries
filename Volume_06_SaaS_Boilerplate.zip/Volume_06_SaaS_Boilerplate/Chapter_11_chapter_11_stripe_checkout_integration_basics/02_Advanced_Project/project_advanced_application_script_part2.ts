/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script_part2.ts
// Description: Advanced Application Script
// ==========================================

// /app/api/webhooks/stripe/route.ts
import { NextResponse, NextRequest } from 'next/server';
import Stripe from 'stripe';
import { prisma } from '@/lib/prisma';

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, {
  apiVersion: '2023-10-16',
});

// IMPORTANT: Use raw body parsing for webhook verification
export const config = {
  api: {
    bodyParser: false,
  },
};

/**
 * POST /api/webhooks/stripe
 * 
 * Listens for Stripe events to update the database.
 * 
 * Events handled:
 * 1. 'checkout.session.completed': User paid successfully. Grant Pro access.
 * 2. 'invoice.payment_failed': Payment failed (e.g., card declined). Update status.
 * 
 * Security: Uses HMAC signature verification to prevent spoofing.
 */
export async function POST(req: NextRequest) {
  const payload = await req.text();
  const signature = req.headers.get('stripe-signature') || '';

  let event: Stripe.Event;

  try {
    // 1. Verify Webhook Signature
    event = stripe.webhooks.constructEvent(
      payload,
      signature,
      process.env.STRIPE_WEBHOOK_SECRET!
    );
  } catch (err) {
    const error = err as Error;
    console.error(`Webhook Signature Verification Failed: ${error.message}`);
    return NextResponse.json({ error: 'Webhook signature invalid' }, { status: 400 });
  }

  // 2. Handle the Event
  try {
    switch (event.type) {
      case 'checkout.session.completed': {
        const session = event.data.object as Stripe.Checkout.Session;
        
        // Ensure this is a subscription (not a one-time payment)
        if (session.mode === 'subscription') {
          const customerId = session.customer as string;
          
          // Retrieve the subscription to get the status
          const subscription = await stripe.subscriptions.retrieve(session.subscription as string);
          
          // Update Database: Grant Pro Access
          await prisma.user.update({
            where: { 
              stripeCustomerId: customerId 
            },
            data: {
              subscriptionStatus: subscription.status, // 'active', 'trialing', etc.
              // Ensure we have the customer ID if it wasn't set before
              stripeCustomerId: customerId,
            },
          });
          
          console.log(`Pro access granted to customer: ${customerId}`);
        }
        break;
      }

      case 'invoice.payment_failed': {
        const invoice = event.data.object as Stripe.Invoice;
        
        // Update Database: Mark subscription as past_due
        if (invoice.customer) {
          await prisma.user.update({
            where: { stripeCustomerId: invoice.customer as string },
            data: {
              subscriptionStatus: 'past_due',
            },
          });
          
          console.log(`Payment failed for customer: ${invoice.customer}`);
        }
        break;
      }

      default:
        console.log(`Unhandled event type: ${event.type}`);
    }

    return NextResponse.json({ received: true }, { status: 200 });

  } catch (error) {
    console.error('Webhook processing error:', error);
    // Return 500 so Stripe retries the webhook (exponential backoff)
    return NextResponse.json({ error: 'Webhook handler failed' }, { status: 500 });
  }
}
