/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.tsx
// Description: Solutions and Explanations
// ==========================================

// MockPaymentFlow.tsx
'use client';

import React, { useState } from 'react';

// 1. Mock Backend Function
const createMockStripeSession = (priceId: string): Promise<{ url: string; id: string }> => {
  console.log(`[Backend] Creating session for price: ${priceId}`);
  return new Promise((resolve) => {
    setTimeout(() => {
      const sessionId = `session_${Math.random().toString(36).substr(2, 9)}`;
      resolve({
        id: sessionId,
        url: `https://stripe.mock/checkout/${sessionId}`,
      });
    }, 1000); // Simulate 1s network delay
  });
};

// 2. Webhook Simulation Function
const simulateWebhookEvent = (sessionId: string) => {
  console.log(`[Stripe] Sending webhook event for session: ${sessionId}`);
  setTimeout(() => {
    console.log(`[Server] Webhook received: checkout.session.completed for session ${sessionId}`);
    // In a real app, this would trigger fulfillOrder(sessionId)
    console.log(`[Server] User access granted to PRO plan.`);
  }, 2000); // Simulate 2s delay for webhook firing
};

// 3. Frontend Component
export default function MockCheckout() {
  const [status, setStatus] = useState<string>('Idle');

  const handlePay = async () => {
    setStatus('Processing...');
    
    // Step 1: Create Session (Mock API Call)
    const session = await createMockStripeSession('price_pro_mock');
    
    // Step 2: Simulate User Redirect
    console.log(`[Frontend] User redirected to: ${session.url}`);
    setStatus('Redirected to Stripe...');
    
    // Simulate user completing payment and returning (Short delay for demo)
    setTimeout(() => {
      setStatus('Payment Successful! Waiting for webhook...');
      console.log(`[Frontend] User returned to success URL.`);
      
      // Step 3: Trigger Webhook Simulation
      simulateWebhookEvent(session.id);
      
      // Reset status for UI clarity
      setTimeout(() => setStatus('Flow Complete'), 2000);
    }, 1500);
  };

  return (
    <div className="p-6 border rounded-lg max-w-md mx-auto bg-gray-50">
      <h3 className="text-lg font-bold mb-4">Mock Payment Flow</h3>
      <p className="text-sm text-gray-600 mb-4">Status: {status}</p>
      <button
        onClick={handlePay}
        disabled={status !== 'Idle' && status !== 'Flow Complete'}
        className="bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700 disabled:opacity-50"
      >
        Pay Now (Mock)
      </button>
      <div className="mt-4 text-xs text-gray-500 font-mono bg-white p-2 border rounded h-32 overflow-auto">
        <p>Check browser console for detailed logs.</p>
      </div>
    </div>
  );
}
