/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

// fulfillment.ts
import Stripe from 'stripe';
import { PrismaClient } from '@prisma/client';

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, {
  apiVersion: '2023-10-16',
});
const prisma = new PrismaClient();

export async function fulfillOrder(sessionId: string) {
  // 1. Retrieve the session from Stripe
  const session = await stripe.checkout.sessions.retrieve(sessionId, {
    expand: ['subscription'], // Expand to get subscription details easily
  });

  // 2. Validate the session state
  if (session.status !== 'complete' || !session.subscription) {
    throw new Error(`Session ${sessionId} is not complete or has no subscription.`);
  }

  // 3. Extract Stripe Customer ID
  const stripeCustomerId = session.customer as string;
  
  if (!stripeCustomerId) {
    throw new Error('No customer ID found in session.');
  }

  // 4. Find user in local database
  const user = await prisma.user.findUnique({
    where: { stripeCustomerId: stripeCustomerId },
  });

  if (!user) {
    // This is a critical error. It means the customer exists in Stripe but not in our DB.
    // We throw an error so the webhook handler returns 400/500, causing Stripe to retry.
    throw new Error(`User not found for Stripe Customer ID: ${stripeCustomerId}`);
  }

  // 5. Update user record
  // Assuming 'subscription' is the expanded object from Stripe
  const subscriptionId = (session.subscription as Stripe.Subscription).id;

  await prisma.user.update({
    where: { id: user.id },
    data: {
      plan: 'PRO',
      stripeSubscriptionId: subscriptionId,
    },
  });

  console.log(`User ${user.id} upgraded to PRO plan.`);
}
