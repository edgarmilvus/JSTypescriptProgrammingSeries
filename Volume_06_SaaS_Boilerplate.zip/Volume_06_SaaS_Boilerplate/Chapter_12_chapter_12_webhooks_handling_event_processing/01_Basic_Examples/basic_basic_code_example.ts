/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

// app/api/webhooks/stripe/route.ts
import { NextResponse, NextRequest } from 'next/server';
import crypto from 'crypto';

/**
 * @description Configuration for the webhook.
 * In a real SaaS, these should be stored in environment variables.
 */
const WEBHOOK_SECRET = process.env.STRIPE_WEBHOOK_SECRET || 'whsec_test_secret';
const ALGORITHM = 'sha256';

/**
 * @description Simulated Database Service.
 * Represents a database where we store event IDs to ensure idempotency.
 */
const processedEvents = new Set<string>();

/**
 * @description Main Webhook Handler for Stripe Events.
 * 
 * @param request - The incoming HTTP request object from Next.js.
 * @returns Promise<NextResponse> - A standard Next.js response.
 */
export async function POST(request: NextRequest) {
  // 1. Extract the raw request body as a Buffer.
  //    We need the raw bytes for signature verification.
  //    In Next.js, we use request.clone() or request.arrayBuffer() to access raw data.
  const rawBody = await request.clone().arrayBuffer();
  const rawBodyString = Buffer.from(rawBody).toString('utf-8');

  // 2. Extract the signature header.
  //    Stripe and other providers send a header like 'stripe-signature'.
  const signature = request.headers.get('stripe-signature');

  if (!signature) {
    console.warn('Webhook error: Missing signature header');
    return NextResponse.json({ error: 'Missing signature' }, { status: 400 });
  }

  // 3. Verify the Webhook Signature (HMAC Verification).
  //    This prevents attackers from sending fake events to your endpoint.
  try {
    const timestamp = signature.split('=')[1]; // e.g., t=1234567890
    const receivedHash = signature.split(',')[1]; // e.g., v1=abcdef...
    
    // Construct the signed payload: timestamp.raw_body
    // This is a standard pattern (Stripe uses it, though they prefix 'v1=')
    const payloadToSign = `${timestamp}.${rawBodyString}`;
    
    // Calculate the expected hash using your secret
    const expectedHash = crypto
      .createHmac(ALGORITHM, WEBHOOK_SECRET)
      .update(payloadToSign, 'utf8')
      .digest('hex');

    // Compare signatures (use timingSafeEqual to prevent timing attacks)
    const isValid = crypto.timingSafeEqual(
      Buffer.from(receivedHash),
      Buffer.from(expectedHash)
    );

    if (!isValid) {
      console.error('Webhook error: Invalid signature');
      return NextResponse.json({ error: 'Invalid signature' }, { status: 401 });
    }
  } catch (error) {
    console.error('Webhook error: Verification failed', error);
    return NextResponse.json({ error: 'Verification failed' }, { status: 401 });
  }

  // 4. Parse the Event Payload.
  let event;
  try {
    event = JSON.parse(rawBodyString);
  } catch (error) {
    console.error('Webhook error: Invalid JSON');
    return NextResponse.json({ error: 'Invalid JSON' }, { status: 400 });
  }

  // 5. Implement Idempotency.
  //    Webhooks can be retried by the sender. We must ensure we don't 
  //    process the same event twice (e.g., charging a user twice).
  const eventId = event.id;
  if (processedEvents.has(eventId)) {
    console.log(`Webhook info: Event ${eventId} already processed. Skipping.`);
    return NextResponse.json({ received: true, status: 'skipped' }, { status: 200 });
  }
  processedEvents.add(eventId);

  // 6. Handle the Event (The Business Logic).
  //    In a real app, this would be an async function calling your database or queue.
  try {
    switch (event.type) {
      case 'payment_intent.succeeded':
        await handlePaymentSuccess(event.data.object);
        break;
      case 'checkout.session.completed':
        await handleCheckoutComplete(event.data.object);
        break;
      default:
        console.log(`Unhandled event type: ${event.type}`);
    }

    // 7. Return 200 OK to the provider.
    //    If we return anything else (like 500), the provider will retry.
    return NextResponse.json({ received: true }, { status: 200 });
  } catch (error) {
    console.error('Webhook error: Processing failed', error);
    // Returning 500 triggers a retry from the webhook provider.
    return NextResponse.json({ error: 'Processing failed' }, { status: 500 });
  }
}

/**
 * @description Helper: Handles successful payment logic.
 * @param paymentIntent - The Stripe payment intent object.
 */
async function handlePaymentSuccess(paymentIntent: any) {
  // In a real app: Update user subscription status in the database.
  console.log(`Processing payment for user: ${paymentIntent.metadata.userId}`);
  // Simulate DB delay
  await new Promise(resolve => setTimeout(resolve, 100));
}

/**
 * @description Helper: Handles checkout completion.
 * @param session - The Stripe session object.
 */
async function handleCheckoutComplete(session: any) {
  // In a real app: Provision access to the SaaS features.
  console.log(`Provisioning access for email: ${session.customer_email}`);
  // Simulate DB delay
  await new Promise(resolve => setTimeout(resolve, 100));
}
