/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// app/api/webhooks/stripe/route.ts
import { NextRequest, NextResponse } from 'next/server';
import Stripe from 'stripe';
import { PrismaClient } from '@prisma/client';
import { headers } from 'next/headers';

// Initialize Stripe with the secret key from environment variables
const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!);

// Initialize Prisma (Database Client)
const prisma = new PrismaClient();

/**
 * @description Represents the structure of a generic webhook event we expect to handle.
 * In a real app, this would be a union of specific event types (e.g., 'checkout.session.completed').
 */
interface WebhookEvent {
  id: string;
  type: string;
  data: {
    object: any;
  };
}

/**
 * @description POST handler for incoming Stripe webhooks.
 * 
 * Architecture:
 * 1. Validate the Webhook Signature (Security).
 * 2. Check Idempotency (Reliability).
 * 3. Process Business Logic (Database updates).
 * 4. Respond Immediately (Performance).
 * 
 * @param req - The incoming NextRequest object.
 * @returns NextResponse
 */
export async function POST(req: NextRequest) {
  const body = await req.text(); // Get raw body as text for signature verification
  const signature = headers().get('stripe-signature');

  // --- 1. SECURITY: Signature Verification ---
  // We must verify the request actually came from Stripe, not a malicious actor.
  let event: Stripe.Event;
  try {
    event = stripe.webhooks.constructEvent(
      body,
      signature!,
      process.env.STRIPE_WEBHOOK_SECRET!
    );
  } catch (err) {
    const errorMessage = err instanceof Error ? err.message : 'Unknown error';
    console.error('Webhook signature verification failed:', errorMessage);
    return new NextResponse(`Webhook Error: ${errorMessage}`, { status: 400 });
  }

  // --- 2. IDEMPOTENCY: Check Database ---
  // We use the Stripe event ID as our unique idempotency key.
  const eventId = event.id;
  
  try {
    // Check if this event has already been processed
    const existingEvent = await prisma.processedWebhookEvent.findUnique({
      where: { id: eventId },
    });

    if (existingEvent) {
      // If found, we have already processed this event.
      // Return 200 OK immediately to acknowledge receipt.
      console.log(`Event ${eventId} already processed. Skipping.`);
      return new NextResponse('Event already processed', { status: 200 });
    }

    // --- 3. BUSINESS LOGIC: Processing the Event ---
    // We wrap the heavy logic in a try-catch to handle the transaction safely.
    await prisma.$transaction(async (tx) => {
      
      // Record the event immediately to prevent race conditions on concurrent retries
      await tx.processedWebhookEvent.create({
        data: {
          id: eventId,
          type: event.type,
          payload: event.data.object as any, // Store relevant payload data
          processedAt: new Date(),
        },
      });

      // Handle specific event types (e.g., 'customer.subscription.updated')
      switch (event.type) {
        case 'invoice.payment_succeeded':
          const invoice = event.data.object as Stripe.Invoice;
          // Logic: Update user's subscription status in DB
          await tx.userSubscription.update({
            where: { stripeCustomerId: invoice.customer as string },
            data: { status: 'active', currentPeriodEnd: new Date(invoice.current_period_end * 1000) },
          });
          console.log(`Updated subscription for customer ${invoice.customer}`);
          break;

        case 'customer.subscription.deleted':
          const subscription = event.data.object as Stripe.Subscription;
          // Logic: Downgrade user to free plan
          await tx.userSubscription.update({
            where: { stripeCustomerId: subscription.customer as string },
            data: { status: 'canceled', plan: 'free' },
          });
          console.log(`Cancelled subscription for customer ${subscription.customer}`);
          break;

        default:
          console.log(`Unhandled event type: ${event.type}`);
      }
    });

    // --- 4. PERFORMANCE: Offload Heavy Tasks (Conceptual) ---
    // If we had heavy tasks (e.g., generating a PDF invoice, sending an email),
    // we would push a job to a queue like BullMQ or Upstash QStash here.
    // Example: await queue.add('send-welcome-email', { userId: ... });

    return new NextResponse('Webhook processed successfully', { status: 200 });

  } catch (error) {
    // If anything fails during processing, we log it and return an error.
    // Stripe will retry sending the webhook if we return a 5xx status.
    console.error('Error processing webhook event:', error);
    return new NextResponse('Webhook handler failed', { status: 500 });
  }
}
