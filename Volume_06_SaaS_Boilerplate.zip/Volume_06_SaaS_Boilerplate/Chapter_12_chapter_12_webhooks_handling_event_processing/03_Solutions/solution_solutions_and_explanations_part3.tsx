/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

// components/JobStatusMonitor.tsx
'use client';

import { useState, useEffect } from 'react';

interface StatusMessage {
  id: number;
  timestamp: string;
  message: string;
}

export default function JobStatusMonitor() {
  const [statusLog, setStatusLog] = useState<StatusMessage[]>([]);
  const [connectionStatus, setConnectionStatus] = useState<'connecting' | 'connected' | 'disconnected'>('connecting');

  useEffect(() => {
    // Initialize EventSource
    const eventSource = new EventSource('/api/events/status');

    // Handler for when connection opens
    eventSource.onopen = () => {
      console.log('SSE Connection Established');
      setConnectionStatus('connected');
    };

    // Handler for incoming messages
    eventSource.onmessage = (event) => {
      try {
        // Parse the JSON data sent from the server
        const data: StatusMessage = JSON.parse(event.data);
        
        // Update state immutably
        setStatusLog((prevLogs) => [...prevLogs, data]);
      } catch (error) {
        console.error('Failed to parse SSE data:', error);
      }
    };

    // Handler for errors
    // Note: The browser's EventSource implementation handles automatic reconnection
    // by default. We listen here primarily to update UI state or handle specific errors.
    eventSource.onerror = () => {
      console.error('SSE Connection Error');
      setConnectionStatus('disconnected');
      // The browser will attempt to reconnect automatically.
      // We can explicitly close if we want to stop retrying:
      // eventSource.close();
    };

    // Cleanup function: Runs when component unmounts
    return () => {
      eventSource.close();
      setConnectionStatus('disconnected');
      console.log('SSE Connection Closed');
    };
  }, []); // Empty dependency array ensures this runs once on mount

  return (
    <div className="p-4 border rounded-md shadow-sm bg-white max-w-md mx-auto">
      <div className="flex justify-between items-center mb-4">
        <h3 className="font-bold text-lg">Job Status Monitor</h3>
        <span className={`text-xs px-2 py-1 rounded ${
          connectionStatus === 'connected' ? 'bg-green-100 text-green-800' : 
          connectionStatus === 'connecting' ? 'bg-yellow-100 text-yellow-800' : 'bg-red-100 text-red-800'
        }`}>
          {connectionStatus.toUpperCase()}
        </span>
      </div>
      
      <div className="space-y-2 max-h-64 overflow-y-auto">
        {statusLog.length === 0 ? (
          <p className="text-gray-400 text-sm italic">Waiting for updates...</p>
        ) : (
          statusLog.map((log) => (
            <div key={log.id} className="text-sm bg-gray-50 p-2 rounded border border-gray-100">
              <div className="text-gray-500 text-xs">{log.timestamp}</div>
              <div className="font-medium">{log.message}</div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
