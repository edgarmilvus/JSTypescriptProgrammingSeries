/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

// simulateQueue.ts

interface QueueItem {
  id: string;
  payload: { [key: string]: any };
  retryCount: number;
}

// Mock queues
let mainQueue: QueueItem[] = [
  { id: '1', payload: { data: 'valid' }, retryCount: 0 },
  { id: '2', payload: { data: 'valid' }, retryCount: 0 },
  { id: '3', payload: { isPoison: true, data: 'bad' }, retryCount: 0 }, // The Poison Pill
  { id: '4', payload: { data: 'valid' }, retryCount: 0 },
  { id: '5', payload: { data: 'valid' }, retryCount: 0 },
];

const deadLetterQueue: QueueItem[] = [];

// Simulation function
async function processQueue() {
  console.log('Starting Queue Processing...');
  
  // Process until the main queue is empty
  while (mainQueue.length > 0) {
    // Shift the first item from the queue (FIFO)
    const item = mainQueue.shift();
    
    if (!item) continue;

    try {
      // Simulate network latency
      await new Promise(resolve => setTimeout(resolve, 200));

      // Check for poison flag
      if (item.payload.isPoison) {
        throw new Error('Poison pill detected: Invalid data structure');
      }

      console.log(`✅ Processed item ${item.id} successfully.`);
      
    } catch (error) {
      console.error(`❌ Error processing item ${item.id}:`, (error as Error).message);
      
      // Retry Logic
      if (item.retryCount < 2) { // Allow 3 attempts total (0, 1, 2)
        item.retryCount++;
        console.log(`🔄 Retrying item ${item.id}. Attempt: ${item.retryCount}`);
        
        // Push to end of queue for later processing
        mainQueue.push(item);
      } else {
        // Max retries reached
        console.log(`💀 Moving item ${item.id} to Dead Letter Queue.`);
        deadLetterQueue.push(item);
      }
    }
  }

  console.log('\n--- Processing Complete ---');
  console.log(`Dead Letter Queue Items: ${deadLetterQueue.length}`);
  console.log(`Remaining Main Queue Items: ${mainQueue.length}`);
  
  if (deadLetterQueue.length > 0) {
    console.log('\nItems in DLQ:');
    deadLetterQueue.forEach(item => console.log(`- ID: ${item.id}, Payload: ${JSON.stringify(item.payload)}`));
  }
}

// Run the simulation
processQueue();

/*
 * QUESTION ANSWER:
 * How does moving the "poison pill" to a DLQ prevent the system from entering an infinite loop, 
 * and why is this critical for a production webhook handler?
 *
 * ANSWER:
 * 1. Prevention of Infinite Loops: Without a DLQ and a retry limit, the "poison pill" would 
 *    fail processing, be re-queued, and immediately be picked up again to fail repeatedly. 
 *    This creates a tight infinite loop that consumes CPU and memory resources, effectively 
 *    stalling the processing of valid events in the queue.
 * 
 * 2. System Stability: In a production webhook handler, events are often processed asynchronously. 
 *    If a single malformed event (e.g., corrupted data, schema mismatch) blocks the queue, 
 *    all subsequent valid events are delayed. This leads to data staleness and poor user experience.
 * 
 * 3. Observability: By moving the item to a DLQ, the system flags the problematic event for 
 *    manual inspection or automated analysis. Engineers can fix the bug in the consumer logic 
 *    or repair the data, then replay the event from the DLQ, ensuring no data is lost.
 */
