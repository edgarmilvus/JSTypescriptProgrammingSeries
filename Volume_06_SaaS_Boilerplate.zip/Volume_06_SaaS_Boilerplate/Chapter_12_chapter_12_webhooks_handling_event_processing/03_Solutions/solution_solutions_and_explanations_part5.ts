/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

// weather-agent.ts
import { StateGraph, Annotation } from "@langchain/langgraph";

// 1. Define State Interface
const StateAnnotation = Annotation.Root({
  city: Annotation<string>,
  weatherReport: Annotation<string>({
    reducer: (curr, update) => update ?? curr, // Simple overwrite reducer
    default: () => "",
  }),
});

type State = typeof StateAnnotation.State;

// 2. Define Asynchronous Node
const fetchWeatherNode = async (state: State): Promise<Partial<State>> => {
  console.log(`[Node] Starting fetch for: ${state.city}`);

  // 3. Simulate Asynchronous Tool Handling
  // We wrap the setTimeout in a Promise. This is mandatory because:
  // - It converts the callback-based API (setTimeout) into a Promise-based one.
  // - It allows us to use the 'await' keyword to pause execution until the timer finishes.
  const weatherData = await new Promise<string>((resolve) => {
    setTimeout(() => {
      // Simulated external API response
      const temp = Math.floor(Math.random() * (80 - 50 + 1) + 50);
      resolve(`${state.city} Weather: Sunny, ${temp}°F`);
    }, 1000); // 1 second delay
  });

  console.log(`[Node] Fetch complete.`);
  
  // Return the state update
  return { weatherReport: weatherData };
};

// 4. Compile Graph
const workflow = new StateGraph(StateAnnotation)
  .addNode("fetch_weather", fetchWeatherNode)
  .addEdge("__start__", "fetch_weather")
  .addEdge("fetch_weather", "__end__");

const app = workflow.compile();

// 5. Execution
async function runAgent() {
  const inputs = { city: "San Francisco" };
  console.log("--- Graph Execution Start ---");
  
  const finalState = await app.invoke(inputs);
  
  console.log("--- Graph Execution End ---");
  console.log("Final State:", finalState);
}

// Execute if this file is run directly
if (require.main === module) {
  runAgent();
}

/*
 * CRITICAL EXPLANATION:
 * Why is async/await and Promise wrapping mandatory?
 * 
 * 1. The Event Loop: Node.js is non-blocking. If we used a synchronous sleep (which doesn't 
 *    exist natively without blocking libraries), the entire thread would freeze. By using 
 *    Promise and setTimeout, we allow the event loop to continue processing other tasks 
 *    (if any) while waiting for the weather data.
 * 
 * 2. Graph Control Flow: LangGraph.js relies on the return value of node functions. 
 *    If a node is async, it returns a Promise. The LangGraph runtime automatically awaits 
 *    this Promise before merging the result into the state and moving to the next node.
 * 
 * 3. Data Integrity: If we did NOT await the Promise inside the node (e.g., just returned 
 *    the Promise object itself or didn't wrap the logic), the graph would receive an 
 *    unresolved Promise object as the state update. This would corrupt the state, 
 *    causing downstream nodes to fail or operate on incorrect data.
 */
