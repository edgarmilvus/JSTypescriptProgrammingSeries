/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises.ts
// Description: Practical Exercises
// ==========================================

// /api/webhooks/payment/route.ts
import { NextResponse, NextRequest } from 'next/server';
import crypto from 'crypto';

// Mock database for idempotency check
const processedEvents = new Set<string>();

export async function POST(request: NextRequest) {
  const body = await request.text(); // Get raw text for signature verification
  const signature = request.headers.get('stripe-signature');
  
  // 1. Verify the signature exists
  if (!signature) {
    return new NextResponse('Missing signature', { status: 401 });
  }

  // 2. Verify the signature using HMAC-SHA256
  const secret = process.env.WEBHOOK_SECRET!;
  const hmac = crypto.createHmac('sha256', secret);
  const digest = hmac.update(body).digest('hex');
  
  // In a real Stripe implementation, you would use stripe.webhooks.constructEvent
  // For this exercise, we simulate the comparison:
  const expectedSignature = `sha256=${digest}`; 
  // Note: Real Stripe headers might differ, this is a generic HMAC simulation.
  
  // Strict comparison to prevent timing attacks
  if (!crypto.timingSafeEqual(Buffer.from(signature), Buffer.from(expectedSignature))) {
    return new NextResponse('Invalid signature', { status: 401 });
  }

  // 3. Parse the event
  const event = JSON.parse(body);

  // 4. Idempotency Check
  if (processedEvents.has(event.id)) {
    console.log(`Event ${event.id} already processed.`);
    return new NextResponse('Event already processed', { status: 200 });
  }

  // 5. Process Event (Mock logic)
  try {
    console.log(`Processing event: ${event.type}`);
    
    // Simulate business logic (e.g., update database, send email)
    // await handlePaymentEvent(event);

    processedEvents.add(event.id);
    return new NextResponse('Webhook received', { status: 200 });
  } catch (error) {
    console.error('Error processing webhook:', error);
    return new NextResponse('Webhook handler failed', { status: 500 });
  }
}
