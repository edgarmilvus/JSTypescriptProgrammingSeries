/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part2.tsx
// Description: Practical Exercises
// ==========================================

// components/JobStatusMonitor.tsx
'use client';

import { useState, useEffect } from 'react';

interface StatusMessage {
  id: number;
  timestamp: string;
  message: string;
}

export default function JobStatusMonitor() {
  const [statusLog, setStatusLog] = useState<StatusMessage[]>([]);
  const [connectionStatus, setConnectionStatus] = useState<'connecting' | 'connected' | 'disconnected'>('disconnected');

  useEffect(() => {
    // 1. Initialize EventSource
    const eventSource = new EventSource('/api/events/status');

    // 2. Handle Connection Open
    eventSource.onopen = () => {
      console.log('SSE Connection Established');
      setConnectionStatus('connected');
    };

    // 3. Handle Incoming Messages
    eventSource.onmessage = (event) => {
      try {
        const data: StatusMessage = JSON.parse(event.data);
        setStatusLog((prev) => [...prev, data]);
      } catch (error) {
        console.error('Failed to parse SSE data:', error);
      }
    };

    // 4. Handle Errors (Reconnection logic is often handled by the browser automatically,
    // but we can listen to close events to update UI state)
    eventSource.onerror = () => {
      console.error('SSE Connection Error');
      setConnectionStatus('disconnected');
      eventSource.close();
    };

    // 5. Cleanup on unmount
    return () => {
      eventSource.close();
      setConnectionStatus('disconnected');
    };
  }, []);

  return (
    <div className="p-4 border rounded-md">
      <h3 className="font-bold mb-2">Job Status: {connectionStatus}</h3>
      <ul className="space-y-2">
        {statusLog.map((log) => (
          <li key={log.id} className="text-sm bg-gray-100 p-2 rounded">
            <span className="text-gray-500">[{log.timestamp}]</span> {log.message}
          </li>
        ))}
      </ul>
    </div>
  );
}
