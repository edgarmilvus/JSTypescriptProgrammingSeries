/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part3.ts
// Description: Practical Exercises
// ==========================================

// simulateQueue.ts

interface QueueItem {
  id: string;
  payload: { [key: string]: any };
  retryCount: number;
}

// Mock queues
const mainQueue: QueueItem[] = [
  { id: '1', payload: { data: 'valid' }, retryCount: 0 },
  { id: '2', payload: { data: 'valid' }, retryCount: 0 },
  { id: '3', payload: { isPoison: true, data: 'bad' }, retryCount: 0 }, // The Poison Pill
  { id: '4', payload: { data: 'valid' }, retryCount: 0 },
  { id: '5', payload: { data: 'valid' }, retryCount: 0 },
];

const deadLetterQueue: QueueItem[] = [];

// Simulation function
async function processQueue() {
  console.log('Starting Queue Processing...');
  
  // Use a while loop to process until mainQueue is empty
  while (mainQueue.length > 0) {
    const item = mainQueue.shift(); // Take from front
    
    if (!item) continue;

    try {
      // Simulate processing delay
      await new Promise(resolve => setTimeout(resolve, 100));

      // Check for poison
      if (item.payload.isPoison) {
        throw new Error('Poison pill detected!');
      }

      console.log(`Processed item ${item.id} successfully.`);
      
    } catch (error) {
      console.error(`Error processing item ${item.id}:`, (error as Error).message);
      
      // Retry Logic
      if (item.retryCount < 2) { // Allow 3 attempts total (0, 1, 2)
        item.retryCount++;
        console.log(`Retrying item ${item.id}. Count: ${item.retryCount}`);
        mainQueue.push(item); // Re-queue
      } else {
        console.log(`Moving item ${item.id} to Dead Letter Queue.`);
        deadLetterQueue.push(item);
      }
    }
  }

  console.log('Processing complete.');
  console.log('Dead Letter Queue Items:', deadLetterQueue.length);
  console.log('Remaining Main Queue Items:', mainQueue.length);
}

// Run the simulation
processQueue();
