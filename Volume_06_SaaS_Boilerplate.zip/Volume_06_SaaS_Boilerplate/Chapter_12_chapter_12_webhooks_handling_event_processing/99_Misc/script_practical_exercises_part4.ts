/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part4.ts
// Description: Practical Exercises
// ==========================================

// weather-agent.ts
import { StateGraph, Annotation, StateSend } from "@langchain/langgraph";

// 1. Define State
const StateAnnotation = Annotation.Root({
  city: Annotation<string>,
  weatherReport: Annotation<string>,
});

type State = typeof StateAnnotation.State;

// 2. Define the Asynchronous Node
const fetchWeatherNode = async (state: State): Promise<Partial<State>> => {
  console.log(`Fetching weather for ${state.city}...`);

  // 3. Simulate Asynchronous Tool Handling
  // We wrap the async operation in a Promise to ensure non-blocking execution
  // and proper async/await handling within the graph runtime.
  const weatherData = await new Promise<string>((resolve) => {
    setTimeout(() => {
      // Simulated API response
      resolve(`Sunny, 72°F in ${state.city}`);
    }, 1000); // 1 second delay
  });

  // Return the state update
  return { weatherReport: weatherData };
};

// 4. Define Graph
const workflow = new StateGraph(StateAnnotation)
  .addNode("fetch_weather", fetchWeatherNode)
  .addEdge("__start__", "fetch_weather")
  .addEdge("fetch_weather", "__end__");

const app = workflow.compile();

// 5. Execution (Example)
async function runAgent() {
  const inputs = { city: "San Francisco" };
  const finalState = await app.invoke(inputs);
  console.log("Final State:", finalState);
}

// runAgent();

/*
  WHY IS ASYNC MANDATORY?
  -----------------------
  1. Non-Blocking Execution: The Node.js event loop can process other tasks 
     while waiting for the weather API response. If we didn't use async/await, 
     the thread would block (if using synchronous code) or the graph execution 
     might proceed before the data is ready (if not awaiting the Promise).
  
  2. Graph Control Flow: LangGraph.js relies on the resolution of Promises 
     to determine when a node has completed its work. If the node function 
     returns a Promise (which happens implicitly with async functions), 
     the graph runtime awaits it automatically. If you returned a Promise 
     without awaiting it inside the node, you would return the Promise object 
     itself, not the resolved state update, breaking the state accumulation logic.
*/
