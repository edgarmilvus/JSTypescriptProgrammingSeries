/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

// src/app/dashboard/page.tsx

import { redirect } from 'next/navigation';
import { NextRequest, NextResponse } from 'next/server';

/**
 * @description Simulates a session verification function.
 * In a real application, this would interface with your auth provider (e.g., Auth.js, Clerk, Supabase Auth)
 * to validate the session token (like a JWT) from the request cookies.
 * 
 * @param {NextRequest} req - The incoming server request object.
 * @returns {Promise<{ user: { id: string; name: string; role: string } } | null>} 
 *          Returns a user object if the session is valid, otherwise null.
 */
async function verifySession(req: NextRequest): Promise<{ user: { id: string; name: string; role: string } } | null> {
  // In a real-world scenario, you would extract the session cookie (e.g., 'session_token')
  // and validate its signature and expiration.
  const cookie = req.cookies.get('session_token');

  // MOCK: We'll simulate a valid session for the purpose of this example.
  // If the cookie is present, we assume it's valid and return a mock user.
  if (cookie?.value === 'valid-session-token') {
    return {
      user: {
        id: 'user-123',
        name: 'Alice Dev',
        role: 'admin', // Role-Based Access Control (RBAC) example
      },
    };
  }

  // If no valid session is found, return null.
  return null;
}

/**
 * @description A Server Component that serves as the protected dashboard page.
 * It runs exclusively on the server, has zero client-side JavaScript bundle size,
 * and performs session verification before rendering any UI.
 * 
 * @param {Object} props - Component props (none in this case).
 * @param {NextRequest} props.req - The request object is passed by Next.js middleware in the App Router.
 *                                  This is a simplified representation; in practice, you might use a middleware
 *                                  to attach the session to the request context.
 */
export default async function DashboardPage({ req }: { req: NextRequest }) {
  // 1. **Session Verification Logic**
  // We call our verification function directly within the Server Component.
  // This is the core of the protection mechanism.
  const session = await verifySession(req);

  // 2. **Authentication Check & Redirection**
  // If the session is null (user not authenticated), we immediately redirect.
  // The `redirect` function from `next/navigation` throws an error that Next.js catches
  // to perform an HTTP 307 Temporary Redirect. This happens on the server.
  if (!session) {
    redirect('/login');
  }

  // 3. **Authorization Check (RBAC)**
  // We can also perform Role-Based Access Control (RBAC) here.
  // For example, only allow users with the 'admin' role to see this page.
  if (session.user.role !== 'admin') {
    // Redirect unauthorized users to a different page, like a general dashboard or home.
    redirect('/unauthorized');
  }

  // 4. **Protected Content Rendering**
  // If the user is authenticated and authorized, we render the protected content.
  // This code will only execute for valid sessions.
  // Notice: There is no `useEffect`, `useState`, or client-side event handling here.
  // This is pure server-side rendering (SSR).
  return (
    <main style={{ padding: '2rem', fontFamily: 'sans-serif' }}>
      <h1>Welcome to the Admin Dashboard, {session.user.name}!</h1>
      <p>
        This page is protected. Only authenticated users with the 'admin' role can see this content.
      </p>
      <div style={{ marginTop: '1rem', padding: '1rem', border: '1px solid #ccc', borderRadius: '8px' }}>
        <h2>Protected Data Section</h2>
        <p>This entire component is rendered on the server. No sensitive data is exposed to the client-side JavaScript bundle.</p>
        <ul>
          <li><strong>User ID:</strong> {session.user.id}</li>
          <li><strong>Role:</strong> {session.user.role}</li>
        </ul>
      </div>
    </main>
  );
}
