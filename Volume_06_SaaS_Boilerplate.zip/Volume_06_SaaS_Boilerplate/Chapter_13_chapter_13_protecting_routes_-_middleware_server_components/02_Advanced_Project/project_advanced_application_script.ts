/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// middleware.ts
import { NextResponse } from 'next/server';
import type { NextRequest } from 'next/server';
import { 
  chain, 
  csp, 
  trustedTypes, 
  frameGuard, 
  xssProtection 
} from 'next-safe-middleware';

/**
 * Configures the Content Security Policy (CSP) for the application.
 * We explicitly allow 'unsafe-eval' for development (Next.js HMR) 
 * and 'unsafe-inline' for simplicity in this example, though strict CSP 
 * requires nonces or hashes for scripts.
 * 
 * In production, 'script-src' should strictly avoid 'unsafe-inline' and 'unsafe-eval'.
 */
const securityHeaders = csp({
  directives: {
    defaultSrc: ["'self'"],
    scriptSrc: ["'self'", "'unsafe-inline'", "'unsafe-eval'"], // Adjust for production
    styleSrc: ["'self'", "'unsafe-inline'"],
    imgSrc: ["'self'", "blob:", "data:", "https://*.vercel.app"],
    connectSrc: ["'self'", "https://*.vercel.app", "wss:"],
    frameAncestors: ["'none'"], // Prevent clickjacking
  },
});

export const config = {
  matcher: [
    /*
     * Match all request paths except for the ones starting with:
     * - api/auth (auth-related)
     * - _next/static (static files)
     * - _next/image (image optimization files)
     * - favicon.ico (favicon file)
     */
    '/((?!api/auth|_next/static|_next/image|favicon.ico).*)',
  ],
};

/**
 * Applies the security middleware chain.
 * 'chain' combines multiple middleware functions into a single execution flow.
 */
export default chain(
  securityHeaders,
  trustedTypes(), // Enforces Trusted Types API to prevent DOM XSS
  frameGuard({ action: 'deny' }), // Explicitly deny framing
  xssProtection() // Enables browser XSS filtering
);
