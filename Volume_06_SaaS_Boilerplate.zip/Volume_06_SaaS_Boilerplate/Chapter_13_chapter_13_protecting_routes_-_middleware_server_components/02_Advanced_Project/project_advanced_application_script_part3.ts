/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script_part3.ts
// Description: Advanced Application Script
// ==========================================

// actions/ai-actions.ts
'use server';

import { streamText } from 'ai';
import { openai } from '@ai-sdk/openai';
import { createStreamableUI } from 'ai/rsc';
import { requireAuth, hasRole } from '@/lib/auth';
import { prisma } from '@/lib/prisma';
import { z } from 'zod';

// Define input validation schema
const ChatInputSchema = z.object({
  prompt: z.string().min(1).max(1000),
});

/**
 * Server Action: Secure AI Chat Generation
 * 1. Verifies Authentication.
 * 2. Checks RBAC (e.g., only 'admin' can use advanced models).
 * 3. Logs the request to the database.
 * 4. Streams the response back to the client.
 * 
 * @param input - The user's prompt.
 * @returns A streamable UI object.
 */
export async function generateSecureAIResponse(input: { prompt: string }) {
  // 1. Security: Verify Authentication
  const session = await requireAuth();
  
  // 2. Security: Verify RBAC
  const isAdmin = await hasRole('admin');
  
  // Parse input
  const { prompt } = ChatInputSchema.parse(input);

  // 3. Database Operation: Log request (Audit Trail)
  // This runs securely on the server.
  await prisma.chatLog.create({
    data: {
      userId: session.user.id!,
      prompt: prompt,
      timestamp: new Date(),
    },
  });

  // 4. Headless Inference & Streaming
  const stream = createStreamableUI();

  (async () => {
    // Select model based on Role
    const model = isAdmin ? openai('gpt-4') : openai('gpt-3.5-turbo');

    // Generate text stream
    const { textStream } = await streamText({
      model: model,
      prompt: prompt,
    });

    // Stream tokens to the client
    for await (const chunk of textStream) {
      stream.update(<div className="text-green-600">{chunk}</div>);
    }

    stream.done();
  })();

  return stream.value;
}
