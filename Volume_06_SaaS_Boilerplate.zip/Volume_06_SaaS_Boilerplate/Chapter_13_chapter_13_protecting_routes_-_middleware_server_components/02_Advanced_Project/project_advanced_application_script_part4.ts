/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script_part4.ts
// Description: Advanced Application Script
// ==========================================

// app/secure-chat/page.tsx
import { requireAuth } from '@/lib/auth';
import { generateSecureAIResponse } from '@/actions/ai-actions';
import { ChatInterface } from './_components/chat-interface';

/**
 * Secure Chat Page (Server Component)
 * 
 * This component runs exclusively on the server.
 * 1. It calls 'requireAuth()' which throws an error if the user isn't logged in.
 *    Next.js automatically catches this and redirects to the login page or shows an error boundary.
 * 2. It passes the server action 'generateSecureAIResponse' to the client component.
 *    The client cannot inspect or modify this function; it can only invoke it.
 */
export default async function SecureChatPage() {
  // This line blocks rendering if the user is not authenticated.
  const session = await requireAuth();

  return (
    <div className="container mx-auto p-4">
      <header className="mb-6">
        <h1 className="text-2xl font-bold text-gray-800">
          Secure AI Assistant
        </h1>
        <p className="text-sm text-gray-500">
          Logged in as: {session.user?.email}
        </p>
      </header>

      {/* 
        Client Component Hydration:
        We pass the server action as a prop. The client component can call this action,
        but the logic remains secure on the server.
      */}
      <ChatInterface onGenerate={generateSecureAIResponse} />
    </div>
  );
}
