/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script_part5.ts
// Description: Advanced Application Script
// ==========================================

// app/secure-chat/_components/chat-interface.tsx
'use client';

import { useState } from 'react';
import { experimental_useStreamableUI as useStreamableUI } from 'ai/rsc';

interface ChatInterfaceProps {
  onGenerate: (input: { prompt: string }) => Promise<any>;
}

export function ChatInterface({ onGenerate }: ChatInterfaceProps) {
  const [input, setInput] = useState('');
  const [status, setStatus] = useState<'idle' | 'loading'>('idle');
  
  // Hook to manage the streamed UI from the server
  const [streamUI, { submit }] = useStreamableUI(onGenerate);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim()) return;

    setStatus('loading');
    
    // Submit the input to the server action.
    // The 'submit' function handles the communication and updates the 'streamUI' state.
    await submit({ prompt: input });
    
    setStatus('idle');
    setInput('');
  };

  return (
    <div className="border rounded-lg p-4 bg-white shadow-sm">
      {/* 
        Rendered Area: 
        This displays the components streamed directly from the server 
        (e.g., text chunks, interactive buttons, or charts).
      */}
      <div className="min-h-[200px] mb-4 p-2 bg-gray-50 rounded">
        {streamUI || <span className="text-gray-400">Waiting for input...</span>}
      </div>

      <form onSubmit={handleSubmit} className="flex gap-2">
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          disabled={status === 'loading'}
          className="flex-1 border rounded px-3 py-2"
          placeholder="Ask something secure..."
        />
        <button
          type="submit"
          disabled={status === 'loading'}
          className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 disabled:opacity-50"
        >
          {status === 'loading' ? 'Thinking...' : 'Send'}
        </button>
      </form>
    </div>
  );
}
