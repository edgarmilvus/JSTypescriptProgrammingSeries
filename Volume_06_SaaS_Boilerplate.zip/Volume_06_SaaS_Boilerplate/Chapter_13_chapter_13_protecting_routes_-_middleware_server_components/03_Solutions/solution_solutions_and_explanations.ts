/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// app/admin/dashboard/page.tsx
import { auth } from "@/auth"; // Adjust based on your auth library (e.g., NextAuth.js)
import { redirect } from "next/navigation";
import { AdminDashboardClient } from "./_components/admin-dashboard-client";
import { fetchSensitiveData } from "./actions";

export default async function AdminDashboardPage() {
  // 1. Retrieve the session on the server
  const session = await auth();

  // 2. RBAC Check: Ensure user is authenticated and has 'admin' role
  if (!session || session.user?.role !== "admin") {
    // Redirect to login or unauthorized page
    redirect("/login");
  }

  // 3. Fetch sensitive data securely (never sent to client bundle)
  // This runs only on the server. The data is passed as props.
  const sensitiveData = await fetchSensitiveData();

  // 4. Render the component passing the data
  return (
    <div className="p-6">
      <h1>Admin Dashboard</h1>
      {/* Pass data to a Client Component for interactivity */}
      <AdminDashboardClient initialData={sensitiveData} />
    </div>
  );
}

// app/admin/dashboard/actions.ts
"use server";

import { auth } from "@/auth";
import { redirect } from "next/navigation";

// Mock database call
const mockDbCall = async () => {
  return [
    { id: 1, email: "user1@example.com", balance: 1000 },
    { id: 2, email: "user2@example.com", balance: 2500 },
  ];
};

export async function fetchSensitiveData() {
  const session = await auth();
  
  // Double-check security on the server action
  if (!session || session.user?.role !== "admin") {
    redirect("/login");
  }

  return await mockDbCall();
}

// app/admin/dashboard/_components/admin-dashboard-client.tsx
"use client";

import { useTransition } from "react";
import { fetchSensitiveData } from "../actions";

export function AdminDashboardClient({ initialData }: { initialData: any[] }) {
  const [data, setData] = useState(initialData);
  const [isPending, startTransition] = useTransition();

  const handleRefresh = () => {
    startTransition(async () => {
      const newData = await fetchSensitiveData();
      setData(newData);
    });
  };

  return (
    <div>
      <button onClick={handleRefresh} disabled={isPending}>
        {isPending ? "Refreshing..." : "Refresh Data"}
      </button>
      <table>
        <thead>
          <tr>
            <th>ID</th>
            <th>Email</th>
            <th>Balance</th>
          </tr>
        </thead>
        <tbody>
          {data.map((row) => (
            <tr key={row.id}>
              <td>{row.id}</td>
              <td>{row.email}</td>
              <td>{row.balance}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
