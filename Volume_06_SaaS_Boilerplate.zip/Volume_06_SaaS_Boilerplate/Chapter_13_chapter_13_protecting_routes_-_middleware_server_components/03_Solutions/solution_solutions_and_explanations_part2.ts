/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

// middleware.ts
import { NextResponse } from "next/server";
import type { NextRequest } from "next/server";
import nextSafe from "next-safe-middleware";

export function middleware(request: NextRequest) {
  const response = NextResponse.next();

  // Configure next-safe-middleware
  nextSafe({
    // 1. Disable 'unsafe-inline' for scripts
    contentSecurityPolicy: {
      directives: {
        defaultSrc: ["'self'"],
        // Allow scripts only from self and trusted analytics
        scriptSrc: [
          "'self'", 
          "https://www.google-analytics.com",
          // We will add a nonce logic here later for the interactive challenge
        ],
        // Restrict images to a specific CDN
        imgSrc: ["'self'", "https://cdn.example.com", "data:"],
        // Upgrade insecure requests
        upgradeInsecureRequests: [],
      },
    },
    // 2. Enable Trusted Types to prevent DOM XSS
    enableTrustedTypes: true,
    // 3. Referrer Policy
    referrerPolicy: "strict-origin-when-cross-origin",
  })(request, response);

  return response;
}

export const config = {
  matcher: [
    /*
     * Match all request paths except for the ones starting with:
     * - api (API routes)
     * - _next/static (static files)
     * - _next/image (image optimization files)
     * - favicon.ico (favicon file)
     */
    '/((?!api|_next/static|_next/image|favicon.ico).*)',
  ],
};
