/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

// components/LikeButton.tsx
"use client";

import { useState, useTransition } from "react";
import { toggleLike } from "@/app/actions";

export function LikeButton({ postId, initialLikes }: { postId: string; initialLikes: number }) {
  const [likes, setLikes] = useState(initialLikes);
  const [isPending, startTransition] = useTransition();
  const [error, setError] = useState<string | null>(null);
  
  // State to handle the "Undo" window
  const [canUndo, setCanUndo] = useState(false);
  const [optimisticLikes, setOptimisticLikes] = useState<number | null>(null);

  const handleClick = () => {
    setError(null);
    
    // Optimistic Update: Immediately show the increment
    const newCount = likes + 1;
    setOptimisticLikes(newCount);
    
    // Start Transition
    startTransition(async () => {
      try {
        const serverCount = await toggleLike(postId, likes);
        setLikes(serverCount);
        setOptimisticLikes(null);
        
        // Enable Undo functionality for 2 seconds
        setCanUndo(true);
        setTimeout(() => setCanUndo(false), 2000);
      } catch (err) {
        // Revert on failure
        setOptimisticLikes(null);
        setError("Failed to like post. Please try again.");
      }
    });
  };

  const handleUndo = () => {
    // Cancel transition if pending (imperative handle)
    // Note: useTransition doesn't have a direct "cancel" API, 
    // but we can revert state immediately.
    setLikes((prev) => prev - 1);
    setCanUndo(false);
    setError(null);
  };

  // Determine what to display
  const displayLikes = optimisticLikes !== null ? optimisticLikes : likes;
  const isLoading = isPending && optimisticLikes !== null;

  return (
    <div className="flex items-center gap-2">
      <button
        onClick={handleClick}
        disabled={isLoading}
        className={`px-4 py-2 rounded ${isLoading ? "bg-gray-400" : "bg-blue-500 text-white"}`}
      >
        {isLoading ? (
          <span className="flex items-center gap-2">
            <span className="animate-spin">⟳</span> Liking...
          </span>
        ) : (
          `Like (${displayLikes})`
        )}
      </button>

      {/* Undo Button Logic */}
      {canUndo && !isPending && (
        <button onClick={handleUndo} className="text-sm text-red-500 underline">
          Undo
        </button>
      )}

      {error && <span className="text-red-500 text-sm">{error}</span>}
    </div>
  );
}
