/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part7.ts
// Description: Solutions and Explanations
// ==========================================

// components/ModelInference.tsx
"use client";

import { useState } from "react";

export default function ModelInference() {
  const [status, setStatus] = useState("Idle");
  const [result, setResult] = useState("");

  const loadModel = async (version: string) => {
    setStatus("Loading...");
    try {
      const response = await fetch(`/api/models/sentiment?version=${version}`, {
        method: "GET",
      });

      if (response.status === 401) {
        setStatus("Error: Please log in.");
        return;
      }
      if (response.status === 403) {
        setStatus("Error: Access denied. Upgrade subscription.");
        return;
      }

      if (!response.ok) throw new Error("Failed to load");

      // Read the binary stream
      const buffer = await response.arrayBuffer();
      const weights = new Float32Array(buffer);

      // Simulate Inference (Mock)
      setStatus("Running Inference...");
      setTimeout(() => {
        setResult(`Sentiment Analysis Result: Positive (Confidence: ${weights[0]})`);
        setStatus("Complete");
      }, 500);
    } catch (error) {
      setStatus("Error loading model");
    }
  };

  return (
    <div className="p-6 border rounded">
      <h2>ML Inference Client</h2>
      <div className="flex gap-2 mt-2">
        <button onClick={() => loadModel("v1")} className="bg-green-600 text-white p-2 rounded">
          Load Free Model (v1)
        </button>
        <button onClick={() => loadModel("v2")} className="bg-purple-600 text-white p-2 rounded">
          Load Pro Model (v2)
        </button>
      </div>
      <p className="mt-4">Status: {status}</p>
      {result && <div className="mt-2 p-2 bg-gray-100">{result}</div>}
    </div>
  );
}
