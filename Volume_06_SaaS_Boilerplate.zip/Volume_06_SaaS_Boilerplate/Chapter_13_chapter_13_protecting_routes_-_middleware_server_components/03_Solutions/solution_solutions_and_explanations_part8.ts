/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part8.ts
// Description: Solutions and Explanations
// ==========================================

// Copy the content below into a Graphviz renderer (e.g., viz-js.com)
digraph SecurityFlow {
    rankdir=TB;
    node [shape=box, style="rounded,filled", color="#e0e0e0"];
    
    // Client Side
    subgraph cluster_client {
        label = "Client Side (Browser)";
        style = "dashed";
        color = "#4CAF50";
        
        ClientRequest [label="User Interaction\n(e.g., Click 'Admin Dashboard')", fillcolor="#A5D6A7"];
        BrowserEnforcement [label="Browser Enforces CSP/Trusted Types", fillcolor="#FFCC80"];
        RenderUI [label="Render React Components", fillcolor="#90CAF9"];
    }

    // Server Side
    subgraph cluster_server {
        label = "Server Side (Next.js)";
        style = "dashed";
        color = "#2196F3";
        
        Middleware [label="Middleware (next-safe-middleware)\nInject CSP Headers", fillcolor="#FFF59D"];
        AuthCheck [label="Auth Helper (auth())\nVerify Session", fillcolor="#FFAB91"];
        RBAC [label="Server Component\nRole Check (admin?)", fillcolor="#CE93D8"];
        DataFetch [label="Server Action / DB\nFetch Sensitive Data", fillcolor="#80CBC4"];
        Response [label="Send HTTP Response\n(HTML + Headers)", fillcolor="#B0BEC5"];
    }

    // Flow
    ClientRequest -> Middleware [label="1. HTTP Request", color="blue"];
    Middleware -> AuthCheck [label="2. Proceed", color="blue"];
    AuthCheck -> RBAC [label="3. Valid Session", color="blue"];
    RBAC -> DataFetch [label="4. Authorized", color="blue"];
    DataFetch -> Response [label="5. Data Fetched", color="blue"];
    Response -> BrowserEnforcement [label="6. HTML/Headers Received", color="blue"];
    BrowserEnforcement -> RenderUI [label="7. Browser blocks XSS\nEnforces CSP", color="green"];
    
    // Feedback Loop (Client Action)
    RenderUI -> ClientRequest [label="User Interaction", style="dotted"];
}
