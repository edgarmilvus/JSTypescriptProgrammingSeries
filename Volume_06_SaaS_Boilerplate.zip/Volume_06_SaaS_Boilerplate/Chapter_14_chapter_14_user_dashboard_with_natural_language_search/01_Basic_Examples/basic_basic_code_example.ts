/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

// app/actions/search.ts

'use server'; // Marks this function as a Server Action

import { z } from 'zod';

// --- 1. DEFINING THE SCHEMA ---
// We define the expected structure of the search parameters using Zod.
// This schema acts as our "JSON Schema" definition.
const SearchFilterSchema = z.object({
  query: z.string().min(1, "Search query cannot be empty"),
  dateRange: z.enum(["last_7_days", "last_30_days", "all_time"]).default("all_time"),
  priority: z.enum(["high", "medium", "low"]).optional(),
});

// Infer the TypeScript type from the Zod schema for type safety.
type SearchFilter = z.infer<typeof SearchFilterSchema>;

// --- 2. THE SERVER ACTION ---
/**
 * Processes a natural language query into a structured database filter.
 * 
 * @param {string} naturalLanguageQuery - The raw text input from the user (e.g., "Show me high priority tasks from last week").
 * @returns {Promise<SearchFilter>} - A promise that resolves to the structured filter object.
 * 
 * @throws {Error} - If the LLM output cannot be parsed or validation fails.
 */
export async function processSearchQuery(
  naturalLanguageQuery: string
): Promise<SearchFilter> {
  
  // --- 3. LLM INTERACTION (SIMULATED) ---
  // In a real app, this is where you would call an LLM (OpenAI, Anthropic, etc.)
  // with a prompt enforcing the JSON Schema.
  // For this "Hello World" example, we simulate the LLM's output string.
  
  const llmResponseString = simulateLLMResponse(naturalLanguageQuery);

  // --- 4. PARSING AND TYPE NARROWING ---
  // We attempt to parse the raw string from the LLM into a JavaScript object.
  // This is the critical step where we narrow the type from 'unknown' or 'any'
  // to a specific, validated structure.
  let parsedData: unknown;
  
  try {
    parsedData = JSON.parse(llmResponseString);
  } catch (error) {
    throw new Error("LLM produced invalid JSON syntax.");
  }

  // --- 5. VALIDATION (RUNTIME TYPE GUARD) ---
  // We use the Zod schema to validate the parsed object.
  // If validation succeeds, the returned data is typed as 'SearchFilter'.
  // If it fails, Zod throws an error, which we catch and handle.
  const validation = SearchFilterSchema.safeParse(parsedData);

  if (!validation.success) {
    console.error("Validation failed:", validation.error.errors);
    throw new Error("The search parameters extracted are invalid.");
  }

  // At this point, TypeScript knows 'validation.data' is of type 'SearchFilter'.
  // We have successfully narrowed the type from 'unknown' to a specific structure.
  return validation.data;
}

// --- 6. HELPER: SIMULATED LLM RESPONSE ---
// This function mocks an LLM call. It demonstrates how an LLM might interpret
// different user intents and format them according to our JSON Schema.
function simulateLLMResponse(input: string): string {
  const lowerInput = input.toLowerCase();

  if (lowerInput.includes("urgent") || lowerInput.includes("high priority")) {
    // Example: User asks for high priority items
    return JSON.stringify({
      query: "urgent tasks",
      dateRange: "all_time",
      priority: "high"
    });
  } 
  
  if (lowerInput.includes("last week") || lowerInput.includes("recent")) {
    // Example: User asks for recent items
    return JSON.stringify({
      query: "recent updates",
      dateRange: "last_7_days",
      priority: undefined // Optional field
    });
  }

  // Default case
  return JSON.stringify({
    query: input,
    dateRange: "all_time",
    priority: undefined
  });
}
