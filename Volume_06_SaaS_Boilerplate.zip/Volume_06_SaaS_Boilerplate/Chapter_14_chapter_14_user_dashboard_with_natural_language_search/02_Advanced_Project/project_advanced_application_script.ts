/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// app/dashboard/page.tsx
import { SearchClient } from './_components/SearchClient';

// ==========================================
// 1. DATA FETCHING IN SERVER COMPONENTS
// ==========================================

/**
 * Simulates fetching user profile and subscription data from a secure database.
 * In a real app, this would connect to PostgreSQL or a similar backend.
 * @returns {Promise<UserProfile>}
 */
async function getUserProfile(): Promise<UserProfile> {
  // Simulate network delay
  await new Promise((resolve) => setTimeout(resolve, 300));
  
  return {
    id: 'user_123',
    name: 'Alice Developer',
    subscriptionTier: 'pro', // 'pro' allows semantic search
    vectorApiKey: process.env.VECTOR_DB_KEY, // Securely injected
  };
}

/**
 * Simulates fetching initial documents from a vector database (e.g., pgvector).
 * In a real app, this might be a raw SQL query or an ORM call.
 * @returns {Promise<Document[]>}
 */
async function getInitialDocuments(): Promise<Document[]> {
  await new Promise((resolve) => setTimeout(resolve, 300));

  // Mock data representing documents with pre-computed embeddings (vectors)
  return [
    {
      id: 'doc_1',
      title: 'API Documentation: Authentication',
      content: 'To authenticate, use the Bearer token in the header.',
      embedding: [0.1, 0.2, 0.3], // Simplified vector representation
    },
    {
      id: 'doc_2',
      title: 'Billing Invoices Q1',
      content: 'Invoice #4022 was paid on Jan 15th.',
      embedding: [0.9, 0.8, 0.7],
    },
    {
      id: 'doc_3',
      title: 'User Guide: Search Features',
      content: 'You can search using natural language queries.',
      embedding: [0.15, 0.25, 0.35],
    },
  ];
}

// ==========================================
// 2. TYPES AND INTERFACES
// ==========================================

/**
 * Defines the shape of the user profile data.
 */
type SubscriptionTier = 'free' | 'pro' | 'enterprise';

interface UserProfile {
  id: string;
  name: string;
  subscriptionTier: SubscriptionTier;
  vectorApiKey?: string;
}

/**
 * Represents a document in the knowledge base.
 * The `embedding` property represents the vectorized form of the content.
 */
interface Document {
  id: string;
  title: string;
  content: string;
  embedding: number[];
}

/**
 * Props for the Client Component.
 */
interface SearchClientProps {
  initialDocuments: Document[];
  user: UserProfile;
}

// ==========================================
// 3. MAIN SERVER COMPONENT
// ==========================================

/**
 * The Dashboard Page Component.
 * This is a Server Component (default in Next.js 13+).
 * It handles data fetching before rendering the UI.
 */
export default async function DashboardPage() {
  // Fetch data in parallel
  const [user, documents] = await Promise.all([
    getUserProfile(),
    getInitialDocuments(),
  ]);

  // Pass data to the Client Component via props
  return (
    <main className="p-8 bg-gray-50 min-h-screen">
      <div className="max-w-4xl mx-auto">
        <header className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900">Knowledge Base</h1>
          <p className="text-gray-600 mt-2">
            Welcome, {user.name}. Tier: {user.subscriptionTier.toUpperCase()}
          </p>
        </header>

        {/* Client-side interactive search interface */}
        <SearchClient initialDocuments={documents} user={user} />
      </div>
    </main>
  );
}
