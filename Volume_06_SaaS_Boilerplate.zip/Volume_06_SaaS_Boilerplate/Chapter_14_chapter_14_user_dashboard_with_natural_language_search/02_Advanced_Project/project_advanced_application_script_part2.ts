/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script_part2.ts
// Description: Advanced Application Script
// ==========================================

// app/dashboard/_components/SearchClient.tsx
'use client';

import { useState, useMemo } from 'react';

// ==========================================
// 4. CLIENT-SIDE INFERENCE LOGIC
// ==========================================

/**
 * Calculates the cosine similarity between two vectors.
 * This is a core mathematical operation for semantic search.
 * 
 * Formula: cos(theta) = (A . B) / (||A|| * ||B||)
 * 
 * @param a - First vector
 * @param b - Second vector
 * @returns {number} Similarity score between 0 and 1
 */
function cosineSimilarity(a: number[], b: number[]): number {
  const dotProduct = a.reduce((acc, val, i) => acc + val * b[i], 0);
  const magnitudeA = Math.sqrt(a.reduce((acc, val) => acc + val * val, 0));
  const magnitudeB = Math.sqrt(b.reduce((acc, val) => acc + val * val, 0));
  
  if (magnitudeA === 0 || magnitudeB === 0) return 0;
  return dotProduct / (magnitudeA * magnitudeB);
}

/**
 * Converts a natural language string into a vector representation.
 * In a real-world scenario, this would use a client-side ML model (e.g., TensorFlow.js)
 * or a remote embedding API. Here, we simulate it for demonstration.
 * 
 * @param text - The user's search query
 * @returns {number[]} A simulated vector
 */
function textToVector(text: string): number[] {
  // Simple simulation: hash the string to create a pseudo-vector
  // In production, this would be a model inference call.
  const hash = text.split('').reduce((acc, char) => acc + char.charCodeAt(0), 0);
  // Return a deterministic vector based on the hash
  return [
    (hash % 100) / 100,
    ((hash * 2) % 100) / 100,
    ((hash * 3) % 100) / 100,
  ];
}

// ==========================================
// 5. REACT COMPONENT
// ==========================================

export function SearchClient({ initialDocuments, user }: SearchClientProps) {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<Document[]>(initialDocuments);

  /**
   * Handles the search logic.
   * This runs entirely on the client side (Client-side Inference).
   */
  const handleSearch = () => {
    if (!query.trim()) {
      setResults(initialDocuments);
      return;
    }

    // 1. Convert query to vector (Inference)
    const queryVector = textToVector(query);

    // 2. Calculate similarity for each document
    const scoredDocs = initialDocuments.map((doc) => ({
      ...doc,
      score: cosineSimilarity(queryVector, doc.embedding),
    }));

    // 3. Filter and Sort based on threshold
    const filtered = scoredDocs
      .filter((doc) => doc.score > 0.1) // Threshold
      .sort((a, b) => b.score - a.score) // Descending order
      .map(({ score, ...rest }) => rest); // Remove score from UI

    setResults(filtered);
  };

  return (
    <div className="space-y-6">
      {/* Search Input Area */}
      <div className="flex gap-4">
        <input
          type="text"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Ask a question (e.g., 'How do I pay?')..."
          className="flex-1 rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 p-2 border"
        />
        <button
          onClick={handleSearch}
          className="bg-indigo-600 text-white px-6 py-2 rounded-md hover:bg-indigo-700 transition"
        >
          Search
        </button>
      </div>

      {/* Results List */}
      <div className="bg-white shadow rounded-lg divide-y divide-gray-200">
        {results.length === 0 ? (
          <div className="p-4 text-gray-500 text-center">
            No results found matching your query.
          </div>
        ) : (
          results.map((doc) => (
            <div key={doc.id} className="p-4 hover:bg-gray-50">
              <h3 className="font-semibold text-indigo-600">{doc.title}</h3>
              <p className="text-gray-700 mt-1 text-sm">{doc.content}</p>
            </div>
          ))
        )}
      </div>

      {/* Debug / Status Panel */}
      <div className="text-xs text-gray-400 font-mono">
        <p>USER_TIER: {user.subscriptionTier}</p>
        <p>RESULTS_COUNT: {results.length}</p>
        <p>INFERENCE_SOURCE: Client-Side (Simulated)</p>
      </div>
    </div>
  );
}
