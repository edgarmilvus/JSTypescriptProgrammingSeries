/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

import React from 'react';
import styled from 'styled-components';

// --- Styled Components ---
const ResultsContainer = styled.div`
  width: 100%;
  max-width: 600px;
  display: flex;
  flex-direction: column;
  gap: 1rem;
`;

const ResultCard = styled.div`
  border: 1px solid #e0e0e0;
  border-radius: 8px;
  padding: 1rem;
  background-color: #fff;
  box-shadow: 0 2px 4px rgba(0,0,0,0.05);
  transition: transform 0.2s;

  &:hover {
    transform: translateY(-2px);
  }
`;

const CardHeader = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 0.5rem;
`;

const Title = styled.h3`
  margin: 0;
  font-size: 1.1rem;
  color: #333;
`;

const SourceBadge = styled.span`
  background-color: #e3f2fd;
  color: #1565c0;
  padding: 0.25rem 0.5rem;
  border-radius: 12px;
  font-size: 0.75rem;
  font-weight: 600;
  text-transform: uppercase;
`;

const ContentSnippet = styled.p`
  margin: 0 0 0.75rem 0;
  color: #666;
  font-size: 0.95rem;
  line-height: 1.5;
`;

const ScoreBarContainer = styled.div`
  width: 100%;
  height: 6px;
  background-color: #f0f0f0;
  border-radius: 3px;
  overflow: hidden;
`;

const ScoreBarFill = styled.div<{ score: number }>`
  height: 100%;
  background-color: ${props => {
    if (props.score > 75) return '#4caf50'; // Green for high relevance
    if (props.score > 50) return '#ffc107'; // Yellow for medium
    return '#f44336'; // Red for low
  }};
  width: ${props => `${props.score}%`};
`;

const StateMessage = styled.div`
  text-align: center;
  padding: 2rem;
  color: #666;
`;

const SkeletonCard = styled(ResultCard)`
  background: linear-gradient(90deg, #f0f0f0 25%, #e0e0e0 50%, #f0f0f0 75%);
  background-size: 200% 100%;
  animation: loading 1.5s infinite;
  height: 120px;

  @keyframes loading {
    0% { background-position: 200% 0; }
    100% { background-position: -200% 0; }
  }
`;

// --- Interfaces ---
interface SearchResult {
  id: string;
  title: string;
  content: string;
  score: number; // 0 to 1
  source: string;
}

interface SearchResultsProps {
  results: SearchResult[] | null;
  isLoading: boolean;
  error: string | null;
}

// --- Component ---
const SearchResults: React.FC<SearchResultsProps> = ({ results, isLoading, error }) => {
  if (isLoading) {
    return (
      <ResultsContainer>
        <SkeletonCard />
        <SkeletonCard />
        <SkeletonCard />
      </ResultsContainer>
    );
  }

  if (error) {
    return <StateMessage>Error: {error}</StateMessage>;
  }

  if (!results) {
    return <StateMessage>Ready to search. Enter a query above.</StateMessage>;
  }

  if (results.length === 0) {
    return <StateMessage>No results found. Try rephrasing your question.</StateMessage>;
  }

  return (
    <ResultsContainer>
      {results.map((result) => (
        <ResultCard key={result.id}>
          <CardHeader>
            <Title>{result.title}</Title>
            <SourceBadge>{result.source}</SourceBadge>
          </CardHeader>
          <ContentSnippet>
            {result.content.length > 150 ? `${result.content.substring(0, 150)}...` : result.content}
          </ContentSnippet>
          <ScoreBarContainer>
            <ScoreBarFill score={result.score * 100} />
          </ScoreBarContainer>
        </ResultCard>
      ))}
    </ResultsContainer>
  );
};

export default SearchResults;
