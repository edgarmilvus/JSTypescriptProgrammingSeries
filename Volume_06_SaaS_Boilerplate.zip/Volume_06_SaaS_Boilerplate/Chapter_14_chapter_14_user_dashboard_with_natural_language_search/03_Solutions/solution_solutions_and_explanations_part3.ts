/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

import React, { useState, useEffect } from 'react';
import styled from 'styled-components';
import SemanticSearchBar from './SemanticSearchBar'; // Assuming these are in separate files
import SearchResults from './SearchResults';

// --- Styled Components ---
const DashboardContainer = styled.div`
  display: grid;
  grid-template-columns: 300px 1fr;
  gap: 2rem;
  padding: 2rem;
  height: 100vh;
  box-sizing: border-box;

  @media (max-width: 768px) {
    grid-template-columns: 1fr;
    height: auto;
  }
`;

const Sidebar = styled.div`
  background-color: #f8f9fa;
  padding: 1.5rem;
  border-radius: 8px;
  height: fit-content;
`;

const MainContent = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  overflow-y: auto;
`;

const ProfileCard = styled.div`
  text-align: center;
`;

const ProfileName = styled.h2`
  margin: 0 0 0.5rem 0;
`;

const StatusBadge = styled.span<{ status: string }>`
  display: inline-block;
  padding: 0.25rem 0.75rem;
  border-radius: 12px;
  font-size: 0.875rem;
  font-weight: bold;
  background-color: ${props => {
    switch(props.status.toLowerCase()) {
      case 'active': return '#d4edda';
      case 'trial': return '#fff3cd';
      case 'canceled': return '#f8d7da';
      default: return '#e2e3e5';
    }
  }};
  color: ${props => {
    switch(props.status.toLowerCase()) {
      case 'active': return '#155724';
      case 'trial': return '#856404';
      case 'canceled': return '#721c24';
      default: return '#383d41';
    }
  }};
`;

const SectionTitle = styled.h3`
  margin-top: 2rem;
  margin-bottom: 1rem;
  width: 100%;
  text-align: left;
  color: #444;
`;

// --- Interfaces ---
interface UserProfile {
  name: string;
  email: string;
  subscriptionStatus: 'active' | 'trial' | 'canceled' | string;
}

interface SearchResult {
  id: string;
  title: string;
  content: string;
  score: number;
  source: string;
}

// --- Component ---
const Dashboard: React.FC = () => {
  // User Profile State
  const [user, setUser] = useState<UserProfile | null>(null);
  const [userLoading, setUserLoading] = useState<boolean>(true);
  const [userError, setUserError] = useState<string | null>(null);

  // Search State
  const [searchResults, setSearchResults] = useState<SearchResult[] | null>(null);
  const [searchLoading, setSearchLoading] = useState<boolean>(false);
  const [searchError, setSearchError] = useState<string | null>(null);

  // Fetch User Profile on Mount
  useEffect(() => {
    const fetchUser = async () => {
      try {
        // Simulating API call
        // const response = await fetch('/api/user/me');
        // const data = await response.json();
        // Mock data for demonstration:
        setTimeout(() => {
          setUser({ name: 'Alex Doe', email: 'alex@example.com', subscriptionStatus: 'active' });
          setUserLoading(false);
        }, 1000);
      } catch (err) {
        setUserError('Failed to load user profile.');
        setUserLoading(false);
      }
    };

    fetchUser();
  }, []);

  // Search Handler
  const handleSearch = async (query: string) => {
    setSearchLoading(true);
    setSearchResults(null);
    setSearchError(null);

    try {
      // Simulating API call
      // const response = await fetch(`/api/search?query=${encodeURIComponent(query)}`);
      // const data = await response.json();
      // Mock data for demonstration:
      setTimeout(() => {
        const mockResults: SearchResult[] = [
          {
            id: '1',
            title: 'Q3 Financial Report',
            content: 'The third quarter showed a significant increase in revenue, primarily driven by the new product line...',
            score: 0.92,
            source: 'invoice'
          },
          {
            id: '2',
            title: 'Project Alpha Update',
            content: 'Development is on track. The team has completed the integration of the new API endpoints...',
            score: 0.85,
            source: 'project_update'
          }
        ];
        setSearchResults(mockResults);
        setSearchLoading(false);
      }, 1500);
    } catch (err) {
      setSearchError('Failed to fetch search results.');
      setSearchLoading(false);
    }
  };

  return (
    <DashboardContainer>
      {/* Left Column: User Profile & Metrics */}
      <Sidebar>
        <ProfileCard>
          {userLoading && <p>Loading profile...</p>}
          {userError && <p style={{ color: 'red' }}>{userError}</p>}
          {user && (
            <>
              <ProfileName>Welcome, {user.name}!</ProfileName>
              <p>{user.email}</p>
              <StatusBadge status={user.subscriptionStatus}>
                {user.subscriptionStatus}
              </StatusBadge>
            </>
          )}
        </ProfileCard>
      </Sidebar>

      {/* Right Column: Search Interface */}
      <MainContent>
        <SectionTitle>Natural Language Search</SectionTitle>
        <SemanticSearchBar onSearch={handleSearch} isLoading={searchLoading} />
        <SearchResults 
          results={searchResults} 
          isLoading={searchLoading} 
          error={searchError} 
        />
      </MainContent>
    </DashboardContainer>
  );
};

export default Dashboard;
