/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

// useSearchAgent.ts
import { useState } from 'react';

// --- Interfaces ---
export interface SearchResult {
  id: string;
  title: string;
  content: string;
  score: number;
  source: string;
}

interface SearchAgentState {
  results: SearchResult[] | null;
  isLoading: boolean;
  error: string | null;
  feedback: string;
}

// --- Custom Hook ---
export const useSearchAgent = () => {
  const [state, setState] = useState<SearchAgentState>({
    results: null,
    isLoading: false,
    error: null,
    feedback: '',
  });

  const search = async (query: string) => {
    // Reset previous state
    setState(prev => ({ ...prev, error: null, results: null }));

    // --- Edge Logic: Rule 1 (Empty Check) ---
    if (!query || query.trim() === '') {
      setState(prev => ({ ...prev, error: 'Please enter a query.' }));
      return;
    }

    // --- Edge Logic: Rule 2 (Meta Command Check) ---
    if (query.startsWith('/meta ')) {
      setState(prev => ({ ...prev, feedback: 'Processing meta-command...', isLoading: true }));
      // In a real app, you might route to a different endpoint here.
    } else {
      // --- Edge Logic: Rule 3 (Standard Search) ---
      setState(prev => ({ ...prev, feedback: 'Searching your data...', isLoading: true }));
    }

    try {
      // Simulate API Call
      // const response = await fetch(`/api/search?query=${encodeURIComponent(query)}`);
      // const data = await response.json();
      
      // Mocking a response for demonstration
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      const mockResults: SearchResult[] = query.startsWith('/meta ')
        ? [{ id: 'meta-1', title: 'Meta Data', content: 'System index health is 99%.', score: 1.0, source: 'system' }]
        : [
            { id: '1', title: 'Result A', content: `Content for query: ${query}`, score: 0.95, source: 'general' },
            { id: '2', title: 'Result B', content: 'Another relevant document found.', score: 0.88, source: 'docs' }
          ];

      setState({
        results: mockResults,
        isLoading: false,
        error: null,
        feedback: `Found ${mockResults.length} results.`,
      });
    } catch (err) {
      setState({
        results: null,
        isLoading: false,
        error: 'Network error. Please try again.',
        feedback: '',
      });
    }
  };

  return {
    search,
    results: state.results,
    isLoading: state.isLoading,
    error: state.error,
    feedback: state.feedback,
  };
};
