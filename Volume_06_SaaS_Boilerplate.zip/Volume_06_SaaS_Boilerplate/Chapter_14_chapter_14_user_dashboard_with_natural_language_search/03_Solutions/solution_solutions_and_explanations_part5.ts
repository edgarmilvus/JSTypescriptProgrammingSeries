/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

// InteractiveDashboard.tsx
import React from 'react';
import styled from 'styled-components';
import { useSearchAgent } from './useSearchAgent';
import SemanticSearchBar from './SemanticSearchBar';
import SearchResults from './SearchResults';

const DashboardWrapper = styled.div`
  padding: 2rem;
  max-width: 800px;
  margin: 0 auto;
`;

const FeedbackBar = styled.div<{ visible: boolean }>`
  background-color: #e3f2fd;
  color: #1565c0;
  padding: 0.75rem;
  border-radius: 4px;
  margin-bottom: 1rem;
  text-align: center;
  font-weight: 500;
  opacity: ${props => (props.visible ? 1 : 0)};
  transition: opacity 0.3s ease;
  height: ${props => (props.visible ? 'auto' : '0')};
  overflow: hidden;
`;

const InteractiveDashboard: React.FC = () => {
  const { search, results, isLoading, error, feedback } = useSearchAgent();

  return (
    <DashboardWrapper>
      <h2>Edge-First Search Agent</h2>
      <FeedbackBar visible={!!feedback}>
        {feedback}
      </FeedbackBar>
      <SemanticSearchBar onSearch={search} isLoading={isLoading} />
      <SearchResults results={results} isLoading={isLoading} error={error} />
    </DashboardWrapper>
  );
};

export default InteractiveDashboard;
