/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

// File: components/WeatherChatWidget.tsx
'use client';

import { useChat } from 'ai/react';
import { useState } from 'react';

/**
 * Defines the structure of the weather tool arguments.
 * This helps TypeScript infer types for the tool call payload.
 */
interface WeatherToolArguments {
  location: string;
}

/**
 * A mock asynchronous function simulating a weather API call.
 * In a real SaaS app, this would be a fetch request to a weather service.
 * 
 * @param args - The location to fetch weather for.
 * @returns A Promise resolving to a formatted weather string.
 */
const fetchWeather = async (args: WeatherToolArguments): Promise<string> => {
  // Simulate network latency (e.g., 500ms)
  await new Promise((resolve) => setTimeout(resolve, 500));
  
  // Mock data based on location
  const weatherMap: Record<string, string> = {
    'New York': 'Sunny, 22°C',
    'London': 'Rainy, 14°C',
    'Tokyo': 'Cloudy, 18°C',
  };

  const weather = weatherMap[args.location] || 'Unknown location';
  return `The weather in ${args.location} is ${weather}.`;
};

export default function WeatherChatWidget() {
  const [toolResult, setToolResult] = useState<string | null>(null);

  /**
   * The `useChat` hook manages the chat state and API communication.
   * 
   * Key Props:
   * - `api`: The endpoint for the AI API (defaults to /api/chat).
   * - `onToolCall`: A callback invoked when the AI model requests a tool execution.
   *   This is where Asynchronous Tool Handling is implemented.
   */
  const { messages, input, handleInputChange, handleSubmit, isLoading } = useChat({
    api: '/api/chat', // In a real app, this points to your Next.js route handler
    onToolCall: async ({ toolCall }) => {
      // 1. Identify the tool call
      if (toolCall.toolName === 'getCurrentWeather') {
        // 2. Parse arguments safely
        const args = toolCall.args as WeatherToolArguments;
        
        // 3. Execute the asynchronous tool logic
        // The SDK awaits this Promise before proceeding.
        const result = await fetchWeather(args);
        
        // 4. Update local state to display the result immediately
        setToolResult(`Tool executed: ${result}`);
        
        // 5. Return the result to the AI model for context
        // The model will use this string to generate a natural language response.
        return result;
      }
    },
  });

  return (
    <div style={{ border: '1px solid #ccc', padding: '1rem', maxWidth: '500px' }}>
      <div style={{ marginBottom: '1rem', minHeight: '200px', overflowY: 'auto' }}>
        {messages.map((m) => (
          <div key={m.id} style={{ marginBottom: '0.5rem' }}>
            <strong>{m.role === 'user' ? 'You: ' : 'AI: '}</strong>
            <span>{m.content}</span>
            {/* Display tool execution status if available */}
            {m.toolInvocations && (
              <div style={{ fontSize: '0.8rem', color: '#666', marginTop: '4px' }}>
                (Tool Running...)
              </div>
            )}
          </div>
        ))}
        {toolResult && (
          <div style={{ fontSize: '0.8rem', color: 'green', marginTop: '4px' }}>
            {toolResult}
          </div>
        )}
      </div>

      <form onSubmit={handleSubmit}>
        <input
          type="text"
          value={input}
          onChange={handleInputChange}
          placeholder="Ask about weather in New York, London, or Tokyo..."
          disabled={isLoading}
          style={{ width: '100%', padding: '8px' }}
        />
        <button type="submit" disabled={isLoading} style={{ marginTop: '8px' }}>
          {isLoading ? 'Thinking...' : 'Send'}
        </button>
      </form>
    </div>
  );
}
