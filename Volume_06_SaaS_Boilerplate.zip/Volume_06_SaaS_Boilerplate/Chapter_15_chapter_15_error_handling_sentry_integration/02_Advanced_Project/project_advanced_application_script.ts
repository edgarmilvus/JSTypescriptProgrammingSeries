/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// lib/errors/AppError.ts
/**
 * @fileoverview Defines the custom AppError class for structured error handling.
 * This allows us to differentiate between operational errors (expected) and
 * programmer errors (unexpected) and attach metadata for better logging.
 */

/**
 * Enum for standard error types. This helps in categorizing errors
 * for both client-side handling and server-side logging.
 */
export enum ErrorType {
  VALIDATION = 'VALIDATION_ERROR',
  AUTH = 'AUTHENTICATION_ERROR',
  NOT_FOUND = 'NOT_FOUND_ERROR',
  INTERNAL = 'INTERNAL_SERVER_ERROR',
  RATE_LIMIT = 'RATE_LIMIT_ERROR',
}

/**
 * Custom error class for application-specific errors.
 * Extends the native Error class to include type, status code, and metadata.
 */
export class AppError extends Error {
  public readonly type: ErrorType;
  public readonly statusCode: number;
  public readonly isOperational: boolean;
  public readonly metadata?: Record<string, any>;

  /**
   * @param message - Human-readable error message.
   * @param type - The category of the error (from ErrorType enum).
   * @param statusCode - HTTP status code to send to the client.
   * @param isOperational - If true, it's a known operational error (e.g., invalid input).
   *                        If false, it's a programmer error (e.g., bug in code).
   * @param metadata - Additional context to attach to the error report (e.g., userId, field).
   */
  constructor(
    message: string,
    type: ErrorType,
    statusCode: number,
    isOperational: boolean = true,
    metadata?: Record<string, any>
  ) {
    super(message);
    this.type = type;
    this.statusCode = statusCode;
    this.isOperational = isOperational;
    this.metadata = metadata;

    // Maintains proper stack trace for debugging (available in V8 environments).
    Error.captureStackTrace(this, this.constructor);
  }
}

// lib/sentry.ts
/**
 * @fileoverview Sentry configuration and helper functions.
 * This module initializes Sentry and provides a function to capture exceptions
 * with enriched context, ensuring we get actionable alerts.
 */

import * as Sentry from '@sentry/nextjs';
import { AppError } from './errors/AppError';

// Initialize Sentry. This is typically done in your `instrumentation.ts` or `sentry.server.config.ts`.
// For this script, we'll assume it's initialized elsewhere, but we define the capture helper here.
// In a real project, you'd call Sentry.init() with your DSN and environment variables.
Sentry.init({
  dsn: process.env.SENTRY_DSN,
  environment: process.env.NODE_ENV,
  // Performance monitoring
  tracesSampleRate: 1.0,
  // Error filtering
  beforeSend(event) {
    // Filter out specific errors or add tags here.
    return event;
  },
});

/**
 * Captures an exception and enriches it with context.
 * This is the primary function we'll use in our error handler.
 *
 * @param error - The error object (can be AppError or native Error).
 * @param context - Optional context to add to the Sentry report (e.g., userId, requestId).
 */
export function captureException(error: any, context?: Record<string, any>) {
  // If it's our custom AppError, we can extract structured data.
  if (error instanceof AppError) {
    Sentry.captureException(error, {
      level: 'error',
      tags: {
        error_type: error.type,
        is_operational: error.isOperational,
      },
      extra: {
        metadata: error.metadata,
        ...context,
      },
    });
  } else {
    // For generic errors, we capture them as is.
    Sentry.captureException(error, {
      extra: context,
    });
  }
}

/**
 * Helper to set user context for Sentry. This should be called
 * in your middleware or server action for authenticated requests.
 * @param userId - The ID of the current user.
 */
export function setUserContext(userId: string) {
  Sentry.setUser({ id: userId });
}

/**
 * Clears the user context from Sentry. Call this after a request is processed.
 */
export function clearUserContext() {
  Sentry.setUser(null);
}

// lib/errors/errorHandler.ts
/**
 * @fileoverview Global error handling middleware for Next.js App Router.
 * This higher-order function wraps server-side logic (API routes, Server Actions)
 * to catch, format, and report errors consistently.
 */

import { NextResponse } from 'next/server';
import { AppError, ErrorType } from './AppError';
import { captureException, setUserContext, clearUserContext } from '../sentry';

/**
 * A generic response type for our API endpoints.
 */
interface ApiResponse<T> {
  success: boolean;
  data?: T;
  error?: {
    message: string;
    type: ErrorType;
    statusCode: number;
  };
}

/**
 * Higher-order function that wraps an asynchronous handler.
 * It catches any errors thrown within the handler and processes them.
 *
 * @param handler - The async function containing the core business logic.
 * @returns A wrapped function that handles errors gracefully.
 */
export function errorHandler<T, P>(
  handler: (args: P) => Promise<T>
): (args: P) => Promise<NextResponse<ApiResponse<T>>> {
  return async (args: P) => {
    try {
      // Execute the core logic.
      const result = await handler(args);
      
      // Return a successful response.
      return NextResponse.json(
        { success: true, data: result },
        { status: 200 }
      );
    } catch (error: any) {
      // 1. Log the error to Sentry with context.
      // In a real app, you'd extract userId from the request args or session.
      const context = { timestamp: new Date().toISOString(), args };
      captureException(error, context);

      // 2. Determine if it's a known AppError or an unexpected system error.
      if (error instanceof AppError) {
        // It's an operational error we know about.
        return NextResponse.json(
          {
            success: false,
            error: {
              message: error.message,
              type: error.type,
              statusCode: error.statusCode,
            },
          },
          { status: error.statusCode }
        );
      } else {
        // It's an unexpected programmer error (e.g., TypeError, ReferenceError).
        // We should NOT leak details to the client in production.
        const isProduction = process.env.NODE_ENV === 'production';
        const message = isProduction
          ? 'An unexpected internal server error occurred.'
          : error.message; // Show detailed error in development.

        return NextResponse.json(
          {
            success: false,
            error: {
              message,
              type: ErrorType.INTERNAL,
              statusCode: 500,
            },
          },
          { status: 500 }
        );
      }
    } finally {
      // Clean up any context (e.g., Sentry user context).
      clearUserContext();
    }
  };
}

// app/actions/auth.ts
/**
 * @fileoverview Server Action for user authentication.
 * This demonstrates how to use the error handler and AppError in a real-world scenario.
 * Server Actions run securely on the server and are ideal for mutations like logins.
 */

'use server'; // Marks this file as containing Server Actions.

import { AppError, ErrorType } from '@/lib/errors/AppError';
import { errorHandler } from '@/lib/errors/errorHandler';
import { setUserContext } from '@/lib/sentry';

// Simulated database for demonstration purposes.
// In a real app, this would be a Prisma or Drizzle query.
const MOCK_DB = [
  { id: 'usr_123', email: 'user@example.com', password: 'password123' },
];

/**
 * Interface for the login action arguments.
 */
interface LoginActionArgs {
  email: string;
  password: string;
}

/**
 * Performs user login.
 * Wrapped in our `errorHandler` to catch and format any errors.
 */
export const loginUser = errorHandler(async (args: LoginActionArgs) => {
  const { email, password } = args;

  // 1. Input Validation (Operational Error)
  if (!email || !password) {
    throw new AppError(
      'Email and password are required.',
      ErrorType.VALIDATION,
      400,
      true,
      { field: 'email' }
    );
  }

  // 2. Database Lookup (Simulated)
  const user = MOCK_DB.find((u) => u.email === email);

  // 3. Authentication Check (Operational Error)
  if (!user || user.password !== password) {
    // We log this as an AUTH error. Note: We don't leak which part failed.
    throw new AppError(
      'Invalid email or password.',
      ErrorType.AUTH,
      401,
      true,
      { email } // Log the email for security monitoring, but not in the response.
    );
  }

  // 4. Set Sentry context for this user's subsequent actions.
  setUserContext(user.id);

  // 5. Simulate a potential programmer error (e.g., accessing a property on null).
  // Uncomment the next line to see how the error handler catches an unexpected error.
  // const nullObject: any = null;
  // nullObject.property; // This will throw a TypeError.

  // 6. Success: Return user data (excluding password).
  const { password: _, ...safeUser } = user;
  return safeUser;
});

// Example Usage (Conceptual)
// In a real Next.js page or API route, you would call the server action:
// const result = await loginUser({ email: 'user@example.com', password: 'wrong' });
// if (!result.success) {
//   // Handle client-side error display based on result.error.type
//   console.error(result.error.message);
// }
