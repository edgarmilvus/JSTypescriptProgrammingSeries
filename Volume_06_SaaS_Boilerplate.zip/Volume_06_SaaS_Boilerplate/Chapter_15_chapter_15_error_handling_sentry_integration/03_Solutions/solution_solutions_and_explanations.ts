/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// types/error.types.ts
export interface ErrorResponse {
  status: string;
  statusCode: number;
  message: string;
  stack?: string;
  errors?: any[];
}

// utils/AppError.ts
export class AppError extends Error {
  public readonly statusCode: number;
  public readonly status: string;

  constructor(message: string, statusCode: number) {
    super(message);
    this.statusCode = statusCode;
    this.status = `${statusCode}`.startsWith('4') ? 'fail' : 'error';
    
    // Maintains proper stack trace for where our error was instantiated (only in V8)
    Error.captureStackTrace(this, this.constructor);
  }
}

// utils/catchAsync.ts
// Higher-order function to wrap async route handlers
export const catchAsync = (fn: (req: any, res: any, next: any) => Promise<any>) => {
  return (req: any, res: any, next: any) => {
    fn(req, res, next).catch(next);
  };
};

// middleware/errorMiddleware.ts
import { Request, Response, NextFunction } from 'express';
import { PrismaClientKnownRequestError } from '@prisma/client/runtime/library';
import { ZodError } from 'zod';
import { AppError } from '../utils/AppError';
import { ErrorResponse } from '../types/error.types';

export const errorMiddleware = (
  err: Error | AppError | PrismaClientKnownRequestError | ZodError,
  req: Request,
  res: Response,
  next: NextFunction
) => {
  // Default to 500 if status code is undefined
  let statusCode = 500;
  let status = 'error';
  let message = 'Something went very wrong!';
  let errors: any[] | undefined;

  // 1. Handle AppError (Operational errors we defined)
  if (err instanceof AppError) {
    statusCode = err.statusCode;
    status = err.status;
    message = err.message;
  } 
  // 2. Handle ZodError (Validation errors)
  else if (err instanceof ZodError) {
    statusCode = 400;
    status = 'fail';
    message = 'Validation failed';
    errors = err.flatten().fieldErrors; // Extract field-specific errors
  }
  // 3. Handle Prisma Errors
  else if (err instanceof PrismaClientKnownRequestError) {
    statusCode = 400; // Default for known request errors
    status = 'fail';
    
    // Handle specific Prisma error codes
    switch (err.code) {
      case 'P2002': // Unique constraint violation
        message = 'Duplicate field value entered. Please use another value.';
        break;
      case 'P2025': // Record not found
        message = 'The requested record does not exist.';
        statusCode = 404;
        break;
      default:
        message = `Database error: ${err.message}`;
    }
  }
  // 4. Handle Unknown/Development Errors
  else {
    // If it's a standard Error object, we might want to grab the message
    if (err instanceof Error) message = err.message;
    
    // Log unknown error for developers
    console.error('💥 UNHANDLED ERROR:', err);
  }

  // 5. Production vs Development Logic
  const isProduction = process.env.NODE_ENV === 'production';

  const response: ErrorResponse = {
    status,
    statusCode,
    message,
  };

  // Include stack trace and errors only in development
  if (!isProduction) {
    response.stack = err.stack;
    if (errors) response.errors = errors;
  }

  res.status(statusCode).json(response);
};
