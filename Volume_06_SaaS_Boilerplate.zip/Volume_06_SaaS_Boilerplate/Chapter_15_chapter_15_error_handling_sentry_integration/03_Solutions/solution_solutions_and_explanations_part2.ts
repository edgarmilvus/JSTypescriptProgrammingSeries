/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

// sentry.server.config.ts
import * as Sentry from '@sentry/nextjs';

const SENTRY_DSN = process.env.SENTRY_DSN || process.env.NEXT_PUBLIC_SENTRY_DSN;

Sentry.init({
  dsn: SENTRY_DSN,
  // Adjust sample rate for production to manage costs
  tracesSampleRate: process.env.NODE_ENV === 'production' ? 0.2 : 1.0,
  // Capture 100% of transactions in development
  debug: process.env.NODE_ENV === 'development',
  environment: process.env.NODE_ENV,
  
  // Integrations allow for additional features
  integrations: [
    new Sentry.Integrations.Http({ tracing: true }),
    new Sentry.Integrations.Prisma({ client: prisma }), // If using Prisma
  ],
});

// lib/sentry-utils.ts
import * as Sentry from '@sentry/nextjs';

export interface CaptureContext {
  userId?: string;
  tags?: Record<string, string>;
  extra?: Record<string, any>;
}

export const captureException = (error: unknown, context?: CaptureContext) => {
  // 1. Filter Logic: Ignore specific non-critical errors
  // Example: Ignore 404s or specific generic network errors if desired
  if (error instanceof Error && error.message.includes('User not found')) {
    // Optional: Log locally but don't send to Sentry
    console.warn('Filtered Sentry event: User not found');
    return;
  }

  // 2. Add Context
  return Sentry.captureException(error, (scope) => {
    if (context?.userId) {
      scope.setUser({ id: context.userId });
    }
    if (context?.tags) {
      scope.setTags(context.tags);
    }
    if (context?.extra) {
      scope.setExtras(context.extra);
    }
    return scope;
  });
};

// Example usage in an API route or Server Action
// import { captureException } from '@/lib/sentry-utils';
// try { ... } catch (e) { captureException(e, { userId: '123' }); }
