/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

// app/actions/user.actions.ts
'use server';

export async function updateUserProfile(prevState: any, formData: FormData) {
  // Simulate random failure
  if (Math.random() > 0.5) {
    // In a real app, throw a specific Error or AppError
    throw new Error('Database connection timeout. Please try again.');
  }
  return { success: true, message: 'Profile updated successfully.' };
}

// components/UserProfileForm.tsx
'use client';

import { useActionState, useState, useEffect } from 'react';
import { updateUserProfile } from '@/app/actions/user.actions';

// Define the shape of the state returned by the action
type ActionState = {
  success: boolean | null;
  message: string | null;
};

const initialState: ActionState = {
  success: null,
  message: null,
};

export function UserProfileForm() {
  // useActionState (available in Next.js 14+ / React 19)
  // It handles the pending state and the return value of the action
  const [state, formAction, isPending] = useActionState(
    updateUserProfile,
    initialState
  );

  // Local state to control toast visibility
  const [showToast, setShowToast] = useState(false);

  // Effect to show toast when state changes (especially on error)
  useEffect(() => {
    if (state?.message) {
      setShowToast(true);
      // Auto-hide toast after 5 seconds
      const timer = setTimeout(() => setShowToast(false), 5000);
      return () => clearTimeout(timer);
    }
  }, [state]);

  return (
    <div className="max-w-md mx-auto p-6 border rounded-lg shadow-sm">
      <h2 className="text-xl font-bold mb-4">Update Profile</h2>
      
      {/* The Form */}
      <form action={formAction} className="space-y-4">
        <div>
          <label className="block text-sm font-medium mb-1">Name</label>
          <input
            type="text"
            name="name"
            className="w-full p-2 border rounded-md"
            placeholder="Enter your name"
          />
        </div>
        
        <button
          type="submit"
          disabled={isPending}
          className={`px-4 py-2 rounded-md text-white font-semibold ${
            isPending ? 'bg-gray-400 cursor-not-allowed' : 'bg-blue-600 hover:bg-blue-700'
          }`}
        >
          {isPending ? 'Updating...' : 'Update Profile'}
        </button>
      </form>

      {/* Toast Notification */}
      {showToast && state?.message && (
        <div className={`mt-4 p-4 rounded-md border ${
          state.success 
            ? 'bg-green-50 border-green-200 text-green-800' 
            : 'bg-red-50 border-red-200 text-red-800'
        }`}>
          <div className="flex justify-between items-center">
            <span>{state.message}</span>
            {/* Interactive Challenge: Retry Button */}
            {!state.success && (
              <button
                onClick={() => window.location.reload()} // Simple reload for retry, or trigger formAction again
                className="ml-4 text-sm underline font-bold"
              >
                Retry
              </button>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
