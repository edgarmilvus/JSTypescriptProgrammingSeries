/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

// graph/nodes/weather.node.ts
import { ToolNode } from "@langchain/langgraph/prebuilt";
import { z } from "zod";

// 1. Define the Zod Schema
const WeatherSchema = z.object({
  city: z.string().describe("The city to get weather for"),
});

// 2. Create the Async Tool Function
export const fetchWeatherData = async ({ city }: z.infer<typeof WeatherSchema>) => {
  const API_KEY = process.env.OPENWEATHER_API_KEY;
  
  if (!API_KEY) {
    return "Error: API Key missing.";
  }

  try {
    // Simulate an external API call
    const response = await fetch(
      `https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${API_KEY}&units=metric`
    );

    if (!response.ok) {
      // Handle HTTP errors (404, 500, etc.)
      return `Error: Unable to fetch weather for ${city}. Status: ${response.status}`;
    }

    const data = await response.json();
    
    // Format the result for the LLM
    const summary = `Weather in ${city}: ${data.weather[0].description}, Temp: ${data.main.temp}°C`;
    return summary;

  } catch (error) {
    // Handle network errors (DNS, timeout, etc.)
    console.error("Weather tool error:", error);
    return `Error: Network failure while fetching weather for ${city}.`;
  }
};

// 3. Define the Tool Object with Schema
// LangChain tools typically require a schema and function definition
import { tool } from "@langchain/core/tools";

export const weatherTool = tool(fetchWeatherData, {
  name: "fetch_weather",
  description: "Fetches the current weather for a given city.",
  schema: WeatherSchema,
});

// 4. Create the Node
// We wrap the tool in a ToolNode which handles the execution logic
export const weatherNode = new ToolNode([weatherTool]);
