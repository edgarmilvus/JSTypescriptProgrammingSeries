/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

// lib/slack.ts
export const sendToSlack = async (payload: { level: string; message: string; context?: any }) => {
  const webhookUrl = process.env.SLACK_WEBHOOK_URL;
  if (!webhookUrl) return;

  const slackPayload = {
    blocks: [
      {
        type: "header",
        text: {
          type: "plain_text",
          text: `🚨 Error Alert: ${payload.level.toUpperCase()}`,
        },
      },
      {
        type: "section",
        text: {
          type: "mrkdwn",
          text: `*Message:* ${payload.message}`,
        },
      },
      {
        type: "section",
        text: {
          type: "mrkdwn",
          text: `*Environment:* ${process.env.NODE_ENV}`,
        },
      },
    ],
  };

  // In a real app, use fetch here
  // await fetch(webhookUrl, { method: 'POST', body: JSON.stringify(slackPayload) });
  console.log(`[MOCK SLACK SEND]: ${JSON.stringify(slackPayload)}`);
};

// lib/logger.ts
import { captureException } from './sentry-utils'; // From Exercise 2
import { sendToSlack } from './slack';

interface LogPayload {
  level: 'info' | 'warn' | 'error';
  message: string;
  context?: Record<string, any>;
}

class Logger {
  private static instance: Logger;

  // Singleton pattern
  public static getInstance(): Logger {
    if (!Logger.instance) {
      Logger.instance = new Logger();
    }
    return Logger.instance;
  }

  private logToConsole(payload: LogPayload) {
    const timestamp = new Date().toISOString();
    const color = payload.level === 'error' ? '\x1b[31m' : payload.level === 'warn' ? '\x1b[33m' : '\x1b[32m';
    const reset = '\x1b[0m';
    
    console.log(
      `${color}[${timestamp}] [${payload.level.toUpperCase()}]: ${payload.message}${reset}`,
      payload.context || ''
    );
  }

  public async log(payload: LogPayload) {
    const isProduction = process.env.NODE_ENV === 'production';

    if (!isProduction) {
      // Development: Verbose console logging
      this.logToConsole(payload);
    } else {
      // Production: Silence standard logs, alert on errors
      if (payload.level === 'error') {
        // 1. Send to Sentry
        captureException(payload.message, { extra: payload.context });
        
        // 2. Send to Slack
        await sendToSlack(payload);
      }
    }
  }

  // Convenience methods
  info(message: string, context?: any) {
    this.log({ level: 'info', message, context });
  }

  warn(message: string, context?: any) {
    this.log({ level: 'warn', message, context });
  }

  error(message: string, context?: any) {
    this.log({ level: 'error', message, context });
  }
}

export const logger = Logger.getInstance();
