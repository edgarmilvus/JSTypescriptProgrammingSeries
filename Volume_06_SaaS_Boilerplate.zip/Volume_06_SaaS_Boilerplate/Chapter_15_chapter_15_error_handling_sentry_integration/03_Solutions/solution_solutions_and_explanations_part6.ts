/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part6.ts
// Description: Solutions and Explanations
// ==========================================

// lib/performance.ts
import * as Sentry from '@sentry/nextjs';

export async function withPerformanceMonitoring<T>(
  operationName: string,
  callback: () => Promise<T>
): Promise<T> {
  // Start a span manually
  const span = Sentry.startSpan({
    op: "function",
    name: operationName,
    // Only finish the span when the callback completes
  }, async (span) => {
    const startTime = performance.now();
    
    try {
      // Execute the actual operation
      const result = await callback();
      
      // Record custom metric for latency
      const duration = performance.now() - startTime;
      span.setTag("duration_ms", duration.toFixed(2));
      span.setStatus("ok");
      
      return result;
    } catch (error) {
      // Mark the span as failed
      span.setStatus("internal_error");
      span.captureException(error); // Capture error on the span
      
      // Re-throw to allow caller to handle the error
      throw error;
    } finally {
      // Ensure span is finished
      span.end();
    }
  });

  return span;
}

// Usage Example in a Server Action
export async function getDashboardData() {
  return withPerformanceMonitoring('db_query_dashboard', async () => {
    // Simulate a slow database query
    await new Promise(resolve => setTimeout(resolve, 500));
    return { data: [1, 2, 3] };
  });
}
