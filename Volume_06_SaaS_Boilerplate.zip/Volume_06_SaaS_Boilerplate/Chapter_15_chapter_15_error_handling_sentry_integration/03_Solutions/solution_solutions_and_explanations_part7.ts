/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part7.ts
// Description: Solutions and Explanations
// ==========================================

digraph ErrorFlow {
    rankdir=TB;
    node [shape=box, style="rounded,filled", fontname="Helvetica"];
    edge [fontname="Helvetica", fontsize=10];

    // Nodes
    Start [label="Client Request", shape=ellipse, fillcolor="#e1f5fe"];
    Middleware [label="Global Error Middleware", fillcolor="#fff3e0"];
    Sentry [label="Sentry Capture", fillcolor="#f3e5f5"];
    Slack [label="Slack Webhook", fillcolor="#fce4ec"];
    Client [label="Client Response (JSON)", fillcolor="#e8f5e9"];
    
    // Decision Nodes (Diamonds)
    NodeEnvCheck [label="NODE_ENV === 'production'?", shape=diamond, fillcolor="#eeeeee"];
    ErrorTypeCheck [label="Error Type?", shape=diamond, fillcolor="#eeeeee"];

    // Logic Flow
    Start -> ErrorTypeCheck [label="Error Occurs"];
    
    ErrorTypeCheck -> Middleware [label="AppError / Zod / Prisma"];
    
    Middleware -> NodeEnvCheck [label="Determine Response"];
    
    NodeEnvCheck -> Client [label="Yes (Production)\nNo Stack Trace" style=dashed];
    NodeEnvCheck -> Client [label="No (Development)\nInclude Stack Trace" style=solid];
    
    // Async Alerting Flow (Parallel to Response)
    Middleware -> Sentry [label="Async Capture"];
    Sentry -> Slack [label="Alert Triggered"];
    
    // Styling for clarity
    { rank=same; NodeEnvCheck; Client; }
}
