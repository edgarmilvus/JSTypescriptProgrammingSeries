/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.tsx
// Description: Basic Code Example
// ==========================================

// app/page.tsx
'use client'; // Mark this as a Client Component

import { useChat } from 'ai/react';

/**
 * A simple chat interface using the Vercel AI SDK's useChat hook.
 */
export default function ChatComponent() {
  // 1. Initialize the useChat hook
  //    - 'messages': Array of chat messages
  //    - 'input': Current value of the input field
  //    - 'handleInputChange': Updates 'input' on typing
  //    - 'handleSubmit': Triggers the API call
  //    - 'isLoading': Indicates if the stream is active
  const { messages, input, handleInputChange, handleSubmit, isLoading } = useChat();

  return (
    <div style={{ padding: '20px', fontFamily: 'sans-serif' }}>
      {/* 2. Display Message History */}
      <div style={{ marginBottom: '20px', minHeight: '200px', border: '1px solid #ccc', padding: '10px' }}>
        {messages.map((m) => (
          <div key={m.id} style={{ marginBottom: '8px' }}>
            <strong>{m.role === 'user' ? 'You: ' : 'AI: '}</strong>
            {m.content}
          </div>
        ))}
        
        {/* 3. Show loading indicator during streaming */}
        {isLoading && <div style={{ color: '#666' }}>Thinking...</div>}
      </div>

      {/* 4. Input Form */}
      <form onSubmit={handleSubmit}>
        <input
          type="text"
          value={input}
          onChange={handleInputChange}
          placeholder="Say something..."
          style={{ padding: '8px', width: '300px', marginRight: '8px' }}
          disabled={isLoading} // Disable input while streaming
        />
        <button type="submit" disabled={isLoading}>
          Send
        </button>
      </form>
    </div>
  );
}
