/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// app/api/summarize/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { StreamingTextResponse, OpenAIStream, experimental_StreamData } from 'ai';
import { kv } from '@vercel/kv'; // Vercel KV (Redis) for Edge caching
import { OpenAI } from 'openai';

// Initialize OpenAI client
const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY!,
});

/**
 * POST /api/summarize
 * 
 * An Edge-optimized API route handler.
 * 
 * Strategy:
 * 1. Receive text input.
 * 2. Generate a deterministic cache key (e.g., hash of the text).
 * 3. Check Vercel KV (Edge Redis) for an existing summary.
 * 4. If found (Cache Hit), return immediately (zero inference cost).
 * 5. If not found (Cache Miss), stream the LLM response.
 * 6. Pipe the stream to the client AND store it in the cache asynchronously.
 */
export const runtime = 'edge'; // Deploy to Vercel Edge Network (lower latency, faster cold starts)

export async function POST(req: NextRequest) {
  try {
    const { text } = await req.json();

    if (!text || typeof text !== 'string') {
      return new NextResponse('Invalid input: "text" is required.', { status: 400 });
    }

    // 1. Cache Key Generation
    // We use a simple hash of the text length and first/last chars for demo purposes.
    // In production, use a proper hashing library like `crypto` or `xxhash`.
    const cacheKey = `summary:${text.length}:${text.substring(0, 10)}`;

    // 2. Check Edge Cache (Vercel KV)
    // This lookup happens at the edge, often <10ms.
    const cachedSummary = await kv.get<string>(cacheKey);

    if (cachedSummary) {
      // Cache Hit: Return immediately without invoking the AI model.
      // This significantly reduces costs and latency.
      return new NextResponse(JSON.stringify({ summary: cachedSummary, cached: true }), {
        headers: { 'Content-Type': 'application/json' },
      });
    }

    // 3. Cache Miss: Prepare AI Inference
    const systemPrompt = `You are an expert summarizer. 
    Summarize the following text concisely (max 3 sentences). 
    Text: "${text}"`;

    // 4. Stream Generation
    // We use the OpenAI SDK directly to create a stream.
    const response = await openai.chat.completions.create({
      model: 'gpt-3.5-turbo', // Use a cost-effective model for summarization
      stream: true,
      messages: [
        { role: 'system', content: systemPrompt },
        { role: 'user', content: 'Summarize this.' }
      ],
    });

    // 5. Create the Stream
    // The OpenAIStream converts the raw OpenAI stream into a standard Web ReadableStream.
    const stream = OpenAIStream(response, {
      onStart: async () => {
        // Optional: Log start event
      },
      onCompletion: async (completion: string) => {
        // 6. Asynchronous Cache Write
        // We do NOT await this. We fire-and-forget to keep the response stream fast.
        // The summary is stored in Redis with a TTL (Time To Live) of 1 hour.
        await kv.set(cacheKey, completion, { ex: 3600 });
      },
    });

    // Return the stream to the client
    return new StreamingTextResponse(stream);
  } catch (error) {
    console.error('Edge Summarization Error:', error);
    return new NextResponse('Internal Server Error', { status: 500 });
  }
}
