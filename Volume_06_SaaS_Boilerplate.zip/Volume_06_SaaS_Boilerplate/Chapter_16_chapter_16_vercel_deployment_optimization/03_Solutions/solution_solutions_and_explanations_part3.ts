/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

// File: /api/search/route.ts

import { NextResponse } from 'next/server';

export async function GET(req: Request) {
  const { searchParams } = new URL(req.url);
  const query = searchParams.get('q');

  if (!query) {
    return new NextResponse('Missing query parameter "q"', { status: 400 });
  }

  // Simulate vector search logic
  // In a real app, this would query Pinecone, pgvector, or a similar service.
  const results = await performVectorSearch(query);

  // Create the response object
  const response = NextResponse.json(results);

  // Set Cache-Control headers for Edge caching.
  // s-maxage=86400: Cache at the Edge (CDN) for 24 hours (86400 seconds).
  // stale-while-revalidate=3600: Serve stale content for 1 hour while fetching fresh data in the background.
  // public: Allows caching by any cache (browser, CDN).
  response.headers.set(
    'Cache-Control',
    'public, s-maxage=86400, stale-while-revalidate=3600'
  );

  return response;
}

// Mock function to simulate vector database search
async function performVectorSearch(query: string) {
  // Simulate a delay for database processing
  await new Promise((resolve) => setTimeout(resolve, 200));
  
  return {
    query,
    results: [
      { id: 'doc_1', content: `Relevant content for ${query}`, score: 0.95 },
      { id: 'doc_2', content: `Additional context regarding ${query}`, score: 0.88 },
    ],
    timestamp: new Date().toISOString(),
  };
}
