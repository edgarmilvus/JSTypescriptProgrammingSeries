/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.tsx
// Description: Solutions and Explanations
// ==========================================

// File: /components/ChatInterface.tsx
'use client';

import { useChat } from '@ai-sdk/react';

export default function ChatInterface() {
  // Initialize the useChat hook
  const { 
    messages, 
    input, 
    handleInputChange, 
    handleSubmit, 
    isLoading, 
    error,
    reload // reload is the key function for regeneration
  } = useChat({
    api: '/api/chat', // Points to our Edge Function
  });

  // Helper to check if the last message is from the AI
  const lastMessage = messages[messages.length - 1];
  const isLastMessageAi = lastMessage?.role === 'assistant';
  const isRegenerating = isLoading && messages.length > 0;

  return (
    <div className="flex flex-col w-full max-w-md py-24 mx-auto stretch">
      <div className="space-y-4">
        {messages.map((m) => (
          <div key={m.id} className="whitespace-pre-wrap">
            <strong>{m.role === 'user' ? 'User: ' : 'AI: '}</strong>
            {m.content}
          </div>
        ))}
      </div>

      {isLoading && !isRegenerating && <div className="mt-2 text-gray-500">Thinking...</div>}
      {isRegenerating && <div className="mt-2 text-blue-500">Regenerating...</div>}
      
      {error && (
        <div className="mt-2 text-red-500">
          Error: {error.message}
          <button 
            onClick={() => window.location.reload()} 
            className="ml-2 underline"
          >
            Retry
          </button>
        </div>
      )}

      {/* Interactive Challenge: Regenerate Button */}
      {isLastMessageAi && !isLoading && (
        <div className="mt-2">
          <button
            onClick={() => reload()}
            className="px-3 py-1 text-sm bg-gray-200 rounded hover:bg-gray-300 transition-colors"
          >
            ↻ Regenerate
          </button>
        </div>
      )}

      <form onSubmit={handleSubmit} className="mt-4">
        <input
          className="w-full p-2 border border-gray-300 rounded shadow-xl"
          value={input}
          placeholder="Say something..."
          onChange={handleInputChange}
          disabled={isLoading}
        />
        <button 
          type="submit" 
          className="mt-2 px-4 py-2 bg-blue-500 text-white rounded disabled:bg-blue-300"
          disabled={isLoading || !input.trim()}
        >
          Send
        </button>
      </form>
    </div>
  );
}
