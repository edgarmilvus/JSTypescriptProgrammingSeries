/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

// @ts-check
// Ensure TypeScript type checking is active in environments that support it.

/**
 * ============================================================================
 * 1. DEPENDENCIES & SETUP
 * ============================================================================
 * We simulate a database lookup and validation. In a real app, you would
 * import `z` from 'zod' and connect to a database client.
 */

// Mocking Zod for this self-contained example (simulating 'zod' library behavior)
// In a real project: import { z } from 'zod';
const z = {
  object: (schema: any) => ({
    parse: (data: any) => {
      // Simple mock validation logic
      const errors: string[] = [];
      for (const key in schema) {
        if (data[key] === undefined || data[key] === null) {
          errors.push(`Missing field: ${key}`);
        }
      }
      if (errors.length > 0) {
        throw new Error(`Validation Error: ${errors.join(', ')}`);
      }
      return data;
    }
  }),
  string: () => 'string', // Placeholder for type inference
};

/**
 * ============================================================================
 * 2. TYPE DEFINITIONS
 * ============================================================================
 * Strict typing ensures we know exactly what shape our data is in.
 */

/**
 * Represents the raw incoming request data.
 * In a real server (Next.js/Express), this would come from headers or query params.
 */
interface IncomingRequest {
  hostname: string; // e.g., "acme.saas-app.com" or "localhost:3000"
  path: string;     // e.g., "/dashboard"
}

/**
 * Represents a Tenant record in the database.
 * This includes the custom domain mapping and the specific database connection string.
 */
interface TenantRecord {
  id: string;
  customDomain: string; // The domain the tenant owns
  dbConnectionUrl: string; // Isolated database instance for this tenant
}

/**
 * Represents the resolved context after routing.
 * This object is passed to the application logic to handle the request.
 */
interface TenantContext {
  tenantId: string;
  databaseUrl: string;
  requestedPath: string;
}

/**
 * ============================================================================
 * 3. MOCK DATABASE LAYER
 * ============================================================================
 * Simulates a database lookup. In production, this would be a SQL query
 * or a Redis cache lookup.
 */

const mockTenantDb: TenantRecord[] = [
  {
    id: 'tenant_123',
    customDomain: 'acme.saas-app.com',
    dbConnectionUrl: 'postgresql://user:pass@db.acme.internal/tenant_123',
  },
  {
    id: 'tenant_456',
    customDomain: 'globex.saas-app.com',
    dbConnectionUrl: 'postgresql://user:pass@db.globex.internal/tenant_456',
  },
];

/**
 * Simulates fetching tenant data by their custom domain.
 * @param domain - The domain extracted from the request.
 * @returns Promise<TenantRecord | null>
 */
async function fetchTenantByDomain(domain: string): Promise<TenantRecord | null> {
  // Simulate async database call
  return new Promise((resolve) => {
    setTimeout(() => {
      const tenant = mockTenantDb.find((t) => t.customDomain === domain);
      resolve(tenant || null);
    }, 50); // Simulate network latency
  });
}

/**
 * ============================================================================
 * 4. ROUTING LOGIC
 * ============================================================================
 * The core logic that maps a request to a specific tenant context.
 */

/**
 * Validates the incoming request structure and resolves the tenant context.
 * 
 * Why Zod? Even though we have TypeScript interfaces, those are erased at runtime.
 * If a malicious user sends a malformed request, we need runtime validation
 * to prevent crashes or security vulnerabilities.
 */
const RequestSchema = z.object({
  hostname: z.string(),
  path: z.string(),
});

/**
 * Main routing function.
 * 1. Validates input.
 * 2. Looks up tenant in DB.
 * 3. Returns enriched context or throws an error.
 */
async function routeRequest(request: IncomingRequest): Promise<TenantContext> {
  // Step 1: Runtime Validation
  // We parse the request to ensure 'hostname' and 'path' exist and are strings.
  const validatedRequest = RequestSchema.parse(request);

  // Step 2: Domain Extraction & Lookup
  // In a real reverse proxy (like Traefik), this hostname is passed via headers (X-Forwarded-Host).
  // Here, we use it directly.
  const { hostname, path } = validatedRequest;
  
  console.log(`[Router] Received request for host: ${hostname}`);

  // Step 3: Database Resolution
  const tenant = await fetchTenantByDomain(hostname);

  if (!tenant) {
    // If no tenant is found, we throw an error to be caught by the global error handler.
    throw new Error(`Tenant not found for domain: ${hostname}`);
  }

  // Step 4: Construct Context
  // This object represents the "State" for the duration of the request.
  const context: TenantContext = {
    tenantId: tenant.id,
    databaseUrl: tenant.dbConnectionUrl,
    requestedPath: path,
  };

  return context;
}

/**
 * ============================================================================
 * 5. SIMULATION & EXECUTION
 * ============================================================================
 * Running the logic with valid and invalid inputs to demonstrate behavior.
 */

async function runSimulation() {
  console.log('--- Starting SaaS Router Simulation ---\n');

  // Scenario A: Valid Custom Domain
  // The user owns "acme.saas-app.com" and points it to our SaaS.
  try {
    const validRequest: IncomingRequest = {
      hostname: 'acme.saas-app.com',
      path: '/dashboard',
    };

    const context = await routeRequest(validRequest);
    
    console.log('✅ Success (Valid Domain):');
    console.log(`   Tenant ID: ${context.tenantId}`);
    console.log(`   Database: ${context.databaseUrl}`);
    console.log(`   Routing to: ${context.requestedPath}\n`);
  } catch (error) {
    console.error('❌ Error:', (error as Error).message);
  }

  // Scenario B: Invalid/Unregistered Domain
  // A user tries to access a domain not configured in the system.
  try {
    const invalidRequest: IncomingRequest = {
      hostname: 'hacker.saas-app.com',
      path: '/admin',
    };

    await routeRequest(invalidRequest);
  } catch (error) {
    console.error('❌ Error (Unregistered Domain):');
    console.error(`   ${(error as Error).message}\n`);
  }

  // Scenario C: Malformed Input (Runtime Validation Failure)
  // Simulating a corrupted request object (e.g., missing hostname).
  try {
    const malformedRequest: any = {
      // hostname is missing
      path: '/profile',
    };

    await routeRequest(malformedRequest);
  } catch (error) {
    console.error('❌ Error (Validation Failure):');
    console.error(`   ${(error as Error).message}\n`);
  }
}

// Execute the simulation
runSimulation();
