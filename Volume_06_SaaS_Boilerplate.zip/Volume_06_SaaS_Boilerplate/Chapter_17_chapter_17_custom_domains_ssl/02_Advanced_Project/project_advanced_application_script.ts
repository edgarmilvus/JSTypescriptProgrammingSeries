/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// app/middleware.ts
import { NextResponse } from 'next/server';
import type { NextRequest } from 'next/server';

// ============================================================================
// 1. DATA MODELS & TYPE SAFETY
// ============================================================================

/**
 * Represents a tenant configuration stored in a central management database.
 * In a real scenario, this would be fetched from a fast cache like Redis.
 */
interface TenantConfig {
  id: string;
  organizationName: string;
  customDomain: string; // e.g., "portal.acme-corp.com"
  dbConnectionString: string; // Isolated DB instance or schema
  featureFlags: {
    enableAiStreaming: boolean;
    enableSso: boolean;
  };
}

/**
 * Extended request context that flows through the application.
 * Augments the standard NextRequest with tenant-specific metadata.
 */
declare global {
  interface NextRequest {
    tenant?: TenantConfig;
  }
}

// ============================================================================
// 2. MOCK INFRASTRUCTURE LAYER
// ============================================================================

/**
 * Simulates a lookup service (e.g., a Key-Value store or SQL table)
 * that maps incoming domains to tenant configurations.
 * 
 * In production, this is the critical link between your Custom Domain setup
 * (DNS A Record -> Load Balancer) and your application logic.
 */
const TenantRegistry = new Map<string, TenantConfig>([
  ['portal.acme-corp.com', {
    id: 'tnt_acme_01',
    organizationName: 'Acme Corp',
    customDomain: 'portal.acme-corp.com',
    dbConnectionString: 'postgresql://user:pass@db1.internal:5432/tenant_acme',
    featureFlags: { enableAiStreaming: true, enableSso: true }
  }],
  ['app.stark-industries.io', {
    id: 'tnt_stark_01',
    organizationName: 'Stark Industries',
    customDomain: 'app.stark-industries.io',
    dbConnectionString: 'postgresql://user:pass@db2.internal:5432/tenant_stark',
    featureFlags: { enableAiStreaming: false, enableSso: true }
  }]
]);

// ============================================================================
// 3. CORE MIDDLEWARE LOGIC
// ============================================================================

/**
 * The main middleware entry point.
 * 
 * Logic Flow:
 * 1. Identify the host.
 * 2. Resolve tenant configuration.
 * 3. Inject context (headers/cookies).
 * 4. Handle edge cases (unknown domains).
 */
export async function middleware(request: NextRequest) {
  const { nextUrl, headers } = request;
  const host = headers.get('host') || '';

  // --- Step 1: Domain Resolution ---
  // In a Docker/Traefik setup, the host might be localhost or an internal IP
  // if the proxy hasn't set the X-Forwarded-Host correctly. 
  // We strip ports for safety.
  const cleanHost = host.split(':')[0];

  // --- Step 2: Tenant Lookup ---
  const tenant = TenantRegistry.get(cleanHost);

  if (!tenant) {
    // --- Edge Case: Unknown Domain ---
    // If the user hits a custom domain that isn't registered, we block access.
    // Alternatively, redirect to a "Domain Not Configured" page.
    return NextResponse.redirect(new URL('/onboarding/setup-domain', request.url));
  }

  // --- Step 3: Context Injection (The "Software Router") ---
  // We clone the response to modify headers without blocking the original request.
  const response = NextResponse.next();

  // CRITICAL: We inject the Tenant ID into the request headers.
  // Next.js API routes and Server Components can read these headers.
  // Note: Next.js blocks request headers by default for security; 
  // we must explicitly allow these custom headers in `next.config.js` or 
  // rely on the fact that they are set by the middleware in the same runtime.
  response.headers.set('x-tenant-id', tenant.id);
  response.headers.set('x-tenant-db', tenant.dbConnectionString);
  
  // We also set a cookie for client-side access if needed, though headers are preferred for server-side.
  response.cookies.set('tenant_id', tenant.id, { httpOnly: true, secure: true, sameSite: 'strict' });

  // --- Step 4: Feature Flag Propagation ---
  // If the tenant has specific features disabled (e.g., AI Streaming), 
  // we can set a header to tell the API layer to skip those logic branches.
  if (!tenant.featureFlags.enableAiStreaming) {
    response.headers.set('x-disable-ai-streaming', 'true');
  }

  // Log for observability (simulated)
  console.log(`[Router] Request to ${cleanHost} routed to Tenant: ${tenant.organizationName}`);

  return response;
}

// ============================================================================
// 4. ROUTE CONFIGURATION
// ============================================================================

// Restrict middleware to specific routes to avoid overhead on static assets.
export const config = {
  matcher: [
    /*
     * Match all request paths except for the ones starting with:
     * - _next/static (static files)
     * - _next/image (image optimization files)
     * - favicon.ico (favicon file)
     * - Public folder (images, fonts, etc.)
     * 
     * We focus on API routes and App Router pages.
     */
    '/((?!_next/static|_next/image|favicon.ico|api/health).*)',
  ],
};

// ============================================================================
// 5. USAGE EXAMPLE IN SERVER COMPONENT / API ROUTE
// ============================================================================

/**
 * Example usage inside a Server Component or API Route:
 * 
 * export async function GET(request: NextRequest) {
 *   const tenantId = request.headers.get('x-tenant-id');
 *   if (!tenantId) throw new Error('Tenant context missing');
 *   
 *   // Initialize DB connection based on injected header
 *   const db = getDatabaseConnection(request.headers.get('x-tenant-db')!);
 *   
 *   const data = await db.query('SELECT * FROM user_settings');
 *   return NextResponse.json(data);
 * }
 */
