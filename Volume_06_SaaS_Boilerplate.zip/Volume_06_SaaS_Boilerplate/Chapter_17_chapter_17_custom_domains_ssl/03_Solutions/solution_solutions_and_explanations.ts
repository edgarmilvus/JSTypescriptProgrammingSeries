/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// types.ts
interface Tenant {
  id: string;
  subdomain: string;
  customDomains: string[];
}

// configGenerator.ts
/**
 * Generates a reverse proxy configuration string in YAML-like format.
 * @param tenants - Array of tenant objects containing ID, subdomain, and custom domains.
 * @returns A string representing the proxy configuration.
 */
function generateProxyConfig(tenants: Tenant[]): string {
  // Initialize the configuration string with a header
  let config = "http:\n  routers:\n";

  tenants.forEach((tenant) => {
    const backendUrl = `http://tenant-service-${tenant.id}:8080`;
    
    // 1. Route for the default subdomain (e.g., tenant-id.saas-platform.com)
    // We replace underscores or spaces if any, but assuming valid subdomain strings.
    const subdomainHost = `${tenant.subdomain}.saas-platform.com`;
    
    config += `    router-${tenant.id}-subdomain:\n`;
    config += `      rule: "Host(\`${subdomainHost}\`)"\n`;
    config += `      service: "service-${tenant.id}"\n`;
    config += `      entryPoints:\n        - "websecure"\n      tls: {}\n\n`;

    // 2. Routes for custom domains
    tenant.customDomains.forEach((domain, index) => {
      config += `    router-${tenant.id}-custom-${index}:\n`;
      config += `      rule: "Host(\`${domain}\`)"\n`;
      config += `      service: "service-${tenant.id}"\n`;
      config += `      entryPoints:\n        - "websecure"\n      tls: {}\n\n`;
    });

    // Define the backend service for this tenant
    config += `  services:\n    service-${tenant.id}:\n`;
    config += `      loadBalancer:\n        servers:\n          - url: "${backendUrl}"\n\n`;
  });

  return config;
}

// Example Usage:
// const tenants: Tenant[] = [
//   { id: "1", subdomain: "acme-corp", customDomains: ["acme.com", "shop.acme.com"] },
//   { id: "2", subdomain: "globex", customDomains: ["globex.io"] }
// ];
// console.log(generateProxyConfig(tenants));
