/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

// useSslCertificate.ts
import { useState, useEffect, useCallback, useRef } from 'react';

type CertStatus = 'pending' | 'active' | 'error';

type UseSslCertificateReturn = {
  status: CertStatus;
  expiresAt: Date | null;
  renew: () => void;
};

export const useSslCertificate = (domain: string): UseSslCertificateReturn => {
  const [status, setStatus] = useState<CertStatus>('pending');
  const [expiresAt, setExpiresAt] = useState<Date | null>(null);
  
  // Use refs to track timeouts to ensure cleanup works correctly
  const timeoutRef = useRef<NodeJS.Timeout | null>(null);
  const pollRef = useRef<NodeJS.Timeout | null>(null);

  // Function to simulate the ACME generation process
  const generateCertificate = useCallback(() => {
    setStatus('pending');
    
    // Clear any existing polling
    if (pollRef.current) clearInterval(pollRef.current);

    // Simulate API call delay (2 seconds)
    timeoutRef.current = setTimeout(() => {
      // Randomly succeed or fail to simulate real-world conditions
      const success = Math.random() > 0.2; // 80% success rate

      if (success) {
        const expiry = new Date();
        expiry.setDate(expiry.getDate() + 90); // Cert valid for 90 days
        setExpiresAt(expiry);
        setStatus('active');
      } else {
        setStatus('error');
      }
    }, 2000);
  }, []);

  // Effect to trigger generation on mount or domain change
  useEffect(() => {
    generateCertificate();

    // Bonus: Polling mechanism for 'pending' status
    // Check every 30 seconds if status is still pending
    pollRef.current = setInterval(() => {
      setStatus((prevStatus) => {
        if (prevStatus === 'pending') {
          // In a real app, we would fetch the status here.
          // For simulation, we keep it pending until the timeout resolves.
          return 'pending';
        }
        return prevStatus;
      });
    }, 30000);

    // Cleanup function
    return () => {
      if (timeoutRef.current) clearTimeout(timeoutRef.current);
      if (pollRef.current) clearInterval(pollRef.current);
    };
  }, [domain, generateCertificate]);

  const renew = useCallback(() => {
    setExpiresAt(null);
    generateCertificate();
  }, [generateCertificate]);

  return { status, expiresAt, renew };
};
