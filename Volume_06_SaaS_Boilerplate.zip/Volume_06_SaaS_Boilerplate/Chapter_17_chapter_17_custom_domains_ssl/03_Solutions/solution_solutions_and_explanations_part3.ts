/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

// middleware.ts (Next.js 13+ App Router style)
import { NextResponse } from 'next/server';
import type { NextRequest } from 'next/server';

// Mock database connection map (simulating a connection pool registry)
const dbConnections = new Map<string, any>();

// Mock Tenant Mapping
// In a real app, this would likely come from a database or cache.
const tenantDomainMap: Record<string, string> = {
  "acme.saas-platform.com": "tenant-1",
  "acme.com": "tenant-1",
  "globex.saas-platform.com": "tenant-2",
  "globex.io": "tenant-2",
};

export async function middleware(request: NextRequest) {
  const { pathname } = request.nextUrl;

  // 1. Skip static files and internal Next paths
  if (
    pathname.startsWith('/_next/') ||
    pathname.startsWith('/favicon.ico') ||
    pathname.startsWith('/api/health') // Example exclusion
  ) {
    return NextResponse.next();
  }

  // 2. Extract Host header
  const host = request.headers.get('host');
  
  if (!host) {
    return new NextResponse(JSON.stringify({ error: "Host header missing" }), { status: 400 });
  }

  // 3. Resolve Tenant ID
  const tenantId = tenantDomainMap[host];

  if (!tenantId) {
    // Return 404 if tenant not found
    return new NextResponse(null, { status: 404 });
  }

  // 4. Initialize/Retrieve DB Connection (Simulated)
  if (!dbConnections.has(tenantId)) {
    // Simulate creating a new connection pool
    dbConnections.set(tenantId, { poolId: `pool-${tenantId}`, status: 'connected' });
  }

  // 5. Attach Tenant ID to Request Headers
  // Next.js middleware modifies request headers to pass data to API routes/Server Components
  const requestHeaders = new Headers(request.headers);
  requestHeaders.set('x-tenant-id', tenantId);

  return NextResponse.next({
    request: {
      headers: requestHeaders,
    },
  });
}

export const config = {
  // Matcher ignores _next/static, images, and favicon
  matcher: '/((?!_next/static|_next/image|favicon.ico).*)',
};
