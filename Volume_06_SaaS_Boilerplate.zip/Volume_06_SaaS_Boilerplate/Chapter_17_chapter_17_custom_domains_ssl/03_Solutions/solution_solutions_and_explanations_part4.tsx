/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.tsx
// Description: Solutions and Explanations
// ==========================================

// DomainManager.tsx
import React, { useState } from 'react';

interface Domain {
  id: string;
  domain: string;
  status: 'active' | 'verifying' | 'error';
}

// Mock API function
const verifyDomain = (domain: string): Promise<void> => {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      // Simulate random failure (20% chance)
      if (Math.random() > 0.8) {
        reject(new Error("DNS verification failed"));
      } else {
        resolve();
      }
    }, 3000);
  });
};

export const DomainManager: React.FC = () => {
  const [domains, setDomains] = useState<Domain[]>([
    { id: '1', domain: 'example.com', status: 'active' }
  ]);
  const [newDomain, setNewDomain] = useState('');
  const [error, setError] = useState<string | null>(null);

  const handleAddDomain = async () => {
    if (!newDomain.trim()) return;

    // 1. Optimistic Update
    const tempId = Date.now().toString();
    const optimisticDomain: Domain = {
      id: tempId,
      domain: newDomain,
      status: 'verifying', // Immediate visual feedback
    };

    setDomains((prev) => [...prev, optimisticDomain]);
    setNewDomain('');
    setError(null);

    try {
      // 2. Simulate API Call
      await verifyDomain(newDomain);

      // 3. Success: Update status to active
      setDomains((prev) =>
        prev.map((d) =>
          d.id === tempId ? { ...d, status: 'active' } : d
        )
      );
    } catch (err) {
      // 4. Failure: Revert optimistic update and show error
      setDomains((prev) => prev.filter((d) => d.id !== tempId));
      setError(`Failed to verify ${newDomain}. Please try again.`);
    }
  };

  return (
    <div style={{ padding: '20px', fontFamily: 'sans-serif' }}>
      <h2>Domain Manager</h2>
      
      {/* Domain List */}
      <ul>
        {domains.map((domain) => (
          <li key={domain.id} style={{ marginBottom: '8px' }}>
            <strong>{domain.domain}</strong> -{' '}
            <span style={{ color: domain.status === 'verifying' ? 'orange' : domain.status === 'error' ? 'red' : 'green' }}>
              {domain.status === 'verifying' ? (
                <span>⏳ Verifying...</span>
              ) : (
                domain.status
              )}
            </span>
          </li>
        ))}
      </ul>

      {/* Add Domain Form */}
      <div style={{ marginTop: '20px' }}>
        <input
          type="text"
          value={newDomain}
          onChange={(e) => setNewDomain(e.target.value)}
          placeholder="new-domain.com"
          style={{ padding: '8px', marginRight: '8px' }}
        />
        <button onClick={handleAddDomain} style={{ padding: '8px 16px' }}>
          Add Domain
        </button>
      </div>

      {/* Error Message */}
      {error && <p style={{ color: 'red', marginTop: '10px' }}>{error}</p>}
    </div>
  );
};
