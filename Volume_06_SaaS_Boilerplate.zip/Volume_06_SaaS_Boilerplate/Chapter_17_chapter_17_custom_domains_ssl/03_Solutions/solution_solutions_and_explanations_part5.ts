/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

digraph ArchitectureFlow {
    rankdir=LR;
    node [shape=box, style="rounded,filled", color="#4F46E5", fontcolor="white"];
    edge [color="#333333", fontcolor="#333333"];

    // Nodes
    Client [label="Client Browser\n(client-domain.com)", fillcolor="#6366f1"];
    DNS [label="DNS Server", fillcolor="#8b5cf6"];
    Proxy [label="Reverse Proxy\n(Traefik/Caddy)", fillcolor="#ec4899"];
    ACME [label="ACME Challenge\n(Let's Encrypt)", fillcolor="#f59e0b", fontcolor="black"];
    TenantService [label="Tenant Service\n(Container A)", fillcolor="#10b981"];
    TenantDB [label="Tenant Database\n(DB A)", fillcolor="#3b82f6"];

    // Flow 1: Standard HTTPS Request
    subgraph cluster_request {
        label="Standard Request Flow";
        style="dashed";
        Client -> DNS [label="1. DNS Lookup\nA Record -> Proxy IP"];
        DNS -> Client [label="IP Address"];
        Client -> Proxy [label="2. HTTPS Request\nHost: client-domain.com", penwidth=2];
        Proxy -> TenantService [label="3. Routing\nBackend: http://tenant-service-a:8080", penwidth=2];
        TenantService -> TenantDB [label="4. Query Data", style="dashed"];
    }

    // Flow 2: SSL/ACME Challenge (Invisible link for layout, then explicit)
    // Note: In Traefik/Caddy, the proxy handles the challenge, but the app might trigger it.
    // We visualize the interaction between Proxy and ACME endpoint.
    
    Proxy -> ACME [label="5. ACME Challenge Request\n(HTTP-01)", style="dotted", constraint=false];
    ACME -> Proxy [label="6. Validation Token\n& Certificate Issuance", style="dotted", constraint=false];

    // Return flows
    TenantService -> Proxy [label="7. Response", dir=back, penwidth=2];
    Proxy -> Client [label="8. Encrypted Response\n(SSL Established)", dir=back, penwidth=2];
}
