/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

import { Queue, Worker, Job } from 'bullmq';
import IORedis from 'ioredis';

// ==========================================
// 1. Configuration & Interfaces
// ==========================================

/**
 * Configuration for the Redis connection.
 * In a real SaaS, these come from environment variables.
 */
const REDIS_CONFIG = {
  host: 'localhost',
  port: 6379,
  maxRetriesPerRequest: null, // Required for BullMQ
};

/**
 * Interface for the data payload expected by our job.
 * Strict typing prevents runtime errors and "hallucinated" data structures.
 */
export interface BillingJobData {
  date: string; // ISO Date string
  tenantId: string;
}

// ==========================================
// 2. Job Queue Initialization
// ==========================================

/**
 * Creates a connection to Redis and initializes the Queue.
 * This queue acts as the persistent storage for pending tasks.
 */
const createBillingQueue = () => {
  const connection = new IORedis(REDIS_CONFIG);
  
  // The queue name 'billing-reconciliation' represents the category of tasks
  return new Queue<BillingJobData>('billing-reconciliation', {
    connection,
    defaultJobOptions: {
      attempts: 3, // Retry failed jobs up to 3 times
      backoff: {
        type: 'exponential', // Wait longer between retries (e.g., 2s, 4s, 8s)
        delay: 1000,
      },
      removeOnComplete: { age: 3600 }, // Keep completed jobs for 1 hour
      removeOnFail: { age: 24 * 3600 }, // Keep failed jobs for 24 hours
    },
  });
};

// ==========================================
// 3. The Worker (Job Processor)
// ==========================================

/**
 * The Worker runs in a separate process (or thread).
 * It listens for new jobs in the queue and executes the logic.
 */
const createWorker = () => {
  const connection = new IORedis(REDIS_CONFIG);

  const worker = new Worker<BillingJobData>(
    'billing-reconciliation',
    async (job: Job<BillingJobData>) => {
      // --- LOGIC START ---
      
      // Simulate a database fetch or heavy computation
      // In a real app, this might query a PostgreSQL DB with vector support
      // or call a Stripe API for invoice generation.
      console.log(`[Worker] Processing Job ID: ${job.id}`);
      console.log(`[Worker] Tenant: ${job.data.tenantId} | Date: ${job.data.date}`);

      // Simulate processing time
      await new Promise((resolve) => setTimeout(resolve, 1000));

      // Simulate a random failure to demonstrate retry logic
      const randomOutcome = Math.random();
      if (randomOutcome < 0.2) {
        // Throwing an error triggers the retry mechanism defined in the Queue
        throw new Error('Simulated API Timeout');
      }

      console.log(`[Worker] Successfully reconciled billing for ${job.data.tenantId}`);
      return { status: 'success', processedAt: new Date().toISOString() };
      // --- LOGIC END ---
    },
    { 
      connection,
      concurrency: 5, // Process up to 5 jobs concurrently
    }
  );

  // Event Listeners for Monitoring
  worker.on('completed', (job, result) => {
    console.log(`✅ Job ${job.id} completed with result:`, result);
  });

  worker.on('failed', (job, err) => {
    console.log(`❌ Job ${job.id} failed with error: ${err.message}`);
    // In a real SaaS, this is where you would trigger an alert (e.g., Slack, PagerDuty)
  });

  return worker;
};

// ==========================================
// 4. Main Execution (Simulating the Cron Trigger)
// ==========================================

/**
 * Main entry point.
 * In a real deployment, this function would be triggered by a cron scheduler
 * (like Kubernetes CronJob, Vercel Cron, or a dedicated scheduler service).
 */
const run = async () => {
  console.log('🚀 Starting SaaS Billing Scheduler...');

  const queue = createBillingQueue();
  const worker = createWorker();

  // Wait for worker to be ready
  await worker.waitUntilReady();
  console.log('Worker connected to Redis.');

  // --- SIMULATION ---
  // We simulate the "Cron" firing by adding a job to the queue.
  // In a real app, this loop would be replaced by a scheduler service.
  console.log('📡 Scheduling daily billing reconciliation...');
  
  try {
    // Add a job to the queue
    const job = await queue.add('daily-billing', {
      date: new Date().toISOString(),
      tenantId: 'tenant_123_abc',
    });

    console.log(`Job added to queue with ID: ${job.id}`);
    
    // Allow time for the worker to process
    // In a real server, the worker runs indefinitely.
    setTimeout(async () => {
      await queue.close();
      await worker.close();
      console.log('✅ Simulation complete. Connections closed.');
    }, 5000);

  } catch (error) {
    console.error('Error scheduling job:', error);
  }
};

// Execute the simulation
run().catch(console.error);
