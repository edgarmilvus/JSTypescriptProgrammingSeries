/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

/**
 * @fileoverview Advanced Application Script: Automated Data Cleanup & Archival
 * 
 * This script acts as a dedicated worker process for a SaaS application.
 * It runs on a schedule (via Cron) to clean up temporary user data, 
 * archive it to cold storage, and maintain database hygiene.
 * 
 * Technologies: TypeScript, BullMQ (Redis), Prisma (Database)
 * Target: Node.js Worker Environment (not browser)
 */

import { Queue, Worker, Job } from 'bullmq';
import { PrismaClient } from '@prisma/client';
import IORedis from 'ioredis';

// ============================================================================
// 1. CONFIGURATION & INITIALIZATION
// ============================================================================

// Initialize Prisma Client for database operations
const prisma = new PrismaClient();

// Configure Redis connection for BullMQ
// In production, these should be stored in environment variables
const connection = new IORedis({
  host: process.env.REDIS_HOST || 'localhost',
  port: parseInt(process.env.REDIS_PORT || '6379'),
  maxRetriesPerRequest: 3,
});

// Define the queue name
const QUEUE_NAME = 'data-cleanup';

// Initialize the Queue instance
const cleanupQueue = new Queue(QUEUE_NAME, {
  connection,
  defaultJobOptions: {
    attempts: 3, // Retry failed jobs up to 3 times
    backoff: {
      type: 'exponential', // Exponential backoff strategy
      delay: 2000, // Start with 2 second delay
    },
    removeOnComplete: { age: 3600 }, // Keep successful jobs for 1 hour
    removeOnFail: { age: 24 * 3600 }, // Keep failed jobs for 24 hours
  },
});

// ============================================================================
// 2. CORE LOGIC: ARCHIVING & DELETION
// ============================================================================

/**
 * Archives expired temporary records to a simulated cold storage (e.g., S3)
 * and deletes them from the primary database.
 * 
 * @param {Job} job - The BullMQ job object containing metadata
 * @returns {Promise<{ archived: number; deleted: number }>}
 */
async function processCleanupJob(job: Job): Promise<{ archived: number; deleted: number }> {
  const { jobId } = job;
  
  // Define the cutoff date: 24 hours ago
  const cutoffDate = new Date(Date.now() - 24 * 60 * 60 * 1000);

  console.log(`[${jobId}] Starting cleanup process. Cutoff: ${cutoffDate.toISOString()}`);

  try {
    // Step A: Fetch records to be cleaned up
    // We use a transaction to ensure data consistency
    const recordsToClean = await prisma.tempUpload.findMany({
      where: {
        createdAt: { lt: cutoffDate },
        status: 'PENDING', // Only clean pending uploads
      },
      select: {
        id: true,
        fileKey: true,
        metadata: true,
      },
      take: 1000, // Process in batches to avoid locking the table
    });

    if (recordsToClean.length === 0) {
      console.log(`[${jobId}] No records found to clean.`);
      return { archived: 0, deleted: 0 };
    }

    // Step B: Simulate Archiving to Cold Storage (e.g., AWS S3 Glacier)
    // In a real app, this would upload the file content to S3 and store the URL
    const archiveLog = {
      timestamp: new Date(),
      count: recordsToClean.length,
      source: 'tempUploads',
      jobBatchId: jobId,
    };
    console.log(`[ARCHIVE] Uploading ${recordsToClean.length} items to cold storage...`, archiveLog);
    // Simulate network delay
    await new Promise(resolve => setTimeout(resolve, 500));

    // Step C: Delete from Primary Database
    // We delete only the successfully "archived" items
    const deleteResult = await prisma.tempUpload.deleteMany({
      where: {
        id: {
          in: recordsToClean.map((r) => r.id),
        },
      },
    });

    console.log(`[${jobId}] Cleanup complete. Archived: ${recordsToClean.length}, Deleted: ${deleteResult.count}`);

    return { archived: recordsToClean.length, deleted: deleteResult.count };

  } catch (error) {
    console.error(`[${jobId}] Critical error during cleanup:`, error);
    // Re-throw to trigger BullMQ retry mechanism
    throw error;
  }
}

// ============================================================================
// 3. WORKER SETUP & EXECUTION
// ============================================================================

/**
 * Initializes the worker process.
 * This runs in an infinite loop, listening for jobs on the Redis queue.
 */
const startWorker = () => {
  const worker = new Worker(
    QUEUE_NAME,
    async (job) => {
      return await processCleanupJob(job);
    },
    {
      connection,
      concurrency: 2, // Process 2 jobs concurrently max
      limiter: {
        max: 10, // Max 10 jobs per second
        duration: 1000,
      },
    }
  );

  // Event Listeners for Monitoring
  worker.on('completed', (job, result) => {
    console.log(`✅ Job ${job.id} completed. Result:`, result);
    // Here you would integrate with monitoring (e.g., DataDog, Sentry)
  });

  worker.on('failed', (job, err) => {
    console.error(`❌ Job ${job.id} failed after ${job.attemptsMade} attempts. Error:`, err.message);
    
    // ALERTING LOGIC:
    // If the job fails after all retries, trigger an alert
    if (job && job.attemptsMade >= job.opts.attempts) {
      triggerAlert(`Data Cleanup Job ${job.id} permanently failed.`, err);
    }
  });

  worker.on('stalled', (jobId) => {
    console.warn(`⚠️ Job ${jobId} stalled. Check worker health.`);
  });

  console.log('🚀 Worker started. Waiting for jobs...');
  return worker;
};

// ============================================================================
// 4. ALERTING & MONITORING INTEGRATION
// ============================================================================

/**
 * Triggers an external alert (e.g., Slack Webhook, Email).
 * Abstracted for modularity.
 * 
 * @param {string} title - Alert title
 * @param {Error} error - The error object
 */
function triggerAlert(title: string, error: Error) {
  // Mock integration: In production, use axios to post to Slack/Discord
  const alertPayload = {
    title,
    message: error.message,
    stack: error.stack,
    service: 'cron-worker-data-cleanup',
    environment: process.env.NODE_ENV,
  };
  
  console.error('🚨 ALERT TRIGGERED:', JSON.stringify(alertPayload, null, 2));
}

// ============================================================================
// 5. SCHEDULER TRIGGER (CRON SIMULATION)
// ============================================================================

/**
 * Function to manually add a job to the queue for testing or 
 * triggered by an external cron service (like system cron or Kubernetes CronJob).
 */
async function scheduleCleanup() {
  try {
    // Add a job to the queue with a timestamp
    const job = await cleanupQueue.add('daily-cleanup', {
      type: 'temp_upload_purge',
      scheduledFor: new Date(),
    });
    console.log(`📅 Job ${job.id} added to queue.`);
  } catch (error) {
    console.error('Failed to schedule job:', error);
  }
}

// ============================================================================
// 6. GRACEFUL SHUTDOWN
// ============================================================================

/**
 * Handles process termination signals to close connections gracefully.
 */
const gracefulShutdown = async (signal: string, worker: Worker) => {
  console.log(`Received ${signal}. Shutting down gracefully...`);
  
  // Stop accepting new jobs
  await worker.close();
  
  // Wait for active jobs to finish (with a timeout)
  await worker.waitUntilFinished();
  
  // Close DB connections
  await prisma.$disconnect();
  await connection.disconnect();
  
  console.log('Shutdown complete.');
  process.exit(0);
};

// ============================================================================
// ENTRY POINT
// ============================================================================

// Only run if executed directly (not imported)
if (require.main === module) {
  const worker = startWorker();

  // Listen for termination signals
  process.on('SIGTERM', () => gracefulShutdown('SIGTERM', worker));
  process.on('SIGINT', () => gracefulShutdown('SIGINT', worker));

  // Optional: Trigger a manual job immediately for testing
  // scheduleCleanup();
}

// Export for testing or import in other modules
export { scheduleCleanup, processCleanupJob };
