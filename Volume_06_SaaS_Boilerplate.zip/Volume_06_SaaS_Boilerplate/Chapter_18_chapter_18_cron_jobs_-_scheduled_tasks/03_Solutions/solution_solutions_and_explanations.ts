/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// file: src/job-processor.ts
import { Queue, Worker, Job } from 'bullmq';
import IORedis from 'ioredis';

// 1. Type Safety: Define the job payload interface
export interface ReconciliationJobPayload {
  reconciliationDate: string; // ISO 8601 format
  customerId?: string;
}

// Configuration (simulated environment variables)
const REDIS_URL = process.env.REDIS_URL || 'redis://localhost:6379';
const QUEUE_NAME = 'billing-reconciliation';

// Redis Connection Setup
const connection = new IORedis(REDIS_URL, { maxRetriesPerRequest: null });

// 2. Job Producer: Schedule Daily Reconciliation
export async function scheduleDailyReconciliation(date: string = new Date().toISOString()) {
  const queue = new Queue<ReconciliationJobPayload>(QUEUE_NAME, { connection });

  // Idempotency check: Check if a job for this date already exists in the waiting list
  // Note: In a production system, you might query a specific job store or use job deduplication features.
  // Here we simulate checking the waiting jobs.
  const waitingJobs = await queue.getWaiting();
  const duplicate = waitingJobs.find(job => job.data.reconciliationDate === date);

  if (duplicate) {
    console.log(`Job for date ${date} is already scheduled. Skipping.`);
    await queue.close();
    return duplicate.id;
  }

  // Add the job to the queue
  const job = await queue.add(
    'daily-reconciliation',
    { reconciliationDate: date },
    {
      attempts: 3, // Max retries
      backoff: {
        type: 'exponential',
        delay: 1000, // Initial delay 1s
      },
      removeOnComplete: { age: 3600 }, // Keep completed jobs for 1 hour
      removeOnFail: { age: 24 * 3600 }, // Keep failed jobs for 24 hours
    }
  );

  console.log(`Scheduled reconciliation job for ${date} with ID: ${job.id}`);
  await queue.close();
  return job.id;
}

// 3. Job Consumer (Worker)
export function startWorker(enableFailureSimulation: boolean = false) {
  const worker = new Worker<ReconciliationJobPayload>(
    QUEUE_NAME,
    async (job: Job<ReconciliationJobPayload>) => {
      console.log(`Processing Job ${job.id} for date: ${job.data.reconciliationDate}`);

      // Simulate heavy processing
      await new Promise(resolve => setTimeout(resolve, 2000));

      // Interactive Challenge: Random failure simulation
      if (enableFailureSimulation) {
        const random = Math.random();
        if (random < 0.2) { // 20% chance of failure
          throw new Error('Simulated transient database error');
        }
      }

      // Simulate successful processing logic here...
      console.log(`Successfully processed job ${job.id}`);
      return { success: true, processedDate: new Date().toISOString() };
    },
    {
      connection,
      concurrency: 5, // Process up to 5 jobs concurrently
      limiter: { max: 10, duration: 1000 }, // Rate limiting
    }
  );

  worker.on('completed', (job, result) => {
    console.log(`Job ${job.id} completed with result:`, result);
  });

  worker.on('failed', (job, err) => {
    console.error(`Job ${job.id} failed after ${job.attemptsMade} attempts. Error: ${err.message}`);
  });

  worker.on('stalled', (jobId) => {
    console.warn(`Job ${jobId} has stalled`);
  });

  return worker;
}

// 4. Integration: Triggering the scheduler
// In a real app, this might be triggered by a cron service or an HTTP endpoint.
// For this exercise, we simulate it on startup.
if (require.main === module) {
  (async () => {
    console.log('Starting Job Processor Application...');
    
    // Schedule a job
    await scheduleDailyReconciliation(new Date().toISOString());
    
    // Start the worker (set to true to enable failure simulation for the interactive challenge)
    const enableFailureSim = process.env.ENABLE_FAILURE_SIMULATION === 'true';
    const worker = startWorker(enableFailureSim);
    
    // Keep the process alive for the worker to function
    process.on('SIGTERM', async () => {
      await worker.close();
      process.exit(0);
    });
  })();
}
