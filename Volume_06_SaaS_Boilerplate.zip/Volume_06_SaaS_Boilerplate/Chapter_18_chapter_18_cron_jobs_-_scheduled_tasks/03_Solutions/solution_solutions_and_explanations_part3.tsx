/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

// file: src/frontend/components/JobStatusDashboard.tsx
import React, { useState, useEffect } from 'react';

// 2. TypeScript Interface for API Response
interface JobStatus {
  id: string;
  name: string;
  status: 'completed' | 'failed' | 'waiting' | 'active';
  timestamp: number;
}

const JobStatusDashboard: React.FC = () => {
  const [jobs, setJobs] = useState<JobStatus[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const [message, setMessage] = useState<string>('');

  // Helper to fetch data
  const fetchJobs = async () => {
    try {
      setLoading(true);
      const response = await fetch('/api/jobs/status');
      if (!response.ok) throw new Error('Network response was not ok');
      const data = await response.json();
      setJobs(data);
      setError(null);
    } catch (err) {
      setError('Failed to load job data.');
    } finally {
      setLoading(false);
    }
  };

  // Initial fetch and Polling (every 10 seconds)
  useEffect(() => {
    fetchJobs();
    const interval = setInterval(fetchJobs, 10000);
    return () => clearInterval(interval);
  }, []);

  // Interactive Challenge: Retry Failed Jobs
  const handleRetryFailed = async () => {
    try {
      const response = await fetch('/api/jobs/retry-failed', { method: 'POST' });
      const result = await response.json();
      setMessage(result.message);
      fetchJobs(); // Refresh list immediately
      setTimeout(() => setMessage(''), 3000);
    } catch (err) {
      setMessage('Error retrying jobs.');
    }
  };

  // 3. Styling Helpers
  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed': return '#4caf50'; // Green
      case 'failed': return '#f44336'; // Red
      case 'active': return '#2196f3'; // Blue
      case 'waiting': return '#ff9800'; // Yellow
      default: return '#757575'; // Grey
    }
  };

  if (loading && jobs.length === 0) return <div>Loading Dashboard...</div>;
  if (error) return <div style={{ color: 'red' }}>Error: {error}</div>;

  return (
    <div style={{ padding: '20px', fontFamily: 'Arial, sans-serif' }}>
      <h2>Job Status Dashboard</h2>
      
      <div style={{ marginBottom: '10px' }}>
        <button onClick={fetchJobs} style={{ marginRight: '10px' }}>Refresh</button>
        <button onClick={handleRetryFailed} style={{ backgroundColor: '#ff9800', color: 'white', border: 'none', padding: '5px 10px', cursor: 'pointer' }}>
          Re-run Failed Jobs
        </button>
        {message && <span style={{ marginLeft: '10px', color: 'green', fontWeight: 'bold' }}>{message}</span>}
      </div>

      <table style={{ width: '100%', borderCollapse: 'collapse', border: '1px solid #ddd' }}>
        <thead>
          <tr style={{ backgroundColor: '#f2f2f2' }}>
            <th style={{ border: '1px solid #ddd', padding: '8px' }}>Job ID</th>
            <th style={{ border: '1px solid #ddd', padding: '8px' }}>Name</th>
            <th style={{ border: '1px solid #ddd', padding: '8px' }}>Status</th>
            <th style={{ border: '1px solid #ddd', padding: '8px' }}>Last Updated</th>
          </tr>
        </thead>
        <tbody>
          {jobs.map(job => (
            <tr key={job.id}>
              <td style={{ border: '1px solid #ddd', padding: '8px' }}>{job.id}</td>
              <td style={{ border: '1px solid #ddd', padding: '8px' }}>{job.name}</td>
              <td style={{ border: '1px solid #ddd', padding: '8px', color: getStatusColor(job.status), fontWeight: 'bold' }}>
                {job.status.toUpperCase()}
              </td>
              <td style={{ border: '1px solid #ddd', padding: '8px' }}>
                {new Date(job.timestamp).toLocaleTimeString()}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default JobStatusDashboard;
