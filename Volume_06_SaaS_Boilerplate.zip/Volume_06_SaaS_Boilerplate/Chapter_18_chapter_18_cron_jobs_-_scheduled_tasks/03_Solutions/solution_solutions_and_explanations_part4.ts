/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

// file: src/robust-worker.ts
import { Worker, Queue, Job } from 'bullmq';
import IORedis from 'ioredis';
import { ReconciliationJobPayload } from './job-processor'; // Import from Ex 1

const REDIS_URL = process.env.REDIS_URL || 'redis://localhost:6379';
const QUEUE_NAME = 'billing-reconciliation';
const DLQ_NAME = 'billing-reconciliation-dlq';
const connection = new IORedis(REDIS_URL, { maxRetriesPerRequest: null });

// 1. Structured Logging (Simulated with console for brevity, but structured)
const logger = {
  info: (msg: string, meta?: object) => console.log(JSON.stringify({ level: 'info', msg, ...meta })),
  error: (msg: string, meta?: object) => console.error(JSON.stringify({ level: 'error', msg, ...meta })),
  warn: (msg: string, meta?: object) => console.warn(JSON.stringify({ level: 'warn', msg, ...meta })),
};

// 2. Alerting Mechanism
const triggerAlert = (job: Job, error: Error) => {
  // In production, this would send an email, Slack message, or PagerDuty alert.
  logger.error('CRITICAL ALERT: Job permanently failed after retries', {
    jobId: job.id,
    error: error.message,
    stack: error.stack,
    payload: job.data,
  });
};

// 3. DLQ Listener Setup
export function setupDLQListener() {
  const dlqQueue = new Queue(DLQ_NAME, { connection });
  
  // This listener acts as a consumer for the DLQ.
  // BullMQ doesn't automatically process DLQ; you need a worker or a listener.
  // Here we use a Queue event listener to log when a job enters the DLQ.
  dlqQueue.on('global:failed', (jobId, err) => {
    logger.error(`Job ${jobId} moved to DLQ. Needs manual inspection.`, { error: err });
  });

  // For the interactive challenge, we also create a worker to "process" the DLQ
  const dlqWorker = new Worker(DLQ_NAME, async (job) => {
    logger.info(`Processing Dead Letter Job ${job.id}. Sending report to monitoring service...`);
    // Simulate sending a report
    await new Promise(resolve => setTimeout(resolve, 500));
    return { dlqProcessed: true };
  }, { connection });

  return dlqWorker;
}

// 4. Main Worker with Failure Simulation and DLQ Routing
export function startRobustWorker(enableFailureSim: boolean) {
  const worker = new Worker<ReconciliationJobPayload>(
    QUEUE_NAME,
    async (job: Job<ReconciliationJobPayload>) => {
      logger.info(`Processing Job ${job.id}`, { date: job.data.reconciliationDate });

      // Simulate processing time
      await new Promise(resolve => setTimeout(resolve, 1000));

      // Failure Simulation: Fail every 3rd job if enabled
      if (enableFailureSim) {
        // We use a deterministic check based on Job ID or a counter to ensure
        // we can observe the DLQ flow reliably.
        const jobNum = parseInt(job.id || '0', 10);
        if (jobNum % 3 === 0) {
          throw new Error(`Simulated deterministic failure for job ${job.id}`);
        }
      }

      return { status: 'success' };
    },
    {
      connection,
      // 5. DLQ Configuration
      // BullMQ handles DLQ automatically if 'removeOnFail' is false and a failed event is triggered
      // after all attempts. However, to explicitly move to a DLQ, we often rely on the `failed` event
      // or specific DLQ settings in BullMQ Pro. 
      // In standard BullMQ, we handle the DLQ logic in the 'failed' event listener below.
      removeOnFail: false, // Keep failed jobs in the main queue for inspection or DLQ handling
      attempts: 3,
      backoff: { type: 'exponential', delay: 1000 },
    }
  );

  // Handle Job Failure (Post-Retries)
  worker.on('failed', async (job, err) => {
    if (job && job.attemptsMade >= job.opts.attempts!) {
      // Max retries reached. Move to DLQ.
      logger.warn(`Job ${job.id} failed permanently. Moving to DLQ.`);
      
      // Trigger Alert
      triggerAlert(job, err);

      // Move to DLQ manually (BullMQ standard way)
      const dlq = new Queue(DLQ_NAME, { connection });
      await dlq.add('dead-letter', job.data, {
        ...job.opts,
        removeOnFail: false,
        removeOnComplete: false,
      });
      
      // Remove from the main queue to keep it clean
      await job.remove();
      await dlq.close();
    } else {
      logger.error(`Job ${job.id} failed (Attempt ${job?.attemptsMade})`, { error: err.message });
    }
  });

  worker.on('completed', (job) => {
    logger.info(`Job ${job.id} completed successfully`);
  });

  return worker;
}

// Entry point for the exercise
if (require.main === module) {
  (async () => {
    const enableSim = process.env.ENABLE_FAILURE_SIMULATION === 'true';
    
    // Start the main worker
    console.log(`Starting Robust Worker with Failure Simulation: ${enableSim}`);
    const worker = startRobustWorker(enableSim);

    // Start the DLQ listener
    const dlqListener = setupDLQListener();

    process.on('SIGTERM', async () => {
      await worker.close();
      await dlqListener.close();
      process.exit(0);
    });
  })();
}
