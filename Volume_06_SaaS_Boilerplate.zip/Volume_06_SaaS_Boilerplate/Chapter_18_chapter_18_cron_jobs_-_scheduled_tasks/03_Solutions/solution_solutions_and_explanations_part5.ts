/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

// file: src/worker-with-health.ts
import { Worker } from 'bullmq';
import IORedis from 'ioredis';
import express from 'express';
import os from 'os';

// Simulated worker logic
const startWorker = () => {
  const connection = new IORedis(process.env.REDIS_URL || 'redis://redis:6379');
  const worker = new Worker('billing-reconciliation', async job => {
    // Processing logic...
  }, { connection });
  
  return worker;
};

// 3. Health Check Endpoint
const startHealthServer = (worker: Worker) => {
  const app = express();
  const port = 8080;

  app.get('/health/worker', async (req, res) => {
    const isRedisConnected = worker.client.status === 'ready';
    
    const healthStatus = {
      status: isRedisConnected ? 'healthy' : 'unhealthy',
      workerId: worker.id,
      uptime: process.uptime(),
      connectedToRedis: isRedisConnected,
      timestamp: new Date().toISOString(),
    };

    if (isRedisConnected) {
      res.status(200).json(healthStatus);
    } else {
      res.status(503).json(healthStatus);
    }
  });

  app.listen(port, () => {
    console.log(`Health check server running on port ${port}`);
  });
};

// Main entry
if (require.main === module) {
  const worker = startWorker();
  startHealthServer(worker);
}
