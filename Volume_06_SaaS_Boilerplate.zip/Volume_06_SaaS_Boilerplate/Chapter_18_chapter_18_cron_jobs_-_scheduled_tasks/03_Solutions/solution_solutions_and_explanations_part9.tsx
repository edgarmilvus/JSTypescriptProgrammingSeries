/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part9.tsx
// Description: Solutions and Explanations
// ==========================================

// file: src/frontend/components/QueueVisualizer.tsx
import React, { useState, useEffect } from 'react';

// 2. TypeScript Interface for Metrics
interface QueueMetrics {
  waiting: number;
  active: number;
  completed: number;
  failed: number;
}

const QueueVisualizer: React.FC = () => {
  const [metrics, setMetrics] = useState<QueueMetrics | null>(null);
  const [loading, setLoading] = useState<boolean>(true);

  // Helper to fetch metrics
  const fetchMetrics = async () => {
    try {
      const response = await fetch('/api/queue-metrics');
      if (!response.ok) throw new Error('Failed to fetch');
      const data = await response.json();
      setMetrics(data);
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  // Polling every 5 seconds
  useEffect(() => {
    fetchMetrics();
    const interval = setInterval(fetchMetrics, 5000);
    return () => clearInterval(interval);
  }, []);

  // Interactive Challenge: Trigger Job Scheduling
  const handleScheduleJob = async () => {
    try {
      const response = await fetch('/api/schedule', { method: 'POST' });
      const result = await response.json();
      console.log(result.message);
      // Force immediate refresh to see the "Waiting" count update
      fetchMetrics();
    } catch (error) {
      console.error('Scheduling failed', error);
    }
  };

  if (loading) return <div>Loading Visualizer...</div>;
  if (!metrics) return <div>Unable to load metrics.</div>;

  // Calculate total for percentage widths (optional, for visual bars)
  const total = metrics.waiting + metrics.active + metrics.completed + metrics.failed || 1;

  // 3. Visualizing with simple CSS bars
  const Bar = ({ label, count, color }: { label: string; count: number; color: string }) => (
    <div style={{ marginBottom: '10px' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between' }}>
        <span>{label}</span>
        <span>{count}</span>
      </div>
      <div style={{ background: '#eee', height: '20px', borderRadius: '4px', overflow: 'hidden' }}>
        <div
          style={{
            width: `${(count / total) * 100}%`,
            background: color,
            height: '100%',
            transition: 'width 0.5s ease',
          }}
        ></div>
      </div>
    </div>
  );

  return (
    <div style={{ padding: '20px', maxWidth: '600px', margin: '0 auto' }}>
      <h2>Real-Time Queue Visualizer</h2>
      
      <button 
        onClick={handleScheduleJob}
        style={{ 
          backgroundColor: '#4caf50', 
          color: 'white', 
          border: 'none', 
          padding: '10px 20px', 
          marginBottom: '20px', 
          cursor: 'pointer',
          fontSize: '16px'
        }}
      >
        Trigger Job Scheduling
      </button>

      <div style={{ border: '1px solid #ddd', padding: '15px', borderRadius: '8px' }}>
        <Bar label="Waiting" count={metrics.waiting} color="#ff9800" />
        <Bar label="Active" count={metrics.active} color="#2196f3" />
        <Bar label="Completed" count={metrics.completed} color="#4caf50" />
        <Bar label="Failed" count={metrics.failed} color="#f44336" />
      </div>

      <div style={{ marginTop: '10px', fontSize: '12px', color: '#666' }}>
        Last updated: {new Date().toLocaleTimeString()}
      </div>
    </div>
  );
};

export default QueueVisualizer;
