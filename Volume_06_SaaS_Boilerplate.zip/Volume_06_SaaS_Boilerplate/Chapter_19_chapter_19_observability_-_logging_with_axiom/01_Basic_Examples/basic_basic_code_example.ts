/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

// File: app/api/chat/init/route.ts
import { NextRequest, NextResponse } from 'next/server';
import winston from 'winston';
import { AxiomTransport } from '@axiomhq/winston';

/**
 * 1. CONFIGURATION & TYPE SAFETY
 * We define a strict interface for our log payload. This prevents 
 * "hallucinated JSON" where log properties might be undefined or misspelled.
 */
interface ChatInitLog {
  userId: string;
  timestamp: string;
  action: 'chat_init' | 'context_fetch';
  metadata: {
    ip: string | null;
    userAgent: string | null;
    vectorSearchDuration: number; // Simulated pgvector latency
  };
  level: 'info' | 'error' | 'warn';
}

/**
 * 2. WINSTON LOGGER SETUP
 * We initialize Winston with a custom format. In production, we add 
 * the AxiomTransport. In development, we fall back to console for readability.
 * 
 * CRITICAL: Environment variables must be set in your Vercel/Env file:
 * - AXIOM_TOKEN: Your API token
 * - AXIOM_DATASET: The dataset name (e.g., 'production-logs')
 */
const logger = winston.createLogger({
  level: 'info',
  format: winston.format.combine(
    winston.format.timestamp(),
    winston.format.json() // Structured logging is essential for querying
  ),
  transports: [
    // Only add Axiom in production to avoid noise during local dev
    process.env.NODE_ENV === 'production' && process.env.AXIOM_TOKEN
      ? new AxiomTransport({
          dataset: process.env.AXIOM_DATASET || 'boilerplate-logs',
          token: process.env.AXIOM_TOKEN,
        })
      : new winston.transports.Console({
          format: winston.format.simple(),
        }),
  ],
});

/**
 * 3. DATA FETCHING MOCK (SCs Pattern)
 * Simulates fetching initial context from a Supabase/pgvector database.
 * In a real app, this would be an async call to your DB.
 */
async function fetchContextMock(userId: string): Promise<{ context: string; latency: number }> {
  // Simulate network latency and vector search
  await new Promise((resolve) => setTimeout(resolve, 150));
  return { context: 'User prefers dark mode.', latency: 150 };
}

/**
 * 4. API HANDLER
 * The main entry point for the request.
 */
export async function POST(req: NextRequest) {
  const startTime = Date.now();
  
  try {
    // Parse incoming payload
    const body = await req.json();
    const { userId } = body;

    // Type Guard: Ensure userId is a string
    if (typeof userId !== 'string') {
      const errorLog: ChatInitLog = {
        userId: 'unknown',
        timestamp: new Date().toISOString(),
        action: 'chat_init',
        level: 'error',
        metadata: {
          ip: req.ip || null,
          userAgent: req.headers.get('user-agent'),
          vectorSearchDuration: 0,
        },
      };
      
      logger.error('Invalid User ID provided', errorLog);
      return NextResponse.json({ error: 'Invalid User ID' }, { status: 400 });
    }

    // 5. LOGGING THE INCOMING REQUEST
    const requestLog: ChatInitLog = {
      userId: userId,
      timestamp: new Date().toISOString(),
      action: 'chat_init',
      level: 'info',
      metadata: {
        ip: req.ip || null,
        userAgent: req.headers.get('user-agent'),
        vectorSearchDuration: 0, // Placeholder
      },
    };
    
    // Stream log to Axiom immediately
    logger.info('Incoming chat initialization', requestLog);

    // 6. EXECUTE BUSINESS LOGIC (Data Fetching)
    const { context, latency } = await fetchContextMock(userId);
    const totalTime = Date.now() - startTime;

    // 7. LOGGING PERFORMANCE METRICS
    const perfLog: ChatInitLog = {
      userId: userId,
      timestamp: new Date().toISOString(),
      action: 'context_fetch',
      level: 'info',
      metadata: {
        ip: req.ip || null,
        userAgent: req.headers.get('user-agent'),
        vectorSearchDuration: latency,
      },
    };

    logger.info('Context fetched successfully', perfLog);

    // Return response
    return NextResponse.json({ 
      status: 'success', 
      context,
      duration: totalTime 
    });

  } catch (error) {
    // 8. ERROR LOGGING
    const errorLog: ChatInitLog = {
      userId: 'unknown', // Safe fallback
      timestamp: new Date().toISOString(),
      action: 'chat_init',
      level: 'error',
      metadata: {
        ip: req.ip || null,
        userAgent: req.headers.get('user-agent'),
        vectorSearchDuration: 0,
      },
    };

    // Winston handles Error objects specially, but we attach our structured data
    logger.error('Critical failure in chat init', { ...errorLog, error });
    
    return NextResponse.json({ error: 'Internal Server Error' }, { status: 500 });
  }
}
