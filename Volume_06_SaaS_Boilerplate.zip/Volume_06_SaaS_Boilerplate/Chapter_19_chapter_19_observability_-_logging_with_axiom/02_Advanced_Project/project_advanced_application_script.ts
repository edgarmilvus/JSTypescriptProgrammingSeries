/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// src/app/api/ai/retrieve/route.ts
// Target: Next.js 14+ App Router (Edge Runtime or Node.js)
// Dependencies: @pinecone-database/pinecone, winston, axiom

import { NextRequest, NextResponse } from 'next/server';
import { Pinecone } from '@pinecone-database/pinecone';
import winston from 'winston';
import { axiomTransport } from '@axiomhq/winston';

// ==============================================================================
// 1. OBSERVABILITY CONFIGURATION (Axiom + Winston)
// ==============================================================================

/**
 * Initializes a structured logger configured to stream logs to Axiom.
 * 
 * Why: Centralized logging is crucial for SaaS observability. We need to distinguish
 * between 'info', 'error', and 'debug' levels to filter logs effectively in Axiom.
 * 
 * Under the Hood: Winston is a versatile logging library. The Axiom transport
 * batches logs and sends them asynchronously to the Axiom API, preventing network
 * latency from blocking the main application thread.
 */
const logger = winston.createLogger({
  level: process.env.LOG_LEVEL || 'info',
  format: winston.format.combine(
    winston.format.timestamp(),
    winston.format.json() // Structured JSON is required for Axiom parsing
  ),
  transports: [
    // Console transport for local development visibility
    new winston.transports.Console(),
    // Axiom transport for production observability
    new axiomTransport({
      dataset: process.env.AXIOM_DATASET || 'saaS-ai-retrieval',
    }),
  ],
});

// ==============================================================================
// 2. PINECONE CLIENT INITIALIZATION
// ==============================================================================

/**
 * Singleton Pinecone Client instance.
 * 
 * Why: Database connections are expensive. We avoid re-initializing the client
 * on every hot-reload or request by checking if an instance already exists.
 * 
 * Exhaustive Async Resilience: We wrap initialization in a try-catch block
 * to handle environment variable misconfigurations or network failures immediately.
 */
let pinecone: Pinecone | null = null;

const initializePinecone = async (): Promise<Pinecone> => {
  if (pinecone) return pinecone;

  try {
    const apiKey = process.env.PINECONE_API_KEY;
    const environment = process.env.PINECONE_ENVIRONMENT;

    if (!apiKey || !environment) {
      throw new Error('Pinecone API Key or Environment is missing.');
    }

    pinecone = new Pinecone({
      apiKey,
      environment,
    });

    logger.info('Pinecone client initialized successfully', {
      service: 'vector-db',
      environment,
    });

    return pinecone;
  } catch (error) {
    // Critical failure: Log with high severity
    logger.error('Failed to initialize Pinecone client', {
      service: 'vector-db',
      error: (error as Error).message,
      stack: (error as Error).stack,
    });
    throw error; // Re-throw to halt execution
  }
};

// ==============================================================================
// 3. SUPERVISOR NODE & ROUTING LOGIC
// ==============================================================================

/**
 * Represents the state of the request graph.
 * In a complex multi-agent system, this would hold conversation history,
 * user context, and tool outputs. Here, it holds the query and metadata.
 */
interface GraphState {
  query: string;
  topK: number;
  filter?: Record<string, any>;
}

/**
 * Supervisor Node: Analyzes the request and delegates to the appropriate Worker Agent.
 * 
 * Why: In a SaaS context, we often need to route requests based on context.
 * This Supervisor checks if the query is valid and routes to the 'VectorSearchWorker'.
 * 
 * Logic:
 * 1. Validate input (Sanity check).
 * 2. Select the appropriate Pinecone Index (Tenant Isolation).
 * 3. Delegate to the Worker Agent.
 */
class SupervisorNode {
  private pc: Pinecone;

  constructor(pineconeClient: Pinecone) {
    this.pc = pineconeClient;
  }

  async execute(state: GraphState): Promise<string[]> {
    logger.info('Supervisor Node invoked', { state });

    // Input Validation
    if (!state.query || state.query.trim().length === 0) {
      logger.warn('Supervisor rejected empty query', { state });
      return [];
    }

    // Dynamic Index Selection (Simulating multi-tenant routing)
    const indexName = process.env.PINECONE_INDEX_NAME || 'default-index';
    const index = this.pc.index(indexName);

    // Delegate to Worker Agent (Vector Search)
    const worker = new VectorSearchWorker(index);
    return await worker.performSearch(state);
  }
}

// ==============================================================================
// 4. WORKER AGENT: VECTOR SEARCH
// ==============================================================================

/**
 * VectorSearchWorker: Handles the specific logic of vector similarity search.
 * 
 * Why: Separation of concerns. The Supervisor handles routing; the Worker handles
 * the heavy lifting of database interaction.
 * 
 * Exhaustive Async Resilience:
 * - Uses try/catch/finally blocks.
 * - Ensures the connection context is handled gracefully (though Pinecone SDK handles this internally,
 *   we simulate resource awareness).
 */
class VectorSearchWorker {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  private index: any; // Pinecone Index type is complex, using any for brevity

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  constructor(index: any) {
    this.index = index;
  }

  async performSearch(state: GraphState): Promise<string[]> {
    const startTime = Date.now();
    logger.info('Worker Agent: Starting vector search', { query: state.query });

    try {
      // In a real app, we would generate an embedding for state.query here.
      // For this script, we simulate a vector array.
      const queryVector: number[] = Array(1536).fill(0).map(() => Math.random());

      // Execute Query
      const queryResponse = await this.index.query({
        vector: queryVector,
        topK: state.topK || 3,
        includeMetadata: true,
      });

      const matches = queryResponse.matches || [];
      
      // Extract relevant data (e.g., document text)
      const results = matches.map((match: any) => {
        // Log specific match metadata for audit trails
        logger.debug('Match found', { 
          id: match.id, 
          score: match.score,
          metadata: match.metadata 
        });
        return match.metadata?.text || `Match ID: ${match.id}`;
      });

      const duration = Date.now() - startTime;
      logger.info('Worker Agent: Search completed successfully', {
        query: state.query,
        resultCount: results.length,
        durationMs: duration,
      });

      return results;

    } catch (error) {
      // Exhaustive Error Handling
      logger.error('Worker Agent: Search failed', {
        query: state.query,
        error: (error as Error).message,
      });
      // Return empty array to prevent API crash, allowing graceful degradation
      return [];
    } finally {
      // Resource cleanup simulation (e.g., closing specific connections if pooled)
      logger.debug('Worker Agent: Cleanup complete', { query: state.query });
    }
  }
}

// ==============================================================================
// 5. NEXT.JS API ROUTE HANDLER
// ==============================================================================

/**
 * POST Handler: Entry point for the AI Retrieval API.
 * 
 * Why: Standardizes the request flow. It initializes the infrastructure
 * (Pinecone) and invokes the Supervisor Node.
 * 
 * Error Boundary: Catches any unhandled errors from the Supervisor chain
 * and returns a standardized JSON error response.
 */
export async function POST(request: NextRequest) {
  const requestId = crypto.randomUUID(); // Trace ID for request correlation

  try {
    // 1. Parse Payload
    const body = await request.json();
    const { query, topK } = body;

    // 2. Initialize Infrastructure (Resilient Initialization)
    const pineconeClient = await initializePinecone();

    // 3. Invoke Supervisor Node
    const supervisor = new SupervisorNode(pineconeClient);
    
    // Construct Graph State
    const state: GraphState = {
      query,
      topK: topK || 3,
    };

    const results = await supervisor.execute(state);

    // 4. Return Success Response
    return NextResponse.json(
      { 
        success: true, 
        data: results,
        meta: { requestId } 
      },
      { status: 200 }
    );

  } catch (error) {
    // Global Error Boundary
    // We log the full error context to Axiom for deep debugging
    logger.error('API Route Handler: Unhandled exception', {
      requestId,
      error: (error as Error).message,
      stack: (error as Error).stack,
    });

    return NextResponse.json(
      { 
        success: false, 
        error: 'Internal Server Error', 
        meta: { requestId } 
      },
      { status: 500 }
    );
  }
}
