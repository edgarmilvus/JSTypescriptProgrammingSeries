/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

// 1. Define the successful response type
type AnalyticsResponse = {
  status: 'success';
  data: {
    totalLogs: number;
    errorRate: number;
    avgLatency: number;
  };
};

// 2. Define the union type for API results
type ApiResult = AnalyticsResponse | { status: 'error'; message: string; };

// 3. Implement the Type Guard function
function isAnalyticsResponse(response: unknown): response is AnalyticsResponse {
  // 4. Check if the input is a non-null object
  if (typeof response !== 'object' || response === null) {
    return false;
  }

  // Cast to a partial structure to check properties safely
  const potentialResponse = response as Partial<AnalyticsResponse>;

  // Verify status is 'success'
  if (potentialResponse.status !== 'success') {
    return false;
  }

  // Verify data exists and is an object
  if (!potentialResponse.data || typeof potentialResponse.data !== 'object') {
    return false;
  }

  // Verify specific data fields exist with correct types
  const data = potentialResponse.data;
  return (
    typeof data.totalLogs === 'number' &&
    typeof data.errorRate === 'number' &&
    typeof data.avgLatency === 'number'
  );
}

/*
 * Instructor's Note on Safety vs Assertion:
 * 
 * Why use a Type Guard (isAnalyticsResponse) instead of an assertion (response as AnalyticsResponse)?
 * 
 * 1. Runtime Safety: Type assertions are purely compile-time. If the API returns an error object or 
 *    malformed JSON, `as AnalyticsResponse` will not prevent runtime crashes when the code tries 
 *    to access `response.data.totalLogs` (which would be undefined).
 * 2. Control Flow: The Type Guard allows us to use conditional logic (if/else) to handle the error 
 *    state explicitly. This is crucial for React components to render fallback UIs (e.g., error banners) 
 *    instead of crashing or rendering undefined values.
 * 3. Exhaustiveness: It forces the developer to acknowledge that the API might return something other 
 *    than the expected shape, leading to more robust error boundaries in the UI.
 */
