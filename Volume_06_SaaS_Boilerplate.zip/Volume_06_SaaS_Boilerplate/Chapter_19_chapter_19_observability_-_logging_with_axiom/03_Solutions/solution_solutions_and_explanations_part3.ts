/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

// Assuming 'crypto' is available in the environment (Node.js or modern browser)
import crypto from 'crypto';

// 1. Define the HOF signature
function withTracing<T extends (...args: any[]) => Promise<any>>(
  operationName: string,
  fn: T
): (...args: Parameters<T>) => Promise<ReturnType<T>> {
  
  // Return a new function that wraps the original execution
  return async (...args: Parameters<T>): Promise<ReturnType<T>> => {
    // 2. Generate a unique correlation ID for this execution scope
    const correlationId = crypto.randomUUID();

    // 3. Log the start of the operation with the ID
    // (Assuming global logger is available)
    (logger as any).info(`Starting operation [${operationName}]`, { correlationId });

    try {
      // 4. Await the execution of the original function
      const result = await fn(...args);
      
      // 5. Log success
      (logger as any).info(`Operation [${operationName}] completed successfully`, { correlationId });
      
      return result;
    } catch (error) {
      // 6. Log error details and re-throw
      const errorMessage = error instanceof Error ? error.message : String(error);
      (logger as any).error(`Operation [${operationName}] failed`, { 
        correlationId, 
        error: errorMessage 
      });
      
      throw error;
    }
  };
}

/*
 * How this helps in Axiom:
 * 
 * In a distributed system, logs are interleaved. Without this pattern, it is impossible to distinguish 
 * logs belonging to Request A from Request B. By injecting a 'correlationId' into every log entry 
 * generated during the execution of 'fn', we create a "trace".
 * 
 * In Axiom, a developer can simply query: correlationId="<uuid>" to retrieve the exact sequence of events 
 * for that specific operation, including the start, success/failure, and any intermediate logs that 
 * might have been added inside the function. This drastically reduces debugging time for race conditions 
 * and intermittent failures.
 */
