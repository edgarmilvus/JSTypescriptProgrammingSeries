/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * @fileoverview main.ts - The main thread entry point.
 * Demonstrates setting up SharedArrayBuffer for parallel computation.
 */

/**
 * Represents the structure of the data shared in the buffer.
 * We use Int32Array to store numbers, but for AI models, Float32Array is common.
 * Structure:
 * [0]: Total count of items to process (int)
 * [1]: Worker 1's partial sum (int)
 * [2]: Worker 2's partial sum (int)
 * [3]: Final Result (int)
 */
const SHARED_BUFFER_SIZE = 4; // 4 integers

/**
 * Initializes the parallel summation process.
 * NOTE: SharedArrayBuffer requires specific security headers (Cross-Origin-Opener-Policy)
 * to function in modern browsers. Without these, the browser will throw a SecurityError.
 */
async function runParallelSum() {
  console.log("Initializing parallel summation...");

  // 1. Create the SharedArrayBuffer
  // This allocates a block of memory shared between the main thread and workers.
  const sharedBuffer = new SharedArrayBuffer(SHARED_BUFFER_SIZE * Int32Array.BYTES_PER_ELEMENT);
  
  // 2. Create a view into the shared memory
  // Int32Array allows us to read/write 32-bit integers to the buffer.
  const sharedView = new Int32Array(sharedBuffer);

  // 3. Define the data to process
  // We will split [1, 2, 3, 4] between two workers.
  // Worker 1 gets [1, 2], Worker 2 gets [3, 4].
  // Expected Sum: 10
  const data = [1, 2, 3, 4];
  
  // Store the total count in the buffer (index 0)
  sharedView[0] = data.length;

  // 4. Initialize Workers
  // We use Blob URLs to create workers without needing separate files for this example.
  const worker1Code = `
    self.onmessage = function(e) {
      const { buffer, rangeStart, rangeEnd } = e.data;
      const view = new Int32Array(buffer);
      
      let partialSum = 0;
      // Simulate some processing time (common in AI tasks)
      for(let i = rangeStart; i < rangeEnd; i++) {
        partialSum += i; // In a real app, this would process complex data
      }
      
      // Write result to shared memory (index 1 for worker 1)
      Atomics.store(view, 1, partialSum);
      
      // Notify main thread (optional, but good for sync)
      self.postMessage("Done");
    };
  `;

  const worker2Code = `
    self.onmessage = function(e) {
      const { buffer, rangeStart, rangeEnd } = e.data;
      const view = new Int32Array(buffer);
      
      let partialSum = 0;
      for(let i = rangeStart; i < rangeEnd; i++) {
        partialSum += i;
      }
      
      // Write result to shared memory (index 2 for worker 2)
      Atomics.store(view, 2, partialSum);
      
      self.postMessage("Done");
    };
  `;

  const worker1 = new Worker(URL.createObjectURL(new Blob([worker1Code], { type: 'application/javascript' })));
  const worker2 = new Worker(URL.createObjectURL(new Blob([worker2Code], { type: 'application/javascript' })));

  // 5. Distribute Work
  // Worker 1 processes indices 0 to 2 (values 1, 2)
  worker1.postMessage({ 
    buffer: sharedBuffer, 
    rangeStart: 1, 
    rangeEnd: 3 
  });

  // Worker 2 processes indices 2 to 4 (values 3, 4)
  worker2.postMessage({ 
    buffer: sharedBuffer, 
    rangeStart: 3, 
    rangeEnd: 5 
  });

  // 6. Wait for completion and aggregate
  // In a real app, we might use Atomics.wait() or Promises.
  // Here we simply wait for messages for simplicity.
  let completedWorkers = 0;

  worker1.onmessage = () => {
    completedWorkers++;
    if (completedWorkers === 2) aggregateResults();
  };

  worker2.onmessage = () => {
    completedWorkers++;
    if (completedWorkers === 2) aggregateResults();
  };

  function aggregateResults() {
    // Read from shared memory
    const worker1Sum = Atomics.load(sharedView, 1);
    const worker2Sum = Atomics.load(sharedView, 2);
    
    const total = worker1Sum + worker2Sum;
    
    // Write final result to shared memory (index 3)
    Atomics.store(sharedView, 3, total);

    console.log(`Worker 1 Sum: ${worker1Sum}`);
    console.log(`Worker 2 Sum: ${worker2Sum}`);
    console.log(`Total Sum (Shared Memory): ${total}`);
    
    // Clean up
    worker1.terminate();
    worker2.terminate();
  }
}

// Execute
// Note: This will fail if headers are not set correctly in the server response.
runParallelSum().catch(console.error);
