/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script_part2.ts
// Description: Advanced Application Script
// ==========================================

// src/app/actions/onboarding.action.ts
'use server';

import { generateText, streamObject } from 'ai';
import { openai } from '@ai-sdk/openai';
import { z } from 'zod';
import { embed } from '@ai-sdk/openai';
import { db } from '@/lib/db'; // Assume this is the Drizzle/Kysely setup with pgvector
import { eq } from 'drizzle-orm';
import { users, userPreferences } from '@/lib/schema';
import { auth } from '@/lib/auth'; // Assume this is the NextAuth adapter

/**
 * @fileoverview Advanced Application Script for AI-Enhanced Onboarding.
 * This script demonstrates the integration of Auth, Vector Database, and UIState
 * streaming to create a personalized SaaS user journey.
 */

// -----------------------------------------------------------------------------
// 1. DATA MODELS & SCHEMAS
// -----------------------------------------------------------------------------

/**
 * Represents the input schema for the onboarding action.
 * Validates that the user provides a meaningful goal string.
 */
const OnboardingInputSchema = z.object({
  goal: z.string().min(3, "Please describe your goal in at least 3 characters."),
});

/**
 * Represents the structure of the vector search result.
 * We expect the database to return a feature ID and a similarity score.
 */
interface VectorSearchResult {
  id: string;
  name: string;
  description: string;
  similarity: number;
}

/**
 * The UIState Schema.
 * This is passed to the AI model. The AI will decide which "state" to activate,
 * which dictates what the client renders.
 */
const UIStateSchema = z.object({
  state: z.enum(['loading', 'success', 'error', 'recommendations']),
  message: z.string().optional(),
  features: z.array(z.object({
    name: z.string(),
    description: z.string(),
  })).optional(),
});

// -----------------------------------------------------------------------------
// 2. CORE LOGIC: VECTOR SEARCH & AUTHENTICATION
// -----------------------------------------------------------------------------

/**
 * Performs a semantic search against the vector database.
 * 
 * @param goal - The user's onboarding goal text.
 * @returns A list of relevant features matching the semantic intent.
 */
async function semanticFeatureSearch(goal: string): Promise<VectorSearchResult[]> {
  // Step 1: Generate Embedding using text-embedding-3-small
  // This model is chosen for its balance of performance and cost-efficiency.
  const { embedding } = await embed({
    model: openai.embedding('text-embedding-3-small'),
    value: goal,
  });

  // Step 2: Query PostgreSQL with pgvector support.
  // We use the cosine similarity operator (<=>) to find the closest matches.
  // Note: In a real Drizzle/Kysely setup, you would use sql template literals.
  const results = await db.execute(
    // SQL Query Example:
    // `SELECT id, name, description, 1 - (embedding <=> $1) as similarity 
    // FROM features 
    // ORDER BY embedding <=> $1 
    // LIMIT 3`,
    [embedding]
  );

  // Map raw DB results to our interface
  return results.map((row) => ({
    id: row.id,
    name: row.name,
    description: row.description,
    similarity: row.similarity,
  })) as VectorSearchResult[];
}

// -----------------------------------------------------------------------------
// 3. THE ADVANCED SCRIPT: SERVER ACTION
// -----------------------------------------------------------------------------

/**
 * The main Server Action triggered by the client.
 * It orchestrates Auth -> Vector Search -> AI Generation -> UIState Streaming.
 * 
 * @param prevState - Previous form state (for Next.js useFormState).
 * @param formData - The form data containing the user's goal.
 */
export async function runOnboardingAssistant(
  prevState: any,
  formData: FormData
) {
  // 1. AUTHENTICATION & INPUT VALIDATION
  const session = await auth();
  if (!session?.user?.id) {
    return { error: 'Unauthorized' };
  }

  const parsed = OnboardingInputSchema.safeParse({
    goal: formData.get('goal'),
  });

  if (!parsed.success) {
    return { error: parsed.error.flatten().fieldErrors.goal?.[0] };
  }

  const { goal } = parsed.data;

  try {
    // 2. VECTOR DATABASE QUERY
    // We fetch context relevant to the user's goal.
    const relevantFeatures = await semanticFeatureSearch(goal);

    // 3. AI ORCHESTRATION WITH UISTATE
    // We use `streamObject` to generate a structured JSON object that represents
    // the UI state. This allows the client to render specific components dynamically.
    const { element } = await streamObject({
      model: openai('gpt-4-turbo'),
      schema: UIStateSchema,
      prompt: `
        You are an onboarding assistant for a SaaS platform.
        The user's goal is: "${goal}".
        
        Here are the relevant platform features retrieved from our database:
        ${relevantFeatures.map(f => `- ${f.name}: ${f.description}`).join('\n')}
        
        Based on the user's goal and the features, determine the UI state:
        1. If the goal is vague, set state to 'loading' and ask for clarification.
        2. If the goal matches features, set state to 'success' and include the features.
        3. If the goal is unrelated to our platform, set state to 'error'.
        
        Generate the JSON object.
      `,
    });

    // 4. STREAMING RESPONSE
    // The `element` is a stream of promises that resolve to the JSON object.
    // In a Next.js App Router context, we return this stream directly to the client.
    return element;
    
  } catch (error) {
    console.error("Onboarding Script Error:", error);
    return { state: 'error', message: 'Internal server error.' };
  }
}
