/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script_part3.tsx
// Description: Advanced Application Script
// ==========================================

// src/app/onboarding/page.tsx
'use client';

import { useFormState, useFormStatus } from 'react-dom';
import { runOnboardingAssistant } from '@/app/actions/onboarding.action';
import { useEffect, useRef } from 'react';
import { readStreamableValue } from 'ai/rsc';

// Helper component for the submit button
function SubmitButton() {
  const { pending } = useFormStatus();
  return (
    <button 
      type="submit" 
      disabled={pending}
      className="bg-blue-600 text-white px-4 py-2 rounded disabled:opacity-50"
    >
      {pending ? 'Analyzing...' : 'Get Recommendations'}
    </button>
  );
}

export default function OnboardingPage() {
  const [state, formAction] = useFormState(runOnboardingAssistant, null);
  const contentRef = useRef<any>(null);

  // Handle the streamed UIState
  useEffect(() => {
    const processStream = async () => {
      if (!state) return;
      
      // Read the streamable value provided by the Server Action
      for await (const chunk of readStreamableValue(state)) {
        if (chunk) {
          // In a real app, you would update a React state here.
          // For this demo, we log the dynamic chunks.
          console.log('Received UI State:', chunk);
          contentRef.current = chunk;
        }
      }
    };
    processStream();
  }, [state]);

  return (
    <div className="max-w-md mx-auto mt-10 p-6 border rounded">
      <h1 className="text-2xl font-bold mb-4">Welcome! What is your goal?</h1>
      
      <form action={formAction} className="flex flex-col gap-4">
        <input 
          name="goal" 
          placeholder="e.g., I want to build a customer support bot"
          className="border p-2 rounded text-black"
        />
        <SubmitButton />
      </form>

      {/* Dynamic UI Rendering based on Streamed State */}
      <div className="mt-6">
        {contentRef.current?.state === 'loading' && (
          <div className="text-gray-500">Thinking...</div>
        )}
        
        {contentRef.current?.state === 'success' && (
          <div className="bg-green-50 p-4 rounded border border-green-200">
            <h3 className="font-bold text-green-800">Recommended Features:</h3>
            <ul className="list-disc pl-5 mt-2">
              {contentRef.current.features?.map((f: any, i: number) => (
                <li key={i}>
                  <strong>{f.name}:</strong> {f.description}
                </li>
              ))}
            </ul>
          </div>
        )}
        
        {contentRef.current?.state === 'error' && (
          <div className="bg-red-50 p-4 rounded text-red-700">
            {contentRef.current.message}
          </div>
        )}
      </div>
    </div>
  );
}
