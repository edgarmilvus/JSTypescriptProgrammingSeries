/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// app/components/AIPromptResponse.tsx
import { Suspense } from 'react';

// 1. Simulate a slow network request for the stream
async function getStreamedResponse(prompt: string): Promise<string> {
  // Simulate a 2-second delay before the first token arrives
  await new Promise((resolve) => setTimeout(resolve, 2000));
  return `AI Generated Response to: "${prompt}"\n\nHere is the streamed content...`;
}

// 2. The Server Component that fetches data
async function ResponseContent({ prompt }: { prompt: string }) {
  const response = await getStreamedResponse(prompt);
  
  return (
    <div className="p-4 bg-gray-100 rounded-md mt-4">
      <p className="font-semibold text-gray-700">AI Response:</p>
      <p>{response}</p>
    </div>
  );
}

// 3. The Loading UI Component
function LoadingSkeleton() {
  return (
    <div className="p-4 bg-gray-100 rounded-md mt-4 animate-pulse">
      <div className="h-4 bg-gray-300 rounded w-1/4 mb-2"></div>
      <div className="h-4 bg-gray-300 rounded w-full mb-2"></div>
      <div className="h-4 bg-gray-300 rounded w-5/6"></div>
    </div>
  );
}

// 4. The Main Component with Suspense Boundary
export default function AIPromptResponse({ prompt }: { prompt: string }) {
  return (
    <div>
      <h2>Streamed AI Response</h2>
      {/* The Suspense boundary catches the pending promise from the child component */}
      <Suspense fallback={<LoadingSkeleton />}>
        <ResponseContent prompt={prompt} />
      </Suspense>
    </div>
  );
}
