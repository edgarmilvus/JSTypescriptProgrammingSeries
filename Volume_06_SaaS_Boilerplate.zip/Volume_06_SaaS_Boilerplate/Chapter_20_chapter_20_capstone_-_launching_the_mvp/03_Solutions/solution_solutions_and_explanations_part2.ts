/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

// components/DocumentEditor.tsx
'use client'; // Must be a Client Component to handle state and events
import { useState } from 'react';

// Mock API function
const upsertDocument = async (data: { id: string; title: string; content: string }) => {
  // Simulate network delay
  await new Promise((resolve) => setTimeout(resolve, 1000));
  
  // Simulate a random failure (e.g., 20% chance)
  if (Math.random() < 0.2) {
    throw new Error('Database conflict or network error');
  }
  
  return { success: true, data };
};

interface Document {
  id: string;
  title: string;
  content: string;
}

interface Props {
  initialDocument: Document;
  // Callback to update the parent list
  onOptimisticUpdate: (updatedDoc: Document) => void;
  // Callback to revert the parent list on error
  onRollback: (oldDoc: Document) => void;
}

export default function DocumentEditor({ initialDocument, onOptimisticUpdate, onRollback }: Props) {
  const [formState, setFormState] = useState(initialDocument);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setError(null);

    // 1. Save the previous state for potential rollback
    const previousDoc = { ...initialDocument };

    // 2. Optimistic Update: Update UI immediately
    onOptimisticUpdate(formState);

    try {
      // 3. Send request to server
      await upsertDocument(formState);
      // Success: The UI is already updated, no further action needed
    } catch (err) {
      // 4. Failure: Rollback UI and show error
      onRollback(previousDoc);
      setError('Failed to save changes. Reverting to previous state.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div>
        <label>Title</label>
        <input
          type="text"
          value={formState.title}
          onChange={(e) => setFormState({ ...formState, title: e.target.value })}
          disabled={isSubmitting}
          className="border p-2 w-full"
        />
      </div>
      <div>
        <label>Content</label>
        <textarea
          value={formState.content}
          onChange={(e) => setFormState({ ...formState, content: e.target.value })}
          disabled={isSubmitting}
          className="border p-2 w-full h-24"
        />
      </div>
      <button type="submit" disabled={isSubmitting} className="bg-blue-500 text-white px-4 py-2 rounded">
        {isSubmitting ? 'Saving...' : 'Save Changes'}
      </button>
      {error && <p className="text-red-500 text-sm">{error}</p>}
    </form>
  );
}
