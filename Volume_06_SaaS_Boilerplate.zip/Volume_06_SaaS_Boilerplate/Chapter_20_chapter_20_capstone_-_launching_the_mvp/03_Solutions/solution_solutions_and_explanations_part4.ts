/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

// types.ts
export type SubscriptionStatus = 'none' | 'trialing' | 'active' | 'canceled';

export interface User {
  id: string;
  email: string;
  name: string;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
}

export interface Document {
  id: string;
  title: string;
  content: string;
  vector: number[]; // Pre-computed embedding
}

export interface GlobalState {
  user: User | null;
  subscription: {
    status: SubscriptionStatus;
    plan?: string;
  } | null;
  chatHistory: ChatMessage[];
  documents: Document[];
}

// components/Dashboard.tsx
'use client';
import { useState, useEffect } from 'react';
import { findTopMatches } from '../utils/search'; // From Exercise 3

// Mock Components for structure
const LoginPrompt = () => <div>Please log in.</div>;
const PaymentWall = () => <div>Upgrade your subscription to access Chat.</div>;
const Suspense = ({ children, fallback }: any) => <div>{children}</div>; // Placeholder

// Simulated AI Response Component (From Exercise 1)
const AIResponse = ({ context }: { context: string }) => {
  // In a real app, this would stream data
  return <div className="p-4 border rounded mt-2">AI: Based on context: {context}</div>;
};

export default function Dashboard() {
  // 1. Global State Shape
  const [state, setState] = useState<GlobalState>({
    user: null, // Start logged out
    subscription: null,
    chatHistory: [],
    documents: [
      { id: 'doc1', title: 'React Docs', content: 'React is a library...', vector: [0.1, 0.9] },
      { id: 'doc2', title: 'Node Guide', content: 'Node is a runtime...', vector: [0.9, 0.1] },
    ],
  });

  const [input, setInput] = useState('');
  const [ragContext, setRagContext] = useState<string | null>(null);

  // 2. Conditional Rendering Logic
  if (!state.user) return <LoginPrompt />;
  if (state.subscription?.status === 'none') return <PaymentWall />;

  // 3. Chat Interface Logic
  const handleSend = async () => {
    if (!input.trim()) return;

    // Add user message
    const userMsg: ChatMessage = { id: Date.now().toString(), role: 'user', content: input, timestamp: new Date() };
    setState((prev) => ({ ...prev, chatHistory: [...prev.chatHistory, userMsg] }));
    setInput('');

    // Trigger RAG Search (Simulated query vector)
    const queryVector = [0.15, 0.85]; // Would be derived from 'input' in real app
    const matches = findTopMatches(queryVector, state.documents, 1);
    
    // Prepare context for AI
    const context = matches.length > 0 
      ? matches[0].id // In reality, use the document content
      : 'No relevant context found.';
    
    setRagContext(context);
  };

  const handleUpload = () => {
    // 4. Upsert Operation Simulation
    const newDoc: Document = { 
      id: `doc${state.documents.length + 1}`, 
      title: 'New Doc', 
      content: 'New content...', 
      vector: [Math.random(), Math.random()] 
    };
    
    // Optimistic update to local state
    setState((prev) => ({ ...prev, documents: [...prev.documents, newDoc] }));
    // Note: In a real app, we would call an API here. 
    // The 'documents' state drives the vector search capability automatically.
  };

  return (
    <div className="dashboard">
      <h1>Dashboard</h1>
      
      {/* Chat Area */}
      <div className="chat-container">
        {state.chatHistory.map((msg) => (
          <div key={msg.id} className={msg.role === 'user' ? 'user-msg' : 'ai-msg'}>
            {msg.content}
          </div>
        ))}
        
        <input 
          value={input} 
          onChange={(e) => setInput(e.target.value)} 
          placeholder="Ask a question..." 
        />
        <button onClick={handleSend}>Send</button>

        {/* RAG Integration */}
        <button onClick={handleUpload} className="ml-2 bg-green-500 text-white p-1">
          Upload Doc (Upsert)
        </button>

        {/* Suspense Boundary for AI Response */}
        {ragContext && (
          <Suspense fallback={<div>Generating response...</div>}>
            <AIResponse context={ragContext} />
          </Suspense>
        )}
      </div>
    </div>
  );
}
