/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.ts
// Description: Basic Code Example
// ==========================================

// app/actions/feedback.ts
'use server'; // Marks this file/module as server-side only

import { z } from 'zod';

// Define the schema for validation using Zod
const FeedbackSchema = z.object({
  email: z.string().email({ message: "Invalid email address" }),
  message: z.string().min(10, { message: "Message must be at least 10 characters" }),
});

/**
 * Server Action: Handles form submission.
 * This runs exclusively on the server, has access to the database, 
 * and returns a serializable state object.
 * 
 * @param prevState - The previous state returned from this action (or initial state)
 * @param formData - The native FormData object from the browser
 * @returns An object representing the new state
 */
export async function submitFeedback(prevState: any, formData: FormData) {
  // 1. Simulate a network delay to demonstrate loading states
  await new Promise((resolve) => setTimeout(resolve, 1500));

  // 2. Parse and validate data
  const validatedFields = FeedbackSchema.safeParse({
    email: formData.get('email'),
    message: formData.get('message'),
  });

  // 3. Handle validation errors
  if (!validatedFields.success) {
    return {
      status: 'error' as const,
      message: validatedFields.error.errors[0].message,
    };
  }

  // 4. Simulate Database Write (e.g., Prisma, Drizzle)
  // In a real app: await db.feedback.create({ data: validatedFields.data });
  console.log('Saving to DB:', validatedFields.data);

  // 5. Return Success State
  return {
    status: 'success' as const,
    message: 'Thank you! Your feedback has been received.',
  };
}
