/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.tsx
// Description: Advanced Application Script
// ==========================================

'use server'; // Marks this file/section as containing Server Actions

import { z } from 'zod';
import { faker } from '@faker-js/faker'; // Used to simulate AI generation
import { revalidatePath } from 'next/cache';
import { useState, useOptimistic, startTransition } from 'react';

// ==========================================
// 1. DATA MODELS & VALIDATION
// ==========================================
// We use Zod for runtime validation, ensuring type safety across the boundary.
// This mimics the strict typing of tRPC but within standard Server Actions.

const BlogIdeaSchema = z.object({
  topic: z.string().min(3, "Topic must be at least 3 characters"),
});

type BlogIdeaInput = z.infer<typeof BlogIdeaSchema>;
type GeneratedIdea = {
  id: string;
  title: string;
  confidence: number; // Simulated AI metric
};

// ==========================================
// 2. SERVER ACTION: "INTELLIGENT API"
// ==========================================
// This function executes exclusively on the server.
// It simulates Headless Inference (processing data without UI).

export async function generateBlogIdeas(
  prevState: any, 
  formData: FormData
): Promise<{ ideas: GeneratedIdea[]; error?: string }> {
  
  // A. VALIDATION
  const parsed = BlogIdeaSchema.safeParse({
    topic: formData.get('topic'),
  });

  if (!parsed.success) {
    return { ideas: [], error: parsed.error.errors[0].message };
  }

  // B. HEADLESS INFERENCE (SIMULATED)
  // In a real scenario, this would call an LLM API or run a model locally.
  // We add an artificial delay to demonstrate the Optimistic UI loading state.
  await new Promise((resolve) => setTimeout(resolve, 2000));

  const { topic } = parsed.data;

  // C. DATA TRANSFORMATION
  // Generating structured data based on the input.
  const ideas: GeneratedIdea[] = Array.from({ length: 3 }).map(() => ({
    id: crypto.randomUUID(),
    title: `${faker.hacker.adjective()} ${topic} Strategy: ${faker.hacker.ingverb()}`,
    confidence: Number((Math.random() * 0.5 + 0.5).toFixed(2)), // 0.50 - 1.00
  }));

  // D. POST-PROCESSING
  // Revalidate cache if applicable (standard Next.js behavior)
  revalidatePath('/dashboard/ideas');

  return { ideas, error: undefined };
}

// ==========================================
// 3. CLIENT COMPONENT
// ==========================================
// Uses 'useOptimistic' for Reconciliation.

export default function IdeaGenerator() {
  // State for the "confirmed" data from the server
  const [state, setState] = useState<{ ideas: GeneratedIdea[]; error?: string }>({
    ideas: [],
    error: undefined,
  });

  // OPTIMISTIC UI STATE
  // 'useOptimistic' allows us to update the UI immediately while the server processes.
  // It handles the reconciliation automatically when the server responds.
  const [optimisticState, addOptimistic] = useOptimistic(
    state,
    (currentState: typeof state, optimisticValue: { isLoading: boolean }) => {
      // We return a temporary state structure to show loading UI
      return {
        ...currentState,
        isLoading: optimisticValue.isLoading,
      };
    }
  );

  // FORM ACTION HANDLER
  const handleSubmit = async (formData: FormData) => {
    // 1. Trigger Optimistic Update (Show Loading)
    startTransition(() => {
      addOptimistic({ isLoading: true });
    });

    // 2. Execute Server Action
    const result = await generateBlogIdeas(undefined, formData);

    // 3. Reconcile State (Update with confirmed data)
    // This replaces the optimistic state with the actual server response.
    setState(result);
    
    // Reset optimistic loading state implicitly by updating the base state
    // Note: In React 19, useOptimistic resolves automatically when the promise settles.
  };

  return (
    <div style={{ maxWidth: '600px', margin: '0 auto', padding: '20px', fontFamily: 'sans-serif' }}>
      <h1>AI Blog Idea Generator</h1>
      
      {/* Form invokes the Server Action directly */}
      <form action={handleSubmit} style={{ marginBottom: '20px' }}>
        <input 
          name="topic" 
          placeholder="Enter a topic (e.g., 'React Performance')"
          style={{ padding: '10px', width: '70%', marginRight: '10px' }}
        />
        <button 
          type="submit" 
          disabled={optimisticState.isLoading}
          style={{ padding: '10px', cursor: optimisticState.isLoading ? 'wait' : 'pointer' }}
        >
          {optimisticState.isLoading ? 'Generating...' : 'Generate Ideas'}
        </button>
      </form>

      {/* Error Display */}
      {state.error && <p style={{ color: 'red' }}>Error: {state.error}</p>}

      {/* LIST RENDERING: Reconciliation Logic */}
      <ul style={{ listStyle: 'none', padding: 0 }}>
        {optimisticState.isLoading ? (
          // 1. Loading Skeleton (Optimistic UI)
          Array.from({ length: 3 }).map((_, i) => (
            <li key={i} style={{ background: '#f3f4f6', padding: '15px', marginBottom: '10px', borderRadius: '8px' }}>
              <div style={{ height: '20px', background: '#e5e7eb', width: '80%', marginBottom: '8px' }}></div>
              <div style={{ height: '12px', background: '#e5e7eb', width: '40%' }}></div>
            </li>
          ))
        ) : state.ideas.length > 0 ? (
          // 2. Confirmed State (Server Response)
          state.ideas.map((idea) => (
            <li key={idea.id} style={{ border: '1px solid #e5e7eb', padding: '15px', marginBottom: '10px', borderRadius: '8px' }}>
              <strong>{idea.title}</strong>
              <div style={{ fontSize: '0.85em', color: '#6b7280', marginTop: '5px' }}>
                Confidence Score: {idea.confidence * 100}%
              </div>
            </li>
          ))
        ) : (
          // 3. Empty State
          <li style={{ color: '#9ca3af', textAlign: 'center' }}>No ideas generated yet.</li>
        )}
      </ul>
    </div>
  );
}
