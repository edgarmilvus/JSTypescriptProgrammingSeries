/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

// trpc/router.ts
import { initTRPC } from '@trpc/server';
import { z } from 'zod';

const t = initTRPC.create();

const userSchema = z.object({
  id: z.string(),
  name: z.string(),
  email: z.string().email(),
});

export const appRouter = t.router({
  getUser: t.procedure
    .input(z.object({ id: z.string() })) // Input validation schema
    .query(async (opts) => {
      const { input } = opts;
      // Simulate fetching from DB
      const user = await db.users.findById(input.id);
      return userSchema.parse(user); // Output type inferred from Zod schema
    }),
});

export type AppRouter = typeof appRouter;

// hooks/useUser.ts
import { trpc } from '../utils/trpc'; // Assuming trpc client is set up in utils

export function useUser(userId: string) {
  // tRPC hooks are built on TanStack Query
  const { data: user, isLoading, error } = trpc.getUser.useQuery({ id: userId });

  return {
    user,
    isLoading,
    error,
  };
}

// Client Component Usage Example (not required in code block but implied)
// const { user, isLoading, error } = useUser('123');
