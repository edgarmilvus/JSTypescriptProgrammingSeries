/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

digraph G {
    rankdir=TB;
    node [shape=box];

    subgraph cluster_server {
        label = "Server Side (SSR)";
        ServerReq [label="HTTP Request\n(Cookie: theme=dark)"];
        ServerRender [label="Server Component Render\nGenerates HTML with Dark Class"];
        ServerHTML [label="Response HTML\n<body class='dark'>...</body>"];
    }

    subgraph cluster_client {
        label = "Client Side (Browser)";
        ClientHTML [label="Initial DOM\n(Inherits Server HTML)"];
        ClientJS [label="Client JS Execution\nReads localStorage (Light)"];
        Hydration [label="Hydration Mismatch\n(React Error: Content mismatch)"];
        FinalDOM [label="Corrected DOM\n<body class='light'>"];
    }

    ServerReq -> ServerRender -> ServerHTML;
    ServerHTML -> ClientHTML;
    ClientHTML -> ClientJS;
    ClientJS -> Hydration;
    Hydration -> FinalDOM [label="Force Update"];
}
