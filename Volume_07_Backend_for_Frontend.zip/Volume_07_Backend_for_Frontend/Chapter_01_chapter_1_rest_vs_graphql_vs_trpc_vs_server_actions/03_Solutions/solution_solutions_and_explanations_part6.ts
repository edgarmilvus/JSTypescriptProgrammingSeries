/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part6.ts
// Description: Solutions and Explanations
// ==========================================

// trpc/router.ts
import { initTRPC } from '@trpc/server';
import { z } from 'zod';

const t = initTRPC.create();

export const documentRouter = t.router({
  // Fetch document content and metadata
  getDocument: t.procedure
    .input(z.object({ documentId: z.string() }))
    .query(async ({ input }) => {
      // Fetch document data from DB
      const doc = await db.documents.findUnique({
        where: { id: input.documentId },
        include: { comments: true, collaborators: true },
      });
      return doc;
    }),

  // Fetch specific comments for a paragraph
  getCommentsForParagraph: t.procedure
    .input(z.object({ documentId: z.string(), paragraphIndex: z.number() }))
    .query(async ({ input }) => {
      return db.comments.findMany({
        where: {
          documentId: input.documentId,
          paragraphIndex: input.paragraphIndex,
        },
      });
    }),
});

export type AppRouter = typeof documentRouter;
