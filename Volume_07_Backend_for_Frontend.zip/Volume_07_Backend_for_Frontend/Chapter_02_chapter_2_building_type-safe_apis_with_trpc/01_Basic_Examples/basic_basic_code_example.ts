/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * @fileoverview Basic tRPC "Hello World" SaaS Backend
 * 
 * This file demonstrates a minimal tRPC server setup.
 * It defines a single query procedure that accepts a user's name
 * and returns a personalized greeting.
 */

// 1. IMPORTS
// We import the necessary tRPC libraries and Zod for schema validation.
// '@trpc/server' contains the core logic for creating routers and procedures.
// 'z' is the standard import for Zod.
import { initTRPC } from '@trpc/server';
import { z } from 'zod';

// 2. INITIALIZATION
// The `initTRPC` function creates a set of utilities for defining our API.
// We typically call this once per application lifecycle.
const t = initTRPC.create();

// 3. MIDDLEWARE & CONTEXT (Optional for Hello World, but good practice)
// In a real SaaS app, context would carry user authentication data.
// Here, we define a simple context interface to show how it's structured.
interface Context {
  user?: {
    id: string;
    name: string;
  };
}

// 4. INPUT VALIDATION SCHEMA
// We define a Zod schema to validate the input of our procedure.
// This ensures type safety from the client all the way to the database.
const greetingInputSchema = z.object({
  name: z.string().min(1, "Name must be at least 1 character long"),
});

// 5. PROCEDURE DEFINITION
// We create a "query" procedure. In tRPC, queries are used for fetching data (GET),
// while mutations are used for modifying data (POST/PUT/DELETE).
const publicProcedure = t.procedure;

// 6. ROUTER DEFINITION
// The router aggregates procedures. Here we define a router named 'greeting'
// containing a single query named 'sayHello'.
const appRouter = t.router({
  greeting: t.router({
    sayHello: publicProcedure
      // Input validation is chained using .input()
      .input(greetingInputSchema)
      // The resolver function executes the logic. It receives the validated input.
      .query((opts) => {
        const { input } = opts;
        
        // In a real app, you might fetch user data from a DB here.
        // For this example, we simply return a string.
        return {
          message: `Hello, ${input.name}! Welcome to the SaaS platform.`,
          timestamp: new Date().toISOString(),
        };
      }),
  }),
});

// 7. EXPORT TYPE DEFINITIONS
// This is the most critical part for end-to-end type safety.
// We export the router's type definition to be used by the frontend client.
export type AppRouter = typeof appRouter;

// NOTE: In a real server file (e.g., index.ts), you would now pass 
// `appRouter` to an HTTP adapter like `createExpressMiddleware` or `createNextApiHandler`.
