/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// src/server/api/routers/user.ts
import { z } from "zod";
import { createTRPCRouter, publicProcedure } from "~/server/api/trpc";

export const userRouter = createTRPCRouter({
  getUserById: publicProcedure
    // 1. Define the input schema with UUID validation and optional boolean
    .input(
      z.object({
        userId: z.string().uuid(),
        includeProfile: z.boolean().optional(),
      })
    )
    // 2. Define the output schema dynamically based on input
    .output(
      z.union([
        z.object({ userId: z.string(), username: z.string() }),
        z.object({
          userId: z.string(),
          username: z.string(),
          profile: z.object({ bio: z.string(), avatar: z.string() }),
        }),
      ])
    )
    // 3. Implement the resolver with inferred types
    .query(({ input }) => {
      // Simulate database fetch
      const baseUser = {
        userId: input.userId,
        username: "johndoe",
      };

      // 4. Return data based on the optional input
      if (input.includeProfile) {
        return {
          ...baseUser,
          profile: {
            bio: "Loves tRPC",
            avatar: "avatar.jpg",
          },
        };
      }

      return baseUser;
    }),
});
