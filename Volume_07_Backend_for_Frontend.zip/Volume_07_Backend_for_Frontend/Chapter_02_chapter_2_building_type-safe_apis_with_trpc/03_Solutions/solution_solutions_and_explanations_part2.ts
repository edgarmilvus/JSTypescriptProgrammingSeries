/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

// src/server/api/routers/protected.ts
import { z } from "zod";
import { createTRPCRouter, protectedProcedure } from "~/server/api/trpc";
import { TRPCError } from "@trpc/server";
import { middleware } from "~/server/api/trpc";

// 1. Define the isAuthenticated middleware
const isAuthenticated = middleware(async ({ ctx, next }) => {
  // Extract token from headers (simulated)
  const token = ctx.headers["x-authorization-token"];

  if (!token || typeof token !== "string") {
    throw new TRPCError({ code: "UNAUTHORIZED", message: "Missing token" });
  }

  // 2. Simulate JWT decoding (split by '.' and take payload)
  // In a real app, use a library like 'jsonwebtoken'
  const parts = token.split(".");
  if (parts.length !== 3) {
    throw new TRPCError({ code: "UNAUTHORIZED", message: "Invalid token format" });
  }

  // Simulate extracting userId from payload
  const payload = JSON.parse(Buffer.from(parts[1], "base64").toString());
  const userId = payload.userId as string;

  // 3. Enrich context
  return next({
    ctx: {
      ...ctx,
      user: {
        id: userId,
      },
    },
  });
});

// 4. Create a router using the middleware
export const protectedRouter = createTRPCRouter({
  // Apply middleware to all procedures in this router
  me: protectedProcedure.use(isAuthenticated).query(({ ctx }) => {
    // 5. Access the enriched context
    return {
      message: "Authenticated successfully",
      userId: ctx.user.id,
    };
  }),
});
