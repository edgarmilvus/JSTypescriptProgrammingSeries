/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.tsx
// Description: Solutions and Explanations
// ==========================================

// src/components/UserProfile.tsx
import React, { useState } from 'react';
import { api } from '~/utils/api';

interface UserProfileProps {
  userId: string;
}

export const UserProfile: React.FC<UserProfileProps> = ({ userId }) => {
  // 1. Use the useQuery hook for data fetching
  const { data, isLoading, error, refetch } = api.user.getUserById.useQuery({
    userId,
    includeProfile: true, // Interactive challenge requirement
  });

  // 2. State for the mutation input
  const [newUsername, setNewUsername] = useState("");

  // 3. Use the useMutation hook (assuming mutation exists in router)
  // Note: We need to define the mutation in the backend first. 
  // For this solution, we assume `api.user.updateUsername` exists.
  const updateMutation = api.user.updateUsername.useMutation({
    onSuccess: () => {
      // 4. Refetch data after successful mutation
      refetch();
    },
  });

  const handleUpdate = () => {
    if (newUsername.trim()) {
      updateMutation.mutate({ userId, newUsername });
    }
  };

  // 5. Handle Loading State
  if (isLoading) {
    return <div>Loading user data...</div>;
  }

  // 6. Handle Error State
  if (error) {
    return <div>Error: {error.message}</div>;
  }

  // 7. Render Data
  return (
    <div className="p-4 border rounded shadow-sm">
      <h2 className="text-xl font-bold">User Profile</h2>
      <p><strong>ID:</strong> {data?.userId}</p>
      <p><strong>Username:</strong> {data?.username}</p>
      
      {data && 'profile' in data && (
        <div className="mt-2 p-2 bg-gray-50">
          <p><strong>Bio:</strong> {data.profile.bio}</p>
        </div>
      )}

      <div className="mt-4">
        <input
          type="text"
          value={newUsername}
          onChange={(e) => setNewUsername(e.target.value)}
          placeholder="New Username"
          className="border p-1 mr-2"
        />
        <button 
          onClick={handleUpdate}
          disabled={updateMutation.isLoading}
          className="bg-blue-500 text-white px-3 py-1 rounded disabled:bg-gray-300"
        >
          {updateMutation.isLoading ? 'Updating...' : 'Update Username'}
        </button>
      </div>
    </div>
  );
};
