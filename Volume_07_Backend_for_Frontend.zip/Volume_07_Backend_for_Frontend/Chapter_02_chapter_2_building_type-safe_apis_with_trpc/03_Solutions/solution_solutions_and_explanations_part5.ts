/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

// src/server/api/factories/entityFactory.ts
import { z } from "zod";
import { createTRPCRouter, publicProcedure } from "~/server/api/trpc";

// 1. Define the generic Entity interface
interface Entity {
  id: string;
}

// 2. Factory function to create a router for any entity
export function createEntityRouter<T extends Entity>(entityName: string) {
  // In-memory storage simulation
  const storage = new Map<string, T>();

  return createTRPCRouter({
    // Get by ID
    getById: publicProcedure
      .input(z.object({ id: z.string() }))
      .query(({ input }) => {
        return storage.get(input.id) || null;
      }),

    // Create
    create: publicProcedure
      .input(z.record(z.any())) // Accepts any object matching T (minus ID)
      .mutation(({ input }) => {
        const id = Math.random().toString(36).substring(7);
        const newItem = { ...input, id } as T;
        storage.set(id, newItem);
        return newItem;
      }),

    // Delete
    delete: publicProcedure
      .input(z.object({ id: z.string() }))
      .mutation(({ input }) => {
        storage.delete(input.id);
        return { success: true, message: `${entityName} deleted` };
      }),

    // 3. Interactive Challenge: Generic Search
    search: publicProcedure
      .input(z.object({ query: z.string() }))
      .query(({ input }) => {
        const query = input.query.toLowerCase();
        
        // Filter over the Map values
        const results = Array.from(storage.values()).filter((item) => {
          // Iterate over properties to find string matches
          return Object.values(item).some((val) => 
            typeof val === "string" && val.toLowerCase().includes(query)
          );
        });

        return results as T[];
      }),
  });
}

// 4. Instantiate specific routers
export const postRouter = createEntityRouter<{ id: string; title: string; content: string }>("Post");
export const productRouter = createEntityRouter<{ id: string; name: string; price: number }>("Product");
