/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part2.ts
// Description: Theoretical Foundations
// ==========================================

// Conceptual representation of the stream controller logic
const stream = new ReadableStream({
  async start(controller) {
    // 1. Open connection to LLM
    const llmStream = await fetchLLMStream();

    // 2. Create a reader for the LLM's output
    const reader = llmStream.getReader();
    const decoder = new TextDecoder();
    let buffer = '';

    // 3. The Pump Function
    while (true) {
      const { done, value } = await reader.read();
      if (done) {
        // LLM finished, close the stream to client
        controller.close();
        break;
      }

      // 4. Decode bytes to text
      const chunk = decoder.decode(value, { stream: true });
      buffer += chunk;

      // 5. Parse buffer (extract complete JSON objects)
      const { parsedData, remainingBuffer } = parsePartialJSON(buffer);
      
      // 6. Send parsed data to client
      if (parsedData) {
        controller.enqueue(JSON.stringify(parsedData));
      }
      
      // 7. Keep the leftover for the next chunk
      buffer = remainingBuffer;
    }
  }
});
