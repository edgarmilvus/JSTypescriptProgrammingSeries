/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

// server.ts
import express, { Request, Response } from 'express';
import cors from 'cors';

const app = express();
const PORT = 3000;

// Middleware to handle CORS (necessary for local dev)
app.use(cors());
// Middleware to parse JSON bodies
app.use(express.json());

/**
 * @route   GET /api/chat
 * @desc    Streams a simulated AI response as Server-Sent Events (SSE).
 * @returns  Text/Event-Stream
 */
app.get('/api/chat', (req: Request, res: Response) => {
  // 1. Set SSE headers
  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache');
  res.setHeader('Connection', 'keep-alive');
  
  // 2. Simulate a sequence of JSON tokens an LLM might produce
  const jsonTokens = [
    '{\n  "response": "Hello', 
    ' World', 
    '! This', 
    ' is', 
    ' a', 
    ' stream', 
    '",\n  "metadata": {\n    "temperature": 0.7,\n    "tokens": 6\n  }\n}'
  ];

  // 3. Helper function to send data in SSE format
  // SSE format: "data: <content>\n\n"
  const sendToken = (token: string) => {
    res.write(`data: ${token}\n\n`);
  };

  // 4. Stream tokens with a delay to simulate network latency and LLM processing
  let index = 0;
  const intervalId = setInterval(() => {
    if (index < jsonTokens.length) {
      sendToken(jsonTokens[index]);
      index++;
    } else {
      // 5. End the stream when done
      clearInterval(intervalId);
      res.end(); 
    }
  }, 100); // 100ms delay between tokens

  // 6. Handle client disconnect (cleanup)
  req.on('close', () => {
    clearInterval(intervalId);
    res.end();
  });
});

app.listen(PORT, () => {
  console.log(`SSE Server running on http://localhost:${PORT}`);
});
