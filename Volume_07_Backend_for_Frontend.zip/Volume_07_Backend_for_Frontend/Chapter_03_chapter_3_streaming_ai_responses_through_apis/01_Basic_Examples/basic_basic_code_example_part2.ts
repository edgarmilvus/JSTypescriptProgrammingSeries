/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.ts
// Description: Basic Code Example
// ==========================================

// client.ts

/**
 * Interface for the expected final JSON structure.
 */
interface AIResponse {
  response: string;
  metadata: {
    temperature: number;
    tokens: number;
  };
}

/**
 * Simulates a UI update function (e.g., updating a DOM element).
 * @param content - The accumulated text to display
 */
const updateUI = (content: string) => {
  const uiElement = document.getElementById('stream-output');
  if (uiElement) {
    uiElement.textContent = content;
  }
  console.log("UI Updated:", content);
};

/**
 * Connects to the SSE endpoint and handles the stream.
 */
function startStream() {
  // 1. Initialize EventSource
  // Note: In a real app, this URL would come from your backend API route.
  const eventSource = new EventSource('http://localhost:3000/api/chat');

  // 2. Accumulator to hold partial JSON chunks
  let accumulatedData = '';

  // 3. Listen for the 'message' event (default event for SSE)
  eventSource.onmessage = (event: MessageEvent) => {
    // 4. Append the new chunk to the accumulator
    const chunk = event.data;
    accumulatedData += chunk;

    // 5. Visual Feedback: Update UI with raw text immediately
    // This shows the "streaming" effect before full JSON validity.
    updateUI(accumulatedData);

    // 6. Attempt Type Narrowing / Validation
    // We try to parse the accumulated data. If it fails, we wait for more chunks.
    try {
      // JSON.parse throws if the string is incomplete/invalid
      const parsedData: unknown = JSON.parse(accumulatedData);
      
      // Type Guard: Check if the parsed object matches our interface
      if (isAIResponse(parsedData)) {
        console.log("Full JSON Validated:", parsedData);
        // Here you might trigger a specific action upon completion
        // For example, lock the UI or save to database.
      }
    } catch (error) {
      // Expected behavior: JSON.parse fails until the stream finishes.
      // We silently ignore this in the UI to allow the stream to continue.
    }
  };

  // 7. Handle errors
  eventSource.onerror = (error) => {
    console.error("EventSource failed:", error);
    eventSource.close();
  };
}

/**
 * Type Guard function.
 * Checks if the unknown object conforms to the AIResponse interface.
 * This is the "Type Narrowing" concept in action.
 */
function isAIResponse(obj: any): obj is AIResponse {
  return (
    typeof obj === 'object' &&
    obj !== null &&
    typeof obj.response === 'string' &&
    typeof obj.metadata === 'object' &&
    typeof obj.metadata.temperature === 'number' &&
    typeof obj.metadata.tokens === 'number'
  );
}

// Start the process
startStream();
