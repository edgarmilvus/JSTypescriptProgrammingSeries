/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

/**
 * ============================================================================
 * FILE: streaming-ai-demo.tsx
 * DESCRIPTION: A comprehensive demo of streaming AI responses using tRPC and
 *              Edge Functions within a Next.js SaaS context.
 * ============================================================================
 */

import { useState, useEffect, useRef } from 'react';
import { experimental_useOptimistic as useOptimistic } from 'react'; // For UI responsiveness

// ----------------------------------------------------------------------------
// 1. TYPE DEFINITIONS
// ----------------------------------------------------------------------------

/**
 * Defines the structure of the data chunks we expect from the AI.
 * In a real scenario, this might be a complex JSON schema.
 */
interface InsightChunk {
  id: string;
  category: 'summary' | 'metric' | 'action';
  content: string;
  timestamp: number;
}

/**
 * Defines the state managed by our client-side hook.
 */
interface StreamState {
  data: InsightChunk[];
  isLoading: boolean;
  error: string | null;
  isDone: boolean;
}

// ----------------------------------------------------------------------------
// 2. SERVER-SIDE LOGIC (Simulated tRPC/Edge Route)
// ----------------------------------------------------------------------------

/**
 * Mocks an Edge Function route handler.
 * In a real app, this would be defined in `src/server/api/routers/report.ts`
 * using `t.router` and `t.procedure`.
 */
class ReportStreamService {
  /**
   * Simulates an LLM generating a JSON response token-by-token.
   * Uses a ReadableStream to pipe data asynchronously.
   */
  async generateStream(): Promise<ReadableStream<string>> {
    // Simulated JSON data to be streamed
    const mockData: InsightChunk[] = [
      { id: '1', category: 'summary', content: 'User engagement has ', timestamp: Date.now() },
      { id: '1', category: 'summary', content: 'increased by 15% this week.', timestamp: Date.now() },
      { id: '2', category: 'metric', content: '{"active_users": 450, "churn_risk": "low"}', timestamp: Date.now() },
      { id: '3', category: 'action', content: 'Recommend sending a feedback survey.', timestamp: Date.now() },
    ];

    // Create a stream that yields data incrementally
    return new ReadableStream({
      async start(controller) {
        for (const chunk of mockData) {
          // Simulate network latency
          await new Promise((resolve) => setTimeout(resolve, 300));
          
          // Convert object to string and send as a chunk
          // In a real LLM stream, we might receive raw text or partial JSON
          const jsonString = JSON.stringify(chunk);
          controller.enqueue(jsonString + '\n'); // Delimiter for parsing
        }
        controller.close();
      },
    });
  }
}

// ----------------------------------------------------------------------------
// 3. CLIENT-SIDE HOOK (useStreamReport)
// ----------------------------------------------------------------------------

/**
 * Custom React hook to handle streaming logic.
 * Manages connection lifecycle, buffer parsing, and state updates.
 */
function useStreamReport() {
  const [state, setState] = useState<StreamState>({
    data: [],
    isLoading: false,
    error: null,
    isDone: false,
  });

  // Buffer to hold incomplete JSON strings
  const bufferRef = useRef<string>('');

  /**
   * Parses a raw text chunk. Handles cases where the stream sends
   * multiple JSON objects concatenated, or partial objects.
   */
  const parseChunk = (chunkText: string): InsightChunk | null => {
    try {
      // Append new data to buffer
      const combined = bufferRef.current + chunkText;
      
      // Attempt to parse the combined string
      // Note: This is a simplified parser. For production, use a robust
      // streaming JSON parser (e.g., `jsonrepair` or custom state machine).
      const parsed = JSON.parse(combined) as InsightChunk;
      
      // If successful, clear buffer
      bufferRef.current = '';
      return parsed;
    } catch (e) {
      // If parsing fails, it means we have a partial JSON object.
      // We keep it in the buffer and wait for the next chunk.
      bufferRef.current += chunkText;
      return null;
    }
  };

  const startStream = async () => {
    setState((prev) => ({ ...prev, isLoading: true, error: null, isDone: false }));
    bufferRef.current = '';

    try {
      // In a real app, this would be a tRPC call: await api.report.stream.query()
      const service = new ReportStreamService();
      const stream = await service.generateStream();
      const reader = stream.getReader();
      const decoder = new TextDecoder();

      while (true) {
        const { done, value } = await reader.read();
        if (done) {
          setState((prev) => ({ ...prev, isLoading: false, isDone: true }));
          break;
        }

        const textChunk = decoder.decode(value, { stream: true });
        const parsedData = parseChunk(textChunk);

        if (parsedData) {
          // Update state with the new complete object
          setState((prev) => ({
            ...prev,
            data: [...prev.data, parsedData],
          }));
        }
      }
    } catch (err) {
      setState((prev) => ({
        ...prev,
        isLoading: false,
        error: 'Failed to stream report data.',
      }));
    }
  };

  return { ...state, startStream };
}

// ----------------------------------------------------------------------------
// 4. UI COMPONENT (Next.js/React)
// ----------------------------------------------------------------------------

/**
 * The visual component that renders the streaming data.
 * Uses distinct styling for different data categories.
 */
export default function StreamingReportWidget() {
  const { data, isLoading, error, isDone, startStream } = useStreamReport();

  return (
    <div className="max-w-2xl mx-auto p-6 bg-white shadow-lg rounded-lg font-sans">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-xl font-bold text-gray-800">AI Insight Generator</h2>
        <button
          onClick={startStream}
          disabled={isLoading}
          className={`px-4 py-2 rounded-md text-white font-medium transition-colors ${
            isLoading ? 'bg-gray-400 cursor-not-allowed' : 'bg-blue-600 hover:bg-blue-700'
          }`}
        >
          {isLoading ? 'Generating...' : 'Generate Report'}
        </button>
      </div>

      {/* Error State */}
      {error && (
        <div className="p-3 bg-red-50 text-red-600 rounded border border-red-200 mb-4">
          Error: {error}
        </div>
      )}

      {/* Stream Output Container */}
      <div className="space-y-3 min-h-[200px] border border-gray-200 rounded-md p-4 bg-gray-50">
        {data.length === 0 && !isLoading && !error && (
          <p className="text-gray-400 text-center italic">
            Click "Generate Report" to see streaming AI output.
          </p>
        )}

        {data.map((chunk, index) => (
          <div
            key={index}
            className={`p-2 rounded border animate-fade-in ${
              chunk.category === 'summary'
                ? 'bg-blue-50 border-blue-200 text-blue-900'
                : chunk.category === 'metric'
                ? 'bg-purple-50 border-purple-200 text-purple-900 font-mono text-sm'
                : 'bg-green-50 border-green-200 text-green-900'
            }`}
          >
            <span className="text-xs uppercase font-bold opacity-70 block mb-1">
              {chunk.category}
            </span>
            {chunk.content}
          </div>
        ))}

        {/* Visual indicator for active streaming */}
        {isLoading && (
          <div className="flex space-x-2 animate-pulse">
            <div className="w-2 h-2 bg-gray-400 rounded-full"></div>
            <div className="w-2 h-2 bg-gray-400 rounded-full delay-75"></div>
            <div className="w-2 h-2 bg-gray-400 rounded-full delay-150"></div>
          </div>
        )}
        
        {/* Success Indicator */}
        {isDone && data.length > 0 && (
           <div className="text-right text-xs text-green-600 mt-2 font-medium">
             Stream Complete
           </div>
        )}
      </div>
    </div>
  );
}
