/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// app/api/stream-test/route.ts
import { NextRequest } from 'next/server';

export const runtime = 'edge'; // Use Edge Runtime

export async function POST(req: NextRequest) {
  // 1. Parse the incoming JSON body to get the prompt
  const { prompt } = await req.json();

  // 2. Create a ReadableStream to handle the streaming data
  const stream = new ReadableStream({
    async start(controller) {
      // 3. Define the static text to simulate an AI response
      const text = "The quick brown fox jumps over the lazy dog.";
      const words = text.split(' ');

      // 4. Loop through words with a delay
      for (const word of words) {
        // Create the SSE formatted string: "data: {\"token\":\"word\"}\n\n"
        const sseMessage = `data: ${JSON.stringify({ token: word })}\n\n`;
        
        // Encode the string to a Uint8Array
        const chunk = new TextEncoder().encode(sseMessage);
        
        // Enqueue the chunk to the stream
        controller.enqueue(chunk);

        // Wait for 100ms to simulate network/LLM latency
        await new Promise((resolve) => setTimeout(resolve, 100));
      }

      // 5. Close the stream once done
      controller.close();
    },
  });

  // 6. Return the response with SSE headers
  return new Response(stream, {
    headers: {
      'Content-Type': 'text/event-stream',
      'Cache-Control': 'no-cache',
      'Connection': 'keep-alive',
    },
  });
}
