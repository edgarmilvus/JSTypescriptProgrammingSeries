/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

// server/api/routers/stream.ts
import { z } from 'zod';
import { publicProcedure, router } from '../trpc';

// 1. Define the Zod schema for input validation
const inputSchema = z.object({
  query: z.string().min(1),
});

// 2. Define the specific shape of the output token for type narrowing
type TokenOutput = {
  type: 'token';
  content: string;
};

export const streamRouter = router({
  streamResponse: publicProcedure
    .input(inputSchema) // Apply Zod validation
    // 3. Use an async generator function to support streaming
    .subscription(async function* ({ input }) {
      const words = ['Here', 'is', 'a', 'streaming', 'response', 'from', 'tRPC', '.'];

      // 4. Iterate and yield tokens
      for (const word of words) {
        // Simulate delay
        await new Promise((resolve) => setTimeout(resolve, 100));

        // 5. Yield the typed object
        const token: TokenOutput = {
          type: 'token',
          content: word + ' ',
        };
        
        yield token;
      }
    }),
});

// NOTE: In your trpc router configuration (root.ts), you typically configure the transformer.
// While tRPC v11 handles JSON streaming automatically, custom transformers 
// ensure complex objects (like Dates) inside the stream are serialized correctly.
