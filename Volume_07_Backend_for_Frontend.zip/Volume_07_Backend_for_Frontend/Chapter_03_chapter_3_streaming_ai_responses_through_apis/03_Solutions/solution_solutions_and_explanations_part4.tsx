/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.tsx
// Description: Solutions and Explanations
// ==========================================

// components/StreamingMarkdownViewer.tsx
'use client';

import { useState, useEffect } from 'react';
import ReactMarkdown from 'react-markdown';

interface StreamingMarkdownViewerProps {
  stream: ReadableStream<string>; // Assuming a stream of strings
}

export function StreamingMarkdownViewer({ stream }: StreamingMarkdownViewerProps) {
  const [markdownContent, setMarkdownContent] = useState('');
  const [buffer, setBuffer] = useState('');

  useEffect(() => {
    if (!stream) return;

    const reader = stream.getReader();
    const decoder = new TextDecoder();

    async function readStream() {
      try {
        while (true) {
          const { done, value } = await reader.read();
          if (done) break;

          // Decode the Uint8Array chunk to string
          const chunk = decoder.decode(value, { stream: true });
          
          // Append to internal buffer
          const newBuffer = buffer + chunk;
          setBuffer(newBuffer);

          // Try parsing the buffer
          const result = parsePartialJSON(newBuffer);

          if (result.valid) {
            // If valid JSON, extract content and update markdown state
            // Assuming the structure is { content: "markdown string" }
            if (result.data?.content) {
              setMarkdownContent(result.data.content);
            }
            // Reset buffer after successful parse (optional, depends on stream structure)
            // For continuous streams, we might keep consuming the buffer.
          }
        }
      } catch (error) {
        console.error("Stream reading error", error);
      } finally {
        reader.releaseLock();
      }
    }

    readStream();
  }, [stream]);

  return (
    <div className="prose">
      <ReactMarkdown>{markdownContent}</ReactMarkdown>
    </div>
  );
}
