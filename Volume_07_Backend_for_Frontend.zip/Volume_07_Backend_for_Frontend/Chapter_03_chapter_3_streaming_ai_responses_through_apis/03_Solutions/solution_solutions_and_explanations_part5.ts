/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

// types/llm.ts
type LLMSimulationChunk = {
  choices: Array<{
    delta: { content?: string } | null;
  }>;
};

// utils/transformLLMStream.ts

// 1. Type Guard to narrow the type
function isLLMChunk(value: unknown): value is LLMSimulationChunk {
  return (
    typeof value === 'object' &&
    value !== null &&
    'choices' in value &&
    Array.isArray((value as any).choices)
  );
}

export async function* transformLLMStream(
  stream: AsyncGenerator<LLMSimulationChunk>,
  temperature: number
) {
  for await (const chunk of stream) {
    // 2. Type Narrowing: Ensure we have the correct shape
    if (!isLLMChunk(chunk)) continue;

    const delta = chunk.choices[0]?.delta;

    // 3. Filter out empty deltas (keep-alive pings)
    if (!delta || !delta.content) continue;

    let content = delta.content;

    // 4. Temperature Simulation Logic
    if (temperature >= 0.5) {
      // High temperature: Simulate "creativity" by occasionally swapping words
      // (This is a naive simulation for demonstration)
      if (Math.random() > 0.8) {
        content = `[Creative: ${content}]`; 
      }
    }

    yield content;
  }
}

// Mock Generator for testing
export async function* mockLLMStream(): AsyncGenerator<LLMSimulationChunk> {
  const words = ["The", "sky", "is", "blue", ".", null]; // null represents empty delta
  for (const word of words) {
    await new Promise(r => setTimeout(r, 50));
    yield {
      choices: [{ delta: word ? { content: word } : {} }]
    };
  }
}
