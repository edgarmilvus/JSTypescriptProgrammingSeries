/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part6.ts
// Description: Solutions and Explanations
// ==========================================

// types/chat.ts
export type ChatMessage = 
  | { role: 'user'; content: string }
  | { role: 'assistant'; content: string; status: 'streaming' | 'complete' };

// components/ChatInterface.tsx
'use client';

import { useState, useRef } from 'react';
// Assuming tRPC hooks are set up
import { api } from '~/utils/api'; 

export function ChatInterface() {
  const [input, setInput] = useState('');
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  
  // Ref to store the AbortController for the current stream
  const abortControllerRef = useRef<AbortController | null>(null);

  const utils = api.useUtils();

  const handleSend = async () => {
    if (!input.trim()) return;

    // 1. Optimistic User Update
    const userMessage: ChatMessage = { role: 'user', content: input };
    setMessages((prev) => [...prev, userMessage]);
    
    // Clear input immediately
    setInput('');

    // 2. Concurrency Handling: Cancel previous stream if active
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
    }

    // Create new AbortController for this request
    const controller = new AbortController();
    abortControllerRef.current = controller;

    // 3. Prepare Assistant Message State
    const assistantMessage: ChatMessage = { 
      role: 'assistant', 
      content: '', 
      status: 'streaming' 
    };
    setMessages((prev) => [...prev, assistantMessage]);

    try {
      // 4. Trigger tRPC Streaming Procedure
      // Note: This assumes a tRPC subscription or query with streaming enabled.
      // We pass the signal to tRPC (if supported) or handle cancellation manually.
      const stream = utils.stream.streamResponse.subscribe(
        { query: input }, 
        { signal: controller.signal } // Pass abort signal
      );

      // Iterate over the stream
      for await (const token of stream) {
        // 5. Update State with new tokens
        setMessages((prev) => {
          const newMessages = [...prev];
          const lastMsg = newMessages[newMessages.length - 1];
          
          // Ensure we are updating the assistant message
          if (lastMsg.role === 'assistant') {
            lastMsg.content += token.content;
          }
          return newMessages;
        });
      }

      // 6. Mark as complete
      setMessages((prev) => {
        const newMessages = [...prev];
        const lastMsg = newMessages[newMessages.length - 1];
        if (lastMsg.role === 'assistant') {
          lastMsg.status = 'complete';
        }
        return newMessages;
      });

    } catch (error) {
      if (error.name === 'AbortError') {
        console.log('Stream cancelled by user');
      } else {
        console.error('Stream error', error);
      }
    } finally {
      abortControllerRef.current = null;
    }
  };

  return (
    <div className="chat-container">
      <div className="message-list">
        {messages.map((msg, idx) => (
          <div key={idx} className={`message ${msg.role}`}>
            <div className="content">{msg.content}</div>
            {msg.role === 'assistant' && msg.status === 'streaming' && (
              <span className="cursor">▊</span>
            )}
          </div>
        ))}
      </div>
      <div className="input-area">
        <input 
          value={input} 
          onChange={(e) => setInput(e.target.value)} 
          onKeyDown={(e) => e.key === 'Enter' && handleSend()}
        />
        <button onClick={handleSend}>Send</button>
      </div>
    </div>
  );
}
