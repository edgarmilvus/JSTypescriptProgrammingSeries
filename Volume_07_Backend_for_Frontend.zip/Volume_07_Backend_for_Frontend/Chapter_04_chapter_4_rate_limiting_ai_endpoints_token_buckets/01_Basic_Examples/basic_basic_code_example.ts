/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

// File: src/server/ratelimit.ts
import { Redis } from "@upstash/redis";
import { TRPCError } from "@trpc/server";
import { middleware } from "./trpc"; // Assuming a central tRPC instance

// 1. CONFIGURATION
// We define a strict interface for our rate limit configuration.
// This prevents typos and makes the configuration self-documenting.
interface RateLimitConfig {
  /**
   * The maximum number of tokens the user can hold in their bucket.
   * This represents the burst capacity.
   * @example 10
   */
  maxTokens: number;
  /**
   * The number of tokens to add to the bucket per second (refill rate).
   * This is the sustained throughput.
   * @example 0.1 (1 token every 10 seconds)
   */
  refillRate: number;
  /**
   * The cost of a single request.
   * @example 1
   */
  tokenCost: number;
}

// 2. REDIS CLIENT INITIALIZATION
// In a real application, these would be environment variables.
// For serverless, we create the client once per function invocation (or use a singleton).
const redis = new Redis({
  url: process.env.UPSTASH_REDIS_REST_URL!,
  token: process.env.UPSTASH_REDIS_REST_TOKEN!,
});

// 3. THE CORE TOKEN BUCKET LOGIC
/**
 * Checks if a user has enough tokens for a request and deducts them if so.
 * This implements the core token bucket algorithm.
 *
 * @param userId - A unique identifier for the user (e.g., from JWT or API key).
 * @param config - The rate limit configuration for this specific endpoint.
 * @returns A promise that resolves to `true` if the request is allowed, `false` otherwise.
 */
async function checkTokenBucket(
  userId: string,
  config: RateLimitConfig
): Promise<boolean> {
  // We use a Redis key specific to the user and the endpoint to avoid collisions.
  // Format: `ratelimit:<userId>:<endpointName>`
  const key = `ratelimit:ai_endpoint:${userId}`;

  // We need to perform an atomic operation to avoid race conditions.
  // Redis Lua scripts are perfect for this. They run as a single transaction.
  const luaScript = `
    local key = KEYS[1]
    local max_tokens = tonumber(ARGV[1])
    local refill_rate = tonumber(ARGV[2])
    local token_cost = tonumber(ARGV[3])
    local now = tonumber(ARGV[4])

    -- Get current state from Redis
    local bucket = redis.call('HMGET', key, 'tokens', 'last_refill')

    local current_tokens = tonumber(bucket[1])
    local last_refill = tonumber(bucket[2])

    -- Initialize if this is the first request
    if current_tokens == nil then
      current_tokens = max_tokens
      last_refill = now
    end

    -- Calculate time elapsed and refill tokens
    local time_elapsed = now - last_refill
    local tokens_to_add = time_elapsed * refill_rate
    current_tokens = math.min(max_tokens, current_tokens + tokens_to_add)

    -- Update the last refill time
    last_refill = now

    -- Check if user has enough tokens for the request
    if current_tokens >= token_cost then
      -- Deduct the cost and save the new state
      current_tokens = current_tokens - token_cost
      redis.call('HMSET', key, 'tokens', current_tokens, 'last_refill', last_refill)
      -- Set an expiry to automatically clean up old keys
      redis.call('EXPIRE', key, 86400) -- 24 hours
      return 1 -- Allowed
    else
      -- Not enough tokens, update the last_refill time anyway to be accurate for next check
      redis.call('HMSET', key, 'tokens', current_tokens, 'last_refill', last_refill)
      redis.call('EXPIRE', key, 86400)
      return 0 -- Denied
    end
  `;

  const now = Math.floor(Date.now() / 1000); // Current time in seconds

  // Execute the Lua script
  const result = await redis.eval(
    luaScript,
    [key],
    [config.maxTokens, config.refillRate, config.tokenCost, now]
  );

  // The script returns 1 for allowed, 0 for denied
  return result === 1;
}

// 4. INTEGRATION WITH T-RPC MIDDLEWARE
/**
 * tRPC middleware that enforces the token bucket rate limit.
 * This middleware should be applied to any procedure that needs protection.
 */
export const rateLimitMiddleware = middleware(async ({ ctx, next, path }) => {
  // In a real app, `ctx.user` would come from an auth middleware
  const userId = ctx.user?.id || "anonymous";

  // Configuration for the AI endpoint. You could have different configs per route.
  const config: RateLimitConfig = {
    maxTokens: 10, // User can burst 10 requests
    refillRate: 0.1, // Refill 1 token every 10 seconds (6 per minute)
    tokenCost: 1, // Each AI query costs 1 token
  };

  const isAllowed = await checkTokenBucket(userId, config);

  if (!isAllowed) {
    // If denied, throw a specific TRPCError. The client can catch this.
    throw new TRPCError({
      code: "TOO_MANY_REQUESTS",
      message: "Rate limit exceeded. Please wait and try again.",
    });
  }

  // If allowed, proceed to the actual procedure logic.
  return next();
});
