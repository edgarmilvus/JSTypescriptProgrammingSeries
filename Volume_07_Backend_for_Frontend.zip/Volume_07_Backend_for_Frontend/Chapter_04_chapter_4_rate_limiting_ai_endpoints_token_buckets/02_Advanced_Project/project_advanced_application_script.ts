/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// src/server/api/routers/aiChat.ts
import { z } from "zod";
import { Ratelimit } from "@upstash/ratelimit";
import { Redis } from "@upstash/redis";
import { TRPCError } from "@trpc/server";
import { publicProcedure, createTRPCRouter } from "~/server/api/trpc";

/**
 * CONFIGURATION
 * In a real app, these would be environment variables.
 * 
 * TOKEN_BUCKET_ALGORITHM:
 * - Refill Rate: 10 tokens per second (allows burst of 10 tokens instantly).
 * - Capacity: 10 tokens (Max burst size).
 * - Cost: 5 tokens per AI summary request (expensive operation).
 */
const REFILL_RATE = 10; // tokens per second
const BUCKET_CAPACITY = 10; // max tokens
const COST_PER_REQUEST = 5; // tokens deducted per request

// Initialize Redis Client (Upstash)
// Ensure UPSTASH_REDIS_REST_URL and UPSTASH_REDIS_REST_TOKEN are in .env
const redis = new Redis({
  url: process.env.UPSTASH_REDIS_REST_URL!,
  token: process.env.UPSTASH_REDIS_REST_TOKEN!,
});

/**
 * Custom Token Bucket Implementation
 * 
 * Why not just use the generic Ratelimit library?
 * While Upstash's `Ratelimit` class is excellent, a custom implementation 
 * allows us to handle "Costly AI Operations" where different prompts 
 * consume different amounts of tokens (e.g., 5 for summary, 20 for image gen).
 * 
 * Data Structure in Redis:
 * Key: `ratelimit:user:{userId}`
 * Value: Hash { tokens: number, lastRefill: number (timestamp in ms) }
 */
async function checkTokenBucket(userId: string, cost: number = COST_PER_REQUEST) {
  const key = `ratelimit:user:${userId}`;
  const now = Date.now();

  // Use a Lua script or transaction for atomicity to prevent race conditions
  // Here we use a simple transaction pipeline for clarity.
  const pipeline = redis.pipeline();
  
  // 1. Get current state
  pipeline.hgetall(key);
  
  // Execute pipeline to get current state
  const result = await pipeline.exec();
  const currentState = result[0] as { tokens: string; lastRefill: string } | null;

  let tokens = BUCKET_CAPACITY;
  let lastRefill = now;

  if (currentState && currentState.tokens && currentState.lastRefill) {
    tokens = parseInt(currentState.tokens, 10);
    lastRefill = parseInt(currentState.lastRefill, 10);
  }

  // 2. Calculate Refill
  const secondsSinceLastRefill = (now - lastRefill) / 1000;
  const tokensToAdd = secondsSinceLastRefill * REFILL_RATE;
  
  // Refill the bucket (capped at capacity)
  tokens = Math.min(BUCKET_CAPACITY, tokens + tokensToAdd);

  // 3. Check if user has enough tokens
  if (tokens < cost) {
    // Calculate retry-after header (optional but good practice)
    const deficit = cost - tokens;
    const secondsToWait = deficit / REFILL_RATE;
    
    throw new TRPCError({
      code: "TOO_MANY_REQUESTS",
      message: `Rate limit exceeded. Retry after ${secondsToWait.toFixed(1)} seconds.`,
      // You can attach meta data for headers if your framework supports it
      meta: { retryAfter: secondsToWait },
    });
  }

  // 4. Deduct tokens and update state
  const newTokenCount = tokens - cost;
  
  // Atomic Update
  await redis.hset(key, {
    tokens: newTokenCount.toString(),
    lastRefill: now.toString(),
  });

  // Optional: Set TTL on key to auto-clean old data (e.g., 24 hours)
  await redis.expire(key, 86400);

  return { success: true, remaining: newTokenCount };
}

/**
 * TRPC Router Definition
 * 
 * This router demonstrates how to integrate the rate limiter 
 * into the middleware pipeline of a tRPC procedure.
 */
export const aiRouter = createTRPCRouter({
  /**
   * Summarize Text Procedure
   * 
   * 1. Validates input.
   * 2. Checks Token Bucket (Rate Limit).
   * 3. If allowed, calls the "expensive" LLM.
   * 4. Returns streamed or synchronous result.
   */
  summarize: publicProcedure
    .input(
      z.object({
        text: z.string().max(2000, "Text too long for this demo endpoint."),
        userId: z.string(), // In production, extract this from Auth Context
      })
    )
    .mutation(async ({ input }) => {
      const { text, userId } = input;

      // --- RATE LIMITING LAYER ---
      // This block executes BEFORE the expensive LLM call.
      // It protects our infrastructure and wallet.
      try {
        await checkTokenBucket(userId, COST_PER_REQUEST);
      } catch (error) {
        // Re-throw the TRPCError to be handled by the global error formatter
        throw error;
      }

      // --- EXPENSIVE AI INFERENCE LAYER ---
      // Mocking an LLM call (e.g., OpenAI GPT-4)
      // In a real scenario, this is where inference latency occurs.
      console.log(`[AI] Processing request for user: ${userId}. Cost: ${COST_PER_REQUEST} tokens.`);
      
      // Simulate network latency and processing
      await new Promise((resolve) => setTimeout(resolve, 800)); 

      const summary = `Summary of text: "${text.substring(0, 50)}...". (Mocked Response)`;

      return {
        success: true,
        summary,
        tokensUsed: COST_PER_REQUEST,
        message: "Request processed successfully within rate limits.",
      };
    }),

  /**
   * Generate Image Procedure
   * 
   * Demonstrates variable cost logic. Image generation costs MORE tokens.
   */
  generateImage: publicProcedure
    .input(
      z.object({
        prompt: z.string(),
        userId: z.string(),
      })
    )
    .mutation(async ({ input }) => {
      const { prompt, userId } = input;
      const IMAGE_COST = 20; // Higher cost for image generation

      try {
        // Check with higher cost
        await checkTokenBucket(userId, IMAGE_COST);
      } catch (error) {
        throw error;
      }

      // Mock Image Generation
      await new Promise((resolve) => setTimeout(resolve, 1500));

      return {
        success: true,
        imageUrl: "https://example.com/generated-image.png",
        tokensUsed: IMAGE_COST,
      };
    }),
});
