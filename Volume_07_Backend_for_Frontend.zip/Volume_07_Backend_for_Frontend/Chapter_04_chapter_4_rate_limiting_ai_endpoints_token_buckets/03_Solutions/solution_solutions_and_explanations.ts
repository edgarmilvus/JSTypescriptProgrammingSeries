/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// rateLimitMiddleware.ts
import { middleware } from '@trpc/server';
import { Redis } from '@upstash/redis';
import { TRPCError } from '@trpc/server';

// 1. Define the Rate Limit Configuration
export interface RateLimitConfig {
  capacity: number;       // Max tokens in bucket
  refillRate: number;     // Tokens added per second
  costPerRequest: number; // Tokens deducted per call
}

// Initialize Upstash Redis (ensure env vars are set)
const redis = new Redis({
  url: process.env.UPSTASH_REDIS_REST_URL!,
  token: process.env.UPSTASH_REDIS_REST_TOKEN!,
});

// 2. Create the tRPC Middleware
export const createRateLimitMiddleware = (config: RateLimitConfig) => {
  return middleware(async ({ ctx, next }) => {
    // Ensure user is authenticated
    if (!ctx.user?.id) {
      throw new TRPCError({ code: 'UNAUTHORIZED' });
    }

    const key = `ratelimit:${ctx.user.id}`;
    const now = Date.now();

    // 3. Implement the Logic using Redis Lua Script for atomicity
    // We use a Lua script to fetch, calculate refill, and update in one atomic operation.
    const luaScript = `
      local key = KEYS[1]
      local now = tonumber(ARGV[1])
      local capacity = tonumber(ARGV[2])
      local refillRate = tonumber(ARGV[3])
      local cost = tonumber(ARGV[4])
      
      local data = redis.call('HMGET', key, 'tokens', 'lastRefill')
      local tokens = tonumber(data[1]) or capacity
      local lastRefill = tonumber(data[2]) or now
      
      -- Calculate refill amount based on time elapsed
      local elapsed = (now - lastRefill) / 1000 -- convert to seconds
      local refillAmount = elapsed * refillRate
      
      -- Update tokens (capped at capacity)
      tokens = math.min(capacity, tokens + refillAmount)
      
      -- Check if sufficient
      if tokens >= cost then
          tokens = tokens - cost
          redis.call('HMSET', key, 'tokens', tokens, 'lastRefill', now)
          return {1, tokens} -- Allowed, remaining tokens
      else
          -- Not enough tokens, do not deduct yet
          return {0, tokens} -- Rejected, current tokens
      end
    `;

    try {
      // Execute script
      const result = await redis.eval(
        luaScript,
        [key],
        [now, config.capacity, config.refillRate, config.costPerRequest]
      ) as [number, number];

      const allowed = result[0] === 1;
      const currentTokens = result[1];

      if (allowed) {
        // Proceed to resolver
        return next();
      } else {
        // Calculate time until refill
        // Formula: (Cost - CurrentTokens) / RefillRate
        const secondsUntilRefill = (config.costPerRequest - currentTokens) / config.refillRate;
        
        throw new TRPCError({
          code: 'TOO_MANY_REQUESTS',
          message: `Rate limit exceeded. Try again in ${secondsUntilRefill.toFixed(1)} seconds.`,
          // Optional: Add meta data for client handling
          meta: { secondsUntilRefill },
        });
      }
    } catch (error) {
      // Handle Redis errors gracefully
      console.error('Redis rate limit error:', error);
      // Fail open or closed depending on policy (here we fail open to allow traffic)
      return next();
    }
  });
};

// 4. Apply Middleware to Procedure (Example usage in router)
// import { router, procedure } from '../trpc';
// import { createRateLimitMiddleware } from './rateLimitMiddleware';

// const rateLimit = createRateLimitMiddleware({
//   capacity: 100,
//   refillRate: 10,
//   costPerRequest: 5,
// });

// export const appRouter = router({
//   summarizeText: procedure
//     .use(rateLimit)
//     .input((val) => ({ text: z.string().parse(val) })) // Example input validation
//     .mutation(async ({ input }) => {
//       // Call LLM API here
//       return `Summary of: ${input.text.substring(0, 10)}...`;
//     }),
// });
