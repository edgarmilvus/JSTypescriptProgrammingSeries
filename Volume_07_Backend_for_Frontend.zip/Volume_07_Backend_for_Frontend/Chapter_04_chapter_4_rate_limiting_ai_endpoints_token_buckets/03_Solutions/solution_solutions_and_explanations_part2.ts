/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

digraph TokenBucketMachine {
    rankdir=TB;
    node [shape=box, style="rounded,filled", fillcolor="#e3f2fd", color="#1565c0"];
    edge [fontname="Arial", fontsize=10];

    // Define States
    Idle [label="Idle", fillcolor="#e8f5e9", shape="ellipse"];
    Refilling [label="Refilling\n(Calculate tokens based on time)", fillcolor="#fff3e0"];
    Checking [label="Checking\n(Compare tokens vs cost)", fillcolor="#fff9c4"];
    Allowed [label="Allowed\n(Deduct tokens & Process)", fillcolor="#c8e6c9", shape="doublecircle"];
    Rejected [label="Rejected\n(Return 429 Too Many Requests)", fillcolor="#ffcdd2", shape="doublecircle"];

    // Transitions
    Idle -> Refilling [label="New Request Arrives"];
    
    Refilling -> Checking [label="Update Token Count"];
    
    Checking -> Allowed [label="Tokens >= Cost", fontcolor="green", color="green"];
    Checking -> Rejected [label="Tokens < Cost", fontcolor="red", color="red"];
    
    Allowed -> Idle [label="Request Complete"];
    Rejected -> Idle [label="Request Handled"];

    // Concurrency / Burst Handling (Subgraph for visual grouping)
    subgraph cluster_burst {
        label = "Burst Handling Scenario";
        style = "dashed";
        color = "gray";
        
        // Visualizing multiple requests hitting the state machine
        BurstReq1 [label="Request A", shape="note", fillcolor="white"];
        BurstReq2 [label="Request B", shape="note", fillcolor="white"];
        BurstReq3 [label="Request C", shape="note", fillcolor="white"];

        BurstReq1 -> Checking [style="dashed", arrowhead="vee"];
        BurstReq2 -> Checking [style="dashed", arrowhead="vee"];
        BurstReq3 -> Checking [style="dashed", arrowhead="vee"];
        
        // Feedback loop showing sequential processing of burst
        Allowed -> BurstReq1 [style="dashed", arrowhead="vee", constraint=false];
        Rejected -> BurstReq3 [style="dashed", arrowhead="vee", constraint=false];
    }
}
