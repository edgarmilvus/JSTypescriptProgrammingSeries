/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

// RateLimitStatus.tsx
import React from 'react';
import { trpc } from '../utils/trpc';

export function RateLimitStatus() {
  // 3. Data Fetching: Using tRPC query with automatic error handling retry
  const { data, isLoading, isError, error } = trpc.rateLimit.getStatus.useQuery();

  // 4. Error Handling
  if (isError) {
    return (
      <div className="rate-limit-card error">
        <p>Status Unavailable: {error.message}</p>
      </div>
    );
  }

  if (isLoading) {
    return (
      <div className="rate-limit-card loading">
        <p>Loading status...</p>
      </div>
    );
  }

  if (!data) {
    return null;
  }

  // Destructure data with defaults for safety
  const { currentTokens, maxTokens, refillsIn } = data;
  const percentage = (currentTokens / maxTokens) * 100;

  // 3. Visual Elements Logic
  let statusText = "Ready";
  let statusColor = "#4caf50"; // Green

  if (currentTokens === 0) {
    statusText = "Empty - Refilling...";
    statusColor = "#f44336"; // Red
  } else if (percentage < 50) {
    statusText = "Limited";
    statusColor = "#ff9800"; // Orange
  }

  return (
    <div className="rate-limit-card" style={{ border: `1px solid ${statusColor}`, padding: '1rem', borderRadius: '8px' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '0.5rem' }}>
        <strong>Rate Limit Status</strong>
        <span style={{ color: statusColor }}>{statusText}</span>
      </div>

      {/* Progress Bar */}
      <div style={{ background: '#eee', height: '10px', borderRadius: '5px', overflow: 'hidden' }}>
        <div 
          style={{ 
            width: `${percentage}%`, 
            background: statusColor, 
            height: '100%',
            transition: 'width 0.3s ease' 
          }} 
        />
      </div>

      <div style={{ marginTop: '0.5rem', fontSize: '0.85rem', color: '#666' }}>
        <span>{currentTokens} / {maxTokens} tokens</span>
        
        {/* Countdown Timer */}
        {refillsIn > 0 && (
          <span style={{ marginLeft: '10px' }}>
            Refills in {Math.ceil(refillsIn)}s
          </span>
        )}
      </div>
    </div>
  );
}
