/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

// simulate-burst.ts
import { createTRPCClient, httpBatchLink } from '@trpc/client';
import type { AppRouter } from '../server/router';

async function simulateBurst() {
  console.log('--- Starting Burst Simulation ---');
  
  // Configuration matching the exercise requirement
  // Capacity: 10 tokens, Refill: 2/sec, Cost: 1
  // Theoretically, the first 10 requests should succeed immediately.
  
  const client = createTRPCClient<AppRouter>({
    links: [
      httpBatchLink({
        url: 'http://localhost:3000/trpc',
        // headers: { authorization: 'Bearer ...' } // Add auth if required
      }),
    ],
  });

  const totalRequests = 15;
  const requests = Array.from({ length: totalRequests }, (_, i) => {
    // We create a promise that resolves with the result of the request
    return client.summarizeText.mutate({ text: `Burst request number ${i}` })
      .then(() => ({ id: i, status: 'Success' } as const))
      .catch((err) => ({ id: i, status: 'Rate Limited', message: err.message } as const));
  });

  // Execute all requests "concurrently"
  const results = await Promise.all(requests);

  // Analyze results
  const successes = results.filter(r => r.status === 'Success');
  const failures = results.filter(r => r.status === 'Rate Limited');

  console.log(`\n--- Simulation Results ---`);
  console.log(`Total Requests: ${totalRequests}`);
  console.log(`Successful: ${successes.length}`);
  console.log(`Rate Limited: ${failures.length}`);

  // 5. Verification
  // With Capacity=10 and Cost=1, we expect exactly 10 successes (assuming no time elapsed between requests).
  // Note: In a real network, slight timing variations might occur, but the logic should hold.
  if (successes.length === 10 && failures.length === 5) {
    console.log('✅ Verification Passed: Bucket capacity respected.');
  } else {
    console.log('❌ Verification Failed: Unexpected distribution.');
    // Debugging info
    results.forEach(r => console.log(`Request ${r.id}: ${r.status}`));
  }

  // Analysis Output
  console.log(`\n--- Analysis ---`);
  console.log('1. Requests 0-9 succeeded immediately because the bucket started with 10 tokens.');
  console.log('2. Requests 10-14 were rejected because the bucket was drained to 0.');
  console.log('3. If we introduced a delay (e.g., 1 second) between batches, we would see the bucket refill at 2 tokens/sec.');
}

simulateBurst().catch(console.error);
