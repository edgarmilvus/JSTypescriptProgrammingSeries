/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

// dynamicRateLimitMiddleware.ts
import { middleware } from '@trpc/server';
import { Redis } from '@upstash/redis';
import { TRPCError } from '@trpc/server';

// 1. Dynamic Cost Function
export const calculateDynamicCost = (input: string): number => {
  if (!input || input.length === 0) return 0;
  // Cost: 1 token per 100 characters
  return Math.ceil(input.length / 100);
};

// 2. Modified Middleware Signature
// We use a generic middleware that infers the input type from the procedure
export const dynamicRateLimitMiddleware = middleware(async ({ ctx, next, input }) => {
  if (!ctx.user?.id) {
    throw new TRPCError({ code: 'UNAUTHORIZED' });
  }

  // 3. tRPC Context Integration: Access input directly
  // Note: Input is available here because middleware runs after input parsing
  const textInput = (input as { text?: string }).text || '';
  
  // Calculate dynamic cost
  const cost = calculateDynamicCost(textInput);

  // Edge Case 4: Handle cost of 0
  if (cost === 0) {
    // Allow request but don't deduct tokens
    return next();
  }

  const key = `ratelimit:${ctx.user.id}`;
  const now = Date.now();
  
  // Configuration for this specific endpoint (could be passed as arg)
  const config = {
    capacity: 100,
    refillRate: 10,
  };

  // Lua Script (Same logic, but cost is passed dynamically)
  const luaScript = `
    local key = KEYS[1]
    local now = tonumber(ARGV[1])
    local capacity = tonumber(ARGV[2])
    local refillRate = tonumber(ARGV[3])
    local cost = tonumber(ARGV[4])
    
    local data = redis.call('HMGET', key, 'tokens', 'lastRefill')
    local tokens = tonumber(data[1]) or capacity
    local lastRefill = tonumber(data[2]) or now
    
    local elapsed = (now - lastRefill) / 1000
    local refillAmount = elapsed * refillRate
    
    tokens = math.min(capacity, tokens + refillAmount)
    
    if tokens >= cost then
        tokens = tokens - cost
        redis.call('HMSET', key, 'tokens', tokens, 'lastRefill', now)
        return {1, tokens}
    else
        return {0, tokens}
    end
  `;

  const result = await redis.eval(
    luaScript,
    [key],
    [now, config.capacity, config.refillRate, cost]
  ) as [number, number];

  const allowed = result[0] === 1;
  const currentTokens = result[1];

  if (allowed) {
    return next();
  } else {
    const secondsUntilRefill = (cost - currentTokens) / config.refillRate;
    throw new TRPCError({
      code: 'TOO_MANY_REQUESTS',
      message: `Dynamic cost ${cost} exceeded. Refills in ${secondsUntilRefill.toFixed(1)}s.`,
    });
  }
});
