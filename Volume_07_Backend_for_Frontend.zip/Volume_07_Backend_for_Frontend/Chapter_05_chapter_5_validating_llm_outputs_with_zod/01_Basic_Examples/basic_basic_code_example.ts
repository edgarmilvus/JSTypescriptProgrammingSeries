/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

import { z } from "zod";

/**
 * SECTION 1: SCHEMA DEFINITION
 * We define the shape of the data we expect the LLM to produce.
 * This acts as both a runtime validator and a TypeScript type definition.
 */

// Define the schema for a User Profile
const UserProfileSchema = z.object({
  id: z.string().uuid(), // Must be a valid UUID string
  username: z.string().min(3).max(20), // Must be a string between 3 and 20 chars
  email: z.string().email(), // Must be a valid email format
  preferences: z.array(z.string()), // Must be an array of strings
  metadata: z.object({
    lastLogin: z.string().datetime(), // ISO 8601 date string
    isActive: z.boolean(), // Must be a boolean
  }),
});

// Infer the TypeScript type from the schema for internal use
type UserProfile = z.infer<typeof UserProfileSchema>;

/**
 * SECTION 2: MOCK LLM RESPONSE
 * In a real scenario, this would be an API call to OpenAI, Anthropic, etc.
 * We simulate a "dirty" response that contains type mismatches and extra fields.
 */
const mockRawLLMResponse: unknown = {
  id: "123e4567-e89b-12d3-a456-426614174000", // Valid UUID
  username: "alex_dev", // Valid
  email: "alex@example.com", // Valid
  preferences: ["dark_mode", "notifications", 123], // ERROR: Array contains a number
  metadata: {
    lastLogin: "2023-10-27T10:00:00Z", // Valid ISO string
    isActive: "true", // ERROR: String "true" instead of boolean true
  },
  // Extra field not in schema (Zod strips this by default in strict mode or .parse)
  internal_token: "secret_llm_token",
};

/**
 * SECTION 3: VALIDATION LOGIC
 * This function acts as the "Type Guard" for the LLM output.
 */
function validateAndTransformLLMOutput(
  rawOutput: unknown
): UserProfile | null {
  try {
    // .parse() throws an error if validation fails
    // This enforces strict typing at runtime
    const validatedData = UserProfileSchema.parse(rawOutput);
    
    console.log("✅ Validation successful. Data is safe to use.");
    return validatedData;
  } catch (error) {
    if (error instanceof z.ZodError) {
      // Log specific validation errors for debugging
      console.error("❌ Validation failed:", error.errors);
    } else {
      console.error("❌ An unexpected error occurred:", error);
    }
    return null;
  }
}

/**
 * SECTION 4: EXECUTION
 * Simulating the flow in a backend handler (e.g., tRPC procedure or Edge Function).
 */
(async () => {
  console.log("--- Starting LLM Output Validation ---");
  
  // 1. Receive raw data from LLM
  const result = validateAndTransformLLMOutput(mockRawLLMResponse);

  // 2. Use the validated data (TypeScript now knows 'result' is UserProfile | null)
  if (result) {
    // TypeScript allows access to specific properties safely
    console.log(`Welcome back, ${result.username}`);
    console.log(`Preferences: ${result.preferences.join(", ")}`);
  } else {
    console.log("Please try generating the profile again.");
  }
})();
