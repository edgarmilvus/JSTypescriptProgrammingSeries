/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.tsx
// Description: Advanced Application Script
// ==========================================

/**
 * File: app/dashboard/retention-analysis/page.tsx
 * 
 * Context: This is a Next.js Server Component. It runs exclusively on the server.
 * It simulates fetching data from an LLM (like OpenAI) and validates the response
 * before passing it to the client for rendering.
 */

import React from 'react';
import { z } from 'zod';

// ==========================================
// 1. ZOD SCHEMA DEFINITION
// ==========================================
// We define the shape of the data we expect the LLM to return.
// This acts as a contract. If the LLM deviates, Zod throws a safe error.

const RetentionMetricSchema = z.object({
  metricName: z.string().min(1), // Must be a non-empty string
  value: z.number().positive(),  // Must be a positive number
  changePercentage: z.number(),  // Can be negative (e.g., -5.2%)
  insight: z.string(),           // Textual explanation
  confidence: z.enum(['high', 'medium', 'low']), // Strict enum validation
});

const RetentionAnalysisSchema = z.object({
  period: z.string(),
  summary: z.string(),
  metrics: z.array(RetentionMetricSchema), // Array of validated objects
  riskFactors: z.array(z.string()).optional(), // Optional array
});

// Infer the TypeScript type from the Zod schema for internal usage
type RetentionAnalysis = z.infer<typeof RetentionAnalysisSchema>;

// ==========================================
// 2. MOCK LLM SERVICE
// ==========================================
/**
 * Simulates an LLM API call (e.g., OpenAI GPT-4).
 * In a real app, this would be an async fetch to '/api/chat' or direct provider SDK.
 * 
 * Note: We intentionally introduce a slight inconsistency in the mock data 
 * (e.g., 'value' as a string) to demonstrate Zod's parsing power.
 */
async function fetchLLMAnalysis(): Promise<string> {
  // Simulate network delay
  await new Promise((resolve) => setTimeout(resolve, 500));

  // This is the raw, unstructured string returned by the LLM
  // Notice 'value' is a string "45.2" instead of a number 45.2
  return JSON.stringify({
    period: "Q3 2024",
    summary: "User retention has stabilized after the v2 launch.",
    metrics: [
      {
        metricName: "Day 7 Retention",
        value: "45.2", // LLMs often return numbers as strings
        changePercentage: 2.5,
        insight: "New onboarding flow is effective.",
        confidence: "high",
      },
      {
        metricName: "Churn Rate",
        value: "12.8",
        changePercentage: -1.2,
        insight: "Slight decrease observed.",
        confidence: "medium",
      },
    ],
    riskFactors: ["Seasonal holiday dip expected"],
  });
}

// ==========================================
// 3. VALIDATION LAYER
// ==========================================
/**
 * Parses the raw string from the LLM against the Zod schema.
 * 
 * @param rawJson - The stringified JSON returned by the LLM
 * @returns A strictly typed object
 * @throws Error if validation fails (handled in the main component)
 */
function validateAndTransform(rawJson: string): RetentionAnalysis {
  // Parse raw JSON string into a JavaScript object
  const parsedRaw = JSON.parse(rawJson);

  // Validate against schema
  // .parse() throws an error if validation fails.
  // .safeParse() is often used in production to handle errors gracefully.
  const result = RetentionAnalysisSchema.parse(parsedRaw);

  // Transformation: Coerce string numbers to actual numbers if necessary
  // While Zod validates types, we can also ensure data consistency here.
  return {
    ...result,
    metrics: result.metrics.map((m) => ({
      ...m,
      value: typeof m.value === 'string' ? parseFloat(m.value) : m.value,
    })),
  };
}

// ==========================================
// 4. SERVER COMPONENT (UI)
// ==========================================

export default async function RetentionAnalysisPage() {
  // Step 1: Fetch raw data (Server-Side Data Fetching)
  const rawLlmResponse = await fetchLLMAnalysis();

  let analysisData: RetentionAnalysis | null = null;
  let error: string | null = null;

  // Step 2: Validate and Transform
  try {
    analysisData = validateAndTransform(rawLlmResponse);
  } catch (e) {
    // In a real app, log to Sentry or Datadog
    if (e instanceof z.ZodError) {
      error = `Validation Failed: ${JSON.stringify(e.errors)}`;
    } else {
      error = "Unknown error parsing LLM response";
    }
  }

  // Step 3: Render Logic
  if (error) {
    return (
      <div className="p-6 bg-red-50 border border-red-200 rounded-lg">
        <h2 className="text-red-800 font-bold text-xl">System Error</h2>
        <p className="text-red-600 mt-2">{error}</p>
        <p className="text-sm text-red-500 mt-4">
          The AI model returned data that did not match our strict safety schema.
        </p>
      </div>
    );
  }

  if (!analysisData) {
    return <div>Loading...</div>;
  }

  // Since the data is validated, TypeScript knows exactly what properties exist
  return (
    <div className="max-w-4xl mx-auto p-8 bg-white shadow-sm rounded-lg border border-gray-100">
      <header className="mb-8 border-b pb-4">
        <h1 className="text-3xl font-bold text-gray-900">Retention Analysis</h1>
        <p className="text-gray-500 mt-1">Period: {analysisData.period}</p>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Summary Card */}
        <div className="col-span-1 md:col-span-2 bg-slate-50 p-4 rounded-md">
          <h3 className="font-semibold text-slate-800">AI Summary</h3>
          <p className="text-slate-600 mt-2">{analysisData.summary}</p>
        </div>

        {/* Metrics Grid */}
        {analysisData.metrics.map((metric, index) => (
          <div key={index} className="border rounded-lg p-4 hover:shadow-md transition">
            <div className="flex justify-between items-start">
              <h4 className="font-medium text-gray-800">{metric.metricName}</h4>
              <span 
                className={`px-2 py-1 rounded text-xs font-bold ${
                  metric.confidence === 'high' 
                    ? 'bg-green-100 text-green-800' 
                    : 'bg-yellow-100 text-yellow-800'
                }`}
              >
                {metric.confidence.toUpperCase()}
              </span>
            </div>
            
            <div className="mt-3 flex items-baseline gap-2">
              <span className="text-2xl font-bold text-gray-900">
                {metric.value.toFixed(1)}%
              </span>
              <span className={`text-sm font-medium ${
                metric.changePercentage >= 0 ? 'text-green-600' : 'text-red-600'
              }`}>
                {metric.changePercentage >= 0 ? '+' : ''}{metric.changePercentage}%
              </span>
            </div>

            <p className="text-sm text-gray-500 mt-2">{metric.insight}</p>
          </div>
        ))}
      </div>

      {/* Risk Factors Section */}
      {analysisData.riskFactors && (
        <div className="mt-8 pt-6 border-t">
          <h3 className="font-semibold text-gray-900 mb-3">Risk Factors</h3>
          <ul className="list-disc list-inside text-gray-600 space-y-1">
            {analysisData.riskFactors.map((risk, idx) => (
              <li key={idx}>{risk}</li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
}
