/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

import { z } from 'zod';

// 1. Define the Zod schema with specific validation rules
const DocumentSummarySchema = z.object({
  summary: z.string().min(10, "Summary must be at least 10 characters long."),
  keyTopics: z.array(z.string().min(1, "Topic cannot be empty.")),
  sentimentScore: z.number().min(-1.0).max(1.0),
});

// 2. Infer the TypeScript type from the schema
type DocumentSummary = z.infer<typeof DocumentSummarySchema>;

// 3. Create the parsing function with error handling
function parseLLMSummary(rawResponse: unknown): { data?: DocumentSummary; error?: string } {
  try {
    // Attempt to parse the raw response
    const parsed = DocumentSummarySchema.parse(rawResponse);
    return { data: parsed };
  } catch (error) {
    // Handle validation errors
    if (error instanceof z.ZodError) {
      // Create a detailed error message listing each validation issue
      const errorMessages = error.errors.map((err) => `${err.path.join('.')}: ${err.message}`).join('; ');
      return { error: `Validation failed: ${errorMessages}` };
    }
    // Handle unexpected errors
    return { error: 'An unexpected error occurred during parsing.' };
  }
}

// Example usage:
const validResponse = {
  summary: "This document discusses the impact of AI on modern software development.",
  keyTopics: ["AI", "Software Development", "Automation"],
  sentimentScore: 0.85
};

const invalidResponse = {
  summary: "Short",
  keyTopics: ["Valid", ""], // Empty string in array fails validation
  sentimentScore: 1.5 // Out of bounds
};

console.log(parseLLMSummary(validResponse)); // { data: { ... } }
console.log(parseLLMSummary(invalidResponse)); // { error: "Validation failed: summary: Summary must be at least 10 characters long.; keyTopics.1: Topic cannot be empty.; sentimentScore: Number must be less than or equal to 1" }
