/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

import { z } from "zod";
import { publicProcedure, router } from "./trpc"; // Assume these are defined
import { TRPCError } from "@trpc/server";

// 1. Define the Zod schema for the note structure
const NoteSchema = z.object({
  title: z.string().min(1),
  content: z.string().min(1),
  tags: z.array(z.string()),
});

// 2. Mock the LLM call (simulating network delay and raw output)
async function mockLLMCall(prompt: string): Promise<unknown> {
  // Simulate network latency
  await new Promise(resolve => setTimeout(resolve, 500));

  // Simulate a response. For testing, we intentionally return an invalid structure
  // if the prompt contains the word "error".
  if (prompt.toLowerCase().includes("error")) {
    return {
      title: "Generated Title",
      // Missing 'content' field to trigger validation error
      tags: ["tag1", "tag2"]
    };
  }

  return {
    title: `Summary of: ${prompt}`,
    content: `This is the generated content for the prompt: ${prompt}.`,
    tags: ["generated", "llm"],
  };
}

// 3. Define the tRPC router
export const appRouter = router({
  generateNote: publicProcedure
    .input(z.object({ prompt: z.string() })) // Input validation
    .mutation(async ({ input }) => {
      try {
        // 1. Call the mock LLM
        const rawResponse = await mockLLMCall(input.prompt);

        // 2. Validate the raw response using the Zod schema
        // .parse() throws a ZodError if validation fails
        const validatedNote = NoteSchema.parse(rawResponse);

        // 3. Return the typed, validated data
        return validatedNote;
      } catch (error) {
        // 4. Handle validation errors specifically
        if (error instanceof z.ZodError) {
          // Format Zod errors for the client
          const formattedErrors = error.flatten().fieldErrors;
          
          throw new TRPCError({
            code: "BAD_REQUEST",
            message: "Invalid LLM response structure.",
            cause: formattedErrors, // Attach detailed errors to the cause
          });
        }
        
        // Handle unexpected errors
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: "An unknown error occurred.",
        });
      }
    }),
});

export type AppRouter = typeof appRouter;
