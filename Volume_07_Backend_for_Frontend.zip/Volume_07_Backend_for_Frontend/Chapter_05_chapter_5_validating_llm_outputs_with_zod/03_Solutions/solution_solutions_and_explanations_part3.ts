/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

import { z } from "zod";

// 1. Define a custom Error class for LLM validation failures
export class LLMValidationError extends Error {
  public issues: z.ZodIssue[];

  constructor(message: string, issues: z.ZodIssue[]) {
    super(message);
    this.name = "LLMValidationError";
    this.issues = issues;
  }
}

// 2. Create the generic validation function
// T extends z.ZodTypeAny allows us to use any Zod schema
export function validateLLMResponse<T extends z.ZodTypeAny>(
  rawResponse: unknown,
  schema: T
): z.infer<T> {
  const result = schema.safeParse(rawResponse);

  if (!result.success) {
    // Throw the custom error with the parsing issues attached
    throw new LLMValidationError(
      "LLM response validation failed",
      result.error.issues
    );
  }

  return result.data;
}

// 3. Define a schema for Product Recommendations
const ProductRecommendationSchema = z.object({
  product_id: z.string().uuid(),
  name: z.string(),
  price: z.number().positive(),
  tags: z.array(z.string()),
});

// 4. Usage Example in an Edge Function context
export async function handleProductRequest(request: Request) {
  // Simulate fetching raw data from an LLM
  const rawLLMOutput = {
    product_id: "123e4567-e89b-12d3-a456-426614174000",
    name: "Wireless Headphones",
    price: 199.99,
    tags: ["audio", "wireless"]
  };

  try {
    // Validate the response
    const product = validateLLMResponse(rawLLMOutput, ProductRecommendationSchema);
    
    // Proceed with typed data
    return new Response(JSON.stringify({ success: true, data: product }), { status: 200 });
  } catch (error) {
    if (error instanceof LLMValidationError) {
      // Log specific validation issues
      console.error("Validation failed:", error.issues);
      
      return new Response(
        JSON.stringify({ error: "Invalid LLM data", details: error.issues }),
        { status: 422 } // Unprocessable Entity
      );
    }
    
    return new Response("Internal Server Error", { status: 500 });
  }
}
