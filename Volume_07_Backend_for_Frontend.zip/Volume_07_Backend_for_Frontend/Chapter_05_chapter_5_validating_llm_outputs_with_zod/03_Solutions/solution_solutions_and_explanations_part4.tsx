/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState } from 'react';
import { z } from 'zod';

// 1. Define Zod schemas for different message types
const TextMessageSchema = z.object({
  type: z.literal("text"),
  content: z.string().min(1),
});

const CodeMessageSchema = z.object({
  type: z.literal("code"),
  language: z.string(),
  code: z.string(),
});

// Union type for valid messages
type ValidMessage = z.infer<typeof TextMessageSchema> | z.infer<typeof CodeMessageSchema>;

// 2. Sub-components for rendering
const TextMessage = ({ content }: { content: string }) => (
  <div style={{ padding: '10px', backgroundColor: '#f0f0f0', borderRadius: '5px', marginBottom: '8px' }}>
    <p>{content}</p>
  </div>
);

const CodeBlock = ({ language, code }: { language: string; code: string }) => (
  <div style={{ padding: '10px', backgroundColor: '#2d2d2d', color: '#fff', borderRadius: '5px', marginBottom: '8px' }}>
    <div style={{ borderBottom: '1px solid #555', paddingBottom: '5px', marginBottom: '5px', fontSize: '0.8em' }}>
      {language.toUpperCase()}
    </div>
    <pre style={{ margin: 0, whiteSpace: 'pre-wrap' }}>{code}</pre>
  </div>
);

// 3. Main Component
export const LLMChatInterface = () => {
  const [messages, setMessages] = useState<ValidMessage[]>([]);

  // Pre-defined raw data for simulation (mix of valid and invalid)
  const simulationData = [
    { type: "text", content: "Hello! How can I assist you today?" },
    { type: "code", language: "typescript", code: "const greeting = 'Hello World';" },
    { type: "text" }, // Invalid: missing content
    { type: "unknown", payload: "some data" }, // Invalid: unknown type
    { type: "code", language: "python", code: "print('Hello')" }
  ];

  const simulateResponse = () => {
    // Pick a random item from simulationData
    const randomItem = simulationData[Math.floor(Math.random() * simulationData.length)];
    
    // We cast to unknown to simulate raw data coming from an API
    const rawMessage = randomItem as unknown;
    
    // Try to validate against schemas
    const parsedText = TextMessageSchema.safeParse(rawMessage);
    if (parsedText.success) {
      setMessages((prev) => [...prev, parsedText.data]);
      return;
    }

    const parsedCode = CodeMessageSchema.safeParse(rawMessage);
    if (parsedCode.success) {
      setMessages((prev) => [...prev, parsedCode.data]);
      return;
    }

    // If neither passes, we handle the invalid state (e.g., show an error UI)
    // For this demo, we will add a visual indicator of failure
    setMessages((prev) => [
      ...prev, 
      { type: "text", content: "Error: Received invalid message format from LLM." } as ValidMessage
    ]);
  };

  return (
    <div style={{ maxWidth: '600px', margin: '0 auto', fontFamily: 'sans-serif' }}>
      <h2>LLM Chat Interface</h2>
      <div style={{ border: '1px solid #ccc', minHeight: '300px', padding: '10px' }}>
        {messages.length === 0 ? (
          <p style={{ color: '#999' }}>No messages yet. Click simulate!</p>
        ) : (
          messages.map((msg, index) => {
            if (msg.type === "text") {
              return <TextMessage key={index} content={msg.content} />;
            }
            if (msg.type === "code") {
              return <CodeBlock key={index} language={msg.language} code={msg.code} />;
            }
            // This acts as a fallback for the "Invalid" visual we added manually
            return <TextMessage key={index} content={msg.content} />;
          })
        )}
      </div>
      <button onClick={simulateResponse} style={{ marginTop: '10px', padding: '8px 16px' }}>
        Simulate LLM Response
      </button>
    </div>
  );
};
