/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

import { z } from "zod";

// 1. Define the generic schema factory
// T extends z.ZodRawShape allows passing an object shape for specific fields
function createEntitySchema<T extends z.ZodRawShape>(specificFieldsSchema: T) {
  return z.object({
    // Common fields
    id: z.string().uuid(),
    createdAt: z.string().datetime(),
    // Spread the specific fields into the schema
    ...specificFieldsSchema,
  });
}

// 2. Create specific schemas using the factory
const UserSchema = createEntitySchema({
  name: z.string(),
  email: z.string().email(),
});

const ProductSchema = createEntitySchema({
  title: z.string(),
  price: z.number().positive(),
});

// 3. Define a discriminated union type for the entities
type Entity = 
  | { type: 'user'; data: z.infer<typeof UserSchema> }
  | { type: 'product'; data: z.infer<typeof ProductSchema> }
  | { type: 'unknown'; error: string };

// 4. Implement the validation function with discriminated union return
function validateEntity<T extends z.ZodTypeAny>(
  entityType: string,
  data: unknown,
  schema: T
): Entity {
  const result = schema.safeParse(data);

  if (!result.success) {
    return {
      type: 'unknown',
      error: `Failed to validate ${entityType}: ${result.error.message}`
    };
  }

  // Type guard to ensure we return the correct union member
  if (entityType === 'user') {
    return { type: 'user', data: result.data as z.infer<typeof UserSchema> };
  }
  
  if (entityType === 'product') {
    return { type: 'product', data: result.data as z.infer<typeof ProductSchema> };
  }

  return { type: 'unknown', error: 'Unknown entity type' };
}

// 5. Example Usage
const rawUserData = {
  id: "123e4567-e89b-12d3-a456-426614174000",
  createdAt: "2023-10-27T10:00:00Z",
  name: "Alice",
  email: "alice@example.com"
};

const rawProductData = {
  id: "123e4567-e89b-12d3-a456-426614174001",
  createdAt: "2023-10-27T11:00:00Z",
  title: "Laptop",
  price: 1200.00
};

// Validating User
const userResult = validateEntity('user', rawUserData, UserSchema);
if (userResult.type === 'user') {
  console.log("User Name:", userResult.data.name); // TypeScript knows 'data' exists here
}

// Validating Product
const productResult = validateEntity('product', rawProductData, ProductSchema);
if (productResult.type === 'product') {
  console.log("Product Price:", productResult.data.price); // TypeScript knows 'data' exists here
}
