/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.tsx
// Description: Basic Code Example
// ==========================================

// File: InvoiceDashboard.tsx
import React from 'react';
import { 
  useQuery, 
  useQueryClient, 
  QueryClient, 
  QueryClientProvider 
} from '@tanstack/react-query';

// ==========================================
// 1. MOCK BACKEND API (Simulating a SaaS Backend)
// ==========================================

/**
 * Simulates a network request to fetch invoices.
 * In a real app, this would be `fetch('/api/invoices')`.
 */
const fetchInvoices = async (): Promise<Array<{ id: string; amount: number; client: string }>> => {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      // Simulate 50% chance of random error to demonstrate error handling
      if (Math.random() > 0.5) {
        reject(new Error('Failed to connect to database.'));
        return;
      }

      resolve([
        { id: 'INV-001', amount: 1200, client: 'Acme Corp' },
        { id: 'INV-002', amount: 450, client: 'Globex Inc' },
        { id: 'INV-003', amount: 3200, client: 'Soylent Corp' },
      ]);
    }, 1500); // Simulate network latency
  });
};

// ==========================================
// 2. REACT COMPONENT: Invoice List
// ==========================================

/**
 * The UI Component.
 * It does NOT manage loading states or error states manually.
 * It delegates that logic to React Query.
 */
const InvoiceList = () => {
  // useQuery is the hook that orchestrates the data fetching lifecycle.
  const { 
    data,      // The actual data (undefined until fetched)
    error,     // Error object (if the fetch fails)
    isLoading, // Boolean: true only on initial fetch (no cache)
    isFetching // Boolean: true whenever fetching (including background)
  } = useQuery({
    queryKey: ['invoices'], // Unique ID for this data cache
    queryFn: fetchInvoices, // The function that returns the data
    staleTime: 5000,        // Data is fresh for 5 seconds (no background refetch)
  });

  // 1. LOADING STATE (Initial fetch only)
  if (isLoading) {
    return <div className="p-4 text-blue-600">Loading invoices...</div>;
  }

  // 2. ERROR STATE
  if (error) {
    return (
      <div className="p-4 text-red-600">
        Error: {(error as Error).message}
        <button 
          onClick={() => window.location.reload()} 
          className="ml-4 underline"
        >
          Retry
        </button>
      </div>
    );
  }

  // 3. SUCCESS STATE
  return (
    <div className="p-4 border rounded shadow-sm">
      <h2 className="text-xl font-bold mb-2">Invoice Dashboard</h2>
      
      {/* Visual indicator that a background fetch is happening */}
      {isFetching && <small className="text-gray-500">Updating...</small>}
      
      <ul className="mt-2 space-y-2">
        {data?.map((invoice) => (
          <li key={invoice.id} className="flex justify-between border-b pb-1">
            <span>{invoice.client}</span>
            <span className="font-mono">${invoice.amount}</span>
          </li>
        ))}
      </ul>
    </div>
  );
};

// ==========================================
// 3. APP SETUP: Providers
// ==========================================

/**
 * In a real app, this QueryClient setup is usually in `main.tsx` or `App.tsx`.
 * We configure global defaults here.
 */
const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      retry: 2, // Retry failed fetches 2 times before failing
      refetchOnWindowFocus: true, // Refetch when user tabs back to window
    }
  }
});

export const InvoiceDashboardApp = () => {
  return (
    // The Provider makes the cache available to all child components
    <QueryClientProvider client={queryClient}>
      <div className="max-w-md mx-auto mt-10">
        <h1 className="text-2xl font-bold mb-4 text-center">SaaS Invoice App</h1>
        <InvoiceList />
        
        {/* Optional: React Query DevTools (only in dev) */}
        {/* <ReactQueryDevtools /> */}
      </div>
    </QueryClientProvider>
  );
};
