/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.tsx
// Description: Advanced Application Script
// ==========================================

// src/app/components/ProjectBoard.tsx
// Target: Next.js 14+ with App Router
// Dependencies: react, react-query (@tanstack/react-query), lucide-react (for icons)

import React, { useState } from 'react';
import {
  useQuery,
  useMutation,
  useQueryClient,
  QueryClient,
  QueryClientProvider,
} from '@tanstack/react-query';

// --- 1. MOCK BACKEND & TYPES ---

// Simulating a database model for a Task
type Task = {
  id: string;
  title: string;
  status: 'TODO' | 'IN_PROGRESS' | 'DONE';
  priority: 'LOW' | 'HIGH';
};

// Mock initial data
const initialTasks: Task[] = [
  { id: '1', title: 'Design System Audit', status: 'TODO', priority: 'HIGH' },
  { id: '2', title: 'API Integration', status: 'IN_PROGRESS', priority: 'HIGH' },
  { id: '3', title: 'Unit Testing', status: 'TODO', priority: 'LOW' },
];

/**
 * Simulates a network delay and potential random failure for the API.
 * In a real app, this would be a fetch() call to your tRPC or REST endpoint.
 */
const simulateApiCall = async <T,>(data: T, failRate: number = 0.1): Promise<T> => {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      // Randomly simulate a server error to demonstrate error handling
      if (Math.random() < failRate) {
        reject(new Error('Server Error: Could not update task status.'));
      } else {
        resolve(data);
      }
    }, 800); // 800ms network delay
  });
};

// --- 2. QUERY KEYS & API FUNCTIONS ---

// Centralized Query Keys for cache management
const queryKeys = {
  all: ['tasks'] as const,
  detail: (id: string) => [...queryKeys.all, id] as const,
};

/**
 * Fetches all tasks. 
 * Uses 'stale-while-revalidate' implicitly via React Query's default config.
 */
const fetchTasks = async (): Promise<Task[]> => {
  // In a real app: const res = await fetch('/api/tasks'); return res.json();
  return simulateApiCall([...initialTasks]);
};

/**
 * Updates a specific task's status.
 * @param param0 - Object containing id and new status
 */
const updateTaskStatus = async ({ id, status }: { id: string; status: Task['status'] }): Promise<Task> => {
  // In a real app: await fetch(`/api/tasks/${id}`, { method: 'PATCH', body: JSON.stringify({ status }) });
  
  // Find the task in our mock data
  const taskIndex = initialTasks.findIndex((t) => t.id === id);
  if (taskIndex === -1) throw new Error('Task not found');
  
  const updatedTask = { ...initialTasks[taskIndex], status };
  initialTasks[taskIndex] = updatedTask; // Update mock DB
  
  return simulateApiCall(updatedTask);
};

// --- 3. REACT COMPONENTS ---

/**
 * TaskCard Component
 * Displays individual task details.
 */
const TaskCard = ({ task }: { task: Task }) => {
  const getStatusColor = (status: Task['status']) => {
    switch (status) {
      case 'TODO': return 'bg-gray-200 text-gray-800';
      case 'IN_PROGRESS': return 'bg-blue-100 text-blue-800';
      case 'DONE': return 'bg-green-100 text-green-800';
      default: return 'bg-gray-200';
    }
  };

  return (
    <div className="p-4 bg-white border border-gray-200 rounded-lg shadow-sm hover:shadow-md transition-shadow flex flex-col gap-2">
      <div className="flex justify-between items-start">
        <h3 className="font-semibold text-gray-900">{task.title}</h3>
        <span className={`text-xs font-bold px-2 py-1 rounded ${task.priority === 'HIGH' ? 'bg-red-100 text-red-700' : 'bg-gray-100 text-gray-600'}`}>
          {task.priority}
        </span>
      </div>
      <div className={`text-xs font-medium px-2 py-1 rounded self-start uppercase tracking-wide ${getStatusColor(task.status)}`}>
        {task.status.replace('_', ' ')}
      </div>
    </div>
  );
};

/**
 * Board Component
 * The main container managing data fetching and mutations.
 */
const ProjectBoard = () => {
  const queryClient = useQueryClient();
  const [filter, setFilter] = useState<'ALL' | 'HIGH'>('ALL');

  // --- REACT QUERY HOOKS ---

  /**
   * useQuery:
   * - Key: ['tasks'] (unique identifier for this data)
   * - QueryFn: fetchTasks (async function)
   * - staleTime: 5000ms (Data is fresh for 5s, no background refetch)
   * - cacheTime: 10 * 60 * 1000 (Cache persists for 10 mins even if unmounted)
   */
  const { data: tasks, isLoading, error } = useQuery({
    queryKey: queryKeys.all,
    queryFn: fetchTasks,
    staleTime: 5000, // 5 seconds
    retry: 1, // Retry once on failure
  });

  /**
   * useMutation:
   * Handles the update logic. 
   * We separate the mutation logic from the query to allow optimistic updates.
   */
  const updateTaskMutation = useMutation({
    mutationFn: updateTaskStatus,

    // ON MUTATE: Optimistic Update Logic
    // This function fires BEFORE the mutation executes.
    // It allows us to modify the UI immediately.
    onMutate: async ({ id, status }) => {
      // 1. Cancel outgoing refetches (to avoid overwriting our optimistic data)
      await queryClient.cancelQueries({ queryKey: queryKeys.all });

      // 2. Snapshot the previous value
      const previousTasks = queryClient.getQueryData<Task[]>(queryKeys.all);

      // 3. Optimistically update the cache
      if (previousTasks) {
        const newTasks = previousTasks.map((task) =>
          task.id === id ? { ...task, status } : task
        );
        queryClient.setQueryData<Task[]>(queryKeys.all, newTasks);
      }

      // Return a context object with the snapshot
      return { previousTasks };
    },

    // ON ERROR: Rollback
    // If the API call fails, revert the UI to the previous state.
    onError: (err, variables, context) => {
      if (context?.previousTasks) {
        queryClient.setQueryData(queryKeys.all, context.previousTasks);
      }
      // Optional: Show a toast notification here
      console.error("Update failed:", err);
    },

    // ON SETTLED: Revalidation
    // Always refetch after error or success to ensure we are in sync with server.
    onSettled: () => {
      queryClient.invalidateQueries({ queryKey: queryKeys.all });
    },
  });

  // --- UI HANDLERS ---

  const handleStatusChange = (id: string, currentStatus: Task['status']) => {
    const nextStatus = currentStatus === 'TODO' ? 'IN_PROGRESS' : currentStatus === 'IN_PROGRESS' ? 'DONE' : 'TODO';
    updateTaskMutation.mutate({ id, status: nextStatus });
  };

  // --- RENDER LOGIC ---

  if (isLoading) return <div className="p-8 text-center text-gray-500">Loading Board...</div>;
  if (error) return <div className="p-8 text-center text-red-500">Error loading tasks. Please refresh.</div>;

  // Filter logic (Client-side)
  const filteredTasks = tasks?.filter(t => filter === 'HIGH' ? t.priority === 'HIGH' : true) || [];

  return (
    <div className="max-w-4xl mx-auto p-6 space-y-6">
      {/* Header & Controls */}
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold text-gray-900">Project Board</h1>
        <div className="flex gap-2">
          <button 
            onClick={() => setFilter('ALL')}
            className={`px-3 py-1 rounded text-sm ${filter === 'ALL' ? 'bg-gray-900 text-white' : 'bg-gray-200 text-gray-700'}`}
          >
            All Tasks
          </button>
          <button 
            onClick={() => setFilter('HIGH')}
            className={`px-3 py-1 rounded text-sm ${filter === 'HIGH' ? 'bg-red-600 text-white' : 'bg-gray-200 text-gray-700'}`}
          >
            High Priority
          </button>
        </div>
      </div>

      {/* Status Indicators for Mutations */}
      {updateTaskMutation.isPending && (
        <div className="text-blue-600 text-sm font-medium animate-pulse">
          Syncing changes with server...
        </div>
      )}
      {updateTaskMutation.isError && (
        <div className="bg-red-50 text-red-700 p-3 rounded border border-red-200 text-sm">
          Failed to update task. Changes reverted. {updateTaskMutation.error.message}
        </div>
      )}

      {/* Task Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredTasks.map((task) => (
          <div key={task.id} className="relative group">
            <TaskCard task={task} />
            {/* Interaction Overlay */}
            <div className="absolute inset-0 bg-black/5 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center rounded-lg">
              <button 
                onClick={() => handleStatusChange(task.id, task.status)}
                className="bg-white text-gray-900 px-4 py-2 rounded shadow text-sm font-medium hover:bg-gray-50"
                disabled={updateTaskMutation.isPending}
              >
                Cycle Status
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

/**
 * Root Component Wrapper
 * Sets up the QueryClient and Provider.
 * In Next.js App Router, this usually lives in a provider file.
 */
export default function ProjectBoardWrapper() {
  const [queryClient] = useState(() => new QueryClient({
    defaultOptions: {
      queries: {
        staleTime: 5 * 60 * 1000, // 5 minutes
        refetchOnWindowFocus: false, // Prevent annoying refocus fetches
      },
    },
  }));

  return (
    <QueryClientProvider client={queryClient}>
      <ProjectBoard />
    </QueryClientProvider>
  );
}
