/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

import { useQuery } from '@tanstack/react-query';

// Define the expected shape of the API response
interface DashboardStats {
  totalRevenue: number;
  activeUsers: number;
  lastUpdated: string;
}

// Custom hook for fetching dashboard statistics
export const useDashboardStats = () => {
  return useQuery<DashboardStats>({
    // Unique key for the query cache
    queryKey: ['dashboard', 'stats'],
    
    // Function to fetch data
    queryFn: async () => {
      const response = await fetch('/api/stats');
      if (!response.ok) {
        throw new Error('Network response was not ok');
      }
      return response.json();
    },

    // 1. Configuration: Stale Time
    // Data is considered fresh for 5 minutes. No background refetch will occur 
    // during this time unless triggered manually or via refetchOnWindowFocus.
    staleTime: 1000 * 60 * 5, // 5 minutes

    // 2. Configuration: Refetch Interval
    // Automatically refetch data every 60 seconds to keep the dashboard updated.
    refetchInterval: 1000 * 60, // 60 seconds
    
    // Optional: Ensure the query only runs if the window is focused to save resources
    refetchOnWindowFocus: false, 
  });
};
