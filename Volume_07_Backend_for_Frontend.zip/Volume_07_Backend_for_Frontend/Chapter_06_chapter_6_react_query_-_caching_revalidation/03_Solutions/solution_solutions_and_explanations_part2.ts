/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

import { useMutation, useQueryClient } from '@tanstack/react-query';

// Define types for the post data structure
interface Post {
  id: string;
  likes: number;
  isLiked: boolean;
}

// Helper to generate the query key for a specific post
const getPostKey = (postId: string) => ['posts', postId];

export const useToggleLike = (postId: string) => {
  const queryClient = useQueryClient();

  return useMutation({
    // 1. Mutation Function: Sends the request to the server
    mutationFn: async () => {
      const response = await fetch(`/api/posts/${postId}/like`, {
        method: 'POST',
      });
      if (!response.ok) throw new Error('Failed to like post');
      return response.json();
    },

    // 2. Optimistic Update: Update cache immediately before the server responds
    onMutate: async () => {
      // Cancel outgoing refetches to avoid overwriting our optimistic update
      await queryClient.cancelQueries({ queryKey: getPostKey(postId) });

      // Snapshot the previous value
      const previousPost = queryClient.getQueryData<Post>(getPostKey(postId));

      // Optimistically update to the new value
      if (previousPost) {
        const newPost: Post = {
          ...previousPost,
          likes: previousPost.isLiked ? previousPost.likes - 1 : previousPost.likes + 1,
          isLiked: !previousPost.isLiked,
        };
        queryClient.setQueryData(getPostKey(postId), newPost);
      }

      // Return a context object with the snapshotted value
      return { previousPost };
    },

    // 3. Rollback Logic: If the mutation errors, revert to the snapshot
    onError: (err, variables, context) => {
      if (context?.previousPost) {
        queryClient.setQueryData(getPostKey(postId), context.previousPost);
      }
      // Trigger UI toast notification (mocked here as console.error)
      console.error('Like failed:', err);
    },

    // 4. Refetching: Ensure server state is the source of truth eventually
    onSettled: () => {
      // Invalidate the query to trigger a refetch and sync with the server
      queryClient.invalidateQueries({ queryKey: getPostKey(postId) });
    },
  });
};
