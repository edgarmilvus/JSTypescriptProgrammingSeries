/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

import { useInfiniteQuery } from '@tanstack/react-query';
import { useInView } from 'react-intersection-observer';

// Types for API response and Product
interface Product {
  id: number;
  name: string;
  price: number;
}

interface ProductApiResponse {
  data: Product[];
  meta: {
    hasNextPage: boolean;
    nextPage: number | null;
  };
}

// 1. Custom Hook: useProductCatalog
export const useProductCatalog = () => {
  return useInfiniteQuery<ProductApiResponse, Error>({
    queryKey: ['products', 'catalog'],
    
    // The queryFn receives the pageParam provided by getNextPageParam
    queryFn: async ({ pageParam = 1 }) => {
      const res = await fetch(`/api/products?page=${pageParam}&limit=10`);
      if (!res.ok) throw new Error('Failed to fetch products');
      return res.json();
    },

    // 2. Logic to determine the next page number
    getNextPageParam: (lastPage, allPages) => {
      if (!lastPage.meta.hasNextPage || !lastPage.meta.nextPage) return undefined;
      return lastPage.meta.nextPage;
    },

    // Initial page param
    initialPageParam: 1,
  });
};

// 3. Component: ProductList
export const ProductList = () => {
  const { ref, inView } = useInView();
  const {
    data,
    fetchNextPage,
    hasNextPage,
    isFetchingNextPage,
    isLoading,
  } = useProductCatalog();

  // 4. Trigger fetch when the sentinel element is in view
  React.useEffect(() => {
    if (inView && hasNextPage && !isFetchingNextPage) {
      fetchNextPage();
    }
  }, [inView, hasNextPage, isFetchingNextPage, fetchNextPage]);

  if (isLoading) return <div>Loading initial products...</div>;

  // Flatten the pages into a single array of products
  const products = data?.pages.flatMap(page => page.data) || [];

  return (
    <div className="product-list">
      {products.map((product) => (
        <div key={product.id} className="product-card">
          <h3>{product.name}</h3>
          <p>${product.price}</p>
        </div>
      ))}

      {/* 5. Sentinel Element & Loading Spinner */}
      <div ref={ref} style={{ height: '20px', margin: '20px 0' }}>
        {isFetchingNextPage && <div>Loading more products...</div>}
        {!hasNextPage && products.length > 0 && <div>No more products to load.</div>}
      </div>
    </div>
  );
};
