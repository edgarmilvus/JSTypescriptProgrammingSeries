/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';

// 1. Data Type
interface User {
  id: number;
  firstName: string;
  lastName: string;
  email: string;
}

// 2. Custom Hook
const useUser = (userId: number | null) => {
  return useQuery<User, Error>({
    // Robust Query Key: Includes the userId to create a unique cache entry per user
    queryKey: ['users', userId],
    
    // Fetching logic
    queryFn: async () => {
      // Simulate network latency (2 seconds)
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      const response = await fetch(`/api/users/${userId}`);
      if (!response.ok) throw new Error('Failed to fetch user');
      return response.json();
    },

    // 3. Enabled Option: Only run query if userId exists
    enabled: userId !== null,

    // 4. Select Option: Transform data before returning it to the component
    select: (data) => ({
      ...data,
      fullName: `${data.firstName} ${data.lastName}`, // Derived property
    }),
  });
};

// 5. Component
export const UserProfileEditor = () => {
  const [selectedUserId, setSelectedUserId] = useState<number | null>(null);

  // Use the custom hook
  const { data, isLoading, isError, error } = useUser(selectedUserId);

  return (
    <div style={{ padding: '20px' }}>
      <h2>User Profile Editor</h2>
      
      {/* Dropdown to switch users */}
      <label>Select User: </label>
      <select 
        value={selectedUserId || ''} 
        onChange={(e) => setSelectedUserId(Number(e.target.value) || null)}
      >
        <option value="">-- Select a User --</option>
        <option value="1">User 1</option>
        <option value="2">User 2</option>
      </select>

      {/* Display Logic */}
      <div style={{ marginTop: '20px', border: '1px solid #ccc', padding: '10px' }}>
        {isLoading && selectedUserId ? (
          <div>Loading profile for User {selectedUserId}...</div>
        ) : isError ? (
          <div>Error: {error.message}</div>
        ) : data ? (
          <div>
            <h3>{data.fullName}</h3> {/* Using the 'select' transformed data */}
            <p>Email: {data.email}</p>
            <p>ID: {data.id}</p>
          </div>
        ) : (
          <div>Please select a user to view their profile.</div>
        )}
      </div>
    </div>
  );
};
