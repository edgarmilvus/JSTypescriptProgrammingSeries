/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.tsx
// Description: Solutions and Explanations
// ==========================================

import { useQuery } from '@tanstack/react-query';
import React, { useState, useEffect } from 'react';

// 1. Custom Wrapper Hook: useSafeQuery
export const useSafeQuery = (options: any) => {
  return useQuery({
    ...options,
    // 2. Retry Logic: 3 attempts with linear backoff
    retry: 3,
    retryDelay: (attemptIndex) => Math.min(1000 * 2 ** attemptIndex, 30000),
    
    // 3. Global Error Logging
    onError: (error) => {
      // Mocking a centralized logging service
      console.log(`[Global Logger] API Error: ${error.message}`);
      
      // Call the original onError if it exists in options
      if (options.onError) {
        options.onError(error);
      }
    },
  });
};

// 4. Component with Offline Detection & Manual Retry
export const NetworkStatusComponent = ({ queryKey, queryFn }: { queryKey: string[], queryFn: () => Promise<any> }) => {
  // State to track online status
  const [isOnline, setIsOnline] = useState(navigator.onLine);

  // Listen for network changes
  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  // Use the safe query hook
  const { data, isLoading, isError, refetch, isFetching } = useSafeQuery({
    queryKey,
    queryFn,
    // Disable query if offline to prevent unnecessary attempts
    enabled: isOnline, 
  });

  // 5. Manual Retry Handler
  const handleManualRetry = () => {
    refetch();
  };

  // UI Logic
  if (!isOnline) {
    return (
      <div style={{ padding: '20px', backgroundColor: '#fff3cd', border: '1px solid #ffeaa7' }}>
        <strong>Offline Detected:</strong> Please check your internet connection.
      </div>
    );
  }

  if (isLoading) return <div>Loading data...</div>;

  if (isError) {
    return (
      <div style={{ padding: '20px', backgroundColor: '#f8d7da', border: '1px solid #f5c6cb' }}>
        <strong>Error:</strong> Failed to load data after retries.
        <button onClick={handleManualRetry} style={{ marginLeft: '10px' }}>
          Retry Now
        </button>
      </div>
    );
  }

  return (
    <div>
      {isFetching && <div style={{ color: 'gray', fontSize: '0.8em' }}>Updating in background...</div>}
      <div>Data: {JSON.stringify(data)}</div>
    </div>
  );
};
