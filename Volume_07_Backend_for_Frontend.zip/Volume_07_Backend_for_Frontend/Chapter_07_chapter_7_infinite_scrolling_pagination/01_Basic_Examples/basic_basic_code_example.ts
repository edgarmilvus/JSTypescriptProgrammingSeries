/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

// File: src/server/api/routers/user.ts
// This file contains the tRPC router for user pagination.

import { z } from 'zod';
import { publicProcedure, createTRPCRouter } from '~/server/api/trpc';

// Mock database: A simple array of user objects.
// In a real application, this would be a database query (e.g., Prisma, Drizzle).
const mockUsers = Array.from({ length: 100 }, (_, i) => ({
  id: `user_${i + 1}`,
  name: `User ${i + 1}`,
  email: `user${i + 1}@example.com`,
  createdAt: new Date(Date.now() - i * 60000), // Created 1 minute apart, descending.
}));

export const userRouter = createTRPCRouter({
  // The infinite query procedure for pagination.
  getInfiniteUsers: publicProcedure
    .input(
      z.object({
        limit: z.number().min(1).max(100).default(10),
        cursor: z.string().optional(), // The cursor is the ID of the last item.
      })
    )
    .query(async ({ input }) => {
      const { limit, cursor } = input;

      // 1. Find the index of the cursor item in our mock data.
      //    If no cursor is provided, we start from the beginning (index -1).
      const cursorIndex = cursor
        ? mockUsers.findIndex((u) => u.id === cursor)
        : -1;

      // 2. Calculate the start index for the next page.
      const startIndex = cursorIndex + 1;

      // 3. Slice the array to get the next 'limit' items.
      const items = mockUsers.slice(startIndex, startIndex + limit);

      // 4. Determine the next cursor.
      //    If we have more items after the current slice, the next cursor is the ID of the last item in the slice.
      //    Otherwise, there is no next cursor (end of list).
      const nextCursor = items.length === limit ? items[items.length - 1].id : undefined;

      // 5. Return the items and the next cursor.
      return {
        items,
        nextCursor,
      };
    }),
});
