/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// src/lib/trpc.ts
import { initTRPC } from '@trpc/server';
import { z } from 'zod';

// Initialize tRPC
const t = initTRPC.create();

// Mock Database: Represents a large dataset of logs
const mockDbLogs = Array.from({ length: 100 }, (_, i) => ({
  id: `log_${i}`,
  timestamp: new Date(Date.now() - i * 60000).toISOString(),
  content: `System event ${i}: User action triggered workflow update. Status code 200.`,
  severity: i % 5 === 0 ? 'high' : 'low',
}));

// --- Edge Function Simulation: Rate Limiting ---
// In a real Edge Function (Vercel/Cloudflare), this would use the runtime environment.
// Here we simulate a token bucket algorithm.
const RATE_LIMIT_WINDOW = 60 * 1000; // 1 minute
const MAX_REQUESTS = 10;
const requestCounts: { [ip: string]: number[] } = {};

/**
 * Checks if a request is allowed based on a sliding window rate limit.
 * @param ip - The identifier for the requester (simulating client IP).
 * @returns boolean indicating if the request is allowed.
 */
const checkRateLimit = (ip: string): boolean => {
  const now = Date.now();
  if (!requestCounts[ip]) requestCounts[ip] = [];
  
  // Filter out timestamps older than the window
  requestCounts[ip] = requestCounts[ip].filter(time => now - time < RATE_LIMIT_WINDOW);
  
  if (requestCounts[ip].length >= MAX_REQUESTS) {
    return false; // Limit exceeded
  }
  
  requestCounts[ip].push(now);
  return true;
};

// --- LLM Data Transformation Simulation ---
/**
 * Simulates an LLM call to summarize verbose log content.
 * In production, this would be an async call to an LLM API.
 * @param content - The raw log content.
 * @returns A summarized string.
 */
const summarizeWithLLM = async (content: string): Promise<string> => {
  // Simulate network latency
  await new Promise(resolve => setTimeout(resolve, 50)); 
  
  // Simple deterministic summarization for demo purposes
  const keywords = content.match(/\b(\w+)\b/g)?.slice(0, 3).join(' ') || 'Event';
  return `[AI Summary] ${keywords.toUpperCase()} - Critical update processed.`;
};

// --- tRPC Router Definition ---
export const appRouter = t.router({
  getLogs: t.procedure
    .input(
      z.object({
        cursor: z.string().optional(), // The ID of the last item fetched
        limit: z.number().min(1).max(50).default(10),
        clientIp: z.string(), // Simulated client identifier
      })
    )
    .query(async ({ input }) => {
      // 1. Enforce Rate Limit
      if (!checkRateLimit(input.clientIp)) {
        throw new Error('Rate limit exceeded. Please try again later.');
      }

      // 2. Fetch Data (Cursor-based)
      const { cursor, limit } = input;
      let startIndex = 0;
      
      if (cursor) {
        const cursorIndex = mockDbLogs.findIndex(log => log.id === cursor);
        startIndex = cursorIndex + 1;
      }

      const fetchedItems = mockDbLogs.slice(startIndex, startIndex + limit);
      
      // 3. Apply LLM Transformation (Intelligent API)
      // Transforming content for the frontend to reduce payload size/add context
      const transformedItems = await Promise.all(
        fetchedItems.map(async (item) => ({
          ...item,
          summary: await summarizeWithLLM(item.content),
        }))
      );

      // 4. Determine Next Cursor
      const nextCursor = startIndex + limit < mockDbLogs.length 
        ? mockDbLogs[startIndex + limit - 1].id 
        : undefined;

      return {
        items: transformedItems,
        nextCursor,
      };
    }),
});

export type AppRouter = typeof appRouter;
