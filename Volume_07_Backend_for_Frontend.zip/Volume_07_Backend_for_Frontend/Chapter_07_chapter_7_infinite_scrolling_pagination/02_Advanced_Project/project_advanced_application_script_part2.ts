/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script_part2.ts
// Description: Advanced Application Script
// ==========================================

// src/hooks/useInfiniteLogFeed.ts
import { useState, useEffect, useCallback, useRef } from 'react';
import { trpc } from '../utils/trpc'; // Assuming tRPC client setup

/**
 * Custom hook to manage infinite scrolling for the log feed.
 * It integrates with the tRPC query to fetch pages on demand.
 */
export const useInfiniteLogFeed = () => {
  // State for tracking the cursor and data accumulation
  const [items, setItems] = useState<any[]>([]);
  const [hasMore, setHasMore] = useState(true);
  
  // tRPC query for fetching data
  // enabled: false allows manual triggering
  const fetchLogs = trpc.getLogs.useInfiniteQuery(
    { limit: 10, clientIp: 'user_123' }, // Mock IP
    {
      getNextPageParam: (lastPage) => lastPage.nextCursor,
      enabled: false, // We control fetching manually
    }
  );

  // Ref for the Intersection Observer sentinel
  const observerRef = useRef<HTMLDivElement | null>(null);

  // Effect to handle data accumulation when new pages arrive
  useEffect(() => {
    if (fetchLogs.data) {
      const newItems = fetchLogs.data.pages.flatMap(page => page.items);
      setItems(newItems);
      setHasMore(!!fetchLogs.data.pages[fetchLogs.data.pages.length - 1].nextCursor);
    }
  }, [fetchLogs.data]);

  // Effect to set up Intersection Observer
  useEffect(() => {
    if (!observerRef.current || !hasMore) return;

    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting && !fetchLogs.isFetching && hasMore) {
          // Trigger the next fetch
          fetchLogs.fetchNextPage();
        }
      },
      { threshold: 0.1 } // Trigger when 10% visible
    );

    observer.observe(observerRef.current);

    return () => {
      if (observerRef.current) observer.unobserve(observerRef.current);
    };
  }, [hasMore, fetchLogs]);

  // Initial load trigger
  useEffect(() => {
    fetchLogs.fetchNextPage();
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return {
    items,
    isLoading: fetchLogs.isLoading || fetchLogs.isFetching,
    error: fetchLogs.error,
    observerRef,
    hasMore,
  };
};
