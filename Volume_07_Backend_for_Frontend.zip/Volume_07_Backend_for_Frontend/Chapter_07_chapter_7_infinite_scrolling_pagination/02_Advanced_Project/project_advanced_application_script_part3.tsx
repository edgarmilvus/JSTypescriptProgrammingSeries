/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script_part3.tsx
// Description: Advanced Application Script
// ==========================================

// src/components/LogFeed.tsx
import React from 'react';
import { useInfiniteLogFeed } from '../hooks/useInfiniteLogFeed';

/**
 * Component: LogFeed
 * Renders the list of logs and the infinite scroll sentinel.
 */
export const LogFeed: React.FC = () => {
  const { items, isLoading, error, observerRef, hasMore } = useInfiniteLogFeed();

  if (error) return <div className="p-4 text-red-500">Error: {error.message}</div>;

  return (
    <div className="max-w-2xl mx-auto p-4 space-y-4">
      <h1 className="text-2xl font-bold mb-4">Project Activity Log</h1>
      
      <div className="space-y-3">
        {items.map((log) => (
          <div key={log.id} className="p-4 bg-white border rounded shadow-sm">
            <div className="flex justify-between text-xs text-gray-500 mb-1">
              <span>{log.id}</span>
              <span>{new Date(log.timestamp).toLocaleTimeString()}</span>
            </div>
            {/* Displaying the LLM-transformed summary */}
            <p className="text-sm font-semibold text-blue-600 mb-1">{log.summary}</p>
            <p className="text-sm text-gray-800">{log.content}</p>
          </div>
        ))}
      </div>

      {/* Sentinel Element for Intersection Observer */}
      <div ref={observerRef} className="h-10 flex justify-center items-center">
        {isLoading && <span className="text-gray-400 animate-pulse">Loading more logs...</span>}
        {!isLoading && !hasMore && <span className="text-gray-400">End of history</span>}
      </div>
    </div>
  );
};
