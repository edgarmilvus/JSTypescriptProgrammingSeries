/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// types.ts
export type Post = {
  id: string;
  content: string;
  createdAt: Date;
};

// trpc/postRouter.ts
import { z } from "zod";
import { publicProcedure, router } from "../trpc";

// Mock data generation (for demonstration purposes)
const generateMockPosts = (count: number): Post[] => {
  return Array.from({ length: count }, (_, i) => ({
    id: `post-${i}`,
    content: `This is the content for post number ${i}`,
    createdAt: new Date(Date.now() - i * 60000), // 1 minute apart
  }));
};

const mockPosts = generateMockPosts(100); // Generate 100 mock posts

export const postRouter = router({
  getInfinitePosts: publicProcedure
    .input(
      z.object({
        limit: z.number().min(1).max(50).default(10),
        cursor: z.string().nullable().default(null),
      })
    )
    .query(async ({ input }) => {
      // 1. Sort mockPosts by createdAt descending (newest first)
      const sortedPosts = [...mockPosts].sort(
        (a, b) => b.createdAt.getTime() - a.createdAt.getTime()
      );

      let startIndex = 0;
      
      // 2. Find the starting index based on input.cursor
      if (input.cursor) {
        const cursorIndex = sortedPosts.findIndex((p) => p.id === input.cursor);
        // If cursor is found, start from the next index. 
        // If not found (edge case), start from 0.
        if (cursorIndex !== -1) {
          startIndex = cursorIndex + 1;
        }
      }

      // 3. Fetch input.limit + 1 items to check for next page
      const fetchedItems = sortedPosts.slice(startIndex, startIndex + input.limit + 1);

      // 4. Determine if there is a nextCursor
      let nextCursor: string | null = null;
      if (fetchedItems.length > input.limit) {
        // If we fetched more than the limit, the last item is the cursor for the next page
        nextCursor = fetchedItems[fetchedItems.length - 1].id;
      }

      // 5. Return the formatted object (slice to exact limit)
      const items = fetchedItems.slice(0, input.limit);

      return {
        items,
        nextCursor,
      };
    }),
});
