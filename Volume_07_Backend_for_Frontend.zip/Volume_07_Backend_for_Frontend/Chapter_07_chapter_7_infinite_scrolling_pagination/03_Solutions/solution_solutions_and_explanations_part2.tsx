/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.tsx
// Description: Solutions and Explanations
// ==========================================

// components/InfinitePostFeed.tsx
import { api } from "~/utils/api";
import { useRef, useEffect } from "react";

export const InfinitePostFeed = () => {
  const {
    data,
    fetchNextPage,
    hasNextPage,
    isFetchingNextPage,
  } = api.post.getInfinitePosts.useInfiniteQuery(
    { limit: 10 },
    {
      getNextPageParam: (lastPage) => lastPage.nextCursor,
      initialPageParam: null,
    }
  );

  const lastPostRef = useRef<HTMLDivElement | null>(null);

  // Intersection Observer Logic
  useEffect(() => {
    // If we are currently fetching or there are no more pages, do nothing
    if (isFetchingNextPage || !hasNextPage) return;

    const observer = new IntersectionObserver(
      (entries) => {
        // If the last element is visible in the viewport
        if (entries[0].isIntersecting) {
          fetchNextPage();
        }
      },
      {
        root: null, // viewport
        rootMargin: "0px",
        threshold: 0.1, // Trigger when 10% of the element is visible
      }
    );

    const currentRef = lastPostRef.current;
    if (currentRef) {
      observer.observe(currentRef);
    }

    // Cleanup function
    return () => {
      if (currentRef) {
        observer.unobserve(currentRef);
      }
    };
    // Dependency array: Re-run effect if dependencies change
  }, [isFetchingNextPage, hasNextPage, fetchNextPage]);

  const posts = data ? data.pages.flatMap((page) => page.items) : [];

  return (
    <div className="space-y-4">
      {posts.map((post, index) => {
        // Attach ref only to the last post
        const isLastPost = index === posts.length - 1;
        return (
          <div
            key={post.id}
            ref={isLastPost ? lastPostRef : null}
            className="p-4 border rounded bg-white shadow-sm"
          >
            <p className="font-bold">{post.id}</p>
            <p>{post.content}</p>
            <small className="text-gray-500">
              {post.createdAt.toLocaleString()}
            </small>
          </div>
        );
      })}
      
      {isFetchingNextPage && (
        <div className="text-center py-4 text-blue-600">Loading more posts...</div>
      )}
      
      {!hasNextPage && posts.length > 0 && (
        <div className="text-center py-4 text-gray-500">No more posts to load.</div>
      )}
    </div>
  );
};
