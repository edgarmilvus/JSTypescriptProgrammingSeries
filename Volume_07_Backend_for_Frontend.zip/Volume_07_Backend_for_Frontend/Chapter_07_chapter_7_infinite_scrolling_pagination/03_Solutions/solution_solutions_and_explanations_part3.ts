/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

// trpc/middleware/rateLimit.ts
import { middleware } from "@trpc/server";
import { TRPCError } from "@trpc/server";

// In-memory store to simulate a distributed cache (e.g., Redis)
// Structure: { [ip]: { count: number, resetTime: number } }
const rateLimitStore = new Map<
  string,
  { count: number; resetTime: number }
>();

// Simulate an Edge Function call
async function checkRateLimit(ip: string): Promise<boolean> {
  const now = Date.now();
  const windowMs = 60 * 1000; // 1 minute window
  const maxRequests = 10;

  const record = rateLimitStore.get(ip);

  if (!record) {
    // First request from this IP
    rateLimitStore.set(ip, { count: 1, resetTime: now + windowMs });
    return true;
  }

  // Check if window has expired
  if (now > record.resetTime) {
    // Reset counter
    record.count = 1;
    record.resetTime = now + windowMs;
    return true;
  }

  // Increment counter
  if (record.count < maxRequests) {
    record.count++;
    return true;
  }

  // Limit exceeded
  return false;
}

export const rateLimitMiddleware = middleware(async ({ ctx, next }) => {
  // 1. Extract IP. In a real app, this comes from ctx.req.headers.
  // For this exercise, we simulate it by looking for a specific header or defaulting.
  const ip = (ctx.req.headers["x-forwarded-for"] as string) || "127.0.0.1";

  // 2. Call the simulated Edge Function
  const isAllowed = await checkRateLimit(ip);

  // 3. Handle rejection
  if (!isAllowed) {
    throw new TRPCError({
      code: "TOO_MANY_REQUESTS",
      message: "Rate limit exceeded. Please try again later.",
    });
  }

  // 4. Proceed
  return next();
});

// trpc/postRouter.ts
// ... (imports from previous exercises)
import { rateLimitMiddleware } from "./middleware/rateLimit";

export const postRouter = router({
  getInfinitePosts: publicProcedure
    .use(rateLimitMiddleware) // Apply middleware
    .input(
      z.object({
        limit: z.number().min(1).max(50).default(10),
        cursor: z.string().nullable().default(null),
      })
    )
    .query(async ({ input }) => {
      // ... (same logic as Exercise 1)
      // ... (Mock data sorting and slicing)
      
      // Returning a dummy response for structure
      return {
        items: [], 
        nextCursor: null
      };
    }),
});
