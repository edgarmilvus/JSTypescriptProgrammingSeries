/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.tsx
// Description: Solutions and Explanations
// ==========================================

// components/InfinitePostFeed.tsx
// ... (imports)
export const InfinitePostFeed = () => {
  // ... (existing infinite query hooks)
  
  // Initialize the mutation hook
  const { mutate, data: summary, isLoading, error } = api.post.summarizePosts.useMutation();

  const handleSummarize = () => {
    if (!data) return;
    
    // Collect all currently loaded posts
    const allPosts = data.pages.flatMap((page) => page.items);
    
    // Trigger the mutation
    mutate(allPosts);
  };

  return (
    <div className="p-4">
      {/* Feed Rendering */}
      <div className="space-y-4 mb-6">
        {/* ... (Same rendering logic as Exercise 2) */}
        {/* Note: For brevity, I'm omitting the full list rendering code from previous exercise */}
        <div className="text-center text-gray-500">[Feed Items Rendered Here]</div>
      </div>

      {/* Action Area */}
      <div className="border-t pt-4">
        <button
          onClick={handleSummarize}
          disabled={isLoading}
          className="px-4 py-2 bg-purple-600 text-white rounded hover:bg-purple-700 disabled:opacity-50"
        >
          {isLoading ? 'Summarizing...' : 'Summarize Feed'}
        </button>

        {/* Result Display */}
        {summary && (
          <div className="mt-4 p-4 bg-blue-50 border border-blue-200 rounded">
            <h3 className="font-bold text-blue-800 mb-2">AI Summary</h3>
            <p className="text-blue-700">{summary}</p>
          </div>
        )}

        {error && (
          <div className="mt-2 text-red-600 text-sm">
            Error: {error.message}
          </div>
        )}
      </div>
    </div>
  );
};
