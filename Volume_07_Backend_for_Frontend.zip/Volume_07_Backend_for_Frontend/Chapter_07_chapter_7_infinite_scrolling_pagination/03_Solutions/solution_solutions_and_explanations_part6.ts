/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part6.ts
// Description: Solutions and Explanations
// ==========================================

digraph G {
  rankdir=TB;
  node [shape=box, style=filled, fillcolor="#E3F2FD"];
  
  // Define specific shapes/colors for clarity
  User [label="User Scrolling", fillcolor="#FFF9C4", shape=ellipse];
  Observer [label="Intersection Observer\n(Frontend Browser API)"];
  Comp [label="InfinitePostFeed Component", fillcolor="#E1BEE7"];
  RQ [label="React Query Client", fillcolor="#B2DFDB"];
  TRPC_Client [label="tRPC Client", fillcolor="#B39DDB"];
  
  // Server Side
  TRPC_Server [label="tRPC Server", fillcolor="#FFCCBC"];
  Middleware [label="Rate Limit Middleware", fillcolor="#FFAB91"];
  EdgeFunc [label="Edge Function\n(checkRateLimit)", fillcolor="#FF8A65", fontcolor="white"];
  Logic [label="Pagination Logic\n(DB Query / Slice)", fillcolor="#C5E1A5"];
  
  // Data
  DB [label="Mock Database", shape=cylinder, fillcolor="#F5F5F5"];
  
  // Feedback
  State [label="State Update\n(Data & Loading)", fillcolor="#B2DFDB"];

  // Flow
  User -> Observer [label="Scrolls to bottom"];
  Observer -> Comp [label="Triggers callback"];
  Comp -> RQ [label="fetchNextPage()"];
  RQ -> TRPC_Client [label="Execute Query\n(cursor, limit)"];
  
  TRPC_Client -> TRPC_Server [label="HTTP Request"];
  TRPC_Server -> Middleware [label="1. Pre-process"];
  
  Middleware -> EdgeFunc [label="2. Check IP Limit"];
  
  // Conditional Paths
  EdgeFunc -> Middleware [label="Allowed", style=dashed, color=green];
  EdgeFunc -> TRPC_Server [label="Denied (429)", style=dashed, color=red, fontcolor=red];
  
  Middleware -> Logic [label="3. Proceed", style=dashed, color=green];
  Logic -> DB [label="Fetch Data"];
  DB -> Logic [label="Raw Rows"];
  Logic -> TRPC_Server [label="Format (items, nextCursor)"];
  
  TRPC_Server -> TRPC_Client [label="JSON Response"];
  TRPC_Client -> RQ [label="Update Cache"];
  RQ -> Comp [label="Re-render"];
  Comp -> State [label="Update UI"];
}
