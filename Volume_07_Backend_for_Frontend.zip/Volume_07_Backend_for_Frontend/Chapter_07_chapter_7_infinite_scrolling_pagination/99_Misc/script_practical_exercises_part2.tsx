/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part2.tsx
// Description: Practical Exercises
// ==========================================

// components/InfinitePostFeed.tsx
import { api } from "~/utils/api";
import { useRef, useEffect } from "react";

export const InfinitePostFeed = () => {
  const {
    data,
    fetchNextPage,
    hasNextPage,
    isFetchingNextPage,
  } = api.post.getInfinitePosts.useInfiniteQuery(
    { limit: 10 },
    {
      getNextPageParam: (lastPage) => lastPage.nextCursor,
      initialPageParam: null,
    }
  );

  const lastPostRef = useRef<HTMLDivElement | null>(null);

  // TODO: Implement the IntersectionObserver logic here.
  // 1. Create an observer that triggers fetchNextPage when the lastPostRef element is visible.
  // 2. Ensure the observer is cleaned up properly.
  // 3. Handle the dependency array of the useEffect hook correctly.

  const posts = data ? data.pages.flatMap((page) => page.items) : [];

  return (
    <div className="space-y-4">
      {posts.map((post, index) => (
        <div
          key={post.id}
          ref={index === posts.length - 1 ? lastPostRef : null}
          className="p-4 border rounded"
        >
          <p>{post.content}</p>
          <small>{post.createdAt.toLocaleString()}</small>
        </div>
      ))}
      {isFetchingNextPage && <div>Loading more posts...</div>}
      {!hasNextPage && posts.length > 0 && <div>No more posts to load.</div>}
    </div>
  );
};
