/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part3.ts
// Description: Practical Exercises
// ==========================================

// trpc/middleware/rateLimit.ts
import { middleware } from "@trpc/server";
import { TRPCError } from "@trpc/server";

// Simulate an Edge Function call
async function checkRateLimit(ip: string): Promise<boolean> {
  // TODO: Implement mock rate limit logic.
  // 1. Use a simple in-memory Map or object to store request counts per IP.
  // 2. Allow a maximum of 10 requests per minute.
  // 3. Return true if allowed, false otherwise.
  return true;
}

export const rateLimitMiddleware = middleware(async ({ ctx, next }) => {
  // TODO: Implement the middleware logic.
  // 1. Extract IP from headers or context.
  // 2. Call checkRateLimit.
  // 3. If false, throw TRPCError with code TOO_MANY_REQUESTS.
  // 4. If true, return next() to proceed.
  return next();
});

// trpc/postRouter.ts
// ... (import statements)
export const postRouter = router({
  getInfinitePosts: publicProcedure
    .use(rateLimitMiddleware) // Apply the middleware here
    .input(/* ... */)
    .query(/* ... */),
});
