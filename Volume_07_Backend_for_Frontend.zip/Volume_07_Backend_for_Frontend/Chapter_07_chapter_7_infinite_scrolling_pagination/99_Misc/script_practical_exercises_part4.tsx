/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part4.tsx
// Description: Practical Exercises
// ==========================================

// trpc/postRouter.ts
// ... (import statements)
export const postRouter = router({
  // ... (previous procedures)
  summarizePosts: publicProcedure
    .input(z.array(z.object({ id: z.string(), content: z.string(), createdAt: z.date() })))
    .query(async ({ input }) => {
      // TODO: Implement the LLM simulation.
      // 1. Concatenate post content.
      // 2. Return a mock summary string after a delay.
    }),
});

// components/InfinitePostFeed.tsx
// ... (previous imports and logic)
export const InfinitePostFeed = () => {
  // ... (existing hooks)
  const { mutate, data: summary, isLoading } = api.post.summarizePosts.useMutation();
  
  const handleSummarize = () => {
    if (!data) return;
    const allPosts = data.pages.flatMap(page => page.items);
    // TODO: Trigger the mutation with allPosts.
  };

  return (
    <div>
      {/* ... (existing feed rendering) */}
      <button onClick={handleSummarize} disabled={isLoading}>
        {isLoading ? 'Summarizing...' : 'Summarize Feed'}
      </button>
      {summary && (
        <div className="p-4 bg-gray-100 mt-4">
          <h3>AI Summary</h3>
          <p>{summary}</p>
        </div>
      )}
    </div>
  );
};
