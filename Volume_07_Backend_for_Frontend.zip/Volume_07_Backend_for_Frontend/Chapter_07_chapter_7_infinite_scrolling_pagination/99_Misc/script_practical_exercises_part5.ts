/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part5.ts
// Description: Practical Exercises
// ==========================================

digraph G {
  rankdir=TB;
  node [shape=box, style=filled, fillcolor=lightblue];

  // Define nodes
  User [label="User Scrolling", fillcolor=lightyellow];
  Observer [label="Intersection Observer"];
  ReactComp [label="React Component (InfinitePostFeed)"];
  QueryClient [label="React Query Client"];
  TRPCClient [label="tRPC Client"];
  TRPCServer [label="tRPC Server (Router)"];
  Middleware [label="Rate Limit Middleware"];
  EdgeFunc [label="Edge Function (Rate Check)"];
  DB [label="Database / Mock Data", shape=cylinder, fillcolor=lightgrey];
  Response [label="Response (items, nextCursor)"];

  // Define edges
  User -> Observer [label="Scroll into view"];
  Observer -> ReactComp [label="trigger()"];
  ReactComp -> QueryClient [label="fetchNextPage()"];
  QueryClient -> TRPCClient [label="execute query"];
  TRPCClient -> TRPCServer [label="request (cursor, limit)"];
  TRPCServer -> Middleware [label="pre-process"];
  Middleware -> EdgeFunc [label="check(ip)"];
  
  // Conditional edges for rate limit
  EdgeFunc -> Middleware [label="Allowed"];
  EdgeFunc -> TRPCServer [label="Too Many Requests" style=dashed color=red];
  TRPCServer -> DB [label="query (cursor, limit)"];
  DB -> TRPCServer [label="raw data"];
  TRPCServer -> Response [label="format & return"];
  Response -> TRPCClient [label="data"];
  TRPCClient -> QueryClient [label="update cache"];
  QueryClient -> ReactComp [label="re-render with new data"];
}
