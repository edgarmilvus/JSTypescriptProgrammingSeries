/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

// src/hooks/useRealtimeTasks.ts

import { useEffect, useState } from 'react';
import { createClient, SupabaseClient, RealtimeChannel } from '@supabase/supabase-js';

// 1. CONFIGURATION
// In a real app, load these from environment variables (.env.local)
const SUPABASE_URL = 'https://your-project-ref.supabase.co';
const SUPABASE_ANON_KEY = 'your-anon-public-key';

// 2. TYPE DEFINITIONS
// Defines the shape of our database table 'tasks'
interface Task {
  id: string;
  title: string;
  status: 'pending' | 'done';
  inserted_at: string;
}

// Defines the shape of the Realtime event payload
interface RealtimePayload {
  eventType: 'INSERT' | 'UPDATE' | 'DELETE';
  new: Task | null;
  old: { id: string } | null;
}

/**
 * A custom hook to manage a Realtime subscription to the 'tasks' table.
 * It handles connection setup, event filtering, and state updates.
 */
const useRealtimeTasks = () => {
  const [tasks, setTasks] = useState<Task[]>([]);
  const [channel, setChannel]<RealtimeChannel | null>(null);
  const [error, setError] = useState<string | null>(null);

  // Initialize Supabase Client
  const supabase: SupabaseClient = createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

  useEffect(() => {
    /**
     * 3. CHANNEL SETUP
     * Create a dedicated channel for the 'tasks' table.
     * 'schema': public
     * 'table': tasks
     * 'event': '*' (listen for all events: INSERT, UPDATE, DELETE)
     */
    const taskChannel = supabase
      .channel('public:tasks')
      .on(
        'postgres_changes',
        {
          event: '*', // Listen for all changes
          schema: 'public',
          table: 'tasks',
        },
        (payload: RealtimePayload) => {
          // 4. DATA TRANSFORMATION & STATE UPDATE
          handleRealtimeEvent(payload);
        }
      )
      .subscribe((status) => {
        // Handle connection status changes
        if (status === 'SUBSCRIBED') {
          console.log('Realtime connection established.');
          setError(null);
        }
        if (status === 'CHANNEL_ERROR') {
          setError('Failed to connect to Realtime server.');
        }
      });

    setChannel(taskChannel);

    // 5. CLEANUP
    // Unsubscribe when the component unmounts to prevent memory leaks
    return () => {
      if (taskChannel) {
        supabase.removeChannel(taskChannel);
      }
    };
  }, []); // Run once on mount

  /**
   * 6. EVENT HANDLER LOGIC
   * Pure function to determine how to update state based on event type.
   */
  const handleRealtimeEvent = (payload: RealtimePayload) => {
    const { eventType, new: newTask, old: oldTask } = payload;

    switch (eventType) {
      case 'INSERT':
        if (newTask) {
          // Append new task to the beginning of the list
          setTasks((prev) => [newTask, ...prev]);
        }
        break;

      case 'UPDATE':
        if (newTask) {
          // Map over existing tasks and replace the updated one
          setTasks((prev) =>
            prev.map((task) => (task.id === newTask.id ? newTask : task))
          );
        }
        break;

      case 'DELETE':
        if (oldTask) {
          // Filter out the deleted task by ID
          setTasks((prev) => prev.filter((task) => task.id !== oldTask.id));
        }
        break;

      default:
        console.warn('Unknown event type:', eventType);
    }
  };

  return { tasks, error };
};

// --- MOCK IMPLEMENTATION FOR DEMONSTRATION PURPOSES ---
// In a real app, this would be a separate component consuming the hook.

/**
 * Dashboard Component
 * Renders the list of tasks and displays real-time updates.
 */
export const TaskDashboard = () => {
  const { tasks, error } = useRealtimeTasks();

  if (error) {
    return <div style={{ color: 'red' }}>Error: {error}</div>;
  }

  return (
    <div style={{ padding: '20px', fontFamily: 'sans-serif' }}>
      <h2>Live Task Dashboard</h2>
      <p>Open this in two tabs. Add a task in one, and it appears instantly in the other.</p>
      
      <ul>
        {tasks.length === 0 ? (
          <li>No tasks yet. Waiting for database changes...</li>
        ) : (
          tasks.map((task) => (
            <li key={task.id} style={{ marginBottom: '10px', padding: '10px', border: '1px solid #eee' }}>
              <strong>{task.title}</strong> - 
              <span style={{ color: task.status === 'done' ? 'green' : 'orange' }}>
                {' '}{task.status.toUpperCase()}
              </span>
            </li>
          ))
        )}
      </ul>
    </div>
  );
};
