/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.tsx
// Description: Advanced Application Script
// ==========================================

// app/components/LiveDocumentEditor.tsx
import React, { useEffect, useRef, useState, useMemo } from 'react';
import { createClient, RealtimeChannel, SupabaseClient } from '@supabase/supabase-js';
import { trpc } from '../utils/trpc'; // Assuming a standard tRPC client setup
import { WorkerType } from '../workers/dataProcessor'; // Reference to our Web Worker

// ============================================================================
// 1. CONFIGURATION & TYPES
// ============================================================================

const SUPABASE_URL = process.env.NEXT_PUBLIC_SUPABASE_URL!;
const SUPABASE_ANON_KEY = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!;

// Type inference for our document structure
type DocumentContent = {
  id: string;
  content: string;
  last_updated_by: string;
  version: number;
};

// Payload structure for LLM transformation
type LLMPayload = {
  documentId: string;
  summary: string;
  sentiment: 'positive' | 'negative' | 'neutral';
  tokens: number;
};

// ============================================================================
// 2. WEB WORKER SETUP (Simulating SharedArrayBuffer Efficiency)
// ============================================================================

/**
 * Creates an inline Web Worker to handle heavy data transformation off the main thread.
 * This mimics the non-blocking I/O paradigm required for high-frequency real-time events.
 * In a production environment, this would be a separate file loaded via Worker constructor.
 */
const createWorker = () => {
  const workerCode = `
    self.onmessage = function(e) {
      const { content, documentId } = e.data;
      
      // Simulate heavy computation (e.g., token counting, regex parsing)
      // This would block the main thread if executed directly in the component
      const tokens = content.split(' ').length;
      const sentimentScore = content.length > 0 ? (content.includes('!') ? 'positive' : 'neutral') : 'neutral';
      
      const result = {
        documentId,
        summary: content.substring(0, 100) + '...',
        sentiment: sentimentScore,
        tokens: tokens
      };
      
      self.postMessage(result);
    };
  `;
  
  const blob = new Blob([workerCode], { type: 'application/javascript' });
  return new Worker(URL.createObjectURL(blob));
};

// ============================================================================
// 3. THE COMPONENT: LIVE EDITOR WITH REALTIME SYNC
// ============================================================================

/**
 * LiveDocumentEditor Component
 * 
 * Integrates Supabase Realtime listeners directly into a tRPC context.
 * Uses a Web Worker to process data streams without blocking the UI thread.
 */
export const LiveDocumentEditor: React.FC<{ documentId: string }> = ({ documentId }) => {
  const [content, setContent] = useState('');
  const [status, setStatus] = useState<'idle' | 'syncing' | 'error'>('idle');
  const [llmData, setLlmData] = useState<LLMPayload | null>(null);

  // References for Supabase channel and Web Worker
  const channelRef = useRef<RealtimeChannel | null>(null);
  const workerRef = useRef<Worker | null>(null);

  // Initialize Web Worker
  useEffect(() => {
    workerRef.current = createWorker();
    
    // Listen for processed data from the worker
    workerRef.current.onmessage = (e: MessageEvent<LLMPayload>) => {
      setLlmData(e.data);
      console.log('Data processed by Worker (Non-Blocking):', e.data);
    };

    return () => {
      workerRef.current?.terminate();
    };
  }, []);

  // Initialize Supabase Realtime Channel
  useEffect(() => {
    const supabase: SupabaseClient = createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

    // Subscribe to changes in the 'documents' table for the specific ID
    channelRef.current = supabase
      .channel(`document:${documentId}`)
      .on(
        'postgres_changes',
        {
          event: '*', // Listen for INSERT, UPDATE, DELETE
          schema: 'public',
          table: 'documents',
          filter: `id=eq.${documentId}`,
        },
        (payload) => {
          // CRITICAL: This callback runs on the main thread.
          // We must minimize work here. We immediately offload processing.
          
          const newContent = (payload.new as DocumentContent)?.content || '';
          setContent(newContent);

          // Offload to Worker for heavy processing (LLM prep)
          if (workerRef.current) {
            workerRef.current.postMessage({
              content: newContent,
              documentId: documentId,
            });
          }
        }
      )
      .subscribe((status) => {
        setStatus(status as any); // Handle subscription status
      });

    return () => {
      if (channelRef.current) supabase.removeChannel(channelRef.current);
    };
  }, [documentId]);

  // 4. TRPC INTEGRATION FOR WRITES
  // ============================================================================

  // tRPC mutation to update the document (triggering the realtime listener above)
  const updateDocument = trpc.updateDocumentContent.useMutation({
    onMutate: () => setStatus('syncing'),
    onSuccess: () => setStatus('idle'),
    onError: () => setStatus('error'),
  });

  const handleInputChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    const val = e.target.value;
    setContent(val);
    
    // Debounce or trigger tRPC mutation here
    updateDocument.mutate({ id: documentId, content: val });
  };

  // 5. LLM DATA PREPARATION (EDGE FUNCTION CONTEXT)
  // ============================================================================

  /**
   * Prepares the transformed data for an LLM.
   * In a real app, this would be sent to a Next.js Edge Function 
   * which formats the prompt for an LLM API (e.g., OpenAI).
   */
  const prepareLLMContext = () => {
    if (!llmData) return "Waiting for data...";
    
    return `
      SYSTEM PROMPT: Analyze the following document update.
      DOCUMENT ID: ${llmData.documentId}
      SUMMARY: ${llmData.summary}
      SENTIMENT: ${llmData.sentiment}
      TOKEN COUNT: ${llmData.tokens}
    `;
  };

  return (
    <div style={{ padding: '20px', fontFamily: 'monospace', maxWidth: '600px' }}>
      <h2>Live Document Editor</h2>
      
      <div style={{ marginBottom: '10px', fontSize: '12px', color: '#666' }}>
        Status: <strong>{status}</strong> | 
        Workers Active: {workerRef.current ? 'Yes' : 'No'}
      </div>

      <textarea
        value={content}
        onChange={handleInputChange}
        rows={10}
        style={{ width: '100%', padding: '10px', marginBottom: '20px' }}
        placeholder="Type here... changes will broadcast to all listeners."
      />

      <div style={{ background: '#f0f0f0', padding: '10px', borderRadius: '4px' }}>
        <h3>LLM Context Payload (Worker Output)</h3>
        <pre style={{ whiteSpace: 'pre-wrap', fontSize: '11px' }}>
          {prepareLLMContext()}
        </pre>
      </div>

      <button 
        onClick={() => updateDocument.mutate({ id: documentId, content: '' })}
        style={{ marginTop: '10px', padding: '5px 10px' }}
      >
        Clear Document
      </button>
    </div>
  );
};
