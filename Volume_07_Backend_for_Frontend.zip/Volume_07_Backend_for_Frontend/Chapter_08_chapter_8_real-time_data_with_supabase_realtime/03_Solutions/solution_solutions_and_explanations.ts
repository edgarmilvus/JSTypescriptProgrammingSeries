/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

import { useEffect, useState, useRef } from 'react';
import { RealtimeChannel, SupabaseClient } from '@supabase/supabase-js';

// Define the shape of the presence state
interface PresenceState {
  user_id: string;
  name: string;
  status: 'editing' | 'viewing';
}

// Define the props for the component
interface ActiveUsersListProps {
  supabase: SupabaseClient;
  documentId: string;
  currentUser: PresenceState; // The user viewing this component
}

export const ActiveUsersList = ({ supabase, documentId, currentUser }: ActiveUsersListProps) => {
  const [activeUsers, setActiveUsers] = useState<PresenceState[]>([]);
  const channelRef = useRef<RealtimeChannel | null>(null);

  useEffect(() => {
    // 1. Initialize the channel
    const channel = supabase.channel(`document_presence:${documentId}`, {
      config: {
        presence: {
          key: currentUser.user_id, // Unique key for the user
        },
      },
    });

    // 2. Track the current user's state when they join
    channel.on('presence', { event: 'sync' }, () => {
      const rawState = channel.presenceState();
      
      // Map over the presence state to extract user details
      // The structure is Record<string, PresenceState[]>
      const users: PresenceState[] = [];
      
      // Iterate through the keys in the presence state
      for (const key in rawState) {
        // rawState[key] is an array of PresenceState objects
        // We take the first one (since we used a unique key per user)
        const user = rawState[key][0];
        if (user) {
          users.push(user);
        }
      }

      // Filter out the current user if desired, or include them
      setActiveUsers(users);
    });

    // 3. Subscribe to the channel and track initial state
    channel.subscribe(async (status) => {
      if (status === 'SUBSCRIBED') {
        await channel.track(currentUser);
      }
    });

    // Store in ref for cleanup
    channelRef.current = channel;

    // 4. Cleanup on unmount
    return () => {
      if (channelRef.current) {
        channelRef.current.unsubscribe();
      }
    };
  }, [supabase, documentId, currentUser]);

  return (
    <div className="active-users-container">
      <h3>Active Users ({activeUsers.length})</h3>
      <ul>
        {activeUsers.map((user) => (
          <li key={user.user_id}>
            <span>{user.name}</span> - 
            <span style={{ color: user.status === 'editing' ? 'green' : 'gray' }}>
              {user.status}
            </span>
          </li>
        ))}
      </ul>
    </div>
  );
};
