/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

import { useEffect, useState } from 'react';
import { SupabaseClient } from '@supabase/supabase-js';

// Define the Task interface
interface Task {
  id: string;
  title: string;
  status: string;
  project_id: string;
}

interface DashboardProps {
  supabase: SupabaseClient;
  projectId: string;
  userId: string;
}

export const TaskDashboard = ({ supabase, projectId, userId }: DashboardProps) => {
  const [tasks, setTasks] = useState<Task[]>([]);

  useEffect(() => {
    // 1. Initial Fetch (to populate the dashboard initially)
    const fetchInitialTasks = async () => {
      const { data, error } = await supabase
        .from('tasks')
        .select('*')
        .eq('project_id', projectId);

      if (!error && data) {
        setTasks(data);
      }
    };
    fetchInitialTasks();

    // 2. Channel Setup
    // Note: We filter on project_id in the channel name to scope updates
    const channel = supabase.channel(`tasks_updates:${projectId}`);

    // 3. Subscribe to INSERT events
    channel.on('postgres_changes', 
      { event: 'INSERT', schema: 'public', table: 'tasks', filter: `project_id=eq.${projectId}` },
      (payload) => {
        // Add new task to state
        const newTask = payload.new as Task;
        setTasks((prev) => [...prev, newTask]);
      }
    );

    // 4. Subscribe to UPDATE events
    channel.on('postgres_changes', 
      { event: 'UPDATE', schema: 'public', table: 'tasks', filter: `project_id=eq.${projectId}` },
      (payload) => {
        // Update existing task in state
        const updatedTask = payload.new as Task;
        setTasks((prev) => 
          prev.map((task) => (task.id === updatedTask.id ? updatedTask : task))
        );
      }
    );

    // 5. Subscribe to DELETE events (Best Practice)
    channel.on('postgres_changes', 
      { event: 'DELETE', schema: 'public', table: 'tasks', filter: `project_id=eq.${projectId}` },
      (payload) => {
        const deletedTask = payload.old as Task;
        setTasks((prev) => prev.filter((task) => task.id !== deletedTask.id));
      }
    );

    channel.subscribe();

    // Cleanup
    return () => {
      supabase.removeChannel(channel);
    };
  }, [supabase, projectId]);

  return (
    <div>
      <h2>Project Tasks</h2>
      <ul>
        {tasks.map((task) => (
          <li key={task.id}>
            {task.title} - {task.status}
          </li>
        ))}
      </ul>
    </div>
  );
};

/*
 * RLS Policy Logic (Conceptual):
 * For this to work securely, the following RLS policies must exist on the `tasks` table:
 *
 * 1. Enable Realtime: ALTER TABLE tasks ENABLE ROW LEVEL SECURITY;
 *
 * 2. Read Policy (SELECT):
 *    CREATE POLICY "Read Project Tasks" ON tasks FOR SELECT USING (
 *      EXISTS (
 *        SELECT 1 FROM project_members 
 *        WHERE project_id = tasks.project_id AND user_id = auth.uid()
 *      )
 *    );
 *
 * 3. Write Policies (INSERT/UPDATE):
 *    Similar logic ensuring the user is a member of the project.
 *    Note: Supabase Realtime broadcasts changes ONLY if the user has SELECT permission 
 *    via RLS on the specific row being changed.
 */
