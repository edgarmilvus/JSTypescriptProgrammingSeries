/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useEffect, useState, useRef } from 'react';
import { SupabaseClient } from '@supabase/supabase-js';

// Define the Message interface
interface Message {
  id: string;
  content: string;
  sender_name: string;
  created_at: string;
  room_id: string;
}

interface ChatRoomProps {
  supabase: SupabaseClient;
  roomId: string;
}

export const ChatRoom = ({ supabase, roomId }: ChatRoomProps) => {
  const [messages, setMessages] = useState<Message[]>([]);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // 1. Setup Realtime Subscription
    const channel = supabase.channel(`chat_room:${roomId}`);

    // 2. Listen for INSERT events only
    channel.on('postgres_changes', 
      { event: 'INSERT', schema: 'public', table: 'chat_messages', filter: `room_id=eq.${roomId}` },
      (payload) => {
        // 3. Type casting for the payload
        const newMessage = payload.new as Message;
        
        // 4. Append to state
        setMessages((prevMessages) => [...prevMessages, newMessage]);
      }
    );

    // Subscribe
    channel.subscribe();

    // Cleanup
    return () => {
      supabase.removeChannel(channel);
    };
  }, [supabase, roomId]);

  // Auto-scroll to bottom when new messages arrive
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  return (
    <div className="chat-container" style={{ height: '400px', overflowY: 'scroll', border: '1px solid #ccc' }}>
      <div className="messages-list">
        {messages.map((msg) => (
          <div key={msg.id} className="message" style={{ marginBottom: '8px' }}>
            <strong>{msg.sender_name}:</strong> {msg.content}
            <small style={{ color: 'gray', marginLeft: '8px' }}>
              {new Date(msg.created_at).toLocaleTimeString()}
            </small>
          </div>
        ))}
        <div ref={messagesEndRef} />
      </div>
    </div>
  );
};
