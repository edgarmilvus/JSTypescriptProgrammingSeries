/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

// Edge Function (Deno runtime in Supabase)
// File: supabase/functions/price-stream/index.ts

import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

// Define the raw incoming structure
interface RawPriceUpdate {
  symbol: string;
  price: number;
  timestamp: string;
  volume: number; // Not needed by client
  metadata: any; // Not needed by client
}

// Define the transformed structure sent to client
interface TransformedPrice {
  symbol: string;
  price: number;
  timestamp: string;
  price_change_percentage: number; // Derived field
}

serve(async (req) => {
  // Check for the API key (standard Edge Function auth)
  const { apiKey } = await req.json();
  
  // Create Supabase client inside the Edge Function
  const supabaseClient = createClient(
    Deno.env.get("SUPABASE_URL") ?? "",
    Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "" // Use Service Role to bypass RLS
  );

  // 1. Subscribe to Realtime Channel
  const channel = supabaseClient.channel('price_updates_edge_proxy')
    .on('postgres_changes', 
      { event: 'INSERT', schema: 'public', table: 'price_updates' },
      (payload) => {
        const raw = payload.new as RawPriceUpdate;

        // 2. Data Transformation
        // Calculate derived field (mock logic: assuming a base price for calc)
        const basePrice = 100; 
        const change = ((raw.price - basePrice) / basePrice) * 100;

        const transformed: TransformedPrice = {
          symbol: raw.symbol,
          price: raw.price,
          timestamp: raw.timestamp,
          price_change_percentage: parseFloat(change.toFixed(2)),
        };

        // 3. Stream to Client (SSE)
        // In a real implementation, we would write to the SSE stream response
        // For this example, we simulate sending the data back
        // (Note: In a real SSE setup, we maintain the connection and write to it)
      }
    )
    .subscribe();

  // Return a dummy response (Real implementation would return a ReadableStream)
  return new Response(JSON.stringify({ status: "Listening for price updates..." }), {
    headers: { "Content-Type": "application/json" },
  });
});

/*
 * CLIENT CONSUMPTION (Conceptual)
 * 
 * The client would not use standard Supabase listeners. Instead:
 * 
 * const eventSource = new EventSource('/functions/v1/price-stream');
 * 
 * eventSource.onmessage = (event) => {
 *   const data: TransformedPrice = JSON.parse(event.data);
 *   // Update UI immediately with lightweight data
 *   updateDashboard(data);
 * };
 */
