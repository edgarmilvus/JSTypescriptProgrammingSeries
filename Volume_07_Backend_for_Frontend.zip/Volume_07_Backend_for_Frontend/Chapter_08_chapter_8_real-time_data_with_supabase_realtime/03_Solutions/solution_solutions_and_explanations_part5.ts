/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

import { useEffect, useRef, useState } from 'react';
import { SupabaseClient } from '@supabase/supabase-js';
import throttle from 'lodash.throttle'; // Assuming lodash is installed

// Define the Cursor State
interface CursorState {
  x: number;
  y: number;
  userId: string;
  color: string;
}

interface CanvasProps {
  supabase: SupabaseClient;
  roomId: string;
  currentUser: { id: string; name: string; color: string };
}

export const CollaborativeCanvas = ({ supabase, roomId, currentUser }: CanvasProps) => {
  const [cursors, setCursors] = useState<Record<string, CursorState>>({});
  const canvasRef = useRef<HTMLDivElement>(null);
  const channelRef = useRef<any>(null);

  // 1. Throttling Mechanism
  // We throttle the update function to send max 1 update every 50ms
  const updateCursor = useRef(
    throttle((x: number, y: number, channel: any) => {
      channel.track({
        x,
        y,
        userId: currentUser.id,
        color: currentUser.color,
      } as CursorState);
    }, 50)
  ).current;

  useEffect(() => {
    const channel = supabase.channel(`canvas:${roomId}`, {
      config: {
        presence: {
          key: currentUser.id,
        },
      },
    });

    // 2. Receiving Updates
    channel.on('presence', { event: 'sync' }, () => {
      const state = channel.presenceState();
      const newCursors: Record<string, CursorState> = {};

      for (const key in state) {
        // key is the userId
        const cursorData = state[key][0] as CursorState;
        if (cursorData) {
          newCursors[key] = cursorData;
        }
      }

      setCursors(newCursors);
    });

    // 3. Broadcasting Movements
    const handleMouseMove = (e: MouseEvent) => {
      if (!canvasRef.current || !channel) return;
      
      // Calculate relative coordinates
      const rect = canvasRef.current.getBoundingClientRect();
      const x = e.clientX - rect.left;
      const y = e.clientY - rect.top;

      // Call throttled function
      updateCursor(x, y, channel);
    };

    // 4. Cleanup Handling (Disconnect)
    // We track unsubscribe to remove cursor immediately
    const handleBeforeUnload = () => {
      channel.unsubscribe();
    };
    window.addEventListener('beforeunload', handleBeforeUnload);

    // Setup listeners
    const currentCanvas = canvasRef.current;
    if (currentCanvas) {
      currentCanvas.addEventListener('mousemove', handleMouseMove);
    }

    channel.subscribe(async (status) => {
      if (status === 'SUBSCRIBED') {
        await channel.track({
          x: 0, y: 0, userId: currentUser.id, color: currentUser.color
        } as CursorState);
      }
    });

    channelRef.current = channel;

    // 5. Rendering Cursors
    // We render them as absolute divs over the canvas
    // (CSS would handle the absolute positioning based on x/y)

    return () => {
      if (currentCanvas) {
        currentCanvas.removeEventListener('mousemove', handleMouseMove);
      }
      window.removeEventListener('beforeunload', handleBeforeUnload);
      if (channelRef.current) {
        channelRef.current.unsubscribe();
      }
    };
  }, [supabase, roomId, currentUser.id]);

  return (
    <div 
      ref={canvasRef} 
      style={{ position: 'relative', width: '100%', height: '500px', border: '1px solid black', overflow: 'hidden' }}
    >
      <p>Move your mouse here!</p>
      
      {/* Render Remote Cursors */}
      {Object.values(cursors).map((cursor) => (
        cursor.userId !== currentUser.id && (
          <div
            key={cursor.userId}
            style={{
              position: 'absolute',
              left: cursor.x,
              top: cursor.y,
              width: '12px',
              height: '12px',
              backgroundColor: cursor.color,
              borderRadius: '50%',
              transform: 'translate(-50%, -50%)',
              pointerEvents: 'none',
              transition: 'left 0.1s ease, top 0.1s ease', // Smooth interpolation
            }}
            title={`User ${cursor.userId}`}
          />
        )
      ))}
    </div>
  );
};
