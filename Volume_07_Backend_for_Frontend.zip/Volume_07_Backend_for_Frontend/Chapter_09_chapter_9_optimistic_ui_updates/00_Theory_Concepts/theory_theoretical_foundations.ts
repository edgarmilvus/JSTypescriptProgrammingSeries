/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: theory_theoretical_foundations.ts
// Description: Theoretical Foundations
// ==========================================

// Conceptual usage of useTransition with Optimistic Updates
import { useTransition } from 'react';
import { trpc } from './trpc';

const LikeButton = ({ postId }: { postId: string }) => {
    const [isPending, startTransition] = useTransition();
    const utils = trpc.useUtils();

    const likeMutation = trpc.post.like.useMutation({
        onMutate: async (newData) => {
            // 1. Snapshot previous state
            const previousPosts = utils.post.getPosts.getData();
            
            // 2. Optimistic Update
            utils.post.getPosts.setData(undefined, (old) => {
                // Logic to increment likes immediately
                return old?.map(p => p.id === postId ? { ...p, likes: p.likes + 1 } : p);
            });

            return { previousPosts };
        },
        onError: (err, newData, context) => {
            // 3. Rollback on error
            if (context?.previousPosts) {
                utils.post.getPosts.setData(undefined, context.previousPosts);
            }
        },
        onSettled: () => {
            // 4. Refetch to ensure server consistency
            utils.post.getPosts.invalidate();
        },
    });

    const handleClick = () => {
        // Wrap the state update in a transition
        startTransition(() => {
            likeMutation.mutate({ postId });
        });
    };

    return (
        <button onClick={handleClick} disabled={isPending}>
            {isPending ? 'Liking...' : 'Like'}
        </button>
    );
};
