/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.tsx
// Description: Basic Code Example
// ==========================================

// frontend/components/LikeButton.tsx
import React, { useState } from 'react';
import { trpc } from '../utils/trpc'; // Standard tRPC client setup

/**
 * Props for the LikeButton component.
 * @property postId - The unique identifier of the post being liked.
 * @property initialLikes - The starting number of likes.
 */
interface LikeButtonProps {
  postId: string;
  initialLikes: number;
}

/**
 * A component demonstrating optimistic UI updates for a "Like" action.
 * 
 * @remarks
 * This component handles:
 * 1. Immediate visual feedback (optimistic update).
 * 2. Background server synchronization via tRPC.
 * 3. Automatic rollback on error.
 */
export const LikeButton: React.FC<LikeButtonProps> = ({ postId, initialLikes }) => {
  // 1. Local state for immediate UI reflection (Optimistic State)
  const [localLikes, setLocalLikes] = useState(initialLikes);

  // 2. Access the tRPC mutation hook
  const likeMutation = trpc.post.like.useMutation({
    // 3. ON MUTATE: Runs immediately before the mutation fires.
    // This is where we implement the optimistic update.
    onMutate: async (variables) => {
      // Cancel any outgoing refetches (so we don't overwrite our optimistic update)
      await trpc.post.getLikes.cancel();

      // Snapshot the previous value in case we need to rollback
      const previousLikes = trpc.post.getLikes.getData();

      // Optimistically update the local state
      setLocalLikes((prev) => prev + 1);

      // Return context object with the snapshot for error handling
      return { previousLikes };
    },

    // 4. ON ERROR: Runs if the server request fails.
    // We use the context returned from onMutate to rollback.
    onError: (err, variables, context) => {
      if (context?.previousLikes) {
        // Revert the local state to the snapshot
        setLocalLikes(context.previousLikes);
      }
      
      // Optional: Show a toast notification
      console.error("Failed to like post:", err.message);
    },

    // 5. ON SETTLED: Runs regardless of success or error.
    // Good for refetching to ensure UI is in sync with server.
    onSettled: () => {
      trpc.post.getLikes.invalidate();
    },
  });

  const handleClick = () => {
    // Trigger the mutation with the post ID
    likeMutation.mutate({ postId });
  };

  return (
    <button 
      onClick={handleClick} 
      disabled={likeMutation.isPending} // Prevent double clicks
      className="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600"
    >
      ❤️ {localLikes} {likeMutation.isPending ? '(Saving...)' : ''}
    </button>
  );
};
