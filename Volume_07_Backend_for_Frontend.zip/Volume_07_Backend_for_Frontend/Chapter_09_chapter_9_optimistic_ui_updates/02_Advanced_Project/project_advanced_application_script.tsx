/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.tsx
// Description: Advanced Application Script
// ==========================================

import React, { useState } from 'react';
import { useMutation, useQueryClient } from '@tanstack/react-query';

// --- MOCKED INFRASTRUCTURE (Simulating tRPC & Backend) ---

// Type definitions for our Kanban domain
type TaskStatus = 'todo' | 'in-progress' | 'done';
interface Task {
  id: string;
  title: string;
  status: TaskStatus;
  summary?: string; // Populated by LLM later
  updatedAt: number;
}

// Mock API delay to simulate network latency
const simulateNetworkLatency = (ms: number) => new Promise(res => setTimeout(res, ms));

/**
 * Simulates an Edge Function call that validates the move and triggers an LLM
 * to generate a smart summary of the task based on its new context.
 */
const mockEdgeFunctionCall = async (taskId: string, newStatus: TaskStatus): Promise<{ summary: string }> => {
  await simulateNetworkLatency(1500); // Simulate 1.5s latency for validation + LLM inference
  
  // Simulate LLM transformation logic
  const summaries = {
    'todo': 'Task moved to backlog. Prioritize based on dependencies.',
    'in-progress': 'Task is actively being worked on. Focus on completion.',
    'done': 'Task completed successfully. Verify with QA.'
  };
  
  return { summary: summaries[newStatus] };
};

// --- REACT COMPONENT ---

export default function KanbanBoard() {
  const queryClient = useQueryClient();
  
  // Local state to simulate the initial data fetch (normally from useQuery)
  const [tasks, setTasks] = useState<Task[]>([
    { id: '1', title: 'Fix Login Bug', status: 'todo', updatedAt: Date.now() },
    { id: '2', title: 'Design Home Page', status: 'in-progress', updatedAt: Date.now() },
  ]);

  /**
   * Mutation Hook for moving tasks.
   * Integrates Optimistic UI patterns via callbacks.
   */
  const moveTaskMutation = useMutation({
    mutationFn: ({ taskId, newStatus }: { taskId: string; newStatus: TaskStatus }) => 
      mockEdgeFunctionCall(taskId, newStatus),

    // 1. ON MUTATE: The Optimistic Update
    // This fires immediately before the server request. We update local state
    // to make the UI feel instant.
    onMutate: async ({ taskId, newStatus }) => {
      // Cancel outgoing refetches to avoid overwriting our optimistic update
      await queryClient.cancelQueries({ queryKey: ['tasks'] });

      // Snapshot the previous value for rollback purposes
      const previousTasks = queryClient.getQueryData<Task[]>(['tasks']);

      // Optimistically update the local state
      setTasks((prev) =>
        prev.map((task) =>
          task.id === taskId ? { ...task, status: newStatus, updatedAt: Date.now() } : task
        )
      );

      // Return a context object containing the snapshot
      return { previousTasks };
    },

    // 2. ON ERROR: The Rollback
    // If the Edge Function fails (e.g., validation error), revert to the snapshot.
    onError: (err, variables, context) => {
      if (context?.previousTasks) {
        setTasks(context.previousTasks);
        alert('Move failed! Reverting changes.');
      }
    },

    // 3. ON SETTLED: Cache Invalidation & Real Data Integration
    // This runs whether the mutation succeeds or fails. 
    // Here we integrate the LLM response (the "confirmed state").
    onSettled: (data, error, variables) => {
      if (data && !error) {
        // Update the state with the "confirmed" data from the LLM/Edge Function
        setTasks((prev) =>
          prev.map((task) =>
            task.id === variables.taskId 
              ? { ...task, summary: data.summary } // Merge the LLM payload
              : task
          )
        );
      }
      // Refetch to ensure we are in sync with the server "source of truth"
      queryClient.invalidateQueries({ queryKey: ['tasks'] });
    },
  });

  // Helper to trigger the mutation
  const handleDragEnd = (taskId: string, targetStatus: TaskStatus) => {
    moveTaskMutation.mutate({ taskId, newStatus: targetStatus });
  };

  return (
    <div style={styles.board}>
      <h2>Project Board (Optimistic UI Demo)</h2>
      <div style={styles.columns}>
        {(['todo', 'in-progress', 'done'] as TaskStatus[]).map((status) => (
          <Column 
            key={status} 
            status={status} 
            tasks={tasks.filter(t => t.status === status)} 
            onMove={handleDragEnd}
            isMutating={moveTaskMutation.isPending}
          />
        ))}
      </div>
      {moveTaskMutation.isPending && <p style={styles.loader}>Saving changes...</p>}
    </div>
  );
}

// --- SUBCOMPONENTS ---

interface ColumnProps {
  status: TaskStatus;
  tasks: Task[];
  onMove: (id: string, status: TaskStatus) => void;
  isMutating: boolean;
}

const Column: React.FC<ColumnProps> = ({ status, tasks, onMove, isMutating }) => {
  return (
    <div style={styles.column}>
      <h3 style={styles.columnHeader}>{status.toUpperCase()}</h3>
      <div style={styles.taskList}>
        {tasks.map((task) => (
          <div key={task.id} style={styles.card}>
            <strong>{task.title}</strong>
            <div style={styles.meta}>
              {/* Show loading indicator specifically for the mutating card */}
              {isMutating && <span style={styles.spinner}>●</span>}
            </div>
            {task.summary && (
              <div style={styles.summary}>
                AI Summary: {task.summary}
              </div>
            )}
            <div style={styles.controls}>
              {status !== 'todo' && (
                <button onClick={() => onMove(task.id, 'todo')}>To Todo</button>
              )}
              {status !== 'in-progress' && (
                <button onClick={() => onMove(task.id, 'in-progress')}>To Progress</button>
              )}
              {status !== 'done' && (
                <button onClick={() => onMove(task.id, 'done')}>To Done</button>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

// --- STYLES (Inline for portability) ---
const styles: Record<string, React.CSSProperties> = {
  board: { fontFamily: 'sans-serif', padding: '20px', maxWidth: '1000px', margin: '0 auto' },
  columns: { display: 'flex', gap: '20px' },
  column: { flex: 1, backgroundColor: '#f4f5f7', padding: '10px', borderRadius: '8px' },
  columnHeader: { marginTop: 0, borderBottom: '2px solid #ddd', paddingBottom: '10px' },
  taskList: { minHeight: '200px' },
  card: { 
    backgroundColor: 'white', 
    padding: '15px', 
    marginBottom: '10px', 
    borderRadius: '4px', 
    boxShadow: '0 1px 3px rgba(0,0,0,0.12)',
    transition: 'transform 0.2s ease' // Subtle animation for optimistic feel
  },
  meta: { fontSize: '0.8rem', color: '#666', minHeight: '20px' },
  summary: { 
    marginTop: '10px', 
    padding: '8px', 
    backgroundColor: '#e6fffa', 
    borderLeft: '3px solid #00bfa5', 
    fontSize: '0.85rem',
    fontStyle: 'italic'
  },
  controls: { marginTop: '10px', display: 'flex', gap: '5px' },
  loader: { position: 'fixed', bottom: '20px', right: '20px', background: '#333', color: '#fff', padding: '10px' },
  spinner: { color: '#0052cc', fontWeight: 'bold', animation: 'pulse 1s infinite' }
};
