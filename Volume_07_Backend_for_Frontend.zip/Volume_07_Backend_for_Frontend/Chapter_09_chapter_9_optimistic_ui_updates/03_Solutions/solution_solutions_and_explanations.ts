/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// File: src/components/Chat.tsx
import { useState } from 'react';
import { useMutation, useQueryClient } from '@tanstack/react-query';

type Message = {
  id: string;
  text: string;
  status: 'pending' | 'sent' | 'failed';
};

// Mock API function (replace with actual tRPC call)
const mockSendMessage = async (text: string): Promise<Message> => {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      // Simulate 10% failure rate
      if (Math.random() < 0.1) {
        reject(new Error('Server error'));
      } else {
        resolve({ id: Math.random().toString(), text, status: 'sent' });
      }
    }, 600); // Simulated latency
  });
};

export const ChatComponent = () => {
  const [inputText, setInputText] = useState('');
  const queryClient = useQueryClient();
  
  // 1. Refactor the Mutation with Optimistic Logic
  const mutation = useMutation({
    mutationFn: (text: string) => mockSendMessage(text),
    
    // 2. Optimistic Update: Run immediately before server responds
    onMutate: async (text) => {
      // Cancel outgoing refetches to avoid overwriting our optimistic update
      await queryClient.cancelQueries({ queryKey: ['messages'] });
      
      // Snapshot the previous value
      const previousMessages = queryClient.getQueryData<Message[]>(['messages']);
      
      // Optimistically update to the new value
      const optimisticMessage: Message = {
        id: 'temp-id', // Temporary ID
        text,
        status: 'pending',
      };
      
      if (previousMessages) {
        queryClient.setQueryData<Message[]>(['messages'], (old) => [
          ...(old || []),
          optimisticMessage,
        ]);
      }

      // 3. Context Handling: Return a context object containing the snapshot
      return { previousMessages };
    },
    
    // 4. Error Rollback: Revert to previous state on failure
    onError: (err, text, context) => {
      if (context?.previousMessages) {
        queryClient.setQueryData(['messages'], context.previousMessages);
      }
      // Display transient error toast (mocked)
      console.error('Failed to send message:', err);
      alert('Message failed to send. Please try again.');
    },
    
    // Ensure cache is invalidated/refetched to get the real ID from server
    onSettled: () => {
      queryClient.invalidateQueries({ queryKey: ['messages'] });
    },
  });

  // Mock query for displaying messages
  const { data: messages = [] } = useQuery({
    queryKey: ['messages'],
    queryFn: async () => [] as Message[], // Initial empty state
  });

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim()) return;
    
    mutation.mutate(inputText);
    setInputText('');
  };

  return (
    <div>
      {/* Message List */}
      <div className="message-list">
        {messages.map((msg) => (
          <div key={msg.id} className="message">
            <span>{msg.text}</span>
            {/* 5. UI State: Conditional rendering of status icons */}
            {msg.status === 'pending' && <span> 🕒 </span>}
            {msg.status === 'sent' && <span> ✅ </span>}
            {msg.status === 'failed' && <span> ❌ </span>}
          </div>
        ))}
      </div>

      {/* Input Field */}
      <form onSubmit={handleSend}>
        <input
          type="text"
          value={inputText}
          onChange={(e) => setInputText(e.target.value)}
          placeholder="Type a message..."
          disabled={mutation.isPending}
        />
        <button type="submit" disabled={mutation.isPending}>
          {mutation.isPending ? 'Sending...' : 'Send'}
        </button>
      </form>
    </div>
  );
};
