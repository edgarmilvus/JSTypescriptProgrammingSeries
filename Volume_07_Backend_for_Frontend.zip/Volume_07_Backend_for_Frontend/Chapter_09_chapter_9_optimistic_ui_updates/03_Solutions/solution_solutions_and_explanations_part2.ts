/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

// File: src/components/BalanceTransfer.tsx
import { useState } from 'react';

interface Transaction {
  id: string;
  amount: number;
  status: 'optimistic' | 'confirmed' | 'rejected';
}

// Mock API
const mockProcessTransaction = (amount: number): Promise<void> => {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      // Simulate rejection if amount is weird (e.g. > 100 for demo)
      if (amount > 100) reject(new Error('Transaction rejected by bank'));
      else resolve();
    }, 500);
  });
};

export const BalanceTransfer = ({ initialBalance }: { initialBalance: number }) => {
  const [serverBalance, setServerBalance] = useState(initialBalance);
  const [pendingTransactions, setPendingTransactions] = useState<Transaction[]>([]);
  const [amount, setAmount] = useState<number>(0);
  const [error, setError] = useState<string | null>(null);

  // Calculate projected balance: Server Balance + Sum of all pending optimistic transactions
  const projectedBalance = pendingTransactions.reduce((acc, tx) => {
    if (tx.status === 'optimistic' || tx.status === 'confirmed') {
      return acc - tx.amount;
    }
    return acc;
  }, serverBalance);

  const handleTransfer = async () => {
    setError(null);
    
    // 3. Validation Guard: Check projected balance BEFORE sending
    if (amount <= 0) return;
    if (projectedBalance < amount) {
      setError('Insufficient funds based on current pending transactions.');
      return;
    }

    const txId = crypto.randomUUID();
    
    // 1. State Management: Add to pending queue immediately
    const optimisticTx: Transaction = {
      id: txId,
      amount,
      status: 'optimistic',
    };
    
    setPendingTransactions((prev) => [...prev, optimisticTx]);

    try {
      // 2. Optimistic Calculation happens automatically via projectedBalance getter
      await mockProcessTransaction(amount);
      
      // Success: Mark as confirmed
      setPendingTransactions((prev) =>
        prev.map((tx) => (tx.id === txId ? { ...tx, status: 'confirmed' } : tx))
      );
      
      // In a real app, we'd wait for the server to return the new balance.
      // Here, we simulate updating the server balance after confirmation.
      setServerBalance((prev) => prev - amount);
      
      // Cleanup confirmed transactions (optional, depending on UI requirements)
      // For this demo, we keep them to show history, but remove from "pending" calculation logic if needed.
    } catch (err) {
      // 4. Reconciliation: Server rejected
      setError('Transaction failed: ' + (err instanceof Error ? err.message : 'Unknown error'));
      
      // Remove from queue (reverts the UI balance calculation)
      setPendingTransactions((prev) => prev.filter((tx) => tx.id !== txId));
    }
  };

  return (
    <div>
      <h3>Banking Dashboard</h3>
      {/* Display: "Available: $X" (Reflecting optimistic changes) */}
      <p>Available Balance: ${projectedBalance.toFixed(2)}</p>
      <p className="text-xs text-gray-500">
        (Server: ${serverBalance.toFixed(2)} | Pending: {pendingTransactions.length})
      </p>

      <input
        type="number"
        value={amount}
        onChange={(e) => setAmount(Number(e.target.value))}
        placeholder="Amount"
      />
      <button onClick={handleTransfer} disabled={amount <= 0}>
        Transfer
      </button>

      {error && <div style={{ color: 'red' }}>{error}</div>}
    </div>
  );
};
