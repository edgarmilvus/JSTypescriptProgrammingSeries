/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

// File: src/components/SmartFeedback.tsx
import { useState } from 'react';
import { useMutation } from '@tanstack/react-query';

// Mock LLM API
const mockLLMSubmit = (text: string): Promise<{ success: boolean; reason?: string }> => {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      if (text.toLowerCase().includes('spam')) {
        resolve({ success: false, reason: 'LLM detected spam content.' });
      } else {
        resolve({ success: true });
      }
    }, 2000);
  });
};

type FormState = 'FORM' | 'SUBMITTING' | 'SUCCESS' | 'ERROR';

export const SmartFeedback = () => {
  const [feedbackText, setFeedbackText] = useState('');
  const [errorReason, setErrorReason] = useState('');
  
  // 1. Component Lifecycle: State management
  const [viewState, setViewState] = useState<FormState>('FORM');

  const mutation = useMutation({
    mutationFn: (text: string) => mockLLMSubmit(text),
    
    // 2. Optimistic Transition: Hide form immediately
    onMutate: () => {
      setViewState('SUCCESS');
    },
    
    // 4. Reconciliation/Revert: Handle LLM rejection
    onError: (error) => {
      // The error object from the promise rejection isn't used here 
      // because we resolve with { success: false } in this mock.
      // But if we threw an actual error, we'd catch it here.
    },
    
    onSuccess: (data) => {
      if (!data.success) {
        // Revert to form view with error
        setViewState('ERROR');
        setErrorReason(data.reason || 'Submission failed.');
      }
      // If success, we stay in SUCCESS state.
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!feedbackText.trim()) return;
    
    // Trigger mutation (which triggers onMutate immediately)
    mutation.mutate(feedbackText);
  };

  const handleRetry = () => {
    setViewState('FORM';
    setErrorReason('');
  };

  // 5. Edge Case: Navigation away
  // If the user navigates away, the component unmounts. 
  // Standard React Query behavior: The promise continues in the background.
  // If we want to cancel, we would need an AbortController passed to the mutationFn.
  // Since we are optimistic, the UI state is already "Success", so navigation is safe.

  return (
    <div className="feedback-widget">
      {viewState === 'SUCCESS' && (
        <div className="success-message">
          <h3>Thank You!</h3>
          <p>Your feedback is being analyzed by our AI.</p>
          {/* Optional: Show a subtle badge if we have confirmed data */}
          {mutation.isSuccess && <span className="badge">AI Verified</span>}
        </div>
      )}

      {(viewState === 'FORM' || viewState === 'ERROR') && (
        <form onSubmit={handleSubmit}>
          {viewState === 'ERROR' && (
            <div className="error-banner" style={{ color: 'red', marginBottom: '10px' }}>
              {errorReason}. Please try again.
            </div>
          )}
          
          <textarea
            value={feedbackText}
            onChange={(e) => setFeedbackText(e.target.value)}
            placeholder="Describe your issue..."
            disabled={mutation.isPending}
          />
          
          <button type="submit" disabled={mutation.isPending}>
            {mutation.isPending ? 'Analyzing...' : 'Submit Feedback'}
          </button>
          
          {viewState === 'ERROR' && (
            <button type="button" onClick={handleRetry} style={{ marginLeft: '10px' }}>
              Edit
            </button>
          )}
        </form>
      )}
    </div>
  );
};
