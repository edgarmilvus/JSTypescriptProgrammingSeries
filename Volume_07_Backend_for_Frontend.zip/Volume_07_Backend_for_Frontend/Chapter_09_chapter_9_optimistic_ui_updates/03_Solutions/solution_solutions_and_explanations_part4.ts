/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

// File: src/components/LoadBalancerStatus.tsx
import { useState } from 'react';
import { useMutation, useQueryClient } from '@tanstack/react-query';

// Mock API with random delay and failure
const mockUpdateLoad = (delta: number): Promise<number> => {
  return new Promise((resolve, reject) => {
    const delay = Math.random() * 1900 + 100; // 100ms - 2000ms
    setTimeout(() => {
      // 10% failure rate
      if (Math.random() < 0.1) {
        reject(new Error('Network fluctuation'));
      } else {
        resolve(delta);
      }
    }, delay);
  });
};

export const LoadBalancerStatus = () => {
  const queryClient = useQueryClient();
  
  // We track two states: 
  // 1. The optimistic UI state (derived from mutation queue + server state)
  // 2. The confirmed server state (for visualization)
  const [serverState, setServerState] = useState(50);
  
  // We use a mutation queue to track in-flight operations
  const [mutationQueue, setMutationQueue] = useState<Array<{ id: string; delta: number; status: 'pending' | 'success' | 'error' }>>([]);

  // Calculate current UI Load
  const currentLoad = mutationQueue.reduce((acc, item) => {
    if (item.status === 'pending' || item.status === 'success') {
      return acc + item.delta;
    }
    return acc;
  }, serverState);

  const mutation = useMutation({
    mutationFn: ({ delta }: { delta: number }) => mockUpdateLoad(delta),
    
    onMutate: async ({ delta }) => {
      const id = crypto.randomUUID();
      // Add to queue immediately
      setMutationQueue((prev) => [...prev, { id, delta, status: 'pending' }]);
      return { id, delta }; // Return context for error handling
    },
    
    onError: (err, variables, context) => {
      if (!context) return;
      
      // 3. Rollback Logic: Mark specific mutation as error
      setMutationQueue((prev) =>
        prev.map((item) =>
          item.id === context.id ? { ...item, status: 'error' } : item
        )
      );

      // Remove the failed item from queue after a short delay to show the error visually
      setTimeout(() => {
        setMutationQueue((prev) => prev.filter((item) => item.id !== context.id));
      }, 2000);
    },
    
    onSuccess: (result, variables, context) => {
      if (!context) return;
      
      // Update Server State (Simulate server confirming the change)
      setServerState((prev) => prev + context.delta);
      
      // Remove successful item from queue (it's now reflected in serverState)
      setMutationQueue((prev) => prev.filter((item) => item.id !== context.id));
    },
  });

  const handleIncrement = () => mutation.mutate({ delta: 1 });
  const handleDecrement = () => mutation.mutate({ delta: -1 });

  return (
    <div style={{ border: '1px solid #ccc', padding: '20px', fontFamily: 'monospace' }}>
      <h3>Load Balancer Status</h3>
      
      <div style={{ marginBottom: '10px' }}>
        <strong>UI State (Optimistic): </strong> 
        <span style={{ color: mutationQueue.length > 0 ? 'green' : 'black', fontSize: '1.2em' }}>
          {currentLoad}
        </span>
        {mutationQueue.length > 0 && ` (+${mutationQueue.length} pending)`}
      </div>

      <div style={{ marginBottom: '20px', color: '#666' }}>
        <strong>Server Confirmed: </strong> {serverState}
      </div>

      <div style={{ display: 'flex', gap: '10px' }}>
        <button onClick={handleIncrement}>+1</button>
        <button onClick={handleDecrement}>-1</button>
      </div>

      <div style={{ marginTop: '20px', borderTop: '1px solid #eee', paddingTop: '10px' }}>
        <strong>Mutation Queue:</strong>
        <ul>
          {mutationQueue.map((q) => (
            <li key={q.id} style={{ color: q.status === 'error' ? 'red' : q.status === 'success' ? 'green' : 'orange' }}>
              {q.delta > 0 ? '+' : ''}{q.delta} - {q.status.toUpperCase()}
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
};
