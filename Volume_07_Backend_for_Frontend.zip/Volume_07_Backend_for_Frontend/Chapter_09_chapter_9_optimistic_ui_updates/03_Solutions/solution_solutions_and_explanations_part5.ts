/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

// File: src/components/MeetingSummarizer.tsx
import { useState } from 'react';
import { useMutation } from '@tanstack/react-query';

// Mock LLM Response type
type LLMSummary = {
  summary: string;
  confidence: number;
};

// 1. Heuristic Function: Runs instantly on client
const generateOptimisticSummary = (rawText: string): string => {
  if (!rawText.trim()) return '';
  // Simple heuristic: Take the first sentence or first 50 chars
  const sentences = rawText.split(/[.!?]+/);
  return (sentences[0] || rawText).substring(0, 50).trim() + '...';
};

// Simple similarity check (length based for demo, could be Levenshtein)
const calculateDifference = (str1: string, str2: string): number => {
  const len1 = str1.length;
  const len2 = str2.length;
  if (len1 === 0 && len2 === 0) return 0;
  return Math.abs(len1 - len2) / Math.max(len1, len2);
};

// Mock API
const mockLLMSummarize = (text: string): Promise<LLMSummary> => {
  return new Promise((resolve) => {
    setTimeout(() => {
      // Simulate LLM generating a different summary
      resolve({
        summary: `AI Processed: ${text.substring(0, 100)}... (Enhanced by LLM)`,
        confidence: 0.95,
      });
    }, 3000);
  });
};

export const MeetingSummarizer = () => {
  const [rawText, setRawText] = useState('');
  const [summary, setSummary] = useState('');
  const [isVerified, setIsVerified] = useState(false);

  const mutation = useMutation({
    mutationFn: (text: string) => mockLLMSummarize(text),
    
    // 2. onMutate: Calculate and set optimistic summary
    onMutate: (text) => {
      const optimistic = generateOptimisticSummary(text);
      setSummary(optimistic);
      setIsVerified(false); // Reset verification badge
    },
    
    // 3. State Sync & Reconciliation
    onSuccess: (data, text) => {
      const diff = calculateDifference(summary, data.summary);
      
      // Reconciliation: If diff > 30% (e.g. 0.3), update to real summary
      // Note: We compare against the current 'summary' state (which is optimistic)
      if (diff > 0.3) {
        setSummary(data.summary);
      }
      
      // Show verified badge regardless (unless we want to hide it on low confidence)
      if (data.confidence > 0.8) {
        setIsVerified(true);
      }
    },
  });

  const handleSummarize = () => {
    if (!rawText.trim()) return;
    mutation.mutate(rawText);
  };

  return (
    <div style={{ maxWidth: '600px', margin: '0 auto' }}>
      <h3>Meeting Notes Summarizer</h3>
      
      <textarea
        rows={5}
        style={{ width: '100%' }}
        placeholder="Enter raw notes..."
        value={rawText}
        onChange={(e) => setRawText(e.target.value)}
      />
      
      <button 
        onClick={handleSummarize} 
        disabled={mutation.isPending}
        style={{ marginTop: '10px' }}
      >
        {mutation.isPending ? 'AI Thinking...' : 'Summarize'}
      </button>

      {summary && (
        <div style={{ marginTop: '20px', padding: '10px', border: '1px solid #ddd' }}>
          <h4>Summary:</h4>
          <p>{summary}</p>
          
          {/* 4. UX Polish: Verified Badge */}
          {isVerified && (
            <span style={{ background: '#e0f7fa', color: '#006064', padding: '2px 6px', borderRadius: '4px', fontSize: '0.8em' }}>
              ✨ AI Verified
            </span>
          )}
          
          {!isVerified && mutation.isSuccess && (
            <span style={{ color: '#888', fontSize: '0.8em' }}>
              (Optimistic Preview)
            </span>
          )}
        </div>
      )}
    </div>
  );
};
