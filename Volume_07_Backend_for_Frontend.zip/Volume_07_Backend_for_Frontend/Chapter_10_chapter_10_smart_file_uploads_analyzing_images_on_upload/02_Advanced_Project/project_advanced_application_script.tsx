/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.tsx
// Description: Advanced Application Script
// ==========================================

// app/components/SmartImageUploader.tsx
'use client';

import React, { useState } from 'react';
import { trpc } from '../utils/trpc'; // Assuming a standard tRPC client setup

/**
 * @component SmartImageUploader
 * @description A client-side component that handles file selection and communicates
 * with the tRPC backend to perform intelligent image analysis.
 */
export const SmartImageUploader = () => {
  const [file, setFile] = useState<File | null>(null);
  const [uploadStatus, setUploadStatus] = useState<
    'idle' | 'uploading' | 'success' | 'error'
  >('idle');
  const [analysisResult, setAnalysisResult] = useState<{
    safe: boolean;
    altText: string;
  } | null>(null);

  // tRPC mutation hook for the smart upload
  const uploadMutation = trpc.analyzeImage.useMutation();

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setFile(e.target.files[0]);
      setUploadStatus('idle');
      setAnalysisResult(null);
    }
  };

  const handleUpload = async () => {
    if (!file) return;

    setUploadStatus('uploading');
    
    // Convert file to Base64 to send over JSON (WebSockets/HTTP)
    // In a real production app, you might use multipart/form-data or presigned URLs
    const reader = new FileReader();
    reader.readAsDataURL(file);
    
    reader.onload = async () => {
      const base64Image = reader.result as string;

      try {
        // Call the tRPC endpoint
        const result = await uploadMutation.mutateAsync({
          imageBase64: base64Image,
          fileName: file.name,
        });

        setAnalysisResult(result);
        setUploadStatus('success');
      } catch (error) {
        console.error('Upload failed:', error);
        setUploadStatus('error');
      }
    };
  };

  return (
    <div className="p-6 border rounded-lg max-w-md mx-auto">
      <h2 className="text-xl font-bold mb-4">Smart Image Upload</h2>
      
      <input type="file" onChange={handleFileChange} className="mb-4 block w-full" />
      
      <button
        onClick={handleUpload}
        disabled={!file || uploadStatus === 'uploading'}
        className="bg-blue-600 text-white px-4 py-2 rounded disabled:opacity-50"
      >
        {uploadStatus === 'uploading' ? 'Analyzing...' : 'Upload & Analyze'}
      </button>

      {uploadStatus === 'success' && analysisResult && (
        <div className="mt-4 p-4 bg-green-50 border border-green-200 rounded">
          <h3 className="font-semibold text-green-800">Analysis Complete</h3>
          <p className="text-sm mt-2">
            <strong>Safety Check:</strong>{' '}
            {analysisResult.safe ? '✅ Safe' : '❌ Unsafe'}
          </p>
          <p className="text-sm mt-2">
            <strong>Generated Alt Text:</strong> "{analysisResult.altText}"
          </p>
        </div>
      )}

      {uploadStatus === 'error' && (
        <div className="mt-4 p-4 bg-red-50 border border-red-200 rounded text-red-700">
          Analysis failed. Please try again.
        </div>
      )}
    </div>
  );
};
