/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script_part2.ts
// Description: Advanced Application Script
// ==========================================

// app/server/routers/imageRouter.ts
import { z } from 'zod';
import { publicProcedure, router } from '../trpc';
import { simulateLLMAnalysis } from '../services/llmService';

/**
 * @description Runtime validation schema for the image upload payload.
 * We use Zod here because TypeScript types are erased at runtime.
 * This ensures that even if a malicious user bypasses the client,
 * the server strictly validates the input structure.
 */
const ImageAnalysisSchema = z.object({
  imageBase64: z.string().startsWith('data:image/'), // Must be a valid image data URL
  fileName: z.string().min(1),
});

export const imageRouter = router({
  /**
   * @procedure analyzeImage
   * @description The core endpoint for the Smart File Upload pipeline.
   * 1. Validates input (Runtime Validation).
   * 2. Offloads analysis to an external service (Asynchronous Tool Handling).
   * 3. Processes the result and prepares it for the database.
   */
  analyzeImage: publicProcedure
    .input(ImageAnalysisSchema)
    .mutation(async ({ input }) => {
      // Step 1: Input Validation (handled automatically by tRPC + Zod)
      // If input fails, tRPC throws a BAD_REQUEST error before this code runs.

      // Step 2: Asynchronous Tool Handling
      // We await the LLM service. In a real Edge Function, this would be
      // a fetch call to an external API (e.g., OpenAI Vision or AWS Rekognition).
      // We wrap this in a try/catch to handle external service failures gracefully.
      try {
        const llmResponse = await simulateLLMAnalysis(input.imageBase64);

        // Step 3: Runtime Validation of External Data
        // We must validate the response from the LLM before trusting it.
        // The LLM might hallucinate or return malformed JSON.
        const validatedResponse = z.object({
          safe: z.boolean(),
          altText: z.string(),
        }).parse(llmResponse);

        // Step 4: Database Storage (Simulated)
        // In a real app, you would now write to Prisma/Drizzle:
        // await db.imageMetadata.create({ data: { ...validatedResponse, fileName: input.fileName } });
        
        return validatedResponse;
      } catch (error) {
        console.error('LLM Service Error:', error);
        throw new Error('Image analysis failed internally');
      }
    }),
});
