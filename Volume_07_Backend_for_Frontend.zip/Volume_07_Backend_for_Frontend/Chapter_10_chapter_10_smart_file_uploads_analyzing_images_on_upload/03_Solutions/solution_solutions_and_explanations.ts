/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// File: src/server/api/routers/upload.ts (tRPC Router)
import { z } from "zod";
import { createTRPCRouter, protectedProcedure } from "~/server/api/trpc";
import { db } from "~/server/db"; // Assuming Drizzle ORM or similar
import { jobs } from "~/server/db/schema"; // Database schema definition
import { v4 as uuidv4 } from "uuid";

export const uploadRouter = createTRPCRouter({
  uploadImage: protectedProcedure
    .input(z.object({ file: z.instanceof(File) })) // tRPC handles File objects via form-data
    .mutation(async ({ input, ctx }) => {
      // 1. Validate file type and size (simplified)
      if (!input.file.type.startsWith("image/") || input.file.size > 5 * 1024 * 1024) {
        throw new Error("Invalid file type or size too large.");
      }

      // 2. Store file (Mocking S3 upload for this example)
      // In production, generate a presigned URL or upload directly to an Edge Function endpoint
      const fileId = uuidv4();
      const fileUrl = `https://storage.example.com/${fileId}`;

      // 3. Generate Job ID and Insert into Database
      const jobId = uuidv4();
      
      await db.insert(jobs).values({
        id: jobId,
        userId: ctx.user.id, // From session
        fileUrl: fileUrl,
        status: "pending",
        createdAt: new Date(),
        retryCount: 0,
      });

      // 4. Trigger the processor (In a real app, this might be a webhook or a queue message)
      // For this exercise, we simulate the trigger by calling the processor function directly
      // or relying on a separate cron job. Here, we just return the ID.
      
      return { jobId };
    }),
});

// File: src/server/edge-functions/job-processor.ts (Edge Function)
import { db } from "~/server/db";
import { jobs } from "~/server/db/schema";
import { eq } from "drizzle-orm";

// Mock LLM analysis function
async function mockAnalyzeImage(url: string): Promise<{ labels: string[]; contains_nudity: boolean }> {
  // Simulate network delay
  await new Promise(resolve => setTimeout(resolve, 2000));
  return { labels: ["cat", "indoor"], contains_nudity: false };
}

export async function processPendingJobs() {
  // 1. Fetch pending jobs (limit to avoid overwhelming the function)
  const pendingJobs = await db.select().from(jobs).where(eq(jobs.status, "pending")).limit(10);

  for (const job of pendingJobs) {
    try {
      // Update status to processing to prevent other workers from picking it up
      await db.update(jobs).set({ status: "processing" }).where(eq(jobs.id, job.id));

      // 2. Download/Analyze (Mocked)
      const analysis = await mockAnalyzeImage(job.fileUrl);

      // 3. Update job with results
      await db.update(jobs).set({
        status: "completed",
        analysisResult: JSON.stringify(analysis), // Store JSON blob
        updatedAt: new Date(),
      }).where(eq(jobs.id, job.id));

    } catch (error) {
      // Handle error (see Exercise 5 for robust logic)
      console.error(`Job ${job.id} failed:`, error);
      await db.update(jobs).set({ status: "failed" }).where(eq(jobs.id, job.id));
    }
  }
}

// File: src/server/api/routers/status.ts (tRPC Router)
export const statusRouter = createTRPCRouter({
  getJobStatus: protectedProcedure
    .input(z.object({ jobId: z.string() }))
    .query(async ({ input }) => {
      const job = await db.select().from(jobs).where(eq(jobs.id, input.jobId)).get();
      
      if (!job) {
        return { status: "not_found" as const };
      }

      return {
        status: job.status,
        analysisResult: job.analysisResult ? JSON.parse(job.analysisResult) : null,
      };
    }),
});
