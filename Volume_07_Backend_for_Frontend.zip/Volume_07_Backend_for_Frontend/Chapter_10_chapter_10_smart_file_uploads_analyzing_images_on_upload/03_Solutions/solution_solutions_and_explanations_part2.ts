/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

// File: src/types/api.ts
export interface UploadResponse {
  jobId: string;
}

export interface JobStatusResponse {
  status: "pending" | "processing" | "completed" | "failed" | "not_found";
  analysisResult?: {
    labels: string[];
    contains_nudity: boolean;
  } | null;
}

// File: src/components/SmartImageUploader.tsx
import { useState } from "react";
import { api } from "~/utils/api"; // Your tRPC client setup
import { useQueryClient } from "@tanstack/react-query";

type UploadState = "idle" | "uploading" | "processing" | "success" | "error";

export const SmartImageUploader = () => {
  const [state, setState] = useState<UploadState>("idle");
  const [jobId, setJobId] = useState<string | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [file, setFile] = useState<File | null>(null);
  const queryClient = useQueryClient();

  // 1. Upload Mutation
  const uploadMutation = api.upload.uploadImage.useMutation({
    onSuccess: (data) => {
      setJobId(data.jobId);
      setState("processing"); // Move to processing state immediately
    },
    onError: () => {
      setState("error");
    },
  });

  // 2. Status Polling Query
  // Enabled only when we have a jobId and are in processing state
  const { data: statusData, isFetching: isPolling } = api.status.getJobStatus.useQuery(
    { jobId: jobId! },
    {
      enabled: !!jobId && state === "processing",
      refetchInterval: (query) => {
        // Stop polling if status is completed or failed
        if (query.state.data?.status === "completed" || query.state.data?.status === "failed") {
          return false;
        }
        return 2000; // Poll every 2 seconds
      },
      onSuccess: (data) => {
        if (data.status === "completed") {
          setState("success");
          setJobId(null); // Stop polling
        } else if (data.status === "failed") {
          setState("error");
          setJobId(null);
        }
      },
    }
  );

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0];
    if (selectedFile) {
      setFile(selectedFile);
      setPreviewUrl(URL.createObjectURL(selectedFile));
      setState("idle");
    }
  };

  const handleUpload = () => {
    if (!file) return;
    setState("uploading");
    uploadMutation.mutate({ file });
  };

  const handleRetry = () => {
    setState("idle");
    setFile(null);
    setPreviewUrl(null);
    setJobId(null);
    queryClient.clear(); // Clear query cache
  };

  return (
    <div className="p-4 border rounded-md">
      <h2 className="text-lg font-bold mb-2">Smart Image Uploader</h2>
      
      {/* File Input */}
      {state === "idle" && (
        <input type="file" onChange={handleFileChange} accept="image/*" />
      )}

      {/* Preview */}
      {previewUrl && (
        <div className="mt-2">
          <img src={previewUrl} alt="Preview" className="max-h-32 rounded" />
        </div>
      )}

      {/* Upload Button */}
      {state === "idle" && file && (
        <button onClick={handleUpload} className="mt-2 bg-blue-500 text-white px-4 py-2 rounded">
          Upload & Analyze
        </button>
      )}

      {/* Loading States */}
      {state === "uploading" && <div className="mt-2 text-blue-600">Uploading...</div>}
      {state === "processing" && (
        <div className="mt-2 text-orange-600">
          Analyzing image... {isPolling ? "(Polling status...)" : ""}
        </div>
      )}

      {/* Success State */}
      {state === "success" && statusData?.analysisResult && (
        <div className="mt-2 p-2 bg-green-100 text-green-800 rounded">
          <p className="font-bold">Analysis Complete!</p>
          <p>Labels: {statusData.analysisResult.labels.join(", ")}</p>
          <p>Nudity Detected: {statusData.analysisResult.contains_nudity ? "Yes" : "No"}</p>
        </div>
      )}

      {/* Error State */}
      {state === "error" && (
        <div className="mt-2 p-2 bg-red-100 text-red-800 rounded">
          <p>An error occurred during upload or analysis.</p>
          <button onClick={handleRetry} className="underline font-bold">
            Try Again
          </button>
        </div>
      )}
    </div>
  );
};
