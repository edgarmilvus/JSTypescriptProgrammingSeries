/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

// File: src/server/edge-functions/llm-processor.ts
import { db } from "~/server/db";
import { jobs } from "~/server/db/schema";
import { eq } from "drizzle-orm";

// Configuration (use environment variables in production)
const LLM_API_URL = "https://api.openai.com/v1/chat/completions";
const LLM_API_KEY = process.env.OPENAI_API_KEY;
const TIMEOUT_MS = 10000; // 10 seconds timeout

interface LLMResponse {
  choices: {
    message: {
      content: string;
    };
  }[];
  usage?: {
    total_tokens: number;
  };
}

export async function generateAltText(jobId: string, imageUrl: string) {
  const job = await db.select().from(jobs).where(eq(jobs.id, jobId)).get();
  if (!job) throw new Error("Job not found");

  // 1. Input Validation
  if (!imageUrl || !imageUrl.startsWith("http")) {
    throw new Error("Invalid image URL provided to LLM");
  }

  // 2. Abort Controller for Timeout
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), TIMEOUT_MS);

  try {
    // 3. Call LLM API (Example: OpenAI GPT-4 Vision)
    const response = await fetch(LLM_API_URL, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${LLM_API_KEY}`,
      },
      body: JSON.stringify({
        model: "gpt-4-vision-preview",
        messages: [
          {
            role: "user",
            content: [
              { type: "text", text: "Describe this image concisely for alt-text." },
              { type: "image_url", image_url: { url: imageUrl } },
            ],
          },
        ],
        max_tokens: 100,
      }),
      signal: controller.signal,
    });

    clearTimeout(timeoutId);

    if (!response.ok) {
      // Handle API errors (Rate limit, 500s, etc.)
      const errorBody = await response.text();
      console.error(`LLM API Error [${response.status}]: ${errorBody}`);
      throw new Error(`LLM API request failed: ${response.statusText}`);
    }

    const data: LLMResponse = await response.json();
    const rawText = data.choices[0].message.content;

    // 4. Data Transformation & Parsing
    // LLMs can be unpredictable; we sanitize the output.
    const altText = rawText.replace(/["\n]/g, "").trim(); // Remove quotes and newlines

    const analysisResult: ImageAnalysisResult = {
      altText: altText,
      confidence: 0.85, // Mock confidence score as LLMs don't always return this
      generatedAt: new Date().toISOString(),
    };

    // 5. Database Update
    await db.update(jobs).set({
      status: "completed",
      analysisResult: JSON.stringify({
        ...job.analysisResult, // Keep existing labels if any
        ...analysisResult,
      }),
      updatedAt: new Date(),
    }).where(eq(jobs.id, jobId));

  } catch (error: any) {
    // 6. Error Logging & Handling
    if (error.name === "AbortError") {
      console.error(`LLM request timed out for job ${jobId}`);
    } else {
      console.error(`LLM processing failed for job ${jobId}:`, error.message);
    }
    // Re-throw to be caught by the job processor's retry logic
    throw error;
  }
}

// Interface definition
interface ImageAnalysisResult {
  altText: string;
  confidence: number;
  generatedAt: string;
  [key: string]: any; // Allow merging with existing analysis
}
