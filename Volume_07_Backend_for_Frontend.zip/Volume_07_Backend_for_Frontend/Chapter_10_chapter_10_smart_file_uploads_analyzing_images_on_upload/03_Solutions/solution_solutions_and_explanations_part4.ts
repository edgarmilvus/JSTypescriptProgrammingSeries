/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

// File: src/server/api/routers/moderation.ts
import { createTRPCRouter, protectedProcedure } from "~/server/api/trpc";
import { db } from "~/server/db";
import { jobs } from "~/server/db/schema";
import { eq } from "drizzle-orm";
import { z } from "zod";

export const moderationRouter = createTRPCRouter({
  getModerationQueue: protectedProcedure
    .input(z.object({ filterLabel: z.string().optional() }))
    .query(async ({ input }) => {
      // Fetch completed jobs
      const completedJobs = await db.select()
        .from(jobs)
        .where(eq(jobs.status, "completed"));

      // Parse JSON results
      const parsedJobs = completedJobs.map(job => ({
        fileUrl: job.fileUrl,
        createdAt: job.createdAt,
        analysis: job.analysisResult ? JSON.parse(job.analysisResult) : null,
      }));

      // Client-side filtering (as requested in requirements)
      if (input.filterLabel) {
        return parsedJobs.filter(job => 
          job.analysis?.labels?.includes(input.filterLabel)
        );
      }

      return parsedJobs;
    }),
});

// File: src/components/ModerationDashboard.tsx
import { useState } from "react";
import { api } from "~/utils/api";

export const ModerationDashboard = () => {
  const [filter, setFilter] = useState("");
  
  // Fetch data with tRPC
  const { data, isLoading, refetch } = api.moderation.getModerationQueue.useQuery({
    filterLabel: filter || undefined,
  });

  if (isLoading) return <div>Loading moderation queue...</div>;

  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-4">
        <h1 className="text-2xl font-bold">Content Moderation Queue</h1>
        <button 
          onClick={() => refetch()}
          className="bg-gray-800 text-white px-4 py-2 rounded hover:bg-gray-700"
        >
          Refresh
        </button>
      </div>

      {/* Filter Dropdown */}
      <div className="mb-4">
        <label className="mr-2">Filter by Label:</label>
        <select 
          value={filter} 
          onChange={(e) => setFilter(e.target.value)}
          className="border p-2 rounded"
        >
          <option value="">All</option>
          <option value="cat">Cat</option>
          <option value="indoor">Indoor</option>
          <option value="outdoor">Outdoor</option>
        </select>
      </div>

      {/* Data Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {data?.length === 0 && <p>No items found.</p>}
        
        {data?.map((item, index) => (
          <div key={index} className="border rounded p-4 shadow bg-white">
            <img 
              src={item.fileUrl} 
              alt="Moderation" 
              className="w-full h-40 object-cover rounded mb-2 bg-gray-200" 
            />
            <div className="space-y-1 text-sm">
              <p className="font-bold text-gray-700">Alt Text:</p>
              <p className="italic text-gray-600">"{item.analysis?.altText || "N/A"}</p>
              
              <p className="font-bold text-gray-700 mt-2">Labels:</p>
              <div className="flex flex-wrap gap-1">
                {item.analysis?.labels?.map((label: string) => (
                  <span key={label} className="bg-blue-100 text-blue-800 px-2 py-1 rounded text-xs">
                    {label}
                  </span>
                ))}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
