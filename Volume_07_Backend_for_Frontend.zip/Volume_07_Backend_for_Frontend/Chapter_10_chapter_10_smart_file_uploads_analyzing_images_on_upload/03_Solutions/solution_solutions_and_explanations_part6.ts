/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part6.ts
// Description: Solutions and Explanations
// ==========================================

// File: src/server/edge-functions/resilient-processor.ts
import { db } from "~/server/db";
import { jobs, failedJobs } from "~/server/db/schema"; // Assuming a separate failed_jobs table
import { eq, lt } from "drizzle-orm";
import { generateAltText } from "./llm-processor"; // Reuse the LLM logic

const MAX_RETRIES = 3;

export async function processJobsResiliently() {
  // 1. Fetch jobs that are pending OR retrying (and haven't exceeded max retries)
  const jobsToProcess = await db.select()
    .from(jobs)
    .where(
      // Logic: Status is pending OR (status is retrying AND retryCount < max)
      // Simplified for Drizzle:
      eq(jobs.status, "pending")
    )
    .limit(10); 

  for (const job of jobsToProcess) {
    try {
      // 2. Idempotency Check
      // If the job is "processing", it might be stuck. 
      // We check if it's been processing for too long (not implemented here for brevity),
      // or we rely on the fact that we only fetch 'pending' jobs here.
      // In a distributed system, we might use a "lease" timestamp.

      // Update status to processing to lock it
      await db.update(jobs).set({ 
        status: "processing",
        updatedAt: new Date(),
      }).where(eq(jobs.id, job.id));

      // 3. Execute Logic (LLM Call)
      await generateAltText(job.id, job.fileUrl);

    } catch (error: any) {
      console.error(`Job ${job.id} failed: ${error.message}`);

      // 4. Retry Logic
      const currentRetries = job.retryCount || 0;
      
      if (currentRetries < MAX_RETRIES) {
        // Increment retry count and set status to retrying
        await db.update(jobs).set({
          status: "retrying",
          retryCount: currentRetries + 1,
          lastErrorMessage: error.message,
          updatedAt: new Date(),
        }).where(eq(jobs.id, job.id));
      } else {
        // 5. Dead-Letter Queue (Max Retries Exceeded)
        // Move to failed_jobs table
        await db.insert(failedJobs).values({
          originalJobId: job.id,
          fileUrl: job.fileUrl,
          errorMessage: error.message,
          payload: JSON.stringify(job), // Store snapshot
          failedAt: new Date(),
        });

        // Mark as failed in main table
        await db.update(jobs).set({
          status: "failed",
          updatedAt: new Date(),
        }).where(eq(jobs.id, job.id));
      }
    }
  }
}

// File: src/components/SmartImageUploader.tsx (Updated Error Handling snippet)
// Inside the tRPC query options for getJobStatus:
const { data: statusData } = api.status.getJobStatus.useQuery(
  { jobId: jobId! },
  {
    enabled: !!jobId && state === "processing",
    // ... polling config
    onSuccess: (data) => {
      if (data.status === "completed") {
        setState("success");
      } else if (data.status === "failed") {
        // Specific error handling for permanent failure
        setState("error");
        alert("Analysis failed permanently after retries. Please contact support.");
      }
    },
  }
);
