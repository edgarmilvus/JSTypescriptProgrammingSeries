/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: theory_theoretical_foundations.ts
// Description: Theoretical Foundations
// ==========================================

// Conceptual Type Definitions for Edge AI Inference

// 1. The Edge Runtime Context
// Unlike a Node.js context, this is lightweight and stateless.
type EdgeRuntimeContext = {
  waitUntil: (promise: Promise<any>) => void; // For background tasks
  env: Record<string, string>; // Environment variables
};

// 2. The Quantized Model Interface
// A model that fits within Edge constraints (small memory footprint).
interface EdgeCompatibleModel {
  // Load the model into the isolate's memory
  load(): Promise<void>;
  
  // Generate a stream of tokens
  generateStream(prompt: string): AsyncIterableIterator<string>;
}

// 3. The LangGraph Node for Edge
// A specialized node that uses the Edge Model instead of a Server Model.
type EdgeGraphNode<TState> = (
  state: TState,
  context: EdgeRuntimeContext
) => Promise<TState>;

// 4. The tRPC Procedure Configuration for Edge
// We specify the runtime explicitly.
const edgeProcedure = t.procedure.meta({
  runtime: 'edge', // Signals the provider to use Edge Functions
  // This ensures the function is deployed to the global edge network
});

// 5. The Streaming Response Wrapper
// Handling the stream efficiently in the Edge environment.
async function* streamInference(model: EdgeCompatibleModel, input: string) {
  const stream = await model.generateStream(input);
  for await (const chunk of stream) {
    // Yield immediately to minimize latency (Time-to-First-Token)
    yield chunk;
  }
}
