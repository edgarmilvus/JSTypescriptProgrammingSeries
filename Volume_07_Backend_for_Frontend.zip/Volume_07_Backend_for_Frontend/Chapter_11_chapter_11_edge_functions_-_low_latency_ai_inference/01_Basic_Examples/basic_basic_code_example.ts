/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * ============================================================================
 * PART 1: EDGE FUNCTION (Server Side)
 * ============================================================================
 * File: app/api/generate/route.ts
 * Runtime: Vercel Edge Runtime (or standard Web Standard API compatible env)
 */

// Import necessary types and utilities for the Edge Runtime.
// Note: In a real app, you would import 'ai' or 'langchain' here.
import { NextResponse } from 'next/server';

/**
 * Configuration for the Edge Function.
 * Edge functions have strict memory and execution time limits (usually 10-30s).
 */
export const runtime = 'edge'; 

/**
 * A mock inference engine to simulate a lightweight LLM.
 * In production, this would be replaced by a library like `onnxruntime-web` 
 * or a fetch call to a specialized inference provider.
 * 
 * @param prompt - The user input string.
 * @returns An AsyncGenerator yielding strings (tokens).
 */
async function* mockInferenceEngine(prompt: string): AsyncGenerator<string, void, unknown> {
  // Simulate a "cold start" delay (common in serverless environments).
  await new Promise(resolve => setTimeout(resolve, 100));

  const responseText = `Hello! You said: "${prompt}". This is a simulated response from the edge.`;
  
  // Yield text token-by-token to simulate a streaming LLM.
  const words = responseText.split(' ');
  for (const word of words) {
    await new Promise(resolve => setTimeout(resolve, 50)); // Simulate inference time per token
    yield word + ' ';
  }
}

/**
 * POST Request Handler.
 * Receives JSON, processes inference, and returns a streaming response.
 */
export async function POST(req: Request) {
  try {
    // 1. Parse the incoming JSON body.
    const { prompt } = await req.json();

    if (!prompt || typeof prompt !== 'string') {
      return new NextResponse(JSON.stringify({ error: 'Prompt is required and must be a string.' }), {
        status: 400,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    // 2. Create a ReadableStream to handle the async generator.
    // This allows us to stream data as it's generated, rather than waiting for the whole response.
    const stream = new ReadableStream({
      async start(controller) {
        try {
          // 3. Invoke the inference engine.
          const inferenceGenerator = mockInferenceEngine(prompt);

          // 4. Iterate over the generator and enqueue chunks to the stream.
          for await (const token of inferenceGenerator) {
            controller.enqueue(new TextEncoder().encode(token));
          }

          // 5. Close the stream when finished.
          controller.close();
        } catch (error) {
          // Handle errors during inference.
          console.error('Inference Error:', error);
          controller.error(error);
        }
      },
    });

    // 6. Return the stream as a response.
    // We set headers to indicate a stream and prevent caching.
    return new NextResponse(stream, {
      headers: {
        'Content-Type': 'text/plain; charset=utf-8', // Or 'text/event-stream' for SSE
        'Cache-Control': 'no-cache',
        'Connection': 'keep-alive',
      },
    });

  } catch (error) {
    // Handle JSON parsing errors or unexpected issues.
    return new NextResponse(JSON.stringify({ error: 'Internal Server Error' }), {
      status: 500,
      headers: { 'Content-Type': 'application/json' }
    });
  }
}

/**
 * ============================================================================
 * PART 2: CLIENT SIDE (Frontend)
 * ============================================================================
 * File: app/page.tsx (or a generic client component)
 * Context: A SaaS Chat Interface
 */

/**
 * Fetches the stream from the Edge Function and updates the UI.
 * Uses the Fetch API with streaming support.
 * 
 * @param prompt - The user's message.
 * @param onToken - Callback function to handle each received token.
 */
export async function fetchInferenceStream(
  prompt: string,
  onToken: (token: string) => void
): Promise<void> {
  const response = await fetch('/api/generate', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ prompt }),
  });

  if (!response.ok) {
    throw new Error(`API Error: ${response.status}`);
  }

  // Ensure we have a body to read.
  const body = response.body;
  if (!body) {
    throw new Error('No response body received.');
  }

  // Get a reader from the stream.
  const reader = body.getReader();
  const decoder = new TextDecoder();

  // Read the stream in a loop.
  while (true) {
    const { done, value } = await reader.read();

    if (done) {
      break; // Stream finished.
    }

    // Decode the Uint8Array chunk into a string.
    const chunk = decoder.decode(value, { stream: true });
    
    // Pass the chunk to the UI update callback.
    onToken(chunk);
  }
}

/**
 * Example Usage in a React Component (Conceptual).
 * 
 * const ChatComponent = () => {
 *   const [input, setInput] = useState('');
 *   const [response, setResponse] = useState('');
 * 
 *   const handleSubmit = async (e: React.FormEvent) => {
 *     e.preventDefault();
 *     setResponse(''); // Clear previous response
 * 
 *     // Optimistic UI update could happen here (e.g., showing the user's message immediately)
 * 
 *     try {
 *       await fetchInferenceStream(input, (token) => {
 *         // Functional update to append tokens
 *         setResponse((prev) => prev + token);
 *       });
 *     } catch (err) {
 *       console.error(err);
 *     }
 *   };
 * 
 *   return (
 *     <div>
 *       <form onSubmit={handleSubmit}>
 *         <input value={input} onChange={(e) => setInput(e.target.value)} />
 *         <button type="submit">Send</button>
 *       </form>
 *       <div>{response}</div>
 *     </div>
 *   );
 * };
 */
