/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// File: src/app/api/trpc/edge-router.ts
// Runtime: Edge Runtime (Vercel/Cloudflare Workers compatible)
// Purpose: Handles the tRPC request for AI summarization and streams the result.

import { initTRPC } from '@trpc/server';
import { fetchRequestHandler } from '@trpc/server/adapters/fetch';
import { NextRequest } from 'next/server';

// 1. Initialize tRPC for Edge Runtime
// We use initTRPC without a context for this specific demo, though in production,
// context would handle authentication and user identification.
const t = initTRPC.create();

// 2. Define the Router
const appRouter = t.router({
  // The 'summarize' procedure
  summarize: t.procedure
    .input((val: unknown) => {
      // Input validation using Zod is recommended here. 
      // For this demo, we assume a string input.
      if (typeof val === 'string') return val;
      throw new Error('Invalid input: String expected');
    })
    .query(async ({ input }) => {
      // Input: The raw text to summarize
      const rawText = input;

      // 3. Simulate AI Inference Logic
      // In a real scenario, this would call a lightweight LLM (e.g., WebGPU optimized or distilled model).
      // We simulate the streaming of tokens using a ReadableStream.
      
      const encoder = new TextEncoder();
      
      // Simulate the AI "thinking" and generating a summary token by token
      const mockSummaryTokens = [
        "Summary: ", 
        "The document discusses ", 
        "advanced edge computing ", 
        "strategies for reducing ", 
        "latency in AI applications. ", 
        "Key concepts include model ", 
        "distillation and streaming ", 
        "APIs to enhance user experience."
      ];

      const stream = new ReadableStream({
        async start(controller) {
          for (const token of mockSummaryTokens) {
            // Simulate network delay and inference time per token
            await new Promise(resolve => setTimeout(resolve, 50)); 
            controller.enqueue(encoder.encode(token));
          }
          controller.close();
        },
      });

      // 4. Return the Stream
      // tRPC on Edge supports returning a Response object directly.
      // This allows us to bypass standard JSON serialization and stream data immediately.
      return new Response(stream, {
        headers: {
          'Content-Type': 'text/plain; charset=utf-8',
          // Enable CORS if needed
          'Access-Control-Allow-Origin': '*',
          'Cache-Control': 'no-cache',
        },
      });
    }),
});

// 5. Export the Handler
// This export is consumed by Next.js Route Handlers (app/api/trpc/edge/[trpc]/route.ts)
export type AppRouter = typeof appRouter;

export const handler = (req: NextRequest) =>
  fetchRequestHandler({
    endpoint: '/api/trpc',
    req,
    router: appRouter,
    createContext: () => ({}),
  });
