/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script_part2.tsx
// Description: Advanced Application Script
// ==========================================

// File: src/components/SummarizeEditor.tsx
'use client';

import React, { useState, useRef, useEffect } from 'react';
import { trpc } from '../utils/trpc'; // Assuming standard tRPC client setup
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';

// 1. Setup Query Client for React Query (Required by tRPC React)
const queryClient = new QueryClient();

// 2. Component Definition
export const SummarizeEditor = () => {
  // State for the raw input text
  const [inputText, setInputText] = useState('');
  
  // State for the AI-generated summary (Optimistic UI target)
  const [summary, setSummary] = useState('');
  
  // Ref to track the stream reader for cleanup
  const streamRef = useRef<ReadableStreamDefaultReader<Uint8Array> | null>(null);

  // 3. tRPC Hook for Streaming
  // We use 'useQuery' which supports streaming responses via the Edge Runtime's Response object.
  // enabled: false allows us to trigger the query manually.
  const summarizeMutation = trpc.summarize.useQuery(inputText, {
    enabled: false, 
    // We bypass standard JSON parsing by handling the stream manually in the 'onSuccess' or via a custom link,
    // but for this demo, we will use a manual fetch wrapper to demonstrate the raw stream handling 
    // if tRPC's automatic JSON parsing interferes with raw streams. 
    // *Note: Standard tRPC JSON parsing expects JSON. For raw streams, we often use a standard fetch API 
    // wrapped in a hook or a custom tRPC transformer.*
    
    // For the purpose of this educational script, we will simulate the streaming consumption 
    // logic inside a custom handler below to ensure clarity on the stream mechanics.
  });

  // 4. Custom Stream Fetcher (Simulating tRPC Stream Handling)
  // In production, tRPC v11+ handles this natively. Here we demonstrate the underlying mechanism.
  const fetchSummary = async (text: string) => {
    try {
      // Reset previous summary
      setSummary('');
      
      // Call the edge function directly (bypassing tRPC client JSON parsing for raw stream)
      // In a real app, you might configure tRPC to handle NDJSON (Newline Delimited JSON).
      const response = await fetch('/api/trpc/edge', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          id: 'summarize', 
          json: text 
        }),
      });

      if (!response.body) return;

      const reader = response.body.getReader();
      streamRef.current = reader;
      const decoder = new TextDecoder();

      // 5. Stream Reading Loop
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        
        // Decode the chunk (token)
        const token = decoder.decode(value, { stream: true });
        
        // 6. Reconciliation (Optimistic UI Update)
        // We append the incoming token immediately to the UI.
        setSummary((prev) => prev + token);
      }
    } catch (error) {
      console.error("Stream error:", error);
    }
  };

  // Cleanup effect to abort stream if component unmounts
  useEffect(() => {
    return () => {
      if (streamRef.current) {
        streamRef.current.cancel();
      }
    };
  }, []);

  return (
    <div style={{ padding: '20px', fontFamily: 'sans-serif' }}>
      <h2>AI Document Summarizer</h2>
      
      <div style={{ display: 'flex', gap: '20px' }}>
        {/* Input Area */}
        <div style={{ flex: 1 }}>
          <label style={{ display: 'block', marginBottom: '8px', fontWeight: 'bold' }}>
            Raw Text
          </label>
          <textarea
            style={{ width: '100%', height: '200px', padding: '10px' }}
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            placeholder="Paste your document text here..."
          />
          <button 
            onClick={() => fetchSummary(inputText)}
            style={{ marginTop: '10px', padding: '8px 16px', cursor: 'pointer' }}
          >
            Generate Summary
          </button>
        </div>

        {/* Output Area (Optimistic UI) */}
        <div style={{ flex: 1 }}>
          <label style={{ display: 'block', marginBottom: '8px', fontWeight: 'bold' }}>
            AI Summary (Streamed)
          </label>
          <div 
            style={{ 
              width: '100%', 
              height: '200px', 
              padding: '10px', 
              border: '1px solid #ccc', 
              backgroundColor: '#f9f9f9',
              overflowY: 'auto'
            }}
          >
            {summary || <span style={{ color: '#999' }}>Waiting for input...</span>}
          </div>
        </div>
      </div>
    </div>
  );
};

// Wrapper to provide tRPC context
export const SummarizeApp = () => (
  <QueryClientProvider client={queryClient}>
    <SummarizeEditor />
  </QueryClientProvider>
);
