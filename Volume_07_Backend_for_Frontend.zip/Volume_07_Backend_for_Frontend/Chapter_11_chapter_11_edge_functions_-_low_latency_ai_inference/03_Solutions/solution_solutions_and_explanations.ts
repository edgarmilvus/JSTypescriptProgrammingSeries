/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// File: api/summarize.ts
// Framework: Vercel Edge Runtime / Standard Web Streams API

export const config = {
  runtime: 'edge',
};

// Helper to simulate an LLM stream with artificial delay (backpressure)
async function* mockLLMStream(text: string) {
  const words = text.split(' ');
  // Simple summarization logic: return first 20 words or fewer
  const summaryWords = words.slice(0, Math.min(words.length, 20));
  
  for (const word of summaryWords) {
    // Simulate network latency and token generation time
    await new Promise(resolve => setTimeout(resolve, 100)); 
    yield `${word} `;
  }
}

export default async function handler(req: Request) {
  // 1. Input Validation
  if (req.method !== 'POST') {
    return new Response(JSON.stringify({ error: 'Method not allowed' }), { status: 405 });
  }

  let body: { text?: string };
  try {
    body = await req.json();
  } catch (e) {
    return new Response(JSON.stringify({ error: 'Invalid JSON' }), { status: 400 });
  }

  const text = body.text;
  if (typeof text !== 'string' || text.length > 2000) {
    return new Response(
      JSON.stringify({ error: 'Invalid input: text is required and must be under 2000 characters' }), 
      { status: 400 }
    );
  }

  // 2. Streaming Implementation using TransformStream
  const encoder = new TextEncoder();
  const stream = new ReadableStream({
    async start(controller) {
      try {
        const llmGenerator = mockLLMStream(text);
        for await (const token of llmGenerator) {
          controller.enqueue(encoder.encode(token));
        }
        controller.close();
      } catch (error) {
        controller.error(error);
      }
    },
  });

  // 3. Return Streamed Response
  return new Response(stream, {
    headers: {
      'Content-Type': 'text/plain; charset=utf-8',
      'Cache-Control': 'no-cache',
      'Connection': 'keep-alive',
    },
  });
}
