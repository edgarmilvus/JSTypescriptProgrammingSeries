/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

// File: lib/validators.ts
export interface ValidatedInput {
  text: string;
}

export class InputValidator {
  private readonly MAX_LENGTH = 2000;

  validate(input: unknown): ValidatedInput {
    if (!input || typeof input !== 'object') {
      throw new Error('Input must be a JSON object');
    }

    const castInput = input as { text?: unknown };
    const text = castInput.text;

    if (typeof text !== 'string') {
      throw new Error('Property "text" is required and must be a string');
    }

    if (text.length > this.MAX_LENGTH) {
      throw new Error(`Text exceeds maximum length of ${this.MAX_LENGTH} characters`);
    }

    // Sanitization step (removing special characters as per prompt)
    const sanitizedText = text.replace(/[^\w\s]/gi, '');

    return { text: sanitizedText };
  }
}
