/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

// Paste this code into a Graphviz renderer (e.g., graphviz.org, VS Code extension)

digraph EdgeArchitecture {
    rankdir=TB;
    node [shape=box, style="rounded,filled", fillcolor="#e3f2fd", color="#1565c0"];
    edge [color="#555555", fontsize=10];

    // Nodes
    Client [label="Client (Browser)", fillcolor="#fff3e0"];
    EdgeNode [label="Edge Network Node\n(POP)", shape="cylinder"];
    Runtime [label="Function Runtime\n(Isolate)", fillcolor="#e8f5e9"];
    LLM [label="External LLM API", fillcolor="#f3e5f5"];
    Cache [label="KV Cache\n(Optional)", fillcolor="#fff9c4", shape="diamond"];

    // Main Flow
    Client -> EdgeNode [label="1. HTTP POST Request\n(User Input)"];
    EdgeNode -> Runtime [label="2. Dispatch to Isolate\n(Cold or Warm)"];
    
    // Cold Start Logic (Conceptual)
    subgraph cluster_cold {
        label="Cold Start Scenario";
        color="red";
        Init [label="Initialize Runtime\n(Load Dependencies)", style="dashed"];
        Runtime -> Init [style="dashed", label="First Request"];
    }

    // Warm Execution Logic (Conceptual)
    subgraph cluster_warm {
        label="Warm Execution Scenario";
        color="green";
        Warm [label="Reuse Active Isolate", style="dashed"];
        Runtime -> Warm [style="dashed", label="Subsequent Requests"];
    }

    // External Interaction
    Runtime -> Cache [label="Check Cache", dir="both"];
    Cache -> Runtime [label="Hit (Return)", style="dotted"];
    Runtime -> LLM [label="3. Stream API Call\n(API Key Auth)"];
    LLM -> Runtime [label="4. Token Stream\n(Chunked Data)"];

    // Return Flow
    Runtime -> EdgeNode [label="5. Transform & Forward\n(Backpressure)"];
    EdgeNode -> Client [label="6. Stream to Client\n(TTFB Optimization)"];
}
