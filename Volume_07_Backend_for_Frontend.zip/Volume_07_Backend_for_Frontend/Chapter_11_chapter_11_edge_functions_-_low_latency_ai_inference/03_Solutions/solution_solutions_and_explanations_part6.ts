/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part6.ts
// Description: Solutions and Explanations
// ==========================================

// File: lib/latencyMonitor.ts

export interface LatencyMetrics {
  totalTime: number;         // Total duration from request start to stream end
  timeToFirstToken: number;  // Time from request sent to first chunk received
  timeBetweenTokens: number; // Average time between subsequent chunks
}

/**
 * Wraps an async inference generator to measure latency metrics.
 * @param inferenceGenerator Async generator yielding tokens.
 * @returns Promise<LatencyMetrics>
 */
export async function measureInferenceLatency(
  inferenceGenerator: AsyncGenerator<string, void, unknown>
): Promise<LatencyMetrics> {
  const startTime = performance.now();
  let firstTokenTime: number | null = null;
  const tokenTimestamps: number[] = [];
  
  const wrappedGenerator = async function* () {
    for await (const token of inferenceGenerator) {
      const now = performance.now();
      
      // Record time of first token
      if (firstTokenTime === null) {
        firstTokenTime = now;
      }
      
      tokenTimestamps.push(now);
      yield token;
    }
  };

  // Consume the generator to trigger execution
  // (In a real Edge Function, this would be piped to the response stream)
  for await (const _ of wrappedGenerator()) {
    // Just consume
  }

  const endTime = performance.now();
  const totalTime = endTime - startTime;
  const timeToFirstToken = firstTokenTime ? firstTokenTime - startTime : 0;

  // Calculate average time between tokens
  let timeBetweenTokens = 0;
  if (tokenTimestamps.length > 1) {
    const intervals = [];
    for (let i = 1; i < tokenTimestamps.length; i++) {
      intervals.push(tokenTimestamps[i] - tokenTimestamps[i - 1]);
    }
    timeBetweenTokens = intervals.reduce((a, b) => a + b, 0) / intervals.length;
  }

  return {
    totalTime,
    timeToFirstToken,
    timeBetweenTokens,
  };
}

// --- Simulation of Cold Start Penalty ---

// Mock inference logic
async function* mockInference() {
  // Simulate a cold start penalty (blocking the event loop)
  const coldStartBlock = 500; 
  const start = Date.now();
  while (Date.now() - start < coldStartBlock) {
    // Busy wait (DO NOT do this in production, purely for simulation)
  }

  // Simulate LLM processing
  yield "Hello";
  await new Promise(r => setTimeout(r, 50));
  yield " World";
}
