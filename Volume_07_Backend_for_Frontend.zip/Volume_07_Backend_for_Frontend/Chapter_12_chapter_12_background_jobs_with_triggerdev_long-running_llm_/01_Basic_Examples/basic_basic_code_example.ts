/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

// src/trigger/example-job.ts
import { task, retry } from "@trigger.dev/sdk/v3";
import { z } from "zod";

// 1. Define the payload schema using Zod for runtime validation.
// This ensures the job only runs with valid data, preventing type errors downstream.
const DocumentPayloadSchema = z.object({
  documentId: z.string().uuid(),
  userId: z.string(),
});

/**
 * A simulated database client for our SaaS application.
 * In a real app, this would be Prisma, Drizzle, or a direct SQL client.
 */
const mockDatabase = {
  // Simulate a slow database call
  async findDocumentById(id: string) {
    await new Promise((resolve) => setTimeout(resolve, 100)); // Simulate network latency
    if (id === "invalid-id") throw new Error("Document not found");
    return {
      id,
      content: "Trigger.dev is a powerful orchestration platform for background jobs. It simplifies running long-running tasks like LLM inference without blocking your main application threads.",
    };
  },
  // Simulate updating the document with the LLM result
  async updateDocumentSummary(id: string, summary: string) {
    console.log(`[DB] Updating document ${id} with summary.`);
    return { success: true, summary };
  },
};

/**
 * 2. Define the Background Job using Trigger.dev's `task` helper.
 * This function is the entry point for the background worker.
 */
export const summarizeDocumentTask = task({
  id: "summarize-document",
  // Define the expected input type. Trigger.dev infers this from the schema.
  schema: DocumentPayloadSchema,
  
  // 3. The main execution logic.
  // This runs in a separate process, isolated from the main web server.
  run: async (payload, { ctx }) => {
    // Log the start of the job for observability
    console.log(`Starting job for user ${payload.userId}, document ${payload.documentId}`);
    
    try {
      // 4. Fetch the document data
      const document = await mockDatabase.findDocumentById(payload.documentId);
      
      // 5. Simulate an LLM Data Transformation
      // In a real scenario, this might call an OpenAI API or run a model locally.
      // We wrap this in a retry block. If the LLM API fails (e.g., rate limit),
      // Trigger.dev will automatically retry this specific block up to 3 times.
      const summary = await retry(
        async () => {
          // Simulate LLM inference latency
          await new Promise((resolve) => setTimeout(resolve, 2000));
          
          // Simulate a potential transient error (random failure)
          if (Math.random() < 0.1) {
            throw new Error("LLM API Rate Limit Exceeded");
          }

          // Mock the LLM output
          return `Summary: ${document.content.substring(0, 50)}... [Processed by Job ID: ${ctx.run.id}]`;
        },
        { 
          maxAttempts: 3, // Retry up to 3 times
          minTimeout: 1000, // Wait at least 1 second between retries
        }
      );

      // 6. Persist the result
      await mockDatabase.updateDocumentSummary(payload.documentId, summary);

      // 7. Return the result (optional, but useful for chaining jobs)
      return {
        status: "success",
        summary,
        jobId: ctx.run.id,
      };

    } catch (error) {
      // 8. Error handling
      // If the error is not caught here, Trigger.dev marks the run as "Errored".
      // You can configure alerting (Slack, Email) in the Trigger.dev dashboard.
      console.error("Job failed permanently:", error);
      throw error; // Re-throw to ensure the failure is recorded
    }
  },
});
