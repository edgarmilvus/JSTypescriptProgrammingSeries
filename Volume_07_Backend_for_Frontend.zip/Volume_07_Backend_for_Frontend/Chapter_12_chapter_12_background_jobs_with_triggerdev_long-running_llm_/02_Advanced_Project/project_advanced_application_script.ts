/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// ==========================================
// 1. Shared Types & Utilities (Shared across Client & Server)
// ==========================================

/**
 * Defines the input shape for our research task.
 * Using `Pick` utility type to strictly control what data is needed to start the job.
 */
export type ResearchTaskInput = {
  query: string;
  maxSources: number;
  tone: 'formal' | 'casual';
};

/**
 * Defines the shape of the processed data before LLM synthesis.
 * This represents the "Chunked & Embedded" state.
 */
export interface ProcessedChunk {
  id: string;
  content: string;
  embedding: number[];
  sourceUrl: string;
}

// ==========================================
// 2. Trigger.dev Job Definition (Background Worker)
// ==========================================

// Note: In a real project, this would be in 'trigger.config.ts' or a dedicated jobs folder.
// We are simulating the Trigger.dev SDK usage for this script.

import { createJob, logger, retry } from '@trigger.dev/sdk'; // Hypothetical SDK import

/**
 * JOB: `deep-research-synthesis`
 * 
 * This job orchestrates a multi-step RAG pipeline:
 * 1. Data Loading (Simulated web search)
 * 2. Chunking & Embedding (Vectorization)
 * 3. Vector Storage (Simulated DB insertion)
 * 4. LLM Synthesis (Final generation)
 * 
 * Why use Trigger.dev?
 * - The 'run' function can exceed Vercel's 45s timeout limit.
 * - It provides built-in retry logic for flaky API calls.
 * - It maintains state (logs, progress) independent of the user's browser session.
 */
export const deepResearchJob = createJob({
  id: 'deep-research-synthesis',
  // Define the expected input payload
  payloadSchema: {
    query: { type: 'string' },
    maxSources: { type: 'number', default: 5 },
    tone: { type: 'string', enum: ['formal', 'casual'] } as const,
  },
  
  // The main execution logic
  run: async (payload, { ctx }) => {
    const { query, maxSources, tone } = payload;
    
    // STEP 1: Data Loading (Simulated)
    // In a real app, this might call a search API like SerpAPI or Brave Search.
    // We wrap this in retry logic because external APIs can be flaky.
    logger.info(`Starting research for: "${query}"`);
    
    const rawDocuments = await retry.run(
      async () => {
        // Simulate fetching documents
        return [
          { id: 'doc_1', content: `Detailed analysis of ${query}...`, url: 'https://example.com/1' },
          { id: 'doc_2', content: `Contextual data regarding ${query}...`, url: 'https://example.com/2' },
        ];
      },
      { maxAttempts: 3, delay: 1000 } // Retry up to 3 times with 1s delay
    );

    // STEP 2: Chunking & Embedding
    // Transform raw text into vector embeddings.
    // This is CPU intensive, so offloading is crucial.
    logger.info(`Processing ${rawDocuments.length} documents...`);
    
    const processedChunks: ProcessedChunk[] = [];
    
    for (const doc of rawDocuments) {
      // Simulate chunking logic (splitting text into smaller semantic units)
      const chunks = doc.content.split('...'); 
      
      for (const chunk of chunks) {
        // Simulate embedding generation (e.g., calling OpenAI embeddings API)
        const embedding = await generateMockEmbedding(chunk);
        
        processedChunks.push({
          id: `${doc.id}-${Math.random().toString(36).substr(2, 9)}`,
          content: chunk,
          embedding: embedding,
          sourceUrl: doc.url
        });
      }
    }

    // STEP 3: Vector Storage (Simulated)
    // Store embeddings in a vector database (e.g., Pinecone, pgvector).
    logger.info(`Storing ${processedChunks.length} chunks in vector DB...`);
    // await vectorDB.upsert(processedChunks); 

    // STEP 4: LLM Synthesis
    // Retrieve relevant context and generate the final answer.
    logger.info('Generating final synthesis...');
    
    // Simulate LLM call (e.g., OpenAI ChatCompletion)
    const finalResult = await new Promise<string>(resolve => {
      setTimeout(() => {
        const contextSummary = processedChunks.map(c => c.content).join('\n');
        resolve(`Tone: ${tone}\nQuery: ${query}\nContext: ${contextSummary}\n\nFinal Synthesis Generated.`);
      }, 2000);
    });

    // Return the result to be stored in Trigger.dev's database
    return {
      status: 'completed',
      synthesis: finalResult,
      processedCount: processedChunks.length,
    };
  },
});

// Mock helper for the demo
async function generateMockEmbedding(text: string): Promise<number[]> {
  // In reality: await openai.embeddings.create({ model: 'text-embedding-ada-002', input: text });
  return Array.from({ length: 1536 }, () => Math.random()); // Standard OpenAI vector size
}

// ==========================================
// 3. Next.js Server Action (The B4F Entry Point)
// ==========================================

'use server';

import { redirect } from 'next/navigation';
import { deepResearchJob } from './trigger.jobs'; // Import the job definition

/**
 * SERVER ACTION: `initiateResearch`
 * 
 * This acts as the Backend for Frontend (B4F) layer.
 * It validates user input and triggers the background job.
 * 
 * Why use React `useTransition` (Client Side)?
 * - When the client calls this action, `useTransition` keeps the UI responsive
 *   (e.g., disables the submit button, shows a spinner) without freezing the browser.
 */
export async function initiateResearch(formData: FormData) {
  // 1. Parse and Validate Input
  const query = formData.get('query') as string;
  const tone = formData.get('tone') as 'formal' | 'casual';

  if (!query || query.length < 5) {
    throw new Error('Query must be at least 5 characters long.');
  }

  // 2. Trigger the Background Job
  // We pass the payload to the Trigger.dev job.
  // This returns immediately with a handle to the run, not the result.
  const run = await deepResearchJob.trigger({
    query: query,
    maxSources: 5,
    tone: tone,
  });

  // 3. Redirect to Status Page
  // The user is redirected to a page that polls for the status of 'run.id'
  redirect(`/research/status/${run.id}`);
}
