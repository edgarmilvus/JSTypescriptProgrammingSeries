/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// job.ts
import { TriggerClient, eventTrigger } from "@trigger.dev/sdk";
import { OpenAI } from "openai";
import { createClient } from "@supabase/supabase-js";
import { RecursiveCharacterTextSplitter } from "langchain/text_splitter";

// Initialize clients (ensure these are configured with env vars)
const supabase = createClient(
  process.env.SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
);

const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

export const client = new TriggerClient({ id: "my-app" });

export const processDocument = client.defineJob({
  id: "process-document",
  name: "Process Document for Search",
  version: "1.0.0",
  trigger: eventTrigger({
    name: "process.document",
    schema: {
      fileUrl: { type: "string" },
      documentId: { type: "string" },
    },
  }),
  run: async (payload, io) => {
    const { fileUrl, documentId } = payload;

    // Step 1: Fetch file content
    // In a real app, fetch from S3/Storage. Here we simulate text extraction.
    await io.logger.info(`Fetching file from ${fileUrl}`);
    const response = await fetch(fileUrl);
    if (!response.ok) throw new Error(`Failed to fetch file: ${response.statusText}`);
    const textContent = await response.text();

    // Step 2: Chunk text
    const splitter = new RecursiveCharacterTextSplitter({
      chunkSize: 1000,
      chunkOverlap: 200,
    });
    const chunks = await splitter.splitText(textContent);
    await io.logger.info(`Split text into ${chunks.length} chunks.`);

    // Step 3 & 4: Generate embeddings and store
    // We process in batches to manage rate limits and performance
    const batchSize = 10;
    for (let i = 0; i < chunks.length; i += batchSize) {
      const batch = chunks.slice(i, i + batchSize);
      
      // We use io.runTask to create checkpoints and enable retries for the batch
      await io.runTask(
        `process-batch-${i}`,
        { retry: { maxAttempts: 3, minTimeout: 2000, factor: 2 } },
        async () => {
          // Generate embeddings for the batch
          // Note: OpenAI SDK usage
          const embeddingResponse = await openai.embeddings.create({
            model: "text-embedding-ada-002",
            input: batch,
          });

          const embeddings = embeddingResponse.data.map((item) => item.embedding);

          // Prepare data for Supabase
          const documentsToInsert = batch.map((content, index) => ({
            document_id: documentId,
            content: content,
            embedding: embeddings[index],
          }));

          // Insert into Supabase
          const { error } = await supabase
            .from("document_chunks")
            .insert(documentsToInsert);

          if (error) {
            // If Supabase fails, throw error to trigger retry logic
            throw new Error(`Supabase insert failed: ${error.message}`);
          }
          
          await io.logger.info(`Processed batch ${i} to ${i + batch.length}`);
        }
      );
    }

    // Final status update
    await io.logger.info(`Document ${documentId} processing complete.`);
  },
  // Global error handling: If the job fails permanently (after retries)
  onError: async (payload, io, error) => {
    await io.logger.error("Document processing failed permanently", { error });
    
    // Log to failed_jobs table
    await supabase.from("failed_jobs").insert({
      job_id: "process-document",
      payload: payload,
      error_message: error.message,
      created_at: new Date().toISOString(),
    });
  },
});
