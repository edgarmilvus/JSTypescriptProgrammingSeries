/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

// job.ts
import { TriggerClient, cronTrigger } from "@trigger.dev/sdk";
import { createClient } from "@supabase/supabase-js";

const supabase = createClient(
  process.env.SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
);

export const client = new TriggerClient({ id: "my-app" });

export const enrichMetadataIndices = client.defineJob({
  id: "enrich-metadata-indices",
  name: "Enrich Metadata Indices",
  version: "1.0.0",
  trigger: cronTrigger({
    // Run every hour
    cron: "0 * * * *",
  }),
  run: async (payload, io) => {
    await io.logger.info("Starting metadata enrichment job.");

    // Step 1: Fetch articles modified in the last hour
    // Note: We use a lookback window. In a real DB, you might query updated_at > NOW() - INTERVAL '1 hour'
    const oneHourAgo = new Date(Date.now() - 60 * 60 * 1000).toISOString();

    const { data: articles, error: fetchError } = await supabase
      .from("articles")
      .select("id, metadata")
      .gt("updated_at", oneHourAgo);

    if (fetchError) throw fetchError;
    if (!articles || articles.length === 0) {
      await io.logger.info("No new or updated articles found.");
      return;
    }

    await io.logger.info(`Found ${articles.length} articles to process.`);

    // Step 2: Transform Data (Flattening)
    const flattenedData = articles.map((article) => {
      const metadata = article.metadata || {};
      
      // Extract specific keys. Handle potential missing keys gracefully.
      return {
        article_id: article.id,
        author_name: metadata.author?.name || "Unknown",
        category: metadata.category || "General",
        year: metadata.year || new Date().getFullYear(),
      };
    });

    // Step 3: Upsert Logic
    // We use Supabase's upsert to insert new records or update existing ones based on article_id
    const { error: upsertError } = await supabase
      .from("search_index_metadata")
      .upsert(flattenedData, { onConflict: "article_id" });

    if (upsertError) throw upsertError;

    await io.logger.info(`Successfully upserted metadata for ${articles.length} articles.`);
  },
});
