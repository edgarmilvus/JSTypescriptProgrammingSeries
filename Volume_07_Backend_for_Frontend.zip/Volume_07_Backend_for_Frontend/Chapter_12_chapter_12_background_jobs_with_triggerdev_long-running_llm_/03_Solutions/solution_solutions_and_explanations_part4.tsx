/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.tsx
// Description: Solutions and Explanations
// ==========================================

// components/LiveQueryResult.tsx
import { useTrigger, useRun } from "@trigger.dev/react"; // Assuming standard SDK hooks
import { useState } from "react";

interface Props {
  runId: string;
}

// Mock components for the example
const Spinner = () => <div className="animate-spin">Loading...</div>;
const ProgressBar = () => <div className="w-full bg-gray-200 h-4 rounded"><div className="bg-blue-500 h-4 rounded w-1/2 animate-pulse"></div></div>;

export function LiveQueryResult({ runId }: Props) {
  // Use the hook to subscribe to the run status
  // This hook handles the polling/websocket connection internally
  const { run, isLoading, error } = useRun(runId);
  const { cancelRun } = useTrigger(); // Hook to access trigger client methods
  const [isCancelling, setIsCancelling] = useState(false);

  // Helper to extract UIState from run metadata or logs
  // In a real scenario, the job emits specific events. 
  // Here we assume the 'run' object has a 'status' and potentially 'output' or metadata.
  const status = run?.status; 
  const output = run?.output; // The final result if successful

  const handleCancel = async () => {
    if (!runId) return;
    setIsCancelling(true);
    try {
      await cancelRun(runId);
      alert("Job cancelled successfully.");
    } catch (err) {
      console.error("Failed to cancel", err);
      setIsCancelling(false);
    }
  };

  if (isLoading) return <div>Loading run details...</div>;
  if (error) return <div>Error: {error.message}</div>;

  return (
    <div className="p-4 border rounded shadow-sm">
      <h3 className="font-bold mb-2">Query Status</h3>
      
      {/* Dynamic Rendering based on Status */}
      {status === "EXECUTING" && (
        <div className="flex items-center gap-2">
          <Spinner />
          <span>Searching documents...</span>
        </div>
      )}

      {status === "SUCCESS" && (
        <div className="text-green-600">
          <p className="font-bold">Done!</p>
          <p>{output?.result}</p> 
        </div>
      )}

      {status === "CANCELED" && (
        <div className="text-red-500">Job was cancelled by user.</div>
      )}

      {status === "EXECUTING" && (
        <button 
          onClick={handleCancel} 
          disabled={isCancelling}
          className="mt-4 px-4 py-2 bg-red-500 text-white rounded hover:bg-red-600 disabled:opacity-50"
        >
          {isCancelling ? "Cancelling..." : "Cancel Job"}
        </button>
      )}
    </div>
  );
}
