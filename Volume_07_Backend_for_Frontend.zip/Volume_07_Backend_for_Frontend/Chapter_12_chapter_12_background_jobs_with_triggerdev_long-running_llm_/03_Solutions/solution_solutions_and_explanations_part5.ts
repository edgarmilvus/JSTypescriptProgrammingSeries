/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

// job.ts
import { TriggerClient, eventTrigger } from "@trigger.dev/sdk";
import { logger } from "@trigger.dev/sdk";
import { createClient } from "@supabase/supabase-js";

const supabase = createClient(
  process.env.SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
);

export const client = new TriggerClient({ id: "my-app" });

// Custom Error class for Permanent Failures
class ValidationError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "ValidationError";
  }
}

export const ingestUserCSV = client.defineJob({
  id: "ingest-user-csv",
  name: "Ingest User CSV",
  version: "1.0.0",
  trigger: eventTrigger({
    name: "ingest.csv",
    schema: {
      csvRows: { type: "array", items: { type: "string" } },
    },
  }),
  run: async (payload, io) => {
    const { csvRows } = payload;

    for (let i = 0; i < csvRows.length; i++) {
      const row = csvRows[i];
      const rowIndex = i + 1; // 1-based index for logic

      await io.logger.info(`Processing row ${rowIndex}: ${row}`);

      try {
        // We wrap the logic in io.runTask to allow granular retry configuration per row
        await io.runTask(
          `process-row-${rowIndex}`,
          {
            // RETRY CONFIGURATION:
            // This applies only if the task throws an error that isn't a ValidationError
            retry: {
              maxAttempts: 3,
              minTimeout: 2000, // 2 seconds
              factor: 2, // Exponential backoff
            },
          },
          async () => {
            // DECISION ENGINE LOGIC
            if (rowIndex === 1) {
              // Simulate Transient Error (Network blip)
              await io.logger.warn("Simulating transient network error...");
              throw new Error("Network timeout");
            } else if (rowIndex === 2) {
              // Simulate Permanent Error (Bad Data)
              await io.logger.error("Simulating validation error (permanent)...");
              // Throw custom error. We will catch this outside the task block
              // to prevent retry logic from triggering.
              throw new ValidationError("Invalid email format in row");
            } else if (rowIndex === 3) {
              // Simulate Success
              await io.logger.info("Row processed successfully.");
              return { status: "success", row: rowIndex };
            }
          }
        );
      } catch (error) {
        // ERROR HANDLING STRATEGY
        if (error instanceof ValidationError) {
          // PERMANENT FAILURE HANDLING
          await io.logger.error("Permanent error detected. Logging to DLQ.", { row: rowIndex, error: error.message });
          
          // Log to Dead Letter Queue (DLQ) in Supabase
          await supabase.from("dead_letter_queue").insert({
            row_content: row,
            error_message: error.message,
            error_type: "ValidationError",
            created_at: new Date().toISOString(),
          });
          
          // Continue to next row (don't fail the whole job)
        } else {
          // If it's not a ValidationError, re-throw it to trigger the retry mechanism defined in io.runTask
          throw error;
        }
      }
    }
  },
});
