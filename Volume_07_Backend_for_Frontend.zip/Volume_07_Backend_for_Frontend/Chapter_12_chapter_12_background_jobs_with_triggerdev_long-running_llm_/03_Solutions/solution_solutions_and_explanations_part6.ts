/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part6.ts
// Description: Solutions and Explanations
// ==========================================

// pages/api/upload.ts
import type { NextApiRequest, NextApiResponse } from 'next';
import { client } from "../../lib/trigger"; // Assumes shared Trigger client initialization

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  try {
    const { fileUrl, documentId } = req.body;

    if (!fileUrl || !documentId) {
      return res.status(400).json({ error: "Missing fileUrl or documentId" });
    }

    // TRIGGER THE JOB
    // We use the Trigger client to send an event.
    // This returns immediately; it does not wait for the job to finish.
    const handle = await client.sendEvent({
      name: "process.document",
      payload: {
        fileUrl,
        documentId,
      },
    });

    // RETURN IMMEDIATE RESPONSE
    // 202 Accepted indicates the request has been accepted for processing,
    // but the processing has not been completed.
    res.status(202).json({
      message: "Document upload accepted for processing.",
      runId: handle.id, // The runId is used by the frontend to track progress
    });

  } catch (error) {
    console.error("Error triggering job:", error);
    res.status(500).json({ error: "Internal Server Error" });
  }
}

/*
 * Frontend Polling Strategy Explanation:
 * 
 * 1. The frontend sends the file data to /api/upload.
 * 2. It receives the `runId` in the 202 response.
 * 3. The frontend should store this `runId` in local state (e.g., React useState).
 * 4. The frontend then has two main options to check status:
 * 
 *    Option A: Polling a Status Endpoint
 *      - Create a separate API route /api/status/[runId].
 *      - This route calls `client.getRun(runId)` on the server and returns the status.
 *      - The frontend uses `setInterval` or `useSWR` to poll this endpoint every few seconds.
 * 
 *    Option B: Client-Side SDK (Preferred)
 *      - Use the `@trigger.dev/react` library.
 *      - Use the `useRun(runId)` hook directly in the component.
 *      - This hook manages the polling lifecycle and updates the UI automatically when the job status changes (e.g., from EXECUTING to SUCCESS).
 * 
 * 5. UI Update: While the status is "EXECUTING", show a progress indicator. 
 *    When "SUCCESS", fetch the processed data or display the result.
 */
