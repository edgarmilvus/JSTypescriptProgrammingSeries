/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

import { NextResponse } from 'next/server'; // Assuming Next.js App Router for the HTTP wrapper
import PDFDocument from 'pdfkit';
import { z } from 'zod';
import { zodResponseFormat } from 'openai/helpers/zod';

// NOTE: In a real project, import OpenAI from 'openai'.
// For this standalone example, we mock the LLM response structure.
// import OpenAI from 'openai';

// ==========================================
// 1. TYPE DEFINITIONS & SCHEMAS
// ==========================================

/**
 * Defines the expected structure of the LLM's response.
 * Using Zod ensures type safety and runtime validation.
 */
const SummarySchema = z.object({
  title: z.string().describe("The main title of the document."),
  summary: z.string().describe("A concise 3-sentence summary of the text."),
  keyPoints: z.array(z.string()).describe("A list of 3-5 critical bullet points."),
  sentiment: z.enum(["positive", "neutral", "negative"]).describe("The overall sentiment of the text."),
});

type SummaryData = z.infer<typeof SummarySchema>;

// ==========================================
// 2. LLM INTEGRATION (MOCKED FOR SIMPLICITY)
// ==========================================

/**
 * Simulates an LLM call (e.g., OpenAI GPT-4).
 * In a real app, this would use `openai.chat.completions.create` with `response_format: { type: 'json_object' }`.
 * 
 * @param text - The raw input text to analyze.
 * @returns A Promise resolving to the structured JSON data.
 */
async function generateSmartSummary(text: string): Promise<SummaryData> {
  // --- REAL IMPLEMENTATION WOULD LOOK LIKE THIS ---
  // const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
  // const completion = await openai.chat.completions.create({
  //   model: "gpt-4-turbo-preview",
  //   messages: [
  //     { role: "system", content: "You are a precise document analyzer. Extract the following data strictly as JSON." },
  //     { role: "user", content: text }
  //   ],
  //   response_format: zodResponseFormat(SummarySchema, "summary"),
  // });
  // return JSON.parse(completion.choices[0].message.content!) as SummaryData;

  // --- MOCK IMPLEMENTATION FOR THIS EXAMPLE ---
  // Simulating a delay for network latency
  await new Promise(resolve => setTimeout(resolve, 500)); 
  
  return {
    title: "Project Alpha Report",
    summary: "This report details the initial findings of Project Alpha. The data indicates a 15% increase in efficiency. Further testing is required for Q3.",
    keyPoints: [
      "Efficiency metrics exceeded expectations.",
      "User adoption rate is stabilizing.",
      "Budget remains within projected limits."
    ],
    sentiment: "positive"
  };
}

// ==========================================
// 3. PDF GENERATION LOGIC
// ==========================================

/**
 * Generates a PDF document from structured data.
 * Uses pdfkit to create a binary buffer in memory.
 * 
 * @param data - The structured summary data.
 * @returns A Promise resolving to a Buffer containing the PDF data.
 */
async function createPdfBuffer(data: SummaryData): Promise<Buffer> {
  return new Promise((resolve, reject) => {
    // Create a new PDF document
    const doc = new PDFDocument({ margin: 50 });
    const chunks: Buffer[] = [];

    // Collect stream data into chunks
    doc.on('data', (chunk: Buffer) => chunks.push(chunk));
    
    // When the stream ends, combine chunks into a single Buffer
    doc.on('end', () => resolve(Buffer.concat(chunks)));
    doc.on('error', reject);

    // --- PDF STYLING & CONTENT ---

    // Title
    doc.fontSize(18).font('Helvetica-Bold').text(data.title, { align: 'center' });
    doc.moveDown();

    // Summary Section
    doc.fontSize(12).font('Helvetica').text("Executive Summary:", { continued: false });
    doc.font('Helvetica-Oblique').text(data.summary);
    doc.moveDown();

    // Key Points Section
    doc.font('Helvetica-Bold').text("Key Takeaways:", { continued: false });
    doc.font('Helvetica');
    data.keyPoints.forEach((point) => {
      doc.text(`• ${point}`, { indent: 15 });
    });
    doc.moveDown();

    // Metadata Footer
    doc.fontSize(10).fillColor('gray').text(`Sentiment: ${data.sentiment.toUpperCase()}`, { align: 'right' });
    doc.text(`Generated on: ${new Date().toLocaleDateString()}`, { align: 'right' });

    // Finalize the PDF
    doc.end();
  });
}

// ==========================================
// 4. API ENDPOINT (NEXT.JS APP ROUTER)
// ==========================================

/**
 * POST /api/generate-pdf
 * 
 * Request Body: { text: string }
 * Response: PDF Binary Stream
 */
export async function POST(req: Request) {
  try {
    // 1. Parse Input
    const { text } = await req.json();

    if (!text || typeof text !== 'string') {
      return NextResponse.json(
        { error: "Invalid input: 'text' field is required." },
        { status: 400 }
      );
    }

    // 2. Generate Smart Summary (LLM Step)
    const summaryData = await generateSmartSummary(text);

    // 3. Generate PDF (Rendering Step)
    const pdfBuffer = await createPdfBuffer(summaryData);

    // 4. Return Binary Stream
    return new NextResponse(pdfBuffer, {
      headers: {
        'Content-Type': 'application/pdf',
        'Content-Disposition': `attachment; filename="summary-${Date.now()}.pdf"`,
        'Content-Length': pdfBuffer.length.toString(),
      },
    });

  } catch (error) {
    console.error("Error generating PDF:", error);
    return NextResponse.json(
      { error: "Failed to generate PDF." },
      { status: 500 }
    );
  }
}
