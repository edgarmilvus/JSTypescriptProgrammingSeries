/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// app/api/generate-summary-pdf/route.ts

import { NextRequest, NextResponse } from 'next/server';
import { streamToBuffer } from '@vercel/blob/stream';
import PDFDocument from 'pdfkit';
import { streamText } from 'ai';
import { openai } from '@ai-sdk/openai';

// -----------------------------------------------------------------------------
// Types & Interfaces
// -----------------------------------------------------------------------------

/**
 * Defines the structured output expected from the LLM.
 * This ensures the PDF generator receives predictable data fields.
 */
interface DocumentAnalysis {
  title: string;
  summary: string;
  keywords: string[];
  sentiment: 'positive' | 'neutral' | 'negative';
}

// -----------------------------------------------------------------------------
// API Route Handler (Edge Runtime)
// -----------------------------------------------------------------------------

export const runtime = 'edge'; // Use Edge Runtime for low-latency execution

/**
 * POST Handler: Processes raw text, generates intelligent summary via LLM,
 * and streams back a generated PDF.
 * 
 * @param {NextRequest} req - The incoming HTTP request containing raw text.
 * @returns {Promise<NextResponse>} - A PDF file stream or an error response.
 */
export async function POST(req: NextRequest) {
  try {
    // 1. Extract raw text from the request body
    const { text } = await req.json();

    if (!text || typeof text !== 'string') {
      return new NextResponse('Invalid input: "text" field is required.', { status: 400 });
    }

    // 2. LLM Processing: Generate structured JSON data
    // We use a system prompt to force the LLM to act as a document analyst.
    const result = await streamText({
      model: openai('gpt-4-turbo-preview'),
      messages: [
        {
          role: 'system',
          content: `
            You are an expert document analyst. Analyze the provided text and extract the following information.
            Output strictly valid JSON matching this schema: 
            {
              "title": "string (short, catchy title)",
              "summary": "string (3-5 sentences)",
              "keywords": "string[] (max 5)",
              "sentiment": "positive | neutral | negative"
            }
            Do not include any markdown formatting or conversational text outside the JSON.
          `,
        },
        { role: 'user', content: text },
      ],
      temperature: 0.2, // Low temperature for deterministic extraction
    });

    // 3. Collect the LLM stream into a string
    // Since we need the full JSON object before generating the PDF, 
    // we must consume the stream here.
    let rawJsonResponse = '';
    for await (const chunk of result.textStream) {
      rawJsonResponse += chunk;
    }

    // 4. Parse and Validate the LLM Output
    let analysis: DocumentAnalysis;
    try {
      // Attempt to clean and parse the JSON
      const cleanedJson = rawJsonResponse.replace(/