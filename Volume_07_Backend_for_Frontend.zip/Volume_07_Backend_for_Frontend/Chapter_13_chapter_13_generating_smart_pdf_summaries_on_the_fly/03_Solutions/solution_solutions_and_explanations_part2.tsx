/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.tsx
// Description: Solutions and Explanations
// ==========================================

'use client';

import { useCompletion } from 'ai/react';
import ReactMarkdown from 'react-markdown'; // Assuming you have a markdown renderer
import { useState } from 'react';

export default function SmartSummaryPanel() {
  const [inputText, setInputText] = useState('');
  
  // Destructure state and functions from the hook
  const { completion, input, isLoading, error, handleInputChange, handleSubmit, stop } = useCompletion({
    api: '/api/summarize',
    body: {
      // We map our local state to the hook's input if needed, 
      // but useCompletion manages its own input state. 
      // For clarity, we will bind the hook's input directly to the textarea.
    },
  });

  // Custom handler to sync our local state with the hook's submission
  const handleGenerate = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!input.trim()) return;
    handleSubmit(e);
  };

  return (
    <div className="max-w-4xl mx-auto p-6 bg-white shadow-lg rounded-lg">
      <h2 className="text-2xl font-bold mb-4 text-gray-800">Smart Summary Panel</h2>
      
      {/* Input Area */}
      <form onSubmit={handleGenerate} className="mb-6">
        <textarea
          value={input}
          onChange={handleInputChange}
          placeholder="Paste your research abstract or meeting transcript here..."
          className="w-full h-32 p-4 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:outline-none transition resize-y"
          disabled={isLoading}
        />
        <div className="mt-3 flex gap-3">
          <button
            type="submit"
            disabled={isLoading}
            className="px-6 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition"
          >
            {isLoading ? 'Generating...' : 'Generate Summary'}
          </button>
          {isLoading && (
            <button
              type="button"
              onClick={stop}
              className="px-6 py-2 bg-gray-500 text-white rounded-md hover:bg-gray-600 transition"
            >
              Cancel
            </button>
          )}
        </div>
      </form>

      {/* Error Display */}
      {error && (
        <div className="mb-4 p-4 bg-red-50 border border-red-200 text-red-700 rounded-md">
          <strong>Error:</strong> {error.message}
        </div>
      )}

      {/* Loading Indicator */}
      {isLoading && (
        <div className="flex items-center gap-2 text-gray-500 mb-4">
          <svg className="animate-spin h-5 w-5" viewBox="0 0 24 24">
            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none"></circle>
            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
          </svg>
          <span>AI is analyzing text...</span>
        </div>
      )}

      {/* Output Area */}
      {completion && (
        <div className="prose max-w-none bg-gray-50 p-6 rounded-md border border-gray-200">
          <h3 className="text-lg font-semibold text-gray-900 mb-2">Summary Result</h3>
          <ReactMarkdown>{completion}</ReactMarkdown>
        </div>
      )}
    </div>
  );
}
