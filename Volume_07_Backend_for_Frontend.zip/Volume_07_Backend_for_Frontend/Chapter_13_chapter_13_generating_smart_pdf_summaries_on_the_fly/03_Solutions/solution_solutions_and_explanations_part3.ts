/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

import { tool } from 'ai'; // Assuming AI SDK or LangChain tool definition
import { z } from 'zod';

// Mock Database for validation
const VALID_PRIORITIES = ['High', 'Medium', 'Low'];

// Tool 1: Extract Entity
export const extractEntityTool = tool({
  description: 'Extracts a specific entity type from the context text.',
  parameters: z.object({
    entityType: z.string().describe('The type of entity to extract (e.g., ticket_id, priority_level)'),
    context: z.string().describe('The text to search within.'),
  }),
  execute: async ({ entityType, context }) => {
    // Simulating extraction logic (Regex or simple string matching for demo)
    // In a real scenario, this might call a specialized NLP model.
    const regexMap: Record<string, RegExp> = {
      ticket_id: /ID[:\s]*(\w+-\d+)/i,
      priority_level: /priority[:\s]*(High|Medium|Low)/i,
      affected_services: /service[s]?[:\s]*([\w\s,]+)/i,
    };

    const regex = regexMap[entityType];
    if (!regex) return `Entity type '${entityType}' not supported.`;

    const match = context.match(regex);
    return match ? match[1].trim() : `No '${entityType}' found in context.`;
  },
});

// Tool 2: Validate Priority
export const validatePriorityTool = tool({
  description: 'Validates if a priority level is acceptable.',
  parameters: z.object({
    priority: z.string().describe('The priority level to validate.'),
  }),
  execute: async ({ priority }) => {
    const isValid = VALID_PRIORITIES.includes(priority);
    return {
      valid: isValid,
      message: isValid ? 'Priority is valid.' : `Invalid priority. Must be one of: ${VALID_PRIORITIES.join(', ')}`,
    };
  },
});
