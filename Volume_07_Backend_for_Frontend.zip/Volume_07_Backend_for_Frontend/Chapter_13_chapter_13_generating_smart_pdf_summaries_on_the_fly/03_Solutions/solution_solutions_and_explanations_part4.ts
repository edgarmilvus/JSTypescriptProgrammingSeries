/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

import { StateGraph, END, Message } from '@langchain/langgraph';
import { ChatOpenAI } from '@langchain/openai';
import { ToolNode } from '@langchain/langgraph/prebuilt';
import { extractEntityTool, validatePriorityTool } from './tools';

// Define State
const StateAnnotation = {
  messages: { reducer: (curr: Message[], update: Message[]) => [...curr, ...update], default: () => [] },
  ticketData: { reducer: (curr: object, update: object) => ({ ...curr, ...update }), default: () => ({}) },
};

const llm = new ChatOpenAI({ model: 'gpt-3.5-turbo', temperature: 0 }).bindTools([
  extractEntityTool,
  validatePriorityTool,
]);

// Define Nodes
const reasoningNode = async (state: typeof StateAnnotation) => {
  const { messages, ticketData } = state;
  
  // System prompt instructing the agent on the goal
  const systemPrompt = `
    You are an extraction agent. Your goal is to extract ticket_id, priority_level, and affected_services from the email.
    You have tools to extract entities and validate priorities.
    Current extracted data: ${JSON.stringify(ticketData)}
    Once you have extracted and validated all data, output the final JSON object and finish.
  `;

  const response = await llm.invoke([{ role: 'system', content: systemPrompt }, ...messages]);
  return { messages: [response] };
};

const toolNode = new ToolNode([extractEntityTool, validatePriorityTool]);

// Define Conditional Edge (Router)
const shouldContinue = (state: typeof StateAnnotation) => {
  const lastMessage = state.messages[state.messages.length - 1];
  
  // If the LLM has no tool calls and says it's done, end
  if (!lastMessage.additional_kwargs?.tool_calls?.length) {
    // Check if content looks like final JSON
    return 'end'; 
  }
  return 'continue';
};

// Build Graph
const workflow = new StateGraph(StateAnnotation)
  .addNode('agent', reasoningNode)
  .addNode('tools', toolNode)
  .addEdge('tools', 'agent') // After acting, go back to reasoning
  .addConditionalEdges('agent', shouldContinue, {
    continue: 'tools',
    end: END,
  })
  .addEdge('__start__', 'agent');

export const app = workflow.compile();
