/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

import { NextRequest } from 'next/server';
import { app } from '@/lib/agentGraph';

export async function POST(req: NextRequest) {
  const { emailText } = await req.json();

  // Limit iterations to prevent infinite loops
  const config = { recursionLimit: 5 };

  try {
    const inputs = { 
      messages: [{ role: 'user', content: emailText }], 
      ticketData: {} 
    };

    const finalState = await app.invoke(inputs, config);
    
    // Extract the final text response from the last message
    const lastMessage = finalState.messages[finalState.messages.length - 1];
    
    // Attempt to parse the LLM's final output as JSON
    // Note: In production, you'd use a Zod schema here to validate strictly.
    let extractedData = {};
    try {
      extractedData = JSON.parse(lastMessage.content);
    } catch {
      // Fallback if LLM returns text instead of JSON
      extractedData = { rawOutput: lastMessage.content };
    }

    return new Response(JSON.stringify(extractedData), { status: 200 });
  } catch (error) {
    console.error('Agent Error:', error);
    return new Response(JSON.stringify({ error: 'Extraction failed or timed out' }), { status: 500 });
  }
}
