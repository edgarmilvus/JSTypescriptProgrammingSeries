/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part6.ts
// Description: Solutions and Explanations
// ==========================================

import { NextRequest } from 'next/server';
import { generateObject } from 'ai';
import { openai } from '@ai-sdk/openai';
import { z } from 'zod';
import PDFDocument from 'pdfkit';
import { PassThrough } from 'stream';

// 1. Define Zod Schema
const ReportSchema = z.object({
  title: z.string(),
  summary: z.string(),
  bulletPoints: z.array(z.string()),
  references: z.array(z.string()).optional(),
});

export const runtime = 'edge'; // Or Node.js runtime if pdfkit requires Node APIs

export async function POST(req: NextRequest) {
  const { query } = await req.json();

  if (!query) return new Response('Query required', { status: 400 });

  try {
    // 2. Generate Structured Object
    const { object } = await generateObject({
      model: openai('gpt-3.5-turbo'),
      schema: ReportSchema,
      prompt: `Generate a detailed analysis report for the following query: ${query}`,
    });

    // 3. Generate PDF
    // We use a PassThrough stream to bridge the PDF document and the HTTP response
    const pdfStream = new PassThrough();
    
    // Create PDF Document
    const doc = new PDFDocument({ margin: 50, size: 'A4' });
    
    // Pipe PDF to our PassThrough stream
    doc.pipe(pdfStream);

    // Styling: Header
    doc.rect(0, 0, doc.page.width, 60).fill('#003366'); // Blue background
    doc.fillColor('white')
       .fontSize(22)
       .text(object.title, 50, 25, { align: 'left' });
    
    // Styling: Body
    doc.fillColor('black')
       .fontSize(12)
       .moveDown(2); // Spacer

    // Summary
    doc.fontSize(14).text('Summary:', { continued: false });
    doc.fontSize(11).text(object.summary);
    doc.moveDown();

    // Bullet Points
    if (object.bulletPoints && object.bulletPoints.length > 0) {
      doc.fontSize(14).text('Key Points:', { continued: false });
      object.bulletPoints.forEach((point: string) => {
        doc.fontSize(11).text(`• ${point}`);
      });
      doc.moveDown();
    }

    // References
    if (object.references && object.references.length > 0) {
      doc.fontSize(14).text('References:', { continued: false });
      doc.fontSize(10).fillColor('gray');
      object.references.forEach((ref: string) => {
        doc.text(ref);
      });
    }

    // Finalize PDF
    doc.end();

    // 4. Return Stream
    // Note: Edge runtimes might not support Node streams directly. 
    // If using Edge, we might need to convert to Uint8Array chunks. 
    // For this example, we assume Node runtime or a compatible stream adapter.
    // If strictly Edge, we would use a library like `pdf-lib` which works with Uint8Arrays.
    
    // For Edge compatibility, let's assume we collect chunks (simplified for Edge)
    // In a real Edge scenario, use `@vercel/functions` or similar.
    // Here, we return the stream directly assuming Node runtime or compatible polyfill.
    
    return new Response(pdfStream as any, {
      headers: {
        'Content-Type': 'application/pdf',
        'Content-Disposition': `attachment; filename="report-${Date.now()}.pdf"`,
      },
    });

  } catch (error) {
    console.error(error);
    return new Response(JSON.stringify({ error: 'Generation failed' }), { status: 500 });
  }
}
