/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

// File: emailGenerator.ts

/**
 * @description Simulates a user in our SaaS application.
 * In a real app, this would come from a database (e.g., PostgreSQL, MongoDB).
 */
interface User {
  id: string;
  name: string;
  email: string;
  plan: 'free' | 'pro' | 'enterprise';
  signupDate: Date;
}

/**
 * @description Represents the structured output from our LLM generation.
 * This ensures the LLM returns data in a predictable format (JSON).
 */
interface EmailContent {
  subject: string;
  body: string;
}

/**
 * @description Mock LLM Provider.
 * In production, this would be a call to OpenAI, Anthropic, or a local model via an SDK.
 * We use a mock here to keep the example self-contained and fast.
 * 
 * @param userContext - The user data to personalize the email.
 * @returns A Promise resolving to a JSON string (simulating an API response).
 */
async function callMockLLMProvider(userContext: User): Promise<string> {
  // Simulate network latency
  await new Promise(resolve => setTimeout(resolve, 150));

  // In a real scenario, we would construct a detailed prompt here.
  // Example: "Generate a welcome email for {user.name} on the {user.plan} plan..."
  // The LLM would respond with JSON. We simulate that response here.
  
  const mockResponse = {
    subject: `Welcome to the ${userContext.plan.toUpperCase()} Plan, ${userContext.name}!`,
    body: `Hi ${userContext.name},\n\nWe are thrilled to have you on board. Your account was created on ${userContext.signupDate.toDateString()}.\n\nAs a ${userContext.plan} user, you have access to specific features. Let's get started!`,
  };

  return JSON.stringify(mockResponse);
}

/**
 * @description Parses the LLM response and validates the structure.
 * This is a critical step to prevent hallucinated JSON or malformed data.
 * 
 * @param llmResponse - The raw string response from the LLM.
 * @returns A validated EmailContent object.
 * @throws Error if parsing fails or schema is invalid.
 */
function parseAndValidateLLMOutput(llmResponse: string): EmailContent {
  try {
    const parsed = JSON.parse(llmResponse) as EmailContent;
    
    // Basic validation: Ensure required fields exist
    if (!parsed.subject || !parsed.body) {
      throw new Error("LLM response missing 'subject' or 'body' fields.");
    }
    
    return parsed;
  } catch (error) {
    console.error("Failed to parse LLM response:", error);
    // Fallback content if AI generation fails
    return {
      subject: "Welcome to Our Service",
      body: "Thank you for signing up. We are processing your request."
    };
  }
}

/**
 * @description Mock Email Sending Service (e.g., Resend, SendGrid, Postmark).
 * In production, this would integrate with the actual provider's SDK.
 * 
 * @param email - The recipient's email address.
 * @param content - The validated email content.
 */
async function sendTransactionalEmail(email: string, content: EmailContent): Promise<void> {
  console.log(`--- Sending Email to ${email} ---`);
  console.log(`Subject: ${content.subject}`);
  console.log(`Body: ${content.body}`);
  console.log('------------------------------------');
  // Simulate successful send
  await new Promise(resolve => setTimeout(resolve, 100));
}

/**
 * @description Main Orchestrator Function.
 * This acts as the entry point for the transactional email pipeline.
 * It handles the flow: User Data -> LLM -> Validation -> Email Dispatch.
 * 
 * @param userId - The ID of the user triggering the email.
 */
export async function generateAndSendTransactionalEmail(userId: string): Promise<void> {
  // 1. MOCK DATA FETCH
  // In a real app, query your database here.
  const mockUser: User = {
    id: userId,
    name: "Alice Developer",
    email: "alice@example.com",
    plan: "pro",
    signupDate: new Date(),
  };

  try {
    // 2. AI GENERATION (Headless Inference)
    // We call the LLM asynchronously. This is non-blocking if handled in a background job.
    const llmRawResponse = await callMockLLMProvider(mockUser);

    // 3. DATA TRANSFORMATION & VALIDATION
    // Transform raw LLM text into structured data.
    const emailContent = parseAndValidateLLMOutput(llmRawResponse);

    // 4. EMAIL DISPATCH
    // Send the structured data to the email provider.
    await sendTransactionalEmail(mockUser.email, emailContent);

    console.log("Transactional email pipeline completed successfully.");
  } catch (error) {
    console.error("Pipeline failed:", error);
    // In a real app, log this to a monitoring service (e.g., Sentry, Datadog).
  }
}

// --- Execution for Demonstration ---
// In a serverless environment, this would be triggered by an HTTP request.
// We run it here to demonstrate the output.
(async () => {
  await generateAndSendTransactionalEmail("user-123");
})();
