/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// app/actions/email-actions.ts
'use server';

import { createClient } from '@supabase/supabase-js';
import { OpenAI } from 'openai'; // Assuming OpenAI SDK for LLM capabilities

// ============================================================================
// 1. CONFIGURATION & TYPES
// ============================================================================

// Initialize Supabase Client for Server Actions
const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL!;
const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY!;
const supabase = createClient(supabaseUrl, supabaseServiceKey);

// Initialize OpenAI (or other LLM provider)
const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

/**
 * Represents the state of our email generation graph.
 * This is the "Graph State" referenced in the Conditional Edge definition.
 */
interface EmailGraphState {
  userId: string;
  userEmail: string;
  rawData: any[]; // Fetched activity data
  generatedContent: string | null; // The AI-generated email body
  status: 'pending' | 'generating' | 'decision' | 'sending' | 'queued' | 'failed';
  priority: 'high' | 'low';
}

// ============================================================================
// 2. CORE LOGIC: THE CONDITIONAL EDGE & STATE MACHINE
// ============================================================================

/**
 * Orchestrates the email generation pipeline using a state machine pattern.
 * 
 * This function acts as the entry point for the Server Action. It initializes
 * the state and sequentially calls processing nodes. In a full LangGraph
 * implementation, this would be replaced by graph compilation and `.stream()`.
 * 
 * @param userId - The ID of the user requesting the digest.
 * @returns A promise resolving to the final status.
 */
export async function generateAndSendDigest(
  userId: string
): Promise<{ success: boolean; message: string }> {
  // Initialize State
  let state: EmailGraphState = {
    userId,
    userEmail: '',
    rawData: [],
    generatedContent: null,
    status: 'pending',
    priority: 'low',
  };

  try {
    // --- Node 1: Data Fetching ---
    state = await nodeFetchData(state);
    if (!state.rawData.length) {
      return { success: false, message: 'No activity found.' };
    }

    // --- Node 2: LLM Generation ---
    state = await nodeGenerateContent(state);

    // --- Node 3: Conditional Edge (Decision Logic) ---
    // This is the "Conditional Edge" defined in the context.
    // It inspects the Graph State and determines the next node.
    const nextNode = await conditionalEdgeRouter(state);

    // --- Node 4: Execution (Branching) ---
    if (nextNode === 'send_email') {
      state = await nodeSendEmail(state);
    } else if (nextNode === 'queue_email') {
      state = await nodeQueueEmail(state);
    } else {
      throw new Error('Invalid routing decision.');
    }

    // --- Node 5: Persistence ---
    await nodePersistLog(state);

    return { success: true, message: `Digest processed: ${state.status}` };
  } catch (error) {
    console.error('Pipeline failed:', error);
    state.status = 'failed';
    // Ideally, log error to DB here
    return { success: false, message: 'Internal server error.' };
  }
}

// ============================================================================
// 3. NODE IMPLEMENTATIONS
// ============================================================================

/**
 * Node: Fetch Data
 * Queries the Supabase database for recent user activity.
 */
async function nodeFetchData(state: EmailGraphState): Promise<EmailGraphState> {
  // Simulate fetching user email and activity logs
  const { data: profile } = await supabase
    .from('profiles')
    .select('email')
    .eq('id', state.userId)
    .single();

  const { data: activities } = await supabase
    .from('user_activities')
    .select('*')
    .eq('user_id', state.userId)
    .order('created_at', { ascending: false })
    .limit(5);

  return {
    ...state,
    userEmail: profile?.email || '',
    rawData: activities || [],
    status: 'generating',
  };
}

/**
 * Node: Generate Content (LLM)
 * Transforms raw data into natural language using prompt engineering.
 * 
 * Under the Hood:
 * 1. We construct a prompt that includes the raw JSON data.
 * 2. We instruct the LLM to act as a "Helpful Assistant" summarizing the week.
 * 3. We request a safe, professional tone to minimize hallucination risks.
 */
async function nodeGenerateContent(state: EmailGraphState): Promise<EmailGraphState> {
  const prompt = `
    You are an AI assistant for a SaaS platform. Summarize the following user activities into a concise, friendly email body (max 150 words).
    Context: The user's name is ${state.userId}.
    Activities: ${JSON.stringify(state.rawData)}
    
    Format: HTML (simple paragraphs, no heavy styling).
    Tone: Professional but warm.
  `;

  const completion = await openai.chat.completions.create({
    model: 'gpt-3.5-turbo', // Use a fast, cost-effective model for this
    messages: [{ role: 'user', content: prompt }],
    temperature: 0.7,
  });

  const content = completion.choices[0]?.message?.content || '';

  return {
    ...state,
    generatedContent: content,
    status: 'decision',
  };
}

/**
 * Conditional Edge: Router
 * Inspects the state to determine the execution path.
 * 
 * Logic:
 * - If content contains flagged words (e.g., "error", "urgent"), route to 'queue_email' for manual review.
 * - If user preference is 'high_priority', route to 'send_email' immediately.
 * - Otherwise, default to 'queue_email' for batch processing (simulating Edge Function backgrounding).
 */
async function conditionalEdgeRouter(state: EmailGraphState): Promise<string> {
  // Simulate content safety check
  const riskyKeywords = ['error', 'problem', 'urgent'];
  const isRisky = riskyKeywords.some((word) =>
    state.generatedContent?.toLowerCase().includes(word)
  );

  // Simulate checking user preference (e.g., from DB)
  // For this demo, we assume high priority if activity count > 3
  const isHighPriority = state.rawData.length > 3;

  if (isRisky) {
    // Always queue risky content for human review
    state.priority = 'low';
    return 'queue_email';
  }

  if (isHighPriority) {
    state.priority = 'high';
    return 'send_email';
  }

  // Default path: Queue for background processing (Edge Function)
  state.priority = 'low';
  return 'queue_email';
}

/**
 * Node: Send Email
 * Directly sends the email using a provider (e.g., Resend, SendGrid).
 * This is the "Fast Path" for high-priority items.
 */
async function nodeSendEmail(state: EmailGraphState): Promise<EmailGraphState> {
  // Mock email provider API call
  console.log(`[PROVIDER API] Sending email to ${state.userEmail}...`);
  // await provider.emails.send({ to: state.userEmail, html: state.generatedContent });
  
  return { ...state, status: 'sending' };
}

/**
 * Node: Queue Email
 * Offloads the email to a background queue (e.g., Vercel Q-Stash, Redis, or Supabase Edge Functions).
 * This prevents blocking the Server Action and allows for retries.
 */
async function nodeQueueEmail(state: EmailGraphState): Promise<EmailGraphState> {
  // Mock queueing mechanism
  console.log(`[QUEUE] Adding job for ${state.userEmail} to background worker...`);
  // await queueClient.enqueue('send_weekly_digest', { ...state });
  
  return { ...state, status: 'queued' };
}

/**
 * Node: Persist Log
 * Records the transaction outcome to the database for auditing.
 */
async function nodePersistLog(state: EmailGraphState) {
  await supabase.from('email_logs').insert({
    user_id: state.userId,
    type: 'weekly_digest',
    status: state.status,
    priority: state.priority,
    generated_content_preview: state.generatedContent?.substring(0, 100),
    sent_at: new Date().toISOString(),
  });
}
