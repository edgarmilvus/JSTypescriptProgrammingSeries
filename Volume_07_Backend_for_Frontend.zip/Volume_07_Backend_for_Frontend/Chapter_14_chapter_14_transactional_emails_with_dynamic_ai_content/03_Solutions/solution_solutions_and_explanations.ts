/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// File: supabase/functions/generate-welcome-email/index.ts

import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

// Define the payload interface
interface WelcomeEmailPayload {
  user_name: string;
  subscription_plan: 'starter' | 'pro' | 'enterprise';
  usage_summary: string;
  tone?: 'enthusiastic' | 'formal' | 'concise'; // Optional dynamic tone
}

// Define the expected LLM response structure
interface LLMResponse {
  subject: string;
  body: string;
}

serve(async (req) => {
  // 1. Input Handling
  const payload: WelcomeEmailPayload = await req.json();
  const { user_name, subscription_plan, usage_summary, tone = 'enthusiastic' } = payload;

  // Basic validation
  if (!user_name || !subscription_plan) {
    return new Response(JSON.stringify({ error: "Missing required fields" }), {
      status: 400,
      headers: { "Content-Type": "application/json" },
    });
  }

  try {
    // 2. LLM Integration (Using OpenAI via fetch for this example)
    // In a real scenario, you might use `import { ai } from '@supabase/ai'`
    
    const prompt = `
      You are a helpful assistant generating a welcome email for a SaaS application.
      
      User Details:
      - Name: ${user_name}
      - Plan: ${subscription_plan}
      - Recent Activity: ${usage_summary}
      
      Instructions:
      1. Adopt a ${tone} tone.
      2. Acknowledge their specific subscription plan.
      3. Reference their recent activity to provide a contextual tip.
      4. Output STRICTLY valid JSON with keys "subject" and "body".
      5. Do not include any markdown formatting or text outside the JSON object.

      Example Output:
      {
        "subject": "Welcome to the Pro Plan!",
        "body": "Hi John, ..."
      }
    `;

    const OPENAI_API_KEY = Deno.env.get("OPENAI_API_KEY");
    
    const response = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${OPENAI_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "gpt-3.5-turbo",
        messages: [{ role: "user", content: prompt }],
        temperature: 0.7,
      }),
    });

    const data = await response.json();
    const content = data.choices[0].message.content.trim();

    // 3. Parse and Validate JSON
    let emailData: LLMResponse;
    try {
      emailData = JSON.parse(content);
    } catch (e) {
      // Fallback or retry logic if LLM returns non-JSON
      throw new Error("LLM returned invalid JSON format.");
    }

    // 4. Return Structured Response
    return new Response(JSON.stringify(emailData), {
      status: 200,
      headers: { "Content-Type": "application/json" },
    });

  } catch (error) {
    // 5. Error Handling
    console.error(error);
    return new Response(JSON.stringify({ error: error.message }), {
      status: 500,
      headers: { "Content-Type": "application/json" },
    });
  }
});
