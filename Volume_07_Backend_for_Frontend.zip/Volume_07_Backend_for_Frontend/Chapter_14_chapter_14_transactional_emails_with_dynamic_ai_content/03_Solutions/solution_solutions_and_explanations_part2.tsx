/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.tsx
// Description: Solutions and Explanations
// ==========================================

// File: app/components/EmailPreview.tsx
"use server"; // Marks this as a Server Component / Server Action container

import { Suspense } from "react";

// 1. Type Safety Interfaces
interface EmailData {
  subject: string;
  body: string;
}

interface EmailPreviewProps {
  userData: {
    name: string;
    plan: string;
    summary: string;
  };
}

// 2. Data Fetching Logic
async function fetchEmailContent(userData: EmailPreviewProps['userData']): Promise<EmailData> {
  // In a real app, this would be the Edge Function URL
  const res = await fetch(`${process.env.SUPABASE_URL}/functions/v1/generate-welcome-email`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      user_name: userData.name,
      subscription_plan: userData.plan,
      usage_summary: userData.summary,
      tone: "enthusiastic",
    }),
    // Cache: 'no-store' ensures fresh generation on every request
    cache: 'no-store' 
  });

  if (!res.ok) {
    throw new Error("Failed to generate email");
  }

  return res.json();
}

// 3. Server Action for Regeneration
export async function regenerateEmail(prevState: any, formData: FormData) {
  'use server';
  const name = formData.get('name') as string;
  const plan = formData.get('plan') as string;
  const summary = formData.get('summary') as string;
  
  try {
    const data = await fetchEmailContent({ name, plan, summary });
    return { success: true, data };
  } catch (error) {
    return { success: false, error: error.message };
  }
}

// 4. Async Component Wrapper (The "Suspense" boundary)
async function EmailContent({ userData }: EmailPreviewProps) {
  const email = await fetchEmailContent(userData);

  return (
    <div style={{ border: '1px solid #ccc', padding: '1rem', borderRadius: '8px' }}>
      <h2 style={{ borderBottom: '1px solid #eee', paddingBottom: '0.5rem' }}>
        {email.subject}
      </h2>
      <p style={{ whiteSpace: 'pre-wrap' }}>{email.body}</p>
    </div>
  );
}

// 5. Skeleton Loader Component
function EmailSkeleton() {
  return (
    <div style={{ border: '1px solid #ccc', padding: '1rem', borderRadius: '8px' }}>
      <div style={{ height: '24px', width: '60%', background: '#eee', marginBottom: '1rem', animation: 'pulse 1.5s infinite' }}></div>
      <div style={{ height: '16px', width: '100%', background: '#eee', marginBottom: '0.5rem', animation: 'pulse 1.5s infinite' }}></div>
      <div style={{ height: '16px', width: '80%', background: '#eee', animation: 'pulse 1.5s infinite' }}></div>
    </div>
  );
}

// 6. Main Component
export default function EmailPreview({ userData }: EmailPreviewProps) {
  return (
    <div>
      {/* Suspense boundary handles the async state */}
      <Suspense fallback={<EmailSkeleton />}>
        <EmailContent userData={userData} />
      </Suspense>
    </div>
  );
}
