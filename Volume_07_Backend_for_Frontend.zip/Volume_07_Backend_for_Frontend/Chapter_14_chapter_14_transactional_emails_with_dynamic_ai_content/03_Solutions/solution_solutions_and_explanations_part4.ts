/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

// File: supabase/functions/retrieve-context/index.ts
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

// 1. Database Schema Definition (Assumed)
interface ActivityLog {
  description: string;
  created_at: string;
}

// 2. Function to retrieve context
async function getRelevantContext(
  userId: string, 
  userEmbedding: number[], 
  timeFilterDays: number = 7
): Promise<string> {
  
  const supabase = createClient(
    Deno.env.get("SUPABASE_URL")!,
    Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
  );

  // 3. Vector Search Logic with Time Filtering
  // Note: We assume the 'embedding' column is of type vector(1536)
  const { data: logs, error } = await supabase
    .rpc('match_user_activities', {
      query_embedding: userEmbedding,
      match_count: 3,
      user_id_param: userId,
      days_back: timeFilterDays // Passing time filter to the function
    });

  if (error) {
    console.error("Vector search failed:", error);
    throw new Error("Context retrieval failed");
  }

  // 4. Format Context
  if (!logs || logs.length === 0) {
    return "No recent activity found.";
  }

  // Map descriptions to a single string
  const contextString = logs
    .map((log: ActivityLog) => log.description)
    .join(", ");

  return contextString;
}

// 5. Privacy Check Implementation
/*
   PRIVACY CONSIDERATIONS:
   1. Data Minimization: We only select the 'description' column. 
      We explicitly avoid selecting 'user_id', 'ip_address', or 'metadata' 
      which might contain PII.
   2. Aggregation: The descriptions are joined into a single string. 
      We do not pass raw database rows to the LLM.
   3. Prompt Injection Defense: Although the context comes from our DB, 
      we should sanitize the text to remove potential prompt injection 
      attempts (e.g., removing special instruction characters) before 
      passing it to the LLM.
   4. Access Control: This function uses the Service Role Key, bypassing 
      RLS, but is restricted to the Edge Function context. 
      Ensure the Edge Function is protected by rate limiting.
*/

// Example SQL Function (Postgres) to support the JS query:
/*
CREATE OR REPLACE FUNCTION match_user_activities(
  query_embedding vector(1536),
  match_count int,
  user_id_param uuid,
  days_back int
)
RETURNS TABLE (description text, created_at timestamptz)
LANGUAGE plpgsql
AS $$
BEGIN
  RETURN QUERY
  SELECT 
    ual.description,
    ual.created_at
  FROM user_activity_logs ual
  WHERE ual.user_id = user_id_param
    AND ual.created_at > NOW() - (days_back || ' days')::INTERVAL
  ORDER BY ual.embedding <-> query_embedding
  LIMIT match_count;
END;
$$;
*/
