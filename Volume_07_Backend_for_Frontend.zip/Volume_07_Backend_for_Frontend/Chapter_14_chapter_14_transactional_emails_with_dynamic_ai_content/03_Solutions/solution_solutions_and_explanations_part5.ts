/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

// File: supabase/functions/process-email-queue/index.ts
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

// 1. Queue Table Schema (SQL Definition)
/*
  CREATE TABLE email_queue (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    recipient_email TEXT NOT NULL,
    subject TEXT NOT NULL,
    body TEXT NOT NULL,
    status TEXT DEFAULT 'pending', 
    retry_count INTEGER DEFAULT 0,
    created_at TIMESTAMPTZ DEFAULT NOW()
  );
*/

interface EmailJob {
  id: string;
  recipient_email: string;
  subject: string;
  body: string;
  retry_count: number;
}

serve(async (req) => {
  const supabase = createClient(
    Deno.env.get("SUPABASE_URL")!,
    Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
  );

  // 2. Fetch Pending Jobs (Limit 10 to prevent timeout/overload)
  const { data: jobs, error } = await supabase
    .from('email_queue')
    .select('*')
    .eq('status', 'pending')
    .lt('retry_count', 3) // Only fetch jobs that haven't exceeded max retries
    .limit(10);

  if (error || !jobs) {
    return new Response(JSON.stringify({ error: "Failed to fetch queue" }), { status: 500 });
  }

  const results = [];

  // 3. Process Jobs
  for (const job of jobs) {
    try {
      // Mock Email Service Call
      await mockSendEmail(job.recipient_email, job.subject, job.body);

      // Success: Update status to 'sent'
      const { error: updateError } = await supabase
        .from('email_queue')
        .update({ status: 'sent' })
        .eq('id', job.id);

      results.push({ id: job.id, status: 'success' });

    } catch (emailError) {
      // Failure: Increment retry_count
      const newRetryCount = job.retry_count + 1;
      
      if (newRetryCount >= 3) {
        // Permanent failure
        await supabase
          .from('email_queue')
          .update({ status: 'failed_permanent', retry_count: newRetryCount })
          .eq('id', job.id);
      } else {
        // Temporary failure, keep status pending for next run
        await supabase
          .from('email_queue')
          .update({ status: 'pending', retry_count: newRetryCount })
          .eq('id', job.id);
      }
      results.push({ id: job.id, status: 'failed', retry_count: newRetryCount });
    }
  }

  return new Response(JSON.stringify({ processed: results.length, results }), {
    status: 200,
    headers: { "Content-Type": "application/json" },
  });
});

// Mock function for demonstration
async function mockSendEmail(to: string, subject: string, body: string) {
  // Simulate random failure for testing retry logic
  if (Math.random() > 0.8) throw new Error("SMTP Timeout");
  console.log(`Sending email to ${to}: ${subject}`);
}
