/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part6.ts
// Description: Solutions and Explanations
// ==========================================

// File: troubleshoot-agent.ts

// 1. Tool Definitions
const tools = {
  check_user_exists: async (email: string) => {
    // Simulate DB check
    const isValid = email.includes("@") && email.includes(".");
    return isValid ? `User ${email} exists in database.` : `User ${email} not found.`;
  },
  
  validate_email_format: (email: string) => {
    const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    const isValid = regex.test(email);
    return `Format valid: ${isValid}.`;
  },

  get_bounce_history: async (email: string) => {
    // Simulate fetching bounce count
    const count = Math.floor(Math.random() * 5);
    return `Bounce count for ${email}: ${count}.`;
  },

  update_user_email: async (oldEmail: string, newEmail: string) => {
    // Simulate DB update
    return `Updated ${oldEmail} to ${newEmail}. Requires confirmation.`;
  }
};

// 2. ReAct Loop Function
export async function runEmailTroubleshooter(
  errorMessage: string, 
  recipientEmail: string
) {
  let history: string[] = [];
  let currentEmail = recipientEmail;

  // System Prompt for the LLM
  const systemPrompt = `
    You are an expert email troubleshooting agent. 
    You must use the tools provided to diagnose the issue.
    Output strictly JSON format: { "thought": string, "action": string, "action_input": string }.
    Once you have a final answer, output: { "final_answer": string }.
    
    Available Tools:
    - check_user_exists(email)
    - validate_email_format(email)
    - get_bounce_history(email)
    - update_user_email(oldEmail, newEmail)
  `;

  // Simulate 3 iterations of the loop
  for (let i = 0; i < 3; i++) {
    console.log(`\n--- Iteration ${i + 1} ---`);
    
    // Construct prompt with history
    const prompt = `${systemPrompt}\n\nError: ${errorMessage}\nCurrent Email: ${currentEmail}\nHistory: ${history.join('\n')}\n\nReasoning:`;

    // MOCK LLM CALL: In reality, this calls OpenAI API
    // For this exercise, we simulate the LLM's logic based on the scenario
    const llmResponse = simulateLLMLogic(errorMessage, history, currentEmail);
    
    console.log("LLM Thought:", llmResponse.thought);
    
    if (llmResponse.final_answer) {
      console.log("Final Answer:", llmResponse.final_answer);
      return;
    }

    // Execute Action
    console.log("Action:", llmResponse.action, llmResponse.action_input);
    let observation = "";
    
    try {
      if (llmResponse.action === "validate_email_format") {
        observation = await tools.validate_email_format(llmResponse.action_input);
      } else if (llmResponse.action === "check_user_exists") {
        observation = await tools.check_user_exists(llmResponse.action_input);
      } else if (llmResponse.action === "update_user_email") {
        // Interactive Challenge: Handling the update tool
        const [oldE, newE] = llmResponse.action_input.split("->");
        observation = await tools.update_user_email(oldE.trim(), newE.trim());
      }
    } catch (e) {
      observation = `Error executing tool: ${e}`;
    }

    console.log("Observation:", observation);
    
    // Add to history for next iteration
    history.push(`Thought: ${llmResponse.thought}\nAction: ${llmResponse.action}\nObservation: ${observation}`);
  }
}

// 3. Simulated LLM Logic (Mocking the LLM's reasoning)
function simulateLLMLogic(error: string, history: string[], email: string) {
  // Scenario: Error is "550 5.1.1 User unknown" (Invalid email)
  
  if (history.length === 0) {
    return {
      thought: "The error indicates the user is unknown. I should first check if the email format is valid.",
      action: "validate_email_format",
      action_input: email
    };
  }

  if (history.length === 1 && history[0].includes("Format valid: false")) {
    return {
      thought: "The email format is invalid. I should suggest updating the email to a valid format.",
      action: "update_user_email",
      action_input: `${email} -> corrected@example.com` // Simulating AI correction
    };
  }

  if (history.length === 2) {
    return {
      final_answer: "Issue identified: Invalid email format. Action taken: Proposed update to 'corrected@example.com'. Please confirm the update."
    };
  }

  return { thought: "Analyzing...", action: "none", action_input: "" };
}

// Run the simulation
runEmailTroubleshooter("550 5.1.1 User unknown", "invalid-email");
