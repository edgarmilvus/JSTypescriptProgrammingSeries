/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * image-generation-pipeline.ts
 * 
 * A self-contained TypeScript example demonstrating a basic asynchronous image generation pipeline.
 * 
 * Dependencies: 
 * - zod (for schema validation)
 * - @trpc/server (for API handling)
 * 
 * Note: This code simulates external API calls to DALL-E/Flux. 
 * In a production environment, you would replace the 'mockGenerateImage' function 
 * with actual fetch calls to OpenAI or Stability AI.
 */

import { initTRPC } from '@trpc/server';
import { z } from 'zod';

// ==========================================
// 1. Define the Request Schema (Input Validation)
// ==========================================

/**
 * We use Zod to strictly define what the client can send.
 * This prevents malformed data from entering the pipeline and ensures type safety.
 * 
 * @field prompt - The text description of the image to generate.
 * @field style - An optional enum to control the artistic style.
 */
const ImageGenerationInput = z.object({
  prompt: z.string().min(3).max(500), // Ensure prompt is reasonable length
  style: z.enum(['realistic', 'cartoon', 'watercolor']).default('realistic'),
});

type ImageGenerationInput = z.infer<typeof ImageGenerationInput>;

// ==========================================
// 2. Mock External AI Service (Simulating DALL-E/Flux)
// ==========================================

/**
 * Simulates the latency and behavior of a real external image generation API.
 * 
 * In a real scenario:
 * 1. This function would make a POST request to OpenAI's DALL-E 3 endpoint.
 * 2. It would handle authentication headers (Bearer Token).
 * 3. It would parse the JSON response to get the image URL.
 * 
 * @param input - The validated input from the client.
 * @returns A Promise resolving to a simulated image URL.
 */
async function mockGenerateImage(input: ImageGenerationInput): Promise<string> {
  console.log(`[System] Calling external AI with prompt: "${input.prompt}" (Style: ${input.style})`);
  
  // Simulate network latency (2 seconds)
  await new Promise(resolve => setTimeout(resolve, 2000));

  // Simulate a successful response
  const mockUrl = `https://example.com/generated-images/${Buffer.from(input.prompt).toString('base64')}.png`;
  return mockUrl;
}

// ==========================================
// 3. tRPC Router Definition (The API Layer)
// ==========================================

/**
 * Initialize the tRPC backend.
 * tRPC allows us to define backend procedures that are callable from the frontend 
 * with full end-to-end type safety.
 */
const t = initTRPC.create();

/**
 * The main application router.
 * We define a mutation named 'generateImage'.
 */
const appRouter = t.router({
  generateImage: t.procedure
    // Validate input using Zod middleware
    .input(ImageGenerationInput)
    // The actual logic handler (Resolver)
    .query(async ({ input }) => {
      
      // Step A: Prompt Engineering (Optional but recommended)
      // In a real app, you might use a lightweight LLM (like GPT-3.5-Turbo) here
      // to refine the user's prompt for better image generation results.
      const optimizedPrompt = `[High Quality, 8k] ${input.prompt}`;

      // Step B: Asynchronous Processing
      // We await the image generation. In a serverless context (Vercel/AWS Lambda),
      // this must complete within the function timeout limit (usually 10-30s).
      try {
        const imageUrl = await mockGenerateImage({
          ...input,
          prompt: optimizedPrompt,
        });

        // Step C: Return Result
        return {
          success: true,
          imageUrl: imageUrl,
          generatedAt: new Date().toISOString(),
        };
      } catch (error) {
        console.error('[System] Image generation failed:', error);
        throw new Error('Failed to generate image');
      }
    }),
});

// ==========================================
// 4. Client-Side Usage (Simulation)
// ==========================================

/**
 * Simulates the frontend client calling the tRPC procedure.
 * In a real app, this would be inside a React component using @trpc/react-query.
 */
async function simulateFrontendCall() {
  console.log('--- Frontend: User submits prompt ---');
  
  const userInput: ImageGenerationInput = {
    prompt: 'A futuristic city skyline at sunset',
    style: 'realistic',
  };

  try {
    // In a real app: const result = await trpc.generateImage.query(userInput);
    // Here, we directly call the router logic:
    const result = await appRouter.generateImage.query(userInput);
    
    console.log('--- Frontend: Received Result ---');
    console.log(`Image URL: ${result.imageUrl}`);
  } catch (error) {
    console.error('Frontend Error:', error);
  }
}

// Execute the simulation
simulateFrontendCall();
