/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// File: server/routers/image.ts
import { z } from 'zod';
import { publicProcedure, router } from '../../server/trpc';
import { v4 as uuidv4 } from 'uuid';

// In-memory store to simulate a database for job statuses
const jobStore = new Map<string, { status: 'queued' | 'processing' | 'completed' | 'failed'; count: number }>();

export const imageRouter = router({
  // 1. Define the input schema and the 'generateImage' mutation
  generateImage: publicProcedure
    .input(
      z.object({
        prompt: z.string().min(3, "Prompt must be at least 3 characters").max(500, "Prompt must be under 500 characters"),
        style: z.enum(['realistic', 'cartoon', 'abstract']).optional().default('realistic'),
      })
    )
    .mutation(async ({ input }) => {
      // Simulate generating a unique ID for the job
      const jobId = uuidv4();
      
      // Initialize job status in our mock database
      jobStore.set(jobId, { status: 'queued', count: 0 });

      // Return the jobId and status immediately (acknowledging receipt)
      return {
        jobId,
        status: 'queued' as const,
      };
    }),

  // Interactive Challenge: Implement 'getImageStatus'
  getImageStatus: publicProcedure
    .input(
      z.object({
        jobId: z.string().uuid("Invalid Job ID format"),
      })
    )
    .query(async ({ input }) => {
      const job = jobStore.get(input.jobId);

      if (!job) {
        throw new Error("Job not found");
      }

      // Increment the access count to simulate state transitions
      job.count += 1;

      // Logic: Return 'completed' after the 3rd call
      if (job.count >= 3) {
        job.status = 'completed';
      } else if (job.count === 2) {
        job.status = 'processing';
      }

      // Update the store
      jobStore.set(input.jobId, job);

      return {
        jobId: input.jobId,
        status: job.status,
      };
    }),
});
