/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

// File: lib/jobQueue.ts
import { v4 as uuidv4 } from 'uuid';

// 1. Define strict interfaces
export type JobStatus = 'queued' | 'processing' | 'completed' | 'failed' | 'cancelled';

export interface Job {
  id: string;
  prompt: string;
  style: string;
  status: JobStatus;
  result?: string; // The image URL
}

export interface QueueResult {
  jobId: string;
  status: JobStatus;
  url?: string;
}

export class JobQueue {
  private jobs: Map<string, Job> = new Map();

  // Enqueue a new job and start processing simulation
  enqueue(prompt: string, style: string): Promise<string> {
    const jobId = uuidv4();
    const job: Job = {
      id: jobId,
      prompt,
      style,
      status: 'queued',
    };

    this.jobs.set(jobId, job);

    // Simulate processing delay (2 to 5 seconds)
    const delay = Math.floor(Math.random() * 3000) + 2000;

    // Use setTimeout to simulate background processing
    const processPromise = new Promise<string>((resolve) => {
      setTimeout(() => {
        const currentJob = this.jobs.get(jobId);
        
        // Check if job was cancelled before processing completed
        if (currentJob && currentJob.status !== 'cancelled') {
          currentJob.status = 'completed';
          currentJob.result = `https://example.com/image-${jobId}.png`;
          this.jobs.set(jobId, currentJob);
        }
        resolve(jobId);
      }, delay);
    });

    return processPromise;
  }

  // Retrieve job result
  getJobResult(jobId: string): Promise<QueueResult> {
    return new Promise((resolve, reject) => {
      // Polling simulation or immediate check
      const checkJob = () => {
        const job = this.jobs.get(jobId);
        
        if (!job) {
          reject(new Error('Job not found'));
          return;
        }

        if (job.status === 'completed') {
          resolve({
            jobId: job.id,
            status: job.status,
            url: job.result,
          });
        } else if (job.status === 'failed' || job.status === 'cancelled') {
          reject(new Error(`Job ended with status: ${job.status}`));
        } else {
          // If still processing or queued, we wait (in a real app, this would be a subscription or polling)
          // For this simulation, we assume the caller handles the delay via the promise resolution in enqueue
          // However, to make getJobResult usable standalone, we can set a short timeout to re-check
          setTimeout(checkJob, 500);
        }
      };

      checkJob();
    });
  }

  // Interactive Challenge: Cancel Job
  cancelJob(jobId: string): { success: boolean; message: string } {
    const job = this.jobs.get(jobId);

    if (!job) {
      return { success: false, message: 'Job not found' };
    }

    // Only allow cancellation if job is currently 'queued'
    if (job.status === 'queued') {
      job.status = 'cancelled';
      this.jobs.set(jobId, job);
      return { success: true, message: 'Job cancelled successfully' };
    }

    // If processing, we cannot cancel (or fail gracefully)
    if (job.status === 'processing') {
      return { success: false, message: 'Job is already processing; cannot cancel' };
    }

    return { success: false, message: `Job is already ${job.status}` };
  }
}
