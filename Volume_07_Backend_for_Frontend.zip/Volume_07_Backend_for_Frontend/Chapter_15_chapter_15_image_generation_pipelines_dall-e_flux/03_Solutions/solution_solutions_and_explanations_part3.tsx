/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

// File: components/ImageGenerator.tsx
import { trpc } from '../utils/trpc';
import { useState } from 'react';

type GenerationStatus = 'idle' | 'generating' | 'polling' | 'success' | 'error';

export const ImageGenerator = () => {
  // Local UI State
  const [prompt, setPrompt] = useState('');
  const [style, setStyle] = useState<'realistic' | 'cartoon' | 'abstract'>('realistic');
  const [status, setStatus] = useState<GenerationStatus>('idle');
  const [jobId, setJobId] = useState<string | null>(null);
  const [imageUrl, setImageUrl] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  // TRPC Mutations and Queries
  const generateMutation = trpc.image.generateImage.useMutation();
  const statusQuery = trpc.image.getImageStatus.useQuery(
    { jobId: jobId! }, 
    { 
      enabled: !!jobId && status === 'polling', // Only poll when we have a jobId and are in polling state
      refetchInterval: 2000, // Poll every 2 seconds
      onSuccess: (data) => {
        if (data.status === 'completed') {
          setStatus('success');
          // In a real app, the backend would return the URL here. 
          // For this exercise, we mock the URL based on the jobId.
          setImageUrl(`https://example.com/image-${data.jobId}.png`);
        } else if (data.status === 'failed') {
          setStatus('error');
          setError('Generation failed.');
        }
      },
      onError: (err) => {
        setStatus('error');
        setError(err.message);
      }
    }
  );

  const handleGenerate = async () => {
    if (!prompt) return;
    
    setStatus('generating');
    setError(null);
    setImageUrl(null);

    try {
      // 1. Trigger the generation mutation
      const result = await generateMutation.mutateAsync({ prompt, style });
      setJobId(result.jobId);
      
      // 2. Start Polling
      setStatus('polling');
    } catch (err: any) {
      setStatus('error');
      setError(err.message);
    }
  };

  // Interactive Challenge: Download Simulation
  const handleDownload = () => {
    if (!imageUrl) return;

    // Simulate creating a Blob from the image URL (mocking a fetch)
    const mockImageContent = `Mock Image Data for ${imageUrl}`;
    const blob = new Blob([mockImageContent], { type: 'text/plain' }); // Using text/plain for simulation
    const url = window.URL.createObjectURL(blob);
    
    const a = document.createElement('a');
    a.href = url;
    // Dynamic filename
    a.download = `generated-${Date.now()}.png`; 
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    window.URL.revokeObjectURL(url);
  };

  return (
    <div style={{ padding: '20px', border: '1px solid #ccc', maxWidth: '500px' }}>
      <h2>Image Generator</h2>
      
      {/* Input Section */}
      <div style={{ marginBottom: '10px' }}>
        <input
          type="text"
          value={prompt}
          onChange={(e) => setPrompt(e.target.value)}
          placeholder="Enter a prompt..."
          disabled={status === 'generating' || status === 'polling'}
          style={{ width: '100%', padding: '8px', marginBottom: '8px' }}
        />
        <select 
          value={style} 
          onChange={(e) => setStyle(e.target.value as any)}
          disabled={status === 'generating' || status === 'polling'}
          style={{ width: '100%', padding: '8px', marginBottom: '8px' }}
        >
          <option value="realistic">Realistic</option>
          <option value="cartoon">Cartoon</option>
          <option value="abstract">Abstract</option>
        </select>
        <button 
          onClick={handleGenerate} 
          disabled={!prompt || status === 'generating' || status === 'polling'}
        >
          {status === 'generating' ? 'Submitting...' : status === 'polling' ? 'Generating...' : 'Generate'}
        </button>
      </div>

      {/* Status & Error Display */}
      {status === 'error' && <div style={{ color: 'red' }}>Error: {error}</div>}
      {status === 'polling' && <div style={{ color: 'blue' }}>Status: {statusQuery.data?.status || 'Queued'}...</div>}

      {/* Result Display */}
      {status === 'success' && imageUrl && (
        <div style={{ marginTop: '20px' }}>
          <img src={imageUrl} alt="Generated" style={{ maxWidth: '100%', border: '1px solid #eee' }} />
          <div style={{ marginTop: '10px' }}>
            <button onClick={handleDownload}>Download Image</button>
          </div>
        </div>
      )}
    </div>
  );
};
