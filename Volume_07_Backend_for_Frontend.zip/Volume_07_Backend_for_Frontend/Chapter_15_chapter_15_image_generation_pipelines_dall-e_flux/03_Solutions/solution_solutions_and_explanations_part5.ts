/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

// File: server/routers/image.ts (Updated)
import { z } from 'zod';
import { publicProcedure, router } from '../../server/trpc';
import { v4 as uuidv4 } from 'uuid';
import { optimizePrompt } from '../../lib/promptOptimizer'; // Import the optimizer

// Mock database
const jobStore = new Map<string, { status: 'queued' | 'processing' | 'completed' | 'failed'; count: number }>();

export const imageRouter = router({
  generateImage: publicProcedure
    .input(
      z.object({
        prompt: z.string().min(3).max(500),
        style: z.enum(['realistic', 'cartoon', 'abstract']).default('realistic'),
      })
    )
    .mutation(async ({ input }) => {
      const jobId = uuidv4();

      // INTEGRATION: Call the optimizer before queuing
      // In a real app, this might be expensive, so we await it here.
      const optimizedPrompt = await optimizePrompt(input.prompt, input.style);

      // Log the transformation (simulating internal logging)
      console.log(`Original: "${input.prompt}" -> Optimized: "${optimizedPrompt}"`);

      // Initialize job
      jobStore.set(jobId, { status: 'queued', count: 0 });

      return {
        jobId,
        status: 'queued' as const,
        optimizedPrompt, // Optionally return this to the client for transparency
      };
    }),

  // getImageStatus remains the same as Exercise 1
  getImageStatus: publicProcedure
    .input(z.object({ jobId: z.string().uuid() }))
    .query(({ input }) => {
      const job = jobStore.get(input.jobId);
      if (!job) throw new Error("Job not found");
      
      job.count += 1;
      if (job.count >= 3) job.status = 'completed';
      else if (job.count === 2) job.status = 'processing';
      
      return { jobId: input.jobId, status: job.status };
    }),
});
