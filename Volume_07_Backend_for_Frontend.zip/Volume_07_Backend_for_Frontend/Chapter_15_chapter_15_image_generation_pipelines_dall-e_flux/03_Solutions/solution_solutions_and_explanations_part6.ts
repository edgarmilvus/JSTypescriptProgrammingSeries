/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part6.ts
// Description: Solutions and Explanations
// ==========================================

// File: lib/imageCache.ts
import { createHash } from 'crypto';

// 1. Define interfaces for Cache and Configuration
export interface CacheEntry {
  jobId: string;
  url: string;
  timestamp: number; // Unix timestamp in ms
}

export interface CacheConfig {
  ttl: number; // Time to live in milliseconds (e.g., 3600000 for 1 hour)
}

export class ImageCache {
  private store = new Map<string, CacheEntry>();
  private config: CacheConfig;

  constructor(config: CacheConfig = { ttl: 3600000 }) {
    this.config = config;
  }

  // Generate a deterministic key from prompt and style
  private generateKey(prompt: string, style: string): string {
    const data = `${prompt.toLowerCase().trim()}:${style}`;
    return createHash('sha256').update(data).digest('hex');
  }

  // Get entry with TTL validation
  get(prompt: string, style: string): CacheEntry | undefined {
    const key = this.generateKey(prompt, style);
    const entry = this.store.get(key);

    if (!entry) return undefined;

    const now = Date.now();
    const isExpired = now - entry.timestamp > this.config.ttl;

    if (isExpired) {
      this.store.delete(key); // Invalidate
      return undefined;
    }

    return entry;
  }

  // Set entry
  set(prompt: string, style: string, jobId: string, url: string): void {
    const key = this.generateKey(prompt, style);
    const entry: CacheEntry = {
      jobId,
      url,
      timestamp: Date.now(),
    };
    this.store.set(key, entry);
  }
}
