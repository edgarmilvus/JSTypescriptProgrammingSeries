/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part7.ts
// Description: Solutions and Explanations
// ==========================================

// File: server/routers/image.ts (Final Update)
import { z } from 'zod';
import { publicProcedure, router } from '../../server/trpc';
import { v4 as uuidv4 } from 'uuid';
import { optimizePrompt } from '../../lib/promptOptimizer';
import { ImageCache } from '../../lib/imageCache';

// Instantiate the cache (Singleton pattern implied)
const imageCache = new ImageCache({ ttl: 3600000 }); // 1 hour TTL

// Mock DB for job tracking
const jobStore = new Map<string, { status: 'queued' | 'processing' | 'completed' | 'failed'; count: number; url?: string }>();

export const imageRouter = router({
  generateImage: publicProcedure
    .input(
      z.object({
        prompt: z.string().min(3).max(500),
        style: z.enum(['realistic', 'cartoon', 'abstract']).default('realistic'),
      })
    )
    .mutation(async ({ input }) => {
      // 1. Optimize Prompt
      const optimizedPrompt = await optimizePrompt(input.prompt, input.style);

      // 2. Check Cache
      const cached = imageCache.get(optimizedPrompt, input.style);
      if (cached) {
        // Cache Hit: Return immediately
        return {
          jobId: cached.jobId,
          status: 'completed' as const,
          url: cached.url,
          source: 'cache' as const,
        };
      }

      // 3. Cache Miss: Proceed with Queueing
      const jobId = uuidv4();
      
      // Simulate async processing completion
      // In a real app, a worker would update the DB and Cache.
      // Here, we simulate the "on complete" callback immediately for simplicity,
      // or we rely on the client polling to trigger the cache set.
      // For this solution, we will set the cache immediately after "processing" 
      // to demonstrate the flow, assuming the generation was successful.
      
      const mockUrl = `https://example.com/image-${jobId}.png`;
      
      // Simulate processing delay
      await new Promise(resolve => setTimeout(resolve, 1000));

      // Store in Job DB
      jobStore.set(jobId, { status: 'completed', count: 0, url: mockUrl });

      // Store in Cache
      imageCache.set(optimizedPrompt, input.style, jobId, mockUrl);

      return {
        jobId,
        status: 'completed' as const,
        url: mockUrl,
        source: 'generation' as const,
      };
    }),

  getImageStatus: publicProcedure
    .input(z.object({ jobId: z.string().uuid() }))
    .query(({ input }) => {
      const job = jobStore.get(input.jobId);
      if (!job) throw new Error("Job not found");
      
      // Return the current status and URL if available
      return { 
        jobId: input.jobId, 
        status: job.status,
        url: job.url 
      };
    }),
});
