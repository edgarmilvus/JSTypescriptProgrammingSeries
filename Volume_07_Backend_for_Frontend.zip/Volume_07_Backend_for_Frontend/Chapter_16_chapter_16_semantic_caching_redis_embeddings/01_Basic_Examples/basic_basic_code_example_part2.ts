/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.ts
// Description: Basic Code Example
// ==========================================

/**
 * semantic-cache-hello-world.ts
 * 
 * A self-contained example of Semantic Caching using Redis and OpenAI.
 * 
 * Context: SaaS Support Chatbot
 * Goal: Reduce LLM latency and costs by caching responses based on query meaning.
 */

import { createClient } from 'redis';
import OpenAI from 'openai';
import dotenv from 'dotenv';

// Load environment variables (OpenAI API Key and Redis URL)
dotenv.config();

// --- Configuration & Constants ---
const SIMILARITY_THRESHOLD = 0.91; // Cosine similarity threshold (0.0 to 1.0)
const REDIS_KEY_PREFIX = 'semantic_cache:';
const EMBEDDING_MODEL = 'text-embedding-3-small';

// --- Types ---
interface CacheEntry {
  response: string;
  timestamp: number;
}

// --- 1. Initialization ---

/**
 * Initializes the Redis client and OpenAI instance.
 * In a real app, these would be singletons or dependency-injected services.
 */
async function initializeClients() {
  const redisClient = createClient({
    url: process.env.REDIS_URL || 'redis://localhost:6379'
  });

  redisClient.on('error', (err) => console.error('Redis Client Error', err));
  await redisClient.connect();

  const openai = new OpenAI({
    apiKey: process.env.OPENAI_API_KEY,
  });

  return { redisClient, openai };
}

/**
 * Generates a vector embedding for a given text string using OpenAI.
 * 
 * @param openai - The OpenAI client instance.
 * @param text - The user query to embed.
 * @returns A Promise resolving to an array of numbers (the vector).
 */
async function getEmbedding(openai: OpenAI, text: string): Promise<number[]> {
  const response = await openai.embeddings.create({
    model: EMBEDDING_MODEL,
    input: text,
  });
  
  // OpenAI returns the embedding in the data array
  return response.data[0].embedding;
}

/**
 * Calculates the Cosine Similarity between two vectors.
 * 
 * Formula: (A . B) / (||A|| * ||B||)
 * 
 * @param vecA - The query embedding.
 * @param vecB - The cached embedding (retrieved from Redis).
 * @returns A number between 0.0 and 1.0 representing similarity.
 */
function cosineSimilarity(vecA: number[], vecB: number[]): number {
  const dotProduct = vecA.reduce((acc, val, i) => acc + val * (vecB[i] || 0), 0);
  const magnitudeA = Math.sqrt(vecA.reduce((acc, val) => acc + val * val, 0));
  const magnitudeB = Math.sqrt(vecB.reduce((acc, val) => acc + val * val, 0));
  
  if (magnitudeA === 0 || magnitudeB === 0) return 0;
  return dotProduct / (magnitudeA * magnitudeB);
}

/**
 * The Core Semantic Search Logic.
 * 
 * 1. Generates embedding for the input query.
 * 2. Scans Redis for keys starting with the cache prefix.
 * 3. Iterates through cached entries, fetching their stored embeddings.
 * 4. Calculates similarity score for each.
 * 5. Returns the best match if it exceeds the threshold.
 * 
 * Note: In production, use Redis Vector Search (Redis Stack) or a dedicated 
 * vector DB (Pinecone, Qdrant) for efficient ANN search. This linear scan is for simplicity.
 */
async function findSemanticMatch(
  redisClient: any, 
  openai: OpenAI, 
  query: string
): Promise<{ key: string, data: CacheEntry, score: number } | null> {
  
  const queryEmbedding = await getEmbedding(openai, query);
  
  // Scan for all cache keys
  const keys = await redisClient.keys(`${REDIS_KEY_PREFIX}*`);
  
  let bestMatch = null;
  let highestScore = 0;

  for (const key of keys) {
    // Structure: semantic_cache:<embedding_string>:<hash>
    // We extract the embedding vector stored in the key name or a separate hash field.
    // For this example, we stored the vector in a separate key: `${key}:vector`
    const storedVectorString = await redisClient.get(`${key}:vector`);
    
    if (!storedVectorString) continue;

    const storedVector: number[] = JSON.parse(storedVectorString);
    const score = cosineSimilarity(queryEmbedding, storedVector);

    if (score > highestScore && score >= SIMILARITY_THRESHOLD) {
      highestScore = score;
      const cachedData = await redisClient.get(key);
      if (cachedData) {
        bestMatch = {
          key,
          data: JSON.parse(cachedData) as CacheEntry,
          score
        };
      }
    }
  }

  return bestMatch;
}

/**
 * Simulates the expensive LLM call.
 * In a real app, this would be `openai.chat.completions.create(...)`.
 */
async function callExpensiveLLM(query: string): Promise<string> {
  console.log(`   [LLM] Calling model for: "${query}"`);
  // Simulate network delay
  await new Promise(resolve => setTimeout(resolve, 500)); 
  return `Generated response for: ${query}. This took 500ms and cost $0.002.`;
}

/**
 * The Main Controller (Simulating a tRPC Router procedure).
 * 
 * Logic Flow:
 * 1. Check Semantic Cache.
 * 2. If Hit: Return cached response immediately.
 * 3. If Miss: Call LLM, generate new embedding, save to Redis, return response.
 */
async function semanticCacheHandler(query: string) {
  const { redisClient, openai } = await initializeClients();
  
  console.log(`\n--- Processing Query: "${query}" ---`);

  try {
    // 1. Attempt Semantic Retrieval
    const match = await findSemanticMatch(redisClient, openai, query);

    if (match) {
      console.log(`✅ CACHE HIT (Score: ${match.score.toFixed(4)})`);
      console.log(`   Response: "${match.data.response}"`);
      await redisClient.quit();
      return match.data.response;
    }

    // 2. Cache Miss: Call LLM
    console.log('❌ CACHE MISS (No similar query found)');
    const llmResponse = await callExpensiveLLM(query);

    // 3. Store New Entry
    // Generate embedding again (or reuse from search step if optimized)
    const newEmbedding = await getEmbedding(openai, query);
    
    // Create a unique key based on the query content or a hash
    const cacheKey = `${REDIS_KEY_PREFIX}${Date.now()}`;
    
    // Store the response data
    await redisClient.set(cacheKey, JSON.stringify({
      response: llmResponse,
      timestamp: Date.now()
    }));
    
    // Store the vector separately for retrieval (In Redis Stack, this is done via a vector field)
    await redisClient.set(`${cacheKey}:vector`, JSON.stringify(newEmbedding));

    console.log('💾 Saved to Semantic Cache');
    await redisClient.quit();
    return llmResponse;

  } catch (error) {
    console.error('Error in semantic cache handler:', error);
    await redisClient.quit();
    throw error;
  }
}

// --- Execution ---

/**
 * Main function to run the demo.
 */
async function main() {
  // Scenario: User asks a question, then asks a slightly rephrased version.
  
  // 1. First call (Cold start)
  await semanticCacheHandler("How do I reset my password?");

  // 2. Second call (Exact match - string cache would catch this, but we do semantic)
  await semanticCacheHandler("How do I reset my password?");

  // 3. Third call (Semantic match - string cache would miss this)
  await semanticCacheHandler("I forgot my login credentials, help.");
  
  // 4. Fourth call (Semantic match - different phrasing)
  await semanticCacheHandler("Can't remember my password.");
  
  // 5. Fifth call (No match - completely different topic)
  await semanticCacheHandler("How do I upgrade my subscription plan?");
}

// Run if executed directly
if (require.main === module) {
  main().catch(console.error);
}
