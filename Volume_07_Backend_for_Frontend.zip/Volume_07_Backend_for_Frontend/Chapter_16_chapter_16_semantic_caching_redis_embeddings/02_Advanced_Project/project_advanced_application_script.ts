/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// src/lib/semantic-cache.ts
// ---------------------------------------------------------
// DEPENDENCIES
// ---------------------------------------------------------
// 1. @upstash/redis: Redis client for serverless/edge.
// 2. openai: For generating text embeddings.
// 3. ml-distance: For calculating cosine similarity in-app.
// ---------------------------------------------------------

import { Redis } from '@upstash/redis';
import { OpenAI } from 'openai';
import { similarity } from 'ml-distance';

// ---------------------------------------------------------
// CONFIGURATION & TYPES
// ---------------------------------------------------------

// Configuration for the Semantic Cache
const CACHE_CONFIG = {
  // The index name for our Redis Vector Search
  INDEX_NAME: 'idx:semantic_cache',
  // The threshold for considering a cache hit (0.0 to 1.0)
  SIMILARITY_THRESHOLD: 0.95,
  // Number of top candidates to fetch from Redis
  TOP_K: 1,
  // Embedding model dimensions (text-embedding-3-small defaults to 1536)
  EMBEDDING_DIMENSIONS: 1536,
};

// Initialize clients (Assuming environment variables are set)
const redis = new Redis({
  url: process.env.UPSTASH_REDIS_REST_URL!,
  token: process.env.UPSTASH_REDIS_REST_TOKEN!,
});

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

/**
 * Represents a cached entry in Redis.
 */
interface CachedEntry {
  id: string;
  query: string;
  response: string;
  embedding: number[]; // Stored as a JSON array in Redis
  createdAt: number;
}

// ---------------------------------------------------------
// CORE LOGIC: SEMANTIC CACHE SERVICE
// ---------------------------------------------------------

/**
 * Generates an embedding vector for a given text string using OpenAI.
 * 
 * @param text - The input text to embed.
 * @returns A Promise resolving to an array of numbers (the vector).
 */
async function generateEmbedding(text: string): Promise<number[]> {
  try {
    const embeddingResponse = await openai.embeddings.create({
      model: 'text-embedding-3-small',
      input: text,
    });
    return embeddingResponse.data[0].embedding;
  } catch (error) {
    console.error('Error generating embedding:', error);
    throw new Error('Embedding generation failed');
  }
}

/**
 * Calculates cosine similarity between two vectors.
 * 
 * @param vecA - The query vector.
 * @param vecB - The cached candidate vector.
 * @returns A similarity score between 0 and 1.
 */
function calculateSimilarity(vecA: number[], vecB: number[]): number {
  return similarity.cosine(vecA, vecB);
}

/**
 * Retrieves a semantically similar cached response from Redis.
 * 
 * Note: In a production environment with Redis Stack/RediSearch, 
 * we would use `FT.SEARCH` with a vector query. 
 * For this script, we simulate the VSS fetch by retrieving a set of recent 
 * entries and filtering by similarity in-memory to ensure the script 
 * runs without complex external index setup requirements.
 * 
 * @param queryEmbedding - The vector of the user's query.
 * @returns The cached entry if found, otherwise null.
 */
async function retrieveFromCache(queryEmbedding: number[]): Promise<CachedEntry | null> {
  // In a real VSS implementation, we would run:
  // redis.ft.search(INDEX_NAME, '*=>[KNN 1 @embedding $query_vec]', { 
  //   PARAMS: { query_vec: queryEmbedding }, 
  //   DIALECT: 2 
  // });
  
  // For this script, we fetch the latest 50 entries to demonstrate the logic
  // (In production, use Redis Vector Search for efficiency).
  const keys = await redis.keys('cache:*');
  if (keys.length === 0) return null;

  const pipeline = redis.pipeline();
  keys.forEach((key) => pipeline.json.get(key));
  const results = await pipeline.exec();

  let bestMatch: CachedEntry | null = null;
  let highestSimilarity = 0;

  for (const result of results) {
    if (!result) continue;
    const entry = result as unknown as CachedEntry;
    
    // Calculate similarity
    const sim = calculateSimilarity(queryEmbedding, entry.embedding);
    
    if (sim > highestSimilarity && sim >= CACHE_CONFIG.SIMILARITY_THRESHOLD) {
      highestSimilarity = sim;
      bestMatch = entry;
    }
  }

  return bestMatch;
}

/**
 * Stores a new query-response pair in Redis.
 * 
 * @param query - The original user query.
 * @param response - The LLM response.
 * @param embedding - The pre-calculated embedding vector.
 */
async function storeInCache(query: string, response: string, embedding: number[]): Promise<void> {
  const cacheId = `cache:${Date.now()}:${Math.random().toString(36).substring(7)}`;
  
  const entry: CachedEntry = {
    id: cacheId,
    query,
    response,
    embedding,
    createdAt: Date.now(),
  };

  // Store using Redis JSON
  await redis.json.set(cacheId, '$', entry);
  
  // Optional: Set a TTL (Time To Live) for automatic cleanup (e.g., 24 hours)
  await redis.expire(cacheId, 86400);
}

// ---------------------------------------------------------
// INTEGRATION: NEXT.JS API ROUTE / tRPC CONTEXT
// ---------------------------------------------------------

/**
 * Main API Handler (Next.js App Router / Edge Runtime).
 * 
 * This handler simulates a tRPC router procedure that wraps the LLM call
 * with the semantic caching layer.
 * 
 * Endpoint: POST /api/analyze
 * Body: { "query": string }
 */
export async function POST(request: Request) {
  const { query } = await request.json();

  if (!query) {
    return new Response(JSON.stringify({ error: 'Query is required' }), { status: 400 });
  }

  try {
    // 1. Generate Embedding for the incoming query
    const queryEmbedding = await generateEmbedding(query);

    // 2. Check Semantic Cache
    const cachedResult = await retrieveFromCache(queryEmbedding);

    if (cachedResult) {
      console.log(`[CACHE HIT] Similarity: ${calculateSimilarity(queryEmbedding, cachedResult.embedding).toFixed(4)}`);
      
      return new Response(
        JSON.stringify({ 
          source: 'cache', 
          data: cachedResult.response,
          debug: { matchedQuery: cachedResult.query }
        }), 
        { status: 200, headers: { 'Content-Type': 'application/json' } }
      );
    }

    // 3. Cache Miss: Call the actual LLM (Simulated)
    // In a real app, this would be: await openai.chat.completions.create(...)
    console.log('[CACHE MISS] Calling LLM...');
    const llmResponse = `Analyzed query: "${query}". \nInsights: Revenue increased by 15% driven by Sector A.`;
    
    // Artificial delay to simulate network latency
    await new Promise(resolve => setTimeout(resolve, 800));

    // 4. Store the result in cache for future requests
    await storeInCache(query, llmResponse, queryEmbedding);

    return new Response(
      JSON.stringify({ source: 'llm', data: llmResponse }), 
      { status: 200, headers: { 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('Semantic Cache Error:', error);
    return new Response(JSON.stringify({ error: 'Internal Server Error' }), { status: 500 });
  }
}
