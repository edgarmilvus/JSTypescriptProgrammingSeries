/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

import { Redis } from 'ioredis';
import { OpenAIApi } from 'openai';

// Configuration
const REDIS_HOST = process.env.REDIS_HOST || 'localhost';
const REDIS_PORT = parseInt(process.env.REDIS_PORT || '6379');
const SIMILARITY_THRESHOLD = 0.92;
const CACHE_INDEX_NAME = 'llm_response_cache_idx'; // Name of the Vector Search index in Redis

// Initialize Redis (Assuming Redis Stack with Vector Search enabled)
const redis = new Redis({
  host: REDIS_HOST,
  port: REDIS_PORT,
  // password: 'your-password', // if applicable
});

/**
 * Helper function to generate embedding vector using OpenAI
 */
async function getEmbedding(text: string, openai: OpenAIApi): Promise<number[]> {
  const response = await openai.createEmbedding({
    model: 'text-embedding-ada-002',
    input: text,
  });
  return response.data.data[0].embedding;
}

/**
 * 1. Checks Redis for a semantic match.
 * 2. Returns cached content if score > threshold, otherwise null.
 */
export async function semanticCacheLookup(
  query: string,
  openai: OpenAIApi
): Promise<{ content: string; score: number } | null> {
  try {
    // 1. Generate embedding for the query
    const queryVector = await getEmbedding(query, openai);
    
    // 2. Perform KNN Search in Redis
    // We use the Redis Stack 'FT.SEARCH' command with the 'KNN' operator.
    // We ask for the top 1 neighbor.
    const searchCommand = [
      'FT.SEARCH',
      CACHE_INDEX_NAME,
      `*=>[KNN 1 @vector $query_vector]`, // Redis Query syntax for KNN
      'RETURN', '1', 'content', // Return only the 'content' field
      'PARAMS', '2', 'query_vector', Buffer.from(new Float32Array(queryVector).buffer).toString('base64'), // Encode vector
      'DIALECT', '2',
    ];

    // Execute search
    const result = await redis.call(...searchCommand) as any[];

    // Redis FT.SEARCH response format: [total_count, id, fields, ...]
    // If total_count is 0, no match found.
    if (!result || result[0] === 0) {
      return null;
    }

    // Extract score (distance) and content
    // The result structure for KNN usually returns metadata including the '__vector_score'
    // Note: Redis Stack returns the score in the fields array or as a special field depending on version.
    // For simplicity, we assume the score is accessible. In real implementation, parsing is specific to the Redis version.
    const score = result[2] ? result[2][result[2].indexOf('__score') + 1] : 0; // Simplified extraction
    const content = result[2] ? result[2][result[2].indexOf('content') + 1] : null;

    // 3. Compare against threshold
    // Note: Redis KNN returns distance (lower is better) or similarity (higher is better) depending on the metric.
    // Assuming Cosine Similarity (1.0 - distance).
    if (score >= SIMILARITY_THRESHOLD) {
      return { content, score };
    }

    return null;
  } catch (error) {
    console.error('Semantic Cache Lookup Error:', error);
    return null; // Fail safe: bypass cache on error
  }
}

/**
 * Stores the query, response, and embedding in Redis.
 */
export async function storeInSemanticCache(
  query: string,
  response: string,
  embedding: number[]
): Promise<void> {
  try {
    // Generate a unique ID for the cache entry (e.g., based on hash of query)
    const id = `cache:${Buffer.from(query).toString('base64')}`;

    // Prepare the vector buffer (Float32Array to Buffer)
    const vectorBuffer = Buffer.from(new Float32Array(embedding).buffer);

    // Use Redis HSET to store data. 
    // Note: For Vector Search, the vector field usually needs to be indexed.
    // In Redis Stack, this is done via the Schema definition (not shown here, assumed pre-configured).
    await redis.hset(id, {
      query: query,
      content: response,
      vector: vectorBuffer, // Store the raw vector bytes
      timestamp: Date.now().toString(),
    });

    // Optional: Set an expiration (TTL) to prevent indefinite growth
    await redis.expire(id, 86400); // 24 hours
  } catch (error) {
    console.error('Semantic Cache Store Error:', error);
  }
}
