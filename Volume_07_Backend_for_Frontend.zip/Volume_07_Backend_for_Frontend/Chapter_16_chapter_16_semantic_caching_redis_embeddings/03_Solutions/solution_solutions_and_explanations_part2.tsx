/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useEffect, useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { trpc } from '../utils/trpc'; // Assuming tRPC client setup

// Props interface
interface CacheStatusMonitorProps {
  query: string;
}

// Types for the tRPC response
type CacheCheckResult = {
  status: 'hit' | 'miss';
  score?: number;
  content?: string;
} | null;

export const CacheStatusMonitor: React.FC<CacheStatusMonitorProps> = ({ query }) => {
  // State to trigger the query only when needed (e.g., on button click or debounce)
  // For this example, we will trigger automatically when query changes, 
  // but in a real app, you might want a debounce to avoid spamming the API.
  const [enabled, setEnabled] = useState(false);

  // tRPC query hook
  // Note: Assumes a tRPC procedure named `semanticCache.check` exists
  const { data, isLoading, error } = useQuery({
    queryKey: ['semanticCache', query],
    queryFn: () => trpc.semanticCache.check.query({ query }),
    enabled: enabled && query.length > 0, // Only run when enabled and query is not empty
    retry: 0, // Don't retry on error for immediate feedback
  });

  // Auto-enable when query changes (debouncing should be added in production)
  useEffect(() => {
    if (query.length > 0) {
      setEnabled(true);
    } else {
      setEnabled(false);
    }
  }, [query]);

  // Render Logic
  if (!query) {
    return <div className="p-4 text-gray-500">Enter a query to monitor cache status.</div>;
  }

  if (isLoading) {
    return (
      <div className="p-4 border rounded bg-gray-50 animate-pulse">
        <span className="text-blue-600 font-medium">Checking semantic cache...</span>
      </div>
    );
  }

  if (error) {
    return (
      <div className="p-4 border rounded bg-red-50 text-red-700">
        Error checking cache: {error.message}
      </div>
    );
  }

  // Determine status based on data
  const isHit = data?.status === 'hit';

  return (
    <div className="p-4 border rounded shadow-sm bg-white max-w-md">
      <div className="flex items-center justify-between mb-2">
        <span className="text-sm font-semibold text-gray-600">Cache Status</span>
        <span 
          className={`px-2 py-1 rounded text-xs font-bold uppercase ${
            isHit ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
          }`}
        >
          {isHit ? 'Cache Hit' : 'Cache Miss'}
        </span>
      </div>
      
      <div className="text-sm text-gray-700">
        <p><strong>Query:</strong> "{query}"</p>
        
        {isHit && (
          <>
            <p className="mt-1 text-green-700">
              <strong>Similarity Score:</strong> {data?.score?.toFixed(4)}
            </p>
            <div className="mt-2 p-2 bg-gray-100 rounded text-xs italic">
              <strong>Cached Content:</strong> {data?.content}
            </div>
          </>
        )}

        {!isHit && (
          <p className="mt-1 text-red-600">
            No close match found in vector store.
          </p>
        )}
      </div>
    </div>
  );
};
