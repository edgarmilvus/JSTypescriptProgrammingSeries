/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

// 1. Data Model Interfaces
interface CacheEntry {
  id: string; // Unique ID for the cache entry
  vector: Float32Array; // The embedding vector
  content: string; // The LLM response
  source_document_id: string; // ID of the PDF/Document
  chunk_id: string; // Specific ID of the chunk within the document
  timestamp: number;
}

// 2. Invalidation Logic
import { Redis } from 'ioredis';

const redis = new Redis(); // Assume connected

/**
 * Handles document updates by invalidating specific cache entries.
 * Uses Redis Sets to map document IDs to cache keys for O(1) lookup deletion.
 */
export async function handleDocumentUpdate(source_document_id: string): Promise<void> {
  // Key pattern for the index set: `doc_index:${doc_id}`
  const indexKey = `doc_index:${source_document_id}`;

  // 1. Retrieve all cache keys associated with this document
  // SMEMBERS returns all members of the set
  const cacheKeys = await redis.smembers(indexKey);

  if (cacheKeys.length === 0) {
    console.log(`No cache entries found for document ${source_document_id}`);
    return;
  }

  // 2. Delete the actual cache entries (Hashes)
  // We can use DEL with multiple keys
  await redis.del(...cacheKeys);

  // 3. Delete the index set itself
  await redis.del(indexKey);

  console.log(`Invalidated ${cacheKeys.length} cache entries for document ${source_document_id}`);
}

/**
 * Helper function to store a new entry with indexing.
 * This must be used instead of a simple HSET to support future invalidation.
 */
export async function storeChunkedCache(entry: CacheEntry): Promise<void> {
  const cacheKey = `cache:${entry.id}`;
  const indexKey = `doc_index:${entry.source_document_id}`;

  // Pipeline for atomic operations
  const pipeline = redis.pipeline();

  // 1. Store the actual data (Hash)
  pipeline.hset(cacheKey, {
    content: entry.content,
    vector: Buffer.from(entry.vector.buffer),
    chunk_id: entry.chunk_id,
    timestamp: entry.timestamp.toString(),
  });

  // 2. Update the secondary index (Set)
  // This maps the document ID to the cache key, allowing fast lookup for deletion
  pipeline.sadd(indexKey, cacheKey);

  await pipeline.exec();
}

// 3. Optimization: Partial Chunk Updates
/*
 * To handle updates to a specific chunk only:
 * 
 * 1. **Granular Indexing**: Instead of one Set per document (`doc_index:doc_id`), 
 *    we can maintain a Set per chunk: `chunk_index:doc_id:chunk_id`.
 * 
 * 2. **Update Flow**:
 *    - When a user updates 'Chunk 5' of 'Document A':
 *    - Call `handleChunkUpdate('doc_a', 'chunk_5')`.
 *    - Lookup `chunk_index:doc_a:chunk_5` to get keys.
 *    - Delete only those keys.
 *    - Remove keys from the main `doc_index:doc_a` set.
 * 
 * 3. **Alternative (Metadata Filtering)**:
 *    - If using a vector database that supports metadata filtering (like Pinecone or Postgres with pgvector), 
 *      you don't need manual Sets. You would simply perform a delete query: 
 *      `DELETE FROM cache WHERE doc_id = 'doc_a' AND chunk_id = 'chunk_5'`.
 *    - However, with raw Redis, the Set-based indexing shown above is the standard approach.
 */
