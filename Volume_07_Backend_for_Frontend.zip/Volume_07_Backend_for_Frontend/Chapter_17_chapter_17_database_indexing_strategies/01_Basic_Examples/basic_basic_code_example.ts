/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

<DIAGRAM>
digraph G {
    rankdir=TB;
    node [shape=box, style="rounded,filled", color="#4F46E5", fontcolor="white"];
    
    Client [label="tRPC Client (Frontend)", fillcolor="#3B82F6"];
    Worker [label="Backend Worker Agent", fillcolor="#6366F1"];
    Index [label="B-Tree Index\n(Email Domain)", fillcolor="#10B981", shape="cylinder"];
    Table [label="User Table\n(Row Storage)", fillcolor="#64748B"];

    Client -> Worker [label="1. tRPC Call\n(getUsersByDomain)"];
    Worker -> Index [label="2. Seek Operation\nO(log n)"];
    Index -> Table [label="3. Row Lookup\nO(1) via TID"];
    Table -> Worker [label="4. Return Data"];
    Worker -> Client [label="5. JSON Response"];
}
</DIAGRAM>
