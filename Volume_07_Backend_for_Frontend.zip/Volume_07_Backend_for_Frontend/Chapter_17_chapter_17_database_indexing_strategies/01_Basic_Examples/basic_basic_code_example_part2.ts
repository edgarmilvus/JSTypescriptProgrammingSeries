/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.ts
// Description: Basic Code Example
// ==========================================

/**
 * DATABASE INDEXING STRATEGIES: "HELLO WORLD" EXAMPLE
 * 
 * Context: SaaS Backend (tRPC + PostgreSQL)
 * Objective: Demonstrate the performance impact of indexing on a user lookup query.
 */

// ==========================================
// 1. MOCK INFRASTRUCTURE (Simulating Supabase/Prisma)
// ==========================================

/**
 * Represents a row in the `users` table.
 */
interface User {
  id: number;
  email: string;
  name: string;
  createdAt: Date;
}

/**
 * Simulates a database table with raw row storage.
 * In a real DB, this is the heap file.
 */
class MockTable {
  private rows: User[] = [];

  constructor(data: User[]) {
    this.rows = data;
  }

  /**
   * Simulates a Sequential Scan (Full Table Scan).
   * Time Complexity: O(n) - Must check every row.
   */
  public sequentialScan(predicate: (user: User) => boolean): User[] {
    console.time("Sequential Scan");
    const results = this.rows.filter(predicate);
    console.timeEnd("Sequential Scan");
    return results;
  }

  /**
   * Simulates an Index Scan.
   * Time Complexity: O(log n) + O(k) (where k is result size)
   * Note: In this simulation, we assume the index structure handles the lookup.
   */
  public indexScan(index: MockBTreeIndex, domain: string): User[] {
    console.time("Index Scan");
    const rowIds = index.lookup(domain);
    // Retrieve rows by ID (assuming fast lookup, e.g., hash map)
    const results = rowIds.map(id => this.rows.find(r => r.id === id)).filter(Boolean) as User[];
    console.timeEnd("Index Scan");
    return results;
  }

  public getAllRows(): User[] {
    return this.rows;
  }
}

/**
 * Simulates a B-Tree Index.
 * Under the hood: A balanced tree structure where keys are sorted.
 * Keys: Email domains (e.g., "gmail.com")
 * Values: List of Row IDs (TIDs) pointing to table rows.
 */
class MockBTreeIndex {
  // Map<Domain, List of User IDs>
  private indexMap: Map<string, number[]> = new Map();

  constructor(table: MockTable) {
    this.buildIndex(table);
  }

  /**
   * Builds the index by iterating over the table once.
   * This is an expensive operation done once (or during writes).
   */
  private buildIndex(table: MockTable) {
    const rows = table.getAllRows();
    for (const row of rows) {
      const domain = row.email.split('@')[1]; // Extract domain
      if (!this.indexMap.has(domain)) {
        this.indexMap.set(domain, []);
      }
      this.indexMap.get(domain)!.push(row.id);
    }
  }

  /**
   * Performs a lookup in the B-Tree.
   * In a real B-Tree, this traverses nodes (logarithmic time).
   * Here, we simulate the speed advantage via direct map access.
   */
  public lookup(domain: string): number[] {
    // Simulate B-Tree traversal overhead
    // In reality, this is where O(log n) happens
    return this.indexMap.get(domain) || [];
  }
}

// ==========================================
// 2. THE INTELLIGENT API (tRPC Context)
// ==========================================

/**
 * Simulates the tRPC backend environment.
 * In a real app, this would be a router procedure calling Prisma/Drizzle.
 */
class TrpcBackend {
  private table: MockTable;
  private index?: MockBTreeIndex;

  constructor(data: User[], useIndex: boolean = false) {
    this.table = new MockTable(data);
    if (useIndex) {
      // Building the index happens once (e.g., on startup or migration)
      console.log("🔧 Initializing B-Tree Index...");
      this.index = new MockBTreeIndex(this.table);
    }
  }

  /**
   * tRPC Procedure: getUsersByDomain
   * @param domain - The email domain to search for (e.g., 'gmail.com')
   */
  public async getUsersByDomain(domain: string): Promise<User[]> {
    // SIMULATION: We are adding artificial delay to mimic network/processing time
    // to make the console logs clearer in this demo.
    await new Promise(r => setTimeout(r, 10)); 

    if (this.index) {
      // STRATEGY 1: Indexed Lookup
      // The database uses the B-Tree to find relevant rows instantly.
      return this.table.indexScan(this.index, domain);
    } else {
      // STRATEGY 2: Unindexed Lookup (Full Scan)
      // The database must load every single row and check the email.
      return this.table.sequentialScan((user) => user.email.endsWith(domain));
    }
  }
}

// ==========================================
// 3. EXECUTION & DEMONSTRATION
// ==========================================

/**
 * Helper to generate mock data.
 * Generating 100,000 rows to highlight the performance gap.
 */
function generateMockUsers(count: number): User[] {
  const users: User[] = [];
  const domains = ['gmail.com', 'yahoo.com', 'outlook.com', 'company.io'];
  
  for (let i = 0; i < count; i++) {
    const domain = domains[i % domains.length];
    users.push({
      id: i,
      email: `user${i}@${domain}`,
      name: `User ${i}`,
      createdAt: new Date(),
    });
  }
  return users;
}

/**
 * Main execution block (simulating a server startup)
 */
async function main() {
  const DATA_SIZE = 100000; // 100k records
  const TARGET_DOMAIN = 'company.io'; // Targeting a specific subset

  console.log(`\n📊 Generating ${DATA_SIZE.toLocaleString()} mock users...`);
  const users = generateMockUsers(DATA_SIZE);

  // --- SCENARIO 1: NO INDEX (Standard SQL Query) ---
  console.log("\n🔴 SCENARIO 1: Unoptimized Query (No Index)");
  console.log("SQL: SELECT * FROM users WHERE email LIKE '%@company.io'");
  
  const unoptimizedBackend = new TrpcBackend(users, false);
  const result1 = await unoptimizedBackend.getUsersByDomain(TARGET_DOMAIN);
  
  console.log(`✅ Found ${result1.length} records.`);
  console.log("------------------------------------------------");

  // --- SCENARIO 2: WITH INDEX (Optimized SQL Query) ---
  console.log("\n🟢 SCENARIO 2: Optimized Query (B-Tree Index)");
  console.log("SQL: SELECT * FROM users WHERE email LIKE '%@company.io'");
  console.log("Note: PostgreSQL uses 'Index Scan' or 'Bitmap Index Scan' here.");

  const optimizedBackend = new TrpcBackend(users, true);
  const result2 = await optimizedBackend.getUsersByDomain(TARGET_DOMAIN);

  console.log(`✅ Found ${result2.length} records.`);
  console.log("------------------------------------------------");

  // --- ANALYSIS ---
  console.log("\n💡 ANALYSIS:");
  console.log("In a real PostgreSQL environment with 100k rows:");
  console.log("- Unindexed: Might take 50ms - 200ms (Sequential Scan)");
  console.log("- Indexed:   Often takes < 5ms (Index Scan)");
  console.log("- Impact:    Essential for LLM context retrieval where latency < 100ms is required.");
}

// Run the simulation
main().catch(console.error);
