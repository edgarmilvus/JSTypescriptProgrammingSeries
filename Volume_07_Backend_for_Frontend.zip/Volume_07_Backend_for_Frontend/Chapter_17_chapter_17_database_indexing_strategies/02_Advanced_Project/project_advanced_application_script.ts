/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

/**
 * ============================================================================
 * ADVANCED INDEXING STRATEGIES: INTELLIGENT API IMPLEMENTATION
 * ============================================================================
 *
 * CONTEXT:
 * This script simulates a backend service for a "Smart Search" SaaS application.
 * It connects to a PostgreSQL database (via Prisma) and a Pinecone Vector Store.
 *
 * PROBLEM:
 * We need to perform complex hybrid searches combining:
 * 1. Full-text search (PostgreSQL) for product names/descriptions.
 * 2. Semantic vector search (Pinecone) for user intent.
 * 3. Filtering by metadata (e.g., price, category) with high selectivity.
 *
 * INDEXING STRATEGY:
 * - PostgreSQL: We utilize Composite Indexes for the relational data and
 *   GIN (Generalized Inverted Index) indexes for full-text search to minimize
 *   sequential scans during filtering.
 * - Pinecone: We utilize an optimized Vector Index (HNSW) for approximate
 *   nearest neighbor search to reduce latency.
 */

import { PrismaClient } from '@prisma/client';
import { Pinecone } from '@pinecone-database/pinecone';
import { NextRequest, NextResponse } from 'next/server';

// --- CONFIGURATION & CLIENTS ---

const prisma = new PrismaClient();
const pinecone = new Pinecone({
  apiKey: process.env.PINECONE_API_KEY!,
});

const PINECONE_INDEX_NAME = 'product-embeddings';
const PINECONE_NAMESPACE = 'smart-search-v1';

// --- TYPES & INTERFACES ---

/**
 * Represents the structure of a product in our relational database.
 * Includes fields specifically chosen to benefit from composite indexing.
 */
interface Product {
  id: string;
  name: string;
  description: string;
  category: string; // High selectivity (e.g., 'Electronics', 'Books')
  price: number;    // Range queries
  stock: number;    // Filtering
  vectorId: string; // Foreign key reference to Pinecone
}

/**
 * Represents the search parameters sent from the frontend.
 */
interface SearchRequest {
  query: string;
  category?: string;
  maxPrice?: number;
  minStock?: number;
  semanticWeight?: number; // 0.0 to 1.0
  keywordWeight?: number;  // 0.0 to 1.0
}

// --- CORE LOGIC: DATABASE INDEXING STRATEGIES ---

/**
 * 1. KEYWORD SEARCH WITH GIN INDEXING
 * 
 * WHY:
 * Standard B-tree indexes are inefficient for text pattern matching (LIKE '%term%').
 * PostgreSQL supports GIN (Generalized Inverted Index) indexes on `tsvector` columns.
 * This allows for rapid full-text search operations without scanning the entire table.
 * 
 * HOW:
 * We use Prisma's raw SQL capabilities to leverage the `tsvector` column type and
 * the `to_tsquery` function, assuming a GIN index exists on the `search_vector` column.
 * 
 * INDEX DEFINITION (PostgreSQL):
 * CREATE INDEX idx_product_search ON "Product" USING gin(to_tsvector('english', name || ' ' || description));
 */
async function searchByKeyword(
  searchTerm: string,
  filters: { category?: string; maxPrice?: number; minStock?: number }
) {
  // Construct the full-text search query
  // The `@@` operator checks for matches between a tsvector and a tsquery.
  const tsQuery = `to_tsquery('english', ${searchTerm.split(' ').map(w => w + ':*').join(' & ')})`;

  // Using Prisma.$queryRaw for complex SQL that Prisma ORM doesn't natively support cleanly
  // This query uses the composite nature of the index (filtering + searching).
  const results = await prisma.$queryRaw`
    SELECT id, name, category, price, stock
    FROM "Product"
    WHERE 
      -- 1. Full-text search using GIN index
      to_tsvector('english', name || ' ' || description) @@ ${tsQuery}
      -- 2. Boolean filters (Composite Index Usage)
      AND (${filters.category}::text IS NULL OR category = ${filters.category})
      AND price <= COALESCE(${filters.maxPrice}, price)
      AND stock >= COALESCE(${filters.minStock}, 0)
    LIMIT 50;
  `;

  return results as Product[];
}

/**
 * 2. COMPOSITE INDEXING FOR FILTERING
 * 
 * WHY:
 * If we index `category` alone, and filter by `price`, the database might still
 * scan many rows. A composite index (Category, Price) allows the engine to
 * jump directly to the specific category range and then scan only the relevant prices.
 * 
 * UNDER THE HOOD:
 * B-Trees are sorted. A composite index (A, B) sorts by A first, then B.
 * Query: WHERE category = 'Electronics' AND price < 100
 * The B-Tree jumps to 'Electronics' and traverses the sorted prices efficiently.
 * 
 * SELECTIVITY:
 * We place the most selective column first. In this case, 'category' is highly selective
 * compared to 'price', so (category, price) is the optimal index order.
 */
async function getFilteredProducts(filters: { category: string; maxPrice: number }) {
  // Prisma automatically attempts to use composite indexes if defined in schema.prisma
  // Example schema index:
  // @@index([category, price])
  return await prisma.product.findMany({
    where: {
      category: filters.category,
      price: { lte: filters.maxPrice },
    },
    take: 20,
  });
}

/**
 * 3. VECTOR SEARCH (PINECONE) FOR SEMANTIC RETRIEVAL
 * 
 * WHY:
 * Keyword search fails on synonyms or abstract concepts (e.g., "durable outdoor gear").
 * Vector stores use Approximate Nearest Neighbor (ANN) algorithms (like HNSW) to find
 * semantically similar items in high-dimensional space.
 * 
 * PERFORMANCE:
 * Unlike relational DBs, vector DBs are optimized for distance calculations.
 * We query Pinecone to get the top-K most relevant IDs, then join back to SQL
 * for the actual data (Hybrid Search Pattern).
 */
async function searchByVector(
  queryEmbedding: number[],
  topK: number = 5
) {
  const index = pinecone.index(PINECONE_INDEX_NAME);

  // Query the vector store
  const queryResponse = await index.namespace(PINECONE_NAMESPACE).query({
    vector: queryEmbedding,
    topK: topK,
    includeMetadata: false,
  });

  // Extract IDs to fetch full relational data
  const matchedIds = queryResponse.matches.map((match) => match.id);
  return matchedIds;
}

/**
 * 4. HYBRID SEARCH ORCHESTRATION
 * 
 * LOGIC:
 * 1. Generate embedding for the user query (simulated here).
 * 2. Fetch candidate IDs from Pinecone (Vector Index).
 * 3. Fetch detailed data from PostgreSQL using the candidate IDs.
 * 4. Apply additional business logic/filters if needed.
 * 
 * WHY THIS MATTERS FOR INDEXING:
 * This reduces the load on the relational database. We don't scan the SQL table;
 * we only perform point lookups (Primary Key Index) on the specific IDs returned
 * by the vector search.
 */
async function hybridSearch(params: SearchRequest) {
  // 1. Simulate LLM/Embedding Generation
  // In production, call OpenAI or a local embedding model.
  const embedding = await generateMockEmbedding(params.query);

  // 2. Vector Search (Pinecone)
  // Fast, approximate retrieval based on semantic meaning.
  const vectorCandidateIds = await searchByVector(embedding, 10);

  if (vectorCandidateIds.length === 0) {
    return [];
  }

  // 3. Relational Data Fetch (PostgreSQL)
  // Using Primary Key Index (O(1) lookup per ID).
  // We combine this with the keyword filter if provided.
  const products = await prisma.product.findMany({
    where: {
      id: { in: vectorCandidateIds },
      // Apply additional filters that might not be in the vector index
      ...(params.category && { category: params.category }),
      ...(params.maxPrice && { price: { lte: params.maxPrice } }),
    },
    // Optional: Sort by relevance score if needed, though usually handled by vector DB
  });

  return products;
}

/**
 * 5. PARTIAL INDEXING STRATEGY (SIMULATED)
 * 
 * WHY:
 * A full index on a boolean flag (e.g., `is_active`) is often wasteful if 90% of rows are active.
 * A Partial Index only indexes rows that meet a specific condition.
 * 
 * SCENARIO:
 * We only want to search "In Stock" items frequently. We create an index that only
 * includes rows where `stock > 0`.
 * 
 * SQL Equivalent:
 * CREATE INDEX idx_active_products ON "Product"(category) WHERE stock > 0;
 */
async function searchActiveItems(category: string) {
  // Prisma doesn't support partial indexes directly in queries, but the DB uses them
  // automatically if the schema defines them.
  // We structure the query to match the partial index definition.
  return await prisma.product.findMany({
    where: {
      category: category,
      stock: { gt: 0 }, // Matches the WHERE clause of the partial index
    },
  });
}

// --- HELPER: MOCK EMBEDDING GENERATOR ---
// In a real app, this would call an LLM API (e.g., OpenAI Embeddings)
async function generateMockEmbedding(text: string): Promise<number[]> {
  // Simulating a 1536-dimension vector (common for OpenAI text-embedding-ada-002)
  const vector: number[] = [];
  for (let i = 0; i < 1536; i++) {
    // Simple hash-based pseudo-random generation for demo consistency
    vector.push(((text.charCodeAt(i % text.length) * i) % 1000) / 1000);
  }
  return vector;
}

// --- NEXT.JS API ROUTE ---

/**
 * POST /api/search
 * 
 * Endpoint: Intelligent Hybrid Search
 * 
 * Strategy:
 * 1. Validates input.
 * 2. Routes to Hybrid Search (Vector + SQL) or Keyword Search based on weights.
 * 3. Returns serialized JSON.
 */
export async function POST(request: NextRequest) {
  try {
    const body: SearchRequest = await request.json();

    // Decision Logic: Choose strategy based on weights
    // If semantic weight is high, prioritize Vector Search.
    // If keyword weight is high, prioritize GIN Index Search.
    
    let results;

    if ((body.semanticWeight || 0) > (body.keywordWeight || 0)) {
      // STRATEGY A: Semantic First (LLM + Vector Store)
      // Best for: "Comfortable shoes for running"
      results = await hybridSearch(body);
    } else {
      // STRATEGY B: Keyword First (SQL GIN Index)
      // Best for: "Nike Air Max 2024"
      results = await searchByKeyword(body.query, {
        category: body.category,
        maxPrice: body.maxPrice,
        minStock: body.minStock,
      });
    }

    // Performance Logging (Under the hood insight)
    console.log(`[Search API] Retrieved ${results.length} results using ${body.semanticWeight ? 'Vector' : 'Keyword'} strategy.`);

    return NextResponse.json({
      success: true,
      count: results.length,
      data: results,
      // In production, include metadata like 'cacheHit' or 'indexUsed'
    });

  } catch (error) {
    console.error('Search API Error:', error);
    return NextResponse.json(
      { success: false, error: 'Internal Server Error' },
      { status: 500 }
    );
  }
}
