/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// Prisma Schema Migration (schema.prisma)
// We define a composite index on (authorId, published, createdAt).
// 1. authorId: Equality filter (WHERE authorId = ?)
// 2. published: Equality filter (WHERE published = true)
// 3. createdAt: Sort order (ORDER BY createdAt DESC)
// Note: In PostgreSQL, an index on (A, B) can be used for sorting on A alone,
// but for sorting on B alone, you generally need (A, B) or (B). 
// Here we sort by createdAt, so placing it at the end allows the index to handle the sort.

model Post {
  id        String   @id @default(uuid())
  title     String
  content   String
  published Boolean  @default(false)
  createdAt DateTime @default(now())
  authorId  String
  
  author User @relation(fields: [authorId], references: [id])

  @@index([authorId, published, createdAt], name: "idx_post_feed_optimization")
}

// Example Query (src/server/routers/feed.ts)
// This query now utilizes the composite index for filtering and sorting.
const recentPosts = await prisma.post.findMany({
  where: {
    authorId: userId,      // Matches 1st column of index
    published: true,       // Matches 2nd column of index
  },
  orderBy: {
    createdAt: 'desc',     // Matches 3rd column of index
  },
  take: 20,
  include: {
    author: true,
  },
});

// Verification SQL (Run in psql or pgAdmin)
/*
EXPLAIN (ANALYZE, BUFFERS)
SELECT "public"."Post"."id", ... 
FROM "public"."Post" 
WHERE ("public"."Post"."authorId" = $1 AND "public"."Post"."published" = $2)
ORDER BY "public"."Post"."createdAt" DESC
LIMIT $3;

-- Expected Output:
-- Index Scan using "idx_post_feed_optimization" on "Post"
-- Index Cond: ((authorId = ...) AND (published = true))
-- Sort Method: quicksort (or no sort if index provides order)
*/
