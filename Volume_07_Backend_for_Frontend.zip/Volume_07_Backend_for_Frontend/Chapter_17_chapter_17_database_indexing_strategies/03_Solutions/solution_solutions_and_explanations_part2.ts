/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

// Prisma Schema (schema.prisma)
// Since Prisma doesn't natively support INCLUDE (Postgres 11+ feature) or covering indexes 
// via standard attributes, we use a raw migration for the most efficient implementation.

// However, if using a standard @@index, Prisma creates a B-tree on the listed columns.
// For a true covering index in Postgres, we want: CREATE INDEX idx_product_dashboard ON products (category) INCLUDE (name, price);
// Or a composite index: CREATE INDEX idx_product_dashboard ON products (category, name, price);

model Product {
  id          String   @id @default(uuid())
  name        String
  price       Float
  category    String
  description String   // Large text field we want to avoid fetching
  metadata    Json     // Large field we want to avoid fetching
  
  @@index([category, name, price], name: "idx_product_dashboard")
}

// Example Query (src/server/routers/products.ts)
// The query only selects columns present in the index.
const products = await prisma.product.findMany({
  where: {
    category: 'electronics', // Filter on 1st column
  },
  select: {
    id: true,      // Included implicitly in PK or index
    name: true,    // 2nd column in index
    price: true,   // 3rd column in index
    category: true // 1st column in index
  },
});

// Verification SQL
/*
EXPLAIN (ANALYZE, BUFFERS)
SELECT name, price, category 
FROM products 
WHERE category = 'electronics';

-- Expected Output:
-- Index Only Scan using "idx_product_dashboard" on "products"
-- Index Cond: (category = 'electronics')
-- Heap Fetches: 0  <-- Key indicator of success
*/
