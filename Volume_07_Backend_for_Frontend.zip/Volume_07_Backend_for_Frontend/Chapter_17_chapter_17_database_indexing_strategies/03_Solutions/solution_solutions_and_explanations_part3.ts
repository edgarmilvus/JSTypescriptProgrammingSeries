/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

// Migration Script (migrations/20231027_add_partial_index.sql)
// Prisma schema does not support partial indexes directly via schema.prisma syntax.
// We must use a raw SQL migration file.

-- Create a partial index on user_id, but ONLY for rows where is_read = false.
-- This index will be significantly smaller than a full index on user_id.
CREATE INDEX idx_unread_notifications 
ON notifications (user_id) 
WHERE is_read = false;

// Prisma Query (src/server/routers/notifications.ts)
// The query WHERE clause MUST match the partial index definition exactly.
const unreadNotifications = await prisma.notification.findMany({
  where: {
    userId: user.id,      // Matches index column
    isRead: false,        // Matches partial index condition
  },
  orderBy: {
    createdAt: 'desc',
  },
});

// Verification SQL
/*
EXPLAIN (ANALYZE)
SELECT * FROM notifications 
WHERE user_id = 'some-uuid' AND is_read = false;

-- Expected Output:
-- Index Scan using "idx_unread_notifications" on "notifications"
-- Index Cond: (user_id = 'some-uuid')
-- Note: The planner knows 'is_read = false' is implicit due to the index definition.
*/
