/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

interface IndexAdvice {
  recommendedIndex: string[];
  isCovering: boolean;
  isPartial: boolean;
  reasoning: string[];
}

/**
 * Analyzes a SQL query and schema to suggest an index strategy.
 * Note: This uses simple regex for demonstration purposes. 
 * Production tools would use a proper SQL AST parser.
 */
function analyzeQuery(sql: string, schema: Record<string, string>): IndexAdvice {
  const advice: IndexAdvice = {
    recommendedIndex: [],
    isCovering: false,
    isPartial: false,
    reasoning: [],
  };

  // 1. Extract Columns from SELECT (for covering check)
  const selectMatch = sql.match(/SELECT\s+(.*?)\s+FROM/i);
  const selectCols = selectMatch ? selectMatch[1].split(',').map(c => c.trim()) : [];

  // 2. Extract WHERE clause columns
  const whereMatch = sql.match(/WHERE\s+(.*)/i);
  if (!whereMatch) return advice;
  
  const whereClause = whereMatch[1];
  
  // 3. Extract ORDER BY columns
  const orderMatch = sql.match(/ORDER BY\s+(.*?)\s*(?:LIMIT|;|$)/i);
  const orderCols = orderMatch ? orderMatch[1].split(',').map(c => c.trim()) : [];

  // 4. Parse Equality vs Range Filters
  const equalityCols: string[] = [];
  const rangeCols: string[] = [];
  
  // Simple regex to find "col = 'value'" or "col = variable"
  const eqRegex = /(\w+)\s*=\s*('[^']*'|\d+|true|false)/gi;
  let match;
  while ((match = eqRegex.exec(whereClause)) !== null) {
    equalityCols.push(match[1]);
  }

  // Simple regex for range operators >, <, >=, <=, BETWEEN
  const rangeRegex = /(\w+)\s*(>|<|>=|<=|BETWEEN)/gi;
  while ((match = rangeRegex.exec(whereClause)) !== null) {
    rangeCols.push(match[1]);
  }

  // 5. Construct Index Strategy
  // Rule: Equality filters first, then Range/Sort columns, then Covering columns
  
  // Add equality columns
  advice.recommendedIndex.push(...equalityCols);
  
  // Add range/sort columns (if they exist in schema)
  orderCols.forEach(col => {
    if (!advice.recommendedIndex.includes(col)) {
      advice.recommendedIndex.push(col);
    }
  });
  rangeCols.forEach(col => {
    if (!advice.recommendedIndex.includes(col)) {
      advice.recommendedIndex.push(col);
    }
  });

  // 6. Check for Covering Index
  // We check if all columns in SELECT are present in our proposed index or are the PK
  const allIndexCols = [...advice.recommendedIndex, 'id']; // Assuming ID is PK
  const isCovering = selectCols.every(col => allIndexCols.includes(col));
  
  if (isCovering) {
    advice.isCovering = true;
    advice.reasoning.push("Index can satisfy query without table access (Covering).");
  }

  // 7. Check for Partial Index
  // If a WHERE clause contains a constant equality check (e.g., status = 'active')
  // that is highly selective, it's a candidate for a partial index.
  if (equalityCols.length > 0) {
    // Heuristic: If we have a column with a literal value in WHERE
    if (whereClause.includes("'")) {
      advice.isPartial = true;
      advice.reasoning.push("Constant filter detected. A partial index is applicable.");
    }
  }

  return advice;
}

// --- Example Usage ---
const query = "SELECT id, email FROM users WHERE role = 'admin' AND created_at > '2023-01-01' ORDER BY created_at DESC";
const schema = {
  id: 'uuid',
  email: 'varchar',
  role: 'varchar',
  created_at: 'timestamp',
  last_login: 'timestamp'
};

const result = analyzeQuery(query, schema);
console.log(result);
/*
Output:
{
  recommendedIndex: [ 'role', 'created_at', 'email' ],
  isCovering: true,
  isPartial: true,
  reasoning: [
    'Index can satisfy query without table access (Covering).',
    'Constant filter detected. A partial index is applicable.'
  ]
}
*/
