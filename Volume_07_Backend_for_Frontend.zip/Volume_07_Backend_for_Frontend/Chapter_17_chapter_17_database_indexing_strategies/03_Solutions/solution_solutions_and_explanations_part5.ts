/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

// Migration Script (migrations/20231027_add_hnsw_index.sql)
// Prisma does not support vector types or HNSW natively yet.
// We use a raw SQL migration to create the table and index.

-- Enable the pgvector extension if not already enabled
CREATE EXTENSION IF NOT EXISTS vector;

-- Create table (if not managed by Prisma)
CREATE TABLE document_chunks (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    content TEXT,
    embedding VECTOR(1536) -- Assuming OpenAI ada-002 dimensions
);

-- Create the HNSW index
-- HNSW (Hierarchical Navigable Small World) is an graph-based index.
-- It provides fast ANN search with high recall.
-- 'vector_cosine_ops' defines the distance function (1 - cosine_similarity).
CREATE INDEX ON document_chunks USING hnsw (embedding vector_cosine_ops);

// Prisma Query (src/server/routers/search.ts)
// To utilize the index, we use the <==> operator (cosine distance) 
// or <=> (cosine similarity) provided by pgvector.

// Note: Prisma raw query is required here as Prisma ORM doesn't support vector operators natively.
const searchResults = await prisma.$queryRaw`
  SELECT id, content, 1 - (embedding <=> ${embeddingVector}::vector) as similarity
  FROM document_chunks
  WHERE embedding <=> ${embeddingVector}::vector < 0.1 -- Threshold for relevance
  ORDER BY embedding <=> ${embeddingVector}::vector
  LIMIT 5;
`;

// Verification SQL
/*
EXPLAIN (ANALYZE)
SELECT * FROM document_chunks 
ORDER BY embedding <=> '[0.1, 0.2, ...]'::vector 
LIMIT 5;

-- Expected Output:
-- Index Scan using "document_chunks_embedding_idx" on "document_chunks"
-- (Note: Output depends on pgvector version, but should show "Index Scan" or "Bitmap Index Scan")
-- Seq Scan should NOT appear.
*/

// --- Performance Comparison Analysis ---

/*
IVFFlat vs HNSW:

1. IVFFlat (Inverted File with Flat Compression):
   - Mechanism: Divides the vector space into lists (clusters). Queries are limited to the nearest lists.
   - Build Time: Fast.
   - Query Speed: Fast, but accuracy depends on the number of lists (probes).
   - Trade-off: Lower recall (accuracy) than HNSW, especially if the probe count is low.
   - Best for: Large datasets where build time matters and slight accuracy loss is acceptable.

2. HNSW (Hierarchical Navigable Small World):
   - Mechanism: Creates a multi-layered graph. The top layers allow fast "jumps" across the space, while lower layers refine the search.
   - Build Time: Slower than IVFFlat (requires building the graph).
   - Query Speed: Very fast, typically O(log n).
   - Trade-off: Higher memory usage (stores graph structure). Slower write speeds.
   - Best for: Real-time applications requiring high accuracy and low latency (e.g., chatbots).

Recommendation: For a real-time chatbot, HNSW is the superior choice. The slower build time is a one-time cost (or paid during updates), while the query speed is critical for user experience.
*/
