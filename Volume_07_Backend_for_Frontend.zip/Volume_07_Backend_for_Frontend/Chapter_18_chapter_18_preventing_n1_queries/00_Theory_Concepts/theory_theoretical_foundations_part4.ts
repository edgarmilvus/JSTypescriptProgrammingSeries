/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part4.ts
// Description: Theoretical Foundations
// ==========================================

// src/server/context.ts
import { CreateFastifyContextOptions } from '@trpc/server/adapters/fastify';
import DataLoader from 'dataloader';
import { db } from './db';
import { usersTable } from './db/schema';
import { eq, inArray } from 'drizzle-orm';

// Define the batching function
const createAuthorLoader = () => {
  return new DataLoader<string, User>(async (authorIds) => {
    // Batched query
    const authors = await db.select().from(usersTable).where(inArray(usersTable.id, [...authorIds]));
    const authorMap = new Map(authors.map(author => [author.id, author]));
    // Map results back to keys
    return authorIds.map(id => authorMap.get(id) || null);
  });
};

export const createContext = async (opts: CreateFastifyContextOptions) => {
  return {
    // Each request gets its own loader instance
    authorLoader: createAuthorLoader(),
    // ... other context properties
  };
};

// src/server/routers/posts.ts
import { router, procedure } from '../trpc';
import { z } from 'zod';

export const postsRouter = router({
  list: procedure.query(async ({ ctx }) => {
    const posts = await db.select().from(postsTable);

    // Now, resolve authors using the loader
    const postsWithAuthors = await Promise.all(
      posts.map(async (post) => ({
        ...post,
        // This will trigger the batching mechanism
        author: await ctx.authorLoader.load(post.authorId),
      }))
    );

    return postsWithAuthors;
  }),
});
