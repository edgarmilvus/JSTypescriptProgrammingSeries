/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

// ==========================================
// 1. Mock Database & Types
// ==========================================

/**
 * Simulates a database table for Users.
 */
type User = {
  id: string;
  username: string;
};

/**
 * Simulates a database table for Posts.
 */
type Post = {
  id: string;
  title: string;
  authorId: string; // Foreign Key
};

// Mock Data
const mockUsers: User[] = [
  { id: '1', username: 'Alice' },
  { id: '2', username: 'Bob' },
  { id: '3', username: 'Charlie' },
];

const mockPosts: Post[] = [
  { id: 'p1', title: 'Hello World', authorId: '1' },
  { id: 'p2', title: 'tRPC is Cool', authorId: '1' }, // Alice again
  { id: 'p3', title: 'Edge Computing', authorId: '2' },
];

// ==========================================
// 2. The Batched Database Layer (The "Loader")
// ==========================================

/**
 * A mock database function that simulates fetching multiple users by IDs.
 * CRITICAL: This accepts an ARRAY of IDs and returns an ARRAY of Users.
 * It represents a single SQL query: `SELECT * FROM users WHERE id IN (...)`
 */
async function fetchUsersByIds(ids: string[]): Promise<User[]> {
  console.log(`[DB] Executing Batched Query for IDs: [${ids.join(', ')}]`);
  
  // Simulate network latency
  await new Promise(resolve => setTimeout(resolve, 50));

  return mockUsers.filter(user => ids.includes(user.id));
}

// ==========================================
// 3. The DataLoader Implementation
// ==========================================

/**
 * A simplified implementation of the DataLoader pattern.
 * 
 * @param batchLoadFn - The function that performs the actual batch fetch.
 * @returns A function that accepts a single ID and returns a Promise for that specific item.
 */
function createDataLoader<T, K>(batchLoadFn: (keys: K[]) => Promise<T[]>) {
  // The queue stores the pending requests (keys) for the current tick
  let queue: { key: K; resolve: (value: T) => void; reject: (reason?: any) => void }[] = [];

  // This is the function returned to the caller (e.g., the tRPC resolver)
  return async (key: K): Promise<T> => {
    return new Promise((resolve, reject) => {
      // 1. Add the request to the queue
      queue.push({ key, resolve, reject });

      // 2. Schedule the batch execution for the next tick of the event loop
      //    (If multiple calls happen in the same synchronous block, they share this timer)
      if (queue.length === 1) {
        process.nextTick(async () => {
          // Copy the queue and clear it immediately so new requests can queue up
          const currentQueue = [...queue];
          queue = [];

          // Extract just the keys
          const keys = currentQueue.map(item => item.key);

          try {
            // 3. Execute the single batched function
            const values = await batchLoadFn(keys);

            // 4. Map the results back to the individual promises
            //    (DataLoader assumes the return array order matches the keys array order)
            currentQueue.forEach(({ key, resolve, reject }, index) => {
              const value = values[index];
              if (value) {
                resolve(value);
              } else {
                reject(new Error(`Key not found: ${key}`));
              }
            });
          } catch (error) {
            // If the batch fails, reject all pending promises
            currentQueue.forEach(({ reject }) => reject(error));
          }
        });
      }
    });
  };
}

// ==========================================
// 4. The "App" Logic (Simulating a tRPC Query)
// ==========================================

/**
 * Simulates a tRPC router procedure.
 * This function fetches posts, and then resolves the author for each post.
 */
async function getPostsWithAuthors() {
  console.log("--- Starting Request ---");

  // A. Initialize the Loader (usually done once per request or globally)
  //    We pass our batch function to it.
  const userLoader = createDataLoader(fetchUsersByIds);

  // B. Fetch the list of Posts (1 Query)
  //    In a real app: const posts = await db.post.findMany();
  const posts = mockPosts; 
  console.log(`[Resolver] Found ${posts.length} posts.`);

  // C. The N+1 Loop (Optimized)
  //    Even though we loop and call 'userLoader' for every post,
  //    the loader batches them internally.
  const postsWithAuthors = await Promise.all(
    posts.map(async (post) => {
      // This line looks like N+1, but it's actually batched!
      const author = await userLoader.load(post.authorId);
      
      return {
        ...post,
        authorName: author.username,
      };
    })
  );

  console.log("--- Result ---");
  console.log(JSON.stringify(postsWithAuthors, null, 2));
}

// Run the example
getPostsWithAuthors().catch(console.error);
