/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// src/server/api/routers/projectAnalytics.ts

import { z } from "zod";
import { createTRPCRouter, publicProcedure } from "~/server/api/trpc";
import { createClient } from "@supabase/supabase-js";
import DataLoader from "dataloader";

// 1. Define the shape of the raw data we expect from the database
interface DeploymentRow {
  id: string;
  project_id: string;
  status: "success" | "failed" | "running";
  created_at: string;
}

// 2. Initialize Supabase Client (Mocked for context, usually in ctx)
const supabase = createClient(
  process.env.SUPABASE_URL!,
  process.env.SUPABASE_ANON_KEY!
);

/**
 * 3. DATA LOADER FACTORY
 * 
 * Why: We create a new DataLoader instance per request (or per context) to ensure
 * that the batching/caching scope is isolated to the current user's operation.
 * 
 * How: The batch function receives an array of keys (projectIds) and must return
 * a Promise that resolves to an array of results in the EXACT same order.
 * 
 * Under the Hood: This allows the database driver to coalesce multiple distinct
 * calls to `load(projectId)` into a single execution cycle.
 */
const createDeploymentLoader = () => {
  return new DataLoader<string, DeploymentRow | null>(async (projectIds) => {
    console.log(`[DataLoader] Batching ${projectIds.length} queries...`);

    // Construct a single SQL-like query to fetch all deployments for the given project IDs
    // We filter by the latest deployment per project (using a subquery or distinct logic)
    // For simplicity here, we fetch all and pick the latest in code, or use DB aggregation.
    
    const { data, error } = await supabase
      .from("deployments")
      .select("*")
      .in("project_id", projectIds as string[])
      .order("created_at", { ascending: false });

    if (error) {
      throw error;
    }

    // 4. MAP RESULTS TO KEYS
    // DataLoader requires the return array to match the input keys array 1:1.
    // We map over the requested IDs and find the matching deployment.
    // Note: In a real scenario, you might use a Map for O(1) lookup.
    const projectMap = new Map<string, DeploymentRow>();
    
    // Since we ordered by date, the first one we see is the latest
    data.forEach((row) => {
      if (!projectMap.has(row.project_id)) {
        projectMap.set(row.project_id, row);
      }
    });

    // Return array aligned with `projectIds`
    return projectIds.map((id) => projectMap.get(id) || null);
  }, {
    // Optional: Cache successful lookups for the duration of this loader instance
    cache: true 
  });
};

export const projectRouter = createTRPCRouter({
  /**
   * PROCEDURE: Get Dashboard List
   * 
   * Objective: Fetch a list of projects and their latest deployment status
   * WITHOUT triggering N+1 queries.
   */
  getDashboardList: publicProcedure.query(async () => {
    // Step 1: Fetch the parent entities (The "1")
    const { data: projects, error: projectError } = await supabase
      .from("projects")
      .select("id, name, owner_id");

    if (projectError || !projects) {
      throw new Error("Failed to fetch projects");
    }

    // Step 2: Instantiate the DataLoader for this specific operation
    const deploymentLoader = createDeploymentLoader();

    // Step 3: Map over parents and "load" the child data
    // Even though this looks like a loop calling the database, DataLoader intercepts these calls.
    const dashboardData = await Promise.all(
      projects.map(async (project) => {
        // This line triggers the batching mechanism. 
        // It does NOT immediately hit the database.
        const latestDeployment = await deploymentLoader.load(project.id);

        return {
          id: project.id,
          name: project.name,
          status: latestDeployment?.status ?? "never_deployed",
          lastDeployed: latestDeployment?.created_at ?? null,
        };
      })
    );

    return dashboardData;
  }),
});
