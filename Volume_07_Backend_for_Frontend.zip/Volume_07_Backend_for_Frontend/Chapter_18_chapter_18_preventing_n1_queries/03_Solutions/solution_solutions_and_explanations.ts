/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// loader.ts
import DataLoader from 'dataloader';
import { createClient } from '@supabase/supabase-js';

// Mock Supabase client (replace with real credentials in production)
const supabase = createClient('https://mock.supabase.co', 'mock-key');

interface Author {
  id: string;
  name: string;
}

// Implementation of the batch loading function
export const createAuthorLoader = () => {
  return new DataLoader<string, Author>(async (authorIds: string[]) => {
    // 1. Remove duplicates to optimize the query
    const uniqueIds = [...new Set(authorIds)];

    // 2. Perform a single Supabase query using the 'in' filter
    const { data, error } = await supabase
      .from('authors')
      .select('id, name')
      .in('id', uniqueIds);

    if (error) {
      throw new Error(`Failed to fetch authors: ${error.message}`);
    }

    // 3. Map results back to the original order of authorIds
    // DataLoader requires the return array to match the order of the keys array
    const authorMap = new Map(data?.map((author) => [author.id, author]));
    return authorIds.map((id) => {
      const author = authorMap.get(id);
      // Return the author if found, or null/undefined if missing (DataLoader handles nulls)
      return author as Author; 
    });
  });
};
