/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

// search.ts
import { createClient } from '@supabase/supabase-js';

// Mock Supabase client
const supabase = createClient('https://mock.supabase.co', 'mock-key');

interface PineconeMatch {
  id: string;
  score: number;
}

interface DocumentMetadata {
  id: string;
  content: string;
  title: string;
}

export async function fetchEnrichedMatches(
  matches: PineconeMatch[]
): Promise<(PineconeMatch & DocumentMetadata)[]> {
  // 1. Extract IDs from matches
  const ids = matches.map((match) => match.id);

  // If no matches, return empty array immediately
  if (ids.length === 0) return [];

  // 2. Perform a single Supabase query
  // We use the 'in' filter to fetch all documents matching the vector IDs
  const { data: documents, error } = await supabase
    .from('documents')
    .select('id, content, title')
    .in('id', ids);

  if (error) {
    console.error("Database fetch error:", error);
    // In an Edge function, we might want to return partial data or throw
    // depending on strictness. Here we return empty to prevent crash.
    return [];
  }

  // 3. Create a map for O(1) lookup of metadata
  const docMap = new Map<string, DocumentMetadata>();
  documents.forEach((doc) => docMap.set(doc.id, doc));

  // 4. Merge metadata with scores and return in original order
  const enrichedResults = matches.map((match) => {
    const metadata = docMap.get(match.id);
    
    // 4. Error Handling: Gracefully handle missing data
    // If metadata is undefined (ID mismatch), we still return the match info
    // but fill metadata with empty strings or nulls to maintain structure.
    return {
      id: match.id,
      score: match.score,
      content: metadata?.content || "[Content Missing]",
      title: metadata?.title || "[Title Missing]",
    };
  });

  return enrichedResults;
}
