/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

// CommentTree.tsx
import React, { useMemo } from 'react';

interface Comment {
  id: string;
  text: string;
  parentId: string | null;
}

interface CommentTreeProps {
  comments: Comment[];
}

// Extended interface for the tree node
interface TreeNode extends Comment {
  children: TreeNode[];
}

export const CommentTree: React.FC<CommentTreeProps> = ({ comments }) => {
  const treeStructure = useMemo(() => {
    // 1. Create a map of ID -> Comment object with a children array
    // This allows O(1) access to any node by ID.
    const map = new Map<string, TreeNode>();
    const roots: TreeNode[] = [];

    comments.forEach((comment) => {
      map.set(comment.id, { ...comment, children: [] });
    });

    // 2. Build the tree structure in a single pass
    comments.forEach((comment) => {
      const node = map.get(comment.id)!;
      
      if (comment.parentId === null) {
        // It's a root comment
        roots.push(node);
      } else {
        // It's a child; find the parent in the map and add this node to its children
        const parent = map.get(comment.parentId);
        if (parent) {
          parent.children.push(node);
        }
      }
    });

    return roots;
  }, [comments]);

  // Helper render function
  const renderNode = (node: TreeNode, depth: number) => {
    return (
      <li key={node.id} style={{ paddingLeft: `${depth * 20}px`, listStyleType: 'none' }}>
        <div style={{ border: '1px solid #eee', margin: '2px', padding: '4px' }}>
          {node.text}
        </div>
        {node.children.length > 0 && (
          <ul>
            {node.children.map((child) => renderNode(child, depth + 1))}
          </ul>
        )}
      </li>
    );
  };

  return (
    <ul style={{ paddingLeft: '0' }}>
      {treeStructure.map((node) => renderNode(node, 0))}
    </ul>
  );
};
