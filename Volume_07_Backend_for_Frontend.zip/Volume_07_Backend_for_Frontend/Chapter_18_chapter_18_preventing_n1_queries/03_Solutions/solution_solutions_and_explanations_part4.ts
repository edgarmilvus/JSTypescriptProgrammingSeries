/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

// data.ts
interface FileNode {
  id: string;
  path: string; 
  imports: string[]; 
}

const mockFiles: FileNode[] = [
  { id: '1', path: 'src/index.ts', imports: ['2', '3'] },
  { id: '2', path: 'src/utils/math.ts', imports: [] },
  { id: '3', path: 'src/components/App.tsx', imports: ['2'] },
  { id: '4', path: 'src/components/App.tsx/styles.css', imports: [] }, 
];

// Helper interface for the tree structure
interface FolderNode {
  name: string;
  files: FileNode[];
  subfolders: Map<string, FolderNode>;
}

export function generateDependencyGraph(files: FileNode[]) {
  // 1. Transform flat list to hierarchy
  const root: FolderNode = {
    name: 'root',
    files: [],
    subfolders: new Map(),
  };

  files.forEach((file) => {
    const parts = file.path.split('/');
    let current = root;

    // Traverse/Create folder structure (excluding the filename)
    for (let i = 0; i < parts.length - 1; i++) {
      const part = parts[i];
      if (!current.subfolders.has(part)) {
        current.subfolders.set(part, {
          name: part,
          files: [],
          subfolders: new Map(),
        });
      }
      current = current.subfolders.get(part)!;
    }

    // Add the file to the final folder
    current.files.push(file);
  });

  // 2. Generate DOT string
  let dot = 'digraph DependencyGraph {\n';
  dot += '  rankdir=LR;\n'; // Left to Right layout
  
  // Helper to traverse the hierarchy and generate nodes
  const traverseAndGenerateNodes = (node: FolderNode, parentPath: string) => {
    const currentPath = parentPath ? `${parentPath}/${node.name}` : node.name;
    
    // Create a cluster for the folder (subgraph)
    if (node.name !== 'root') {
      dot += `  subgraph "cluster_${currentPath}" {\n`;
      dot += `    label = "${node.name}";\n`;
      dot += `    style = filled;\n`;
      dot += `    color = lightgrey;\n`;
    }

    // Add files as nodes
    node.files.forEach((file) => {
      const safeId = file.id; // Use ID for graph uniqueness
      const label = file.path.split('/').pop(); // Just filename for label
      dot += `    "${safeId}" [label="${label}"];\n`;
    });

    // Recurse for subfolders
    node.subfolders.forEach((subfolder) => {
      traverseAndGenerateNodes(subfolder, currentPath);
    });

    if (node.name !== 'root') {
      dot += '  }\n';
    }
  };

  traverseAndGenerateNodes(root, '');

  // Add edges based on imports
  files.forEach((file) => {
    file.imports.forEach((importId) => {
      // Check if target exists in our dataset to avoid invalid refs
      const target = files.find(f => f.id === importId);
      if (target) {
        dot += `  "${file.id}" -> "${target.id}";\n`;
      }
    });
  });

  dot += '}';

  // 3. Return the string wrapped in a format suitable for LLM or visualization
  return `\`\`\`dot\n${dot}\n\`\`\``;
}
