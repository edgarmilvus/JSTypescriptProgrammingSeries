/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

// agent.ts

interface AgentState {
  input: string;
  iterationCount: number;
  status: 'running' | 'finished' | 'maxed_out';
  logs: string[];
}

const MAX_ITERATIONS = 5;

export function runAgentLoop(initialState: AgentState) {
  // Create a mutable copy of the state
  let currentState: AgentState = { ...initialState };

  // Simulate the loop
  while (true) {
    // 1. Check Max Iteration Policy (Guardrail)
    if (currentState.iterationCount >= MAX_ITERATIONS) {
      currentState.status = 'maxed_out';
      currentState.logs.push(`Safety Stop: Reached max iterations (${MAX_ITERATIONS}).`);
      break;
    }

    // 2. Increment iterationCount (Immutable update)
    currentState = {
      ...currentState,
      iterationCount: currentState.iterationCount + 1,
    };

    // 3. Simulate an action (e.g., the agent thinking or taking an action)
    currentState.logs.push(`Iteration ${currentState.iterationCount}: Processing input...`);

    // 4. Check if we should finish naturally
    // Simulating a condition where the input is processed or empty
    if (currentState.input.length === 0 || currentState.iterationCount === 3) {
      currentState.status = 'finished';
      currentState.logs.push("Task completed naturally.");
      break;
    }

    // Simulate a reduction in input for the next loop
    currentState.input = ""; 
  }

  return currentState;
}

// Edge Function Handler (Skeleton)
export async function POST(request: Request) {
  const initialState: AgentState = {
    input: "Query user data",
    iterationCount: 0,
    status: 'running',
    logs: []
  };

  try {
    const result = runAgentLoop(initialState);

    if (result.status === 'maxed_out') {
      // 422 Unprocessable Entity is appropriate for semantic validation failure (safety limit)
      return new Response(JSON.stringify({ 
        error: "Max iterations reached", 
        logs: result.logs 
      }), {
        status: 422,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    return new Response(JSON.stringify(result), {
      status: 200,
      headers: { 'Content-Type': 'application/json' }
    });
  } catch (error) {
    // Generic error handling for Edge Runtime
    return new Response(JSON.stringify({ error: "Internal Server Error" }), {
      status: 500,
      headers: { 'Content-Type': 'application/json' }
    });
  }
}
