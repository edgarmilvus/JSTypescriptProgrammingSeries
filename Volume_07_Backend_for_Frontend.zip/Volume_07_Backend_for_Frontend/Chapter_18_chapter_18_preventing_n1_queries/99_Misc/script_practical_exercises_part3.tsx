/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part3.tsx
// Description: Practical Exercises
// ==========================================

// CommentTree.tsx
import React, { useMemo } from 'react';

interface Comment {
  id: string;
  text: string;
  parentId: string | null;
}

interface CommentTreeProps {
  comments: Comment[];
}

// TODO: Implement the CommentTree component
export const CommentTree: React.FC<CommentTreeProps> = ({ comments }) => {
  // HINT: Create a map of parentId -> Comment[] to batch the lookups.
  //       Then, recursively build the tree structure using the map, not the original array.
  
  const treeStructure = useMemo(() => {
    // Implementation logic here
    return []; // Return the root nodes
  }, [comments]);

  // Helper render function
  const renderNode = (node: Comment, depth: number) => {
    return (
      <li key={node.id} style={{ paddingLeft: `${depth * 20}px` }}>
        {node.text}
        {/* Recursively render children */}
      </li>
    );
  };

  return <ul>{treeStructure.map((node) => renderNode(node, 0))}</ul>;
};
