/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part4.ts
// Description: Practical Exercises
// ==========================================

// data.ts
interface FileNode {
  id: string;
  path: string; // e.g., "src/utils/helper.ts"
  imports: string[]; // List of file IDs this file imports
}

const mockFiles: FileNode[] = [
  { id: '1', path: 'src/index.ts', imports: ['2', '3'] },
  { id: '2', path: 'src/utils/math.ts', imports: [] },
  { id: '3', path: 'src/components/App.tsx', imports: ['2'] },
  { id: '4', path: 'src/components/App.tsx/styles.css', imports: [] }, // Deep nesting
];

// TODO: Implement the transformation and DOT generator
export function generateDependencyGraph(files: FileNode[]) {
  // 1. Transform flat list to hierarchy
  // 2. Generate DOT string
  // 3. Return the string wrapped in 

[ERROR: Failed to render diagram.]



---

### Exercise 5: Edge Function Caching & Max Iteration Policy

**Problem Description:**
You are implementing a LangGraph-based agent inside a Vercel Edge Function that performs RAG (Retrieval-Augmented Generation). The agent cycles through a "Thought -> Action -> Observation" loop. You must implement a `MaxIterationPolicy` guardrail to prevent infinite loops, which are costly in a serverless environment.

**Requirements:**
1.  **State Management:** Define the state interface for the graph, which must include a `iterationCount` and `status`.
2.  **Conditional Edge:** Implement a function `checkMaxIterations` that acts as a conditional edge in the LangGraph. It should return `true` to continue the loop or `false` to terminate and transition to a `FINISH` node.
3.  **Context Propagation:** Ensure that every time the graph cycles, the `iterationCount` is incremented. This state must be immutable (create a new object on every update).
4.  **Edge Function Integration:** Wrap the graph execution in a `try/catch` block suitable for an Edge Runtime (no Node.js polyfills). If the max iteration limit is reached, return a JSON response with a 422 status code indicating the process was terminated for safety.

**Interactive Challenge:**
Simulate the agent loop. Write a function `runAgentLoop(startState)` that accepts an initial state. Inside a `while` loop, check the `MaxIterationPolicy`. If the limit (e.g., 5 iterations) is exceeded, break the loop and return a specific error message. Log the state at each step.

