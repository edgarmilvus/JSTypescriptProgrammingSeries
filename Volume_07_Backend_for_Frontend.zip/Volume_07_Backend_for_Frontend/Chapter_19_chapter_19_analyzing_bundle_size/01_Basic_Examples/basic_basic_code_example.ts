/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

// File: src/app/_components/HelloWorld.tsx
// Purpose: A client component that consumes a tRPC query.
// This component will be hydrated on the client, bringing tRPC dependencies into the bundle.

"use client";

import { api } from "~/utils/api";

/**
 * @component HelloWorld
 * @description A simple component that fetches and displays a message from tRPC.
 * This demonstrates the client-side footprint of tRPC.
 */
export default function HelloWorld() {
  // 1. Trigger a tRPC query. This hook is responsible for client-side data fetching.
  // It contains logic for caching, retries, and state management.
  const helloQuery = api.hello.sayHello.useQuery({ name: "World" });

  // 2. Handle loading state
  if (helloQuery.isLoading) {
    return <div>Loading...</div>;
  }

  // 3. Handle error state
  if (helloQuery.isError) {
    return <div>Error: {helloQuery.error.message}</div>;
  }

  // 4. Render the data
  return (
    <main>
      <h1>tRPC Bundle Analysis Example</h1>
      <p>Message from server: {helloQuery.data?.greeting}</p>
    </main>
  );
}
