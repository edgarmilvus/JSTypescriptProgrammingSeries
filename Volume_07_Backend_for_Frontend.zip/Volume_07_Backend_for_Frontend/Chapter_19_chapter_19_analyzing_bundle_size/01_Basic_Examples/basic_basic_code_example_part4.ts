/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example_part4.ts
// Description: Basic Code Example
// ==========================================

// File: analyze-bundle.ts
// Purpose: A Node.js script to generate a bundle analysis report.
// This script uses `esbuild` to bundle the client component and `esbuild-visualizer` to visualize it.

import * as esbuild from "esbuild";
import { visualizer } from "esbuild-visualizer";

/**
 * @function analyzeBundle
 * @description Builds the HelloWorld component and generates an HTML visualization of the bundle.
 * This mimics the build process of a Next.js app to isolate the client bundle size.
 */
async function analyzeBundle() {
  console.log("🚀 Starting bundle analysis...");

  // 1. Define the entry point (the client component).
  const entryPoint = "./src/app/_components/HelloWorld.tsx";

  // 2. Configure the esbuild context.
  // We target 'esnext' to see the full dependency tree without polyfills.
  const ctx = await esbuild.context({
    entryPoints: [entryPoint],
    bundle: true,
    outdir: "./dist-analysis",
    format: "esm",
    target: "esnext",
    // We need to define globals for React, as esbuild won't resolve them automatically in this standalone script.
    // In a real Next.js build, these are handled by the framework.
    define: {
      "process.env.NODE_ENV": '"production"',
    },
    // 3. Add the visualizer plugin.
    plugins: [
      visualizer({
        filename: "./dist-analysis/bundle-report.html",
        title: "tRPC Client Bundle Analysis",
        // This option allows us to see the size of specific modules.
        template: "treemap", 
      }),
    ],
    // 4. Mark external dependencies to simulate a browser environment.
    // In a real build, React and Next.js are externalized.
    external: ["react", "react-dom", "@tanstack/react-query"],
  });

  // 5. Rebuild the bundle.
  await ctx.rebuild();

  // 6. Dispose of the context.
  ctx.dispose();

  console.log("✅ Analysis complete. Open 'dist-analysis/bundle-report.html' in your browser.");
}

analyzeBundle().catch((err) => {
  console.error("❌ Bundle analysis failed:", err);
  process.exit(1);
});
