/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

// src/components/DashboardHeader.tsx
import { api } from "~/trpc/server";
import { Suspense } from "react";

// 1. Create a separate async component for the data fetching logic
// This allows the parent to render immediately while data loads
async function UserData() {
  // Direct server-side call to the tRPC router
  // No useEffect, no useSWR, no fetch calls manually
  const greeting = await api.example.hello.query({ text: "World" });

  return (
    <div className="p-4 bg-blue-50 rounded shadow">
      <h1 className="text-xl font-bold">Dashboard Header</h1>
      <p className="text-gray-700">Server Fetched Data: {greeting.greeting}</p>
      <p className="text-sm text-gray-500">Timestamp: {greeting.timestamp}</p>
    </div>
  );
}

// 2. The Main Server Component
export default async function DashboardHeader() {
  return (
    // Wrap in Suspense to handle the async boundary gracefully
    // This prevents the whole route from blocking if UserData is slow
    <Suspense fallback={<div>Loading Dashboard Header...</div>}>
      <UserData />
    </Suspense>
  );
}
