/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

// src/server/api/routers/ai.ts
import { z } from "zod";
import { createTRPCRouter, publicProcedure } from "~/server/api/trpc";
import { HeavyLLMService } from "~/lib/llm"; // Hypothetical heavy import

// ❌ BAD: Initializing heavy dependencies at the top level (Cold Start Killer)
// This runs every time the Edge Function instance spins up.
// const llm = new HeavyLLMService(process.env.LLM_API_KEY); 

export const aiRouter = createTRPCRouter({
  generateReport: publicProcedure
    .input(z.object({ prompt: z.string() }))
    .query(async ({ input }) => {
      // ✅ OPTIMIZED: Lazy initialization
      // We only import and instantiate the heavy dependency when the procedure is actually called.
      // Note: Dynamic imports can be used to further split bundles if the library is massive.
      const { HeavyLLMService } = await import("~/lib/llm");
      
      // Initialize here, inside the request scope
      const llm = new HeavyLLMService(process.env.LLM_API_KEY!);
      
      // Verify Edge Compatibility: 
      // Ensure 'llm' does not use Node.js specific APIs like 'fs' or 'net'
      // unless they are polyfilled by the framework.
      const report = await llm.generate(input.prompt);
      
      return { report };
    }),
});
