/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part6.ts
// Description: Solutions and Explanations
// ==========================================

// trpc/middleware/quantize.ts
import { middleware } from "~/trpc/server"; // Adjust path to your tRPC instance
import { TRPCError } from "@trpc/server";

/**
 * Recursively quantizes numbers in an object or array.
 * This reduces the string length of JSON payloads.
 */
function quantizeValue(value: unknown, precision: number = 2): unknown {
  if (typeof value === "number") {
    // Check if it's a float and round it
    if (!Number.isInteger(value)) {
      return Number(value.toFixed(precision));
    }
    return value;
  }

  if (Array.isArray(value)) {
    return value.map((item) => quantizeValue(item, precision));
  }

  if (typeof value === "object" && value !== null) {
    const result: Record<string, unknown> = {};
    for (const [key, val] of Object.entries(value)) {
      result[key] = quantizeValue(val, precision);
    }
    return result;
  }

  return value;
}

export const quantizePayload = middleware(async ({ next }) => {
  // Proceed with the request
  const result = await next();

  // If the result contains data, process it
  if (result.ok && result.data) {
    // We apply quantization to the data payload
    // Precision set to 2 decimal places as requested
    const quantizedData = quantizeValue(result.data, 2);
    
    return {
      ...result,
      data: quantizedData,
    };
  }

  return result;
});
