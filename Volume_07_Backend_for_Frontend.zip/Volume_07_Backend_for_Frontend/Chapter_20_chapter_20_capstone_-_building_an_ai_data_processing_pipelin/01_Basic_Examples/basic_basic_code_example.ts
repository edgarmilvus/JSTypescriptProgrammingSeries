/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

// app/api/trpc/[trpc]/route.ts
import { initTRPC } from '@trpc/server';
import { fetchRequestHandler } from '@trpc/server/adapters/fetch';
import OpenAI from 'openai';
import { z } from 'zod';

// 1. Initialize tRPC
const t = initTRPC.create();

// 2. Define the Input Schema using Zod
// We expect a 'rawData' string containing unstructured text.
const inputSchema = z.object({
  rawData: z.string(),
});

// 3. Create the Router
const appRouter = t.router({
  // Define the 'transformData' procedure
  transformData: t.procedure
    .input(inputSchema)
    .query(async ({ input }) => {
      // Initialize OpenAI client (Ensure OPENAI_API_KEY is in env)
      const openai = new OpenAI();

      // 4. Construct the Prompt
      // We instruct the LLM to act as a data parser and output strict JSON.
      const prompt = `
        You are a precise data extraction engine.
        Transform the following raw data into a JSON object with keys: "summary", "sentiment", and "priority".
        
        Raw Data:
        "${input.rawData}"
        
        Output only valid JSON.
      `;

      // 5. Call the LLM with Streaming
      // We use streaming to simulate real-time processing latency handling.
      const stream = await openai.chat.completions.create({
        model: 'gpt-3.5-turbo', // or gpt-4
        messages: [{ role: 'user', content: prompt }],
        stream: true,
        response_format: { type: 'json_object' }, // Hint for structured output
      });

      // 6. Create a ReadableStream to pipe LLM tokens to the client
      // This bypasses tRPC's default JSON serialization for streaming.
      const encoder = new TextEncoder();
      const readableStream = new ReadableStream({
        async start(controller) {
          for await (const chunk of stream) {
            const content = chunk.choices[0]?.delta?.content || '';
            controller.enqueue(encoder.encode(content));
          }
          controller.close();
        },
      });

      return readableStream;
    }),
});

// 7. Export the Handler for Next.js Route Handlers
export const handler = (req: Request) =>
  fetchRequestHandler({
    endpoint: '/api/trpc',
    req,
    router: appRouter,
    createContext: () => ({}),
  });

// 8. Explicitly export the POST method (Next.js Route Handler requirement)
export { handler as POST, handler as GET };
