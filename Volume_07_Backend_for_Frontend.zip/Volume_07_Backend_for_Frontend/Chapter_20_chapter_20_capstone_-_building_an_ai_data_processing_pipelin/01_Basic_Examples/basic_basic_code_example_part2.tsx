/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.tsx
// Description: Basic Code Example
// ==========================================

// app/page.tsx
import { useState } from 'react';

/**
 * Client Component to interact with the tRPC pipeline.
 * In a real app, this would be wrapped with a tRPC Provider.
 * For this "Hello World", we use a raw fetch call to demonstrate the raw stream.
 */
export default function DataPipelinePage() {
  const [result, setResult] = useState('');
  const [loading, setLoading] = useState(false);

  const handleProcess = async () => {
    setLoading(true);
    setResult('');

    // Prepare the input payload matching the Zod schema
    const payload = {
      rawData: "Customer feedback: 'The app crashes every time I click save. Very frustrating!'",
    };

    try {
      // 1. Call the tRPC endpoint
      // Note: tRPC uses POST requests for queries when sending inputs.
      const response = await fetch('/api/trpc/transformData', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          // tRPC v11+ format: { 0: { input: payload } }
          // Adjust based on your specific tRPC version configuration
          0: { input: payload }
        }),
      });

      if (!response.body) return;

      // 2. Process the Stream
      // We read the stream token-by-token (or chunk-by-chunk)
      const reader = response.body.getReader();
      const decoder = new TextDecoder();

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        // 3. Decode and Append
        const chunk = decoder.decode(value, { stream: true });
        setResult((prev) => prev + chunk);
      }
    } catch (error) {
      console.error("Pipeline failed:", error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{ padding: '20px', fontFamily: 'sans-serif' }}>
      <h1>AI Data Processing Pipeline</h1>
      <p>Input: "Customer feedback: 'The app crashes...'"</p>
      
      <button onClick={handleProcess} disabled={loading}>
        {loading ? 'Processing...' : 'Run Pipeline'}
      </button>

      <div style={{ marginTop: '20px', padding: '10px', border: '1px solid #ccc' }}>
        <strong>Structured Output:</strong>
        <pre>{result}</pre>
      </div>
    </div>
  );
}
