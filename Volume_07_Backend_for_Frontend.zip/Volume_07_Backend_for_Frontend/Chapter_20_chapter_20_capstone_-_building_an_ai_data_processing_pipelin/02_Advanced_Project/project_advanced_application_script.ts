/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// File: src/server/api/routers/feedbackRouter.ts
// Location: Backend (tRPC Router)
// Purpose: Defines the API endpoints for the feedback processing pipeline.

import { z } from "zod";
import { createTRPCRouter, publicProcedure } from "~/server/api/trpc";
import { TRPCError } from "@trpc/server";
import { StreamingTextResponse } from "ai"; // Assuming Vercel AI SDK is used for streaming

/**
 * @description Mock database fetch for raw feedback.
 * In a real scenario, this would query a Supabase table using the Supabase JS Client.
 * We simulate a network delay to mimic real-world latency.
 */
const fetchRawFeedback = async (): Promise<Array<{ id: string; text: string }>> => {
  await new Promise((resolve) => setTimeout(resolve, 500)); // Simulate DB latency
  return [
    { id: "fb_001", text: "The login button on the dashboard is unresponsive on mobile." },
    { id: "fb_002", text: "I love the new dark mode feature! It's exactly what I needed." },
    { id: "fb_003", text: "The API documentation is missing examples for the v2 endpoints." },
  ];
};

/**
 * @description Mock LLM call for data transformation.
 * Simulates sending a prompt to an LLM (e.g., GPT-4) and receiving a structured JSON response.
 * In production, this would use the `ai` SDK's `streamText` or `generateObject` functions.
 */
const transformWithLLM = async (rawText: string): Promise<string> => {
  // Simulate LLM processing time
  await new Promise((resolve) => setTimeout(resolve, 300));
  
  // Simulated LLM Output (JSON string)
  // Logic: Extracts intent, sentiment, and urgency.
  const mockAnalysis = {
    original_text: rawText,
    extracted_entities: {
      sentiment: rawText.includes("love") ? "positive" : rawText.includes("missing") ? "negative" : "neutral",
      urgency: rawText.includes("unresponsive") ? "high" : "medium",
      feature_tag: rawText.includes("login") ? "auth" : rawText.includes("dark mode") ? "ui" : "docs",
    },
    summary: `User reported issue regarding ${rawText.split(" ")[2]}.`,
  };
  
  return JSON.stringify(mockAnalysis);
};

export const feedbackRouter = createTRPCRouter({
  /**
   * @description The Core Pipeline Procedure.
   * 1. Fetches raw data (Data Fetching in SCs context).
   * 2. Orchestrates LLM transformation.
   * 3. Streams the structured result back to the client.
   */
  processFeedbackStream: publicProcedure
    .input(z.object({ batchId: z.string().optional() }))
    .mutation(async ({ input }) => {
      try {
        // Step 1: Data Fetching (Server-Side Context)
        // We fetch raw data before the stream starts to ensure the LLM has immediate context.
        const rawFeedback = await fetchRawFeedback();
        
        // Step 2: LLM Transformation & Streaming
        // We create a custom ReadableStream to simulate streaming the LLM response.
        // This allows the client to receive data chunks as they are generated (low latency).
        const stream = new ReadableStream({
          async start(controller) {
            for (const item of rawFeedback) {
              // Transform individual items using the LLM
              const structuredData = await transformWithLLM(item.text);
              
              // Encode the chunk and enqueue it to the stream
              const chunk = new TextEncoder().encode(
                `data: ${JSON.stringify({ id: item.id, analysis: structuredData })}\n\n`
              );
              controller.enqueue(chunk);
              
              // Simulate a small delay between chunks to visualize streaming
              await new Promise((resolve) => setTimeout(resolve, 200));
            }
            controller.close();
          },
        });

        // Return the stream response compatible with tRPC/Next.js
        return new StreamingTextResponse(stream);
      } catch (error) {
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: "Failed to process feedback pipeline.",
        });
      }
    }),
});
