/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script_part2.ts
// Description: Advanced Application Script
// ==========================================

// File: src/app/components/FeedbackTriageDashboard.tsx
// Location: Frontend (Next.js Client Component)
// Purpose: Consumes the tRPC stream and manages the real-time UI state.

"use client";

import { useState } from "react";
import { api } from "~/trpc/react"; // tRPC React Query wrapper

/**
 * @description The ReAct Loop Visualization (Conceptual)
 * While not explicitly coded as a LangGraph loop here, the UI mimics the cycle:
 * 1. Thought: User clicks "Analyze" (Trigger).
 * 2. Action: tRPC mutation is called, data is streamed.
 * 3. Observation: UI updates with parsed stream data.
 */
export function FeedbackTriageDashboard() {
  const [isProcessing, setIsProcessing] = useState(false);
  const [processedData, setProcessedData] = useState<any[]>([]);

  // Initialize the tRPC mutation hook
  const processFeedback = api.feedback.processFeedbackStream.useMutation();

  /**
   * @description Handles the pipeline execution.
   * Orchestrates the client-side interaction with the Edge/tRPC backend.
   */
  const handleAnalyze = async () => {
    setIsProcessing(true);
    setProcessedData([]); // Reset state

    try {
      // Execute the mutation. Note: In a real streaming scenario with tRPC,
      // we often use a subscription or a custom fetch wrapper. 
      // Here we simulate the stream consumption.
      const response = await processFeedback.mutateAsync({ batchId: "batch_123" });
      
      // Since the backend returns a StreamingTextResponse, we need to read the body
      if (response.body) {
        const reader = response.body.getReader();
        const decoder = new TextDecoder();

        while (true) {
          const { done, value } = await reader.read();
          if (done) break;

          // Decode the stream chunk
          const chunk = decoder.decode(value, { stream: true });
          
          // Parse the SSE (Server-Sent Events) formatted data
          // Format: "data: {json}\n\n"
          const lines = chunk.split("\n").filter((line) => line.startsWith("data:"));
          
          lines.forEach((line) => {
            try {
              const jsonStr = line.replace("data: ", "");
              const parsed = JSON.parse(jsonStr);
              setProcessedData((prev) => [...prev, parsed]);
            } catch (e) {
              console.error("Failed to parse stream chunk", e);
            }
          });
        }
      }
    } catch (error) {
      console.error("Pipeline failed:", error);
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="p-6 max-w-4xl mx-auto bg-white rounded-lg shadow-md">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold text-gray-800">AI Feedback Triage</h1>
        <button
          onClick={handleAnalyze}
          disabled={isProcessing}
          className={`px-4 py-2 rounded font-semibold transition-colors ${
            isProcessing
              ? "bg-gray-400 cursor-not-allowed"
              : "bg-blue-600 text-white hover:bg-blue-700"
          }`}
        >
          {isProcessing ? "Processing..." : "Analyze Raw Data"}
        </button>
      </div>

      <div className="space-y-4">
        {processedData.length === 0 && !isProcessing && (
          <div className="text-center text-gray-500 py-8">
            Click "Analyze Raw Data" to start the pipeline.
          </div>
        )}

        {isProcessing && (
          <div className="flex items-center justify-center py-4">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
            <span className="ml-3 text-gray-600">Fetching context & transforming data...</span>
          </div>
        )}

        {processedData.map((item) => (
          <div
            key={item.id}
            className="border border-gray-200 rounded p-4 bg-gray-50 hover:bg-gray-100 transition-colors"
          >
            <div className="flex justify-between mb-2">
              <span className="text-sm font-mono text-gray-500">ID: {item.id}</span>
              <span
                className={`text-xs px-2 py-1 rounded ${
                  item.analysis.extracted_entities.sentiment === "positive"
                    ? "bg-green-100 text-green-800"
                    : item.analysis.extracted_entities.sentiment === "negative"
                    ? "bg-red-100 text-red-800"
                    : "bg-gray-100 text-gray-800"
                }`}
              >
                {item.analysis.extracted_entities.sentiment.toUpperCase()}
              </span>
            </div>
            
            <p className="text-gray-700 mb-2 italic">
              "{item.analysis.original_text}"
            </p>

            <div className="grid grid-cols-2 gap-2 text-sm">
              <div className="bg-white p-2 rounded border">
                <span className="font-semibold block text-gray-500">Urgency</span>
                {item.analysis.extracted_entities.urgency}
              </div>
              <div className="bg-white p-2 rounded border">
                <span className="font-semibold block text-gray-500">Feature</span>
                {item.analysis.extracted_entities.feature_tag}
              </div>
            </div>
            
            <div className="mt-2 text-xs text-gray-500">
              Summary: {item.analysis.summary}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
