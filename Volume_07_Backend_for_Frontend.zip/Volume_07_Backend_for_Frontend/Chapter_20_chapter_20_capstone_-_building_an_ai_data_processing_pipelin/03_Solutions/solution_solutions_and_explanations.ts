/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// app/processor/page.tsx (Server Component)
import { Suspense } from 'react';
import AiTransformer from './AiTransformer';
import { fetchRawLogData } from '@/lib/data-service';

// 1. Server Component fetches data synchronously
export default async function DataProcessorPage() {
  // This await runs on the server and blocks rendering until resolved
  const rawLogs = await fetchRawLogData();

  return (
    <div className="p-8">
      <h1>AI Log Processor</h1>
      {/* 
        2. Suspense Boundary wraps the Client Component.
        The fallback displays ONLY while the Server Component 
        is waiting for 'fetchRawLogData'.
      */}
      <Suspense fallback={<SkeletonLoader />}>
        {/* 
          3. Raw data is passed as a prop. 
          By the time AiTransformer hydrates, 'rawLogs' is already available.
        */}
        <AiTransformer initialData={rawLogs} />
      </Suspense>
    </div>
  );
}

function SkeletonLoader() {
  return <div className="animate-pulse bg-gray-200 h-32 w-full rounded" />;
}

// app/processor/AiTransformer.tsx (Client Component)
'use client';

import { useEffect, useState } from 'react';
import { trpc } from '@/lib/trpc/client';

interface AiTransformerProps {
  initialData: string[];
}

export default function AiTransformer({ initialData }: AiTransformerProps) {
  const [streamedText, setStreamedText] = useState('');
  const [status, setStatus] = useState<'idle' | 'connecting' | 'streaming' | 'complete'>('idle');

  useEffect(() => {
    // 4. Client-side logic initiates after hydration
    const startStream = async () => {
      setStatus('connecting');
      
      // Example tRPC call (implementation depends on your tRPC setup)
      // This assumes a procedure that returns an AsyncIterable
      const stream = await trpc.ai.transformData.query({ data: initialData });

      setStatus('streaming');
      
      for await (const chunk of stream) {
        setStreamedText((prev) => prev + chunk);
      }
      
      setStatus('complete');
    };

    startStream();
  }, [initialData]);

  return (
    <div className="mt-4 border p-4 rounded">
      <div className="text-sm text-gray-500 mb-2">Status: {status}</div>
      <div className="whitespace-pre-wrap">
        {streamedText}
      </div>
    </div>
  );
}
