/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

// app/api/process/route.ts (Edge Function)
import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';

// 1. Schema Validation
const inputSchema = z.object({
  logs: z.array(z.string()).min(1),
  instruction: z.string().optional(),
});

export const runtime = 'edge';

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    
    // Validate input immediately
    const result = inputSchema.safeParse(body);
    if (!result.success) {
      return NextResponse.json(
        { error: 'Invalid input', details: result.error.issues },
        { status: 400 }
      );
    }

    const { logs, instruction } = result.data;
    const prompt = `Transform these logs into JSON based on: ${instruction || 'standard format'}. Logs: ${JSON.stringify(logs)}`;

    // 2. LLM Integration with Retry Logic
    const maxRetries = 3;
    let attempt = 0;
    let response: Response;

    while (attempt < maxRetries) {
      try {
        // Simulated LLM call
        response = await fetch('https://api.openai.com/v1/chat/completions', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${process.env.OPENAI_API_KEY}` },
          body: JSON.stringify({
            model: 'gpt-3.5-turbo',
            messages: [{ role: 'user', content: prompt }],
            stream: true, // Assuming streaming response
          }),
          // Timeout handling
          signal: AbortSignal.timeout(5000), 
        });

        if (!response.ok) {
          if (response.status >= 500) throw new Error('Server Error');
          // Don't retry 4xx errors
          return NextResponse.json({ error: 'LLM Provider Error' }, { status: response.status });
        }

        // If successful, break the loop
        break; 
      } catch (error) {
        attempt++;
        if (attempt >= maxRetries) {
          return NextResponse.json(
            { error: 'LLM Service Unavailable', message: (error as Error).message },
            { status: 503 }
          );
        }
        // Exponential Backoff: 1s, 2s, 4s
        await new Promise(resolve => setTimeout(resolve, Math.pow(2, attempt) * 1000));
      }
    }

    // 3. Stream the response back to the client
    // (Assuming we are proxying the stream)
    return new Response(response!.body, {
      headers: { 'Content-Type': 'text/event-stream' }
    });

  } catch (error) {
    return NextResponse.json({ error: 'Internal Server Error' }, { status: 500 });
  }
}
