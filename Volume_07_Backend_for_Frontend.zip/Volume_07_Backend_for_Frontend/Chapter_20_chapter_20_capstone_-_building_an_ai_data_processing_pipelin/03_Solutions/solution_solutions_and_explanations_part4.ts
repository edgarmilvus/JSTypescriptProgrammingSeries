/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

// server/routers/aiRouter.ts
import { publicProcedure, router } from '../trpc';
import { observable } from '@trpc/server/observable';

export const aiRouter = router({
  transformData: publicProcedure
    .input(z.object({ data: z.array(z.string()) }))
    .subscription(async function* (opts) {
      // Simulate an AsyncGenerator yielding tokens
      const mockStream = async function* () {
        for (let i = 0; i < 10; i++) {
          // Simulate processing time
          await new Promise(resolve => setTimeout(resolve, 500));
          yield `Token ${i} `;
        }
      };

      // 4. Server-side generator
      for await (const chunk of mockStream()) {
        // This yield sends data immediately to the client
        yield chunk;
      }
    }),
});

// client/components/StreamReceiver.tsx
'use client';
import { trpc } from '@/lib/trpc/client';
import { useState } from 'react';

export default function StreamReceiver() {
  const [chunks, setChunks] = useState<string[]>([]);
  const [isPaused, setIsPaused] = useState(false);

  // Subscription with enabled flag to control backpressure
  const subscription = trpc.ai.transformData.useSubscription(undefined, {
    enabled: !isPaused, // If paused, client stops requesting/polling
    onData: (data) => {
      setChunks((prev) => [...prev, data]);
    },
  });

  return (
    <div>
      <button 
        onClick={() => setIsPaused((p) => !p)}
        className="bg-blue-500 text-white p-2 rounded"
      >
        {isPaused ? 'Resume' : 'Pause'}
      </button>
      
      <div className="mt-4">
        {chunks.map((c, i) => (
          <span key={i}>{c}</span>
        ))}
      </div>
    </div>
  );
}
