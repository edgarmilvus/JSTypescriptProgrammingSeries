/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

// components/ProgressiveJsonViewer.tsx
'use client';

import { useEffect, useState } from 'react';

interface Props {
  stream: AsyncIterable<string>;
}

export default function ProgressiveJsonViewer({ stream }: Props) {
  const [buffer, setBuffer] = useState('');
  const [parsedData, setParsedData] = useState<any>(null);
  const [error, setError] = useState<string | null>(null);
  const [mode, setMode] = useState<'parsing' | 'raw' | 'rendered'>('parsing');

  useEffect(() => {
    const processStream = async () => {
      for await (const chunk of stream) {
        setBuffer((prev) => {
          const newBuffer = prev + chunk;
          
          // Attempt progressive parsing
          try {
            // Wrap in brackets to handle array stream if needed, 
            // or assume the stream is a single JSON object building up.
            // Here we assume the stream is a complete JSON object building up.
            const parsed = JSON.parse(newBuffer);
            setParsedData(parsed);
            setMode('rendered');
            return newBuffer; // Keep buffer for context
          } catch (e) {
            // If parsing fails, it's likely incomplete JSON.
            // We only switch to raw mode if we detect a syntax error 
            // that isn't just "unexpected end of input".
            if (e instanceof SyntaxError && !newBuffer.endsWith('}')) {
               // Still building, keep waiting
               return newBuffer;
            } else if (e instanceof SyntaxError && newBuffer.endsWith('}')) {
               // End of stream but still invalid? Switch to raw.
               setError('JSON parsing failed. Displaying raw text.');
               setMode('raw');
            }
            return newBuffer;
          }
        });
      }
    };

    processStream();
  }, [stream]);

  if (mode === 'raw') {
    return (
      <div className="bg-red-50 border border-red-200 p-4">
        <div className="text-red-700 font-bold mb-2">Warning: {error}</div>
        <pre className="text-sm whitespace-pre-wrap">{buffer}</pre>
      </div>
    );
  }

  if (mode === 'rendered' && parsedData) {
    return (
      <div className="bg-green-50 border border-green-200 p-4">
        <h3 className="font-bold text-green-800">Structured Data</h3>
        <pre className="text-sm">{JSON.stringify(parsedData, null, 2)}</pre>
      </div>
    );
  }

  return <div>Receiving data... ({buffer.length} chars)</div>;
}
