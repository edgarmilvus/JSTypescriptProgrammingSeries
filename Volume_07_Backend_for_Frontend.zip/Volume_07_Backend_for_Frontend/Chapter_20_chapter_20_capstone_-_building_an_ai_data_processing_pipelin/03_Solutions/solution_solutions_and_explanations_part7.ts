/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part7.ts
// Description: Solutions and Explanations
// ==========================================

digraph Architecture {
    rankdir=LR;
    node [shape=box, style=filled, color=lightblue];

    User [shape=circle, color=lightgrey];

    subgraph cluster_edge {
        label = "Edge Network (Global)";
        style = dashed;
        color = blue;

        EdgeRouter [label="tRPC Router (Edge Runtime)"];
        LLMWrapper [label="LLM Orchestrator (Edge Function)"];
        Cache [label="KV Cache (e.g., Vercel Blob)"];
    }

    subgraph cluster_region {
        label = "Region: US-East";
        style = dashed;
        color = grey;
        DB [label="Database (Connection Pool)"];
    }

    User -> EdgeRouter [label="1. Request"];
    EdgeRouter -> LLMWrapper [label="2. Validate & Call"];
    LLMWrapper -> DB [label="3. (Optional) Read Config"];
    LLMWrapper -> User [label="4. Stream Response"];
    
    // Edge connections
    EdgeRouter -> Cache [label="Check Cache", style=dotted];
}
