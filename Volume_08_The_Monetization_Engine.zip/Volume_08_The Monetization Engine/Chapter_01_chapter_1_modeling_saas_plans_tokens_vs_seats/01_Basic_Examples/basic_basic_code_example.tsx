/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.tsx
// Description: Basic Code Example
// ==========================================

// File: app/actions.ts
'use server';

import { generateText } from 'ai';
import { openai } from '@ai-sdk/openai';
import { createStreamableValue } from 'ai/rsc';
import React from 'react';

/**
 * @description A simple React Button component that will be streamed to the client.
 * Note: In a real app, this might be a complex interactive chart or form.
 */
const StreamableButton = ({ text }: { text: string }) => {
  return (
    <button 
      onClick={() => alert(`Clicked: ${text}`)}
      style={{ 
        padding: '10px 20px', 
        marginTop: '10px', 
        backgroundColor: '#0070f3', 
        color: 'white', 
        border: 'none', 
        borderRadius: '5px', 
        cursor: 'pointer' 
      }}
    >
      {text}
    </button>
  );
};

/**
 * @description Server Action to generate text and inject a UI component.
 * This function streams both raw text tokens and a serializable component definition.
 */
export async function generateInteractiveResponse(prompt: string) {
  // 1. Initialize a streamable value. This acts as the transport mechanism.
  const stream = createStreamableValue<string>();

  (async () => {
    // 2. Generate text from the LLM.
    // We use generateText for simplicity, but in a real streaming UI scenario, 
    // we would likely use streamText to process tokens as they arrive.
    const { text } = await generateText({
      model: openai('gpt-3.5-turbo'),
      prompt: `Generate a response to: "${prompt}". 
               If the user asks for an action, include the text "[ACTION]" in your response.`,
    });

    // 3. Simulate streaming logic.
    // In a real streamText implementation, we would iterate over the token stream.
    // Here, we simulate the flow by splitting the text and injecting the component.
    const parts = text.split('[ACTION]');

    // Stream the first part of the text
    if (parts[0]) {
      stream.update(parts[0]);
    }

    // 4. The Magic: Inject a React Component into the stream.
    // We serialize the component definition. The client will hydrate this.
    // We pass the component type and its props.
    if (parts.length > 1) {
      stream.update(
        // @ts-ignore - We are passing a component definition to the stream
        <StreamableButton text="Confirm Action" />
      );
      
      // Stream the remaining text if any
      if (parts[1]) {
        stream.update(parts[1]);
      }
    }

    // 5. Close the stream
    stream.done();
  })();

  return stream.value;
}
