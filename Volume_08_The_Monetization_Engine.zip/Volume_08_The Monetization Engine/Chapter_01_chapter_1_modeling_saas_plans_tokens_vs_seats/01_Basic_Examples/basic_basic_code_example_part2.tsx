/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.tsx
// Description: Basic Code Example
// ==========================================

// File: app/page.tsx
'use client';

import { useState } from 'react';
import { readStreamableValue } from 'ai/rcs';
import { generateInteractiveResponse } from './actions';

export default function Page() {
  const [input, setInput] = useState('');
  const [components, setComponents] = useState<React.ReactNode[]>([]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // 1. Call the Server Action to get the stream
    const stream = await generateInteractiveResponse(input);

    // 2. Read the stream
    for await (const chunk of readStreamableValue(stream)) {
      // 3. Check if the chunk is a React Element (Component) or a String
      if (React.isValidElement(chunk)) {
        // If it's a component, add it to our state to render it
        setComponents((prev) => [...prev, chunk]);
      } else if (typeof chunk === 'string') {
        // If it's text, we typically append it to a text state.
        // For simplicity here, we just log it or append to a display string.
        console.log('Text Token:', chunk);
      }
    }
  };

  return (
    <div style={{ padding: '20px', fontFamily: 'sans-serif' }}>
      <h1>Streamable UI Demo</h1>
      <form onSubmit={handleSubmit}>
        <input 
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Ask for an action..."
          style={{ padding: '10px', width: '300px' }}
        />
        <button type="submit" style={{ marginLeft: '10px', padding: '10px' }}>
          Send
        </button>
      </form>

      <div style={{ marginTop: '20px', border: '1px solid #eee', padding: '10px' }}>
        <strong>Streamed Components:</strong>
        {/* 4. Render the components that were streamed from the server */}
        <div style={{ marginTop: '10px' }}>
          {components.map((comp, index) => (
            <div key={index}>{comp}</div>
          ))}
        </div>
      </div>
    </div>
  );
}
