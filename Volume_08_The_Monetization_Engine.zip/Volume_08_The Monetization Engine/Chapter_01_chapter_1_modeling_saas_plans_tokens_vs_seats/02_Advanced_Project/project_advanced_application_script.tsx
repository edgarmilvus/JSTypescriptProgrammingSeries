/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.tsx
// Description: Advanced Application Script
// ==========================================

// app/actions/plan-switcher.ts
'use server';

import { createStreamableUI, createStreamableValue } from 'ai/rsc';
import { OpenAI } from 'openai';
import { ReactNode } from 'react';
import { z } from 'zod';

// --- 1. SCHEMA DEFINITION & TYPES ---

// Schema for validating the user's current plan context.
const PlanContextSchema = z.object({
  currentPlan: z.enum(['free', 'pro_seat', 'enterprise_seat']),
  monthlyTokenUsage: z.number().min(0),
  seatLimit: z.number().default(1),
});

type PlanContext = z.infer<typeof PlanContextSchema>;

// --- 2. COMPONENT DEFINITIONS ---

/**
 * Renders a visual usage meter showing consumption vs limit.
 * Used for Token-based plans.
 */
const UsageMeter = ({ used, limit }: { used: number; limit: number }) => {
  const percentage = Math.min((used / limit) * 100, 100);
  return (
    <div className="border p-4 rounded-lg shadow-sm bg-gray-50">
      <h4 className="font-bold text-gray-700">Token Consumption</h4>
      <div className="w-full bg-gray-200 rounded-full h-2.5 mt-2">
        <div
          className="bg-blue-600 h-2.5 rounded-full transition-all duration-500"
          style={{ width: `${percentage}%` }}
        ></div>
      </div>
      <p className="text-sm text-gray-500 mt-2">
        {used.toLocaleString()} / {limit.toLocaleString()} tokens used
      </p>
    </div>
  );
};

/**
 * Renders a strategic upgrade card based on cost analysis.
 * Used to switch between Seat and Token models.
 */
const PlanSwitchCard = ({
  currentCost,
  projectedCost,
  recommendedPlan,
}: {
  currentCost: number;
  projectedCost: number;
  recommendedPlan: 'seat' | 'token';
}) => {
  const isTokenCheaper = recommendedPlan === 'token';
  return (
    <div className="border-l-4 border-indigo-500 bg-indigo-50 p-4 mt-4 rounded-r-lg">
      <h4 className="font-bold text-indigo-900">Optimization Suggestion</h4>
      <p className="text-sm text-indigo-700 mt-1">
        Your current trajectory suggests a cost of <strong>${projectedCost}</strong>.
        {isTokenCheaper ? (
          <span>
            {' '}
            Switching to a <strong>Pay-as-you-go (Token)</strong> model could save you an
            estimated <strong>${currentCost - projectedCost}</strong> this month.
          </span>
        ) : (
          <span>
            {' '}
            Locking in a <strong>Seat License</strong> would cap your costs at{' '}
            <strong>${currentCost}</strong> regardless of usage spikes.
          </span>
        )}
      </p>
      <button className="mt-3 px-4 py-2 bg-indigo-600 text-white text-sm rounded hover:bg-indigo-700">
        Switch to {recommendedPlan === 'token' ? 'Pay-as-you-go' : 'Pro Seat'}
      </button>
    </div>
  );
};

// --- 3. THE SERVER ACTION (THE MONETIZATION ENGINE) ---

/**
 * Analyzes user billing context and streams a dynamic UI response.
 * This simulates the "Monetization Engine" logic deciding between Seat vs Token billing.
 */
export async function analyzeAndStreamPlan(context: PlanContext) {
  // Validate input using Zod
  const parsed = PlanContextSchema.safeParse(context);
  if (!parsed.success) {
    return { error: 'Invalid plan context provided.' };
  }
  const { currentPlan, monthlyTokenUsage, seatLimit } = parsed.data;

  // Initialize the streamable UI container
  const uiStream = createStreamableUI(<div />);
  
  // Initialize text stream for the AI agent's conversational response
  const textStream = createStreamableValue('');

  // --- LOGIC BLOCK 1: STRATEGIC COST ANALYSIS ---
  // Determine if the user is over-utilizing their current plan.
  // Logic: If on a Seat plan and usage > (Seat Limit * 10,000 tokens), suggest Token model.
  
  let recommendation: 'stay' | 'switch_token' | 'switch_seat' = 'stay';
  let estimatedMonthlyCost = 0;
  let projectedSavings = 0;

  if (currentPlan === 'pro_seat') {
    const tokenPerSeatAllowance = seatLimit * 10000; // e.g., 10k tokens per seat
    if (monthlyTokenUsage > tokenPerSeatAllowance) {
      recommendation = 'switch_token';
      // Simple cost math: $0.002 per token vs $20 per seat
      const tokenCost = monthlyTokenUsage * 0.002;
      const seatCost = seatLimit * 20;
      estimatedMonthlyCost = tokenCost;
      projectedSavings = seatCost - tokenCost;
    }
  } else if (currentPlan === 'free') {
    // Free tier logic: if usage is high, push to Seat plan for stability
    if (monthlyTokenUsage > 5000) {
      recommendation = 'switch_seat';
      estimatedMonthlyCost = 20; // Flat Pro Seat rate
    }
  }

  // --- LOGIC BLOCK 2: STREAMING THE AI RESPONSE ---
  // Simulate an LLM generating a natural language explanation.
  // In a real app, this would be an OpenAI stream call.
  
  (async () => {
    const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
    
    // Constructing a prompt based on the billing logic calculated above
    const prompt = `Explain billing status. Plan: ${currentPlan}. Usage: ${monthlyTokenUsage}. Recommendation: ${recommendation}. Keep it concise.`;
    
    // Simulating a stream response (mocking for this script)
    const mockTokens = [
      "I've analyzed your current usage patterns. ",
      `You are currently on the ${currentPlan} plan. `,
      recommendation === 'switch_token' 
        ? "Your token usage is exceeding the seat allowance. " 
        : recommendation === 'switch_seat'
        ? "You are approaching free tier limits. "
        : "Your usage is within normal bounds. ",
      "Let me show you a visual breakdown."
    ];

    for (const token of mockTokens) {
      textStream.update(token);
      await new Promise(r => setTimeout(r, 100)); // Simulate latency
    }
    textStream.done();
  })();

  // --- LOGIC BLOCK 3: STREAMING DYNAMIC COMPONENTS ---
  // Based on the strategic calculation, we inject specific React components into the stream.
  
  // 1. Always show usage meter for context
  uiStream.update(
    <div className="flex flex-col gap-2">
      <UsageMeter used={monthlyTokenUsage} limit={seatLimit * 10000} />
    </div>
  );

  // 2. Conditionally render the Plan Switch Card based on the Monetization Engine's logic
  if (recommendation === 'switch_token') {
    await new Promise(r => setTimeout(r, 300)); // Artificial delay for UX flow
    uiStream.append(
      <PlanSwitchCard
        currentCost={seatLimit * 20}
        projectedCost={estimatedMonthlyCost}
        recommendedPlan="token"
      />
    );
  } else if (recommendation === 'switch_seat') {
    await new Promise(r => setTimeout(r, 300));
    uiStream.append(
      <PlanSwitchCard
        currentCost={0} // Free tier cost
        projectedCost={estimatedMonthlyCost}
        recommendedPlan="seat"
      />
    );
  }

  // Finalize the UI stream
  uiStream.done();

  return {
    // Return both the text agent response and the dynamic UI components
    agentResponse: textStream.value,
    uiComponent: uiStream.value,
  };
}
