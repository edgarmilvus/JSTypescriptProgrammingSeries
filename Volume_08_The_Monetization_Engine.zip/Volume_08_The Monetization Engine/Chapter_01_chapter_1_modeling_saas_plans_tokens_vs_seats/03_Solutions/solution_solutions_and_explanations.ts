/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// Define the types as specified in the problem description
type PlanType = 'starter' | 'pro';

interface UserProfile {
  id: string;
  planType: PlanType;
  basePrice: number; // e.g., 29.00 for starter, 0 for pro
  tokenAllowance: number; // e.g., 50000 for starter, 0 for pro
  tokenRate?: number; // e.g., 0.00005 (for $0.05/1000) for pro
  overageRate?: number; // e.g., 0.0001 for starter overage
}

interface UsageRecord {
  sessionId: string;
  tokenCount: number;
  timestamp: Date;
}

interface Invoice {
  subtotal: number;
  overageCost?: number;
  total: number;
}

/**
 * Calculates the invoice based on user profile and usage records.
 * 
 * @param userProfile - The user's subscription details.
 * @param usageRecords - An array of usage records for the billing period.
 * @returns An Invoice object detailing the costs.
 */
export function calculateInvoice(
  userProfile: UserProfile,
  usageRecords: UsageRecord[]
): Invoice {
  // 1. Calculate total tokens used across all sessions
  const totalTokens = usageRecords.reduce((sum, record) => sum + record.tokenCount, 0);

  // 2. Handle Logic based on Plan Type
  if (userProfile.planType === 'starter') {
    // Starter Plan: Base price + Overage if applicable
    const basePrice = userProfile.basePrice;
    let overageCost = 0;
    
    // Check for overage (assuming allowance is strictly monthly)
    if (totalTokens > userProfile.tokenAllowance) {
      const excessTokens = totalTokens - userProfile.tokenAllowance;
      // Use the provided overage rate, default to a standard rate if missing (e.g., $0.10/1000 tokens -> 0.0001 per token)
      const rate = userProfile.overageRate ?? 0.0001; 
      overageCost = excessTokens * rate;
    }

    return {
      subtotal: basePrice,
      overageCost: overageCost,
      total: basePrice + overageCost,
    };

  } else if (userProfile.planType === 'pro') {
    // Pro Plan: Pure consumption-based billing
    // Ensure tokenRate is provided, throw error if missing for safety
    if (!userProfile.tokenRate) {
      throw new Error("Pro plan requires a tokenRate to calculate costs.");
    }

    const usageCost = totalTokens * userProfile.tokenRate;
    
    return {
      subtotal: usageCost,
      overageCost: 0, // Explicitly 0 for clarity, though optional
      total: usageCost,
    };
  }

  // Fallback for unknown plan types
  throw new Error(`Unknown plan type: ${userProfile.planType}`);
}
