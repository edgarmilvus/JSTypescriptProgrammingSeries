/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState, useEffect } from 'react';

interface TokenBudgetDisplayProps {
  initialBudget: number;
  consumedTokens: number; // In a real app, this might come from a Context or Redux store
}

// Simple styles for the progress bar
const styles = {
  container: { padding: '10px', fontFamily: 'sans-serif' },
  barContainer: {
    height: '20px',
    width: '100%',
    backgroundColor: '#e0e0e0',
    borderRadius: '10px',
    overflow: 'hidden',
    marginTop: '5px',
  },
  barFill: {
    height: '100%',
    transition: 'width 0.3s ease, background-color 0.3s ease',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    fontSize: '12px',
    color: 'white',
  },
  text: { marginTop: '5px', fontWeight: 'bold' },
};

export const TokenBudgetDisplay: React.FC<TokenBudgetDisplayProps> = ({
  initialBudget,
  consumedTokens,
}) => {
  // State for the visual display (allows for smooth animation/streaming simulation)
  const [displayedConsumed, setDisplayedConsumed] = useState(0);

  // Simulate streaming updates: When the prop changes, update state gradually
  useEffect(() => {
    // In a real streaming scenario, this would handle websocket messages
    // For this exercise, we update immediately to reflect the prop change
    setDisplayedConsumed(consumedTokens);
  }, [consumedTokens]);

  // Calculations
  const remainingTokens = Math.max(0, initialBudget - displayedConsumed);
  const percentageUsed = (displayedConsumed / initialBudget) * 100;

  // Determine color based on usage percentage
  let barColor = '#4caf50'; // Green
  if (percentageUsed >= 90) {
    barColor = '#f44336'; // Red
  } else if (percentageUsed >= 75) {
    barColor = '#ff9800'; // Yellow
  }

  return (
    <div style={styles.container}>
      <div style={styles.text}>
        {remainingTokens.toLocaleString()} tokens remaining
      </div>
      <div style={styles.barContainer}>
        <div
          style={{
            ...styles.barFill,
            width: `${Math.min(percentageUsed, 100)}%`,
            backgroundColor: barColor,
          }}
        />
      </div>
      <div style={{ fontSize: '12px', color: '#666', marginTop: '2px' }}>
        {percentageUsed.toFixed(1)}% Used
      </div>
    </div>
  );
};
