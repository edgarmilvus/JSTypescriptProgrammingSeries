/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

/**
 * Chunks a text document into segments that fit within a max token limit.
 * Uses the heuristic: 1 token ≈ 4 characters.
 * 
 * @param text - The raw text to chunk.
 * @param maxTokensPerChunk - The maximum number of tokens allowed per chunk.
 * @returns An array of text chunks.
 */
export function chunkDocument(text: string, maxTokensPerChunk: number): string[] {
  if (!text || maxTokensPerChunk <= 0) {
    return [];
  }

  // Heuristic: 1 token ≈ 4 characters. 
  // We add a small buffer (e.g., 0.8) to be safe, or stick strictly to 4.
  // Let's stick to 4 chars per token as requested.
  const maxCharsPerChunk = maxTokensPerChunk * 4;

  const chunks: string[] = [];
  let currentChunk = "";

  // Split by whitespace to get words, but we need to reconstruct sentences.
  // A robust way is to look for sentence endings, but we must handle long sentences.
  // We will iterate through the text, building a buffer, and splitting at sentence boundaries
  // if adding the next sentence exceeds the limit.

  // Regex to split by sentence boundaries (. ! ?) followed by whitespace or end of string
  // This keeps the delimiter with the sentence.
  const sentenceDelimiter = /(?<=[.!?])\s+/;
  const sentences = text.split(sentenceDelimiter);

  for (const sentence of sentences) {
    // Check if adding this sentence (plus a space) exceeds the limit
    if ((currentChunk + " " + sentence).length > maxCharsPerChunk) {
      
      // If current chunk is not empty, push it to results
      if (currentChunk.trim().length > 0) {
        chunks.push(currentChunk.trim());
      }

      // Handle edge case: A single sentence is longer than the max chunk size.
      // We must force-split this sentence.
      if (sentence.length > maxCharsPerChunk) {
        const forcedChunks = forceSplit(sentence, maxCharsPerChunk);
        chunks.push(...forcedChunks);
        currentChunk = ""; // Reset as forced chunks are already added
      } else {
        // Start the new chunk with the current sentence
        currentChunk = sentence;
      }
    } else {
      // Append to current chunk
      currentChunk = currentChunk ? currentChunk + " " + sentence : sentence;
    }
  }

  // Push the remaining chunk if it exists
  if (currentChunk.trim().length > 0) {
    chunks.push(currentChunk.trim());
  }

  return chunks;
}

/**
 * Helper function to force split a very long sentence into fixed-size chunks.
 */
function forceSplit(text: string, limit: number): string[] {
  const chunks = [];
  for (let i = 0; i < text.length; i += limit) {
    chunks.push(text.substring(i, i + limit));
  }
  return chunks;
}
