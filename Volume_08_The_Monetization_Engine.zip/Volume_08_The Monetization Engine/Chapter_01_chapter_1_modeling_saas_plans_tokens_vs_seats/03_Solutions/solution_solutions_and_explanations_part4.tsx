/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState, useEffect } from 'react';

// 1. Define the types for the stream elements using a Discriminated Union
type TextChunk = { type: 'text'; content: string };
type ComponentChunk = { type: 'component'; component: React.ReactNode };

type StreamElement = TextChunk | ComponentChunk;

// 2. Placeholder Component for the Interactive UI
const TokenCalculator = () => (
  <div style={{ border: '1px solid #ccc', padding: '10px', margin: '10px 0', backgroundColor: '#f9f9f9' }}>
    <strong>[Interactive Calculator Component]</strong>
    <div>Input: <input type="number" placeholder="Tokens" style={{ width: '60px' }} /> </div>
    <div>Cost: $0.00</div>
  </div>
);

export const AISupportStream: React.FC = () => {
  const [streamedElements, setStreamedElements] = useState<StreamElement[]>([]);

  useEffect(() => {
    // Sequence of events to simulate the stream
    const streamSequence: StreamElement[] = [
      { type: 'text', content: "I see you're asking about your token usage. Let me calculate that for you.\n" },
      { type: 'component', component: <TokenCalculator key="calc-1" /> },
      { type: 'text', content: "\nBased on your current plan, you have 15,000 tokens remaining." }
    ];

    let currentIndex = 0;

    // Simulation loop
    const intervalId = setInterval(() => {
      if (currentIndex < streamSequence.length) {
        // Add the next element to the state
        setStreamedElements((prev) => [...prev, streamSequence[currentIndex]]);
        currentIndex++;
      } else {
        clearInterval(intervalId);
      }
    }, 800); // Delay to simulate network latency

    // Cleanup interval on unmount
    return () => clearInterval(intervalId);
  }, []);

  return (
    <div style={{ padding: '20px', maxWidth: '600px', margin: '0 auto', fontFamily: 'system-ui' }}>
      <h3>AI Support Agent</h3>
      <div style={{ 
        border: '1px solid #ddd', 
        borderRadius: '8px', 
        padding: '15px', 
        minHeight: '100px',
        backgroundColor: '#fff'
      }}>
        {streamedElements.map((el, index) => {
          // 3. Render logic based on the discriminated union
          if (el.type === 'text') {
            return <span key={index} style={{ whiteSpace: 'pre-wrap' }}>{el.content}</span>;
          }
          if (el.type === 'component') {
            return <div key={index}>{el.component}</div>;
          }
          return null;
        })}
        
        {/* Visual indicator that stream is active (if not finished) */}
        {streamedElements.length < 3 && (
          <span style={{ color: '#999' }}>...</span>
        )}
      </div>
    </div>
  );
};
