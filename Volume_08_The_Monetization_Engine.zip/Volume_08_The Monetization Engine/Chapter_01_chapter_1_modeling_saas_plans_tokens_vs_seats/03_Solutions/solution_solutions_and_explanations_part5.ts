/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

digraph MonetizationFlow {
    rankdir=TB;
    node [shape=box, style="rounded,filled", color="#4A90E2", fillcolor="#E6F3FF"];
    edge [color="#555555"];

    // Define Nodes
    "User Interface (React)" [fillcolor="#D1E8FF"];
    "Next.js Backend (Server Action)" [fillcolor="#FFF4E6"];
    "Billing Engine (DB/API)" [fillcolor="#E6FCE6"];
    "AI Model Provider (e.g., OpenAI)" [fillcolor="#FCE6E6"];

    // Define Edges (Flow)
    "User Interface (React)" -> "Next.js Backend (Server Action)" [label="1. Chat Message / Request", fontcolor="#555555"];
    
    "Next.js Backend (Server Action)" -> "Billing Engine (DB/API)" [label="2. Check Token Balance", fontcolor="#555555"];
    
    "Billing Engine (DB/API)" -> "Next.js Backend (Server Action)" [label="3. Balance OK / Reserved", fontcolor="#555555"];
    
    "Next.js Backend (Server Action)" -> "AI Model Provider (e.g., OpenAI)" [label="4. Request Stream", fontcolor="#555555"];
    
    "AI Model Provider (e.g., OpenAI)" -> "Next.js Backend (Server Action)" [label="5. Stream Tokens", fontcolor="#555555", style="dashed"];
    
    "Next.js Backend (Server Action)" -> "User Interface (React)" [label="6. Stream UI/Text", fontcolor="#555555", style="dashed"];
    
    "Next.js Backend (Server Action)" -> "Billing Engine (DB/API)" [label="7. Finalize Usage / Update DB", fontcolor="#555555"];

    // Ensure top-to-bottom ranking
    { rank = same; "User Interface (React)"; }
    { rank = same; "Next.js Backend (Server Action)"; }
    { rank = same; "Billing Engine (DB/API)"; "AI Model Provider (e.g., OpenAI)"; }
}
