/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

// ==========================================
// 1. TYPE DEFINITIONS & CONFIGURATION
// ==========================================

/**
 * Represents the two distinct integration strategies available in Stripe.
 * - 'checkout': Redirects to a Stripe-hosted page.
 * - 'elements': Embeds payment fields directly in your app.
 */
type IntegrationMode = 'checkout' | 'elements';

/**
 * Configuration object for the payment flow.
 * In a real app, these would be fetched from your backend API.
 */
interface PaymentConfig {
  mode: IntegrationMode;
  amount: number; // Amount in cents
  currency: string;
  successUrl: string;
  cancelUrl: string;
}

// Mock Data: Simulating a backend response
const mockPaymentConfig: PaymentConfig = {
  mode: 'checkout', // Change this to 'elements' to switch modes
  amount: 2000, // $20.00
  currency: 'usd',
  successUrl: 'https://my-saas-app.com/success',
  cancelUrl: 'https://my-saas-app.com/cancel',
};

// ==========================================
// 2. BACKEND LOGIC SIMULATION
// ==========================================

/**
 * Simulates the server-side creation of a Stripe resource.
 * 
 * @param config - The payment configuration
 * @returns A promise resolving to the resource ID (Session ID or Intent ID)
 */
async function createStripeResource(config: PaymentConfig): Promise<string> {
  console.log(`[Server] Creating resource for mode: ${config.mode}...`);
  
  // In a real app, you would use the Stripe Node.js library here:
  // const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY);

  if (config.mode === 'checkout') {
    // LOGIC BLOCK A: Checkout Session Creation
    // We tell Stripe we want a hosted page.
    // const session = await stripe.checkout.sessions.create({ ... });
    // return session.id;
    
    // Mock ID for demonstration
    return 'cs_test_a1B2C3D4E5F6...'; 
  } else {
    // LOGIC BLOCK B: PaymentIntent Creation
    // We create an intent to capture funds later on the client.
    // const intent = await stripe.paymentIntents.create({
    //   amount: config.amount,
    //   currency: config.currency,
    // });
    // return intent.client_secret; // Crucial for Elements
    
    // Mock Client Secret for demonstration
    return 'pi_test_XyZwVuTsRq..._secret_abc123...';
  }
}

// ==========================================
// 3. FRONTEND LOGIC (REACT COMPONENT)
// ==========================================

/**
 * A React component that renders the payment UI based on the selected mode.
 * This demonstrates the "Branching Logic" required in the frontend.
 */
const PaymentPage: React.FC = () => {
  const { mode, amount, currency, successUrl, cancelUrl } = mockPaymentConfig;

  // --- LOGIC FLOW CONTROL ---
  
  if (mode === 'checkout') {
    // -------------------------------------------------
    // PATH 1: CHECKOUT FLOW (The "Redirect" Pattern)
    // -------------------------------------------------
    
    // 1. The backend generates a Session ID.
    const sessionId = createStripeResource(mockPaymentConfig); 
    
    // 2. The frontend constructs the Stripe Checkout URL.
    // Note: In a real app, this happens inside a useEffect or form submission handler.
    const stripeCheckoutUrl = `https://checkout.stripe.com/c/pay/${sessionId}?redirect=${successUrl}`;

    return (
      <div className="payment-container">
        <h2>Checkout Integration</h2>
        <p>Amount: {amount / 100} {currency.toUpperCase()}</p>
        
        {/* 
          In a real app, you would use window.location.href or window.location.replace
          to redirect the user immediately or on button click.
        */}
        <a href={stripeCheckoutUrl} className="btn-primary">
          Pay with Stripe Checkout
        </a>
        
        <div className="explanation">
          <strong>Under the Hood:</strong> This link points directly to Stripe's servers. 
          The user leaves your site, enters payment details on a Stripe-hosted page, 
          and is redirected back to your `successUrl`.
        </div>
      </div>
    );
  } 

  // -------------------------------------------------
  // PATH 2: ELEMENTS FLOW (The "Embedded" Pattern)
  // -------------------------------------------------
  else if (mode === 'elements') {
    // 1. The backend generates a PaymentIntent and returns the client_secret.
    // We simulate the async fetch of this secret.
    const clientSecretPromise = createStripeResource(mockPaymentConfig);

    // 2. The frontend renders input fields that will be mounted by Stripe.js
    // Note: This is pseudo-code for the UI structure. 
    // Actual implementation requires `@stripe/react-stripe-js`.
    
    return (
      <div className="payment-container">
        <h2>Elements Integration</h2>
        <p>Amount: {amount / 100} {currency.toUpperCase()}</p>
        
        <form onSubmit={(e) => e.preventDefault()}>
          {/* 
            These are standard HTML inputs that Stripe Elements will overlay or replace.
            In a real app, we use <CardElement /> from @stripe/react-stripe-js.
          */}
          <div className="form-group">
            <label>Card Number</label>
            <div className="stripe-input-mock">4242 4242 4242 4242</div>
          </div>
          
          <div className="form-row">
            <div className="form-group">
              <label>Expiry</label>
              <div className="stripe-input-mock">MM / YY</div>
            </div>
            <div className="form-group">
              <label>CVC</label>
              <div className="stripe-input-mock">123</div>
            </div>
          </div>

          <button type="submit" className="btn-primary">
            Pay Securely
          </button>
        </form>

        <div className="explanation">
          <strong>Under the Hood:</strong> The user stays on your site. 
          You mount the `CardElement` using the `client_secret`. 
          When the user clicks "Pay", you call `stripe.confirmCardPayment()` 
          directly from your frontend code.
        </div>
      </div>
    );
  }

  return <div>Invalid Configuration</div>;
};

// Export for demonstration purposes
export default PaymentPage;
