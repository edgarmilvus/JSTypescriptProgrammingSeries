/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.tsx
// Description: Advanced Application Script
// ==========================================

// app/components/AdvancedPaymentForm.tsx
'use client';

import React, { useState } from 'react';
import { loadStripe } from '@stripe/stripe-js';
import {
  Elements,
  CardElement,
  useStripe,
  useElements,
} from '@stripe/react-stripe-js';
import { processPayment } from '@/app/actions/paymentActions';

// 1. CONFIGURATION
// Initialize Stripe outside the component to prevent re-initialization on re-renders.
const stripePromise = loadStripe(
  process.env.NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY!
);

// 2. PAYMENT FORM COMPONENT
// This is a client component that interacts with the Stripe Elements library.
const CheckoutForm = () => {
  const stripe = useStripe();
  const elements = useElements();
  const [message, setMessage] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  /**
   * Handles the form submission.
   * 
   * Logic Breakdown:
   * 1. Prevent default browser submission.
   * 2. Validate that Stripe.js has loaded.
   * 3. Call the Server Action (`processPayment`) to create a PaymentIntent.
   * 4. Use the returned client_secret to confirm the card payment on the client.
   * 5. Handle success or failure states.
   */
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setMessage(null);

    if (!stripe || !elements) {
      // Stripe.js has not yet loaded.
      return;
    }

    try {
      // A. SERVER INTERACTION
      // We pass minimal data to the server action. The server handles the secret keys.
      // This leverages the Event Loop on the server to handle the Stripe API call asynchronously.
      const { clientSecret, error: backendError } = await processPayment({
        amount: 1000, // $10.00 in cents
        currency: 'usd',
      });

      if (backendError) {
        setMessage(backendError);
        setIsLoading(false);
        return;
      }

      if (!clientSecret) {
        throw new Error('No client secret returned from server.');
      }

      // B. CLIENT-SIDE CONFIRMATION
      // We confirm the payment using the client secret.
      // This keeps the card data on the client side (PCI compliant) while using the server-generated intent.
      const { error: stripeError, paymentIntent } = await stripe.confirmCardPayment(
        clientSecret,
        {
          payment_method: {
            card: elements.getElement(CardElement)!,
            billing_details: {
              name: 'Test User',
            },
          },
        }
      );

      if (stripeError) {
        // C. SMART DUNNING TRIGGER POINT
        // If the card is declined, we can immediately surface a message.
        // In a full app, this error code would trigger the Smart Dunning logic (e.g., retry logic or AI agent suggestion).
        setMessage(stripeError.message || 'Payment failed');
      } else if (paymentIntent?.status === 'succeeded') {
        setMessage('Payment successful!');
        // Trigger refresh or redirect here
      }
    } catch (err) {
      setMessage('An unexpected error occurred.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="max-w-md mx-auto p-6 bg-white shadow-lg rounded-lg">
      <div className="mb-4">
        <label className="block text-gray-700 text-sm font-bold mb-2">
          Card Details
        </label>
        <div className="p-3 border rounded-md bg-gray-50">
          <CardElement
            options={{
              style: {
                base: {
                  fontSize: '16px',
                  color: '#424770',
                  '::placeholder': { color: '#aab7c4' },
                },
              },
            }}
          />
        </div>
      </div>

      <button
        disabled={isLoading || !stripe || !elements}
        className={`w-full bg-blue-600 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline ${
          isLoading ? 'opacity-50 cursor-not-allowed' : 'hover:bg-blue-700'
        }`}
        type="submit"
      >
        {isLoading ? 'Processing...' : 'Pay Now'}
      </button>

      {message && (
        <div className="mt-4 text-center text-sm font-medium text-red-600">
          {message}
        </div>
      )}
    </form>
  );
};

// 3. WRAPPER COMPONENT
// This component initializes the Stripe Elements provider.
export const AdvancedPaymentForm = () => {
  const options = {
    mode: 'payment' as const,
    amount: 1000,
    currency: 'usd',
  };

  return (
    <Elements stripe={stripePromise} options={options}>
      <CheckoutForm />
    </Elements>
  );
};
