/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script_part2.ts
// Description: Advanced Application Script
// ==========================================

// app/actions/paymentActions.ts
'use server';

import Stripe from 'stripe';
import { headers } from 'next/headers';

// Initialize Stripe on the server side
const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!);

/**
 * Server Action: processPayment
 * 
 * This function runs securely on the server (Node.js environment).
 * 
 * @param {Object} paymentData - The payment details.
 * @returns {Promise<{ clientSecret?: string; error?: string }>}
 */
export async function processPayment(paymentData: { amount: number; currency: string }) {
  // 1. SECURITY & VALIDATION
  // We can access secure environment variables here that are hidden from the client.
  // We can also perform database checks (e.g., user subscription status) here.

  // 2. PAYMENT INTENT CREATION
  // We create a PaymentIntent. This is the "Server Action" that triggers the Stripe API call.
  // The Node.js Event Loop handles this I/O operation asynchronously.
  try {
    const intent = await stripe.paymentIntents.create({
      amount: paymentData.amount,
      currency: paymentData.currency,
      automatic_payment_methods: {
        enabled: true,
      },
      // Metadata is crucial for downstream systems (Smart Dunning, AI Agents)
      metadata: {
        integration_check: 'accept_a_payment',
        source: 'hybrid_elements_checkout',
      },
    });

    // 3. RETURN CLIENT SECRET
    // We return only the client secret to the client. The secret allows the client
    // to confirm the payment without having access to the secret key.
    return { clientSecret: intent.client_secret };
  } catch (error: any) {
    // 4. ERROR HANDLING
    // If the server action fails (e.g., Stripe API down, invalid key), we catch it here.
    // This error is passed back to the client component.
    console.error('Server Action Error:', error.message);
    return { error: error.message };
  }
}
