/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

import Stripe from 'stripe';
import { SupabaseClient } from '@supabase/supabase-js'; // Assuming Supabase for DB

// Initialize Stripe with secret key
const stripe = new Stripe(process.env.STRIPE_SECRET_KEY as string, {
  apiVersion: '2023-10-16',
});

// Initialize Supabase client (or your preferred DB client)
const supabase = new SupabaseClient(
  process.env.SUPABASE_URL as string,
  process.env.SUPABASE_SERVICE_ROLE_KEY as string
);

/**
 * Creates a Stripe Checkout Session for a subscription.
 * @param priceId - The Stripe Price ID to subscribe to.
 * @param userId - The internal ID of the user in your database.
 * @returns The URL of the Checkout Session.
 */
export async function createCheckoutSession(priceId: string, userId: string): Promise<{ url: string } | { error: string }> {
  try {
    // 1. Look up user in database to get email and Stripe Customer ID
    const { data: user, error: dbError } = await supabase
      .from('users')
      .select('email, stripe_customer_id')
      .eq('id', userId)
      .single();

    if (dbError || !user) {
      throw new Error('User not found in database.');
    }

    let customerId = user.stripe_customer_id;

    // 2. If no Stripe Customer ID exists, create a new customer
    if (!customerId) {
      const customer = await stripe.customers.create({
        email: user.email,
        metadata: {
          internal_user_id: userId,
        },
      });
      customerId = customer.id;

      // Save the new Stripe Customer ID back to your database
      await supabase
        .from('users')
        .update({ stripe_customer_id: customerId })
        .eq('id', userId);
    }

    // 3. Create the Checkout Session
    const session = await stripe.checkout.sessions.create({
      customer: customerId,
      payment_method_types: ['card'],
      mode: 'subscription',
      line_items: [
        {
          price: priceId,
          quantity: 1,
        },
      ],
      // Dynamic success URL with session ID for verification
      success_url: `https://app.example.com/dashboard?session_id={CHECKOUT_SESSION_ID}`,
      // Static cancel URL
      cancel_url: 'https://app.example.com/pricing',
      // Pass customer email if not using customer ID (optional if customer is set)
      customer_email: !customerId ? user.email : undefined,
    });

    if (!session.url) {
      throw new Error('Failed to generate Checkout URL.');
    }

    return { url: session.url };

  } catch (error: any) {
    // 4. Handle Stripe API errors
    console.error('Stripe Checkout Error:', error.message);
    return { error: error.message };
  }
}
