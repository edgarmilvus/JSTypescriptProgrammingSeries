/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

import { Request, Response, NextFunction } from 'express';
import Stripe from 'stripe';
import { SupabaseClient } from '@supabase/supabase-js';

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY as string, {
  apiVersion: '2023-10-16',
});

const supabase = new SupabaseClient(
  process.env.SUPABASE_URL as string,
  process.env.SUPABASE_SERVICE_ROLE_KEY as string
);

export const stripeWebhookHandler = async (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  const sig = req.headers['stripe-signature'];
  const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET;

  let event: Stripe.Event;

  // 1. Verify the webhook signature
  try {
    if (!sig || !webhookSecret) {
      return res.status(400).send('Webhook signature or secret missing.');
    }
    // req.body must be raw buffer for verification
    event = stripe.webhooks.constructEvent(
      req.body as Buffer,
      sig,
      webhookSecret
    );
  } catch (err: any) {
    console.error(`Webhook Signature Verification failed: ${err.message}`);
    return res.status(400).send(`Webhook Error: ${err.message}`);
  }

  // 2. Handle the specific event type
  if (event.type === 'invoice.payment_failed') {
    const invoice = event.data.object as Stripe.Invoice;
    const customerId = invoice.customer as string;

    try {
      // 3. Find user in Supabase by Stripe Customer ID
      const { data: user, error: dbError } = await supabase
        .from('users')
        .select('id')
        .eq('stripe_customer_id', customerId)
        .single();

      if (dbError || !user) {
        console.error(`User not found for customer ID: ${customerId}`);
        // We return 200 to acknowledge the event, even if user isn't found locally
        // to prevent Stripe from retrying indefinitely for a non-existent user.
        return res.status(200).json({ received: true });
      }

      // 4. Update user status to 'dunning'
      const { error: updateError } = await supabase
        .from('users')
        .update({ payment_status: 'dunning' })
        .eq('id', user.id);

      if (updateError) throw updateError;

      // 5. Log to audit table
      await supabase.from('dunning_events').insert({
        user_id: user.id,
        event_type: event.type,
        invoice_id: invoice.id,
        amount_due: invoice.amount_due,
        created: new Date().toISOString(),
      });

      console.log(`Dunning triggered for user ${user.id}`);

    } catch (processingError: any) {
      console.error('Error processing dunning logic:', processingError);
      // Return 500 so Stripe retries the webhook
      return res.status(500).send('Internal Server Error');
    }
  }

  // 6. Return 200 OK for successfully processed or ignored events
  res.status(200).json({ received: true });
};
