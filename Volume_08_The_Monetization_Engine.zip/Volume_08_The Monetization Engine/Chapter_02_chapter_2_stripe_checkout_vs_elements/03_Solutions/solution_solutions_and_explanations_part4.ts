/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

// sw.ts

const MODEL_CACHE_NAME = 'ai-model-v1';
const MODEL_URL = '/models/ai_intent_model.onnx';

// 1. Install Event: Precache the heavy asset
self.addEventListener('install', (event: ExtendableEvent) => {
  event.waitUntil(
    (async () => {
      const cache = await caches.open(MODEL_CACHE_NAME);
      try {
        // Prefetch and cache the model immediately
        await cache.add(MODEL_URL);
        console.log('AI Model cached successfully.');
      } catch (error) {
        console.error('Failed to cache model during install:', error);
      }
      // Force the waiting service worker to become active immediately
      self.skipWaiting();
    })()
  );
});

// 2. Activate Event: Cleanup old caches
self.addEventListener('activate', (event: ExtendableEvent) => {
  event.waitUntil(
    (async () => {
      const cacheNames = await caches.keys();
      const deletePromises = cacheNames
        .filter(name => name !== MODEL_CACHE_NAME)
        .map(name => caches.delete(name));
      
      await Promise.all(deletePromises);
      self.clients.claim(); // Control all clients immediately
    })()
  );
});

// 3. Fetch Event: Serve from cache, fallback to network
self.addEventListener('fetch', (event: FetchEvent) => {
  const { request } = event;

  // Only intercept requests for the specific model URL
  if (request.url.includes(MODEL_URL)) {
    event.respondWith(
      (async () => {
        const cache = await caches.open(MODEL_CACHE_NAME);
        
        // 1. Check Cache First (Low Latency Strategy)
        const cachedResponse = await cache.match(request);
        if (cachedResponse) {
          // Optional: Fetch in background to update cache (Stale-While-Revalidate)
          event.waitUntil(
            cache.add(request).catch(() => {/* ignore network errors */})
          );
          return cachedResponse;
        }

        // 2. If not in cache, fetch from network
        try {
          const networkResponse = await fetch(request);
          if (networkResponse.ok) {
            // Clone and cache the response for future use
            cache.put(request, networkResponse.clone());
          }
          return networkResponse;
        } catch (error) {
          // Handle network failure (e.g., offline)
          return new Response('Model unavailable offline', { status: 503 });
        }
      })()
    );
  }
});
