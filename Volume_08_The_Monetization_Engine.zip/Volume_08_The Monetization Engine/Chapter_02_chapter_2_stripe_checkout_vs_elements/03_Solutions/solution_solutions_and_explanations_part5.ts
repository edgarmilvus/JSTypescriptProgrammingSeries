/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

import { useState, useCallback } from 'react';

// Types for the hook state
type CheckoutMode = 'checkout' | 'elements' | null;
type PaymentStatus = 'idle' | 'loading' | 'error' | 'success';

interface HybridCheckoutState {
  mode: CheckoutMode;
  clientSecret: string | null;
  checkoutUrl: string | null;
  status: PaymentStatus;
  error: string | null;
}

export const useHybridCheckout = () => {
  const [state, setState] = useState<HybridCheckoutState>({
    mode: null,
    clientSecret: null,
    checkoutUrl: null,
    status: 'idle',
    error: null,
  });

  // 1. Switching Logic
  const switchMethod = useCallback(async (method: 'checkout' | 'elements') => {
    setState(prev => ({ ...prev, status: 'loading', mode: method, error: null }));

    try {
      if (method === 'elements') {
        // Call API to create a Payment Intent (for Elements)
        const response = await fetch('/api/create-payment-intent', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ amount: 1000, currency: 'usd' }), // Example payload
        });
        const data = await response.json();
        
        if (!data.clientSecret) throw new Error('No client secret returned');
        
        setState(prev => ({ 
          ...prev, 
          clientSecret: data.clientSecret, 
          status: 'idle',
          checkoutUrl: null // Clear checkout URL
        }));

      } else if (method === 'checkout') {
        // Call API to create a Checkout Session
        const response = await fetch('/api/create-checkout-session', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ priceId: 'price_123' }),
        });
        const data = await response.json();

        if (!data.url) throw new Error('No checkout URL returned');

        setState(prev => ({ 
          ...prev, 
          checkoutUrl: data.url, 
          status: 'idle',
          clientSecret: null // Clear client secret
        }));
      }
    } catch (error: any) {
      setState(prev => ({ ...prev, status: 'error', error: error.message }));
    }
  }, []);

  // 2. Execution Logic
  const executePayment = useCallback(() => {
    if (state.status === 'loading') return;

    if (state.mode === 'elements' && state.clientSecret) {
      // In Elements mode, the actual confirmation happens inside the <PaymentElement> component
      // using the clientSecret. This hook just provides the secret.
      // However, if we are managing the form submission here:
      console.log("Client Secret ready for Payment Element:", state.clientSecret);
      // Trigger UI form submission event here if needed
      return;
    }

    if (state.mode === 'checkout' && state.checkoutUrl) {
      // Redirect the user to Stripe's hosted page
      window.location.href = state.checkoutUrl;
    }
  }, [state]);

  return {
    ...state,
    switchMethod,
    executePayment,
  };
};
