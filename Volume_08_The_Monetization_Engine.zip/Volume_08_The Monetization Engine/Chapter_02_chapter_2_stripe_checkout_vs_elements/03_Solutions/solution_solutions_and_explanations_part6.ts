/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part6.ts
// Description: Solutions and Explanations
// ==========================================

digraph HybridCheckoutFlow {
    rankdir=LR;
    node [shape=box, style="rounded,filled", color="#e0e0e0"];

    ReactComponent [label="React Component\n(UI)", fillcolor="#bbdefb"];
    Hook [label="useHybridCheckout Hook\n(State Manager)", fillcolor="#fff9c4"];
    Backend [label="Backend API\n(Node.js/Express)", fillcolor="#c8e6c9"];
    Stripe [label="Stripe API\n(Payment Gateway)", fillcolor="#ffcdd2", shape="ellipse"];

    // Data Flows
    ReactComponent -> Hook [label="1. User clicks\n'Switch Method'"];
    Hook -> Backend [label="2. Request Payment Intent\nor Checkout Session"];
    Backend -> Stripe [label="3. Create Resource\n(PaymentIntent / Session)"];
    Stripe -> Backend [label="4. Return Resource Data\n(ClientSecret / URL)"];
    Backend -> Hook [label="5. Return Data to Client"];
    
    // Execution Flow
    Hook -> ReactComponent [label="6. Update State\n(ClientSecret / URL)"];
    ReactComponent -> Hook [label="7. User clicks 'Pay'"];
    
    // Path A: Elements
    Hook -> ReactComponent [label="8A. Submit Payment Element\n(Uses ClientSecret)", style="dashed"];
    
    // Path B: Checkout
    Hook -> ReactComponent [label="8B. Redirect Window\n(To Checkout URL)", style="dashed"];
    
    // Final Step
    ReactComponent -> Stripe [label="9. Finalize Payment\n(3D Secure / Auth)"];
}
