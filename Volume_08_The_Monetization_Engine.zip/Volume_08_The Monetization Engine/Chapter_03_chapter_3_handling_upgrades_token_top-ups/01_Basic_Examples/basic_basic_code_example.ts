/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

// app/actions/stripeActions.ts
'use server';

import Stripe from 'stripe';
import { redirect } from 'next/navigation';

// Initialize Stripe with the secret key from environment variables
const stripe = new Stripe(process.env.STRIPE_SECRET_KEY as string);

/**
 * @description Server Action to initiate a token top-up via Stripe Checkout.
 * @param {number} amount - The amount in USD to top up (e.g., 10 for $10.00).
 * @param {string} userId - The ID of the user performing the top-up.
 * @returns {Promise<string>} The URL to redirect the user to Stripe Checkout.
 */
export async function createTokenTopupCheckout(amount: number, userId: string) {
  try {
    // 1. Validate input (Security Best Practice)
    if (amount <= 0) {
      throw new Error('Top-up amount must be greater than zero.');
    }

    // 2. Define the price ID for the top-up product in Stripe.
    // In a real app, you might dynamically create a Price object, 
    // but for this example, we assume a standard 'Top-up' price exists in Stripe Dashboard.
    // Note: Stripe Checkout requires a Price ID or a line item with a unit amount.
    const PRICE_ID = 'price_1234567890'; // Replace with actual Stripe Price ID
    
    // 3. Create a Checkout Session
    const session = await stripe.checkout.sessions.create({
      payment_method_types: ['card'],
      line_items: [
        {
          price: PRICE_ID,
          quantity: 1,
          // If using dynamic pricing without a saved Price ID:
          // price_data: {
          //   currency: 'usd',
          //   product_data: { name: 'Token Top-up' },
          //   unit_amount: amount * 100, // Convert to cents
          // },
        },
      ],
      mode: 'payment',
      // 4. Metadata to track the transaction in your database
      metadata: {
        userId: userId,
        type: 'token_topup',
        amount: amount.toString(),
      },
      // 5. Success URL: Stripe redirects here after payment.
      // We append the session_id to verify it later via a webhook or API route.
      success_url: `${process.env.NEXT_PUBLIC_APP_URL}/dashboard/billing?success=true&session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: `${process.env.NEXT_PUBLIC_APP_URL}/dashboard/billing?cancelled=true`,
    });

    // 6. Error handling for session creation
    if (!session.url) {
      throw new Error('Failed to create Stripe Checkout session.');
    }

    // 7. Return the URL to the client for redirection
    return session.url;

  } catch (error) {
    console.error('Stripe Error:', error);
    // Re-throwing allows the client to catch and display the error
    throw new Error('An error occurred while processing your payment.');
  }
}
