/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// app/api/usage-stream/route.ts

import { NextRequest } from 'next/server';

// --- TYPE DEFINITIONS ---

/**
 * Represents the state of a user's token balance.
 * In a real application, this would be fetched from a database (e.g., PostgreSQL, Redis).
 */
interface UserBalance {
    userId: string;
    remainingTokens: number;
    planId: string;
}

/**
 * Represents the data payload for a Stripe Checkout Session creation request.
 * This is the "tool" we will call asynchronously.
 */
interface StripeCheckoutPayload {
    userId: string;
    amount: number; // In cents
    currency: string;
    successUrl: string;
    cancelUrl: string;
}

/**
 * Mock Stripe Checkout Session Response.
 */
interface StripeSession {
    id: string;
    url: string;
    status: 'open' | 'complete' | 'expired';
}

// --- MOCK DATABASE & SERVICES ---

// In-memory store for demonstration purposes. Use a real database in production.
const userBalanceStore = new Map<string, UserBalance>();

// Initialize a mock user
userBalanceStore.set('user_123', {
    userId: 'user_123',
    remainingTokens: 100, // Start with a low balance to trigger the top-up logic
    planId: 'pro_plan',
});

/**
 * MOCK: Simulates an asynchronous database call to fetch user balance.
 * @param userId - The ID of the user.
 * @returns A Promise resolving to the UserBalance object.
 */
async function getUserBalance(userId: string): Promise<UserBalance> {
    // Simulate network latency
    await new Promise(resolve => setTimeout(resolve, 100));
    const balance = userBalanceStore.get(userId);
    if (!balance) {
        throw new Error(`User ${userId} not found.`);
    }
    return balance;
}

/**
 * MOCK: Simulates an asynchronous database call to update user balance after a top-up.
 * @param userId - The ID of the user.
 * @param newBalance - The updated token count.
 * @returns A Promise resolving to the updated UserBalance.
 */
async function updateUserBalance(userId: string, newBalance: number): Promise<UserBalance> {
    await new Promise(resolve => setTimeout(resolve, 100));
    const currentBalance = userBalanceStore.get(userId);
    if (!currentBalance) {
        throw new Error(`User ${userId} not found.`);
    }
    const updatedBalance = { ...currentBalance, remainingTokens: newBalance };
    userBalanceStore.set(userId, updatedBalance);
    return updatedBalance;
}

/**
 * ASYNCHRONOUS TOOL: Simulates a call to the Stripe API to create a Checkout Session.
 * This is a critical pattern: external I/O is wrapped in a Promise and awaited.
 * @param payload - The data required to create the session.
 * @returns A Promise resolving to the Stripe Session object.
 */
async function createStripeCheckoutSession(payload: StripeCheckoutPayload): Promise<StripeSession> {
    console.log(`[Stripe] Creating checkout session for user ${payload.userId}...`);
    
    // Simulate a network request to Stripe's servers
    await new Promise(resolve => setTimeout(resolve, 1500)); 

    // In a real app, you would use `stripe.checkout.sessions.create(payload)`
    const mockSession: StripeSession = {
        id: `cs_test_${Math.random().toString(36).substring(7)}`,
        url: `https://checkout.stripe.com/c/pay/${Math.random().toString(36).substring(7)}`,
        status: 'open',
    };

    console.log(`[Stripe] Session created: ${mockSession.id}`);
    return mockSession;
}

// --- CORE LOGIC: API ROUTE ---

/**
 * GET /api/usage-stream
 * 
 * Establishes a Server-Sent Events (SSE) connection to stream real-time token usage
 * to the client. It also handles asynchronous tool calls (Stripe top-up) when
 * the user's balance is low.
 * 
 * @param req - The incoming Next.js request object.
 */
export async function GET(req: NextRequest) {
    // 1. SETUP: Create a ReadableStream for SSE
    const encoder = new TextEncoder();
    const stream = new ReadableStream({
        async start(controller) {
            // 2. INITIALIZATION: Get user context from headers or query params
            const url = new URL(req.url);
            const userId = url.searchParams.get('userId') || 'user_123';
            
            try {
                // Fetch initial user balance
                let userBalance = await getUserBalance(userId);
                
                // Send initial connection message
                controller.enqueue(
                    encoder.encode(`data: ${JSON.stringify({ type: 'connected', userId, balance: userBalance.remainingTokens })}\n\n`)
                );

                // 3. STREAMING LOOP: Simulate AI token generation and consumption
                const consumptionRate = 15; // tokens per tick
                const tickInterval = 1000; // ms

                const intervalId = setInterval(async () => {
                    try {
                        // --- SIMULATION LOGIC ---
                        const tokensConsumed = Math.floor(Math.random() * consumptionRate) + 5;
                        userBalance.remainingTokens -= tokensConsumed;

                        // --- THRESHOLD CHECK & ASYNC TOOL HANDLING ---
                        // If balance is critically low, trigger the top-up flow
                        if (userBalance.remainingTokens < 20) {
                            // IMPORTANT: We must pause the stream or handle this state carefully.
                            // Here, we send a warning message to the client first.
                            controller.enqueue(
                                encoder.encode(`data: ${JSON.stringify({ type: 'warning', message: 'Low token balance. Initiating top-up flow...' })}\n\n`)
                            );

                            // Stop the regular consumption stream temporarily
                            clearInterval(intervalId);

                            // --- ASYNCHRONOUS TOOL CALL ---
                            // This call is awaited, ensuring non-blocking execution of the overall graph.
                            // The stream is effectively "paused" during this I/O operation.
                            const stripePayload: StripeCheckoutPayload = {
                                userId: userBalance.userId,
                                amount: 500, // $5.00
                                currency: 'usd',
                                successUrl: `${url.origin}/dashboard?session_id={CHECKOUT_SESSION_ID}`,
                                cancelUrl: `${url.origin}/dashboard`,
                            };

                            const session = await createStripeCheckoutSession(stripePayload);

                            // --- POST-TOOL LOGIC ---
                            // In a real app, the top-up would only be confirmed via a Stripe Webhook.
                            // For this demo, we simulate a successful top-up grant.
                            const topUpAmount = 1000; // Grant 1000 new tokens
                            userBalance = await updateUserBalance(userId, userBalance.remainingTokens + topUpAmount);

                            // Notify client of success and new balance
                            controller.enqueue(
                                encoder.encode(`data: ${JSON.stringify({ 
                                    type: 'topup_complete', 
                                    message: 'Top-up successful! Balance updated.', 
                                    balance: userBalance.remainingTokens,
                                    checkoutUrl: session.url 
                                })}\n\n`)
                            );

                            // Resume the stream
                            startStreaming(controller, userBalance, consumptionRate);
                        } else {
                            // --- REGULAR STREAMING UPDATE ---
                            // Send the usage data to the client
                            const usageData = {
                                type: 'usage',
                                tokensConsumed,
                                remainingTokens: userBalance.remainingTokens,
                                timestamp: new Date().toISOString(),
                            };
                            controller.enqueue(encoder.encode(`data: ${JSON.stringify(usageData)}\n\n`));
                        }

                    } catch (error) {
                        // Handle any errors during the interval
                        console.error('Error in streaming interval:', error);
                        controller.enqueue(
                            encoder.encode(`data: ${JSON.stringify({ type: 'error', message: 'An error occurred during streaming.' })}\n\n`)
                        );
                        clearInterval(intervalId);
                        controller.close();
                    }
                }, tickInterval);

                // Helper function to restart streaming after a top-up
                function startStreaming(controller: ReadableStreamDefaultController, balance: UserBalance, rate: number) {
                    const newIntervalId = setInterval(() => {
                        const tokensConsumed = Math.floor(Math.random() * rate) + 5;
                        balance.remainingTokens -= tokensConsumed;

                        // Check again for low balance
                        if (balance.remainingTokens < 20) {
                            clearInterval(newIntervalId);
                            // In a real app, you might loop back to the top-up logic or just stop.
                            // For this demo, we'll just send a final message.
                            controller.enqueue(
                                encoder.encode(`data: ${JSON.stringify({ type: 'warning', message: 'Balance low again. Please top up.' })}\n\n`)
                            );
                            controller.close();
                        } else {
                            const usageData = {
                                type: 'usage',
                                tokensConsumed,
                                remainingTokens: balance.remainingTokens,
                                timestamp: new Date().toISOString(),
                            };
                            controller.enqueue(encoder.encode(`data: ${JSON.stringify(usageData)}\n\n`));
                        }
                    }, tickInterval);
                }

                // 4. CLEANUP: Handle client disconnect
                req.signal.addEventListener('abort', () => {
                    console.log(`Client ${userId} disconnected.`);
                    // Clear any active intervals to prevent memory leaks
                    clearInterval(intervalId);
                    controller.close();
                });

            } catch (err) {
                // Handle initial connection errors
                console.error('Stream initialization error:', err);
                controller.enqueue(
                    encoder.encode(`data: ${JSON.stringify({ type: 'error', message: 'Failed to initialize stream.' })}\n\n`)
                );
                controller.close();
            }
        },
    });

    // 5. RETURN RESPONSE: Send the stream with SSE headers
    return new Response(stream, {
        headers: {
            'Content-Type': 'text/event-stream',
            'Cache-Control': 'no-cache',
            'Connection': 'keep-alive',
        },
    });
}
