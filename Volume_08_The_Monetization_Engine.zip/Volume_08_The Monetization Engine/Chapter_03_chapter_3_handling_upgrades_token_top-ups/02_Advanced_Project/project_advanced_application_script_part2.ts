/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script_part2.ts
// Description: Advanced Application Script
// ==========================================

// components/UsageMonitor.tsx
import { useEffect, useState } from 'react';

export function UsageMonitor({ userId }: { userId: string }) {
    const [usageData, setUsageData] = useState<any>(null);
    const [status, setStatus] = useState<'idle' | 'streaming' | 'topping_up'>('idle');

    useEffect(() => {
        // Establish SSE connection
        const eventSource = new EventSource(`/api/usage-stream?userId=${userId}`);

        eventSource.onmessage = (event) => {
            const data = JSON.parse(event.data);
            
            switch (data.type) {
                case 'connected':
                    setStatus('streaming');
                    setUsageData(data);
                    break;
                case 'usage':
                    setUsageData(data);
                    break;
                case 'warning':
                    setStatus('topping_up');
                    console.warn(data.message);
                    break;
                case 'topup_complete':
                    setStatus('streaming');
                    setUsageData({ balance: data.balance });
                    // Redirect to checkout URL if needed
                    // window.location.href = data.checkoutUrl;
                    break;
                case 'error':
                    console.error(data.message);
                    eventSource.close();
                    break;
            }
        };

        eventSource.onerror = (error) => {
            console.error("SSE Error:", error);
            eventSource.close();
            setStatus('idle');
        };

        // Cleanup on component unmount
        return () => {
            eventSource.close();
        };
    }, [userId]);

    // Render UI based on status and usageData
    // ...
}
