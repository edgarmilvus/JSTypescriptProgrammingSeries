/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part10.ts
// Description: Solutions and Explanations
// ==========================================

// File: app/api/webhooks/route.ts
import { NextRequest, NextResponse } from 'next/server';
import Stripe from 'stripe';

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!);

// Mock Database Interface
interface UserSubscription {
  stripeSubscriptionId: string;
  planId: string;
  status: 'active' | 'canceled' | 'past_due';
  currentPeriodEnd: number;
}

// Mock DB Update Function
const updateUserSubscription = async (id: string, data: Partial<UserSubscription>) => {
  console.log(`Updating DB for user ${id}:`, data);
  // Simulate DB write
  return true;
};

// In-memory set to track processed event IDs (simple idempotency)
const processedEvents = new Set<string>();

export async function POST(request: NextRequest) {
  const payload = await request.text();
  const signature = request.headers.get('stripe-signature')!;

  let event: Stripe.Event;

  try {
    // 1. Security: Verify Signature
    event = stripe.webhooks.constructEvent(
      payload,
      signature,
      process.env.STRIPE_WEBHOOK_SECRET!
    );
  } catch (err) {
    console.error('Webhook signature verification failed.');
    return NextResponse.json({ error: 'Invalid signature' }, { status: 400 });
  }

  // 2. Idempotency Check
  if (processedEvents.has(event.id)) {
    console.log(`Event ${event.id} already processed. Skipping.`);
    return NextResponse.json({ received: true, status: 'skipped' });
  }

  try {
    // 3. Event Handling
    switch (event.type) {
      case 'customer.subscription.updated': {
        const subscription = event.data.object as Stripe.Subscription;
        await updateUserSubscription(subscription.id, {
          planId: subscription.items.data[0].price.id,
          status: subscription.status,
          currentPeriodEnd: subscription.current_period_end,
        });
        break;
      }

      case 'invoice.payment_succeeded': {
        const invoice = event.data.object as Stripe.Invoice;
        // Log transaction and update paid status
        console.log(`Payment succeeded for invoice ${invoice.id}`);
        break;
      }

      case 'customer.subscription.deleted': {
        const subscription = event.data.object as Stripe.Subscription;
        await updateUserSubscription(subscription.id, {
          status: 'canceled',
        });
        break;
      }

      default:
        console.log(`Unhandled event type: ${event.type}`);
    }

    // Mark as processed
    processedEvents.add(event.id);

    return NextResponse.json({ received: true, status: 'success' });
  } catch (error) {
    console.error('Error processing webhook:', error);

    // 4. Retry Queue Logic (Simulated)
    // By returning a non-200 status, Stripe will retry the webhook.
    // For a robust system, we would push to a queue (Redis/SQS) here.
    // e.g., await queueService.push({ payload, signature });
    
    return NextResponse.json(
      { error: 'Webhook handler failed', details: error }, 
      { status: 500 } // Stripe retries on 5xx
    );
  }
}
