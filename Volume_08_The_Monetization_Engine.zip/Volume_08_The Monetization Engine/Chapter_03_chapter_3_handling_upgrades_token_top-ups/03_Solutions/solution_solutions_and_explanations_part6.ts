/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part6.ts
// Description: Solutions and Explanations
// ==========================================

// File: components/TokenTopUp.tsx
'use client';

import { useState, useEffect } from 'react';
import { calculateTopUpCost } from '@/utils/calculateTopUpCost';

export default function TokenTopUp() {
  const [tokens, setTokens] = useState<number>(0);
  const [cost, setCost] = useState<number>(0);
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState('');

  // Real-time calculation
  useEffect(() => {
    if (tokens > 0) {
      setCost(calculateTopUpCost(tokens));
    } else {
      setCost(0);
    }
  }, [tokens]);

  const handleBuy = async () => {
    // Validation
    if (!Number.isInteger(tokens) || tokens <= 0) {
      setMessage('Please enter a positive integer.');
      return;
    }
    if (tokens > 5_000_000) {
      setMessage('Maximum top-up is 5 million tokens.');
      return;
    }

    setLoading(true);
    try {
      const response = await fetch('/api/top-up-tokens', {
        method: 'POST',
        body: JSON.stringify({ tokenAmount: tokens }),
        headers: { 'Content-Type': 'application/json' },
      });
      const data = await response.json();
      setMessage(data.message || 'Top-up successful!');
    } catch (error) {
      setMessage('Error processing top-up.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="p-4 border rounded">
      <h3 className="font-bold mb-2">Buy Tokens</h3>
      <input
        type="number"
        value={tokens || ''}
        onChange={(e) => setTokens(Number(e.target.value))}
        placeholder="Enter tokens (e.g. 500000)"
        className="border p-2 w-full mb-2"
      />
      <p className="text-sm text-gray-600 mb-4">Cost: ${cost.toFixed(2)}</p>
      <button 
        onClick={handleBuy} 
        disabled={loading}
        className="bg-green-600 text-white px-4 py-2 rounded disabled:opacity-50"
      >
        {loading ? 'Processing...' : 'Buy Tokens'}
      </button>
      {message && <p className="mt-2 text-sm">{message}</p>}
    </div>
  );
}
