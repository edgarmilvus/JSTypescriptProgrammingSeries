/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part7.ts
// Description: Solutions and Explanations
// ==========================================

// File: app/api/top-up-tokens/route.ts
import { NextRequest, NextResponse } from 'next/server';

// Mock Database
const userBalances: Record<string, number> = {
  'user_123': 100000, // Initial balance
};

export async function POST(request: NextRequest) {
  const { tokenAmount } = await request.json();
  const userId = 'user_123'; // Hardcoded for mock

  // Simulate Stripe Payment Intent (synchronous mock)
  // In reality, this would be async and confirmed via webhook
  console.log(`Creating Stripe Payment Intent for ${tokenAmount} tokens...`);

  // Simulate DB Update
  if (userBalances[userId] !== undefined) {
    userBalances[userId] += tokenAmount;
    
    return NextResponse.json({
      success: true,
      message: `Payment successful. New balance: ${userBalances[userId]} tokens.`,
      newBalance: userBalances[userId]
    });
  }

  return NextResponse.json({ error: 'User not found' }, { status: 404 });
}
