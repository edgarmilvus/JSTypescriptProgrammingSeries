/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part9.ts
// Description: Solutions and Explanations
// ==========================================

// File: components/BillingSupportChat.tsx
'use client';

import { useChat } from '@ai-sdk/react';
import { useEffect } from 'react';

export default function BillingSupportChat() {
  const { messages, input, handleInputChange, handleSubmit, isLoading } = useChat({
    api: '/api/chat',
  });

  // Mock fetching user context on mount
  useEffect(() => {
    const fetchContext = async () => {
      // In a real app, fetch actual user data
      const mockContext = {
        currentPlan: 'Starter',
        lastInvoice: '$10.00 on Oct 1st',
        usage: '45k tokens used this month'
      };
      // We would typically pass this via the API call or store in a ref
      // For this SDK, we can attach it to the first message or a custom header
      // Here, we simulate it by sending it with the first message or a system update
    };
    fetchContext();
  }, []);

  return (
    <div className="flex flex-col w-full max-w-md p-4 border rounded-lg">
      <div className="flex-1 overflow-y-auto space-y-4 mb-4 h-64">
        {messages.map((m) => (
          <div key={m.id} className={`p-2 rounded ${m.role === 'user' ? 'bg-blue-100' : 'bg-gray-100'}`}>
            <strong>{m.role === 'user' ? 'You: ' : 'Agent: '}</strong>
            {m.content}
          </div>
        ))}
      </div>

      <form onSubmit={(e) => {
        // Inject context into the request
        // Note: useChat allows passing extra body params
        handleSubmit(e, {
          body: {
            userContext: {
              plan: 'Starter',
              lastInvoice: '$10.00'
            }
          }
        });
      }} className="flex gap-2">
        <input
          value={input}
          onChange={handleInputChange}
          placeholder="Ask about billing..."
          className="flex-1 border p-2 rounded"
          disabled={isLoading}
        />
        <button type="submit" disabled={isLoading} className="bg-blue-600 text-white px-4 rounded">
          Send
        </button>
      </form>
    </div>
  );
}
