/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: theory_theoretical_foundations.ts
// Description: Theoretical Foundations
// ==========================================

// Conceptual TypeScript definition of a Portal Configuration Object
// This defines the "permissions" granted to the user for this specific session.
interface PortalConfiguration {
  business_profile: {
    headline: string; // Custom branding
    privacy_policy_url: string;
    terms_of_service_url: string;
  };
  features: {
    customer_update: {
      enabled: boolean;
      allowed_updates: ('address' | 'billing' | 'email' | 'name' | 'phone')[];
    };
    invoice_history: { enabled: boolean };
    payment_method_update: { enabled: boolean };
    subscription_cancel: {
      enabled: boolean;
      mode: 'at_period_end' | 'immediately';
      cancellation_reason?: {
        enabled: boolean;
        options: ('too_expensive' | 'missing_features' | 'switched_service' | 'unused')[];
      };
    };
    subscription_pause: { enabled: boolean };
    subscription_update: {
      enabled: boolean;
      default_allowed_updates: ('price' | 'quantity' | 'promotion_code')[];
    };
  };
}
