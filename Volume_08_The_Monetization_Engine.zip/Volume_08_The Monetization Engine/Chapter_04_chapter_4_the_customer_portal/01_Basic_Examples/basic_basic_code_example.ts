/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

// app/actions/billing-agent.ts

'use server'; // Marks this function as a Server Action for Next.js

import { generateObject } from 'ai'; // Vercel AI SDK for structured generation
import { openai } from '@ai-sdk/openai'; // OpenAI provider
import { z } from 'zod'; // Schema validation

/**
 * @typedef {Object} BillingContext
 * @property {string} customerId - The unique identifier for the Stripe customer.
 * @property {string} query - The natural language billing inquiry from the user.
 */

/**
 * @typedef {Object} AgentResponse
 * @property {string} action - The specific billing action to take (e.g., 'retrieve_invoice', 'update_payment_method').
 * @property {string} explanation - A human-readable explanation of what the agent is doing.
 * @property {string} vectorId - A unique ID used for the simulated vector database upsert (representing the intent vector).
 */

// 1. SCHEMA DEFINITION
// We define a strict schema using Zod to ensure the AI returns predictable JSON.
// This prevents "hallucinated" or malformed data structures.
const billingResponseSchema = z.object({
  action: z.enum(['retrieve_invoice', 'update_payment_method', 'cancel_subscription', 'retry_payment']),
  explanation: z.string(),
  vectorId: z.string().uuid(), // Simulating a vector ID for the upsert operation
});

/**
 * Server Action: Handles billing inquiries via AI.
 * 
 * @param {BillingContext} context - The customer ID and the user's natural language query.
 * @returns {Promise<AgentResponse>} - The structured response from the AI agent.
 */
export async function handleBillingInquiry(context: {
  customerId: string;
  query: string;
}) {
  // 2. AI INTERACTION
  // We use generateObject to force the LLM to adhere to our strict schema.
  // This is safer than generating text and parsing it manually.
  const { object } = await generateObject({
    model: openai('gpt-4o-mini'), // Using a fast, efficient model
    schema: billingResponseSchema,
    prompt: `
      You are a billing support agent for a SaaS platform.
      Customer ID: ${context.customerId}
      User Query: "${context.query}"
      
      Based on the query, determine the correct billing action.
      Generate a unique UUID for the 'vectorId' to represent this interaction in our vector database.
    `,
  });

  // 3. SIMULATED DATABASE UPSERT
  // In a real scenario, this would interact with a vector database (e.g., Pinecone, Qdrant)
  // or a relational database to log the intent.
  // We simulate the "Upsert Operation" here.
  await simulateVectorUpsert(object.vectorId, object.action, context.customerId);

  // 4. RETURN STRUCTURED RESPONSE
  // The client receives this JSON object to update the UI or trigger further actions.
  return {
    action: object.action,
    explanation: object.explanation,
    vectorId: object.vectorId,
  };
}

/**
 * Simulates an Upsert Operation in a Vector Database.
 * Upsert = Update if exists, Insert if new.
 * 
 * @param {string} id - The unique Vector ID.
 * @param {string} intent - The billing intent/action.
 * @param {string} custId - The customer ID associated with the vector.
 */
async function simulateVectorUpsert(id: string, intent: string, custId: string) {
  // Mock latency for database operation
  await new Promise(resolve => setTimeout(resolve, 200));
  
  // In a real implementation, this would look like:
  // await pinecone.index('billing-intents').upsert([
  //   { id, values: generateEmbedding(intent), metadata: { customerId: custId } }
  // ]);
  
  console.log(`[DB UPSERT] Vector ID: ${id} | Action: ${intent} | Customer: ${custId}`);
}
