/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// File: app/api/webhooks/dunning/route.ts
// Runtime: Edge (Vercel/Next.js) for low latency

import { NextResponse } from 'next/server';
import Stripe from 'stripe';
import { z } from 'zod';

// -----------------------------------------------------------------------------
// 1. TYPE DEFINITIONS & SCHEMAS
// -----------------------------------------------------------------------------

/**
 * Schema for the structured output expected from the AI Worker Agent.
 * This ensures the AI's response is predictable and machine-readable.
 */
const DunningResolutionSchema = z.object({
  action: z.enum(['retry_immediately', 'update_payment_method', 'cancel_subscription', 'do_nothing']),
  reason: z.string().describe("The justification for the chosen action."),
  targetInvoiceId: z.string().optional(),
});

type DunningResolution = z.infer<typeof DunningResolutionSchema>;

// -----------------------------------------------------------------------------
// 2. HELPER: STRIPE INITIALIZATION
// -----------------------------------------------------------------------------

const getStripe = (): Stripe => {
  const apiKey = process.env.STRIPE_SECRET_KEY;
  if (!apiKey) throw new Error("Missing Stripe Secret Key");
  return new Stripe(apiKey, { apiVersion: '2023-10-16' });
};

// -----------------------------------------------------------------------------
// 3. SUPERVISOR NODE: WEBHOOK HANDLER
// -----------------------------------------------------------------------------

/**
 * Handles incoming Stripe webhooks specifically for payment failures.
 * Acts as the Supervisor Node, parsing the event and delegating to the AI Agent.
 */
export async function POST(req: Request) {
  const stripe = getStripe();
  const payload = await req.text();
  const signature = req.headers.get('stripe-signature') ?? '';

  let event: Stripe.Event;

  try {
    // Verify the webhook signature (Crucial for security)
    event = stripe.webhooks.constructEvent(
      payload,
      signature,
      process.env.STRIPE_WEBHOOK_SECRET ?? ''
    );
  } catch (err: any) {
    return NextResponse.json({ error: `Webhook Error: ${err.message}` }, { status: 400 });
  }

  // Filter for the specific event: payment_intent.payment_failed
  if (event.type === 'payment_intent.payment_failed') {
    const paymentIntent = event.data.object as Stripe.PaymentIntent;
    const customerId = typeof paymentIntent.customer === 'string' 
      ? paymentIntent.customer 
      : paymentIntent.customer?.id;

    if (!customerId) {
      return NextResponse.json({ message: 'No customer associated' }, { status: 200 });
    }

    try {
      // DELEGATION STRATEGY:
      // We extract the context and pass it to the AI Worker Agent.
      const resolution = await dunningWorkerAgent({
        customerId,
        paymentIntentId: paymentIntent.id,
        lastPaymentError: paymentIntent.last_payment_error?.message || 'Unknown error',
      });

      // Execute the decision made by the AI Agent
      await executeDunningAction(stripe, resolution);

      return NextResponse.json({ received: true, action: resolution.action }, { status: 200 });
    } catch (error) {
      return NextResponse.json({ error: 'Internal Agent Error' }, { status: 500 });
    }
  }

  // Return 200 for unhandled events
  return NextResponse.json({ received: true }, { status: 200 });
}

// -----------------------------------------------------------------------------
// 4. AI WORKER AGENT: REASONING LAYER
// -----------------------------------------------------------------------------

/**
 * Simulates an AI Agent that analyzes the failure context and determines the best recovery path.
 * In a production environment, this would call an LLM (e.g., GPT-4) with the schema.
 * Here, we mock the logic to demonstrate the Delegation Strategy.
 *
 * @param context - The data payload from the Supervisor Node
 * @returns Promise<DunningResolution> - Structured output from the AI
 */
async function dunningWorkerAgent(context: {
  customerId: string;
  paymentIntentId: string;
  lastPaymentError: string;
}): Promise<DunningResolution> {
  const stripe = getStripe();

  // Fetch additional context: Current subscription status and default payment method
  const customer = await stripe.customers.retrieve(context.customerId);
  
  if (customer.deleted) {
    throw new Error("Customer deleted");
  }

  // LOGIC: Analyze the error message to decide the action
  // This is where the "AI" logic resides (simplified for this script)
  let action: DunningResolution['action'] = 'do_nothing';
  let reason = '';

  if (context.lastPaymentError.includes('expired') || context.lastPaymentError.includes('card')) {
    // If the error is card-related, we check if the customer has updated their payment method recently
    // In a real app, we might check the `invoice_settings.default_payment_method` timestamp.
    if (customer.invoice_settings?.default_payment_method) {
      action = 'retry_immediately';
      reason = 'Card error detected, but customer has a valid default payment method set. Attempting retry.';
    } else {
      action = 'update_payment_method';
      reason = 'Card error detected and no valid payment method on file. Prompt user to update via portal.';
    }
  } else if (context.lastPaymentError.includes('insufficient_funds')) {
    action = 'do_nothing'; // Wait for dunning cycle
    reason = 'Insufficient funds. Relying on Stripe’s automated smart dunning schedule.';
  }

  // Return structured output (simulating JSON schema enforcement)
  return {
    action,
    reason,
    targetInvoiceId: undefined, // In a real scenario, we would attach the invoice ID here
  };
}

// -----------------------------------------------------------------------------
// 5. EXECUTION LAYER: INTERACTING WITH PORTAL BACKEND
// -----------------------------------------------------------------------------

/**
 * Executes the specific action determined by the AI Agent.
 * This directly manipulates Stripe resources (the "Backend" of the Customer Portal).
 */
async function executeDunningAction(stripe: Stripe, resolution: DunningResolution) {
  console.log(`[Dunning Engine] Executing Action: ${resolution.action}`);

  switch (resolution.action) {
    case 'retry_immediately':
      // In a real scenario, we would fetch the latest invoice and attempt to pay it again
      // using the updated payment method.
      // stripe.invoices.pay(invoiceId);
      console.log(" -> Triggering invoice retry via Stripe API...");
      break;

    case 'update_payment_method':
      // Logic to notify the user or update the portal configuration to force a prompt.
      // We might update a metadata flag on the customer object that the Portal reads.
      console.log(" -> Updating Customer Metadata to flag 'payment_method_required'...");
      break;

    case 'cancel_subscription':
      // Hard cancellation logic
      console.log(" -> Canceling subscription immediately...");
      break;

    case 'do_nothing':
    default:
      console.log(" -> No immediate action taken. Relying on Smart Dunning.");
      break;
  }
}
