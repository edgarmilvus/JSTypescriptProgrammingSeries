/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

import { Request, Response } from 'express';

// 1. Define the interface for the specific Stripe event
// We focus on the 'data.object' structure which contains the invoice details.
interface InvoicePaymentSucceededEvent {
  type: string; // e.g., 'invoice.payment_succeeded'
  data: {
    object: {
      id: string;
      customer: string;
      amount_paid: number;
      // Stripe sends many more fields, but we strictly type what we need.
      status?: string; 
    };
  };
}

// 2. Define the user-defined type guard
function isInvoicePaymentSucceededEvent(payload: unknown): payload is InvoicePaymentSucceededEvent {
  // Check if payload is an object and not null
  if (typeof payload !== 'object' || payload === null) {
    return false;
  }

  const event = payload as any;

  // Validate the existence and type of required top-level and nested properties
  const hasCorrectType = typeof event.type === 'string' && event.type === 'invoice.payment_succeeded';
  const hasDataObject = typeof event.data === 'object' && event.data !== null;
  const hasNestedObject = hasDataObject && typeof event.data.object === 'object' && event.data.object !== null;

  if (!hasCorrectType || !hasNestedObject) {
    return false;
  }

  const invoice = event.data.object;

  // Validate the specific properties inside data.object
  return (
    typeof invoice.id === 'string' &&
    typeof invoice.customer === 'string' &&
    typeof invoice.amount_paid === 'number'
  );
}

// 3. Implement the route handler
// Mocking the verifyStripeSignature function for the sake of the exercise
const verifyStripeSignature = (payload: string, signature: string) => {
  if (!signature || signature !== 'valid_signature') {
    throw new Error('Invalid signature');
  }
};

app.post('/webhook', (req: Request, res: Response) => {
  const payload = req.rawBody; // In a real app, use req.rawBody for signature verification
  const signature = req.headers['stripe-signature'] as string;

  try {
    // 1. Verify the signature to ensure the request is genuinely from Stripe
    verifyStripeSignature(payload, signature);

    // 2. Parse the JSON payload
    const event = JSON.parse(payload.toString());

    // 3. Use the type guard to validate the event structure
    if (isInvoicePaymentSucceededEvent(event)) {
      // Type narrowing ensures TypeScript knows the exact structure of 'event' here
      console.log(`Processing successful payment for Invoice ID: ${event.data.object.id}`);
      console.log(`Amount Paid: ${event.data.object.amount_paid}`);
      
      // Here you would typically update your database or trigger other business logic
      res.status(200).send('Webhook processed successfully');
    } else {
      // The event structure does not match our expectation
      console.error('Error: Received an event with an unexpected structure.');
      res.status(400).send('Bad Request: Invalid event structure');
    }
  } catch (err: any) {
    // Handle errors (e.g., signature verification failed, JSON parsing error)
    console.error(`Webhook Error: ${err.message}`);
    res.status(400).send(`Webhook Error: ${err.message}`);
  }
});
