/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

// 1. Define the types for our domain
type PaymentAttempt = {
  attemptNumber: number;
  failureReason: 'card_declined' | 'insufficient_funds' | 'expired_card' | 'processing_error';
  timestamp: Date;
};

type DunningAction = 'retry_immediately' | 'schedule_retry' | 'escalate' | 'do_nothing';

// 2. Implement the dunning logic function
function calculateDunningAction(attempts: PaymentAttempt[]): DunningAction {
  // Edge case: If there are no attempts, there's nothing to do.
  if (attempts.length === 0) {
    return 'do_nothing';
  }

  // Get the most recent attempt for analysis
  const lastAttempt = attempts[attempts.length - 1];
  const { failureReason, attemptNumber } = lastAttempt;

  // Rule 1: Escalate immediately for specific hard failures
  if (failureReason === 'expired_card' || failureReason === 'processing_error') {
    return 'escalate';
  }

  // Rule 2: If fewer than 3 attempts, schedule a retry (giving the customer time)
  if (attemptNumber < 3) {
    return 'schedule_retry';
  }

  // Rule 3: If 3 or more attempts and the last failure was a hard decline, escalate
  if (attemptNumber >= 3 && failureReason === 'card_declined') {
    return 'escalate';
  }

  // Rule 4: If the failure was due to insufficient funds, retry immediately
  if (failureReason === 'insufficient_funds') {
    return 'retry_immediately';
  }

  // Default case: For any other scenario (e.g., 'card_declined' on attempt 1 or 2), schedule a retry
  return 'schedule_retry';
}

// --- Example Usage ---
// const attempts: PaymentAttempt[] = [
//   { attemptNumber: 1, failureReason: 'card_declined', timestamp: new Date() }
// ];
// console.log(calculateDunningAction(attempts)); // Output: 'schedule_retry'

// const attempts2: PaymentAttempt[] = [
//   { attemptNumber: 1, failureReason: 'insufficient_funds', timestamp: new Date() }
// ];
// console.log(calculateDunningAction(attempts2)); // Output: 'retry_immediately'
