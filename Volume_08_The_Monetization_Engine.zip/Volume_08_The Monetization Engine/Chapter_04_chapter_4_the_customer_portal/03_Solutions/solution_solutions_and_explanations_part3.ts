/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

// 1. Define JSON Schemas (as TypeScript objects)
const getInvoiceStatusSchema = {
  type: 'object',
  properties: {
    intent: { type: 'string', const: 'get_invoice_status' },
    parameters: {
      type: 'object',
      properties: {
        invoice_id: { type: 'string' },
        customer_id: { type: 'string' },
      },
      required: ['invoice_id', 'customer_id'],
    },
  },
  required: ['intent', 'parameters'],
};

const updatePaymentMethodSchema = {
  type: 'object',
  properties: {
    intent: { type: 'string', const: 'update_payment_method' },
    parameters: {
      type: 'object',
      properties: {
        customer_id: { type: 'string' },
        new_payment_method_id: { type: 'string' },
      },
      required: ['customer_id', 'new_payment_method_id'],
    },
  },
  required: ['intent', 'parameters'],
};

// 2. Define the system prompt
const systemPrompt = `
You are a specialized AI assistant for a customer billing portal. Your task is to analyze a user's query and extract structured information.
You must identify one of two intents: 'get_invoice_status' or 'update_payment_method'.
Based on the intent, extract the relevant parameters and output a JSON object.

For 'get_invoice_status', you must extract:
- invoice_id
- customer_id

For 'update_payment_method', you must extract:
- customer_id
- new_payment_method_id

If the intent is unknown, output { "intent": "unknown", "parameters": {} }.
Do not include any other text in your response. Output only the JSON object.
`;

// 3. Implement the simulation function with type guards
// Helper function to validate against the schema (simplified for this exercise)
function isValidGetInvoiceStatusResponse(response: any): response is { intent: 'get_invoice_status'; parameters: { invoice_id: string; customer_id: string } } {
  return response?.intent === 'get_invoice_status' && 
         typeof response.parameters?.invoice_id === 'string' && 
         typeof response.parameters?.customer_id === 'string';
}

function isValidUpdatePaymentMethodResponse(response: any): response is { intent: 'update_payment_method'; parameters: { customer_id: string; new_payment_method_id: string } } {
  return response?.intent === 'update_payment_method' && 
         typeof response.parameters?.customer_id === 'string' && 
         typeof response.parameters?.new_payment_method_id === 'string';
}

async function simulateAIAgent(query: string): Promise<{ intent: string; parameters: any }> {
  // Mock the LLM's response based on simple keyword matching
  let mockResponse: any;

  if (query.toLowerCase().includes('status of invoice') && query.toLowerCase().includes('customer')) {
    // In a real scenario, the LLM would parse the IDs from the string.
    // For this mock, we will extract them using regex or hardcode for demonstration.
    const invoiceIdMatch = query.match(/INV-\d+/);
    const customerIdMatch = query.match(/CUST-\d+/);
    
    mockResponse = {
      intent: 'get_invoice_status',
      parameters: {
        invoice_id: invoiceIdMatch ? invoiceIdMatch[0] : 'INV-12345', // Fallback for mock
        customer_id: customerIdMatch ? customerIdMatch[0] : 'CUST-678' // Fallback for mock
      }
    };
  } else if (query.toLowerCase().includes('update my payment method')) {
    // Mock extraction of payment method ID (e.g., from "card ending in 4242")
    mockResponse = {
      intent: 'update_payment_method',
      parameters: {
        customer_id: 'CUST-999', // Hardcoded for mock
        new_payment_method_id: 'pm_card_4242' // Hardcoded for mock
      }
    };
  } else {
    mockResponse = { intent: 'unknown', parameters: {} };
  }

  // Use a type guard to validate the mocked response before returning it
  if (isValidGetInvoiceStatusResponse(mockResponse) || isValidUpdatePaymentMethodResponse(mockResponse)) {
    console.log('AI Agent: Intent successfully classified and validated.');
    return mockResponse;
  } else {
    console.error('AI Agent: Failed to validate the generated response.');
    // In a real system, you might trigger a retry or fallback logic here.
    return { intent: 'error', parameters: {} };
  }
}

// --- Example Usage ---
// simulateAIAgent("What is the status of invoice INV-12345 for customer CUST-678?");
// simulateAIAgent("I need to update my payment method to the card ending in 4242 for my account.");
