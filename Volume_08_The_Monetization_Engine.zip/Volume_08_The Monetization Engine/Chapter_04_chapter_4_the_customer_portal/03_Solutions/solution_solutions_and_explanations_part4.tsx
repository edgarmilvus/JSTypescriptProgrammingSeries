/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState, useEffect } from 'react';

// 1. Define interfaces for the data
interface Invoice {
  id: string;
  amount: number; // In cents
  status: 'paid' | 'open' | 'void';
  date: string;
}

// 2. Mock API function
const fetchInvoices = (customerId: string): Promise<Invoice[]> => {
  console.log(`Fetching invoices for customer: ${customerId}`);
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve([
        { id: 'in_1', amount: 1000, status: 'paid', date: '2023-10-01' },
        { id: 'in_2', amount: 2500, status: 'open', date: '2023-10-15' },
        { id: 'in_3', amount: 500, status: 'void', date: '2023-10-20' },
        { id: 'in_4', amount: 3000, status: 'paid', date: '2023-11-01' },
      ]);
    }, 2000); // 2-second delay
  });
};

// 3. React Component
const InvoiceHistory: React.FC<{ customerId: string }> = ({ customerId }) => {
  // State management
  const [invoices, setInvoices] = useState<Invoice[]>([]);
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [filter, setFilter] = useState<string>('all');

  // useEffect for data fetching
  useEffect(() => {
    const loadData = async () => {
      setLoading(true);
      setError(null);
      try {
        const data = await fetchInvoices(customerId);
        setInvoices(data);
      } catch (err) {
        setError('Failed to fetch invoice data.');
      } finally {
        setLoading(false);
      }
    };

    loadData();
  }, [customerId]); // Re-run if customerId changes

  // Filter logic
  const filteredInvoices = invoices.filter((invoice) => 
    filter === 'all' ? true : invoice.status === filter
  );

  // Render logic
  if (loading) {
    return <div className="loading-spinner">Loading invoices...</div>;
  }

  if (error) {
    return <div className="error-message" style={{ color: 'red' }}>{error}</div>;
  }

  return (
    <div className="invoice-history-container">
      <h2>Invoice History</h2>
      
      {/* Filter Controls */}
      <div className="filter-controls">
        <label>Filter by Status: </label>
        <select value={filter} onChange={(e) => setFilter(e.target.value)}>
          <option value="all">All</option>
          <option value="paid">Paid</option>
          <option value="open">Open</option>
          <option value="void">Void</option>
        </select>
      </div>

      {/* Invoice Table */}
      {filteredInvoices.length > 0 ? (
        <table>
          <thead>
            <tr>
              <th>Invoice ID</th>
              <th>Date</th>
              <th>Status</th>
              <th>Amount</th>
            </tr>
          </thead>
          <tbody>
            {filteredInvoices.map((invoice) => (
              <tr key={invoice.id}>
                <td>{invoice.id}</td>
                <td>{invoice.date}</td>
                <td>{invoice.status.toUpperCase()}</td>
                {/* Format amount from cents to dollars */}
                <td>${(invoice.amount / 100).toFixed(2)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      ) : (
        <p>No invoices match the current filter.</p>
      )}
    </div>
  );
};

export default InvoiceHistory;
