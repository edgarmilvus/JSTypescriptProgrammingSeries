/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

digraph HierarchicalAgenticWorkflow {
    rankdir=TB;
    node [shape=box, style=filled, fillcolor="#E0F7FA", fontname="Helvetica"];
    edge [fontname="Helvetica", fontsize=10];

    // Supervisor Layer
    subgraph cluster_supervisor {
        label = "Supervisor Layer";
        style = filled;
        color = lightgrey;
        node [fillcolor="#B2EBF2"];
        Supervisor [label="Supervisor Agent\n(Decomposes Query)"];
    }

    // Executor Layer
    subgraph cluster_executors {
        label = "Executor Layer";
        style = filled;
        color = lightgrey;
        node [fillcolor="#FFF9C4"];
        PaymentStatusAgent [label="PaymentStatusAgent\n(Queries Payment Failure)"];
        DunningAgent [label="DunningAgent\n(Decides Retry Action)"];
    }

    // Tool Layer
    subgraph cluster_tools {
        label = "Tool Layer";
        style = filled;
        color = lightgrey;
        node [fillcolor="#FFCCBC"];
        RetrieveTool [label="stripe.invoices.retrieve()"];
        RetryTool [label="stripe.paymentIntents.retry()"];
    }

    // User and Final Response
    node [fillcolor="#FFFFFF", shape=ellipse];
    UserQuery [label="User Query:\n'Why was my payment declined?'"];
    FinalResponse [label="Final Response to User"];

    // Workflow Flow
    UserQuery -> Supervisor;
    
    Supervisor -> PaymentStatusAgent [label="1. Delegate Payment Status Check"];
    PaymentStatusAgent -> RetrieveTool [label="2. Use Tool"];
    RetrieveTool -> PaymentStatusAgent [label="3. Return Failure Reason"];
    PaymentStatusAgent -> Supervisor [label="4. Report Failure Reason"];

    Supervisor -> DunningAgent [label="5. Delegate Dunning Decision"];
    DunningAgent -> RetryTool [label="6. Use Tool (if applicable)"];
    RetryTool -> DunningAgent [label="7. Return Result"];
    DunningAgent -> Supervisor [label="8. Report Action Result"];

    Supervisor -> FinalResponse [label="9. Formulate Final Answer"];
}
