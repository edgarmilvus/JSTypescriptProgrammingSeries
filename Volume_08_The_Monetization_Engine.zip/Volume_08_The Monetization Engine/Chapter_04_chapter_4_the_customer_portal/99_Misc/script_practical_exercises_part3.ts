/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part3.ts
// Description: Practical Exercises
// ==========================================

// Example starter code structure

// 1. Define JSON Schemas (as TypeScript objects or strings)
// const getInvoiceStatusSchema = { ... };
// const updatePaymentMethodSchema = { ... };

// 2. Define the system prompt
// const systemPrompt = `...`;

// 3. Implement the simulation function
// async function simulateAIAgent(query: string): Promise<{ intent: string; parameters: any }> {
//   // Mock the LLM response based on the query
//   let mockResponse: any;
//   if (query.includes('status of invoice')) {
//     // mockResponse = { intent: 'get_invoice_status', parameters: { ... } };
//   } else if (query.includes('update my payment method')) {
//     // mockResponse = { intent: 'update_payment_method', parameters: { ... } };
//   } else {
//     // mockResponse = { intent: 'unknown', parameters: {} };
//   }

//   // Use a type guard to validate the mockResponse
//   // if (isGetInvoiceStatusResponse(mockResponse)) { ... }
//   // else if (isUpdatePaymentMethodResponse(mockResponse)) { ... }

//   return mockResponse;
// }
