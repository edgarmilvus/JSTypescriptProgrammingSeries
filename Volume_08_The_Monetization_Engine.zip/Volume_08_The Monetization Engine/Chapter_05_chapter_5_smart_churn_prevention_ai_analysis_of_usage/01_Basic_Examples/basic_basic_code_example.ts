/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

// Import necessary modules from Zod and Node.js
import { z } from 'zod';
import { randomUUID } from 'node:crypto';

/**
 * 1. DEFINE THE ZOD SCHEMA
 * We define the shape of a "Usage Event" that our SaaS app will capture.
 * This acts as the single source of truth for our data structure.
 */
const UsageEventSchema = z.object({
  userId: z.string().uuid(), // Must be a valid UUID
  eventType: z.enum(['login', 'view_dashboard', 'export_report']), // Strictly limited values
  timestamp: z.date().default(() => new Date()), // Defaults to current time if missing
  metadata: z.record(z.unknown()).optional(), // Flexible object for extra data
});

// TYPE INFERENCE IN ACTION:
// We don't write an interface manually. Zod infers the TS type directly from the schema.
type UsageEvent = z.infer<typeof UsageEventSchema>;

/**
 * 2. SIMULATE DATA INGESTION
 * In a real app, this data comes from an API or frontend analytics tracker.
 * Here, we create a mock dataset with one valid event and one "at-risk" signal.
 */
const rawMockData: unknown[] = [
  // Valid login event
  {
    userId: randomUUID(),
    eventType: 'login',
    timestamp: new Date(Date.now() - 1000 * 60 * 5), // 5 minutes ago
  },
  // User who hasn't logged in for 8 days (Churn Risk Signal)
  {
    userId: randomUUID(),
    eventType: 'view_dashboard',
    timestamp: new Date(Date.now() - 1000 * 60 * 60 * 24 * 8), // 8 days ago
  },
  // Invalid event (missing userId) - will be filtered out
  {
    eventType: 'login',
    timestamp: new Date(),
  },
];

/**
 * 3. PROCESS AND ANALYZE
 * A function to parse, validate, and analyze the raw data.
 */
function analyzeChurnRisk(data: unknown[]): { safe: UsageEvent[]; atRisk: UsageEvent[] } {
  const safe: UsageEvent[] = [];
  const atRisk: UsageEvent[] = [];

  // Define the churn threshold (7 days in milliseconds)
  const SEVEN_DAYS_MS = 7 * 24 * 60 * 60 * 1000;
  const now = new Date();

  for (const item of data) {
    // Validate against the Zod schema
    const result = UsageEventSchema.safeParse(item);

    if (result.success) {
      const event = result.data;
      
      // Calculate time difference
      const timeDiff = now.getTime() - event.timestamp.getTime();

      // LOGIC: If the last event was more than 7 days ago, flag as at-risk
      if (timeDiff > SEVEN_DAYS_MS) {
        console.log(`[AI Analysis] Flagging User ${event.userId} as At-Risk.`);
        atRisk.push(event);
      } else {
        safe.push(event);
      }
    } else {
      // Handle validation errors (e.g., malformed JSON from client)
      console.warn(`[Validation Error] Skipping invalid event:`, result.error.errors);
    }
  }

  return { safe, atRisk };
}

// EXECUTE THE PIPELINE
const results = analyzeChurnRisk(rawMockData);

console.log('--- Analysis Results ---');
console.log(`Total Safe Users: ${results.safe.length}`);
console.log(`Total At-Risk Users: ${results.atRisk.length}`);
