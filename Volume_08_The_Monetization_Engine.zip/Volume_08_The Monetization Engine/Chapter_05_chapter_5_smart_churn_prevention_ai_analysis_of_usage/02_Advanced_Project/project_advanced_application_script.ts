/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// src/app/api/churn-analysis/route.ts
import { NextRequest, NextResponse } from 'next/server';
import Stripe from 'stripe';
import { z } from 'zod';

// ============================================================================
// 1. TYPE DEFINITIONS & SCHEMAS
// ============================================================================

// Using Zod for runtime validation. TypeScript infers the 'UsageEvent' type 
// directly from the schema, ensuring frontend and backend types stay in sync.
const UsageEventSchema = z.object({
  userId: z.string().uuid(),
  eventType: z.enum(['login', 'feature_click', 'export_request', 'session_end']),
  timestamp: z.number().int(), // Unix timestamp
  metadata: z.record(z.unknown()).optional(),
});

type UsageEvent = z.infer<typeof UsageEventSchema>;

// The Churn Risk Score is a normalized value between 0 (Safe) and 1 (High Risk).
type ChurnRiskScore = number;

// Configuration for our AI Heuristic Model (In a real app, these weights come from ML training)
const RISK_MODEL_CONFIG = {
  weights: {
    loginFrequency: 0.4,      // Importance of login count decay
    featureDepth: 0.3,        // Importance of using core features
    sessionDuration: 0.3,     // Importance of time spent
  },
  thresholds: {
    warning: 0.6,             // Trigger "Check-in" email
    critical: 0.85,           // Trigger "Smart Dunning" / Discount offer
  },
};

// ============================================================================
// 2. THE ANALYSIS ENGINE (AI LOGIC)
// ============================================================================

/**
 * Analyzes a stream of usage events to calculate a churn risk score.
 * 
 * Under the Hood:
 * This function acts as the "Brain" of our churn prevention system. 
 * While a production system might query a pre-trained TensorFlow.js model, 
 * this implementation uses a weighted heuristic approach to demonstrate the logic.
 * 
 * Logic:
 * 1. Calculate Login Decay: Compare recent logins vs. historical average.
 * 2. Analyze Feature Abandonment: Check if critical features (e.g., 'export_request') 
 *    have stopped appearing in recent events.
 * 3. Compute Score: Invert the metrics (less usage = higher risk) and apply weights.
 */
function calculateChurnRisk(events: UsageEvent[]): ChurnRiskScore {
  if (events.length === 0) return 1.0; // Maximum risk for new/inactive users

  const now = Date.now();
  const thirtyDaysAgo = now - (30 * 24 * 60 * 60 * 1000);
  
  // Filter events for the analysis window (last 30 days)
  const recentEvents = events.filter(e => e.timestamp > thirtyDaysAgo);
  
  if (recentEvents.length === 0) return 1.0;

  // --- Metric 1: Login Frequency Decay ---
  // Simple heuristic: If logins < 5 in 30 days, risk increases.
  const loginCount = recentEvents.filter(e => e.eventType === 'login').length;
  const loginScore = Math.max(0, 1 - (loginCount / 10)); // Normalize 0-10 logins
  
  // --- Metric 2: Feature Abandonment ---
  // Check if the user stopped using 'export_request' (a high-value feature).
  const exportCount = recentEvents.filter(e => e.eventType === 'export_request').length;
  const featureScore = exportCount > 0 ? 0 : 1; // 1 (High Risk) if 0 exports
  
  // --- Metric 3: Session Duration Proxy ---
  // In a real app, calculate average session time. Here, we use event density.
  const daysActive = new Set(recentEvents.map(e => new Date(e.timestamp).getDate())).size;
  const activityScore = Math.max(0, 1 - (daysActive / 15)); // Low activity = High risk

  // --- Weighted Aggregation ---
  const rawScore = 
    (loginScore * RISK_MODEL_CONFIG.weights.loginFrequency) +
    (featureScore * RISK_MODEL_CONFIG.weights.featureDepth) +
    (activityScore * RISK_MODEL_CONFIG.weights.sessionDuration);

  // Clamp between 0 and 1
  return Math.min(1, Math.max(0, rawScore));
}

// ============================================================================
// 3. STRIPE SMART DUNNING INTEGRATION
// ============================================================================

/**
 * Triggers a Stripe intervention based on the calculated risk score.
 * 
 * Under the Hood:
 * This function bridges the AI analysis with the payment gateway. 
 * It utilizes Stripe's PaymentIntents API to attempt recovery before 
 * involuntary churn occurs due to card failure or subscription status.
 */
async function triggerSmartDunning(userId: string, score: ChurnRiskScore) {
  const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!);

  try {
    // 1. Retrieve the user's active subscription
    // In a real DB, we map 'userId' to 'stripeCustomerId'
    const customerResponse = await fetch(`/api/db/get-customer?userId=${userId}`);
    const { stripeCustomerId } = await customerResponse.json();

    const subscriptions = await stripe.subscriptions.list({
      customer: stripeCustomerId,
      status: 'active',
      limit: 1,
    });

    if (subscriptions.data.length === 0) return;

    const subscription = subscriptions.data[0];

    // 2. Logic: If Risk is Critical (> 0.85), we update the subscription 
    // to add a "Win-back" discount or update the payment method logic.
    if (score >= RISK_MODEL_CONFIG.thresholds.critical) {
      console.log(`[Smart Dunning] Critical risk detected for ${userId}. Initiating recovery flow.`);

      // Example: Update subscription metadata to flag for dunning email
      await stripe.subscriptions.update(subscription.id, {
        metadata: {
          churn_risk_score: score.toString(),
          dunning_status: 'pending_intervention',
          last_analysis: new Date().toISOString(),
        },
      });

      // In a full implementation, this would trigger a Stripe Billing 'dunning' 
      // schedule or an email via Stripe Webhooks.
    }
  } catch (error) {
    console.error("Error in Smart Dunning Trigger:", error);
  }
}

// ============================================================================
// 4. NEXT.JS API ROUTE HANDLER
// ============================================================================

/**
 * POST /api/churn-analysis
 * 
 * Flow:
 * 1. Receive usage telemetry from the frontend.
 * 2. Validate data using Zod (Type Inference).
 * 3. Run AI Heuristic Analysis.
 * 4. If risk is high, trigger Stripe Smart Dunning.
 */
export async function POST(request: NextRequest) {
  try {
    // A. Parse and Validate Input
    const body = await request.json();
    const result = UsageEventSchema.safeParse(body);

    if (!result.success) {
      return NextResponse.json(
        { error: "Invalid usage event data", details: result.error.flatten() },
        { status: 400 }
      );
    }

    const event: UsageEvent = result.data;

    // B. Fetch Historical Data (Mocking a DB call)
    // In production, we would query a Time-Series DB (e.g., InfluxDB) or Data Lake.
    // Here, we simulate a history of events for the user.
    const mockHistory: UsageEvent[] = [
      // Simulating a user who logged in 2 times in the last 30 days
      { userId: event.userId, eventType: 'login', timestamp: Date.now() - (1000 * 60 * 60 * 24 * 5) },
      { userId: event.userId, eventType: 'login', timestamp: Date.now() - (1000 * 60 * 60 * 24 * 1) },
      { userId: event.userId, eventType: 'session_end', timestamp: Date.now() - (1000 * 60 * 60 * 24 * 1) },
      // Note: No 'export_request' events, indicating feature abandonment.
    ];

    // C. Run AI Analysis
    const riskScore = calculateChurnRisk(mockHistory);

    // D. Decision Matrix
    if (riskScore >= RISK_MODEL_CONFIG.thresholds.warning) {
      // Trigger backend workflows
      await triggerSmartDunning(event.userId, riskScore);
      
      return NextResponse.json({
        status: 'intervention_triggered',
        riskScore: riskScore,
        message: 'High churn risk detected. Smart Dunning workflow initiated.',
      });
    }

    return NextResponse.json({
      status: 'monitoring',
      riskScore: riskScore,
      message: 'User behavior within normal parameters.',
    });

  } catch (error) {
    console.error("Internal Server Error:", error);
    return NextResponse.json(
      { error: "Internal Server Error" },
      { status: 500 }
    );
  }
}
