/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// 1. Define the UserActivity interface
interface UserActivity {
  userId: string;
  lastLogin: Date;
  loginFrequency: number; // Avg logins per week
  featuresUsed: string[]; // Features interacted with in last 14 days
  supportTickets: number; // Count of open/recent tickets
}

// 2. Define the return type for the analysis result
interface RiskAnalysisResult {
  userId: string;
  riskScore: number;
}

// 3. Implement the analyzeChurnRisk function
function analyzeChurnRisk(users: UserActivity[]): RiskAnalysisResult[] {
  const results: RiskAnalysisResult[] = [];

  for (const user of users) {
    // Start with a base score of 10
    let riskScore = 10;

    // --- Login Penalty Logic ---
    const today = new Date();
    const daysSinceLastLogin = (today.getTime() - user.lastLogin.getTime()) / (1000 * 60 * 60 * 24);

    // If lastLogin is more than 7 days ago
    if (daysSinceLastLogin > 7) {
      riskScore += 40;
    }

    // If loginFrequency is less than 1
    if (user.loginFrequency < 1) {
      riskScore += 20;
    }

    // --- Feature Abandonment Penalty ---
    // Check if 'dashboard' OR 'api_access' is missing
    if (!user.featuresUsed.includes('dashboard') || !user.featuresUsed.includes('api_access')) {
      riskScore += 25;
    }

    // --- Support Burden Bonus ---
    if (user.supportTickets > 3) {
      riskScore += 15;
    }

    // Ensure score doesn't exceed 100
    if (riskScore > 100) riskScore = 100;

    results.push({
      userId: user.userId,
      riskScore: riskScore,
    });
  }

  return results;
}

// --- Example Usage (Mock Data) ---
const mockUsers: UserActivity[] = [
  {
    userId: "user_001",
    lastLogin: new Date(), // Today
    loginFrequency: 5,
    featuresUsed: ["dashboard", "api_access", "reporting"],
    supportTickets: 0,
  },
  {
    userId: "user_002",
    lastLogin: new Date(Date.now() - 10 * 24 * 60 * 60 * 1000), // 10 days ago
    loginFrequency: 0.5,
    featuresUsed: ["reporting"], // Missing dashboard and api_access
    supportTickets: 5,
  },
];

// const analysis = analyzeChurnRisk(mockUsers);
// console.log(analysis);
