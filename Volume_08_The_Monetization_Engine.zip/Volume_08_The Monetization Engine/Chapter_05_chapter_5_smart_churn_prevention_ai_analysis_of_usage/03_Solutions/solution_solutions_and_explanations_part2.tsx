/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState, useEffect } from 'react';

// 1. Define the prop types
interface RiskData {
  userId: string;
  riskScore: number;
}

interface ChurnRiskDashboardProps {
  riskData: RiskData[];
}

// 2. Helper function for dynamic styling
const getRiskStyle = (score: number) => {
  if (score <= 30) return { border: '2px solid green', backgroundColor: '#e8f5e9' };
  if (score <= 60) return { border: '2px solid orange', backgroundColor: '#fff3e0' };
  return { border: '2px solid red', backgroundColor: '#ffebee' };
};

const ChurnRiskDashboard: React.FC<ChurnRiskDashboardProps> = ({ riskData }) => {
  // 3. State management for fetching simulation
  const [data, setData] = useState<RiskData[]>([]);
  const [loading, setLoading] = useState(true);

  // 4. Simulate fetching data
  useEffect(() => {
    const fetchData = async () => {
      // Simulate network delay
      await new Promise(resolve => setTimeout(resolve, 500));
      
      // In a real app, this would be an API call. 
      // Here we accept the prop or use it to set state.
      setData(riskData);
      setLoading(false);
    };

    fetchData();
  }, [riskData]); // Re-run if prop changes

  // 5. Calculate summary statistic
  const atRiskCount = data.filter(user => user.riskScore > 60).length;

  if (loading) {
    return <div>Loading Risk Analysis...</div>;
  }

  return (
    <div style={{ fontFamily: 'Arial, sans-serif', padding: '20px' }}>
      {/* Summary Statistic */}
      <div style={{ marginBottom: '20px', fontWeight: 'bold', fontSize: '1.2rem' }}>
        At-Risk Users: {atRiskCount}
      </div>

      {/* List of User Cards */}
      <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
        {data.map((user) => (
          <div 
            key={user.userId} 
            style={{
              padding: '15px',
              borderRadius: '5px',
              ...getRiskStyle(user.riskScore)
            }}
          >
            <div><strong>User ID:</strong> {user.userId}</div>
            <div><strong>Risk Score:</strong> {user.riskScore}</div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default ChurnRiskDashboard;
