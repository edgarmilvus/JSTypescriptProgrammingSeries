/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

// 1. Strategy Determination Logic
function determineInterventionStrategy(riskScore: number): string {
  if (riskScore > 80) {
    return "high_value_intervention";
  } else if (riskScore > 60) {
    return "proactive_outreach";
  } else {
    return "monitor";
  }
}

// 2. Simulated API Execution (Async)
async function executeIntervention(
  userId: string, 
  strategy: string
): Promise<{ status: string; message: string }> {
  // Simulate network latency (500ms)
  await new Promise(resolve => setTimeout(resolve, 500));

  if (strategy === "high_value_intervention") {
    return { 
      status: 'success', 
      message: 'Assigned to CSM for personal outreach' 
    };
  } else if (strategy === "proactive_outreach") {
    return { 
      status: 'success', 
      message: 'Automated email sequence triggered' 
    };
  } else {
    return { 
      status: 'info', 
      message: 'User will be monitored for further activity' 
    };
  }
}

// 3. Main Workflow Orchestrator
async function runChurnPreventionWorkflow(user: { userId: string; riskScore: number }) {
  // Determine strategy
  const strategy = determineInterventionStrategy(user.riskScore);
  
  console.log(`User ${user.userId} with score ${user.riskScore} -> Strategy: ${strategy}`);

  try {
    // Execute intervention
    const result = await executeIntervention(user.userId, strategy);
    
    // Log final outcome
    console.log(`Outcome: [${result.status}] ${result.message}`);
  } catch (error) {
    console.error("Intervention failed:", error);
  }
}

// --- Demonstration ---
// Mock user with high risk score
const highRiskUser = { userId: "user_999", riskScore: 85 };

// Run the workflow
// Note: In a real environment, we would call this directly.
// runChurnPreventionWorkflow(highRiskUser);

// To allow this code block to be valid TypeScript without running side effects immediately:
export { determineInterventionStrategy, executeIntervention, runChurnPreventionWorkflow };
