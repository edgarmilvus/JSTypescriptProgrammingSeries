/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

// 1. Define the relevant Stripe Invoice type
interface StripeInvoice {
  id: string;
  customer: string;
  attempt_count: number;
  status: string;
}

// 2. Handle Payment Failure Logic
async function handlePaymentFailure(invoice: StripeInvoice): Promise<void> {
  // Check the attempt count to decide the course of action
  if (invoice.attempt_count <= 2) {
    // Logic for automatic retries via Stripe Smart Dunning
    console.log(`Stripe will automatically retry invoice ${invoice.id} for customer ${invoice.customer}`);
  } else {
    // Logic for escalation (e.g., email support, pause account)
    console.log(`Invoice ${invoice.id} has failed ${invoice.attempt_count} times. Escalating to manual review.`);
  }
}

// --- Example Usage (Mock Data) ---
const mockInvoice1: StripeInvoice = {
  id: "in_12345",
  customer: "cus_67890",
  attempt_count: 1,
  status: "open"
};

const mockInvoice2: StripeInvoice = {
  id: "in_98765",
  customer: "cus_54321",
  attempt_count: 3,
  status: "open"
};

// To execute logic (commented out for clean export):
// handlePaymentFailure(mockInvoice1); // Output: Stripe will automatically retry...
// handlePaymentFailure(mockInvoice2); // Output: Invoice in_98765 has failed 3 times...

export { handlePaymentFailure };
