/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

digraph ChurnPreventionFlow {
    rankdir=TB; // Top to Bottom layout
    node [shape=box, style="rounded,filled", color="#2c3e50", fontcolor="white"];

    // Define Nodes
    User_Activity_Logs [label="User Activity Logs\n(Database/Table)", fillcolor="#3498db"];
    Churn_Analysis_Job [label="Churn Analysis Job\n(Scheduled Process)", fillcolor="#e67e22"];
    Risk_Score_Database [label="Risk Score Database", fillcolor="#2980b9"];
    React_Dashboard [label="React Dashboard\n(Frontend Component)", fillcolor="#27ae60"];
    AI_Intervention_Workflow [label="AI Intervention Workflow\n(Backend Service)", fillcolor="#8e44ad"];
    Stripe_Webhook [label="Stripe Webhook\n(External Event)", fillcolor="#c0392b"];
    Smart_Dunning_Engine [label="Smart Dunning Engine\n(Stripe/Backend)", fillcolor="#d35400"];

    // Define Edges (Data Flow)
    
    // 1. Activity Logs feed into Analysis Job
    User_Activity_Logs -> Churn_Analysis_Job [label="Raw Activity Data"];

    // 2. Analysis Job writes to Database
    Churn_Analysis_Job -> Risk_Score_Database [label="Calculated Scores"];

    // 3. Dashboard reads from Database
    Risk_Score_Database -> React_Dashboard [label="Risk Data Query"];

    // 4. AI Workflow is triggered by Database data
    Risk_Score_Database -> AI_Intervention_Workflow [label="High Risk Triggers"];

    // 5. Stripe Webhook triggers Dunning Engine
    Stripe_Webhook -> Smart_Dunning_Engine [label="Payment Failure Event"];
}
