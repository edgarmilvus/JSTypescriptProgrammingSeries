/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

// app/actions/chat.ts
'use server';

import { createStreamableValue } from 'ai/rsc';
import { OpenAI } from 'openai';

// Initialize OpenAI client
const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY!,
});

/**
 * @description A Server Action that streams an LLM response while tracking
 * token usage for metered billing.
 * @param prompt - The user's input string.
 * @returns An object containing the streamable UI state and the final usage count.
 */
export async function streamMeteredResponse(prompt: string) {
  // 1. Initialize the streamable value. This creates a mutable reference
  // that the client can subscribe to.
  const stream = createStreamableValue('');

  // 2. Initialize usage counter (simulating a database field)
  let totalTokensUsed = 0;

  // 3. Start the LLM call asynchronously
  (async () => {
    try {
      const response = await openai.chat.completions.create({
        model: 'gpt-3.5-turbo',
        messages: [{ role: 'user', content: prompt }],
        stream: true, // CRITICAL: Enable streaming from OpenAI
      });

      // 4. Iterate over the stream from OpenAI
      for await (const chunk of response) {
        const content = chunk.choices[0]?.delta?.content || '';
        
        if (content) {
          // 5. Update the streamable value with the new token
          stream.update(content);

          // 6. METERING LOGIC:
          // Estimate tokens (1 char ≈ 0.75 tokens for rough billing)
          // In production, use a tokenizer library like 'gpt-tokenizer' or 'tiktoken'
          const estimatedTokens = Math.ceil(content.length * 0.75);
          totalTokensUsed += estimatedTokens;

          // 7. Log usage to database (Simulated async write)
          // In production, this would be an async DB call (e.g., Prisma/Supabase)
          // We do NOT await this here to prevent blocking the stream processing
          logUsageToDB(estimatedTokens);
        }
      }
    } catch (error) {
      stream.error(error);
    } finally {
      // 8. Close the stream when done
      stream.done();
    }
  })();

  // 9. Return the stream object to the client
  return {
    stream: stream.value,
    usage: totalTokensUsed, // Note: This will be 0 initially; client should read final state
  };
}

/**
 * @description Simulates writing usage data to a billing provider (Stripe).
 * In a real Stripe implementation, you would use `stripe.billing.meterEvents.create()`.
 */
async function logUsageToDB(tokenCount: number) {
  // Simulate network latency
  // await new Promise((resolve) => setTimeout(resolve, 50));
  
  // Mock DB insert
  console.log(`[Billing Log] Incremented usage by: ${tokenCount} tokens`);
}
