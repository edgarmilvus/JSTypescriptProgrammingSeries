/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// app/actions/ai-chat-action.ts
'use server';

import { streamText } from 'ai';
import { openai } from '@ai-sdk/openai';
import { createStreamableValue, createStreamableUI } from 'ai/rsc';
import Stripe from 'stripe';
import { Ratelimit } from '@upstash/ratelimit';
import { Redis } from '@upstash/redis';
import { z } from 'zod';

// Initialize Stripe (Server-side only)
const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, {
  apiVersion: '2023-10-16',
});

// Initialize Rate Limiter (Prevents abuse of metered billing)
const ratelimit = new Ratelimit({
  redis: Redis.fromEnv(),
  limiter: Ratelimit.slidingWindow(10, '1 m'),
  analytics: true,
});

/**
 * SERVER ACTION: processTokenStream
 * 
 * 1. Authenticates the user via Stripe Customer ID.
 * 2. Checks rate limits.
 * 3. Streams AI response token-by-token.
 * 4. Increments Stripe Usage Record for every token generated.
 * 5. Injects interactive UI components based on content triggers.
 */
export async function processTokenStream(
  message: string, 
  customerId: string
) {
  // 1. Authentication & Rate Limiting
  const { success, limit, reset, remaining } = await ratelimit.limit(customerId);
  if (!success) throw new Error('Rate limit exceeded');

  // 2. Stripe Metered Subscription Verification
  // In a real app, fetch the subscription ID associated with the customerId
  const subscriptions = await stripe.subscriptions.list({
    customer: customerId,
    status: 'active',
  });
  
  const subscription = subscriptions.data.find(
    (sub) => sub.items.data[0].price.recurring?.usage_type === 'metered'
  );

  if (!subscription) throw new Error('No active metered subscription found');

  const priceId = subscription.items.data[0].price.id;
  
  // 3. Initialize Streamable UI and Text
  const uiStream = createStreamableUI(<div>Initializing...</div>);
  const textStream = createStreamableValue('');

  // 4. AI Model Streaming & Metering Logic
  (async () => {
    try {
      const result = await streamText({
        model: openai('gpt-4-turbo-preview'),
        prompt: message,
      });

      let tokenCount = 0;
      let accumulatedText = '';

      // Process the stream from the AI provider
      for await (const part of result.fullStream) {
        if (part.type === 'text-delta') {
          // Accumulate text to detect patterns
          accumulatedText += part.textDelta;
          tokenCount += 1; // Simplified: 1 delta = 1 token for billing demo

          // Update the text stream for the UI
          textStream.update(part.textDelta);

          // 5. Real-Time Stripe Usage Recording
          // We batch updates to avoid hitting Stripe API limits too frequently
          // In production, use a queue (e.g., Redis Queue) to batch these.
          if (tokenCount % 5 === 0) {
            try {
              await stripe.subscriptionItems.createUsageRecord(subscription.items.data[0].id, {
                quantity: 5, // Record 5 tokens
                timestamp: 'now',
                action: 'increment',
              });
            } catch (stripeError) {
              console.error('Stripe usage recording failed:', stripeError);
              // Continue stream even if billing fails (fail-open strategy)
            }
          }

          // 6. streamable-ui Logic: Inject Components on Triggers
          // If the AI mentions "pricing" or "buy", inject a component.
          if (accumulatedText.includes('pricing') && !accumulatedText.includes('buy-button-injected')) {
            const buyButton = (
              <div className="mt-4 p-4 border rounded bg-blue-50">
                <p className="text-sm font-bold">Ready to upgrade?</p>
                <button 
                  className="mt-2 bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700"
                  onClick={() => console.log('Upgrade clicked')}
                >
                  View Pricing Plans
                </button>
              </div>
            );
            
            // Append the UI component to the stream
            uiStream.append(buyButton);
            
            // Mark as injected to prevent duplicates
            accumulatedText += '[INJECTED_COMPONENT]';
          }
        }
      }

      // Finalize streams
      textStream.done();
      uiStream.done();
      
      // Final flush of remaining usage to Stripe
      const remainingTokens = tokenCount % 5;
      if (remainingTokens > 0) {
        await stripe.subscriptionItems.createUsageRecord(subscription.items.data[0].id, {
          quantity: remainingTokens,
          timestamp: 'now',
          action: 'increment',
        });
      }

    } catch (error) {
      textStream.error(error);
      uiStream.error(error);
    }
  })();

  // Return the streamable objects to the client
  return {
    ui: uiStream.value,
    text: textStream.value,
  };
}
