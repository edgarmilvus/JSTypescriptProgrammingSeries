/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script_part2.ts
// Description: Advanced Application Script
// ==========================================

// app/components/ChatInterface.tsx
'use client';

import { useState } from 'react';
import { readStreamableValue } from 'ai/rsc';
import { processTokenStream } from '@/app/actions/ai-chat-action';

export function ChatInterface({ customerId }: { customerId: string }) {
  const [input, setInput] = useState('');
  const [messages, setMessages] = useState<Array<{ type: 'user' | 'ai' | 'ui'; content: any }>>([]);
  const [isGenerating, setIsGenerating] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim()) return;

    // 1. Add user message immediately
    const userMessage = { type: 'user' as const, content: input };
    setMessages((prev) => [...prev, userMessage]);
    setInput('');
    setIsGenerating(true);

    // 2. Call Server Action to start the stream
    const { ui, text } = await processTokenStream(input, customerId);

    // 3. Initialize AI message container
    setMessages((prev) => [...prev, { type: 'ai', content: '' }]);
    
    // 4. Process Text Stream (Token by Token)
    for await (const content of readStreamableValue(text)) {
      setMessages((prev) => {
        const newMessages = [...prev];
        const lastMsg = newMessages[newMessages.length - 1];
        if (lastMsg.type === 'ai') {
          lastMsg.content += content;
        }
        return newMessages;
      });
    }

    // 5. Process UI Stream (Dynamic Components)
    // The UI stream arrives after the text stream finishes or when appended
    for await (const component of readStreamableValue(ui)) {
      setMessages((prev) => [
        ...prev,
        { type: 'ui', content: component }
      ]);
    }

    setIsGenerating(false);
  };

  return (
    <div className="max-w-2xl mx-auto p-4">
      <div className="border rounded-lg p-4 h-96 overflow-y-auto mb-4 space-y-4">
        {messages.map((msg, idx) => (
          <div key={idx} className={`p-2 rounded ${msg.type === 'user' ? 'bg-gray-100 text-right' : 'bg-white border'}`}>
            {typeof msg.content === 'string' ? (
              <p>{msg.content}</p>
            ) : (
              // Render injected React components directly
              <div>{msg.content}</div>
            )}
          </div>
        ))}
        {isGenerating && <div className="text-gray-400 italic">Thinking...</div>}
      </div>

      <form onSubmit={handleSubmit} className="flex gap-2">
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Ask about pricing or features..."
          className="flex-1 border rounded px-3 py-2"
          disabled={isGenerating}
        />
        <button 
          type="submit" 
          disabled={isGenerating}
          className="bg-black text-white px-4 py-2 rounded disabled:opacity-50"
        >
          Send
        </button>
      </form>
    </div>
  );
}
