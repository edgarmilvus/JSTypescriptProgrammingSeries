/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState, useEffect, useRef } from 'react';

// Define the shape of the data expected from the server
interface UsageData {
  tokens: number;
  totalQuota: number;
}

export const TokenUsageMonitor: React.FC = () => {
  const [currentUsage, setCurrentUsage] = useState<number>(0);
  const [totalQuota, setTotalQuota] = useState<number>(1000); // Default
  const [isPaused, setIsPaused] = useState<boolean>(false);
  const [connectionStatus, setConnectionStatus] = useState<'connected' | 'disconnected' | 'error'>('disconnected');
  
  // Ref to store the EventSource instance so we can close it properly
  const eventSourceRef = useRef<EventSource | null>(null);
  
  // Ref to buffer events when paused
  const bufferRef = useRef<UsageData | null>(null);

  const connectStream = () => {
    // Optimistically set status
    setConnectionStatus('connected');

    // In a real app, this URL would be your backend endpoint
    const eventSource = new EventSource('/api/usage/stream');

    eventSource.onmessage = (event) => {
      try {
        const data: UsageData = JSON.parse(event.data);

        if (isPaused) {
          // Buffer the latest data if paused
          bufferRef.current = data;
        } else {
          // Update state immediately if not paused
          setCurrentUsage(data.tokens);
          setTotalQuota(data.totalQuota);
        }
      } catch (error) {
        console.error("Failed to parse SSE data:", error);
        setConnectionStatus('error');
      }
    };

    eventSource.onerror = () => {
      setConnectionStatus('disconnected');
      eventSource.close();
    };

    eventSourceRef.current = eventSource;
  };

  const disconnectStream = () => {
    if (eventSourceRef.current) {
      eventSourceRef.current.close();
      eventSourceRef.current = null;
    }
    setConnectionStatus('disconnected');
  };

  // Effect: Handle Connection Lifecycle
  useEffect(() => {
    connectStream();

    // Cleanup on unmount
    return () => {
      disconnectStream();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Effect: Handle Resume Logic
  useEffect(() => {
    if (!isPaused && bufferRef.current) {
      // Catch up with buffered data
      setCurrentUsage(bufferRef.current.tokens);
      setTotalQuota(bufferRef.current.totalQuota);
      bufferRef.current = null;
    }
  }, [isPaused]);

  // Calculate progress
  const progressPercentage = totalQuota > 0 ? (currentUsage / totalQuota) * 100 : 0;

  return (
    <div style={{ padding: '20px', border: '1px solid #ccc', borderRadius: '8px', maxWidth: '400px' }}>
      <h3>Token Usage Monitor</h3>
      
      <div style={{ marginBottom: '10px' }}>
        <strong>Status:</strong> {connectionStatus}
      </div>

      <div style={{ marginBottom: '10px', fontSize: '1.2em' }}>
        {currentUsage} / {totalQuota} tokens
      </div>

      {/* Progress Bar */}
      <div style={{ width: '100%', height: '20px', backgroundColor: '#e0e0e0', borderRadius: '10px', overflow: 'hidden' }}>
        <div 
          style={{ 
            width: `${Math.min(progressPercentage, 100)}%`, 
            height: '100%', 
            backgroundColor: progressPercentage > 90 ? 'red' : '#4caf50',
            transition: 'width 0.3s ease' 
          }} 
        />
      </div>

      <div style={{ marginTop: '20px' }}>
        <button 
          onClick={() => setIsPaused(!isPaused)}
          style={{ padding: '8px 16px', cursor: 'pointer' }}
        >
          {isPaused ? 'Resume' : 'Pause'}
        </button>
        
        <button 
          onClick={connectionStatus === 'connected' ? disconnectStream : connectStream}
          style={{ padding: '8px 16px marginLeft: 10px', cursor: 'pointer' }}
        >
          {connectionStatus === 'connected' ? 'Disconnect' : 'Reconnect'}
        </button>
      </div>
    </div>
  );
};
