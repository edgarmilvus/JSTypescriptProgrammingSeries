/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

// SERVER SIDE (e.g., app/actions.ts)
'use server';

import { streamUI } from 'ai'; // Assuming Vercel AI SDK or similar
import { setTimeout } from 'timers/promises';

// Mock component for "Copy" button
const CopyButton = ({ text }: { text: string }) => {
  // In a real RSC, this would be a server component that renders a client component
  // For simulation, we return a JSON structure representing the component
  return {
    type: 'component',
    component: 'CopyButton',
    props: { text }
  };
};

// Mock component for Highlight
const HighlightDiv = ({ content }: { content: string }) => {
  return {
    type: 'component',
    component: 'HighlightDiv',
    props: { content }
  };
};

export async function generateStreamableResponse(prompt: string) {
  // Simulate token generation
  const tokens = `Here is the response. This part is standard text. 
  IMPORTANT: This is a very important section. 
  Here is some code coming up: 
  \`\`\`typescript
  const x = 10;
  \`\`\`
  End of response.`.split(' ');

  let tokenCounter = 0;
  let bufferText = '';

  // We use a generator to simulate the stream yield
  async function* generateTokens() {
    for (const token of tokens) {
      await setTimeout(100); // Simulate delay
      tokenCounter++;
      bufferText += token + ' ';
      
      // Logic: Yield Copy Button every 50 tokens
      if (tokenCounter % 50 === 0) {
        yield CopyButton(bufferText);
        bufferText = ''; // Reset buffer or keep depending on logic
      }

      // Logic: Yield Highlight on keyword
      if (token === 'IMPORTANT:') {
        yield HighlightDiv("This is an important highlight");
      }

      // Logic: Yield Code Block
      if (token.includes('