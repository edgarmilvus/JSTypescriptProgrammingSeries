/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

import Stripe from 'stripe';

// Mock Database (In-memory)
const db = {
  users: {
    'user_123': {
      stripeCustomerId: 'cus_mock123',
      currentUsage: 0,
      usageCap: 10000,
      lastBilled: null
    }
  }
};

// Mock Stripe Instance (Typically initialized with process.env.STRIPE_SECRET_KEY)
const stripe = new Stripe('sk_test_mock', { apiVersion: '2023-10-16' });

// Configuration
const RATE_PER_TOKEN = 0.001; // $0.001 per token

interface RecordUsageResult {
  success: boolean;
  message?: string;
  reason?: 'cap_exceeded';
}

export async function recordUsage(userId: string, tokenCount: number): Promise<RecordUsageResult> {
  const user = db.users[userId];

  if (!user) {
    return { success: false, message: 'User not found' };
  }

  // 1. Check Usage Cap
  if (user.currentUsage + tokenCount > user.usageCap) {
    // Trigger "cap-reached" event (simulated)
    console.error(`[ALERT] Usage cap reached for user ${userId}. Current: ${user.currentUsage}, Attempted: ${tokenCount}`);
    
    return { 
      success: false, 
      reason: 'cap_exceeded',
      message: 'Usage cap exceeded. Service blocked.' 
    };
  }

  // 2. Aggregate Usage
  user.currentUsage += tokenCount;
  console.log(`[LOG] Usage recorded. New total: ${user.currentUsage}`);
  
  return { success: true };
}

export async function createInvoiceItem(userId: string): Promise<void> {
  const user = db.users[userId];

  if (!user) {
    throw new Error('User not found');
  }

  if (user.currentUsage === 0) {
    console.log('[INFO] No usage to bill.');
    return;
  }

  try {
    // 1. Calculate Cost
    const amountDecimal = (user.currentUsage * RATE_PER_TOKEN * 100).toFixed(2); // Convert to cents
    const amountInCents = Math.round(Number(amountDecimal));

    // 2. Create Stripe Invoice Item
    // Note: In a real metered setup, you often attach a usage record to a Subscription Item.
    // For this exercise, we create a one-off invoice item as requested.
    await stripe.invoiceItems.create({
      customer: user.stripeCustomerId,
      price_data: {
        currency: 'usd',
        product: 'prod_llm_tokens', // Assumes product exists in Stripe
        unit_amount_decimal: (RATE_PER_TOKEN * 100).toFixed(2), // Price per unit (in cents)
        // For metered, we usually pass the quantity. 
        // If using unit_amount_decimal, we calculate total: unit * quantity
      },
      quantity: user.currentUsage, 
      description: `LLM Token Usage: ${user.currentUsage} tokens`,
    });

    console.log(`[SUCCESS] Invoice item created for ${user.currentUsage} tokens ($${amountInCents / 100})`);

    // 3. Reset Usage
    user.currentUsage = 0;
    user.lastBilled = new Date();

  } catch (error) {
    if (error instanceof Stripe.errors.StripeError) {
      console.error(`[STRIPE ERROR] ${error.message}`);
      // Implement retry logic here (e.g., push to a queue like BullMQ)
    } else {
      console.error('[UNKNOWN ERROR]', error);
    }
    throw error;
  }
}
