/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

// Define Interfaces
interface PricingTier {
  minTokens: number;
  maxTokens: number | null; // null implies infinity
  ratePerToken: number;
}

interface DiscountConfig {
  code: string;
  percentage: number;
}

interface CostBreakdown {
  tierCosts: Array<{ tier: string; cost: number }>;
  subtotal: number;
  discountAmount: number;
  offPeakDiscountAmount: number;
  total: number;
}

// Constants
const PROMO_CODES: Record<string, DiscountConfig> = {
  'WELCOME20': { code: 'WELCOME20', percentage: 0.20 }
};

const OFF_PEAK_HOURS = { start: 0, end: 6 }; // 12:00 AM to 6:00 AM

export function calculateCost(
  tiers: PricingTier[],
  tokenCount: number,
  promoCode?: string,
  timeOfDay?: Date
): CostBreakdown {
  let remainingTokens = tokenCount;
  let subtotal = 0;
  const tierCosts: Array<{ tier: string; cost: number }> = [];

  // 1. Tiered Calculation
  // Sort tiers to ensure correct processing order
  const sortedTiers = [...tiers].sort((a, b) => a.minTokens - b.minTokens);

  for (const tier of sortedTiers) {
    if (remainingTokens <= 0) break;

    // Determine how many tokens fall into this tier
    const tierMax = tier.maxTokens ?? Infinity;
    const tokensInTier = Math.min(remainingTokens, tierMax - tier.minTokens + 1);

    // Since tiers are usually ranges (e.g., 0-1000, 1001-5000), we need to adjust logic slightly
    // Let's assume tiers are sequential ranges:
    // If we have processed X tokens, the next tier starts at X.
    
    // Better logic for sequential tiers:
    // Let's track `startToken` of the current batch.
  }

  // Refined Tier Logic for sequential ranges
  let currentTokenStart = 1;
  let calculatedCost = 0;

  for (const tier of sortedTiers) {
    if (tokenCount < currentTokenStart) break;

    const tierEnd = tier.maxTokens ?? Infinity;
    const tokensInThisTier = Math.min(tokenCount, tierEnd) - (currentTokenStart - 1);
    
    if (tokensInThisTier > 0) {
      const costForTier = tokensInThisTier * tier.ratePerToken;
      calculatedCost += costForTier;
      
      tierCosts.push({
        tier: `${currentTokenStart}-${tierEnd === Infinity ? '∞' : tierEnd}`,
        cost: Number(costForTier.toFixed(4))
      });
      
      currentTokenStart = tierEnd + 1;
    }
  }

  let subtotalCost = calculatedCost;

  // 2. Promo Code Discount
  let discountAmount = 0;
  if (promoCode && PROMO_CODES[promoCode]) {
    discountAmount = subtotalCost * PROMO_CODES[promoCode].percentage;
    subtotalCost -= discountAmount;
  }

  // 3. Off-Peak Discount (Time Based)
  let offPeakDiscountAmount = 0;
  if (timeOfDay) {
    const hour = timeOfDay.getUTCHours();
    if (hour >= OFF_PEAK_HOURS.start && hour < OFF_PEAK_HOURS.end) {
      // Apply 10% to the current subtotal (after promo)
      offPeakDiscountAmount = subtotalCost * 0.10;
      subtotalCost -= offPeakDiscountAmount;
    }
  }

  return {
    tierCosts,
    subtotal: Number(calculatedCost.toFixed(4)),
    discountAmount: Number(discountAmount.toFixed(4)),
    offPeakDiscountAmount: Number(offPeakDiscountAmount.toFixed(4)),
    total: Number(subtotalCost.toFixed(4))
  };
}

// Usage Example:
const tiers: PricingTier[] = [
  { minTokens: 0, maxTokens: 1000, ratePerToken: 0.01 },
  { minTokens: 1001, maxTokens: 5000, ratePerToken: 0.008 },
  { minTokens: 5001, maxTokens: null, ratePerToken: 0.005 }
];

// Scenario: 6000 tokens, Promo "WELCOME20", Time 2:00 AM UTC
// const result = calculateCost(tiers, 6000, 'WELCOME20', new Date('2023-01-01T02:00:00Z'));
