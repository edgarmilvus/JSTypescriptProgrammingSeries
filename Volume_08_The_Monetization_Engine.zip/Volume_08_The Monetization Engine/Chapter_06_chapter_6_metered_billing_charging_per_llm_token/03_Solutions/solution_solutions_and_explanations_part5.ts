/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

// SERVER ACTION (app/actions.ts)
'use server';

import { createStreamableValue } from 'ai/stream';
import { setTimeout } from 'timers/promises';

export async function generateStreamWithUsage(prompt: string) {
  const stream = createStreamableValue();
  let totalUsage = 0;

  (async () => {
    // Simulate generating 20 tokens
    const tokens = ["Hello", "user,", "this", "is", "a", "streaming", "response", "with", "cost", "tracking."];
    
    for (const token of tokens) {
      // 1. Yield Token
      stream.update({ type: 'token', content: token + ' ' });
      
      // 2. Simulate Cost (e.g., 1 token = 1 usage unit)
      totalUsage += 1; 
      
      // 3. Yield Usage Update
      stream.update({ type: 'usage', count: totalUsage });
      
      await setTimeout(200); // Simulate processing time
    }
    
    stream.done();
  })();

  return stream.value;
}

// CLIENT COMPONENT (app/components/LiveChatWithCost.tsx)
'use client';

import { useState, useEffect } from 'react';
import { readStreamableValue } from 'ai/stream';

// Discriminated Union Type
type StreamChunk = 
  | { type: 'token'; content: string }
  | { type: 'usage'; count: number };

export function LiveChatWithCost() {
  const [chatHistory, setChatHistory] = useState<string>('');
  const [currentUsage, setCurrentUsage] = useState<number>(0);
  const [isBudgetMode, setIsBudgetMode] = useState<boolean>(false);
  const [budgetLimit, setBudgetLimit] = useState<number>(5);
  const [status, setStatus] = useState<'idle' | 'streaming' | 'cancelled' | 'exceeded'>('idle');
  
  // Abort Controller for cancelling the stream
  const [controller, setController] = useState<AbortController | null>(null);

  const startStream = async () => {
    // Reset state
    setChatHistory('');
    setCurrentUsage(0);
    setStatus('streaming');

    // Create AbortController
    const newController = new AbortController();
    setController(newController);

    try {
      // In a real app, pass signal to fetch options
      const streamValue = await generateStreamWithUsage('dummy prompt');
      
      for await (const chunk of readStreamableValue(streamValue)) {
        // Check Budget Mode logic BEFORE processing
        if (isBudgetMode && currentUsage >= budgetLimit) {
          // This check happens inside the loop, but usually we check after state update
          // Let's handle the "Exceeded" state in the usage update handler below
        }

        const data = chunk as StreamChunk;

        if (data.type === 'token') {
          setChatHistory(prev => prev + data.content);
        } else if (data.type === 'usage') {
          const newUsage = data.count;
          setCurrentUsage(newUsage);

          // BUDGET LOGIC
          if (isBudgetMode) {
            // Check 80%
            if (newUsage >= budgetLimit * 0.8 && newUsage < budgetLimit) {
              // Visual indicator handled in JSX
            }
            // Check 100% (Exceeded)
            else if (newUsage >= budgetLimit) {
              setStatus('exceeded');
              // Trigger Cancellation
              if (controller) {
                controller.abort();
              }
              // Break loop or return
              return; 
            }
          }
        }
      }
      
      if (status !== 'exceeded') {
        setStatus('idle');
      }

    } catch (error) {
      if (error instanceof DOMException && error.name === 'AbortError') {
        setStatus('cancelled');
        console.log('Stream aborted due to budget limit.');
      } else {
        console.error('Stream error:', error);
        setStatus('idle');
      }
    }
  };

  // Cleanup effect
  useEffect(() => {
    return () => {
      if (controller) {
        controller.abort();
      }
    };
  }, [controller]);

  // Determine Cost Indicator Color
  const getCostColor = () => {
    if (status === 'exceeded') return 'red';
    if (isBudgetMode && currentUsage >= budgetLimit * 0.8) return 'yellow';
    return 'green';
  };

  return (
    <div style={{ padding: '20px', border: '1px solid #ddd' }}>
      <h3>Live Chat with Cost</h3>
      
      {/* Controls */}
      <div style={{ marginBottom: '15px', display: 'flex', gap: '10px', alignItems: 'center' }}>
        <button onClick={startStream} disabled={status === 'streaming'}>
          {status === 'streaming' ? 'Generating...' : 'Start Stream'}
        </button>
        
        <label>
          <input 
            type="checkbox" 
            checked={isBudgetMode} 
            onChange={(e) => setIsBudgetMode(e.target.checked)} 
          />
          Budget Mode
        </label>

        {isBudgetMode && (
          <input 
            type="number" 
            value={budgetLimit} 
            onChange={(e) => setBudgetLimit(Number(e.target.value))}
            style={{ width: '60px' }}
            placeholder="Limit"
          />
        )}
      </div>

      {/* Chat Area */}
      <div style={{ border: '1px solid #eee', padding: '10px', minHeight: '100px', marginBottom: '10px' }}>
        {chatHistory || <em>Stream output will appear here...</em>}
        {status === 'streaming' && <span style={{ animation: 'blink 1s infinite' }}>|</span>}
      </div>

      {/* Cost Indicator */}
      <div style={{ 
        padding: '10px', 
        fontWeight: 'bold', 
        backgroundColor: getCostColor(),
        color: getCostColor() === 'yellow' ? 'black' : 'white',
        transition: 'background-color 0.3s'
      }}>
        Usage: {currentUsage} {isBudgetMode ? `/ ${budgetLimit}` : ''} Tokens
        {status === 'exceeded' && ' - BUDGET EXCEEDED! STREAM CANCELLED.'}
        {status === 'cancelled' && ' - Stream Cancelled.'}
      </div>
    </div>
  );
}

// Mock Server Action for the example to compile/run conceptually
async function generateStreamWithUsage(prompt: string) {
  // Implementation from server side above
  return { /* mock streamable value */ };
}
