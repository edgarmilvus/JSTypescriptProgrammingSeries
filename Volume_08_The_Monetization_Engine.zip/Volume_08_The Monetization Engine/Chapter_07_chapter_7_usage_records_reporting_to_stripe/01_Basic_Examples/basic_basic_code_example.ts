/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

// ==========================================
// stripe-usage-reporter.ts
// A self-contained TypeScript example for reporting usage.
// ==========================================

/**
 * Mocks the Stripe Node.js library.
 * In a real application, you would import: `import Stripe from 'stripe';`
 */
class MockStripe {
  private subscriptions: Map<string, any> = new Map();

  constructor() {
    // Seed some mock data: A subscription item ID that we will report usage against.
    this.subscriptions.set('si_123456789', {
      id: 'si_123456789',
      plan: { interval: 'month' },
      // We track the last reported usage to simulate cumulative logic
      lastReportedUsage: 0 
    });
  }

  /**
   * Mocks `stripe.subscriptionItems.createUsageRecord`
   * @param itemID - The ID of the subscription item (e.g., 'si_...')
   * @param params - The usage record data (quantity, timestamp)
   */
  async createUsageRecord(itemID: string, params: { quantity: number; timestamp: number }) {
    const subItem = this.subscriptions.get(itemID);
    if (!subItem) {
      throw new Error(`Subscription item ${itemID} not found.`);
    }

    // Simulate Stripe API latency
    await new Promise(resolve => setTimeout(resolve, 100));

    console.log(`[Stripe API] Received Usage Report for ${itemID}:`);
    console.log(`   - Quantity: ${params.quantity}`);
    console.log(`   - Timestamp: ${new Date(params.timestamp * 1000).toISOString()}`);
    
    // Mock response object
    return {
      id: `ur_${Math.random().toString(36).substring(7)}`,
      object: 'usage_record',
      quantity: params.quantity,
      timestamp: params.timestamp,
      subscription_item: itemID
    };
  }
}

// Initialize the mock Stripe client
const stripe = new MockStripe();

/**
 * Interface representing our internal database record for a user's meter.
 */
interface UserMeter {
  userId: string;
  subscriptionItemId: string;
  currentUsageCount: number; // The usage accumulated since the last report
}

/**
 * The main reporting function.
 * 1. Fetches internal usage data.
 * 2. Formats the data for Stripe.
 * 3. Sends the report.
 * 4. (Crucial) Resets/Updates internal state to prevent double billing.
 */
async function reportUsageToStripe(meter: UserMeter): Promise<void> {
  console.log(`\n--- Processing User: ${meter.userId} ---`);
  
  // 1. Check if there is anything to report
  if (meter.currentUsageCount === 0) {
    console.log("No new usage to report. Skipping.");
    return;
  }

  // 2. Prepare the payload
  // In Cumulative Reporting, we send the *total* usage for the current billing period.
  // Stripe calculates the difference between the last report and this one.
  const usageRecordParams = {
    quantity: meter.currentUsageCount,
    timestamp: Math.floor(Date.now() / 1000), // Current Unix timestamp
  };

  try {
    // 3. Call the Stripe API
    const response = await stripe.createUsageRecord(
      meter.subscriptionItemId,
      usageRecordParams
    );

    console.log(`✅ Successfully reported usage. Stripe ID: ${response.id}`);

    // 4. Post-Report Logic (Critical for Data Integrity)
    // In a real app, you would now archive these usage logs or reset the counter
    // so you don't report the same events again next time.
    meter.currentUsageCount = 0; 
    console.log("Internal meter reset to 0.");

  } catch (error) {
    // 5. Error Handling
    // If this fails, you must NOT reset the counter. It should retry later.
    console.error("❌ Failed to report usage:", error);
    throw error; // Bubble up to be handled by a retry mechanism (e.g., BullMQ, AWS SQS)
  }
}

/**
 * Simulation Runner
 * (This mimics a cron job or a background worker processing a queue)
 */
(async () => {
  // Simulate a user who has accumulated 150 API calls since the last report
  const myUserMeter: UserMeter = {
    userId: 'user_999',
    subscriptionItemId: 'si_123456789',
    currentUsageCount: 150 
  };

  await reportUsageToStripe(myUserMeter);
})();
