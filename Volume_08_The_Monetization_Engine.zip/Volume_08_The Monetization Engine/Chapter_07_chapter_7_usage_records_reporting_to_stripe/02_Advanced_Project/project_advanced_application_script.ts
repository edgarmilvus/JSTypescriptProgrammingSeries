/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// app/api/usage/ingest/route.ts

import { NextResponse } from 'next/server';
import Stripe from 'stripe';
import { Database } from '@/lib/database'; // Hypothetical Vector DB client

// Initialize Stripe with the secret key
const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, {
  apiVersion: '2023-10-16', // Ensure you use the latest stable version
});

// Configure for Edge Runtime to leverage low-latency global execution
export const runtime = 'edge';

/**
 * POST /api/usage/ingest
 * 
 * Objective: 
 * 1. Receive high-volume usage events from a SaaS client.
 * 2. Aggregate usage data and report to Stripe Usage Records.
 * 3. Analyze usage velocity to trigger AI Customer Support Agents for churn prevention.
 * 
 * Context: Book 8, Chapter 7 - Usage Records Reporting to Stripe
 */

export async function POST(req: Request) {
  try {
    // 1. Parse the incoming usage payload
    const body = await req.json();
    const { 
      customerId, 
      subscriptionItemId, 
      timestamp, 
      metricValue, // e.g., API calls, seats, storage (GB)
      eventType 
    } = body;

    // Validation: Ensure required fields exist
    if (!customerId || !subscriptionItemId || !metricValue) {
      return NextResponse.json(
        { error: 'Missing required usage parameters.' },
        { status: 400 }
      );
    }

    // 2. Local Aggregation & Deduplication (Cumulative Reporting Strategy)
    // In a production environment, we might use Redis or a buffer here.
    // For this script, we simulate a "flush" of a single event to Stripe.
    // Stripe's Usage Records API is idempotent if we provide a unique 'timestamp' 
    // or 'idempotency_key' to prevent double-billing during retries.
    
    const usageRecord = await stripe.subscriptionItems.createUsageRecord(
      subscriptionItemId,
      {
        quantity: metricValue,
        timestamp: Math.floor(new Date(timestamp).getTime() / 1000), // Unix timestamp
        action: 'increment', // 'increment' adds to the current period, 'set' overwrites
      },
      {
        idempotencyKey: `usage_${customerId}_${timestamp}_${eventType}`, // Critical for high-volume
      }
    );

    // 3. AI Agent Trigger Logic: Churn Prevention Analysis
    // We analyze the 'velocity' of usage. A sudden drop or spike can indicate 
    // churn risk or account misuse. We query a Vector Database for historical context.
    
    // Simulate fetching historical usage pattern from Vector DB (Upsert/Query operation)
    // In Book 5, we discussed using Vector DBs for storing user behavior embeddings.
    const accountContext = await Database.query('user_embeddings', {
      vector: generateEmbedding(metricValue, eventType), // Hypothetical embedding function
      topK: 1,
      filter: { customerId },
    });

    const historicalAverage = accountContext[0]?.metadata?.avgUsage || 0;
    
    // Logic: Trigger AI Agent if usage drops > 80% below average (Churn Risk)
    // OR if usage spikes > 200% (Potential Fraud/Scaling Opportunity)
    const usageDeviation = metricValue / (historicalAverage || 1);
    const isChurnRisk = usageDeviation < 0.2; // 80% drop
    const isUpsellOpportunity = usageDeviation > 2.0; // 2x spike

    if (isChurnRisk) {
      // 4. Trigger Smart Dunning & AI Support Agent
      // Instead of waiting for the next billing cycle to fail, we proactively engage.
      
      await triggerAISupportAgent({
        customerId,
        reason: 'usage_drop_churn_risk',
        context: `Current usage (${metricValue}) is ${(usageDeviation * 100).toFixed(0)}% of historical average.`,
        priority: 'high',
      });

      // Optional: Update Stripe Metadata for downstream billing logic
      await stripe.customers.update(customerId, {
        metadata: { 
          last_risk_check: new Date().toISOString(),
          risk_score: 'high' 
        }
      });
    }

    // 5. Return Success
    return NextResponse.json(
      { 
        status: 'success', 
        data: { 
          usageRecordId: usageRecord.id, 
          reportedQuantity: usageRecord.quantity,
          aiTriggered: isChurnRisk 
        } 
      },
      { status: 200 }
    );

  } catch (error: any) {
    console.error('Usage Ingestion Error:', error);
    
    // Handle Stripe specific errors (e.g., subscription not active)
    if (error instanceof Stripe.errors.StripeError) {
      return NextResponse.json({ error: error.message }, { status: 402 });
    }

    return NextResponse.json({ error: 'Internal Server Error' }, { status: 500 });
  }
}

/**
 * HELPER: Trigger AI Customer Support Agent
 * 
 * Simulates calling an AI agent endpoint (e.g., a LangChain or Vercel AI SDK route)
 * to draft a proactive email or Slack notification to the account manager.
 */
async function triggerAISupportAgent(params: {
  customerId: string;
  reason: string;
  context: string;
  priority: string;
}) {
  // In a real app, this would fetch the customer's recent logs 
  // and generate a personalized outreach message.
  console.log(`[AI Agent Triggered]: Customer ${params.customerId} - ${params.reason}`);
  
  // Simulate API call to AI Agent Service
  await new Promise(resolve => setTimeout(resolve, 100)); // Mock latency
  return { agentId: 'agent_123', draftCreated: true };
}

/**
 * HELPER: Generate Embedding
 * Placeholder for Book 5 logic: Local AI & Production
 * Converts usage metrics into a vector for similarity search.
 */
function generateEmbedding(value: number, type: string): number[] {
  // In production, use a local AI model (e.g., ONNX) or external API
  // to convert usage data into a high-dimensional vector.
  // For this script, we return a mock vector.
  return Array(1536).fill(value * 0.001); 
}
