/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

import Stripe from 'stripe';

// Mock Stripe instance (in a real app, initialize with your secret key)
const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, { apiVersion: '2022-11-15' });

/**
 * Reports usage to Stripe with resilience against transient errors.
 * @param customerId - The Stripe Customer ID.
 * @param priceId - The Stripe Price ID associated with the usage.
 * @param quantity - The number of units to report.
 */
export async function reportUsageToStripe(
  customerId: string,
  priceId: string,
  quantity: number
): Promise<void> {
  const MAX_RETRIES = 3;
  let attempt = 0;

  // Simulating external resource management (e.g., a database connection)
  // In a real app, you would open this connection here.
  let dbConnection: any = null; 

  try {
    // Simulate acquiring a resource
    dbConnection = { status: 'open', close: () => console.log("Database connection closed.") };

    while (attempt < MAX_RETRIES) {
      try {
        attempt++;
        console.log(`Attempt ${attempt}: Reporting ${quantity} units for customer ${customerId}...`);

        // Simulate the Stripe API call
        // In a real app: await stripe.subscriptionItems.createUsageRecord(...)
        if (Math.random() > 0.7) { // Simulate random failure (30% chance)
            throw new Error("Stripe API 502 Bad Gateway");
        }

        // Success case
        console.log("Success: Usage reported to Stripe.");
        return; // Exit function immediately on success

      } catch (error: any) {
        console.error(`Attempt Failed: ${error.message}`);
        
        if (attempt === MAX_RETRIES) {
          // We have exhausted all retries
          console.error("Retry Exhausted: Max attempts reached. Data lost or queued for manual retry.");
          throw error; // Re-throw the error to notify the caller
        }

        // Exponential Backoff: Wait 1s, 2s, 4s...
        const delay = Math.pow(2, attempt - 1) * 1000;
        console.log(`Waiting ${delay}ms before retry...`);
        await new Promise(resolve => setTimeout(resolve, delay));
      }
    }
  } finally {
    // Resource Management: Ensure cleanup happens regardless of success/failure
    if (dbConnection) {
      dbConnection.close();
    }
  }
}

// Example Usage (Uncomment to test):
// reportUsageToStripe('cus_123', 'price_abc', 10).catch(console.error);
