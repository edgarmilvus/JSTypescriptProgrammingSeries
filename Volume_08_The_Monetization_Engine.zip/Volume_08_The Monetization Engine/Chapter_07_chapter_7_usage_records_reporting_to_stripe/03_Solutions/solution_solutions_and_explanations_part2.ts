/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

interface UsageEvent {
  userId: string;
  timestamp: number;
  units: number;
}

// Mock Database Functions
const mockDb: Record<string, number> = {}; // Stores last reported timestamp per user

function getLastReportedTimestamp(userId: string): number {
  return mockDb[userId] || 0; // Default to 0 (epoch) if never reported
}

function saveCurrentTimestamp(userId: string, timestamp: number): void {
  mockDb[userId] = timestamp;
  console.log(`Saved new timestamp ${timestamp} for user ${userId}`);
}

/**
 * Aggregates usage events occurring after the last reported timestamp.
 * @param events - Array of raw usage events.
 * @returns An object containing the total quantity and the new last timestamp.
 */
export function aggregateAndReport(events: UsageEvent[]): { quantity: number; newLastTimestamp: number } {
  if (events.length === 0) {
    return { quantity: 0, newLastTimestamp: 0 };
  }

  // Determine the user ID (assuming all events in a batch belong to the same user for simplicity)
  const userId = events[0].userId;
  
  // 1. Get the last reported timestamp to prevent double counting
  const lastReportedTimestamp = getLastReportedTimestamp(userId);

  // 2. Filter events: Only include those strictly after the last reported time
  const newEvents = events.filter(event => event.timestamp > lastReportedTimestamp);

  // 3. Aggregate the units
  const totalUnits = newEvents.reduce((sum, event) => sum + event.units, 0);

  // 4. Determine the new last timestamp (the max timestamp in the processed batch)
  const newLastTimestamp = newEvents.length > 0
    ? Math.max(...newEvents.map(e => e.timestamp))
    : lastReportedTimestamp; // Keep old timestamp if no new events

  // 5. Persist the new state
  if (newEvents.length > 0) {
    saveCurrentTimestamp(userId, newLastTimestamp);
  }

  return {
    quantity: totalUnits,
    newLastTimestamp: newLastTimestamp
  };
}

// Example Usage:
// const events = [
//   { userId: 'user_1', timestamp: 100, units: 5 },
//   { userId: 'user_1', timestamp: 120, units: 3 },
//   { userId: 'user_1', timestamp: 90, units: 2 } // Older event, should be ignored if last reported was 100
// ];
// console.log(aggregateAndReport(events));
