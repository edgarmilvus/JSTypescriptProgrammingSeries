/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

'use client'; // Mark as Client Component for interactivity

import { useState, useEffect } from 'react';

// Define the shape of the data expected from the API
interface DunningPrediction {
  customerId: string;
  name: string;
  usageDropPercentage: number;
  status: 'AT_RISK' | 'WARNING';
}

// Mock function to simulate the API call
const fetchDunningData = async (): Promise<DunningPrediction[]> => {
  // In a real app, this would be: const res = await fetch('/api/admin/dunning-predictions');
  return [
    { customerId: 'cus_1', name: 'Acme Corp', usageDropPercentage: 65, status: 'AT_RISK' },
    { customerId: 'cus_2', name: 'Globex Inc', usageDropPercentage: 20, status: 'WARNING' },
    { customerId: 'cus_3', name: 'Soylent Corp', usageDropPercentage: 80, status: 'AT_RISK' },
  ];
};

// Mock function for the action
const triggerAgent = (customerId: string) => {
  console.log(`Triggering AI Support Agent for customer: ${customerId}`);
  alert(`AI Agent triggered for ${customerId}`);
};

export default function DunningMonitor() {
  const [predictions, setPredictions] = useState<DunningPrediction[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchDunningData().then((data) => {
      setPredictions(data);
      setLoading(false);
    });
  }, []);

  if (loading) return <div>Loading predictions...</div>;

  return (
    <div style={{ padding: '20px', fontFamily: 'sans-serif' }}>
      <h1>Smart Dunning Monitor</h1>
      <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
        {predictions.map((customer) => (
          <div
            key={customer.customerId}
            style={{
              padding: '15px',
              borderRadius: '8px',
              border: '1px solid #ddd',
              // Conditional Styling based on status
              backgroundColor: customer.status === 'AT_RISK' ? '#ffebee' : '#fffde7', // Red for Risk, Yellow for Warning
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
            }}
          >
            <div>
              <h3 style={{ margin: 0 }}>{customer.name}</h3>
              <p style={{ margin: '5px 0 0 0', color: '#555' }}>
                Status: <strong>{customer.status}</strong>
              </p>
              <p style={{ margin: '5px 0 0 0', fontWeight: 'bold' }}>
                Usage Drop: {customer.usageDropPercentage}%
              </p>
            </div>
            <button
              onClick={() => triggerAgent(customer.customerId)}
              style={{
                padding: '8px 16px',
                backgroundColor: '#0070f3',
                color: 'white',
                border: 'none',
                borderRadius: '4px',
                cursor: 'pointer',
              }}
            >
              Trigger AI Support Agent
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}
