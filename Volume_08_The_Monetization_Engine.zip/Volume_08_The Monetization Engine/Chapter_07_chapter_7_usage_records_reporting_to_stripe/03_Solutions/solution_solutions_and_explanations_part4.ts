/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

import { tool } from 'ai';
import { z } from 'zod';

// 1. Tool Definition using Vercel AI SDK and Zod for schema validation
export const draftChurnPreventionEmailTool = tool({
  // The description helps the AI decide WHEN to use this tool
  description: 'Drafts a personalized email to a customer whose usage has dropped significantly, offering an incentive to stay.',
  
  // 2. Tool Parameters defined with Zod
  parameters: z.object({
    customerName: z.string().describe('The name of the customer'),
    reason: z.string().describe('The specific reason for the churn risk, e.g., "Usage dropped by 50%"'),
    offer: z.string().describe('The retention offer to propose, e.g., "20% discount for next month"'),
  }),

  // 3. Tool Execution Logic
  execute: async ({ customerName, reason, offer }) => {
    // In a real app, this might save to a database or send an email via SendGrid
    // Here we simply return the formatted string as requested.
    return `Draft created for ${customerName}: ${reason}. Proposed offer: ${offer}`;
  },
});

// 4. System Prompt for the AI
export const systemPrompt = `
You are a proactive account manager AI. 
Your goal is to prevent customer churn. 
When you analyze customer data and detect a significant drop in usage (e.g., > 40%), 
you must immediately use the 'draftChurnPreventionEmail' tool. 
You must provide a personalized reason for the drop and suggest a relevant offer 
(like a discount or feature training) to retain the customer.
`;
