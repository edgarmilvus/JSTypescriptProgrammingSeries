/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

digraph RaceCondition {
    rankdir=LR;
    node [shape=box, style=rounded];

    ProcessA [label="Process A (Add 10)"];
    ProcessB [label="Process B (Add 5)"];
    DB [label="Database (Version 1, Usage 100)"];

    // Step 1: Both read
    ProcessA -> DB [label="1. Read (Ver=1, Usage=100)"];
    ProcessB -> DB [label="2. Read (Ver=1, Usage=100)"];

    // Step 2: Process A updates first
    ProcessA -> DB [label="3. Update: Usage=110, Ver=2 (WHERE Ver=1)"];
    
    // Step 3: Process B tries to update but fails condition
    ProcessB -> DB [label="4. Update: Usage=105, Ver=2 (WHERE Ver=1)"];
    
    // Step 4: DB responds to B that update failed (0 rows affected)
    DB -> ProcessB [label="5. Update Failed (Row not found/Version mismatch)"];

    // Step 5: Process B retries logic
    ProcessB -> ProcessB [label="6. Retry: Read New Ver (2), Recalculate, Update"];
}
