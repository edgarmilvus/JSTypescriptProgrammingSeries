/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

import { Stripe } from 'stripe';
import { createClient } from '@supabase/supabase-js';

// ============================================================================
// 1. CONFIGURATION & CLIENT INITIALIZATION
// ============================================================================

// Initialize Stripe with the secret key (Server-side only)
const stripe = new Stripe(process.env.STRIPE_SECRET_KEY as string, {
  apiVersion: '2023-10-16', // Ensure API version compatibility
});

// Initialize Supabase client for database verification
const supabase = createClient(
  process.env.SUPABASE_URL as string,
  process.env.SUPABASE_SERVICE_ROLE_KEY as string // Use service role for backend
);

// ============================================================================
// 2. TYPE DEFINITIONS
// ============================================================================

/**
 * Request body expected from the frontend client.
 * @property amount - Total amount in cents (e.g., $100.00 = 10000).
 * @property sellerAccountId - The Stripe Connect ID of the seller (e.g., 'acct_123...').
 * @property platformFee - The fee the platform keeps in cents.
 */
interface CreateSplitPaymentRequest {
  amount: number;
  sellerAccountId: string;
  platformFee: number;
}

/**
 * Database record for storing transaction logs.
 */
interface TransactionLog {
  id?: string;
  payment_intent_id: string;
  seller_id: string;
  amount_received: number;
  platform_fee: number;
  status: 'pending' | 'succeeded' | 'failed';
  created_at?: string;
}

// ============================================================================
// 3. CORE LOGIC: SPLIT PAYMENT HANDLER
// ============================================================================

/**
 * Handles the creation of a split payment intent and records the transaction.
 * Implements Exhaustive Asynchronous Resilience via try/catch/finally blocks.
 * 
 * @param req - Express Request object containing payment details.
 * @param res - Express Response object.
 */
export async function createSplitPayment(req: any, res: any) {
  const { amount, sellerAccountId, platformFee } = req.body as CreateSplitPaymentRequest;

  // --- Pre-validation ---
  if (amount <= 0 || platformFee < 0 || platformFee >= amount) {
    return res.status(400).json({ error: 'Invalid amount or platform fee configuration.' });
  }

  // Calculate the transfer amount (Total - Platform Fee)
  const transferAmount = amount - platformFee;

  // Transaction log entry to be saved to Supabase
  const transactionLog: TransactionLog = {
    payment_intent_id: '', // Will be populated after creation
    seller_id: sellerAccountId,
    amount_received: transferAmount,
    platform_fee: platformFee,
    status: 'pending',
  };

  try {
    // --- STEP 1: Create Payment Intent with Application Fee ---
    // This instructs Stripe to hold the funds and calculate the split.
    const paymentIntent = await stripe.paymentIntents.create({
      amount: amount,
      currency: 'usd',
      application_fee_amount: platformFee, // The platform's cut
      transfer_data: {
        destination: sellerAccountId, // The seller's connected account ID
      },
    });

    // Update log with the generated ID
    transactionLog.payment_intent_id = paymentIntent.id;

    // --- STEP 2: Log Transaction to Database (Supabase) ---
    // We persist the intent ID immediately for tracking, even before confirmation.
    const { error: dbError } = await supabase
      .from('marketplace_transactions')
      .insert([transactionLog]);

    if (dbError) {
      // Critical: Log the error but do not stop the payment flow.
      // The payment intent exists in Stripe; we just failed to log locally.
      console.error('Supabase Logging Error:', dbError.message);
      // We proceed, but this requires a reconciliation job later.
    }

    // --- STEP 3: Return Client Secret to Frontend ---
    // The frontend uses this secret to confirm the payment on the client side.
    return res.status(200).json({
      clientSecret: paymentIntent.client_secret,
      paymentIntentId: paymentIntent.id,
    });

  } catch (error: any) {
    // --- STEP 4: ERROR HANDLING (Exhaustive Resilience) ---
    // Catch block handles Stripe errors (e.g., insufficient funds, invalid account).
    
    console.error('Payment Processing Error:', error.message);

    // Update log status to failed if possible (requires ID, which we might have)
    if (transactionLog.payment_intent_id) {
      await supabase
        .from('marketplace_transactions')
        .update({ status: 'failed' })
        .eq('payment_intent_id', transactionLog.payment_intent_id);
    }

    return res.status(500).json({
      error: 'Payment processing failed.',
      details: error.message,
    });

  } finally {
    // --- STEP 5: RESOURCE CLEANUP ---
    // Although Stripe connections are stateless, this block ensures
    // any open database connections or temporary variables are cleared.
    // In a real scenario, this might close specific connection pools.
    console.log('Execution cycle completed for split payment.');
  }
}
