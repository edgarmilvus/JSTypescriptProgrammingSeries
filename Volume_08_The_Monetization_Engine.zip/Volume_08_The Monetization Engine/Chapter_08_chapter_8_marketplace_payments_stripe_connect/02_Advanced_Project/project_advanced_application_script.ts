/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// pages/api/marketplace/payouts.ts
// Target: Next.js 13+ (App Router or Pages Router compatible)
// Dependencies: stripe (npm install stripe @types/stripe)

import { NextApiRequest, NextApiResponse } from 'next';
import Stripe from 'stripe';

// Initialize Stripe with secret key
const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, {
  apiVersion: '2023-10-16', // Use the latest stable version
});

/**
 * Interface for the incoming request payload.
 * Represents a marketplace order where the platform takes a commission.
 */
interface PayoutRequest {
  orderId: string;
  buyerPaymentIntentId: string; // The ID of the PaymentIntent created by the buyer
  sellerAccountId: string;      // The Stripe Connect ID of the seller
  platformFeeBps: number;       // Platform fee in basis points (e.g., 100 = 1%)
}

/**
 * Helper: Validates the incoming request body.
 */
const validateRequest = (body: any): body is PayoutRequest => {
  return (
    !!body.orderId &&
    !!body.buyerPaymentIntentId &&
    !!body.sellerAccountId &&
    typeof body.platformFeeBps === 'number'
  );
};

/**
 * API Handler: Processes a marketplace payout using Stripe Connect.
 * Implements SSE for real-time status updates.
 */
export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  // 1. Method Validation
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method Not Allowed' });
  }

  // 2. Input Validation
  if (!validateRequest(req.body)) {
    return res.status(400).json({ error: 'Invalid request payload' });
  }

  const { orderId, buyerPaymentIntentId, sellerAccountId, platformFeeBps } = req.body;

  // 3. Server-Sent Events (SSE) Setup
  // We set headers to keep the connection open for streaming updates.
  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache');
  res.setHeader('Connection', 'keep-alive');
  res.flushHeaders(); // Flush headers immediately to establish the stream

  /**
   * Helper: Sends a status update to the client via SSE.
   * @param status - The current stage of the process.
   * @param message - Human-readable message.
   */
  const sendUpdate = (status: string, message: string) => {
    const data = JSON.stringify({ orderId, status, message, timestamp: new Date().toISOString() });
    res.write(`data: ${data}\n\n`);
  };

  try {
    // --- LOGIC BLOCK 1: VERIFY EXISTING PAYMENT ---
    sendUpdate('VERIFYING', 'Verifying buyer payment intent...');
    
    // Retrieve the PaymentIntent to ensure it was successful
    const paymentIntent = await stripe.paymentIntents.retrieve(buyerPaymentIntentId);
    
    if (paymentIntent.status !== 'succeeded') {
      throw new Error(`PaymentIntent status is ${paymentIntent.status}, expected 'succeeded'.`);
    }

    // --- LOGIC BLOCK 2: CALCULATE SPLIT AMOUNTS ---
    sendUpdate('CALCULATING', 'Calculating platform fees and seller payout...');
    
    const totalAmount = paymentIntent.amount; // Amount in smallest currency unit (e.g., cents)
    const platformFee = Math.round(totalAmount * (platformFeeBps / 10000));
    const sellerPayout = totalAmount - platformFee;

    if (sellerPayout <= 0) {
      throw new Error('Invalid payout amount after fees.');
    }

    // --- LOGIC BLOCK 3: CREATE TRANSFER (SPLIT PAYMENT) ---
    sendUpdate('DISTRIBUTING', 'Creating Stripe Transfer to connected account...');
    
    // Create a Transfer to the seller's connected account.
    // This moves funds from the Platform's Stripe account to the Seller's.
    const transfer = await stripe.transfers.create({
      amount: sellerPayout,
      currency: 'usd',
      destination: sellerAccountId,
      description: `Payout for Order ${orderId}`,
      // Metadata for audit trails
      metadata: { 
        orderId, 
        platformFee: platformFee.toString() 
      },
    });

    // --- LOGIC BLOCK 4: RECORD PLATFORM FEE ---
    // In a real app, you might also create a separate Transfer to a platform-owned account
    // or simply record the fee as revenue. Here we simulate the deduction logic.
    sendUpdate('RECORDING', 'Recording platform fees...');

    // --- LOGIC BLOCK 5: COMPLETION ---
    sendUpdate('COMPLETED', `Funds distributed successfully. Transfer ID: ${transfer.id}`);
    
    // Close the SSE connection
    res.end();

  } catch (error: any) {
    // --- EXHAUSTIVE ASYNCHRONOUS RESILIENCE ---
    // Catch block handles errors from Stripe API or logic validation.
    // We stream the error to the client rather than just crashing or sending a one-off JSON response.
    
    const errorMessage = error.message || 'An unknown error occurred during payout processing.';
    console.error(`[Marketplace Payout Error] Order: ${orderId}`, error);

    sendUpdate('ERROR', errorMessage);
    
    // Ensure the connection is closed after sending the error
    res.end();
  }
}
