/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.tsx
// Description: Solutions and Explanations
// ==========================================

// File: components/SellerOnboarding.tsx
import React, { useState } from 'react';

// Define the shape of the API response from your backend
type AccountLinkResponse = {
  url: string;
};

export const SellerOnboarding: React.FC = () => {
  // State for loading status
  const [isLoading, setIsLoading] = useState<boolean>(false);
  // State for error messages
  const [error, setError] = useState<string | null>(null);

  const handleConnectClick = async () => {
    // Reset previous errors and start loading
    setError(null);
    setIsLoading(true);

    try {
      // Assume we have the stripeAccountId available (e.g., from context or props)
      // For this example, we'll hardcode a placeholder or fetch it dynamically
      const stripeAccountId = "acct_123456789"; 

      const response = await fetch('/api/stripe/create-account-link', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ stripeAccountId }),
      });

      if (!response.ok) {
        throw new Error('Failed to create account link. Please try again.');
      }

      const data: AccountLinkResponse = await response.json();

      // Redirect the user to the Stripe onboarding URL
      if (data.url) {
        window.location.href = data.url;
      } else {
        throw new Error('Invalid response from server.');
      }
    } catch (err) {
      // Handle errors gracefully
      const errorMessage = err instanceof Error ? err.message : 'An unknown error occurred.';
      setError(errorMessage);
      setIsLoading(false); // Stop loading so user can retry
    }
  };

  return (
    <div className="p-6 bg-white rounded-lg shadow-md max-w-md mx-auto">
      <h2 className="text-xl font-semibold mb-4">Connect Your Bank Account</h2>
      
      {/* Error Message Display */}
      {error && (
        <div className="mb-4 p-3 bg-red-100 text-red-700 rounded border border-red-200">
          {error}
        </div>
      )}

      {/* Action Button */}
      <button
        onClick={handleConnectClick}
        disabled={isLoading}
        className={`w-full py-2 px-4 rounded text-white font-medium transition-colors ${
          isLoading 
            ? 'bg-gray-400 cursor-not-allowed' 
            : 'bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2'
        }`}
      >
        {isLoading ? 'Redirecting...' : 'Start Onboarding'}
      </button>
    </div>
  );
};
