/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

// File: logic/payout.ts
import Stripe from 'stripe';
import { db } from './database'; // Hypothetical database client

// Define the function signature for processing a payout
export async function processPayout(transactionId: string): Promise<'success' | 'failed'> {
  try {
    // 1. Fetch transaction details from the database
    const transaction = await db.transactions.findUnique({
      where: { id: transactionId },
    });

    if (!transaction) {
      console.error(`Transaction ${transactionId} not found.`);
      return 'failed';
    }

    // 2. Verify the transaction is in a state that allows payout
    // Note: The requirement asked for 'completed', but the schema in the prompt
    // does not have a 'paid_out' status. We assume 'completed' means funds are ready.
    if (transaction.status !== 'completed') {
      console.error(`Transaction ${transactionId} is not in a completable state: ${transaction.status}`);
      return 'failed';
    }

    // Initialize Stripe
    const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, {
      apiVersion: '2023-10-16',
    });

    // 3. Use Stripe's API to create a transfer to the seller's connected account
    // We assume the platform has already charged the buyer and the funds are 
    // in the platform's Stripe account (Destination Charge or Separate Auth & Capture).
    const transfer = await stripe.transfers.create({
      amount: transaction.amount_seller_payout,
      currency: 'usd',
      destination: transaction.seller_stripe_account_id, // ID of the seller's connected account
      description: `Payout for Transaction ${transaction.id}`,
    });

    // 4. Handle potential Stripe errors (e.g., insufficient funds, account issues)
    // (Stripe SDK throws exceptions on error, caught by the catch block)

    // 5. Update the transaction status in the database
    // Note: The schema provided in the prompt didn't have a 'paid_out' status, 
    // but the logic requires it. We will assume we update the status to 'completed' 
    // or a new status 'paid_out' if allowed. 
    // For this example, we will stick to the provided enum but mark it logically handled.
    await db.transactions.update({
      where: { id: transactionId },
      data: {
        status: 'completed', // Assuming 'completed' implies payout done, or add 'paid_out'
        stripe_transfer_id: transfer.id, // Store the transfer ID for reference
      },
    });

    return 'success';
  } catch (error) {
    // Log the error for debugging
    console.error(`Payout failed for transaction ${transactionId}:`, error);
    
    // Update DB status to reflect failure if necessary
    await db.transactions.update({
      where: { id: transactionId },
      data: { status: 'disputed' }, // Or a specific 'payout_failed' status
    });

    return 'failed';
  }
}
