/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

// File: routes/webhooks.ts
import express, { Request, Response } from 'express';
import Stripe from 'stripe';
import { db } from '../lib/database'; // Hypothetical DB import

const router = express.Router();
const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, {
  apiVersion: '2023-10-16',
});

// Webhook Secret from Stripe Dashboard
const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET!;

router.post('/webhooks/stripe', express.raw({ type: 'application/json' }), async (req: Request, res: Response) => {
  const sig = req.headers['stripe-signature'] as string;
  let event: Stripe.Event;

  // 1. Verify Event Signature
  try {
    event = stripe.webhooks.constructEvent(req.body, sig, webhookSecret);
  } catch (err) {
    const errorMessage = err instanceof Error ? err.message : 'Unknown error';
    console.error(`Webhook Error: ${errorMessage}`);
    // Return a 400 status to Stripe if verification fails
    return res.status(400).send(`Webhook Error: ${errorMessage}`);
  }

  // 2. Event Processing Logic
  try {
    // Handle the specific event type
    if (event.type === 'charge.dispute.created') {
      const dispute = event.data.object as Stripe.Dispute;
      
      // Extract relevant IDs
      // Disputes can be linked to a Charge ID. In a robust system, 
      // we map Charge IDs to our internal Transaction IDs.
      const chargeId = dispute.charge as string;
      
      // Find the transaction in our database associated with this charge
      // (Assuming we store the stripe_charge_id or payment_intent_id)
      const transaction = await db.transactions.findFirst({
        where: { stripe_payment_intent_id: dispute.payment_intent } 
      });

      if (transaction) {
        // Update transaction status to 'disputed'
        await db.transactions.update({
          where: { id: transaction.id },
          data: { status: 'disputed' },
        });

        // Trigger notification (Mock function)
        await notifyAdmins({
          subject: 'New Dispute Received',
          message: `Transaction ${transaction.id} has been disputed for amount ${dispute.amount}.`,
          disputeId: dispute.id,
        });
      } else {
        // 4. Error Handling: Transaction not found
        console.warn(`Dispute received for unknown transaction. Charge ID: ${chargeId}`);
        // We still return 200 to Stripe to acknowledge receipt, 
        // but we log this for manual investigation.
      }
    }

    // Return a 200 status to acknowledge receipt
    res.json({ received: true });
  } catch (error) {
    console.error('Error processing webhook:', error);
    // Return 500 to Stripe to trigger a retry
    res.status(500).send('Internal Server Error');
  }
});

// Mock notification function
async function notifyAdmins(details: any) {
  console.log('NOTIFICATION SENT:', details);
  // Integration with SendGrid, Slack API, etc. would go here
}

export default router;
