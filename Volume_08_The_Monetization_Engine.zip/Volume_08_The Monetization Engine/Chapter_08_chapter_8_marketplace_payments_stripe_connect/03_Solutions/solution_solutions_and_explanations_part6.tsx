/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part6.tsx
// Description: Solutions and Explanations
// ==========================================

// File: components/DisputeDashboard.tsx
import React, { useEffect, useState } from 'react';

interface Dispute {
  transaction_id: string;
  amount: number; // in cents
  status: 'pending' | 'under_review' | 'won' | 'lost';
}

export const DisputeDashboard: React.FC = () => {
  const [disputes, setDisputes] = useState<Dispute[]>([]);

  useEffect(() => {
    // 1. Establish SSE connection
    // Assuming the backend endpoint /events/disputes streams JSON data
    const eventSource = new EventSource('/events/disputes');

    // 2. Set up event listener for 'dispute_created'
    eventSource.onmessage = (event) => {
      try {
        const data: Dispute = JSON.parse(event.data);
        
        // 3. Update state with new dispute data
        // We prepend the new dispute to the top of the list
        setDisputes((prevDisputes) => [data, ...prevDisputes]);
      } catch (error) {
        console.error('Error parsing SSE data:', error);
      }
    };

    eventSource.onerror = (error) => {
      console.error('SSE Error:', error);
      // EventSource automatically retries on error, but we can handle specific logic here
      eventSource.close();
    };

    // 4. Cleanup function to close the EventSource
    return () => {
      eventSource.close();
    };
  }, []); // Empty dependency array ensures this runs once on mount

  return (
    <div className="p-6 bg-gray-50 min-h-screen">
      <h1 className="text-2xl font-bold mb-6">Real-Time Dispute Monitor</h1>
      
      {disputes.length === 0 ? (
        <p className="text-gray-500">Listening for new disputes...</p>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {/* 5. Map over disputes to render cards */}
          {disputes.map((dispute, index) => (
            <div 
              key={`${dispute.transaction_id}-${index}`} 
              className="bg-white p-4 rounded-lg shadow border-l-4 border-red-500"
            >
              <div className="flex justify-between items-start mb-2">
                <span className="font-mono text-sm text-gray-600">
                  {dispute.transaction_id}
                </span>
                <span className="text-xs font-bold uppercase px-2 py-1 rounded bg-red-100 text-red-800">
                  {dispute.status}
                </span>
              </div>
              <div className="text-lg font-semibold">
                ${(dispute.amount / 100).toFixed(2)}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
