/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part7.ts
// Description: Solutions and Explanations
// ==========================================

// File: lib/ai/disputeAgent.ts
import { Pinecone } from '@pinecone-database/pinecone';

// Define the interface for the context returned from Pinecone
interface DisputeContext {
  disputeText: string;
  resolution: string; // e.g., "Refunded to buyer", "Case dismissed"
  similarityScore: number;
}

/**
 * Queries the Pinecone vector database to find similar past disputes.
 * @param disputeDescription - The text description of the current dispute.
 * @returns A promise that resolves to an array of relevant dispute contexts.
 */
export async function getDisputeContext(disputeDescription: string): Promise<DisputeContext[]> {
  // 1. Initialize Pinecone client
  const pinecone = new Pinecone({
    environment: process.env.PINECONE_ENVIRONMENT!,
    apiKey: process.env.PINECONE_API_KEY!,
  });

  const indexName = 'dispute-resolutions';
  const index = pinecone.Index(indexName);

  // 2. Mock the embedding step
  // In a real application, you would send the description to an embedding model 
  // (e.g., OpenAI text-embedding-ada-002) to get a vector array of floats.
  // For this exercise, we generate a dummy vector of the correct dimension (e.g., 1536).
  const embeddingVector: number[] = Array(1536).fill(0).map(() => Math.random());

  try {
    // 3. Query the 'dispute-resolutions' index
    const queryResponse = await index.query({
      vector: embeddingVector,
      topK: 3, // Return top 3 matches
      includeMetadata: true, // Ensure metadata is returned
    });

    // 4. Format and return the top 3 results
    // Assuming the Pinecone index stores metadata with 'disputeText' and 'resolution'
    const results: DisputeContext[] = [];

    if (queryResponse.matches) {
      for (const match of queryResponse.matches) {
        if (match.metadata) {
          results.push({
            disputeText: match.metadata.disputeText as string,
            resolution: match.metadata.resolution as string,
            similarityScore: match.score || 0,
          });
        }
      }
    }

    return results;
  } catch (error) {
    console.error('Error querying Pinecone:', error);
    throw new Error('Failed to retrieve dispute context');
  }
}
