/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

// File: app/actions/taxAgentAction.ts
// Purpose: Server-side logic to handle tax inquiries securely.

'use server';

import { generateText } from 'ai'; // Assuming 'ai' package for LLM interaction
import { openai } from '@ai-sdk/openai'; // Example provider

/**
 * @description Simulates a database lookup for a user's invoice data.
 * In a real app, this would query a SQL/NoSQL database.
 * @param {string} invoiceId - The ID of the invoice to look up.
 * @returns {Promise<Object>} - Invoice details including tax amount and jurisdiction.
 */
async function fetchInvoiceData(invoiceId: string) {
  // Simulate network latency
  await new Promise((resolve) => setTimeout(resolve, 500));

  // Mock data: In a real scenario, this comes from Stripe or your DB
  return {
    id: invoiceId,
    amount: 49.00,
    currency: 'EUR',
    tax_amount: 9.31,
    tax_rate: 19.0, // German VAT rate
    jurisdiction: 'DE', // Germany
    description: 'Pro Plan Subscription (Oct 2023)',
  };
}

/**
 * @description Server Action to process tax inquiries.
 * This function is called directly from the client.
 * @param {Object} args - Arguments passed from the client.
 * @param {string} args.message - The user's input message.
 * @param {string} args.invoiceId - The specific invoice ID the user is asking about.
 */
export async function handleTaxInquiry({
  message,
  invoiceId,
}: {
  message: string;
  invoiceId: string;
}) {
  // 1. Securely fetch relevant tax data on the server
  const invoice = await fetchInvoiceData(invoiceId);

  // 2. Construct a prompt for the LLM using the retrieved data
  // This prevents hallucination by grounding the AI in facts.
  const systemPrompt = `
    You are a helpful customer support agent for a SaaS company.
    The user is asking about a charge on their invoice.
    Use the provided invoice data to explain the VAT charge clearly.
    Keep the tone professional and concise.
    
    Invoice Data:
    - Amount: ${invoice.amount} ${invoice.currency}
    - VAT Amount: ${invoice.tax_amount} ${invoice.currency}
    - VAT Rate: ${invoice.tax_rate}%
    - Jurisdiction: ${invoice.jurisdiction}
    - Description: ${invoice.description}
  `;

  // 3. Stream the response from the LLM
  // The 'ai' SDK handles the streaming connection.
  const { textStream } = await generateText({
    model: openai('gpt-3.5-turbo'),
    prompt: message,
    system: systemPrompt,
  });

  // 4. Return the stream to the client
  // In a real app, we might return a ReadableStream, but the AI SDK
  // often handles the response streaming directly to the client.
  // For this example, we will simulate the stream return.
  return textStream;
}
