/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.tsx
// Description: Basic Code Example
// ==========================================

// File: app/components/TaxChat.tsx
// Purpose: Frontend interface for the tax dispute agent.

'use client';

import { useChat } from 'ai/react';
import { handleTaxInquiry } from '../actions/taxAgentAction';

export default function TaxChat() {
  // useChat hook manages message history, input state, and submission
  const { messages, input, handleInputChange, handleSubmit, isLoading } = useChat({
    // We provide our custom Server Action as the API endpoint
    api: '/api/chat', // Default behavior, but we override via handleSubmit
  });

  /**
   * @description Custom submit handler to invoke our Server Action directly.
   * This bridges the Vercel AI SDK with Next.js Server Actions.
   */
  const customHandleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    
    // We hardcode an invoice ID for this demo context
    const invoiceId = 'inv_123456789';

    // We use the SDK's handleSubmit but intercept the generation
    // Note: In a real 'useChat' implementation with Server Actions, 
    // you might use the `onSubmit` callback or a custom fetch call.
    // Here, we demonstrate the direct integration pattern.
    
    // 1. Add user message to UI immediately
    // (The useChat hook handles this if we use its handleSubmit, 
    // but for direct Server Action usage, we often manage this manually or use `useSWR`).
    // To keep it simple with useChat, we will use its native endpoint logic 
    // but point it to a route that calls our action.
    
    // *Simplification for the example*: 
    // Since `useChat` expects an API route, we will simulate the flow 
    // by manually calling the action and updating the UI, 
    // or strictly adhering to the `useChat` pattern by creating an API route wrapper.
    
    // Let's stick to the `useChat` pattern strictly:
    // We will assume we have an API route `/api/chat` that calls `handleTaxInquiry`.
    // However, the prompt asks for a "Basic Code Example".
    
    // Let's use the `handleSubmit` provided by the hook, 
    // but we need to configure it to hit our logic.
    // Usually, `useChat` sends a POST request to `/api/chat`.
    // We will create that API route in the explanation below.
    
    handleSubmit(e);
  };

  return (
    <div className="flex flex-col w-full max-w-md p-4 mx-auto border rounded-lg shadow-xl bg-white">
      <h2 className="text-xl font-bold mb-4 text-gray-800">Tax Support Agent</h2>
      
      <div className="flex flex-col gap-2 mb-4 h-64 overflow-y-auto p-2 bg-gray-50 rounded">
        {messages.map((m) => (
          <div
            key={m.id}
            className={`p-2 rounded max-w-[80%] ${
              m.role === 'user'
                ? 'self-end bg-blue-100 text-blue-900'
                : 'self-start bg-green-100 text-green-900'
            }`}
          >
            <p className="text-sm font-semibold mb-1">
              {m.role === 'user' ? 'You' : 'Agent'}
            </p>
            <p className="text-sm">{m.content}</p>
          </div>
        ))}
        {isLoading && (
          <div className="self-start p-2 bg-green-100 rounded animate-pulse">
            <p className="text-sm text-green-900">Thinking...</p>
          </div>
        )}
      </div>

      <form onSubmit={customHandleSubmit} className="flex gap-2">
        <input
          type="text"
          value={input}
          onChange={handleInputChange}
          placeholder="Ask about VAT on invoice..."
          className="flex-1 p-2 border rounded text-black"
          disabled={isLoading}
        />
        <button
          type="submit"
          disabled={isLoading || !input}
          className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 disabled:opacity-50"
        >
          Send
        </button>
      </form>
    </div>
  );
}
