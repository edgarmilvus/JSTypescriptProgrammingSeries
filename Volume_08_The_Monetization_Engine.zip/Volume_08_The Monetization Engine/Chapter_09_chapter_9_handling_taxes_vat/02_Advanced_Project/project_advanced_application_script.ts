/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// app/api/chat/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { streamText } from 'ai'; // Vercel AI SDK
import { openai } from '@ai-sdk/openai'; // Requires @ai-sdk/openai package

/**
 * Simulates a backend database or Stripe API call to retrieve invoice details.
 * In a real scenario, this would query a database like PostgreSQL or the Stripe API.
 * 
 * @param invoiceId - The unique identifier for the invoice.
 * @returns A Promise resolving to tax details.
 */
async function fetchInvoiceTaxDetails(invoiceId: string): Promise<{
  amount: number;
  currency: string;
  taxRate: number;
  taxRegion: string;
  taxable: boolean;
}> {
  // Simulate network latency (database lookup)
  await new Promise(resolve => setTimeout(resolve, 500));

  // Mock logic: If invoice ID ends in 'X', it's a B2B EU transaction (0% VAT via reverse charge)
  // Otherwise, it's a standard B2C transaction subject to VAT.
  if (invoiceId.endsWith('X')) {
    return {
      amount: 100.00,
      currency: 'EUR',
      taxRate: 0,
      taxRegion: 'EU (B2B Reverse Charge)',
      taxable: true
    };
  }

  return {
    amount: 100.00,
    currency: 'USD',
    taxRate: 20, // Simulated VAT rate
    taxRegion: 'United Kingdom',
    taxable: true
  };
}

export async function POST(req: NextRequest) {
  const { messages, invoiceId } = await req.json();

  // 1. ASYNC TOOL HANDLING
  // We await the external data fetch. In a LangGraph.js implementation, 
  // this would be a distinct node in the graph that passes state to the next node.
  const taxContext = await fetchInvoiceTaxDetails(invoiceId);

  // 2. PROMPT ENGINEERING
  // We inject the raw tax data into the system prompt. This grounds the LLM 
  // in factual data, preventing hallucinations regarding tax rates.
  const systemPrompt = `
    You are a specialized VAT and Tax Support Agent for a SaaS company.
    The user is asking about an invoice charge.
    
    Use the following retrieved tax data to explain the charge:
    - Invoice Amount: ${taxContext.amount} ${taxContext.currency}
    - Tax Rate Applied: ${taxContext.taxRate}%
    - Tax Jurisdiction: ${taxContext.taxRegion}
    - Is Taxable: ${taxContext.taxable ? 'Yes' : 'No'}

    Rules for explanation:
    1. If the tax rate is 0%, explain that the customer is likely B2B and subject to reverse charge mechanisms.
    2. If the tax rate is > 0%, explain that based on their location (${taxContext.taxRegion}), local laws require collecting VAT.
    3. Be concise, polite, and professional.
  `;

  // 3. STREAMING RESPONSE
  // Use the Vercel AI SDK to stream the response back to the client.
  const result = await streamText({
    model: openai('gpt-4o-mini'),
    system: systemPrompt,
    messages, // The conversation history sent from the client
  });

  return result.toAIStreamResponse();
}
