/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script_part2.tsx
// Description: Advanced Application Script
// ==========================================

// components/TaxDisputeChat.tsx
'use client';

import { useChat } from 'ai/react';
import { useState } from 'react';

export default function TaxDisputeChat({ invoiceId }: { invoiceId: string }) {
  // 1. CLIENT STATE MANAGEMENT
  // useChat handles message history, input state, and streaming updates.
  const { messages, input, handleInputChange, handleSubmit, isLoading } = useChat({
    api: '/api/chat',
    body: {
      // Pass the specific invoice ID to the API route with every request
      invoiceId: invoiceId,
    },
  });

  return (
    <div className="flex flex-col w-full max-w-lg mx-auto p-4 bg-white border rounded-lg shadow-sm">
      <div className="mb-4">
        <h2 className="text-lg font-semibold text-gray-800">
          Tax Dispute Assistant
        </h2>
        <p className="text-sm text-gray-500">
          Ask about VAT/GST charges for Invoice: <span className="font-mono bg-gray-100 px-1 rounded">{invoiceId}</span>
        </p>
      </div>

      {/* 2. MESSAGE DISPLAY AREA */}
      <div className="flex flex-col gap-3 mb-4 h-64 overflow-y-auto p-2 bg-gray-50 rounded">
        {messages.map((message) => (
          <div
            key={message.id}
            className={`p-3 rounded-lg max-w-[80%] text-sm ${
              message.role === 'user'
                ? 'self-end bg-blue-600 text-white'
                : 'self-start bg-white border border-gray-200 text-gray-800'
            }`}
          >
            <div className="font-semibold mb-1">
              {message.role === 'user' ? 'You' : 'Tax Agent'}
            </div>
            <div className="whitespace-pre-wrap">{message.content}</div>
          </div>
        ))}
        {isLoading && (
          <div className="self-start bg-white border border-gray-200 text-gray-800 p-3 rounded-lg text-sm">
            <span className="inline-block w-2 h-2 bg-blue-500 rounded-full animate-pulse"></span>
            <span className="ml-2">Consulting tax records...</span>
          </div>
        )}
      </div>

      {/* 3. INPUT FORM */}
      <form onSubmit={handleSubmit} className="flex gap-2">
        <input
          type="text"
          value={input}
          onChange={handleInputChange}
          placeholder="e.g., Why is the VAT 20%?"
          className="flex-1 border border-gray-300 rounded px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
          disabled={isLoading}
        />
        <button
          type="submit"
          disabled={isLoading || !input.trim()}
          className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed"
        >
          Send
        </button>
      </form>
    </div>
  );
}
