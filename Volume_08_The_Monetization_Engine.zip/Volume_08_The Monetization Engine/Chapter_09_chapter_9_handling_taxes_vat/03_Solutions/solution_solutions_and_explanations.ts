/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// app/actions/taxActions.ts
'use server';

import { Plan, plans } from '@/data/plans'; // Assuming a data file for plans

// Define the shape of the tax response
export interface TaxCalculationResult {
  basePrice: number;
  taxRate: number;
  totalPrice: number;
  currency: string;
  error?: string;
}

// Mock function to simulate a tax engine API call
async function mockTaxEngine(countryCode: string, basePrice: number): Promise<{ rate: number }> {
  // Simulate network delay
  await new Promise(resolve => setTimeout(resolve, 500));

  if (countryCode === "ERR") {
    throw new Error("Tax calculation service unavailable");
  }

  // Simple mock logic for tax rates
  const rates: Record<string, number> = {
    "US": 0.08,  // 8% Sales Tax
    "EU": 0.21,  // 21% VAT
    "UK": 0.20,  // 20% VAT
    "CA": 0.13,  // 13% HST
  };

  return { rate: rates[countryCode] || 0 };
}

export async function calculateTaxRate(
  countryCode: string, 
  planId: string
): Promise<TaxCalculationResult> {
  try {
    // 1. Fetch plan details
    const plan = plans.find(p => p.id === planId);
    if (!plan) {
      return { 
        basePrice: 0, 
        taxRate: 0, 
        totalPrice: 0, 
        currency: 'USD', 
        error: 'Plan not found' 
      };
    }

    // 2. Call Tax Engine
    const { rate } = await mockTaxEngine(countryCode, plan.basePrice);
    
    // 3. Calculate totals
    const taxAmount = plan.basePrice * rate;
    const totalPrice = plan.basePrice + taxAmount;

    return {
      basePrice: plan.basePrice,
      taxRate: rate,
      totalPrice: totalPrice,
      currency: plan.currency,
    };
  } catch (error) {
    console.error("Tax calculation error:", error);
    return {
      basePrice: 0,
      taxRate: 0,
      totalPrice: 0,
      currency: 'USD',
      error: "Failed to calculate tax. Please try again."
    };
  }
}

// Interactive Challenge: Multi-Region Pricing Support
export async function calculateMultiRegionTax(
  countryCode: string, 
  planId: string
): Promise<TaxCalculationResult> {
  try {
    // 1. Fetch plan details with multi-region base prices
    const plan = plans.find(p => p.id === planId);
    if (!plan || !plan.basePrices) {
      return { 
        basePrice: 0, 
        taxRate: 0, 
        totalPrice: 0, 
        currency: 'USD', 
        error: 'Plan not found or missing regional pricing' 
      };
    }

    // 2. Determine region-specific base price
    const basePrice = plan.basePrices[countryCode] || plan.basePrices['DEFAULT'];
    if (basePrice === undefined) {
       return { 
        basePrice: 0, 
        taxRate: 0, 
        totalPrice: 0, 
        currency: 'USD', 
        error: 'Region not supported for this plan' 
      };
    }

    // 3. Call Tax Engine
    const { rate } = await mockTaxEngine(countryCode, basePrice);
    
    // 4. Calculate totals
    const taxAmount = basePrice * rate;
    const totalPrice = basePrice + taxAmount;

    return {
      basePrice: basePrice,
      taxRate: rate,
      totalPrice: totalPrice,
      currency: plan.currency,
    };
  } catch (error) {
    return {
      basePrice: 0,
      taxRate: 0,
      totalPrice: 0,
      currency: 'USD',
      error: "Failed to calculate tax."
    };
  }
}
