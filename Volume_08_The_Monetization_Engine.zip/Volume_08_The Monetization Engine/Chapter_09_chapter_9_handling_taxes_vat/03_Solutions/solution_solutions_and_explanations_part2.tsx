/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.tsx
// Description: Solutions and Explanations
// ==========================================

// app/components/TaxInclusivePlanSelector.tsx
'use client';

import { useState, useTransition } from 'react';
import { calculateTaxRate, calculateMultiRegionTax } from '@/app/actions/taxActions';

// Mock data for the UI
const PLANS = [
  { id: 'basic', name: 'Basic', basePrice: 10, currency: 'USD' },
  { id: 'pro', name: 'Pro', basePrice: 20, currency: 'USD' },
  { id: 'enterprise', name: 'Enterprise', basePrice: 50, currency: 'USD' },
];

export default function TaxInclusivePlanSelector() {
  const [selectedPlanId, setSelectedPlanId] = useState<string>('');
  const [countryCode, setCountryCode] = useState<string>('');
  const [totalPrice, setTotalPrice] = useState<number | null>(null);
  const [taxRate, setTaxRate] = useState<number | null>(null);
  const [basePrice, setBasePrice] = useState<number | null>(null);
  const [error, setError] = useState<string | null>(null);
  
  // useTransition handles the async server call without blocking the UI
  const [isPending, startTransition] = useTransition();

  const handleCalculate = () => {
    if (!selectedPlanId || !countryCode) return;

    setError(null);
    setTotalPrice(null);

    startTransition(async () => {
      // Toggle between standard and interactive challenge logic here:
      // const result = await calculateTaxRate(countryCode, selectedPlanId);
      const result = await calculateMultiRegionTax(countryCode, selectedPlanId);

      if (result.error) {
        setError(result.error);
      } else {
        setBasePrice(result.basePrice);
        setTaxRate(result.taxRate);
        setTotalPrice(result.totalPrice);
      }
    });
  };

  return (
    <div className="p-6 border rounded-lg max-w-md mx-auto">
      <h2 className="text-xl font-bold mb-4">Subscription Plan Selector</h2>
      
      <div className="mb-4">
        <label className="block text-sm font-medium mb-1">Select Plan</label>
        <select 
          value={selectedPlanId} 
          onChange={(e) => setSelectedPlanId(e.target.value)}
          className="w-full p-2 border rounded"
        >
          <option value="">Choose a plan...</option>
          {PLANS.map(plan => (
            <option key={plan.id} value={plan.id}>
              {plan.name} ({plan.currency} {plan.basePrice})
            </option>
          ))}
        </select>
      </div>

      <div className="mb-4">
        <label className="block text-sm font-medium mb-1">Country Code (e.g., US, EU, UK)</label>
        <input 
          type="text" 
          value={countryCode} 
          onChange={(e) => setCountryCode(e.target.value.toUpperCase())}
          placeholder="US"
          className="w-full p-2 border rounded"
        />
      </div>

      <button 
        onClick={handleCalculate}
        disabled={isPending || !selectedPlanId || !countryCode}
        className="w-full bg-blue-600 text-white p-2 rounded hover:bg-blue-700 disabled:bg-gray-400"
      >
        {isPending ? 'Calculating...' : 'Calculate Total Price'}
      </button>

      <div className="mt-6 p-4 bg-gray-50 rounded">
        <h3 className="font-semibold mb-2">Price Breakdown</h3>
        
        {error && (
          <div className="text-red-600 mb-2">{error}</div>
        )}

        {totalPrice !== null && !error && (
          <div className="space-y-1 text-sm">
            <div className="flex justify-between">
              <span>Base Price:</span>
              <span>${basePrice?.toFixed(2)}</span>
            </div>
            <div className="flex justify-between">
              <span>Tax Rate ({(taxRate! * 100).toFixed(1)}%):</span>
              <span>${((basePrice || 0) * taxRate!).toFixed(2)}</span>
            </div>
            <div className="flex justify-between font-bold text-lg border-t pt-2 mt-2">
              <span>Total:</span>
              <span>${totalPrice.toFixed(2)}</span>
            </div>
          </div>
        )}
        
        {!totalPrice && !error && !isPending && (
          <p className="text-gray-500 text-sm">Select a plan and enter a country code to see the total.</p>
        )}
      </div>
    </div>
  );
}
