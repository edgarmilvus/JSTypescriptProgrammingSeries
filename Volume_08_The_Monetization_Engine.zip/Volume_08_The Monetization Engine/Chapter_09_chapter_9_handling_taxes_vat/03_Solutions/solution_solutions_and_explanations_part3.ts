/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

// app/actions/dunningActions.ts
'use server';

// 1. Data Structures
interface Customer {
  id: string;
  taxId: string | null;
  email: string;
}

interface Subscription {
  id: string;
  customerId: string;
  status: 'active' | 'past_due' | 'canceled';
  planId: string;
}

interface Invoice {
  id: string;
  subscriptionId: string;
  amountDue: number;
  taxRate: number;
  status: 'open' | 'paid' | 'void';
}

// Mock Database State
const mockDb: { customers: Customer[]; invoices: Invoice[]; subscriptions: Subscription[] } = {
  customers: [
    { id: 'cust_123', taxId: 'invalid_tax_id', email: 'user@example.com' }
  ],
  subscriptions: [
    { id: 'sub_123', customerId: 'cust_123', status: 'past_due', planId: 'pro' }
  ],
  invoices: [
    { id: 'inv_123', subscriptionId: 'sub_123', amountDue: 100, taxRate: 0.20, status: 'open' }
  ]
};

// Mock Tax Engine Validation
async function validateTaxId(taxId: string): Promise<{ valid: boolean; correctRate: number }> {
  await new Promise(r => setTimeout(r, 500)); // Simulate API latency
  if (taxId.startsWith('VALID_')) {
    return { valid: true, correctRate: 0.05 }; // Lower rate for valid ID
  }
  return { valid: false, correctRate: 0.20 }; // Standard rate
}

// Mock Payment Gateway
async function mockChargePayment(amount: number): Promise<{ success: boolean }> {
  await new Promise(r => setTimeout(r, 300));
  // Simulate random failure or success based on amount
  return { success: amount < 150 }; 
}

// 2. Server Action
export async function retryPaymentWithUpdatedTax(
  customerId: string, 
  newTaxId: string, 
  retryCount: number = 0
) {
  const MAX_RETRIES = 3;

  // 3. Retry Limit Logic (Interactive Challenge)
  if (retryCount >= MAX_RETRIES) {
    return {
      status: 'failed',
      message: 'Maximum retry attempts reached. Manual intervention required.',
      requiresSupport: true,
    };
  }

  try {
    // Fetch Data
    const customer = mockDb.customers.find(c => c.id === customerId);
    const invoice = mockDb.invoices.find(i => i.subscriptionId === customer?.id); // Simplified lookup
    const subscription = mockDb.subscriptions.find(s => s.id === invoice?.subscriptionId);

    if (!customer || !invoice || !subscription) {
      return { status: 'error', message: 'Customer or invoice not found.' };
    }

    // Validate Tax ID & Recalculate
    const taxValidation = await validateTaxId(newTaxId);
    
    // Update Customer Tax ID
    customer.taxId = newTaxId;

    // Recalculate Invoice Amount (Base is arbitrary 100 for this exercise)
    const baseAmount = 100;
    const newTaxAmount = baseAmount * taxValidation.correctRate;
    const newTotal = baseAmount + newTaxAmount;

    // Update Invoice in "DB"
    invoice.amountDue = newTotal;
    invoice.taxRate = taxValidation.correctRate;

    // Retry Payment
    const paymentResult = await mockChargePayment(newTotal);

    if (paymentResult.success) {
      // Update Status
      invoice.status = 'paid';
      subscription.status = 'active';
      
      return {
        status: 'success',
        message: 'Payment successful. Invoice paid.',
        updatedInvoice: invoice
      };
    } else {
      // Payment failed again
      return {
        status: 'retry_failed',
        message: 'Payment failed again with updated tax. Please try another method.',
        updatedInvoice: invoice,
        retryCount: retryCount + 1
      };
    }

  } catch (error) {
    return {
      status: 'error',
      message: 'An unexpected error occurred during the retry process.',
    };
  }
}
