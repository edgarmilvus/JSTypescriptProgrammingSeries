/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.tsx
// Description: Solutions and Explanations
// ==========================================

// app/components/SmartDunning.tsx
'use client';

import { useState, useTransition } from 'react';
import { retryPaymentWithUpdatedTax } from '@/app/actions/dunningActions';

export default function SmartDunning() {
  const [newTaxId, setNewTaxId] = useState('');
  const [result, setResult] = useState<any>(null);
  const [isPending, startTransition] = useTransition();
  const [retryCount, setRetryCount] = useState(0);

  const handleRetry = () => {
    startTransition(async () => {
      const response = await retryPaymentWithUpdatedTax('cust_123', newTaxId, retryCount);
      setResult(response);

      // If the server indicates a retry attempt happened (but failed), update local count
      if (response.status === 'retry_failed') {
        setRetryCount(response.retryCount);
      }
    });
  };

  return (
    <div className="p-6 border rounded-lg max-w-md mx-auto bg-white shadow-sm">
      <h2 className="text-xl font-bold mb-4">Smart Dunning: Tax Update</h2>
      
      <div className="mb-4">
        <label className="block text-sm font-medium mb-1">New Tax ID</label>
        <input 
          type="text" 
          value={newTaxId} 
          onChange={(e) => setNewTaxId(e.target.value)}
          placeholder="e.g. VALID_TAX_123"
          className="w-full p-2 border rounded"
        />
        <p className="text-xs text-gray-500 mt-1">Try "VALID_TAX" for success simulation.</p>
      </div>

      <button 
        onClick={handleRetry}
        disabled={isPending}
        className="w-full bg-green-600 text-white p-2 rounded hover:bg-green-700 disabled:bg-gray-400"
      >
        {isPending ? 'Processing...' : 'Update Tax & Retry Payment'}
      </button>

      {result && (
        <div className={`mt-4 p-3 rounded ${result.status === 'success' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>
          <p className="font-bold">{result.status.toUpperCase()}</p>
          <p>{result.message}</p>
          
          {result.requiresSupport && (
            <div className="mt-2 p-2 border border-red-300 bg-white rounded">
              <strong>Action Required:</strong> Please contact support team immediately.
            </div>
          )}
          
          {result.updatedInvoice && (
            <div className="mt-2 text-xs font-mono">
              New Total: ${result.updatedInvoice.amountDue.toFixed(2)} <br/>
              Status: {result.updatedInvoice.status}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
