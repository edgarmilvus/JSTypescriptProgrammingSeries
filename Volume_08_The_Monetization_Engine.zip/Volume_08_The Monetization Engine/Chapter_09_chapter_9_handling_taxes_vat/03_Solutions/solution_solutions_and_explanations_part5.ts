/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

// app/ai-tools/vatTools.ts
// 1. Tool Definitions (Async Functions)

export interface Invoice {
  id: string;
  amount: number;
  vatAmount: number;
  customerId: string;
}

export interface ExemptionCertificate {
  valid: boolean;
  coveragePercentage: number; // e.g., 1.0 for 100%, 0.5 for 50%
  exemptionType: string;
}

// Tool 1: Retrieve Invoice
export async function getInvoice(invoiceId: string): Promise<Invoice | null> {
  console.log(`[Tool] Fetching invoice ${invoiceId}...`);
  await new Promise(r => setTimeout(r, 200)); // Simulate API
  if (invoiceId === 'inv_999') return null;
  return {
    id: invoiceId,
    amount: 200,
    vatAmount: 40, // 20% of 200
    customerId: 'cust_123'
  };
}

// Tool 2: Validate VAT Exemption
export async function validateVatExemption(customerId: string): Promise<ExemptionCertificate> {
  console.log(`[Tool] Validating VAT exemption for ${customerId}...`);
  await new Promise(r => setTimeout(r, 200));
  // Simulate finding a partial exemption certificate
  return {
    valid: true,
    coveragePercentage: 0.50, // Covers 50% of VAT
    exemptionType: 'Charitable Organization'
  };
}

// Tool 3: Process Refund
export async function processRefund(invoiceId: string, refundAmount: number): Promise<{ success: boolean; refundId: string }> {
  console.log(`[Tool] Processing refund of $${refundAmount} for ${invoiceId}...`);
  await new Promise(r => setTimeout(r, 300));
  return { success: true, refundId: `refund_${Math.floor(Math.random() * 10000)}` };
}

// 2. LangGraph.js Node Implementation
// Note: This assumes a standard LangGraph State definition.
// We use a simple object structure here to mimic the graph node behavior.

type DisputeState = {
  invoiceId: string;
  customerId: string;
  reason: string;
  resolution?: any;
  stepsTaken?: string[];
};

export async function vatDisputeResolver(state: DisputeState): Promise<DisputeState> {
  const { invoiceId, customerId } = state;
  const steps: string[] = [...(state.stepsTaken || [])];

  try {
    // Step 1: Get Invoice
    const invoice = await getInvoice(invoiceId);
    if (!invoice) {
      return { ...state, resolution: { status: 'error', reason: 'Invoice not found' }, stepsTaken: steps };
    }
    steps.push('Retrieved invoice details');

    // Step 2: Validate Exemption
    const certificate = await validateVatExemption(customerId);
    steps.push(`Validated exemption: ${certificate.exemptionType}`);

    if (!certificate.valid) {
      return {
        ...state,
        resolution: { status: 'rejected', reason: 'No valid exemption certificate on file.' },
        stepsTaken: steps
      };
    }

    // Step 3: Calculate Refund (Interactive Challenge: Partial Refund)
    // Original VAT was 40. If coverage is 50%, refund is 20.
    const refundAmount = invoice.vatAmount * certificate.coveragePercentage;
    
    // Step 4: Process Refund
    const refundResult = await processRefund(invoiceId, refundAmount);
    steps.push(`Processed refund: ${refundResult.refundId}`);

    return {
      ...state,
      resolution: {
        status: 'refunded',
        amount: refundAmount,
        coverage: `${certificate.coveragePercentage * 100}%`,
        refundId: refundResult.refundId
      },
      stepsTaken: steps
    };

  } catch (error) {
    return {
      ...state,
      resolution: { status: 'error', reason: 'Internal agent error' },
      stepsTaken: steps
    };
  }
}
