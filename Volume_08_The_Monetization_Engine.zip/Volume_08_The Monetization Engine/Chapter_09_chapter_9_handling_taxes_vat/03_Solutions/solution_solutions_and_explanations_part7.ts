/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part7.ts
// Description: Solutions and Explanations
// ==========================================

digraph TaxWorkflow {
    rankdir=TB;
    node [fontname="Arial", shape=box, style="rounded,filled", fillcolor="#e3f2fd"];
    edge [fontname="Arial", fontsize=10];

    // Nodes
    Start [label="User Initiates\nSubscription", shape=ellipse, fillcolor="#f3e5f5"];
    FetchDetails [label="Fetch Customer\n& Billing Address"];
    DetermineJurisdiction [label="Determine Tax\nJurisdiction"];
    CallTaxEngine [label="Call Tax Engine\n(e.g., Stripe Tax)", fillcolor="#fff3e0"];
    CalcInvoice [label="Calculate Final\nInvoice Amount"];
    AttemptPayment [label="Attempt Payment"];
    
    // Decision Node
    PaymentSuccess [label="Payment\nSuccessful?", shape=diamond, fillcolor="#eeeeee"];
    
    // Success Path
    CreateSub [label="Create Subscription\n& Send Invoice", fillcolor="#e8f5e9"];
    
    // Failure Path (Smart Dunning)
    TriggerDunning [label="Trigger Smart Dunning\n(Update Tax ID & Retry)", fillcolor="#ffebee"];
    
    // Dispute Path (Parallel)
    InvoiceCreated [label="Invoice Status: Open", shape=ellipse];
    CustomerDispute [label="Customer Disputes\nVAT Charge", shape=ellipse, fillcolor="#fffde7"];
    AIResolver [label="AI Agent\nVAT Dispute Resolver", fillcolor="#e0f7fa"];
    
    Refund [label="Process Refund\n(Partial/Full)", fillcolor="#f1f8e9"];
    Escalate [label="Escalate to\nHuman Agent", fillcolor="#ffcdd2"];

    // Workflow Logic
    Start -> FetchDetails;
    FetchDetails -> DetermineJurisdiction;
    DetermineJurisdiction -> CallTaxEngine;
    CallTaxEngine -> CalcInvoice;
    CalcInvoice -> AttemptPayment;
    AttemptPayment -> PaymentSuccess;

    PaymentSuccess -> CreateSub [label="Yes"];
    PaymentSuccess -> TriggerDunning [label="No"];

    // Dispute Flow
    CreateSub -> InvoiceCreated;
    InvoiceCreated -> CustomerDispute [label="After Delivery"];
    CustomerDispute -> AIResolver;
    
    AIResolver -> Refund [label="Valid Exemption\n(Partial/Full)"];
    AIResolver -> Escalate [label="Invalid/Complex"];
    
    Refund -> InvoiceCreated [label="Update Status", style=dashed];
    Escalate -> InvoiceCreated [label="Manual Update", style=dashed];

    // Annotations (Subgraphs for visual grouping if needed, or just labels)
    { rank = same; CreateSub; TriggerDunning; }
}
