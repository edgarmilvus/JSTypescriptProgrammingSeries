/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part8.ts
// Description: Solutions and Explanations
// ==========================================

// app/actions/bulkTaxActions.ts
'use server';

// In-memory store to simulate a job queue/database
const jobStore = new Map<string, { status: 'pending' | 'processing' | 'completed'; progress: number; total: number; results: any[] }>();

interface Subscription {
  id: string;
  region: string;
  basePrice: number;
}

// Mock Data: 25 subscriptions in EU
const mockSubscriptions: Subscription[] = Array.from({ length: 25 }, (_, i) => ({
  id: `sub_${i}`,
  region: 'EU',
  basePrice: 100 + i
}));

export async function bulkRecalculateTax(region: string, newTaxRate: number) {
  // 1. Filter subscriptions by region
  const targetSubs = mockSubscriptions.filter(sub => sub.region === region);
  
  if (targetSubs.length === 0) {
    return { error: 'No subscriptions found for region' };
  }

  // 2. Generate Job ID
  const jobId = `job_${Date.now()}`;
  
  // Initialize Job Status
  jobStore.set(jobId, {
    status: 'pending',
    progress: 0,
    total: targetSubs.length,
    results: []
  });

  // 3. Start Async Processing (Non-blocking)
  processBatch(jobId, targetSubs, newTaxRate);

  // Return immediately to client
  return { jobId, message: 'Bulk job started', totalItems: targetSubs.length };
}

async function processBatch(jobId: string, subs: Subscription[], taxRate: number) {
  const job = jobStore.get(jobId);
  if (!job) return;

  job.status = 'processing';
  const batchSize = 10;
  
  // Interactive Challenge: Rate-limited processing
  for (let i = 0; i < subs.length; i += batchSize) {
    const batch = subs.slice(i, i + batchSize);
    
    // Process current batch
    const batchResults = batch.map(sub => {
      const newTotal = sub.basePrice * (1 + taxRate);
      return { subId: sub.id, newTotal, taxRate };
    });

    // Update Store
    job.results.push(...batchResults);
    job.progress = Math.min(i + batchSize, subs.length);
    
    // Wait before next batch (Simulate rate limit / avoid API throttling)
    await new Promise(resolve => setTimeout(resolve, 1000));
  }

  job.status = 'completed';
  jobStore.set(jobId, job);
}

export async function getJobStatus(jobId: string) {
  const job = jobStore.get(jobId);
  if (!job) {
    return { error: 'Job not found' };
  }
  return job;
}
