/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part9.tsx
// Description: Solutions and Explanations
// ==========================================

// app/components/BulkTaxRecalculator.tsx
'use client';

import { useState } from 'react';
import { bulkRecalculateTax, getJobStatus } from '@/app/actions/bulkTaxActions';

export default function BulkTaxRecalculator() {
  const [jobId, setJobId] = useState<string | null>(null);
  const [status, setStatus] = useState<any>(null);
  const [polling, setPolling] = useState<boolean>(false);

  const startJob = async () => {
    const result = await bulkRecalculateTax('EU', 0.25); // 25% VAT
    if (result.jobId) {
      setJobId(result.jobId);
      startPolling(result.jobId);
    }
  };

  const startPolling = (id: string) => {
    setPolling(true);
    const interval = setInterval(async () => {
      const jobStatus = await getJobStatus(id);
      setStatus(jobStatus);

      if (jobStatus.status === 'completed') {
        clearInterval(interval);
        setPolling(false);
      }
    }, 1000); // Poll every 1 second
  };

  return (
    <div className="p-6 border rounded-lg max-w-md mx-auto">
      <h2 className="text-xl font-bold mb-4">Bulk Tax Recalculation</h2>
      
      <button 
        onClick={startJob}
        disabled={polling}
        className="w-full bg-purple-600 text-white p-2 rounded hover:bg-purple-700 disabled:bg-gray-400"
      >
        {polling ? 'Processing Batch...' : 'Start Bulk Recalculation (EU)'}
      </button>

      {status && (
        <div className="mt-4 p-4 bg-gray-50 rounded border">
          <div className="flex justify-between font-bold mb-2">
            <span>Job ID:</span>
            <span className="font-mono text-xs">{jobId}</span>
          </div>
          <div className="flex justify-between mb-2">
            <span>Status:</span>
            <span className={`font-bold ${status.status === 'completed' ? 'text-green-600' : 'text-blue-600'}`}>
              {status.status.toUpperCase()}
            </span>
          </div>
          
          <div className="w-full bg-gray-200 rounded-full h-2.5 mb-2">
            <div 
              className="bg-blue-600 h-2.5 rounded-full transition-all duration-500" 
              style={{ width: `${(status.progress / status.total) * 100}%` }}
            ></div>
          </div>
          
          <div className="text-sm text-gray-600">
            Processed {status.progress} / {status.total} subscriptions
          </div>

          {status.status === 'completed' && (
            <div className="mt-4 text-xs">
              <strong>Summary:</strong>
              <div className="max-h-32 overflow-y-auto mt-1 border p-1 bg-white">
                {status.results.map((r: any) => (
                  <div key={r.subId}>{r.subId}: ${r.newTotal.toFixed(2)}</div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
