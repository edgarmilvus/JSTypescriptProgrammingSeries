/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * @fileoverview A "Hello World" example of an automated invoice data extraction pipeline.
 * This script simulates parsing unstructured invoice data and converting it into a structured
 * format suitable for Stripe Billing integration.
 * 
 * Prerequisites: Node.js with TypeScript installed.
 * To run: Save as `invoice-processor.ts` and execute `npx ts-node invoice-processor.ts`.
 */

// ============================================================================
// 1. TYPE DEFINITIONS (Strict Type Discipline)
// ============================================================================

/**
 * Represents a single line item on an invoice, as extracted by an AI/OCR model.
 * This interface defines the data contract for the raw, unstructured input.
 * Note: All fields are explicitly typed to prevent `any` and ensure null-safety.
 */
interface InvoiceLineItem {
  description: string;
  quantity: number;
  unit_price: number; // In cents to avoid floating-point issues
}

/**
 * Represents the raw, unstructured invoice data object.
 * This simulates the output from an AI model that has processed a PDF or email.
 */
interface RawInvoiceData {
  invoice_number: string;
  vendor_name: string;
  total_amount: number; // In cents
  line_items: InvoiceLineItem[];
  due_date?: string; // Optional field
}

/**
 * Represents the final, validated data structure ready for Stripe API integration.
 * Stripe expects specific field names and data types for its `InvoiceItem` object.
 */
interface StripeInvoiceItem {
  customer: string; // Stripe Customer ID
  description: string;
  quantity: number;
  unit_price: number; // In cents
  currency: string; // e.g., 'usd'
}

// ============================================================================
// 2. MOCK DATA SIMULATION
// ============================================================================

/**
 * Simulates the output of an AI-powered OCR/LLM model that has parsed a PDF invoice.
 * In a real-world scenario, this data would come from a service like AWS Textract,
 * Google Document AI, or a custom LLM endpoint.
 */
const mockRawInvoice: RawInvoiceData = {
  invoice_number: "INV-2023-001",
  vendor_name: "Cloud Services Inc.",
  total_amount: 15000, // $150.00 in cents
  due_date: "2023-12-31",
  line_items: [
    { description: "Pro Plan Subscription", quantity: 1, unit_price: 10000 },
    { description: "API Overage (1M requests)", quantity: 5, unit_price: 1000 },
  ],
};

// ============================================================================
// 3. CORE PROCESSING LOGIC
// ============================================================================

/**
 * Validates the extracted invoice data against business rules.
 * This is a critical step to catch hallucinations or errors from the AI model.
 * 
 * @param rawInvoice - The raw invoice data object.
 * @returns A boolean indicating if the data is valid.
 * @throws Error if validation fails (for demonstration).
 */
function validateInvoiceData(rawInvoice: RawInvoiceData): boolean {
  // Calculate the expected total from line items
  const calculatedTotal = rawInvoice.line_items.reduce(
    (sum, item) => sum + item.quantity * item.unit_price,
    0
  );

  // **Validation Logic:**
  // 1. Check if the calculated total matches the extracted total.
  // 2. Ensure required fields are not empty.
  if (calculatedTotal !== rawInvoice.total_amount) {
    throw new Error(
      `Validation Error: Total mismatch. Expected ${rawInvoice.total_amount}, but calculated ${calculatedTotal}.`
    );
  }

  if (!rawInvoice.vendor_name || !rawInvoice.invoice_number) {
    throw new Error("Validation Error: Missing critical vendor or invoice number.");
  }

  console.log("✅ Invoice data validated successfully.");
  return true;
}

/**
 * Transforms raw invoice line items into Stripe-compatible format.
 * This function handles the data mapping and formatting required by the target system.
 * 
 * @param rawInvoice - The validated raw invoice data.
 * @param stripeCustomerId - The Stripe Customer ID to associate the invoice with.
 * @returns An array of StripeInvoiceItem objects.
 */
function transformToStripeItems(
  rawInvoice: RawInvoiceData,
  stripeCustomerId: string
): StripeInvoiceItem[] {
  // Map each line item to the Stripe structure
  return rawInvoice.line_items.map((item) => ({
    customer: stripeCustomerId,
    description: item.description,
    quantity: item.quantity,
    unit_price: item.unit_price,
    currency: "usd", // Assuming USD for this example
  }));
}

/**
 * Main processor function that orchestrates the pipeline.
 * 
 * @param rawInvoice - The raw invoice data.
 * @param stripeCustomerId - The target customer ID in Stripe.
 * @returns The formatted Stripe invoice items ready for API sync.
 */
function processInvoice(
  rawInvoice: RawInvoiceData,
  stripeCustomerId: string
): StripeInvoiceItem[] {
  try {
    // Step 1: Validate the data integrity
    validateInvoiceData(rawInvoice);

    // Step 2: Transform the data into the target format
    const stripeItems = transformToStripeItems(rawInvoice, stripeCustomerId);

    console.log("✅ Data transformation complete.");
    return stripeItems;
  } catch (error) {
    // In a real app, this would trigger a "Smart Dunning" alert or a manual review queue
    console.error("❌ Pipeline failed:", (error as Error).message);
    return []; // Return empty array on failure
  }
}

// ============================================================================
// 4. EXECUTION
// ============================================================================

// Simulate a Stripe Customer ID (e.g., fetched from a database)
const STRIPE_CUSTOMER_ID = "cus_12345abc";

// Execute the pipeline
const processedInvoiceItems = processInvoice(mockRawInvoice, STRIPE_CUSTOMER_ID);

// Log the final output for integration
console.log("\n--- Final Stripe Invoice Payload ---");
console.log(JSON.stringify(processedInvoiceItems, null, 2));
