/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// app/actions/invoiceProcessing.ts
'use server';

import { z } from 'zod';

// ============================================================================
// 1. DATA STRUCTURES & IMMUTABLE STATE DEFINITIONS
// ============================================================================

/**
 * Represents the raw input from the client.
 * Immutable by design: once received, this object is never modified.
 */
export interface RawInvoiceInput {
  fileBuffer: Buffer; // In a real app, this might be a URL or stream
  emailContent?: string;
  sourceType: 'pdf' | 'email' | 'image';
}

/**
 * Represents the extracted text data from OCR or email parsing.
 * This is an intermediate immutable state.
 */
export interface ExtractedTextData {
  rawText: string;
  metadata: {
    extractionMethod: 'ocr' | 'email_parser';
    confidenceScore: number;
    timestamp: number;
  };
}

/**
 * Represents the structured data parsed by the LLM.
 * This is the target shape before validation.
 */
export interface ParsedInvoiceData {
  vendorName: string;
  invoiceNumber: string;
  date: string; // ISO string
  totalAmount: number;
  currency: string;
  lineItems: Array<{
    description: string;
    quantity: number;
    unitPrice: number;
    total: number;
  }>;
}

/**
 * The final, validated schema ready for Stripe/Accounting ingestion.
 * Uses Zod for runtime type checking.
 */
export const StripeInvoiceSchema = z.object({
  vendorName: z.string().min(1),
  invoiceNumber: z.string().min(1),
  dueDate: z.string().datetime(), // Stripe expects ISO 8601
  amount: z.number().positive(),
  currency: z.string().length(3).toUpperCase(),
  metadata: z.record(z.string()), // Flexible metadata for accounting
});

export type StripeInvoicePayload = z.infer<typeof StripeInvoiceSchema>;

// ============================================================================
// 2. WORKER AGENT POOL SIMULATION
// ============================================================================

/**
 * Simulates the OCR Agent.
 * In a production environment, this would call Google Cloud Vision, AWS Textract, or Tesseract.
 * @param input - The raw invoice input (PDF/Image buffer)
 * @returns Promise<ExtractedTextData> - Immutable text extraction result
 */
async function ocrAgent(input: RawInvoiceInput): Promise<ExtractedTextData> {
  console.log(`[OCR Agent] Processing ${input.sourceType}...`);
  
  // Simulation of async processing delay
  await new Promise(resolve => setTimeout(resolve, 500));

  // Mocking OCR output based on input type
  const mockText = input.sourceType === 'pdf' 
    ? "INVOICE #12345\nVendor: Acme Corp\nDate: 2023-10-27\nTotal: $1500.00\nLine Item: Web Design - 10 hrs @ $150/hr"
    : "Invoice from Globex Inc\nRef: INV-999\nTotal: $5,500.00";

  return {
    rawText: mockText,
    metadata: {
      extractionMethod: 'ocr',
      confidenceScore: 0.92,
      timestamp: Date.now(),
    },
  };
}

/**
 * Simulates the LLM Parser Agent.
 * In production, this sends extracted text to an LLM (e.g., GPT-4) with a strict JSON schema prompt.
 * @param textData - The immutable extracted text data
 * @returns Promise<ParsedInvoiceData> - Structured JSON object
 */
async function llmParserAgent(textData: ExtractedTextData): Promise<ParsedInvoiceData> {
  console.log(`[LLM Parser Agent] Analyzing text with confidence ${textData.metadata.confidenceScore}...`);
  
  await new Promise(resolve => setTimeout(resolve, 800));

  // Mocking LLM extraction logic (Regex or NLP in reality)
  // This block creates a NEW object, adhering to immutability
  const structuredData: ParsedInvoiceData = {
    vendorName: textData.rawText.includes("Acme") ? "Acme Corp" : "Globex Inc",
    invoiceNumber: textData.rawText.includes("12345") ? "12345" : "INV-999",
    date: "2023-10-27T00:00:00Z",
    totalAmount: textData.rawText.includes("$1500") ? 1500 : 5500,
    currency: "USD",
    lineItems: [
      {
        description: "Professional Services",
        quantity: 1,
        unitPrice: 1500, // Simplified for demo
        total: 1500
      }
    ],
  };

  return structuredData;
}

/**
 * Simulates the Validation & Enrichment Agent.
 * Validates data against business rules and Stripe requirements.
 * @param data - The parsed invoice data
 * @returns Promise<StripeInvoicePayload> - Validated and transformed payload
 */
async function validationAgent(data: ParsedInvoiceData): Promise<StripeInvoicePayload> {
  console.log(`[Validation Agent] Validating schema and business logic...`);

  // Transformation: Map ParsedInvoiceData to StripeInvoiceSchema
  // Note: We are creating a new object structure here
  const rawPayload = {
    vendorName: data.vendorName,
    invoiceNumber: data.invoiceNumber,
    dueDate: data.date, // In real app, calculate due date + 30 days
    amount: data.totalAmount,
    currency: data.currency,
    metadata: {
      source: 'automated_extraction',
      lineItemCount: data.lineItems.length.toString(),
    },
  };

  // Validate using Zod
  const result = StripeInvoiceSchema.safeParse(rawPayload);

  if (!result.success) {
    throw new Error(`Validation Failed: ${JSON.stringify(result.error.errors)}`);
  }

  return result.data;
}

// ============================================================================
// 3. ORCHESTRATION SERVER ACTION
// ============================================================================

/**
 * The primary Server Action exposed to the client.
 * Orchestrates the Worker Agent Pool and manages the immutable state flow.
 * 
 * @param prevState - Previous form state (for Next.js useFormState)
 * @param formData - Form data containing the file input
 * @returns Promise<{ success: boolean; message: string; payload?: StripeInvoicePayload }>
 */
export async function processInvoiceAction(
  prevState: any,
  formData: FormData
) {
  try {
    // 1. EXTRACT & FREEZE RAW INPUT (Immutable Initialization)
    const file = formData.get('invoiceFile') as File;
    if (!file) return { success: false, message: 'No file provided' };

    const buffer = Buffer.from(await file.arrayBuffer());
    const rawInput: RawInvoiceInput = {
      fileBuffer: buffer,
      sourceType: 'pdf', // Determined by file extension or content type
    };

    // 2. STAGE 1: OCR EXTRACTION
    // Output is treated as immutable snapshot
    const extractedText = await ocrAgent(rawInput);

    // 3. STAGE 2: LLM PARSING
    // Input is immutable, output is new immutable structure
    const parsedData = await llmParserAgent(extractedText);

    // 4. STAGE 3: VALIDATION & STRIP SYNC PREP
    // Final transformation before external API call
    const validatedPayload = await validationAgent(parsedData);

    // 5. STAGE 4: INTEGRATION HOOK (Stripe Billing)
    // In a real app, this is where we call Stripe API
    // await stripe.invoices.create({ ...validatedPayload });
    console.log(`[Integration] Syncing to Stripe: ${validatedPayload.invoiceNumber}`);

    return {
      success: true,
      message: 'Invoice processed and synced successfully.',
      payload: validatedPayload,
    };

  } catch (error) {
    console.error('Pipeline Error:', error);
    return {
      success: false,
      message: error instanceof Error ? error.message : 'Unknown processing error',
      payload: undefined,
    };
  }
}
