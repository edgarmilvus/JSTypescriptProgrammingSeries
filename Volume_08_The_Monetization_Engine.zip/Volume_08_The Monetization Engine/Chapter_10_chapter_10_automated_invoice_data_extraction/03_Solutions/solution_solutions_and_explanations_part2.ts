/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

// File: types/rawInvoice.ts
export interface RawInvoice {
  id: string;
  rawText: string;
  imageBase64?: string;
  receivedAt: string;
}

// File: app/actions.ts (Server Actions)
'use server';

import { RawInvoice } from '@/types/rawInvoice';

// Mock API function
async function fetchMockRawInvoice(id: string): Promise<RawInvoice> {
  // Simulate network request
  await new Promise(resolve => setTimeout(resolve, 500));
  
  if (!id) throw new Error("ID is required");
  
  return {
    id: id,
    rawText: `INVOICE ${id}\nVENDOR: Generic Corp\nAMOUNT: $500.00\nDATE: 2023-11-01`,
    imageBase64: 'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII=',
    receivedAt: new Date().toISOString(),
  };
}

// Server Action to handle form submission
export async function fetchRawInvoiceDataAction(formData: FormData) {
  const invoiceId = formData.get('invoiceId') as string;
  
  try {
    const data = await fetchMockRawInvoice(invoiceId);
    return { success: true, data };
  } catch (error) {
    return { success: false, error: (error as Error).message };
  }
}

// File: components/RawInvoiceData.tsx (Server Component)
import { fetchMockRawInvoice } from './actions'; // Reusing the mock logic
import { RawInvoice } from '@/types/rawInvoice';

// 1. Component Creation: Server Component
export default async function RawInvoiceData({ invoiceId }: { invoiceId: string }) {
  // 2. Data Fetching: Fetch happens on the server
  const data: RawInvoice = await fetchMockRawInvoice(invoiceId);

  // 5. UI Rendering: Render raw data in a pre-formatted block
  return (
    <div className="p-4 bg-gray-100 rounded border border-gray-300 font-mono text-xs overflow-x-auto">
      <h3 className="font-bold mb-2">Raw Data for ID: {invoiceId}</h3>
      <pre>{JSON.stringify(data, null, 2)}</pre>
    </div>
  );
}

// File: components/InvoiceInputForm.tsx (Client Component for Interactive Challenge)
'use client';

import { useActionState } from 'react'; // React 19 hook, or useTransition in older versions
import { fetchRawInvoiceDataAction } from '@/app/actions';

const initialState = {
  success: false,
  data: null,
  error: null,
};

export function InvoiceInputForm() {
  // Using useActionState to handle the Server Action result
  const [state, formAction, isPending] = useActionState(fetchRawInvoiceDataAction, initialState);

  return (
    <div className="space-y-4">
      <form action={formAction} className="flex gap-2">
        <input 
          name="invoiceId" 
          placeholder="Enter Invoice ID (e.g., INV-123)" 
          className="p-2 border rounded text-black"
          required
        />
        <button 
          type="submit" 
          disabled={isPending}
          className="p-2 bg-blue-600 text-white rounded disabled:opacity-50"
        >
          {isPending ? 'Fetching...' : 'Fetch Raw Data'}
        </button>
      </form>

      {state?.success && state.data && (
        <div className="p-4 bg-green-50 border border-green-200 rounded">
          <h4 className="font-bold text-green-800">Server Action Result:</h4>
          <pre className="text-xs mt-2 text-green-900">{JSON.stringify(state.data, null, 2)}</pre>
        </div>
      )}

      {state?.error && (
        <div className="p-4 bg-red-50 border border-red-200 rounded text-red-700">
          Error: {state.error}
        </div>
      )}
    </div>
  );
}
