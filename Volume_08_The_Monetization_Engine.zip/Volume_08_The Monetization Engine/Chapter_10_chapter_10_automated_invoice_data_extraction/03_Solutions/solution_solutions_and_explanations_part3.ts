/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

// File: utils/validators.ts
import { Invoice } from '@/types/invoice';

export interface ValidationResult {
  isValid: boolean;
  errors: string[];
}

export function validateExtractedInvoice(invoice: Invoice): ValidationResult {
  const errors: string[] = [];

  // 1. Required Fields Check
  if (!invoice.invoiceId) errors.push("Invoice ID is missing.");
  if (!invoice.vendorName) errors.push("Vendor Name is missing.");
  if (invoice.totalAmount === undefined || invoice.totalAmount === null) errors.push("Total Amount is missing.");

  // 2. Date Format Check (ISO 8601)
  const dateRegex = /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(\.\d+)?(Z|[+-]\d{2}:\d{2})?$/;
  if (!invoice.invoiceDate || !dateRegex.test(invoice.invoiceDate)) {
    errors.push("Invoice Date is missing or not a valid ISO 8601 string.");
  }

  // 3. Total Calculation Check (Floating point tolerance)
  if (invoice.lineItems && invoice.lineItems.length > 0) {
    const calculatedTotal = invoice.lineItems.reduce((acc, item) => {
      return acc + (item.quantity * item.unitPrice);
    }, 0);
    
    // Allow a tolerance of 0.01 for floating point math
    if (Math.abs(calculatedTotal - invoice.totalAmount) > 0.01) {
      errors.push(`Total amount mismatch. Calculated: ${calculatedTotal}, Provided: ${invoice.totalAmount}`);
    }
  }

  // 4. Interactive Challenge: Cross-field Validation
  const vendorCurrencyMap: Record<string, string> = {
    "Stripe Inc.": "USD",
    "AWS": "USD",
  };

  if (vendorCurrencyMap[invoice.vendorName]) {
    // Assuming 'currency' is part of the Invoice interface or we check a specific field.
    // For this exercise, let's assume the Invoice interface has a 'currency' field added.
    // If the interface from Ex 1 didn't have it, we add it here conceptually.
    const expectedCurrency = vendorCurrencyMap[invoice.vendorName];
    
    // Mocking the check since 'currency' wasn't in the original Ex 1 interface
    // In a real scenario, we would check invoice.currency
    const hasCurrencyField = 'currency' in invoice; 
    // If we strictly follow the prompt, we might need to cast or extend the type.
    // Let's assume the interface was extended:
    // interface Invoice { ..., currency: string; }
    
    if (hasCurrencyField) {
       const actualCurrency = (invoice as any).currency;
       if (actualCurrency !== expectedCurrency) {
         errors.push(`Currency mismatch for ${invoice.vendorName}. Expected ${expectedCurrency}, got ${actualCurrency}.`);
       }
    } else {
       // If we can't check it, we log it as a data issue, but for the exercise logic:
       // We will simulate the check by assuming a property exists or adding it to the mock data.
    }
  }

  return {
    isValid: errors.length === 0,
    errors,
  };
}

// --- Conceptual Unit Tests ---
/*
describe('validateExtractedInvoice', () => {
  test('returns valid for a correct invoice', () => {
    const validInvoice: Invoice = { 
      invoiceId: '1', vendorName: 'AWS', totalAmount: 100, 
      invoiceDate: '2023-01-01T00:00:00Z', 
      lineItems: [{ description: 'Item', quantity: 1, unitPrice: 100 }] 
    };
    // Note: Add currency: 'USD' for the cross-field test
    expect(validateExtractedInvoice(validInvoice).isValid).toBe(true);
  });

  test('detects total mismatch', () => {
    const invalidInvoice: Invoice = { 
      invoiceId: '1', vendorName: 'Vendor', totalAmount: 90, 
      invoiceDate: '2023-01-01T00:00:00Z', 
      lineItems: [{ description: 'Item', quantity: 1, unitPrice: 100 }] 
    };
    const result = validateExtractedInvoice(invalidInvoice);
    expect(result.isValid).toBe(false);
    expect(result.errors).toContain("Total amount mismatch.");
  });

  test('detects invalid date format', () => {
    const invalidInvoice: Invoice = { 
      invoiceId: '1', vendorName: 'Vendor', totalAmount: 100, 
      invoiceDate: '1/1/2023', // Invalid format
      lineItems: [] 
    };
    const result = validateExtractedInvoice(invalidInvoice);
    expect(result.isValid).toBe(false);
    expect(result.errors).toContain("Invoice Date is missing or not a valid ISO 8601 string.");
  });

  test('detects cross-field currency violation (Interactive Challenge)', () => {
    const invalidInvoice: any = { 
      invoiceId: '1', vendorName: 'Stripe Inc.', totalAmount: 100, 
      invoiceDate: '2023-01-01T00:00:00Z', 
      lineItems: [], 
      currency: 'EUR' // Should be USD
    };
    const result = validateExtractedInvoice(invalidInvoice);
    expect(result.isValid).toBe(false);
    expect(result.errors).toContain("Currency mismatch for Stripe Inc.. Expected USD, got EUR.");
  });
});
*/
