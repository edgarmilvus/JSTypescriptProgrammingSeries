/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

// File: lib/stripeSync.ts
import Stripe from 'stripe';
import { Invoice } from '@/types/invoice';

// Initialize Stripe (ensure STRIPE_SECRET_KEY is in env)
const stripe = new Stripe(process.env.STRIPE_SECRET_KEY || 'sk_test_fake', {
  apiVersion: '2023-10-16',
});

export interface SyncResult {
  successes: { invoiceId: string; stripeInvoiceId: string }[];
  failures: { invoiceId: string; error: string }[];
}

/**
 * Single Invoice Sync (Base Logic)
 */
export async function syncSingleInvoice(invoice: Invoice): Promise<string> {
  try {
    // 1. Attempt to retrieve existing invoice by metadata
    // We assume we store our internal ID in metadata.custom_id
    const existingInvoices = await stripe.invoices.list({
      limit: 1,
      metadata: { custom_id: invoice.invoiceId },
    });

    let stripeInvoice: Stripe.Invoice;

    if (existingInvoices.data.length > 0) {
      // 2. Update Logic
      stripeInvoice = existingInvoices.data[0];
      // Note: Updating line items on a Stripe invoice usually requires deleting and recreating lines
      // or using InvoiceItems. For this exercise, we'll update metadata and description.
      await stripe.invoices.update(stripeInvoice.id, {
        metadata: {
          total_amount: invoice.totalAmount.toString(),
          vendor: invoice.vendorName,
        },
        description: `Updated for ${invoice.vendorName} - ${invoice.invoiceId}`,
      });
    } else {
      // 3. Create Logic
      // Note: In a real Stripe flow, you usually create a Customer first, then an Invoice.
      // We will mock the customer creation or use a default one for this exercise.
      const customer = await stripe.customers.create({
        name: invoice.vendorName,
        metadata: { internal_id: invoice.invoiceId },
      });

      stripeInvoice = await stripe.invoices.create({
        customer: customer.id,
        metadata: { custom_id: invoice.invoiceId },
        description: `Invoice for ${invoice.vendorName}`,
        // In a real scenario, you would add line items here
      });
    }

    return stripeInvoice.id;

  } catch (error) {
    // 4. Error Handling
    if (error instanceof Stripe.errors.StripeError) {
      throw new Error(`Stripe Error (${error.code}): ${error.message}`);
    }
    throw new Error(`Unknown Error syncing invoice ${invoice.invoiceId}`);
  }
}

/**
 * Batch Sync (Interactive Challenge)
 */
export async function syncInvoiceToStripe(invoices: Invoice | Invoice[]): Promise<SyncResult> {
  const invoicesArray = Array.isArray(invoices) ? invoices : [invoices];
  const result: SyncResult = { successes: [], failures: [] };

  // Process sequentially to avoid rate limits (simple approach)
  for (const invoice of invoicesArray) {
    try {
      const stripeId = await syncSingleInvoice(invoice);
      result.successes.push({ invoiceId: invoice.invoiceId, stripeInvoiceId: stripeId });
    } catch (error) {
      result.failures.push({ 
        invoiceId: invoice.invoiceId, 
        error: (error as Error).message 
      });
    }
  }

  return result;
}
