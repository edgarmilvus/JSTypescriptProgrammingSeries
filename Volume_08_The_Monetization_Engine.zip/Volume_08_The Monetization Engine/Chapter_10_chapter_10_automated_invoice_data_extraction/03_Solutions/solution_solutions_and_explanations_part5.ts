/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

digraph InvoicePipeline {
    rankdir=TB;
    node [shape=box, style=rounded];

    subgraph cluster_client {
        label = "Client Side";
        style = dashed;
        UserInterface [label="User Interface\n(File Upload Form)"];
        SuspenseBoundary [label="Suspense Boundary\n(Loading State)"];
        ErrorDisplay [label="Error UI\n(Retry Button)"];
    }

    subgraph cluster_server {
        label = "Server Side";
        style = dashed;
        
        AIServerComponent [label="AI Extraction Server Component\n(RSC)"];
        ValidationAction [label="Validation Function\n(Server Action)"];
        StripeAction [label="Stripe Integration\n(Server Action)"];
        
        DB_Raw [label="Vector DB\n(Raw PDF Data)", shape=cylinder];
        DB_Structured [label="SQL DB\n(Validated Data)", shape=cylinder];
    }

    // Flow Edges
    UserInterface -> SuspenseBoundary [label="1. Submit PDF"];
    SuspenseBoundary -> AIServerComponent [label="2. Process PDF\n(Async Stream)"];
    
    AIServerComponent -> DB_Raw [label="Store Raw Text/Image"];
    AIServerComponent -> ValidationAction [label="3. Structured JSON"];
    
    ValidationAction -> DB_Structured [label="Store Validated Data"];
    ValidationAction -> StripeAction [label="4. Validated Invoice"];
    
    StripeAction -> UserInterface [label="5. Success Confirmation"];
    
    // Error Flow
    AIServerComponent -> ErrorDisplay [label="Error\n(Extraction Failed)", style=dashed, color=red];
    ValidationAction -> ErrorDisplay [label="Validation Errors", style=dashed, color=red];
    StripeAction -> ErrorDisplay [label="API Error", style=dashed, color=red];
}
