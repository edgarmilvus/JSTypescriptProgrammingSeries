/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * @fileoverview A minimal TypeScript example demonstrating AI-powered UI localization.
 *              This script simulates translating a UI string from English to Spanish
 *              using a context-aware prompt.
 * @author AI Instructor
 */

// --- Type Definitions ---

/**
 * Represents the supported locales in our application.
 * Using a union type ensures type safety for locale identifiers.
 */
type Locale = 'en-US' | 'es-ES' | 'fr-FR';

/**
 * Represents the structure of the translation request sent to the AI.
 */
interface TranslationRequest {
  text: string;
  targetLocale: Locale;
  context: string; // e.g., "button_label", "error_message"
}

// --- Configuration & Constants ---

/**
 * Simulated AI Model Configuration.
 * In a real application, this would be an API endpoint (e.g., OpenAI, Anthropic).
 */
const AI_MODEL_CONFIG = {
  endpoint: 'https://api.openai.com/v1/chat/completions',
  model: 'gpt-4o-mini', // Efficient model for text generation
  maxTokens: 50,
};

// --- Core Logic ---

/**
 * Simulates an asynchronous call to an AI translation service.
 * 
 * Why Async? Network requests are non-blocking. We use async/await to handle
 * the Promise returned by the API call without freezing the execution thread.
 * 
 * @param request - The translation request object.
 * @returns A Promise resolving to the translated string.
 */
async function translateWithAI(request: TranslationRequest): Promise<string> {
  console.log(`[AI Service] Received request for locale: ${request.targetLocale}`);
  
  // In a real scenario, we would use fetch() here:
  // const response = await fetch(AI_MODEL_CONFIG.endpoint, {
  //   method: 'POST',
  //   headers: { 'Content-Type': 'application/json' },
  //   body: JSON.stringify({ ... })
  // });
  // const data = await response.json();
  // return data.choices[0].message.content;

  // SIMULATION: We mock the response based on the target locale.
  // This ensures the code is executable without external dependencies.
  if (request.targetLocale === 'es-ES') {
    // Simulating a slight delay for network latency
    await new Promise(resolve => setTimeout(resolve, 100)); 
    return "Iniciar sesión"; // "Log In" in Spanish
  } 
  
  if (request.targetLocale === 'fr-FR') {
    return "Se connecter"; // "Log In" in French
  }

  // Default to English if no specific translation logic exists
  return request.text;
}

/**
 * Detects the user's locale.
 * 
 * In a browser environment, this would typically access `navigator.language`.
 * For this server-side script, we simulate a detection mechanism.
 * 
 * @returns A detected Locale.
 */
function detectUserLocale(): Locale {
  // Simulation: Randomly select a locale to demonstrate dynamic behavior
  const locales: Locale[] = ['en-US', 'es-ES', 'fr-FR'];
  return locales[Math.floor(Math.random() * locales.length)];
}

/**
 * Main function to demonstrate the localization flow.
 * 
 * Logic Flow:
 * 1. Detect user locale.
 * 2. Check if translation is needed (e.g., is locale 'en-US' and text English?).
 * 3. Construct a context-aware prompt.
 * 4. Call the AI translation service.
 * 5. Update the UI (simulated via console logs).
 */
async function localizeUI() {
  // 1. Define the source UI text
  const sourceText = "Log In";
  const context = "authentication_button";

  // 2. Detect User Locale
  const userLocale = detectUserLocale();
  console.log(`\n--- Starting Localization Flow ---`);
  console.log(`Detected User Locale: ${userLocale}`);

  // 3. Check if translation is strictly necessary
  if (userLocale === 'en-US') {
    console.log(`[UI] Rendering text: "${sourceText}" (No translation needed)`);
    return;
  }

  // 4. Construct the Translation Request
  // CRITICAL: We include context in the prompt to ensure the AI understands
  // the semantic meaning (e.g., "Log In" as a button vs. "Log In" as a noun).
  const request: TranslationRequest = {
    text: sourceText,
    targetLocale: userLocale,
    context: `Translate the following UI text used in a "${context}" context. Maintain the brand voice: concise and action-oriented.`,
  };

  try {
    // 5. Call the AI Service (Asynchronous Tool Handling)
    const translatedText = await translateWithAI(request);

    // 6. Simulate UI Re-rendering
    // In a React app, this would trigger a state update (e.g., setText(translatedText)).
    console.log(`[AI Service] Received translation: "${translatedText}"`);
    console.log(`[UI] Re-rendering component with localized text: "${translatedText}"`);
    
  } catch (error) {
    console.error("[Error] Localization failed:", error);
    // Fallback to source text in case of error
    console.log(`[UI] Rendering fallback text: "${sourceText}"`);
  }
}

// --- Execution ---

// Execute the localization flow
localizeUI();
