/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.tsx
// Description: Advanced Application Script
// ==========================================

// File: components/LocalizedDashboard.tsx
'use client';

import React, { useState, useEffect, useMemo } from 'react';
import { translateText } from '@/lib/ai/localizationService'; // Assumed backend API wrapper

// ==========================================
// 1. Type Definitions & Interfaces
// ==========================================

/**
 * Represents the state of a translation for a specific UI element.
 * Uses Type Inference for the 'status' union.
 */
interface TranslationState {
  text: string; // The translated text
  status: 'loading' | 'success' | 'error';
}

/**
 * Defines the structure of our client-side cache.
 * Key: `${sourceText}|${locale}` -> Value: TranslationState
 */
type TranslationCache = Record<string, string>;

/**
 * Props for the LocalizedDashboard component.
 */
interface LocalizedDashboardProps {
  locale: 'en' | 'es' | 'fr' | 'de'; // Supported locales
}

// ==========================================
// 2. The Component: LocalizedDashboard
// ==========================================

/**
 * A dashboard component that dynamically localizes UI text using AI.
 * Implements a client-side cache to minimize API calls and latency.
 */
export default function LocalizedDashboard({ locale }: LocalizedDashboardProps) {
  // State to hold the translation cache (simulating an Upsert operation storage)
  const [cache, setCache] = useState<TranslationCache>({});
  
  // State for the specific text we are rendering (e.g., a dashboard header)
  const [headerText, setHeaderText] = useState<TranslationState>({ text: '', status: 'loading' });
  const [ctaText, setCtaText] = useState<TranslationState>({ text: '', status: 'loading' });

  // Source strings (Hardcoded for demo, usually from a localization keys file)
  const SOURCE_TEXTS = {
    header: 'Welcome to your Monetization Engine',
    cta: 'Configure Smart Dunning',
  };

  /**
   * Core Logic: The Translation Hook.
   * Checks cache -> Triggers API -> Updates Cache.
   * 
   * @param sourceText - The original English text to translate.
   * @param setter - The React state setter function for the specific UI element.
   */
  const getTranslation = async (sourceText: string, setter: React.Dispatch<React.SetStateAction<TranslationState>>) => {
    // 1. Cache Check (Upsert Logic: Read)
    const cacheKey = `${sourceText}|${locale}`;
    
    if (cache[cacheKey]) {
      setter({ text: cache[cacheKey], status: 'success' });
      return;
    }

    // 2. If not in cache, start loading
    setter((prev) => ({ ...prev, status: 'loading' }));

    try {
      // 3. Call the AI Service (Abstracted)
      // This function handles the LLM call and adheres to the Function Calling Schema
      const translated = await translateText(sourceText, locale);

      // 4. Update Cache (Upsert Logic: Write/Update)
      setCache((prevCache) => ({
        ...prevCache,
        [cacheKey]: translated, // This overwrites existing keys or adds new ones
      }));

      // 5. Update UI State
      setter({ text: translated, status: 'success' });
    } catch (error) {
      console.error("Localization failed:", error);
      setter({ text: sourceText, status: 'error' }); // Fallback to source text
    }
  };

  // Initialize translations on mount or locale change
  useEffect(() => {
    if (locale === 'en') {
      // No translation needed for English, instant load
      setHeaderText({ text: SOURCE_TEXTS.header, status: 'success' });
      setCtaText({ text: SOURCE_TEXTS.cta, status: 'success' });
      return;
    }

    getTranslation(SOURCE_TEXTS.header, setHeaderText);
    getTranslation(SOURCE_TEXTS.cta, setCtaText);
  }, [locale]);

  // ==========================================
  // 3. UI Rendering
  // ==========================================

  return (
    <div className="p-8 border rounded-lg shadow-sm bg-white max-w-2xl mx-auto mt-10">
      <header className="mb-6">
        <h1 className="text-2xl font-bold text-gray-900">
          {/* Fallback logic: Show source text if translation is loading or errored */}
          {headerText.status === 'loading' ? '...' : headerText.text}
        </h1>
        <p className="text-sm text-gray-500 mt-2">
          Current Locale: <span className="font-mono bg-gray-100 px-2 py-1 rounded">{locale}</span>
        </p>
      </header>

      <main className="space-y-4">
        <div className="p-4 bg-blue-50 border-l-4 border-blue-500">
          <p className="text-blue-700">
            {ctaText.status === 'loading' ? 'Loading translation...' : ctaText.text}
          </p>
        </div>

        <div className="text-xs text-gray-400 mt-4">
          <p>Cache Status: {Object.keys(cache).length} items stored.</p>
          <p>Debug Info: {JSON.stringify(cache, null, 2)}</p>
        </div>
      </main>
    </div>
  );
}
