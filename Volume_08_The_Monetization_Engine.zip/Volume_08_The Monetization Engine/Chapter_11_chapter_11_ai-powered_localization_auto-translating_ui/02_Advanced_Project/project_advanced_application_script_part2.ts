/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script_part2.ts
// Description: Advanced Application Script
// ==========================================

// File: lib/ai/localizationService.ts

/**
 * Defines the expected structure for the LLM's function call response.
 * This ensures the LLM returns a clean JSON object instead of natural language text.
 */
interface TranslationFunctionCall {
  name: 'submit_translation';
  arguments: {
    translated_text: string;
    cultural_context_note?: string;
  };
}

/**
 * Calls the LLM API with a strict function schema to translate text.
 * 
 * @param text - The source text.
 * @param targetLocale - The ISO locale code (e.g., 'es', 'fr').
 * @returns Promise<string> - The translated text.
 */
export async function translateText(text: string, targetLocale: string): Promise<string> {
  const systemPrompt = `
    You are a localization expert for a SaaS dashboard.
    Translate the text into ${targetLocale}.
    Maintain the brand voice: Professional, concise, and helpful.
    Do not change variables like {count} or {user}.
  `;

  // Function Calling Schema Definition
  const functions = [{
    name: 'submit_translation',
    description: 'Submits the translated text and context.',
    parameters: {
      type: 'object',
      properties: {
        translated_text: { type: 'string', description: 'The localized string.' },
        cultural_context_note: { type: 'string', description: 'Brief note on cultural adaptation.' }
      },
      required: ['translated_text']
    }
  }];

  // Mocking the API call to OpenAI or similar
  const response = await fetch('https://api.openai.com/v1/chat/completions', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${process.env.OPENAI_API_KEY}` },
    body: JSON.stringify({
      model: 'gpt-4',
      messages: [
        { role: 'system', content: systemPrompt },
        { role: 'user', content: text }
      ],
      functions: functions,
      function_call: { name: 'submit_translation' }
    })
  });

  const data = await response.json();
  
  // Parse the function call arguments returned by the LLM
  const args = JSON.parse(data.choices[0].message.function_call.arguments) as TranslationFunctionCall['arguments'];
  
  return args.translated_text;
}
