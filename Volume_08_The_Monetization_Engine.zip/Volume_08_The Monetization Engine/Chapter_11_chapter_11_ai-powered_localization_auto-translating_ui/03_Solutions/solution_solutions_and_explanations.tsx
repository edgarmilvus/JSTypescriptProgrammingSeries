/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.tsx
// Description: Solutions and Explanations
// ==========================================

"use client";

import { useState, ChangeEvent } from 'react';

// Define a strict type for supported locales to ensure type safety
type Locale = 'en' | 'es' | 'fr';

// Helper function to safely get the browser's language, falling back to 'en'
const getBrowserLocale = (): Locale => {
  if (typeof window !== 'undefined' && navigator.language) {
    const lang = navigator.language.split('-')[0]; // e.g., 'en-US' -> 'en'
    if (['en', 'es', 'fr'].includes(lang)) {
      return lang as Locale;
    }
  }
  return 'en';
};

export default function LocaleDetector() {
  // Initialize state with the browser's detected locale
  const [currentLocale, setCurrentLocale] = useState<Locale>(getBrowserLocale());

  const handleLocaleChange = (e: ChangeEvent<HTMLSelectElement>) => {
    // Update state with the new value, validated by the type definition
    setCurrentLocale(e.target.value as Locale);
  };

  return (
    <div style={{ padding: '20px', fontFamily: 'sans-serif' }}>
      <h2>Locale Manager</h2>
      
      <div style={{ marginBottom: '10px' }}>
        <label htmlFor="locale-select" style={{ marginRight: '10px' }}>
          Select Language:
        </label>
        <select 
          id="locale-select" 
          value={currentLocale} 
          onChange={handleLocaleChange}
        >
          <option value="en">English (en)</option>
          <option value="es">Spanish (es)</option>
          <option value="fr">French (fr)</option>
        </select>
      </div>

      <div style={{ padding: '10px', backgroundColor: '#f0f0f0', borderRadius: '4px' }}>
        <strong>Current Locale State:</strong> {currentLocale}
      </div>
    </div>
  );
}
