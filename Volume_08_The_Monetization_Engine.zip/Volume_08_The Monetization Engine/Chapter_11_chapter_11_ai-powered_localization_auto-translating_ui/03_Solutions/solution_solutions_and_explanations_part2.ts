/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

/**
 * Generates a structured prompt for an LLM to translate UI text contextually.
 * 
 * @param text - The source text to translate.
 * @param targetLocale - The target language code (e.g., 'es', 'fr').
 * @param context - Description of the UI element (e.g., 'Call-to-action button').
 * @returns A string prompt engineered for high-quality translation.
 */
export function generateTranslationPrompt(
  text: string,
  targetLocale: string,
  context: string
): string {
  // We use a template literal to construct a clear, multi-line instruction set.
  // This ensures the LLM understands the constraints.
  return `
    You are an expert UI/UX translator. Your task is to translate the following text into the target language.

    **Target Language:** ${targetLocale}
    **UI Context:** ${context}

    **Guidelines:**
    1. Translate the text accurately while maintaining the specific tone required for the context (e.g., buttons should be short and imperative, error messages should be clear and polite).
    2. Ensure the translation is concise and user-friendly for a modern web application.
    3. CRITICAL: Preserve any variables or placeholders exactly as they appear in the original text (e.g., {username}, {count}, {date}).
    4. Do not add explanatory notes. Return only the translated string.

    **Text to Translate:**
    "${text}"
  `;
}
