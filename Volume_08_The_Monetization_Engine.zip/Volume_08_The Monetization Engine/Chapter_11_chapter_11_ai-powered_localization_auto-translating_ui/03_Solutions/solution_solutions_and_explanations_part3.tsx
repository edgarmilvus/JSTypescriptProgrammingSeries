/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

"use client";

import React, { useState, useEffect, useContext, createContext } from 'react';

// --- Mock Global Context (Simulating the provider from Exercise 1) ---
type Locale = 'en' | 'es' | 'fr';
const LocaleContext = createContext<Locale>('en');

export const useLocale = () => useContext(LocaleContext);

// --- Mock Translation Service (Simulating the LLM call) ---
// In a real app, this would call an API endpoint.
const mockTranslate = async (text: string, locale: Locale, context: string): Promise<string> => {
  // Simulate network latency
  await new Promise(resolve => setTimeout(resolve, 600));
  
  // Simple mock logic for demonstration
  if (locale === 'es') {
    if (context === 'button') return `Botón: ${text}`; // Simulated translation
    return `ES: ${text}`;
  }
  if (locale === 'fr') {
    return `FR: ${text}`;
  }
  return text; // English
};

// --- In-Memory Cache ---
// Using a Map for O(1) lookups. Key is a composite string.
const translationCache = new Map<string, string>();

const getCacheKey = (text: string, locale: Locale, context: string): string => {
  return `${text}|${locale}|${context}`;
};

// --- The DynamicText Component ---
interface DynamicTextProps {
  children: string;
  context: string;
  className?: string;
}

export const DynamicText: React.FC<DynamicTextProps> = ({ children, context, className }) => {
  const locale = useLocale();
  const [translatedText, setTranslatedText] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(false);

  useEffect(() => {
    let isMounted = true;

    const fetchTranslation = async () => {
      // 1. Check Cache first
      const cacheKey = getCacheKey(children, locale, context);
      if (translationCache.has(cacheKey)) {
        if (isMounted) setTranslatedText(translationCache.get(cacheKey)!);
        return;
      }

      // 2. Set Loading State
      setIsLoading(true);

      try {
        // 3. Fetch Translation (Async)
        const result = await mockTranslate(children, locale, context);
        
        // 4. Update Cache and State
        if (isMounted) {
          translationCache.set(cacheKey, result);
          setTranslatedText(result);
        }
      } catch (error) {
        console.error("Translation failed:", error);
        // 5. Fallback to original text on error
        if (isMounted) setTranslatedText(children);
      } finally {
        if (isMounted) setIsLoading(false);
      }
    };

    fetchTranslation();

    return () => {
      isMounted = false;
    };
  }, [children, locale, context]); // Re-run effect when these change

  return (
    <span className={className}>
      {isLoading ? "..." : translatedText || children}
    </span>
  );
};
