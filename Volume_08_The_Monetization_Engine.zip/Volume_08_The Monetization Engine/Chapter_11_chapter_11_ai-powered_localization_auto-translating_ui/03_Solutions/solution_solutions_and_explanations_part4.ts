/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

type MarketingGoal = 'urgency' | 'trust' | 'exclusivity' | null;

/**
 * Generates a context-aware prompt with optional marketing optimization.
 */
export function generateTranslationPrompt(
  text: string,
  targetLocale: string,
  context: string,
  marketingGoal: MarketingGoal = null
): string {
  
  // Base prompt structure
  let prompt = `
    You are an expert UI/UX translator specializing in conversion optimization.
    
    **Target Language:** ${targetLocale}
    **UI Context:** ${context}
    **Original Text:** "${text}"

    **Core Instructions:**
    1. Translate the text accurately.
    2. Maintain a concise, user-friendly tone suitable for a modern web application.
    3. Preserve placeholders (e.g., {username}).
  `;

  // Add marketing-specific instructions if a goal is provided
  if (marketingGoal) {
    prompt += `
      
      **Marketing Optimization Goal: ${marketingGoal.toUpperCase()}**
      
      Adjust the translation to align with this goal:
    `;

    switch (marketingGoal) {
      case 'urgency':
        prompt += "- Use phrases that convey scarcity or limited time (e.g., 'Hurry', 'Last chance', 'Today only').\n";
        break;
      case 'trust':
        prompt += "- Use formal, reassuring language that builds credibility (e.g., 'Guaranteed', 'Secure', 'Official').\n";
        break;
      case 'exclusivity':
        prompt += "- Use language that implies VIP status or limited access (e.g., 'Premium', 'Invite-only', 'Elite').\n";
        break;
    }
  }

  prompt += "\n**Output:** Return only the translated string.";

  return prompt;
}

// --- Demonstration ---
const demoText = "Get Started Now";
const targetLocale = "es";
const context = "Hero Section Button";

console.log("--- Default Prompt ---");
console.log(generateTranslationPrompt(demoText, targetLocale, context));

console.log("\n--- Urgency Prompt ---");
console.log(generateTranslationPrompt(demoText, targetLocale, context, 'urgency'));

console.log("\n--- Trust Prompt ---");
console.log(generateTranslationPrompt(demoText, targetLocale, context, 'trust'));
