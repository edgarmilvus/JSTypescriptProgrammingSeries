/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

digraph LLM_Prompt_Generator {
    rankdir=TD;
    node [shape=box, style="rounded,filled", fillcolor="#e3f2fd"];
    edge [color="#555555"];

    Start [label="Start: Inputs\n(Text, Locale, Context)", shape=ellipse, fillcolor="#f3e5f5"];
    CheckGoal [label="Is Marketing Goal\nspecified?", shape=diamond, fillcolor="#fff3e0"];
    
    BuildBase [label="Construct Base Prompt\n(Generic Translation Rules)", shape=rect];
    
    BuildMarketing [label="Construct Marketing Prompt\n(Add Goal-Specific Instructions)", shape=rect, fillcolor="#e8f5e9"];
    
    Merge [label="Finalize Prompt\n(Append Output Constraints)", shape=rect, fillcolor="#fce4ec"];
    End [label="Return Prompt String", shape=ellipse, fillcolor="#f3e5f5"];

    Start -> CheckGoal;
    CheckGoal -> BuildBase [label="No"];
    CheckGoal -> BuildMarketing [label="Yes"];
    BuildBase -> Merge;
    BuildMarketing -> Merge;
    Merge -> End;
}
