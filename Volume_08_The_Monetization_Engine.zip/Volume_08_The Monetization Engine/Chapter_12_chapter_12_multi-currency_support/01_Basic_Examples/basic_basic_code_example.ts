/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * Multi-Currency Payment Processor with Smart Dunning Simulation
 * 
 * This script simulates a SaaS backend handling a payment intent for a user
 * in a different currency. It includes logic for currency conversion,
 * payment processing, and a basic dunning recovery mechanism.
 * 
 * Dependencies: None (Pure Node.js/TypeScript for demonstration)
 */

// --- 1. TYPES & INTERFACES ---

interface CurrencyExchangeRate {
    [key: string]: number; // e.g., 'USD_EUR': 0.92
}

interface PaymentIntent {
    id: string;
    amount: number; // Amount in smallest currency unit (e.g., cents)
    currency: string;
    status: 'requires_payment_method' | 'succeeded' | 'failed';
    customer_id: string;
}

interface DunningAttempt {
    attemptCount: number;
    nextRetryAt: Date | null;
    status: 'active' | 'recovered' | 'churned';
}

// --- 2. MOCK EXTERNAL SERVICES ---

/**
 * Simulates Stripe's API.
 * In a real app, this would be replaced by `stripe.paymentIntents.create()`.
 */
class MockStripe {
    async createPaymentIntent(amount: number, currency: string): Promise<PaymentIntent> {
        console.log(`[Stripe API] Creating intent for ${amount} ${currency.toUpperCase()}...`);
        
        // Simulate a random failure rate (e.g., 30%) to trigger dunning
        const isSuccessful = Math.random() > 0.3;

        return new Promise((resolve) => {
            setTimeout(() => {
                resolve({
                    id: `pi_${Math.random().toString(36).substring(7)}`,
                    amount,
                    currency,
                    status: isSuccessful ? 'succeeded' : 'failed',
                    customer_id: 'cus_12345'
                });
            }, 500); // Simulate network latency
        });
    }
}

/**
 * Simulates a database for storing dunning state.
 */
class DunningDatabase {
    private records: Map<string, DunningAttempt> = new Map();

    async getDunningRecord(paymentIntentId: string): Promise<DunningAttempt | null> {
        return this.records.get(paymentIntentId) || null;
    }

    async saveDunningRecord(paymentIntentId: string, record: DunningAttempt): Promise<void> {
        this.records.set(paymentIntentId, record);
        console.log(`[DB] Updated dunning record for ${paymentIntentId}:`, record);
    }
}

// --- 3. CORE LOGIC ---

/**
 * Simulates fetching an exchange rate. 
 * In production, this would call an API like Fixer.io or Stripe's own conversion.
 */
const getExchangeRate = (from: string, to: string): number => {
    const rates: CurrencyExchangeRate = {
        'USD_EUR': 0.92, // 1 USD = 0.92 EUR
        'USD_GBP': 0.79, // 1 USD = 0.79 GBP
        'USD_USD': 1.00
    };
    const key = `${from}_${to}`;
    return rates[key] || 1.00;
};

/**
 * Converts base price to localized currency (smallest unit).
 * @param baseAmountUsd - The price in USD dollars (e.g., 29.99)
 * @param targetCurrency - ISO code (e.g., 'EUR')
 * @returns Amount in cents/smallest unit
 */
function calculateLocalizedAmount(baseAmountUsd: number, targetCurrency: string): number {
    const rate = getExchangeRate('USD', targetCurrency);
    const converted = baseAmountUsd * rate;
    // Convert to smallest unit (cents) and round to avoid floating point errors
    return Math.round(converted * 100);
}

/**
 * The main payment processor function.
 * Handles the transaction flow and triggers dunning on failure.
 */
async function processPayment(
    basePrice: number, 
    currency: string, 
    stripe: MockStripe, 
    db: DunningDatabase
): Promise<void> {
    console.log(`\n--- Processing Payment for ${currency} ---`);
    
    // Step 1: Calculate localized amount
    const amountInCents = calculateLocalizedAmount(basePrice, currency);
    console.log(`Calculated Amount: ${basePrice} USD -> ${amountInCents} ${currency}`);

    // Step 2: Create Payment Intent
    const intent = await stripe.createPaymentIntent(amountInCents, currency);

    // Step 3: Handle Result (Smart Dunning Logic)
    if (intent.status === 'succeeded') {
        console.log(`✅ Payment Succeeded! ID: ${intent.id}`);
    } else {
        console.log(`❌ Payment Failed. Initiating Smart Dunning...`);
        await handleSmartDunning(intent.id, db);
    }
}

/**
 * Smart Dunning Handler.
 * Checks if we should retry or mark as churned.
 */
async function handleSmartDunning(paymentIntentId: string, db: DunningDatabase): Promise<void> {
    const existingRecord = await db.getDunningRecord(paymentIntentId);
    
    let attemptCount = 1;
    if (existingRecord) {
        attemptCount = existingRecord.attemptCount + 1;
    }

    // Simple logic: Retry up to 3 times, then mark as churned
    if (attemptCount < 3) {
        const nextRetry = new Date(Date.now() + 24 * 60 * 60 * 1000); // Retry in 24h
        const record: DunningAttempt = {
            attemptCount,
            nextRetryAt: nextRetry,
            status: 'active'
        };
        await db.saveDunningRecord(paymentIntentId, record);
        console.log(`🔔 Dunning Alert: Retry scheduled for ${nextRetry.toLocaleString()}`);
    } else {
        const record: DunningAttempt = {
            attemptCount,
            nextRetryAt: null,
            status: 'churned'
        };
        await db.saveDunningRecord(paymentIntentId, record);
        console.log(`⚠️ Max retries reached. Customer marked as CHURNED.`);
    }
}

// --- 4. EXECUTION ---

(async () => {
    const stripe = new MockStripe();
    const db = new DunningDatabase();

    // Scenario 1: User in Germany (EUR)
    await processPayment(29.99, 'EUR', stripe, db);

    // Scenario 2: User in UK (GBP)
    await processPayment(49.99, 'GBP', stripe, db);
})();
