/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// app/api/pricing/advanced-currency-engine.ts
// Target: Next.js API Route or Server Component Logic
// Concepts: Multi-Currency Support, Consensus Mechanism, SIMD-like Vectorization

import { NextResponse } from 'next/server';

// --- Types & Interfaces ---

/**
 * Represents a currency pair and its exchange rate.
 * e.g., { base: 'USD', target: 'EUR', rate: 0.92 }
 */
interface ExchangeRate {
  base: string;
  target: string;
  rate: number;
  source: string; // e.g., 'Stripe', 'OpenExchangeRates', 'Fallback'
}

/**
 * Represents a product price in the store's base currency (USD).
 */
interface ProductPrice {
  id: string;
  amount: number; // In cents (e.g., 1000 = $10.00)
  currency: string; // Base currency (USD)
}

/**
 * Result of the consensus verification.
 */
interface ConsensusResult {
  derivedRate: number;
  confidence: 'HIGH' | 'MEDIUM' | 'LOW';
  variance: number; // Percentage difference between sources
}

// --- Configuration ---

const BASE_CURRENCY = 'USD';
const TARGET_CURRENCY = 'EUR'; // Example: Displaying prices to EU customers
const CONSENSUS_THRESHOLD = 0.02; // 2% variance allowed before flagging

// --- 1. The "SIMD" Vector Processor ---
// Simulates WASM SIMD by performing bulk operations on arrays of data
// without explicit loops, leveraging functional programming patterns.

/**
 * Processes an array of product prices in bulk to convert them to a target currency.
 * This mimics the efficiency of Single Instruction, Multiple Data (SIMD) architectures.
 * 
 * @param prices - Array of base currency prices
 * @param rate - The validated exchange rate
 * @returns Array of converted prices
 */
function vectorizedCurrencyConversion(
  prices: ProductPrice[],
  rate: number
): number[] {
  // In a true SIMD environment, this multiplication happens on multiple data points 
  // simultaneously in CPU registers. Here, we use .map for a JS-equivalent abstraction.
  return prices.map((p) => p.amount * rate);
}

// --- 2. The Consensus Mechanism (Worker Agents) ---

/**
 * Simulates fetching exchange rates from a primary API (e.g., Stripe's internal rates).
 * @returns Promise<ExchangeRate>
 */
async function fetchPrimaryRate(): Promise<ExchangeRate> {
  // Simulate network latency
  await new Promise((resolve) => setTimeout(resolve, 100));
  return {
    base: BASE_CURRENCY,
    target: TARGET_CURRENCY,
    rate: 0.925, // Stripe's live rate (example)
    source: 'Stripe',
  };
}

/**
 * Simulates fetching rates from a secondary external provider (e.g., OpenExchangeRates).
 * @returns Promise<ExchangeRate>
 */
async function fetchSecondaryRate(): Promise<ExchangeRate> {
  await new Promise((resolve) => setTimeout(resolve, 150));
  return {
    base: BASE_CURRENCY,
    target: TARGET_CURRENCY,
    rate: 0.928, // Slightly different due to timing/source
    source: 'ExternalProvider',
  };
}

/**
 * Simulates a cached fallback rate (e.g., from Redis or local DB) for resilience.
 * @returns Promise<ExchangeRate>
 */
async function fetchFallbackRate(): Promise<ExchangeRate> {
  return {
    base: BASE_CURRENCY,
    target: TARGET_CURRENCY,
    rate: 0.920, // Stale but safe
    source: 'Cache',
  };
}

// --- 3. The Supervisor Agent (Consensus Logic) ---

/**
 * The Supervisor Agent. It compiles outputs from multiple worker agents (API calls),
 * compares them, and synthesizes a single robust rate.
 * 
 * Logic:
 * 1. Fetch rates concurrently.
 * 2. Calculate the mean and variance.
 * 3. If variance is within threshold, return high-confidence rate.
 * 4. If variance is high, flag for manual review or use median.
 */
async function synthesizeExchangeRate(): Promise<ConsensusResult> {
  try {
    // Execute worker agents in parallel (Event Loop optimization)
    const rates = await Promise.all([
      fetchPrimaryRate(),
      fetchSecondaryRate(),
      fetchFallbackRate(),
    ]);

    // Extract numeric rates
    const numericRates = rates.map((r) => r.rate);

    // Calculate Mean
    const sum = numericRates.reduce((acc, curr) => acc + curr, 0);
    const mean = sum / numericRates.length;

    // Calculate Variance (Standard Deviation squared)
    const variance = numericRates.reduce((acc, curr) => acc + Math.pow(curr - mean, 2), 0) / numericRates.length;
    const stdDev = Math.sqrt(variance);
    
    // Determine Confidence Level
    const variancePercentage = stdDev / mean;
    const confidence = variancePercentage < CONSENSUS_THRESHOLD ? 'HIGH' : 'LOW';

    // In a real scenario, if confidence is LOW, we might trigger an alert or use a median.
    // Here, we return the mean (averaged) rate for stability.
    return {
      derivedRate: mean,
      confidence,
      variance: variancePercentage,
    };
  } catch (error) {
    console.error("Consensus Agent failed:", error);
    // Fallback logic if all agents fail
    return {
      derivedRate: 0.90, // Emergency fallback
      confidence: 'LOW',
      variance: 1.0,
    };
  }
}

// --- 4. Main Execution Flow (Next.js API Route Handler) ---

/**
 * API Endpoint: /api/pricing/normalize
 * Handles the request to normalize a list of product prices to a target currency
 * using the consensus mechanism.
 */
export async function POST(request: Request) {
  const startTime = performance.now();

  try {
    const { products, targetCurrency } = await request.json();

    if (!products || !Array.isArray(products)) {
      return NextResponse.json({ error: "Invalid product list" }, { status: 400 });
    }

    // Step 1: Establish Consensus on Exchange Rate
    // This ensures we aren't displaying rates based on a single, potentially flaky source.
    const consensus = await synthesizeExchangeRate();

    // Step 2: Vectorized Conversion
    // Process the entire product list in a single optimized pass.
    const convertedPrices = vectorizedCurrencyConversion(products, consensus.derivedRate);

    // Step 3: Construct Response Payload
    const enrichedProducts = products.map((product, index) => ({
      ...product,
      originalAmount: product.amount,
      localizedAmount: convertedPrices[index],
      localizedCurrency: targetCurrency || TARGET_CURRENCY,
      rateSource: 'Consensus_Agent', // Metadata for transparency
      confidence: consensus.confidence,
    }));

    const endTime = performance.now();
    const processingTime = (endTime - startTime).toFixed(2);

    return NextResponse.json({
      status: 'success',
      metadata: {
        processingTimeMs: processingTime,
        consensus: consensus,
        simulatedSIMD: true, // Indicates vectorized processing
      },
      data: enrichedProducts,
    });

  } catch (error) {
    return NextResponse.json({ error: "Internal Server Error" }, { status: 500 });
  }
}
