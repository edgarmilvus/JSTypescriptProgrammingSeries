/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState, useEffect } from 'react';

// --- Interfaces ---
interface LocalizedPriceDisplayProps {
  basePrice: number;
  baseCurrency: string; // e.g., "USD"
  enableRegionalPricing?: boolean;
  regionalMultiplier?: number; // e.g., 1.1 for Europe
}

interface ExchangeRates {
  [key: string]: number;
}

// --- Component ---
const LocalizedPriceDisplay: React.FC<LocalizedPriceDisplayProps> = ({
  basePrice,
  baseCurrency,
  enableRegionalPricing = false,
  regionalMultiplier = 1.0,
}) => {
  const [selectedCurrency, setSelectedCurrency] = useState<string>('USD');
  const [exchangeRates, setExchangeRates] = useState<ExchangeRates | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  // Fetch exchange rates on mount or when base currency changes
  useEffect(() => {
    const fetchRates = async () => {
      setLoading(true);
      setError(null);
      try {
        // Using a mock API endpoint as requested
        const response = await fetch(`https://api.exchangerate.host/latest?base=${baseCurrency}`);
        if (!response.ok) {
          throw new Error('Network response was not ok');
        }
        const data = await response.json();
        setExchangeRates(data.rates);
      } catch (err) {
        setError('Error fetching rates');
        console.error(err);
      } finally {
        setLoading(false);
      }
    };

    fetchRates();
  }, [baseCurrency]);

  // Calculate final price
  let displayPrice = basePrice;
  let displayCurrency = selectedCurrency;

  if (exchangeRates && exchangeRates[selectedCurrency]) {
    // 1. Convert base price to selected currency
    let convertedPrice = basePrice * exchangeRates[selectedCurrency];

    // 2. Apply regional pricing multiplier if enabled
    if (enableRegionalPricing) {
      convertedPrice *= regionalMultiplier;
    }

    displayPrice = convertedPrice;
  }

  // Format the price using Intl.NumberFormat
  const formattedPrice = new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: displayCurrency,
  }).format(displayPrice);

  return (
    <div style={{ padding: '20px', border: '1px solid #ccc', borderRadius: '8px', maxWidth: '300px' }}>
      <h3>Localized Price Display</h3>
      
      {/* Currency Selector */}
      <div style={{ marginBottom: '10px' }}>
        <label>Select Currency: </label>
        <select 
          value={selectedCurrency} 
          onChange={(e) => setSelectedCurrency(e.target.value)}
          disabled={loading || !!error}
        >
          <option value="USD">USD</option>
          <option value="EUR">EUR</option>
          <option value="GBP">GBP</option>
          <option value="JPY">JPY</option>
        </select>
      </div>

      {/* Status Messages */}
      {loading && <p style={{ color: 'blue' }}>Loading...</p>}
      {error && <p style={{ color: 'red' }}>{error}</p>}

      {/* Price Display */}
      {!loading && !error && exchangeRates && (
        <div style={{ marginTop: '15px', fontSize: '1.2em', fontWeight: 'bold' }}>
          Price: {formattedPrice}
          {enableRegionalPricing && regionalMultiplier !== 1.0 && (
            <div style={{ fontSize: '0.8em', fontWeight: 'normal', color: '#555' }}>
              (Includes regional adjustment: {regionalMultiplier}x)
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default LocalizedPriceDisplay;
