/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

// --- Interfaces ---
interface FailedPayment {
  customerId: string;
  amount: number;
  currency: string;
  failureReason: 'insufficient_funds' | 'expired_card' | 'network_error' | string;
  retryCount: number;
  lastAttemptDate: Date;
}

interface DunningAction {
  customerId: string;
  nextRetryDate: Date;
  emailSubject: string;
  emailBody: string;
}

// --- Mock Worker Functions (Simulated) ---
const generateDunningStrategy = async (payment: FailedPayment): Promise<{ delayDays: number }> => {
  // Simulate processing time
  await new Promise(resolve => setTimeout(resolve, 50));
  
  let delay = 1;
  if (payment.failureReason === 'insufficient_funds') delay = 2;
  if (payment.failureReason === 'expired_card') delay = 5;
  
  return { delayDays: delay };
};

const validateDunningStrategy = async (payment: FailedPayment): Promise<{ delayDays: number }> => {
  // Simulate processing time
  await new Promise(resolve => setTimeout(resolve, 50));
  
  // Validation logic might be stricter
  let delay = 1;
  if (payment.failureReason === 'insufficient_funds') delay = 3; // Validator suggests 3 days
  if (payment.failureReason === 'expired_card') delay = 5;
  
  return { delayDays: delay };
};

// --- Main Function ---
const processDunningWorkflow = async (failedPayments: FailedPayment[]): Promise<DunningAction[]> => {
  const actions: DunningAction[] = [];

  for (const payment of failedPayments) {
    // 1. Parallel Execution of Consensus Mechanism
    const [strategy, validation] = await Promise.all([
      generateDunningStrategy(payment),
      validateDunningStrategy(payment)
    ]);

    // 2. Compare and Determine Final Delay (Fallback Rule: Use longer delay)
    let finalDelayDays: number;
    if (strategy.delayDays !== validation.delayDays) {
      console.log(`Consensus mismatch for ${payment.customerId}. Strategy: ${strategy.delayDays}, Validation: ${validation.delayDays}. Applying fallback.`);
      finalDelayDays = Math.max(strategy.delayDays, validation.delayDays);
    } else {
      finalDelayDays = strategy.delayDays;
    }

    // 3. Calculate Date
    const nextRetryDate = new Date(payment.lastAttemptDate);
    nextRetryDate.setDate(nextRetryDate.getDate() + finalDelayDays);

    // 4. Generate Localized Email Content
    const formatter = new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: payment.currency,
    });
    const formattedAmount = formatter.format(payment.amount);

    let subject = "";
    let body = "";

    // Simple localization mapping based on currency
    if (payment.currency === 'USD') {
      subject = `Payment Failed for ${formattedAmount}`;
      body = `Dear Customer, your payment of ${formattedAmount} failed. Please update your details.`;
    } else if (payment.currency === 'EUR') {
      subject = `Zahlung fehlgeschlagen für ${formattedAmount}`;
      body = `Sehr geehrter Kunde, Ihre Zahlung über ${formattedAmount} ist fehlgeschlagen.`;
    } else {
      subject = `Payment Failed (${formattedAmount})`;
      body = `Your payment of ${formattedAmount} failed.`;
    }

    // 5. Construct Action Object
    actions.push({
      customerId: payment.customerId,
      nextRetryDate,
      emailSubject: subject,
      emailBody: body,
    });
  }

  return actions;
};

// --- Example Usage (Mock Data) ---
/*
const mockPayments: FailedPayment[] = [
    { customerId: 'C1', amount: 50, currency: 'USD', failureReason: 'insufficient_funds', retryCount: 1, lastAttemptDate: new Date() },
    { customerId: 'C2', amount: 100, currency: 'EUR', failureReason: 'expired_card', retryCount: 0, lastAttemptDate: new Date() }
];

processDunningWorkflow(mockPayments).then(console.log);
*/
