/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

// --- Interfaces ---
interface InquiryResponse {
  response: string;
  detectedIntent: string;
  locale: string;
}

// --- Mock Tools (Async Functions) ---
const fetchTransactionDetails = async (transactionId: string): Promise<string> => {
  return new Promise(resolve => setTimeout(() => resolve(`Transaction ${transactionId} found: Status Failed`), 100));
};

const checkAccountBalance = async (customerId: string): Promise<string> => {
  return new Promise(resolve => setTimeout(() => resolve(`Balance for ${customerId}: $50.00`), 100));
};

// --- Main Agent Function ---
const handleBillingInquiry = async (query: string, locale: string): Promise<InquiryResponse> => {
  // 1. Intent Classification (Simple Keyword Matching)
  let detectedIntent = 'unknown';
  const lowerQuery = query.toLowerCase();

  if (lowerQuery.includes('rate') || lowerQuery.includes('currency') || lowerQuery.includes('exchange')) {
    detectedIntent = 'currency';
  } else if (lowerQuery.includes('fail') || lowerQuery.includes('error') || lowerQuery.includes('decline')) {
    detectedIntent = 'failure';
  } else if (lowerQuery.includes('refund') || lowerQuery.includes('return')) {
    detectedIntent = 'refund';
  }

  // 2. Response Generation based on Intent and Locale
  let response = '';

  if (detectedIntent === 'currency') {
    if (locale === 'en-US') {
      response = "You can view current exchange rates and conversion tools in your account settings under 'Financials'.";
    } else if (locale === 'de-DE') {
      response = "Sie können aktuelle Wechselkurse und Umrechnungstools in Ihren Kontoeinstellungen unter 'Finanzen' einsehen.";
    } else if (locale === 'ja-JP') {
      response = "為替レートは、アカウント設定の「財務」セクションで確認できます。";
    } else {
      response = "Exchange rates are available in your account settings.";
    }
  } 
  else if (detectedIntent === 'failure') {
    // Extract Transaction ID (Mock logic)
    const transactionIdMatch = query.match(/ID\s*(\w+)/i);
    const transactionId = transactionIdMatch ? transactionIdMatch[1] : 'Unknown-ID';
    const customerId = 'Cust-123'; // Mock customer ID

    // Interactive Challenge: Parallel Tool Execution
    const [txDetails, balance] = await Promise.all([
      fetchTransactionDetails(transactionId),
      checkAccountBalance(customerId)
    ]);

    if (locale === 'de-DE') {
      response = `Fehler bei Transaktion. Details: ${txDetails}. Kontostand: ${balance}. Bitte versuchen Sie es erneut.`;
    } else {
      response = `Payment failure detected. ${txDetails}. Current Balance: ${balance}. Please try again or update payment method.`;
    }
  } 
  else if (detectedIntent === 'refund') {
    if (locale === 'ja-JP') {
      response = "返金ポリシーについては、利用規約をご確認ください。";
    } else {
      response = "Please refer to our refund policy in the Terms of Service for details.";
    }
  } 
  else {
    // Unknown Intent Fallback
    if (locale === 'de-DE') {
      response = "Entschuldigung, ich habe Ihre Anfrage nicht verstanden. Bitte kontaktieren Sie den Support.";
    } else {
      response = "I'm sorry, I didn't understand your request. Please contact support.";
    }
  }

  return {
    response,
    detectedIntent,
    locale
  };
};

// --- Example Usage ---
/*
handleBillingInquiry("My payment failed for ID TX999", "en-US").then(console.log);
handleBillingInquiry("Warum ist die Zahlung fehlgeschlagen? ID TX999", "de-DE").then(console.log);
*/
