/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

// --- Interfaces ---
interface Transaction {
  id: string;
  amount: number;
  currency: string;
  countryCode: string;
  productType: string;
}

interface TaxReport {
  totalTransactions: number;
  totalGrossAmount: number; // Sum in USD
  totalTaxAmount: number;
  totalNetAmount: number;
  breakdownByCurrency: { [currency: string]: number }; // Net amount per currency
}

// --- Helper: Tax Calculation Logic ---
const calculateTax = (transaction: Transaction): { taxRate: number; taxAmount: number; netAmount: number } => {
  let taxRate = 0;
  
  // Apply region-specific tax rules
  if (transaction.countryCode.startsWith('DE')) {
    taxRate = 0.19; // 19% VAT
  } else if (transaction.countryCode.startsWith('AU')) {
    taxRate = 0.10; // 10% GST
  }

  const taxAmount = transaction.amount * taxRate;
  const netAmount = transaction.amount + taxAmount; // Gross + Tax

  return { taxRate, taxAmount, netAmount };
};

// --- Main Function ---
const generateTaxReport = (transactions: Transaction[]): TaxReport => {
  // Using reduce for aggregation
  const report = transactions.reduce((acc, tx) => {
    const { taxAmount, netAmount } = calculateTax(tx);
    
    // For simplicity, assume fixed mock rate 1.0 for USD conversion as requested
    // In a real scenario, we would multiply tx.amount by exchange rate here
    const usdEquivalent = tx.amount; 

    acc.totalTransactions += 1;
    acc.totalGrossAmount += usdEquivalent;
    acc.totalTaxAmount += taxAmount;
    acc.totalNetAmount += netAmount;

    // Breakdown by currency
    if (!acc.breakdownByCurrency[tx.currency]) {
      acc.breakdownByCurrency[tx.currency] = 0;
    }
    acc.breakdownByCurrency[tx.currency] += netAmount;

    return acc;
  }, {
    totalTransactions: 0,
    totalGrossAmount: 0,
    totalTaxAmount: 0,
    totalNetAmount: 0,
    breakdownByCurrency: {}
  } as TaxReport);

  return report;
};

// --- Interactive Challenge: SIMD Simulation ---
const vectorizedTaxCalculation = async (transactions: Transaction[], chunkSize: number = 2): Promise<TaxReport[]> => {
  // Split transactions into chunks
  const chunks: Transaction[][] = [];
  for (let i = 0; i < transactions.length; i += chunkSize) {
    chunks.push(transactions.slice(i, i + chunkSize));
  }

  // Process chunks in parallel using Promise.all
  const startParallel = performance.now();
  const reports = await Promise.all(
    chunks.map(chunk => new Promise<TaxReport>(resolve => {
      // Simulate async processing of a chunk
      setImmediate(() => {
        const report = generateTaxReport(chunk);
        resolve(report);
      });
    }))
  );
  const endParallel = performance.now();
  
  console.log(`Vectorized (Parallel) execution time: ${endParallel - startParallel}ms`);

  // Compare with Sequential approach (Simulated)
  const startSequential = performance.now();
  transactions.forEach(tx => calculateTax(tx)); // Just calculation, no reporting
  const endSequential = performance.now();
  
  console.log(`Sequential execution time: ${endSequential - startSequential}ms`);

  return reports;
};

// --- Example Usage ---
/*
const mockTransactions: Transaction[] = [
  { id: '1', amount: 100, currency: 'EUR', countryCode: 'DE', productType: 'Software' },
  { id: '2', amount: 200, currency: 'AUD', countryCode: 'AU', productType: 'Service' },
  { id: '3', amount: 50, currency: 'USD', countryCode: 'US', productType: 'Goods' }
];

// generateTaxReport(mockTransactions);
// vectorizedTaxCalculation(mockTransactions);
*/
