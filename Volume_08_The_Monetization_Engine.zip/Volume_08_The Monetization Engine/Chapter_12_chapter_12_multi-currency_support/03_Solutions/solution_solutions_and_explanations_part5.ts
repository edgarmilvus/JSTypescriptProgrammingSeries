/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

// --- Interfaces ---
interface Subscription {
  id: string;
  customerId: string;
  currency: string;
  amount: number;
  status: 'active' | 'past_due' | 'canceled';
}

interface PaymentAttempt {
  subscriptionId: string;
  amount: number;
  currency: string;
  timestamp: Date;
  idempotencyKey: string;
}

// --- Class Implementation ---
class SubscriptionManager {
  private subscriptions: Map<string, Subscription> = new Map();
  private paymentHistory: PaymentAttempt[] = [];
  private idempotencyCache: Map<string, any> = new Map();
  private auditLog: string[] = [];

  // Create a new subscription
  async createSubscription(sub: Subscription): Promise<string> {
    this.subscriptions.set(sub.id, sub);
    this.log(`Created subscription ${sub.id} for customer ${sub.customerId}`);
    return sub.id;
  }

  // Process payment with idempotency and retries
  async processPayment(attempt: PaymentAttempt): Promise<boolean> {
    // 1. Idempotency Check
    if (this.idempotencyCache.has(attempt.idempotencyKey)) {
      this.log(`Idempotency hit for key: ${attempt.idempotencyKey}`);
      return this.idempotencyCache.get(attempt.idempotencyKey);
    }

    // 2. Consensus Validation (Interactive Challenge)
    const isValid = await this.validatePayment(attempt);
    if (!isValid) {
      this.log(`Payment validation failed for ${attempt.subscriptionId}. Manual review required.`);
      this.handleFailure(attempt.subscriptionId);
      this.idempotencyCache.set(attempt.idempotencyKey, false);
      return false;
    }

    // 3. Simulate Payment Processing with Retry Logic
    let retries = 0;
    const maxRetries = 3;
    
    while (retries < maxRetries) {
      try {
        // Simulate random failure (20% chance)
        if (Math.random() < 0.2) {
          throw new Error('Random network failure');
        }
        
        // Success
        this.paymentHistory.push(attempt);
        this.log(`Payment processed successfully for ${attempt.subscriptionId}`);
        this.idempotencyCache.set(attempt.idempotencyKey, true);
        return true;

      } catch (error) {
        retries++;
        this.log(`Payment attempt ${retries} failed for ${attempt.subscriptionId}. Retrying...`);
        
        // Exponential Backoff: 2^retryCount * 100ms
        const delay = Math.pow(2, retries) * 100;
        await new Promise(resolve => setTimeout(resolve, delay));
      }
    }

    // Max retries exceeded
    this.handleFailure(attempt.subscriptionId);
    this.idempotencyCache.set(attempt.idempotencyKey, false);
    return false;
  }

  // Update subscription status on failure
  handleFailure(subId: string): void {
    const sub = this.subscriptions.get(subId);
    if (sub) {
      sub.status = 'past_due';
      this.log(`Subscription ${subId} marked as past_due`);
    }
  }

  // Interactive Challenge: Consensus Validation
  private async validatePayment(attempt: PaymentAttempt): Promise<boolean> {
    // Mock Worker Agents
    const fraudCheckAgent = async (): Promise<boolean> => {
      return new Promise(resolve => setTimeout(() => resolve(true), 50)); // Always passes
    };

    const limitCheckAgent = async (): Promise<boolean> => {
      return new Promise(resolve => setTimeout(() => resolve(true), 50)); // Always passes
    };

    try {
      // Run agents in parallel
      const [fraudResult, limitResult] = await Promise.all([
        fraudCheckAgent(),
        limitCheckAgent()
      ]);

      // Only proceed if BOTH return true
      return fraudResult && limitResult;
    } catch (error) {
      // Handle rejection in any worker
      console.error("Consensus worker error:", error);
      return false;
    }
  }

  private log(message: string): void {
    const timestamp = new Date().toISOString();
    this.auditLog.push(`[${timestamp}] ${message}`);
  }
}

// --- Example Usage ---
/*
const manager = new SubscriptionManager();
const subId = 'sub_123';
manager.createSubscription({ id: subId, customerId: 'cust_1', currency: 'USD', amount: 50, status: 'active' });

const attempt: PaymentAttempt = {
  subscriptionId: subId,
  amount: 50,
  currency: 'USD',
  timestamp: new Date(),
  idempotencyKey: 'key_1'
};

manager.processPayment(attempt).then(success => {
  console.log(`Final result: ${success}`);
});
*/
