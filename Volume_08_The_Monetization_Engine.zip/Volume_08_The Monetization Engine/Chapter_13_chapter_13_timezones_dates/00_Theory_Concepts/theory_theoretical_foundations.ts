/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: theory_theoretical_foundations.ts
// Description: Theoretical Foundations
// ==========================================

// The core representation of a temporal anchor in the database.
// All dates are stored as ISO 8601 strings in UTC.
interface BillingCycle {
  id: string;
  userId: string;
  
  // The anchor represents the "day" of the month (or specific date for annual)
  // This is independent of timezones.
  anchorDay: number; // e.g., 15th of the month
  
  // The IANA Time Zone Database identifier (e.g., "America/New_York")
  // This is crucial for converting the anchorDay into a specific UTC timestamp.
  userTimezone: string; 
  
  // The next time the billing engine should wake up for this user.
  // Calculated as: (Current UTC Time + Buffer) -> Converted to User Local -> Adjusted to Anchor
  nextScheduledEventUTC: Date; 
}

// The output of the Temporal Calculator, used for UI display and API responses.
interface LocalizedBillingEvent {
  eventId: string;
  type: 'RENEWAL' | 'DUNNING_RETRY' | 'GRACE_PERIOD_END';
  
  // The exact moment in time, stored in UTC for consistency.
  timestampUTC: Date;
  
  // The human-readable representation for the user.
  localizedDisplay: string; // e.g., "November 15, 10:00 AM EST"
  
  // Metadata used by Smart Dunning to decide retry logic.
  // Is the user currently in a "business hour" window?
  isWithinBusinessHours: boolean;
}

// The context passed to an AI Agent for support interactions.
interface TemporalContext {
  currentLocalTime: Date;
  userTimezone: string;
  lastPaymentAttempt: Date;
  
  // Calculates the optimal window for the next action.
  getNextOptimalWindow(hoursOffset: number): Date;
}
