/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * @fileoverview A basic example of timezone-aware subscription billing logic.
 * This simulates a backend service that calculates billing cycles for SaaS customers.
 * 
 * Key Concepts:
 * - Temporal Data: Using `Date` objects and timezones to manage subscription lifecycles.
 * - Billing Logic: Calculating the next billing date based on a fixed cycle (e.g., monthly).
 * - Perceived Performance: Pre-calculating due dates avoids complex real-time calculations.
 */

// Import the necessary library for timezone handling.
// In a real-world scenario, you might use `date-fns-tz` or `Luxon`.
// For this example, we'll use a simplified mock of a timezone library.
// In a Node.js environment, you might use `Intl.DateTimeFormat` directly.
// For simplicity, we will mock the `getTodayInTimezone` function.

// --- MOCK LIBRARY ---
// This is a placeholder for a real timezone library like `date-fns-tz`.
// It simulates getting the current date in a specific IANA timezone.
// We use this to avoid external dependencies for this "Hello World" example.
const getTodayInTimezone = (timezone: string): Date => {
    // In a real implementation, this would use Intl.DateTimeFormat to get the date in the target timezone.
    // For this example, we'll simulate it by returning a fixed date for demonstration purposes.
    // Let's assume today is '2023-10-27' in UTC, and we are checking for different timezones.
    // This is a critical simplification for the example.
    const now = new Date();
    // Using Intl to get the date string in the target timezone.
    const options: Intl.DateTimeFormatOptions = { 
        year: 'numeric', 
        month: '2-digit', 
        day: '2-digit',
        timeZone: timezone 
    };
    const dateString = new Intl.DateTimeFormat('en-US', options).format(now);
    // Convert the formatted string back to a Date object for calculation.
    return new Date(dateString);
};

// --- TYPE DEFINITIONS ---

/**
 * Represents a subscription in the system.
 */
interface Subscription {
    id: string;
    customerId: string;
    planId: string;
    status: 'active' | 'past_due' | 'canceled';
    /**
     * The IANA timezone string for the customer (e.g., 'America/New_York').
     * This is crucial for calculating billing dates in the customer's local time.
     */
    timezone: string;
    /**
     * The date the subscription started (ISO 8601 string).
     */
    startDate: string;
    /**
     * The date the next payment is due (ISO 8601 string).
     * This is pre-calculated and stored to avoid real-time computation.
     */
    nextBillingDate: string;
    /**
     * The billing cycle interval in days (e.g., 30 for monthly).
     */
    billingIntervalDays: number;
}

// --- CORE LOGIC ---

/**
 * Calculates the next billing date for a subscription based on its start date and interval.
 * This function is timezone-aware, meaning it calculates the date in the customer's timezone.
 *
 * @param {Subscription} subscription - The subscription object.
 * @returns {Date} The calculated next billing date in the customer's timezone.
 */
function calculateNextBillingDate(subscription: Subscription): Date {
    // 1. Parse the start date.
    const startDate = new Date(subscription.startDate);
    
    // 2. Get the current date in the customer's timezone.
    // This is the most critical step for accurate billing.
    const todayInCustomerTimezone = getTodayInTimezone(subscription.timezone);
    
    // 3. Calculate the time difference between today and the start date.
    // We use the time in the customer's timezone for this comparison.
    const timeDiff = todayInCustomerTimezone.getTime() - startDate.getTime();
    
    // 4. Calculate the number of days that have passed since the start date.
    const daysPassed = Math.floor(timeDiff / (1000 * 60 * 60 * 24));
    
    // 5. Determine how many full billing cycles have passed.
    const cyclesPassed = Math.floor(daysPassed / subscription.billingIntervalDays);
    
    // 6. Calculate the next billing date by adding the number of cycles and the interval to the start date.
    const nextBillingDate = new Date(startDate);
    nextBillingDate.setDate(startDate.getDate() + (cyclesPassed + 1) * subscription.billingIntervalDays);
    
    // 7. Return the calculated next billing date.
    return nextBillingDate;
}

/**
 * Checks a list of subscriptions and updates their status based on the current date.
 * This simulates a daily cron job that runs to update subscription statuses.
 * 
 * @param {Subscription[]} subscriptions - An array of subscription objects.
 * @returns {Subscription[]} - The updated list of subscriptions.
 */
function checkForDueSubscriptions(subscriptions: Subscription[]): Subscription[] {
    const updatedSubscriptions: Subscription[] = [];

    for (const sub of subscriptions) {
        // 1. Get the current date in the subscription's timezone.
        const todayInCustomerTimezone = getTodayInTimezone(sub.timezone);
        
        // 2. Parse the stored next billing date.
        const nextBillingDate = new Date(sub.nextBillingDate);
        
        // 3. Compare the dates. If today is on or after the next billing date, the subscription is due.
        // We compare only the date part (year, month, day) to ignore time differences.
        if (todayInCustomerTimezone >= nextBillingDate) {
            // 4. Update the subscription status to 'past_due'.
            // In a real system, this would trigger a payment retry or a dunning email.
            const updatedSub: Subscription = { ...sub, status: 'past_due' };
            updatedSubscriptions.push(updatedSub);
        } else {
            // If not due, keep the subscription as is.
            updatedSubscriptions.push(sub);
        }
    }

    return updatedSubscriptions;
}

// --- USAGE EXAMPLE ---

// Sample data: Two customers in different timezones.
// Customer A is in New York (UTC-5/-4). Customer B is in London (UTC+0/+1).
const sampleSubscriptions: Subscription[] = [
    {
        id: 'sub_001',
        customerId: 'cust_A',
        planId: 'plan_pro',
        status: 'active',
        timezone: 'America/New_York',
        startDate: '2023-10-01T00:00:00Z', // Started on Oct 1st
        nextBillingDate: '2023-10-31T00:00:00Z', // Next billing date is Oct 31st
        billingIntervalDays: 30, // Monthly subscription
    },
    {
        id: 'sub_002',
        customerId: 'cust_B',
        planId: 'plan_basic',
        status: 'active',
        timezone: 'Europe/London',
        startDate: '2023-09-15T00:00:00Z', // Started on Sep 15th
        nextBillingDate: '2023-10-15T00:00:00Z', // Next billing date is Oct 15th
        billingIntervalDays: 30, // Monthly subscription
    },
];

// Simulate a daily check. Let's assume today is '2023-10-27' in UTC.
// In New York, it's still Oct 27th. In London, it's also Oct 27th.
// For Customer A (NY), nextBillingDate is Oct 31st. Today (Oct 27) is BEFORE Oct 31st. Status remains 'active'.
// For Customer B (London), nextBillingDate is Oct 15th. Today (Oct 27) is AFTER Oct 15th. Status becomes 'past_due'.

const dueSubscriptions = checkForDueSubscriptions(sampleSubscriptions);

console.log('--- Subscription Status Check ---');
dueSubscriptions.forEach(sub => {
    console.log(`Subscription ${sub.id} (${sub.timezone}): Status is now ${sub.status}`);
});

// Example of calculating a new next billing date for a new subscription.
const newSubscription: Subscription = {
    id: 'sub_003',
    customerId: 'cust_C',
    planId: 'plan_enterprise',
    status: 'active',
    timezone: 'Asia/Tokyo',
    startDate: '2023-10-20T00:00:00Z',
    nextBillingDate: '', // Will be calculated
    billingIntervalDays: 30,
};

const calculatedNextBillingDate = calculateNextBillingDate(newSubscription);
console.log(`\n--- New Subscription Calculation ---`);
console.log(`For Subscription ${newSubscription.id} in ${newSubscription.timezone}:`);
console.log(`Calculated Next Billing Date: ${calculatedNextBillingDate.toISOString()}`);
