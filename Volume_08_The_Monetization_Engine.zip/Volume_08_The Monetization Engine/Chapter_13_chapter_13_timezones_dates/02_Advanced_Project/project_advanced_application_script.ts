/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// pages/api/smart-dunning.ts
// Next.js API Route Handler (TypeScript)

import type { NextApiRequest, NextApiResponse } from 'next';
import { DateTime, Interval } from 'luxon'; // Essential for robust timezone handling
import { Readable } from 'stream';

/**
 * @typedef {Object} CustomerProfile
 * @property {string} id - The unique identifier for the customer.
 * @property {string} stripeId - The corresponding Stripe Customer ID.
 * @property {string} timezone - IANA timezone string (e.g., "America/New_York").
 * @property {Date} lastPaymentAttempt - Timestamp of the previous failed attempt.
 * @property {number} retryCount - Number of consecutive failures.
 */

/**
 * @typedef {Object} DunningEvent
 * @property {string} type - The event type (e.g., 'processing', 'scheduled', 'error').
 * @property {string} message - Human-readable status update.
 * @property {Object} data - Payload containing specific calculation details.
 */

// MOCK DATABASE: In a real app, this would be a Prisma/SQL query.
const CUSTOMER_DB: CustomerProfile[] = [
  {
    id: 'cust_001',
    stripeId: 'cus_12345',
    timezone: 'America/New_York',
    lastPaymentAttempt: new Date(Date.now() - 1000 * 60 * 60 * 24), // 24 hours ago
    retryCount: 1,
  },
  {
    id: 'cust_002',
    stripeId: 'cus_67890',
    timezone: 'Europe/London',
    lastPaymentAttempt: new Date(Date.now() - 1000 * 60 * 90), // 90 mins ago
    retryCount: 3, // High retry count implies higher urgency
  },
];

/**
 * API Handler: Smart Dunning Orchestrator
 * 
 * 1. Accepts a customerId via query param.
 * 2. Establishes an SSE stream for real-time feedback.
 * 3. Calculates the optimal retry window based on customer timezone.
 * 4. Streams the calculation logic back to the client.
 */
export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  // CORS & Method Validation
  if (req.method !== 'GET') {
    return res.status(405).json({ error: 'Method Not Allowed' });
  }

  const { customerId } = req.query;

  if (!customerId || typeof customerId !== 'string') {
    return res.status(400).json({ error: 'Missing or invalid customerId' });
  }

  // 1. Retrieve Customer Context
  const customer = CUSTOMER_DB.find((c) => c.id === customerId);
  if (!customer) {
    return res.status(404).json({ error: 'Customer not found' });
  }

  // 2. Setup Server-Sent Events (SSE) Headers
  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache');
  res.setHeader('Connection', 'keep-alive');
  res.setHeader('X-Accel-Buffering', 'no'); // Disable buffering for Nginx

  // 3. Create a Readable Stream to push events
  const stream = new Readable({
    read() {}, // No-op required for custom stream
  });

  // Pipe the stream to the response
  stream.pipe(res);

  /**
   * Helper: Send data to the client via SSE format
   * Format: `event: <type>\ndata: <json_payload>\n\n`
   */
  const sendEvent = (type: string, message: string, data: object = {}) => {
    const payload = JSON.stringify({ type, message, data });
    stream.push(`event: dunning-update\ndata: ${payload}\n\n`);
  };

  /**
   * Helper: Simulate async processing delay
   */
  const delay = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

  /**
   * CORE LOGIC BLOCK: Timezone-Aware Scheduling
   * 
   * Determines the next retry timestamp ensuring it falls within
   * local business hours (e.g., 9 AM - 6 PM).
   */
  const calculateOptimalRetryTime = (customer: CustomerProfile): Date => {
    const nowUTC = DateTime.utc();
    
    // Convert customer's timezone to a Luxon object
    const customerLocalTime = nowUTC.setZone(customer.timezone);
    
    // Define Business Hours (9 AM to 6 PM)
    const businessStart = 9;
    const businessEnd = 18;

    // Logic: If it's currently within business hours, schedule for later today
    // If it's outside, schedule for tomorrow morning.
    // If retryCount is high, we might shorten the interval (e.g., 4 hours later).
    
    let targetTime: DateTime;

    if (customerLocalTime.hour >= businessStart && customerLocalTime.hour < businessEnd) {
      // Currently in business hours
      // If high urgency (retryCount > 2), retry in 4 hours. Otherwise, next day.
      const hoursToAdd = customer.retryCount > 2 ? 4 : 24;
      targetTime = customerLocalTime.plus({ hours: hoursToAdd });
    } else {
      // Outside business hours
      // If late at night, schedule for 9 AM tomorrow.
      targetTime = customerLocalTime.plus({ days: 1 }).set({ hour: businessStart, minute: 0, second: 0 });
    }

    // Edge Case: Ensure we don't schedule in the past (rare, but possible with timezone math)
    if (targetTime < customerLocalTime) {
      targetTime = customerLocalTime.plus({ hours: 1 });
    }

    return targetTime.toUTC().toJSDate(); // Return as JS Date object (UTC)
  };

  /**
   * Execution Flow
   */
  (async () => {
    try {
      // Step 1: Initiate
      sendEvent('init', `Starting Smart Dunning analysis for customer in ${customer.timezone}...`);
      await delay(500);

      // Step 2: Analyze Temporal Context
      sendEvent('analyzing', 'Analyzing local time and business hours...');
      await delay(800);

      // Step 3: Calculate Retry Time
      const optimalRetryDate = calculateOptimalRetryTime(customer);
      const localTimeStr = DateTime.fromJSDate(optimalRetryDate).setZone(customer.timezone).toFormat('ff');

      sendEvent('calculated', 'Optimal retry time calculated.', {
        utcTimestamp: optimalRetryDate.toISOString(),
        localDisplay: localTimeStr,
        timezone: customer.timezone,
        strategy: customer.retryCount > 2 ? 'High Urgency (4h)' : 'Standard (24h)',
      });

      await delay(600);

      // Step 4: Simulate Stripe API Call (Mock)
      sendEvent('processing', 'Contacting Stripe API to schedule payment retry...');
      await delay(1000);

      // Step 5: Success
      sendEvent('success', 'Payment retry scheduled successfully.', {
        stripeInvoiceId: 'in_123456789',
        nextAttempt: optimalRetryDate.toISOString(),
      });

      // End Stream
      stream.push(null);

    } catch (error) {
      const errMsg = error instanceof Error ? error.message : 'Unknown error';
      sendEvent('error', 'Dunning process failed.', { error: errMsg });
      stream.push(null);
    }
  })();
}

/**
 * FRONTEND CONSUMPTION EXAMPLE (Conceptual React Component)
 * 
 * const eventSource = new EventSource(`/api/smart-dunning?customerId=cust_001`);
 * 
 * eventSource.onmessage = (event) => {
 *   const parsed = JSON.parse(event.data);
 *   console.log(`[${parsed.type}]: ${parsed.message}`);
 *   // Update UI state (e.g., show a toast, update a progress bar)
 * };
 */
