/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// File: utils/billing.ts

import { zonedTimeToUtc, utcToZonedTime, format } from 'date-fns-tz';

/**
 * Calculates the next billing date for a user in their specific timezone.
 * 
 * @param startDate - The ISO 8601 string of when the subscription began.
 * @param interval - 'month' or 'year'.
 * @param userTimezone - IANA timezone string (e.g., 'America/New_York').
 * @returns The next billing date in UTC as an ISO 8601 string.
 */
export const calculateNextBillingDate = (
  startDate: string,
  interval: 'month' | 'year',
  userTimezone: string
): string => {
  // 1. Validate Input
  const startUtcDate = new Date(startDate);
  if (isNaN(startUtcDate.getTime())) {
    throw new Error('Invalid ISO 8601 date string provided.');
  }

  // 2. Convert UTC start date to the user's local time to extract the specific time (e.g., 09:00)
  const userLocalStart = utcToZonedTime(startUtcDate, userTimezone);
  
  // Extract components to reconstruct the time in local context
  const hours = userLocalStart.getHours();
  const minutes = userLocalStart.getMinutes();
  const seconds = userLocalStart.getSeconds();
  const milliseconds = userLocalStart.getMilliseconds();

  // 3. Calculate the next billing date in User's Local Time
  // We create a new date object based on the local start time, then add the interval.
  let nextLocalDate = new Date(userLocalStart);

  if (interval === 'month') {
    nextLocalDate.setMonth(nextLocalDate.getMonth() + 1);
  } else {
    nextLocalDate.setFullYear(nextLocalDate.getFullYear() + 1);
  }

  // 4. Handle Month-End Boundaries
  // If adding a month results in a date in the following month (e.g., Jan 31 + 1 month = March 3),
  // the Date object automatically corrects this. We want to bill on the *last day* of the target month
  // if the original day doesn't exist (e.g., billing on the 31st).
  // However, standard subscription logic usually maintains the day of the month if possible.
  // The logic above handles the "day overflow" naturally by JS Date behavior.
  
  // 5. Convert the calculated Local Time back to UTC
  // We need the exact local time string to convert accurately.
  // We format the local date to a string, then parse it as if it were in the user's timezone.
  const nextLocalDateStr = format(nextLocalDate, "yyyy-MM-dd HH:mm:ss.SSS", { timeZone: userTimezone });
  
  // Convert that local string representation back to a UTC Date object
  const nextUtcDate = zonedTimeToUtc(nextLocalDateStr, userTimezone);

  // 6. Return ISO 8601 UTC String
  return nextUtcDate.toISOString();
};
