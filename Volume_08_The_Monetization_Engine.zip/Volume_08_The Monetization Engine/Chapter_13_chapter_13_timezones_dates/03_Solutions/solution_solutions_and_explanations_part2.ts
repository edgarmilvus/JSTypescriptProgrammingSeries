/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

// File: services/dunning.ts

import { addHours, isWithinInterval, setHours, startOfDay } from 'date-fns';
import { utcToZonedTime, zonedTimeToUtc, format } from 'date-fns-tz';

/**
 * Calculates the optimal retry time for a failed payment using smart dunning logic.
 * 
 * @param currentUtcTime - The current time in UTC (ISO string).
 * @param failureCount - The number of consecutive payment failures.
 * @param userTimezone - IANA timezone string.
 * @returns The UTC timestamp for the next retry attempt.
 */
export const calculateNextRetryTime = (
  currentUtcTime: string,
  failureCount: number,
  userTimezone: string
): string => {
  const now = new Date(currentUtcTime);
  
  // 1. Calculate Base Exponential Backoff Interval
  // Base 1 hour, doubling per failure. Cap at 168 hours (7 days).
  const baseIntervalHours = 1;
  const rawHours = baseIntervalHours * Math.pow(2, failureCount - 1);
  const cappedHours = Math.min(rawHours, 168); // 7 days cap

  // 2. Calculate Tentative Next Retry Time (UTC)
  const tentativeRetryUtc = addHours(now, cappedHours);

  // 3. Convert Tentative Time to User's Local Timezone
  const userLocalTime = utcToZonedTime(tentativeRetryUtc, userTimezone);

  // 4. Define Business Hours (9 AM to 5 PM)
  const startBusinessHour = 9;
  const endBusinessHour = 17; // 5 PM

  // Check if the tentative time falls within business hours
  const currentHour = userLocalTime.getHours();
  
  let finalLocalDate = userLocalTime;

  if (currentHour < startBusinessHour || currentHour >= endBusinessHour) {
    // If outside business hours, snap to the next 9 AM slot.
    
    // If we are before 9 AM today, schedule for 9 AM today.
    // If we are after 5 PM, schedule for 9 AM tomorrow.
    let targetDate = startOfDay(userLocalTime);
    
    if (currentHour >= endBusinessHour) {
      // Move to next day
      targetDate = addHours(targetDate, 24); 
    }
    
    // Set to 9:00 AM
    finalLocalDate = setHours(targetDate, startBusinessHour);
  }

  // 5. Convert Final Local Time back to UTC
  // Format the local date string to ensure precision, then convert
  const finalLocalStr = format(finalLocalDate, "yyyy-MM-dd HH:mm:ss.SSS", { timeZone: userTimezone });
  const finalUtcDate = zonedTimeToUtc(finalLocalStr, userTimezone);

  return finalUtcDate.toISOString();
};
