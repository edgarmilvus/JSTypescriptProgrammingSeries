/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

// File: components/BillingCycleToggle.tsx

import React, { useState, useTransition } from 'react';

interface BillingCycleToggleProps {
  initialCycle: 'month' | 'year';
}

const BillingCycleToggle: React.FC<BillingCycleToggleProps> = ({ initialCycle }) => {
  const [cycle, setCycle] = useState(initialCycle);
  // useTransition returns a state tuple: [isPending, startTransition]
  const [isPending, startTransition] = useStateTransition();
  const [error, setError] = useState<string | null>(null);

  // Helper to simulate API latency and potential failure
  const simulateApiCall = async (newCycle: 'month' | 'year'): Promise<void> => {
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        // Simulate a 20% chance of failure
        if (Math.random() > 0.2) {
          console.log(`API Success: Cycle updated to ${newCycle}`);
          resolve();
        } else {
          console.log('API Failure: Network Error');
          reject(new Error('Network Error'));
        }
      }, 1000);
    });
  };

  const toggleCycle = () => {
    const newCycle = cycle === 'month' ? 'year' : 'month';
    const previousCycle = cycle; // Store for rollback

    // Start the transition
    startTransition(async () => {
      // 1. Optimistic Update: Update UI immediately
      setCycle(newCycle);
      setError(null);

      try {
        // 2. Background Work: Call API
        await simulateApiCall(newCycle);
      } catch (err) {
        // 3. Rollback Logic: Revert state on failure
        setCycle(previousCycle);
        setError('Failed to update billing cycle. Please try again.');
      }
    });
  };

  return (
    <div className="billing-toggle" style={{ padding: '20px', border: '1px solid #ccc', borderRadius: '8px' }}>
      <p>Current Cycle: <strong>{cycle}</strong></p>
      
      <button 
        onClick={toggleCycle} 
        disabled={isPending}
        style={{ 
          padding: '8px 16px', 
          cursor: isPending ? 'not-allowed' : 'pointer',
          opacity: isPending ? 0.7 : 1 
        }}
      >
        {isPending ? 'Updating...' : `Switch to ${cycle === 'month' ? 'Yearly' : 'Monthly'}`}
      </button>
      
      {error && (
        <div style={{ color: 'red', marginTop: '10px', fontSize: '0.9rem' }}>
          {error}
        </div>
      )}
    </div>
  );
};

// Mock implementation of useTransition for environments where it might not be available 
// (e.g., older React versions or strict mode without experimental features)
// In a real React 18+ app, you would import this directly.
function useStateTransition() {
    // This is a wrapper to ensure the code compiles if useTransition isn't strictly typed in the environment
    return React.useTransition();
}

export default BillingCycleToggle;
