/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

// File: ai/contextEngine.ts

import { utcToZonedTime, format } from 'date-fns-tz';
import { calculateNextRetryTime } from '../services/dunning';

// 1. Define the Interface
export interface AITemporalContext {
  userTimezone: string;
  billingHistory: Array<{ date: string; amount: number }>;
  latestPaymentStatus: 'success' | 'failed';
  nextRetryTime?: string;
}

// Mock Database State
const mockDb = {
  'user_123': {
    timezone: 'America/Los_Angeles',
    billingHistory: [
      { date: '2023-09-15T09:00:00Z', amount: 49.99 },
      { date: '2023-10-15T09:00:00Z', amount: 49.99 },
      { date: '2023-11-15T09:00:00Z', amount: 49.99 },
    ],
    paymentStatus: 'success' as const,
    failureCount: 0,
  },
  'user_456': {
    timezone: 'Asia/Tokyo',
    billingHistory: [
      { date: '2023-09-01T01:00:00Z', amount: 99.00 },
      { date: '2023-10-01T01:00:00Z', amount: 99.00 },
      { date: '2023-11-01T01:00:00Z', amount: 99.00 },
    ],
    paymentStatus: 'failed' as const,
    failureCount: 3, // Triggering higher backoff
  },
};

/**
 * Simulates fetching temporal context for an AI Support Agent.
 */
export const fetchTemporalContextForAI = async (
  userId: string
): Promise<AITemporalContext> => {
  // Simulate network delay
  await new Promise(resolve => setTimeout(resolve, 500));

  const user = mockDb[userId];
  if (!user) {
    throw new Error('User not found');
  }

  // 2. Convert Billing History to User's Local Time
  const localBillingHistory = user.billingHistory.map(event => {
    const localDate = utcToZonedTime(event.date, user.timezone);
    // Format: "Oct 12, 2023, 10:00 AM"
    const formattedDate = format(localDate, 'MMM dd, yyyy, hh:mm a', { timeZone: user.timezone });
    return {
      date: formattedDate,
      amount: event.amount
    };
  });

  // 3. Calculate Next Retry Time if applicable
  let nextRetryTime: string | undefined;
  if (user.paymentStatus === 'failed') {
    const nowUtc = new Date().toISOString();
    // Using the logic from Exercise 2
    nextRetryTime = calculateNextRetryTime(nowUtc, user.failureCount, user.timezone);
  }

  // 4. Return Structured Context
  return {
    userTimezone: user.timezone,
    billingHistory: localBillingHistory,
    latestPaymentStatus: user.paymentStatus,
    nextRetryTime,
  };
};
