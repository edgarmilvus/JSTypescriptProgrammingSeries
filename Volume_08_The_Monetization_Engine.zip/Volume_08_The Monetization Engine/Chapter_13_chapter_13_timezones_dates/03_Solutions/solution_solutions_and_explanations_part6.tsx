/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part6.tsx
// Description: Solutions and Explanations
// ==========================================

// File: components/BillingDashboard.tsx

import React, { useState, useEffect } from 'react';

// 1. Define Data Interface
interface BillingData {
  nextBillingDate: string;
  userTimezone: string;
}

// 2. Skeleton Sub-component
const Skeleton: React.FC = () => {
  return (
    <div className="skeleton-container">
      <div className="skeleton-wrapper">
        <div className="skeleton-line" style={{ width: '60%', height: '24px', marginBottom: '12px' }}></div>
        <div className="skeleton-line" style={{ width: '40%', height: '18px' }}></div>
      </div>
      <style>{`
        .skeleton-container {
          padding: 20px;
          background: #fff;
          border-radius: 8px;
          box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        .skeleton-wrapper {
          display: flex;
          flex-direction: column;
        }
        .skeleton-line {
          background: #e0e0e0;
          border-radius: 4px;
          animation: pulse 1.5s ease-in-out infinite;
        }
        @keyframes pulse {
          0% { opacity: 0.6; }
          50% { opacity: 1; }
          100% { opacity: 0.6; }
        }
      `}</style>
    </div>
  );
};

const BillingDashboard: React.FC = () => {
  const [data, setData] = useState<BillingData | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      setIsLoading(true);
      // 3. Simulate Network Delay (1.5s)
      setTimeout(() => {
        setData({
          nextBillingDate: '2023-12-15T09:00:00Z',
          userTimezone: 'America/New_York'
        });
        setIsLoading(false);
      }, 1500);
    };

    fetchData();
  }, []);

  // 4. Render Skeleton while loading
  if (isLoading) {
    return (
      <div className="dashboard-wrapper">
        <h2>Billing Dashboard</h2>
        <Skeleton />
      </div>
    );
  }

  // 5. Render Actual Content with Fade-in
  return (
    <div className="dashboard-wrapper">
      <h2>Billing Dashboard</h2>
      <div className="content-card fade-in">
        <p><strong>Next Billing Date:</strong> {data?.nextBillingDate}</p>
        <p><strong>Timezone:</strong> {data?.userTimezone}</p>
      </div>
      <style>{`
        .dashboard-wrapper {
          font-family: sans-serif;
          max-width: 400px;
        }
        .content-card {
          padding: 20px;
          background: #fff;
          border: 1px solid #ddd;
          border-radius: 8px;
        }
        .fade-in {
          animation: fadeIn 0.5s ease-out forwards;
        }
        @keyframes fadeIn {
          from { opacity: 0; transform: translateY(10px); }
          to { opacity: 1; transform: translateY(0); }
        }
      `}</style>
    </div>
  );
};

export default BillingDashboard;
