/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part3.tsx
// Description: Practical Exercises
// ==========================================

// File: components/BillingCycleToggle.tsx

import React, { useState, useTransition } from 'react';

interface BillingCycleToggleProps {
  initialCycle: 'month' | 'year';
}

const BillingCycleToggle: React.FC<BillingCycleToggleProps> = ({ initialCycle }) => {
  const [cycle, setCycle] = useState(initialCycle);
  const [isPending, startTransition] = useTransition();
  const [error, setError] = useState<string | null>(null);

  const toggleCycle = async () => {
    const newCycle = cycle === 'month' ? 'year' : 'month';
    
    // Start the transition
    startTransition(async () => {
      // Optimistically update the UI
      setCycle(newCycle);
      
      try {
        // Simulate API call
        await simulateApiCall(newCycle);
        setError(null);
      } catch (err) {
        // Rollback on failure
        setCycle(cycle); 
        setError('Failed to update billing cycle. Please try again.');
      }
    });
  };

  // Helper to simulate API latency and potential failure
  const simulateApiCall = async (newCycle: 'month' | 'year') => {
    return new Promise<void>((resolve, reject) => {
      setTimeout(() => {
        // Simulate a 20% chance of failure
        if (Math.random() > 0.2) {
          resolve();
        } else {
          reject(new Error('Network Error'));
        }
      }, 1000);
    });
  };

  return (
    <div className="billing-toggle">
      <p>Current Cycle: <strong>{cycle}</strong></p>
      <button onClick={toggleCycle} disabled={isPending}>
        {isPending ? 'Updating...' : `Switch to ${cycle === 'month' ? 'Yearly' : 'Monthly'}`}
      </button>
      {error && <div className="error">{error}</div>}
    </div>
  );
};

export default BillingCycleToggle;
