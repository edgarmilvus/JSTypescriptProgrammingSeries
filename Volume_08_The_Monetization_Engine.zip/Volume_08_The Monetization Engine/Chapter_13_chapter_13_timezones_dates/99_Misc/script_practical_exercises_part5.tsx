/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part5.tsx
// Description: Practical Exercises
// ==========================================

// File: components/BillingDashboard.tsx

import React, { useState, useEffect } from 'react';

interface BillingData {
  nextBillingDate: string;
  userTimezone: string;
}

const BillingDashboard: React.FC = () => {
  const [data, setData] = useState<BillingData | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Simulate fetching data
    const fetchData = async () => {
      setIsLoading(true);
      setTimeout(() => {
        setData({
          nextBillingDate: '2023-11-15T09:00:00Z',
          userTimezone: 'America/New_York'
        });
        setIsLoading(false);
      }, 1500);
    };

    fetchData();
  }, []);

  if (isLoading) {
    return (
      <div className="dashboard">
        <h3>Billing Overview</h3>
        {/* Skeleton UI Implementation */}
        <div className="skeleton-container">
          <div className="skeleton-line" style={{ width: '60%' }}></div>
          <div className="skeleton-line" style={{ width: '40%' }}></div>
        </div>
      </div>
    );
  }

  return (
    <div className="dashboard fade-in">
      <h3>Billing Overview</h3>
      <p>Next Billing: <strong>{data?.nextBillingDate}</strong></p>
      <p>Timezone: <strong>{data?.userTimezone}</strong></p>
    </div>
  );
};

export default BillingDashboard;
