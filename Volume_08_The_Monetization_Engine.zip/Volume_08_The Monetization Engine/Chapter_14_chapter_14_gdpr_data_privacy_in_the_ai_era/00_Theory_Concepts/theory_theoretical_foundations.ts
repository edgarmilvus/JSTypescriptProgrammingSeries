/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: theory_theoretical_foundations.ts
// Description: Theoretical Foundations
// ==========================================

// Theoretical Type Definitions for a Privacy-Aware Graph State

// 1. Define a base type for PII. 
// In a strict system, we treat this as a "tainted" type.
type PII = string; 

// 2. Define non-PII data.
type NonPII = string | number | boolean;

// 3. The Graph State interface enforces strict segregation.
// Notice how PII is isolated in a specific property.
interface AgenticGraphState {
    // Non-sensitive context (safe to pass between nodes)
    sessionId: string;
    intent: string;
    riskScore: number;
    
    // Sensitive data (requires explicit handling and audit)
    // By isolating this, we can apply specific access controls.
    piiData?: {
        email: PII;
        stripeCustomerId: PII;
        ipAddress: PII;
    };
    
    // Derived data (e.g., embeddings) - requires strict validation
    vectorEmbeddings?: number[];
}

// 4. A function signature that explicitly requires PII handling.
// This prevents accidental leakage of PII into generic logs.
function processDunningStrategy(
    state: Pick<AgenticGraphState, 'riskScore' | 'intent'>, 
    pii: NonNullable<AgenticGraphState['piiData']>
): void {
    // Logic here
}
