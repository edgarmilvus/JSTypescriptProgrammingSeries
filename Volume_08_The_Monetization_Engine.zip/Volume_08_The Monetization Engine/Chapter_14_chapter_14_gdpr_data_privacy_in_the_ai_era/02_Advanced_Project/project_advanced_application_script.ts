/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// app/api/ai-recovery/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { generateText } from 'ai';
import { openai } from '@ai-sdk/openai';
import { z } from 'zod';
import { db } from '@/lib/db'; // Hypothetical database client
import { consentLog } from '@/lib/db/schema'; // Hypothetical schema

/**
 * GDPR & Data Privacy Context:
 * This API route acts as the "Human-in-the-Loop" boundary. It processes
 * sensitive payment recovery requests. We use Runtime Validation (Zod) to
 * ensure data integrity before processing. The AI is prompted to generate
 * generic recovery text, avoiding the injection of raw PII into the model
 * context where possible, adhering to Data Minimization principles.
 */

// 1. Runtime Validation Schema
// We define a strict schema for the incoming request payload.
// This prevents malformed data from entering our system and validates types at runtime.
const RecoveryRequestSchema = z.object({
  userId: z.string().uuid(),
  email: z.string().email(),
  invoiceId: z.string().uuid(),
  // We explicitly validate consent status. If false, the AI should not proceed.
  hasMarketingConsent: z.boolean(),
  // The specific debt amount is sensitive; we pass it but ensure it's treated carefully.
  outstandingAmount: z.number().positive(),
});

type RecoveryRequest = z.infer<typeof RecoveryRequestSchema>;

/**
 * POST /api/ai-recovery
 * 
 * Handles the logic for generating a GDPR-compliant payment recovery message.
 * 
 * @param req - The incoming NextRequest containing the recovery payload.
 * @returns A NextResponse containing the generated text or an error.
 */
export async function POST(req: NextRequest) {
  try {
    // 2. Input Parsing & Validation
    // We never trust external inputs. Zod validates the structure and types.
    const body = await req.json();
    const validation = RecoveryRequestSchema.safeParse(body);

    if (!validation.success) {
      return NextResponse.json(
        { error: 'Invalid request data', details: validation.error.flatten() },
        { status: 400 }
      );
    }

    const { userId, email, invoiceId, hasMarketingConsent, outstandingAmount } = validation.data;

    // 3. Consent & Compliance Check
    // GDPR Article 6 & 7: Legal basis for processing.
    // If the user has revoked consent for automated marketing/communication,
    // we must stop immediately. This is a hard gate.
    if (!hasMarketingConsent) {
      // Log this attempt for audit purposes (Data Processing Log)
      await db.insert(consentLog).values({
        userId,
        action: 'RECOVERY_BLOCKED_CONSENT',
        timestamp: new Date(),
        details: `Attempted recovery for ${invoiceId} but consent was false.`,
      });

      return NextResponse.json(
        { message: 'Communication blocked: User consent not granted.' },
        { status: 403 } // Forbidden
      );
    }

    // 4. Data Minimization & AI Context Preparation
    // We prepare a context for the AI that minimizes PII exposure.
    // Instead of sending the full user object, we send structured, non-sensitive data.
    // The AI does not need the user's full name or address to draft a generic reminder.
    const aiContext = `
      User Invoice ID: ${invoiceId}
      Outstanding Balance: ${outstandingAmount} USD
      Context: The user is a customer of a SaaS platform.
      Tone: Professional, empathetic, and helpful.
      Goal: Remind the user of the pending payment without being aggressive.
      Constraint: Do not use any personal names or addresses. Use generic terms like "Account Holder".
    `;

    // 5. AI Generation (Smart Dunning)
    // We invoke the LLM to generate the recovery text.
    // The model is stateless regarding this specific user's history (unless explicitly designed otherwise),
    // which helps in maintaining data privacy by not retaining conversation history in the model context.
    const { text } = await generateText({
      model: openai('gpt-4o-mini'),
      prompt: `Draft a payment recovery email based on this context: ${aiContext}`,
    });

    // 6. Audit Logging (Data Processing Record)
    // GDPR requires keeping records of data processing activities.
    // We log that an AI-generated recovery message was created.
    // We do NOT log the generated text if it contains PII, but here we know it's generic.
    await db.insert(consentLog).values({
      userId,
      action: 'AI_RECOVERY_GENERATED',
      timestamp: new Date(),
      details: `Generated recovery text for invoice ${invoiceId}.`,
    });

    // 7. Return Structured Response
    // The client receives the text, but the heavy lifting and sensitive data handling
    // remained entirely on the server.
    return NextResponse.json({
      success: true,
      recoveryText: text,
      metadata: {
        invoiceId,
        generatedAt: new Date().toISOString(),
      },
    });

  } catch (error) {
    // Error handling: Ensure no sensitive data leaks in error messages.
    console.error('AI Recovery Error:', error);
    return NextResponse.json(
      { error: 'Internal Server Error' },
      { status: 500 }
    );
  }
}
