/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

import express, { Request, Response } from 'express';
import Stripe from 'stripe';
import { buffer } from 'micro';

// Initialize Stripe with the secret key
const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, {
  apiVersion: '2022-11-15',
});

// 1. Define strict TypeScript interfaces for the data we intend to keep
interface SanitizedPaymentData {
  payment_intent_id: string;
  amount: number;
  currency: string;
  created: number; // Unix timestamp
  customer_id: string | null; // Stripe customer ID reference
}

// Mock database upsert function (simulating Prisma/MongoDB)
async function saveInvoiceRecord(data: SanitizedPaymentData): Promise<void> {
  console.log(`[DB Upsert] Saving invoice for ID: ${data.payment_intent_id}`);
  // In a real app: await db.invoice.upsert({ where: { id: data.payment_intent_id }, update: data, create: data });
}

// 2. Data Minimization Function
function sanitizePaymentData(rawEvent: Stripe.Event): SanitizedPaymentData {
  // We know this is a payment_intent.succeeded event, but we cast carefully
  const paymentIntent = rawEvent.data.object as Stripe.PaymentIntent;

  // Extract only what is legally required for invoicing
  return {
    payment_intent_id: paymentIntent.id,
    amount: paymentIntent.amount,
    currency: paymentIntent.currency,
    created: rawEvent.created, // Timestamp from the event wrapper
    customer_id: typeof paymentIntent.customer === 'string' 
      ? paymentIntent.customer 
      : paymentIntent.customer?.id || null,
  };
}

// 3. Express Endpoint Setup
const app = express();

// Webhook endpoint
app.post('/webhook', async (req: Request, res: Response) => {
  const sig = req.headers['stripe-signature'] as string;
  const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET;

  let event: Stripe.Event;

  // 4. Security: Verify Webhook Signature
  try {
    // We use 'micro' buffer helper to get the raw body for verification
    const rawBody = await buffer(req);
    event = stripe.webhooks.constructEvent(rawBody, sig, webhookSecret!);
  } catch (err: any) {
    console.error(`Webhook Error: ${err.message}`);
    // Throw error to prevent processing invalid data
    return res.status(400).send(`Webhook Error: ${err.message}`);
  }

  // Handle the specific event type
  if (event.type === 'payment_intent.succeeded') {
    try {
      // Step 1: Sanitize
      const sanitizedData = sanitizePaymentData(event);
      
      // Step 2: Upsert
      await saveInvoiceRecord(sanitizedData);
      
      console.log('Payment processed successfully and data minimized.');
      res.json({ received: true, status: 'processed' });
    } catch (processingError) {
      console.error('Processing error:', processingError);
      res.status(500).send('Internal Server Error');
    }
  } else {
    // Acknowledge receipt of other event types but do nothing
    res.json({ received: true, status: 'ignored' });
  }
});

// Export app for testing or serverless use
export default app;
