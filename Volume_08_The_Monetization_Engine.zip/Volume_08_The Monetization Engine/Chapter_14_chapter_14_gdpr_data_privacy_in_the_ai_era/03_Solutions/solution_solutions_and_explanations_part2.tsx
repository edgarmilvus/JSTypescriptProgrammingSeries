/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState, useMemo } from 'react';

// 1. Define strict interfaces
interface User {
  id: string;
  email: string;
  hasMarketingConsent: boolean;
  dunningCountLast24h: number;
}

interface CampaignState {
  ethicalMode: boolean;
}

// 2. Filtering Logic
const filterUsersForDunning = (users: User[], ethicalMode: boolean): User[] => {
  if (!ethicalMode) {
    // If ethical mode is off, return all users (simulating legacy aggressive dunning)
    return users;
  }

  // If ethical mode is on, apply strict GDPR-friendly filters
  return users.filter(
    (user) => user.hasMarketingConsent && user.dunningCountLast24h < 3
  );
};

// Mock Data
const INITIAL_USERS: User[] = [
  { id: '1', email: 'alice@example.com', hasMarketingConsent: true, dunningCountLast24h: 0 },
  { id: '2', email: 'bob@example.com', hasMarketingConsent: false, dunningCountLast24h: 1 }, // Opted out
  { id: '3', email: 'charlie@example.com', hasMarketingConsent: true, dunningCountLast24h: 3 }, // Limit reached
  { id: '4', email: 'diana@example.com', hasMarketingConsent: true, dunningCountLast24h: 1 },
];

export const DunningCampaignManager: React.FC = () => {
  const [users, setUsers] = useState<User[]>(INITIAL_USERS);
  const [ethicalMode, setEthicalMode] = useState<boolean>(true);

  // 3. Memoize the filtered list to optimize performance
  const visibleUsers = useMemo(() => {
    return filterUsersForDunning(users, ethicalMode);
  }, [users, ethicalMode]);

  // 4. Interactive Simulation Logic
  const handleSimulateRetry = (userId: string) => {
    setUsers((prevUsers) =>
      prevUsers.map((user) =>
        user.id === userId
          ? { ...user, dunningCountLast24h: user.dunningCountLast24h + 1 }
          : user
      )
    );
  };

  return (
    <div style={{ padding: '20px', fontFamily: 'sans-serif' }}>
      <div style={{ marginBottom: '20px', display: 'flex', alignItems: 'center', gap: '10px' }}>
        <h2>Dunning Campaign Manager</h2>
        <label>
          <input
            type="checkbox"
            checked={ethicalMode}
            onChange={(e) => setEthicalMode(e.target.checked)}
          />
          Ethical Mode (GDPR Compliant)
        </label>
      </div>

      <table style={{ width: '100%', borderCollapse: 'collapse' }}>
        <thead>
          <tr style={{ borderBottom: '2px solid #ccc', textAlign: 'left' }}>
            <th style={{ padding: '8px' }}>Email</th>
            <th style={{ padding: '8px' }}>Consent</th>
            <th style={{ padding: '8px' }}>Retry Count (24h)</th>
            <th style={{ padding: '8px' }}>Status</th>
            <th style={{ padding: '8px' }}>Action</th>
          </tr>
        </thead>
        <tbody>
          {visibleUsers.length > 0 ? (
            visibleUsers.map((user) => (
              <tr key={user.id} style={{ borderBottom: '1px solid #eee' }}>
                <td style={{ padding: '8px' }}>{user.email}</td>
                <td style={{ padding: '8px' }}>
                  {user.hasMarketingConsent ? 'Yes' : 'No'}
                </td>
                <td style={{ padding: '8px' }}>{user.dunningCountLast24h}</td>
                <td style={{ padding: '8px' }}>
                  <span
                    style={{
                      padding: '4px 8px',
                      borderRadius: '4px',
                      backgroundColor: '#e6fffa',
                      color: '#006d75',
                      fontSize: '0.85em',
                      fontWeight: 'bold',
                    }}
                  >
                    Ready for Retry
                  </span>
                </td>
                <td style={{ padding: '8px' }}>
                  <button onClick={() => handleSimulateRetry(user.id)}>
                    Simulate Retry
                  </button>
                </td>
              </tr>
            ))
          ) : (
            <tr>
              <td colSpan={5} style={{ padding: '20px', textAlign: 'center', color: '#666' }}>
                No users match the ethical criteria.
              </td>
            </tr>
          )}
        </tbody>
      </table>
      
      <div style={{ marginTop: '20px', fontSize: '0.9em', color: '#555' }}>
        <strong>Current User Count (Total):</strong> {users.length} | <strong>Visible (Filtered):</strong> {visibleUsers.length}
      </div>
    </div>
  );
};
