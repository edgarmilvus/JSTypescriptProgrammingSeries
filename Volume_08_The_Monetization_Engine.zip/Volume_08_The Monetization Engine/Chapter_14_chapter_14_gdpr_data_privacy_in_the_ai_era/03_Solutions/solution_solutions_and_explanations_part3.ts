/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

// 1. Define strict types for input and output
interface UserContext {
  userId: string;
  hasActiveSubscription: boolean;
  openInvoices: string[] | undefined; // Can be undefined
  lastLogin: Date;
}

interface DeletionPayload {
  userId: string;
  timestamp: Date;
}

// Discriminated Union for the result
type ErasureResult = 
  | { type: 'SIMPLE'; data: DeletionPayload }
  | { type: 'COMPLEX'; reason: string };

// 2. Decision Logic Function
function processErasureRequest(
  requestText: string, 
  context: UserContext
): ErasureResult {
  
  // Normalize request text for keyword scanning
  const lowerRequest = requestText.toLowerCase();

  // Check 1: Active Subscription (High Risk)
  if (context.hasActiveSubscription) {
    return {
      type: 'COMPLEX',
      reason: 'User has an active subscription. Automated deletion could violate tax laws or subscription terms.',
    };
  }

  // Check 2: Open Invoices (High Risk)
  // Using strictNullChecks: We check if openInvoices exists and has length > 0
  if (context.openInvoices && context.openInvoices.length > 0) {
    return {
      type: 'COMPLEX',
      reason: 'User has open financial invoices. Financial records must be retained for tax auditing.',
    };
  }

  // Check 3: Intent Analysis (Keywords)
  // If the user explicitly asks to keep invoices or asks for a partial deletion
  if (lowerRequest.includes('keep invoices') || lowerRequest.includes('partial')) {
    return {
      type: 'COMPLEX',
      reason: 'User requested partial deletion or specific retention of financial data.',
    };
  }

  // 3. Data Minimization in Success Case
  // If we reach here, it's a simple deletion
  return {
    type: 'SIMPLE',
    data: {
      userId: context.userId,
      timestamp: new Date(), // Only return minimal payload
    },
  };
}

// --- Usage Examples ---

// Example 1: Simple Request (Passes all checks)
const simpleCase: UserContext = {
  userId: 'user_123',
  hasActiveSubscription: false,
  openInvoices: [], // Empty array
  lastLogin: new Date('2023-01-01'),
};

const result1 = processErasureRequest("Please delete my account.", simpleCase);
console.log(result1); 
// Output: { type: 'SIMPLE', data: { userId: 'user_123', timestamp: ... } }

// Example 2: Complex (Open Invoices)
const complexCase: UserContext = {
  userId: 'user_456',
  hasActiveSubscription: false,
  openInvoices: ['inv_999'], // Has open invoice
  lastLogin: new Date(),
};

const result2 = processErasureRequest("Delete my account.", complexCase);
console.log(result2);
// Output: { type: 'COMPLEX', reason: 'User has open financial invoices...' }

// Example 3: Complex (Keyword Trigger)
const result3 = processErasureRequest("Delete my account but keep my invoices.", simpleCase);
console.log(result3);
// Output: { type: 'COMPLEX', reason: 'User requested partial deletion...' }
