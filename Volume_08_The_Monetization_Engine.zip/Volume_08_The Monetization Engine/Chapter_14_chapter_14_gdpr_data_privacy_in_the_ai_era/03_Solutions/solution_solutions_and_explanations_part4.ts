/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

// 1. Define strict types
type SharedMemoryBuffer = Uint8Array;

interface WorkerMessage {
  chunkIndex: number;
  status: 'STARTING' | 'PROCESSING' | 'COMPLETE';
}

class SecureDataProcessor {
  // Simulating SharedArrayBuffer with a Uint8Array
  private sharedBuffer: SharedMemoryBuffer;
  private isLocked: boolean = false;

  constructor(size: number = 1024) {
    this.sharedBuffer = new Uint8Array(size);
    // Initialize with zeros
    this.sharedBuffer.fill(0);
    console.log(`[System] Shared Memory allocated: ${size} bytes.`);
  }

  // 2. Simulate Web Worker behavior
  // In a real WASM scenario, this would be an async message passing to a worker thread
  private spawnWorker(index: number): Promise<void> {
    return new Promise((resolve, reject) => {
      // Simulate processing delay
      setTimeout(() => {
        // 3. Critical Section: Accessing Shared Memory
        // We must acquire the lock
        if (this.isLocked) {
          reject(new Error(`Race Condition Detected at index ${index}! Buffer is locked.`));
          return;
        }

        // Acquire Lock
        this.isLocked = true;

        // --- SIMULATED ENCRYPTION ---
        // Write a specific byte pattern (simulating an encrypted header)
        // Pattern: 0xFF (start byte), Index, 0x00 (end byte)
        if (index + 2 < this.sharedBuffer.length) {
          this.sharedBuffer[index] = 0xFF;
          this.sharedBuffer[index + 1] = index; // Embed index as data
          this.sharedBuffer[index + 2] = 0x00;
          
          console.log(`[Worker ${index}] Wrote encrypted header to buffer at offset ${index}.`);
        } else {
          console.error(`[Worker ${index}] Buffer overflow prevented.`);
        }

        // Release Lock
        this.isLocked = false;
        
        resolve();
      }, Math.random() * 50); // Random delay to simulate variable processing time
    });
  }

  // 4. Parallel Processing Orchestrator
  public async parallelProcess(chunks: number[]): Promise<void> {
    console.log(`[System] Starting parallel processing for ${chunks.length} chunks...`);
    
    // Create a batch of promises to simulate parallel execution
    const promises = chunks.map(async (chunkVal, idx) => {
      // Add a slight random delay to the start time to ensure they overlap in a real scenario
      await new Promise(r => setTimeout(r, Math.random() * 10));
      
      try {
        await this.spawnWorker(idx * 4); // Offset by 4 bytes per chunk to avoid overlap
      } catch (error) {
        console.error(`[System Error] ${error.message}`);
      }
    });

    await Promise.all(promises);
    console.log('[System] Batch processing complete.');
    this.printBufferSnapshot();
  }

  // Helper to visualize the buffer state
  public printBufferSnapshot(): void {
    const snapshot = Array.from(this.sharedBuffer.slice(0, 20)) // Show first 20 bytes
      .map(b => b.toString(16).padStart(2, '0')).join(' ');
    console.log(`[Buffer Snapshot] ${snapshot} ...`);
  }
}

// --- Execution Simulation ---

// Initialize processor
const processor = new SecureDataProcessor(64);

// Define data chunks (simulating incoming data stream)
const dataChunks = [10, 20, 30, 40, 50];

// Run the parallel process
processor.parallelProcess(dataChunks).catch(console.error);
