/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

digraph GDPR_AI_Architecture {
    rankdir=LR;
    node [shape=box, style="rounded,filled", fillcolor="#e3f2fd", fontname="Arial"];
    edge [color="#555555", fontname="Arial", fontsize=10];

    // External Input
    Stripe [shape=cylinder, fillcolor="#f3e5f5", label="Stripe Webhook\n(Raw Data)"];

    // Security Layer
    Security [shape=diamond, fillcolor="#ffebee", label="Signature\nVerification"];
    
    // Compliance Layer
    Sanitizer [shape=ellipse, fillcolor="#fff3e0", label="Data Sanitizer\n(GDPR Minimization)"];

    // Storage Layer
    RelationalDB [shape=cylinder, fillcolor="#e8f5e9", label="Relational DB\n(Audit/Invoicing)"];
    VectorDB [shape=cylinder, fillcolor="#e0f7fa", label="Vector DB\n(Context/AI Memory)"];

    // AI Layer
    AI_Agent [shape=component, fillcolor="#fce4ec", label="AI Support Agent\n(Human-in-the-Loop)"];
    
    // Audit
    AuditLog [shape=note, fillcolor="#fff9c4", label="Immutable Audit Log"];

    // Flow Connections
    Stripe -> Security [label="1. Payload"];
    Security -> Sanitizer [label="2. Valid Event"];
    Security -> AuditLog [label="Error/Rejection"];

    Sanitizer -> RelationalDB [label="3. Invoice Data\n(Amount, Currency, Date)"];
    Sanitizer -> VectorDB [label="4. Context Data\n(Anonymized User ID, Status)"];

    VectorDB -> AI_Agent [label="5. Query Context"];
    AI_Agent -> VectorDB [label="6. Update Context"];
    
    // HITL Loop
    AI_Agent -> RelationalDB [label="7. Modification Request\n(e.g., Refund/Deletion)", color="red", penwidth=2];
    RelationalDB -> AuditLog [label="8. Record Action"];

    // Styling for critical path
    { rank=same; RelationalDB; VectorDB }
}
