/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

// File: app/actions.ts
// Location: Server-Side (Server Actions)

'use server';

import { generateObject } from 'ai';
import { openai } from '@ai-sdk/openai';
import { z } from 'zod';

// 1. Define the Stripe Stub
// In a real app, import the actual Stripe SDK. 
// Here we simulate a response to keep the example self-contained.
const stripe = {
  customers: {
    retrieve: async (id: string) => ({
      id,
      email: 'user@example.com',
      subscription_status: 'active',
    }),
  },
  charges: {
    list: async (params: { customer: string; limit: number }) => [
      { id: 'ch_1', amount: 2000, currency: 'usd', status: 'succeeded' },
    ],
  },
  refunds: {
    create: async (params: { charge: string }) => ({ id: 're_1', status: 'refunded' }),
  },
};

/**
 * 2. Define the Tool Schema
 * This Zod schema dictates the exact structure the AI must output.
 * It acts as the "contract" between the LLM and our application logic.
 */
const refundToolSchema = z.object({
  reasoning: z.string().describe("The AI's step-by-step logic for the decision."),
  action: z.enum(['refund', 'do_nothing', 'escalate']).describe("The recommended action."),
  chargeId: z.string().optional().describe("The ID of the charge to refund, if applicable."),
});

/**
 * 3. Server Action: Process Support Request
 * This function is called from the client. It handles the AI generation
 * and executes the secure logic.
 */
export async function processSupportRequest(userMessage: string) {
  // A. Generate Structured Output from the LLM
  // We instruct the model to analyze the request and output our specific JSON schema.
  const { object } = await generateObject({
    model: openai('gpt-4o-mini'),
    schema: refundToolSchema,
    prompt: `
      You are a support agent for a SaaS company.
      User inquiry: "${userMessage}"
      
      Context available to you:
      - Customer ID: cus_123
      - Recent Charge: $20.00
      
      Analyze the request. If the user is complaining about a charge for an inactive service,
      recommend a refund. If the request is vague, recommend escalation.
    `,
  });

  // B. Execute Logic Based on AI Decision
  // This is the "Guardrail" or "Execution Engine" layer.
  switch (object.action) {
    case 'refund':
      // Simulate Stripe Refund API call
      if (object.chargeId) {
        // In a real app: await stripe.refunds.create({ charge: object.chargeId });
        return {
          success: true,
          message: `Refund processed for charge ${object.chargeId}.`,
          details: object,
        };
      }
      return { success: false, message: 'No charge ID provided for refund.' };

    case 'escalate':
      return {
        success: false,
        message: 'Your request requires human review. An agent has been notified.',
        details: object,
      };

    case 'do_nothing':
    default:
      return {
        success: true,
        message: 'We have reviewed your account and found no issues requiring action.',
        details: object,
      };
  }
}
