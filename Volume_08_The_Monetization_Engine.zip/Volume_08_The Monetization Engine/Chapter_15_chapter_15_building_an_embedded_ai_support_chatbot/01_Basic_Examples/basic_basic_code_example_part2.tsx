/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.tsx
// Description: Basic Code Example
// ==========================================

// File: app/page.tsx
// Location: Client-Side (React Component)

'use client';

import { useChat } from 'ai/react';
import { processSupportRequest } from './actions';

export default function SupportChat() {
  // 4. Initialize the Vercel AI SDK Hook
  // This handles message state, user input, and streaming updates.
  const { messages, input, handleInputChange, handleSubmit, isLoading } = useChat({
    // We override the default API route to use our Server Action
    api: '/api/chat', // Placeholder, but we will intercept logic below
  });

  // Custom handler to bridge useChat with our Server Action
  const customSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input) return;

    // Add user message to UI immediately
    const userMessage = { role: 'user', content: input };
    // Note: useChat automatically updates messages, but for Server Actions 
    // we often handle the stream manually or use the `useChat` hook's streaming capabilities.
    // For this "Hello World", we simulate the streaming response:
    
    // 1. Clear input
    const currentInput = input;
    handleInputChange({ target: { value: '' } } as any); 

    // 2. Call the Server Action
    const result = await processSupportRequest(currentInput);

    // 3. Append the AI response to the chat
    // (In a production app, you would use `onSubmit` and stream the response via `useChat`)
    // Here we manually append for clarity of the Server Action flow.
    const event = new CustomEvent('ai-response', { detail: result });
    window.dispatchEvent(event);
  };

  return (
    <div className="flex flex-col w-full max-w-md mx-auto p-4 border rounded-lg shadow-sm">
      <h1 className="text-xl font-bold mb-4">AI Support Agent</h1>
      
      <div className="h-64 overflow-y-auto border-b mb-4 p-2 bg-gray-50 rounded">
        {messages.map((m, index) => (
          <div key={index} className={`mb-2 ${m.role === 'user' ? 'text-right' : 'text-left'}`}>
            <span className={`inline-block px-3 py-1 rounded ${m.role === 'user' ? 'bg-blue-100' : 'bg-green-100'}`}>
              {m.content}
            </span>
          </div>
        ))}
        {isLoading && <div className="text-gray-500 animate-pulse">Thinking...</div>}
      </div>

      <form onSubmit={customSubmit} className="flex gap-2">
        <input
          type="text"
          value={input}
          onChange={handleInputChange}
          placeholder="Ask about billing, refunds..."
          className="flex-1 border rounded px-3 py-2"
        />
        <button 
          type="submit" 
          disabled={isLoading}
          className="bg-black text-white px-4 py-2 rounded disabled:opacity-50"
        >
          Send
        </button>
      </form>
    </div>
  );
}
