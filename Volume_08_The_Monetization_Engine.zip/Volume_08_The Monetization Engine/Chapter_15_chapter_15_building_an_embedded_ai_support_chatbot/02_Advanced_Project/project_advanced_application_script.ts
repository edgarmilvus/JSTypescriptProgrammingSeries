/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// app/actions/chat-support.ts
'use server';

import { generateObject } from 'ai';
import { openai } from '@ai-sdk/openai';
import { z } from 'zod';
import Stripe from 'stripe';
import { auth } from '@/auth'; // Hypothetical NextAuth helper
import { db } from '@/db'; // Hypothetical database helper

// Initialize Stripe
const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, {
  apiVersion: '2023-10-16',
});

/**
 * SCHEMA: JSON Schema Output Definition
 * Defines the strict structure the LLM must adhere to.
 * This prevents hallucinations and enables predictable tool routing.
 */
const billingSupportSchema = z.object({
  intent: z.enum(['check_payment_status', 'request_refund', 'retry_payment', 'general_query']),
  paymentIntentId: z.string().optional().describe("The Stripe PaymentIntent ID if relevant."),
  refundAmount: z.number().optional().describe("Amount to refund in cents."),
  reasoning: z.string().describe("Brief explanation of the user's request."),
});

/**
 * SERVER ACTION: Handle Chat Message
 * 1. Fetches user context (Stripe Customer ID).
 * 2. Generates structured object from LLM using JSON mode.
 * 3. Routes to specific tool based on intent.
 * 4. Executes secure Stripe operations.
 */
export async function handleSupportChat(
  previousMessages: any[],
  newMessage: string
) {
  // 1. SECURE CONTEXT GATHERING
  // Retrieve the authenticated user to link chat to specific billing data.
  const session = await auth();
  if (!session?.user?.email) {
    return { error: 'User not authenticated.' };
  }

  // Fetch the user's Stripe Customer ID from our internal DB
  const user = await db.user.findUnique({
    where: { email: session.user.email },
    select: { stripeCustomerId: true },
  });

  if (!user?.stripeCustomerId) {
    return { error: 'No billing profile found.' };
  }

  // 2. LLM INTERACTION WITH JSON SCHEMA
  // We instruct the model to act as a billing support agent and output structured data.
  const { object } = await generateObject({
    model: openai('gpt-4-turbo'),
    schema: billingSupportSchema,
    prompt: `
      You are an AI Billing Support Agent for a SaaS platform.
      User Context: Stripe Customer ID: ${user.stripeCustomerId}
      Recent Payment Intents: (Assume context is available or ask user for ID)
      
      Analyze the user message and classify the intent strictly according to the schema.
      Message: "${newMessage}"
    `,
  });

  // 3. TOOL ROUTING & EXECUTION
  // Based on the structured output, execute the appropriate Stripe logic.
  try {
    switch (object.intent) {
      case 'check_payment_status':
        return await checkPaymentStatus(object.paymentIntentId, user.stripeCustomerId);

      case 'request_refund':
        return await processRefund(object.paymentIntentId, object.refundAmount, user.stripeCustomerId);

      case 'retry_payment':
        return await retryFailedPayment(object.paymentIntentId);

      case 'general_query':
      default:
        return { response: "I can help with payment status, refunds, or retrying failed payments. Please provide a PaymentIntent ID if applicable." };
    }
  } catch (error) {
    console.error('Support Action Error:', error);
    return { response: "I encountered an error processing your request. Please contact human support." };
  }
}

/**
 * TOOL 1: Check Payment Status
 * Retrieves status from Stripe securely, ensuring user owns the payment.
 */
async function checkPaymentStatus(paymentIntentId: string | undefined, customerId: string) {
  if (!paymentIntentId) return { response: "Please provide a PaymentIntent ID to check status." };

  try {
    const paymentIntent = await stripe.paymentIntents.retrieve(paymentIntentId);

    // SECURITY GUARDRAIL: Verify ownership
    if (paymentIntent.customer !== customerId) {
      return { response: "Access denied. This payment does not belong to your account." };
    }

    return {
      response: `The payment status for ${paymentIntentId} is: **${paymentIntent.status}**. 
      Amount: ${(paymentIntent.amount / 100).toFixed(2)} ${paymentIntent.currency.toUpperCase()}.`,
    };
  } catch (e) {
    return { response: "Could not retrieve payment details. Verify the ID." };
  }
}

/**
 * TOOL 2: Process Refund with Guardrails
 * Initiates a refund only if specific conditions are met (e.g., not older than 30 days).
 */
async function processRefund(
  paymentIntentId: string | undefined, 
  amount: number | undefined, 
  customerId: string
) {
  if (!paymentIntentId) return { response: "Refund requires a PaymentIntent ID." };

  try {
    const paymentIntent = await stripe.paymentIntents.retrieve(paymentIntentId);

    // GUARDRAIL 1: Ownership Check
    if (paymentIntent.customer !== customerId) {
      return { response: "Security violation detected." };
    }

    // GUARDRAIL 2: Idempotency & Eligibility
    // (In production, check if already refunded or if charge is older than 30 days)
    if (paymentIntent.status !== 'succeeded') {
      return { response: "Cannot refund a payment that hasn't succeeded." };
    }

    // Execute Refund
    const refund = await stripe.refunds.create({
      payment_intent: paymentIntentId,
      amount: amount ? amount * 100 : undefined, // Convert to cents
    });

    return {
      response: `Refund processed successfully. Refund ID: ${refund.id}. Status: ${refund.status}.`,
    };
  } catch (e: any) {
    return { response: `Refund failed: ${e.message}` };
  }
}

/**
 * TOOL 3: Smart Dunning (Retry Payment)
 * Attempts to re-authorize a failed payment using Stripe's internal logic.
 */
async function retryFailedPayment(paymentIntentId: string | undefined) {
  if (!paymentIntentId) return { response: "PaymentIntent ID required for retry." };

  try {
    // Stripe handles automatic retries, but we can trigger a manual update
    // or attach a new payment method if the error was 'card_declined'.
    const paymentIntent = await stripe.paymentIntents.retrieve(paymentIntentId);

    if (paymentIntent.status !== 'requires_payment_method') {
      return { response: `Payment is currently in '${paymentIntent.status}' state and cannot be retried automatically.` };
    }

    // In a full implementation, we would update the payment method here.
    // For this script, we simulate the intent to retry.
    return {
      response: `The payment for ${paymentIntentId} requires a new payment method. 
      Please update your card details in the customer portal to complete the transaction.`,
    };
  } catch (e) {
    return { response: "Error accessing payment intent for retry." };
  }
}
