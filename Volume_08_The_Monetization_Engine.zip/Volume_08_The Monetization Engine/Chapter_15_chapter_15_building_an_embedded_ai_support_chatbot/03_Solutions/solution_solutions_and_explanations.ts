/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// app/components/StripeSupportChat.tsx (Server Component)
import { auth } from '@/auth'; // Hypothetical auth helper
import { db } from '@/db'; // Hypothetical database helper
import { Chat } from './chat'; // Client Component wrapper

export default async function StripeSupportChat() {
  // 1. Fetch the current user session securely on the server
  const session = await auth();
  
  if (!session?.user?.id) {
    return <div>Please log in to access support.</div>;
  }

  // 2. Fetch the Stripe Customer ID from the database securely
  // This ID is never exposed to the client directly in this component
  const user = await db.query.users.findFirst({
    where: (users, { eq }) => eq(users.id, session.user.id),
  });

  const stripeCustomerId = user?.stripeCustomerId;

  if (!stripeCustomerId) {
    return <div>No Stripe account associated with this user.</div>;
  }

  // 3. Pass the ID as a prop to the Client Component
  // The Client Component will use this to initialize the chat context
  return <Chat initialContext={{ stripeCustomerId }} />;
}

// app/components/chat.tsx (Client Component)
'use client';

import { useChat } from 'ai/react';
import { useEffect } from 'react';

interface ChatProps {
  initialContext: {
    stripeCustomerId: string;
  };
}

export function Chat({ initialContext }: ChatProps) {
  // 4. Configure the useChat hook to stream responses
  const { messages, input, handleInputChange, handleSubmit, isLoading } = useChat({
    api: '/api/chat',
    body: {
      // We pass the context here, but it was derived securely on the server
      // The API route will validate this context against the session
      context: initialContext,
    },
    // Optional: Add a system prompt as the first message for context
    initialMessages: [
      {
        id: 'system-1',
        role: 'system',
        content: `You are assisting a customer with Stripe ID: ${initialContext.stripeCustomerId}. Use this ID for any billing queries.`,
      },
    ],
  });

  return (
    <div className="flex flex-col w-full max-w-md py-24 mx-auto stretch">
      <div className="space-y-4">
        {messages.map((m) => (
          <div key={m.id} className="whitespace-pre-wrap">
            <strong>{m.role === 'user' ? 'User: ' : 'AI: '}</strong>
            {m.content}
          </div>
        ))}
      </div>

      <form onSubmit={handleSubmit}>
        <input
          className="fixed bottom-0 w-full max-w-md p-2 mb-8 border border-gray-300 rounded shadow-xl"
          value={input}
          placeholder="Ask about your billing..."
          onChange={handleInputChange}
          disabled={isLoading}
        />
      </form>
    </div>
  );
}
