/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

// lib/tools/billingSchema.ts
import { z } from 'zod';

// 1. Define the schema using Zod (which converts to JSON Schema)
export const getBillingDetailsSchema = z.object({
  stripeCustomerId: z.string().describe("The customer's unique Stripe ID"),
  queryType: z.enum(['latest_invoice', 'payment_intent']).describe("The specific billing data to fetch"),
});

export type BillingDetailsTool = z.infer<typeof getBillingDetailsSchema>;

// app/api/chat/route.ts
import { streamText } from 'ai';
import { openai } from '@ai-sdk/openai';
import { z } from 'zod';
import { getBillingDetailsSchema } from '@/lib/tools/billingSchema';

// Mock Stripe function
const mockStripeCall = async (customerId: string, type: string) => {
  console.log(`Fetching ${type} for customer ${customerId}...`);
  return { amount: 4999, currency: 'usd', status: 'paid' };
};

export async function POST(req: Request) {
  const { messages, context } = await req.json();

  // 2. Define the tools available to the LLM
  const result = await streamText({
    model: openai('gpt-4-turbo-preview'),
    messages,
    tools: {
      getBillingDetails: {
        description: 'Get the latest billing details for a customer',
        parameters: getBillingDetailsSchema, // Strict typing via Zod
        execute: async ({ stripeCustomerId, queryType }) => {
          // 4. Execute the tool if the LLM decides to call it
          const data = await mockStripeCall(stripeCustomerId, queryType);
          return JSON.stringify(data);
        },
      },
    },
    // 3. Prompt the LLM to use the tool for billing inquiries
    system: `You are a support agent. If the user asks about billing, invoices, or payments, use the 'getBillingDetails' tool. Customer ID: ${context.stripeCustomerId}`,
  });

  return result.toAIStreamResponse();
}
