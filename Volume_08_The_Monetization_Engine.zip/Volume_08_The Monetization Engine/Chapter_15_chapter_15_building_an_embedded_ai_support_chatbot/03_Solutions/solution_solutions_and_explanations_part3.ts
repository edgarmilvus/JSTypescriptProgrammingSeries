/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

// app/actions/dunning.ts
'use server';

import { revalidatePath } from 'next/cache';

// 1. Define the Server Action
export async function handleDunningInquiry(paymentIntentId: string) {
  // 2. Simulate fetching payment intent from Stripe
  // In a real app, this would be await stripe.paymentIntents.retrieve(id);
  const mockPaymentIntent = {
    id: paymentIntentId,
    status: 'requires_payment_method',
    last_payment_error: { code: 'card_declined', message: 'Card was declined' },
    amount: 5000,
  };

  // 3. Determine logic based on status and error
  let suggestedAction: 'retry' | 'update_card' | 'contact_support' = 'contact_support';

  if (mockPaymentIntent.status === 'requires_payment_method') {
    if (mockPaymentIntent.last_payment_error?.code === 'card_declined') {
      suggestedAction = 'update_card';
    } else {
      suggestedAction = 'retry';
    }
  }

  // 4. Return structured response
  return {
    suggestedAction,
    details: `Payment ${mockPaymentIntent.id} failed. Amount: $${mockPaymentIntent.amount / 100}.`,
  };
}

// app/api/chat/route.ts (Snippet of integration)
import { streamText } from 'ai';
import { openai } from '@ai-sdk/openai';
import { handleDunningInquiry } from '@/app/actions/dunning';

export async function POST(req: Request) {
  const { messages } = await req.json();

  const result = await streamText({
    model: openai('gpt-4-turbo-preview'),
    messages,
    tools: {
      checkPaymentFailure: {
        description: 'Check status of a failed payment and suggest action',
        parameters: z.object({ paymentIntentId: z.string() }),
        execute: async ({ paymentIntentId }) => {
          // 5. Trigger the Server Action
          const result = await handleDunningInquiry(paymentIntentId);
          return `Suggested action: ${result.suggestedAction}. Details: ${result.details}`;
        },
      },
    },
    system: "If the user mentions a payment failed or declined, ask for the Payment Intent ID and use the 'checkPaymentFailure' tool.",
  });

  return result.toAIStreamResponse();
}
