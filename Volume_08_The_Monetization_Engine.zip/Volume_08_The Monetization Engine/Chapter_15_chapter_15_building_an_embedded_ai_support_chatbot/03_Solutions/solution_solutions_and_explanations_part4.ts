/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

// lib/tools/refundSchema.ts
import { z } from 'zod';

// 3. TypeScript Interface for the Refund Tool
export const refundToolSchema = z.object({
  paymentIntentId: z.string().describe("The ID of the payment to refund"),
  amount: z.number().positive().describe("Amount to refund in cents"),
  reason: z.enum(['duplicate', 'fraudulent', 'requested_by_customer']).describe("Reason for refund"),
  userConfirmation: z.boolean().describe("Explicit confirmation from the user to proceed"),
});

export type RefundToolParams = z.infer<typeof refundToolSchema>;

// app/api/chat/route.ts (Refund Logic Snippet)
import { streamText } from 'ai';
import { openai } from '@ai-sdk/openai';
import { refundToolSchema } from '@/lib/tools/refundSchema';

// Mock Stripe Refund
const createRefund = async (params: any) => {
  if (params.amount > 5000) {
    throw new Error("Amount exceeds manual approval limit ($50). Contact support.");
  }
  return { id: 're_123', status: 'succeeded' };
};

export async function POST(req: Request) {
  const { messages } = await req.json();

  const result = await streamText({
    model: openai('gpt-4-turbo-preview'),
    messages,
    tools: {
      processRefund: {
        description: 'Process a refund for a specific payment intent',
        parameters: refundToolSchema,
        execute: async (params) => {
          // Security Guardrail: Check confirmation
          if (!params.userConfirmation) {
            return "Refund cancelled: User did not confirm.";
          }
          
          // Security Guardrail: Amount check
          if (params.amount > 5000) {
            return "Refund requires manual approval due to amount.";
          }

          try {
            const refund = await createRefund(params);
            return `Refund processed successfully: ${refund.id}`;
          } catch (error: any) {
            return `Error processing refund: ${error.message}`;
          }
        },
      },
    },
    system: "You can process refunds. You must ask the user to confirm the amount and reason explicitly before using the tool. If the amount is over $50, inform them it requires manual approval.",
  });

  return result.toAIStreamResponse();
}
