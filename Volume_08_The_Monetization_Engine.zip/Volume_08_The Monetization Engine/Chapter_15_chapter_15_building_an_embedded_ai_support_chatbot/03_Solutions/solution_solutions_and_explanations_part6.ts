/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part6.ts
// Description: Solutions and Explanations
// ==========================================

// db/schema.ts (Drizzle ORM Example)
import { pgTable, serial, varchar, boolean, jsonb } from 'drizzle-orm/pg-core';

export const supportSessions = pgTable('support_sessions', {
  id: serial('id').primaryKey(),
  sessionId: varchar('session_id').notNull(),
  stripeCustomerId: varchar('stripe_customer_id').notNull(),
  initialQuery: varchar('initial_query').notNull(),
  resolutionType: varchar('resolution_type', { 
    enum: ['refund', 'dunning_retry', 'billing_info', 'human_escalation'] 
  }),
  resolvedByAI: boolean('resolved_by_ai').notNull().default(false),
  createdAt: varchar('created_at').default(new Date().toISOString()),
});

// app/api/chat/route.ts (Logging Snippet)
import { db } from '@/db';
import { supportSessions } from '@/db/schema';

async function logSession(
  sessionId: string, 
  customerId: string, 
  query: string, 
  type: string, 
  resolved: boolean
) {
  await db.insert(supportSessions).values({
    sessionId,
    stripeCustomerId: customerId,
    initialQuery: query,
    resolutionType: type,
    resolvedByAI: resolved,
  });
}

// Inside the API route, after tool execution or escalation:
// if (toolExecutedSuccessfully) {
//    await logSession(id, custId, query, 'refund', true);
// } else if (escalatedToHuman) {
//    await logSession(id, custId, query, 'human_escalation', false);
// }
