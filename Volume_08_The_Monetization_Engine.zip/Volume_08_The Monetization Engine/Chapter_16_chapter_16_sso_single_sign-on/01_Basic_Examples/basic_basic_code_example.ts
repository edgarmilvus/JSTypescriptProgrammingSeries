/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * Represents the base structure of a user object returned after SSO authentication.
 * This is the "Contract" that all providers must eventually adhere to after processing.
 */
interface StandardizedUser {
  id: string;
  email: string;
  role: 'customer' | 'admin' | 'support_agent';
}

/**
 * 1. Define Generic Types:
 *    - T: The raw data structure returned specifically by the SSO provider (e.g., Google's profile or Microsoft's graph response).
 */
class SSOHandler<T extends Record<string, unknown>> {
  private providerName: string;

  constructor(providerName: string) {
    this.providerName = providerName;
  }

  /**
   * 2. The Generic Method:
   *    Accepts raw data of type T and a transformer function to convert T into our StandardizedUser.
   *    This ensures we don't lose type information during the transformation.
   */
  public async authenticate(
    rawData: T, 
    transformer: (data: T) => StandardizedUser
  ): Promise<StandardizedUser> {
    // Simulate network latency (common in SSO flows)
    await new Promise(resolve => setTimeout(resolve, 500));

    // Validate: Check if the raw data exists
    if (!rawData || Object.keys(rawData).length === 0) {
      throw new Error(`[${this.providerName}] Authentication failed: No data received.`);
    }

    // Transform: Use the provided function to map provider-specific data to our standard format
    const user = transformer(rawData);

    // Security Check: Ensure the email is valid
    if (!user.email.includes('@')) {
      throw new Error(`[${this.providerName}] Invalid email format in token.`);
    }

    console.log(`✅ User authenticated via ${this.providerName}: ${user.email}`);
    return user;
  }
}

// --- MOCK DATA PROVIDERS ---

// Simulating a response from Google's SSO
const googleResponse = {
  sub: '1234567890',
  email: 'alice@stripe-saas.com',
  email_verified: true,
  picture: 'https://google.com/avatar.jpg',
  role: 'admin' // Custom claim added in Google Workspace
};

// Simulating a response from Microsoft's SSO (Azure AD)
const microsoftResponse = {
  oid: '9876543210',
  userPrincipalName: 'bob@enterprise-client.com',
  businessPhones: ['+1 555 0199'],
  jobTitle: 'Finance Manager',
  roles: ['customer'] // Microsoft uses array for roles
};

// --- TRANSFORMERS ---

/**
 * 3. Transformer Functions:
 *    These functions know how to extract specific fields from the generic 'T' shape.
 */
const transformGoogle = (data: typeof googleResponse): StandardizedUser => {
  return {
    id: data.sub,
    email: data.email,
    role: data.role as StandardizedUser['role'] // Type assertion for safety
  };
};

const transformMicrosoft = (data: typeof microsoftResponse): StandardizedUser => {
  return {
    id: data.oid,
    email: data.userPrincipalName,
    role: data.roles[0] as StandardizedUser['role']
  };
};

// --- EXECUTION ---

/**
 * 4. Main Execution Logic:
 *    Demonstrates how the same SSOHandler instance processes different data shapes
 *    while returning a strictly typed StandardizedUser.
 */
async function runSSOFlow() {
  // Initialize handler for Google
  const googleHandler = new SSOHandler<typeof googleResponse>('Google Workspace');

  // Initialize handler for Microsoft
  const microsoftHandler = new SSOHandler<typeof microsoftResponse>('Microsoft Azure AD');

  try {
    // Process Google User
    const googleUser = await googleHandler.authenticate(googleResponse, transformGoogle);
    
    // Process Microsoft User
    const microsoftUser = await microsoftHandler.authenticate(microsoftResponse, transformMicrosoft);

    // --- Integration Point: Monetization Engine ---
    // Now that we have standardized users, we can link them to Stripe Customers
    console.log('\n--- Monetization Engine Integration ---');
    console.log(`Linking Google User (ID: ${googleUser.id}) to Stripe Customer...`);
    console.log(`Linking Microsoft User (ID: ${microsoftUser.id}) to Stripe Customer...`);

  } catch (error) {
    console.error('SSO Error:', (error as Error).message);
  }
}

// Run the example
runSSOFlow();
