/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// /app/api/auth/callback/oidc/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { jwtVerify } from 'jose'; // For verifying JWTs with JWKS
import Stripe from 'stripe';
import { v4 as uuidv4 } from 'uuid';

// ---------------------------------------------------------------------------
// 1. TYPE DEFINITIONS & CONFIGURATION
// ---------------------------------------------------------------------------

// Interface for the decoded OIDC ID Token payload
interface OIDCTokenPayload {
  sub: string; // Unique user identifier from IdP
  email: string;
  name: string;
  exp: number;
  iat: number;
}

// Interface for the unified session context passed to downstream services
export interface UnifiedSessionContext {
  userId: string;
  email: string;
  stripeCustomerId: string | null;
  supportAgentToken: string; // JWT for the AI Support Agent
  permissions: string[];
}

// Environment Configuration (Validate these in production)
const OIDC_ISSUER_URL = process.env.OIDC_ISSUER_URL!;
const OIDC_CLIENT_ID = process.env.OIDC_CLIENT_ID!;
const OIDC_CLIENT_SECRET = process.env.OIDC_CLIENT_SECRET!;
const OIDC_JWKS_URL = `${OIDC_ISSUER_URL}/.well-known/jwks.json`;
const STRIPE_SECRET_KEY = process.env.STRIPE_SECRET_KEY!;

const stripe = new Stripe(STRIPE_SECRET_KEY, { apiVersion: '2023-10-16' });

// ---------------------------------------------------------------------------
// 2. HELPER: FETCH AND VALIDATE JWKS (JSON Web Key Set)
// ---------------------------------------------------------------------------

/**
 * Fetches the public keys from the Identity Provider to verify the signature
 * of the incoming ID Token. This prevents token forgery.
 */
async function getJWK(kid: string) {
  const response = await fetch(OIDC_JWKS_URL, { cache: 'no-store' });
  if (!response.ok) throw new Error('Failed to fetch JWKS');
  
  const jwks = await response.json();
  const key = jwks.keys.find((k: any) => k.kid === kid);
  
  if (!key) throw new Error('Key ID not found in JWKS');
  return key;
}

// ---------------------------------------------------------------------------
// 3. CORE LOGIC: THE OIDC CALLBACK HANDLER
// ---------------------------------------------------------------------------

/**
 * Handles the POST request from the Identity Provider containing the code/token.
 * 
 * Logic Flow:
 * 1. Extract and verify the ID Token signature.
 * 2. Lookup or create the user in our local database.
 * 3. Retrieve the user's Stripe Customer ID.
 * 4. Generate a Stripe Billing Portal session (SSO deep-linking).
 * 5. Generate a secure token for the AI Support Agent.
 * 6. Return the unified session context.
 */
export async function POST(req: NextRequest) {
  try {
    // A. Parse the incoming OIDC callback payload
    const body = await req.json();
    const { id_token, code } = body; // In a full flow, you might exchange 'code' for tokens

    if (!id_token) {
      return NextResponse.json({ error: 'Missing ID Token' }, { status: 400 });
    }

    // B. Decode header to find the Key ID (kid) for signature verification
    const header = JSON.parse(Buffer.from(id_token.split('.')[0], 'base64').toString());
    const jwk = await getJWK(header.kid);

    // C. Verify the JWT using the fetched public key
    const { payload } = await jwtVerify(id_token, jwk, {
      issuer: OIDC_ISSUER_URL,
      audience: OIDC_CLIENT_ID,
    }) as { payload: OIDCTokenPayload };

    // D. Simulate User Lookup / Provisioning
    // In production, query your database (e.g., Prisma, Drizzle) for user.email
    // If not found, create a new user record linked to payload.sub (IdP ID).
    const dbUser = await mockFindOrCreateUser(payload.email, payload.sub);

    // E. Retrieve Stripe Customer ID
    // Ideally, this is stored in your DB. If not, search Stripe by email.
    let stripeCustomerId = dbUser.stripeCustomerId;
    if (!stripeCustomerId) {
      const customers = await stripe.customers.list({ email: payload.email, limit: 1 });
      if (customers.data.length > 0) {
        stripeCustomerId = customers.data[0].id;
      } else {
        // Create a new customer in Stripe if one doesn't exist
        const newCustomer = await stripe.customers.create({
          email: payload.email,
          name: payload.name,
        });
        stripeCustomerId = newCustomer.id;
      }
    }

    // F. Generate Downstream Sessions (The "Monetization Engine" Integration)
    
    // 1. Stripe Billing Portal Session
    // We create a session directly from the backend to avoid exposing API keys.
    // The return_url points back to the app.
    const stripePortalSession = await stripe.billingPortal.sessions.create({
      customer: stripeCustomerId,
      return_url: `https://app.example.com/dashboard`,
    });

    // 2. AI Support Agent Token
    // We create a custom JWT that the AI Agent will accept.
    // This allows the agent to know the user's tier and history without separate auth.
    const agentToken = await createSupportAgentToken({
      userId: dbUser.id,
      email: payload.email,
      tier: dbUser.subscriptionTier, // e.g., 'pro', 'enterprise'
    });

    // G. Construct the Unified Response
    const unifiedSession: UnifiedSessionContext = {
      userId: dbUser.id,
      email: payload.email,
      stripeCustomerId: stripeCustomerId,
      supportAgentToken: agentToken,
      permissions: ['read:billing', 'write:support'],
    };

    // H. Return the session data to the client
    // The client can now redirect the user to stripePortalSession.url
    // or initialize the AI Chat widget with supportAgentToken.
    return NextResponse.json({
      success: true,
      session: unifiedSession,
      actions: {
        redirectToBilling: stripePortalSession.url,
        initializeSupport: true,
      },
    });

  } catch (error) {
    console.error('OIDC Callback Error:', error);
    return NextResponse.json({ error: 'Authentication Failed' }, { status: 401 });
  }
}

// ---------------------------------------------------------------------------
// 4. MOCK DATA & UTILITY FUNCTIONS (For Demonstration)
// ---------------------------------------------------------------------------

/**
 * Mock function to simulate database interaction.
 * Replaces a real Prisma/Mongoose call.
 */
async function mockFindOrCreateUser(email: string, oidcSub: string) {
  // Simulate checking DB...
  return {
    id: 'user_12345', // Internal ID
    email: email,
    oidcSubject: oidcSub,
    stripeCustomerId: 'cus_mock_98765', // Pre-linked customer
    subscriptionTier: 'pro', // Used for AI Agent personalization
  };
}

/**
 * Creates a JWT for the AI Support Agent.
 * In production, use a library like 'jsonwebtoken' to sign this.
 */
async function createSupportAgentToken(payload: { userId: string; email: string; tier: string }) {
  // Simulating a signed JWT string
  const header = { alg: 'HS256', typ: 'JWT' };
  const body = {
    ...payload,
    iss: 'monetization-engine',
    exp: Math.floor(Date.now() / 1000) + (60 * 60), // 1 hour expiry
  };
  // In real code: return jwt.sign(body, process.env.JWT_SECRET);
  return `eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.${Buffer.from(JSON.stringify(body)).toString('base64')}.Signature`;
}
