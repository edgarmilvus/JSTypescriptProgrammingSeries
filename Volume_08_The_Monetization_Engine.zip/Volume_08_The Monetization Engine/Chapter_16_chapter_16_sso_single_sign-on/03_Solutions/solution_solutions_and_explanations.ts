/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// SSOLoginButton.tsx
import React, { useState, useEffect } from 'react';
import { useAuth } from '../hooks/useAuth';
import { generateCodeVerifier, generateCodeChallenge } from '../utils/pkce';

// Interfaces for token decoding
interface DecodedIdToken {
  exp: number; // Expiration time (seconds)
  iat: number; // Issued at
  sub: string; // Subject (User ID)
  email: string;
}

export const SSOLoginButton: React.FC = () => {
  const { login, logout, isAuthenticated, token, refreshToken } = useAuth();
  const [loading, setLoading] = useState(false);

  // 1. Initial Login Flow
  const handleLogin = async () => {
    setLoading(true);
    try {
      // Generate PKCE
      const verifier = generateCodeVerifier();
      const challenge = await generateCodeChallenge(verifier);
      
      // Store verifier in sessionStorage (survives redirect)
      sessionStorage.setItem('pkce_verifier', verifier);

      // Construct Authorization URL
      const authUrl = new URL('https://your-idp.com/authorize');
      authUrl.searchParams.set('response_type', 'code');
      authUrl.searchParams.set('client_id', process.env.REACT_APP_CLIENT_ID!);
      authUrl.searchParams.set('redirect_uri', window.location.origin + '/callback');
      authUrl.searchParams.set('scope', 'openid email profile');
      authUrl.searchParams.set('code_challenge', challenge);
      authUrl.searchParams.set('code_challenge_method', 'S256');
      authUrl.searchParams.set('state', crypto.randomUUID()); // CSRF protection

      // Redirect
      window.location.href = authUrl.toString();
    } catch (error) {
      console.error("Login failed:", error);
      setLoading(false);
    }
  };

  // 2. Silent Authentication (Renewal) Flow
  useEffect(() => {
    if (!token || !refreshToken) return;

    const decoded = JSON.parse(atob(token.split('.')[1])) as DecodedIdToken;
    const expirationTime = decoded.exp * 1000; // Convert to ms
    const now = Date.now();
    
    // Check if token expires in less than 5 minutes
    const timeUntilExpiry = expirationTime - now;
    
    if (timeUntilExpiry < 5 * 60 * 1000) {
      // Trigger silent renewal
      handleSilentRenewal();
    } else {
      // Set a timeout to trigger renewal just before expiration
      const timeoutId = setTimeout(() => {
        handleSilentRenewal();
      }, timeUntilExpiry - (5 * 60 * 1000));

      return () => clearTimeout(timeoutId);
    }
  }, [token]);

  const handleSilentRenewal = async () => {
    // Create a hidden iframe for silent auth
    const iframe = document.createElement('iframe');
    iframe.style.display = 'none';
    document.body.appendChild(iframe);

    // Construct silent auth URL (prompt=none tells IdP not to show UI)
    const silentAuthUrl = new URL('https://your-idp.com/authorize');
    silentAuthUrl.searchParams.set('response_type', 'code');
    silentAuthUrl.searchParams.set('client_id', process.env.REACT_APP_CLIENT_ID!);
    silentAuthUrl.searchParams.set('redirect_uri', window.location.origin + '/silent-callback');
    silentAuthUrl.searchParams.set('scope', 'openid email profile');
    silentAuthUrl.searchParams.set('prompt', 'none'); // Critical for silent auth
    silentAuthUrl.searchParams.set('state', crypto.randomUUID());
    
    // Note: PKCE is usually not required for silent refresh if using Refresh Tokens, 
    // but strictly following OIDC, we might need to re-use the original verifier or use a refresh token grant.
    // Here we simulate the iframe loading the authorize endpoint.
    
    iframe.src = silentAuthUrl.toString();

    // Listen for message from the iframe (assuming the silent-callback posts a message on load)
    const messageHandler = (event: MessageEvent) => {
      if (event.origin !== window.location.origin) return;
      if (event.data.type === 'SILENT_AUTH_SUCCESS') {
        // Update token in state/context
        login(event.data.token); 
        document.body.removeChild(iframe);
        window.removeEventListener('message', messageHandler);
      } else if (event.data.type === 'SILENT_AUTH_FAILURE') {
        // Refresh failed, logout
        logout();
        document.body.removeChild(iframe);
        window.removeEventListener('message', messageHandler);
      }
    };

    window.addEventListener('message', messageHandler);
  };

  return (
    <button onClick={handleLogin} disabled={loading || isAuthenticated}>
      {loading ? 'Connecting...' : isAuthenticated ? 'Signed In' : 'Sign In with SSO'}
    </button>
  );
};
