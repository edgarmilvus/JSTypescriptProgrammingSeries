/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

// samlService.ts
import { inflate, deflate } from 'zlib';
import { promisify } from 'util';
import * as crypto from 'crypto';
import * as xml2js from 'xml2js';

const inflateAsync = promisify(inflate);
const deflateAsync = promisify(deflate);

// Mock Database and Stripe interfaces
interface LocalUser {
  id: string;
  email: string;
  stripeCustomerId: string;
  role: string;
}

const db: LocalUser[] = []; // In-memory store for example

export async function generateSAMLRequest(issuer: string, acsUrl: string): Promise<string> {
  const id = `_${crypto.randomBytes(8).toString('hex')}`;
  const issueInstant = new Date().toISOString();

  // 1. Create XML template
  const xml = `
    <samlp:AuthnRequest xmlns:samlp="urn:oasis:names:tc:SAML:2.0:protocol"
                        xmlns:saml="urn:oasis:names:tc:SAML:2.0:assertion"
                        ID="${id}"
                        Version="2.0"
                        IssueInstant="${issueInstant}"
                        ProtocolBinding="urn:oasis:names:tc:SAML:2.0:bindings:HTTP-POST"
                        AssertionConsumerServiceURL="${acsUrl}">
      <saml:Issuer>${issuer}</saml:Issuer>
      <samlp:NameIDPolicy Format="urn:oasis:names:tc:SAML:1.1:nameid-format:emailAddress" AllowCreate="true"/>
    </samlp:AuthnRequest>
  `;

  // 2. Deflate and Base64 encode
  const deflated = await deflateAsync(Buffer.from(xml));
  return Buffer.from(deflated).toString('base64');
}

export async function validateSAMLResponse(samlResponse: string): Promise<any> {
  // 1. Base64 decode
  const decodedResponse = Buffer.from(samlResponse, 'base64');

  // 2. Inflate (SAML responses are often compressed)
  const inflatedBuffer = await inflateAsync(decodedResponse);
  const xmlString = inflatedBuffer.toString('utf-8');

  // 3. Parse XML
  const parser = new xml2js.Parser();
  const result = await parser.parseStringPromise(xmlString);
  
  // 4. Verify Signature (Simplified logic - in production use 'xml-crypto')
  // Extract the Signature node and verify against IdP Public Certificate
  const signature = result['samlp:Response']['Signature'];
  if (!signature) throw new Error("SAML Response missing signature");
  
  // NOTE: Real implementation requires extracting the X.509 cert from the metadata
  // and verifying the cryptographic signature of the XML.
  
  // 5. Extract Assertion Attributes
  const assertion = result['samlp:Response']['saml:Assertion'][0];
  const attributes = assertion['saml:AttributeStatement'][0]['saml:Attribute'];
  
  const userAttrs: Record<string, string> = {};
  attributes.forEach((attr: any) => {
    const key = attr.$.Name;
    const val = attr['saml:AttributeValue'][0];
    userAttrs[key] = val;
  });

  const email = userAttrs['email'] || assertion['saml:Subject'][0]['saml:NameID'][0]._;
  
  // 6. JIT Provisioning & Stripe Mapping (Interactive Challenge)
  let user = db.find(u => u.email === email);
  
  if (!user) {
    // Check if user exists in Stripe (Mocking Stripe API call)
    // const existingStripeCustomer = await stripe.customers.list({ email });
    
    // If not, create new Stripe customer
    const newCustomer = await stripe.customers.create({ email }); 
    const stripeCustomerId = newCustomer.id;

    // Assign default role from SAML attribute or default
    const role = userAttrs['role'] || 'BillingViewer';

    // Create local record
    user = {
      id: crypto.randomUUID(),
      email,
      stripeCustomerId,
      role
    };
    db.push(user);
  }

  // 7. Generate JWT for Session
  const jwtPayload = {
    sub: user.id,
    email: user.email,
    stripeCustomerId: user.stripeCustomerId,
    role: user.role
  };

  // Sign JWT (using a private key)
  const token = crypto.sign('SHA256', Buffer.from(JSON.stringify(jwtPayload)), {
    key: process.env.JWT_PRIVATE_KEY!,
    passphrase: process.env.JWT_PASSPHRASE!
  });

  return { token, user };
}
