/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

// BillingPortal.tsx
import React, { useState } from 'react';
import useSWR from 'swr';
import { useAuth } from '../hooks/useAuth'; // Assume this provides token and refresh logic

// Interfaces
interface StripeSubscription {
  id: string;
  status: string;
  current_period_end: number;
}

interface StripeInvoice {
  id: string;
  amount_due: number;
  status: string;
}

// Enhanced Fetcher with Token Refresh Logic
const fetcher = async (url: string, token: string, refreshToken: () => Promise<string>) => {
  const headers = { Authorization: `Bearer ${token}` };
  
  let response = await fetch(url, { headers });

  // Handle 401 Unauthorized (Token Expired)
  if (response.status === 401) {
    console.log("Token expired, attempting refresh...");
    try {
      const newToken = await refreshToken();
      // Retry request with new token
      response = await fetch(url, { 
        headers: { Authorization: `Bearer ${newToken}` } 
      });
    } catch (refreshError) {
      throw new Error('SESSION_EXPIRED'); // Signal to trigger logout
    }
  }

  if (!response.ok) {
    throw new Error('API Error');
  }

  return response.json();
};

export const BillingPortal: React.FC = () => {
  const { token, refreshToken, logout } = useAuth();
  const [retryCount, setRetryCount] = useState(0);

  // Use SWR for data fetching
  const { data, error, isLoading } = useSWR(
    token ? ['/api/stripe/billing-details', token] : null,
    ([url, tkn]) => fetcher(url, tkn, refreshToken),
    {
      onError: (err) => {
        if (err.message === 'SESSION_EXPIRED') {
          logout(); // Trigger logout if refresh fails
        }
      },
      revalidateOnFocus: false // Prevent unwanted refetches
    }
  );

  const subscriptions = data?.subscriptions as StripeSubscription[];
  const invoices = data?.invoices as StripeInvoice[];

  // Render States
  if (!token) {
    return <div>Please log in to view billing details.</div>;
  }

  if (isLoading) {
    return <div className="spinner">Loading billing data...</div>;
  }

  if (error) {
    return (
      <div className="error-message">
        {error.message === 'SESSION_EXPIRED' 
          ? 'Session expired. Please log in again.' 
          : 'Failed to load billing data. Please try again.'}
      </div>
    );
  }

  return (
    <div className="billing-container">
      <h2>Active Subscriptions</h2>
      <ul>
        {subscriptions?.map(sub => (
          <li key={sub.id}>
            Plan: {sub.id} | Status: {sub.status} | Ends: {new Date(sub.current_period_end * 1000).toLocaleDateString()}
          </li>
        ))}
      </ul>

      <h2>Recent Invoices</h2>
      <ul>
        {invoices?.map(inv => (
          <li key={inv.id}>
            Amount: ${inv.amount_due / 100} | Status: {inv.status}
          </li>
        ))}
      </ul>
    </div>
  );
};
