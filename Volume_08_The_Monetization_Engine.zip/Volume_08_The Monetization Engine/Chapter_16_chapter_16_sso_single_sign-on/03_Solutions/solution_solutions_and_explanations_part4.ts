/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

digraph SSO_Flow {
    rankdir=LR;
    node [shape=box, style="rounded,filled", color="#e0e0e0"];
    
    // Define Nodes
    User [label="User Browser\n(React App)", shape=component, fillcolor="#add8e6"];
    Backend [label="Application Backend\n(Node.js)", fillcolor="#90ee90"];
    IdP [label="Identity Provider\n(Auth0/Okta)", fillcolor="#ffb6c1"];

    // Define Styles
    edge [color="#333", fontname="Arial"];
    subgraph cluster_login {
        label="Initial Login Flow (Solid)";
        style="solid";
        
        // Step 1: Initiation
        User -> Backend [label="1. Click Login\nGET /auth/login", arrowhead=vee];
        
        // Step 2: Redirect to IdP
        Backend -> User [label="2. Redirect\n302 to IdP /authorize (PKCE)", arrowhead=vee, style=solid];
        User -> IdP [label="3. Browser Redirects", arrowhead=vee, style=solid];

        // Step 3: Authentication
        IdP -> User [label="4. User Authenticated\nSet Cookie", arrowhead=vee, style=solid];

        // Step 4: Code Grant
        User -> Backend [label="5. POST Code + State\nto /callback", arrowhead=vee, style=solid];

        // Step 5: Token Exchange
        Backend -> IdP [label="6. POST Code + PKCE\n/token endpoint", arrowhead=vee, style=solid];
        IdP -> Backend [label="7. Returns ID Token\nAccess Token", arrowhead=vee, style=solid];
        
        // Step 6: Session
        Backend -> User [label="8. Set Session Cookie\n/ Redirect to App", arrowhead=vee, style=solid];
    }

    subgraph cluster_refresh {
        label="Token Refresh Flow (Dashed)";
        style="dashed";
        color="blue";

        // Refresh Sequence
        User -> Backend [label="9. API Call (Expired Token)\nAuthorization: Bearer <exp>", style=dashed, color=blue];
        Backend -> User [label="10. 401 Unauthorized", style=dashed, color=blue];
        
        User -> IdP [label="11. POST /token\n(Refresh Token Grant)", style=dashed, color=blue];
        IdP -> User [label="12. New Access Token", style=dashed, color=blue];
        
        User -> Backend [label="13. Retry API Call\nNew Token", style=dashed, color=blue];
        Backend -> User [label="14. 200 OK Data", style=dashed, color=blue];
    }
}
