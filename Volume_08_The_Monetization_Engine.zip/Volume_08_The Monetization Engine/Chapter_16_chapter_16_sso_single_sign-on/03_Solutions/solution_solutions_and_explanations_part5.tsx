/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.tsx
// Description: Solutions and Explanations
// ==========================================

// main-app.tsx (Parent Window)
import React, { useEffect, useState } from 'react';

interface BillingContextRequest {
  type: 'REQUEST_BILLING_CONTEXT';
}

interface BillingContextResponse {
  type: 'BILLING_CONTEXT_RESPONSE';
  payload: {
    customerId: string;
    plan: 'Free' | 'Pro' | 'Enterprise';
  } | null;
  error?: string;
}

const ALLOWED_ORIGINS = ['https://ai-agent.example.com'];

export const MainApp: React.FC = () => {
  const [customerPlan, setCustomerPlan] = useState<string>('');

  useEffect(() => {
    const handleMessage = async (event: MessageEvent) => {
      // 1. Security: Origin Whitelist Check
      if (!ALLOWED_ORIGINS.includes(event.origin)) {
        console.warn(`Blocked message from unauthorized origin: ${event.origin}`);
        return;
      }

      const message = event.data as BillingContextRequest;

      // 2. Check Message Type
      if (message.type === 'REQUEST_BILLING_CONTEXT') {
        try {
          // 3. Data Enrichment: Fetch current plan from Stripe
          // (In a real app, you would fetch this dynamically based on the logged-in user)
          // const plan = await fetchStripePlan(currentCustomerId);
          
          // Mock data for demonstration
          const response: BillingContextResponse = {
            type: 'BILLING_CONTEXT_RESPONSE',
            payload: {
              customerId: 'cus_12345',
              plan: 'Pro' // Fetched dynamically in real scenario
            }
          };

          // 4. Post back to source (The iframe window)
          // event.source is the Window object of the iframe
          if (event.source) {
            (event.source as Window).postMessage(response, event.origin);
          }
        } catch (err) {
          const errorResponse: BillingContextResponse = {
            type: 'BILLING_CONTEXT_RESPONSE',
            payload: null,
            error: 'Failed to fetch billing context'
          };
          if (event.source) {
            (event.source as Window).postMessage(errorResponse, event.origin);
          }
        }
      }
    };

    window.addEventListener('message', handleMessage);
    return () => window.removeEventListener('message', handleMessage);
  }, []);

  return (
    <div className="main-app">
      <h1>Support Dashboard</h1>
      <p>Current Plan: {customerPlan}</p>
      {/* The AI Agent Iframe */}
      <iframe 
        src="https://ai-agent.example.com" 
        title="AI Support Agent"
        style={{ width: '100%', height: '500px', border: '1px solid #ccc' }}
      />
    </div>
  );
};
