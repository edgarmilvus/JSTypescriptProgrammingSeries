/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part6.tsx
// Description: Solutions and Explanations
// ==========================================

// ai-agent.tsx (Child Iframe Window)
import React, { useEffect, useState } from 'react';

interface BillingContextRequest {
  type: 'REQUEST_BILLING_CONTEXT';
}

interface BillingContextResponse {
  type: 'BILLING_CONTEXT_RESPONSE';
  payload: {
    customerId: string;
    plan: string;
  } | null;
  error?: string;
}

export const AIAgent: React.FC = () => {
  const [billingInfo, setBillingInfo] = useState<string>('Loading...');
  
  useEffect(() => {
    // 1. Define Timeout Logic
    const timeoutId = setTimeout(() => {
      setBillingInfo("Error: Request timed out waiting for billing context.");
      console.warn("Timeout: No response received from Main App within 5 seconds.");
    }, 5000);

    // 2. Define Message Handler
    const handleMessage = (event: MessageEvent) => {
      // Verify origin (Even child should check, though parent is the critical gate)
      if (event.origin !== "https://main-app.example.com") return;

      const message = event.data as BillingContextResponse;

      if (message.type === 'BILLING_CONTEXT_RESPONSE') {
        clearTimeout(timeoutId); // Clear timeout on success
        
        if (message.payload) {
          setBillingInfo(`Customer: ${message.payload.customerId} | Plan: ${message.payload.plan}`);
        } else {
          setBillingInfo(`Error: ${message.error || 'Unknown error'}`);
        }
      }
    };

    window.addEventListener('message', handleMessage);

    // 3. Send Request to Parent
    const request: BillingContextRequest = { type: 'REQUEST_BILLING_CONTEXT' };
    // window.parent refers to the parent window (Main App)
    window.parent.postMessage(request, '*'); // '*' or specific origin for security

    return () => {
      window.removeEventListener('message', handleMessage);
      clearTimeout(timeoutId);
    };
  }, []);

  return (
    <div className="ai-agent">
      <h3>AI Support Bot</h3>
      <div className="context-box">
        <strong>System Context:</strong> {billingInfo}
      </div>
      <p>How can I help you today?</p>
    </div>
  );
};
