/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part4.tsx
// Description: Practical Exercises
// ==========================================

// main-app.tsx (Parent Window)
import React, { useEffect } from 'react';

interface BillingContextRequest {
  type: 'REQUEST_BILLING_CONTEXT';
}

interface BillingContextResponse {
  type: 'BILLING_CONTEXT_RESPONSE';
  payload: {
    customerId: string;
    plan: 'Free' | 'Pro' | 'Enterprise';
  } | null;
}

// Whitelist of allowed origins for the AI Agent
const ALLOWED_ORIGINS = ['https://ai-agent.example.com'];

export const MainApp: React.FC = () => {
  useEffect(() => {
    const handleMessage = (event: MessageEvent) => {
      // 1. Check Origin
      if (!ALLOWED_ORIGINS.includes(event.origin)) return;

      // 2. Check Message Type
      if ((event.data as BillingContextRequest).type === 'REQUEST_BILLING_CONTEXT') {
        // 3. Fetch Data (Mock implementation)
        const response: BillingContextResponse = {
          type: 'BILLING_CONTEXT_RESPONSE',
          payload: { customerId: 'cus_123', plan: 'Pro' }
        };
        
        // 4. Post back to source
        // Note: event.source is the window object of the iframe
        (event.source as Window).postMessage(response, event.origin);
      }
    };

    window.addEventListener('message', handleMessage);
    return () => window.removeEventListener('message', handleMessage);
  }, []);

  return <div>Main App Content <iframe src="https://ai-agent.example.com" /></div>;
};

// ai-agent.tsx (Child Iframe Window)
// Implement the request logic, timeout handling, and type checking here.
