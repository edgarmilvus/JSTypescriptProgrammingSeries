/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.ts
// Description: Basic Code Example
// ==========================================

/**
 * @fileoverview Basic implementation of an immutable audit log for SaaS revenue systems.
 * Focuses on SRP (Single Responsibility Principle) and cryptographic integrity.
 */

// --- 1. Type Definitions ---

/**
 * Represents the raw data of an event before logging.
 * In a real app, this would be a Stripe Event or an AI Agent decision payload.
 */
interface RawEvent {
    type: 'STRIPE_PAYMENT' | 'AI_DUNNING_DECISION' | 'SUPPORT_TICKET';
    payload: Record<string, any>;
    userId: string;
}

/**
 * Represents the structure of a single immutable log entry.
 */
interface AuditLogEntry {
    id: string;                 // Unique ID for this log entry
    timestamp: number;          // Unix timestamp (milliseconds)
    type: string;               // Event type
    data: Record<string, any>;  // The sanitized event payload
    previousHash: string;       // Hash of the previous entry (Chain of Trust)
    currentHash: string;        // Hash of this entry (Integrity Check)
}

// --- 2. The AuditLogger Module (SRP) ---

class AuditLogger {
    private lastHash: string = 'GENESIS'; // The hash of the previous entry in the chain

    /**
     * Generates a simple cryptographic hash (simulated for brevity).
     * In production, use SHA-256 via Web Crypto API.
     */
    private generateHash(data: string): string {
        // Simulating a hash function for the example
        let hash = 0;
        if (data.length === 0) return hash.toString();
        for (let i = 0; i < data.length; i++) {
            const char = data.charCodeAt(i);
            hash = ((hash << 5) - hash) + char;
            hash |= 0; // Convert to 32bit integer
        }
        return `hash_${Math.abs(hash).toString(16)}`;
    }

    /**
     * Creates an immutable log entry.
     * Responsibility: Data formatting and Hash calculation.
     * @param event - The raw event data
     */
    public createEntry(event: RawEvent): AuditLogEntry {
        const timestamp = Date.now();
        
        // Sanitize payload to ensure clean logging
        const sanitizedData = {
            type: event.type,
            userId: event.userId,
            payload: event.payload
        };

        // Create the data string for hashing
        const dataString = JSON.stringify({
            prev: this.lastHash,
            time: timestamp,
            data: sanitizedData
        });

        const currentHash = this.generateHash(dataString);

        const entry: AuditLogEntry = {
            id: crypto.randomUUID(), // Native Web API for unique IDs
            timestamp: timestamp,
            type: event.type,
            data: sanitizedData,
            previousHash: this.lastHash,
            currentHash: currentHash
        };

        // Update the chain state
        this.lastHash = currentHash;

        return entry;
    }
}

// --- 3. The Application Context (Usage) ---

/**
 * Simulates an AI Customer Support Agent making a decision.
 * This function demonstrates how to integrate the logger without coupling logic.
 */
async function handleAICustomerSupportDecision(
    logger: AuditLogger, 
    decision: 'RETRY_PAYMENT' | 'ESCALATE_HUMAN'
) {
    // 1. Prepare the event data
    const rawEvent: RawEvent = {
        type: 'AI_DUNNING_DECISION',
        userId: 'user_12345',
        payload: {
            decision: decision,
            confidence: 0.95,
            context: 'User failed payment 3 times'
        }
    };

    // 2. Create the audit log entry (Immutable Record)
    const logEntry = logger.createEntry(rawEvent);

    // 3. Persist the log (Simulated Edge Storage write)
    // In a real app: await edgeKV.put(logEntry.id, JSON.stringify(logEntry));
    console.log(`[EDGE] Writing immutable log to storage...`);
    console.log(JSON.stringify(logEntry, null, 2));

    // 4. Execute the business logic (Only after logging!)
    if (decision === 'RETRY_PAYMENT') {
        console.log(`[ACTION] Initiating Stripe retry for user ${rawEvent.userId}...`);
    }
}

// --- 4. Execution ---

// Initialize the logger (Singleton pattern usually recommended here)
const auditSystem = new AuditLogger();

// Simulate a sequence of events
(async () => {
    console.log("--- Starting Audit Log Simulation ---");
    
    // Event 1: Initial AI Decision
    await handleAICustomerSupportDecision(auditSystem, 'RETRY_PAYMENT');
    
    console.log("\n--- Chain Integrity Check ---");
    
    // Event 2: Subsequent Stripe Event
    const stripeEvent: RawEvent = {
        type: 'STRIPE_PAYMENT',
        userId: 'user_12345',
        payload: { amount: 2000, currency: 'usd', status: 'succeeded' }
    };
    
    const entry2 = auditSystem.createEntry(stripeEvent);
    console.log(JSON.stringify(entry2, null, 2));
    
    // Verify Chain (Conceptual check)
    console.log(`\n[VERIFICATION] Chain is intact. Last Hash: ${entry2.currentHash}`);
})();
