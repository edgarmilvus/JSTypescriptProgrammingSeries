/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// app/api/audit/log/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { createClient } from '@supabase/supabase-js';
import { v4 as uuidv4 } from 'uuid';

// -----------------------------------------------------------------------------
// 1. CONFIGURATION & TYPES
// -----------------------------------------------------------------------------

// Initialize Supabase Client (Server-side only)
const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL!;
const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY!; // Use Service Role for bypassing RLS
const supabase = createClient(supabaseUrl, supabaseServiceKey);

/**
 * Defines the structure of the audit log entry.
 * Using a discriminated union allows TypeScript to enforce specific payloads
 * based on the `source` type.
 */
type AuditSource = 'stripe' | 'ai_agent' | 'manual';

interface BaseAuditEvent {
  source: AuditSource;
  userId?: string;
  metadata?: Record<string, any>;
  timestamp: string;
}

interface StripeAuditEvent extends BaseAuditEvent {
  source: 'stripe';
  stripeEventId: string;
  eventType: string;
  amount?: number;
  currency?: string;
}

interface AIAuditEvent extends BaseAuditEvent {
  source: 'ai_agent';
  agentId: string;
  decision: 'retry' | 'escalate' | 'forgive' | 'contact';
  reasoning: string; // Natural language reasoning for the decision
  confidence: number;
}

type AuditEvent = StripeAuditEvent | AIAuditEvent;

// -----------------------------------------------------------------------------
// 2. HELPER: OPTIMISTIC UI RECONCILIATION
// -----------------------------------------------------------------------------

/**
 * Simulates the "Reconciliation" step.
 * In a real app, this would be a client-side function that updates the UI
 * based on the server response. Here, we structure the response to facilitate that.
 */
const reconcileResponse = (status: 'success' | 'error', eventId: string) => {
  return {
    status,
    eventId,
    message: status === 'success' 
      ? 'Event logged successfully. UI will reconcile.' 
      : 'Logging failed. UI should revert state.',
    serverTimestamp: new Date().toISOString()
  };
};

// -----------------------------------------------------------------------------
// 3. CORE LOGIC: THE AUDIT SINK
// -----------------------------------------------------------------------------

/**
 * POST /api/audit/log
 * 
 * Accepts audit events from Stripe Webhooks or internal AI Agents.
 * 1. Validates the incoming payload.
 * 2. Returns an immediate 200 OK (Optimistic UI principle).
 * 3. Offloads the heavy DB write and Vector Embedding generation to a background task.
 */
export async function POST(request: NextRequest) {
  try {
    // A. Parse and Validate Input
    const body = await request.json();
    const event = body as AuditEvent;

    if (!event.source || !event.timestamp) {
      return NextResponse.json(
        { error: 'Invalid audit event structure' }, 
        { status: 400 }
      );
    }

    // Generate a unique ID for this log entry
    const logId = uuidv4();

    // B. The "Optimistic" Response
    // We return immediately to the client (Stripe or AI Agent) so they don't hang.
    // The actual logging happens asynchronously below.
    const responsePayload = reconcileResponse('success', logId);
    const immediateResponse = NextResponse.json(responsePayload, { status: 200 });

    // C. Background Processing (Async/Await)
    // We do not 'await' this block in the return statement, allowing the client
    // to receive the response before the DB transaction completes.
    // Note: In Vercel Serverless Functions, we must be careful with background tasks
    // as the function instance may freeze. In production, consider a queue (e.g., Upstash Redis).
    
    (async () => {
      try {
        // 4. DATA ENRICHMENT & VECTOR GENERATION
        // ---------------------------------------------------------
        // We construct the row for the database.
        // For the `embedding` column (pgvector), we need a text representation
        // to generate a vector. We concatenate relevant fields.
        
        const textForEmbedding = `
          Source: ${event.source}
          Action: ${'eventType' in event ? event.eventType : event.decision}
          Reasoning: ${'reasoning' in event ? event.reasoning : ''}
          Metadata: ${JSON.stringify(event.metadata || {})}
        `.trim().replace(/\s+/g, ' '); // Normalize whitespace

        // NOTE: In a real production environment, generating the vector 
        // requires an embedding model (e.g., via Edge Runtime or a separate service).
        // For this script, we simulate the vector array. 
        // In production, you would call an embedding API here.
        const simulatedVector = new Array(384).fill(0.1); // Placeholder for 384-dim vector

        // ---------------------------------------------------------
        // 5. INSERT INTO SUPABASE (PGVECTOR)
        // ---------------------------------------------------------
        
        const { data, error } = await supabase
          .from('audit_logs')
          .insert([
            {
              id: logId,
              source: event.source,
              user_id: event.userId || null,
              event_data: event, // Store raw JSON
              text_context: textForEmbedding, // Store text for readability
              embedding: simulatedVector, // Store the vector for semantic search
              created_at: event.timestamp
            }
          ])
          .select(); // Select to confirm insertion

        if (error) {
          console.error('Audit Log DB Error:', error);
          // In a real system, we would push this to a dead-letter queue
        } else {
          console.log(`Audit Log ${logId} committed to database.`);
        }

      } catch (err) {
        console.error('Background audit processing failed:', err);
      }
    })();

    // Return the immediate response to the caller
    return immediateResponse;

  } catch (error) {
    console.error('Audit API Error:', error);
    return NextResponse.json(
      { error: 'Internal Server Error' }, 
      { status: 500 }
    );
  }
}
