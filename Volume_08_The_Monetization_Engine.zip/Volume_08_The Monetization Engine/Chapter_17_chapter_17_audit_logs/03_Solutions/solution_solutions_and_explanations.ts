/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// 1. Define specific metadata interfaces
interface StripeEventMetadata {
    stripeEventId: string;
    customerId: string;
    amount: number;
}

interface DunningActionMetadata {
    invoiceId: string;
    retryAttempt: number;
    strategy: "email_escalation" | "payment_retry";
}

interface AIDecisionMetadata {
    agentId: string;
    conversationId: string;
    intent: string;
    confidence: number;
}

// 2. Create a union type for the metadata
type EventMetadata = StripeEventMetadata | DunningActionMetadata | AIDecisionMetadata;

// 3. Define the main AuditLogEntry interface
interface AuditLogEntry {
    id: string;
    timestamp: string; // ISO 8601
    source: "Stripe" | "SmartDunning" | "AIAgent";
    action: string;
    metadata: EventMetadata;
}

// 4. Helper function with Type Narrowing
function validateLogEntry(entry: AuditLogEntry): boolean {
    // Type guard for Stripe
    if (entry.source === "Stripe") {
        const meta = entry.metadata as StripeEventMetadata;
        return (
            typeof meta.stripeEventId === "string" &&
            typeof meta.customerId === "string" &&
            typeof meta.amount === "number"
        );
    }

    // Type guard for SmartDunning
    if (entry.source === "SmartDunning") {
        const meta = entry.metadata as DunningActionMetadata;
        return (
            typeof meta.invoiceId === "string" &&
            typeof meta.retryAttempt === "number" &&
            (meta.strategy === "email_escalation" || meta.strategy === "payment_retry")
        );
    }

    // Type guard for AIAgent
    if (entry.source === "AIAgent") {
        const meta = entry.metadata as AIDecisionMetadata;
        return (
            typeof meta.agentId === "string" &&
            typeof meta.conversationId === "string" &&
            typeof meta.intent === "string" &&
            typeof meta.confidence === "number"
        );
    }

    return false;
}
