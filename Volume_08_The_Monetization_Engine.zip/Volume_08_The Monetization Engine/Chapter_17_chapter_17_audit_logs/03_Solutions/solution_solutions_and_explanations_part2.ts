/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

// 1. Define the generic Tool Handler type
type ToolHandler<TInput, TOutput> = (input: TInput) => Promise<TOutput>;

// 2. Define a simplified AuditLogEntry for the context (assuming Exercise 1 definitions exist)
interface AuditLogEntry {
    id: string;
    timestamp: string;
    source: "AIAgent";
    action: string;
    metadata: any; // Simplified for this exercise
}

// Mock function to simulate logging storage
declare function storeLog(log: AuditLogEntry): void;

// 3. The Higher-Order Function
function withAuditLogging<TInput, TOutput>(
    handler: ToolHandler<TInput, TOutput>,
    agentId: string,
    toolName: string
): ToolHandler<TInput, TOutput> {
    
    // 4. Return a function matching the Tool Handler signature
    return async (input: TInput): Promise<TOutput> => {
        const logId = crypto.randomUUID(); // Available in modern TS/Node environments
        const startTime = new Date().toISOString();

        // Log Attempt
        const attemptLog: AuditLogEntry = {
            id: logId,
            timestamp: startTime,
            source: "AIAgent",
            action: `${toolName}_attempt`,
            metadata: { agentId, input }
        };
        storeLog(attemptLog);

        try {
            // Execute the original handler
            const result = await handler(input);
            const endTime = new Date().toISOString();

            // Log Success
            const successLog: AuditLogEntry = {
                id: crypto.randomUUID(),
                timestamp: endTime,
                source: "AIAgent",
                action: `${toolName}_success`,
                metadata: { agentId, result }
            };
            storeLog(successLog);

            return result;
        } catch (error) {
            const endTime = new Date().toISOString();

            // Log Failure
            const failureLog: AuditLogEntry = {
                id: crypto.randomUUID(),
                timestamp: endTime,
                source: "AIAgent",
                action: `${toolName}_failure`,
                metadata: { agentId, error }
            };
            storeLog(failureLog);

            // Re-throw to maintain LangGraph flow control
            throw error;
        }
    };
}
