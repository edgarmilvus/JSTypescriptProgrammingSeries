/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState, useMemo } from 'react';

// Reusing interfaces from Exercise 1
interface AuditLogEntry {
    id: string;
    timestamp: string;
    source: "Stripe" | "SmartDunning" | "AIAgent";
    action: string;
    metadata: any;
}

interface AuditStreamVisualizerProps {
    logs: AuditLogEntry[];
}

export const AuditStreamVisualizer: React.FC<AuditStreamVisualizerProps> = ({ logs }) => {
    const [selectedStripeLog, setSelectedStripeLog] = useState<AuditLogEntry | null>(null);

    // 1. Group logs by source using useMemo
    const groupedLogs = useMemo(() => {
        const initial: { Stripe: AuditLogEntry[]; SmartDunning: AuditLogEntry[]; AIAgent: AuditLogEntry[] } = {
            Stripe: [],
            SmartDunning: [],
            AIAgent: [],
        };
        return logs.reduce((acc, log) => {
            if (acc[log.source]) {
                acc[log.source].push(log);
            }
            return acc;
        }, initial);
    }, [logs]);

    // 2. Logic to highlight related AI logs (within 5 seconds)
    const highlightedAiIds = useMemo(() => {
        if (!selectedStripeLog) return new Set<string>();
        
        const stripeTime = new Date(selectedStripeLog.timestamp).getTime();
        const windowMs = 5000; // 5 seconds

        return new Set(
            groupedLogs.AIAgent
                .filter(aiLog => {
                    const aiTime = new Date(aiLog.timestamp).getTime();
                    return aiTime >= stripeTime && aiTime <= stripeTime + windowMs;
                })
                .map(l => l.id)
        );
    }, [selectedStripeLog, groupedLogs]);

    // 3. Generate Graphviz DOT string
    const dotString = useMemo(() => {
        let dot = 'digraph AuditFlow {\n  rankdir=LR;\n';
        
        // Create nodes
        logs.forEach(log => {
            const nodeLabel = `${log.source}: ${log.action}`;
            dot += `  "${log.id}" [label="${nodeLabel}"];\n`;
        });

        // Create edges (Stripe -> AIAgent within 5s)
        groupedLogs.Stripe.forEach(stripeLog => {
            const stripeTime = new Date(stripeLog.timestamp).getTime();
            const relatedAi = groupedLogs.AIAgent.filter(aiLog => {
                const aiTime = new Date(aiLog.timestamp).getTime();
                return aiTime >= stripeTime && aiTime <= stripeTime + 5000;
            });

            relatedAi.forEach(aiLog => {
                dot += `  "${stripeLog.id}" -> "${aiLog.id}";\n`;
            });
        });

        dot += '}';
        return dot;
    }, [logs, groupedLogs]);

    const renderLogCard = (log: AuditLogEntry, isHighlighted: boolean = false) => (
        <div 
            key={log.id} 
            onClick={() => log.source === "Stripe" && setSelectedStripeLog(log)}
            style={{ 
                border: '1px solid #ccc', 
                padding: '8px', 
                margin: '4px', 
                borderRadius: '4px',
                backgroundColor: isHighlighted ? '#e6f7ff' : '#fff',
                cursor: log.source === "Stripe" ? 'pointer' : 'default'
            }}
        >
            <strong>{log.action}</strong>
            <div style={{ fontSize: '0.8em', color: '#666' }}>
                {new Date(log.timestamp).toLocaleTimeString()} - ID: {log.id.substring(0, 8)}...
            </div>
        </div>
    );

    return (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
            {/* Visualization Columns */}
            <div style={{ display: 'flex', gap: '10px' }}>
                {(['Stripe', 'SmartDunning', 'AIAgent'] as const).map(source => (
                    <div key={source} style={{ flex: 1, border: '1px solid #eee', padding: '10px' }}>
                        <h3>{source}</h3>
                        {groupedLogs[source].map(log => 
                            renderLogCard(log, highlightedAiIds.has(log.id))
                        )}
                    </div>
                ))}
            </div>

            {/* Graphviz Output */}
            <div style={{ marginTop: '20px' }}>
                <h4>Relationship Graph (DOT)</h4>
                <pre style={{ background: '#f5f5f5', padding: '10px', overflowX: 'auto' }}>
                    {dotString}
                </pre>
                {/* In a real app, a library like react-graphviz would render this visually */}
                <code>[ERROR: Failed to render diagram.]</code>
            </div>
        </div>
    );
};
