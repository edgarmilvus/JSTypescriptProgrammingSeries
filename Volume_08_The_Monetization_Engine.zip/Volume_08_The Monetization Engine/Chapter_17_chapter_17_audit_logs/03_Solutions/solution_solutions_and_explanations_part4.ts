/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

// 1. Define the GraphState interface
interface GraphState {
    conversationHistory: {
        role: 'user' | 'agent';
        content: string;
        timestamp: Date;
    }[];
    currentInvoiceId: string | null;
    dunningLevel: number;
    metadata: Record<string, any>;
}

// 2. Mock database fetch
async function fetchPersistedState(stateId: string): Promise<string> {
    // Simulating a DB return with ISO string dates
    const mockData = {
        conversationHistory: [
            { role: 'user', content: 'I want a refund', timestamp: new Date().toISOString() }
        ],
        currentInvoiceId: 'inv_123',
        dunningLevel: 2,
        metadata: { disputeReason: 'unauthorized' }
    };
    return JSON.stringify(mockData);
}

// 3. Hydration function
async function hydrateGraphState(jsonString: string): Promise<GraphState> {
    // 4. Parse the JSON
    const parsed = JSON.parse(jsonString);

    // 5. Type Narrowing and Transformation
    // Check top-level structure
    if (
        !parsed ||
        !Array.isArray(parsed.conversationHistory) ||
        (parsed.currentInvoiceId !== null && typeof parsed.currentInvoiceId !== 'string') ||
        typeof parsed.dunningLevel !== 'number'
    ) {
        throw new Error("Invalid State Structure: Top-level properties missing or incorrect type.");
    }

    // Transform conversationHistory dates
    const conversationHistory = parsed.conversationHistory.map((entry: any) => {
        if (!entry.timestamp || typeof entry.timestamp !== 'string') {
            throw new Error("Invalid State Structure: Missing or invalid timestamp in history.");
        }
        return {
            role: entry.role,
            content: entry.content,
            timestamp: new Date(entry.timestamp) // Hydrate string to Date
        };
    });

    // Construct and return the typed object
    const hydratedState: GraphState = {
        conversationHistory,
        currentInvoiceId: parsed.currentInvoiceId,
        dunningLevel: parsed.dunningLevel,
        metadata: parsed.metadata || {}
    };

    return hydratedState;
}
