/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

// Assuming interfaces from Exercise 1 are available
interface AuditLogEntry {
    id: string;
    timestamp: string;
    source: "Stripe" | "SmartDunning" | "AIAgent";
    action: string;
    metadata: any;
}

// 1. Define the return type
interface EngineMetrics {
    totalStripeEvents: number;
    totalAIAgentActions: number;
    successfulDunningRetries: number;
    aiResolutionRate: number;
}

// 2. The Calculation Function
function calculateMetrics(logs: AuditLogEntry[]): EngineMetrics {
    // Initialize counters
    let totalStripeEvents = 0;
    let totalAIAgentActions = 0;
    let successfulDunningRetries = 0;
    let successfulAiActions = 0;

    // 3. Iterate over logs
    for (const log of logs) {
        // 4. Switch statement for Type Narrowing
        switch (log.source) {
            case "Stripe":
                totalStripeEvents++;
                // Accessing metadata is safe here, though not strictly needed for this count
                // const meta = log.metadata as StripeEventMetadata; 
                break;

            case "SmartDunning":
                // 6. Check action string for success
                if (log.action.includes("success")) {
                    successfulDunningRetries++;
                }
                // Accessing metadata safely
                // const dMeta = log.metadata as DunningActionMetadata;
                break;

            case "AIAgent":
                totalAIAgentActions++;
                // 7. Check action string for failure
                if (!log.action.includes("failure")) {
                    successfulAiActions++;
                }
                break;
            
            default:
                // Exhaustiveness check (optional but good practice)
                const _exhaustiveCheck: never = log.source;
                break;
        }
    }

    // 8. Calculate Rate (handle division by zero)
    const aiResolutionRate = totalAIAgentActions > 0 
        ? (successfulAiActions / totalAIAgentActions) * 100 
        : 0;

    // 9. Return aggregated object
    return {
        totalStripeEvents,
        totalAIAgentActions,
        successfulDunningRetries,
        aiResolutionRate
    };
}
