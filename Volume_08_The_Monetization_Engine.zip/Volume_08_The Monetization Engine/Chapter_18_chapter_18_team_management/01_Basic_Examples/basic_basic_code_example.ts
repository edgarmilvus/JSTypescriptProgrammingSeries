/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * @fileoverview A simple AI Customer Support Agent for ticket triage.
 * This script simulates analyzing a support ticket to determine priority and
 * assign it to the correct team.
 */

// --- 1. TYPE DEFINITIONS ---

/**
 * Represents a support ticket submitted by a customer.
 */
type SupportTicket = {
  id: string;
  customerEmail: string;
  subject: string;
  body: string;
};

/**
 * Represents the result of the triage process.
 */
type TriageResult = {
  ticketId: string;
  priority: 'Low' | 'Medium' | 'High' | 'Urgent';
  assignedTeam: 'Billing' | 'Technical' | 'General';
  reasoning: string;
};

// --- 2. MOCK DATA: KNOWLEDGE BASE FOR CLASSIFICATION ---

/**
 * A mock knowledge base of issue patterns.
 * In a real application, this would be stored in a vector database (like Pinecone)
 * and indexed by embeddings of the issue descriptions.
 */
const KNOWLEDGE_BASE: { pattern: string; team: 'Billing' | 'Technical' | 'General'; priority: 'Low' | 'Medium' | 'High' | 'Urgent' }[] = [
  {
    pattern: "payment failed charge card declined refund",
    team: "Billing",
    priority: "High",
  },
  {
    pattern: "bug crash error not working api latency",
    team: "Technical",
    priority: "Urgent",
  },
  {
    pattern: "how to feature request tutorial documentation",
    team: "General",
    priority: "Low",
  },
  {
    pattern: "subscription cancel downgrade plan",
    team: "Billing",
    priority: "Medium",
  },
];

// --- 3. CORE LOGIC: THE TRIAGE AGENT ---

/**
 * Simulates a vector similarity search.
 * In a production environment, this function would query Pinecone with a text embedding
 * of the ticket to find the most semantically similar known issues.
 * Here, we use a simple keyword matching heuristic for demonstration.
 *
 * @param ticketText - The combined subject and body of the ticket.
 * @returns The best-matching knowledge base entry.
 */
function simulateVectorSearch(ticketText: string): (typeof KNOWLEDGE_BASE)[0] {
  const lowerCaseText = ticketText.toLowerCase();
  
  // Find the knowledge base entry with the most keyword matches.
  // This is a simplified heuristic for the example.
  let bestMatch = KNOWLEDGE_BASE[0]; // Default to General/Low
  let maxMatches = 0;

  for (const entry of KNOWLEDGE_BASE) {
    const keywords = entry.pattern.split(' ');
    const matchCount = keywords.filter(keyword => lowerCaseText.includes(keyword)).length;
    
    if (matchCount > maxMatches) {
      maxMatches = matchCount;
      bestMatch = entry;
    }
  }

  return bestMatch;
}

/**
 * Analyzes a support ticket and returns a triage result.
 * This is the main function of our AI agent.
 *
 * @param ticket - The incoming support ticket.
 * @returns A promise that resolves to the triage result.
 */
async function triageSupportTicket(ticket: SupportTicket): Promise<TriageResult> {
  // Combine subject and body for analysis.
  const fullText = `${ticket.subject} ${ticket.body}`;

  // Step 1: Use the "AI" (simulated vector search) to find the best match.
  const matchedPattern = simulateVectorSearch(fullText);

  // Step 2: Generate a reasoning string based on the match.
  const reasoning = `Ticket analyzed. Keywords matched pattern for '${matchedPattern.team}' issues. ` +
                    `Identified priority level based on historical data for similar tickets.`;

  // Step 3: Construct and return the final result.
  return {
    ticketId: ticket.id,
    priority: matchedPattern.priority,
    assignedTeam: matchedPattern.team,
    reasoning: reasoning,
  };
}

// --- 4. MAIN EXECUTION BLOCK ---

/**
 * Main function to run the triage agent simulation.
 */
async function main() {
  console.log('🚀 AI Support Agent Initializing...\n');

  // Example 1: A billing-related issue
  const billingTicket: SupportTicket = {
    id: 'TICKET-101',
    customerEmail: 'user@example.com',
    subject: 'My payment failed!',
    body: 'I tried to upgrade my plan but my credit card was declined. Please help.',
  };

  // Example 2: A technical bug report
  const bugTicket: SupportTicket = {
    id: 'TICKET-102',
    customerEmail: 'dev@startup.io',
    subject: 'Critical Error in Dashboard',
    body: 'The application crashes every time I try to export the analytics report. This is a major bug.',
  };

  // Process tickets
  const [billingResult, bugResult] = await Promise.all([
    triageSupportTicket(billingTicket),
    triageSupportTicket(bugTicket),
  ]);

  // Display results
  console.log('--- Triage Results ---');
  console.log(`[Ticket: ${billingResult.ticketId}]`);
  console.log(`  - Assigned Team: ${billingResult.assignedTeam}`);
  console.log(`  - Priority: ${billingResult.priority}`);
  console.log(`  - Reasoning: ${billingResult.reasoning}\n`);

  console.log(`[Ticket: ${bugResult.ticketId}]`);
  console.log(`  - Assigned Team: ${bugResult.assignedTeam}`);
  console.log(`  - Priority: ${bugResult.priority}`);
  console.log(`  - Reasoning: ${bugResult.reasoning}\n`);
  
  console.log('✅ Triage process complete.');
}

// Execute the main function.
// Using a standard Node.js pattern to run an async main function.
if (require.main === module) {
  main().catch(error => {
    console.error('An unhandled error occurred:', error);
    process.exit(1);
  });
}
