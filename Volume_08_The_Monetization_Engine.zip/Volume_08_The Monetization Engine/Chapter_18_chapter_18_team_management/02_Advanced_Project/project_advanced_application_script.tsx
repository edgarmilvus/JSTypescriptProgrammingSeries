/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.tsx
// Description: Advanced Application Script
// ==========================================

// app/components/TeamPerformanceDashboard.tsx
'use client';

import React, { useState, useEffect, useReducer, useMemo } from 'react';

/**
 * @typedef {Object} AgentMetric
 * @description Represents performance data for a single support agent (AI or Human).
 * @property {string} id - Unique identifier for the agent.
 * @property {string} name - Display name of the agent.
 * @property {'AI' | 'HUMAN'} type - The type of agent.
 * @property {number} ticketsResolved - Total tickets resolved in the current period.
 * @property {number} avgResolutionTime - Average time to resolve tickets (in minutes).
 * @property {number} revenueAttributed - Revenue attributed via support upsell (in USD).
 */
type AgentMetric = {
  id: string;
  name: string;
  type: 'AI' | 'HUMAN';
  ticketsResolved: number;
  avgResolutionTime: number;
  revenueAttributed: number;
};

/**
 * @typedef {Object} DashboardState
 * @description The immutable state structure for the dashboard.
 * @property {AgentMetric[]} agents - Array of agent performance metrics.
 * @property {number} totalRevenue - Aggregated revenue from Stripe.
 * @property {string} lastUpdated - Timestamp of the last data fetch.
 * @property {'loading' | 'ready' | 'error'} status - Current data status.
 */
type DashboardState = {
  agents: AgentMetric[];
  totalRevenue: number;
  lastUpdated: string;
  status: 'loading' | 'ready' | 'error';
};

/**
 * @typedef {Object} DashboardAction
 * @description Actions for the immutable state reducer.
 */
type DashboardAction =
  | { type: 'FETCH_START' }
  | { type: 'FETCH_SUCCESS'; payload: { agents: AgentMetric[]; revenue: number } }
  | { type: 'UPDATE_AGENT_METRIC'; payload: Partial<AgentMetric> & { id: string } }
  | { type: 'FILTER_AGENTS'; filterType: 'ALL' | 'AI' | 'HUMAN' };

/**
 * @function dashboardReducer
 * @description Handles state transitions immutably. It never mutates the existing state object.
 * Instead, it creates new objects and arrays using the spread operator and map/filter.
 * @param {DashboardState} state - The current state.
 * @param {DashboardAction} action - The action dispatched.
 * @returns {DashboardState} The new state.
 */
const dashboardReducer = (state: DashboardState, action: DashboardAction): DashboardState => {
  switch (action.type) {
    case 'FETCH_START':
      return { ...state, status: 'loading' };
      
    case 'FETCH_SUCCESS':
      return {
        ...state,
        status: 'ready',
        agents: action.payload.agents, // Replaces array entirely (immutable)
        totalRevenue: action.payload.revenue,
        lastUpdated: new Date().toISOString(),
      };

    case 'UPDATE_AGENT_METRIC':
      // IMMUTABLE PATTERN: Map over the array to create a NEW array.
      // We do not use .push() or modify 'state.agents' directly.
      return {
        ...state,
        agents: state.agents.map((agent) =>
          agent.id === action.payload.id
            ? { ...agent, ...action.payload } // Merge updates into a new object
            : agent
        ),
      };

    case 'FILTER_AGENTS':
      // Note: In a real app, filtering might be a UI view state. 
      // Here we demonstrate creating a derived state or resetting based on action.
      // For simplicity, we return state as is, but in a complex app, 
      // we might maintain a separate 'filteredAgents' list in the state.
      return state;

    default:
      return state;
  }
};

/**
 * @function TeamPerformanceDashboard
 * @description A Client Component that manages team performance data.
 * It uses `useReducer` for complex state logic and `useEffect` for data hydration.
 */
export default function TeamPerformanceDashboard() {
  // 1. STATE MANAGEMENT
  // We use useReducer for predictable state transitions, crucial for team metrics.
  // Initial state is immutable.
  const [state, dispatch] = useReducer(dashboardReducer, {
    agents: [],
    totalRevenue: 0,
    lastUpdated: '',
    status: 'loading',
  });

  // Local UI state for filtering (Client-side interactivity)
  const [filter, setFilter] = useState<'ALL' | 'AI' | 'HUMAN'>('ALL');

  // 2. DATA HYDRATION (Simulating Server-Side Data Fetching)
  // This effect runs on the client after the initial server render (hydration).
  // It fetches "live" data from the backend (Stripe & Support APIs).
  useEffect(() => {
    dispatch({ type: 'FETCH_START' });

    // Simulate API calls to Stripe and Support Systems
    const fetchData = async () => {
      try {
        // Simulating network delay
        await new Promise((resolve) => setTimeout(resolve, 800));

        // Mock Data: AI Agent vs Human Agent
        const mockAgents: AgentMetric[] = [
          {
            id: 'ai-001',
            name: 'SupportBot v2.0 (AI)',
            type: 'AI',
            ticketsResolved: 1450,
            avgResolutionTime: 1.2,
            revenueAttributed: 3200,
          },
          {
            id: 'human-001',
            name: 'Sarah Connor (Lead)',
            type: 'HUMAN',
            ticketsResolved: 120,
            avgResolutionTime: 25.5,
            revenueAttributed: 15400,
          },
          {
            id: 'human-002',
            name: 'John Doe (Tier 2)',
            type: 'HUMAN',
            ticketsResolved: 85,
            avgResolutionTime: 45.0,
            revenueAttributed: 8200,
          },
        ];

        // Mock Stripe Revenue Total
        const mockRevenue = 26800;

        dispatch({
          type: 'FETCH_SUCCESS',
          payload: { agents: mockAgents, revenue: mockRevenue },
        });
      } catch (error) {
        console.error("Failed to hydrate data:", error);
      }
    };

    fetchData();
  }, []); // Empty dependency array ensures this runs once on mount/hydration

  // 3. DERIVED STATE (Memoization)
  // Calculating metrics on every render is expensive. useMemo optimizes this.
  // This separates calculation logic from rendering logic.
  const { filteredAgents, aiEfficiency, humanEfficiency } = useMemo(() => {
    const filtered = state.agents.filter((a) => filter === 'ALL' || a.type === filter);
    
    // Calculate Weighted Efficiency Scores
    // (Revenue / Avg Resolution Time) normalized
    const aiAgents = filtered.filter(a => a.type === 'AI');
    const humanAgents = filtered.filter(a => a.type === 'HUMAN');

    const calculateScore = (agents: AgentMetric[]) => {
      if (agents.length === 0) return 0;
      const totalRev = agents.reduce((sum, a) => sum + a.revenueAttributed, 0);
      const avgTime = agents.reduce((sum, a) => sum + a.avgResolutionTime, 0) / agents.length;
      return avgTime > 0 ? (totalRev / avgTime).toFixed(2) : 0;
    };

    return {
      filteredAgents: filtered,
      aiEfficiency: calculateScore(aiAgents),
      humanEfficiency: calculateScore(humanAgents),
    };
  }, [state.agents, filter]);

  // 4. EVENT HANDLING: Simulation of Real-time Updates
  // Simulates an incoming webhook event (e.g., Stripe payment or Support ticket resolved)
  const simulateIncomingEvent = () => {
    const randomAgentId = state.agents[Math.floor(Math.random() * state.agents.length)].id;
    const randomRevenueBoost = Math.floor(Math.random() * 500) + 50;
    
    dispatch({
      type: 'UPDATE_AGENT_METRIC',
      payload: {
        id: randomAgentId,
        revenueAttributed: randomRevenueBoost, // In real app, this would be an increment
      },
    });
  };

  if (state.status === 'loading') {
    return <div className="p-6 text-gray-500">Hydrating Dashboard Data...</div>;
  }

  return (
    <div className="max-w-5xl mx-auto p-6 bg-slate-900 text-slate-100 rounded-lg shadow-xl font-sans">
      {/* Header Section */}
      <header className="flex justify-between items-center mb-6 border-b border-slate-700 pb-4">
        <div>
          <h1 className="text-2xl font-bold text-white">Monetization Engine: Team Ops</h1>
          <p className="text-sm text-slate-400">Real-time monitoring of Stripe & Support Agents</p>
        </div>
        <div className="text-right">
          <div className="text-xs text-slate-400 uppercase tracking-wider">Total Revenue</div>
          <div className="text-2xl font-mono text-green-400">${state.totalRevenue.toLocaleString()}</div>
          <div className="text-xs text-slate-500">Last updated: {new Date(state.lastUpdated).toLocaleTimeString()}</div>
        </div>
      </header>

      {/* Metrics Overview */}
      <div className="grid grid-cols-2 gap-4 mb-6">
        <div className="bg-slate-800 p-4 rounded border border-slate-700">
          <h3 className="text-sm text-slate-400 mb-1">AI Efficiency Score</h3>
          <div className="text-xl font-bold text-blue-400">{aiEfficiency}</div>
        </div>
        <div className="bg-slate-800 p-4 rounded border border-slate-700">
          <h3 className="text-sm text-slate-400 mb-1">Human Efficiency Score</h3>
          <div className="text-xl font-bold text-orange-400">{humanEfficiency}</div>
        </div>
      </div>

      {/* Controls */}
      <div className="flex gap-2 mb-4">
        <button 
          onClick={() => setFilter('ALL')}
          className={`px-3 py-1 rounded text-sm ${filter === 'ALL' ? 'bg-white text-black' : 'bg-slate-700 text-white'}`}
        >
          All
        </button>
        <button 
          onClick={() => setFilter('AI')}
          className={`px-3 py-1 rounded text-sm ${filter === 'AI' ? 'bg-blue-600 text-white' : 'bg-slate-700 text-white'}`}
        >
          AI Only
        </button>
        <button 
          onClick={() => setFilter('HUMAN')}
          className={`px-3 py-1 rounded text-sm ${filter === 'HUMAN' ? 'bg-orange-600 text-white' : 'bg-slate-700 text-white'}`}
        >
          Human Only
        </button>
        
        <div className="flex-grow"></div>
        
        {/* Simulation Button for Demo Purposes */}
        <button 
          onClick={simulateIncomingEvent}
          className="px-3 py-1 rounded text-sm bg-indigo-600 hover:bg-indigo-500 text-white transition-colors"
        >
          Simulate Webhook Event
        </button>
      </div>

      {/* Data Table */}
      <div className="overflow-x-auto">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="text-xs text-slate-400 uppercase border-b border-slate-700">
              <th className="p-3">Agent Name</th>
              <th className="p-3">Type</th>
              <th className="p-3 text-right">Tickets</th>
              <th className="p-3 text-right">Avg Time (min)</th>
              <th className="p-3 text-right">Revenue Attributed</th>
            </tr>
          </thead>
          <tbody>
            {filteredAgents.map((agent) => (
              <tr 
                key={agent.id} 
                className="border-b border-slate-800 hover:bg-slate-800/50 transition-colors"
              >
                <td className="p-3 font-medium">{agent.name}</td>
                <td className="p-3">
                  <span className={`px-2 py-1 rounded text-xs font-bold ${
                    agent.type === 'AI' ? 'bg-blue-900 text-blue-200' : 'bg-orange-900 text-orange-200'
                  }`}>
                    {agent.type}
                  </span>
                </td>
                <td className="p-3 text-right font-mono">{agent.ticketsResolved.toLocaleString()}</td>
                <td className="p-3 text-right font-mono">{agent.avgResolutionTime}</td>
                <td className="p-3 text-right font-mono text-green-400">${agent.revenueAttributed.toLocaleString()}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
