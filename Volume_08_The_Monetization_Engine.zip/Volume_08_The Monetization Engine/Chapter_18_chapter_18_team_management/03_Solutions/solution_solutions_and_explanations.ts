/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

import Stripe from 'stripe';
import { v4 as uuidv4 } from 'uuid';

// Define immutable interfaces for type safety
interface ImmutablePaymentRecord {
    readonly id: string;
    readonly stripeEventId: string;
    readonly amount: number;
    readonly currency: string;
    readonly customerId: string;
    readonly status: 'succeeded' | 'failed' | 'pending';
    readonly timestamp: Date;
    readonly metadata: Readonly<Record<string, any>>;
}

// In-memory store for demo purposes (replace with Redis/DB in production)
const paymentRecords = new Map<string, ImmutablePaymentRecord>();

/**
 * Handles Stripe webhook events immutably.
 * 
 * Team Alignment:
 * - Customer Success: Failed payments trigger AI agents for recovery workflows.
 * - Product Team: Success rates feed into revenue KPI dashboards for feature prioritization.
 * 
 * Testing Considerations:
 * - Unit tests should mock concurrent webhook calls using Promise.all()
 * - Verify no mutations occur by deep-freezing test inputs
 * - Check for duplicate event handling via event ID tracking
 */
export async function handleStripeWebhook(
    event: Stripe.Event,
    stripeSecretKey: string
): Promise<ImmutablePaymentRecord> {
    // 1. Validate Stripe signature
    const stripe = new Stripe(stripeSecretKey, { apiVersion: '2023-10-16' });
    
    try {
        // In production, verify the signature with stripe.webhooks.constructEvent
        // For this example, we assume the event is already validated
    } catch (error) {
        throw new Error(`Invalid Stripe signature: ${error}`);
    }

    // 2. Check for duplicate events (idempotency)
    const existingRecord = paymentRecords.get(event.id);
    if (existingRecord) {
        console.log(`Duplicate event detected: ${event.id}`);
        return existingRecord;
    }

    // 3. Parse event data immutably
    let paymentData: Omit<ImmutablePaymentRecord, 'id' | 'timestamp'>;
    
    switch (event.type) {
        case 'payment_intent.succeeded':
            const paymentIntent = event.data.object as Stripe.PaymentIntent;
            paymentData = {
                stripeEventId: event.id,
                amount: paymentIntent.amount / 100, // Convert from cents
                currency: paymentIntent.currency || 'usd',
                customerId: paymentIntent.customer as string,
                status: 'succeeded',
                metadata: Object.freeze({ ...paymentIntent.metadata })
            };
            break;
            
        case 'invoice.payment_failed':
            const invoice = event.data.object as Stripe.Invoice;
            paymentData = {
                stripeEventId: event.id,
                amount: invoice.amount_due / 100,
                currency: invoice.currency || 'usd',
                customerId: invoice.customer as string,
                status: 'failed',
                metadata: Object.freeze({ ...invoice.metadata })
            };
            break;
            
        default:
            console.warn(`Unhandled event type: ${event.type}`);
            // Return a generic record for unhandled events
            paymentData = {
                stripeEventId: event.id,
                amount: 0,
                currency: 'usd',
                customerId: 'unknown',
                status: 'pending',
                metadata: Object.freeze({})
            };
    }

    // 4. Create immutable record using Object.freeze and spread operator
    const newRecord: ImmutablePaymentRecord = Object.freeze({
        id: uuidv4(),
        timestamp: new Date(),
        ...paymentData
    });

    // 5. Store immutably (no mutation of existing data)
    paymentRecords.set(event.id, newRecord);

    // 6. Log for monitoring (non-mutating operation)
    console.log(`Processed payment: ${newRecord.id} - ${newRecord.status}`);

    return newRecord;
}

// Example usage with concurrent webhook simulation
export async function simulateConcurrentWebhooks() {
    const mockEvent: Stripe.Event = {
        id: 'evt_test_123',
        type: 'payment_intent.succeeded',
        data: {
            object: {
                amount: 1000,
                currency: 'usd',
                customer: 'cus_123',
                metadata: { plan: 'premium' }
            } as any
        }
    } as any;

    // Simulate concurrent processing
    const promises = Array(5).fill(null).map(() => 
        handleStripeWebhook(mockEvent, 'sk_test_123')
    );
    
    const results = await Promise.all(promises);
    console.log(`All ${results.length} concurrent calls returned the same immutable record`);
}
