/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

import { Pinecone, Vector, QueryOptions } from '@pinecone-database/pinecone';

// Define immutable interfaces
interface ImmutableSupportResponse {
    readonly relevantTickets: ReadonlyArray<string>;
    readonly suggestedResponse: string;
    readonly confidenceScore: number;
    readonly queryTimestamp: Date;
}

interface PineconeConnectionError extends Error {
    code: 'PINECONE_CONNECTION_ERROR';
}

// Mock embedding generator (in production, use a proper embedding model)
function generateMockEmbedding(text: string): number[] {
    // Simple deterministic embedding based on string length
    const base = text.length / 100;
    return Array(1536).fill(0).map((_, i) => 
        (base + (i % 10) * 0.01) % 1.0
    );
}

/**
 * Queries Pinecone immutably for support ticket similarity.
 * 
 * Team Alignment:
 * - Support Team: Handles 80% of routine queries automatically, freeing agents for complex issues.
 * - Engineering Team: Focuses on optimizing search algorithms and embedding models.
 * - KPI: Reduce average resolution time by 30% and increase agent capacity by 2x.
 * 
 * Error Handling:
 * - Throws typed PineconeConnectionError without mutating global state
 * - Returns empty results for no matches without side effects
 */
export async function querySupportTickets(
    query: string,
    customerId: string,
    pineconeApiKey: string
): Promise<ImmutableSupportResponse> {
    try {
        // 1. Initialize Pinecone client immutably
        const pinecone = new Pinecone({ 
            apiKey: pineconeApiKey,
            environment: 'us-west1-gcp'
        });
        
        const index = pinecone.Index('support-tickets');

        // 2. Generate query embedding (immutable transformation)
        const queryEmbedding = generateMockEmbedding(query);
        
        // 3. Perform similarity search (no mutation of Pinecone index)
        const queryRequest: QueryOptions = {
            vector: queryEmbedding,
            topK: 3,
            includeMetadata: true
        };

        const queryResponse = await index.query(queryRequest);

        // 4. Extract relevant ticket IDs immutably
        const relevantTickets = queryResponse.matches?.map(match => 
            match.id
        ) || [];

        // 5. Generate suggested response using immutable string operations
        let suggestedResponse: string;
        let confidenceScore: number;

        if (relevantTickets.length === 0) {
            suggestedResponse = "I understand you're having billing issues. Let me connect you with a human agent for personalized assistance.";
            confidenceScore = 0.0;
        } else {
            // Simple template-based response generation (immutable)
            const ticketCount = relevantTickets.length;
            suggestedResponse = `Based on ${ticketCount} similar cases, here's what helped other customers: Please check your payment method and ensure sufficient funds. If the issue persists, our team can assist.`;
            confidenceScore = Math.min(0.3 + (ticketCount * 0.2), 0.95);
        }

        // 6. Create immutable response object
        const response: ImmutableSupportResponse = Object.freeze({
            relevantTickets: Object.freeze(relevantTickets),
            suggestedResponse,
            confidenceScore,
            queryTimestamp: new Date()
        });

        return response;

    } catch (error) {
        // 7. Throw typed error without mutating state
        const pineconeError: PineconeConnectionError = {
            name: 'PineconeConnectionError',
            code: 'PINECONE_CONNECTION_ERROR',
            message: `Failed to connect to Pinecone: ${error instanceof Error ? error.message : String(error)}`
        };
        throw pineconeError;
    }
}

// Example usage with mock data
export async function demonstrateSupportAgent() {
    // Upsert sample ticket embedding (mock operation)
    // In production: await index.upsert([vector])
    console.log("Upserting sample ticket embedding...");
    
    const response = await querySupportTickets(
        "payment failed insufficient funds",
        "customer_123",
        "demo-api-key"
    );
    
    console.log("Immutable Support Response:", {
        tickets: response.relevantTickets,
        response: response.suggestedResponse,
        confidence: response.confidenceScore
    });
}
