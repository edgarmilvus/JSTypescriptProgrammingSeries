/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

'use client';

import React, { useState, useEffect, useMemo } from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

// Define immutable KPI interfaces
interface ImmutableKPI {
    readonly id: string;
    readonly name: string;
    readonly value: number;
    readonly timestamp: Date;
    readonly trend: 'up' | 'down' | 'stable';
}

interface KPIDashboardProps {
    initialRevenueKPIs: ImmutableKPI[];
    initialSupportKPIs: ImmutableKPI[];
    initialVelocityKPIs: ImmutableKPI[];
}

/**
 * KPIDashboard - Client Component for real-time KPI visualization
 * 
 * Team Alignment:
 * - Product Team: Uses revenue KPIs for feature prioritization and roadmap decisions
 * - Support Team: Monitors resolution rates for agent training and resource allocation
 * - Engineering Team: Tracks team velocity for sprint planning and capacity management
 * 
 * Performance Optimization:
 * - Memoized calculations prevent unnecessary re-renders
 * - Immutable updates ensure consistent hydration between server and client
 * - Virtualized rendering for large datasets (via recharts)
 */
const KPIDashboard: React.FC<KPIDashboardProps> = ({
    initialRevenueKPIs,
    initialSupportKPIs,
    initialVelocityKPIs
}) => {
    // 1. State management with immutable updates
    const [revenueKPIs, setRevenueKPIs] = useState<ImmutableKPI[]>(() => 
        Object.freeze(initialRevenueKPIs)
    );
    
    const [supportKPIs, setSupportKPIs] = useState<ImmutableKPI[]>(() => 
        Object.freeze(initialSupportKPIs)
    );
    
    const [velocityKPIs, setVelocityKPIs] = useState<ImmutableKPI[]>(() => 
        Object.freeze(initialVelocityKPIs)
    );

    // 2. Simulate real-time updates (WebSocket simulation)
    useEffect(() => {
        const interval = setInterval(() => {
            // Create new immutable KPI objects
            const newRevenueKPI: ImmutableKPI = Object.freeze({
                id: `rev_${Date.now()}`,
                name: 'Daily Revenue',
                value: Math.random() * 1000 + 5000,
                timestamp: new Date(),
                trend: Math.random() > 0.5 ? 'up' : 'down'
            });

            // Immutable update: create new array, never mutate in place
            setRevenueKPIs(prev => {
                const newArray = [...prev, newRevenueKPI];
                // Keep only last 20 entries for performance
                return Object.freeze(newArray.slice(-20));
            });

            // Similar immutable updates for other KPIs
            const newSupportKPI: ImmutableKPI = Object.freeze({
                id: `sup_${Date.now()}`,
                name: 'Resolution Rate',
                value: 70 + Math.random() * 25,
                timestamp: new Date(),
                trend: 'up'
            });

            setSupportKPIs(prev => Object.freeze([...prev, newSupportKPI].slice(-20)));

        }, 3000); // Update every 3 seconds

        return () => clearInterval(interval);
    }, []);

    // 3. Memoized calculations to prevent unnecessary re-renders
    const averageRevenue = useMemo(() => {
        if (revenueKPIs.length === 0) return 0;
        const sum = revenueKPIs.reduce((acc, kpi) => acc + kpi.value, 0);
        return sum / revenueKPIs.length;
    }, [revenueKPIs]);

    const averageResolutionRate = useMemo(() => {
        if (supportKPIs.length === 0) return 0;
        const sum = supportKPIs.reduce((acc, kpi) => acc + kpi.value, 0);
        return sum / supportKPIs.length;
    }, [supportKPIs]);

    const currentVelocity = useMemo(() => {
        if (velocityKPIs.length === 0) return 0;
        return velocityKPIs[velocityKPIs.length - 1].value;
    }, [velocityKPIs]);

    // 4. Memoized chart data to prevent re-creation on every render
    const chartData = useMemo(() => {
        return revenueKPIs.map(kpi => ({
            time: kpi.timestamp.toLocaleTimeString(),
            revenue: kpi.value,
            resolution: supportKPIs.find(s => s.id === kpi.id)?.value || 0
        }));
    }, [revenueKPIs, supportKPIs]);

    return (
        <div className="kpi-dashboard" style={{ padding: '20px', fontFamily: 'system-ui' }}>
            <h1>Monetization Engine Dashboard</h1>
            
            {/* KPI Summary Cards */}
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '20px', marginBottom: '30px' }}>
                <div style={{ padding: '20px', border: '1px solid #ddd', borderRadius: '8px' }}>
                    <h3>Average Revenue</h3>
                    <p style={{ fontSize: '24px', fontWeight: 'bold' }}>
                        ${averageRevenue.toFixed(2)}
                    </p>
                    <small>Real-time from Stripe webhooks</small>
                </div>
                
                <div style={{ padding: '20px', border: '1px solid #ddd', borderRadius: '8px' }}>
                    <h3>Resolution Rate</h3>
                    <p style={{ fontSize: '24px', fontWeight: 'bold' }}>
                        {averageResolutionRate.toFixed(1)}%
                    </p>
                    <small>AI agent performance</small>
                </div>
                
                <div style={{ padding: '20px', border: '1px solid #ddd', borderRadius: '8px' }}>
                    <h3>Team Velocity</h3>
                    <p style={{ fontSize: '24px', fontWeight: 'bold' }}>
                        {currentVelocity.toFixed(1)}
                    </p>
                    <small>Story points completed</small>
                </div>
            </div>

            {/* Revenue Trend Chart */}
            <div style={{ height: '400px', marginBottom: '30px' }}>
                <h3>Revenue & Resolution Trends</h3>
                <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={chartData}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="time" />
                        <YAxis yAxisId="left" />
                        <YAxis yAxisId="right" orientation="right" />
                        <Tooltip />
                        <Legend />
                        <Line 
                            yAxisId="left" 
                            type="monotone" 
                            dataKey="revenue" 
                            stroke="#8884d8" 
                            name="Revenue ($)" 
                        />
                        <Line 
                            yAxisId="right" 
                            type="monotone" 
                            dataKey="resolution" 
                            stroke="#82ca9d" 
                            name="Resolution Rate (%)" 
                        />
                    </LineChart>
                </ResponsiveContainer>
            </div>

            {/* Raw Data Table (for debugging) */}
            <details>
                <summary>Raw KPI Data (Last 5 entries)</summary>
                <pre style={{ 
                    background: '#f5f5f5', 
                    padding: '10px', 
                    borderRadius: '4px',
                    maxHeight: '200px',
                    overflow: 'auto'
                }}>
                    {JSON.stringify({
                        revenue: revenueKPIs.slice(-5),
                        support: supportKPIs.slice(-5)
                    }, null, 2)}
                </pre>
            </details>
        </div>
    );
};

// 5. Server Component wrapper for initial data fetching
// This would be in a separate server-side file in Next.js
export async function getServerSideKPIs() {
    // Simulate API calls to Stripe and Pinecone
    const mockRevenueKPIs: ImmutableKPI[] = Object.freeze([
        { id: '1', name: 'Daily Revenue', value: 5200, timestamp: new Date(), trend: 'up' },
        { id: '2', name: 'Daily Revenue', value: 5400, timestamp: new Date(), trend: 'up' },
    ]);

    const mockSupportKPIs: ImmutableKPI[] = Object.freeze([
        { id: '1', name: 'Resolution Rate', value: 85, timestamp: new Date(), trend: 'up' },
        { id: '2', name: 'Resolution Rate', value: 87, timestamp: new Date(), trend: 'up' },
    ]);

    const mockVelocityKPIs: ImmutableKPI[] = Object.freeze([
        { id: '1', name: 'Team Velocity', value: 42, timestamp: new Date(), trend: 'stable' },
    ]);

    return {
        initialRevenueKPIs: mockRevenueKPIs,
        initialSupportKPIs: mockSupportKPIs,
        initialVelocityKPIs: mockVelocityKPIs
    };
}

export default KPIDashboard;
