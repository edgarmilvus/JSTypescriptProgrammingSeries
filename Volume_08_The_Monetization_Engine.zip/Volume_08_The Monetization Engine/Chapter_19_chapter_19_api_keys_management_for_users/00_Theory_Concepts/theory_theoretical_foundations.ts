/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: theory_theoretical_foundations.ts
// Description: Theoretical Foundations
// ==========================================

// Define an immutable interface for API Key Configuration
interface ApiKeyConfig {
    readonly keyId: string;
    readonly scopes: ReadonlyArray<string>; // e.g., ['read:customers', 'write:logs']
    readonly environment: 'test' | 'live';
    readonly expiresAt: Date;
}

// Function to update a key's scope immutably
function updateKeyScopes(
    currentConfig: ApiKeyConfig,
    newScopes: string[]
): ApiKeyConfig {
    // Instead of mutating currentConfig.scopes, we create a new object
    return {
        ...currentConfig, // Spread existing properties
        scopes: Object.freeze([...newScopes]), // Create a new, frozen array
        // The old config object remains untouched and valid for audit trails
    };
}

// Usage
const originalConfig: ApiKeyConfig = {
    keyId: 'sk_123',
    scopes: Object.freeze(['read:customers']),
    environment: 'live',
    expiresAt: new Date('2024-12-31'),
};

// This operation does not change originalConfig
const updatedConfig = updateKeyScopes(originalConfig, ['read:customers', 'write:logs']);

// originalConfig.scopes is still ['read:customers']
// updatedConfig.scopes is ['read:customers', 'write:logs']
