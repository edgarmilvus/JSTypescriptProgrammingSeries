/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

// File: app/components/VectorSearch.tsx
// This file contains both the Server Component (Parent) and Client Component (Child).

import { Pinecone } from '@pinecone-database/pinecone';
import { SearchClient } from './SearchClient'; // Assuming a separate Client Component file for clarity

// ============================================================================
// 1. SERVER COMPONENT: Secure Data Fetching
// ============================================================================

/**
 * @description A Server Component that runs exclusively on the server.
 * It initializes the Pinecone client using a server-side environment variable
 * and performs a vector similarity search.
 * 
 * @returns {Promise<JSX.Element>} Renders the client component with fetched data.
 */
export default async function VectorSearchServer() {
  // -----------------------------------------------------------------------
  // SECURITY: Environment Variable Access
  // -----------------------------------------------------------------------
  // In Next.js, process.env variables are only accessible on the server
  // unless explicitly prefixed with NEXT_PUBLIC_.
  const pineconeApiKey = process.env.PINECONE_API_KEY;
  const pineconeEnvironment = process.env.PINECONE_ENVIRONMENT;
  const pineconeIndexName = process.env.PINECONE_INDEX_NAME || 'default-index';

  if (!pineconeApiKey || !pineconeEnvironment) {
    // Fail fast: Do not render if secrets are missing.
    return <div>Error: Pinecone configuration missing.</div>;
  }

  // -----------------------------------------------------------------------
  // CLIENT INITIALIZATION (Server-Side Only)
  // -----------------------------------------------------------------------
  // The Pinecone client is instantiated here. This is safe because
  // this code executes in the Node.js runtime environment, not the browser.
  const pc = new Pinecone({
    apiKey: pineconeApiKey,
    environment: pineconeEnvironment,
  });

  // Access the specific index.
  const index = pc.Index(pineconeIndexName);

  // -----------------------------------------------------------------------
  // DATA FETCHING: Vector Similarity Search
  // -----------------------------------------------------------------------
  try {
    // Example query vector (in a real app, this would come from an embedding model).
    const queryVector = [0.1, 0.2, 0.3, 0.4]; // Dummy vector for demonstration

    // Perform the query. This executes against the Pinecone API.
    const queryResponse = await index.query({
      vector: queryVector,
      topK: 3,
      includeMetadata: true,
    });

    // ---------------------------------------------------------------------
    // DATA SANITIZATION
    // ---------------------------------------------------------------------
    // We only extract the necessary data to send to the client.
    // We strip out internal IDs or sensitive metadata if present.
    const safeResults = queryResponse.matches.map((match) => ({
      id: match.id,
      score: match.score,
      // Assuming metadata has a 'text' field we want to display.
      text: (match.metadata as { text?: string })?.text || 'No text available',
    }));

    // ---------------------------------------------------------------------
    // RENDER PASS
    // ---------------------------------------------------------------------
    // Pass the sanitized data to the Client Component.
    return <SearchClient initialResults={safeResults} />;
    
  } catch (error) {
    console.error('Pinecone Query Error:', error);
    return <div>Error performing search.</div>;
  }
}

// File: app/components/SearchClient.tsx
// This is the Client Component responsible for interactivity.

'use client'; // Marks this as a Client Component for the Next.js App Router.

import { useState } from 'react';

/**
 * @description A Client Component that renders in the browser.
 * It receives initial data from the server but handles user interactions
 * like re-querying or filtering locally.
 * 
 * @param {Object} props
 * @param {Array<{id: string, score: number, text: string}>} props.initialResults
 */
export function SearchClient({ initialResults }: { initialResults: any[] }) {
  const [results, setResults] = useState(initialResults);
  const [loading, setLoading] = useState(false);

  // This function simulates a client-side action, like filtering the existing data
  // or triggering a new server action (which would require a Server Action API route).
  const handleFilter = () => {
    setLoading(true);
    // Simulate async delay
    setTimeout(() => {
      // Filter locally (mock example)
      const filtered = results.filter((r) => r.score > 0.1);
      setResults(filtered);
      setLoading(false);
    }, 500);
  };

  return (
    <div className="p-4 border rounded">
      <h2 className="text-lg font-bold mb-2">Search Results</h2>
      <button 
        onClick={handleFilter}
        className="bg-blue-500 text-white px-3 py-1 rounded mb-4"
        disabled={loading}
      >
        {loading ? 'Filtering...' : 'Filter Low Scores'}
      </button>

      <ul>
        {results.map((result) => (
          <li key={result.id} className="mb-2 border-b pb-2">
            <p><strong>ID:</strong> {result.id}</p>
            <p><strong>Score:</strong> {result.score.toFixed(4)}</p>
            <p><strong>Text:</strong> {result.text}</p>
          </li>
        ))}
      </ul>
    </div>
  );
}
