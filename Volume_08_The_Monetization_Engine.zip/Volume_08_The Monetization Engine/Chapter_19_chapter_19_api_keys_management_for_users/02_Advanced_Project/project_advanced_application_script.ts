/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// app/api/keys/route.ts (Server-Side API Route)
import { NextRequest, NextResponse } from 'next/server';
import { SecretsManager } from '@/lib/secrets-manager'; // Assume this is a separate module
import { generateApiKey, rotateApiKey, revokeApiKey } from '@/lib/key-utils';
import { monitorUsage, detectAnomaly } from '@/lib/monitoring';
import { User, ApiKey, Permission } from '@/types/api-keys';

// Mock user session (in production, use NextAuth or JWT)
const mockUser: User = {
  id: 'user-123',
  role: 'admin', // or 'developer'
  permissions: ['read:keys', 'write:keys', 'revoke:keys'], // Admins have full access
};

// Middleware for RBAC (simplified; in production, use Next.js middleware)
function checkPermission(user: User, required: Permission): boolean {
  return user.permissions.includes(required);
}

// POST: Generate a new API key
export async function POST(req: NextRequest) {
  const { environment, userId } = await req.json() as { environment: 'test' | 'live'; userId: string };

  // Check permission: Admins can generate for any user; Developers only for themselves
  if (!checkPermission(mockUser, 'write:keys') || (mockUser.role === 'developer' && userId !== mockUser.id)) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 403 });
  }

  try {
    const newKey = generateApiKey(environment, userId);
    const secretsManager = new SecretsManager();
    await secretsManager.storeKey(newKey); // Securely store (e.g., AWS Secrets Manager)
    
    // Log for auditing
    console.log(`[AUDIT] Key generated for user ${userId} in ${environment} mode`);

    return NextResponse.json({ key: newKey }, { status: 201 });
  } catch (error) {
    return NextResponse.json({ error: 'Key generation failed' }, { status: 500 });
  }
}

// GET: Retrieve keys for a user (with monitoring)
export async function GET(req: NextRequest) {
  const { userId } = await req.nextUrl.searchParams as { userId: string };

  if (!checkPermission(mockUser, 'read:keys') || (mockUser.role === 'developer' && userId !== mockUser.id)) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 403 });
  }

  try {
    const secretsManager = new SecretsManager();
    const keys = await secretsManager.getKeysByUser(userId);

    // Monitor usage for each key
    const monitoredKeys = await Promise.all(keys.map(async (key) => {
      const usage = await monitorUsage(key.id);
      const isAnomaly = detectAnomaly(usage);
      if (isAnomaly) {
        await revokeApiKey(key.id); // Immediate invalidation
        return { ...key, status: 'revoked', reason: 'anomaly detected' };
      }
      return { ...key, status: 'active' };
    }));

    // Immutable state: Return new array without mutating original
    return NextResponse.json({ keys: monitoredKeys }, { status: 200 });
  } catch (error) {
    return NextResponse.json({ error: 'Failed to retrieve keys' }, { status: 500 });
  }
}

// DELETE: Revoke a key
export async function DELETE(req: NextRequest) {
  const { keyId } = await req.json() as { keyId: string };

  if (!checkPermission(mockUser, 'revoke:keys')) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 403 });
  }

  try {
    await revokeApiKey(keyId);
    console.log(`[AUDIT] Key ${keyId} revoked by user ${mockUser.id}`);
    return NextResponse.json({ success: true }, { status: 200 });
  } catch (error) {
    return NextResponse.json({ error: 'Revocation failed' }, { status: 500 });
  }
}
