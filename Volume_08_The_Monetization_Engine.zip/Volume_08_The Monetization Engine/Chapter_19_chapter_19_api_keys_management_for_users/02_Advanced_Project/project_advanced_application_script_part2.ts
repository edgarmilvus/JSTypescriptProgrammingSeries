/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script_part2.ts
// Description: Advanced Application Script
// ==========================================

// lib/secrets-manager.ts (Mock Secrets Manager)
export class SecretsManager {
  private storage: Map<string, ApiKey> = new Map(); // In-memory simulation; use Redis/DB in production

  /**
   * Stores an API key securely.
   * @param key - The ApiKey object to store.
   * @throws Error if storage fails.
   */
  async storeKey(key: ApiKey): Promise<void> {
    // Simulate encryption (in production, use AWS KMS or similar)
    this.storage.set(key.id, { ...key, value: `encrypted-${key.value}` });
  }

  /**
   * Retrieves keys for a specific user (immutable: returns new array).
   * @param userId - The user ID.
   * @returns Array of ApiKey objects.
   */
  async getKeysByUser(userId: string): Promise<ApiKey[]> {
    const userKeys = Array.from(this.storage.values()).filter(k => k.userId === userId);
    // Return immutable copy
    return userKeys.map(k => ({ ...k }));
  }

  /**
   * Invalidates a key by removing it (or marking as revoked).
   * @param keyId - The key ID to revoke.
   */
  async revokeKey(keyId: string): Promise<void> {
    this.storage.delete(keyId);
  }
}
