/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script_part3.ts
// Description: Advanced Application Script
// ==========================================

// lib/key-utils.ts (Key Generation and Rotation Utilities)
import crypto from 'crypto';

/**
 * Generates a new API key with scoping.
 * @param environment - 'test' or 'live' for scoping.
 * @param userId - The user owning the key.
 * @returns New ApiKey object.
 */
export function generateApiKey(environment: 'test' | 'live', userId: string): ApiKey {
  const keyId = `key_${crypto.randomUUID()}`;
  const value = `sk_${environment}_${crypto.randomBytes(32).toString('hex')}`; // Stripe-like format
  const now = new Date();

  return {
    id: keyId,
    value,
    userId,
    environment,
    createdAt: now,
    expiresAt: new Date(now.getTime() + 30 * 24 * 60 * 60 * 1000), // 30 days
    permissions: ['read', 'write'], // Least-privilege: Customize per role
  };
}

/**
 * Rotates an API key: Generate new, invalidate old.
 * @param oldKeyId - The key to rotate.
 * @param secretsManager - Instance of SecretsManager.
 * @returns New ApiKey object.
 * @throws Error if key not found.
 */
export async function rotateApiKey(oldKeyId: string, secretsManager: SecretsManager): Promise<ApiKey> {
  const keys = await secretsManager.getKeysByUser(mockUser.id); // Assume user context
  const oldKey = keys.find(k => k.id === oldKeyId);
  if (!oldKey) throw new Error('Key not found');

  // Generate new key with same scope
  const newKey = generateApiKey(oldKey.environment, oldKey.userId);
  await secretsManager.storeKey(newKey);

  // Invalidate old key
  await secretsManager.revokeKey(oldKeyId);

  console.log(`[AUDIT] Key ${oldKeyId} rotated to ${newKey.id}`);
  return newKey;
}

/**
 * Revokes a key immediately.
 * @param keyId - The key ID.
 * @param secretsManager - Instance of SecretsManager.
 */
export async function revokeApiKey(keyId: string): Promise<void> {
  const secretsManager = new SecretsManager();
  await secretsManager.revokeKey(keyId);
}
