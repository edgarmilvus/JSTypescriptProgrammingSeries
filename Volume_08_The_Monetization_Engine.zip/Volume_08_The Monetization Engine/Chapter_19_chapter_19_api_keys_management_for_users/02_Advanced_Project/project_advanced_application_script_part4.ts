/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script_part4.ts
// Description: Advanced Application Script
// ==========================================

// lib/monitoring.ts (Usage Monitoring and Anomaly Detection)
import { ApiKey } from '@/types/api-keys';

// Mock usage data (in production, integrate with Stripe logs or custom analytics)
const usageLog: Map<string, number[]> = new Map(); // keyId -> array of request timestamps

/**
 * Logs API usage for a key (immutable: creates new log entry).
 * @param keyId - The key ID.
 * @param timestamp - Request timestamp (defaults to now).
 */
export function logUsage(keyId: string, timestamp: Date = new Date()): void {
  const existing = usageLog.get(keyId) || [];
  // Immutable update: Create new array
  usageLog.set(keyId, [...existing, timestamp.getTime()]);
}

/**
 * Monitors usage and returns metrics.
 * @param keyId - The key ID.
 * @returns Usage metrics (e.g., requests per minute).
 */
export async function monitorUsage(keyId: string): Promise<{ rpm: number; total: number }> {
  const timestamps = usageLog.get(keyId) || [];
  const now = Date.now();
  const oneMinuteAgo = now - 60000;
  const recent = timestamps.filter(t => t > oneMinuteAgo);
  return { rpm: recent.length, total: timestamps.length };
}

/**
 * Detects anomalies based on thresholds (e.g., >100 RPM).
 * @param usage - The usage metrics.
 * @returns boolean indicating anomaly.
 */
export function detectAnomaly(usage: { rpm: number; total: number }): boolean {
  const THRESHOLD_RPM = 100; // Configurable
  return usage.rpm > THRESHOLD_RPM;
}

// Example usage: Simulate logging (call this in your API or middleware)
// logUsage('key_123');
