/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script_part6.tsx
// Description: Advanced Application Script
// ==========================================

// app/components/ApiKeyManager.tsx (Client Component for UI)
'use client';

import { useState, useEffect } from 'react';
import { ApiKey } from '@/types/api-keys';

/**
 * ApiKeyManager Component: Admin dashboard for key management.
 * Uses Client Component for interactivity and state management.
 */
export default function ApiKeyManager() {
  const [keys, setKeys] = useState<ApiKey[]>([]); // Immutable state
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Fetch keys on mount (immutable update)
  useEffect(() => {
    fetchKeys();
  }, []);

  const fetchKeys = async () => {
    setLoading(true);
    try {
      const res = await fetch(`/api/keys?userId=user-123`);
      if (!res.ok) throw new Error('Failed to fetch');
      const data = await res.json();
      // Immutable: Create new array
      setKeys([...data.keys]);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unknown error');
    } finally {
      setLoading(false);
    }
  };

  const generateKey = async (environment: 'test' | 'live') => {
    setLoading(true);
    try {
      const res = await fetch('/api/keys', {
        method: 'POST',
        body: JSON.stringify({ environment, userId: 'user-123' }),
      });
      if (!res.ok) throw new Error('Generation failed');
      const data = await res.json();
      // Immutable: Append new key
      setKeys(prev => [...prev, data.key]);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unknown error');
    } finally {
      setLoading(false);
    }
  };

  const revokeKey = async (keyId: string) => {
    setLoading(true);
    try {
      const res = await fetch('/api/keys', {
        method: 'DELETE',
        body: JSON.stringify({ keyId }),
      });
      if (!res.ok) throw new Error('Revocation failed');
      // Immutable: Filter out revoked key
      setKeys(prev => prev.filter(k => k.id !== keyId));
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unknown error');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div>
      <h1>API Key Management</h1>
      {loading && <p>Loading...</p>}
      {error && <p style={{ color: 'red' }}>Error: {error}</p>}
      <button onClick={() => generateKey('test')}>Generate Test Key</button>
      <button onClick={() => generateKey('live')}>Generate Live Key</button>
      <ul>
        {keys.map(key => (
          <li key={key.id}>
            <p>Key: {key.value.substring(0, 10)}... | Env: {key.environment} | Status: {key.status || 'active'}</p>
            <button onClick={() => revokeKey(key.id)}>Revoke</button>
          </li>
        ))}
      </ul>
    </div>
  );
}
