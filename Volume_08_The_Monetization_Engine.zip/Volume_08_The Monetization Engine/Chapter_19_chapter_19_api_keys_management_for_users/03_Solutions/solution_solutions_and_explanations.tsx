/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState } from 'react';

type Environment = 'test' | 'live';

export const ApiKeyGenerator: React.FC = () => {
  const [environment, setEnvironment] = useState<Environment>('test');
  const [generatedKey, setGeneratedKey] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);

  /**
   * SECURITY NOTE:
   * We use local component state (useState) for the generated key instead of a global context or
   * local storage to minimize the attack surface. Storing sensitive keys in global state (like Redux)
   * or persistent storage (localStorage) increases the risk of exposure via Cross-Site Scripting (XSS)
   * attacks. By keeping it ephemeral in local state, the key disappears upon page refresh or
   * component unmount, adhering to the principle of ephemeral secrets.
   */

  const generateKey = (env: Environment): string => {
    const prefix = env === 'live' ? 'sk_live_' : 'sk_test_';
    const randomPart = Math.random().toString(36).substring(2, 18); // Simulating randomness
    
    if (env === 'live') {
      // Enforce strict length for live keys
      return prefix + randomPart + Math.random().toString(36).substring(2, 26);
    }
    
    return prefix + randomPart;
  };

  const handleGenerate = () => {
    const key = generateKey(environment);
    setGeneratedKey(key);
    setCopied(false);
  };

  const handleCopy = () => {
    if (generatedKey) {
      navigator.clipboard.writeText(generatedKey);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  return (
    <div style={{ padding: '20px', border: '1px solid #ccc', borderRadius: '8px', maxWidth: '500px' }}>
      <h3>API Key Generator</h3>
      
      <div style={{ marginBottom: '15px' }}>
        <label>
          <input 
            type="radio" 
            value="test" 
            checked={environment === 'test'} 
            onChange={() => setEnvironment('test')} 
          />{' '}
          Test
        </label>
        <label style={{ marginLeft: '15px' }}>
          <input 
            type="radio" 
            value="live" 
            checked={environment === 'live'} 
            onChange={() => setEnvironment('live')} 
          />{' '}
          Live
        </label>
      </div>

      <div style={{ display: 'flex', gap: '10px', alignItems: 'center' }}>
        <input
          type="text"
          value={generatedKey || ''}
          readOnly
          disabled
          placeholder="Key will appear here..."
          style={{
            flex: 1,
            padding: '8px',
            fontFamily: 'monospace',
            // Visual distinction for Live keys
            color: environment === 'live' ? '#dc2626' : '#000',
            fontWeight: environment === 'live' ? 'bold' : 'normal',
            backgroundColor: '#f9f9f9',
            border: '1px solid #ddd',
          }}
        />
        <button onClick={handleGenerate} style={{ padding: '8px 12px' }}>
          Generate
        </button>
        <button 
          onClick={handleCopy} 
          disabled={!generatedKey}
          style={{ padding: '8px 12px', backgroundColor: copied ? '#d1fae5' : '#e5e7eb' }}
        >
          {copied ? 'Copied!' : 'Copy'}
        </button>
      </div>
      
      {environment === 'live' && (
        <p style={{ color: '#dc2626', fontSize: '0.85rem', marginTop: '8px' }}>
          <strong>Warning:</strong> Live keys have full production access. Handle with extreme care.
        </p>
      )}
    </div>
  );
};
