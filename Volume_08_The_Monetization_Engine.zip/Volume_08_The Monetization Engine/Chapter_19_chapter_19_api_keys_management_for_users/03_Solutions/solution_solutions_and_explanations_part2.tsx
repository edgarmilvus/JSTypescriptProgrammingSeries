/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState } from 'react';

// 1. Define the Interface
interface ApiKey {
  id: string;
  keyPrefix: string;
  lastUsed: string;
  role: 'admin' | 'developer';
  isActive: boolean;
}

interface KeyRevocationDashboardProps {
  userRole: 'admin' | 'developer';
}

export const KeyRevocationDashboard: React.FC<KeyRevocationDashboardProps> = ({ userRole }) => {
  // 2. Mock Data
  const [keys, setKeys] = useState<ApiKey[]>([
    { id: '1', keyPrefix: 'sk_live_', lastUsed: '2023-10-27', role: 'admin', isActive: true },
    { id: '2', keyPrefix: 'sk_test_', lastUsed: '2023-10-26', role: 'developer', isActive: true },
    { id: '3', keyPrefix: 'sk_live_', lastUsed: '2023-10-25', role: 'developer', isActive: true },
  ]);

  // 3. Logic & Immutable State Update
  const handleRevoke = (id: string) => {
    setKeys(prevKeys => 
      prevKeys.map(key => 
        key.id === id ? { ...key, isActive: false } : key
      )
    );
  };

  // Helper to check permissions
  const canRevoke = (keyRole: 'admin' | 'developer'): boolean => {
    // Admins can revoke everything. Developers can only revoke their own keys.
    if (userRole === 'admin') return true;
    if (userRole === 'developer' && keyRole === 'developer') return true;
    return false;
  };

  return (
    <div style={{ padding: '20px', fontFamily: 'sans-serif' }}>
      <h3>Key Management Dashboard ({userRole.toUpperCase()} View)</h3>
      <table style={{ width: '100%', borderCollapse: 'collapse', marginTop: '10px' }}>
        <thead>
          <tr style={{ borderBottom: '2px solid #333', textAlign: 'left' }}>
            <th style={{ padding: '8px' }}>ID</th>
            <th style={{ padding: '8px' }}>Prefix</th>
            <th style={{ padding: '8px' }}>Owner Role</th>
            <th style={{ padding: '8px' }}>Last Used</th>
            <th style={{ padding: '8px' }}>Actions</th>
          </tr>
        </thead>
        <tbody>
          {keys.map(key => {
            const allowed = canRevoke(key.role);
            return (
              <tr key={key.id} style={{ borderBottom: '1px solid #eee' }}>
                <td style={{ padding: '8px' }}>{key.id}</td>
                <td style={{ padding: '8px' }}>{key.keyPrefix}...</td>
                <td style={{ padding: '8px' }}>{key.role}</td>
                <td style={{ padding: '8px' }}>{key.lastUsed}</td>
                <td style={{ padding: '8px' }}>
                  <button
                    onClick={() => handleRevoke(key.id)}
                    disabled={!allowed || !key.isActive}
                    title={!allowed ? "You do not have permission to revoke this key." : undefined}
                    style={{
                      padding: '5px 10px',
                      backgroundColor: !allowed ? '#ccc' : (key.isActive ? '#ef4444' : '#10b981'),
                      color: 'white',
                      border: 'none',
                      borderRadius: '4px',
                      cursor: !allowed ? 'not-allowed' : 'pointer',
                    }}
                  >
                    {key.isActive ? (allowed ? 'Revoke' : 'Locked') : 'Revoked'}
                  </button>
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
};
