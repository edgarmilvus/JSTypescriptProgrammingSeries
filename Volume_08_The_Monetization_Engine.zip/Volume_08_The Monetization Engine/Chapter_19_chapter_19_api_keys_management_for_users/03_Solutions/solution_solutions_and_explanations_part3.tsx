/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState, useEffect, useRef } from 'react';

export const KeyRotationSimulator: React.FC = () => {
  const [currentKey, setCurrentKey] = useState<string>('sk_live_initial123');
  const [status, setStatus] = useState<'idle' | 'rotating' | 'success' | 'error'>('idle');
  const [logs, setLogs] = useState<string[]>([]);
  const [intervalInput, setIntervalInput] = useState<number>(10); // Default 10 seconds
  const intervalRef = useRef<NodeJS.Timeout | null>(null);

  // Helper to append logs
  const addLog = (message: string) => {
    const timestamp = new Date().toLocaleTimeString();
    setLogs(prev => [`[${timestamp}] ${message}`, ...prev]);
  };

  // Core Rotation Logic
  const rotateKey = async () => {
    if (status === 'rotating') return;

    setStatus('rotating');
    addLog('Initiating rotation...');

    // Simulate network delay
    await new Promise(resolve => setTimeout(resolve, 2000));

    try {
      // Simulate key generation
      const newKey = `sk_live_${crypto.randomUUID().replace(/-/g, '')}`;
      setCurrentKey(newKey);
      addLog(`Success: New key generated and activated.`);
      setStatus('success');
    } catch (err) {
      addLog('Error: Rotation failed.');
      setStatus('error');
    } finally {
      // Reset status to idle after a brief moment so button is clickable again
      setTimeout(() => setStatus('idle'), 1000);
    }
  };

  // Interactive Challenge: Auto-rotation timer
  useEffect(() => {
    if (intervalInput > 0) {
      // Cleanup previous timer
      if (intervalRef.current) clearInterval(intervalRef.current);

      // Set new timer
      intervalRef.current = setInterval(() => {
        rotateKey();
      }, intervalInput * 1000);

      return () => {
        if (intervalRef.current) clearInterval(intervalRef.current);
      };
    }
  }, [intervalInput]); // Re-run when interval changes

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current);
    };
  }, []);

  return (
    <div style={{ padding: '20px', border: '1px solid #ddd', borderRadius: '8px', maxWidth: '600px' }}>
      <h3>Key Rotation Simulator</h3>
      
      <div style={{ marginBottom: '15px', padding: '10px', backgroundColor: '#f0f9ff', borderRadius: '4px' }}>
        <strong>Current Key:</strong> <code>{currentKey}</code>
      </div>

      <div style={{ marginBottom: '15px' }}>
        <label>
          Rotation Interval (seconds):{' '}
          <input 
            type="number" 
            value={intervalInput} 
            onChange={(e) => setIntervalInput(Number(e.target.value))}
            style={{ width: '60px', marginRight: '10px' }}
          />
        </label>
        <small style={{ color: '#666' }}>(Set to 0 to disable auto-rotation)</small>
      </div>

      <button 
        onClick={rotateKey} 
        disabled={status === 'rotating'}
        style={{ 
          padding: '8px 16px', 
          backgroundColor: status === 'rotating' ? '#ccc' : '#3b82f6', 
          color: 'white',
          border: 'none',
          borderRadius: '4px',
          cursor: status === 'rotating' ? 'wait' : 'pointer'
        }}
      >
        {status === 'rotating' ? 'Rotating...' : 'Rotate Now'}
      </button>

      <div style={{ marginTop: '20px' }}>
        <h4>Rotation Logs:</h4>
        <div style={{ 
          height: '200px', 
          overflowY: 'auto', 
          border: '1px solid #eee', 
          padding: '10px', 
          fontFamily: 'monospace', 
          backgroundColor: '#fafafa' 
        }}>
          {logs.length === 0 ? <em>No logs yet.</em> : (
            <ul style={{ paddingLeft: '20px', margin: 0 }}>
              {logs.map((log, idx) => <li key={idx} style={{ marginBottom: '4px' }}>{log}</li>)}
            </ul>
          )}
        </div>
      </div>
    </div>
  );
};
