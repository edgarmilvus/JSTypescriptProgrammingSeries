/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

// 1. Define the Interface
interface ISecretsManager {
  storeKey(key: string, environment: 'test' | 'live'): Promise<string>;
  getKey(id: string): Promise<string | null>;
  revokeKey(id: string): Promise<boolean>;
  logAccess(id: string, action: 'read' | 'write' | 'revoke'): Promise<void>;
}

// 2. Mock Implementation
class InMemorySecretsManager implements ISecretsManager {
  // Internal database simulation
  private db = new Map<string, { 
    key: string; 
    environment: 'test' | 'live'; 
    revoked: boolean 
  }>();

  private generateId(): string {
    return Math.random().toString(36).substring(2, 15);
  }

  // Store a new key
  async storeKey(key: string, environment: 'test' | 'live'): Promise<string> {
    const id = this.generateId();
    this.db.set(id, { key, environment, revoked: false });
    
    // Log the write action
    await this.logAccess(id, 'write');
    
    return id;
  }

  // Retrieve a key (only if not revoked)
  async getKey(id: string): Promise<string | null> {
    const record = this.db.get(id);
    
    if (!record || record.revoked) {
      return null;
    }

    // Log the read action
    await this.logAccess(id, 'read');
    
    return record.key;
  }

  // Revoke a key
  async revokeKey(id: string): Promise<boolean> {
    const record = this.db.get(id);
    
    if (!record) {
      return false;
    }

    record.revoked = true;
    this.db.set(id, record);

    // Log the revoke action
    await this.logAccess(id, 'revoke');
    
    return true;
  }

  // Logging mechanism (Console output for mock)
  async logAccess(id: string, action: 'read' | 'write' | 'revoke'): Promise<void> {
    const timestamp = new Date().toISOString();
    console.log(`[AUDIT LOG] ${timestamp} | ID: ${id} | Action: ${action.toUpperCase()}`);
  }
}

// 3. Usage Example
export async function exampleUsage() {
  const manager = new InMemorySecretsManager();

  console.log("--- Starting Secrets Manager Example ---");

  // Storing a key
  console.log("1. Storing key...");
  const keyId = await manager.storeKey("sk_live_abc123secret", "live");
  console.log(`   Stored Key ID: ${keyId}`);

  // Retrieving it (logs access)
  console.log("2. Retrieving key...");
  const retrievedKey = await manager.getKey(keyId);
  console.log(`   Retrieved: ${retrievedKey}`);

  // Revoking it
  console.log("3. Revoking key...");
  const revoked = await manager.revokeKey(keyId);
  console.log(`   Revoked: ${revoked}`);

  // Attempting to retrieve again
  console.log("4. Retrieving revoked key...");
  const revokedKey = await manager.getKey(keyId);
  console.log(`   Retrieved: ${revokedKey} (Should be null)`);
  
  console.log("--- Example Complete ---");
}

// To run this in a Node environment, uncomment below:
// exampleUsage();
