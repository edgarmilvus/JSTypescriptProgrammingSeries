/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState, useEffect } from 'react';

// 1. Data Structure
interface UsageEvent {
  keyId: string;
  timestamp: number; // Unix timestamp in ms
  requestCount: number;
  environment: 'test' | 'live';
}

// Mock function for invalidation
const invalidateKey = (keyId: string) => {
  console.log(`Action: Invalidated key ${keyId} due to anomaly.`);
  alert(`Key ${keyId} has been invalidated.`);
};

export const UsageAnomalyMonitor: React.FC = () => {
  const [events, setEvents] = useState<UsageEvent[]>([]);
  const [alerts, setAlerts] = useState<string[]>([]);

  // 2. Anomaly Detection Logic
  const detectAnomalies = (currentEvents: UsageEvent[]) => {
    const newAlerts: string[] = [];

    // Heuristic 1: High Frequency Attack (Simulated window check)
    // Group by keyId and check if sum of requests in recent 5 seconds > 10
    const now = Date.now();
    const windowStart = now - 5000; // 5 seconds ago

    const keyCounts: { [keyId: string]: number } = {};
    
    currentEvents.forEach(event => {
      if (event.timestamp >= windowStart) {
        keyCounts[event.keyId] = (keyCounts[event.keyId] || 0) + event.requestCount;
      }
    });

    Object.entries(keyCounts).forEach(([keyId, count]) => {
      if (count > 10) {
        newAlerts.push(`High Frequency Attack detected on Key ${keyId}: ${count} requests in 5s.`);
      }
    });

    // Heuristic 2: Environment Policy Violation
    // Check if a key typically used in 'test' appears in 'live' logs
    const keyEnvironments: { [keyId: string]: Set<'test' | 'live'> } = {};
    currentEvents.forEach(event => {
      if (!keyEnvironments[event.keyId]) keyEnvironments[event.keyId] = new Set();
      keyEnvironments[event.keyId].add(event.environment);
    });

    Object.entries(keyEnvironments).forEach(([keyId, envs]) => {
      if (envs.has('test') && envs.has('live')) {
        newAlerts.push(`Environment Policy Violation: Key ${keyId} used in both Test and Live.`);
      }
    });

    return newAlerts;
  };

  // Update alerts whenever events change
  useEffect(() => {
    const detected = detectAnomalies(events);
    // Only update if there are new unique alerts
    if (detected.length > 0) {
      setAlerts(prev => [...new Set([...prev, ...detected])]);
    }
  }, [events]);

  // Simulation: Add random events every 2 seconds
  useEffect(() => {
    const interval = setInterval(() => {
      const randomKey = `key_${Math.floor(Math.random() * 3)}`;
      const isSpike = Math.random() > 0.8; // 20% chance of spike
      
      const newEvent: UsageEvent = {
        keyId: randomKey,
        timestamp: Date.now(),
        requestCount: isSpike ? 12 : Math.floor(Math.random() * 3) + 1,
        environment: Math.random() > 0.9 ? 'live' : 'test', // 10% chance of live usage
      };

      setEvents(prev => [...prev, newEvent].slice(-50)); // Keep last 50 events
    }, 2000);

    return () => clearInterval(interval);
  }, []);

  // 3. Visualization Helper (CSS Bar Chart)
  const renderChart = () => {
    const counts: { [keyId: string]: number } = {};
    events.forEach(e => {
      counts[e.keyId] = (counts[e.keyId] || 0) + e.requestCount;
    });

    const max = Math.max(...Object.values(counts), 1);

    return (
      <div style={{ display: 'flex', alignItems: 'flex-end', height: '100px', gap: '10px', marginTop: '10px' }}>
        {Object.entries(counts).map(([keyId, count]) => (
          <div key={keyId} style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', width: '40px' }}>
            <div 
              style={{ 
                width: '100%', 
                height: `${(count / max) * 80}px`, 
                backgroundColor: '#3b82f6', 
                borderRadius: '2px 2px 0 0' 
              }} 
              title={`${keyId}: ${count} requests`}
            ></div>
            <span style={{ fontSize: '10px', marginTop: '4px' }}>{keyId}</span>
          </div>
        ))}
      </div>
    );
  };

  return (
    <div style={{ padding: '20px', display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '20px' }}>
      {/* Left Panel: Visualization & Logs */}
      <div>
        <h3>Live Usage Monitor</h3>
        <div style={{ border: '1px solid #ddd', padding: '10px', borderRadius: '4px' }}>
          <h4>Request Volume (CSS Chart)</h4>
          {renderChart()}
        </div>
        
        <div style={{ marginTop: '20px' }}>
          <h4>Recent Events</h4>
          <div style={{ height: '150px', overflowY: 'auto', border: '1px solid #eee', padding: '5px', fontSize: '12px' }}>
            {events.slice().reverse().map((e, i) => (
              <div key={i} style={{ borderBottom: '1px solid #f0f0f0', padding: '2px' }}>
                {new Date(e.timestamp).toLocaleTimeString()} - {e.keyId}: {e.requestCount} reqs ({e.environment})
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Right Panel: Alerts & Actions */}
      <div>
        <h3>Security Alerts</h3>
        <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
          {alerts.length === 0 ? (
            <div style={{ color: 'green', padding: '10px', border: '1px solid green', borderRadius: '4px' }}>
              No anomalies detected.
            </div>
          ) : (
            alerts.map((alert, idx) => (
              <div key={idx} style={{ 
                padding: '10px', 
                border: '1px solid #ef4444', 
                backgroundColor: '#fef2f2', 
                borderRadius: '4px',
                display: 'flex',
                justifyContent: 'space-between',
                alignItems: 'center'
              }}>
                <span style={{ fontSize: '12px', color: '#991b1b' }}>{alert}</span>
                <button 
                  onClick={() => {
                    // Extract keyId from alert string for demo purposes
                    const match = alert.match(/Key (key_\d+)/);
                    if (match) invalidateKey(match[1]);
                  }}
                  style={{ padding: '4px 8px', backgroundColor: '#ef4444', color: 'white', border: 'none', borderRadius: '4px', cursor: 'pointer' }}
                >
                  Invalidate
                </button>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
