/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: theory_theoretical_foundations.ts
// Description: Theoretical Foundations
// ==========================================

// Represents the shared state for a single billing workflow or inquiry
interface GraphState {
    // Core identifiers
    userId: string;
    stripeCustomerId: string;
    workflowId: string;

    // Current billing status (the state machine's current state)
    billingStatus: 'active' | 'payment_due' | 'payment_failed' | 'dunning' | 'suspended';

    // Contextual data
    recentUsage: Array<{ metric: string; value: number; timestamp: number }>;
    outstandingInvoices: Array<{ id: string; amount: number; status: string }>;
    lastPaymentError?: string;

    // The incoming trigger (e.g., a webhook from Stripe or a customer email)
    trigger: {
        type: 'stripe_event' | 'customer_query';
        payload: any; // The raw webhook payload or the customer's message
    };

    // The final decision made by the Supervisor (for audit trails)
    supervisorDecision?: {
        nextAgent: 'dunning_agent' | 'inquiry_agent' | 'anomaly_agent' | 'human_escalation';
        reasoning: string; // The LLM's justification for the decision
        timestamp: number;
    };
}
