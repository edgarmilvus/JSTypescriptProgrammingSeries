/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

// supervisor-node-billing.ts
import { StateGraph, Annotation, END, START } from "@langchain/langgraph";
import { z } from "zod";

// 1. Define the State Schema
// We use Zod for runtime type validation, ensuring the graph state is always predictable.
const BillingState = z.object({
  customerId: z.string(),
  usageMetric: z.number().min(0),
  billingStatus: z.enum(["active", "past_due", "inactive"]).optional(),
  finalBill: z.number().optional(),
});

type BillingState = z.infer<typeof BillingState>;

// 2. Define the Supervisor's Tools (Worker Agents)
// In a real system, these would be API calls to Stripe or a database.
// Here, we mock them as async functions.

/**
 * Checks the customer's billing status in the database.
 * @param state - The current graph state containing the customerId.
 * @returns - A partial state update with the billing status.
 */
async function checkBillingStatus(state: BillingState): Promise<Partial<BillingState>> {
  console.log(`[Supervisor] Checking status for customer: ${state.customerId}`);
  
  // Simulate database latency
  await new Promise(resolve => setTimeout(resolve, 100));

  // Mock logic: 'user_123' is active, others are past_due
  const status = state.customerId === "user_123" ? "active" : "past_due";
  
  return { billingStatus: status };
}

/**
 * Calculates the cost based on usage and logs the meter.
 * This worker only runs if the billing status is 'active'.
 * @param state - The current graph state.
 * @returns - The final calculated bill.
 */
async function calculateAndLogUsage(state: BillingState): Promise<Partial<BillingState>> {
  console.log(`[Supervisor] Calculating usage for metric: ${state.usageMetric}`);
  
  // Simple pricing model: $0.01 per unit
  const cost = state.usageMetric * 0.01;
  
  return { finalBill: cost };
}

/**
 * Handles failed payments or inactive accounts.
 * In a real system, this might trigger a Smart Dunning workflow.
 * @param state - The current graph state.
 * @returns - An error state.
 */
async function handleFailedPayment(state: BillingState): Promise<Partial<BillingState>> {
  console.error(`[Supervisor] Payment failed or inactive for customer: ${state.customerId}`);
  
  // In a real app, we might throw an error or trigger a retry logic here.
  throw new Error(`Billing check failed for ${state.customerId}. Status: ${state.billingStatus}`);
}

// 3. Define the Routing Logic (The "Brain" of the Supervisor)
// This function analyzes the state and decides which worker to invoke next.
// It uses a simple conditional logic, but in production, this is often an LLM call.
function router(state: BillingState): string {
  if (!state.billingStatus) {
    return "check_status";
  }

  if (state.billingStatus === "active") {
    return "calculate_usage";
  }

  return "handle_failure";
}

// 4. Build the Graph
// We construct the workflow using LangGraph's StateGraph API.
const workflow = new StateGraph(BillingState)
  // Define nodes (agents/workers)
  .addNode("check_status", checkBillingStatus)
  .addNode("calculate_usage", calculateAndLogUsage)
  .addNode("handle_failure", handleFailedPayment)
  
  // Define the entry point
  .addEdge(START, "check_status")
  
  // Define conditional edges (The Supervisor's Routing Logic)
  .addConditionalEdges("check_status", router, {
    "calculate_usage": "calculate_usage",
    "handle_failure": "handle_failure",
    "check_status": "check_status", // Fallback, though unlikely in this logic
  })
  
  // End the graph after calculation or failure
  .addEdge("calculate_usage", END)
  .addEdge("handle_failure", END);

// 5. Compile the Graph
// This creates the executable agent.
const app = workflow.compile();

// 6. Execution Function
// This simulates an API endpoint (e.g., AWS Lambda) receiving a usage event.
async function main() {
  console.log("--- Starting Usage-Based Billing System ---");
  
  // Simulated incoming event from a serverless trigger
  const initialInput: Partial<BillingState> = {
    customerId: "user_123", // Try changing this to "user_999" to see failure logic
    usageMetric: 1000, // 1000 API calls
  };

  try {
    // Execute the graph
    const result = await app.invoke(initialInput);
    
    console.log("\n--- Final Result ---");
    console.log(JSON.stringify(result, null, 2));
  } catch (error) {
    console.error("\n--- Workflow Error ---");
    console.error(error);
  }
}

// Run the example
main();
