/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// pages/api/track-usage.ts
// Next.js API Route for Usage-Based Billing
// ---------------------------------------------------------
// Dependencies: stripe (npm install stripe @types/stripe)
// Environment Variables: STRIPE_SECRET_KEY

import { NextApiRequest, NextApiResponse } from 'next';
import Stripe from 'stripe';

// Initialize Stripe with strict typing
const stripe = new Stripe(process.env.STRIPE_SECRET_KEY as string, {
  apiVersion: '2023-10-16', // Ensure compatibility with your Stripe version
});

// ---------------------------------------------------------
// TYPE DEFINITIONS
// ---------------------------------------------------------

/**
 * Represents the incoming payload from the client application.
 * In a real scenario, this might come from a WebSocket or a background job queue.
 */
interface UsagePayload {
  customerId: string;       // The Stripe Customer ID
  metricName: string;       // e.g., 'api_requests', 'storage_gb', 'seats'
  quantity: number;         // The raw usage value
  timestamp: number;        // Unix timestamp
}

/**
 * Represents the calculated billing details before invoicing.
 */
interface BillingDetails {
  amount: number;           // Total amount in cents
  currency: string;
  description: string;
}

// ---------------------------------------------------------
// UTILITY FUNCTIONS
// ---------------------------------------------------------

/**
 * Calculates the cost based on the usage metric.
 * In a production system, this would query a pricing database or configuration.
 * 
 * @param metric - The name of the metric being tracked.
 * @param quantity - The amount consumed.
 * @returns The calculated amount in cents (integer).
 */
const calculateCost = (metric: string, quantity: number): number => {
  const PRICING_TABLE: Record<string, number> = {
    'api_requests': 0.01,   // $0.01 per request
    'storage_gb': 0.10,     // $0.10 per GB
    'seats': 5.00,          // $5.00 per seat
  };

  const rate = PRICING_TABLE[metric];
  if (!rate) throw new Error(`Unknown metric: ${metric}`);
  
  // Return amount in cents to avoid floating point issues
  return Math.ceil(quantity * rate * 100);
};

// ---------------------------------------------------------
// CORE LOGIC: THE MONETIZATION ENGINE
// ---------------------------------------------------------

/**
 * Main API Handler.
 * 1. Receives usage data (Non-blocking I/O).
 * 2. Calculates cost.
 * 3. Creates a Stripe Invoice.
 * 4. Attempts payment collection.
 * 5. Implements Exhaustive Asynchronous Resilience.
 */
export default async function handler(
  req: NextApiRequest, 
  res: NextApiResponse
) {
  // -------------------------------------------------------
  // 1. REQUEST VALIDATION (Guard Clauses)
  // -------------------------------------------------------
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method Not Allowed' });
  }

  const payload: UsagePayload = req.body;

  // Validate input structure
  if (!payload.customerId || !payload.metricName || !payload.quantity) {
    return res.status(400).json({ error: 'Invalid usage payload' });
  }

  // -------------------------------------------------------
  // 2. BILLING CALCULATION & INVOICE CREATION
  // -------------------------------------------------------
  try {
    // Calculate cost based on the usage metric
    const amount = calculateCost(payload.metricName, payload.quantity);
    
    const billingDetails: BillingDetails = {
      amount: amount,
      currency: 'usd',
      description: `Usage: ${payload.metricName} (${payload.quantity})`,
    };

    // Create an Invoice Item
    // In a real usage-based system, you might aggregate items into a single invoice at the end of the billing cycle.
    // For this capstone, we create a "Pay-as-you-go" invoice immediately.
    const invoiceItem = await stripe.invoiceItems.create({
      customer: payload.customerId,
      amount: billingDetails.amount,
      currency: billingDetails.currency,
      description: billingDetails.description,
    });

    // Create the Invoice
    const invoice = await stripe.invoices.create({
      customer: payload.customerId,
      auto_advance: true, // Allows Stripe to automatically retry if payment fails
      collection_method: 'charge_automatically',
      metadata: {
        usage_id: `${payload.metricName}_${payload.timestamp}`,
      },
    });

    // Finalize the invoice to trigger the charge
    const finalizedInvoice = await stripe.invoices.finalizeInvoice(invoice.id);

    // -------------------------------------------------------
    // 3. SMART DUNNING HANDLING (Resilience Layer)
    // -------------------------------------------------------
    // Check the payment intent status to see if the charge succeeded immediately
    if (finalizedInvoice.status === 'paid') {
      return res.status(200).json({
        success: true,
        message: 'Usage tracked and payment successful.',
        invoiceId: finalizedInvoice.id,
        amount: billingDetails.amount,
      });
    } 
    
    // Handle Payment Failure (The "Smart Dunning" entry point)
    if (finalizedInvoice.status === 'open' && finalizedInvoice.next_payment_attempt) {
      // Stripe's 'auto_advance' handles the retry logic.
      // We log this event and notify the user asynchronously.
      console.warn(`Payment pending for Invoice ${finalizedInvoice.id}. Smart Dunning scheduled.`);
      
      return res.status(202).json({
        success: true,
        message: 'Usage tracked. Payment failed but Smart Dunning is active.',
        invoiceId: finalizedInvoice.id,
        nextRetry: new Date(finalizedInvoice.next_payment_attempt * 1000).toISOString(),
        action: 'User notification sent (Email/SMS)',
      });
    }

    // Handle unexpected statuses
    return res.status(400).json({
      error: 'Unexpected invoice status',
      status: finalizedInvoice.status,
    });

  } catch (error: any) {
    // -------------------------------------------------------
    // 4. EXHAUSTIVE ASYNCHRONOUS RESILIENCE (Error Handling)
    // -------------------------------------------------------
    
    // Log the error for monitoring (e.g., Sentry, CloudWatch)
    console.error('Billing Engine Error:', error);

    // Handle Stripe specific errors
    if (error instanceof Stripe.errors.StripeError) {
      return res.status(500).json({
        error: 'Payment Gateway Error',
        message: error.message,
        code: error.code,
      });
    }

    // Generic Error Fallback
    return res.status(500).json({
      error: 'Internal Server Error',
      message: 'An unexpected error occurred during billing calculation.',
    });
  }
}
