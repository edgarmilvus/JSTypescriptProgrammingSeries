/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

import express, { Request, Response } from 'express';
import { z } from 'zod';

// 1. Define the Event Schema using Zod
const UsageEventSchema = z.object({
  eventId: z.string().uuid(),
  customerId: z.string(),
  resourceId: z.string(),
  metricType: z.enum(['api_call', 'storage_mb', 'compute_seconds']),
  quantity: z.number().positive(),
  timestamp: z.number().int().positive(),
});

// Define the TypeScript type inferred from the schema
type UsageEvent = z.infer<typeof UsageEventSchema>;

// Mock Message Queue (In-memory array for simulation)
const messageQueue: UsageEvent[] = [];

const app = express();
app.use(express.json());

// 2. Non-Blocking Route Handler
app.post('/usage', async (req: Request, res: Response) => {
  // Parse and validate input
  const result = UsageEventSchema.safeParse(req.body);

  // 3. Immediate Error Handling (Bad Request)
  if (!result.success) {
    console.error('Validation failed:', result.error.errors);
    return res.status(400).json({ error: 'Invalid usage event schema' });
  }

  const event = result.data;

  // 4. Asynchronous Processing (Simulated)
  // We use setImmediate or a Promise to push processing to the next tick of the event loop.
  // This allows the HTTP response to be sent immediately.
  setImmediate(() => {
    try {
      // Simulate heavy processing or network latency
      setTimeout(() => {
        // Forward to simulated queue
        messageQueue.push(event);
        console.log(`Event ${event.eventId} queued successfully.`);
      }, 100); // Simulate 100ms processing time
    } catch (error) {
      // 5. Resilient Error Handling (Log only, do not crash)
      console.error('Error processing event in background:', error);
    }
  });

  // 6. Immediate Acknowledgement (HTTP 202 Accepted)
  // This executes before the setTimeout callback finishes.
  return res.status(202).json({ 
    status: 'Accepted', 
    message: 'Event received and is being processed.' 
  });
});

// Start server (mocking for the exercise context)
// app.listen(3000, () => console.log('Ingestion service running on port 3000'));
