/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

// 1. Type Definitions
interface AgentPrompt {
  role: string;
  instruction: string;
  context?: string;
}

interface SupervisorDecision {
  finalVerdict: 'Approve' | 'Reject' | 'Escalate';
  reasoning: string;
  customerResponse: string;
}

// 2. Worker Agent 1: BillingAnalyst
const billingAnalystPrompt: AgentPrompt = {
  role: "Billing Analyst",
  instruction: "Analyze the provided usage logs and Stripe subscription history. Compare the timestamp of the customer's plan downgrade request against the exact timestamp of the renewal billing charge. Determine if the downgrade occurred strictly before the renewal charge was processed.",
  context: "Customer ID: 12345. Dispute: $500 charge for 'Enterprise Plan'. Claim: Downgraded to 'Starter Plan' 2 days prior."
};

// 3. Worker Agent 2: PolicyExpert
const policyExpertPrompt: AgentPrompt = {
  role: "Policy Expert",
  instruction: "Review the company's refund policy. Check if a refund is warranted based on the following criteria: 'Refunds allowed within 24 hours of renewal if usage is below 10% of plan limit'. If the usage exceeds 10%, no refund is allowed regardless of timing.",
  context: "Current usage for the billing cycle: 5% of Enterprise Plan limits."
};

// 4. Supervisor Node
const supervisorPrompt: AgentPrompt = {
  role: "Supervisor / Consensus Builder",
  instruction: `
    You are synthesizing reports from two worker agents: BillingAnalyst and PolicyExpert.
    
    1. Compare the BillingAnalyst's timestamp verification against the PolicyExpert's rule set.
    2. If the downgrade happened BEFORE renewal AND usage is < 10%, the refund is APPROVED.
    3. If either condition fails, the refund is REJECTED.
    4. If the data is contradictory or incomplete, ESCALATE to a human.
    
    Output a JSON object containing the final verdict, a brief reasoning, and a polite customer response explaining the decision.
  `,
  context: "Worker outputs will be injected here dynamically."
};

// Example usage structure (Simulation)
const simulateConsensus = (analystData: string, policyData: string): SupervisorDecision => {
  // In a real scenario, this would call an LLM API with these prompts concatenated.
  // Logic simulation:
  const downgradeBeforeRenewal = analystData.includes("downgrade processed before billing");
  const usageUnderLimit = policyData.includes("usage is 5%");

  if (downgradeBeforeRenewal && usageUnderLimit) {
    return {
      finalVerdict: "Approve",
      reasoning: "Downgrade timestamp precedes billing timestamp, and usage is within the refundable window.",
      customerResponse: "We have reviewed your account and confirmed the downgrade occurred before renewal. Your refund of $500 has been approved."
    };
  } else {
    return {
      finalVerdict: "Reject",
      reasoning: "Criteria for refund not met based on timing or usage limits.",
      customerResponse: "After reviewing your request against our policy, we are unable to issue a refund as the usage limits exceeded the threshold for plan changes."
    };
  }
};
