/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState, useEffect } from 'react';

// 1. Types
interface UsageEvent {
  eventId: string;
  customerId: string;
  resourceId: string;
  metricType: 'api_call' | 'storage_mb' | 'compute_seconds';
  quantity: number;
  timestamp: number;
}

const PRICING_MAP = {
  api_call: 0.01,
  storage_mb: 0.005,
  compute_seconds: 0.10
};

// 2. Component
const LiveUsageMonitor: React.FC = () => {
  const [events, setEvents] = useState<UsageEvent[]>([]);
  const [totalSpend, setTotalSpend] = useState<number>(0);
  const [connectionStatus, setConnectionStatus] = useState<string>('Disconnected');

  useEffect(() => {
    // 3. WebSocket Connection
    const ws = new WebSocket('ws://localhost:8080/usage');

    // Connection Open
    ws.onopen = () => {
      setConnectionStatus('Connected');
      console.log('WebSocket Connected');
    };

    // Message Handler
    ws.onmessage = (event) => {
      try {
        const newEvent: UsageEvent = JSON.parse(event.data);
        
        // Update Events List (Keep last 10)
        setEvents((prev) => {
          const updated = [...prev, newEvent];
          return updated.slice(-10); 
        });

        // Calculate Cost for this event
        const cost = newEvent.quantity * PRICING_MAP[newEvent.metricType];

        // Update Total Spend
        setTotalSpend((prevTotal) => prevTotal + cost);
        
      } catch (error) {
        console.error('Error parsing WebSocket message:', error);
      }
    };

    // Error Handling
    ws.onerror = (err) => {
      setConnectionStatus('Error');
      console.error('WebSocket Error:', err);
    };

    // 4. Cleanup on Unmount
    return () => {
      if (ws.readyState === WebSocket.OPEN) {
        ws.close();
      }
    };
  }, []); // Empty dependency array ensures this runs once on mount

  return (
    <div style={{ padding: '20px', fontFamily: 'Arial, sans-serif' }}>
      <h2>Live Usage Monitor</h2>
      <p>Status: <strong>{connectionStatus}</strong></p>

      {/* 5. Rendering: Prominent Total Spend */}
      <div style={{
        backgroundColor: '#f0f4f8',
        border: '1px solid #ccc',
        borderRadius: '8px',
        padding: '20px',
        marginBottom: '20px',
        textAlign: 'center'
      }}>
        <h3>Current Monthly Spend</h3>
        <div style={{ fontSize: '2.5rem', fontWeight: 'bold', color: '#2c3e50' }}>
          ${totalSpend.toFixed(2)}
        </div>
      </div>

      {/* Rendering: List of Last 10 Events */}
      <h4>Recent Events</h4>
      <ul style={{ listStyle: 'none', padding: 0 }}>
        {events.slice().reverse().map((evt) => (
          <li key={evt.eventId} style={{
            borderBottom: '1px solid #eee',
            padding: '8px 0',
            display: 'flex',
            justifyContent: 'space-between'
          }}>
            <span>{evt.metricType.replace('_', ' ').toUpperCase()}</span>
            <span>Qty: {evt.quantity}</span>
            <span>${(evt.quantity * PRICING_MAP[evt.metricType]).toFixed(4)}</span>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default LiveUsageMonitor;
