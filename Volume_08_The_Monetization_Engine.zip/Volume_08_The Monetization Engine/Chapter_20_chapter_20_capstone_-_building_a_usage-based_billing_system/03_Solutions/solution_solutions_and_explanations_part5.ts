/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

// 1. Interfaces
interface UsageEvent {
  eventId: string;
  metricType: 'api_call' | 'storage_mb' | 'compute_seconds';
  quantity: number;
}

interface InvoiceResult {
  totalAmount: number;
  currency: string;
  breakdown: {
    api_call: number;
    storage_mb: number;
    compute_seconds: number;
  };
}

// 2. Lambda Handler
export const calculateInvoice = (events: UsageEvent[]): InvoiceResult => {
  // 3. Idempotency: Use a Set to track processed Event IDs
  const processedIds = new Set<string>();
  
  // Initialize totals
  let totalAmount = 0;
  const breakdown = {
    api_call: 0,
    storage_mb: 0,
    compute_seconds: 0,
  };

  // 4. Tiered Pricing Logic
  // Helper for API Calls
  const calculateApiCost = (quantity: number): number => {
    if (quantity <= 1000) return 0;
    if (quantity <= 10000) return (quantity - 1000) * 0.01;
    return (9000 * 0.01) + (quantity - 10000) * 0.005;
  };

  // Process events
  for (const event of events) {
    // Deduplication check
    if (processedIds.has(event.eventId)) {
      console.log(`Skipping duplicate event: ${event.eventId}`);
      continue;
    }
    processedIds.add(event.eventId);

    let cost = 0;

    switch (event.metricType) {
      case 'api_call':
        cost = calculateApiCost(event.quantity);
        break;
      case 'storage_mb':
        // Flat rate
        cost = event.quantity * 0.005;
        break;
      case 'compute_seconds':
        // Flat rate
        cost = event.quantity * 0.10;
        break;
    }

    // Accumulate
    totalAmount += cost;
    breakdown[event.metricType] += cost;
  }

  // 5. Return Structured Result
  return {
    totalAmount: parseFloat(totalAmount.toFixed(4)), // Avoid floating point errors
    currency: 'USD',
    breakdown,
  };
};

// --- Example Usage / Test Data ---
/*
const mockEvents: UsageEvent[] = [
  { eventId: 'evt-1', metricType: 'api_call', quantity: 1500 }, // Cost: (500 * 0.01) = $5
  { eventId: 'evt-1', metricType: 'api_call', quantity: 1500 }, // Duplicate (Idempotency test) - Should be skipped
  { eventId: 'evt-2', metricType: 'storage_mb', quantity: 200 }, // Cost: 200 * 0.005 = $1
  { eventId: 'evt-3', metricType: 'api_call', quantity: 12000 }, // Cost: (9000*0.01) + (2000*0.005) = $90 + $10 = $100
];

console.log(calculateInvoice(mockEvents));
// Expected Output: { totalAmount: 106, currency: 'USD', breakdown: { api_call: 105, storage_mb: 1, compute_seconds: 0 } }
*/
