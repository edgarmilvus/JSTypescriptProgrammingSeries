/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: theory_theoretical_foundations.ts
// Description: Theoretical Foundations
// ==========================================

// app/blog/[slug]/page.tsx

// This function runs on the server *before* the page is rendered.
// It fetches the specific article data and returns a metadata object.
export async function generateMetadata({ params }: { params: { slug: string } }): Promise<Metadata> {
  // Fetch data for this specific slug. This could be from a database,
  // a headless CMS, or even a call to an AI model to generate a summary.
  const article = await fetchArticleFromDatabase(params.slug);

  // If the article doesn't exist, we can return undefined or throw an error.
  if (!article) {
    return {
      title: 'Article Not Found',
    };
  }

  // The metadata is now a direct function of the dynamic data.
  return {
    title: article.title,
    description: article.summary,
    openGraph: {
      title: article.title,
      description: article.summary,
      images: [
        // We will generate this image dynamically in the next section
        `/api/og?title=${encodeURIComponent(article.title)}`,
      ],
    },
    twitter: {
      card: 'summary_large_image',
      title: article.title,
      description: article.summary,
      images: [`/api/og?title=${encodeURIComponent(article.title)}`],
    },
  };
}

// The page component itself is now free to focus solely on rendering the UI.
export default function BlogPostPage({ params }: { params: { slug: string } }) {
  // ... component logic to render the article content
  return <div>{/* ... */}</div>;
}
