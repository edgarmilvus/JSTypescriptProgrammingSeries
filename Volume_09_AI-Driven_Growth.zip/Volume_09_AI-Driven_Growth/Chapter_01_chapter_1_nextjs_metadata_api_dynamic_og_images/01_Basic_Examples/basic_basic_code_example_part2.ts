/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.ts
// Description: Basic Code Example
// ==========================================

// File: app/api/og/route.ts

import { ImageResponse } from '@vercel/og';
import { NextRequest } from 'next/server';

/**
 * Route Handler: GET /api/og
 * 
 * Generates a dynamic Open Graph image based on the 'title' query parameter.
 * 
 * @param {NextRequest} req - The incoming HTTP request object.
 * @returns {Promise<ImageResponse>} A PNG image response.
 */
export async function GET(req: NextRequest) {
  try {
    // 1. Extract query parameters from the request URL
    const { searchParams } = new URL(req.url);
    
    // 2. Get the 'title' parameter, defaulting to 'Hello World' if missing
    const title = searchParams.get('title') ?? 'Hello World';

    // 3. Define the font data (fetching a standard font for the image)
    // Note: In a real app, you might fetch a font file from your /public directory
    // or a CDN. Here we use a standard system font fallback logic for simplicity.
    const fontData = await fetch(
      new URL('@vercel/og/dist/font.ttf', import.meta.url)
    ).then((res) => res.arrayBuffer());

    // 4. Define the React component to render inside the image
    // This uses Tailwind-like utility classes for styling.
    const component = (
      <div
        style={{
          height: '100%',
          width: '100%',
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          justifyContent: 'center',
          backgroundColor: '#fff',
          fontFamily: 'Inter',
        }}
      >
        <div
          style={{
            border: '4px solid #0070f3',
            borderRadius: '8px',
            padding: '20px 40px',
            fontSize: '60px',
            fontWeight: 'bold',
            color: '#0070f3',
            textAlign: 'center',
            backgroundColor: '#f0f7ff',
          }}
        >
          {title}
        </div>
        <div
          style={{
            marginTop: '20px',
            fontSize: '24px',
            color: '#666',
          }}
        >
          Powered by Next.js & Vercel OG
        </div>
      </div>
    );

    // 5. Return the ImageResponse
    // This automatically handles the conversion of the React component to a PNG.
    return new ImageResponse(component, {
      width: 1200,
      height: 630,
      fonts: [
        {
          name: 'Inter',
          data: fontData,
          style: 'normal',
          weight: 400,
        },
      ],
    });

  } catch (error) {
    // 6. Basic error handling
    console.error('Error generating OG image:', error);
    return new Response('Failed to generate image', { status: 500 });
  }
}
