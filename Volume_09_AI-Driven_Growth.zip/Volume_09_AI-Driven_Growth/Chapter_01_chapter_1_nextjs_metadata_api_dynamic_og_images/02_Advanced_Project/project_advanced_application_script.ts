/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// File: app/api/og/[userId]/route.ts
import { ImageResponse } from '@vercel/og';
import { NextRequest } from 'next/server';

// Export the runtime to use Edge functions for optimal performance
export const runtime = 'edge';

/**
 * Handles the GET request for dynamic OG image generation.
 * 
 * @param {NextRequest} req - The incoming HTTP request object.
 * @param {{ params: { userId: string } }} context - The route parameters containing the userId.
 * @returns {Promise<ImageResponse>} - A streaming image response.
 */
export async function GET(req: NextRequest, { params }: { params: { userId: string } }) {
  const { userId } = params;

  // 1. SERVER-SIDE DATA FETCHING
  // In a real app, this would be a database call or API fetch.
  // We simulate fetching user profile data here.
  const userData = await fetchUserDetails(userId);

  // 2. DYNAMIC STYLE GENERATION
  // We can generate colors or layouts based on user data (e.g., tier, activity).
  const backgroundColor = userData.isPremium ? '#1a1a2e' : '#ffffff';
  const textColor = userData.isPremium ? '#ffffff' : '#1a1a2e';
  const avatarUrl = userData.avatar || 'https://via.placeholder.com/150';

  // 3. REACT COMPONENT RENDERING
  // The UI is defined as a React component. This is rendered to an image buffer.
  const html = {
    type: 'div',
    props: {
      style: {
        display: 'flex',
        height: '100%',
        width: '100%',
        alignItems: 'center',
        justifyContent: 'center',
        flexDirection: 'column',
        backgroundColor: backgroundColor,
        fontFamily: 'Inter, sans-serif',
      },
      children: [
        {
          type: 'div',
          props: {
            style: {
              display: 'flex',
              alignItems: 'center',
              gap: '24px',
            },
            children: [
              // Avatar Image
              {
                type: 'img',
                props: {
                  src: avatarUrl,
                  width: 120,
                  height: 120,
                  style: { borderRadius: '50%' },
                },
              },
              // User Info Container
              {
                type: 'div',
                props: {
                  style: { display: 'flex', flexDirection: 'column' },
                  children: [
                    {
                      type: 'div',
                      props: {
                        style: {
                          fontSize: '48px',
                          fontWeight: 'bold',
                          color: textColor,
                        },
                        children: userData.name,
                      },
                    },
                    {
                      type: 'div',
                      props: {
                        style: {
                          fontSize: '24px',
                          color: userData.isPremium ? '#a0a0ff' : '#555',
                        },
                        children: `@${userData.handle}`,
                      },
                    },
                  ],
                },
              },
            ],
          },
        },
        // Footer Badge
        {
          type: 'div',
          props: {
            style: {
              marginTop: '40px',
              padding: '12px 24px',
              backgroundColor: userData.isPremium ? '#4f46e5' : '#eee',
              borderRadius: '8px',
              color: userData.isPremium ? '#fff' : '#000',
              fontSize: '20px',
              fontWeight: '600',
            },
            children: userData.isPremium ? 'Pro Member' : 'Community Member',
          },
        },
      ],
    },
  };

  // 4. STREAMING RESPONSE
  // Return the ImageResponse. The Vercel OG library handles the conversion to PNG.
  return new ImageResponse(html, {
    width: 1200,
    height: 630,
    fonts: [
      // Load a font if necessary, or rely on system defaults for speed
    ],
  });
}

/**
 * Mock function to simulate fetching user data from a database.
 * In production, replace this with a Prisma, Drizzle, or direct SQL call.
 */
async function fetchUserDetails(userId: string) {
  // Simulate network delay
  await new Promise((resolve) => setTimeout(resolve, 100));

  // Mock data based on ID
  const isPremium = userId === 'user-123'; // Only user-123 is premium
  
  return {
    name: isPremium ? 'Alice Johnson' : 'Bob Smith',
    handle: isPremium ? 'alice_dev' : 'bob_guest',
    avatar: isPremium 
      ? 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80'
      : 'https://images.unsplash.com/photo-1599566150163-29194dcaad36?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80',
    isPremium,
  };
}
