/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script_part2.ts
// Description: Advanced Application Script
// ==========================================

// File: app/profile/[userId]/page.tsx
import { Metadata } from 'next';

/**
 * Generates dynamic metadata for the profile page.
 * This runs on the server side before the page is rendered.
 * 
 * @param {{ params: { userId: string } }} context - The route parameters.
 * @returns {Promise<Metadata>} - The metadata object for the page.
 */
export async function generateMetadata({ params }: { params: { userId: string } }): Promise<Metadata> {
  const { userId } = params;

  // 1. CONSTRUCT DYNAMIC IMAGE URL
  // We point directly to our API route that generates the image.
  // Note: In a real app, ensure the domain is whitelisted in next.config.js
  const ogImageUrl = `${process.env.NEXT_PUBLIC_BASE_URL || 'http://localhost:3000'}/api/og/${userId}`;

  // 2. DEFINE METADATA
  // The metadata object is used by Next.js to render <meta> tags in the <head>.
  return {
    title: `Profile: ${userId}`,
    description: `View the profile of user ${userId}.`,
    openGraph: {
      title: `Profile: ${userId}`,
      description: `View the profile of user ${userId}.`,
      // The critical part: referencing the dynamic image generator
      images: [
        {
          url: ogImageUrl,
          width: 1200,
          height: 630,
          type: 'image/png',
        },
      ],
      type: 'profile',
    },
    twitter: {
      card: 'summary_large_image',
      title: `Profile: ${userId}`,
      description: `View the profile of user ${userId}.`,
      images: [ogImageUrl], // Twitter uses the same image
    },
  };
}

/**
 * The UI component for the Profile Page.
 * In this simplified example, we focus on the metadata generation,
 * but the page would typically fetch and display user data here.
 */
export default function UserProfilePage({ params }: { params: { userId: string } }) {
  return (
    <div style={{ padding: '2rem', fontFamily: 'sans-serif' }}>
      <h1>User Profile: {params.userId}</h1>
      <p>Check the browser tab title or inspect the page source to see the dynamic OG tags.</p>
      <p>
        <a href={`/api/og/${params.userId}`} target="_blank">
          View Generated OG Image
        </a>
      </p>
    </div>
  );
}
