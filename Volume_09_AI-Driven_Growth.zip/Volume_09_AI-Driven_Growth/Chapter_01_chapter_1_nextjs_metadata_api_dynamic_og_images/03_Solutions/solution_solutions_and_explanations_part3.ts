/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

// lib/search.ts
// Mock vector database interface
interface VectorSearchResult {
  id: string;
  score: number;
  metadata: {
    title: string;
    category: string;
    author: string;
  };
}

// Mock client
const mockVectorClient = {
  query: async (vector: number[], filter: any, topK: number): Promise<VectorSearchResult[]> => {
    // Simulates a database query with filtering
    console.log('Querying with filter:', JSON.stringify(filter, null, 2));
    return [
      // Mock return data
      { id: '1', score: 0.95, metadata: { title: 'Advanced React Patterns', category: 'Engineering', author: 'Jane Doe' } },
      { id: '2', score: 0.92, metadata: { title: 'Next.js Server Actions Deep Dive', category: 'Engineering', author: 'John Smith' } },
      { id: '3', score: 0.89, metadata: { title: 'Building Scalable APIs', category: 'Engineering', author: 'Jane Doe' } },
      { id: '4', score: 0.85, metadata: { title: 'CSS Grid Mastery', category: 'Design', author: 'Alice Johnson' } },
      { id: '5', score: 0.82, metadata: { title: 'TypeScript Generics', category: 'Engineering', author: 'Bob Lee' } },
    ].filter(item => {
      // Apply mock filter logic for demonstration
      if (!filter || !filter.$and) return true;
      return filter.$and.every((condition: any) => {
        const key = Object.keys(condition)[0];
        const op = Object.keys(condition[key])[0];
        const value = condition[key][op];
        if (op === '$eq') return item.metadata[key] === value;
        return true;
      });
    }).slice(0, topK);
  }
};

export async function searchWithFilters(query: string, filters: Record<string, string>): Promise<VectorSearchResult[]> {
  // Step 1: Convert the query text into a vector embedding (mocked)
  // In a real scenario, this would call an embedding model API
  const embedding = new Array(1536).fill(0).map((_, i) => Math.random() * 2 - 1);

  // Step 2: Construct the metadata filter object from the 'filters' parameter
  const filterConditions = Object.entries(filters).map(([key, value]) => ({
    [key]: { $eq: value }
  }));

  const filter = filterConditions.length > 0 ? { $and: filterConditions } : undefined;

  // Step 3: Call the vector client query with the embedding, filter, and topK
  const results = await mockVectorClient.query(embedding, filter, 5);

  // Step 4: Return the results
  return results;
}
