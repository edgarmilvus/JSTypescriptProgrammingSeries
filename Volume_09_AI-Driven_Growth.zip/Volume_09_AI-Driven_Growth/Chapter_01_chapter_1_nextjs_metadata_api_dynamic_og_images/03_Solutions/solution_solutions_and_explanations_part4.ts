/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

// types/agent.ts
type AgentRole = 'Researcher' | 'Writer' | 'Editor' | 'FINISH';

interface SupervisorState {
  messages: Array<{ role: 'user' | 'assistant'; content: string }>;
  task: 'research' | 'write' | 'edit' | 'done';
  draft?: string;
}

interface SupervisorDecision {
  next: AgentRole;
  reason: string;
}

export async function supervisorNode(state: SupervisorState): Promise<SupervisorDecision> {
  const { task, draft } = state;

  // Logic for routing based on the current task and draft status
  if (task === 'research' && !draft) {
    return {
      next: 'Researcher',
      reason: 'The task is set to research and no draft exists. Need to gather information first.',
    };
  }

  if (task === 'write' || (task === 'research' && draft)) {
    // If the task is explicitly 'write', or if research produced a draft that needs writing
    return {
      next: 'Writer',
      reason: 'Content creation is required based on the current task or existing research draft.',
    };
  }

  if (task === 'edit') {
    return {
      next: 'Editor',
      reason: 'A draft is available and the task is set to edit for revision and polishing.',
    };
  }

  if (task === 'done') {
    return {
      next: 'FINISH',
      reason: 'The task status is marked as done. The workflow is complete.',
    };
  }

  // Fallback for any unhandled state
  return {
    next: 'FINISH',
    reason: 'No specific routing logic matched. Defaulting to finish to prevent infinite loops.',
  };
}
