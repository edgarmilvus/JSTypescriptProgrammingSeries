/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

// components/OGImagePreview.tsx
'use client';

import { useState, useEffect } from 'react';
import Image from 'next/image';
import { useDebounce } from 'use-debounce'; // Assuming a library like use-debounce is available

interface OGImagePreviewProps {
  title: string;
  author: string;
}

export default function OGImagePreview({ title, author }: OGImagePreviewProps) {
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Debounce the title and author to avoid excessive API calls
  const [debouncedTitle] = useDebounce(title, 500);
  const [debouncedAuthor] = useDebounce(author, 500);

  useEffect(() => {
    // Don't fetch if debounced values are empty
    if (!debouncedTitle && !debouncedAuthor) {
      setPreviewUrl(null);
      return;
    }

    const controller = new AbortController();
    const signal = controller.signal;

    const fetchPreview = async () => {
      setIsLoading(true);
      setError(null);
      
      const url = `/api/og?title=${encodeURIComponent(debouncedTitle)}&author=${encodeURIComponent(debouncedAuthor)}`;
      setPreviewUrl(url);

      // Optional: Pre-fetch to check for errors (though next/image handles this)
      try {
        const response = await fetch(url, { signal });
        if (!response.ok) throw new Error('Failed to generate image');
      } catch (err: any) {
        if (err.name !== 'AbortError') {
          setError('Could not load preview.');
        }
      } finally {
        setIsLoading(false);
      }
    };

    fetchPreview();

    // Cleanup function to abort the fetch if the component unmounts or inputs change
    return () => {
      controller.abort();
    };
  }, [debouncedTitle, debouncedAuthor]);

  return (
    <div className="og-preview-container" style={{ width: '100%', maxWidth: '600px', aspectRatio: '1200/630', position: 'relative' }}>
      {isLoading && (
        <div className="skeleton-loader" style={{ width: '100%', height: '100%', background: '#e0e0e0', borderRadius: '8px' }} />
      )}
      
      {error && !isLoading && (
        <div className="error-fallback" style={{ width: '100%', height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center', background: '#f0f0f0', color: '#999' }}>
          Image Preview Unavailable
        </div>
      )}

      {!isLoading && !error && previewUrl && (
        <Image
          src={previewUrl}
          alt="OG Image Preview"
          fill
          style={{ objectFit: 'cover', borderRadius: '8px' }}
          // The onLoadingComplete callback can be used to further manage state if needed
          onLoadingComplete={() => setIsLoading(false)}
          // onError is built into next/Image, but we can add custom logic
          onError={() => setError('Image failed to load')}
        />
      )}
    </div>
  );
}
