/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part4.ts
// Description: Practical Exercises
// ==========================================

// types/agent.ts
type AgentRole = 'Researcher' | 'Writer' | 'Editor' | 'FINISH';

interface SupervisorState {
  messages: Array<{ role: 'user' | 'assistant'; content: string }>;
  task: 'research' | 'write' | 'edit' | 'done';
  draft?: string;
}

interface SupervisorDecision {
  next: AgentRole;
  reason: string;
}

export async function supervisorNode(state: SupervisorState): Promise<SupervisorDecision> {
  // TODO: Analyze the state.task and state.draft
  // TODO: If task is 'research' and no draft exists, route to 'Researcher'
  // TODO: If task is 'write' and draft exists but needs polishing, route to 'Writer'
  // TODO: If task is 'edit', route to 'Editor'
  // TODO: If task is 'done' or quality checks pass, route to 'FINISH'
  // TODO: Return the decision object with a reasoning string
}
