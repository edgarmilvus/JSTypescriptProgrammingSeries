/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * @fileoverview Smart Sitemap Generator using LangGraph ReAct Loop.
 * 
 * Dependencies:
 * - @langchain/langgraph
 * - @langchain/openai
 * - zod (for schema validation)
 * 
 * Run with: npx ts-node sitemap-agent.ts
 */

import { z } from "zod";
import { StateGraph, END, MessageGraph } from "@langchain/langgraph";
import { ChatOpenAI } from "@langchain/openai";
import { HumanMessage } from "@langchain/core/messages";

// ==========================================
// 1. CONFIGURATION & SCHEMAS
// ==========================================

// Define the structure of the sitemap data we want the agent to generate.
const SitemapNodeSchema = z.object({
  slug: z.string().describe("SEO-friendly URL slug (e.g., '/features/task-management')"),
  title: z.string().describe("Page title for the metadata"),
  priority: z.number().min(0).max(1).describe("Priority score between 0.0 and 1.0"),
  changefreq: z.enum(["always", "hourly", "daily", "weekly", "monthly", "yearly", "never"])
    .describe("How frequently the page is likely to change"),
});

const SitemapClusterSchema = z.object({
  nodes: z.array(SitemapNodeSchema).describe("List of pages in this cluster"),
});

// Initialize the LLM (GPT-4 Turbo). 
// NOTE: Ensure OPENAI_API_KEY is set in your environment.
const llm = new ChatOpenAI({
  model: "gpt-4-turbo-preview",
  temperature: 0, // Deterministic output for structured data
});

// ==========================================
// 2. AGENT NODES (THE "ACTING" PARTS)
// ==========================================

/**
 * Node 1: Reasoning Step
 * Analyzes the topic and decides what actions are needed (generating the sitemap structure).
 */
async function reasonNode(state: { topic: string }) {
  const systemPrompt = `
    You are an SEO Expert Agent. 
    Your goal is to generate a structured sitemap for a SaaS product based on the input topic.
    
    Topic: "${state.topic}"
    
    Instructions:
    1. Identify 3 core content pillars (e.g., Features, Pricing, Blog).
    2. For each pillar, generate 2 specific URL slugs.
    3. Assign a priority (1.0 for homepage, decreasing for subpages).
    4. Return ONLY the JSON object matching the schema provided.
  `;

  const response = await llm.invoke([
    new HumanMessage(systemPrompt),
  ]);

  // Store the raw LLM response in state for the next step
  return { rawResponse: response.content };
}

/**
 * Node 2: Acting Step (Tool Simulation)
 * Parses the LLM text response into structured JSON.
 * In a real app, this acts as a "tool" or function call.
 */
async function actNode(state: { rawResponse: string }) {
  try {
    // Parse the string response into the Zod schema
    const parsedData = SitemapClusterSchema.parse(
      JSON.parse(state.rawResponse as string)
    );
    return { sitemapData: parsedData };
  } catch (error) {
    // If parsing fails, we flag validation failure to trigger a retry loop
    console.error("Validation failed:", error);
    return { sitemapData: null, validationError: true };
  }
}

/**
 * Node 3: Observation Step (Quality Assurance)
 * Checks if the generated data meets quality standards.
 */
async function observeNode(state: { sitemapData: any; validationError?: boolean }) {
  if (state.validationError || !state.sitemapData) {
    return { status: "RETRY", reason: "JSON parsing or schema validation failed." };
  }

  // Basic QA check: Ensure we have at least 3 nodes
  if (state.sitemapData.nodes.length < 3) {
    return { status: "RETRY", reason: "Generated sitemap is too small." };
  }

  return { status: "SUCCESS" };
}

/**
 * Node 4: Final Output Generation
 * Converts the structured data into an XML string.
 */
function generateXMLNode(state: { sitemapData: any }) {
  const { nodes } = state.sitemapData;
  
  // Standard XML Sitemap Header
  let xml = '<?xml version="1.0" encoding="UTF-8"?>\n';
  xml += '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n';

  // Generate <url> entries
  nodes.forEach((node: any) => {
    xml += '  <url>\n';
    xml += `    <loc>https://example.com${node.slug}</loc>\n`;
    xml += `    <lastmod>${new Date().toISOString().split('T')[0]}</lastmod>\n`;
    xml += `    <changefreq>${node.changefreq}</changefreq>\n`;
    xml += `    <priority>${node.priority}</priority>\n`;
    xml += '  </url>\n';
  });

  xml += '</urlset>';
  return { xmlOutput: xml };
}

// ==========================================
// 3. REACT LOOP GRAPH DEFINITION
// ==========================================

/**
 * Constructs the LangGraph workflow.
 * This creates the cyclical "Reason -> Act -> Observe" loop.
 */
function createSitemapGraph() {
  const workflow = new StateGraph({
    channels: {
      // Define the state schema
      topic: { value: (x?: string, y?: string) => y ?? x ?? "" },
      rawResponse: { value: (x?: string, y?: string) => y ?? x ?? "" },
      sitemapData: { value: (x?: any, y?: any) => y ?? x ?? null },
      validationError: { value: (x?: boolean, y?: boolean) => y ?? x ?? false },
      status: { value: (x?: string, y?: string) => y ?? x ?? "" },
      xmlOutput: { value: (x?: string, y?: string) => y ?? x ?? "" },
    },
  });

  // Add nodes
  workflow.addNode("reason", reasonNode);
  workflow.addNode("act", actNode);
  workflow.addNode("observe", observeNode);
  workflow.addNode("generate_xml", generateXMLNode);

  // Define Edges (The Logic Flow)
  
  // 1. Start -> Reason
  workflow.setEntryPoint("reason");

  // 2. Reason -> Act
  workflow.addEdge("reason", "act");

  // 3. Act -> Observe
  workflow.addEdge("act", "observe");

  // 4. Observe -> Conditional Logic
  // If status is RETRY, go back to 'reason'. If SUCCESS, go to 'generate_xml'.
  workflow.addConditionalEdges(
    "observe",
    (state) => {
      if (state.status === "RETRY") return "reason";
      return "generate_xml";
    }
  );

  // 5. Generate XML -> End
  workflow.addEdge("generate_xml", END);

  return workflow.compile();
}

// ==========================================
// 4. EXECUTION
// ==========================================

async function main() {
  console.log("🚀 Initializing Smart Sitemap Agent...\n");
  
  const graph = createSitemapGraph();
  
  // Input: The broad topic for the SaaS
  const initialInput = { 
    topic: "AI-Powered Project Management Tool for Remote Teams" 
  };

  try {
    // Execute the ReAct Loop
    const result = await graph.invoke(initialInput);
    
    console.log("✅ Sitemap Generation Complete!\n");
    console.log("--- Generated XML Sitemap ---");
    console.log(result.xmlOutput);
    
  } catch (error) {
    console.error("❌ Agent execution failed:", error);
  }
}

// Execute if run directly
if (require.main === module) {
  main();
}
