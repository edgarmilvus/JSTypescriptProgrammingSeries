/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// app/actions/sitemap-generator.ts
'use server';

import { z } from 'zod';
import { ChatOpenAI } from '@langchain/openai';
import {
  ChatPromptTemplate,
  HumanMessagePromptTemplate,
  SystemMessagePromptTemplate,
} from '@langchain/core/prompts';
import { StructuredOutputParser } from '@langchain/core/output_parsers';
import { tool } from '@langchain/core/tools';
import { StateGraph, END, MessageGraph } from '@langchain/langgraph';

// ============================================================================
// 1. SCHEMA DEFINITIONS & CONFIGURATION
// ============================================================================

// Schema for a single sitemap entry (URL set)
const SitemapEntrySchema = z.object({
  slug: z.string().describe("SEO-friendly URL path (e.g., /tools/ai-writing-assistant)"),
  title: z.string().describe("Page title optimized for search"),
  priority: z.number().min(0).max(1).describe("Priority score based on search volume"),
  cluster: z.string().describe("The parent topic category"),
});

// Schema for the agent's reasoning state
const AgentStateSchema = z.object({
  inputTopic: z.string(),
  iterations: z.number().default(0),
  entries: z.array(SitemapEntrySchema).optional(),
  error: z.string().optional(),
});

// Type definitions for strict TypeScript usage
type AgentState = z.infer<typeof AgentStateSchema>;
type SitemapEntry = z.infer<typeof SitemapEntrySchema>;

// ============================================================================
// 2. TOOL DEFINITIONS (The "Acting" Phase)
// ============================================================================

/**
 * Tool: Generate Content Clusters & Metadata
 * Simulates an SEO API call (e.g., Ahrefs/SEMrush) to generate structured data.
 * In a real app, this would fetch actual search volume data.
 */
const generateClusterTool = tool(
  async (topic: string): Promise<SitemapEntry[]> => {
    // Simulated delay for API latency
    await new Promise((resolve) => setTimeout(resolve, 500));

    // Mock logic: Generate 3 variations of the topic for the sitemap
    const baseEntries: SitemapEntry[] = [
      {
        slug: `/${topic.toLowerCase().replace(/\s+/g, '-')}/overview`,
        title: `Ultimate Guide to ${topic}`,
        priority: 0.9,
        cluster: topic,
      },
      {
        slug: `/${topic.toLowerCase().replace(/\s+/g, '-')}/tools`,
        title: `Top 10 ${topic} Tools in 2024`,
        priority: 0.8,
        cluster: topic,
      },
      {
        slug: `/${topic.toLowerCase().replace(/\s+/g, '-')}/tutorial`,
        title: `How to Use ${topic}: Step-by-Step Tutorial`,
        priority: 0.7,
        cluster: topic,
      },
    ];

    // Introduce a "defect" to test the QA loop (e.g., a slug that is too long)
    if (topic.length > 10) {
      baseEntries.push({
        slug: `/${topic.toLowerCase().replace(/\s+/g, '-')}/advanced-configuration-and-settings-guide`,
        title: `Advanced Config for ${topic}`,
        priority: 0.5,
        cluster: topic,
      });
    }

    return baseEntries;
  },
  {
    name: 'generate_seo_clusters',
    description: 'Generates a list of SEO-optimized URLs and metadata based on a topic.',
    argsSchema: z.object({ topic: z.string() }),
  }
);

/**
 * Tool: Quality Assurance (QA) Validator
 * Checks generated entries against technical SEO constraints.
 */
const validateSitemapTool = tool(
  async (entries: SitemapEntry[]): Promise<{ valid: boolean; errors: string[] }> => {
    const errors: string[] = [];
    
    entries.forEach((entry, index) => {
      // Rule 1: Slug length should be under 60 characters
      if (entry.slug.length > 60) {
        errors.push(`Entry ${index} (${entry.slug}): Slug exceeds 60 chars.`);
      }
      // Rule 2: Priority must be > 0.5 for high-value pages
      if (entry.priority < 0.5) {
        errors.push(`Entry ${index} (${entry.slug}): Priority too low.`);
      }
    });

    return { valid: errors.length === 0, errors };
  },
  {
    name: 'validate_sitemap_structure',
    description: 'Validates a list of sitemap entries against technical SEO rules.',
    argsSchema: z.object({ entries: z.array(SitemapEntrySchema) }),
  }
);

// ============================================================================
// 3. AGENT NODES (The Logic Steps)
// ============================================================================

/**
 * Node 1: Planner
 * Uses LLM to reason about the input and decide on the initial structure.
 */
const plannerNode = async (state: AgentState): Promise<Partial<AgentState>> => {
  const model = new ChatOpenAI({ model: 'gpt-4-turbo-preview', temperature: 0 });
  
  const prompt = ChatPromptTemplate.fromMessages([
    SystemMessagePromptTemplate.fromTemplate(
      `You are an SEO Growth Engineer. Analyze the user's topic and generate a list of specific, high-intent sub-topics to cover. 
       Return ONLY the sub-topic names, comma-separated.`
    ),
    HumanMessagePromptTemplate.fromTemplate("Topic: {topic}"),
  ]);

  const chain = prompt.pipe(model);
  const response = await chain.invoke({ topic: state.inputTopic });
  
  // Parse the LLM response to get raw sub-topics
  const subTopics = response.content.toString().split(',').map(s => s.trim());
  
  return { 
    iterations: state.iterations + 1,
    // We pass these raw topics to the next 'Acting' step via the state
    // Note: In a full graph, we might store this in a separate key, 
    // but for this simplified loop, we trigger the tool directly.
    inputTopic: state.inputTopic // Keep original
  };
};

/**
 * Node 2: Actor (Tool Caller)
 * Calls the generation tool to create structured data.
 */
const actorNode = async (state: AgentState): Promise<Partial<AgentState>> => {
  // Invoke the tool defined in Step 2
  const rawEntries = await generateClusterTool.invoke({ topic: state.inputTopic });
  
  return {
    entries: rawEntries,
    iterations: state.iterations + 1,
  };
};

/**
 * Node 3: Observer (QA Checker)
 * Validates the generated data and logs errors.
 */
const observerNode = async (state: AgentState): Promise<Partial<AgentState>> => {
  if (!state.entries) return state;

  const result = await validateSitemapTool.invoke({ entries: state.entries });
  
  if (!result.valid) {
    console.warn('QA Check Failed:', result.errors);
    return {
      error: result.errors.join('; '),
      iterations: state.iterations + 1,
    };
  }

  return { error: undefined, iterations: state.iterations + 1 };
};

/**
 * Node 4: Corrector (Refinement)
 * If QA failed, this node attempts to fix the issues (simplified for demo).
 * In a complex agent, this would trigger a specific 'rewrite' prompt.
 */
const correctorNode = async (state: AgentState): Promise<Partial<AgentState>> => {
  if (!state.entries) return state;

  // Simple logic: Filter out invalid entries (in reality, we'd regenerate them)
  const validEntries = state.entries.filter(e => e.slug.length <= 60);
  
  return {
    entries: validEntries,
    error: undefined, // Clear error
    iterations: state.iterations + 1,
  };
};

/**
 * Node 5: Formatter
 * Converts the valid JSON entries into a standard XML sitemap string.
 */
const formatterNode = async (state: AgentState): Promise<Partial<AgentState>> => {
  if (!state.entries) return state;

  // Generate XML
  const xmlHeader = `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">`;
  const xmlBody = state.entries
    .map(
      (entry) => `  <url>\n    <loc>https://example.com${entry.slug}</loc>\n    <priority>${entry.priority}</priority>\n  </url>`
    )
    .join('\n');
  const xmlFooter = `</urlset>`;
  
  const fullXml = `${xmlHeader}\n${xmlBody}\n${xmlFooter}`;

  // In a real app, we would save this to a database or file system
  console.log('Generated Sitemap:', fullXml);

  return { ...state }; // Return final state
};

// ============================================================================
// 4. GRAPH CONSTRUCTION (The ReAct Loop)
// ============================================================================

/**
 * Defines the control flow of the agent.
 * Logic: Generate -> Validate -> (If Invalid -> Correct -> Re-Validate) -> Format
 */
const workflow = new StateGraph(AgentStateSchema)
  // Step 1: Initial Generation
  .addNode('planner', plannerNode)
  .addNode('actor', actorNode)
  
  // Step 2: Quality Assurance
  .addNode('observer', observerNode)
  .addNode('corrector', correctorNode)
  
  // Step 3: Final Output
  .addNode('formatter', formatterNode);

// Define Edges (Control Flow)
workflow.addEdge('planner', 'actor');
workflow.addEdge('actor', 'observer');

// Conditional Edge: Check if QA passed
workflow.addConditionalEdges(
  'observer',
  (state: AgentState) => {
    if (state.error) return 'corrector'; // If error exists, go to corrector
    return 'formatter'; // Otherwise, go to formatter
  }
);

workflow.addEdge('corrector', 'observer'); // Re-check after correction
workflow.addEdge('formatter', END);

// Set Entry Point
workflow.setEntryPoint('planner');

// Compile the graph
const app = workflow.compile();

// ============================================================================
// 5. SERVER ACTION (API INTERFACE)
// ============================================================================

/**
 * Next.js Server Action
 * Called from a client component (e.g., a form submitting a topic).
 * Securely executes the agent loop.
 */
export async function generateSmartSitemap(topic: string) {
  if (!topic) {
    return { success: false, error: 'Topic is required' };
  }

  try {
    // Initialize the agent state
    const initialState: AgentState = {
      inputTopic: topic,
      iterations: 0,
    };

    // Execute the ReAct Loop
    const finalState = await app.invoke(initialState);

    // Return the formatted XML (stored in the state or computed at the end)
    // For this demo, we re-compute or retrieve from the last step
    return {
      success: true,
      data: finalState.entries, // In a real scenario, this would be the XML string
      iterations: finalState.iterations,
    };
  } catch (error) {
    console.error('Sitemap Generation Failed:', error);
    return { success: false, error: 'Internal Agent Error' };
  }
}
