/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script_part2.ts
// Description: Advanced Application Script
// ==========================================

digraph ReActSitemap {
    rankdir=TB;
    node [shape=box, style="rounded,filled", color="#4F46E5", fontcolor="white"];
    
    Start [label="User Input\n(Topic)", shape=ellipse, color="#10B981"];
    Planner [label="Planner Node\n(LLM Reasoning)"];
    Actor [label="Actor Node\n(Generate Data)"];
    Observer [label="Observer Node\n(Validate QA)"];
    Corrector [label="Corrector Node\n(Retry/Fix)"];
    Formatter [label="Formatter Node\n(Generate XML)"];
    End [label="Return Sitemap", shape=ellipse, color="#10B981"];
    
    // Logic Flow
    Start -> Planner;
    Planner -> Actor;
    Actor -> Observer;
    
    // Conditional Loop
    Observer -> Corrector [label="Error Found"];
    Observer -> Formatter [label="Valid"];
    Corrector -> Observer;
    
    // Final Output
    Formatter -> End;
    
    // Styling for dark mode compatibility in docs
    node [color="#4F46E5", fillcolor="#4F46E5"];
    Start [fillcolor="#10B981"];
    End [fillcolor="#10B981"];
}
