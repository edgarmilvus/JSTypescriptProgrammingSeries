/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// Dependencies: @langchain/langgraph, @langchain/core
import { StateGraph, END, Annotation } from "@langchain/langgraph";
import { BaseMessage, HumanMessage, AIMessage } from "@langchain/core/messages";

// 1. State Management Interface
interface SitemapAgentState {
  seedKeyword: string;
  reasoningSteps: BaseMessage[];
  currentAction: string | null;
  toolOutput: Record<string, string[]> | null;
  sitemap: Array<{
    url: string;
    title: string;
    intent: 'informational' | 'transactional' | 'comparison';
    priority: number;
  }> | null;
}

// Define State Annotation for LangGraph
const SitemapState = Annotation.Root({
  seedKeyword: Annotation<string>(),
  reasoningSteps: Annotation<BaseMessage[]>({
    reducer: (curr, update) => [...curr, ...update],
    default: () => [],
  }),
  currentAction: Annotation<string | null>({
    reducer: (curr, update) => update,
    default: () => null,
  }),
  toolOutput: Annotation<Record<string, string[]> | null>({
    reducer: (curr, update) => update,
    default: () => null,
  }),
  sitemap: Annotation<Array<{
    url: string;
    title: string;
    intent: 'informational' | 'transactional' | 'comparison';
    priority: number;
  }> | null>({
    reducer: (curr, update) => update,
    default: () => null,
  }),
});

// 2. Mock Tool Implementation
async function fetchKeywordClusters(keyword: string): Promise<Record<string, string[]>> {
  console.log(`[Tool] Fetching clusters for: "${keyword}"...`);
  // Simulate API latency
  await new Promise(resolve => setTimeout(resolve, 500));
  
  return {
    informational: [
      `how to use ${keyword}`,
      `${keyword} benefits`,
      `what is ${keyword}`
    ],
    transactional: [
      `buy ${keyword}`,
      `${keyword} pricing`,
      `best ${keyword} deals`
    ],
    comparison: [
      `${keyword} vs dropbox`,
      `${keyword} alternatives`,
      `is ${keyword} worth it`
    ]
  };
}

// 3. LangGraph Nodes

// Node: Reasoning (Simulated LLM Decision)
async function reasoningNode(state: typeof SitemapState.State): Promise<Partial<SitemapAgentState>> {
  console.log("[Reasoning Node] Deciding next step...");
  
  // Simple logic: if no tool output, decide to use tool. 
  // In a real app, this would be an LLM call deciding between tools or END.
  const decision = state.toolOutput 
    ? "We have the data. Proceed to generate sitemap." 
    : "We need keyword data. Use the fetchKeywordClusters tool.";
  
  const message = new AIMessage(decision);
  
  return {
    reasoningSteps: [message],
    currentAction: state.toolOutput ? "generate_sitemap" : "fetch_keyword_clusters"
  };
}

// Node: Acting (Tool Execution)
async function actingNode(state: typeof SitemapState.State): Promise<Partial<SitemapAgentState>> {
  if (!state.currentAction || state.currentAction === "generate_sitemap") {
    return {};
  }

  if (state.currentAction === "fetch_keyword_clusters") {
    const toolOutput = await fetchKeywordClusters(state.seedKeyword);
    return {
      toolOutput,
      reasoningSteps: [new HumanMessage(`Observation: Received clusters.`)]
    };
  }

  return {};
}

// Node: Sitemap Generation (Final Step)
async function generateSitemapNode(state: typeof SitemapState.State): Promise<Partial<SitemapAgentState>> {
  console.log("[Generation Node] Building sitemap...");
  if (!state.toolOutput || !state.seedKeyword) return { sitemap: [] };

  const sitemap: SitemapAgentState['sitemap'] = [];
  const { seedKeyword, toolOutput } = state;

  // Priority Logic: Info=7, Transactional=9, Comparison=5
  const intentPriorityMap = {
    informational: 7,
    transactional: 9,
    comparison: 5
  };

  // Generate entries
  (Object.keys(toolOutput) as Array<keyof typeof toolOutput>).forEach(intent => {
    toolOutput[intent].forEach((topic) => {
      // Create slug: remove special chars, replace spaces with hyphens
      const slug = topic.toLowerCase().replace(/[^a-z0-9\s-]/g, "").replace(/\s+/g, "-");
      
      sitemap.push({
        url: `/${seedKeyword}/${slug}`,
        title: topic.charAt(0).toUpperCase() + topic.slice(1),
        intent: intent as 'informational' | 'transactional' | 'comparison',
        priority: intentPriorityMap[intent]
      });
    });
  });

  return { sitemap };
}

// 4. Graph Definition
function createSitemapGraph() {
  const workflow = new StateGraph(SitemapState);

  workflow.addNode("reasoning", reasoningNode);
  workflow.addNode("acting", actingNode);
  workflow.addNode("generation", generateSitemapNode);

  workflow.setEntryPoint("reasoning");

  // Conditional Edges
  workflow.addConditionalEdges(
    "reasoning",
    (state: typeof SitemapState.State) => {
      if (state.currentAction === "generate_sitemap") return "generation";
      return "acting";
    }
  );

  workflow.addEdge("acting", "reasoning");
  workflow.addEdge("generation", END);

  return workflow.compile();
}

// 5. CLI Execution
async function runCLI(seedKeyword: string) {
  console.log(`🚀 Starting ReAct Loop for keyword: "${seedKeyword}"`);
  
  const graph = createSitemapGraph();
  
  // Initial State
  const initialState = {
    seedKeyword: seedKeyword,
    reasoningSteps: [],
    currentAction: null,
    toolOutput: null,
    sitemap: null,
  };

  // Run the graph
  // Note: For this specific exercise, we rely on the graph logic to cycle.
  // To strictly enforce "3 cycles" as requested, we could iterate manually, 
  // but LangGraph handles the loop based on edges. 
  // We will run until completion (Generation -> END).
  const finalState = await graph.invoke(initialState);

  console.log("\n--- Final Reasoning Trace ---");
  finalState.reasoningSteps.forEach((msg: BaseMessage) => {
    console.log(`${msg._getType().toUpperCase()}: ${msg.content}`);
  });

  console.log("\n--- Generated Sitemap JSON ---");
  console.log(JSON.stringify(finalState.sitemap, null, 2));
}

// Entry point check
if (process.argv.length < 3) {
  console.log("Usage: ts-node script.ts <seedKeyword>");
} else {
  runCLI(process.argv[2]).catch(console.error);
}
