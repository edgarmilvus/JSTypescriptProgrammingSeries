/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useReducer, useEffect } from 'react';
import { useCompletion } from '@ai-sdk/react';

// 1. State & Types
interface SitemapEntry {
  url: string;
  intent: string;
  priority: number;
}

interface SitemapState {
  isGenerating: boolean;
  reasoningTrace: string[];
  sitemap: SitemapEntry[];
}

type Action = 
  | { type: 'START_GENERATION' }
  | { type: 'UPDATE_REASONING'; payload: string }
  | { type: 'ADD_SITEMAP_ENTRY'; payload: SitemapEntry }
  | { type: 'FINISH_GENERATION' };

// 2. Reducer Logic
const sitemapReducer = (state: SitemapState, action: Action): SitemapState => {
  switch (action.type) {
    case 'START_GENERATION':
      return { ...state, isGenerating: true, reasoningTrace: [], sitemap: [] };
    case 'UPDATE_REASONING':
      return { ...state, reasoningTrace: [...state.reasoningTrace, action.payload] };
    case 'ADD_SITEMAP_ENTRY':
      return { ...state, sitemap: [...state.sitemap, action.payload] };
    case 'FINISH_GENERATION':
      return { ...state, isGenerating: false };
    default:
      return state;
  }
};

export const SitemapGenerator = ({ seedKeyword }: { seedKeyword: string }) => {
  const [state, dispatch] = useReducer(sitemapReducer, {
    isGenerating: false,
    reasoningTrace: [],
    sitemap: [],
  });

  // 3. AI SDK Integration (Simulated for Exercise Context)
  // In a real app, the API route would stream the ReAct loop steps.
  // Here, we simulate the stream to demonstrate UI updates.
  const { complete, completion, isLoading } = useCompletion({
    api: '/api/generate', // Placeholder API endpoint
    onFinish: () => {
      dispatch({ type: 'FINISH_GENERATION' });
    }
  });

  // 4. Simulation Logic (Since we don't have a real backend in this file)
  useEffect(() => {
    if (state.isGenerating && state.sitemap.length === 0) {
      const simulateGeneration = async () => {
        // Simulate Reasoning
        dispatch({ type: 'UPDATE_REASONING', payload: `Analyzing seed: ${seedKeyword}...` });
        await new Promise(r => setTimeout(r, 800));
        dispatch({ type: 'UPDATE_REASONING', payload: `Identified intent clusters: Informational, Transactional.` });
        
        // Simulate Acting (Skeleton Loader Phase)
        await new Promise(r => setTimeout(r, 1000));

        // Simulate Sitemap Entries (Optimistic UI)
        const mockEntries: SitemapEntry[] = [
          { url: `/${seedKeyword}/how-to-guide`, intent: 'informational', priority: 7 },
          { url: `/${seedKeyword}/pricing`, intent: 'transactional', priority: 9 },
          { url: `/${seedKeyword}/vs-competitor`, intent: 'comparison', priority: 5 },
        ];

        for (const entry of mockEntries) {
          dispatch({ type: 'UPDATE_REASONING', payload: `Generating entry: ${entry.url}` });
          dispatch({ type: 'ADD_SITEMAP_ENTRY', payload: entry });
          await new Promise(r => setTimeout(r, 400)); // Staggered appearance
        }

        dispatch({ type: 'FINISH_GENERATION' });
      };
      
      simulateGeneration();
    }
  }, [state.isGenerating, seedKeyword]);

  // 5. Download Handler
  const handleDownload = () => {
    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(state.sitemap, null, 2));
    const downloadAnchorNode = document.createElement('a');
    downloadAnchorNode.setAttribute("href", dataStr);
    downloadAnchorNode.setAttribute("download", "sitemap.json");
    document.body.appendChild(downloadAnchorNode);
    downloadAnchorNode.click();
    downloadAnchorNode.remove();
  };

  const startGeneration = () => {
    dispatch({ type: 'START_GENERATION' });
  };

  return (
    <div className="p-6 border rounded-lg shadow-md bg-white max-w-2xl mx-auto">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-xl font-bold">Sitemap Generator</h2>
        {!state.isGenerating && state.sitemap.length === 0 && (
          <button 
            onClick={startGeneration}
            className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700"
          >
            Generate for "{seedKeyword}"
          </button>
        )}
      </div>

      {/* Reasoning Trace */}
      <div className="bg-gray-50 p-3 rounded mb-4 h-32 overflow-y-auto text-sm font-mono">
        {state.reasoningTrace.map((step, idx) => (
          <div key={idx} className="mb-1 text-gray-700">
            <span className="text-blue-500">➜</span> {step}
          </div>
        ))}
        {state.isGenerating && <div className="animate-pulse text-gray-400">Thinking...</div>}
      </div>

      {/* Skeleton / Loading State */}
      {state.isGenerating && state.sitemap.length === 0 && (
        <div className="space-y-2 animate-pulse">
          <div className="h-8 bg-gray-200 rounded w-full"></div>
          <div className="h-8 bg-gray-200 rounded w-3/4"></div>
        </div>
      )}

      {/* Sitemap List */}
      {state.sitemap.length > 0 && (
        <div className="mb-4">
          <h3 className="font-semibold mb-2">Generated Sitemap</h3>
          <ul className="space-y-2">
            {state.sitemap.map((item, idx) => (
              <li key={idx} className="flex justify-between items-center p-2 border rounded bg-gray-50">
                <div>
                  <span className="font-mono text-xs text-gray-600 block">{item.url}</span>
                  <span className={`text-xs font-bold px-2 py-0.5 rounded ${
                    item.intent === 'transactional' ? 'bg-green-100 text-green-800' :
                    item.intent === 'informational' ? 'bg-blue-100 text-blue-800' :
                    'bg-purple-100 text-purple-800'
                  }`}>
                    {item.intent.toUpperCase()}
                  </span>
                </div>
                <div className="font-bold text-gray-700">Pri: {item.priority}</div>
              </li>
            ))}
          </ul>
        </div>
      )}

      {/* Download Button */}
      {state.sitemap.length > 0 && (
        <button 
          onClick={handleDownload}
          className="w-full py-2 bg-green-600 text-white rounded hover:bg-green-700 flex items-center justify-center gap-2"
        >
          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"></path></svg>
          Download JSON
        </button>
      )}
    </div>
  );
};
