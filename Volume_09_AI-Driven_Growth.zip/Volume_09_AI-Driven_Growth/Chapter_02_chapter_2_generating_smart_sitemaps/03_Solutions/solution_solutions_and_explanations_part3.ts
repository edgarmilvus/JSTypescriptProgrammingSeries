/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

// 1. Strict Interface Definition
export interface SitemapEntry {
  url: string;
  title: string;
  description: string;
  intent: 'informational' | 'transactional' | 'comparison';
  priority: number;
}

interface ValidationResult {
  isValid: boolean;
  errors: Array<{ index: number; message: string }>;
}

// 2. QA Validator Function
export function validateSitemap(sitemap: SitemapEntry[]): ValidationResult {
  const errors: ValidationResult['errors'] = [];
  const seenUrls = new Set<string>();

  // Regex for slug validation: lowercase alphanumeric and hyphens only
  const slugRegex = /^[a-z0-9-]+$/;

  sitemap.forEach((entry, index) => {
    // Rule 1: Slug Uniqueness
    if (seenUrls.has(entry.url)) {
      errors.push({ index, message: `Duplicate URL found: ${entry.url}` });
    }
    seenUrls.add(entry.url);

    // Rule 2: Character Encoding (Slug check)
    // Extract the slug part (after last slash) for validation
    const slugParts = entry.url.split('/');
    const lastPart = slugParts[slugParts.length - 1];
    if (!slugRegex.test(lastPart)) {
      errors.push({ index, message: `Invalid slug format: "${lastPart}". Only lowercase alphanumeric and hyphens allowed.` });
    }

    // Rule 3: Metadata Completeness
    if (!entry.title || entry.title.trim() === '') {
      errors.push({ index, message: "Title is missing or empty." });
    }
    if (!entry.description || entry.description.trim() === '') {
      errors.push({ index, message: "Description is missing or empty." });
    }

    // Rule 4: Priority Range
    if (!Number.isInteger(entry.priority) || entry.priority < 1 || entry.priority > 10) {
      errors.push({ index, message: `Priority ${entry.priority} is invalid. Must be an integer between 1 and 10.` });
    }
  });

  return {
    isValid: errors.length === 0,
    errors,
  };
}

// 3. Wrapper Function (Conceptual Integration)
export async function generateAndValidateSitemap(generationLogic: () => Promise<SitemapEntry[]>): Promise<ValidationResult> {
  try {
    const sitemap = await generationLogic();
    return validateSitemap(sitemap);
  } catch (error) {
    return {
      isValid: false,
      errors: [{ index: -1, message: `Generation failed: ${error}` }]
    };
  }
}
