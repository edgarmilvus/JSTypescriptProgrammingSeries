/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

// tests/qa.test.ts
import { describe, it, expect } from 'vitest'; // or 'jest'
import { validateSitemap, SitemapEntry } from './qa';

describe('Sitemap QA Validator', () => {
  const baseEntry: SitemapEntry = {
    url: '/cloud-storage/best-guide',
    title: 'Best Guide',
    description: 'A detailed guide.',
    intent: 'informational',
    priority: 7
  };

  it('should pass for a valid sitemap', () => {
    const validSitemap = [baseEntry];
    const result = validateSitemap(validSitemap);
    expect(result.isValid).toBe(true);
    expect(result.errors).toHaveLength(0);
  });

  it('should detect duplicate URLs', () => {
    const duplicateSitemap = [
      baseEntry,
      { ...baseEntry, title: 'Different Title' } // Same URL
    ];
    const result = validateSitemap(duplicateSitemap);
    expect(result.isValid).toBe(false);
    expect(result.errors[0].message).toContain('Duplicate URL');
  });

  it('should detect invalid slug characters', () => {
    const invalidCharSitemap = [
      { ...baseEntry, url: '/cloud-storage/Best Guide!' } // Contains space and !
    ];
    const result = validateSitemap(invalidCharSitemap);
    expect(result.isValid).toBe(false);
    expect(result.errors[0].message).toContain('Invalid slug format');
  });

  it('should detect missing metadata', () => {
    const missingMetaSitemap = [
      { ...baseEntry, description: '' }
    ];
    const result = validateSitemap(missingMetaSitemap);
    expect(result.isValid).toBe(false);
    expect(result.errors[0].message).toContain('Description is missing');
  });

  it('should detect invalid priority range', () => {
    const invalidPrioritySitemap = [
      { ...baseEntry, priority: 11 } // Out of 1-10 range
    ];
    const result = validateSitemap(invalidPrioritySitemap);
    expect(result.isValid).toBe(false);
    expect(result.errors[0].message).toContain('Priority 11 is invalid');
  });
});
