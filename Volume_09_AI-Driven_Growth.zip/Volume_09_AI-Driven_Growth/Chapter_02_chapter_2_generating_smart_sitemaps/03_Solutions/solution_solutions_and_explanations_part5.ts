/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

// 1. Interfaces and Template
interface SitemapEntry {
  url: string;
  title: string;
  description: string;
  intent: 'informational' | 'transactional' | 'comparison';
  priority: number;
}

const promptTemplate = `
  Generate a sitemap entry for the keyword: "{keyword}".
  Intent: {intent}.
  Format the URL as: {base_url}/{intent}/{keyword-slug}.
  Return only JSON.
`;

// 2. Gap Analysis Logic
export function analyzeKeywordGap(
  currentSitemap: SitemapEntry[], 
  competitorKeywords: string[]
): string[] {
  // Extract keywords from existing sitemap (tokenizing titles and URLs)
  const existingKeywords = new Set<string>();
  
  currentSitemap.forEach(entry => {
    // Simple tokenization: split URL and title by space/hyphen
    const tokens = (entry.url + " " + entry.title).toLowerCase().split(/[-\s/]+/);
    tokens.forEach(t => existingKeywords.add(t));
  });

  // Find keywords in competitor list that don't exist in our set
  const missingKeywords = competitorKeywords.filter(kw => {
    const kwTokens = kw.toLowerCase().split(/[-\s]+/);
    // If any token of the competitor keyword is missing, we consider it a gap
    // For simplicity, we check if the full string exists in our tokens
    return !existingKeywords.has(kw.toLowerCase());
  });

  return missingKeywords;
}

// 3. Mock LLM Integration
async function mockLLMCall(prompt: string): Promise<SitemapEntry> {
  // Simulate parsing the prompt to extract data
  const keywordMatch = prompt.match(/keyword: "([^"]+)"/);
  const intentMatch = prompt.match(/Intent: ([a-z]+)\./i);
  const urlMatch = prompt.match(/URL as: ([^\n]+)/);

  const keyword = keywordMatch ? keywordMatch[1] : "unknown";
  const intent = (intentMatch ? intentMatch[1].toLowerCase() : 'informational') as SitemapEntry['intent'];
  
  // Generate a mock slug from the keyword
  const slug = keyword.toLowerCase().replace(/[^a-z0-9-]/g, '').replace(/\s+/g, '-');

  return {
    url: `/generated/${intent}/${slug}`,
    title: `Guide to ${keyword}`,
    description: `This is a generated description for ${keyword}.`,
    intent: intent,
    priority: intent === 'transactional' ? 9 : 7
  };
}

// 4. Main Function
export async function generateDynamicSitemap(
  baseSitemap: SitemapEntry[],
  competitorKeywords: string[]
): Promise<SitemapEntry[]> {
  
  // Step 1: Analyze Gap
  const missingKeywords = analyzeKeywordGap(baseSitemap, competitorKeywords);
  console.log(`Found ${missingKeywords.length} missing keywords.`);

  // Step 2: Generate Prompts & Call LLM (Simulated)
  // We limit to top 3 for the exercise
  const keywordsToGenerate = missingKeywords.slice(0, 3);
  const newEntries: SitemapEntry[] = [];

  for (const keyword of keywordsToGenerate) {
    // Determine intent based on keyword heuristics (mock logic)
    const intent = keyword.includes('buy') ? 'transactional' : 'informational';
    
    const filledPrompt = promptTemplate
      .replace('{keyword}', keyword)
      .replace('{intent}', intent)
      .replace('{base_url}', 'https://example.com');

    const entry = await mockLLMCall(filledPrompt);
    newEntries.push(entry);
  }

  // Step 3: Merge and Sort
  const mergedSitemap = [...baseSitemap, ...newEntries];
  
  // Sort by priority descending
  mergedSitemap.sort((a, b) => b.priority - a.priority);

  return mergedSitemap;
}
