/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part6.ts
// Description: Solutions and Explanations
// ==========================================

// 1. Interfaces
interface SitemapEntry {
  url: string;
  title: string;
  description: string;
  intent: 'informational' | 'transactional' | 'comparison';
  priority: number;
}

interface AnalyticsData {
  keyword: string; // e.g., "how-to-use-cloud-storage"
  searchVolume: number;
}

// 2. Priority Calculation Logic
export function calculatePriority(
  volume: number,
  minVolume: number,
  maxVolume: number
): number {
  // Edge case: If all volumes are the same, return a default priority (e.g., 5)
  if (maxVolume === minVolume) {
    return 5;
  }

  // Min-Max Scaling: Normalize to 0-1, then scale to 1-10
  const normalized = (volume - minVolume) / (maxVolume - minVolume);
  const scaled = 1 + (normalized * 9); // 9 because range size is 9 (10-1)
  
  return Math.round(scaled); // Return integer
}

// 3. Mock API
export async function fetchAnalyticsData(keywords: string[]): Promise<AnalyticsData[]> {
  // Simulate API delay
  await new Promise(resolve => setTimeout(resolve, 500));
  
  // Return random volumes for demonstration
  return keywords.map(kw => ({
    keyword: kw,
    searchVolume: Math.floor(Math.random() * 10000) + 100 // Random between 100 and 10100
  }));
}

// 4. State Update Function
export function adjustPriorities(
  sitemap: SitemapEntry[],
  analytics: AnalyticsData[]
): SitemapEntry[] {
  // Map analytics for O(1) lookup
  const analyticsMap = new Map<string, number>();
  analytics.forEach(item => analyticsMap.set(item.keyword, item.searchVolume));

  // Extract volumes to find min/max for normalization
  const volumes = analytics.map(a => a.searchVolume);
  const minVolume = Math.min(...volumes);
  const maxVolume = Math.max(...volumes);

  // Update sitemap entries
  return sitemap.map(entry => {
    // Extract keyword from URL for matching (e.g., "how-to-use-cloud-storage" from "/cloud-storage/how-to-use-cloud-storage")
    const urlParts = entry.url.split('/');
    const slug = urlParts[urlParts.length - 1];
    
    const volume = analyticsMap.get(slug);
    
    // If we have data for this entry, recalculate priority
    if (volume !== undefined) {
      const newPriority = calculatePriority(volume, minVolume, maxVolume);
      return { ...entry, priority: newPriority };
    }

    // Return original if no data found
    return entry;
  });
}

// 5. React Component Integration (Conceptual Snippet for Exercise 5)
/*
// Inside the React component from Exercise 2:
const [analyticsData, setAnalyticsData] = useState<AnalyticsData[]>([]);

const handleRefreshPriorities = async () => {
  const keywords = state.sitemap.map(e => e.url.split('/').pop()!);
  const data = await fetchAnalyticsData(keywords);
  setAnalyticsData(data); // Store for "Sort by Volume" toggle
  
  const updatedSitemap = adjustPriorities(state.sitemap, data);
  // Dispatch update to reducer or set state directly
  setSitemap(updatedSitemap); 
};

const handleSortToggle = () => {
  if (!analyticsData.length) return;
  // Sort by volume descending
  const sorted = [...state.sitemap].sort((a, b) => {
    const volA = analyticsData.find(d => a.url.includes(d.keyword))?.searchVolume || 0;
    const volB = analyticsData.find(d => b.url.includes(d.keyword))?.searchVolume || 0;
    return volB - volA;
  });
  setSitemap(sorted);
};
*/
