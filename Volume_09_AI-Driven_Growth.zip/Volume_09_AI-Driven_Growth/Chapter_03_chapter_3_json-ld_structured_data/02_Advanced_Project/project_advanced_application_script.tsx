/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.tsx
// Description: Advanced Application Script
// ==========================================

import React, { Suspense } from 'react';
import { Metadata } from 'next';

// ==========================================
// 1. TYPE DEFINITIONS & INTERFACES
// ==========================================

/**
 * Represents the raw data fetched from our GPT-4 generation pipeline or CMS.
 * This is the "Source of Truth" before schema transformation.
 */
interface GeneratedContent {
  id: string;
  title: string;
  description: string;
  author: string;
  datePublished: string;
  softwareCategory?: 'CRM' | 'Analytics' | 'Automation';
  aggregateRating?: number;
  reviewCount?: number;
}

/**
 * Base interface for all Schema.org objects.
 * We strictly type the `@context` and `@type` to prevent invalid schema definitions.
 */
interface SchemaBase {
  '@context': 'https://schema.org';
  '@type': string;
}

/**
 * Specific interface for SoftwareApplication Schema.
 * Note: We use optional fields to allow for partial data generation.
 */
interface SoftwareApplicationSchema extends SchemaBase {
  '@type': 'SoftwareApplication';
  name: string;
  description: string;
  applicationCategory: string;
  operatingSystem: string; // Example requirement for software
  aggregateRating?: {
    '@type': 'AggregateRating';
    ratingValue: number;
    reviewCount: number;
  };
  author: {
    '@type': 'Organization' | 'Person';
    name: string;
  };
}

/**
 * Union type for all possible schemas this engine can generate.
 */
type JsonLdSchema = SoftwareApplicationSchema;

// ==========================================
// 2. IMMUTABLE STATE MANAGEMENT & FACTORY
// ==========================================

/**
 * Generates a JSON-LD object based on input content.
 * 
 * CRITICAL: This function follows Immutable State Management principles.
 * It does not modify the `content` argument. It constructs and returns
 * a brand new object literal.
 * 
 * Why? In a concurrent rendering environment (Next.js), mutating shared
 * objects leads to race conditions and unpredictable SEO metadata.
 * 
 * @param content - The raw generated content data.
 * @returns A fully typed JSON-LD object ready for serialization.
 */
function createSchemaFromContent(content: GeneratedContent): JsonLdSchema {
  // Logic to determine the specific schema type based on content metadata
  if (content.softwareCategory) {
    return {
      '@context': 'https://schema.org',
      '@type': 'SoftwareApplication',
      name: content.title,
      description: content.description,
      applicationCategory: `BusinessApplication`, // Mapping internal category to Schema.org
      operatingSystem: 'Cloud', // Default for SaaS
      author: {
        '@type': 'Organization',
        name: content.author,
      },
      // Conditionally add rating if data exists
      ...(content.aggregateRating && content.reviewCount
        ? {
            aggregateRating: {
              '@type': 'AggregateRating',
              ratingValue: content.aggregateRating,
              reviewCount: content.reviewCount,
            },
          }
        : {}),
    };
  }

  // Fallback to a generic Article schema if no software category is detected
  return {
    '@context': 'https://schema.org',
    '@type': 'Article', // Fallback type
    name: content.title,
    description: content.description,
    author: {
      '@type': 'Person',
      name: content.author,
    },
  } as any; // Casting for simplicity in this demo; ideally, define ArticleSchema interface
}

// ==========================================
// 3. VALIDATION & UTILITIES
// ==========================================

/**
 * Validates the JSON-LD object structure.
 * In a production environment, this would use a library like `zod` or `ajv`
 * to validate against the Schema.org JSON-LD specifications.
 * 
 * @param schema - The generated schema object.
 * @returns boolean indicating validity.
 */
function validateSchema(schema: JsonLdSchema): boolean {
  if (!schema['@context'] || !schema['@type'] || !schema.name) {
    console.warn('Schema validation failed: Missing required fields.');
    return false;
  }
  
  // Specific validation for SoftwareApplication
  if (schema['@type'] === 'SoftwareApplication') {
    if (!schema.operatingSystem) {
      console.warn('Schema validation warning: SoftwareApplication should have operatingSystem.');
      // We might still allow this to pass but log it.
    }
  }

  return true;
}

// ==========================================
// 4. REACT SERVER COMPONENT INTEGRATION
// ==========================================

/**
 * Props for the JSON-LD component.
 * We accept the raw content data directly, keeping the schema generation
 * logic on the server side (security + performance).
 */
interface JsonLdProps {
  content: GeneratedContent;
}

/**
 * A Server Component that renders the JSON-LD script tag.
 * 
 * ARCHITECTURAL NOTE: We wrap the generation logic in an async function
 * to simulate potential database lookups or API calls. This allows us
 * to use React's `Suspense` boundaries in the parent layout.
 * 
 * Under the Hood: Next.js serializes the JSON object to a string.
 * We explicitly set `dangerouslySetInnerHTML` because JSON-LD contains
 * characters (like quotes) that standard text escaping would break.
 */
async function JsonLdScript({ content }: JsonLdProps) {
  // Simulate async data fetching (e.g., fetching additional metadata)
  await new Promise((resolve) => setTimeout(resolve, 100)); // 100ms latency simulation

  // 1. Generate Immutable Schema
  const schema = createSchemaFromContent(content);

  // 2. Validate (Optional but recommended in dev)
  const isValid = validateSchema(schema);
  
  if (!isValid) {
    // In production, we might return null or a generic schema.
    // Here we log and proceed for demonstration.
    console.error('Invalid Schema Generated for ID:', content.id);
  }

  // 3. Serialize to string
  const jsonLdString = JSON.stringify(schema, null, 2);

  return (
    <script
      type="application/ld+json"
      dangerouslySetInnerHTML={{ __html: jsonLdString }}
      key={content.id} // Important: Key changes force re-render on navigation
    />
  );
}

/**
 * The Main Wrapper Component.
 * This is the entry point for the application.
 * It utilizes `Suspense` to handle the async nature of the script generation
 * without blocking the hydration of the rest of the page.
 */
export default function SeoMetadataGenerator({ content }: JsonLdProps) {
  return (
    <head>
      {/* Standard Next.js Metadata can go here */}
      <title>{content.title}</title>
      
      {/* 
        SUSPENSE BOUNDARY:
        While `JsonLdScript` fetches data or computes the schema,
        the fallback (null) is rendered. This prevents the "hydration mismatch"
        error that occurs if the server sends different HTML than the client expects
        during the initial load.
      */}
      <Suspense fallback={null}>
        <JsonLdScript content={content} />
      </Suspense>
    </head>
  );
}

// ==========================================
// 5. USAGE EXAMPLE (MOCK DATA)
// ==========================================

/**
 * Example usage in a Next.js Page.
 * 
 * export default function Page() {
 *   const mockContent: GeneratedContent = {
 *     id: '101',
 *     title: 'AutoScale CRM',
 *     description: 'An AI-driven CRM for scaling startups.',
 *     author: 'GrowthTech Inc.',
 *     datePublished: '2023-10-27',
 *     softwareCategory: 'CRM',
 *     aggregateRating: 4.8,
 *     reviewCount: 150,
 *   };
 * 
 *   return (
 *     <div>
 *       <h1>{mockContent.title}</h1>
 *       <p>{mockContent.description}</p>
 *       <SeoMetadataGenerator content={mockContent} />
 *     </div>
 *   );
 * }
 */
