/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// 1. Define TypeScript Interfaces

// Represents the raw data fetched from a database or CMS
interface ArticleData {
  id: string;
  title: string;
  authorName: string;
  datePublished: Date;
  content: string;
  imageUrls: string[];
  url: string;
}

// Represents the final JSON-LD structure based on Schema.org Article
interface ArticleSchema {
  "@context": "https://schema.org";
  "@type": "Article";
  headline: string;
  author: {
    "@type": "Person";
    name: string;
  };
  datePublished: string; // ISO 8601 string
  articleBody: string;
  image: string[];
  mainEntityOfPage: string;
}

// 2. Implement the Generator Function
async function generateArticleSchema(articleData: ArticleData): Promise<ArticleSchema> {
  // Simulate async processing or additional data fetching if needed
  // In a real scenario, this might fetch author details from a separate API
  await new Promise(resolve => setTimeout(resolve, 10)); 

  // Map raw data to the structured schema format
  const schema: ArticleSchema = {
    "@context": "https://schema.org",
    "@type": "Article",
    headline: articleData.title,
    author: {
      "@type": "Person",
      name: articleData.authorName,
    },
    // Convert Date object to ISO 8601 string
    datePublished: articleData.datePublished.toISOString(),
    articleBody: articleData.content,
    image: articleData.imageUrls,
    mainEntityOfPage: articleData.url,
  };

  return schema;
}

// 3. Integration Example (Conceptual Next.js Server Component)
// File: app/articles/[id]/page.tsx

import { notFound } from 'next/navigation';

// Mock database fetch
async function getArticleData(id: string): Promise<ArticleData | null> {
  // In a real app, this would be a database call (e.g., Prisma, Drizzle)
  if (id === '123') {
    return {
      id: '123',
      title: 'Understanding JSON-LD',
      authorName: 'Jane Doe',
      datePublished: new Date('2023-10-27'),
      content: 'JSON-LD is a JSON-based linked data format...',
      imageUrls: ['https://example.com/image.jpg'],
      url: 'https://example.com/articles/json-ld',
    };
  }
  return null;
}

export default async function ArticlePage({ params }: { params: { id: string } }) {
  // 1. Data Fetching in Server Component (Non-blocking I/O)
  const articleData = await getArticleData(params.id);

  if (!articleData) {
    notFound();
  }

  // 2. Schema Generation (Server-side)
  // This happens before the page is sent to the client
  const articleSchema = await generateArticleSchema(articleData);

  // 3. Injecting into the Head
  // We return the schema as a JSON object to be serialized by Next.js
  // In a real app, you might use the 'next/head' component or metadata API
  return (
    <main>
      {/* 
        Conceptual Injection:
        The metadata API in Next.js App Router handles this automatically.
        Or, manually render a script tag:
      */}
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(articleSchema) }}
      />
      
      <h1>{articleData.title}</h1>
      <p>By {articleData.authorName}</p>
      <div>{articleData.content}</div>
    </main>
  );
}
