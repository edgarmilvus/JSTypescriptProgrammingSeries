/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

// 1. Setup Mock Data Types
interface ProductSchema {
  "@context"?: string;
  "@type": "Product";
  name: string;
  description?: string;
  offers: {
    "@type": "Offer";
    price: number;
    priceCurrency: string;
  };
}

// 2. Implement a Validator
function validateSchema(schema: any, schemaType: string): { isValid: boolean; errors: string[] } {
  const errors: string[] = [];

  // Check for basic JSON-LD structure
  if (!schema["@type"]) {
    errors.push("Missing '@type' property.");
  } else if (schema["@type"] !== schemaType) {
    errors.push(`Expected '@type' to be '${schemaType}', but got '${schema["@type"]}'.`);
  }

  // Validate based on schemaType (Product)
  if (schemaType === "Product") {
    if (!schema.name || typeof schema.name !== "string") {
      errors.push("Property 'name' is missing or not a string.");
    }
    if (!schema.offers) {
      errors.push("Property 'offers' is missing.");
    } else {
      if (typeof schema.offers.price !== "number") {
        errors.push("Property 'offers.price' must be a number.");
      }
      if (!schema.offers.priceCurrency || typeof schema.offers.priceCurrency !== "string") {
        errors.push("Property 'offers.priceCurrency' is missing or not a string.");
      }
    }
  }

  return {
    isValid: errors.length === 0,
    errors,
  };
}

// 3. Batch Processing
// Helper to generate mock data (intentionally flawed)
function generateMockProducts(count: number): ProductSchema[] {
  const products: ProductSchema[] = [];
  for (let i = 0; i < count; i++) {
    // Introduce errors for specific indices
    if (i === 5) {
      // Missing name
      products.push({
        "@type": "Product",
        // name: "Product 5", // Intentionally missing
        offers: { "@type": "Offer", price: 19.99, priceCurrency: "USD" },
      } as any);
    } else if (i === 10) {
      // Wrong price type
      products.push({
        "@type": "Product",
        name: "Product 10",
        offers: { "@type": "Offer", price: "19.99", priceCurrency: "USD" }, // String instead of number
      } as any);
    } else {
      // Valid product
      products.push({
        "@type": "Product",
        name: `Product ${i}`,
        offers: { "@type": "Offer", price: 10.00 + i, priceCurrency: "USD" },
      });
    }
  }
  return products;
}

async function processBatchValidation(schemas: object[], schemaType: string) {
  console.log(`Starting batch validation for ${schemaType}...`);
  
  let validCount = 0;
  let invalidCount = 0;
  
  // Simulate non-blocking processing for a large batch
  // Using setImmediate or process.nextTick in Node.js would be ideal,
  // but a simple loop with await is sufficient for demonstration.
  for (let i = 0; i < schemas.length; i++) {
    const schema = schemas[i];
    const result = validateSchema(schema, schemaType);
    
    if (result.isValid) {
      validCount++;
    } else {
      invalidCount++;
      console.error(`\n--- Invalid Schema at Index ${i} ---`);
      console.error(`Errors: ${result.errors.join(", ")}`);
    }
    
    // Yield control to the event loop every 10 items to prevent blocking
    if (i % 10 === 0) {
      await new Promise(resolve => setImmediate(resolve));
    }
  }

  console.log(`\nValidation Complete.`);
  console.log(`Total Schemas: ${schemas.length}`);
  console.log(`Valid: ${validCount}`);
  console.log(`Invalid: ${invalidCount}`);
}

// Execution
const mockProducts = generateMockProducts(100);
processBatchValidation(mockProducts, "Product");
