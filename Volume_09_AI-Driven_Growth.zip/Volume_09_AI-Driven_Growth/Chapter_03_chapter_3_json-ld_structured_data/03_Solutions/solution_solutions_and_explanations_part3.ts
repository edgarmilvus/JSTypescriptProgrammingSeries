/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

// 1. Component Interface
interface BreadcrumbItem {
  name: string;
  url: string;
}

interface BreadcrumbProps {
  items: BreadcrumbItem[];
}

// 2. Server-Side Logic (Breadcrumb.tsx)
// This is a Server Component by default in Next.js App Router
export default function Breadcrumb({ items }: BreadcrumbProps) {
  // 3. Immutable State Management
  // We create a new array to ensure we don't mutate the original props.
  // This is good practice, though props are usually immutable in React.
  const breadcrumbItems = [...items];

  // 4. Generate BreadcrumbList Schema
  const schema = {
    "@context": "https://schema.org",
    "@type": "BreadcrumbList",
    itemListElement: breadcrumbItems.map((item, index) => ({
      "@type": "ListItem",
      position: index + 1,
      name: item.name,
      item: item.url,
    })),
  };

  return (
    <>
      {/* Visual Breadcrumb Rendering */}
      <nav aria-label="Breadcrumb" className="breadcrumb-nav">
        <ul>
          {breadcrumbItems.map((item, index) => (
            <li key={index}>
              <a href={item.url}>{item.name}</a>
              {index < breadcrumbItems.length - 1 && <span> &gt; </span>}
            </li>
          ))}
        </ul>
      </nav>

      {/* JSON-LD Injection */}
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(schema) }}
      />
    </>
  );
}

// 5. Interactive Challenge Extension (Conceptual)
// To handle client-side additions, we would likely need to make this a Client Component.
// However, since the prompt asks for the Server Component solution first, the above is correct.
// The strategy discussion is in the Instructor's Analysis.
