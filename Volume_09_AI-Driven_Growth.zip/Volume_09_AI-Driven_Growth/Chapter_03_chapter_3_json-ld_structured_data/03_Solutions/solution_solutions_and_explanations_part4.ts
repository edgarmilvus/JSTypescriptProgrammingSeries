/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

// 1. Data Modeling
interface FAQItem {
  question: string;
  answer: string;
}

interface FAQPageSchema {
  "@context": "https://schema.org";
  "@type": "FAQPage";
  mainEntity: {
    "@type": "Question";
    name: string;
    acceptedAnswer: {
      "@type": "Answer";
      text: string;
    };
  }[];
}

// 2. Pipeline Function
async function buildFAQPageSchema(questions: FAQItem[]): Promise<FAQPageSchema> {
  // Simulate async data processing or validation
  // This yields control to the event loop if this function is awaited
  await new Promise(resolve => setTimeout(resolve, 0));

  // Handle data inconsistencies (trimming, filtering empty)
  const validQuestions = questions.filter(q => 
    q.question.trim().length > 0 && q.answer.trim().length > 0
  );

  // Transform raw data into the FAQPage structure
  const mainEntity = validQuestions.map((q) => ({
    "@type": "Question",
    name: q.question.trim(),
    acceptedAnswer: {
      "@type": "Answer",
      text: q.answer.trim(),
    },
  }));

  return {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    mainEntity,
  };
}

// 3. Non-Blocking I/O Explanation (Code Context)
// Imagine fetching data from a remote CMS:
async function fetchQuestionsFromCMS(): Promise<FAQItem[]> {
  // Simulate a network request (I/O operation)
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve([
        { question: "What is JSON-LD?", answer: "It is a linked data format." },
        { question: "Why use it?", answer: "For SEO and rich results." },
      ]);
    }, 100);
  });
}

// Main execution context
async function renderFAQPage() {
  // 1. Start Data Fetching (Non-blocking)
  // The 'await' keyword pauses the execution of 'renderFAQPage' but 
  // frees up the Node.js Event Loop to handle other requests.
  const rawQuestions = await fetchQuestionsFromCMS();

  // 2. Process Data
  // The transformation happens synchronously, but since the data is small,
  // it doesn't block significantly. If the dataset were huge, we would
  // process it in chunks using streams or generators.
  const schema = await buildFAQPageSchema(rawQuestions);

  // 3. Render
  console.log("Schema Ready:", JSON.stringify(schema, null, 2));
}

// Run the pipeline
renderFAQPage();
