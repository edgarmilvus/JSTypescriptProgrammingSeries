/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part2.ts
// Description: Theoretical Foundations
// ==========================================

import { z } from 'zod';

// 1. Define the strict schema for a page's metadata
const PageMetaSchema = z.object({
  url: z.string().url(),
  title: z.string().nullable(), // Explicitly allow null
  metaDescription: z.string().nullable(),
  h1: z.string().nullable(),
  wordCount: z.number().int(),
});

// 2. Infer the TypeScript type from the schema
// This ensures our compile-time types always match our runtime validation.
type PageMeta = z.infer<typeof PageMetaSchema>;

// 3. Create a validated function
function analyzeTitleStrict(pageData: unknown): string | null {
  // Parse the unknown data against the schema
  const result = PageMetaSchema.safeParse(pageData);

  if (!result.success) {
    // We catch the error here, before it reaches the LLM
    console.error("Validation failed:", result.error);
    return null;
  }

  const { data } = result; // 'data' is now fully typed as PageMeta

  // Now we can safely access properties
  // TypeScript knows 'title' is string | null
  if (data.title === null) {
    return "Missing title tag";
  }

  const length = data.title.length;
  if (length > 60) {
    return `Title is too long (${length} chars). Recommended: < 60.`;
  }

  return null; // No issues found
}
