/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

// File: seo-audit-service.ts

/**
 * @fileoverview A simple demonstration of using LLMs to analyze SEO crawl data.
 * This script runs in a Node.js environment and utilizes the Event Loop for
 * non-blocking API calls to the LLM provider.
 */

// -----------------------------------------------------------------------------
// 1. TYPE DEFINITIONS (Strict Type Discipline)
// -----------------------------------------------------------------------------

/**
 * Represents a single page crawled from a website.
 * We use strict typing to define the data contract expected from our crawler.
 */
interface CrawlPage {
  url: string;
  title: string | null; // Explicitly nullable
  metaDescription: string | null;
  wordCount: number;
}

/**
 * Represents the structured output we expect back from the LLM.
 * This is crucial for preventing "hallucinated" text in downstream logic.
 */
interface AuditFinding {
  url: string;
  issueType: 'Thin Content' | 'Missing Meta Description' | 'Low Quality Title';
  severity: 'High' | 'Medium' | 'Low';
  recommendation: string;
}

// -----------------------------------------------------------------------------
// 2. MOCK DATA & CONFIGURATION
// -----------------------------------------------------------------------------

// Simulating raw data coming from a crawler (e.g., Screaming Frog API export)
const mockCrawlData: CrawlPage[] = [
  { url: 'https://example.com/', title: 'Home', metaDescription: 'Welcome to our SaaS platform.', wordCount: 850 },
  { url: 'https://example.com/about', title: 'About Us', metaDescription: null, wordCount: 120 }, // Missing Meta
  { url: 'https://example.com/ghost-page', title: null, metaDescription: null, wordCount: 15 }, // Thin & Missing
  { url: 'https://example.com/blog/post-1', title: 'Blog Post 1', metaDescription: 'A short post.', wordCount: 300 },
];

// Mocking the LLM API response structure
interface LLMResponse {
  choices: {
    message: {
      content: string; // This will be a JSON string
    };
  }[];
}

// -----------------------------------------------------------------------------
// 3. LLM INTEGRATION LAYER
// -----------------------------------------------------------------------------

/**
 * Simulates an asynchronous call to an LLM (like GPT-4).
 * In a real app, this would use the `openai` npm package.
 * 
 * @param pages - The array of crawl data to analyze.
 * @returns A Promise resolving to a JSON string of findings.
 */
async function callLLMForAudit(pages: CrawlPage[]): Promise<string> {
  // In a real scenario, we would construct a prompt here.
  // We are mocking the delay and the response to keep this example self-contained.
  
  console.log(`[System] Sending ${pages.length} pages to LLM for analysis...`);
  
  // Simulate network latency (Event Loop handling)
  await new Promise(resolve => setTimeout(resolve, 1000)); 

  // This is the "Expected" output from a well-prompted LLM
  const mockLLMContent = JSON.stringify([
    {
      url: 'https://example.com/about',
      issueType: 'Missing Meta Description',
      severity: 'High',
      recommendation: 'Write a concise meta description (150-160 chars) summarizing the page content.'
    },
    {
      url: 'https://example.com/ghost-page',
      issueType: 'Thin Content',
      severity: 'High',
      recommendation: 'Expand content to be at least 300 words to provide value to users and search engines.'
    }
  ]);

  // Simulating the API response object
  const mockResponse: LLMResponse = {
    choices: [
      {
        message: {
          content: mockLLMContent
        }
      }
    ]
  };

  return mockResponse.choices[0].message.content;
}

// -----------------------------------------------------------------------------
// 4. MAIN AUDIT LOGIC
// -----------------------------------------------------------------------------

/**
 * Orchestrates the SEO audit workflow.
 * 1. Receives raw crawl data.
 * 2. Invokes the LLM.
 * 3. Parses and validates the LLM response.
 * 4. Returns structured findings.
 */
async function performSEOAudit(pages: CrawlPage[]): Promise<AuditFinding[]> {
  try {
    // Step 1: Call the LLM (Non-blocking operation)
    const llmResultString = await callLLMForAudit(pages);

    // Step 2: Parse the JSON string returned by the LLM.
    // LLMs return text; we must parse it into objects.
    const parsedResult = JSON.parse(llmResultString);

    // Step 3: Validate the structure (Type Guard).
    // Even though we parsed it, we must ensure it matches our AuditFinding interface.
    // In strict mode, we check properties to avoid runtime errors.
    const findings: AuditFinding[] = parsedResult.map((item: any) => {
      // Basic validation to ensure data integrity
      if (!item.url || !item.issueType) {
        throw new Error(`Invalid finding detected: ${JSON.stringify(item)}`);
      }
      
      // Return typed object
      return {
        url: item.url,
        issueType: item.issueType,
        severity: item.severity || 'Medium', // Default value if missing
        recommendation: item.recommendation || 'No recommendation provided.'
      } as AuditFinding;
    });

    return findings;

  } catch (error) {
    console.error("Audit failed:", error);
    // In a real app, we might retry or fallback to basic rules.
    return [];
  }
}

// -----------------------------------------------------------------------------
// 5. EXECUTION (Entry Point)
// -----------------------------------------------------------------------------

/**
 * Main function to run the script.
 * Using an IIFE (Immediately Invoked Function Expression) to support top-level await
 * in modern Node.js environments.
 */
(async () => {
  console.log("--- Starting SEO Audit Service ---");
  
  const findings = await performSEOAudit(mockCrawlData);

  console.log("\n--- Audit Results ---");
  findings.forEach(f => {
    console.log(`[${f.severity}] ${f.issueType} on ${f.url}`);
    console.log(`   → Action: ${f.recommendation}`);
  });
  
  console.log("\n--- Process Complete ---");
})();
