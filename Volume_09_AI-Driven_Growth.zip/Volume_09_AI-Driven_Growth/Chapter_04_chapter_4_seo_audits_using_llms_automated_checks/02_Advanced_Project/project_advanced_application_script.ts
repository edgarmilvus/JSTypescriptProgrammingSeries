/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// app/api/seo-audit/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import OpenAI from 'openai';
import { zodResponseFormat } from 'openai/helpers/zod';

// ==========================================
// 1. TYPE DISCIPLINE & SCHEMA DEFINITIONS
// ==========================================

/**
 * Strict Type Discipline: We define the shape of our data using Zod schemas.
 * This serves as a compile-time contract and a runtime validator.
 * It prevents 'implicit any' errors and ensures the LLM output matches our expectations.
 */

// Schema for the input request from the frontend
const AuditRequestSchema = z.object({
  url: z.string().url('Invalid URL provided'),
  depth: z.number().min(1).max(3).default(1), // Crawl depth
});

// Schema for the LLM's output (JSON Schema Output enforcement)
const AuditFindingSchema = z.object({
  severity: z.enum(['critical', 'high', 'medium', 'low']),
  issueType: z.enum(['technical', 'content', 'performance']),
  pageTitle: z.string(),
  url: z.string(),
  description: z.string(),
  recommendation: z.string(),
  codeSnippet: z.string().optional(), // Optional code fix
});

// The final response structure
const AuditResponseSchema = z.object({
  auditId: z.string().uuid(),
  summary: z.object({
    totalIssues: z.number(),
    criticalCount: z.number(),
  }),
  findings: z.array(AuditFindingSchema),
});

// TypeScript types inferred from Zod schemas
type AuditRequest = z.infer<typeof AuditRequestSchema>;
type AuditFinding = z.infer<typeof AuditFindingSchema>;
type AuditResponse = z.infer<typeof AuditResponseSchema>;

// ==========================================
// 2. CRAWLER INTEGRATION LAYER
// ==========================================

/**
 * Simulates a Python-based crawler (like Screaming Frog) returning structured JSON.
 * In a real production environment, this would be an internal API call or a 
 * message queue consumer (e.g., consuming from a Redis queue).
 * 
 * @param url - The target domain to crawl
 * @param depth - The recursion depth
 * @returns Promise<AuditPageData[]>
 */
async function triggerCrawl(url: string, depth: number): Promise<any[]> {
  // Simulating the delay of a network request to a crawler service
  await new Promise(resolve => setTimeout(resolve, 1500));

  // Mock data representing raw crawl results
  // In reality, this data comes from tools like 'screaming-frog-api' or 'cheerio'
  return [
    {
      url: 'https://example.com/',
      title: 'Home | Example SaaS',
      metaDescription: 'A leading SaaS platform for growth engineering.',
      h1: 'Welcome to Growth Engine',
      statusCode: 200,
      wordCount: 850,
      canonical: 'https://example.com/',
    },
    {
      url: 'https://example.com/pricing',
      title: '', // Missing title - SEO Issue
      metaDescription: null, // Missing meta description
      h1: 'Pricing Plans',
      statusCode: 404, // Broken link
      wordCount: 50, // Thin content
      canonical: null,
    },
    {
      url: 'https://example.com/blog/ai-seo',
      title: 'AI SEO Guide',
      metaDescription: 'Learn about AI.',
      h1: 'AI SEO Guide',
      statusCode: 200,
      wordCount: 3000, // Good content
      canonical: 'https://example.com/blog/ai-seo',
    },
  ];
}

// ==========================================
// 3. LLM AUDIT ENGINE
// ==========================================

/**
 * The core logic engine. It takes raw crawl data and uses an LLM to generate
 * structured audit findings. This demonstrates prompt engineering for audit workflows.
 * 
 * @param crawlData - Raw data from the crawler
 * @returns Promise<AuditFinding[]>
 */
async function analyzeWithLLM(crawlData: any[]): Promise<AuditFinding[]> {
  const openai = new OpenAI({
    apiKey: process.env.OPENAI_API_KEY,
  });

  // Prompt Engineering: We instruct the model to act as an SEO expert.
  // We explicitly ask it to output JSON matching our schema.
  const systemPrompt = `
    You are an expert SEO Technical Auditor. Analyze the provided crawl data.
    Identify issues related to HTTP status codes, missing metadata, thin content, and canonicalization.
    Return a JSON array of findings strictly adhering to the provided schema.
    Do not include markdown formatting or text outside the JSON.
  `;

  const completion = await openai.chat.completions.create({
    model: 'gpt-4-turbo-preview',
    messages: [
      { role: 'system', content: systemPrompt },
      { role: 'user', content: JSON.stringify(crawlData) },
    ],
    // JSON Schema Output: We pass the Zod schema to OpenAI's helper
    // This significantly increases the reliability of the output format.
    response_format: zodResponseFormat(AuditFindingSchema, 'seo_audit'),
  });

  const content = completion.choices[0].message.content;
  
  if (!content) {
    throw new Error('LLM returned no content');
  }

  // Parse and validate the LLM output
  // This is where strict type discipline ensures safety.
  const parsed = JSON.parse(content);
  
  // We use Zod to validate the parsed data. If the LLM hallucinates 
  // or formats incorrectly, this will throw an error, preventing bad data 
  // from entering our database.
  const validatedFindings = z.array(AuditFindingSchema).parse(parsed);

  return validatedFindings;
}

// ==========================================
// 4. API ROUTE HANDLER (Next.js)
// ==========================================

/**
 * POST /api/seo-audit
 * 
 * Entry point for the SaaS feature. Orchestrates the crawl and analysis.
 */
export async function POST(request: NextRequest) {
  try {
    // 1. Validate Input
    const body = await request.json();
    const { url, depth } = AuditRequestSchema.parse(body);

    // 2. Trigger Crawl (Data Ingestion)
    const crawlData = await triggerCrawl(url, depth);

    // 3. Analyze with LLM (Intelligent Processing)
    const findings = await analyzeWithLLM(crawlData);

    // 4. Construct Response
    const responsePayload: AuditResponse = {
      auditId: crypto.randomUUID(),
      summary: {
        totalIssues: findings.length,
        criticalCount: findings.filter(f => f.severity === 'critical').length,
      },
      findings: findings,
    };

    // 5. Final Validation (Defense in Depth)
    const finalResponse = AuditResponseSchema.parse(responsePayload);

    return NextResponse.json(finalResponse, { status: 200 });

  } catch (error: any) {
    // Specific error handling for Zod validation errors
    if (error.errors) {
      return NextResponse.json(
        { error: 'Validation failed', details: error.errors },
        { status: 400 }
      );
    }
    
    // Generic error handling
    return NextResponse.json(
      { error: 'Internal Server Error', message: error.message },
      { status: 500 }
    );
  }
}
