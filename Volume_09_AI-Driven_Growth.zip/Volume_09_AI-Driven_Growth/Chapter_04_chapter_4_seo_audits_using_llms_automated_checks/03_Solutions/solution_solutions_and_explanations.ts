/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

import { z } from 'zod';

// 1. Define the Zod Schema
const PageAuditSchema = z.object({
  url: z.string().url(),
  httpStatus: z.number().refine((val) => [200, 301, 404, 500].includes(val), {
    message: "HTTP Status must be one of: 200, 301, 404, 500",
  }),
  metaTitle: z.string().max(60),
  metaDescription: z.string().max(160).optional(),
  wordCount: z.number().int().positive(),
  internalLinks: z.array(z.string().url()),
  isIndexable: z.boolean(),
});

// Infer the TypeScript type for usage in the application
export type PageAudit = z.infer<typeof PageAuditSchema>;

// 2. Implement Validation Function
export function validateCrawlData<T>(
  data: unknown,
  schema: z.ZodSchema<T>
): T {
  try {
    // Attempt to parse and validate the data
    return schema.parse(data);
  } catch (error) {
    // Zod throws an error with an 'issues' array containing details about validation failures
    if (error instanceof z.ZodError) {
      const errorMessage = error.issues
        .map((issue) => `${issue.path.join('.')}: ${issue.message}`)
        .join('; ');
      throw new Error(`Validation failed: ${errorMessage}`);
    }
    // Re-throw if it's an unexpected error type
    throw error;
  }
}

// 3. Demonstrate Failure
const mockBadData = {
  // url: "not-a-url", // Missing URL constraint violation
  httpStatus: 502, // Violates enum constraint (only 200, 301, 404, 500 allowed)
  metaTitle: "A".repeat(61), // Violates max length
  wordCount: -5, // Violates positive integer constraint
  internalLinks: ["valid-url.com"], // Violates URL format constraint inside array
  isIndexable: "yes", // Violates boolean type
};

try {
  // This will throw an error
  validateCrawlData(mockBadData, PageAuditSchema);
} catch (e) {
  console.error((e as Error).message);
  // Expected output example: "Validation failed: url: Required; httpStatus: Invalid enum value. Expected 200, 301, 404 or 500, received 502; metaTitle: String must contain at most 60 character(s); wordCount: Number must be greater than 0; internalLinks.0: Invalid url; isIndexable: Expected boolean, received string"
}
