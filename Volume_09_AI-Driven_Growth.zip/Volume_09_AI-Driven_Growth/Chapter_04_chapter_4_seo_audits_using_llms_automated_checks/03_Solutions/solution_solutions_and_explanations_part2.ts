/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

import { createHash } from 'crypto';

// 1. & 2. The Embedding Function (Simulated)
export async function generateEmbedding(text: string): Promise<number[]> {
  // In a real scenario, we would call an API like OpenAI here.
  // For simulation, we use SHA-256 hashing to generate deterministic bytes.
  const hash = createHash('sha256').update(text).digest();
  
  // Convert the 32-byte hash into an array of 1536 floats (simulating ada-002 dimensions)
  // We repeat the hash pattern to fill the required vector size.
  const vectorSize = 1536;
  const embedding: number[] = [];
  
  for (let i = 0; i < vectorSize; i++) {
    // Use modulo to cycle through hash bytes and normalize to 0-1 range
    const byte = hash[i % hash.length];
    embedding.push(byte / 255); 
  }
  
  return embedding;
}

// 3. Cosine Similarity Helper
export function calculateCosineSimilarity(vecA: number[], vecB: number[]): number {
  if (vecA.length !== vecB.length) {
    throw new Error('Vectors must be of the same length');
  }

  let dotProduct = 0;
  let normA = 0;
  let normB = 0;

  for (let i = 0; i < vecA.length; i++) {
    dotProduct += vecA[i] * vecB[i];
    normA += vecA[i] * vecA[i];
    normB += vecB[i] * vecB[i];
  }

  if (normA === 0 || normB === 0) return 0;
  return dotProduct / (Math.sqrt(normA) * Math.sqrt(normB));
}

// 4. The Audit Check
export async function findDuplicateContent(
  pages: { url: string; content: string }[],
  threshold: number = 0.98
): Promise<string[][]> {
  // Step 1: Generate embeddings for all pages
  const embeddings = await Promise.all(
    pages.map(async (page) => ({
      url: page.url,
      vector: await generateEmbedding(page.content),
    }))
  );

  const groups: string[][] = [];
  const processedIndices = new Set<number>();

  // Step 2: Compare every pair
  for (let i = 0; i < embeddings.length; i++) {
    if (processedIndices.has(i)) continue;

    const currentGroup: string[] = [embeddings[i].url];
    processedIndices.add(i);

    for (let j = i + 1; j < embeddings.length; j++) {
      if (processedIndices.has(j)) continue;

      const similarity = calculateCosineSimilarity(
        embeddings[i].vector,
        embeddings[j].vector
      );

      if (similarity >= threshold) {
        currentGroup.push(embeddings[j].url);
        processedIndices.add(j);
      }
    }

    // Only add groups with more than one page (actual duplicates)
    if (currentGroup.length > 1) {
      groups.push(currentGroup);
    }
  }

  return groups;
}
