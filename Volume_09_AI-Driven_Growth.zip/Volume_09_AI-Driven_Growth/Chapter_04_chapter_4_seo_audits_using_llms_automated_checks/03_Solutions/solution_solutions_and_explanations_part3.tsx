/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState, useMemo } from 'react';

// 1. Type Definitions
type Severity = 'critical' | 'warning' | 'info';
type Category = 'Technical' | 'Content' | 'Performance';

interface AuditIssue {
  id: string;
  severity: Severity;
  category: Category;
  title: string;
  description: string;
  suggestedFix: string;
}

interface PrioritizedFixListProps {
  issues: AuditIssue[];
  isLoading: boolean;
}

// Helper for sorting severity
const severityOrder: Record<Severity, number> = {
  critical: 0,
  warning: 1,
  info: 2,
};

// 2. & 3. & 4. Component Logic
export const PrioritizedFixList: React.FC<PrioritizedFixListProps> = ({
  issues,
  isLoading,
}) => {
  const [selectedCategory, setSelectedCategory] = useState<Category | 'All'>('All');
  const [expandedIssueId, setExpandedIssueId] = useState<string | null>(null);

  // Filtering and Sorting Logic
  const processedIssues = useMemo(() => {
    let filtered = issues;

    if (selectedCategory !== 'All') {
      filtered = issues.filter((i) => i.category === selectedCategory);
    }

    // Sort by severity (Critical first)
    return filtered.sort(
      (a, b) => severityOrder[a.severity] - severityOrder[b.severity]
    );
  }, [issues, selectedCategory]);

  const toggleExpand = (id: string) => {
    setExpandedIssueId((prev) => (prev === id ? null : id));
  };

  if (isLoading) return <div className="loading">Loading audit data...</div>;

  return (
    <div className="audit-report">
      <div className="filters">
        <label>Filter by Category: </label>
        {(['All', 'Technical', 'Content', 'Performance'] as const).map((cat) => (
          <button
            key={cat}
            onClick={() => setSelectedCategory(cat)}
            style={{ fontWeight: selectedCategory === cat ? 'bold' : 'normal' }}
          >
            {cat}
          </button>
        ))}
      </div>

      <ul className="issue-list">
        {processedIssues.map((issue) => (
          <li key={issue.id} className={`issue-item ${issue.severity}`}>
            <div
              className="issue-header"
              onClick={() => toggleExpand(issue.id)}
              style={{ cursor: 'pointer' }}
            >
              <strong>
                [{issue.severity.toUpperCase()}] {issue.title}
              </strong>
              <span> ({issue.category})</span>
              <span> {expandedIssueId === issue.id ? '▲' : '▼'}</span>
            </div>

            {expandedIssueId === issue.id && (
              <div className="issue-details">
                <p>{issue.description}</p>
                {issue.suggestedFix && (
                  <div>
                    <strong>Suggested Fix:</strong>
                    <pre>
                      <code>{issue.suggestedFix}</code>
                    </pre>
                  </div>
                )}
              </div>
            )}
          </li>
        ))}
      </ul>
    </div>
  );
};
