/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

const systemPrompt = `
You are an expert SEO data parser. Your task is to analyze raw server log files and extract specific SEO-relevant metrics.

**Input Data:**
You will receive a string containing raw server log entries. Example:
"GET /products/red-running-shoes HTTP/1.1" 200 4520 "-" "Mozilla/5.0..." "10.20.30.40" "Response Time: 145ms"

**Task:**
1. Identify each distinct log entry in the input text.
2. Extract the following three fields for each entry:
   - **url**: The path requested (e.g., "/products/red-running-shoes").
   - **status**: The HTTP status code (e.g., 200, 404).
   - **responseTimeMs**: The numeric value of the response time in milliseconds (e.g., 145).

**Constraints:**
- **IGNORE** the User Agent string (the text in quotes containing "Mozilla", "Googlebot", etc.).
- **IGNORE** the IP Address.
- **IGNORE** the byte size of the response.
- If a response time is not explicitly listed in the format "Response Time: [number]ms", default to 0.

**Output Format:**
Output **ONLY** a valid JSON array of objects. Do not include markdown formatting (like \`\`\`json), explanations, or conversational text.
The JSON must match this TypeScript interface:
interface LogEntry {
  url: string;
  status: number;
  responseTimeMs: number;
}

**Example Output:**
[
  { "url": "/products/red-running-shoes", "status": 200, "responseTimeMs": 145 },
  { "url": "/blog/seo-tips", "status": 404, "responseTimeMs": 320 }
]
`;
