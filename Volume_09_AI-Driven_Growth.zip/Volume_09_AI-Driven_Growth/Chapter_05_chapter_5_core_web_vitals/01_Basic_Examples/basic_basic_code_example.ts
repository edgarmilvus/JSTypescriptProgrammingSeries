/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * @fileoverview Performance Budget Validator for Programmatic Pages
 * @description Enforces strict limits on DOM complexity and asset size to maintain Core Web Vitals.
 */

// 1. CONFIGURATION & TYPES
// ----------------------------------------------------------------------

/**
 * Defines the structure of our performance budget.
 * These limits are derived from Google's Core Web Vitals recommendations.
 */
interface PerformanceBudget {
  maxDOMNodes: number;       // Prevents excessive layout calculations (CLS risk)
  maxImageWeightKB: number;  // Ensures fast LCP
  maxScriptWeightKB: number; // Reduces main thread blocking
}

/**
 * Represents the analysis result for a single page.
 */
interface ValidationResult {
  isValid: boolean;
  violations: string[];
  metrics: {
    domNodes: number;
    totalImageWeight: number; // in KB
    totalScriptWeight: number; // in KB
  };
}

// 2. CORE LOGIC: BUDGET ENFORCER
// ----------------------------------------------------------------------

/**
 * Analyzes an HTML string against a defined performance budget.
 * 
 * @param html - The raw HTML string of the programmatic page.
 * @param budget - The configuration object defining limits.
 * @returns A validation report indicating pass/fail status.
 */
function validatePageBudget(html: string, budget: PerformanceBudget): ValidationResult {
  const violations: string[] = [];
  
  // --- Metric 1: DOM Complexity ---
  // We use a simple regex to estimate the number of opening tags. 
  // In a production environment, use a parser like 'cheerio' or 'jsdom'.
  const openingTagRegex = /<[a-zA-Z][^>]*>/g;
  const domNodeCount = (html.match(openingTagRegex) || []).length;

  if (domNodeCount > budget.maxDOMNodes) {
    violations.push(`DOM Node limit exceeded: ${domNodeCount} > ${budget.maxDOMNodes}`);
  }

  // --- Metric 2: Image Weight (LCP Optimization) ---
  // Calculate total weight of <img> src attributes based on simulated fetch times or metadata.
  // Here we simulate parsing image sizes from a mock database.
  const imageWeightKB = simulateImageWeightExtraction(html);

  if (imageWeightKB > budget.maxImageWeightKB) {
    violations.push(`Image weight limit exceeded: ${imageWeightKB}KB > ${budget.maxImageWeightKB}KB`);
  }

  // --- Metric 3: Script Weight (Main Thread Blocking) ---
  // Calculate total weight of external scripts.
  const scriptWeightKB = simulateScriptWeightExtraction(html);

  if (scriptWeightKB > budget.maxScriptWeightKB) {
    violations.push(`Script weight limit exceeded: ${scriptWeightKB}KB > ${budget.maxScriptWeightKB}KB`);
  }

  return {
    isValid: violations.length === 0,
    violations,
    metrics: {
      domNodes: domNodeCount,
      totalImageWeight: imageWeightKB,
      totalScriptWeight: scriptWeightKB,
    },
  };
}

// 3. HELPER SIMULATIONS (Mocking Backend Data)
// ----------------------------------------------------------------------

/**
 * Simulates fetching image metadata from a CDN to calculate total weight.
 * In a real app, this would be an async call to an asset manager API.
 */
function simulateImageWeightExtraction(html: string): number {
  // Mock: Counting <img> tags and assigning an average weight per image
  const imgCount = (html.match(/<img/g) || []).length;
  // Assume each image is roughly 150KB (unoptimized) - a common issue in auto-gen pages
  return imgCount * 150; 
}

/**
 * Simulates calculating script bundle sizes.
 */
function simulateScriptWeightExtraction(html: string): number {
  // Mock: Counting external scripts
  const scriptTags = (html.match(/<script src=/g) || []).length;
  // Assume each script is roughly 50KB
  return scriptTags * 50;
}

// 4. EXECUTION CONTEXT (SaaS Pipeline Simulation)
// ----------------------------------------------------------------------

/**
 * Main entry point simulating a CI/CD pipeline step.
 */
async function runPerformanceAudit() {
  console.log("🚀 Starting Programmatic Page Audit...\n");

  // Simulate a generated page from a template
  const programmaticPageHTML = `
    <!DOCTYPE html>
    <html>
      <head><title>Product Page</title></head>
      <body>
        <div class="container">
          <h1>Dynamic Content</h1>
          <!-- Excessive DOM nodes for simulation -->
          ${Array(1500).fill('<span>Item</span>').join('')}
          <!-- Heavy Images -->
          <img src="hero-1.jpg" />
          <img src="hero-2.jpg" />
          <!-- Heavy Scripts -->
          <script src="analytics.js"></script>
          <script src="tracking.js"></script>
          <script src="legacy-bundle.js"></script>
        </div>
      </body>
    </html>
  `;

  // Define strict limits for our SaaS platform
  const strictBudget: PerformanceBudget = {
    maxDOMNodes: 1200,       // Keep DOM shallow for fast rendering
    maxImageWeightKB: 200,   // Max 200KB total for images
    maxScriptWeightKB: 100,  // Max 100KB total for scripts
  };

  // Run validation
  const result = validatePageBudget(programmaticPageHTML, strictBudget);

  // Output results
  if (!result.isValid) {
    console.error("❌ Audit Failed. Violations found:");
    result.violations.forEach(v => console.error(`   - ${v}`));
    console.log("\n📊 Metrics:", result.metrics);
    // In a real CI/CD, this would throw an error to stop the build
    // throw new Error("Performance Budget Breached");
  } else {
    console.log("✅ Audit Passed. Page is within budget.");
    console.log("\n📊 Metrics:", result.metrics);
  }
}

// Run the simulation
runPerformanceAudit();
