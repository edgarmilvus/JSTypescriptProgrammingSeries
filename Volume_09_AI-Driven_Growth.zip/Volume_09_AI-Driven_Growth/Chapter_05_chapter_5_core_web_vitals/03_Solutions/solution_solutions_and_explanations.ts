/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// Define the PropertyData interface here
interface PropertyData {
  id: string;
  title: string;
  price: number;
  imageUrl: string;
  description: string;
}

// Write a function that calculates the appropriate container height 
// based on the number of lines of text expected.
function calculateContainerHeight(lines: number): string {
  // Assuming 1.5rem line height and 1rem padding
  const lineHeight = 1.5; 
  const padding = 1; 
  return `${(lines * lineHeight) + padding}rem`;
}

// Example of the FIXED component structure:
const PropertyCard = ({ data, isLoading }: { data: PropertyData | null, isLoading: boolean }) => {
  // 1. Define static dimensions for the container to reserve vertical space
  // We use a min-height to ensure the container has structure even when empty.
  const containerStyle = {
    minHeight: '400px', // Reserve space for image + text
    border: '1px solid #ccc',
    borderRadius: '8px',
    overflow: 'hidden' // Ensures image corners are clipped correctly
  };

  // 2. Optimize Image Loading
  // We set explicit width and height attributes to let the browser calculate the aspect ratio
  // before the image downloads. CSS will control the visual size, but the attributes reserve the space.
  const imageStyle = {
    width: '100%',
    height: 'auto', // Maintains aspect ratio
    aspectRatio: '16 / 9', // Modern CSS property to reserve space
    objectFit: 'cover',
    display: 'block'
  };

  // 3. Text Container Reservation
  // We calculate a min-height for the text area based on expected lines.
  const textStyle = {
    minHeight: calculateContainerHeight(4), // Reserve space for 4 lines of text
    padding: '1rem'
  };

  if (isLoading) {
    return (
      <div style={containerStyle}>
        <div style={{ ...imageStyle, background: '#e0e0e0' }} /> {/* Skeleton Image */}
        <div style={textStyle}>
          <div style={{ background: '#e0e0e0', height: '1.5rem', marginBottom: '0.5rem', width: '80%' }}></div>
          <div style={{ background: '#e0e0e0', height: '1.5rem', width: '60%' }}></div>
        </div>
      </div>
    );
  }

  return (
    <div style={containerStyle} className="property-card">
      {/* The shift is mitigated here because the container has a defined min-height */}
      <img 
        src={data!.imageUrl} 
        alt={data!.title} 
        width={800} // Explicit width
        height={450} // Explicit height (16:9 aspect ratio)
        style={imageStyle}
      />
      <div style={textStyle}>
        <h2>{data!.title}</h2>
        <p>${data!.price.toLocaleString()}</p>
        <p>{data!.description}</p>
      </div>
    </div>
  );
};
