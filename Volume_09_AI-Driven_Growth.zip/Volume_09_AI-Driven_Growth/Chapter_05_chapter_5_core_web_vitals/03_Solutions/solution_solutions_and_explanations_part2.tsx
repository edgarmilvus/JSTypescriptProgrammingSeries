/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.tsx
// Description: Solutions and Explanations
// ==========================================

// 1. Define the interface for the heavy analytics module
interface AnalyticsModule {
  renderChart: (data: number[]) => void;
  exportData: () => string;
}

// 2. Implement the lazy loader function
// This function returns a Promise<AnalyticsModule>
async function loadAnalyticsModule(): Promise<AnalyticsModule> {
  // Dynamic import syntax creates a separate chunk for this library
  const module = await import('./heavy-analytics-lib');
  return module.default; // Assuming the lib exports default
}

// 3. Performance Budget Utility
// function checkScriptBudget(startTime: number, resourceEntryName: string): boolean 
function checkScriptBudget(startTime: number, resourceEntryName: string): boolean {
  const BUDGET_MS = 200;
  
  // In a real browser environment, we would use PerformanceObserver or performance.getEntriesByName
  // For this simulation, we calculate the delta from the provided start time.
  const endTime = performance.now(); 
  const duration = endTime - startTime;

  console.log(`Resource [${resourceEntryName}] loaded in ${duration.toFixed(2)}ms`);
  
  return duration > BUDGET_MS;
}

// 4. React Component Usage (Conceptual)
/*
import React, { useState } from 'react';

const Dashboard = () => {
  const [analytics, setAnalytics] = useState<AnalyticsModule | null>(null);
  const [isOverBudget, setIsOverBudget] = useState(false);

  const handleViewClick = async () => {
    const startLoadTime = performance.now();
    
    try {
      // Dynamically import the heavy library
      const module = await loadAnalyticsModule();
      
      // Check performance budget
      const exceeded = checkScriptBudget(startLoadTime, 'heavy-analytics-lib');
      setIsOverBudget(exceeded);

      setAnalytics(() => module);
      module.renderChart([10, 20, 30]);
    } catch (error) {
      console.error("Failed to load analytics", error);
    }
  };

  return (
    <div>
      <button onClick={handleViewClick}>View Charts</button>
      {isOverBudget && <p style={{color: 'red'}}>Warning: Analytics script exceeded performance budget!</p>}
      <div id="chart-container">{/* Chart will render here */}</div>
    </div>
  );
};
*/
