/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

// Define the interface for the performance metric data point
interface PagePerformanceMetrics {
  url: string;
  lcp: number; // in seconds
  cls: number; // 0 to 1
  timestamp: Date;
}

// 1. Generate mock data for 10 programmatic URLs
function generateMockReports(count: number): PagePerformanceMetrics[] {
  const reports: PagePerformanceMetrics[] = [];
  
  for (let i = 1; i <= count; i++) {
    // Randomize metrics to simulate variance
    // LCP: Normal distribution around 2s, with occasional spikes
    // CLS: Random value between 0 and 0.4
    const lcp = Math.max(0.5, 2 + (Math.random() * 2 - 1)); 
    const cls = Math.random() * 0.4;

    reports.push({
      url: `https://example.com/property/${i}`,
      lcp: parseFloat(lcp.toFixed(2)),
      cls: parseFloat(cls.toFixed(3)),
      timestamp: new Date()
    });
  }
  return reports;
}

// 2. Filter function to identify regressions
function getFailingPages(
  reports: PagePerformanceMetrics[],
  lcpThreshold: number,
  clsThreshold: number
): PagePerformanceMetrics[] {
  return reports.filter(report => 
    report.lcp > lcpThreshold || report.cls > clsThreshold
  );
}

// 3. Formatting function for the report
function formatReport(failingPages: PagePerformanceMetrics[]): string {
  if (failingPages.length === 0) {
    return "No performance regressions detected. All pages pass Core Web Vitals.";
  }

  let reportString = "PERFORMANCE REGRESSION REPORT\n";
  reportString += "================================\n";
  
  failingPages.forEach(page => {
    const issues = [];
    if (page.lcp > 2.5) issues.push(`LCP: ${page.lcp}s (Threshold: 2.5s)`);
    if (page.cls > 0.1) issues.push(`CLS: ${page.cls} (Threshold: 0.1)`);
    
    reportString += `URL: ${page.url}\n`;
    reportString += `  - Issues: ${issues.join(', ')}\n`;
  });

  return reportString;
}

// Usage Simulation
// const allReports = generateMockReports(10);
// const failing = getFailingPages(allReports, 2.5, 0.1);
// console.log(formatReport(failing));
