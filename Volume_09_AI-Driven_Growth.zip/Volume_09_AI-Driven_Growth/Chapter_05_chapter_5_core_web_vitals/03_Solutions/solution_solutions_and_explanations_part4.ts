/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

// Define the Task type
type TaskType = 'io' | 'cpu';
interface Task {
  type: TaskType;
  duration: number; // in ms
  name: string;
}

// 1. Implement the busy wait (blocking) function
function blockCpu(duration: number): void {
  const start = Date.now();
  // While loop blocks the main thread entirely
  while (Date.now() - start < duration) {
    // Busy wait: keep CPU occupied
  }
}

// 2. Implement the simulation function
async function simulateEventLoop(tasks: Task[]): Promise<void> {
  console.log("Starting Event Loop Simulation...");
  const startTime = Date.now();

  for (const task of tasks) {
    const taskStart = Date.now() - startTime;
    
    if (task.type === 'cpu') {
      console.log(`[+${taskStart}ms] START CPU TASK: ${task.name} (Blocking)`);
      // Synchronous blocking operation
      blockCpu(task.duration);
      const taskEnd = Date.now() - startTime;
      console.log(`[+${taskEnd}ms] END CPU TASK:   ${task.name}`);
    } 
    else if (task.type === 'io') {
      console.log(`[+${taskStart}ms] START IO TASK:  ${task.name} (Non-blocking scheduled)`);
      
      // We use setTimeout to simulate the non-blocking nature.
      // Even though we await it, the event loop allows the current stack to clear 
      // or, in this specific linear simulation, demonstrates that IO tasks 
      // are queued but don't halt the thread *while waiting*.
      // However, in a real scenario, IO tasks run in parallel.
      // To visualize the delay caused by a preceding CPU task, we schedule the IO execution.
      
      await new Promise<void>(resolve => {
        setTimeout(() => {
           const ioEnd = Date.now() - startTime;
           console.log(`[+${ioEnd}ms] COMPLETE IO TASK: ${task.name}`);
           resolve();
        }, task.duration);
      });
    }
  }
  console.log("Event Loop Simulation Complete.");
}

// 3. Example usage to demonstrate the concept
/*
const tasks: Task[] = [
  { type: 'io', duration: 100, name: 'Read File A' },
  { type: 'cpu', duration: 2000, name: 'Generate Large JSON' },
  { type: 'io', duration: 50, name: 'Read File B' }, 
];

// Run this in a Node environment to see the blocking effect
// simulateEventLoop(tasks);
*/
