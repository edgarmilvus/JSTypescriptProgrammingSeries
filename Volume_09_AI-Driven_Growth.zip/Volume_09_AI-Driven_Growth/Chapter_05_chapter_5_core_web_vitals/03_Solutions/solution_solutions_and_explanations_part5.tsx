/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.tsx
// Description: Solutions and Explanations
// ==========================================

import React from 'react';

// 1. Define the Props interface
interface StableLayoutWrapperProps {
  children: React.ReactNode;
  isLoading: boolean;
  minHeight?: string;
  aspectRatio?: string; // e.g., "16/9"
  className?: string;
}

// 2. Implement the Component
const StableLayoutWrapper = ({ 
  children, 
  isLoading, 
  minHeight = 'auto', 
  aspectRatio,
  className = '' 
}: StableLayoutWrapperProps) => {
  
  // Calculate styles to reserve space
  const wrapperStyle: React.CSSProperties = {
    minHeight,
    aspectRatio, // Modern CSS property that reserves perfect space
    position: 'relative',
    // If aspectRatio is set, we might want to ensure overflow is handled
    overflow: 'hidden' 
  };

  // Skeleton style to mimic loading state
  const skeletonStyle: React.CSSProperties = {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: '#e0e0e0',
    borderRadius: '4px',
    animation: 'pulse 1.5s infinite ease-in-out' // Assuming global CSS keyframes
  };

  return (
    <div style={wrapperStyle} className={`stable-wrapper ${className}`}>
      {isLoading ? (
        <div style={skeletonStyle} />
      ) : (
        <div style={{ width: '100%', height: '100%' }}>
          {children}
        </div>
      )}
    </div>
  );
};

// 3. Usage Example (Conceptual)
/*
// A programmatic product card
const ProductCard = ({ product, loading }) => {
  return (
    <StableLayoutWrapper 
      isLoading={loading} 
      minHeight="300px"
      aspectRatio="1/1" // Square layout for products
    >
      <img src={product.image} style={{width: '100%', height: '100%', objectFit: 'cover'}} />
      <h3>{product.title}</h3>
    </StableLayoutWrapper>
  );
};
*/
