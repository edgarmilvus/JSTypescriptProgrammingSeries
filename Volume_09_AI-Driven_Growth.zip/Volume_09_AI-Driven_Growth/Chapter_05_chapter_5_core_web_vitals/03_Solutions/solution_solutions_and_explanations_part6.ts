/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part6.ts
// Description: Solutions and Explanations
// ==========================================

// Since this is a text-based environment, we provide the DOT language string.
// This string can be rendered using tools like Graphviz, or online viewers like viz-js.com.

const dotDiagram = `
digraph RenderingPipeline {
    rankdir=LR; // Left to Right layout
    node [fontname="Arial", fontsize=10];
    edge [fontname="Arial", fontsize=8];

    // Define Styles
    node [shape=box, style=filled, color="#E3F2FD"];
    node [shape=ellipse, style=filled, color="#FFECB3"]; // Sync nodes
    node [shape=ellipse, style=filled, color="#C8E6C9"]; // Async nodes

    // Nodes
    API_Request [label="API Request", shape=box, style=filled, color="#C8E6C9", URL="https://"];
    Data_Parsing [label="JSON Parsing", shape=ellipse, style=filled, color="#FFECB3"];
    Template_Hydration [label="Template Hydration", shape=ellipse, style=filled, color="#FFECB3"];
    Image_Loading [label="Image Loading", shape=box, style=filled, color="#C8E6C9"];
    DOM_Injection [label="DOM Injection", shape=ellipse, style=filled, color="#FFECB3"];

    // Edges & Labels
    API_Request -> Data_Parsing [label="Network I/O (Async)", color="#2E7D32", fontcolor="#2E7D32"];
    Data_Parsing -> Template_Hydration [label="CPU (Sync - Blocking)", color="#C62828", fontcolor="#C62828"];
    Template_Hydration -> Image_Loading [label="Initiate Fetch (Async)", color="#2E7D32", fontcolor="#2E7D32"];
    Image_Loading -> DOM_Injection [label="Bytes to Pixels (Async)", color="#2E7D32", fontcolor="#2E7D32"];
    
    // Impact Labels
    {
        rank=sink;
        Impact_LCP [label="LCP Impact: Images & Text", shape=note, fillcolor=white];
        Impact_CLS [label="CLS Impact: Image Dimensions", shape=note, fillcolor=white];
    }
    
    Template_Hydration -> Impact_LCP [style=dotted, constraint=false];
    Image_Loading -> Impact_CLS [style=dotted, constraint=false];
}
`;

// To view this diagram, copy the string above into a Graphviz renderer.
// Example visualization logic (mock):
console.log(dotDiagram);
