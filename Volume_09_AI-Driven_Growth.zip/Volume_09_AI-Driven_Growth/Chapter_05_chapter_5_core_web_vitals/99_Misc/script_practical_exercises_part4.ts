/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part4.ts
// Description: Practical Exercises
// ==========================================

// Define the Task type
type TaskType = 'io' | 'cpu';
interface Task {
  type: TaskType;
  duration: number; // in ms
  name: string;
}

// 1. Implement the busy wait (blocking) function
// function blockCpu(duration: number): void { ... }

// 2. Implement the simulation function
// This function should log when a task starts and finishes.
// It must demonstrate the blocking nature of 'cpu' tasks.
// function simulateEventLoop(tasks: Task[]): void { ... }

// 3. Example usage to demonstrate the concept:
/*
const tasks: Task[] = [
  { type: 'io', duration: 100, name: 'Read File A' },
  { type: 'cpu', duration: 2000, name: 'Generate Large JSON' },
  { type: 'io', duration: 50, name: 'Read File B' }, // This should appear AFTER the CPU task finishes
];

// simulateEventLoop(tasks);
*/
