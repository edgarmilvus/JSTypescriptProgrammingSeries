/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

// file: src/lib/programmaticGenerator.ts

import OpenAI from 'openai';

// ============================================================================
// CONFIGURATION & TYPES
// ============================================================================

/**
 * Configuration for the OpenAI client.
 * In a real application, API keys should be stored in environment variables
 * (e.g., process.env.OPENAI_API_KEY) and never hardcoded.
 */
const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY || 'sk-demo-key-placeholder', // Placeholder for demo
  dangerouslyAllowBrowser: true, // Only for client-side demo; use server-side in production
});

/**
 * Represents the structured data required to generate a specific programmatic page.
 */
type PageInput = {
  keyword: string;
  category: string;
  intent: 'informational' | 'commercial' | 'transactional';
};

/**
 * Represents the structured output from the AI model.
 * This ensures the generated content is predictable and easily renderable.
 */
type PageOutput = {
  title: string;
  metaDescription: string;
  h1: string;
  body: string; // HTML string
  slug: string;
};

// ============================================================================
// CORE LOGIC
// ============================================================================

/**
 * Generates a programmatic landing page using GPT-4.
 * 
 * @param input - The data defining the page's topic and intent.
 * @returns A Promise resolving to the structured page content.
 * 
 * @remarks
 * This function uses a "few-shot" prompting technique to guide the LLM
 * towards a specific JSON structure, reducing the risk of hallucination.
 */
async function generateProgrammaticPage(input: PageInput): Promise<PageOutput> {
  // 1. Define the System Prompt to enforce structure and tone.
  const systemPrompt = `
    You are an expert SEO copywriter and SaaS content architect.
    Your task is to generate a landing page for a specific keyword.
    You must output ONLY valid JSON. Do not include markdown formatting like \`\`\`json\`\`\`.
    The JSON must match the following schema:
    {
      "title": "string (max 60 chars)",
      "metaDescription": "string (max 160 chars)",
      "h1": "string",
      "body": "string (HTML format, using <h2>, <p>, <ul>, <li>)",
      "slug": "string (lowercase, hyphens)"
    }
  `;

  // 2. Define the User Prompt with context and the specific keyword.
  const userPrompt = `
    Generate content for the keyword: "${input.keyword}".
    Category: ${input.category}.
    User Intent: ${input.intent}.
    
    Guidelines:
    - The H1 should be engaging and include the keyword.
    - The body should be informative, covering 3 key features or benefits.
    - Use simple HTML tags for formatting.
    - The slug should be based on the keyword.
  `;

  // 3. Call the OpenAI API (GPT-4 model).
  const completion = await openai.chat.completions.create({
    model: 'gpt-4', // Or 'gpt-4-turbo-preview' for cost efficiency
    messages: [
      { role: 'system', content: systemPrompt },
      { role: 'user', content: userPrompt },
    ],
    temperature: 0.7, // Balances creativity and determinism
    response_format: { type: 'json_object' }, // Crucial for structured output
  });

  // 4. Parse the response.
  // The API returns a stringified JSON object in the message content.
  const content = completion.choices[0].message.content;

  if (!content) {
    throw new Error('No content generated from AI.');
  }

  // 5. Validate and Type Cast the result.
  // In production, use a schema validator like Zod or Yup here.
  const parsedContent: PageOutput = JSON.parse(content);
  
  // 6. Post-processing: Ensure slug is safe for URLs.
  parsedContent.slug = input.keyword
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/(^-|-$)/g, '');

  return parsedContent;
}

// ============================================================================
// USAGE EXAMPLE (Simulated Main Execution)
// ============================================================================

/**
 * Main execution function to demonstrate the workflow.
 * In a real app, this would be triggered by a Server Action or API Route.
 */
async function main() {
  const input: PageInput = {
    keyword: 'project management software for architects',
    category: 'SaaS',
    intent: 'commercial',
  };

  try {
    console.log(`Generating page for: "${input.keyword}"...`);
    
    const pageData = await generateProgrammaticPage(input);
    
    console.log('--- Generated Page Data ---');
    console.log(JSON.stringify(pageData, null, 2));
    
    // Simulate saving to database or rendering to HTML
    // await saveToDatabase(pageData);
    
  } catch (error) {
    console.error('Error generating page:', error);
  }
}

// Execute if running directly (for Node.js environments)
if (require.main === module) {
  // Note: This requires OPENAI_API_KEY to be set in the environment.
  main();
}

export { generateProgrammaticPage };
