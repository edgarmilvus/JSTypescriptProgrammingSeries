/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// app/actions/generatePageContent.ts

'use server';

import { generateObject } from 'ai';
import { openai } from '@ai-sdk/openai';
import { z } from 'zod';
import { db } from '@/lib/db'; // Hypothetical database client
import { redis } from '@/lib/redis'; // Hypothetical cache client

// ============================================================================
// 1. DATA SCHEMA & TYPE DEFINITIONS
// ============================================================================

/**
 * Represents the dynamic parameters passed from the URL or request context.
 * In a pSEO context, these are often derived from the slug structure.
 */
export interface PageParams {
  source: string;      // e.g., 'slack'
  target: string;      // e.g., 'salesforce'
  industry: string;    // e.g., 'fintech'
}

/**
 * Represents the raw data fetched from the database or CSV source.
 */
interface DataSource {
  id: string;
  sourceName: string;
  targetName: string;
  industry: string;
  integrationType: 'native' | 'api' | 'third-party';
  keyFeatures: string[];
  estimatedCost: number;
}

/**
 * The structured output schema for the AI-generated content.
 * This ensures the GPT-4 response is predictable and type-safe.
 */
const AiContentSchema = z.object({
  metaTitle: z.string().max(60, "Title too long for SEO"),
  metaDescription: z.string().max(160, "Description too long"),
  h1Heading: z.string(),
  summaryParagraph: z.string(),
});

type AiContent = z.infer<typeof AiContentSchema>;

/**
 * The final page object combining data sources, AI-generated content,
 * and SEO metadata.
 */
export interface ProgrammaticPage {
  slug: string;
  dataSource: DataSource;
  aiContent: AiContent;
  lastGenerated: Date;
}

// ============================================================================
// 2. CORE LOGIC: DYNAMIC PARAMETER HANDLING & CACHING
// ============================================================================

/**
 * Orchestrates the generation of a programmatic page.
 * 
 * Why Server Action? 
 * - Security: API keys (OpenAI, Redis) never leave the server.
 * - Performance: Reduces client-side bundle size.
 * - DX: Simplifies data fetching logic for the client component.
 * 
 * @param params - The dynamic URL parameters (source, target, industry).
 * @returns Promise<ProgrammaticPage> - The fully constructed page data.
 */
export async function generateIntegrationPage(
  params: PageParams
): Promise<ProgrammaticPage> {
  const { source, target, industry } = params;
  const slug = `${source}-to-${target}-integration-guide-${industry}`;

  // ---------------------------------------------------------
  // Step 1: Check Cache (Redis)
  // ---------------------------------------------------------
  // In pSEO, we generate thousands of pages. We must avoid re-generating
  // content on every request. We cache the final HTML or the data object.
  const cacheKey = `page:${slug}`;
  const cachedPage = await redis.get<ProgrammaticPage>(cacheKey);
  
  if (cachedPage) {
    console.log(`[Cache Hit] Serving from Redis: ${slug}`);
    return cachedPage;
  }

  // ---------------------------------------------------------
  // Step 2: Fetch Structured Data (The "Source of Truth")
  // ---------------------------------------------------------
  // This simulates fetching a row from a database or CSV based on the
  // dynamic parameters.
  const dataSource = await db.integration.findFirst({
    where: {
      sourceName: source,
      targetName: target,
      industry: industry,
    },
  });

  if (!dataSource) {
    throw new Error(`No data found for combination: ${source} + ${target} + ${industry}`);
  }

  // ---------------------------------------------------------
  // Step 3: Generate Modular Content via GPT-4
  // ---------------------------------------------------------
  // We use 'generateObject' from Vercel AI SDK. This enforces the
  // AiContentSchema, preventing hallucinations from breaking the page structure.
  // This is the "Modular Content Generation" strategy.
  const prompt = `
    You are an SEO expert writing a technical integration guide.
    Context:
    - Source Software: ${dataSource.sourceName}
    - Target Software: ${dataSource.targetName}
    - Industry: ${dataSource.industry}
    - Integration Type: ${dataSource.integrationType}
    - Key Features: ${dataSource.keyFeatures.join(', ')}
    
    Generate a title, meta description, H1, and a 2-sentence summary
    tailored for developers in the ${industry} sector.
  `;

  const { object: aiContent } = await generateObject({
    model: openai('gpt-4-turbo-preview'),
    schema: AiContentSchema,
    prompt: prompt,
    temperature: 0.3, // Lower temp for consistency in programmatic generation
  });

  // ---------------------------------------------------------
  // Step 4: Construct Final Page Object
  // ---------------------------------------------------------
  const pageData: ProgrammaticPage = {
    slug,
    dataSource,
    aiContent,
    lastGenerated: new Date(),
  };

  // ---------------------------------------------------------
  // Step 5: Cache the Result
  // ---------------------------------------------------------
  // Set a TTL (Time To Live) to allow for future data updates.
  await redis.setex(cacheKey, 3600, JSON.stringify(pageData)); // 1 hour TTL

  return pageData;
}

// ============================================================================
// 3. ADVANCED: BATCH GENERATION FOR BUILD TIME
// ============================================================================

/**
 * A utility function used during the build process (getStaticPaths)
 * to pre-generate pages for all valid parameter combinations.
 * 
 * This ensures high Core Web Vitals by serving static HTML.
 */
export async function generateAllPages(): Promise<string[]> {
  // Fetch all unique combinations from the database
  const allCombinations = await db.integration.findMany({
    select: { sourceName: true, targetName: true, industry: true },
    distinct: ['sourceName', 'targetName', 'industry']
  });

  const slugs: string[] = [];

  for (const combo of allCombinations) {
    // We generate the content ahead of time.
    // In a real scenario, this would write to a .json file or 
    // trigger a build hook.
    const page = await generateIntegrationPage(combo);
    slugs.push(page.slug);
  }

  return slugs;
}
