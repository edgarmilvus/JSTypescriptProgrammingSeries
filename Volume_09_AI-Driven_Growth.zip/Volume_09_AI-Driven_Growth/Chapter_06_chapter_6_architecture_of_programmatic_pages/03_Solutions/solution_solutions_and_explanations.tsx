/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.tsx
// Description: Solutions and Explanations
// ==========================================

import React from 'react';

// 1. Define the PageEntity interface
export interface PageEntity {
  id: string;
  title: string;
  description: string;
  features: string[];
  metadata: { keywords: string; lastUpdated: string };
}

// 2. Define the component props
interface DynamicPageTemplateProps {
  data: PageEntity;
}

// 3. Implement the component
const DynamicPageTemplate: React.FC<DynamicPageTemplateProps> = ({ data }) => {
  // Destructure data for cleaner JSX
  const { title, description, features, metadata } = data;

  return (
    <article className="page-container">
      {/* Render Title */}
      <h1>{title}</h1>

      {/* Render Description */}
      <p>{description}</p>

      {/* 
        Render Features List 
        Requirement: Handle empty array gracefully by rendering nothing.
        We use a conditional check to ensure the <ul> is only rendered if features exist.
      */}
      {features && features.length > 0 && (
        <section className="features-section">
          <h2>Key Features</h2>
          <ul>
            {features.map((feature, index) => (
              <li key={index}>{feature}</li>
            ))}
          </ul>
        </section>
      )}

      {/* Render Metadata Footer */}
      <footer className="metadata-footer">
        <div className="keywords">
          <strong>Keywords:</strong> {metadata.keywords}
        </div>
        <div className="last-updated">
          <em>Last Updated:</em> {metadata.lastUpdated}
        </div>
      </footer>
    </article>
  );
};

export default DynamicPageTemplate;
