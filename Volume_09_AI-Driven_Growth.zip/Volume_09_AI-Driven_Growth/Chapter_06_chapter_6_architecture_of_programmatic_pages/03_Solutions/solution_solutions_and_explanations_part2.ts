/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

// Reusing the PageEntity interface from Exercise 1
interface PageEntity {
  id: string;
  title: string;
  description: string;
  features: string[];
  metadata: { keywords: string; lastUpdated: string };
}

// 1. Mock Database
const mockDatabase: PageEntity[] = [
  {
    id: 'tech-gadgets',
    title: 'Top Tech Gadgets 2024',
    description: 'A curated list of the best gadgets.',
    features: ['Smartphone X', 'Laptop Pro', 'Wireless Buds'],
    metadata: { keywords: 'tech, gadgets, 2024', lastUpdated: '2023-10-25' }
  },
  {
    id: 'coffee-makers',
    title: 'Best Espresso Machines',
    description: 'Brew cafe-quality coffee at home.',
    features: ['Machine A', 'Machine B'],
    metadata: { keywords: 'coffee, espresso, home brewing', lastUpdated: '2023-11-01' }
  },
  {
    id: 'hiking-trails',
    title: 'Top 10 Hiking Trails',
    description: 'Explore nature like never before.',
    features: ['Trail 1', 'Trail 2', 'Trail 3'],
    metadata: { keywords: 'hiking, nature, outdoors', lastUpdated: '2023-09-15' }
  },
  {
    id: 'ai-tools',
    title: 'AI Productivity Tools',
    description: 'Boost your workflow with AI.',
    features: ['Tool A', 'Tool B', 'Tool C'],
    metadata: { keywords: 'ai, productivity, automation', lastUpdated: '2023-12-01' }
  },
  {
    id: 'gardening-tips',
    title: 'Beginner Gardening Guide',
    description: 'Start your garden today.',
    features: ['Soil Prep', 'Watering Basics'],
    metadata: { keywords: 'gardening, plants, outdoors', lastUpdated: '2023-08-20' }
  }
];

// 2. Async function to get page data by slug
const getPageDataBySlug = async (slug: string): Promise<PageEntity | null> => {
  // Simulate network delay of 500ms
  await new Promise(resolve => setTimeout(resolve, 500));

  // Search the mock database
  const entity = mockDatabase.find(item => item.id === slug);

  if (entity) {
    return entity;
  }
  
  return null;
};

// 3. Demonstration of usage (Mocking a framework's getServerSideProps)
const mockGetServerSideProps = async (slug: string) => {
  console.log(`Fetching data for slug: ${slug}...`);
  
  try {
    const data = await getPageDataBySlug(slug);
    
    if (!data) {
      console.log("404: Entity not found.");
      return { notFound: true };
    }

    console.log("Data fetched successfully:", data);
    return { props: { data } };
  } catch (error) {
    console.error("Error fetching data:", error);
    return { props: { error: "Failed to load" } };
  }
};

// Example Usage:
// mockGetServerSideProps('tech-gadgets');
// mockGetServerSideProps('invalid-slug');
