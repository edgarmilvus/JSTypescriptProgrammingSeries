/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState, useEffect } from 'react';

// Reusing PageEntity from Exercise 1
interface PageEntity {
  id: string;
  title: string;
  description: string;
  features: string[];
  metadata: { keywords: string; lastUpdated: string };
}

// 1. Define AI Content Request Interface
interface AIContentRequest {
  topic: string;
  tone: 'professional' | 'casual';
}

// 2. Mock AI Generation Function
const generateAIDescription = async (request: AIContentRequest): Promise<string> => {
  // Simulate a 1-second API delay
  await new Promise(resolve => setTimeout(resolve, 1000));
  
  // Return a mock generated string
  return `Generated ${request.tone} description for topic: ${request.topic}. This content is dynamically created to enhance the user experience.`;
};

// 3. Component Implementation
const AIGeneratedPage: React.FC<{ data: PageEntity }> = ({ data }) => {
  // State for the generated content
  const [generatedContent, setGeneratedContent] = useState<string>('');
  // State to handle loading status
  const [isLoading, setIsLoading] = useState<boolean>(false);

  useEffect(() => {
    // Function to fetch AI content
    const fetchAIContent = async () => {
      setIsLoading(true);
      try {
        // Prepare the request based on incoming data
        const request: AIContentRequest = {
          topic: data.title,
          tone: 'professional' // Defaulting to professional, could be dynamic
        };

        const description = await generateAIDescription(request);
        setGeneratedContent(description);
      } catch (error) {
        console.error("Failed to generate AI content", error);
        setGeneratedContent("Content generation failed.");
      } finally {
        setIsLoading(false);
      }
    };

    // Trigger fetch only if data exists and has an ID
    if (data && data.id) {
      fetchAIContent();
    }
  }, [data.id]); // Dependency array ensures this runs when the specific data entity changes

  return (
    <div className="ai-page-container">
      <h1>{data.title}</h1>

      {/* Render Loading State or Generated Content */}
      {isLoading ? (
        <div className="loading-indicator">
          <p>Generating AI content...</p>
        </div>
      ) : (
        generatedContent && (
          <blockquote className="ai-generated-blockquote">
            "{generatedContent}"
          </blockquote>
        )
      )}

      <p>{data.description}</p>
      {/* ... rest of the component ... */}
    </div>
  );
};

export default AIGeneratedPage;
