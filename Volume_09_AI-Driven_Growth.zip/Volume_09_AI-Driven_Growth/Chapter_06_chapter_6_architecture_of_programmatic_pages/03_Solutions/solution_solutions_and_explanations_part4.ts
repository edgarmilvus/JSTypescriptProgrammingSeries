/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

// 1. Interface Definition (Reused)
interface PageEntity {
  id: string;
  title: string;
  description: string;
  features: string[];
  metadata: { keywords: string; lastUpdated: string };
}

// 2. SEO Metadata Interface (Output)
interface SEOMetadata {
  title: string;
  description: string;
  keywords: string;
  openGraph: {
    title: string;
    description: string;
  };
}

// 3. Implementation of generateSEOmetadata
const generateSEOmetadata = (data: PageEntity): SEOMetadata => {
  // Handle Title
  const formattedTitle = `${data.title} | MySite`;

  // Handle Description Truncation
  const MAX_DESC_LENGTH = 160;
  let formattedDescription = data.description;
  if (formattedDescription.length > MAX_DESC_LENGTH) {
    formattedDescription = formattedDescription.substring(0, MAX_DESC_LENGTH) + '...';
  }

  // Handle Keywords Fallback
  const formattedKeywords = data.metadata.keywords && data.metadata.keywords.length > 0
    ? data.metadata.keywords
    : 'programmatic seo, dynamic content';

  // Construct Return Object
  return {
    title: formattedTitle,
    description: formattedDescription,
    keywords: formattedKeywords,
    openGraph: {
      title: formattedTitle,
      description: formattedDescription
    }
  };
};

// 4. Test Suite (Jest/Vitest Syntax)
// To run these, you would typically use a test runner like Jest or Vitest.
// Below is the logic for the test cases.

/*
import { describe, it, expect } from 'vitest'; // or 'jest'

describe('generateSEOmetadata', () => {
  // Test Case 1: Standard Input
  it('should generate correct metadata for standard input', () => {
    const mockData: PageEntity = {
      id: '1',
      title: 'Test Product',
      description: 'A standard description.',
      features: ['Feature 1'],
      metadata: { keywords: 'test, product', lastUpdated: '2023-01-01' }
    };

    const result = generateSEOmetadata(mockData);

    expect(result.title).toBe('Test Product | MySite');
    expect(result.description).toBe('A standard description.');
    expect(result.keywords).toBe('test, product');
  });

  // Test Case 2: Long Description (Truncation)
  it('should truncate description longer than 160 characters', () => {
    const longDesc = 'a'.repeat(200); // 200 'a's
    const mockData: PageEntity = {
      id: '2',
      title: 'Long Text',
      description: longDesc,
      features: [],
      metadata: { keywords: '', lastUpdated: '2023-01-01' }
    };

    const result = generateSEOmetadata(mockData);

    expect(result.description.length).toBe(163); // 160 chars + '...'
    expect(result.description.endsWith('...')).toBe(true);
    expect(result.openGraph.description).toBe(result.description); // Ensure OG matches
  });

  // Test Case 3: Missing Keywords (Fallback)
  it('should use default keywords when metadata.keywords is empty', () => {
    const mockData: PageEntity = {
      id: '3',
      title: 'No Keywords',
      description: 'Description here.',
      features: [],
      metadata: { keywords: '', lastUpdated: '2023-01-01' }
    };

    const result = generateSEOmetadata(mockData);

    expect(result.keywords).toBe('programmatic seo, dynamic content');
  });
});
*/
