/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part2.ts
// Description: Theoretical Foundations
// ==========================================

// This function demonstrates the principle of assembling a prompt from data.
// It does NOT call the LLM, but prepares the instruction set.
function assembleDynamicPrompt(product: ProductData): string {
    // 1. System Role (Constant)
    const systemRole = `You are an expert SEO copywriter for athletic gear. Your task is to write a compelling, unique landing page.`;

    // 2. Contextual Blueprint (Derived from Data)
    const context = `
    The product to write about is: ${product.productName}.
    It belongs to the category: ${product.category}.
    The primary target audience is the '${product.targetPersona}' persona.
    You MUST integrate the following primary keywords naturally: ${product.primaryKeywords.join(', ')}.
    `;

    // 3. Data Injection (Raw Material)
    const dataInjection = `
    Here are the specific product attributes you must highlight:
    - Material: ${product.attributes.material}
    - Heel Drop: ${product.attributes['heel-drop']}mm
    - Arch Support: ${product.attributes['arch-support']}
    - Weight: ${product.attributes.weight}g

    Here are unique selling points to feature:
    ${product.sellingPoints.map(p => `- ${p}`).join('\n')}
    `;

    // 4. Few-Shot Example (The "Golden Copy")
    const fewShotExample = `
    Example of desired output structure for a different product:
    <start_example>
    ## Unleash Your Potential with the 'Velocity Pro'

    For the dedicated runner, every millisecond counts. The Velocity Pro, crafted from lightweight **AeroWeave Mesh**, is engineered for speed.

    ### Optimized for Your Stride
    With a low **8mm heel-drop**, this shoe promotes a natural, mid-foot strike, reducing strain and improving efficiency. The **high arch support** system cradles your foot, providing stability during long-distance runs.

    <end_example>
    `;

    // Final Assembly
    return `${systemRole}\n\n${context}\n\n${dataInjection}\n\n${fewShotExample}\n\nNow, generate the landing page for ${product.productName}:`;
}
