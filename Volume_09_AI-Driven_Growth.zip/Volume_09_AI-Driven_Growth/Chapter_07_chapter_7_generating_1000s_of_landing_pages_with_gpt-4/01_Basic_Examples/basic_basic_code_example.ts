/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

// ==========================================
// 1. CONFIGURATION & TYPE DEFINITIONS
// ==========================================

import OpenAI from 'openai';

// Configuration for the OpenAI client
const CONFIG = {
  apiKey: process.env.OPENAI_API_KEY || '',
  model: 'gpt-4-turbo-preview',
  maxTokens: 300,
} as const;

/**
 * Represents a single row of data used to generate a page.
 * In a real scenario, this comes from a CSV, database, or API.
 */
interface CityData {
  name: string;
  country: string;
  population: number;
  primaryAttraction: string;
}

/**
 * Represents the structured output we expect from GPT-4.
 * We force the model to return JSON matching this interface.
 */
interface GeneratedContent {
  metaTitle: string;
  h1Heading: string;
  description: string;
  localFact: string;
}

// ==========================================
// 2. THE DYNAMIC PROMPT TEMPLATE
// ==========================================

/**
 * Constructs a prompt string dynamically based on the city data.
 * This ensures context is injected into the LLM for every iteration.
 * 
 * @param city - The data object for the specific city
 * @returns A string prompt instructing GPT-4
 */
const createPrompt = (city: CityData): string => {
  return `
    You are an SEO content generator for a travel SaaS platform.
    Generate a landing page section for the city: ${city.name}, ${city.country}.
    
    Context:
    - Population: ${city.population}
    - Main Attraction: ${city.primaryAttraction}
    
    Instructions:
    1. Create a compelling meta title (max 60 chars).
    2. Create an H1 heading.
    3. Write a 2-sentence description highlighting the attraction.
    4. Provide one unique "Local Fact" about the city.
    
    Output Requirement:
    Return ONLY valid JSON matching this structure:
    {
      "metaTitle": "string",
      "h1Heading": "string",
      "description": "string",
      "localFact": "string"
    }
    Do not include markdown formatting or conversational text.
  `;
};

// ==========================================
// 3. THE GENERATION ENGINE (LLM INTERFACE)
// ==========================================

/**
 * Interacts with the OpenAI API to generate content.
 * Handles the API call and parsing of the response.
 * 
 * @param prompt - The fully constructed prompt string
 * @returns A Promise resolving to the GeneratedContent object
 */
const generateContent = async (prompt: string): Promise<GeneratedContent> => {
  const openai = new OpenAI({ apiKey: CONFIG.apiKey });

  try {
    const completion = await openai.chat.completions.create({
      model: CONFIG.model,
      messages: [{ role: 'user', content: prompt }],
      temperature: 0.7, // Adds some creativity while staying factual
      response_format: { type: 'json_object' }, // Crucial for structured data
    });

    const content = completion.choices[0].message.content;
    
    if (!content) {
      throw new Error('Empty response from LLM');
    }

    // Parse the JSON string returned by the LLM
    return JSON.parse(content) as GeneratedContent;

  } catch (error) {
    console.error('Error generating content:', error);
    // In a production app, implement retry logic or fallback content here
    throw error;
  }
};

// ==========================================
// 4. PAGE COMPILATION (TEMPLATE ENGINE)
// ==========================================

/**
 * Compiles the generated text into a basic HTML string.
 * This simulates the final step of creating the landing page file.
 * 
 * @param city - The source data
 * @param content - The AI-generated content
 * @returns A string of HTML
 */
const compilePageHTML = (city: CityData, content: GeneratedContent): string => {
  return `
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>${content.metaTitle}</title>
    <meta name="description" content="${content.description}">
</head>
<body>
    <header>
        <h1>${content.h1Heading}</h1>
    </header>
    <main>
        <section class="intro">
            <p>${content.description}</p>
        </section>
        <section class="facts">
            <h2>Did you know?</h2>
            <p>${content.localFact}</p>
        </section>
        <footer>
            <p>Data for ${city.name}, ${city.country} (Pop: ${city.population.toLocaleString()})</p>
        </footer>
    </main>
</body>
</html>
`;
};

// ==========================================
// 5. MAIN EXECUTION LOOP
// ==========================================

/**
 * The main driver function. 
 * Iterates over the dataset, generates content, and compiles pages.
 */
const main = async () => {
  // Mock Dataset (In reality, this would be loaded from a CSV file)
  const dataset: CityData[] = [
    { name: 'Tokyo', country: 'Japan', population: 13960000, primaryAttraction: 'Shibuya Crossing' },
    { name: 'Paris', country: 'France', population: 2161000, primaryAttraction: 'Eiffel Tower' },
    { name: 'New York', country: 'USA', population: 8400000, primaryAttraction: 'Central Park' },
  ];

  console.log(`🚀 Starting generation for ${dataset.length} cities...`);

  // Process each city sequentially (simplified for example)
  for (const city of dataset) {
    console.log(`\nProcessing: ${city.name}...`);
    
    try {
      // 1. Generate the prompt
      const prompt = createPrompt(city);
      
      // 2. Get content from GPT-4
      const content = await generateContent(prompt);
      
      // 3. Compile the HTML
      const html = compilePageHTML(city, content);
      
      // 4. Output (In production, this would save to a file or database)
      console.log(`✅ Generated page for ${city.name}:`);
      console.log(`   Title: ${content.metaTitle}`);
      console.log(`   HTML Length: ${html.length} chars`);
      
      // Simulate saving to disk (uncomment to actually save)
      // require('fs').writeFileSync(`./dist/${city.name.toLowerCase()}.html`, html);
      
    } catch (error) {
      console.error(`❌ Failed to generate page for ${city.name}`);
    }
  }

  console.log('\n🎉 Batch generation complete.');
};

// Execute the script
// Note: In a real environment, you would wrap this in a check to ensure it runs only when intended.
if (require.main === module) {
  // Check for API key before running
  if (!CONFIG.apiKey) {
    console.error('Error: OPENAI_API_KEY environment variable is missing.');
  } else {
    main();
  }
}

export { generateContent, compilePageHTML };
