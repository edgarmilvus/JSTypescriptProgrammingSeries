/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.ts
// Description: Basic Code Example
// ==========================================

digraph G {
    rankdir=TB;
    node [shape=box, style="rounded,filled", color="#e0e0e0"];
    
    Source [label="CSV/Database\n(City Data)", fillcolor="#bbdefb"];
    Prompt [label="Dynamic Prompt\nGenerator", fillcolor="#fff9c4"];
    LLM [label="GPT-4 API\n(Inference)", fillcolor="#c8e6c9"];
    Content [label="Structured JSON\n(Content Fragments)", fillcolor="#e1bee7"];
    Template [label="HTML Template\nCompiler", fillcolor="#ffccbc"];
    Output [label="Final Landing Page\n(.html file)", fillcolor="#b2dfdb"];

    Source -> Prompt [label="1. Iterate Row"];
    Prompt -> LLM [label="2. Send Prompt"];
    LLM -> Content [label="3. Return JSON"];
    Content -> Template [label="4. Inject Data"];
    Template -> Output [label="5. Save File"];
}
