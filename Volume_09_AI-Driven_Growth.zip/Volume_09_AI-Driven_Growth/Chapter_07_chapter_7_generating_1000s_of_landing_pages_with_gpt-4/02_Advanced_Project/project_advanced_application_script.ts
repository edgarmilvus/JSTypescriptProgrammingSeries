/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// app/actions/generatePages.ts
'use server';

import { OpenAI } from 'openai';
import { z } from 'zod';
import { zodResponseFormat } from 'openai/zod';

// 1. CONFIGURATION & TYPES
// --------------------------------------------------
const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY!,
});

// Schema for the input data (e.g., from a CSV upload)
const KeywordSchema = z.object({
  keyword: z.string().min(1),
  intent: z.enum(['informational', 'commercial', 'transactional']),
  volume: z.number().optional(),
});

type KeywordData = z.infer<typeof KeywordSchema>;

// Schema for the structured output from GPT-4
// This ensures the generated content is strictly typed and valid JSON.
const LandingPageSchema = z.object({
  title: z.string(),
  metaDescription: z.string().max(160),
  h1Header: z.string(),
  bodyContent: z.string().min(500),
  ctaText: z.string(),
  slug: z.string(),
});

type GeneratedPage = z.infer<typeof LandingPageSchema>;

/**
 * SERVER ACTION: generateLandingPages
 * 
 * @param {KeywordData[]} keywords - Array of keyword objects to process.
 * @returns {Promise<GeneratedPage[]>} - Array of generated page data ready for DB insertion.
 * 
 * UNDER THE HOOD:
 * This function executes exclusively on the server. It iterates through the keyword list,
 * constructs a dynamic prompt using Few-Shot examples, and requests a structured JSON response.
 * We use Zod for runtime type validation to prevent malformed data from entering our database.
 */
export async function generateLandingPages(
  keywords: KeywordData[]
): Promise<GeneratedPage[]> {
  if (!keywords || keywords.length === 0) return [];

  const generatedPages: GeneratedPage[] = [];

  // 2. FEW-SHOT PROMPTING DEFINITION
  // --------------------------------------------------
  // We provide high-quality examples to guide the model's style and format.
  // This is crucial for maintaining brand voice across thousands of pages.
  const systemPrompt = `
    You are an expert SEO copywriter for "NexusFlow", a project management SaaS.
    Generate a unique landing page based on the provided keyword and intent.
    Strictly adhere to the JSON schema provided.
    
    EXAMPLE 1:
    Input: { keyword: "agile workflow", intent: "informational" }
    Output: {{ "title": "Agile Workflow Management Guide | NexusFlow", "metaDescription": "Learn how to implement an agile workflow for your team using NexusFlow's intuitive boards.", "h1Header": "Streamline Your Agile Workflow", "bodyContent": "Implementing an agile workflow requires...", "ctaText": "Start Your Free Trial", "slug": "agile-workflow-guide" }}

    EXAMPLE 2:
    Input: { keyword: "kanban board software", intent: "commercial" }
    Output: {{ "title": "Best Kanban Board Software for 2024", "metaDescription": "Compare the top kanban board software options. Why NexusFlow is the leading choice for agile teams.", "h1Header": "Visualize Your Tasks with Kanban", "bodyContent": "Kanban boards are essential for...", "ctaText": "View Pricing", "slug": "kanban-board-software" }}
  `;

  // 3. PROCESSING LOOP & LLM INTERACTION
  // --------------------------------------------------
  for (const item of keywords) {
    try {
      // Construct the user prompt dynamically
      const userPrompt = `
        Keyword: "${item.keyword}"
        Intent: "${item.intent}"
        Volume: ${item.volume || 'N/A'}
      `;

      // Call GPT-4 with structured output capability
      const completion = await openai.chat.completions.create({
        model: 'gpt-4o-mini', // Efficient model for high-volume generation
        messages: [
          { role: 'system', content: systemPrompt },
          { role: 'user', content: userPrompt },
        ],
        response_format: zodResponseFormat(LandingPageSchema, 'landing_page'),
      });

      // Parse and validate the response
      const content = completion.choices[0].message.content;
      if (!content) throw new Error('Empty response from LLM');

      const parsedData = JSON.parse(content);
      const validatedPage = LandingPageSchema.parse(parsedData);

      // Append unique slug based on keyword to prevent collisions
      validatedPage.slug = `${item.keyword.toLowerCase().replace(/\s+/g, '-')}-${item.intent.charAt(0)}`;

      generatedPages.push(validatedPage);
      
      // Rate limiting simulation (crucial for API cost management)
      await new Promise(resolve => setTimeout(resolve, 500));

    } catch (error) {
      console.error(`Failed to generate page for keyword: ${item.keyword}`, error);
      // In production, log to a dead-letter queue for retry logic
    }
  }

  return generatedPages;
}
