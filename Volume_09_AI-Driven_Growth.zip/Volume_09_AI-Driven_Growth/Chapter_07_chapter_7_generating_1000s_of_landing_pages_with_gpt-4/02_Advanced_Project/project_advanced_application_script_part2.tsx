/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script_part2.tsx
// Description: Advanced Application Script
// ==========================================

// app/components/PageGeneratorUI.tsx
'use client';

import { useState } from 'react';
import { generateLandingPages } from '@/app/actions/generatePages';

// 4. CLIENT COMPONENT: WORKFLOW MANAGEMENT
// --------------------------------------------------
export default function PageGeneratorUI() {
  const [isGenerating, setIsGenerating] = useState(false);
  const [progress, setProgress] = useState(0);
  const [results, setResults] = useState<any[]>([]);

  // Mock data representing a CSV upload
  const mockKeywords = [
    { keyword: "remote team collaboration", intent: "commercial" as const, volume: 1200 },
    { keyword: "task automation tools", intent: "informational" as const, volume: 850 },
    { keyword: "project management pricing", intent: "transactional" as const, volume: 400 },
  ];

  const handleGenerate = async () => {
    setIsGenerating(true);
    setProgress(0);
    
    try {
      // We process in batches to avoid UI freezing and manage server load
      const batchSize = 1;
      const pages = [];
      
      for (let i = 0; i < mockKeywords.length; i += batchSize) {
        const batch = mockKeywords.slice(i, i + batchSize);
        const generated = await generateLandingPages(batch);
        pages.push(...generated);
        
        setProgress(Math.round(((i + batchSize) / mockKeywords.length) * 100));
      }

      setResults(pages);
    } catch (error) {
      console.error("Generation failed", error);
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <div className="p-6 border rounded-lg max-w-4xl mx-auto">
      <h2 className="text-xl font-bold mb-4">NexusFlow: Programmatic SEO Generator</h2>
      
      <div className="flex gap-4 mb-6">
        <button
          onClick={handleGenerate}
          disabled={isGenerating}
          className="px-4 py-2 bg-blue-600 text-white rounded disabled:opacity-50"
        >
          {isGenerating ? 'Generating...' : 'Generate Landing Pages'}
        </button>
      </div>

      {isGenerating && (
        <div className="w-full bg-gray-200 rounded h-2 mb-4">
          <div 
            className="bg-blue-600 h-2 rounded transition-all duration-300" 
            style={{ width: `${progress}%` }}
          ></div>
        </div>
      )}

      <div className="space-y-4">
        {results.map((page, idx) => (
          <div key={idx} className="p-4 bg-gray-50 border rounded">
            <h3 className="font-semibold text-lg">{page.title}</h3>
            <p className="text-sm text-gray-600 mb-2">{page.metaDescription}</p>
            <div className="text-xs font-mono bg-gray-200 inline-block px-2 py-1 rounded">
              /{page.slug}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
