/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// 1. Define the ProductData interface as required
interface ProductData {
    productName: string;
    category: string;
    keyFeatures: string[];
    compatibility: string[];
    price: number;
    sku: string;
}

/**
 * Generates a detailed, structured prompt for GPT-4 based on product data.
 * @param data - The product data object.
 * @returns A string containing the full prompt for the LLM.
 */
function generateProductLandingPagePrompt(data: ProductData): string {
    // Construct the prompt using a template literal for readability
    // and to ensure all dynamic data is injected.
    const prompt = `
    You are a Senior SEO Copywriter for a leading Smart Home Technology company. 
    Your task is to write a high-converting landing page for a specific product.

    **Product Details:**
    - **Product Name:** ${data.productName}
    - **Category:** ${data.category}
    - **SKU:** ${data.sku}
    - **Price:** $${data.price.toFixed(2)}

    **Key Features:**
    ${data.keyFeatures.map(feature => `- ${feature}`).join('\n')}

    **Compatibility:**
    ${data.compatibility.map(platform => `- ${platform}`).join('\n')}

    **Instructions:**
    1. Write a compelling marketing summary (1-2 paragraphs) that highlights the value proposition and mentions the price point naturally.
    2. Structure the output using specific HTML tags:
       - Use an <h1> tag for the main product name.
       - Use an <h2> tag for the "Key Features" section.
       - Use an <h2> tag for the "Compatibility" section.
       - Use <p> tags for the marketing summary and other text.
       - Use <ul> and <li> tags to list the features and compatibility details.
    3. Ensure the tone is professional, modern, and persuasive.
    4. Do not include any introductory text or explanations. Output only the HTML content.
    `;

    return prompt.trim();
}

// Example Usage:
// const sampleProduct: ProductData = {
//     productName: "Aura Smart Light Bulb",
//     category: "Lighting",
//     keyFeatures: ["16 million color options", "Energy-efficient LED", "Voice control ready"],
//     compatibility: ["Amazon Alexa", "Google Home"],
//     price: 24.99,
//     sku: "AURA-BULB-001"
// };
// console.log(generateProductLandingPagePrompt(sampleProduct));
