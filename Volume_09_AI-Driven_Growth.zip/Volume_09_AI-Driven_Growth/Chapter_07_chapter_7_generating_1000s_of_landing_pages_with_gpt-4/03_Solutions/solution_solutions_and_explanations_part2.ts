/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

// Re-using the ProductData interface from Exercise 1
interface ProductData {
    productName: string;
    category: string;
    keyFeatures: string[];
    compatibility: string[];
    price: number;
    sku: string;
}

// 1. Define the RawProductInput type with all properties optional
type RawProductInput = {
    [K in keyof ProductData]?: ProductData[K];
};

/**
 * Validates a single raw input object and transforms it into a ProductData object if valid.
 * Uses type narrowing to ensure type safety.
 * @param rawInput - The unknown input object to validate.
 * @returns A ProductData object if valid, otherwise null.
 */
function validateAndTransformInput(rawInput: unknown): ProductData | null {
    // Type Narrowing Step 1: Check if rawInput is a non-null object
    if (!rawInput || typeof rawInput !== 'object') {
        return null;
    }

    // We can now safely cast to 'any' for property access checks,
    // or use a type guard. Here we use 'any' for simplicity in runtime checks.
    const input = rawInput as any;

    // Validation Step: Check for existence and correct types of required fields
    const isValid =
        typeof input.productName === 'string' &&
        typeof input.category === 'string' &&
        Array.isArray(input.keyFeatures) && input.keyFeatures.every((item: any) => typeof item === 'string') &&
        Array.isArray(input.compatibility) && input.compatibility.every((item: any) => typeof item === 'string') &&
        typeof input.price === 'number' &&
        typeof input.sku === 'string';

    if (isValid) {
        // Type Narrowing Step 2: At this point, we have confirmed the object's structure
        // matches the ProductData interface, so we can confidently return it.
        // In a real-world scenario, you might want to create a new object to ensure
        // no extra properties are carried over, but for this exercise, returning the
        // validated object is sufficient.
        return input as ProductData;
    }

    // Return null if validation fails
    return null;
}

/**
 * Processes an array of unknown objects, filtering out invalid ones.
 * @param dataset - An array of unknown objects.
 * @returns A new array containing only valid ProductData objects.
 */
function processProductDataset(dataset: unknown[]): ProductData[] {
    // Use map to apply the validation function and then filter out nulls.
    // This is a clean, functional approach.
    const validProducts = dataset
        .map(item => validateAndTransformInput(item))
        .filter((item): item is ProductData => item !== null); // Type guard for the filter

    return validProducts;
}

// Example Usage:
// const rawDataset = [
//     { productName: "Valid Product", category: "Test", keyFeatures: ["feat1"], compatibility: ["comp1"], price: 10, sku: "SKU1" },
//     { productName: "Invalid Product", price: 20 }, // Missing fields
//     { productName: 123, category: "Test", keyFeatures: [], compatibility: [], price: 30, sku: "SKU3" } // Wrong type
// ];
// console.log(processProductDataset(rawDataset));
