/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

import React from 'react';

// 1. Define the required interface for the job status
interface GenerationJob {
    totalItems: number;
    processedItems: number;
    successfulGenerations: number;
    failedGenerations: number;
    errors: Array<{ sku: string; message: string }>;
    isRunning: boolean;
}

// Define props for the component
interface GenerationStatusDashboardProps {
    job: GenerationJob;
}

/**
 * A purely presentational React component to display the status of a page generation job.
 */
export const GenerationStatusDashboard: React.FC<GenerationStatusDashboardProps> = ({ job }) => {
    // Calculate progress percentage, avoiding division by zero
    const progressPercentage = job.totalItems > 0 
        ? (job.processedItems / job.totalItems) * 100 
        : 0;

    return (
        <div className="status-dashboard">
            {/* Progress Bar */}
            <div className="progress-container" style={{ border: '1px solid #ccc', height: '20px', width: '100%', position: 'relative' }}>
                <div 
                    className="progress-fill"
                    style={{
                        width: `${progressPercentage}%`,
                        height: '100%',
                        backgroundColor: progressPercentage === 100 ? '#4CAF50' : '#2196F3',
                        transition: 'width 0.3s ease'
                    }}
                >
                    {/* Optional: Display percentage text inside the bar */}
                    <span style={{ color: 'white', fontSize: '12px', position: 'absolute', left: '5px', top: '2px' }}>
                        {Math.round(progressPercentage)}%
                    </span>
                </div>
            </div>

            {/* Status Summary */}
            <div className="status-summary" style={{ marginTop: '10px' }}>
                <p><strong>Processed:</strong> {job.processedItems} / {job.totalItems}</p>
                <p style={{ color: 'green' }}><strong>Successful:</strong> {job.successfulGenerations}</p>
                <p style={{ color: 'red' }}><strong>Failed:</strong> {job.failedGenerations}</p>
            </div>

            {/* Error List - Conditional Rendering */}
            {job.errors.length > 0 && (
                <div className="error-list" style={{ marginTop: '15px', border: '1px solid red', padding: '10px', backgroundColor: '#ffebee' }}>
                    <h4>Errors:</h4>
                    <ul>
                        {job.errors.map((error, index) => (
                            <li key={index}>
                                <strong>SKU:</strong> {error.sku} - <span>{error.message}</span>
                            </li>
                        ))}
                    </ul>
                </div>
            )}
        </div>
    );
};
