/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

// 1. Define the GeneratedPage interface
interface GeneratedPage {
    slug: string;
    htmlContent: string;
    metadata: {
        targetKeywords: string[];
        lastGenerated: Date;
    };
}

// 2. Create a mock FileSystem object
const mockFileSystem = {
    // In-memory store to simulate files
    files: new Set<string>(),

    writeFile: async (path: string, content: string): Promise<void> => {
        console.log(`[FileSystem] Writing file to path: ${path}`);
        // Simulate async delay
        await new Promise(resolve => setTimeout(resolve, 100));
        mockFileSystem.files.add(path);
        return Promise.resolve();
    },

    fileExists: async (path: string): Promise<boolean> => {
        // Simulate async delay
        await new Promise(resolve => setTimeout(resolve, 50));
        return mockFileSystem.files.has(path);
    }
};

// 3. Create a mock CMS_API object
const mockCMS_API = {
    publishPage: async (page: GeneratedPage): Promise<{ success: boolean; message: string }> => {
        console.log(`[CMS_API] Attempting to publish page with slug: ${page.slug}`);
        // Simulate async delay
        await new Promise(resolve => setTimeout(resolve, 200));
        // Randomly succeed or fail to simulate real-world conditions
        const isSuccess = Math.random() > 0.2; // 80% chance of success
        if (isSuccess) {
            return { success: true, message: `Page ${page.slug} published successfully.` };
        } else {
            return { success: false, message: `API Error: Failed to publish page ${page.slug}.` };
        }
    }
};

/**
 * Deploys a list of generated pages, handling conflicts and API calls.
 * @param pages - An array of GeneratedPage objects.
 * @returns A summary report of the deployment process.
 */
async function deployPages(pages: GeneratedPage[]) {
    const report = {
        total: pages.length,
        successful: 0,
        failed: 0,
        details: [] as Array<{ slug: string; status: 'SUCCESS' | 'FAILURE'; message: string }>
    };

    for (const page of pages) {
        let currentSlug = page.slug;

        // Step 1: Check for file conflicts
        const fileExists = await mockFileSystem.fileExists(currentSlug);
        if (fileExists) {
            console.log(`[Workflow] Conflict detected for slug: ${currentSlug}. Appending version number.`);
            currentSlug = `${currentSlug}-v2`; // Simple versioning strategy
            console.log(`[Workflow] New slug is: ${currentSlug}`);
        }

        // Step 2: Write file to mock file system
        try {
            await mockFileSystem.writeFile(currentSlug, page.htmlContent);
        } catch (error) {
            const message = `Failed to write file for slug ${currentSlug}`;
            report.failed++;
            report.details.push({ slug: currentSlug, status: 'FAILURE', message });
            continue; // Move to the next page
        }

        // Step 3: Call CMS API to publish
        try {
            const apiResponse = await mockCMS_API.publishPage({ ...page, slug: currentSlug });
            if (apiResponse.success) {
                report.successful++;
                report.details.push({ slug: currentSlug, status: 'SUCCESS', message: apiResponse.message });
            } else {
                report.failed++;
                report.details.push({ slug: currentSlug, status: 'FAILURE', message: apiResponse.message });
            }
        } catch (error) {
            const message = `Unexpected error publishing page ${currentSlug}`;
            report.failed++;
            report.details.push({ slug: currentSlug, status: 'FAILURE', message });
        }
    }

    return report;
}

// Example Usage:
// const pagesToDeploy: GeneratedPage[] = [
//     { slug: 'aura-smart-bulb', htmlContent: '<h1>Aura Bulb</h1>', metadata: { targetKeywords: ['smart bulb'], lastGenerated: new Date() } },
//     { slug: 'smart-thermostat', htmlContent: '<h1>Smart Thermostat</h1>', metadata: { targetKeywords: ['thermostat'], lastGenerated: new Date() } },
//     { slug: 'aura-smart-bulb', htmlContent: '<h1>Aura Bulb V2</h1>', metadata: { targetKeywords: ['smart bulb'], lastGenerated: new Date() } }, // This will cause a conflict
// ];

// deployPages(pagesToDeploy).then(console.log).catch(console.error);
