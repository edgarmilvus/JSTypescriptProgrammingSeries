/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

// Re-using interfaces from previous exercises
interface ProductData {
    productName: string;
    category: string;
    keyFeatures: string[];
    compatibility: string[];
    price: number;
    sku: string;
}

interface GeneratedPage {
    slug: string;
    htmlContent: string;
    metadata: {
        targetKeywords: string[];
        lastGenerated: Date;
    };
}

// 1. Define the GraphState interface as specified
interface GraphState {
    currentStep: 'START' | 'INGESTED' | 'PROMPT_GENERATED' | 'CONTENT_GENERATED' | 'DEPLOYED' | 'ERROR';
    rawData: unknown[] | null;
    validatedData: ProductData[] | null;
    prompts: string[] | null;
    generatedContent: GeneratedPage[] | null;
    errorMessage: string | null;
}

/**
 * The Supervisor Node function.
 * Analyzes the graph state and returns the next agent to invoke or a final status.
 * @param graphState - The current state of the workflow.
 * @returns A string literal indicating the next step or a final/error state.
 */
function supervisorNode(
    graphState: GraphState
): 'DataIngestor' | 'PromptEngineer' | 'ContentGenerator' | 'Deployer' | 'FINISHED' | 'REQUIRES_HUMAN_INTERVENTION' {
    const { currentStep, rawData, validatedData, prompts, generatedContent } = graphState;

    // Logic for transitioning from START
    if (currentStep === 'START') {
        if (rawData && rawData.length > 0) {
            return 'DataIngestor';
        }
        // If no data is provided at the start, the job cannot begin.
        return 'REQUIRES_HUMAN_INTERVENTION';
    }

    // Logic for transitioning from INGESTED
    if (currentStep === 'INGESTED') {
        if (validatedData && validatedData.length > 0) {
            return 'PromptEngineer';
        }
        // If validation resulted in an empty array (or null), there's no valid data to process.
        return 'REQUIRES_HUMAN_INTERVENTION';
    }

    // Logic for transitioning from PROMPT_GENERATED
    if (currentStep === 'PROMPT_GENERATED') {
        if (prompts && prompts.length > 0) {
            return 'ContentGenerator';
        }
        // If prompts are missing or empty, something went wrong in the previous step.
        return 'REQUIRES_HUMAN_INTERVENTION';
    }

    // Logic for transitioning from CONTENT_GENERATED
    if (currentStep === 'CONTENT_GENERATED') {
        if (generatedContent && generatedContent.length > 0) {
            return 'Deployer';
        }
        // If no content was generated, deployment cannot happen.
        return 'REQUIRES_HUMAN_INTERVENTION';
    }

    // Logic for the final step
    if (currentStep === 'DEPLOYED') {
        return 'FINISHED';
    }

    // Catch-all for any ERROR state or unexpected transition
    if (currentStep === 'ERROR') {
        // An error has occurred, manual intervention is required.
        return 'REQUIRES_HUMAN_INTERVENTION';
    }

    // This is a fallback for any state not explicitly handled above.
    return 'REQUIRES_HUMAN_INTERVENTION';
}

// Example Usage:
// const startState: GraphState = {
//     currentStep: 'START',
//     rawData: [{ productName: 'Test' }],
//     validatedData: null,
//     prompts: null,
//     generatedContent: null,
//     errorMessage: null,
// };
// console.log(supervisorNode(startState)); // Output: 'DataIngestor'

// const ingestedState: GraphState = {
//     currentStep: 'INGESTED',
//     rawData: null,
//     validatedData: [{ productName: 'Test', category: 'A', keyFeatures: [], compatibility: [], price: 1, sku: '1' }],
//     prompts: null,
//     generatedContent: null,
//     errorMessage: null,
// };
// console.log(supervisorNode(ingestedState)); // Output: 'PromptEngineer'
