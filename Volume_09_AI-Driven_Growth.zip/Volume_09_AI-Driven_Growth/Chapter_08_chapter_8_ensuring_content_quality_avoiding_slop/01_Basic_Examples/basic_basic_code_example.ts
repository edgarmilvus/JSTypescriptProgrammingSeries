/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

// app/api/generate-content/route.ts
// Next.js App Router API Route (Edge Runtime)

import { NextResponse } from 'next/server';

// -----------------------------------------------------------------------------
// 1. TYPE DEFINITIONS
// -----------------------------------------------------------------------------

/**
 * Represents the output structure from our LLM.
 * Enforcing a schema prevents hallucinated formats.
 */
interface ContentDraft {
  title: string;
  body: string;
  keywords: string[];
}

/**
 * Represents the result of our quality analysis.
 * Used to determine if refinement is needed.
 */
interface QualityScore {
  passed: boolean;
  reasons: string[]; // Specific reasons for failure
  score: number;     // 0-100
}

// -----------------------------------------------------------------------------
// 2. CONFIGURATION & CONSTANTS
// -----------------------------------------------------------------------------

// In a real app, these would be environment variables
const SYSTEM_PROMPT_DRAFT = `You are a helpful assistant. Write a short blog post introduction about a specific topic. 
Return ONLY valid JSON matching this structure: { "title": string, "body": string, "keywords": string[] }`;

const SYSTEM_PROMPT_REFINE = `You are a strict editor. Improve the provided draft based on these specific feedback points: {feedback}. 
Ensure the output is longer, more engaging, and includes the requested keywords. 
Return ONLY valid JSON matching this structure: { "title": string, "body": string, "keywords": string[] }`;

const MIN_WORD_COUNT = 100;
const REQUIRED_KEYWORDS = 2;

// -----------------------------------------------------------------------------
// 3. CORE LOGIC: THE GENERATION PIPELINE
// -----------------------------------------------------------------------------

/**
 * Main entry point for the API Route.
 * Handles the request and streams the response.
 */
export async function POST(req: Request) {
  try {
    const { topic } = await req.json();

    if (!topic) {
      return NextResponse.json({ error: "Topic is required" }, { status: 400 });
    }

    // --- Step 1: Initial Draft Generation ---
    const draft = await generateDraft(topic);

    // --- Step 2: Quality Analysis ---
    const analysis = analyzeQuality(draft);

    // --- Step 3: Conditional Refinement ---
    let finalContent = draft;
    if (!analysis.passed) {
      // If the draft fails, we refine it using the specific failure reasons
      finalContent = await refineDraft(draft, analysis.reasons);
      
      // Re-check the refined content (safety net)
      const reAnalysis = analyzeQuality(finalContent);
      if (!reAnalysis.passed) {
        // If it still fails, we abort to prevent publishing "slop"
        return NextResponse.json(
          { error: "Content quality threshold not met after refinement", details: reAnalysis.reasons },
          { status: 422 } // Unprocessable Entity
        );
      }
    }

    // --- Step 4: Return Result ---
    return NextResponse.json({ 
      success: true, 
      content: finalContent,
      qualityScore: analysis.score 
    });

  } catch (error) {
    console.error("Pipeline Error:", error);
    return NextResponse.json({ error: "Internal Server Error" }, { status: 500 });
  }
}

// -----------------------------------------------------------------------------
// 4. HELPER FUNCTIONS (Simulating LLM Calls & Analysis)
// -----------------------------------------------------------------------------

/**
 * Simulates an LLM call to generate a draft.
 * In production, this would use `fetch` to OpenAI/Anthropic APIs.
 */
async function generateDraft(topic: string): Promise<ContentDraft> {
  // Simulating a network delay
  await new Promise(resolve => setTimeout(resolve, 500));

  // Mock Response (Simulating a potentially weak AI output)
  return {
    title: `Thoughts on ${topic}`,
    body: `This is a very short introduction about ${topic}. It lacks depth.`,
    keywords: [topic]
  };
}

/**
 * Simulates an LLM call to refine content based on feedback.
 */
async function refineDraft(draft: ContentDraft, feedback: string[]): Promise<ContentDraft> {
  // Simulating a network delay
  await new Promise(resolve => setTimeout(resolve, 500));

  // Mock Response (Simulating a corrected, higher quality output)
  return {
    title: `The Ultimate Guide to Mastering ${draft.keywords[0]}`,
    body: `In this comprehensive introduction, we explore the nuances of ${draft.keywords[0]}. ${feedback.join(' ')}. This expanded section provides actionable insights and detailed analysis.`,
    keywords: [...draft.keywords, "strategy", "implementation"]
  };
}

/**
 * Performs deterministic checks on the content.
 * This is the "Anti-Slop" mechanism.
 */
function analyzeQuality(draft: ContentDraft): QualityScore {
  const reasons: string[] = [];
  let score = 100;
  
  // Check 1: Word Count
  const wordCount = draft.body.split(/\s+/).length;
  if (wordCount < MIN_WORD_COUNT) {
    reasons.push(`Body too short (${wordCount}/${MIN_WORD_COUNT} words).`);
    score -= 40;
  }

  // Check 2: Keyword Density
  if (draft.keywords.length < REQUIRED_KEYWORDS) {
    reasons.push(`Insufficient keywords (${draft.keywords.length}/${REQUIRED_KEYWORDS}).`);
    score -= 30;
  }

  // Check 3: Title Quality (Heuristic)
  if (draft.title.length < 10) {
    reasons.push("Title is too vague.");
    score -= 20;
  }

  return {
    passed: reasons.length === 0,
    reasons,
    score: Math.max(0, score)
  };
}
