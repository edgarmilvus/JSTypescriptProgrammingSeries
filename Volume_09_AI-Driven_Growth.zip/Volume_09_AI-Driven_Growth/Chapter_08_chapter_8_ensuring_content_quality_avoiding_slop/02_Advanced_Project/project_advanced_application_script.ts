/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// app/api/generate-article/route.ts

import { NextRequest } from 'next/server';
import { OpenAIStream, StreamingTextResponse } from 'ai';
import OpenAI from 'openai';

// -----------------------------------------------------------------------------
// 1. CONFIGURATION & TYPES
// -----------------------------------------------------------------------------

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY || '',
});

// Define strict typing for our content generation stages
interface ContentRequest {
  topic: string;
  targetKeywords: string[];
  minQualityScore: number; // Threshold for passing validation (0-100)
}

interface ValidationResult {
  score: number;
  passed: boolean;
  feedback: string;
  originalContent: string;
}

// -----------------------------------------------------------------------------
// 2. PROMPT TEMPLATES (FEW-SHOT EXAMPLES)
// -----------------------------------------------------------------------------

/**
 * Few-Shot Prompt for Content Generation.
 * We provide high-quality examples to guide the model's tone and structure,
 * reducing the likelihood of generic or "sloppy" output.
 */
const GENERATION_SYSTEM_PROMPT = `
You are an expert SEO content writer. Your goal is to write a comprehensive, factual article.
Strictly adhere to the user's topic and target keywords.
Avoid fluff, repetition, and generic introductions.
`;

const GENERATION_USER_PROMPT = (topic: string, keywords: string[]) => `
Topic: ${topic}
Target Keywords: ${keywords.join(', ')}

Example of High-Quality Output Structure:
1. Introduction: Hook the reader immediately with a specific insight.
2. Core Concept: Define the topic clearly.
3. Technical Deep Dive: Explain the mechanics using the target keywords naturally.
4. Conclusion: Summarize actionable takeaways.

Generate the article now:
`;

/**
 * Few-Shot Prompt for Quality Evaluation.
 * This acts as the "Human-in-the-Loop" proxy. We give the model examples
 * of what constitutes "Slop" vs. "Quality" to score the generated content.
 */
const EVALUATION_SYSTEM_PROMPT = `
You are a strict Quality Assurance Editor. Analyze the provided content for "Slop".
Slop characteristics: Vague language, missing keywords, hallucinated facts, poor structure.
Score the content from 0 to 100 based on quality.
Provide a brief reason for the score.
`;

const EVALUATION_USER_PROMPT = (content: string, requiredKeywords: string[]) => `
Content to evaluate:
"${content}"

Required Keywords: ${requiredKeywords.join(', ')}

Evaluation Criteria:
1. Keyword Usage (0-30 pts): Are all keywords present and used naturally?
2. Depth (0-40 pts): Is the content specific and technical, or vague?
3. Structure (0-30 pts): Is it readable and well-formatted?

Output format: JSON only. { "score": number, "feedback": string, "passed": boolean }
Evaluate now:
`;

// -----------------------------------------------------------------------------
// 3. CORE LOGIC: THE PIPELINE
// -----------------------------------------------------------------------------

/**
 * Stage 1: Generation
 * Uses Few-Shot prompting to generate the initial draft.
 * @returns Promise<string> - The raw generated content
 */
async function generateContent(topic: string, keywords: string[]): Promise<string> {
  const response = await openai.chat.completions.create({
    model: 'gpt-4-turbo-preview',
    messages: [
      { role: 'system', content: GENERATION_SYSTEM_PROMPT },
      { role: 'user', content: GENERATION_USER_PROMPT(topic, keywords) },
    ],
    temperature: 0.7,
    max_tokens: 1500,
  });

  return response.choices[0]?.message?.content || '';
}

/**
 * Stage 2: Deterministic Quality Scoring (Hybrid Approach)
 * While we use an LLM for evaluation here, in a production high-volume system,
 * we often layer this with deterministic checks (regex, keyword density)
 * before calling the LLM to save costs and latency.
 * 
 * @returns Promise<ValidationResult>
 */
async function validateContent(
  content: string,
  keywords: string[],
  minScoreThreshold: number
): Promise<ValidationResult> {
  // A. Deterministic Pre-check (Cost & Latency Optimization)
  // Check if all target keywords exist in the content using simple regex.
  const missingKeywords = keywords.filter(
    (kw) => !new RegExp(`\\b${kw}\\b`, 'i').test(content)
  );

  if (missingKeywords.length > 0) {
    return {
      score: 0,
      passed: false,
      feedback: `Missing required keywords: ${missingKeywords.join(', ')}`,
      originalContent: content,
    };
  }

  // B. LLM-based Semantic Evaluation (The "Slop" Detector)
  const evaluationResponse = await openai.chat.completions.create({
    model: 'gpt-4-turbo-preview',
    messages: [
      { role: 'system', content: EVALUATION_SYSTEM_PROMPT },
      { role: 'user', content: EVALUATION_USER_PROMPT(content, keywords) },
    ],
    temperature: 0.1, // Low temp for consistent scoring
    response_format: { type: 'json_object' },
  });

  const resultText = evaluationResponse.choices[0]?.message?.content;
  if (!resultText) throw new Error("Evaluation failed");

  const parsedResult = JSON.parse(resultText) as { score: number; feedback: string };
  
  return {
    score: parsedResult.score,
    passed: parsedResult.score >= minScoreThreshold,
    feedback: parsedResult.feedback,
    originalContent: content,
  };
}

// -----------------------------------------------------------------------------
// 4. API ROUTE HANDLER (EDGE RUNTIME)
// -----------------------------------------------------------------------------

export const runtime = 'edge'; // Ensures low latency and efficient concurrency

export async function POST(req: NextRequest) {
  try {
    const body = (await req.json()) as ContentRequest;
    const { topic, targetKeywords, minQualityScore = 70 } = body;

    // Step 1: Initial Generation
    // We stream this generation to the client to show progress.
    // However, in this specific pipeline, we need the *full* text 
    // for the validation stage before we can confidently return it.
    // Strategy: Generate internally -> Validate -> If Pass, Stream final result.
    
    // NOTE: For a true streaming experience with validation, we would typically
    // generate, validate, and then re-stream the validated content. 
    // To keep this example concise and robust, we will generate, validate, 
    // and then stream the final validated content.
    
    const rawContent = await generateContent(topic, targetKeywords);

    // Step 2: Validate (The "Slop" Filter)
    const validation = await validateContent(rawContent, targetKeywords, minQualityScore);

    if (!validation.passed) {
      // Return a non-streaming error response
      return new Response(
        JSON.stringify({ 
          error: 'Content failed quality check.', 
          feedback: validation.feedback,
          score: validation.score 
        }), 
        { status: 400, headers: { 'Content-Type': 'application/json' } }
      );
    }

    // Step 3: Stream the Validated Content
    // Since the content is already generated and validated, we stream it back.
    // In a real scenario, you might save `validation.originalContent` to DB here.
    
    const stream = OpenAIStream(
      await openai.chat.completions.create({
        model: 'gpt-4-turbo-preview',
        messages: [{ role: 'user', content: `Re-format the following validated text for web display: ${validation.originalContent}` }],
        stream: true,
      })
    );

    return new StreamingTextResponse(stream);

  } catch (error) {
    console.error('Pipeline Error:', error);
    return new Response(
      JSON.stringify({ error: 'Internal Server Error' }), 
      { status: 500, headers: { 'Content-Type': 'application/json' } }
    );
  }
}
