/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// Types for our chain
interface RefinementError {
  error: "INSUFFICIENT_QUALITY";
  reason: string;
}

/**
 * Simulates an LLM call for generation.
 * In a real app, this would call an API like OpenAI.
 */
async function callLLM(prompt: string): Promise<string> {
  // Simulate network delay
  await new Promise(resolve => setTimeout(resolve, 500));
  
  // Mock response based on prompt content for demonstration
  if (prompt.includes("Generate a 200-word blog post introduction")) {
    return "Sustainable energy is good and great for the future. It is being developed by many companies. The benefits are many, like being good for the environment. We should all use it.";
  }
  
  // Refinement mock
  if (prompt.includes("Act as a strict editor")) {
    // Extract the text to refine from the prompt (mock logic)
    const contentStart = prompt.indexOf("Text to refine:") + 15;
    const textToRefine = prompt.substring(contentStart).trim();
    
    // Simulate fixing passive voice and vague words
    let refined = textToRefine
      .replace(/is being developed/g, "developers are creating")
      .replace(/good/g, "beneficial")
      .replace(/great/g, "essential");
      
    return refined;
  }
  
  return "Generated content.";
}

/**
 * Stage 1: Generator
 * Focuses on keyword density and basic structure.
 */
export async function generateRawContent(topic: string): Promise<string> {
  const prompt = `
    Generate a 200-word blog post introduction about ${topic}.
    Focus on keyword density for the topic.
    Ensure basic structure is present.
  `;
  return await callLLM(prompt);
}

/**
 * Stage 2: Critic/Refiner
 * Identifies and fixes passive voice, vague language, and checks readability.
 */
export async function refineContent(rawContent: string): Promise<string | RefinementError> {
  // Constraint Handling: Check if content is fundamentally flawed
  const wordCount = rawContent.split(/\s+/).length;
  if (wordCount < 20) {
    return { 
      error: "INSUFFICIENT_QUALITY", 
      reason: "Content is too short (under 20 words)." 
    };
  }

  // Check for factual inconsistencies or major errors (mock check)
  if (rawContent.toLowerCase().includes("false fact")) {
    return {
      error: "INSUFFICIENT_QUALITY",
      reason: "Detected factual inaccuracies."
    };
  }

  const prompt = `
    Act as a strict editor.
    Fix the following text:
    1. Convert passive voice to active voice.
    2. Replace vague adjectives (e.g., "good", "great") with specific terms.
    3. Ensure Flesch-Kincaid reading ease is above 60.
    
    Text to refine: ${rawContent}
  `;

  return await callLLM(prompt);
}

/**
 * Integration: Combined pipeline
 */
export async function generateAndRefine(topic: string): Promise<string | RefinementError> {
  console.log(`Starting generation for topic: ${topic}`);
  
  // Stage 1
  const rawContent = await generateRawContent(topic);
  console.log("Raw content generated:", rawContent);

  // Stage 2
  const finalContent = await refineContent(rawContent);
  
  if (typeof finalContent === 'object' && 'error' in finalContent) {
    console.error("Refinement failed:", finalContent.reason);
    return finalContent;
  }

  console.log("Refinement successful.");
  return finalContent;
}

// Example Usage (Mock Execution)
// generateAndRefine("Sustainable Energy").then(console.log);
