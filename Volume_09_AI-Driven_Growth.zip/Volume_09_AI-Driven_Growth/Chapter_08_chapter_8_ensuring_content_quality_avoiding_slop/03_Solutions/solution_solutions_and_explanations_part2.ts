/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

interface ScoreResult {
  score: number;
  isPublishable: boolean;
}

export class QualityScorer {
  private text: string;
  private primaryKeyword: string;

  constructor(text: string, primaryKeyword: string) {
    this.text = text;
    this.primaryKeyword = primaryKeyword.toLowerCase();
  }

  private getWordCount(): number {
    return this.text.split(/\s+/).filter(w => w.length > 0).length;
  }

  private getSentences(): string[] {
    // Split by common punctuation, filter empty strings
    return this.text.split(/[.!?]+/).filter(s => s.trim().length > 0);
  }

  // Metric 1: Keyword Density (30% weight)
  private calculateKeywordDensity(): number {
    const words = this.text.toLowerCase().split(/\s+/);
    const count = words.filter(w => w === this.primaryKeyword).length;
    const total = words.length;
    
    if (total === 0) return 0;
    
    const density = (count / total) * 100; // Percentage
    
    // Check range 1% to 2.5%
    if (density >= 1 && density <= 2.5) {
      return 100; // Full points
    }
    return 0; // Outside range
  }

  // Metric 2: Sentence Length Variance (30% weight)
  private calculateSentenceVariance(): number {
    const sentences = this.getSentences();
    if (sentences.length < 2) return 0;

    const lengths = sentences.map(s => s.trim().split(/\s+/).length);
    const mean = lengths.reduce((a, b) => a + b, 0) / lengths.length;
    
    const variance = lengths.reduce((sum, len) => sum + Math.pow(len - mean, 2), 0) / lengths.length;
    const stdDev = Math.sqrt(variance);

    // Score 0 if std dev is below 2.0
    if (stdDev < 2.0) return 0;
    return 100;
  }

  // Metric 3: Unique Word Ratio (20% weight)
  private calculateUniqueWordRatio(): number {
    const words = this.text.toLowerCase().split(/\s+/).filter(w => w.length > 0);
    if (words.length === 0) return 0;

    const uniqueWords = new Set(words);
    const ratio = (uniqueWords.size / words.length) * 100;

    // Score 0 if ratio is below 30%
    if (ratio < 30) return 0;
    return 100;
  }

  // Metric 4: Readability Score (20% weight)
  private calculateReadability(): number {
    // Simplified Flesch-Kincaid Grade Level logic for demonstration
    // Real implementation requires syllable counting
    const sentences = this.getSentences();
    const words = this.text.split(/\s+/).filter(w => w.length > 0);
    
    if (sentences.length === 0 || words.length === 0) return 0;

    // Mock calculation: Average sentence length proxy
    const avgSentenceLength = words.length / sentences.length;
    
    // Inverse relationship: Longer sentences = higher grade level
    // Let's map avg length 10-15 words to grade 7-10
    let gradeLevel = 0;
    if (avgSentenceLength < 8) gradeLevel = 5; // Easy
    else if (avgSentenceLength >= 8 && avgSentenceLength <= 12) gradeLevel = 8; // Target
    else gradeLevel = 12; // Hard

    // Full points for grade 7-10
    if (gradeLevel >= 7 && gradeLevel <= 10) return 100;
    // Partial points for 5-6 or 11-12 (simulated as 50)
    if ((gradeLevel >= 5 && gradeLevel <= 6) || (gradeLevel >= 11 && gradeLevel <= 12)) return 50;
    
    return 0;
  }

  public score(): ScoreResult {
    // Edge Cases: Few sentences or words
    const sentences = this.getSentences();
    const wordCount = this.getWordCount();

    if (sentences.length < 3 || wordCount < 50) {
      return { score: 0, isPublishable: false };
    }

    // Calculate weighted average
    const weights = {
      keyword: 0.30,
      variance: 0.30,
      unique: 0.20,
      readability: 0.20
    };

    const metricScores = {
      keyword: this.calculateKeywordDensity(),
      variance: this.calculateSentenceVariance(),
      unique: this.calculateUniqueWordRatio(),
      readability: this.calculateReadability()
    };

    const totalScore = 
      (metricScores.keyword * weights.keyword) +
      (metricScores.variance * weights.variance) +
      (metricScores.unique * weights.unique) +
      (metricScores.readability * weights.readability);

    return {
      score: Math.round(totalScore),
      isPublishable: totalScore >= 75
    };
  }
}

// Example Usage
// const scorer = new QualityScorer("Your sample text here...", "keyword");
// console.log(scorer.score());
