/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState } from 'react';

// 1. Props Interface
interface ContentReviewCardProps {
  contentId: string;
  rawText: string;
  refinedText: string;
  qualityScore: number;
  metrics: {
    keywordDensity: number;
    readability: number;
    sentenceVariance: number;
  };
  onDecision: (decision: 'approve' | 'reject' | 'rewrite', feedback?: string) => void;
}

// 2. Component Definition
export const ContentReviewCard: React.FC<ContentReviewCardProps> = ({
  rawText,
  refinedText,
  qualityScore,
  metrics,
  onDecision,
}) => {
  const [showFeedback, setShowFeedback] = useState(false);
  const [feedbackText, setFeedbackText] = useState('');

  const handleRewriteRequest = () => {
    setShowFeedback(true);
  };

  const handleSubmitDecision = (decision: 'approve' | 'reject' | 'rewrite') => {
    if (decision === 'rewrite' && feedbackText.trim() === '') {
      alert("Please provide feedback for the rewrite.");
      return;
    }
    
    const feedback = decision === 'rewrite' ? feedbackText : undefined;
    onDecision(decision, feedback);
    
    // Reset UI state
    setShowFeedback(false);
    setFeedbackText('');
  };

  return (
    <div style={{ border: '1px solid #ccc', padding: '16px', margin: '16px', borderRadius: '8px' }}>
      <h3>Content Review</h3>
      
      {/* Score Indicator */}
      <div style={{ marginBottom: '12px' }}>
        <strong>Quality Score: {qualityScore}/100</strong>
        <div style={{ background: '#eee', height: '10px', borderRadius: '5px', overflow: 'hidden' }}>
          <div 
            style={{ 
              width: `${qualityScore}%`, 
              background: qualityScore >= 75 ? 'green' : 'orange', 
              height: '100%' 
            }} 
          />
        </div>
      </div>

      {/* Metrics Table */}
      <div style={{ marginBottom: '12px' }}>
        <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '0.9em' }}>
          <thead>
            <tr>
              <th style={{ border: '1px solid #ddd', padding: '4px' }}>Metric</th>
              <th style={{ border: '1px solid #ddd', padding: '4px' }}>Value</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td style={{ border: '1px solid #ddd', padding: '4px' }}>Keyword Density</td>
              <td style={{ border: '1px solid #ddd', padding: '4px' }}>{metrics.keywordDensity}%</td>
            </tr>
            <tr>
              <td style={{ border: '1px solid #ddd', padding: '4px' }}>Readability</td>
              <td style={{ border: '1px solid #ddd', padding: '4px' }}>{metrics.readability}</td>
            </tr>
            <tr>
              <td style={{ border: '1px solid #ddd', padding: '4px' }}>Sentence Variance</td>
              <td style={{ border: '1px solid #ddd', padding: '4px' }}>{metrics.sentenceVariance}</td>
            </tr>
          </tbody>
        </table>
      </div>

      {/* Text Comparison */}
      <div style={{ display: 'flex', gap: '10px' }}>
        <div style={{ flex: 1 }}>
          <label><strong>Raw Text</strong></label>
          <textarea 
            value={rawText} 
            readOnly 
            style={{ width: '100%', height: '100px' }} 
          />
        </div>
        <div style={{ flex: 1 }}>
          <label><strong>Refined Text</strong></label>
          <textarea 
            value={refinedText} 
            readOnly 
            style={{ width: '100%', height: '100px' }} 
          />
        </div>
      </div>

      {/* Actions */}
      <div style={{ marginTop: '16px', display: 'flex', gap: '8px' }}>
        <button onClick={() => handleSubmitDecision('approve')} style={{ background: '#4CAF50', color: 'white', border: 'none', padding: '8px 16px' }}>
          Approve
        </button>
        <button onClick={() => handleSubmitDecision('reject')} style={{ background: '#f44336', color: 'white', border: 'none', padding: '8px 16px' }}>
          Reject
        </button>
        {!showFeedback ? (
          <button onClick={handleRewriteRequest} style={{ background: '#2196F3', color: 'white', border: 'none', padding: '8px 16px' }}>
            Request Rewrite
          </button>
        ) : (
          <div style={{ flex: 1 }}>
            <textarea 
              placeholder="Specific Feedback for AI..."
              value={feedbackText}
              onChange={(e) => setFeedbackText(e.target.value)}
              style={{ width: '100%', marginBottom: '8px' }}
            />
            <button onClick={() => handleSubmitDecision('rewrite')} style={{ background: '#FF9800', color: 'white', border: 'none', padding: '8px 16px' }}>
              Submit Rewrite Request
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

// 3. Mock Application / State Management
export const MockReviewApp: React.FC = () => {
  // Mock queue data
  const [queue, setQueue] = useState([
    {
      id: '1',
      rawText: 'Sustainable energy is good. It is being developed fast.',
      refinedText: 'Sustainable energy is beneficial. Developers are creating it fast.',
      qualityScore: 65,
      metrics: { keywordDensity: 1.5, readability: 8, sentenceVariance: 1.5 }
    },
    {
      id: '2',
      rawText: 'Solar panels capture sunlight. They convert it to electricity.',
      refinedText: 'Solar panels capture sunlight. They convert it to electricity efficiently.',
      qualityScore: 82,
      metrics: { keywordDensity: 2.0, readability: 7, sentenceVariance: 3.0 }
    }
  ]);

  const handleDecision = (id: string, decision: string, feedback?: string) => {
    console.log(`Decision for item ${id}: ${decision}`, feedback ? `Feedback: ${feedback}` : '');

    // Remove item from queue
    setQueue(prev => prev.filter(item => item.id !== id));

    // Simulate rewrite flow
    if (decision === 'rewrite' && feedback) {
      console.log(`Simulating API call for rewrite with prompt: "${feedback}"`);
      // In a real app, you would call an API here and add the new item back to the queue
    }
  };

  return (
    <div>
      <h1>Content Review Queue ({queue.length} items)</h1>
      {queue.length === 0 ? <p>Queue is empty!</p> : null}
      {queue.map(item => (
        <ContentReviewCard
          key={item.id}
          contentId={item.id}
          rawText={item.rawText}
          refinedText={item.refinedText}
          qualityScore={item.qualityScore}
          metrics={item.metrics}
          onDecision={(dec, fb) => handleDecision(item.id, dec, fb)}
        />
      ))}
    </div>
  );
};
