/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

// File: app/api/generate-stream/route.ts
import { NextRequest } from 'next/server';

export const runtime = 'edge'; // Use Edge Runtime

/**
 * Helper to simulate an async delay (non-blocking)
 */
const delay = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

/**
 * Simulates a non-blocking calculation of keyword density based on accumulated text.
 */
async function calculateMetric(textChunk: string, totalWords: number): Promise<number> {
  // Use setImmediate or a microtask to simulate yielding control back to the event loop
  await Promise.resolve(); 
  
  // Simple mock calculation
  const words = textChunk.split(/\s+/);
  const keywordCount = words.filter(w => w === 'ai').length; // Assume 'ai' is the keyword
  if (totalWords === 0) return 0;
  return (keywordCount / totalWords) * 100;
}

export async function POST(req: NextRequest) {
  const { topic } = await req.json();

  // Create a ReadableStream to send data incrementally
  const stream = new ReadableStream({
    async start(controller) {
      const encoder = new TextEncoder();
      
      // Simulate AI generation yielding chunks
      const chunks = [
        "Artificial Intelligence is transforming the world. ",
        "It enables machines to learn from data. ",
        "This technology impacts healthcare and finance significantly. ",
        "Future advancements are expected to accelerate rapidly."
      ];

      let accumulatedText = "";
      let wordCount = 0;

      for (const chunk of chunks) {
        // 1. Send the text chunk
        controller.enqueue(
          encoder.encode(
            JSON.stringify({ type: "chunk", data: chunk }) + "\n"
          )
        );

        // Update state
        accumulatedText += chunk;
        wordCount += chunk.split(/\s+/).length;

        // 2. Perform non-blocking quality analysis
        // We await the delay to simulate processing time and yield to the event loop
        await delay(100); 
        
        const density = await calculateMetric(accumulatedText, wordCount);
        
        controller.enqueue(
          encoder.encode(
            JSON.stringify({ 
              type: "metric_update", 
              metric: "keyword_density", 
              value: parseFloat(density.toFixed(2)) 
            }) + "\n"
          )
        );
      }

      // 3. Send final score
      // Simulate a final calculation delay
      await delay(100);
      controller.enqueue(
        encoder.encode(
          JSON.stringify({ type: "final_score", score: 85 }) + "\n"
        )
      );

      controller.close();
    },
  });

  return new Response(stream, {
    headers: {
      'Content-Type': 'application/x-ndjson', // Newline Delimited JSON
    },
  });
}
