/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * @fileoverview Semantic Internal Linking Engine
 * Simulates vector-based content recommendation for a SaaS blog.
 */

// --- 1. Type Definitions ---

/**
 * Represents a single content node (e.g., a blog post or documentation page).
 */
type ContentNode = {
  id: string;
  title: string;
  body: string;
  vector: number[]; // The embedding vector representing the content
};

/**
 * Represents a recommended link with a relevance score.
 */
type RecommendedLink = {
  targetId: string;
  targetTitle: string;
  score: number; // Cosine similarity score (0 to 1)
};

// --- 2. Vector Simulation & Math Utilities ---

/**
 * Simulates an embedding model by converting text into a numeric vector.
 * 
 * In a production environment, this would call an API like OpenAI's embeddings endpoint.
 * Here, we use a simple hashing algorithm to ensure deterministic output for the example.
 * 
 * @param text - The input string to embed.
 * @param dimensions - The size of the vector (e.g., 1536 for ada-002).
 * @returns A number array representing the vector.
 */
function generateEmbedding(text: string, dimensions: number = 10): number[] {
  const vector: number[] = [];
  let hash = 0;
  
  // Create a simple hash based on character codes
  for (let i = 0; i < text.length; i++) {
    const char = text.charCodeAt(i);
    hash = ((hash << 5) - hash) + char;
    hash = hash & hash; // Convert to 32bit integer
  }

  // Fill vector dimensions based on the hash
  for (let i = 0; i < dimensions; i++) {
    // Pseudo-random number generation based on the initial hash
    const pseudoRandom = Math.abs(Math.sin(hash + i) * 10000) % 1;
    vector.push(pseudoRandom);
  }

  return vector;
}

/**
 * Calculates the Cosine Similarity between two vectors.
 * 
 * Cosine Similarity = (A . B) / (||A|| * ||B||)
 * It measures the cosine of the angle between two vectors in a multi-dimensional space.
 * 
 * @param vecA - First vector
 * @param vecB - Second vector
 * @returns A number between 0 (no similarity) and 1 (identical).
 */
function cosineSimilarity(vecA: number[], vecB: number[]): number {
  if (vecA.length !== vecB.length) {
    throw new Error("Vectors must have the same dimensionality.");
  }

  let dotProduct = 0;
  let normA = 0;
  let normB = 0;

  for (let i = 0; i < vecA.length; i++) {
    dotProduct += vecA[i] * vecB[i];
    normA += vecA[i] * vecA[i];
    normB += vecB[i] * vecB[i];
  }

  if (normA === 0 || normB === 0) return 0;
  
  return dotProduct / (Math.sqrt(normA) * Math.sqrt(normB));
}

// --- 3. The Linking Engine ---

/**
 * Finds the top N semantically similar content nodes.
 * 
 * @param targetNode - The node we are trying to link FROM.
 * @param allNodes - The database of existing content.
 * @param limit - Max number of recommendations.
 * @param threshold - Minimum similarity score (0.0 to 1.0) to accept a link.
 * @returns An array of RecommendedLink objects, sorted by score descending.
 */
function getInternalLinkRecommendations(
  targetNode: ContentNode,
  allNodes: ContentNode[],
  limit: number = 3,
  threshold: number = 0.5
): RecommendedLink[] {
  
  // Filter out the target node itself and calculate scores
  const candidates = allNodes
    .filter(node => node.id !== targetNode.id)
    .map(node => {
      const score = cosineSimilarity(targetNode.vector, node.vector);
      return {
        targetId: node.id,
        targetTitle: node.title,
        score: score
      };
    });

  // Sort by score descending (highest similarity first)
  candidates.sort((a, b) => b.score - a.score);

  // Filter by threshold and limit results
  return candidates
    .filter(c => c.score >= threshold)
    .slice(0, limit);
}

/**
 * Generates HTML markup for a "Read Next" section.
 * 
 * @param links - The recommended links.
 * @returns A string of HTML.
 */
function generateLinkMarkup(links: RecommendedLink[]): string {
  if (links.length === 0) {
    return `<div class="internal-links"><p>No relevant internal links found.</p></div>`;
  }

  const listItems = links.map(link => {
    // Semantic anchor text generation (simplified)
    const anchorText = `Read more about ${link.targetTitle.toLowerCase()}`;
    return `<li><a href="/blog/${link.targetId}" title="Similarity: ${link.score.toFixed(2)}">${anchorText}</a></li>`;
  }).join('\n');

  return `
<div class="internal-links">
  <h3>Related Articles</h3>
  <ul>
    ${listItems}
  </ul>
</div>`;
}

// --- 4. Execution Simulation ---

// A. Mock Database (Content Graph)
const contentDatabase: ContentNode[] = [
  {
    id: "post-101",
    title: "Intro to Vector Databases",
    body: "Vector databases store data as high-dimensional vectors to enable fast similarity search.",
    vector: [] // Populated below
  },
  {
    id: "post-102",
    title: "React Server Components",
    body: "Server Components allow rendering UI on the server, reducing client-side JavaScript bundle size.",
    vector: []
  },
  {
    id: "post-103",
    title: "Semantic Search with AI",
    body: "Using AI embeddings to find contextually relevant data rather than exact keyword matches.",
    vector: []
  },
  {
    id: "post-104",
    title: "CSS Grid Layouts",
    body: "A comprehensive guide to creating complex web layouts using CSS Grid.",
    vector: []
  }
];

// B. Generate Vectors (Simulating the "Training" phase)
console.log("Generating embeddings for content database...");
contentDatabase.forEach(node => {
  // We combine title and body for a richer semantic representation
  node.vector = generateEmbedding(`${node.title} ${node.body}`);
});

// C. Create a New Post (The Target)
const newPost: ContentNode = {
  id: "post-105",
  title: "Building AI Search Features",
  body: "How to implement semantic search using OpenAI embeddings and cosine similarity metrics.",
  vector: generateEmbedding("Building AI Search Features How to implement semantic search using OpenAI embeddings and cosine similarity metrics.")
};

// D. Run the Recommendation Engine
const recommendations = getInternalLinkRecommendations(newPost, contentDatabase);

// E. Output Results
console.log(`\n--- Recommendations for "${newPost.title}" ---`);
console.log(recommendations);

const htmlOutput = generateLinkMarkup(recommendations);
console.log("\n--- Generated HTML Injection ---");
console.log(htmlOutput);

// Export for usage (if this were a module)
export { generateEmbedding, cosineSimilarity, getInternalLinkRecommendations };
