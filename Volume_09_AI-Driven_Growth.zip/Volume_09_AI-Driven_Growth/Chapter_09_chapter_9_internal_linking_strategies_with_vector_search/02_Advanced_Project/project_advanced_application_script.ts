/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// pages/api/generate-links.ts (or app/api/generate-links/route.ts)
import type { NextApiRequest, NextApiResponse } from 'next';

// ============================================================================
// 1. DATA MODELING & INITIALIZATION
// ============================================================================

/**
 * Represents a single page or post in our content system.
 * @typedef {Object} Page
 * @property {string} id - Unique identifier for the page.
 * @property {string} title - The title of the page.
 * @property {string} content - The full text content for semantic analysis.
 * @property {string} slug - The URL-friendly path for the page.
 */
type Page = {
  id: string;
  title: string;
  content: string;
  slug: string;
};

/**
 * Represents a vector embedding for a page.
 * In a real system, this would be a high-dimensional array of numbers (e.g., 1536 dimensions).
 * For this demo, we use a simplified fixed-size array.
 */
type Embedding = number[];

/**
 * Represents a single entry in our vector index, linking a page ID to its vector.
 * This is an immutable data structure; we never modify it in place.
 */
type VectorIndexEntry = {
  pageId: string;
  vector: Embedding;
};

/**
 * Represents the entire vector index, which is an array of entries.
 */
type VectorIndex = VectorIndexEntry[];

/**
 * Represents a linking opportunity discovered by the engine.
 */
type LinkOpportunity = {
  targetPage: Page;
  similarityScore: number; // Cosine similarity score (0 to 1)
  suggestedAnchorText: string;
};

/**
 * Sample content corpus. In a real SaaS app, this would be fetched from a database.
 */
const samplePages: Page[] = [
  {
    id: 'p1',
    title: 'Introduction to Vector Databases',
    content: 'Vector databases are specialized databases designed to store and query high-dimensional vector data, which is essential for AI applications like semantic search and recommendation systems.',
    slug: '/blog/vector-databases-intro',
  },
  {
    id: 'p2',
    title: 'Advanced Python Programming Techniques',
    content: 'This article covers advanced Python topics including decorators, generators, and context managers to write more efficient and readable code.',
    slug: '/blog/advanced-python',
  },
  {
    id: 'p3',
    title: 'Understanding Semantic Search',
    content: 'Semantic search goes beyond keyword matching. It uses AI to understand the contextual meaning of a query, leading to more relevant search results. This is often powered by vector embeddings.',
    slug: '/blog/understanding-semantic-search',
  },
  {
    id: 'p4',
    title: 'A Guide to React and Next.js',
    content: 'Learn how to build modern web applications using React and the Next.js framework. We cover server-side rendering, static site generation, and API routes.',
    slug: '/blog/react-nextjs-guide',
  },
];

// ============================================================================
// 2. EMBEDDING GENERATION (SIMULATION)
// ============================================================================

/**
 * Generates a simulated vector embedding for a given text string.
 * 
 * HOW IT WORKS:
 * - It creates a fixed-size array (e.g., 768 dimensions).
 * - It iterates through the input text, hashing each character to generate a pseudo-random number.
 * - This simulates the process of an LLM converting text into a high-dimensional vector.
 * 
 * WHY THIS IS A SIMULATION:
 * Real embeddings capture semantic meaning. The vector for "dog" would be closer to "puppy" than "car".
 * This simple hash-based approach creates a deterministic but semantically meaningless vector.
 * In production, you would use an API call like: `await openai.createEmbedding({ model: 'text-embedding-ada-002', input: text })`
 *
 * @param {string} text - The input text to embed.
 * @returns {Embedding} - A simulated embedding vector.
 */
function generateEmbedding(text: string): Embedding {
  const DIMENSIONALITY = 768; // Simulate a standard embedding size
  const vector: Embedding = new Array(DIMENSIONALITY).fill(0);
  
  // A simple, deterministic hash function to generate vector values
  let hash = 0;
  for (let i = 0; i < text.length; i++) {
    const char = text.charCodeAt(i);
    hash = ((hash << 5) - hash) + char;
    hash = hash & hash; // Convert to 32-bit integer
  }

  // Populate the vector based on the hash
  for (let i = 0; i < DIMENSIONALITY; i++) {
    // Use a pseudo-random number generator seeded with the hash and index
    const pseudoRandom = Math.abs(Math.sin(hash + i) * 10000);
    vector[i] = pseudoRandom % 1; // Normalize to values between 0 and 1
  }

  return vector;
}

// ============================================================================
// 3. VECTOR INDEX CONSTRUCTION
// ============================================================================

/**
 * Builds an immutable vector index from a list of pages.
 * 
 * IMMUTABLE STATE MANAGEMENT:
 * - This function does not modify any external state.
 * - It takes an array of pages and returns a new `VectorIndex` array.
 * - Each page is processed independently, and a new index entry is created.
 * - This pattern is crucial for predictability in serverless functions and concurrent systems.
 *
 * @param {Page[]} pages - An array of page objects.
 * @returns {VectorIndex} - The newly constructed vector index.
 */
function buildVectorIndex(pages: Page[]): VectorIndex {
  console.log('Building vector index...');
  const index: VectorIndex = pages.map(page => ({
    pageId: page.id,
    vector: generateEmbedding(page.content),
  }));
  console.log(`Index built with ${index.length} entries.`);
  return index;
}

// ============================================================================
// 4. SEMANTIC SEARCH (KNN IMPLEMENTATION)
// ============================================================================

/**
 * Calculates the cosine similarity between two vectors.
 * 
 * UNDER THE HOOD:
 * Cosine similarity measures the cosine of the angle between two vectors.
 * - Score of 1: Vectors are identical (pointing in the same direction).
 * - Score of 0: Vectors are orthogonal (no correlation).
 * - Score of -1: Vectors are opposite (anti-correlated).
 * For embeddings, a higher score means greater semantic similarity.
 *
 * @param {Embedding} vecA - The first vector.
 * @param {Embedding} vecB - The second vector.
 * @returns {number} - The similarity score between 0 and 1.
 */
function cosineSimilarity(vecA: Embedding, vecB: Embedding): number {
  if (vecA.length !== vecB.length) {
    throw new Error('Vectors must have the same dimensionality');
  }

  let dotProduct = 0;
  let normA = 0;
  let normB = 0;

  for (let i = 0; i < vecA.length; i++) {
    dotProduct += vecA[i] * vecB[i];
    normA += vecA[i] * vecA[i];
    normB += vecB[i] * vecB[i];
  }

  if (normA === 0 || normB === 0) {
    return 0; // Avoid division by zero
  }

  return dotProduct / (Math.sqrt(normA) * Math.sqrt(normB));
}

/**
 * Finds the K-Nearest Neighbors for a given source page.
 * 
 * HOW IT WORKS:
 * 1. It retrieves the embedding for the source page.
 * 2. It iterates through every other page in the vector index.
 * 3. For each target page, it calculates the cosine similarity.
 * 4. It sorts the results by similarity score in descending order.
 * 5. It returns the top `k` results.
 *
 * @param {string} sourcePageId - The ID of the page we're finding links for.
 * @param {VectorIndex} index - The complete vector index.
 * @param {Page[]} allPages - The original page data (to retrieve metadata).
 * @param {number} k - The number of neighbors to return.
 * @returns {LinkOpportunity[]} - An array of the top K linking opportunities.
 */
function findKNearestNeighbors(
  sourcePageId: string,
  index: VectorIndex,
  allPages: Page[],
  k: number
): LinkOpportunity[] {
  const sourceEntry = index.find(entry => entry.pageId === sourcePageId);
  if (!sourceEntry) {
    throw new Error(`Source page with ID ${sourcePageId} not found in index.`);
  }

  const opportunities = index
    .filter(entry => entry.pageId !== sourcePageId) // Exclude the page itself
    .map(entry => {
      const targetPage = allPages.find(p => p.id === entry.pageId)!;
      const score = cosineSimilarity(sourceEntry.vector, entry.vector);
      
      // Generate context-aware anchor text
      const suggestedAnchorText = `Learn more about ${targetPage.title.split(' ')[0]}`;

      return {
        targetPage,
        similarityScore: score,
        suggestedAnchorText,
      };
    })
    .filter(op => op.similarityScore > 0.1) // Filter out very low-confidence matches
    .sort((a, b) => b.similarityScore - a.similarityScore) // Sort descending

  return opportunities.slice(0, k);
}

// ============================================================================
// 5. LINK GENERATION & API ENDPOINT
// ============================================================================

/**
 * Next.js API Route Handler
 * 
 * This function handles the incoming request to generate links for a given page.
 * 
 * REQUEST BODY EXPECTED:
 * {
 *   "sourcePageId": "p1" // The ID of the page needing links
 * }
 * 
 * RESPONSE:
 * {
 *   "sourcePageId": "p1",
 *   "opportunities": [ ... ]
 * }
 */
export default function handler(req: NextApiRequest, res: NextApiResponse) {
  // Only allow POST requests
  if (req.method !== 'POST') {
    return res.status(405).json({ message: 'Method Not Allowed' });
  }

  try {
    const { sourcePageId } = req.body;

    if (!sourcePageId) {
      return res.status(400).json({ message: 'Missing sourcePageId in request body.' });
    }

    // Step 1 & 3: Build the vector index from our content corpus.
    // In a real app, this index would be pre-built and stored/retrieved from a database or cache.
    // We rebuild it here for demonstration of the full pipeline.
    const vectorIndex = buildVectorIndex(samplePages);

    // Step 4: Perform the KNN search to find the best linking targets.
    const opportunities = findKNearestNeighbors(sourcePageId, vectorIndex, samplePages, 3);

    // Step 5: Return the structured results.
    const response = {
      sourcePageId,
      opportunities,
    };

    res.status(200).json(response);

  } catch (error) {
    console.error('Error generating links:', error);
    res.status(500).json({ message: 'Internal Server Error' });
  }
}
