/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// types.ts
export interface Article {
  id: string;
  content: string;
}

export interface EmbeddedArticle extends Article {
  vector: number[];
}

// embeddingService.ts
import OpenAI from 'openai';
import * as fs from 'fs/promises';
import { Article, EmbeddedArticle } from './types';

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

/**
 * Generates embeddings for an array of articles using OpenAI's text-embedding-ada-002 model.
 * Skips articles that fail to generate an embedding and logs the error.
 */
export async function generateEmbeddings(articles: Article[]): Promise<EmbeddedArticle[]> {
  const embeddedArticles: EmbeddedArticle[] = [];

  for (const article of articles) {
    try {
      // Check for empty content to avoid API errors
      if (!article.content || article.content.trim() === '') {
        console.warn(`Skipping article ${article.id}: Content is empty.`);
        continue;
      }

      const response = await openai.embeddings.create({
        model: 'text-embedding-ada-002',
        input: article.content,
      });

      const vector = response.data[0].embedding;
      
      embeddedArticles.push({
        id: article.id,
        content: article.content,
        vector: vector,
      });

    } catch (error) {
      // Detailed error logging for debugging
      if (error instanceof Error) {
        console.error(`Error generating embedding for article ${article.id}: ${error.message}`);
      } else {
        console.error(`Unknown error generating embedding for article ${article.id}`);
      }
      // Continue to the next article
    }
  }

  return embeddedArticles;
}

/**
 * Simulates storage by writing the embedded articles to a local JSON file.
 */
export async function storeVectors(embeddedArticles: EmbeddedArticle[]): Promise<void> {
  try {
    // Format the JSON with indentation for readability
    await fs.writeFile('vectors.json', JSON.stringify(embeddedArticles, null, 2));
    console.log(`Successfully stored ${embeddedArticles.length} vectors to vectors.json`);
  } catch (error) {
    if (error instanceof Error) {
      console.error(`Failed to write vectors to file: ${error.message}`);
    }
    throw error;
  }
}
