/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

// similarityService.ts
import * as fs from 'fs/promises';
import { EmbeddedArticle } from './types';

/**
 * Loads embedded articles from the local 'vectors.json' file.
 */
export async function loadVectors(): Promise<EmbeddedArticle[]> {
  try {
    const data = await fs.readFile('vectors.json', 'utf-8');
    return JSON.parse(data);
  } catch (error) {
    if (error instanceof Error) {
      console.error(`Error loading vectors: ${error.message}`);
    }
    throw new Error('Could not load vectors.json. Ensure Exercise 1 has been run successfully.');
  }
}

/**
 * Calculates the cosine similarity between two vectors.
 * Returns a value between -1 and 1.
 */
export function calculateCosineSimilarity(vecA: number[], vecB: number[]): number {
  if (vecA.length !== vecB.length) {
    throw new Error('Vectors must be of the same dimension');
  }

  let dotProduct = 0;
  let normA = 0;
  let normB = 0;

  for (let i = 0; i < vecA.length; i++) {
    dotProduct += vecA[i] * vecB[i];
    normA += vecA[i] * vecA[i];
    normB += vecB[i] * vecB[i];
  }

  // Handle division by zero
  if (normA === 0 || normB === 0) {
    return 0;
  }

  return dotProduct / (Math.sqrt(normA) * Math.sqrt(normB));
}

/**
 * Finds link candidates for a source article based on a similarity threshold.
 */
export async function findLinkCandidates(
  sourceArticleId: string,
  threshold: number
): Promise<{ targetArticleId: string; similarityScore: number }[]> {
  const allArticles = await loadVectors();
  
  const sourceArticle = allArticles.find((article) => article.id === sourceArticleId);
  
  if (!sourceArticle) {
    throw new Error(`Source article with ID '${sourceArticleId}' not found.`);
  }

  const candidates: { targetArticleId: string; similarityScore: number }[] = [];

  for (const targetArticle of allArticles) {
    // Skip comparing the article to itself
    if (targetArticle.id === sourceArticleId) {
      continue;
    }

    const score = calculateCosineSimilarity(sourceArticle.vector, targetArticle.vector);

    if (score > threshold) {
      candidates.push({
        targetArticleId: targetArticle.id,
        similarityScore: score,
      });
    }
  }

  // Sort by similarity score in descending order
  candidates.sort((a, b) => b.similarityScore - a.similarityScore);

  return candidates;
}
