/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

// linkInjectionService.ts
interface LinkCandidate {
  targetArticleId: string;
  targetArticleTitle: string;
  similarityScore: number;
}

/**
 * Injects semantic links into HTML content based on candidate relevance.
 * Avoids injecting links into existing HTML tags.
 */
export function injectSemanticLinks(
  content: string,
  candidates: LinkCandidate[],
  maxLinks: number = 3
): string {
  let modifiedContent = content;
  let linksInjected = 0;

  // Create a regex to find the title text, ensuring it's not inside an HTML tag.
  // The negative lookbehind (?<!<[^>]*) ensures there is no '<' before the match 
  // that hasn't been closed by a '>'.
  // The negative lookahead (?![^<]*>) ensures there is no '>' after the match
  // that hasn't been preceded by a '<'.
  
  for (const candidate of candidates) {
    if (linksInjected >= maxLinks) {
      break;
    }

    const title = candidate.targetArticleTitle;
    const href = `/articles/${candidate.targetArticleId}`;
    const anchorTag = `<a href="${href}">${title}</a>`;

    // Regex explanation:
    // (?<!<[^>]*)  : Negative lookbehind. Asserts the match is not preceded by '<' followed by any characters except '>'.
    // (title)      : The literal title text to match.
    // (?![^<]*>)   : Negative lookahead. Asserts the match is not followed by any characters (except '<') until a '>'.
    // 'gi' flags   : Global (find all) and Case-insensitive.
    const regex = new RegExp(`(?<!<[^>]*)${title}(?![^<]*>)`, 'gi');

    // We only want to replace the *first* occurrence per candidate, 
    // but the 'g' flag in regex helps us scan the string. 
    // To strictly replace only the first occurrence globally, we can use .replace() once.
    const originalContent = modifiedContent;
    modifiedContent = modifiedContent.replace(regex, anchorTag);

    // Check if a replacement actually occurred
    if (modifiedContent !== originalContent) {
      linksInjected++;
    }
  }

  return modifiedContent;
}
