/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.tsx
// Description: Solutions and Explanations
// ==========================================

// SemanticLinkVisualizer.tsx
import React from 'react';
import './SemanticLinkVisualizer.css'; // Assuming a separate CSS file for styling

interface LinkCandidate {
  targetArticleId: string;
  targetArticleTitle: string;
  similarityScore: number;
}

interface SemanticLinkVisualizerProps {
  sourceArticleId: string;
  candidates: LinkCandidate[];
}

const SemanticLinkVisualizer: React.FC<SemanticLinkVisualizerProps> = ({
  sourceArticleId,
  candidates,
}) => {
  // Helper function to format score as a percentage
  const formatPercentage = (score: number): string => {
    return (score * 100).toFixed(1) + '%';
  };

  // Helper function to determine color based on score
  const getScoreColor = (score: number): string => {
    if (score >= 0.85) return '#4caf50'; // Green for high relevance
    if (score >= 0.70) return '#ffc107'; // Yellow for medium relevance
    return '#f44336'; // Red for low relevance
  };

  if (candidates.length === 0) {
    return (
      <div className="visualizer-container">
        <h2>Link Candidates for: {sourceArticleId}</h2>
        <p className="no-candidates-message">No relevant link candidates found.</p>
      </div>
    );
  }

  return (
    <div className="visualizer-container">
      <h2>Link Candidates for: {sourceArticleId}</h2>
      <div className="candidates-list">
        {candidates.map((candidate) => (
          <div key={candidate.targetArticleId} className="candidate-item">
            <div className="candidate-info">
              <span className="candidate-title">{candidate.targetArticleTitle}</span>
              <span className="candidate-score">{formatPercentage(candidate.similarityScore)}</span>
            </div>
            <div className="score-bar-container">
              <div
                className="score-bar"
                style={{
                  width: formatPercentage(candidate.similarityScore),
                  backgroundColor: getScoreColor(candidate.similarityScore),
                }}
              ></div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default SemanticLinkVisualizer;
