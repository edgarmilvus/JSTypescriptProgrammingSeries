/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part6.ts
// Description: Solutions and Explanations
// ==========================================

// graphService.ts
import { EmbeddedArticle } from './types';

/**
 * Calculates the cosine similarity between two vectors (re-implemented for self-containment).
 */
function calculateCosineSimilarity(vecA: number[], vecB: number[]): number {
  if (vecA.length !== vecB.length) return 0;
  let dotProduct = 0;
  let normA = 0;
  let normB = 0;
  for (let i = 0; i < vecA.length; i++) {
    dotProduct += vecA[i] * vecB[i];
    normA += vecA[i] * vecA[i];
    normB += vecB[i] * vecB[i];
  }
  if (normA === 0 || normB === 0) return 0;
  return dotProduct / (Math.sqrt(normA) * Math.sqrt(normB));
}

/**
 * Generates a Graphviz DOT string representing the semantic network of articles.
 */
export function generateLinkGraph(
  articles: EmbeddedArticle[],
  threshold: number
): string {
  const edges: string[] = [];

  // Iterate through all unique pairs of articles
  for (let i = 0; i < articles.length; i++) {
    for (let j = i + 1; j < articles.length; j++) {
      const source = articles[i];
      const target = articles[j];

      const similarity = calculateCosineSimilarity(source.vector, target.vector);

      if (similarity > threshold) {
        // Add edge to the list, formatted for Graphviz.
        // The label is the similarity score rounded to two decimal places.
        const edge = `  "${source.id}" -> "${target.id}" [label="${similarity.toFixed(2)}"];`;
        edges.push(edge);
      }
    }
  }

  // Construct the final DOT string
  const dotString = `digraph G {\n${edges.join('\n')}\n}`;

  return dotString;
}

/**
 * Conceptual visualization function (for documentation purposes).
 * This function would not be part of the executable code.
 */
export function explainVisualization(): string {
  return `
    To visualize the generated DOT string:
    1. Save the string output from generateLinkGraph to a file, e.g., 'graph.dot'.
    2. Use the Graphviz command-line tool to render the graph:
       - For a PNG image: 'dot -Tpng graph.dot -o graph.png'
       - For an SVG image: 'dot -Tsvg graph.dot -o graph.svg'
    3. Alternatively, copy and paste the DOT string into an online Graphviz renderer like 'dreampuf.github.io/GraphvizOnline'.
  `;
}
