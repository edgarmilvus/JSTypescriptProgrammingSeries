/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part2.ts
// Description: Theoretical Foundations
// ==========================================

// types.ts

/**
 * Configuration interface for ISR on a programmatic route.
 * This dictates how the server handles caching and regeneration.
 */
interface ISRConfig {
  /**
   * The time in seconds after which a page revalidation is triggered.
   * If set to 60, the page will serve the cached version for 60 seconds.
   * After 60 seconds, the next request triggers a background regeneration.
   */
  revalidate: number | false; // false implies SSG (no revalidation)

  /**
   * Optional: A list of specific paths to pre-render at build time.
   * For pSEO, we might pre-render the top 100 high-traffic pages (SSG)
   * and leave the rest to ISR.
   */
  preRenderPaths?: string[];
}

/**
 * Example usage in a route definition for generating
 * "Best Running Shoes in [City]" pages.
 */
const pSEOConfig: ISRConfig = {
  revalidate: 3600, // Revalidate every hour
  preRenderPaths: ['/shoes/new-york', '/shoes/london'] // Critical pages pre-rendered
};

/**
 * The data payload returned by the LLM (via Context Augmentation)
 * that serves as the source of truth for the page generation.
 */
interface AIPageData {
  title: string;
  content: string; // HTML or Markdown string
  metaDescription: string;
  lastUpdated: Date;
}
