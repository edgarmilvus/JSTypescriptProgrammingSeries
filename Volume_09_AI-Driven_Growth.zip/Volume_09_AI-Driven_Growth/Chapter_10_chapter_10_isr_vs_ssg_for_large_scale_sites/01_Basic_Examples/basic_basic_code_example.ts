/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

// pages/ai-tools/[slug].tsx
// ------------------------------------------------------------
// Next.js ISR Implementation for Programmatic SEO
// ------------------------------------------------------------

import { GetStaticPaths, GetStaticProps, NextPage } from 'next';
import { ParsedUrlQuery } from 'querystring';

// ------------------------------------------------------------
// 1. Data Fetching & Mocking Layer
// ------------------------------------------------------------

/**
 * Simulates a database or CMS query for programmatic content.
 * In a real SaaS app, this would connect to a PostgreSQL DB, 
 * a Headless CMS (e.g., Contentful), or an external API.
 * 
 * @param slug - The unique identifier for the page (e.g., "ai-writing-tools")
 * @returns An object containing the page data and a timestamp for freshness
 */
const fetchPageData = async (slug: string) => {
  // Simulate network latency
  await new Promise((resolve) => setTimeout(resolve, 500));

  // Mock database response
  const mockDatabase = {
    'ai-writing-tools': {
      title: 'AI Writing Tools',
      description: 'Generate high-quality content using GPT-4.',
      lastUpdated: new Date().toISOString(),
    },
    'seo-analytics': {
      title: 'SEO Analytics',
      description: 'Track programmatic page performance in real-time.',
      lastUpdated: new Date().toISOString(),
    },
  };

  // Return data or a default structure if not found
  return (
    mockDatabase[slug as keyof typeof mockDatabase] || {
      title: 'New Programmatic Page',
      description: 'This page was generated dynamically.',
      lastUpdated: new Date().toISOString(),
    }
  );
};

// ------------------------------------------------------------
// 2. Component Definition
// ------------------------------------------------------------

interface PageProps {
  title: string;
  description: string;
  lastUpdated: string;
}

interface PageParams extends ParsedUrlQuery {
  slug: string;
}

/**
 * The React Component rendering the programmatic page.
 * This is a "dumb" component that simply displays the props passed from getStaticProps.
 */
const ProgrammaticPage: NextPage<PageProps> = ({ title, description, lastUpdated }) => {
  return (
    <div style={{ padding: '2rem', fontFamily: 'sans-serif' }}>
      <h1>{title}</h1>
      <p>{description}</p>
      
      <hr />
      
      {/* Visual indicator of content freshness */}
      <small style={{ color: '#666' }}>
        Content generated at: {lastUpdated} <br />
        <em>(Served via ISR: Stale-While-Revalidate)</em>
      </small>
    </div>
  );
};

// ------------------------------------------------------------
// 3. Static Generation Logic (SSG + ISR)
// ------------------------------------------------------------

/**
 * getStaticPaths: Defines which pages should be pre-rendered at build time.
 * 
 * For programmatic SEO with thousands of pages, you might not want to 
 * pre-render all of them if they are extremely long-tail.
 * 
 * Strategy: 
 * - 'fallback: true': Generates pages on the first request if not in the list.
 * - 'fallback: false': Returns 404 for paths not in the list.
 * - 'fallback: blocking': Generates page on first request (no loading state) and caches it.
 */
export const getStaticPaths: GetStaticPaths<PageParams> = async () => {
  // In a real app, fetch top 100 most popular slugs from your database
  const paths = [
    { params: { slug: 'ai-writing-tools' } },
    { params: { slug: 'seo-analytics' } },
  ];

  return {
    paths,
    fallback: 'blocking', // Allows new slugs to be generated on-demand
  };
};

/**
 * getStaticProps: The core of ISR.
 * 
 * This function runs at build time (for pre-defined paths) or at runtime 
 * (for on-demand generation).
 * 
 * The 'revalidate' key enables ISR.
 * - Value (in seconds): 60
 * - Meaning: The page is valid for 60 seconds. After 60s, the next request 
 *   triggers a background rebuild.
 */
export const getStaticProps: GetStaticProps<PageProps, PageParams> = async (context) => {
  const { params } = context;
  const slug = params?.slug as string;

  if (!slug) {
    return { notFound: true };
  }

  // 1. Fetch data (Database/CMS call)
  const data = await fetchPageData(slug);

  // 2. Return props and revalidation interval
  return {
    props: {
      title: data.title,
      description: data.description,
      lastUpdated: data.lastUpdated,
    },
    // --- THE ISR MAGIC HAPPENS HERE ---
    // Next.js will cache this page for 60 seconds.
    // If requested after 60s, it serves the stale page immediately
    // while regenerating the page in the background.
    revalidate: 60, 
  };
};

export default ProgrammaticPage;
