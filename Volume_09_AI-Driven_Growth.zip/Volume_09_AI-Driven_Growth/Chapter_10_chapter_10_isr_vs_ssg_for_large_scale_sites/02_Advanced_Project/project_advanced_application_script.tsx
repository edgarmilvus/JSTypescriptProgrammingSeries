/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.tsx
// Description: Advanced Application Script
// ==========================================

// pages/ai-reports/[id].tsx

import { GetStaticProps, GetStaticPaths } from 'next';
import React from 'react';

// -----------------------------------------------------------------------------
// 1. DATA FETCHING & TYPES
// -----------------------------------------------------------------------------

/**
 * Represents the structure of our AI-generated report data.
 * In a real app, this would come from a vector database or LLM API.
 */
interface AiReport {
  id: string;
  title: string;
  summary: string;
  sentimentScore: number; // 0.0 to 1.0
  generatedAt: string;
}

/**
 * Simulates an expensive call to an LLM or database.
 * In a production environment, this is where you would implement
 * Context Augmentation (RAG) to generate the content.
 */
async function fetchAiReport(id: string): Promise<AiReport> {
  console.log(`[ISR] Fetching data for ID: ${id}...`);
  
  // Simulate network latency
  await new Promise(resolve => setTimeout(resolve, 500));

  // Mock data generation based on ID
  return {
    id,
    title: `AI Analysis Report #${id}`,
    summary: `This is a dynamically generated summary for report ${id}. The content is cached via ISR to ensure fast load times.`,
    sentimentScore: Math.random(),
    generatedAt: new Date().toISOString(),
  };
}

// -----------------------------------------------------------------------------
// 2. ISR PAGE COMPONENT
// -----------------------------------------------------------------------------

interface PageProps {
  report: AiReport;
  timestamp: number;
}

/**
 * The UI Component for the Report Page.
 * Uses the data passed from getStaticProps.
 */
const AiReportPage: React.FC<PageProps> = ({ report, timestamp }) => {
  return (
    <div style={{ fontFamily: 'sans-serif', padding: '2rem', maxWidth: '800px', margin: '0 auto' }}>
      <header>
        <h1>{report.title}</h1>
        <p style={{ color: '#666' }}>
          Generated: {new Date(report.generatedAt).toLocaleString()}
        </p>
      </header>

      <main style={{ marginTop: '2rem', lineHeight: '1.6' }}>
        <p>{report.summary}</p>
        
        <div style={{ 
          background: '#f0f9ff', 
          padding: '1rem', 
          borderRadius: '8px', 
          marginTop: '2rem',
          border: '1px solid #bae6fd'
        }}>
          <strong>Debug Info (ISR Status):</strong>
          <ul>
            <li>Report ID: {report.id}</li>
            <li>Sentiment Score: {(report.sentimentScore * 100).toFixed(2)}%</li>
            <li>Page Rendered At: {new Date(timestamp).toLocaleTimeString()}</li>
          </ul>
          <p style={{ fontSize: '0.9rem', color: '#555' }}>
            <em>
              Note: This page is statically generated. If you trigger a revalidation 
              via the API, the content will update in the background on the next request.
            </em>
          </p>
        </div>
      </main>
    </div>
  );
};

// -----------------------------------------------------------------------------
// 3. STATIC GENERATION LOGIC (ISR)
// -----------------------------------------------------------------------------

/**
 * Defines the paths to pre-render at build time.
 * For large-scale sites, we might only pre-render the top 100 pages
 * and let ISR handle the rest on-demand.
 */
export const getStaticPaths: GetStaticPaths = async () => {
  // In a real app, this might be empty (fallback: true) or contain only popular IDs
  const popularIds = ['101', '102', '103'];

  const paths = popularIds.map((id) => ({
    params: { id },
  }));

  return {
    paths,
    fallback: 'blocking', // 'blocking' waits for the page to be generated on first request
  };
};

/**
 * The core ISR logic.
 * 'revalidate' ensures that if a page is older than 60 seconds,
 * the next request triggers a background rebuild.
 */
export const getStaticProps: GetStaticProps = async (context) => {
  const id = context.params?.id as string;

  if (!id) {
    return { notFound: true };
  }

  // 1. Fetch the data (LLM call or DB query)
  const report = await fetchAiReport(id);

  // 2. Return props and revalidation interval
  return {
    props: {
      report,
      timestamp: Date.now(),
    },
    // ISR KEY: Revalidate every 60 seconds.
    // This balances cost (fewer builds) with freshness.
    revalidate: 60, 
  };
};

export default AiReportPage;
