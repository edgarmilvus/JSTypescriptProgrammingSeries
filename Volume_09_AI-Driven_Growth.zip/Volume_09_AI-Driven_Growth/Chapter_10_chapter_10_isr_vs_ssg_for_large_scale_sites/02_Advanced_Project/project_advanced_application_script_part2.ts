/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script_part2.ts
// Description: Advanced Application Script
// ==========================================

// pages/api/revalidate.ts

import { NextApiRequest, NextApiResponse } from 'next';

/**
 * API Route to trigger on-demand revalidation.
 * This mimics the "Analytics Trigger" mentioned in the chapter.
 * 
 * Security Note: In production, validate a secret token to prevent
 * unauthorized cache purging (DDoS vector).
 */
export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse
) {
  // Check for secret token to validate the request is from the analytics system
  if (req.query.secret !== process.env.REVALIDATION_SECRET_TOKEN) {
    return res.status(401).json({ message: 'Invalid token' });
  }

  try {
    const { id } = req.body;

    if (!id) {
      return res.status(400).json({ message: 'ID is required' });
    }

    // Trigger revalidation for the specific dynamic path
    // This removes the cache entry for '/ai-reports/[id]' and rebuilds it in background
    await res.revalidate(`/ai-reports/${id}`);
    
    console.log(`[API] Revalidation triggered for /ai-reports/${id}`);

    return res.json({ revalidated: true, now: Date.now() });
  } catch (err) {
    // If there was an error, Next.js attempts to retry.
    // We return a 500 status to indicate failure.
    return res.status(500).send('Error revalidating');
  }
}
