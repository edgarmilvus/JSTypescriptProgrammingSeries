/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// File: pages/api/revalidate.ts
// Purpose: API Route to trigger on-demand revalidation for specific paths.
import type { NextApiRequest, NextApiResponse } from 'next';

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  // 1. Check for secret token to prevent unauthorized revalidation
  if (req.query.secret !== process.env.REVALIDATION_SECRET) {
    return res.status(401).json({ message: 'Invalid token' });
  }

  // 2. Check for path parameter
  const path = req.query.path;
  if (typeof path !== 'string') {
    return res.status(400).json({ message: 'Path is required' });
  }

  try {
    // 3. Trigger revalidation
    await res.revalidate(path);
    return res.json({ revalidated: true, path });
  } catch (err) {
    // If there was an error, Next.js attempts to revalidate the page on the next request.
    // We return a 500 status code here to indicate the immediate revalidation failed.
    return res.status(500).send({ error: err });
  }
}

// File: pages/docs/[slug].tsx
// Purpose: Dynamic page using ISR to fetch content from a mock data source.
import { GetStaticProps, GetStaticPaths } from 'next';
import fs from 'fs';
import path from 'path';

// Mocking a Headless CMS with a JSON file
const DATA_SOURCE_PATH = path.join(process.cwd(), 'data', 'docs.json');

interface DocPageProps {
  content: string;
  slug: string;
  lastUpdated: string;
}

// 1. Fetch data for static generation
export const getStaticProps: GetStaticProps = async (context) => {
  const slug = context.params?.slug as string;
  
  // Read mock data
  const rawData = fs.readFileSync(DATA_SOURCE_PATH, 'utf-8');
  const data = JSON.parse(rawData);
  
  const pageData = data.find((item: any) => item.slug === slug);

  if (!pageData) {
    return { notFound: true };
  }

  return {
    props: {
      content: pageData.content,
      slug: pageData.slug,
      lastUpdated: new Date().toISOString(), // Just to show dynamic generation time
    },
    // 2. Enable ISR: Revalidate every 60 seconds
    revalidate: 60, 
  };
};

// 3. Define paths to pre-render (SSG)
export const getStaticPaths: GetStaticPaths = async () => {
  // In a real app, you might fetch a list of slugs from the CMS.
  // Here we read the mock file to generate paths.
  if (!fs.existsSync(DATA_SOURCE_PATH)) {
    return { paths: [], fallback: 'blocking' };
  }

  const rawData = fs.readFileSync(DATA_SOURCE_PATH, 'utf-8');
  const data = JSON.parse(rawData);

  const paths = data.map((item: any) => ({
    params: { slug: item.slug },
  }));

  return {
    paths,
    fallback: 'blocking', // Allow new pages to be generated on demand
  };
};

// 4. The Page Component
export default function DocPage({ content, slug, lastUpdated }: DocPageProps) {
  return (
    <div style={{ padding: '20px' }}>
      <h1>Documentation: {slug}</h1>
      <p style={{ color: '#666', fontSize: '0.9rem' }}>Last Generated: {lastUpdated}</p>
      <div style={{ marginTop: '20px', lineHeight: '1.6' }}>
        {content}
      </div>
      <hr style={{ marginTop: '40px' }} />
      <p><em>To test revalidation: 1. Modify <code>data/docs.json</code>. 2. Call <code>/api/revalidate?secret=YOUR_SECRET&path=/docs/[slug]</code>.</em></p>
    </div>
  );
}
