/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.tsx
// Description: Solutions and Explanations
// ==========================================

// File: components/MetricCard.tsx
import React, { useState, useEffect, useRef } from 'react';

interface MetricData {
  value: number;
  label: string;
  timestamp: string;
}

interface MetricCardProps {
  initialData: MetricData;
  refreshInterval?: number; // in ms
  priority?: boolean; // If true, fetch immediately; if false, wait for viewport
}

const MetricCard: React.FC<MetricCardProps> = ({ 
  initialData, 
  refreshInterval = 5000, 
  priority = false 
}) => {
  const [data, setData] = useState<MetricData>(initialData);
  const [isStale, setIsStale] = useState(false); // Visual indicator
  const [isVisible, setIsVisible] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  // Intersection Observer Logic for non-priority fetching
  useEffect(() => {
    if (priority) {
      setIsVisible(true); // Immediate if priority
      return;
    }

    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.disconnect(); // Stop observing once visible
        }
      },
      { rootMargin: '100px' } // Start loading slightly before it enters viewport
    );

    if (ref.current) {
      observer.observe(ref.current);
    }

    return () => observer.disconnect();
  }, [priority]);

  // Data Fetching Logic
  useEffect(() => {
    if (!isVisible || !refreshInterval) return;

    const intervalId = setInterval(async () => {
      setIsStale(true); // Show visual indicator immediately
      
      try {
        // Simulate fetching new data from API
        // In real app: const res = await fetch('/api/metrics'); const newData = await res.json();
        const newData: MetricData = {
          ...initialData,
          value: initialData.value + Math.random() * 10, // Simulated change
          timestamp: new Date().toISOString(),
        };

        // 4. Compare to avoid unnecessary UI flashes
        if (newData.value !== data.value) {
          setData(newData);
        }
      } catch (error) {
        console.error("Failed to refresh metric", error);
      } finally {
        // Small delay to show the shimmer effect clearly
        setTimeout(() => setIsStale(false), 500);
      }
    }, refreshInterval);

    return () => clearInterval(intervalId);
  }, [isVisible, refreshInterval, data.value, initialData]);

  // Visual Styles
  const cardStyle: React.CSSProperties = {
    border: '1px solid #ddd',
    padding: '16px',
    borderRadius: '8px',
    background: isStale ? '#f9f9f9' : '#fff',
    transition: 'opacity 0.3s ease',
    opacity: isStale ? 0.7 : 1,
  };

  return (
    <div ref={ref} style={cardStyle}>
      <h3>{data.label}</h3>
      <p style={{ fontSize: '2rem', fontWeight: 'bold', margin: 0 }}>
        {data.value.toFixed(2)}
      </p>
      {isStale && <small style={{ color: '#888' }}>Updating...</small>}
      <div style={{ fontSize: '0.7rem', color: '#aaa', marginTop: '8px' }}>
        Last fetched: {new Date(data.timestamp).toLocaleTimeString()}
      </div>
    </div>
  );
};

export default MetricCard;
