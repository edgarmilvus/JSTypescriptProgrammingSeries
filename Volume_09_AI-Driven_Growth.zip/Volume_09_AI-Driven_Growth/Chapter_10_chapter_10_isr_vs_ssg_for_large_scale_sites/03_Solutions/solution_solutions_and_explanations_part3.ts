/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

// File: public/sw.ts
// Note: This is technically JavaScript, but written in a TS style for clarity.
// In a real TS project, you'd compile this or use a Workbox plugin.

const CACHE_NAME = 'ai-model-cache-v2'; // Increment this to trigger cleanup

// Assets to cache immediately on install
const PRECACHE_ASSETS = [
  '/models/model-v2.onnx',
  '/models/weights-v2.bin'
];

// 1. Install: Pre-cache essential assets
self.addEventListener('install', (event) => {
  self.skipWaiting(); // Activate immediately
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => {
      return cache.addAll(PRECACHE_ASSETS);
    })
  );
});

// 2. Activate: Clean up old caches
self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((cacheNames) => {
      return Promise.all(
        cacheNames.map((cacheName) => {
          // Delete any cache that doesn't match our current version
          if (cacheName !== CACHE_NAME) {
            console.log('Deleting old cache:', cacheName);
            return caches.delete(cacheName);
          }
        })
      );
    }).then(() => {
      // 3. Claim clients to ensure the SW takes control immediately
      return self.clients.claim();
    })
  );
});

// 3. Fetch: Intercept requests for heavy assets
self.addEventListener('fetch', (event) => {
  const url = new URL(event.request.url);

  // Check if this is a heavy asset we want to cache
  const isModelAsset = url.pathname.endsWith('.onnx') || url.pathname.endsWith('.bin');

  if (isModelAsset) {
    // Strategy: Cache First (Check Cache -> Return -> If missing, Fetch & Cache)
    event.respondWith(
      caches.match(event.request).then((cachedResponse) => {
        if (cachedResponse) {
          console.log('Serving from Cache:', url.pathname);
          return cachedResponse;
        }

        // If not in cache, fetch from network
        console.log('Fetching from Network:', url.pathname);
        return fetch(event.request).then((networkResponse) => {
          // Open cache and store the new response
          return caches.open(CACHE_NAME).then((cache) => {
            // Clone response because it can only be consumed once
            cache.put(event.request, networkResponse.clone());
            return networkResponse;
          });
        });
      })
    );
  }
});
