/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

// File: chunker.ts

/**
 * Estimates tokens based on a rough approximation (1 token ~= 4 chars).
 * A production solution would use a tokenizer library like 'tiktoken'.
 */
const estimateTokens = (text: string): number => {
  return Math.ceil(text.length / 4);
};

export function chunkDocument(text: string, maxTokens: number, overlapTokens: number): string[] {
  const chunks: string[] = [];
  
  // 1. Split by Headers (Regex for Markdown headers #, ##, ###)
  // This creates "sections" that we want to keep intact if possible.
  const sections = text.split(/(?=\n#{1,3}\s)/g);

  let currentChunk = "";
  
  for (const section of sections) {
    const sectionTokens = estimateTokens(section);

    // Case A: The section fits within the limit
    if (estimateTokens(currentChunk + section) <= maxTokens) {
      currentChunk += section;
    } 
    // Case B: The section is too large to fit even as a single chunk
    else if (sectionTokens > maxTokens) {
      // 1. Save whatever is in the current buffer first
      if (currentChunk.trim().length > 0) {
        chunks.push(currentChunk);
        currentChunk = ""; // Reset
      }

      // 2. Split this huge section by sentences
      // Regex looks for . ? ! followed by whitespace or end of string
      const sentences = section.split(/(?<=[.!?])\s+/g);

      for (const sentence of sentences) {
        if (estimateTokens(currentChunk + sentence) <= maxTokens) {
          currentChunk += sentence + " ";
        } else {
          // Sentence doesn't fit, push current chunk and start new one
          if (currentChunk.trim().length > 0) chunks.push(currentChunk.trim());
          currentChunk = sentence + " ";
        }
      }
    } 
    // Case C: Section doesn't fit in current chunk, but isn't huge itself
    else {
      if (currentChunk.trim().length > 0) chunks.push(currentChunk.trim());
      currentChunk = section;
    }
  }

  // Push remaining content
  if (currentChunk.trim().length > 0) {
    chunks.push(currentChunk.trim());
  }

  // 3. Apply Sliding Window Overlap
  if (overlapTokens > 0) {
    const finalChunks: string[] = [];
    for (let i = 0; i < chunks.length; i++) {
      let chunk = chunks[i];
      
      if (i > 0) {
        // Get the previous chunk
        const prevChunk = chunks[i - 1];
        // Tokenize (roughly) to get the overlap
        // In a real app, use a tokenizer to split exactly by tokens
        const prevWords = prevChunk.split(/\s+/);
        const overlapWords = prevWords.slice(-Math.ceil(overlapTokens / 1.5)); // Approx words for tokens
        
        // Prepend overlap to current chunk
        chunk = overlapWords.join(' ') + ' ' + chunk;
      }
      
      // Ensure we don't exceed maxTokens due to overlap
      // (If it exceeds, we just don't add overlap or truncate - simplified here)
      finalChunks.push(chunk);
    }
    return finalChunks;
  }

  return chunks;
}

// Example Usage:
// const text = `# Introduction\nThis is the start.\n## Setup\nRun npm install.\n## Usage\nImport the library.`;
// const result = chunkDocument(text, 50, 10);
// console.log(result);
