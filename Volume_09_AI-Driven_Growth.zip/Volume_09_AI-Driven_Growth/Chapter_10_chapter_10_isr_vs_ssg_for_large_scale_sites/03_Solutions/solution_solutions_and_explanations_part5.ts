/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

// File: metadataGenerator.ts
import { z } from 'zod';

// 1. Define the Zod Schema
const SEOSchema = z.object({
  title: z.string().max(60, "Title must be 60 chars or less"),
  description: z.string().max(160, "Description must be 160 chars or less"),
  tags: z.array(z.string()).min(1, "At least one tag is required"),
  canonicalUrl: z.string().url("Must be a valid URL"),
});

// 2. Generate the Prompt
export function generateMetadataPrompt(topic: string): string {
  return `You are an expert SEO specialist. Generate SEO metadata for a documentation page about "${topic}".
  
Strict Rules:
1. Output ONLY valid JSON. Do not include conversational text, greetings, or markdown code blocks (like \`\`\`json).
2. The JSON must adhere to the following schema:
   - "title": string (max 60 chars)
   - "description": string (max 160 chars)
   - "tags": array of strings (min 1 item)
   - "canonicalUrl": string (valid URL format)

Example Output:
{"title": "Quick Start Guide", "description": "Learn how to install the library.", "tags": ["install", "guide"], "canonicalUrl": "https://example.com/install"}`;
}

// 3. Parser and Validator
export function parseLLMResponse(rawResponse: string): z.infer<typeof SEOSchema> {
  let jsonString = rawResponse;

  // Step A: Extract JSON if wrapped in markdown code blocks
  // Regex to find content between 