/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

// ============================================================================
// DATA MODELS & TYPE DEFINITIONS
// ============================================================================

/**
 * Represents the state of a user in our SaaS application.
 * Using `readonly` properties enforces immutability at the type level.
 */
type User = {
  readonly id: string;
  readonly email: string;
  readonly createdAt: Date;
  readonly referredBy: string | null; // ID of the user who referred them, if any
};

/**
 * Represents a referral attribution event.
 * This is an immutable record of a successful referral.
 */
type ReferralAttribution = {
  readonly id: string;
  readonly newUserId: string;
  readonly referrerId: string;
  readonly attributedAt: Date;
  readonly source: 'direct_link'; // Could be 'email', 'social', etc.
};

/**
 * A simple in-memory "database" for demonstration purposes.
 * In a real application, this would be a connection to PostgreSQL, MongoDB, etc.
 */
type Database = {
  users: Map<string, User>;
  referralAttributions: Map<string, ReferralAttribution>;
};

// ============================================================================
// CORE LOGIC: IMMUTABLE STATE MANAGEMENT
// ============================================================================

/**
 * Creates a new user record without mutating any existing state.
 * This is a pure function that returns a new User object.
 *
 * @param email - The email of the new user.
 * @param referredBy - The ID of the user who referred them (optional).
 * @returns A new, immutable User object.
 */
function createUser(email: string, referredBy: string | null): User {
  // We use `Object.freeze` to ensure the object is immutable at runtime.
  // This is a defensive programming practice.
  return Object.freeze({
    id: `user_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`,
    email,
    createdAt: new Date(),
    referredBy,
  });
}

/**
 * Creates a new referral attribution record.
 * This function does not modify the database; it only creates the data structure.
 *
 * @param newUserId - The ID of the newly signed-up user.
 * @param referrerId - The ID of the user who sent the invitation.
 * @returns A new, immutable ReferralAttribution object.
 */
function createReferralAttribution(
  newUserId: string,
  referrerId: string
): ReferralAttribution {
  return Object.freeze({
    id: `attr_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`,
    newUserId,
    referrerId,
    attributedAt: new Date(),
    source: 'direct_link',
  });
}

// ============================================================================
// SERVICE LAYER: HANDLING THE SIGN-UP FLOW
// ============================================================================

/**
 * Simulates the backend API endpoint for user registration.
 * This function orchestrates the entire process: validation, user creation,
 * and referral attribution.
 *
 * @param db - The in-memory database instance.
 * @param email - The email from the sign-up form.
 * @param referralCode - The referral code from the URL query parameter.
 * @returns The newly created user.
 * @throws Error if the referral code is invalid or the user already exists.
 */
async function handleUserSignUp(
  db: Database,
  email: string,
  referralCode: string | null
): Promise<User> {
  // 1. VALIDATION: Check if the user already exists (mock check).
  if (Array.from(db.users.values()).some((u) => u.email === email)) {
    throw new Error('User with this email already exists.');
  }

  // 2. REFERRAL VALIDATION: Check if the referral code is valid.
  let referrerId: string | null = null;
  if (referralCode) {
    const referrer = db.users.get(referralCode);
    if (!referrer) {
      // In a real app, you might log this for fraud analysis.
      console.warn(`Invalid referral code attempted: ${referralCode}`);
      // We proceed without attribution, but you could also throw an error here.
    } else {
      referrerId = referrer.id;
    }
  }

  // 3. IMMUTABLE STATE CREATION: Create the new user.
  const newUser = createUser(email, referrerId);

  // 4. DATABASE UPDATE (Simulated): Store the new user.
  // In a real system, this would be a database transaction.
  db.users.set(newUser.id, newUser);

  // 5. ATTRIBUTION LOGIC: If referred, create the attribution record.
  if (referrerId) {
    const attribution = createReferralAttribution(newUser.id, referrerId);
    
    // Store the attribution event.
    db.referralAttributions.set(attribution.id, attribution);
    
    console.log(`✅ Referral Attributed: ${newUser.id} was referred by ${referrerId}`);
    
    // --- NEXT STEPS (Conceptual) ---
    // This is where you would trigger the reward system.
    // e.g., `grantReferralReward(referrerId);`
    // This could be a Tool Call to an external billing API or an internal service.
  } else {
    console.log(`ℹ️  New user ${newUser.id} signed up organically.`);
  }

  return newUser;
}

// ============================================================================
// SIMULATION: RUNNING THE "HELLO WORLD" EXAMPLE
// ============================================================================

/**
 * Main function to demonstrate the referral system.
 */
async function main() {
  console.log('--- Initializing SaaS Application State ---');
  const appDb: Database = {
    users: new Map(),
    referralAttributions: new Map(),
  };

  // 1. Create an initial user (the referrer).
  const referrer = createUser('alice@example.com', null);
  appDb.users.set(referrer.id, referrer);
  console.log(`Created Referrer: ${referrer.email} (ID: ${referrer.id})`);

  // 2. Simulate a new user signing up via Alice's referral link.
  // The frontend would extract `referrer.id` from the URL and send it as `referralCode`.
  console.log('\n--- Simulating New User Sign-up via Referral Link ---');
  try {
    const newUser = await handleUserSignUp(
      appDb,
      'bob@example.com',
      referrer.id // This is the referral code from the URL
    );
    console.log(`New User Created: ${newUser.email} (ID: ${newUser.id})`);
  } catch (error) {
    console.error('Sign-up failed:', error);
  }

  // 3. Simulate a new user signing up organically (no referral).
  console.log('\n--- Simulating Organic User Sign-up ---');
  try {
    const organicUser = await handleUserSignUp(appDb, 'charlie@example.com', null);
    console.log(`Organic User Created: ${organicUser.email} (ID: ${organicUser.id})`);
  } catch (error) {
    console.error('Sign-up failed:', error);
  }

  // 4. Display the final state of our "database".
  console.log('\n--- Final Application State ---');
  console.log('Total Users:', appDb.users.size);
  console.log('Total Referral Attributions:', appDb.referralAttributions.size);
  console.log('Attribution Details:');
  appDb.referralAttributions.forEach((attr) => {
    console.log(`  - New User: ${attr.newUserId}, Referrer: ${attr.referrerId}`);
  });
}

// Run the simulation.
main();
