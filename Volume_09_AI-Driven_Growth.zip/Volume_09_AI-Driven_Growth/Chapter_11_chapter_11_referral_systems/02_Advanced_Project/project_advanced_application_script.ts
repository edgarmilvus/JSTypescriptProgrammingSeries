/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// pages/api/referral/claim.ts
// Next.js API Route for Programmatic Referral Engine

import type { NextApiRequest, NextApiResponse } from 'next';

// ==========================================
// 1. IMMUTABLE STATE MANAGEMENT & TYPES
// ==========================================

/**
 * Represents the immutable state of a user within the system.
 * Properties are readonly to enforce immutability at the type level.
 */
type UserState = {
  readonly id: string;
  readonly email: string;
  readonly tier: 'FREE' | 'PRO' | 'ENTERPRISE';
  readonly lifetimeValue: number;
};

/**
 * Represents the outcome of a referral claim.
 * Uses discriminated unions for type-safe state handling.
 */
type ReferralOutcome =
  | { status: 'SUCCESS'; rewardId: string; amount: number }
  | { status: 'FRAUD_DETECTED'; reason: string }
  | { status: 'INVALID_TIER'; message: string };

/**
 * Tool Definition for Tool Calling pattern.
 * Defines the contract for dynamic incentive generation.
 */
interface IncentiveTool {
  name: string;
  description: string;
  parameters: {
    userTier: UserState['tier'];
    referralSource: string;
  };
  // The function that executes the tool logic
  executor: (params: {
    userTier: UserState['tier'];
    referralSource: string;
  }) => Promise<{ rewardId: string; amount: number }>;
}

// ==========================================
// 2. TOOL CALLING: DYNAMIC INCENTIVE GENERATION
// ==========================================

/**
 * Tool: Generates a discount code for Pro/Enterprise users.
 * Simulates an external API call to a billing provider (e.g., Stripe).
 */
const generateDiscountCodeTool: IncentiveTool = {
  name: 'generate_discount_code',
  description: 'Generates a 20% off discount code for referrals.',
  parameters: {} as any, // Simplified for brevity
  executor: async ({ userTier, referralSource }) => {
    console.log(`[Tool] Generating discount for ${userTier} via ${referralSource}...`);
    // In a real scenario, this calls Stripe or similar
    const rewardId = `DISC_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    return { rewardId, amount: 20 }; // 20% discount
  },
};

/**
 * Tool: Generates a cash reward for Enterprise users.
 * Simulates an external API call to a payout provider (e.g., PayPal).
 */
const generateCashRewardTool: IncentiveTool = {
  name: 'generate_cash_reward',
  description: 'Generates a $50 cash reward for Enterprise referrals.',
  parameters: {} as any,
  executor: async ({ userTier, referralSource }) => {
    console.log(`[Tool] Generating cash reward for ${userTier}...`);
    const rewardId = `CASH_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    return { rewardId, amount: 50 };
  },
};

/**
 * Router function for Tool Calling.
 * Selects the appropriate tool based on User State.
 */
const selectIncentiveTool = (user: UserState): IncentiveTool => {
  if (user.tier === 'ENTERPRISE') {
    return generateCashRewardTool;
  }
  // Default to discount for Pro and Free users
  return generateDiscountCodeTool;
};

// ==========================================
// 3. CONSENSUS MECHANISM: FRAUD DETECTION
// ==========================================

/**
 * Worker Agent 1: Velocity Check
 * Checks if the user has referred too many people in a short time.
 */
const velocityCheckAgent = async (userId: string): Promise<boolean> => {
  // Simulate database query
  const recentReferrals = Math.random() > 0.8 ? 15 : 2; 
  const isSuspicious = recentReferrals > 10;
  console.log(`[Agent:Velocity] User ${userId} referrals count: ${recentReferrals}. Suspicious: ${isSuspicious}`);
  return !isSuspicious; // Return true if safe
};

/**
 * Worker Agent 2: Pattern Analysis
 * Checks for bot-like patterns (e.g., similar IP addresses, email patterns).
 */
const patternAnalysisAgent = async (ipAddress: string): Promise<boolean> => {
  // Simulate pattern analysis
  const isBotPattern = ipAddress.includes('999.999'); // Mock bot IP
  console.log(`[Agent:Pattern] IP ${ipAddress} analyzed. Bot pattern: ${isBotPattern}`);
  return !isBotPattern; // Return true if safe
};

/**
 * Supervisor Node: Consensus Aggregator
 * Compiles worker outputs to produce a final verdict.
 */
const fraudDetectionSupervisor = async (
  userId: string,
  ipAddress: string
): Promise<{ isSafe: boolean; score: number }> => {
  // Execute workers in parallel
  const [isVelocitySafe, isPatternSafe] = await Promise.all([
    velocityCheckAgent(userId),
    patternAnalysisAgent(ipAddress),
  ]);

  // Calculate consensus score (0 to 1)
  const score = (Number(isVelocitySafe) + Number(isPatternSafe)) / 2;
  
  // Threshold for approval (e.g., > 0.5)
  const isSafe = score > 0.5;

  console.log(`[Supervisor] Consensus Score: ${score}. Final Verdict: ${isSafe ? 'APPROVED' : 'REJECTED'}`);
  
  return { isSafe, score };
};

// ==========================================
// 4. NEXT.JS API ROUTE HANDLER
// ==========================================

export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse<ReferralOutcome>
) {
  // Only allow POST requests
  if (req.method !== 'POST') {
    res.status(405).json({ status: 'INVALID_TIER', message: 'Method Not Allowed' });
    return;
  }

  // Extract request data
  const { userId, ipAddress, referralSource } = req.body;

  // --- PHASE 1: Retrieve User State (Simulated) ---
  // In production, this would be a database call (e.g., Prisma/Drizzle)
  const currentUser: UserState = {
    id: userId,
    email: 'user@example.com',
    tier: 'ENTERPRISE', // Try changing this to 'FREE' to see tool selection change
    lifetimeValue: 5000,
  };

  // --- PHASE 2: Consensus Mechanism (Fraud Check) ---
  const fraudCheck = await fraudDetectionSupervisor(currentUser.id, ipAddress);

  if (!fraudCheck.isSafe) {
    // Immutable state transition: We do not credit the user.
    // We return a failure state.
    res.status(403).json({
      status: 'FRAUD_DETECTED',
      reason: 'High risk score from multi-agent consensus.',
    });
    return;
  }

  // --- PHASE 3: Tool Calling (Incentive Generation) ---
  // Dynamically select the tool based on user tier
  const selectedTool = selectIncentiveTool(currentUser);
  
  // Execute the tool
  const reward = await selectedTool.executor({
    userTier: currentUser.tier,
    referralSource,
  });

  // --- PHASE 4: Immutable State Update & Analytics ---
  // We simulate updating the database. In a real immutable system,
  // we might append an event to an event store (e.g., Kafka) rather than updating a row.
  
  const newRewardState = {
    ...currentUser, // Copy existing state
    rewards: [...(currentUser as any).rewards, reward.rewardId], // Append new reward ID
    lastReferralDate: new Date().toISOString(),
  };

  // Simulate logging to Analytics Dashboard (Cohort LTV tracking)
  console.log(`[Analytics] Event: referral_claimed. User: ${currentUser.id}. Reward: ${reward.amount}. Cohort: ${currentUser.tier}`);

  // Return Success
  res.status(200).json({
    status: 'SUCCESS',
    rewardId: reward.rewardId,
    amount: reward.amount,
  });
}
