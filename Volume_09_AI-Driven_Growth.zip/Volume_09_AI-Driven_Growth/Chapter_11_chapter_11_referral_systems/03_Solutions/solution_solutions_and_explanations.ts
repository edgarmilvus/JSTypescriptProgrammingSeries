/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// 1. Define the Tool Schema
interface GenerateLinkParams {
  userId: string;
  campaign: string;
  tier: string;
}

// Mock Database
const userTiers: Record<string, string> = {
  'u123': 'gold',
  'u456': 'silver',
};

// 2. Implement the Tool Logic
async function executeGenerateLink(params: GenerateLinkParams): Promise<string> {
  // Simulate async database operation (e.g., writing to a referral table)
  return new Promise((resolve) => {
    setTimeout(() => {
      const baseUrl = 'https://growth.app/ref';
      const url = `${baseUrl}?ref_id=${params.userId}&campaign=${params.campaign}&tier=${params.tier}`;
      resolve(url);
    }, 500);
  });
}

// 3. Create the AI Interaction Layer (Simulated)
// This function simulates the LLM parsing the prompt and deciding to call the tool.
async function getReferralLink(prompt: string): Promise<string> {
  // Step A: Parse the prompt (Simulated LLM logic)
  // We use regex to extract parameters. In a real LLM, the model would output structured JSON.
  const userIdMatch = prompt.match(/user\s+'([^']+)'/);
  const campaignMatch = prompt.match(/campaign\s+'([^']+)'/);
  const tierMatch = prompt.match(/tier\s+'([^']+)'/);

  if (!userIdMatch || !campaignMatch) {
    throw new Error("Invalid prompt: missing userId or campaign");
  }

  const userId = userIdMatch[1];
  const campaign = campaignMatch[1];
  let tier = tierMatch ? tierMatch[1] : null;

  // Step B: Interactive Challenge - Contextual Tier Assignment
  // If tier is missing in the prompt, query the mock database
  if (!tier) {
    console.log(`Tier not specified in prompt. Looking up user ${userId}...`);
    tier = userTiers[userId];
    
    if (!tier) {
      // Default to Bronze if user not found or has no tier
      tier = 'bronze'; 
    }
  }

  // Step C: Call the tool with the resolved parameters
  console.log(`Calling tool: generate_referral_link with { userId: '${userId}', campaign: '${campaign}', tier: '${tier}' }`);
  const link = await executeGenerateLink({ userId, campaign, tier });
  
  return link;
}

// Example Usage (Simulated)
(async () => {
  // Case 1: Tier specified
  const link1 = await getReferralLink("Generate a referral link for user 'u123' for the 'summer24' campaign at the 'gold' tier");
  console.log("Generated Link 1:", link1);

  // Case 2: Tier NOT specified (Triggers database lookup)
  const link2 = await getReferralLink("Generate a referral link for user 'u456' for the 'winter24' campaign");
  console.log("Generated Link 2:", link2);
})();
