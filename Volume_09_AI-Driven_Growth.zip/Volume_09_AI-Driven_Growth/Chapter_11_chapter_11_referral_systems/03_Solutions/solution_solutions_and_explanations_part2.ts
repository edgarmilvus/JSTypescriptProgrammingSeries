/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

// 1. Define State Interfaces
interface ReferralState {
  userId: string;
  referralCount: number;
  tier: 'Bronze' | 'Silver' | 'Gold';
}

// 2. Implement Immutable Update Functions
function incrementReferral(currentState: ReferralState): ReferralState {
  // Return a new object with updated count, spreading the previous properties
  return {
    ...currentState,
    referralCount: currentState.referralCount + 1,
  };
}

function promoteTier(currentState: ReferralState): ReferralState {
  const { referralCount } = currentState;
  let newTier = currentState.tier;

  // Determine new tier based on thresholds
  if (referralCount > 50) {
    newTier = 'Gold';
  } else if (referralCount > 10) {
    newTier = 'Silver';
  } else {
    newTier = 'Bronze';
  }

  // Only return a new object if the tier actually changes, 
  // otherwise return a copy (or strictly, the same state if no mutation needed, 
  // but for history tracking we usually want to record the event).
  // Here we return a new object to ensure history captures the step.
  return {
    ...currentState,
    tier: newTier,
  };
}

// 3. State History Class
class ReferralHistory {
  private history: ReferralState[] = [];

  constructor(initialState: ReferralState) {
    this.history.push({ ...initialState }); // Store a copy of initial state
  }

  // Helper to get current state (last in history)
  getCurrentState(): ReferralState {
    return this.history[this.history.length - 1];
  }

  // Apply an update and store the result in history
  applyUpdate(updateFn: (state: ReferralState) => ReferralState): void {
    const currentState = this.getCurrentState();
    const newState = updateFn(currentState);
    this.history.push(newState);
  }

  getHistory(): ReferralState[] {
    return this.history;
  }
}

// 4. Validation Helper
function validateState(history: ReferralState[], index: number): boolean {
  if (index <= 0 || index >= history.length) return false;
  
  // Check if the state at 'index' is strictly equal to the state at 'index - 1'
  // In JavaScript, objects are compared by reference.
  // Since we use immutable updates (creating new objects), strict equality should always be false.
  const previousState = history[index - 1];
  const currentState = history[index];
  
  return previousState === currentState;
}

// --- Usage Example ---
const initialState: ReferralState = {
  userId: 'u789',
  referralCount: 0,
  tier: 'Bronze',
};

const manager = new ReferralHistory(initialState);

// Simulate 12 referrals
for (let i = 0; i < 12; i++) {
  manager.applyUpdate(incrementReferral);
}

// Check for promotion (should go to Silver at 11 referrals)
manager.applyUpdate(promoteTier);

const finalState = manager.getCurrentState();
const historyLog = manager.getHistory();

// Validation check (should return false, proving immutability)
const isImmutable = validateState(historyLog, historyLog.length - 1); 

console.log(`Final State:`, finalState);
console.log(`History Length:`, historyLog.length);
console.log(`Is Immutable Check Passed:`, !isImmutable); // True if objects are distinct references
