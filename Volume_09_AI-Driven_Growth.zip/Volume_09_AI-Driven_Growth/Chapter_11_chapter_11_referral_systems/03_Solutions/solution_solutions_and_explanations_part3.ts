/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

// 1. Define Worker Interfaces
interface FraudCheckResult {
  agent: string;
  isSuspicious: boolean;
  weight?: number; // Optional for advanced weighted logic
}

// 2. & 3. Implement Supervisor Logic (Basic + Weighted)
function evaluateReferralConsensus(
  checks: FraudCheckResult[], 
  useWeighted: boolean = false
): { status: 'Approved' | 'Rejected' | 'Under Review'; confidence: number } {
  
  if (checks.length === 0) {
    return { status: 'Under Review', confidence: 0 };
  }

  // --- Logic Branch A: Basic Majority Vote ---
  if (!useWeighted) {
    const suspiciousCount = checks.filter(c => c.isSuspicious).length;
    const totalCount = checks.length;

    if (suspiciousCount >= 2) {
      return { status: 'Rejected', confidence: 0.95 };
    } else if (suspiciousCount === 1) {
      return { status: 'Under Review', confidence: 0.5 };
    } else {
      return { status: 'Approved', confidence: 0.99 };
    }
  }

  // --- Logic Branch B: Weighted Consensus ---
  // Calculate total weight of suspicious agents
  const suspiciousWeight = checks
    .filter(c => c.isSuspicious)
    .reduce((sum, c) => sum + (c.weight || 0), 0);

  // Calculate total available weight (for normalization/confidence)
  const totalWeight = checks.reduce((sum, c) => sum + (c.weight || 0), 0);

  // Rule: If suspicious weight > 1.0 (arbitrary threshold), reject
  if (suspiciousWeight > 1.0) {
    return { status: 'Rejected', confidence: suspiciousWeight / totalWeight };
  } 
  
  // Rule: If there is some suspicion but below threshold, review
  if (suspiciousWeight > 0) {
    return { status: 'Under Review', confidence: 1 - (suspiciousWeight / totalWeight) };
  }

  // Rule: No suspicion
  return { status: 'Approved', confidence: 1.0 };
}

// --- Testing the Logic ---

// Mock Data 1: Simple majority (1 suspicious)
const mockChecksBasic: FraudCheckResult[] = [
  { agent: 'ipCheck', isSuspicious: false },
  { agent: 'deviceCheck', isSuspicious: true },
  { agent: 'velocityCheck', isSuspicious: false },
];

// Mock Data 2: Weighted (Device check is heavy, but only one is suspicious)
const mockChecksWeighted: FraudCheckResult[] = [
  { agent: 'ipCheck', isSuspicious: false, weight: 0.5 },
  { agent: 'deviceCheck', isSuspicious: true, weight: 0.8 }, // Suspicious, but total < 1.0
  { agent: 'velocityCheck', isSuspicious: false, weight: 0.3 },
];

// Mock Data 3: Weighted (Suspicious weight exceeds 1.0)
const mockChecksWeightedReject: FraudCheckResult[] = [
  { agent: 'ipCheck', isSuspicious: true, weight: 0.6 },
  { agent: 'deviceCheck', isSuspicious: true, weight: 0.8 }, // Total suspicious weight = 1.4
];

console.log("Basic Consensus:", evaluateReferralConsensus(mockChecksBasic));
console.log("Weighted Consensus (Review):", evaluateReferralConsensus(mockChecksWeighted, true));
console.log("Weighted Consensus (Reject):", evaluateReferralConsensus(mockChecksWeightedReject, true));
