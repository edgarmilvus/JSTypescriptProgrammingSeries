/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState, useEffect } from 'react';

// 1. & 2. Interfaces
interface ReferralStats {
  totalReferrals: number;
  conversionRate: number;
  estimatedEarnings: number;
}

interface ReferralDashboardProps {
  userId: string;
}

// 3. & 4. Component Implementation
export const ReferralDashboard: React.FC<ReferralDashboardProps> = ({ userId }) => {
  // State Management
  const [stats, setStats] = useState<ReferralStats | null>(null);
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  
  // Interactive Challenge: View State
  const [viewMode, setViewMode] = useState<'card' | 'table'>('card');

  // Data Fetching Simulation
  const fetchData = () => {
    setLoading(true);
    setError(null);
    setStats(null);

    // Simulate API call
    setTimeout(() => {
      // Randomize data slightly for effect
      const mockData: ReferralStats = {
        totalReferrals: Math.floor(Math.random() * 100),
        conversionRate: 0.12 + (Math.random() * 0.05),
        estimatedEarnings: Math.floor(Math.random() * 5000),
      };
      
      // Simulate occasional error (optional)
      if (Math.random() > 0.9) {
        setError("Failed to fetch data. Please try again.");
      } else {
        setStats(mockData);
      }
      
      setLoading(false);
    }, 1000);
  };

  // Trigger fetch on mount or userId change
  useEffect(() => {
    fetchData();
  }, [userId]);

  // Helper to format currency
  const formatCurrency = (amount: number) => new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(amount);

  // 5. Rendering Logic
  if (loading) {
    return <div className="dashboard-loading">Loading Referral Data for {userId}...</div>;
  }

  if (error) {
    return <div className="dashboard-error" style={{ color: 'red' }}>{error}</div>;
  }

  if (!stats) {
    return <div>No data available.</div>;
  }

  // Interactive Challenge: Toggle View Logic
  const renderStats = () => {
    if (viewMode === 'card') {
      // Card View
      return (
        <div style={{ display: 'flex', gap: '1rem', flexWrap: 'wrap' }}>
          <div className="stat-card" style={{ border: '1px solid #ccc', padding: '1rem', borderRadius: '8px' }}>
            <h3>Total Referrals</h3>
            <p style={{ fontSize: '1.5rem', fontWeight: 'bold' }}>{stats.totalReferrals}</p>
          </div>
          <div className="stat-card" style={{ border: '1px solid #ccc', padding: '1rem', borderRadius: '8px' }}>
            <h3>Conversion Rate</h3>
            <p style={{ fontSize: '1.5rem', fontWeight: 'bold' }}>{(stats.conversionRate * 100).toFixed(1)}%</p>
          </div>
          <div className="stat-card" style={{ border: '1px solid #ccc', padding: '1rem', borderRadius: '8px' }}>
            <h3>Est. Earnings</h3>
            <p style={{ fontSize: '1.5rem', fontWeight: 'bold' }}>{formatCurrency(stats.estimatedEarnings)}</p>
          </div>
        </div>
      );
    } else {
      // Table View
      return (
        <table style={{ width: '100%', borderCollapse: 'collapse', marginTop: '1rem' }}>
          <thead>
            <tr style={{ backgroundColor: '#f2f2f2' }}>
              <th style={{ padding: '0.5rem', border: '1px solid #ddd' }}>Metric</th>
              <th style={{ padding: '0.5rem', border: '1px solid #ddd' }}>Value</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td style={{ padding: '0.5rem', border: '1px solid #ddd' }}>Total Referrals</td>
              <td style={{ padding: '0.5rem', border: '1px solid #ddd' }}>{stats.totalReferrals}</td>
            </tr>
            <tr>
              <td style={{ padding: '0.5rem', border: '1px solid #ddd' }}>Conversion Rate</td>
              <td style={{ padding: '0.5rem', border: '1px solid #ddd' }}>{(stats.conversionRate * 100).toFixed(1)}%</td>
            </tr>
            <tr>
              <td style={{ padding: '0.5rem', border: '1px solid #ddd' }}>Est. Earnings</td>
              <td style={{ padding: '0.5rem', border: '1px solid #ddd' }}>{formatCurrency(stats.estimatedEarnings)}</td>
            </tr>
          </tbody>
        </table>
      );
    }
  };

  return (
    <div style={{ padding: '1rem', fontFamily: 'sans-serif' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1rem' }}>
        <h2>Referral Dashboard ({userId})</h2>
        <div>
          <button onClick={() => setViewMode(viewMode === 'card' ? 'table' : 'card')} style={{ marginRight: '0.5rem', padding: '0.5rem' }}>
            Toggle View ({viewMode === 'card' ? 'Table' : 'Card'})
          </button>
          <button onClick={fetchData} style={{ padding: '0.5rem' }}>Refresh</button>
        </div>
      </div>
      
      {renderStats()}
    </div>
  );
};
