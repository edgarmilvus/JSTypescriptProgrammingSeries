/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

// 1. Define Data Structures
interface User {
  id: string;
  acquisitionSource: 'referral' | 'organic';
  cohortDate: string;
}

interface Transaction {
  userId: string;
  amount: number;
  date: string;
}

// 2. Implement the Calculator
function calculateLtvUplift(users: User[], transactions: Transaction[]) {
  // Filter users into two groups
  const referralUsers = users.filter(u => u.acquisitionSource === 'referral');
  const organicUsers = users.filter(u => u.acquisitionSource === 'organic');

  // Helper to calculate average LTV for a specific group
  const calculateAverageLtv = (userGroup: User[]): number => {
    if (userGroup.length === 0) return 0;

    // Get unique user IDs for this group
    const userIds = new Set(userGroup.map(u => u.id));

    // Sum revenue for these users
    const totalRevenue = transactions
      .filter(t => userIds.has(t.userId))
      .reduce((sum, t) => sum + t.amount, 0);

    // Average LTV = Total Revenue / Number of Users
    return totalRevenue / userGroup.length;
  };

  // 3. Calculate Metrics
  const referralLtv = calculateAverageLtv(referralUsers);
  const organicLtv = calculateAverageLtv(organicUsers);

  // 4. Calculate Uplift Percentage
  let upliftPercentage = 0;
  
  // Edge Case: Handle division by zero if organic LTV is 0
  if (organicLtv > 0) {
    upliftPercentage = ((referralLtv - organicLtv) / organicLtv) * 100;
  } else if (referralLtv > 0) {
    // If organic is 0 but referral is positive, uplift is effectively infinite
    // We can return a special marker or just a large number, here we return 100+ logic
    upliftPercentage = 100; 
  }

  return {
    referralLtv: Number(referralLtv.toFixed(2)),
    organicLtv: Number(organicLtv.toFixed(2)),
    upliftPercentage: Number(upliftPercentage.toFixed(2))
  };
}

// --- Mock Data ---
const mockUsers: User[] = [
  { id: 'u1', acquisitionSource: 'referral', cohortDate: '2023-01-01' },
  { id: 'u2', acquisitionSource: 'referral', cohortDate: '2023-01-01' },
  { id: 'u3', acquisitionSource: 'organic', cohortDate: '2023-01-01' },
  { id: 'u4', acquisitionSource: 'organic', cohortDate: '2023-01-01' },
];

const mockTransactions: Transaction[] = [
  { userId: 'u1', amount: 100, date: '2023-01-05' },
  { userId: 'u1', amount: 50, date: '2023-02-05' }, // u1 total: 150
  { userId: 'u2', amount: 200, date: '2023-01-10' }, // u2 total: 200
  { userId: 'u3', amount: 30, date: '2023-01-15' },  // u3 total: 30
  { userId: 'u4', amount: 40, date: '2023-01-20' },  // u4 total: 40
];

// --- Execution ---
const result = calculateLtvUplift(mockUsers, mockTransactions);

/*
Logic Check:
Referral Users: u1, u2 -> Total Revenue: 350 -> Count: 2 -> Avg LTV: 175
Organic Users: u3, u4 -> Total Revenue: 70 -> Count: 2 -> Avg LTV: 35
Uplift: ((175 - 35) / 35) * 100 = 400%
*/

console.log(result); 
// Expected: { referralLtv: 175, organicLtv: 35, upliftPercentage: 400 }
