/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part6.ts
// Description: Solutions and Explanations
// ==========================================

digraph ViralLoop {
    // Graph Attributes
    rankdir=TB;
    splines=ortho;
    node [fontname="Arial", fontsize=12];
    edge [fontname="Arial", fontsize=10];

    // Node Definitions
    ExistingUser [label="Existing User\n(Advocate)" shape=ellipse style=filled fillcolor="#e1f5fe"];
    InviteSent [label="Invite Sent\n(Email/SMS/Link)" shape=box style=filled fillcolor="#fff3e0"];
    LandingPage [label="Landing Page\n(Referral URL)" shape=box style=filled fillcolor="#f3e5f5"];
    SignUp [label="Sign Up\n(Conversion)" shape=diamond style=filled fillcolor="#e8f5e8"];
    Activated [label="Activated\n(First Key Action)" shape=ellipse style=filled fillcolor="#fff9c4"];
    NewAdvocate [label="New Advocate\n(Ready to Invite)" shape=ellipse style=filled fillcolor="#ffebee"];

    // Edges (The Flow)
    ExistingUser -> InviteSent [label="1. Triggers"];
    InviteSent -> LandingPage [label="2. Clicks"];
    LandingPage -> SignUp [label="3. Registers"];
    SignUp -> Activated [label="4. Onboards"];
    Activated -> NewAdvocate [label="5. Becomes"];

    // The Viral Feedback Loop
    // Visual emphasis using color and label
    NewAdvocate -> InviteSent [label="Viral Loop\n(Restarts Cycle)" color="#d32f2f" fontcolor="#d32f2f" penwidth=2.0 style=dashed];

    // Subgraph for grouping (Optional visual aid)
    { rank=same; ExistingUser; NewAdvocate }
}
