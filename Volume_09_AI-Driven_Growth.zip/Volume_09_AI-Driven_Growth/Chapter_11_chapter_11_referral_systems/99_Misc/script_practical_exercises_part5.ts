/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part5.ts
// Description: Practical Exercises
// ==========================================

// Define Data Interfaces
interface User {
  id: string;
  acquisitionSource: 'referral' | 'organic';
  cohortDate: string; // YYYY-MM-DD
}

interface Transaction {
  userId: string;
  amount: number;
  date: string;
}

// Mock Data Arrays
const mockUsers: User[] = [
  { id: 'u1', acquisitionSource: 'referral', cohortDate: '2023-01-01' },
  { id: 'u2', acquisitionSource: 'organic', cohortDate: '2023-01-01' },
  // ... more users
];

const mockTransactions: Transaction[] = [
  { userId: 'u1', amount: 50, date: '2023-01-05' },
  { userId: 'u2', amount: 30, date: '2023-01-06' },
  // ... more transactions
];
