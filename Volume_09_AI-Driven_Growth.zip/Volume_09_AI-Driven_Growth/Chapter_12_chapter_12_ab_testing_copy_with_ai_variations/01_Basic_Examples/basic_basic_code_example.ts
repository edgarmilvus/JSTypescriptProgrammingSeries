/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

// File: generate-ab-test.ts
// Dependencies: @ai-sdk/openai, @supabase/supabase-js, zod, ai

import { createOpenAI } from '@ai-sdk/openai';
import { generateObject } from 'ai';
import { createClient } from '@supabase/supabase-js';
import { z } from 'zod';

// 1. CONFIGURATION & INITIALIZATION
// Initialize the OpenAI provider with the API key.
const openai = createOpenAI({
  apiKey: process.env.OPENAI_API_KEY!,
});

// Initialize the Supabase client for server-side operations.
// Note: In a real app, ensure this runs in a secure environment (e.g., Vercel Server Actions).
const supabase = createClient(
  process.env.SUPABASE_URL!,
  process.env.SUPABASE_ANON_KEY!
);

// 2. DATA SCHEMA DEFINITION
// We use Zod to define the structure of the AI's output. This prevents hallucinations
// and ensures we get exactly what we need (Type Guarding at runtime).
const ABTestVariationSchema = z.object({
  variationA: z.string().describe("The first copy variation (e.g., Subject Line A)"),
  variationB: z.string().describe("The second copy variation (e.g., Subject Line B)"),
  rationale: z.string().describe("A brief explanation of the difference between A and B"),
});

// 3. CORE LOGIC: GENERATE AND STORE
/**
 * Generates A/B test copy variations using GPT-4 and stores them in Supabase.
 * 
 * @param context - The context for the copy (e.g., "Onboarding Email #1")
 * @param goal - The specific conversion goal (e.g., "Open Rate")
 * @returns The stored record ID or an error.
 */
export async function generateAndStoreABTest(
  context: string,
  goal: string
): Promise<{ success: boolean; data?: any; error?: string }> {
  
  // A. Construct the prompt for the AI
  const prompt = `
    You are a marketing copywriter for a SaaS platform. 
    Generate two distinct subject lines for an email.
    
    Context: ${context}
    Goal: Maximize ${goal}.
    
    Variation A should be descriptive and professional.
    Variation B should be punchy and urgent.
    
    Return the result as a JSON object matching the schema.
  `;

  try {
    // B. Generate the object using the Vercel AI SDK
    // This handles the LLM call and parses the response against our Zod schema.
    const { object } = await generateObject({
      model: openai('gpt-4-turbo-preview'),
      schema: ABTestVariationSchema,
      prompt: prompt,
      temperature: 0.7, // Encourage creativity while staying on topic
    });

    // C. Store the result in Supabase
    // We assume a table named 'ab_tests' with columns: 
    // id (uuid), context (text), variation_a (text), variation_b (text), created_at (timestamp)
    const { data, error } = await supabase
      .from('ab_tests')
      .insert([
        {
          context: context,
          goal: goal,
          variation_a: object.variationA,
          variation_b: object.variationB,
          rationale: object.rationale,
        },
      ])
      .select(); // Return the inserted row

    if (error) {
      console.error("Database Error:", error);
      return { success: false, error: error.message };
    }

    return { success: true, data: data?.[0] };

  } catch (error) {
    // D. Error Handling
    // Catching generation errors (e.g., API down, rate limits) or validation errors.
    if (error instanceof Error) {
      return { success: false, error: error.message };
    }
    return { success: false, error: "Unknown error occurred" };
  }
}

// 4. EXECUTION EXAMPLE (Mock)
// This is how you would call the function in a Server Action or API route.
(async () => {
  const result = await generateAndStoreABTest(
    "Welcome email for new signups",
    "Click-through rate"
  );
  
  if (result.success) {
    console.log("✅ A/B Test Variations Generated and Saved:", result.data);
  } else {
    console.error("❌ Failed to generate variations:", result.error);
  }
})();
