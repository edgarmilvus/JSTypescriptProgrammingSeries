/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// pages/api/generate-variations.ts
// Next.js API Route for generating AI copy variations.
// This runs on the server, utilizing the Vercel AI SDK (hypothetical import for context).

import type { NextApiRequest, NextApiResponse } from 'next';
import { generateText } from 'ai'; // Assuming Vercel AI SDK
import { openai } from '@ai-sdk/openai';

/**
 * @description A Generic Type definition for the AI State.
 * This ensures that whatever content type we generate (Headline, Body, etc.),
 * the state structure remains consistent and type-safe.
 * @template T - The type of the payload contained within the state.
 */
interface AIState<T> {
  id: string;
  timestamp: number;
  payload: T;
  metadata: {
    model: string;
    variationType: string;
  };
}

/**
 * @description Input interface for the generation request.
 */
interface GenerationRequest {
  topic: string;
  tone: 'professional' | 'playful' | 'urgent';
  targetAudience: string;
}

/**
 * @description Output interface for the generated variations.
 */
interface GenerationResponse {
  variationA: string;
  variationB: string;
  testId: string;
}

/**
 * @description API Handler for generating copy variations.
 * Uses Generics in the internal state management to ensure type safety.
 */
export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse<GenerationResponse | { error: string }>
) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  const { topic, tone, targetAudience } = req.body as GenerationRequest;

  try {
    // 1. Define the Prompt Chain Logic
    // We construct a structured prompt to ensure GPT-4 generates two distinct variations.
    const systemPrompt = `
      You are an expert copywriter for a SaaS company.
      Generate TWO distinct headlines for a landing page about: "${topic}".
      Tone: ${tone}.
      Target Audience: ${targetAudience}.
      
      Format your response strictly as JSON:
      {
        "variationA": "Headline A text",
        "variationB": "Headline B text"
      }
      
      Ensure variationA and variationB are significantly different in structure and wording.
    `;

    // 2. Execute AI Generation
    const aiResponse = await generateText({
      model: openai('gpt-4-turbo-preview'),
      prompt: systemPrompt,
      temperature: 0.7, // Encourage creativity
    });

    // Parse the JSON response from the AI
    const parsedContent = JSON.parse(aiResponse.text);

    // 3. Manage AI State using Generics
    // We encapsulate the output in a typed state object.
    const aiState: AIState<GenerationResponse> = {
      id: `test_${Date.now()}`,
      timestamp: Date.now(),
      payload: {
        variationA: parsedContent.variationA,
        variationB: parsedContent.variationB,
        testId: `test_${Date.now()}`,
      },
      metadata: {
        model: 'gpt-4-turbo',
        variationType: 'headline',
      },
    };

    // 4. Return the variations to the frontend
    // In a real scenario, we would persist this state to a database (e.g., Redis or Postgres)
    // keyed by aiState.id for later retrieval during the Event Loop processing.
    res.status(200).json(aiState.payload);
  } catch (error) {
    console.error('AI Generation Error:', error);
    res.status(500).json({ error: 'Failed to generate variations' });
  }
}
