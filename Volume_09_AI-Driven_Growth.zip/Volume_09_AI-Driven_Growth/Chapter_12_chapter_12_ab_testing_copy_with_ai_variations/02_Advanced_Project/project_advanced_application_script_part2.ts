/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script_part2.ts
// Description: Advanced Application Script
// ==========================================

// pages/index.tsx
// Frontend Component: Renders the A/B Test and handles Client-Side Tracking.
// Uses Next.js Server-Side Props to fetch variations securely.

import { GetServerSideProps, NextPage } from 'next';
import { useEffect, useState } from 'react';
import { v4 as uuidv4 } from 'uuid';

interface PageProps {
  variationA: string;
  variationB: string;
  testId: string;
}

const LandingPage: NextPage<PageProps> = ({ variationA, variationB, testId }) => {
  // Randomly select a variation on the server or client (here we do it in state for hydration)
  const [activeVariation, setActiveVariation] = useState<string>('');
  const [viewId] = useState<string>(uuidv4()); // Unique ID for this specific user session

  useEffect(() => {
    // Determine variation on mount to ensure hydration matches
    const choice = Math.random() < 0.5 ? variationA : variationB;
    setActiveVariation(choice);

    // Log the impression immediately
    // In a real app, this would be a beacon or a dedicated API call
    fetch('/api/analytics/track', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        type: 'IMPRESSION',
        testId,
        viewId,
        variation: choice,
        timestamp: Date.now(),
      }),
    });
  }, [variationA, variationB, testId, viewId]);

  const handleConversion = () => {
    // Track the conversion event
    fetch('/api/analytics/track', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        type: 'CONVERSION',
        testId,
        viewId,
        variation: activeVariation,
        timestamp: Date.now(),
      }),
    });
    alert('Conversion tracked!');
  };

  return (
    <div style={{ padding: '2rem', fontFamily: 'sans-serif' }}>
      <h1 style={{ fontSize: '2.5rem', marginBottom: '1rem' }}>
        {activeVariation || 'Loading...'}
      </h1>
      <p>Running Test ID: {testId}</p>
      <button 
        onClick={handleConversion} 
        style={{ padding: '10px 20px', fontSize: '1rem', cursor: 'pointer' }}
      >
        Sign Up Now
      </button>
    </div>
  );
};

export const getServerSideProps: GetServerSideProps = async () => {
  // In a real app, we would fetch pre-generated tests from a DB.
  // For this demo, we simulate the API call or generate fresh ones.
  // We'll call our internal generation API here for SSR.
  
  const res = await fetch(`${process.env.NEXT_PUBLIC_BASE_URL}/api/generate-variations`, {
    method: 'POST',
    body: JSON.stringify({
      topic: 'AI-Powered Analytics',
      tone: 'professional',
      targetAudience: 'CTOs',
    }),
  });
  
  const data = await res.json();

  return {
    props: {
      variationA: data.variationA,
      variationB: data.variationB,
      testId: data.testId,
    },
  };
};

export default LandingPage;
