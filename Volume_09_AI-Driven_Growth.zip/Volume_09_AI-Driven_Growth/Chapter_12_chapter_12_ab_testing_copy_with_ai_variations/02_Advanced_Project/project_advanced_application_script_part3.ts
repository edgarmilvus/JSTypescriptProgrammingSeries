/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script_part3.ts
// Description: Advanced Application Script
// ==========================================

// pages/api/analytics/track.ts
// Analytics API Endpoint.
// This endpoint receives raw event data and queues it for processing.

import type { NextApiRequest, NextApiResponse } from 'next';

// A simple in-memory queue. In production, use Redis or AWS SQS.
const eventQueue: any[] = [];

export default function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method === 'POST') {
    const eventData = req.body;

    // 1. Immediate Acknowledgment
    // We push the event to the queue and respond immediately.
    // This utilizes the non-blocking nature of Node.js.
    eventQueue.push(eventData);
    
    // 2. Trigger the Event Loop processing (simulated via setTimeout)
    // This allows the HTTP response to finish before heavy processing begins.
    if (!global.isProcessing) {
      setTimeout(processQueue, 0);
    }

    return res.status(200).json({ status: 'received' });
  }
  return res.status(405).end();
}

/**
 * @description The Event Loop Consumer.
 * This function runs asynchronously, processing the queue of analytics events.
 * It calculates conversion rates and determines the winning variation.
 */
async function processQueue() {
  if (global.isProcessing) return;
  global.isProcessing = true;

  while (eventQueue.length > 0) {
    // Simulate async database write or heavy calculation
    await new Promise(resolve => setTimeout(resolve, 100)); // Simulate network latency
    
    const event = eventQueue.shift();
    console.log(`[Event Loop] Processing event: ${event.type} for Test: ${event.testId}`);

    // Logic: Aggregate data to find the winner
    // In a real system, this would update a Redis sorted set or SQL table
    // e.g., INCR "test:variationA:impressions" or "test:variationA:conversions"
    
    if (event.type === 'CONVERSION') {
      console.log(`>>> WINNER DETECTED: ${event.variation} converted! <<<`);
    }
  }

  global.isProcessing = false;
}

// Augment global namespace for the simple queue lock
declare global {
  var isProcessing: boolean;
}
