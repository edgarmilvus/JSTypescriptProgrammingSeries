/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// 1. Define strict interfaces for type safety
interface VariationRequest {
  baseText: string;
  constraints: string[];
  optionalKeywords?: string[];
}

interface ValidationStatus {
  passed: boolean;
  reasons: string[];
}

interface VariationResponse {
  generatedText: string;
  model: string;
  validationStatus: ValidationStatus;
}

/**
 * Mock function to simulate GPT-4 API call.
 * In a real scenario, you would use the OpenAI SDK (e.g., `await openai.chat.completions.create(...)`).
 */
async function callGPT4(systemPrompt: string, userPrompt: string): Promise<string> {
  // Simulating network delay
  await new Promise(resolve => setTimeout(resolve, 100));
  // Mock response logic: Just appending constraints to base text for demonstration
  return `[${systemPrompt}] ${userPrompt}`;
}

// 2. Helper function to validate the generated text
function validateOutput(text: string, requiredKeywords?: string[]): ValidationStatus {
  const reasons: string[] = [];
  
  // Check Length (50 - 120 characters)
  if (text.length < 50) reasons.push("Text is too short (under 50 chars).");
  if (text.length > 120) reasons.push("Text is too long (over 120 chars).");

  // Check Keywords
  if (requiredKeywords && requiredKeywords.length > 0) {
    const hasKeyword = requiredKeywords.some(keyword => 
      text.toLowerCase().includes(keyword.toLowerCase())
    );
    if (!hasKeyword) reasons.push(`Missing required keywords: ${requiredKeywords.join(", ")}`);
  }

  return {
    passed: reasons.length === 0,
    reasons: reasons
  };
}

// 3. Main Function Implementation
async function generateVariations(request: VariationRequest): Promise<VariationResponse[]> {
  const { baseText, constraints, optionalKeywords } = request;
  const responses: VariationResponse[] = [];

  // Generate 2 variations for demonstration (could be N variations)
  for (let i = 0; i < 2; i++) {
    // Construct Dynamic System Prompt based on constraints
    const systemPrompt = `You are an expert copywriter. Rewrite the text adhering to these constraints: ${constraints.join(", ")}. Ensure the output is engaging and concise.`;
    
    // Call the API (Mocked here)
    const generatedText = await callGPT4(systemPrompt, baseText);
    
    // Apply Guardrails
    const validationStatus = validateOutput(generatedText, optionalKeywords);

    responses.push({
      generatedText,
      model: "gpt-4", // Hardcoded for this exercise
      validationStatus
    });
  }

  return responses;
}

// Example Usage:
// const request: VariationRequest = {
//   baseText: "Buy our new shoes today.",
//   constraints: ["Urgent Tone", "Focus on Comfort"],
//   optionalKeywords: ["buy", "discount"]
// };
// generateVariations(request).then(console.log);
