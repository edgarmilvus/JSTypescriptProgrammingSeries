/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState } from 'react';

// 1. Define Props Interface
interface CopyVariantPreviewerProps {
  variations: string[];
  campaignName: string;
  onChange?: (index: number, text: string) => void;
}

// 2. Define Styles (Inline for simplicity in this exercise)
const styles = {
  container: { display: 'flex', gap: '20px', fontFamily: 'Arial, sans-serif' },
  list: { display: 'flex', flexDirection: 'column', gap: '10px', width: '300px' },
  item: { padding: '10px', border: '1px solid #ccc', cursor: 'pointer', borderRadius: '4px' },
  itemActive: { borderColor: '#007bff', backgroundColor: '#e7f3ff', fontWeight: 'bold' },
  preview: { 
    flex: 1, 
    border: '1px solid #ddd', 
    padding: '20px', 
    borderRadius: '8px', 
    backgroundColor: '#f9f9f9',
    boxShadow: '0 2px 4px rgba(0,0,0,0.1)'
  },
  adCard: {
    border: '1px solid #ccc',
    padding: '15px',
    backgroundColor: '#fff',
    borderRadius: '8px',
    maxWidth: '400px'
  },
  header: { color: '#555', fontSize: '0.9rem', marginBottom: '10px' }
};

const CopyVariantPreviewer: React.FC<CopyVariantPreviewerProps> = ({ 
  variations, 
  campaignName, 
  onChange 
}) => {
  // 3. State Management
  const [selectedIndex, setSelectedIndex] = useState<number>(0);

  const handleSelect = (index: number) => {
    setSelectedIndex(index);
    if (onChange) {
      onChange(index, variations[index]);
    }
  };

  return (
    <div style={styles.container}>
      {/* 4. Render List of Variations */}
      <div style={styles.list}>
        <h3>{campaignName}</h3>
        {variations.map((text, index) => (
          <div
            key={index}
            style={index === selectedIndex ? { ...styles.item, ...styles.itemActive } : styles.item}
            onClick={() => handleSelect(index)}
          >
            {text.substring(0, 50)}{text.length > 50 ? '...' : ''}
          </div>
        ))}
      </div>

      {/* 5. Render Ad Card Preview */}
      <div style={styles.preview}>
        <h4>Ad Preview</h4>
        <div style={styles.adCard}>
          <div style={styles.header}>Sponsored • {campaignName}</div>
          <div style={{ fontSize: '1.1rem', color: '#333' }}>
            {variations[selectedIndex]}
          </div>
          <div style={{ marginTop: '10px', fontSize: '0.8rem', color: '#888' }}>
            example.com • Learn More
          </div>
        </div>
      </div>
    </div>
  );
};

export default CopyVariantPreviewer;
