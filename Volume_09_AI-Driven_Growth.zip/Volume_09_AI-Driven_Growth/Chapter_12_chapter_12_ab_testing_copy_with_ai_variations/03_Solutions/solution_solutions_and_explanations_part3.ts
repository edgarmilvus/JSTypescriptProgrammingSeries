/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

// 1. Define Input and Output Interfaces
interface TestMetrics {
  variantA: { visitors: number; conversions: number };
  variantB: { visitors: number; conversions: number };
}

interface SignificanceResult {
  zScore: number;
  pValue: number;
  isSignificant: boolean;
}

// 2. Helper function for Standard Normal Distribution (CDF)
// Approximation of the error function needed for P-value calculation
function normalCDF(x: number): number {
  const t = 1 / (1 + 0.2316419 * Math.abs(x));
  const d = 0.3989423 * Math.exp(-x * x / 2);
  const prob = d * t * (0.3193815 + t * (-0.3565638 + t * (1.781478 + t * (-1.821256 + t * 1.330274))));
  return x > 0 ? 1 - prob : prob;
}

function calculateSignificance(metrics: TestMetrics): SignificanceResult {
  const { variantA, variantB } = metrics;

  // 3. Handle Edge Cases (Zero visitors)
  if (variantA.visitors === 0 || variantB.visitors === 0) {
    return { zScore: 0, pValue: 1.0, isSignificant: false };
  }

  // 4. Calculate Conversion Rates
  const pA = variantA.conversions / variantA.visitors;
  const pB = variantB.conversions / variantB.visitors;

  // 5. Calculate Pooled Probability
  const pPool = (variantA.conversions + variantB.conversions) / (variantA.visitors + variantB.visitors);

  // 6. Calculate Standard Error (SE)
  // SE = sqrt( p_pool * (1 - p_pool) * (1/n1 + 1/n2) )
  const se = Math.sqrt(
    pPool * (1 - pPool) * (1 / variantA.visitors + 1 / variantB.visitors)
  );

  // Avoid division by zero if SE is 0 (rare but possible)
  if (se === 0) {
    return { zScore: 0, pValue: 1.0, isSignificant: false };
  }

  // 7. Calculate Z-Score
  const zScore = (pA - pB) / se;

  // 8. Calculate P-Value (Two-tailed test)
  const pValue = 2 * (1 - normalCDF(Math.abs(zScore)));

  // 9. Determine Significance (Alpha = 0.05)
  const isSignificant = pValue < 0.05;

  return {
    zScore,
    pValue,
    isSignificant
  };
}

// Example Usage:
// const metrics = { variantA: { visitors: 1000, conversions: 50 }, variantB: { visitors: 1000, conversions: 30 } };
// console.log(calculateSignificance(metrics));
