/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

// 1. Define Interfaces
interface GrowthLoopResult {
  winningCopy: string;
  nextIterationPrompt: string;
  confidence: number; // 0.0 to 1.0
}

// Mocks for external dependencies
const mockVariations = [
  "Buy now! Limited time offer on premium shoes.", // Variant A (Simulated Winner)
  "Our shoes are available for purchase now."      // Variant B (Simulated Loser)
];

// Mock function to simulate the AI generation from Exercise 1
async function mockGenerateVariations(): Promise<string[]> {
  return mockVariations;
}

// Mock function to simulate the Stat Calc from Exercise 3
function mockCalculateSignificance(): { isSignificant: boolean; pValue: number } {
  // Simulating a significant result where Variant A wins
  return { isSignificant: true, pValue: 0.02 }; 
}

// 2. Main Orchestrator Function
async function runGrowthLoop(basePrompt: string, targetMetric: string): Promise<GrowthLoopResult> {
  console.log(`Starting growth loop for: ${basePrompt}`);

  // Step 1: Generate Variations
  const variations = await mockGenerateVariations();
  
  // Step 2: Simulate A/B Test Data (High volume for significance)
  // In a real app, this data comes from an analytics platform
  const simulatedMetrics = {
    variantA: { visitors: 1000, conversions: 50 }, // 5% CR
    variantB: { visitors: 1000, conversions: 20 }  // 2% CR
  };

  // Step 3: Calculate Significance (Using logic from Ex 3)
  // For this demo, we use the mock, but in reality, we'd call calculateSignificance(simulatedMetrics)
  const stats = mockCalculateSignificance();

  if (!stats.isSignificant) {
    throw new Error("Test results not statistically significant. Cannot determine winner yet.");
  }

  // Step 4: Identify Winner and Loser
  // Logic: Compare conversion rates. 
  const winnerIndex = simulatedMetrics.variantA.conversions > simulatedMetrics.variantB.conversions ? 0 : 1;
  const winningCopy = variations[winnerIndex];
  const losingCopy = variations[winnerIndex === 0 ? 1 : 0];

  // Step 5: Analyze Loser & Construct Refinement Prompt
  // Simple heuristic analysis: Check for "power words" or lack thereof.
  const winningKeywords = ["offer", "buy", "limited", "premium"];
  const losingKeywords = ["available", "purchase"]; // Passive/Standard words
  
  let analysis = "The winning copy used active, urgent language. ";
  
  // Analyze why the loser lost
  const loserIsPassive = losingKeywords.some(w => losingCopy.toLowerCase().includes(w));
  if (loserIsPassive) {
    analysis += "The losing copy was too passive. ";
  }

  const nextIterationPrompt = `Iterate on the base prompt. ${analysis}Focus on using imperative verbs and scarcity tactics. Avoid passive phrasing. Previous loser: "${losingCopy}"`;

  // Step 6: Return Result
  return {
    winningCopy,
    nextIterationPrompt,
    confidence: 1 - stats.pValue // e.g., 0.98 confidence
  };
}

// Example Usage:
// runGrowthLoop("Promote our new shoe line", "clicks").then(console.log);
