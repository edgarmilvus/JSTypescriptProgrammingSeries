/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

// 1. Define Interfaces
interface SemanticMatch {
  existingContent: string;
  similarity: number;
}

// Mock Database Client (Simulating 'pg' or 'slonik')
const mockDb = {
  query: async (text: string, params: any[]) => {
    // Simulate a database response
    // If the new text is semantically similar, return a match
    if (params[0].includes("similar_vector")) {
      return {
        rows: [
          { content: "Existing similar ad copy", similarity: 0.98 }
        ]
      };
    }
    // If no match
    return { rows: [] };
  }
};

// 2. Mock Embedding Function
// In production, use OpenAI or a local model
async function getEmbedding(text: string): Promise<number[]> {
  // Simulating a 384-dim vector (simplified for demo)
  // In reality, this would be a complex array of floats
  return Array(384).fill(0).map(() => Math.random()); 
}

// 3. Main Search Function
async function findSemanticDuplicates(
  newVariation: string, 
  threshold: number
): Promise<SemanticMatch | null> {
  
  // Generate embedding for the new variation
  const embedding = await getEmbedding(newVariation);
  
  // Convert embedding array to PostgreSQL vector string format: '[0.1, 0.2, ...]'
  const embeddingString = JSON.stringify(embedding);

  // 4. Construct SQL Query
  // We use the cosine similarity operator <=>.
  // Note: For HNSW index usage, the query must be formatted correctly.
  const query = `
    SELECT content, 1 - (embedding <=> $1::vector) as similarity
    FROM tested_copy
    WHERE 1 - (embedding <=> $1::vector) > $2
    ORDER BY similarity DESC
    LIMIT 1;
  `;

  // 5. Execute Query
  // In a real scenario, this connects to PostgreSQL
  const result = await mockDb.query(query, [embeddingString, threshold]);

  if (result.rows.length > 0) {
    return {
      existingContent: result.rows[0].content,
      similarity: result.rows[0].similarity
    };
  }

  return null;
}

// Example Usage:
// findSemanticDuplicates("Buy our new shoes today", 0.95).then(console.log);
