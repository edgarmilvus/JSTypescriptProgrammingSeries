/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part2.ts
// Description: Theoretical Foundations
// ==========================================

// types/feature-flags.ts
// Defining the shape of our feature flag configuration
export type FeatureFlagKey = 
  | 'enable_programmatic_seo_v2' 
  | 'use_new_embedding_model' 
  | 'rollout_ai_writer_beta';

export interface FlagContext {
  userId: string;
  email: string;
  segment: 'internal' | 'beta' | 'public';
  // Custom attributes for specific AI experiments
  experimentGroups?: Record<string, string>;
}

// services/flagService.ts
// Abstracting the decision logic. In a real app, this would fetch from a remote source.
// For theoretical purposes, we simulate the logic here.

/**
 * Evaluates feature flags based on the provided context.
 * This function adheres to SRP: its sole responsibility is determining feature state.
 */
export async function evaluateFlags(
  context: FlagContext
): Promise<Set<FeatureFlagKey>> {
  const enabledFlags = new Set<FeatureFlagKey>();

  // Example Rule: Internal users always get the latest AI features
  if (context.segment === 'internal') {
    enabledFlags.add('enable_programmatic_seo_v2');
    enabledFlags.add('use_new_embedding_model');
  }

  // Example Rule: Deterministic hashing for percentage rollout
  // This simulates a remote flag service's percentage logic
  if (context.segment === 'beta') {
    const hash = simpleHash(context.userId);
    const percentage = (hash % 100) / 100;

    // Rollout to 10% of beta users
    if (percentage < 0.1) {
      enabledFlags.add('rollout_ai_writer_beta');
    }
  }

  return enabledFlags;
}

// Simple deterministic hash function for demonstration
function simpleHash(str: string): number {
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    const char = str.charCodeAt(i);
    hash = (hash << 5) - hash + char;
    hash = hash & hash; // Convert to 32bit integer
  }
  return Math.abs(hash);
}
