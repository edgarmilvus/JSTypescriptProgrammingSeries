/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

// feature-flag-example.ts

/**
 * @description Types for feature flag configuration and evaluation context.
 * Adheres to the Single Responsibility Principle (SRP) by strictly defining data shapes
 * without mixing in logic.
 */

type FeatureFlagName = 'new_ai_content_template_v1' | 'experimental_seo_keyword_extraction';

type EvaluationContext = {
    userId: string;
    userAgent: string;
    // In a real app, this might be geo-location, subscription tier, etc.
};

type FlagConfig = {
    isEnabled: boolean;
    rolloutPercentage: number; // 0 to 100
    allowedUserIds?: string[]; // Specific overrides (e.g., internal testers)
};

/**
 * @class FeatureFlagManager
 * @description Manages feature flag logic. 
 * Responsibilities:
 * 1. Evaluate if a flag is active for a given context.
 * 2. Handle deterministic rollout percentages (using user ID hashing).
 */
class FeatureFlagManager {
    private flags: Map<FeatureFlagName, FlagConfig>;

    constructor() {
        this.flags = new Map();
        this.initializeFlags();
    }

    /**
     * Initializes flags with default configurations.
     * In a real SaaS, this would fetch from a remote config service (e.g., LaunchDarkly, Split).
     */
    private initializeFlags(): void {
        this.flags.set('new_ai_content_template_v1', {
            isEnabled: true,
            rolloutPercentage: 10, // Only 10% of users see this
            allowedUserIds: ['user-internal-001'] // Always enable for internal tester
        });

        this.flags.set('experimental_seo_keyword_extraction', {
            isEnabled: false, // Completely disabled
            rolloutPercentage: 0
        });
    }

    /**
     * Checks if a feature is enabled for a specific evaluation context.
     * @param flagName - The name of the feature flag.
     * @param context - The user/request context.
     * @returns boolean - True if the feature should be enabled.
     */
    public isEnabled(flagName: FeatureFlagName, context: EvaluationContext): boolean {
        const config = this.flags.get(flagName);

        // 1. If flag doesn't exist or is explicitly disabled, return false immediately.
        if (!config || !config.isEnabled) {
            return false;
        }

        // 2. Check for explicit user overrides (e.g., internal testers).
        if (config.allowedUserIds && config.allowedUserIds.includes(context.userId)) {
            return true;
        }

        // 3. Calculate deterministic percentage rollout based on User ID.
        // We use a simple hashing algorithm to map a string to a number 0-99.
        const hash = this.hashString(context.userId);
        const percentageBucket = hash % 100;

        return percentageBucket < config.rolloutPercentage;
    }

    /**
     * A simple string hashing function (djb2 algorithm) for deterministic rollout.
     * Ensures the same user always falls into the same bucket.
     * @param str - String to hash.
     * @returns number - Integer hash value.
     */
    private hashString(str: string): number {
        let hash = 5381;
        for (let i = 0; i < str.length; i++) {
            hash = (hash * 33) ^ str.charCodeAt(i);
        }
        return Math.abs(hash);
    }
}

/**
 * @description Simulating the AI Content Service that consumes the feature flag.
 * This demonstrates the decoupling of deployment and release.
 */

// Mock function representing the old AI content generation logic
function generateOldContent(topic: string): string {
    return `[OLD TEMPLATE] Here is a standard article about ${topic}.`;
}

// Mock function representing the new AI content generation logic (behind the flag)
function generateNewContent(topic: string): string {
    return `[NEW AI TEMPLATE] Optimized SEO Article: Comprehensive Guide to ${topic}.`;
}

/**
 * Main application logic (e.g., an API route handler or Server Component).
 * This function decides which content generator to invoke.
 */
async function handleContentRequest(
    topic: string, 
    context: EvaluationContext, 
    flagManager: FeatureFlagManager
): Promise<string> {
    
    // Check the feature flag
    const useNewTemplate = flagManager.isEnabled('new_ai_content_template_v1', context);

    // Branch logic based on flag status
    if (useNewTemplate) {
        console.log(`[Feature Flag Active] User ${context.userId} receiving NEW AI content.`);
        return generateNewContent(topic);
    } else {
        console.log(`[Feature Flag Inactive] User ${context.userId} receiving OLD content.`);
        return generateOldContent(topic);
    }
}

/**
 * @description Execution Block - Simulating requests from different users.
 */
(async () => {
    const manager = new FeatureFlagManager();

    // Scenario 1: Internal Tester (Always gets new feature)
    const internalUser = { userId: 'user-internal-001', userAgent: 'Chrome' };
    const result1 = await handleContentRequest('Feature Flags', internalUser, manager);
    console.log('Result 1:', result1);

    // Scenario 2: Regular User A (Likely gets old feature due to 10% rollout)
    // Note: The hash of 'user-123' determines the bucket. 
    // In a real scenario, we calculate this dynamically. 
    // For this demo, we assume 'user-123' falls outside the 10% bucket.
    const regularUserA = { userId: 'user-123', userAgent: 'Safari' };
    const result2 = await handleContentRequest('AI Growth', regularUserA, manager);
    console.log('Result 2:', result2);

    // Scenario 3: Experimental Flag (Disabled)
    const powerUser = { userId: 'user-power-999', userAgent: 'Firefox' };
    // We are checking a different flag here, though the handler currently only checks one.
    // Let's just log the check explicitly.
    const isEnabled = manager.isEnabled('experimental_seo_keyword_extraction', powerUser);
    console.log(`Result 3: Experimental SEO Extraction enabled? ${isEnabled}`);
})();
