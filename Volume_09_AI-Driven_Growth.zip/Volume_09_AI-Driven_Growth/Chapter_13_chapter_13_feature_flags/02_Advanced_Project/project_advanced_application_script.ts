/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

/**
 * Advanced Application Script: AI-Driven Feature Flag Gatekeeper
 * Framework: Next.js (App Router) + TypeScript
 * Context: Programmatic SEO & Growth Engineering
 */

import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';

// -----------------------------------------------------------------------------
// 1. Domain Definitions & Types
// -----------------------------------------------------------------------------

/**
 * Represents the state of a feature flag for AI content generation.
 * We use strict typing to enforce the SRP (Single Responsibility Principle)
 * by ensuring the flag configuration is isolated from business logic.
 */
type AIFeatureFlag = {
  isEnabled: boolean;
  rolloutPercentage: number; // 0-100
  targetModel: 'gpt-3.5-turbo' | 'gpt-4-turbo-preview' | 'gpt-4o';
  useWasmThreads: boolean; // Optimization for heavy computation
  metadata: {
    description: string;
    owner: string;
  };
};

/**
 * Input schema for the API route. Validates the request payload
 * before it touches the inference logic.
 */
const RequestSchema = z.object({
  pageSlug: z.string().min(1),
  userId: z.string().optional(),
});

// -----------------------------------------------------------------------------
// 2. Feature Flag Service (The Gatekeeper)
// -----------------------------------------------------------------------------

/**
 * Mock Service to fetch feature flag configurations.
 * In production, this would be an async call to a remote config provider (e.g., LaunchDarkly).
 * 
 * Why separate this? Adheres to SRP. The flag logic shouldn't live inside the AI prompt logic.
 */
class FeatureFlagService {
  /**
   * Determines if a specific AI feature is active for the current context.
   * Implements a deterministic rollout strategy based on user ID hash.
   */
  async getFlag(flagKey: string, userId?: string): Promise<AIFeatureFlag> {
    // Simulate fetching remote configuration
    const config: Record<string, AIFeatureFlag> = {
      'programmatic-seo-gen-v2': {
        isEnabled: true,
        rolloutPercentage: 50, // 50% of users get the new model
        targetModel: 'gpt-4-turbo-preview',
        useWasmThreads: true, // Enable parallel processing for complex SEO data
        metadata: { description: 'Rollout of structured JSON output for SEO', owner: 'Growth Team' }
      },
      'programmatic-seo-gen-v1': {
        isEnabled: true,
        rolloutPercentage: 100,
        targetModel: 'gpt-3.5-turbo',
        useWasmThreads: false,
        metadata: { description: 'Legacy text generation', owner: 'Legacy' }
      }
    };

    const flag = config[flagKey];
    
    if (!flag) {
      return { isEnabled: false, rolloutPercentage: 0, targetModel: 'gpt-3.5-turbo', useWasmThreads: false, metadata: { description: 'Default', owner: 'System' } };
    }

    // Deterministic Rollout Logic
    if (userId && flag.rolloutPercentage < 100) {
      const hash = this.hashString(userId);
      const isAssigned = (hash % 100) < flag.rolloutPercentage;
      return { ...flag, isEnabled: flag.isEnabled && isAssigned };
    }

    return flag;
  }

  /**
   * Simple hash function for deterministic user assignment.
   */
  private hashString(str: string): number {
    let hash = 0;
    for (let i = 0; i < str.length; i++) {
      const char = str.charCodeAt(i);
      hash = (hash << 5) - hash + char;
      hash = hash & hash; // Convert to 32-bit integer
    }
    return Math.abs(hash);
  }
}

// -----------------------------------------------------------------------------
// 3. AI Inference Module (The Engine)
// -----------------------------------------------------------------------------

/**
 * Abstracts the AI generation logic.
 * Note: We do not call the LLM directly here; we simulate the inference step.
 * This module is responsible ONLY for generating content based on the model selected.
 */
class AIContentGenerator {
  /**
   * Generates SEO content using the specified model.
   * 
   * @param model - The LLM model identifier determined by the feature flag.
   * @param slug - The SEO slug used as context for generation.
   * @param useWasm - If true, simulates heavy parallel processing (WASM Threads).
   */
  async generate(model: string, slug: string, useWasm: boolean): Promise<string> {
    console.log(`[AI Engine] Initializing generation with model: ${model}`);
    
    if (useWasm) {
      console.log('[AI Engine] Optimizing pipeline with WASM Threads for parallel data processing...');
      // In a real scenario, this would trigger a WebAssembly module to pre-process
      // large datasets (e.g., keyword clusters) in parallel before sending to LLM.
      await this.simulateWasmProcessing();
    }

    // Simulate LLM API Call
    const mockResponses: Record<string, string> = {
      'gpt-3.5-turbo': `Legacy Content: This is a standard SEO paragraph for ${slug}. It is generic and cost-effective.`,
      'gpt-4-turbo-preview': `Advanced Content: Structured data for ${slug}. \n\n## Key Concepts\n1. Semantic Richness\n2. Entity Extraction\n3. Programmatic Scalability`
    };

    await new Promise(resolve => setTimeout(resolve, 300)); // Simulate network latency
    return mockResponses[model] || mockResponses['gpt-3.5-turbo'];
  }

  /**
   * Simulates the heavy computation handled by WASM Threads.
   * This keeps the JS main thread unblocked.
   */
  private async simulateWasmProcessing(): Promise<void> {
    // Placeholder for OffscreenCanvas or WebWorker communication
    return new Promise(resolve => setTimeout(resolve, 100));
  }
}

// -----------------------------------------------------------------------------
// 4. Next.js API Route (The Integration Layer)
// -----------------------------------------------------------------------------

/**
 * POST /api/generate-seo-content
 * 
 * The entry point of the application. It orchestrates the Feature Flag check
 * and the AI generation based on the result.
 * 
 * Architecture Flow:
 * 1. Validate Input
 * 2. Check Feature Flags (Gatekeeper)
 * 3. Route to appropriate AI Model (Strategy Pattern)
 * 4. Return Safe Response
 */
export async function POST(request: NextRequest) {
  try {
    // 4.1 Input Validation (SRP: Isolate validation from logic)
    const body = await request.json();
    const { pageSlug, userId } = RequestSchema.parse(body);

    // 4.2 Initialize Services
    const flagService = new FeatureFlagService();
    const aiEngine = new AIContentGenerator();

    // 4.3 Evaluate Feature Flag
    // We check for 'programmatic-seo-gen-v2' first. If disabled or not rolled out, fallback to v1.
    const v2Flag = await flagService.getFlag('programmatic-seo-gen-v2', userId);
    
    let selectedModel: string;
    let useWasm: boolean;

    if (v2Flag.isEnabled) {
      selectedModel = v2Flag.targetModel;
      useWasm = v2Flag.useWasmThreads;
      console.log(`[Growth Engine] User ${userId} assigned to V2 experiment.`);
    } else {
      // Fallback strategy
      const v1Flag = await flagService.getFlag('programmatic-seo-gen-v1', userId);
      selectedModel = v1Flag.targetModel;
      useWasm = v1Flag.useWasmThreads;
      console.log(`[Growth Engine] User ${userId} assigned to V1 control.`);
    }

    // 4.4 Execute Inference
    const content = await aiEngine.generate(selectedModel, pageSlug, useWasm);

    // 4.5 Return Structured Response
    // In a real app, we might cache this response based on the flag state.
    return NextResponse.json({
      success: true,
      data: {
        content,
        meta: {
          modelUsed: selectedModel,
          featureFlag: v2Flag.isEnabled ? 'v2' : 'v1',
          timestamp: new Date().toISOString()
        }
      }
    });

  } catch (error) {
    console.error('Error in SEO Generation Pipeline:', error);
    // Safe fallback: Return generic content to ensure site stability
    return NextResponse.json(
      { success: false, error: 'Generation failed', content: 'Default fallback content.' },
      { status: 500 }
    );
  }
}
