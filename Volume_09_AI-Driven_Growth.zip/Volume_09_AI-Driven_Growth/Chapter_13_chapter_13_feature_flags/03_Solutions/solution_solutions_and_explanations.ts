/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// src/hooks/useFeatureFlags.ts
import { useState, useCallback } from 'react';

// Define the shape of our state
type FeatureFlags = Record<string, boolean>;

interface UseFeatureFlagsReturn {
  flags: FeatureFlags;
  toggleFlag: (key: string) => void;
  resetToInitial: () => void;
}

export const useFeatureFlags = (initialFlags: FeatureFlags): UseFeatureFlagsReturn => {
  // Initialize state with the initial flags
  const [flags, setFlags] = useState<FeatureFlags>(initialFlags);

  // useCallback ensures the function reference is stable
  const toggleFlag = useCallback((key: string) => {
    setFlags((prevFlags) => {
      // Check if the key exists to avoid creating undefined properties
      if (!(key in prevFlags)) {
        console.warn(`Flag "${key}" does not exist.`);
        return prevFlags;
      }
      
      // Create a new object (Immutable update)
      return {
        ...prevFlags,
        [key]: !prevFlags[key],
      };
    });
  }, []);

  const resetToInitial = useCallback(() => {
    // Simply set the state back to the initial object reference
    // or create a new copy to ensure strict immutability if needed downstream
    setFlags({ ...initialFlags });
  }, [initialFlags]);

  return {
    flags,
    toggleFlag,
    resetToInitial,
  };
};
