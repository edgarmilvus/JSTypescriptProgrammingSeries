/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part10.ts
// Description: Solutions and Explanations
// ==========================================

// src/utils/flagGraph.ts

export interface FlagDependency {
  name: string;
  requires?: string[];
}

/**
 * Generates a Graphviz DOT representation of the dependency graph.
 */
export function generateDotGraph(dependencies: FlagDependency[]): string {
  let dot = 'digraph FlagDependencies {\n';
  dot += '  rankdir=TB;\n'; // Top-to-Bottom layout
  
  dependencies.forEach(node => {
    // Create a node for each flag
    dot += `  "${node.name}";\n`;
    
    // Create edges for dependencies
    if (node.requires) {
      node.requires.forEach(dep => {
        // Edge: Flag -> Dependency (Flag depends on Dependency)
        dot += `  "${node.name}" -> "${dep}";\n`;
      });
    }
  });
  
  dot += '}';
  return dot;
}

/**
 * Performs a topological sort on the dependency graph.
 * Returns an ordered array of flag names.
 * Throws an error if a circular dependency is detected.
 */
export function getSafeActivationOrder(dependencies: FlagDependency[]): string[] {
  const graph: Map<string, string[]> = new Map();
  const inDegree: Map<string, number> = new Map();
  
  // Initialize graph and in-degree map
  dependencies.forEach(node => {
    graph.set(node.name, node.requires || []);
    inDegree.set(node.name, 0);
  });

  // Calculate in-degrees (number of dependencies pointing to a node)
  dependencies.forEach(node => {
    if (node.requires) {
      node.requires.forEach(dep => {
        if (inDegree.has(dep)) {
          inDegree.set(dep, inDegree.get(dep)! + 1);
        }
      });
    }
  });

  // Kahn's Algorithm
  const queue: string[] = [];
  const result: string[] = [];

  // Add nodes with 0 dependencies (in-degree) to the queue
  dependencies.forEach(node => {
    if (inDegree.get(node.name) === 0) {
      queue.push(node.name);
    }
  });

  while (queue.length > 0) {
    const current = queue.shift()!;
    result.push(current);

    // Iterate over neighbors (dependencies of current node)
    // Note: In our graph Map, 'current' maps to its *required* dependencies.
    // However, for topological sort, we need to find nodes that depend on 'current'.
    // To optimize, we should build an adjacency list of "who depends on whom".
    
    // Re-building the adjacency list for "dependents" (reverse graph)
    const dependents: string[] = [];
    dependencies.forEach(node => {
      if (node.requires && node.requires.includes(current)) {
        dependents.push(node.name);
      }
    });

    dependents.forEach(dependent => {
      const currentDegree = inDegree.get(dependent)!;
      inDegree.set(dependent, currentDegree - 1);
      
      if (inDegree.get(dependent) === 0) {
        queue.push(dependent);
      }
    });
  }

  // Check for circular dependencies
  if (result.length !== dependencies.length) {
    throw new Error('Circular dependency detected in feature flags.');
  }

  return result;
}
