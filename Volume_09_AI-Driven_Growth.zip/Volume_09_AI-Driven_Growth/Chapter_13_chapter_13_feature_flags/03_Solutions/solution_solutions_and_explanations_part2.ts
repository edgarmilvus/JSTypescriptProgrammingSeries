/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

// src/components/ABTestRenderer.tsx
import React from 'react';

// Assume this context exists and is provided higher up in the tree
// For the sake of this solution, we'll define a mock context usage.
// In a real app, you would import the actual context.
interface FlagContextType {
  getFlag: (flagName: string) => boolean;
}
const FeatureFlagContext = React.createContext<FlagContextType | undefined>(undefined);

interface ABTestRendererProps<T> {
  flagName: string;
  variantA: T;
  variantB: T;
  render: (content: T) => React.ReactNode;
}

export const ABTestRenderer = <T,>({
  flagName,
  variantA,
  variantB,
  render,
}: ABTestRendererProps<T>) => {
  const context = React.useContext(FeatureFlagContext);

  if (!context) {
    throw new Error('ABTestRenderer must be used within a FeatureFlagContext.Provider');
  }

  const isEnabled = context.getFlag(flagName);
  
  // Select the content based on the flag
  const content = isEnabled ? variantB : variantA;

  // Execute the render prop with the selected content
  return <>{render(content)}</>;
};
