/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part9.ts
// Description: Solutions and Explanations
// ==========================================

// src/scripts/analyzeFlags.ts
import * as fs from 'fs/promises';
import * as path from 'path';

interface FlagReport {
  active: string[];
  potentially_stale: string[];
}

/**
 * Recursively finds all files with specific extensions in a directory.
 */
async function findFiles(dir: string, ext: string): Promise<string[]> {
  const entries = await fs.readdir(dir, { withFileTypes: true });
  const files = await Promise.all(entries.map((entry) => {
    const resolvedPath = path.resolve(dir, entry.name);
    if (entry.isDirectory()) {
      return findFiles(resolvedPath, ext);
    }
    return resolvedPath.endsWith(ext) ? [resolvedPath] : [];
  }));
  return files.flat();
}

/**
 * Scans files for the presence of a flag string.
 * Performs a simple regex check to ensure it's not just a substring of a larger word.
 */
async function isFlagUsedInCode(flagName: string, files: string[]): Promise<boolean> {
  const pattern = new RegExp(`\\b${flagName}\\b`); // Word boundary check
  
  for (const file of files) {
    const content = await fs.readFile(file, 'utf-8');
    if (pattern.test(content)) {
      return true;
    }
  }
  return false;
}

export async function analyzeFlags(flagFilePath: string, scanDir: string): Promise<FlagReport> {
  // 1. Read flag definitions
  const flagFileContent = await fs.readFile(flagFilePath, 'utf-8');
  const flags: Record<string, boolean> = JSON.parse(flagFileContent);
  const flagNames = Object.keys(flags);

  // 2. Find all source files
  const tsFiles = await findFiles(scanDir, '.ts');
  const tsxFiles = await findFiles(scanDir, '.tsx');
  const allFiles = [...tsFiles, ...tsxFiles];

  // 3. Check usage
  const report: FlagReport = {
    active: [],
    potentially_stale: [],
  };

  for (const flag of flagNames) {
    const used = await isFlagUsedInCode(flag, allFiles);
    if (used) {
      report.active.push(flag);
    } else {
      report.potentially_stale.push(flag);
    }
  }

  return report;
}

// Main execution block for CLI usage
if (require.main === module) {
  const args = process.argv.slice(2);
  if (args.length < 2) {
    console.error('Usage: ts-node analyzeFlags.ts <flags.json> <scanDir>');
    process.exit(1);
  }
  
  const [flagPath, scanPath] = args;
  analyzeFlags(flagPath, scanPath)
    .then((report) => console.log(JSON.stringify(report, null, 2)))
    .catch((err) => console.error('Error analyzing flags:', err));
}
