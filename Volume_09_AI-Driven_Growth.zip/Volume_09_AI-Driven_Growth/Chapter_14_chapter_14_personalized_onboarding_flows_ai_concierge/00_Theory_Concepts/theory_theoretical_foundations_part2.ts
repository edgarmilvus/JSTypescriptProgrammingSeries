/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part2.ts
// Description: Theoretical Foundations
// ==========================================

// A union type representing the possible UI components the AI might generate
type AI_Generated_Component = 
  | { type: 'tooltip'; content: string; targetSelector: string }
  | { type: 'modal'; title: string; body: string[] }
  | { type: 'sidebar_walkthrough'; steps: string[] };

// A function that renders the component
const renderConciergeElement = (component: AI_Generated_Component) => {
  // Type Narrowing in action:
  if (component.type === 'tooltip') {
    // TypeScript now knows 'component' is strictly the tooltip shape
    // We can safely access component.targetSelector
    showTooltip(component.targetSelector, component.content);
  } 
  else if (component.type === 'modal') {
    // TypeScript narrows the type here to the modal shape
    showModal(component.title, component.body);
  }
  // ... other checks
};
