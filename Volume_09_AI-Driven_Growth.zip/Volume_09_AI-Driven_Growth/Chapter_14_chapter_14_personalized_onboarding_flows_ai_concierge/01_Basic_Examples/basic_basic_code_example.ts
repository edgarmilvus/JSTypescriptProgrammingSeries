/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

// File: onboarding-concierge.ts
// Run with: npx ts-node onboarding-concierge.ts

// --- 1. TYPE DEFINITIONS ---

/**
 * Represents the possible intents a new user might have.
 * In a real system, these would be detected via NLP or event analysis.
 */
type UserIntent = 'IMPORT_DATA' | 'INVITE_TEAM' | 'EXPLORE_FEATURES' | 'UNKNOWN';

/**
 * Represents a single user action or event.
 * This is the data stream we analyze for intent.
 */
interface UserEvent {
  type: 'CLICK' | 'VIEW' | 'INPUT';
  elementId: string;
  timestamp: Date;
}

/**
 * Represents the state of a user's onboarding session.
 * This would typically be stored in a database or Redis cache.
 */
interface OnboardingSession {
  userId: string;
  currentStep: number;
  completedSteps: string[];
  detectedIntent: UserIntent | null;
}

/**
 * Represents the AI-generated response for the user.
 */
interface OnboardingResponse {
  message: string;
  suggestedAction: string;
  stepId: string;
}

// --- 2. MOCK SERVICES ---

/**
 * Mock Intent Detector.
 * Simulates an NLP model or a rule-based system that analyzes user events.
 * @param events - An array of recent user events.
 * @returns The detected UserIntent.
 */
function detectIntent(events: UserEvent[]): UserIntent {
  // In a real system, this would be a complex model or vector search.
  // Here, we use simple keyword matching on element IDs.
  const lastEvent = events[events.length - 1];
  
  if (!lastEvent) return 'UNKNOWN';

  if (lastEvent.elementId.includes('import')) {
    return 'IMPORT_DATA';
  }
  if (lastEvent.elementId.includes('invite')) {
    return 'INVITE_TEAM';
  }
  if (lastEvent.elementId.includes('dashboard') || lastEvent.elementId.includes('features')) {
    return 'EXPLORE_FEATURES';
  }
  
  return 'UNKNOWN';
}

/**
 * Mock AI Response Generator.
 * Simulates a prompt-engineered LLM call (e.g., GPT-4).
 * In a real app, this would call an API with a prompt like:
 * "Generate an onboarding message for a user with intent: {intent}. Current step: {step}."
 * @param intent - The detected user intent.
 * @param step - The current step in the flow.
 * @returns A structured onboarding response.
 */
function generateAIResponse(intent: UserIntent, step: number): OnboardingResponse {
  const responses: Record<UserIntent, OnboardingResponse[]> = {
    'IMPORT_DATA': [
      { message: "Welcome! I see you're interested in data. Let's start by connecting your first data source.", suggestedAction: "Click the 'Connect Database' button", stepId: "import_step_1" },
      { message: "Great! Now, select the tables you want to sync. Our AI can help you map schemas.", suggestedAction: "Select tables and click 'Next'", stepId: "import_step_2" },
    ],
    'INVITE_TEAM': [
      { message: "Teamwork makes the dream work! Let's get your colleagues on board.", suggestedAction: "Enter their email addresses in the invite box", stepId: "invite_step_1" },
      { message: "Perfect. You can assign roles now. Admins have full access, while Editors can only modify content.", suggestedAction: "Assign a role and click 'Send Invites'", stepId: "invite_step_2" },
    ],
    'EXPLORE_FEATURES': [
      { message: "Let's take a quick tour of the dashboard. I'll highlight key features for you.", suggestedAction: "Click 'Start Tour' to begin", stepId: "explore_step_1" },
    ],
    'UNKNOWN': [
      { message: "Hi there! I'm your AI concierge. What would you like to accomplish today?", suggestedAction: "Tell me your goal (e.g., 'I want to import data')", stepId: "welcome_step_1" },
    ]
  };

  const flow = responses[intent];
  // Return the current step, or the last step if the flow is complete.
  const response = flow[Math.min(step, flow.length - 1)];
  
  // If we've reached the end of the flow, signal completion.
  if (step >= flow.length) {
    return {
      message: "You've completed the onboarding flow! Feel free to explore on your own.",
      suggestedAction: "Navigate to the main dashboard",
      stepId: "flow_complete"
    };
  }

  return response;
}

// --- 3. CORE LOGIC ---

/**
 * The main AI Concierge function.
 * Processes a user's event and returns a personalized onboarding response.
 * @param userId - The unique identifier for the user.
 * @param event - The latest user event to analyze.
 * @param sessionStore - A simple in-memory store for sessions (simulating a DB).
 * @returns A promise resolving to the onboarding response.
 */
async function aiConcierge(
  userId: string,
  event: UserEvent,
  sessionStore: Map<string, OnboardingSession>
): Promise<OnboardingResponse> {
  
  // 1. Retrieve or create the user's session.
  let session = sessionStore.get(userId);
  if (!session) {
    session = {
      userId,
      currentStep: 0,
      completedSteps: [],
      detectedIntent: null,
    };
  }

  // 2. If intent is not yet detected, analyze the event.
  // In a real system, we'd analyze a history of events, not just the last one.
  if (!session.detectedIntent) {
    // Simulate fetching recent events (in this case, just the current one)
    const recentEvents: UserEvent[] = [event]; 
    session.detectedIntent = detectIntent(recentEvents);
  }

  // 3. Generate the AI response based on the detected intent and current step.
  // This simulates the LLM call.
  const response = generateAIResponse(session.detectedIntent, session.currentStep);

  // 4. Update the session state for the next interaction.
  // We increment the step only if the flow is not complete.
  if (response.stepId !== 'flow_complete') {
    session.currentStep += 1;
    session.completedSteps.push(response.stepId);
  }
  
  // 5. Persist the updated session.
  sessionStore.set(userId, session);

  // Simulate network latency for the LLM call
  await new Promise(resolve => setTimeout(resolve, 100));

  return response;
}

// --- 4. DEMONSTRATION ---

/**
 * Main function to run the demonstration.
 */
async function main() {
  // In-memory session store (use Redis or a DB in production)
  const sessionStore = new Map<string, OnboardingSession>();

  console.log("--- AI Concierge Demo: User 'Alice' importing data ---\n");

  // User Alice performs her first action.
  const aliceId = 'user-alice-123';
  const event1: UserEvent = { type: 'CLICK', elementId: 'btn_import_data', timestamp: new Date() };
  
  const response1 = await aiConcierge(aliceId, event1, sessionStore);
  console.log(`[EVENT 1] Alice clicks 'Import Data':`);
  console.log(`  AI Response: "${response1.message}"`);
  console.log(`  Suggested Action: "${response1.suggestedAction}"\n`);

  // Alice performs her second action (following the AI's suggestion).
  const event2: UserEvent = { type: 'CLICK', elementId: 'btn_connect_db', timestamp: new Date() };
  
  const response2 = await aiConcierge(aliceId, event2, sessionStore);
  console.log(`[EVENT 2] Alice clicks 'Connect DB' (following step 1):`);
  console.log(`  AI Response: "${response2.message}"`);
  console.log(`  Suggested Action: "${response2.suggestedAction}"\n`);

  // Check the final session state.
  const finalSession = sessionStore.get(aliceId);
  console.log("Final Session State for Alice:");
  console.log(JSON.stringify(finalSession, null, 2));
}

// Execute the demo
main().catch(console.error);
