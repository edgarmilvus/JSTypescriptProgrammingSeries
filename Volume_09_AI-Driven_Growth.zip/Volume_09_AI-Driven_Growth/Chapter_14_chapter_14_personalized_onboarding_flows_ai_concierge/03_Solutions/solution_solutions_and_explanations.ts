/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// lib/actions/detectUserIntent.ts
'use server';

import { z } from 'zod';

// 1. Define the Intent Schema using Zod for runtime validation
const IntentSchema = z.object({
  primaryIntent: z.enum(["Developer", "Marketing", "Executive"]),
  confidenceScore: z.number().min(0).max(1),
  reasoning: z.string().max(200),
});

export type UserIntent = z.infer<typeof IntentSchema>;

// Mock function to simulate an LLM call
async function callLLM(prompt: string): Promise<string> {
  // In a real app, this would be await fetch('https://api.openai.com/v1/chat/completions', ...)
  // For this exercise, we simulate a response based on keywords in the context.
  
  const context = prompt.toLowerCase();
  if (context.includes("api") || context.includes("code") || context.includes("dev")) {
    return JSON.stringify({
      primaryIntent: "Developer",
      confidenceScore: 0.95,
      reasoning: "Context contains keywords related to coding and APIs."
    });
  }
  
  if (context.includes("marketing") || context.includes("campaign") || context.includes("analytics")) {
    return JSON.stringify({
      primaryIntent: "Marketing",
      confidenceScore: 0.92,
      reasoning: "Context mentions marketing metrics and campaigns."
    });
  }

  // Simulate a malformed response occasionally to test error handling
  if (context.includes("error")) {
    return "This is not valid JSON";
  }

  // Default fallback simulation
  return JSON.stringify({
    primaryIntent: "Executive",
    confidenceScore: 0.5,
    reasoning: "No specific keywords found; defaulting to executive overview."
  });
}

// 2. Implement the Server Action
export async function detectUserIntent(contextString: string): Promise<UserIntent> {
  // Construct the prompt enforcing strict JSON output
  const prompt = `
    Analyze the following user context: "${contextString}".
    
    Determine the user's primary intent from these categories: Developer, Marketing, Executive.
    
    Respond ONLY with a raw JSON object that matches this schema:
    {
      "primaryIntent": "Developer" | "Marketing" | "Executive",
      "confidenceScore": number,
      "reasoning": string
    }
    Do not include markdown formatting or conversational text.
  `;

  try {
    const llmResponse = await callLLM(prompt);
    
    // Parse the raw JSON string
    const parsedData = JSON.parse(llmResponse);
    
    // Validate against the schema
    const validatedData = IntentSchema.parse(parsedData);
    
    return validatedData;
    
  } catch (error) {
    // 3. Error Handling: Return a safe default if parsing or validation fails
    console.error("Intent detection failed:", error);
    
    return {
      primaryIntent: "Developer", // Safe default for technical products
      confidenceScore: 0.1,
      reasoning: "LLM response invalid or timed out; used default fallback."
    };
  }
}
