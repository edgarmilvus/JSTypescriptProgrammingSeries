/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

// components/OnboardingFlow.tsx
'use client';

import { useState } from 'react';
import { UserIntent } from '@/lib/actions/detectUserIntent'; // Assuming import from Ex 1

// 1. Define Mock Data Structures
const STEPS_DATA = {
  Developer: [
    { title: "Generate API Key", description: "Create your secret key to access the backend." },
    { title: "Install CLI", description: "Run npm install -g my-app-cli in your terminal." },
    { title: "Deploy First Project", description: "Push your code to the staging environment." },
  ],
  Marketing: [
    { title: "Connect Google Analytics", description: "Link your GA4 property to track traffic." },
    { title: "Invite Team", description: "Add colleagues to collaborate on campaigns." },
    { title: "Create Dashboard", description: "Customize your view with key metrics." },
  ],
  Executive: [
    { title: "View Overview", description: "See high-level team performance." },
    { title: "Set KPIs", description: "Define success metrics for the quarter." },
  ],
};

interface OnboardingFlowProps {
  intent: UserIntent;
  onComplete: () => void;
}

export function OnboardingFlow({ intent, onComplete }: OnboardingFlowProps) {
  // 2. State Management for current step
  const [currentStepIndex, setCurrentStepIndex] = useState(0);

  // 3. Get steps based on intent
  // Fallback to generic steps if intent is not recognized
  const steps = STEPS_DATA[intent.primaryIntent] || [{ title: "Welcome", description: "Getting started..." }];

  const isLastStep = currentStepIndex === steps.length - 1;

  const handleNext = () => {
    if (!isLastStep) {
      setCurrentStepIndex(prev => prev + 1);
    } else {
      onComplete();
    }
  };

  const handlePrev = () => {
    if (currentStepIndex > 0) {
      setCurrentStepIndex(prev => prev - 1);
    }
  };

  // 4. Calculate progress
  const progress = ((currentStepIndex + 1) / steps.length) * 100;

  return (
    <div className="max-w-md mx-auto p-6 border rounded-lg shadow-sm bg-white">
      {/* Progress Bar */}
      <div className="w-full bg-gray-200 rounded-full h-2.5 mb-6">
        <div 
          className="bg-blue-600 h-2.5 rounded-full transition-all duration-300" 
          style={{ width: `${progress}%` }}
        ></div>
      </div>

      {/* Step Content */}
      <div className="mb-6">
        <h2 className="text-xl font-bold mb-2">
          Step {currentStepIndex + 1}: {steps[currentStepIndex].title}
        </h2>
        <p className="text-gray-600">
          {steps[currentStepIndex].description}
        </p>
        <div className="mt-2 text-xs text-gray-400">
          Detected Intent: {intent.primaryIntent} (Confidence: {intent.confidenceScore})
        </div>
      </div>

      {/* Navigation Buttons */}
      <div className="flex justify-between">
        <button
          onClick={handlePrev}
          disabled={currentStepIndex === 0}
          className="px-4 py-2 bg-gray-200 text-gray-800 rounded disabled:opacity-50"
        >
          Previous
        </button>
        
        <button
          onClick={handleNext}
          className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700"
        >
          {isLastStep ? "Finish" : "Next"}
        </button>
      </div>
    </div>
  );
}
