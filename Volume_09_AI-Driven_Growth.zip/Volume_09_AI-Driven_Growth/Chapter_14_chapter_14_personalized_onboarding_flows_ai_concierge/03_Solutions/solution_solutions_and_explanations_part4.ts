/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

// components/FeatureButton.tsx (Usage Example)
'use client';

import { logOnboardingEvent } from '@/lib/analytics/eventLogger';

export function FeatureButton({ userId }: { userId: string }) {
  
  const handleClick = () => {
    // 3. Non-Blocking Usage
    // We do NOT await this promise here. 
    // This is a "fire-and-forget" pattern.
    logOnboardingEvent({
      userId: userId,
      timestamp: new Date(),
      eventType: "click",
      elementId: "feature-button-1"
    }).catch((error) => {
      // Optional: Handle error silently or show a toast notification
      console.warn("Failed to log event", error);
    });

    // Immediate UI feedback follows
    alert("Feature activated!");
  };

  return (
    <button onClick={handleClick} className="px-4 py-2 bg-green-500 text-white rounded">
      Trigger Feature
    </button>
  );
}
