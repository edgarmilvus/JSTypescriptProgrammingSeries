/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

// lib/abTesting/onboardingVariation.ts

// 1. Variation Assignment
// Deterministic: Same ID always gets same variation
export function getOnboardingVariation(userId: string): 'A' | 'B' {
  // Simple hash: sum char codes % 2
  const hash = userId.split('').reduce((acc, char) => acc + char.charCodeAt(0), 0);
  return hash % 2 === 0 ? 'A' : 'B';
}

// 2. Prompt Generation
export function generateOnboardingPrompt(variation: 'A' | 'B', context: string): string {
  const baseInstructions = `User context: "${context}". Generate an onboarding plan.`;

  if (variation === 'A') {
    // Friendly & Casual
    return `
      ${baseInstructions}
      Tone: Friendly, enthusiastic, and casual. Use emojis to make it fun.
      Structure: Keep sentences short and punchy.
      Output: Return only the JSON plan.
    `;
  } else {
    // Professional & Direct
    return `
      ${baseInstructions}
      Tone: Professional, direct, and concise. No emojis.
      Structure: Focus on efficiency and clarity.
      Output: Return only the JSON plan.
    `;
  }
}

// 3. Integration Pseudo-code (Next.js Server Component)
/*
import { getOnboardingVariation, generateOnboardingPrompt } from '@/lib/abTesting/onboardingVariation';
import { detectUserIntent } from '@/lib/actions/detectUserIntent';

export default async function OnboardingPage({ params }: { params: { userId: string } }) {
  // Assign variation
  const variation = getOnboardingVariation(params.userId);
  
  // Detect intent (simulated context)
  const intent = await detectUserIntent("User clicked on marketing link");
  
  // Generate specific prompt based on variation
  const prompt = generateOnboardingPrompt(variation, intent.primaryIntent);
  
  // Call LLM with prompt...
  // Render component with variation-specific styling or messages
  return <OnboardingFlow prompt={prompt} variation={variation} />;
}
*/
