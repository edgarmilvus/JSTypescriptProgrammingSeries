/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part6.ts
// Description: Solutions and Explanations
// ==========================================

// lib/prompts/onboardingBuilder.ts

export const buildOnboardingPrompt = (
  userIntent: string, 
  availableFeatures: string[]
): string => {
  return `
    You are an AI Onboarding Concierge for a SaaS platform. Your goal is to generate a personalized onboarding plan.

    **User Context:**
    - Primary Intent: ${userIntent}
    - Available Features: ${availableFeatures.join(', ')}

    **Task:**
    Generate exactly 3 onboarding steps tailored to the user's intent. 
    - If the user is a "Developer", prioritize API and CLI features.
    - If the user is "Marketing", prioritize Analytics and Campaign features.
    - If the user is "Executive", prioritize high-level dashboards and KPIs.

    **Strict Output Requirement:**
    You must respond with **only** a raw JSON object. Do not include any markdown formatting (like \`\`\`json), conversational filler, or explanations before or after the JSON.

    **JSON Schema:**
    {
      "steps": [
        {
          "title": "string (concise step title)",
          "description": "string (brief explanation of the step)",
          "action": "click" | "type" | "view",
          "targetElementId": "string (e.g., 'api-key-generator' or 'analytics-dashboard')"
        }
      ]
    }

    **Example Output (for reference only, do not copy):**
    {
      "steps": [
        { "title": "Generate API Key", "description": "Access your credentials", "action": "click", "targetElementId": "api-key-btn" }
      ]
    }
  `;
};
