/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.tsx
// Description: Basic Code Example
// ==========================================

// File: GamifiedOnboarding.tsx
// Dependencies: React (v18+)
// Description: A React component demonstrating a gamified onboarding flow using useTransition for state updates.

import React, { useState, useTransition } from 'react';

// --- Type Definitions ---

/**
 * Represents a single step in the onboarding flow.
 * @property id - Unique identifier for the step.
 * @property label - User-facing text for the step.
 * @property isCompleted - Boolean indicating if the step is done.
 */
type OnboardingStep = {
  id: string;
  label: string;
  isCompleted: boolean;
};

/**
 * Represents the state of the gamification system.
 * @property steps - An array of onboarding steps.
 * @property currentStepIndex - The index of the step the user is currently on.
 * @property badgeEarned - The name of the badge earned, if any.
 */
type GamificationState = {
  steps: OnboardingStep[];
  currentStepIndex: number;
  badgeEarned: string | null;
};

// --- Mock Data ---

const INITIAL_STEPS: OnboardingStep[] = [
  { id: 'step_1', label: 'Complete your profile', isCompleted: false },
  { id: 'step_2', label: 'Upload your first dataset', isCompleted: false },
  { id: 'step_3', label: 'Invite a teammate', isCompleted: false },
];

// --- Main Component ---

/**
 * GamifiedOnboarding Component
 * Renders a list of steps and a button to simulate completing them.
 * Uses `useTransition` to manage the pending state of the completion action.
 */
export function GamifiedOnboarding() {
  // State for the gamification logic
  const [state, setState] = useState<GamificationState>({
    steps: [...INITIAL_STEPS],
    currentStepIndex: 0,
    badgeEarned: null,
  });

  // useTransition hook to handle non-urgent state updates
  const [isPending, startTransition] = useTransition();

  /**
   * Handles the click event to complete the current step.
   * This function wraps the state update in a transition to keep the UI responsive.
   */
  const handleCompleteStep = () => {
    startTransition(() => {
      // 1. Simulate a network delay (e.g., calling an API to save progress)
      // In a real app, this would be an async function call.
      setTimeout(() => {
        setState((prevState) => {
          const newSteps = [...prevState.steps];
          const currentStep = newSteps[prevState.currentStepIndex];

          if (!currentStep || currentStep.isCompleted) {
            return prevState; // No change if step is already done or doesn't exist
          }

          // Mark the current step as completed
          currentStep.isCompleted = true;

          // Check for badge logic (e.g., completing all steps)
          const allStepsCompleted = newSteps.every((step) => step.isCompleted);
          const newBadge = allStepsCompleted ? 'Onboarding Master' : null;

          // Move to the next step index
          const nextIndex = prevState.currentStepIndex + 1;

          return {
            steps: newSteps,
            currentStepIndex: nextIndex,
            badgeEarned: newBadge,
          };
        });
      }, 1000); // 1-second simulated delay
    });
  };

  // Determine the current step to display
  const currentStep = state.steps[state.currentStepIndex];

  return (
    <div style={{ padding: '20px', fontFamily: 'sans-serif', maxWidth: '400px' }}>
      <h2>🚀 Your Onboarding Quest</h2>

      {/* Progress List */}
      <ul style={{ listStyle: 'none', padding: 0 }}>
        {state.steps.map((step) => (
          <li
            key={step.id}
            style={{
              padding: '8px',
              margin: '4px 0',
              backgroundColor: step.isCompleted ? '#e6fffa' : '#f3f4f6',
              borderLeft: `4px solid ${step.isCompleted ? '#10b981' : '#9ca3af'}`,
              opacity: step.isCompleted ? 1 : 0.7,
            }}
          >
            {step.isCompleted ? '✅' : '⬜'} {step.label}
          </li>
        ))}
      </ul>

      {/* Action Area */}
      <div style={{ marginTop: '20px', padding: '10px', border: '1px dashed #ccc' }}>
        {currentStep ? (
          <>
            <p>
              <strong>Next Challenge:</strong> {currentStep.label}
            </p>
            <button
              onClick={handleCompleteStep}
              disabled={isPending}
              style={{
                padding: '10px 20px',
                backgroundColor: isPending ? '#ccc' : '#3b82f6',
                color: 'white',
                border: 'none',
                borderRadius: '4px',
                cursor: isPending ? 'not-allowed' : 'pointer',
              }}
            >
              {isPending ? 'Completing...' : 'Complete Step'}
            </button>
          </>
        ) : (
          <p style={{ color: '#10b981', fontWeight: 'bold' }}>
            All steps completed! 🎉
          </p>
        )}
      </div>

      {/* Badge Display */}
      {state.badgeEarned && (
        <div style={{ marginTop: '20px', padding: '10px', backgroundColor: '#fef3c7', borderRadius: '4px' }}>
          <strong>🏆 Badge Earned:</strong> {state.badgeEarned}
        </div>
      )}
    </div>
  );
}
