/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// app/api/challenge/validate/route.ts
import { NextResponse } from 'next/server';
import { openai } from '@ai-sdk/openai';
import { streamText } from 'ai';

/**
 * POST /api/challenge/validate
 * 
 * Server-side agent responsible for validating user solutions against the 
 * gamified challenge. It uses GPT-4 to evaluate natural language responses 
 * and returns a structured JSON result including XP gain and badge unlocks.
 * 
 * This acts as the 'Executor' layer in our Hierarchical Agentic Workflow.
 */
export async function POST(req: Request) {
  const { challengeId, userSolution, currentLevel } = await req.json();

  const systemPrompt = `
    You are a strict but fair Gamification Engine. 
    Challenge ID: ${challengeId}
    User Level: ${currentLevel}

    Evaluate the user's solution. 
    Criteria:
    1. Accuracy: Is the solution technically correct?
    2. Completeness: Does it address all parts of the prompt?
    
    Return a JSON object with the following structure:
    {
      "isCorrect": boolean,
      "xpEarned": number,
      "badgeUnlocked": string | null,
      "feedback": string (Constructive, concise feedback)
    }
    
    Base XP on level: Base 100 * (1 + level * 0.1).
    If correct, award full XP. If incorrect, award 0 XP.
    Badge "Quick Thinker" if XP > 200.
  `;

  const result = await streamText({
    model: openai('gpt-4-turbo-preview'),
    prompt: `User Solution: "${userSolution}"`,
    system: systemPrompt,
    temperature: 0, // Deterministic validation
  });

  // We stream the text, but the client will parse the final JSON chunk
  return result.toAIStreamResponse();
}
