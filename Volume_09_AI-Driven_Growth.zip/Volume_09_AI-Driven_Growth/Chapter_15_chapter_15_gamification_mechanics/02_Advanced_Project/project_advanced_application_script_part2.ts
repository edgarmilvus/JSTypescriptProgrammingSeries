/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script_part2.ts
// Description: Advanced Application Script
// ==========================================

// app/components/GamificationEngine.tsx
'use client';

import { useState, useEffect } from 'react';
import { useChat } from 'ai/react';

// --- Type Definitions ---

/**
 * Represents the gamification state managed within the client.
 * This is part of the UIState concept: it dictates what components 
 * render (e.g., the 'BadgeModal') and holds optimistic data.
 */
interface GamificationState {
  xp: number;
  level: number;
  badges: string[];
  activeChallenge: Challenge | null;
  isProcessing: boolean;
  showBadgeModal: boolean;
}

interface Challenge {
  id: string;
  prompt: string;
  difficulty: 'easy' | 'medium' | 'hard';
}

// --- Mock Data (In a real app, this comes from a database) ---
const MOCK_CHALLENGES: Challenge[] = [
  { id: 'c1', prompt: 'Explain the concept of "Optimistic UI" in one sentence.', difficulty: 'medium' },
  { id: 'c2', prompt: 'What is the benefit of a Hierarchical Agentic Workflow?', difficulty: 'hard' },
];

// --- Main Component ---

export default function GamificationEngine() {
  // 1. Local UI State (Optimistic State)
  const [gameState, setGameState] = useState<GamificationState>({
    xp: 0,
    level: 1,
    badges: [],
    activeChallenge: null,
    isProcessing: false,
    showBadgeModal: false,
  });

  // 2. AI SDK Hook for Server Communication
  const { messages, input, handleInputChange, handleSubmit, isLoading } = useChat({
    api: '/api/challenge/validate',
    sendExtraMessageFields: true, // Send custom fields like challengeId
    onFinish: (message) => {
      // 3. Reconciliation: Parse the confirmed state from the AI response
      handleGamificationResult(message.content);
    },
  });

  // --- Logic Breakdown ---

  /**
   * 1. INITIALIZATION
   * Load a random challenge on mount.
   */
  useEffect(() => {
    const randomChallenge = MOCK_CHALLENGES[Math.floor(Math.random() * MOCK_CHALLENGES.length)];
    setGameState((prev) => ({ ...prev, activeChallenge: randomChallenge }));
  }, []);

  /**
   * 2. OPTIMISTIC SUBMISSION
   * Intercept the form submit to update UI immediately, 
   * then send data to the server.
   */
  const handleOptimisticSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Optimistic Update: Show loading state immediately
    setGameState((prev) => ({ ...prev, isProcessing: true }));

    // Append user message manually to UI (handled by useChat, but we add metadata)
    handleSubmit(e, {
      body: {
        challengeId: gameState.activeChallenge?.id,
        currentLevel: gameState.level,
      },
    });
  };

  /**
   * 3. RECONCILIATION & REWARD LOGIC
   * Parse the JSON response from the AI and reconcile with local state.
   */
  const handleGamificationResult = (content: string) => {
    try {
      // Extract JSON from the markdown response if necessary
      const jsonMatch = content.match(/\{[\s\S]*\}/);
      if (!jsonMatch) throw new Error("No JSON found");

      const result = JSON.parse(jsonMatch[0]);

      // Update State based on Server Truth
      setGameState((prev) => {
        const newXP = prev.xp + result.xpEarned;
        const newLevel = Math.floor(newXP / 1000) + 1; // Simple leveling curve
        const newBadges = result.badgeUnlocked 
          ? [...prev.badges, result.badgeUnlocked] 
          : prev.badges;

        return {
          ...prev,
          xp: newXP,
          level: newLevel,
          badges: newBadges,
          isProcessing: false,
          showBadgeModal: !!result.badgeUnlocked,
          activeChallenge: null, // Clear challenge (or load next)
        };
      });
    } catch (error) {
      console.error("Reconciliation failed", error);
      setGameState((prev) => ({ ...prev, isProcessing: false }));
    }
  };

  // --- Render Logic ---

  if (!gameState.activeChallenge) return <div>Loading Challenge...</div>;

  return (
    <div className="p-6 max-w-md mx-auto bg-gray-50 rounded-xl shadow-lg border border-gray-200">
      {/* HUD: Heads Up Display */}
      <div className="flex justify-between mb-4 text-sm font-mono text-gray-600">
        <span>Level: {gameState.level}</span>
        <span>XP: {gameState.xp}</span>
        <span>Badges: {gameState.badges.length}</span>
      </div>

      {/* Challenge Card */}
      <div className="bg-white p-4 rounded-lg border-l-4 border-blue-500 mb-4">
        <h3 className="font-bold text-gray-800">Challenge</h3>
        <p className="text-gray-600 mt-1">{gameState.activeChallenge.prompt}</p>
      </div>

      {/* Input Form */}
      <form onSubmit={handleOptimisticSubmit} className="space-y-3">
        <textarea
          value={input}
          onChange={handleInputChange}
          disabled={gameState.isProcessing}
          className="w-full p-2 border rounded-md focus:ring-2 focus:ring-blue-500 outline-none disabled:opacity-50"
          placeholder="Type your answer here..."
          rows={3}
        />
        
        <button
          type="submit"
          disabled={gameState.isProcessing || !input}
          className="w-full bg-blue-600 text-white py-2 rounded-md hover:bg-blue-700 disabled:bg-gray-400 transition-colors"
        >
          {gameState.isProcessing ? 'Validating...' : 'Submit Answer'}
        </button>
      </form>

      {/* Feedback Loop (Streamed from Server) */}
      {messages.length > 0 && (
        <div className="mt-4 p-3 bg-gray-100 rounded text-sm text-gray-700">
          <strong>System:</strong> {messages[messages.length - 1].content}
        </div>
      )}

      {/* Badge Unlock Modal (Conditional Rendering based on UIState) */}
      {gameState.showBadgeModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white p-6 rounded-lg shadow-2xl text-center animate-bounce">
            <div className="text-4xl mb-2">🏆</div>
            <h2 className="text-xl font-bold text-yellow-600">Badge Unlocked!</h2>
            <p className="text-gray-600 mt-2">
              You earned the <strong>Quick Thinker</strong> badge!
            </p>
            <button
              onClick={() => setGameState((prev) => ({ ...prev, showBadgeModal: false }))}
              className="mt-4 px-4 py-2 bg-yellow-500 text-white rounded-md"
            >
              Awesome!
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
