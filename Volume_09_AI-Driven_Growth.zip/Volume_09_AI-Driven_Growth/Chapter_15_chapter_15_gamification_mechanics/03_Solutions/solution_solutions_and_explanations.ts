/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// Define a structure for the reward event output
interface RewardEvent {
    userId: string;
    badgeName: string;
    timestamp: Date;
}

// Define the threshold configuration
const BADGE_THRESHOLDS = [
    { points: 100, badge: "Novice" },
    { points: 500, badge: "Intermediate" },
    { points: 1000, badge: "Expert" }
];

export class GamificationEngine {
    // In-memory storage for user points (Map<userId, points>)
    private userPoints: Map<string, number> = new Map();

    /**
     * Registers a user action and updates their point total.
     * @param userId - The unique identifier for the user.
     * @param actionType - The type of action performed (e.g., 'login', 'purchase').
     * @param value - The numerical value of points to add.
     */
    public registerAction(userId: string, actionType: string, value: number): void {
        const currentPoints = this.userPoints.get(userId) || 0;
        this.userPoints.set(userId, currentPoints + value);
        console.log(`Action [${actionType}] processed for user [${userId}]. Total points: ${currentPoints + value}`);
    }

    /**
     * Checks if the user has crossed any badge thresholds.
     * @param userId - The unique identifier for the user.
     * @returns A RewardEvent object if a new badge is earned, otherwise null.
     */
    public checkForRewards(userId: string): RewardEvent | null {
        const currentPoints = this.userPoints.get(userId) || 0;

        // Iterate through thresholds to find the highest badge earned
        // We reverse the array to check the highest threshold first (Expert -> Intermediate -> Novice)
        // This ensures we award the highest applicable badge in a single check pass.
        for (const threshold of [...BADGE_THRESHOLDS].reverse()) {
            if (currentPoints >= threshold.points) {
                // In a real system, we would check if the user *already* has this badge
                // to avoid re-issuing the same reward. For this exercise, we assume
                // the check is triggered only on point updates.
                return {
                    userId,
                    badgeName: threshold.badge,
                    timestamp: new Date()
                };
            }
        }

        return null;
    }
}

// --- Example Usage ---
/*
const engine = new GamificationEngine();
engine.registerAction("user_1", "completed_tutorial", 120);
const reward = engine.checkForRewards("user_1");
console.log(reward); 
// Output: { userId: 'user_1', badgeName: 'Novice', timestamp: 2023-10-27T... }
*/
