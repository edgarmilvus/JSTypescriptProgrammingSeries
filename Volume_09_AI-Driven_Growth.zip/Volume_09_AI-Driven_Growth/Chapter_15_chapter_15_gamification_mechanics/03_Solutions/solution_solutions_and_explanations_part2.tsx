/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.tsx
// Description: Solutions and Explanations
// ==========================================

import React from 'react';

interface ProgressionBarProps {
  currentPoints: number;
  currentLevel: string;
  nextLevelThreshold: number;
  nextLevelName: string; // Added to satisfy the "Next Level Name" requirement in text
}

const ProgressionBar: React.FC<ProgressionBarProps> = ({
  currentPoints,
  currentLevel,
  nextLevelThreshold,
  nextLevelName
}) => {
  // Edge Case: Check if user has already met or exceeded the threshold
  if (currentPoints >= nextLevelThreshold) {
    return (
      <div style={styles.container}>
        <h3>🎉 Level Up! 🎉</h3>
        <p>You have reached <strong>{nextLevelName}</strong>!</p>
      </div>
    );
  }

  // Calculate percentage for the progress bar
  // Ensure we don't divide by zero or exceed 100%
  const percentage = Math.min(100, Math.max(0, (currentPoints / nextLevelThreshold) * 100));
  const pointsNeeded = nextLevelThreshold - currentPoints;

  return (
    <div style={styles.container}>
      <div style={styles.infoText}>
        <span>Current Level: <strong>{currentLevel}</strong></span>
        <span>You need <strong>{pointsNeeded}</strong> more points to reach <strong>{nextLevelName}</strong></span>
      </div>
      
      {/* Visual Progress Bar */}
      <div style={styles.progressBarBackground}>
        <div 
          style={{
            ...styles.progressBarFill,
            width: `${percentage}%`
          }} 
        />
      </div>
      
      {/* Optional: Show current points / threshold */}
      <div style={styles.counter}>
        {currentPoints} / {nextLevelThreshold} pts
      </div>
    </div>
  );
};

// Basic inline styles for demonstration (CSS-in-JS)
const styles: { [key: string]: React.CSSProperties } = {
  container: {
    padding: '20px',
    border: '1px solid #e0e0e0',
    borderRadius: '8px',
    maxWidth: '400px',
    fontFamily: 'Arial, sans-serif',
    backgroundColor: '#f9f9f9'
  },
  infoText: {
    display: 'flex',
    flexDirection: 'column',
    marginBottom: '10px',
    fontSize: '14px',
    color: '#333'
  },
  progressBarBackground: {
    width: '100%',
    height: '20px',
    backgroundColor: '#e0e0e0',
    borderRadius: '10px',
    overflow: 'hidden'
  },
  progressBarFill: {
    height: '100%',
    backgroundColor: '#4caf50',
    transition: 'width 0.3s ease'
  },
  counter: {
    marginTop: '5px',
    fontSize: '12px',
    textAlign: 'right',
    color: '#666'
  }
};

export default ProgressionBar;
