/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

// 1. Define the UserProfile interface
export interface UserProfile {
    userId: string;
    interests: string[];
}

// 2. Define the GeneratedChallenge interface
export interface GeneratedChallenge {
    challengeId: string;
    title: string;
    description: string;
    pointsReward: number;
}

/**
 * 3. Function to generate a daily challenge.
 * Note: This function returns a Promise as it simulates an async API call.
 */
export async function generateDailyChallenge(userProfile: UserProfile): Promise<GeneratedChallenge> {
    
    // 4. Construct the detailed System Prompt
    const systemPrompt = `
    You are an expert Gamification Bot designed to create engaging daily challenges for users.
    
    User Context:
    - User ID: ${userProfile.userId}
    - Interests: ${userProfile.interests.join(", ")}

    Task:
    Generate a single, personalized challenge that aligns with the user's interests.
    The challenge should be actionable, specific, and encourage learning or productivity.

    Constraints:
    - The challenge must be relevant to at least one of the user's interests.
    - The points reward should scale with the estimated difficulty (10-50 points).
    - You must respond ONLY with a valid JSON object.
    - Do not include any markdown formatting (like \`\`\`json) or conversational text.

    JSON Schema:
    {
      "challengeId": "string (uuid format)",
      "title": "string (short catchy title)",
      "description": "string (detailed instructions)",
      "pointsReward": "number (integer)"
    }
    `;

    // Simulation of the API call
    console.log("Sending prompt to LLM...");
    
    // In a real implementation, we would call the OpenAI API here:
    // const response = await openai.chat.completions.create({ ... });
    // const content = response.choices[0].message.content;
    // return JSON.parse(content) as GeneratedChallenge;

    // For the purpose of this exercise, we return a mock promise
    return new Promise((resolve) => {
        setTimeout(() => {
            resolve({
                challengeId: "550e8400-e29b-41d4-a716-446655440000",
                title: "React Deep Dive",
                description: "Read the official React documentation on Hooks for 30 minutes.",
                pointsReward: 25
            });
        }, 500);
    });
}
