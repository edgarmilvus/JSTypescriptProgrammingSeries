/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

-- 1. Enable the pgvector extension if not already enabled
CREATE EXTENSION IF NOT EXISTS vector;

-- 2. Define the schema for the challenge_feedback table
CREATE TABLE challenge_feedback (
    feedback_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id TEXT NOT NULL,
    challenge_text TEXT NOT NULL,
    challenge_embedding VECTOR(1536), -- Common dimension for text-embedding-ada-002
    rating INTEGER CHECK (rating >= 1 AND rating <= 5)
);

-- 3. Create an HNSW index for efficient similarity search
-- Using inner product (dot product) <#> is often used for cosine similarity 
-- when vectors are normalized, or euclidean <-> for standard distance.
-- Here we use vector_l2_ops for Euclidean distance, but cosine is common for text.
-- For this example, we assume Euclidean distance is the metric.
CREATE INDEX ON challenge_feedback USING hnsw (challenge_embedding vector_l2_ops);

-- 4. Query to find top 3 similar challenges with high ratings
-- We use a parameter placeholder ($1) for the input vector
-- We use the '<->' Euclidean distance operator. Lower distance means more similar.

SELECT 
    challenge_text, 
    rating,
    challenge_embedding <-> $1 AS distance
FROM 
    challenge_feedback
WHERE 
    user_id = 'user123' -- Specific user filter
    AND rating >= 4      -- High rating filter (4 or 5)
ORDER BY 
    distance ASC         -- Sort by closest similarity
LIMIT 3;                -- Limit to top 3 results
