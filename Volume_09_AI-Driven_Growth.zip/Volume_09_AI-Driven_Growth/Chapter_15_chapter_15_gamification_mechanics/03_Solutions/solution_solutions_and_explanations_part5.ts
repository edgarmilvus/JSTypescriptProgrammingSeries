/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

interface SimulationResult {
    finalScore: number;
    actionsTaken: number;
    burnout: boolean;
}

/**
 * Simulates a user's engagement loop over a set number of turns.
 * 
 * @param turns - The total number of turns to simulate.
 * @param rewardThreshold - The point threshold required to trigger a motivation boost.
 */
export function simulateEngagementLoop(turns: number, rewardThreshold: number): SimulationResult {
    let motivation = 100;   // Starting motivation
    let score = 0;          // Starting points
    let actionsTaken = 0;
    let burnout = false;

    // Loop through the simulation turns
    for (let i = 0; i < turns; i++) {
        // Check for burnout condition before acting
        if (motivation <= 0) {
            burnout = true;
            break; // Stop simulation if motivation hits 0
        }

        // Perform the action (Core Loop: Action)
        // Cost: 10 motivation, Reward: 15 points
        motivation -= 10;
        score += 15;
        actionsTaken++;

        // Check for Reward (Core Loop: Reward)
        if (score >= rewardThreshold) {
            // Apply the motivation boost (Core Loop: Feedback)
            motivation += 50;
            
            // Optional: Reset threshold or track boost events in a real system.
            // For this simple loop, we continue checking against the same threshold 
            // (or we could increase it to simulate progressive difficulty).
            // To prevent infinite boosts in a single turn loop, we assume 
            // the threshold is a milestone. In this simulation, we'll leave it 
            // as is, but in a real app, we would likely increment the threshold.
        }
    }

    return {
        finalScore: score,
        actionsTaken: actionsTaken,
        burnout: burnout
    };
}

// --- Example Usage ---
/*
const result = simulateEngagementLoop(20, 100);
console.log(result); 
// Possible Output: { finalScore: 315, actionsTaken: 20, burnout: false }
// If the threshold was too high or motivation cost too steep, burnout might be true.
*/
