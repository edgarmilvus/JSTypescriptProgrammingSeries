/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: theory_theoretical_foundations.ts
// Description: Theoretical Foundations
// ==========================================

// 1. Define the raw, broad type coming from the client.
// It could be ANY event, or it might be malformed.
type AnalyticsEvent = {
  event: string;
  distinct_id: string;
  properties: Record<string, any>; // The "wild west" of data
  timestamp: string;
};

// 2. Define the SPECIFIC type we care about for AI Growth Engineering.
// We only want to analyze interactions with our AI agents.
type AIInteractionEvent = AnalyticsEvent & {
  event: 'ai_interaction';
  properties: {
    prompt_id: string;
    response_time_ms: number;
    user_feedback: 'positive' | 'negative' | null;
    // We explicitly DO NOT track PII like IP or Email here
  };
};

// 3. The Type Guard (The Narrowing Logic).
// This function takes a generic event and checks if it fits our AI shape.
// If it returns true, TypeScript KNOWS it's an AIInteractionEvent.
function isAIInteraction(event: AnalyticsEvent): event is AIInteractionEvent {
  return (
    event.event === 'ai_interaction' &&
    typeof event.properties.prompt_id === 'string' &&
    typeof event.properties.response_time_ms === 'number'
  );
}

// 4. The Processing Function (The "Why").
function processEvent(rawEvent: AnalyticsEvent) {
  // Before Type Narrowing, we are flying blind.
  // We can't safely access rawEvent.properties.prompt_id 
  // because TypeScript complains it might not exist.

  if (isAIInteraction(rawEvent)) {
    // === TYPE NARROWING HAPPENS HERE ===
    // Inside this block, 'rawEvent' is now treated as 'AIInteractionEvent'.
    // We have full autocomplete and type safety.
    
    console.log(`Processing AI Prompt: ${rawEvent.properties.prompt_id}`);
    
    // Now we can safely feed this data into our feedback loop
    // to refine the GPT-4 system prompt used for that prompt_id.
    refineGPTPrompt(rawEvent.properties.prompt_id, rawEvent.properties.user_feedback);
  } else {
    console.log("Non-AI event, ignoring for prompt refinement.");
  }
}

function refineGPTPrompt(id: string, feedback: 'positive' | 'negative' | null) {
    // Logic to update the prompt in the database...
}
