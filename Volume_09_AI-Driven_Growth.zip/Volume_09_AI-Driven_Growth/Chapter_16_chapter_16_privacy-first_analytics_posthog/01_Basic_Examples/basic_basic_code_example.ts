/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

// Import the PostHog library
import posthog from 'posthog-js';

/**
 * Configuration interface for PostHog initialization.
 * @typedef {Object} PostHogConfig
 * @property {string} apiKey - Your PostHog API key (project-specific).
 * @property {string} apiHost - The host URL for your PostHog instance (e.g., 'https://app.posthog.com' for cloud or your self-hosted URL).
 * @property {boolean} [disableCookie] - Optional: Disable cookie-based storage for privacy compliance.
 */
interface PostHogConfig {
  apiKey: string;
  apiHost: string;
  disableCookie?: boolean;
}

/**
 * Initializes the PostHog client with the provided configuration.
 * This function should be called once when the application starts.
 * 
 * @param {PostHogConfig} config - Configuration object for PostHog.
 */
function initializePostHog(config: PostHogConfig): void {
  // Check if PostHog is already initialized to avoid duplicate instances.
  if (posthog.__loaded) {
    console.warn('PostHog is already initialized.');
    return;
  }

  // Initialize PostHog with the provided configuration.
  posthog.init(config.apiKey, {
    api_host: config.apiHost,
    // For privacy-first compliance, we can disable cookie storage.
    // This uses session storage or in-memory storage instead.
    disable_cookie: config.disableCookie ?? false,
    // Enable autocapture for basic interactions (optional, can be disabled for privacy).
    // autocapture: false, // Uncomment to disable
    // Capture page views manually to control what data is sent.
    capture_pageview: false,
  });

  console.log('PostHog initialized successfully.');
}

/**
 * Captures a custom event for AI-generated content views.
 * This event includes properties that can be used for feedback loops.
 * 
 * @param {string} eventName - The name of the event (e.g., 'ai_content_viewed').
 * @param {Object} properties - Additional properties to attach to the event.
 * @param {string} properties.contentId - Unique identifier for the AI-generated content.
 * @param {string} properties.promptVersion - Version of the GPT-4 prompt used to generate the content.
 * @param {string} properties.seoTarget - The SEO keyword or topic targeted.
 */
function captureAIContentViewEvent(
  eventName: string,
  properties: {
    contentId: string;
    promptVersion: string;
    seoTarget: string;
  }
): void {
  // Check if PostHog is initialized before capturing events.
  if (!posthog.__loaded) {
    console.error('PostHog is not initialized. Call initializePostHog first.');
    return;
  }

  // Capture the event with the provided properties.
  posthog.capture(eventName, properties);

  console.log(`Event '${eventName}' captured with properties:`, properties);
}

// Example usage in a web application context.
// This would typically be called when a user views a specific content block.
// For demonstration, we simulate this with a function call.

// Step 1: Define configuration (replace with your actual PostHog instance details).
const config: PostHogConfig = {
  apiKey: 'your-posthog-api-key', // Replace with your actual API key
  apiHost: 'https://app.posthog.com', // Or your self-hosted URL
  disableCookie: true, // Enable cookie-less tracking for privacy
};

// Step 2: Initialize PostHog.
initializePostHog(config);

// Step 3: Simulate capturing an event when AI content is viewed.
// In a real app, this might be triggered by a React useEffect or a DOM event listener.
setTimeout(() => {
  captureAIContentViewEvent('ai_content_viewed', {
    contentId: 'article-123',
    promptVersion: 'v1.2',
    seoTarget: 'programmatic-seo-guide',
  });
}, 1000); // Simulate a delay for page load or content rendering
