/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.tsx
// Description: Advanced Application Script
// ==========================================

import { useEffect, useState } from 'react';
import posthog from 'posthog-js';
import { usePostHog } from 'posthog-js/react';

// --- Types & Interfaces ---

/**
 * Represents the state of user consent for privacy tracking.
 */
interface ConsentState {
  analytics: boolean;
  sessionRecording: boolean;
}

/**
 * Configuration for the A/B test variants.
 * In a real scenario, these might be dynamic prompts sent to GPT-4.
 */
interface ExperimentVariant {
  id: string;
  layout: 'minimal' | 'detailed';
  promptSnippet: string;
}

// --- Configuration ---

const POSTHOG_API_KEY = process.env.NEXT_PUBLIC_POSTHOG_KEY || 'YOUR_KEY';
const POSTHOG_API_HOST = 'https://us.i.posthog.com'; // Or your self-hosted EU instance

const VARIANT_A: ExperimentVariant = {
  id: 'variant_a',
  layout: 'minimal',
  promptSnippet: 'Summarize this topic in 3 bullet points.',
};

const VARIANT_B: ExperimentVariant = {
  id: 'variant_b',
  layout: 'detailed',
  promptSnippet: 'Explain this topic with examples and analogies.',
};

// --- Helper Hooks & Logic ---

/**
 * Custom hook to manage PostHog initialization and user consent.
 * This ensures no data is sent until the user opts-in.
 */
const usePrivacyAnalytics = (consent: ConsentState) => {
  useEffect(() => {
    if (consent.analytics && !posthog._initialized) {
      posthog.init(POSTHOG_API_KEY, {
        api_host: POSTHOG_API_HOST,
        // Disable session recording initially; we enable it conditionally later
        disable_session_recording: !consent.sessionRecording,
        // GDPR compliance settings
        capture_device_id: false, // Avoids fingerprinting
        persistence: 'memory', // Stores distinct ID in memory only, resets on reload (optional strict privacy)
      });
    }
  }, [consent]);
};

/**
 * Main Component: Handles the A/B test logic and UI rendering.
 */
export default function PrivacyFirstExperiment() {
  const [consent, setConsent] = useState<ConsentState>({ analytics: false, sessionRecording: false });
  const [variant, setVariant] = useState<ExperimentVariant | null>(null);
  const posthogClient = usePostHog();

  // Initialize analytics based on consent
  usePrivacyAnalytics(consent);

  /**
   * Handles the user granting consent.
   * Triggers initialization and immediately checks feature flags.
   */
  const handleGrantConsent = () => {
    const newConsent = { analytics: true, sessionRecording: true };
    setConsent(newConsent);
    
    // Re-initialize if needed (or update config)
    if (!posthog._initialized) {
        posthog.init(POSTHOG_API_KEY, {
            api_host: POSTHOG_API_HOST,
            disable_session_recording: !newConsent.sessionRecording,
        });
    }

    // Fetch the assigned variant immediately
    fetchExperimentVariant();
  };

  /**
   * Logic to retrieve the Feature Flag.
   * We use a timeout to simulate async fetching, ensuring PostHog is ready.
   */
  const fetchExperimentVariant = () => {
    // PostHog needs a moment to identify the user (distinct_id)
    setTimeout(() => {
      // 'ai-content-layout' is the feature flag key created in PostHog dashboard
      const flagValue = posthogClient.getFeatureFlag('ai-content-layout');
      
      if (flagValue === 'test') {
        setVariant(VARIANT_B); // 'test' group gets detailed layout
      } else {
        setVariant(VARIANT_A); // Control group gets minimal layout
      }
    }, 500);
  };

  /**
   * Tracks a specific interaction with the AI content.
   * This data feeds back into the GPT-4 prompt optimization loop.
   */
  const trackInteraction = (action: string) => {
    if (posthogClient && consent.analytics) {
      posthogClient.capture('ai_suggestion_interaction', {
        variant_id: variant?.id,
        action: action,
        timestamp: new Date().toISOString(),
      });
    }
  };

  // --- Render Logic ---

  if (!consent.analytics) {
    return (
      <div className="p-6 border rounded-lg max-w-md mx-auto">
        <h2 className="text-xl font-bold mb-4">Privacy-First Experiment</h2>
        <p className="mb-4 text-gray-600">
          To participate in this A/B test and help us improve our AI content, we need your consent to analyze usage patterns.
        </p>
        <button 
          onClick={handleGrantConsent}
          className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700"
        >
          Grant Consent & Start Experiment
        </button>
      </div>
    );
  }

  if (!variant) {
    return <div className="text-center p-10">Loading Experiment...</div>;
  }

  // Render the dynamic AI content based on the Feature Flag
  return (
    <div className="p-8 border rounded-lg max-w-2xl mx-auto bg-white shadow-sm">
      <div className="mb-4 text-xs font-mono text-gray-400 uppercase tracking-wide">
        Experiment ID: ai-content-layout | Variant: {variant.id}
      </div>

      <h1 className="text-2xl font-bold mb-4">Topic: The Future of AI</h1>

      {/* Conditional Layout Rendering */}
      {variant.layout === 'minimal' ? (
        <div className="bg-gray-50 p-4 rounded">
          <ul className="list-disc pl-5 space-y-2">
            <li>Automation of repetitive tasks.</li>
            <li>Enhanced data analysis capabilities.</li>
            <li>Personalized user experiences.</li>
          </ul>
        </div>
      ) : (
        <div className="bg-blue-50 p-4 rounded border border-blue-100">
          <h3 className="font-semibold mb-2">Detailed Explanation</h3>
          <p className="mb-2">
            AI is transforming industries by automating repetitive tasks, similar to how the steam engine revolutionized manufacturing.
          </p>
          <p>
            Furthermore, its ability to analyze vast datasets allows for insights previously impossible, acting as a "co-pilot" for human decision-making.
          </p>
        </div>
      )}

      {/* Interaction Tracking Buttons */}
      <div className="mt-6 flex gap-4">
        <button 
          onClick={() => trackInteraction('clicked_helpful')}
          className="px-4 py-2 border rounded hover:bg-green-50 hover:border-green-300 transition"
        >
          👍 Helpful
        </button>
        <button 
          onClick={() => trackInteraction('clicked_confusing')}
          className="px-4 py-2 border rounded hover:bg-red-50 hover:border-red-300 transition"
        >
          👎 Confusing
        </button>
      </div>

      {/* Privacy Status Indicator */}
      <div className="mt-8 p-3 bg-gray-100 rounded text-sm text-gray-600 flex items-center gap-2">
        <div className="w-2 h-2 rounded-full bg-green-500"></div>
        <span>
          Privacy Mode Active: Analytics are anonymized and hosted in the EU. 
          <button 
            onClick={() => posthogClient.reset()}
            className="underline ml-2 hover:text-gray-900"
          >
            Reset Identity
          </button>
        </span>
      </div>
    </div>
  );
}
