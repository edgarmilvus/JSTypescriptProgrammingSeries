/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// React Component: PrivacyFirstTracker.tsx
// Import dependencies: React, useEffect, posthog

import React, { useEffect } from 'react';

interface PrivacyFirstTrackerProps {
  consentGiven: boolean;
  eventName: string;
  source: string;
}

const PrivacyFirstTracker: React.FC<PrivacyFirstTrackerProps> = ({
  consentGiven,
  eventName,
  source,
}) => {
  useEffect(() => {
    // 1. Privacy Check: Only proceed if explicit consent is provided.
    if (!consentGiven) {
      return;
    }

    // 2. Data Minimization: Construct payload with strictly non-PII data.
    // We exclude user IDs, IP addresses (handled by PostHog config if allowed),
    // and any sensitive text content.
    const eventPayload = {
      source: source,
      timestamp: new Date().toISOString(),
      // Ensure no AI text or user input is added here.
    };

    // 3. Event Capture: Send the sanitized event to PostHog.
    if (typeof window !== 'undefined' && window.posthog) {
      window.posthog.capture(eventName, eventPayload);
    }
  }, [consentGiven, eventName, source]);

  // 4. Rendering: Component renders nothing to avoid UI clutter
  // as it is purely a tracking utility.
  return null;
};

export default PrivacyFirstTracker;

/*
 * Instructor's Analysis:
 * This component uses a React `useEffect` hook to trigger the tracking logic
 * whenever the props change. The core privacy mechanism is the `if (!consentGiven)`
 * check, which acts as a hard gate for any data transmission.
 *
 * The payload construction deliberately limits data to `source` and `timestamp`.
 * This adheres to data minimization principles by avoiding the capture of
 * the actual AI-generated text or user identifiers.
 *
 * Edge-First Consideration (Comments):
 * To implement edge-first queuing:
 * 1. Replace `window.posthog.capture` with a custom function `queueEvent`.
 * 2. `queueEvent` would push the event object into an array stored in `localStorage`
 *    or `IndexedDB`.
 * 3. A separate background worker (Service Worker or setInterval) would periodically
 *    flush this queue to the PostHog endpoint.
 * 4. Benefits: This ensures data persistence during network loss and reduces
 *    request overhead by batching events.
 */
