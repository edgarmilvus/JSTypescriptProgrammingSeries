/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

// TypeScript Utility: promptVariant.ts

// Define types for the PostHog global object if necessary
declare global {
  interface Window {
    posthog: any;
  }
}

export const getAIPromptVariant = (): string => {
  // 1. Feature Flag Check:
  // We check the flag 'meta-description-prompt-v2'.
  // PostHog's `isFeatureEnabled` method typically uses deterministic hashing
  // of the distinct_id (user ID) to assign a variant.
  // This ensures that a specific user always sees the same variant (consistency).
  if (typeof window !== 'undefined' && window.posthog) {
    const isEnabled = window.posthog.isFeatureEnabled('meta-description-prompt-v2');
    
    // 2. Variant Logic:
    // If the flag is strictly true, we return 'concise'. 
    // Otherwise, we default to 'standard'.
    return isEnabled ? 'concise' : 'standard';
  }
  
  // Fallback for server-side rendering or missing PostHog instance
  return "standard";
};

// Example usage in a content generation function
export const generateMetaDescription = async (topic: string): Promise<string> => {
  const variant = getAIPromptVariant();
  
  // Logic to call GPT-4 with the specific prompt based on 'variant'
  // (Pseudo-code for context)
  // const prompt = variant === 'concise' ? SHORT_PROMPT_TEMPLATE : STANDARD_PROMPT_TEMPLATE;
  // const description = await aiClient.generate(prompt, topic);

  // 3. Tracking Requirement:
  // Capture the event immediately after determining the variant.
  if (typeof window !== 'undefined' && window.posthog) {
    window.posthog.capture('prompt_variant_served', {
      variant: variant,
      topic_length: topic.length // Optional context
    });
  }

  // Mock return for the exercise
  return `Generated description for ${topic} using ${variant} prompt...`;
};
