/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

// posthog_config.ts
export const posthogConfig = {
  api_host: 'https://eu.posthog.com', // EU Cloud for data sovereignty
  // Enable session replay
  enable_recording_dom_event_dom_changed: true, // Optional: improve accuracy
  // Disable recording on specific elements via CSS class
  mask_all_text: false, // We want to record non-sensitive text
  mask_input_selector: 'input[type="password"], input[type="email"], .sensitive-input',
  // Alternatively, use a custom class to ignore specific elements
  // ignore_class: 'ph-no-capture' 
};

// CodeSnippetViewer.tsx
import React, { useEffect, useRef } from 'react';

interface CodeSnippetViewerProps {
  code: string;
  language: string;
}

const CodeSnippetViewer: React.FC<CodeSnippetViewerProps> = ({ code, language }) => {
  const codeRef = useRef<HTMLPreElement>(null);

  // Interactive Challenge: Masking logic
  useEffect(() => {
    if (codeRef.current) {
      // Scan the rendered code for potential PII patterns (e.g., API keys)
      // Note: In a real app, this regex would be more robust.
      const piiPattern = /(sk-[a-zA-Z0-9]{20,}|password\s*=\s*['"].*?['"])/g;
      
      // This is a simulation of dynamic masking. 
      // In PostHog replay, masking is usually done via CSS classes or config.
      // However, to satisfy the requirement of masking based on content:
      if (piiPattern.test(code)) {
        // We add a class that PostHog is configured to mask or ignore
        codeRef.current.classList.add('sensitive-input');
      }
    }
  }, [code]);

  return (
    <div className="code-viewer">
      <div className="code-header">
        <span>{language}</span>
        {/* The button is interactive and will be recorded */}
        <button onClick={() => navigator.clipboard.writeText(code)}>
          Copy to Clipboard
        </button>
      </div>
      {/* 
        The pre tag contains the code. 
        If the 'sensitive-input' class is added, PostHog will mask it 
        based on the config provided in posthog_config.ts.
      */}
      <pre ref={codeRef} className="code-content">
        {code}
      </pre>
    </div>
  );
};

export default CodeSnippetViewer;
