/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

// TypeScript Interface: VectorFeedback.ts

export interface VectorFeedbackEvent {
  event: string; // "vector_chunk_feedback"
  vector_id: string;
  relevance_score: 1 | 2 | 3 | 4 | 5;
  query_context: string;
  distinct_id: string;
  timestamp: string; // ISO 8601 string
}

// Function: captureVectorFeedback.ts
// We assume a helper 'db' object exists for IndexedDB operations
// (Implementation of the DB helper is omitted for brevity, but logic is described)

export const captureVectorFeedback = async (eventData: VectorFeedbackEvent): Promise<void> => {
  // 1. Online Check: Determine if we can send immediately
  const isOnline = navigator.onLine;

  if (isOnline) {
    // 2. Immediate Capture (Online):
    // If online, send directly to PostHog for real-time analysis.
    if (typeof window !== 'undefined' && window.posthog) {
      window.posthog.capture(eventData.event, {
        ...eventData,
        // Remove distinct_id from props if PostHog handles it automatically,
        // otherwise keep it if using custom distinct_id logic.
      });
    }
  } else {
    // 3. Edge-First Buffering (Offline):
    // Store the event in IndexedDB to be flushed later.
    // IndexedDB is chosen over localStorage because feedback events
    // might contain large text chunks (query_context) and require asynchronous access
    // without blocking the main thread.
    await storeInIndexedDB(eventData);
  }
};

// Mock implementation of the storage function
async function storeInIndexedDB(event: VectorFeedbackEvent) {
  // Logic: Open DB connection -> Create Transaction -> Add Object
  console.log("Offline: Event buffered in IndexedDB", event);
}

/*
 * Instructor's Analysis:
 * The solution defines a strict interface `VectorFeedbackEvent` ensuring
 * type safety for the RAG feedback loop.
 *
 * The `captureVectorFeedback` function implements an "Edge-First" strategy.
 * It checks `navigator.onLine` to decide the routing path.
 * - Online: Direct capture to PostHog.
 * - Offline: Persistence to IndexedDB.
 *
 * Trade-offs discussed in comments:
 * - IndexedDB vs. localStorage:
 *   - IndexedDB is asynchronous and supports larger data volumes (crucial for `query_context`).
 *   - localStorage is synchronous (blocks UI) and has a strict size limit (usually 5MB).
 *   - For high-volume telemetry like vector feedback, IndexedDB is the superior choice.
 */
