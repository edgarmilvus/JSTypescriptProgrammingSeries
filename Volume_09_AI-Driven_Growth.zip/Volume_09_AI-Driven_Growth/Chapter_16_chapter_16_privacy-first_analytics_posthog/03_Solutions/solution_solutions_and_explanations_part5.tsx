/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.tsx
// Description: Solutions and Explanations
// ==========================================

// React Component: ColdStartMonitor.tsx
import React, { useState } from 'react';

interface ColdStartMonitorProps {
  modelUrl: string; // Base URL for the model
}

const ColdStartMonitor: React.FC<ColdStartMonitorProps> = ({ modelUrl }) => {
  const [latency, setLatency] = useState<number | null>(null);
  const [isEdgeEnabled, setIsEdgeEnabled] = useState<boolean>(false);
  const [isLoading, setIsLoading] = useState<boolean>(false);

  // Helper to simulate network delay
  const simulateFetch = (url: string): Promise<void> => {
    return new Promise((resolve) => {
      // Simulate network latency based on the strategy
      // Edge is faster (e.g., 200ms), Central is slower (e.g., 800ms)
      const delay = url.includes('edge') ? 200 : 800;
      setTimeout(resolve, delay);
    });
  };

  const handleInitialize = async () => {
    setIsLoading(true);
    const startTime = performance.now();

    // Determine URL based on toggle
    const targetUrl = isEdgeEnabled 
      ? `https://cdn.edge.ai/model-v1.wasm` // Simulated Edge URL
      : `${modelUrl}/model-v1.wasm`;       // Simulated Central URL

    try {
      // 1. Simulate Fetch
      await simulateFetch(targetUrl);

      // 2. Measure Duration
      const endTime = performance.now();
      const duration = Math.round(endTime - startTime);
      setLatency(duration);

      // 3. Capture Event
      if (typeof window !== 'undefined' && window.posthog) {
        window.posthog.capture('cold_start_latency', {
          duration_ms: duration,
          strategy: isEdgeEnabled ? 'edge_first' : 'central',
        });
      }
    } catch (error) {
      console.error("Model load failed", error);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div style={{ padding: '20px', border: '1px solid #ccc', borderRadius: '8px' }}>
      <h3>AI Model Cold Start Monitor</h3>
      
      <div style={{ marginBottom: '15px' }}>
        <label>
          <input 
            type="checkbox" 
            checked={isEdgeEnabled} 
            onChange={(e) => setIsEdgeEnabled(e.target.checked)} 
          />
          {' '}Enable Edge-First Pre-fetch
        </label>
      </div>

      <button onClick={handleInitialize} disabled={isLoading}>
        {isLoading ? 'Initializing...' : 'Initialize Model'}
      </button>

      {latency && (
        <div style={{ marginTop: '15px' }}>
          <strong>Last Latency:</strong> {latency} ms
        </div>
      )}
    </div>
  );
};

export default ColdStartMonitor;

/*
 * Graphviz Diagram (DOT Syntax) for Visualization:
 * 
 * digraph G {
 *   rankdir=LR;
 *   User [shape=box];
 *   CentralServer [shape=server, label="Central Origin\n(US-East)"];
 *   EdgeNode [shape=server, label="Edge CDN\n(Paris)", color="green"];
 *   ModelWeights [shape=cylinder, label="Model Weights"];
 * 
 *   // Central Path
 *   User -> CentralServer [label="Standard Fetch\n(800ms)", style=dashed];
 *   CentralServer -> ModelWeights [style=dashed];
 * 
 *   // Edge Path
 *   User -> EdgeNode [label="Edge Fetch\n(200ms)", color="green", fontcolor="green"];
 *   EdgeNode -> ModelWeights [color="green"];
 * }
 */
