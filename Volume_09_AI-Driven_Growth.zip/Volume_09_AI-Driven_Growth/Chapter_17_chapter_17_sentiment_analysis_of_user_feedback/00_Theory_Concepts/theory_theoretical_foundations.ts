/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: theory_theoretical_foundations.ts
// Description: Theoretical Foundations
// ==========================================

// The structured data we expect from the LLM after analyzing feedback.
// This schema drives our automated growth loops.
interface SentimentAnalysisResult {
  // The overall sentiment score, ranging from -1.0 (extremely negative) to 1.0 (extremely positive).
  overallSentiment: number;
  
  // The confidence score of the model in its classification (0.0 to 1.0).
  confidence: number;
  
  // A list of specific aspects mentioned in the text and their associated sentiment.
  aspects: Array<{
    aspect: string; // e.g., "performance", "pricing", "uiux"
    sentiment: 'positive' | 'negative' | 'neutral';
    // Extracted entities relevant to the aspect (e.g., specific feature names).
    entities: string[]; 
  }>;
  
  // Categorization of the feedback intent.
  intent: 'bug_report' | 'feature_request' | 'praise' | 'inquiry';
  
  // Keywords extracted for SEO relevance.
  keywords: string[];
}
