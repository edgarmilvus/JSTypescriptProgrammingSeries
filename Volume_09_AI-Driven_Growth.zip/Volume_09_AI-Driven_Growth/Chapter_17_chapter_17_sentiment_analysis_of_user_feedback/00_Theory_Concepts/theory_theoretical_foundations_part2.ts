/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part2.ts
// Description: Theoretical Foundations
// ==========================================

// app/actions/analyzeFeedback.ts
'use server';

import { openai } from '@ai-sdk/openai';
import { generateObject } from 'ai';
import { z } from 'zod';

// Re-using the interface defined earlier
const SentimentSchema = z.object({
  overallSentiment: z.number().min(-1).max(1),
  confidence: z.number().min(0).max(1),
  intent: z.enum(['bug_report', 'feature_request', 'praise', 'inquiry']),
  keywords: z.array(z.string()),
});

export async function analyzeUserFeedback(feedbackText: string, userId: string) {
  // 1. Data Fetching in Server Components:
  // Fetch user context directly on the server to avoid client waterfalls.
  const userContext = await db.query('SELECT plan, usage_level FROM users WHERE id = $1', [userId]);

  // 2. Construct the prompt with context.
  const systemPrompt = `
    You are a Growth Engineering Analysis Engine.
    Analyze the following user feedback.
    User Context: Plan=${userContext.plan}, Usage=${userContext.usage_level}.
    Prioritize feedback from high-usage users.
  `;

  // 3. Generate structured object using the LLM.
  const { object } = await generateObject({
    model: openai('gpt-4-turbo-preview'),
    schema: SentimentSchema,
    prompt: `${systemPrompt}\n\nFeedback: "${feedbackText}"`,
  });

  // 4. Store the structured insight.
  await db.insert('sentiment_insights').values({
    userId,
    originalText: feedbackText,
    sentimentScore: object.overallSentiment,
    intent: object.intent,
    keywords: object.keywords,
    analyzedAt: new Date(),
  });

  return object;
}
