/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * @fileoverview A basic sentiment analysis service for SaaS user feedback.
 * This example simulates classification logic to demonstrate the data flow
 * from unstructured text to structured sentiment data.
 */

// -----------------------------------------------------------------------------
// 1. TYPE DEFINITIONS & CONSTANTS
// -----------------------------------------------------------------------------

/**
 * Represents the possible sentiment classifications.
 * Using a union type ensures type safety.
 */
type SentimentLabel = 'POSITIVE' | 'NEGATIVE' | 'NEUTRAL';

/**
 * The structured output of our analysis service.
 * This format is ideal for storing in a database (e.g., PostgreSQL, MongoDB)
 * or sending to an analytics dashboard.
 */
interface SentimentResult {
  originalText: string;
  sentiment: SentimentLabel;
  confidenceScore: number; // A value between 0.0 and 1.0
  timestamp: string;       // ISO 8601 format for standardization
}

// Keywords to simulate NLP analysis (in a real app, this would be an LLM call)
const POSITIVE_KEYWORDS = ['love', 'great', 'amazing', 'fast', 'excellent', 'perfect'];
const NEGATIVE_KEYWORDS = ['slow', 'bug', 'crash', 'bad', 'terrible', 'hate', 'broken'];

// -----------------------------------------------------------------------------
// 2. THE CORE LOGIC: SENTIMENT CLASSIFIER
// -----------------------------------------------------------------------------

/**
 * Analyzes a string of text and determines its sentiment.
 * 
 * This function simulates the behavior of a complex NLP model.
 * It uses a simple keyword matching algorithm to assign a sentiment label
 * and a confidence score based on the density of keywords found.
 * 
 * @param text - The raw user feedback string.
 * @returns A Promise resolving to a SentimentResult object.
 *          (Promises are used to simulate async API calls).
 */
async function analyzeSentiment(text: string): Promise<SentimentResult> {
  // Normalize text: lowercase and remove punctuation for easier matching
  const normalizedText = text.toLowerCase().replace(/[^\w\s]/g, '');
  const words = normalizedText.split(' ');

  // Initialize counters
  let positiveScore = 0;
  let negativeScore = 0;

  // Count keyword occurrences
  for (const word of words) {
    if (POSITIVE_KEYWORDS.includes(word)) positiveScore++;
    if (NEGATIVE_KEYWORDS.includes(word)) negativeScore++;
  }

  // Determine sentiment based on scores
  let sentiment: SentimentLabel = 'NEUTRAL';
  let confidence = 0.5; // Default confidence for neutral

  if (positiveScore > negativeScore) {
    sentiment = 'POSITIVE';
    // Calculate confidence: simple ratio of positive hits to total length
    confidence = Math.min(0.95, 0.5 + (positiveScore * 0.1));
  } else if (negativeScore > positiveScore) {
    sentiment = 'NEGATIVE';
    confidence = Math.min(0.95, 0.5 + (negativeScore * 0.1));
  }

  // Simulate network latency (Optimistic UI updates rely on this being fast, 
  // but we add a small delay to mimic real-world processing).
  await new Promise(resolve => setTimeout(resolve, 100));

  return {
    originalText: text,
    sentiment,
    confidenceScore: parseFloat(confidence.toFixed(2)),
    timestamp: new Date().toISOString(),
  };
}

// -----------------------------------------------------------------------------
// 3. MOCK API HANDLER (Simulating a Web Route)
// -----------------------------------------------------------------------------

/**
 * Simulates a Next.js API route or Express.js endpoint.
 * In a real app, this function would be triggered by an HTTP POST request.
 * 
 * @param feedback - The incoming user feedback payload.
 */
async function handleFeedbackSubmission(feedback: { text: string }): Promise<void> {
  console.log('--- Processing New Feedback ---');
  console.log(`Input: "${feedback.text}"`);

  try {
    // 1. Perform Sentiment Analysis
    const result = await analyzeSentiment(feedback.text);

    // 2. Log the structured result (In reality, save to DB here)
    console.log('Analysis Complete:');
    console.log(JSON.stringify(result, null, 2));

    // 3. Trigger downstream actions based on sentiment
    if (result.sentiment === 'NEGATIVE' && result.confidenceScore > 0.7) {
      console.log('>>> ACTION: Auto-create support ticket (High Priority)');
    } else if (result.sentiment === 'POSITIVE') {
      console.log('>>> ACTION: Tag for potential marketing testimonial');
    }

  } catch (error) {
    console.error('Error processing feedback:', error);
  }
}

// -----------------------------------------------------------------------------
// 4. EXECUTION (Simulating User Interaction)
// -----------------------------------------------------------------------------

// Simulating a user submitting a form in the web app
const mockUserFeedback1 = { text: "I love the new dashboard, it's super fast!" };
const mockUserFeedback2 = { text: "The app crashes whenever I try to upload a file. This is terrible." };
const mockUserFeedback3 = { text: "I updated the app today." };

// Run the simulation
(async () => {
  await handleFeedbackSubmission(mockUserFeedback1);
  console.log('\n');
  await handleFeedbackSubmission(mockUserFeedback2);
  console.log('\n');
  await handleFeedbackSubmission(mockUserFeedback3);
})();
