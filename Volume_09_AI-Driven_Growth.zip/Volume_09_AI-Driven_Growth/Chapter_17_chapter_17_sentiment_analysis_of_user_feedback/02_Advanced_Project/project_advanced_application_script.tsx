/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.tsx
// Description: Advanced Application Script
// ==========================================

"use client";

import React, { useState, useTransition } from "react";
import { useChat } from "ai/react"; // Vercel AI SDK

// --- Type Definitions ---

/**
 * Represents the structured output we expect from the LLM after analyzing raw feedback.
 * This allows us to programmatically render UI components based on the analysis.
 */
type FeedbackAnalysis = {
  sentiment: "Positive" | "Negative" | "Neutral";
  confidence: number; // 0.0 to 1.0
  category: "Bug Report" | "Feature Request" | "General Feedback";
  actionItem: string; // A concise summary of what needs to be done
};

// --- Mock Server Action (Simulated) ---
// In a real app, this would be in `app/actions.ts` or `lib/actions.ts`.
// We simulate the server-side processing here for a self-contained script.

/**
 * Simulates a Server Action that sends the user feedback to an LLM for analysis.
 * 
 * @param feedback - The raw text string from the user.
 * @returns A Promise resolving to the structured FeedbackAnalysis object.
 */
async function analyzeFeedbackAction(feedback: string): Promise<FeedbackAnalysis> {
  // 1. Construct the System Prompt for the LLM.
  // This instructs the model to act as a strict sentiment analyzer and extractor.
  const systemPrompt = `
    You are a helpful assistant analyzing user feedback for a SaaS product.
    Analyze the following text and return a JSON object with the following structure:
    {
      "sentiment": "Positive" | "Negative" | "Neutral",
      "confidence": number (0.0 - 1.0),
      "category": "Bug Report" | "Feature Request" | "General Feedback",
      "actionItem": string (A 1-sentence summary of what the team should do)
    }
    
    Text: "${feedback}"
  `;

  // 2. Simulate an API call to an LLM (e.g., GPT-4).
  // In a real Next.js app, we would use `await fetch('/api/analyze')` or `generateText` from ai sdk.
  // We add a slight delay to simulate network latency.
  await new Promise((resolve) => setTimeout(resolve, 800));

  // 3. Mock Logic: Since we can't actually call an API in this static block, 
  // we simulate the LLM's logic based on keywords. 
  // In production, the LLM handles this nuance.
  const lowerFeedback = feedback.toLowerCase();
  let analysis: FeedbackAnalysis;

  if (lowerFeedback.includes("slow") || lowerFeedback.includes("bug") || lowerFeedback.includes("crash")) {
    analysis = {
      sentiment: "Negative",
      confidence: 0.95,
      category: "Bug Report",
      actionItem: "Investigate performance issues on the dashboard and check logs.",
    };
  } else if (lowerFeedback.includes("love") || lowerFeedback.includes("great") || lowerFeedback.includes("awesome")) {
    analysis = {
      sentiment: "Positive",
      confidence: 0.98,
      category: "General Feedback",
      actionItem: "Share this positive feedback with the engineering team.",
    };
  } else if (lowerFeedback.includes("add") || lowerFeedback.includes("feature") || lowerFeedback.includes("wish")) {
    analysis = {
      sentiment: "Neutral",
      confidence: 0.85,
      category: "Feature Request",
      actionItem: "Add this request to the product backlog for prioritization.",
    };
  } else {
    analysis = {
      sentiment: "Neutral",
      confidence: 0.70,
      category: "General Feedback",
      actionItem: "Review for context and archive.",
    };
  }

  return analysis;
}

// --- React Components ---

/**
 * FeedbackCard Component
 * Displays the analyzed feedback with color-coded sentiment indicators.
 */
const FeedbackCard: React.FC<{ analysis: FeedbackAnalysis; originalText: string }> = ({
  analysis,
  originalText,
}) => {
  const sentimentColors = {
    Positive: "bg-green-100 border-green-300 text-green-800",
    Negative: "bg-red-100 border-red-300 text-red-800",
    Neutral: "bg-gray-100 border-gray-300 text-gray-800",
  };

  const categoryColors = {
    "Bug Report": "text-red-600 font-bold",
    "Feature Request": "text-blue-600 font-bold",
    "General Feedback": "text-gray-600 font-bold",
  };

  return (
    <div className={`p-4 rounded-lg border ${sentimentColors[analysis.sentiment]} mb-4 shadow-sm`}>
      <div className="flex justify-between items-start mb-2">
        <span className={`text-sm uppercase tracking-wide ${categoryColors[analysis.category]}`}>
          {analysis.category}
        </span>
        <span className="text-xs font-mono opacity-75">Conf: {(analysis.confidence * 100).toFixed(0)}%</span>
      </div>
      
      <p className="font-medium mb-2">"{originalText}"</p>
      
      <div className="text-sm border-t border-black/10 pt-2 mt-2 opacity-90">
        <strong>Action:</strong> {analysis.actionItem}
      </div>
    </div>
  );
};

/**
 * Main Dashboard Component
 * Integrates useChat for input and useTransition for state management.
 */
export default function FeedbackTriageDashboard() {
  // State for storing the list of analyzed feedbacks
  const [analyzedFeedbacks, setAnalyzedFeedbacks] = useState<FeedbackAnalysis[]>([]);
  
  // useTransition: Allows us to update state without blocking the UI.
  // 'isPending' gives us a boolean to show loading indicators.
  const [isPending, startTransition] = useTransition();

  // useChat Hook: Handles the user input text field and submission logic.
  // We hook into the 'onSubmit' event to intercept and process with our custom logic.
  const { input, handleInputChange, handleSubmit, setInput } = useChat({
    // We disable the default useChat behavior (sending to /api/chat) 
    // because we want to run our custom 'analyzeFeedbackAction' instead.
    api: "/api/placeholder", 
  });

  /**
   * Custom Form Handler
   * Wraps the submission logic to inject our Server Action and Transition.
   */
  const handleAnalyze = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();

    if (!input.trim()) return;

    // Start a transition to update the UI safely
    startTransition(async () => {
      try {
        // 1. Call the analysis logic (Server Action)
        const result = await analyzeFeedbackAction(input);

        // 2. Update the state with the new analysis
        setAnalyzedFeedbacks((prev) => [result, ...prev]);

        // 3. Clear the input field
        setInput("");
      } catch (error) {
        console.error("Analysis failed:", error);
      }
    });
  };

  return (
    <div className="max-w-4xl mx-auto p-6 font-sans">
      <header className="mb-8">
        <h1 className="text-2xl font-bold text-gray-900">Feedback Triage Engine</h1>
        <p className="text-gray-600">
          Submit raw user feedback below. The system will classify sentiment and generate action items automatically.
        </p>
      </header>

      {/* Input Section */}
      <div className="bg-white p-6 rounded-xl shadow-lg border border-gray-200 mb-8">
        <form onSubmit={handleAnalyze} className="flex flex-col gap-4">
          <div>
            <label htmlFor="feedback-input" className="block text-sm font-medium text-gray-700 mb-1">
              User Feedback
            </label>
            <textarea
              id="feedback-input"
              value={input}
              onChange={handleInputChange}
              placeholder="e.g., The app crashes when I click export, or I love the new UI..."
              className="w-full p-3 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors"
              rows={3}
              disabled={isPending} // Disable input while processing
            />
          </div>

          <div className="flex justify-end">
            <button
              type="submit"
              disabled={isPending || !input.trim()}
              className={`px-6 py-2 rounded-md font-medium text-white transition-all ${
                isPending || !input.trim()
                  ? "bg-gray-400 cursor-not-allowed"
                  : "bg-blue-600 hover:bg-blue-700 active:scale-95"
              }`}
            >
              {isPending ? (
                <span className="flex items-center gap-2">
                  <svg className="animate-spin h-4 w-4" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none"></circle>
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                  </svg>
                  Analyzing...
                </span>
              ) : (
                "Analyze Feedback"
              )}
            </button>
          </div>
        </form>
      </div>

      {/* Results Section */}
      <div className="space-y-4">
        <h2 className="text-lg font-semibold text-gray-800">
          Analysis Queue {analyzedFeedbacks.length > 0 && `(${analyzedFeedbacks.length})`}
        </h2>
        
        {analyzedFeedbacks.length === 0 ? (
          <div className="text-center py-10 text-gray-400 border-2 border-dashed border-gray-200 rounded-lg">
            No feedback analyzed yet. Submit a sample above.
          </div>
        ) : (
          analyzedFeedbacks.map((item, index) => (
            <FeedbackCard key={index} analysis={item} originalText={/* Mocking original text storage */ "User Input Processed"} />
          ))
        )}
      </div>
    </div>
  );
}
