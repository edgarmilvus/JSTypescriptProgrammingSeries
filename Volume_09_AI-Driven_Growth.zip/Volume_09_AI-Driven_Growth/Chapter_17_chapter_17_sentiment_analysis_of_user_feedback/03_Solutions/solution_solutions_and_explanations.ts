/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

/**
 * Interfaces and Mock Data
 */

// 1. Simulate a Vector Database Interface
interface KnowledgeBaseChunk {
    id: number;
    content: string;
    tags: string[];
}

// Mock Data representing Product Documentation
const knowledgeBase: KnowledgeBaseChunk[] = [
    { 
        id: 1, 
        content: "API Latency exceeding 500ms is considered a critical performance issue. Classify as negative immediately.", 
        tags: ["api", "performance", "latency", "speed"] 
    },
    { 
        id: 2, 
        content: "Feature 'Dark Mode' is currently in beta. User feedback on this feature is highly valued and should be treated as constructive.", 
        tags: ["feature", "dark mode", "beta", "ui"] 
    },
    { 
        id: 3, 
        content: "Login authentication failures are high priority bugs. These are critical negative sentiment drivers.", 
        tags: ["login", "auth", "bug", "error"] 
    }
];

/**
 * 2. Context Retrieval Function
 * Simulates vector search by matching keywords from the query to tags.
 */
function retrieveContext(query: string): string[] {
    const lowerQuery = query.toLowerCase();
    
    // Filter chunks where at least one tag matches a word in the query
    const relevantChunks = knowledgeBase.filter(chunk => 
        chunk.tags.some(tag => lowerQuery.includes(tag))
    );

    return relevantChunks.map(chunk => chunk.content);
}

/**
 * 3. Prompt Construction Function
 * Builds a detailed prompt instructing the LLM to act as a Senior Product Analyst.
 */
function buildContextualPrompt(userReview: string, context: string[]): string {
    const contextString = context.length > 0 
        ? context.join("\n- ") 
        : "No specific context found.";

    return `
    You are a Senior Product Analyst for a software company. 
    Your task is to analyze user feedback and output a structured JSON object.

    **CRITICAL INSTRUCTIONS:**
    1. You must weight your sentiment analysis based on the provided "Product Context" below.
    2. Technical constraints or known issues in the context should override general sentiment.
    3. If the review mentions a known critical issue (e.g., latency > 500ms), classify it as "negative" regardless of the tone.

    **Product Context:**
    - ${contextString}

    **User Review:**
    "${userReview}"

    **Output Requirements:**
    Return ONLY a valid JSON object with the following structure. Do not include markdown formatting or text outside the JSON.
    {
      "sentiment": "positive" | "negative" | "neutral",
      "confidence": number, // A float between 0.0 and 1.0
      "reasoning": string // A brief explanation citing the context if used.
    }
    `;
}

/**
 * 4. Integration Function
 * Orchestrates the retrieval and prompt building.
 */
function analyzeWithContext(review: string): string {
    // Step 1: Retrieve context
    const context = retrieveContext(review);
    
    // Step 2: Build the prompt
    const prompt = buildContextualPrompt(review, context);
    
    // Step 3: Simulate LLM Call (Returning the prompt for demonstration)
    // In a real scenario, this would be sent to an LLM API.
    return prompt;
}

// --- Usage Example ---
const review = "The API latency is high, but I love the dark mode.";
const generatedPrompt = analyzeWithContext(review);

// console.log(generatedPrompt); 
// (In a real app, you would parse the JSON response from the LLM)
