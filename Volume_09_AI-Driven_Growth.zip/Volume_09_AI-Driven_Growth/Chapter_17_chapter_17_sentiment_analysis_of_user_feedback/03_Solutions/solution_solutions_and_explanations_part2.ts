/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

/**
 * 1. Define the Output Schema
 */
type FeatureRequest = {
    requestTitle: string;
    description: string;
    category: "UI/UX" | "Performance" | "Integration" | "Core Functionality";
    priorityScore: number; // 1-10
};

/**
 * 2. Construct a Few-Shot Prompt
 */
function generateFewShotPrompt(feedback: string): string {
    // Define the examples (shots)
    const examples = [
        {
            input: "I wish I could export my data to CSV.",
            output: `{ "requestTitle": "CSV Export", "description": "User requests ability to export data to CSV format.", "category": "Core Functionality", "priorityScore": 7 }`
        },
        {
            input: "The dark mode hurts my eyes, the contrast is too low.",
            output: `{ "requestTitle": "Dark Mode Contrast", "description": "User reports low contrast in dark mode causing eye strain.", "category": "UI/UX", "priorityScore": 6 }`
        },
        {
            input: "Great app, but crashes on startup on iOS.",
            output: `{ "requestTitle": "iOS Startup Crash", "description": "Application crashes immediately upon launch on iOS devices.", "category": "Performance", "priorityScore": 9 }`
        }
    ];

    // Construct the prompt
    let prompt = `You are an expert product manager. Extract feature requests from user feedback into JSON format.\n\n`;

    examples.forEach((ex, index) => {
        prompt += `Example ${index + 1}:\n`;
        prompt += `Input: "${ex.input}"\n`;
        prompt += `Output: ${ex.output}\n\n`;
    });

    prompt += `Now, analyze the following input:\n`;
    prompt += `Input: "${feedback}"\n`;
    prompt += `Output: `;

    return prompt;
}

/**
 * 3. Parsing Logic
 */
function parseFeatureResponse(llmResponse: string): FeatureRequest | null {
    try {
        // Clean the response: remove potential markdown code blocks or whitespace
        const cleanResponse = llmResponse
            .replace(/