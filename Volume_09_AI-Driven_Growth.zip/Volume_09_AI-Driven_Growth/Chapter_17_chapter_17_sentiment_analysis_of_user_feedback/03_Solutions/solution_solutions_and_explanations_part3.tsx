/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState, useEffect } from 'react';

// Types
type Sentiment = 'positive' | 'negative' | 'neutral';
type Category = 'UI/UX' | 'Performance' | 'Integration' | 'Core Functionality' | 'None';

interface AnalysisResult {
    sentiment: Sentiment;
    extractedFeature?: string;
    category?: Category;
}

// Mock Analysis Function
const analyzeFeedback = (feedback: string, isHighVolume: boolean): Promise<AnalysisResult> => {
    return new Promise((resolve) => {
        setTimeout(() => {
            // Simulate logic based on content
            const lower = feedback.toLowerCase();
            let sentiment: Sentiment = 'neutral';
            let category: Category = 'None';

            if (lower.includes('crash') || lower.includes('slow')) {
                sentiment = 'negative';
                category = 'Performance';
            } else if (lower.includes('love') || lower.includes('great')) {
                sentiment = 'positive';
            } else if (lower.includes('ui') || lower.includes('button')) {
                sentiment = 'neutral'; // Constructive
                category = 'UI/UX';
            }

            // Dynamic behavior: If high volume, prioritize critical bugs
            if (isHighVolume && (lower.includes('crash') || lower.includes('error'))) {
                sentiment = 'negative'; // Force negative for critical issues in high volume
            }

            resolve({
                sentiment,
                category,
                extractedFeature: category !== 'None' ? `Feature: ${category}` : undefined
            });
        }, 500); // Simulate network latency
    });
};

// Helper for Dynamic Prompt Construction
const constructDynamicPrompt = (queueLength: number): string => {
    if (queueLength > 5) {
        return "LLM System Prompt: High volume detected. Prioritize critical bugs and performance issues over feature requests.";
    }
    return "LLM System Prompt: Analyze sentiment normally.";
};

// Component
const SentimentDashboard: React.FC = () => {
    const [feedbackQueue, setFeedbackQueue] = useState<string[]>([]);
    const [analysisResults, setAnalysisResults] = useState<AnalysisResult[]>([]);
    const [isLoading, setIsLoading] = useState<boolean>(false);
    const [inputValue, setInputValue] = useState<string>("");

    // Simulate incoming stream
    useEffect(() => {
        const interval = setInterval(() => {
            const mockFeedback = [
                "The app is great!",
                "It crashes on startup.",
                "UI is confusing.",
                "Performance is slow.",
                "Love the new update.",
                "Billing is broken."
            ];
            const randomFeedback = mockFeedback[Math.floor(Math.random() * mockFeedback.length)];
            
            // Only add if not simulating manual input to avoid clutter
            if (Math.random() > 0.7) {
                setFeedbackQueue(prev => [...prev, randomFeedback]);
            }
        }, 3000);
        return () => clearInterval(interval);
    }, []);

    // Process Queue Effect
    useEffect(() => {
        if (feedbackQueue.length > 0 && !isLoading) {
            processNextItem();
        }
    }, [feedbackQueue, isLoading]);

    const processNextItem = async () => {
        if (feedbackQueue.length === 0) return;

        setIsLoading(true);
        const currentItem = feedbackQueue[0];
        
        // Construct prompt based on current queue length
        const promptContext = constructDynamicPrompt(feedbackQueue.length);
        console.log(`Processing with context: ${promptContext}`); // Debugging

        const result = await analyzeFeedback(currentItem, feedbackQueue.length > 5);

        setAnalysisResults(prev => [...prev, result]);
        setFeedbackQueue(prev => prev.slice(1));
        setIsLoading(false);
    };

    const handleManualAdd = () => {
        if (inputValue.trim()) {
            setFeedbackQueue(prev => [...prev, inputValue]);
            setInputValue("");
        }
    };

    // Visualization Data Calculation
    const sentimentCounts = analysisResults.reduce((acc, curr) => {
        acc[curr.sentiment] = (acc[curr.sentiment] || 0) + 1;
        return acc;
    }, {} as Record<Sentiment, number>);

    const categoryCounts = analysisResults.reduce((acc, curr) => {
        if (curr.category && curr.category !== 'None') {
            acc[curr.category] = (acc[curr.category] || 0) + 1;
        }
        return acc;
    }, {} as Record<Category, number>);

    return (
        <div style={{ padding: '20px', fontFamily: 'sans-serif' }}>
            <h2>Real-Time Sentiment Dashboard</h2>
            
            {/* Controls */}
            <div style={{ marginBottom: '20px' }}>
                <input 
                    type="text" 
                    value={inputValue} 
                    onChange={(e) => setInputValue(e.target.value)}
                    placeholder="Type feedback manually..."
                    style={{ padding: '8px', marginRight: '8px' }}
                />
                <button onClick={handleManualAdd} style={{ padding: '8px' }}>Add Feedback</button>
            </div>

            {/* Status */}
            <div style={{ marginBottom: '20px', padding: '10px', background: '#f0f0f0' }}>
                <strong>Queue Size:</strong> {feedbackQueue.length} | 
                <strong> Processed:</strong> {analysisResults.length} | 
                <strong> Current Prompt Strategy:</strong> {constructDynamicPrompt(feedbackQueue.length)}
            </div>

            {/* Visualizations */}
            <div style={{ display: 'flex', gap: '20px' }}>
                {/* Sentiment Bar Chart */}
                <div style={{ flex: 1, border: '1px solid #ccc', padding: '10px' }}>
                    <h3>Sentiment</h3>
                    {(['positive', 'neutral', 'negative'] as Sentiment[]).map(s => (
                        <div key={s} style={{ marginBottom: '5px' }}>
                            <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                                <span>{s}</span>
                                <span>{sentimentCounts[s] || 0}</span>
                            </div>
                            <div style={{ 
                                height: '10px', 
                                width: `${(sentimentCounts[s] || 0) * 10}%`, 
                                backgroundColor: s === 'positive' ? 'green' : s === 'negative' ? 'red' : 'gray' 
                            }}></div>
                        </div>
                    ))}
                </div>

                {/* Category Bar Chart */}
                <div style={{ flex: 1, border: '1px solid #ccc', padding: '10px' }}>
                    <h3>Categories</h3>
                    {Object.keys(categoryCounts).map(cat => (
                        <div key={cat} style={{ marginBottom: '5px' }}>
                            <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                                <span>{cat}</span>
                                <span>{categoryCounts[cat as Category]}</span>
                            </div>
                            <div style={{ 
                                height: '10px', 
                                width: `${categoryCounts[cat as Category] * 10}%`, 
                                backgroundColor: '#3498db' 
                            }}></div>
                        </div>
                    ))}
                </div>
            </div>
        </div>
    );
};

export default SentimentDashboard;
