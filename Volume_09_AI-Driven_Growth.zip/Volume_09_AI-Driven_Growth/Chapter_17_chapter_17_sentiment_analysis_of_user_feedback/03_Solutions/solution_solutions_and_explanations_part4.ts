/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

/**
 * 1. Type Definitions
 */
type SentimentLabel = 'positive' | 'negative' | 'neutral';
type Topic = 'onboarding' | 'billing' | 'performance' | 'ui';

interface RawFeedback {
    id: number;
    text: string;
}

interface ProcessedItem {
    originalText: string;
    sentiment: SentimentLabel;
    topic: Topic | null;
}

interface DraftArticle {
    topic: Topic;
    title: string;
    bullets: string[];
    sourceCount: number; // How many negative feedback items triggered this
}

/**
 * 2. Simulation Helpers
 */
// Simulates an LLM call to classify sentiment and extract topic
const simulateLLMClassification = (text: string): { sentiment: SentimentLabel; topic: Topic | null } => {
    const lower = text.toLowerCase();
    let sentiment: SentimentLabel = 'neutral';
    let topic: Topic | null = null;

    if (lower.includes('confusing') || lower.includes('tutorial') || lower.includes('onboarding')) {
        topic = 'onboarding';
    } else if (lower.includes('billing') || lower.includes('payment')) {
        topic = 'billing';
    }

    if (lower.includes('broken') || lower.includes('hard') || lower.includes('cant')) {
        sentiment = 'negative';
    } else if (lower.includes('love')) {
        sentiment = 'positive';
    }

    return { sentiment, topic };
};

// Simulates an LLM call to generate content
const simulateContentGeneration = (topic: Topic, count: number): { title: string; bullets: string[] } => {
    // Mock logic for generating content based on topic
    if (topic === 'billing') {
        return {
            title: "Navigating the Billing Dashboard",
            bullets: [
                "Locate the 'Settings' tab in the top right corner.",
                "Click 'Subscription' to view current plans.",
                "Update payment methods under 'Payment Info'."
            ]
        };
    }
    if (topic === 'onboarding') {
        return {
            title: "Getting Started: A Step-by-Step Guide",
            bullets: [
                "Complete the initial setup wizard.",
                "Watch our introductory video series.",
                "Invite team members via the 'Users' tab."
            ]
        };
    }
    return { title: "General Guide", bullets: ["Contact support for assistance."] };
};

/**
 * 3. Pipeline Functions
 */
function processBatch(feedbackArray: string[]): DraftArticle[] {
    // Step A: Input Processing & Classification
    const processedData: ProcessedItem[] = feedbackArray.map((text, index) => {
        const classification = simulateLLMClassification(text);
        return {
            id: index,
            text,
            sentiment: classification.sentiment,
            topic: classification.topic
        };
    });

    // Step B: Sentiment & Topic Clustering
    // Filter for negative sentiment AND known topics
    const negativeFeedbackWithTopics = processedData.filter(
        item => item.sentiment === 'negative' && item.topic !== null
    ) as (ProcessedItem & { topic: Topic })[];

    // Group by topic
    const topicGroups: Record<Topic, ProcessedItem[]> = {};
    negativeFeedbackWithTopics.forEach(item => {
        if (!topicGroups[item.topic]) {
            topicGroups[item.topic] = [];
        }
        topicGroups[item.topic].push(item);
    });

    // Step C: Content Generation
    const draftArticles: DraftArticle[] = [];
    
    // Iterate over topics and generate articles if threshold (>2) is met
    (Object.keys(topicGroups) as Topic[]).forEach(topic => {
        const items = topicGroups[topic];
        if (items.length > 2) {
            const content = simulateContentGeneration(topic, items.length);
            draftArticles.push({
                topic,
                title: content.title,
                bullets: content.bullets,
                sourceCount: items.length
            });
        }
    });

    return draftArticles;
}

// --- Usage Example ---
const feedbackBatch = [
    "I can't find the billing settings.",
    "The onboarding tutorial is too confusing.",
    "Billing page is broken.",
    "I love the design!",
    "Why is onboarding so hard?",
    "The billing update failed.",
    "Onboarding is confusing for new users."
];

const articles = processBatch(feedbackBatch);
// console.log(JSON.stringify(articles, null, 2));
