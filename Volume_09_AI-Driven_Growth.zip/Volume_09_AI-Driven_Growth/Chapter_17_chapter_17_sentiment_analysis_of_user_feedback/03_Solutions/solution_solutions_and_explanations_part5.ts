/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

digraph ContextAugmentationPipeline {
    // Graph settings
    rankdir=TB;
    splines=ortho;
    nodesep=0.8;
    ranksep=0.8;

    // Node definitions
    node [shape=box, style="filled,rounded", fontname="Helvetica"];

    UserInput [label="User Input\n(Review Text)", shape=ellipse, fillcolor="#e3f2fd"];
    VectorSearch [label="Vector Search\n(Retrieval)", shape=diamond, fillcolor="#fff3e0"];
    ContextRetrieval [label="Context Chunks\n(Knowledge Base)", shape=parallelogram, fillcolor="#f3e5f5"];
    
    node [shape=box, fillcolor="#e8f5e9"]; // Green for processing
    PromptConstruction [label="Prompt Construction\n(System + Context + Query)"];
    
    node [shape=cylinder, fillcolor="#fff9c4"]; // Yellow for storage/data
    LLMInference [label="LLM Inference\n(Model Processing)"];
    
    node [shape=hexagon, fillcolor="#ffebee"]; // Red for output
    StructuredOutput [label="Structured Output\n(JSON Result)"];

    // Edges (Flow)
    UserInput -> VectorSearch [label="1. Query"];
    VectorSearch -> ContextRetrieval [label="2. Fetch Relevant Data"];
    ContextRetrieval -> PromptConstruction [label="3. Inject Context"];
    UserInput -> PromptConstruction [label="4. Combine with Query"];
    PromptConstruction -> LLMInference [label="5. Send Prompt"];
    LLMInference -> StructuredOutput [label="6. Return JSON"];

    // Subgraph for visual grouping (Optional, but good for clarity)
    subgraph cluster_0 {
        label = "Pipeline Flow";
        style = "dashed";
        UserInput;
        VectorSearch;
        PromptConstruction;
        LLMInference;
        StructuredOutput;
    }
}
