/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// ==========================================
// PART 1: Edge Function (app/api/feedback/route.ts)
// ==========================================
import { NextRequest, NextResponse } from 'next/server';
import { OpenAIStream, StreamingTextResponse } from 'ai';
import OpenAI from 'openai';

// Define the OpenAI client for Edge Runtime
const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY!,
});

/**
 * @description Type Guard to validate the incoming request body structure.
 * This ensures we have the required fields before processing.
 * @param body - The unknown request body.
 * @returns boolean - True if the body matches the FeedbackRequest interface.
 */
interface FeedbackRequest {
  initialFeedback: string;
  pageContext: string; // e.g., "/dashboard/billing"
  userRole: 'admin' | 'user' | 'guest';
}

function isFeedbackRequest(body: any): body is FeedbackRequest {
  return (
    typeof body?.initialFeedback === 'string' &&
    typeof body?.pageContext === 'string' &&
    typeof body?.userRole === 'string'
  );
}

export const runtime = 'edge'; // Enable Edge Runtime for low latency

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();

    // 1. VALIDATION: Use Type Guard to ensure data integrity
    if (!isFeedbackRequest(body)) {
      return NextResponse.json(
        { error: 'Invalid request payload' },
        { status: 400 }
      );
    }

    const { initialFeedback, pageContext, userRole } = body;

    // 2. CONTEXT AUGMENTATION: Construct the dynamic prompt
    // We inject the page context and user role to guide the LLM's tone and focus.
    const systemPrompt = `
      You are a UX researcher for a SaaS platform. 
      The user is currently on the page: "${pageContext}".
      Their role is: "${userRole}".
      
      The user just submitted this feedback: "${initialFeedback}".
      
      Your task is to generate a SINGLE, empathetic follow-up question 
      to dig deeper into their specific pain point or praise. 
      Keep the question concise (under 20 words) and specific to the context.
    `;

    // 3. LLM INFERENCE: Request a completion from GPT-4
    const response = await openai.chat.completions.create({
      model: 'gpt-4-turbo-preview',
      messages: [
        { role: 'system', content: systemPrompt },
        { role: 'user', content: 'Generate the follow-up question.' }
      ],
      stream: true, // Stream the response for real-time UI updates
      temperature: 0.7,
    });

    // 4. STREAMING: Convert the OpenAI stream to a Next.js compatible stream
    const stream = OpenAIStream(response);
    return new StreamingTextResponse(stream);

  } catch (error) {
    console.error('Edge Function Error:', error);
    return NextResponse.json(
      { error: 'Internal Server Error' },
      { status: 500 }
    );
  }
}

// ==========================================
// PART 2: React Component (components/AdaptiveFeedbackWidget.tsx)
// ==========================================
'use client';

import { useState, useEffect, useRef } from 'react';
import { useChat } from 'ai/react'; // Hook for streaming UI

interface Props {
  pageContext: string;
  userRole: 'admin' | 'user' | 'guest';
}

export default function AdaptiveFeedbackWidget({ pageContext, userRole }: Props) {
  const [stage, setStage] = useState<'idle' | 'questioning' | 'complete'>('idle');
  const [userFeedback, setUserFeedback] = useState('');
  
  // Use Vercel AI SDK hook for handling streaming responses
  const { messages, input, handleInputChange, handleSubmit, isLoading } = useChat({
    api: '/api/feedback',
    body: {
      // These are passed to the Edge Function via context augmentation
      pageContext,
      userRole,
    },
    onFinish: () => {
      setStage('complete');
      // Here you would typically trigger a database write or analytics event
      console.log('Feedback loop closed.');
    }
  });

  /**
   * @description Handles the initial feedback submission.
   * We intercept the standard form submission to manage our local state
   * before sending the data to the edge for context augmentation.
   */
  const onInitialSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!userFeedback.trim()) return;

    // Trigger the AI chat completion with the initial feedback as the first message
    // The `useChat` hook automatically sends this to our Edge API
    handleInputChange({ target: { value: userFeedback } } as any);
    handleSubmit(e);
    setStage('questioning');
  };

  return (
    <div className="fixed bottom-4 right-4 w-80 bg-white shadow-xl rounded-lg border border-gray-200 p-4 font-sans">
      
      {/* STAGE 1: Initial Feedback Input */}
      {stage === 'idle' && (
        <form onSubmit={(e) => { setUserFeedback(e.currentTarget.feedback.value); onInitialSubmit(e); }}>
          <label className="block text-sm font-semibold text-gray-700 mb-2">
            How can we improve this page?
          </label>
          <textarea
            name="feedback"
            className="w-full border rounded p-2 text-sm focus:ring-2 focus:ring-blue-500 outline-none"
            rows={3}
            placeholder="I found the billing section confusing..."
            required
          />
          <button 
            type="submit" 
            className="mt-2 w-full bg-blue-600 text-white py-1.5 rounded text-sm hover:bg-blue-700 transition"
          >
            Send Feedback
          </button>
        </form>
      )}

      {/* STAGE 2: Adaptive Questioning (Streaming) */}
      {stage === 'questioning' && (
        <div className="space-y-3">
          <div className="text-sm text-gray-500">Analyzing context...</div>
          
          {/* Display the AI's generated follow-up question */}
          {messages.length > 0 && (
            <div className="bg-gray-100 p-2 rounded text-sm text-gray-800">
              {messages[messages.length - 1].content}
            </div>
          )}

          {/* Only show input if we haven't answered yet */}
          {messages.length > 0 && !isLoading && (
            <form onSubmit={handleSubmit}>
              <input
                type="text"
                value={input}
                onChange={handleInputChange}
                className="w-full border rounded p-2 text-sm"
                placeholder="Your answer..."
                autoFocus
              />
            </form>
          )}

          {isLoading && <div className="text-xs text-gray-400 animate-pulse">Generating question...</div>}
        </div>
      )}

      {/* STAGE 3: Completion State */}
      {stage === 'complete' && (
        <div className="text-center py-4">
          <div className="text-2xl mb-2">🎉</div>
          <p className="text-sm font-semibold text-green-600">Thank you!</p>
          <p className="text-xs text-gray-500 mt-1">Your feedback has been logged.</p>
          <button 
            onClick={() => setStage('idle')} 
            className="mt-3 text-xs text-blue-600 hover:underline"
          >
            Submit another
          </button>
        </div>
      )}
    </div>
  );
}
