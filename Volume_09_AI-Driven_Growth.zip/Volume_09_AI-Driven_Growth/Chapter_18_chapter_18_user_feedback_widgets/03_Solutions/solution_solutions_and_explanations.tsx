/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState, useEffect, useRef, useTransition } from 'react';

// Define the component
export const IntelligentFeedbackTrigger = () => {
  // State to track if the widget should be visible
  const [isVisible, setIsVisible] = useState<boolean>(false);
  
  // useTransition allows us to mark the state update as non-urgent
  // This keeps the UI responsive even if the logic is slightly heavy
  const [isPending, startTransition] = useTransition();

  // Refs to track progress without causing re-renders on every event
  const dwellTimeRef = useRef<number>(0);
  const hasTriggeredRef = useRef<boolean>(false);
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  // Configuration constants
  const SCROLL_THRESHOLD = 0.6; // 60%
  const DWELL_TIME_THRESHOLD = 45000; // 45 seconds in ms
  const DEBOUNCE_DELAY = 1000; // 1 second debounce

  // Effect for Scroll Depth Logic
  useEffect(() => {
    const handleScroll = () => {
      if (hasTriggeredRef.current) return;

      const scrollHeight = document.documentElement.scrollHeight - window.innerHeight;
      const scrolled = window.scrollY;
      const scrollProgress = scrolled / scrollHeight;

      if (scrollProgress >= SCROLL_THRESHOLD) {
        triggerWidget();
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Effect for Dwell Time Logic
  useEffect(() => {
    const resetTimer = () => {
      if (timerRef.current) clearTimeout(timerRef.current);
      // Only restart timer if we haven't already triggered
      if (!hasTriggeredRef.current) {
        timerRef.current = setTimeout(() => {
          triggerWidget();
        }, DWELL_TIME_THRESHOLD);
      }
    };

    // Listen for active user engagement
    window.addEventListener('mousemove', resetTimer);
    window.addEventListener('keypress', resetTimer);

    // Start initial timer on mount
    resetTimer();

    return () => {
      window.removeEventListener('mousemove', resetTimer);
      window.removeEventListener('keypress', resetTimer);
      if (timerRef.current) clearTimeout(timerRef.current);
    };
  }, []);

  // Centralized trigger function with debounce logic
  const triggerWidget = () => {
    if (hasTriggeredRef.current) return;

    // Mark as triggered immediately to prevent race conditions
    hasTriggeredRef.current = true;

    // Clear any pending timers
    if (timerRef.current) clearTimeout(timerRef.current);

    // Debounce the actual state update using startTransition
    setTimeout(() => {
      startTransition(() => {
        setIsVisible(true);
      });
    }, DEBOUNCE_DELAY);
  };

  // Edge-First Consideration Comment:
  /*
   * To minimize main thread impact, we could offload the event listeners to a Web Worker.
   * 1. Create a worker script that listens for scroll/dwell events.
   * 2. The worker calculates the progress thresholds.
   * 3. When a threshold is met, the worker posts a message back to the main thread.
   * 4. The main thread receives the message and calls startTransition(() => setIsVisible(true)).
   * This ensures heavy calculations or frequent event firing don't block the UI rendering.
   */

  if (!isVisible) return null;

  return (
    <div className="feedback-widget" style={{ position: 'fixed', bottom: 20, right: 20, background: '#fff', padding: '20px', border: '1px solid #ccc', opacity: isPending ? 0.7 : 1 }}>
      <h3>Feedback</h3>
      <p>How are we doing?</p>
      {/* Form inputs would go here */}
    </div>
  );
};
