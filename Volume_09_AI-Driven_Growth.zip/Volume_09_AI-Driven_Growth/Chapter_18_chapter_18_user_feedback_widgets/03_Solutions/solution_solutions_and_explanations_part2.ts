/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

// File: pages/api/generate-feedback-question.ts (or app/api/generate-feedback-question/route.ts)

import type { NextApiRequest, NextApiResponse } from 'next';

// 1. Input Schema Interface
interface RequestBody {
  context: {
    pageTitle: string;
    contentType: 'tutorial' | 'product-page' | 'blog';
    keywords: string[];
  };
}

// 2. Response Interface
interface ResponseData {
  questionId: string;
  questionText: string;
}

// 3. Mock LLM Integration
// In a real app, this would call an API like OpenAI's ChatCompletion
async function callLLMForQuestion(context: RequestBody['context']): Promise<string> {
  // Simulate network delay
  await new Promise(resolve => setTimeout(resolve, 500));

  // Mock Logic based on content type
  if (context.contentType === 'tutorial') {
    return `Was the explanation of "${context.keywords[0] || 'the concept'}" clear enough for you to apply it immediately?`;
  }
  
  if (context.contentType === 'product-page') {
    return `Does the value proposition of ${context.pageTitle} meet your expectations?`;
  }

  // Default generic question
  return `How can we improve the content on ${context.pageTitle}?`;
}

// 4. API Route Handler
export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse<ResponseData | { error: string }>
) {
  // Ensure POST method
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method Not Allowed' });
  }

  try {
    const { context } = req.body as RequestBody;

    // Validate input
    if (!context || !context.pageTitle) {
      return res.status(400).json({ error: 'Missing context' });
    }

    // Call the LLM service
    const questionText = await callLLMForQuestion(context);

    // Generate a simple UUID for the question
    const questionId = `q_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;

    // Return success
    res.status(200).json({ questionId, questionText });

  } catch (error) {
    // 5. Error Handling & Fallback
    console.error('LLM Service Error:', error);
    
    // Fallback to a generic question to ensure UI stability
    const fallbackQuestion: ResponseData = {
      questionId: `fallback_${Date.now()}`,
      questionText: 'What did you think about this page?'
    };

    res.status(200).json(fallbackQuestion);
  }
}
