/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

// 1. Type Definitions (Reusing from Exercise 3)
interface ProcessedFeedback {
  sentimentScore: number;
  category: 'Bug Report' | 'Feature Request' | 'Praise' | 'General Inquiry';
  summary: string;
}

// 2. Aggregation Logic
export function analyzeFeedbackTrends(
  feedbackData: ProcessedFeedback[], 
  threshold: number
): { isFlagged: boolean; refinementPrompt?: string } {
  
  const totalFeedback = feedbackData.length;
  if (totalFeedback === 0) return { isFlagged: false };

  // Filter for "Confusion Signals": Negative sentiment + General Inquiry
  // Note: We also consider Bug Reports related to navigation as confusion
  const confusingFeedback = feedbackData.filter(item => 
    item.sentimentScore < -0.2 && 
    (item.category === 'General Inquiry' || item.category === 'Bug Report')
  );

  const confusionRate = confusingFeedback.length / totalFeedback;

  // Check against threshold
  if (confusionRate >= threshold) {
    // Generate the Refinement Prompt
    const prompt = `
      ANALYSIS: The content on this page is generating high confusion rates (${(confusionRate * 100).toFixed(0)}%).
      Users are specifically reporting issues with clarity and usability.
      
      TASK: Rewrite the page content to be more user-friendly.
      1. Simplify sentence structures.
      2. Break down complex steps into bullet points.
      3. Ensure UI elements (buttons, links) are explicitly mentioned.
      
      FEEDBACK SAMPLES FOR CONTEXT:
      ${confusingFeedback.map(f => `- "${f.summary}"`).join('\n')}
    `;
    
    return { isFlagged: true, refinementPrompt: prompt };
  }

  return { isFlagged: false };
}

// 3. Interactive Challenge: Scenario Application

// Input Data
const scenarioData: ProcessedFeedback[] = [
  { sentimentScore: -0.4, category: 'General Inquiry', summary: "The steps are confusing." },
  { sentimentScore: 0.1, category: 'General Inquiry', summary: "I love the new design but step 3 is unclear." },
  { sentimentScore: 0.8, category: 'Praise', summary: "Great guide!" },
  { sentimentScore: -0.6, category: 'Bug Report', summary: "I can't find the download button mentioned in step 3." }
];

// Execution
const result = analyzeFeedbackTrends(scenarioData, 0.30); // 30% Threshold

// Output Generation
console.log("Flagged:", result.isFlagged);
if (result.isFlagged && result.refinementPrompt) {
  console.log("Generated Prompt:", result.refinementPrompt);
}
