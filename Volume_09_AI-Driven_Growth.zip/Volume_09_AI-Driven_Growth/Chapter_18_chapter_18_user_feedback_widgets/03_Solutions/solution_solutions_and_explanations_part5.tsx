/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState, useTransition } from 'react';

// Mock API function
const mockApiSubmit = async (text: string): Promise<boolean> => {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      // Simulate a 50% failure rate for testing error handling
      if (Math.random() > 0.5) {
        resolve(true);
      } else {
        reject(new Error("Server error"));
      }
    }, 1000);
  });
};

// Define the Feedback Item type
interface FeedbackItem {
  id: string;
  text: string;
  isPending: boolean; // To track optimistic state
}

export const FeedbackForm = () => {
  const [inputValue, setInputValue] = useState('');
  const [items, setItems] = useState<FeedbackItem[]>([]);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  
  // useTransition hook
  const [isPending, startTransition] = useTransition();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputValue.trim()) return;

    const tempId = `temp_${Date.now()}`;
    const newItem: FeedbackItem = {
      id: tempId,
      text: inputValue,
      isPending: true // Mark as pending immediately
    };

    // Optimistically update the UI
    startTransition(() => {
      setItems((prev) => [newItem, ...prev]);
      setInputValue(''); // Clear input immediately
      setErrorMessage(null); // Clear previous errors
    });

    // Run the server interaction
    // We don't await this inside startTransition, but we handle the result
    const submission = mockApiSubmit(newItem.text);

    submission
      .then(() => {
        // Success: Update the item to not be pending
        startTransition(() => {
          setItems((prev) =>
            prev.map((item) =>
              item.id === tempId ? { ...item, isPending: false } : item
            )
          );
        });
      })
      .catch((error) => {
        // Failure: Revert the UI
        startTransition(() => {
          setItems((prev) => prev.filter((item) => item.id !== tempId));
          setErrorMessage("Failed to submit feedback. Please try again.");
        });
      });
  };

  return (
    <div style={{ padding: '20px', maxWidth: '400px', margin: '0 auto' }}>
      <form onSubmit={handleSubmit}>
        <input
          type="text"
          value={inputValue}
          onChange={(e) => setInputValue(e.target.value)}
          placeholder="Enter feedback..."
          disabled={isPending} // Disable input during transition if desired
          style={{ width: '100%', padding: '8px' }}
        />
        <button type="submit" disabled={isPending || !inputValue} style={{ marginTop: '10px' }}>
          {isPending ? 'Submitting...' : 'Submit'}
        </button>
      </form>

      {errorMessage && (
        <div style={{ color: 'red', marginTop: '10px' }}>{errorMessage}</div>
      )}

      <ul style={{ marginTop: '20px', listStyle: 'none', padding: 0 }}>
        {items.map((item) => (
          <li
            key={item.id}
            style={{
              padding: '8px',
              borderBottom: '1px solid #eee',
              // Visual distinction for pending items
              opacity: item.isPending ? 0.5 : 1,
              fontStyle: item.isPending ? 'italic' : 'normal',
              backgroundColor: item.isPending ? '#f9f9f9' : '#fff'
            }}
          >
            {item.text} {item.isPending && <span> (Saving...)</span>}
          </li>
        ))}
      </ul>
    </div>
  );
};
