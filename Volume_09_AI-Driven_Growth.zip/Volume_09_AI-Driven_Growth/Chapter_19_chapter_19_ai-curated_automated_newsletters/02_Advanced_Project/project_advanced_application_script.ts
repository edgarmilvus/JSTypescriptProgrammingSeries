/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// app/actions/newsletterActions.ts
'use server';

import { ReactNode } from 'react';
import { createStreamableUI, createStreamableValue } from 'ai/rsc'; // Hypothetical Vercel AI SDK imports
import { OpenAI } from 'openai'; // Standard OpenAI SDK

// ============================================================================
// 1. TYPE DEFINITIONS & INTERFACES
// ============================================================================

/**
 * Interface defining the shape of a raw article fetched from a source.
 * Interfaces are used here to establish a strict contract for external data.
 */
export interface RawArticle {
  id: string;
  url: string;
  title: string;
  content: string;
  publishedAt: Date;
}

/**
 * Interface defining the shape of the curated newsletter item.
 * This separates the raw data structure from the processed output structure.
 */
export interface CuratedNewsletterItem {
  headline: string;
  summary: string;
  sentiment: 'positive' | 'neutral' | 'negative';
  keyPoints: string[];
}

// ============================================================================
// 2. MOCK DATA FETCHER (EDGE-READY)
// ============================================================================

/**
 * Simulates an edge-optimized scraper.
 * In a real scenario, this would use libraries like Cheerio or Puppeteer Cloud.
 * It returns a Promise of raw articles.
 */
async function fetchRawSources(): Promise<RawArticle[]> {
  // Simulating network latency
  await new Promise(resolve => setTimeout(resolve, 500));

  return [
    {
      id: '1',
      url: 'https://technews.example/ai-growth',
      title: 'AI Sector Sees 300% Growth in Q3',
      content: 'The artificial intelligence sector has experienced unprecedented growth...',
      publishedAt: new Date(),
    },
    {
      id: '2',
      url: 'https://technews.example/web-assembly',
      title: 'WebAssembly Adoption Rises',
      content: 'Developers are increasingly adopting WebAssembly for performance-critical tasks...',
      publishedAt: new Date(),
    },
  ];
}

// ============================================================================
// 3. AI PROCESSING LAYER
// ============================================================================

/**
 * Uses LLM to transform raw content into a structured newsletter object.
 * This logic is offloaded to the server to keep the client lightweight.
 * 
 * @param article - The raw article data.
 * @returns A Promise resolving to a CuratedNewsletterItem.
 */
async function processArticleWithAI(article: RawArticle): Promise<CuratedNewsletterItem> {
  // NOTE: In a production environment, you would instantiate OpenAI here:
  // const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
  
  // Simulating LLM response generation for this example script.
  // The AI analyzes the content and extracts specific structure.
  await new Promise(resolve => setTimeout(resolve, 300)); // Simulate inference time

  return {
    headline: `🚀 ${article.title}`, // Example of simple transformation
    summary: `A concise summary of the article "${article.title}" focusing on the main impact.`,
    sentiment: 'positive',
    keyPoints: [
      'Key point 1 extracted from context.',
      'Key point 2 regarding industry trends.',
    ],
  };
}

// ============================================================================
// 4. THE CORE SERVER ACTION (STREAMABLE UI)
// ============================================================================

/**
 * The main Server Action invoked by the client.
 * It creates a streamable UI component that updates progressively as
 * articles are fetched and processed.
 * 
 * This implements the 'streamable-ui' architectural pattern.
 */
export async function generateNewsletterStream() {
  // 1. Initialize the streamable UI container.
  // This acts as a placeholder that will be progressively updated.
  const streamableUI = createStreamableUI(
    <div className="animate-pulse bg-gray-100 h-32 rounded-lg" />
  );

  // 2. Fetch raw data (Edge task).
  const articles = await fetchRawSources();

  // 3. Process articles sequentially to stream updates.
  // We use a loop to yield UI updates as soon as each article is processed.
  const processedItems: CuratedNewsletterItem[] = [];

  for (const article of articles) {
    // Process the individual article
    const curatedItem = await processArticleWithAI(article);
    processedItems.push(curatedItem);

    // Update the streamable UI with the new component.
    // We reconstruct the UI to include the latest item.
    streamableUI.update(
      <div className="space-y-4 p-4 border rounded-lg">
        {processedItems.map((item, index) => (
          <div key={index} className="p-3 bg-white shadow-sm rounded border">
            <h3 className="font-bold text-lg text-blue-600">{item.headline}</h3>
            <p className="text-gray-600 mt-2">{item.summary}</p>
            <ul className="list-disc pl-5 mt-2 text-sm text-gray-500">
              {item.keyPoints.map((point, i) => (
                <li key={i}>{point}</li>
              ))}
            </ul>
            <span className={`inline-block mt-2 px-2 py-1 text-xs rounded ${
              item.sentiment === 'positive' ? 'bg-green-100 text-green-800' : 'bg-gray-100'
            }`}>
              Sentiment: {item.sentiment}
            </span>
          </div>
        ))}
      </div>
    );
  }

  // 4. Finalize the stream.
  // Once all processing is done, we close the stream with a final footer.
  streamableUI.done(
    <div className="mt-6 p-4 bg-blue-50 text-blue-800 rounded-lg text-center">
      <p className="font-bold">Newsletter Generation Complete</p>
      <p className="text-sm">Delivered {articles.length} curated updates.</p>
    </div>
  );

  return { ui: streamableUI.value };
}
