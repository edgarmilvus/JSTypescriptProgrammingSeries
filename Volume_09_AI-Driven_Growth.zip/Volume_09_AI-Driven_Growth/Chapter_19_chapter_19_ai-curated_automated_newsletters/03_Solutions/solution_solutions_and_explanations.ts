/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// types.ts
export interface Article {
  url: string;
  title: string;
  content: string;
}

export interface Newsletter {
  id: string;
  timestamp: Date;
  articles: Article[];
}

// utils.ts
import { Article, Newsletter } from './types';

/**
 * Simulates fetching an article from a URL.
 * Randomly delays (100-500ms) and has a 20% chance of rejection.
 */
export const fetchArticle = (url: string): Promise<Article> => {
  return new Promise((resolve, reject) => {
    const delay = Math.floor(Math.random() * 400) + 100; // 100-500ms
    const shouldFail = Math.random() < 0.2; // 20% chance of failure

    setTimeout(() => {
      if (shouldFail) {
        reject(new Error(`Failed to fetch ${url}`));
      } else {
        resolve({
          url,
          title: `Article from ${url}`,
          content: `This is the content for ${url}. It took ${delay}ms to fetch.`
        });
      }
    }, delay);
  });
};

/**
 * Generates a newsletter by fetching articles from provided URLs.
 * Uses Promise.allSettled to ensure all promises settle (resolve or reject).
 */
export const generateNewsletter = async (urls: string[]): Promise<Newsletter> => {
  console.log('Starting newsletter generation...');
  
  // Create an array of promises
  const fetchPromises = urls.map(url => fetchArticle(url));

  // Wait for all promises to settle
  const results = await Promise.allSettled(fetchPromises);

  const successfulArticles: Article[] = [];

  // Process results
  results.forEach((result, index) => {
    if (result.status === 'fulfilled') {
      console.log(`[SUCCESS] Fetched article from ${urls[index]}`);
      successfulArticles.push(result.value);
    } else {
      console.log(`[FAILURE] Could not fetch article from ${urls[index]}. Reason: ${result.reason.message}`);
    }
  });

  return {
    id: `newsletter-${Date.now()}`,
    timestamp: new Date(),
    articles: successfulArticles
  };
};
