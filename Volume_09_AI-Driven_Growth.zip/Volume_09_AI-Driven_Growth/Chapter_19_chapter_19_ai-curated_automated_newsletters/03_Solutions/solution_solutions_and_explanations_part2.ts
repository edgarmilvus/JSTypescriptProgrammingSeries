/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

// types.ts
export interface Article {
  url: string;
  title: string;
  content: string;
}

// vector-store.ts
export interface VectorStore {
  upsert(id: string, vector: number[]): Promise<void>;
  query(vector: number[], topK: number): Promise<{ id: string; score: number }[]>;
}

export class MockVectorStore implements VectorStore {
  // In-memory storage: id -> vector
  private store: Map<string, number[]> = new Map();

  async upsert(id: string, vector: number[]): Promise<void> {
    // Simulate async I/O
    await new Promise(resolve => setTimeout(resolve, 10)); 
    this.store.set(id, vector);
  }

  async query(vector: number[], topK: number): Promise<{ id: string; score: number }[]> {
    // Simulate async I/O
    await new Promise(resolve => setTimeout(resolve, 10));

    const results: { id: string; score: number }[] = [];

    // Calculate cosine similarity (simplified for demo)
    for (const [id, storedVector] of this.store) {
      const score = this.cosineSimilarity(vector, storedVector);
      results.push({ id, score });
    }

    // Sort by score descending
    return results.sort((a, b) => b.score - a.score).slice(0, topK);
  }

  // Helper to calculate cosine similarity
  private cosineSimilarity(v1: number[], v2: number[]): number {
    if (v1.length !== v2.length) return 0;
    
    let dotProduct = 0;
    let normA = 0;
    let normB = 0;

    for (let i = 0; i < v1.length; i++) {
      dotProduct += v1[i] * v2[i];
      normA += v1[i] * v1[i];
      normB += v2[i] * v2[i];
    }

    if (normA === 0 || normB === 0) return 0;
    return dotProduct / (Math.sqrt(normA) * Math.sqrt(normB));
  }
}

// deduplication.ts
import { Article } from './types';
import { VectorStore } from './vector-store';

export class DeduplicationService {
  constructor(private vectorStore: VectorStore) {}

  /**
   * Generates a mock embedding vector based on content length.
   * In a real app, this would call an LLM embedding API.
   */
  private generateEmbedding(content: string): number[] {
    // Create a simple vector of size 5 based on length and char codes
    const base = content.length % 100; 
    return [base / 100, base * 0.5, base * 0.2, base * 0.1, base * 0.05];
  }

  async isDuplicate(article: Article, threshold: number = 0.95): Promise<boolean> {
    const vector = this.generateEmbedding(article.content);
    const results = await this.vectorStore.query(vector, 1);

    if (results.length === 0) return false;

    // If the top result score is above threshold, it's a duplicate
    return results[0].score > threshold;
  }

  async addArticle(article: Article): Promise<void> {
    const isDup = await this.isDuplicate(article);
    if (isDup) {
      console.log(`[DEDUP] Skipped duplicate article: ${article.title}`);
      return;
    }

    console.log(`[DEDUP] Adding unique article: ${article.title}`);
    const vector = this.generateEmbedding(article.content);
    await this.vectorStore.upsert(article.url, vector);
  }
}
