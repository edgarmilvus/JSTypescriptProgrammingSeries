/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

digraph VectorStorePipeline {
    rankdir=LR;
    node [shape=box, style="rounded,filled", color="#e0e0e0"];

    Article [label="Article (Data Source)", fillcolor="#a7c7e7"];
    DeduplicationService [label="DeduplicationService", fillcolor="#c1e1c1"];
    VectorStore [label="MockVectorStore (DB)", fillcolor="#f8d7da"];
    
    Article -> DeduplicationService [label="1. Check for Duplicate"];
    DeduplicationService -> VectorStore [label="2. Query (Read)"];
    VectorStore -> DeduplicationService [label="3. Return Similarity Score"];
    
    DeduplicationService -> VectorStore [label="4. Upsert (Write)", style=dashed];
}
