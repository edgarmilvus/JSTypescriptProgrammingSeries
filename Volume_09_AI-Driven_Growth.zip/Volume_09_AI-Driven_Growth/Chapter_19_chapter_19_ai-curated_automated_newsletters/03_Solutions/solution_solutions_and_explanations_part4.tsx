/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.tsx
// Description: Solutions and Explanations
// ==========================================

// NewsletterDashboard.tsx
import React, { useState } from 'react';

// 1. Define Interfaces
export interface NewsletterMetric {
  id: string;
  subject: string;
  sentDate: string;
  openRate: number; // 0-100
  ctr: number;      // 0-100
}

interface NewsletterDashboardProps {
  metrics: NewsletterMetric[];
}

// 2. Styles for the bar chart (inline for simplicity)
const styles = {
  container: { fontFamily: 'sans-serif', padding: '20px' },
  list: { listStyle: 'none', padding: 0 },
  listItem: { 
    padding: '10px', 
    borderBottom: '1px solid #ccc', 
    cursor: 'pointer', 
    hover: { backgroundColor: '#f0f0f0' } 
  },
  detailCard: { 
    marginTop: '20px', 
    padding: '20px', 
    border: '1px solid #ddd', 
    borderRadius: '8px' 
  },
  chartRow: { marginBottom: '10px' },
  barContainer: { 
    height: '20px', 
    backgroundColor: '#e0e0e0', 
    borderRadius: '4px', 
    marginTop: '5px',
    overflow: 'hidden'
  },
  bar: { 
    height: '100%', 
    backgroundColor: '#4caf50', 
    transition: 'width 0.3s ease' 
  },
  ctrBar: { backgroundColor: '#2196f3' }
};

const NewsletterDashboard: React.FC<NewsletterDashboardProps> = ({ metrics }) => {
  const [selectedId, setSelectedId] = useState<string | null>(null);

  // Handle empty state
  if (!metrics || metrics.length === 0) {
    return <div style={styles.container}>No metrics available.</div>;
  }

  const selectedNewsletter = metrics.find(m => m.id === selectedId);

  return (
    <div style={styles.container}>
      <h2>Newsletter Analytics</h2>
      
      {/* 3. Render List */}
      <ul style={styles.list}>
        {metrics.map((metric) => (
          <li 
            key={metric.id} 
            onClick={() => setSelectedId(metric.id)}
            style={{
              ...styles.listItem,
              backgroundColor: selectedId === metric.id ? '#e3f2fd' : 'white'
            }}
          >
            <strong>{metric.subject}</strong> - Sent: {metric.sentDate}
          </li>
        ))}
      </ul>

      {/* 4. Conditional Detail View */}
      {selectedNewsletter && (
        <div style={styles.detailCard}>
          <h3>Details: {selectedNewsletter.subject}</h3>
          <p>Sent: {selectedNewsletter.sentDate}</p>

          {/* Open Rate Bar */}
          <div style={styles.chartRow}>
            <label>Open Rate: {selectedNewsletter.openRate}%</label>
            <div style={styles.barContainer}>
              <div 
                style={{ 
                  ...styles.bar, 
                  width: `${selectedNewsletter.openRate}%` 
                }} 
              />
            </div>
          </div>

          {/* CTR Bar */}
          <div style={styles.chartRow}>
            <label>CTR: {selectedNewsletter.ctr}%</label>
            <div style={styles.barContainer}>
              <div 
                style={{ 
                  ...styles.bar, 
                  ...styles.ctrBar,
                  width: `${selectedNewsletter.ctr}%` 
                }} 
              />
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default NewsletterDashboard;
