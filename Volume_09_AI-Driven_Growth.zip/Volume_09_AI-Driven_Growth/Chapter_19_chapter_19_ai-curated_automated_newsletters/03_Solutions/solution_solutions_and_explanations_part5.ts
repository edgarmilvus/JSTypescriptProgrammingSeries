/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

// retry.ts

/**
 * Executes an async operation with exponential backoff retry logic.
 * @param operation - The async function to execute.
 * @param maxRetries - Maximum number of retry attempts.
 * @param delay - Initial delay in milliseconds.
 */
export async function withRetry<T>(
  operation: () => Promise<T>,
  maxRetries: number,
  delay: number
): Promise<T> {
  let attempt = 0;

  while (attempt <= maxRetries) {
    try {
      // Attempt to execute the operation
      const result = await operation();
      return result;
    } catch (error) {
      attempt++;
      
      // If we've exceeded max retries, throw the error
      if (attempt > maxRetries) {
        console.error(`[Retry] Final failure after ${maxRetries} retries.`);
        throw error;
      }

      // Log the retry attempt
      console.warn(
        `[Retry] Attempt ${attempt} failed. Retrying in ${delay}ms...`
      );

      // Wait for the specified delay
      await new Promise(resolve => setTimeout(resolve, delay));

      // Exponential backoff: double the delay for the next attempt
      delay *= 2;
    }
  }

  // This line is theoretically unreachable due to the throw inside the loop,
  // but TypeScript requires a return path.
  throw new Error('Unexpected state in withRetry');
}

// simulation.ts
import { withRetry } from './retry';

// Simulate an API call that fails the first 3 times and succeeds on the 4th
let callCount = 0;

const simulateFailingApi = async (): Promise<string> => {
  callCount++;
  console.log(`[API] Call attempt #${callCount}`);
  
  if (callCount < 4) {
    throw new Error(`Simulated Network Error (Attempt ${callCount})`);
  }
  
  return "Success: Data received from AI API";
};

// Test the function
(async () => {
  try {
    console.log("--- Starting Retry Simulation ---");
    const result = await withRetry(simulateFailingApi, 5, 100); // Max 5 retries, start with 100ms
    console.log("--- Operation Succeeded ---");
    console.log("Result:", result);
  } catch (error) {
    console.error("--- Operation Failed Permanently ---");
    console.error(error);
  }
})();
