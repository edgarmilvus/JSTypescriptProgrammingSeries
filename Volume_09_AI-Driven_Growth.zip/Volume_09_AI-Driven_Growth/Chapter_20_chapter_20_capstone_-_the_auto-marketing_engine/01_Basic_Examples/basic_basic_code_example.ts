/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * @fileoverview Auto-Marketing Engine: Basic pSEO Page Generation
 * 
 * This script demonstrates the core logic of generating a dynamic landing page
 * based on a data entity. It simulates the behavior of a headless CMS rendering
 * a page from a template.
 */

// --- 1. TYPE DEFINITIONS ---

/**
 * Represents the raw data input for a specific page (e.g., a City, a Product).
 * We use Type Inference later when creating objects of this type.
 */
type EntityData = {
  name: string;
  category: string;
  feature: string;
};

/**
 * Represents the final output of the engine: a structured page ready for deployment.
 */
type GeneratedPage = {
  slug: string;
  title: string;
  metaDescription: string;
  bodyContent: string;
  timestamp: Date;
};

// --- 2. LOGIC MODULES (SRP) ---

/**
 * Module A: Content Generation.
 * Responsibility: Pure text generation. No API calls, no formatting.
 * @param data - The entity data to base the content on.
 * @returns A string containing the generated HTML body.
 */
function generateContent(data: EntityData): string {
  // Simple template literal acting as our "Prompt Engineering" layer
  return `
    <section class="hero">
      <h1>The Ultimate Guide to ${data.name}</h1>
      <p>Exploring the best of ${data.category} in ${data.name}.</p>
    </section>
    <section class="features">
      <h2>Why choose ${data.name}?</h2>
      <p>Experience the unique ${data.feature} that sets ${data.name} apart from the rest.</p>
    </section>
  `;
}

/**
 * Module B: Page Assembly.
 * Responsibility: Structuring the data into a deployable format (SEO optimization).
 * @param data - The raw entity data.
 * @returns A fully formed GeneratedPage object.
 */
function assemblePage(data: EntityData): GeneratedPage {
  // 1. Generate Slug (URL-friendly)
  const slug = `/${data.category.toLowerCase()}/${data.name.toLowerCase().replace(/\s+/g, '-')}`;

  // 2. Generate SEO Title (H1 equivalent)
  const title = `${data.name} | Best ${data.category} for ${data.feature}`;

  // 3. Generate Meta Description (Snippet)
  const metaDescription = `Learn about ${data.name} and how it leverages ${data.feature}. The top resource for ${data.category}.`;

  // 4. Generate Body Content
  const bodyContent = generateContent(data);

  // 5. Return structured object (Type Inference handles the rest)
  return {
    slug,
    title,
    metaDescription,
    bodyContent,
    timestamp: new Date(),
  };
}

// --- 3. MAIN EXECUTION (The Engine) ---

/**
 * The entry point of our Auto-Marketing Engine.
 * It simulates fetching a list of keywords and processing them.
 */
function runAutoMarketingEngine(): void {
  console.log("🚀 Starting Auto-Marketing Engine...\n");

  // Simulate a database of keywords/entities to target
  const entities: EntityData[] = [
    { name: "San Francisco", category: "Travel", feature: "Golden Gate Bridge" },
    { name: "TypeScript", category: "Programming", feature: "Type Safety" },
  ];

  // Process each entity (The "Programmatic" part)
  const generatedPages: GeneratedPage[] = entities.map(assemblePage);

  // Output the results (Simulating a CMS API response or file write)
  generatedPages.forEach((page) => {
    console.log(`✅ Generated Page: ${page.slug}`);
    console.log(`   Title: ${page.title}`);
    console.log(`   Desc:  ${page.metaDescription}`);
    console.log(`   --- Content Snippet ---\n${page.bodyContent.trim()}\n`);
  });
}

// Run the engine
runAutoMarketingEngine();
