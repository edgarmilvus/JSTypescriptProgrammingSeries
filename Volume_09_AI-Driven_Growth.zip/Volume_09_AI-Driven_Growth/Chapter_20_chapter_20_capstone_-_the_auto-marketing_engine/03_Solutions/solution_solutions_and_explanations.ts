/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

/**
 * Core Interfaces for the Page Generation Engine
 */

// 1. Define the Core Page Interface
// We make 'metadata' a generic type M to allow for flexible extensions while keeping defaults.
interface Page<M = Record<string, string>> {
  slug: string;
  title: string;
  content: string;
  metadata: M & { generator: string }; // Enforce the generator tag always exists
}

/**
 * Generic Page Generator Function
 * 
 * @param sourceData - The raw data object (type T is inferred automatically).
 * @param template - A function that transforms T into page content and partial metadata.
 * @returns A fully formed Page object with merged metadata.
 */
function generatePage<T extends Record<string, any>>(
  sourceData: T,
  template: (data: T) => {
    slug: string;
    title: string;
    content: string;
    metadata?: Partial<Record<string, string>>;
  }
): Page {
  // Execute the template function with the provided source data
  const result = template(sourceData);

  // Define default metadata
  const defaultMetadata = {
    generator: 'Auto-Marketing Engine v1.0',
    timestamp: new Date().toISOString(),
  };

  // Merge default metadata with template metadata (template overrides defaults if keys collide)
  const finalMetadata = {
    ...defaultMetadata,
    ...result.metadata,
  };

  // Return the complete Page object
  return {
    slug: result.slug,
    title: result.title,
    content: result.content,
    metadata: finalMetadata,
  };
}

/**
 * DEMONSTRATION OF USAGE
 */

// 1. Define a specific data source interface
interface Product {
  id: string;
  name: string;
  price: number;
  features: string[];
}

// 2. Create a specific template for a Product page
const productTemplate = (product: Product) => {
  return {
    slug: `/products/${product.name.toLowerCase().replace(/\s+/g, '-')}`,
    title: `Buy ${product.name} - $${product.price}`,
    content: `
      <h1>${product.name}</h1>
      <p>Price: $${product.price}</p>
      <ul>
        ${product.features.map(f => `<li>${f}</li>`).join('')}
      </ul>
    `,
    metadata: {
      // Type inference ensures these keys are valid strings
      'product-id': product.id,
      'og:type': 'product',
      'robots': 'index, follow',
    },
  };
};

// 3. Usage Example
const inputData = { 
  id: 'p123', 
  name: 'Super Widget', 
  price: 99.99, 
  features: ['Fast', 'Durable', 'Eco-friendly'] 
};

// T is automatically inferred as 'Product' here
const productPage = generatePage(inputData, productTemplate);

// Verify the result (console log for demonstration)
// console.log(productPage);
