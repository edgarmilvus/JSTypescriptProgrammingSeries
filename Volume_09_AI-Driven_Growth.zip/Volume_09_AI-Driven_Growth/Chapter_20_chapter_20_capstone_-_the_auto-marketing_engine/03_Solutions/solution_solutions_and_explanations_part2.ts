/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

/**
 * A class responsible solely for processing a large list of items
 * with controlled concurrency to avoid blocking the event loop.
 */
class BatchProcessor<T, R> {
  private concurrencyLimit: number;

  constructor(concurrencyLimit: number) {
    if (concurrencyLimit <= 0) {
      throw new Error("Concurrency limit must be greater than 0");
    }
    this.concurrencyLimit = concurrencyLimit;
  }

  /**
   * Processes items in batches.
   * 
   * @param items - The array of items to process.
   * @param processItem - An async function that processes a single item.
   * @returns A Promise resolving to an array of successful results.
   */
  async processBatch(items: T[], processItem: (item: T) => Promise<R>): Promise<R[]> {
    // Use an array to track active promises
    const results: R[] = [];
    
    // We maintain a queue of items to process
    const queue = [...items];
    
    // Worker function: pulls an item from the queue and processes it
    const worker = async () => {
      while (queue.length > 0) {
        const item = queue.shift(); // Get next item
        if (!item) return; // Safety check

        try {
          const result = await processItem(item);
          results.push(result);
        } catch (error) {
          // Error Handling: Log error but do not stop the batch
          console.error(`Failed to process item: ${item}`, error);
        }
      }
    };

    // Create a pool of concurrent workers
    const workers = Array(Math.min(this.concurrencyLimit, items.length))
      .fill(null)
      .map(() => worker());

    // Wait for all workers to finish
    await Promise.all(workers);

    return results;
  }
}

/**
 * Example Usage
 */
// const processor = new BatchProcessor<string, Page>(10);
// const pages = await processor.processBatch(keywords, generatePageFromKeyword);
