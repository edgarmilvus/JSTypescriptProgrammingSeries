/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

import React from 'react';

// 1. Define Interfaces
// We define PageWithMetrics to include the specific data required for this view.
interface PageWithMetrics {
  id: string; // Unique identifier for the page
  slug: string;
  title: string;
  clicks: number;
  impressions: number;
  ctr: number; // Click-Through Rate as a percentage (e.g., 1.5 for 1.5%)
}

interface PagePerformanceTableProps {
  pages: PageWithMetrics[];
  onPausePage: (pageId: string) => void;
  onViewDetails: (pageId: string) => void;
}

// 2. Define Styles (Inline for simplicity in this exercise)
const styles = {
  table: { width: '100%', borderCollapse: 'collapse', fontFamily: 'sans-serif' },
  th: { textAlign: 'left', padding: '12px', borderBottom: '2px solid #ddd' },
  td: { padding: '10px', borderBottom: '1px solid #eee' },
  rowLowCtr: { backgroundColor: '#ffe6e6' }, // Light red for underperforming
  rowNormal: { backgroundColor: '#ffffff' },
  button: { margin: '0 4px', padding: '4px 8px', cursor: 'pointer' },
};

// 3. Component Implementation
const PagePerformanceTable: React.FC<PagePerformanceTableProps> = ({
  pages,
  onPausePage,
  onViewDetails,
}) => {
  // Threshold for flagging underperforming content
  const CTR_THRESHOLD = 1.5;

  return (
    <table style={styles.table}>
      <thead>
        <tr>
          <th style={styles.th}>Title</th>
          <th style={styles.th}>Slug</th>
          <th style={styles.th}>Impressions</th>
          <th style={styles.th}>Clicks</th>
          <th style={styles.th}>CTR (%)</th>
          <th style={styles.th}>Actions</th>
        </tr>
      </thead>
      <tbody>
        {pages.map((page) => {
          // Determine row style based on CTR
          const rowStyle =
            page.ctr < CTR_THRESHOLD ? styles.rowLowCtr : styles.rowNormal;

          return (
            <tr key={page.id} style={rowStyle}>
              <td style={styles.td}>{page.title}</td>
              <td style={styles.td}>{page.slug}</td>
              <td style={styles.td}>{page.impressions.toLocaleString()}</td>
              <td style={styles.td}>{page.clicks.toLocaleString()}</td>
              <td style={styles.td}>{page.ctr.toFixed(2)}%</td>
              <td style={styles.td}>
                <button
                  style={styles.button}
                  onClick={() => onPausePage(page.id)}
                >
                  Pause
                </button>
                <button
                  style={styles.button}
                  onClick={() => onViewDetails(page.id)}
                >
                  View Details
                </button>
              </td>
            </tr>
          );
        })}
      </tbody>
    </table>
  );
};

export default PagePerformanceTable;
