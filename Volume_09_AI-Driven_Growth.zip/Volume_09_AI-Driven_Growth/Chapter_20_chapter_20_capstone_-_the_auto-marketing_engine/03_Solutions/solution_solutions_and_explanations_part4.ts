/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

// 1. Define Data Structures
interface PageMetrics {
  pageId: string;
  keyword: string;
  ctr: number; // Percentage (e.g., 0.8 means 0.8%)
  status: 'active' | 'paused';
}

interface OptimizationDecision {
  action: 'kill' | 'promote';
  keyword?: string;
  reason: string;
}

// 2. Simulator Class
class FeedbackLoopSimulator {
  private readonly MAX_ACTIVE_PAGES = 5;
  private readonly KILL_THRESHOLD = 1.0; // CTR %
  private readonly RECLAIM_THRESHOLD = 3.0; // CTR %

  /**
   * Analyzes current pages and potential keywords to generate optimization decisions.
   */
  public analyzeAndOptimize(
    currentPages: PageMetrics[],
    potentialKeywords: string[]
  ): OptimizationDecision[] {
    const decisions: OptimizationDecision[] = [];
    const activePages = currentPages.filter(p => p.status === 'active');
    const pausedPages = currentPages.filter(p => p.status === 'paused');
    const usedKeywords = new Set(currentPages.map(p => p.keyword));

    // Rule 1: Kill Rule (Active pages with low CTR)
    for (const page of activePages) {
      if (page.ctr < this.KILL_THRESHOLD) {
        decisions.push({
          action: 'kill',
          keyword: page.keyword,
          reason: 'CTR too low',
        });
      }
    }

    // Calculate current active capacity after potential kills
    // (Note: In a real system, we'd apply kills first, but for this simulation 
    // we check capacity based on the initial state to keep it simple).
    const currentActiveCount = activePages.length;

    // Rule 2: Promote Rule (Fill capacity)
    if (currentActiveCount < this.MAX_ACTIVE_PAGES) {
      // Find a keyword not currently used by any page (active or paused)
      const availableKeyword = potentialKeywords.find(kw => !usedKeywords.has(kw));
      
      if (availableKeyword) {
        decisions.push({
          action: 'promote',
          keyword: availableKeyword,
          reason: 'Fill capacity',
        });
      }
    }

    // Rule 3: Reclaim Rule (Paused pages with high CTR)
    // Only apply if there is room to promote (or if we consider reclaiming 
    // a paused page doesn't count against the "new keyword" capacity).
    // Assuming "promote" here means moving from paused to active.
    for (const page of pausedPages) {
      if (page.ctr > this.RECLAIM_THRESHOLD) {
        // Check if we have capacity to reactivate
        // (Using a strict interpretation: only reclaim if under max active limit)
        const activeCount = currentPages.filter(p => p.status === 'active' && p.pageId !== page.pageId).length;
        
        if (activeCount < this.MAX_ACTIVE_PAGES) {
           decisions.push({
            action: 'promote',
            keyword: page.keyword,
            reason: 'High-performing paused page',
          });
        }
      }
    }

    return decisions;
  }
}

// 3. Interactive Simulation Runner
function runSimulation() {
  // Initial Data
  const initialPages: PageMetrics[] = [
    { pageId: 'p1', keyword: 'ai marketing tools', ctr: 0.8, status: 'active' }, // Should be killed
    { pageId: 'p2', keyword: 'programmatic seo guide', ctr: 4.2, status: 'active' }, // Keep
    { pageId: 'p3', keyword: 'gpt-4 content', ctr: 0.5, status: 'active' }, // Should be killed
    { pageId: 'p4', keyword: 'automation software', ctr: 3.5, status: 'paused' }, // Should be reclaimed
  ];

  const potentialKeywords: string[] = [
    'content automation', 'autonomous marketing', 'seo feedback loop', 'v8 performance'
  ];

  const simulator = new FeedbackLoopSimulator();
  const decisions = simulator.analyzeAndOptimize(initialPages, potentialKeywords);

  // Output results
  console.log('--- Autonomous Feedback Loop Simulation Results ---');
  console.log(`Total Decisions: ${decisions.length}`);
  
  decisions.forEach((decision, index) => {
    console.log(
      `${index + 1}. Action: ${decision.action.toUpperCase()} | ` +
      `Keyword: ${decision.keyword || 'N/A'} | ` +
      `Reason: ${decision.reason}`
    );
  });
}

// Execute the simulation
// runSimulation();
