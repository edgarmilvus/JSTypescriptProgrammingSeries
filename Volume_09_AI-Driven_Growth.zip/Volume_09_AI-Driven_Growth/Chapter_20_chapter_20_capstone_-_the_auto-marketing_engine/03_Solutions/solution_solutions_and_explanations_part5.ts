/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

digraph AutoMarketingEngine {
    rankdir=LR; // Layout from Left to Right
    node [fontname="Arial", shape=box, style="rounded,filled", color="#2c3e50", fillcolor="#ecf0f1", fontcolor="#2c3e50"];
    edge [fontname="Arial", fontsize=10, color="#34495e"];

    // Main Graph Attributes
    label="Auto-Marketing Engine: System Architecture & Data Flow";
    labelloc=t;
    fontsize=20;

    // --- Subgraph: Data Ingestion & Generation (Left Side) ---
    subgraph cluster_generation {
        label="Content Generation Pipeline";
        style="filled,rounded";
        color="#3498db";
        fillcolor="#ebf5fb";
        fontcolor="#2980b9";

        source [label="Data Source\n(CSV/JSON)", shape=database];
        ingestion [label="Data Ingestion Module", fillcolor="#d6eaf8"];
        generator [label="Programmatic SEO Generator\n(Generic Function)", fillcolor="#d6eaf8"];
        deployer [label="Headless CMS Deployer", fillcolor="#d6eaf8"];
    }

    // --- Subgraph: Analytics & Optimization (Right Side) ---
    subgraph cluster_optimization {
        label="Autonomous Optimization Loop";
        style="filled,rounded";
        color="#e74c3c";
        fillcolor="#fdedec";
        fontcolor="#c0392b";

        analytics [label="Analytics Collector", fillcolor="#fadbd8"];
        feedback [label="Feedback Loop Analyzer\n(Class Logic)", fillcolor="#fadbd8"];
    }

    // --- External/Output Nodes ---
    live_site [label="Live Website\n(Public Pages)", shape=house, fillcolor="#d5f5e3"];
    decisions_log [label="Optimization Log", shape=note, fillcolor="#fcf3cf"];

    // --- Data Flow Connections ---

    // Linear Flow (Generation)
    source -> ingestion [label="Raw Data"];
    ingestion -> generator [label="Structured Data Objects"];
    generator -> deployer [label="Page Objects (JSON)"];
    deployer -> live_site [label="HTTP API Requests"];

    // Feedback Loop Flow
    live_site -> analytics [label="Performance Metrics\n(CTR, Impressions)"];
    analytics -> feedback [label="Page Metrics Data"];

    // The Autonomous Control Signal
    feedback -> generator [label="Optimization Decisions\n(Kill/Promote Keywords)", color="#e74c3c", fontcolor="#e74c3c", penwidth=2.0];
    feedback -> decisions_log [label="Log Decisions", style=dashed];

    // Visual emphasis on the loop
    { rank=same; generator; feedback; }
}
