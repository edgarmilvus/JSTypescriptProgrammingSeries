/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * @fileoverview Client-side AI Inference using WebAssembly (WASM) Simulation.
 * This TypeScript file demonstrates the architecture for running a machine learning model
 * directly in the browser to minimize inference latency.
 * 
 * Context: SaaS Dashboard for Real-time Sentiment Analysis.
 * Technology Stack: TypeScript, WebAssembly (simulated), DOM APIs.
 */

// ==========================================
// 1. Type Definitions & Interfaces
// ==========================================

/**
 * Represents the shape of the WebAssembly module we expect to load.
 * In a real scenario, this would be defined by the WASM exports.
 */
interface IWasmModule {
    /**
     * Allocates memory inside the WASM heap for input data.
     * @param size - Number of bytes to allocate.
     * @returns Pointer (memory address) to the allocated block.
     */
    malloc(size: number): number;

    /**
     * Frees memory allocated on the WASM heap.
     * @param pointer - The pointer returned by malloc.
     */
    free(pointer: number): void;

    /**
     * The core inference function.
     * @param inputPointer - Pointer to the input vector (tokenized text).
     * @param inputLength - Length of the input vector.
     * @returns A pointer to the output probability array.
     */
    infer(inputPointer: number, inputLength: number): number;
}

/**
 * Represents the result of the sentiment analysis.
 */
interface SentimentResult {
    label: 'Positive' | 'Negative' | 'Neutral';
    score: number; // Confidence score (0.0 to 1.0)
}

// ==========================================
// 2. The Inference Engine (Simulated WASM Wrapper)
// ==========================================

/**
 * A wrapper class to manage the WebAssembly module lifecycle.
 * This abstracts the low-level memory management required for WASM interactions.
 * 
 * Under the Hood:
 * - WebAssembly memory is linear and separate from JavaScript's garbage-collected heap.
 * - To pass data (like strings) to WASM, we must write it into the WASM memory buffer.
 */
class InferenceEngine {
    private wasmModule: IWasmModule;
    private memory: WebAssembly.Memory;

    constructor(module: IWasmModule) {
        this.wasmModule = module;
        // In a real WASM instance, memory is exported by the module.
        // We simulate this here for the example to be runnable.
        this.memory = new WebAssembly.Memory({ initial: 256, maximum: 512 });
    }

    /**
     * Preprocesses the input text into a numerical vector (tokenization simulation).
     * In a real app, this would match the tokenizer used to train the model.
     * @param text - User input string.
     * @returns Float32Array representing the input tensor.
     */
    private tokenize(text: string): Float32Array {
        // Simple simulation: map characters to ASCII codes normalized between 0 and 1.
        // Real models use complex tokenizers (e.g., BPE, WordPiece).
        const tokens = new Float32Array(10); // Fixed input size for simplicity
        for (let i = 0; i < Math.min(text.length, 10); i++) {
            tokens[i] = text.charCodeAt(i) / 255.0;
        }
        return tokens;
    }

    /**
     * Runs the inference pipeline.
     * @param inputText - The raw text from the user.
     * @returns The calculated sentiment.
     */
    public async predict(inputText: string): Promise<SentimentResult> {
        // 1. Preprocessing (Tokenization)
        const inputVector = this.tokenize(inputText);

        // 2. Memory Allocation (Pointer Arithmetic)
        // We need to write the Float32Array into the WASM linear memory.
        // We calculate the byte offset and length.
        const inputPointer = this.wasmModule.malloc(inputVector.byteLength);
        
        // Create a view into the WASM memory buffer
        const wasmMemoryBuffer = new Uint8Array(this.memory.buffer);
        const inputBytes = new Uint8Array(inputVector.buffer);
        
        // Copy input data into WASM memory
        wasmMemoryBuffer.set(inputBytes, inputPointer);

        // 3. Execution (The Inference Call)
        // This is the heavy lifting, typically synchronous in WASM to avoid overhead.
        const outputPointer = this.wasmModule.infer(inputPointer, inputVector.length);

        // 4. Post-processing (Reading Output)
        // Read the result back from WASM memory.
        // The output is assumed to be a probability array [neg, neu, pos]
        const outputView = new Float32Array(this.memory.buffer, outputPointer, 3);
        const [negScore, neuScore, posScore] = outputView;

        // 5. Cleanup
        // Crucial: Free allocated memory to prevent memory leaks in the WASM heap.
        this.wasmModule.free(inputPointer);
        this.wasmModule.free(outputPointer);

        // 6. Determine Label
        const maxScore = Math.max(posScore, neuScore, negScore);
        let label: 'Positive' | 'Negative' | 'Neutral' = 'Neutral';
        if (maxScore === posScore) label = 'Positive';
        else if (maxScore === negScore) label = 'Negative';

        return {
            label,
            score: maxScore
        };
    }
}

// ==========================================
// 3. DOM Interaction & Main Logic
// ==========================================

/**
 * Main application entry point.
 * Simulates loading a WASM module and binding UI events.
 */
async function initializeApp() {
    // SIMULATION: Mocking the WebAssembly compilation/loading process.
    // In a real scenario: const wasmInstance = await WebAssembly.instantiateStreaming(...)
    const mockWasmModule: IWasmModule = {
        malloc: (size: number) => {
            // Simulate allocating memory and returning a pointer (index)
            // In reality, this interacts with the WASM heap allocator.
            return 1024; 
        },
        free: (pointer: number) => {
            // Simulate freeing memory.
            console.log(`Freed memory at pointer: ${pointer}`);
        },
        infer: (inputPointer: number, inputLength: number): number => {
            // SIMULATION: The Neural Network Forward Pass.
            // Since we can't run a real model here, we generate dummy probabilities
            // based on simple heuristics (e.g., length of text) to demonstrate the flow.
            
            // Allocate a fake output buffer in the memory
            const outputPointer = 2048;
            const outputBuffer = new Float32Array(3); // [Neg, Neu, Pos]
            
            // Heuristic logic for demonstration:
            if (inputLength > 8) {
                outputBuffer[0] = 0.1; // Negative
                outputBuffer[1] = 0.2; // Neutral
                outputBuffer[2] = 0.7; // Positive (Longer text implies complexity/positivity in this fake model)
            } else {
                outputBuffer[0] = 0.6;
                outputBuffer[1] = 0.3;
                outputBuffer[2] = 0.1;
            }

            // Write to the simulated WASM memory buffer
            const memoryView = new Float32Array(mockWasmModule.malloc(12)); // Re-use malloc for the output buffer
            memoryView.set(outputBuffer);
            
            return outputPointer;
        }
    };

    // Initialize the Engine
    const engine = new InferenceEngine(mockWasmModule);

    // DOM Elements
    const inputElement = document.getElementById('user-input') as HTMLTextAreaElement;
    const buttonElement = document.getElementById('analyze-btn') as HTMLButtonElement;
    const resultElement = document.getElementById('result-display') as HTMLDivElement;

    if (!inputElement || !buttonElement || !resultElement) {
        console.error("UI Elements not found.");
        return;
    }

    // Event Listener
    buttonElement.addEventListener('click', async () => {
        const text = inputElement.value.trim();
        if (!text) return;

        // UI Feedback: Loading State
        buttonElement.disabled = true;
        buttonElement.textContent = "Analyzing...";
        resultElement.textContent = "Processing locally via WASM...";

        try {
            // Execute Inference
            const startTime = performance.now();
            const result = await engine.predict(text);
            const endTime = performance.now();
            const latency = (endTime - startTime).toFixed(2);

            // Update UI
            resultElement.innerHTML = `
                <strong>Result:</strong> ${result.label} <br>
                <strong>Confidence:</strong> ${(result.score * 100).toFixed(1)}% <br>
                <em>Inference Latency: ${latency}ms (Client-side)</em>
            `;
        } catch (error) {
            resultElement.textContent = "Error during inference.";
            console.error(error);
        } finally {
            buttonElement.disabled = false;
            buttonElement.textContent = "Analyze Sentiment";
        }
    });
}

// Start the application when the DOM is ready
if (typeof window !== 'undefined') {
    document.addEventListener('DOMContentLoaded', initializeApp);
}
