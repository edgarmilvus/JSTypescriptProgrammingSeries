/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

/**
 * FILE: pages/api/inference/config.ts
 * 
 * DESCRIPTION:
 * This API route simulates a backend service that manages AI model configurations.
 * In a real Dockerized environment, this service would be isolated from the host machine,
 * ensuring that the Node.js version and system dependencies are identical to production.
 * 
 * We use TypeScript to enforce strict typing, preventing runtime errors that often
 * occur in JavaScript when environment variables or data structures mismatch.
 */

import type { NextApiRequest, NextApiResponse } from 'next';

/**
 * Type Definitions
 * We define strict interfaces for our data contracts. This is critical for
 * maintaining consistency across microservices (e.g., the Frontend container
 * talking to the Backend container).
 */

export interface ModelConfig {
  id: string;
  name: string;
  version: string;
  // Simulating a WebAssembly (WASM) binary path or a TensorFlow.js model URL
  sourceUrl: string; 
  // Specific parameters for the inference engine
  parameters: {
    temperature: number;
    maxTokens: number;
  };
}

export interface ApiResponse<T> {
  success: boolean;
  data?: T;
  error?: string;
}

/**
 * Mock Data Store
 * In a real scenario, this would be fetched from a database or a volume mounted
 * into the Docker container.
 */
const MOCK_MODELS: ModelConfig[] = [
  {
    id: 'sentiment-v1',
    name: 'Sentiment Analysis Engine',
    version: '1.2.0',
    sourceUrl: '/models/sentiment_v1.wasm', // Simulating a WASM binary
    parameters: { temperature: 0.0, maxTokens: 512 }
  },
  {
    id: 'summary-pro-v2',
    name: 'Text Summarizer',
    version: '2.0.1',
    sourceUrl: '/models/summary_v2.json', // Simulating a TF.js model
    parameters: { temperature: 0.7, maxTokens: 1024 }
  }
];

/**
 * Logic Block 1: The Model Manager
 * 
 * WHY:
 * Encapsulates the logic for retrieving and validating model configurations.
 * By isolating this logic, we can easily test it or swap the data source
 * without changing the API route handler.
 * 
 * HOW:
 * Uses a class-based approach to simulate a stateful service that might
 * hold database connections or cached data.
 * 
 * UNDER THE HOOD:
 * The `getModelConfig` method simulates an async database call. In a Dockerized
 * setup, the latency and behavior of this call would be identical to production
 * because the container's network stack and I/O performance are consistent.
 */
class ModelManager {
  /**
   * Retrieves a specific model configuration by ID.
   * @param id - The unique identifier of the model.
   * @returns Promise<ModelConfig | null>
   */
  async getModelConfig(id: string): Promise<ModelConfig | null> {
    // Simulate network latency (common in distributed systems)
    await new Promise(resolve => setTimeout(resolve, 50)); 
    
    return MOCK_MODELS.find(m => m.id === id) || null;
  }

  /**
   * Lists all available models.
   * @returns Promise<ModelConfig[]>
   */
  async listModels(): Promise<ModelConfig[]> {
    await new Promise(resolve => setTimeout(resolve, 20));
    return MOCK_MODELS;
  }
}

// Singleton instance to mimic a global service resource within the container
const modelManager = new ModelManager();

/**
 * Logic Block 2: The API Route Handler
 * 
 * WHY:
 * This is the entry point for the frontend application. It must handle
 * different HTTP methods (GET) and return standardized JSON responses.
 * 
 * HOW:
 * We use Next.js API routes. The handler checks the request method and
 * delegates to the ModelManager.
 * 
 * UNDER THE HOOD:
 * When this runs in Docker, the Node.js runtime (V8 engine) executes this code.
 * Docker ensures that the environment variables (like `NODE_ENV`) and the
 * binary version of Node.js are exactly what we defined in our Dockerfile.
 * This eliminates the "works on my machine" issue where a developer might have
 * Node 16 while production runs Node 20.
 */
export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse<ApiResponse<ModelConfig[] | ModelConfig>>
) {
  // Logic Block 3: Method Routing
  // We strictly enforce RESTful principles.
  if (req.method !== 'GET') {
    res.setHeader('Allow', ['GET']);
    return res.status(405).json({ 
      success: false, 
      error: `Method ${req.method} Not Allowed` 
    });
  }

  // Logic Block 4: Query Parameter Handling
  // Extracting the 'id' parameter to fetch a specific model.
  const { id } = req.query;

  try {
    if (typeof id === 'string') {
      // Fetch single model
      const model = await modelManager.getModelConfig(id);
      
      if (!model) {
        return res.status(404).json({ 
          success: false, 
          error: 'Model not found' 
        });
      }

      // Success response for single model
      return res.status(200).json({ success: true, data: model });
    } else {
      // Fetch all models (if no ID provided)
      const models = await modelManager.listModels();
      
      // Success response for list
      return res.status(200).json({ success: true, data: models });
    }
  } catch (error) {
    // Logic Block 5: Error Handling
    // Captures unexpected runtime errors (e.g., if the mock data was corrupted).
    // In a Docker container, these logs would be piped to stdout/stderr and
    // captured by the Docker logging driver.
    console.error('Inference Config Error:', error);
    return res.status(500).json({ 
      success: false, 
      error: 'Internal Server Error' 
    });
  }
}
