/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script_part2.ts
// Description: Advanced Application Script
// ==========================================

digraph DockerArchitecture {
    rankdir=TB;
    node [shape=box, style=filled, fillcolor=lightblue];

    subgraph cluster_host {
        label = "Host Machine (Dev Laptop)";
        style = dashed;
        color = grey;

        HostOS [label="Linux/Mac/Windows", fillcolor=lightgrey];
        DockerEngine [label="Docker Engine", fillcolor=orange];
        
        subgraph cluster_container {
            label = "Container: 'ai-nextjs-app'";
            style = solid;
            color = black;
            
            ContainerNode [label="Node.js Runtime (V8)\n(Identical to Prod)", fillcolor=white];
            AppCode [label="Next.js API Route\n(config.ts)", fillcolor=white];
            Dependencies [label="node_modules &\nSystem Libs", fillcolor=white];
            
            AppCode -> Dependencies;
        }
    }

    HostOS -> DockerEngine [label="Runs Container"];
    DockerEngine -> ContainerNode;

    // Visualizing the consistency
    subgraph cluster_prod {
        label = "Production Environment";
        style = dashed;
        color = grey;
        ProdServer [label="Cloud Server", fillcolor=lightgrey];
        ProdContainer [label="Container: 'ai-nextjs-app'\n(Same Image)", fillcolor=white];
    }

    DockerEngine -> ProdServer [label="Push Image", style=dotted];
}
