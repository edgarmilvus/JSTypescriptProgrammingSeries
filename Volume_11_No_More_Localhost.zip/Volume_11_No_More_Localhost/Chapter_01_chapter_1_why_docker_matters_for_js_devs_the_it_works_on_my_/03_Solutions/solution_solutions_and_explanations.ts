/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

# Use the official Node.js 20 Alpine image as the base
# Alpine is preferred for its small size, reducing attack surface and download times.
FROM node:20-alpine

# Set the working directory inside the container
WORKDIR /app

# Step 1: Copy package definitions first to leverage Docker layer caching.
# This layer is only rebuilt if package.json changes, not on every source code change.
COPY package*.json ./
COPY tsconfig.json ./

# Install dependencies (including dev dependencies needed for building)
# We use npm ci for reproducible builds based on the lockfile.
RUN npm ci

# Step 2: Copy the source code
COPY src/ ./src

# Step 3: Build the TypeScript application
# This compiles src/*.ts into the dist/ directory
RUN npx tsc

# Expose port 3000 to the outside world
EXPOSE 3000

# Set the runtime command to execute the compiled JavaScript
# We use 'node' to run the transpiled code.
CMD ["node", "dist/index.js"]
