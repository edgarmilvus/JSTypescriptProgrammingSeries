/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

# STAGE 1: Builder
# This stage contains build tools (typescript, dev dependencies)
FROM node:20-alpine AS builder

WORKDIR /app

COPY package*.json ./
COPY tsconfig.json ./

# Install ALL dependencies (dev and prod)
RUN npm ci

COPY src/ ./src

# Compile TypeScript
RUN npx tsc

# STAGE 2: Runner
# This stage is minimal and contains only the runtime
FROM node:20-alpine AS runner

WORKDIR /app

# Create a non-root user for security
RUN addgroup -g 1001 -S nodejs
RUN adduser -S nodeuser -u 1001

# Copy only the compiled dist folder from the builder stage
COPY --from=builder /app/dist ./dist

# Copy only production dependencies
# We need to copy package.json again to run npm ci --only=production
COPY --from=builder /app/package.json ./
RUN npm ci --only=production

# Change ownership of the app directory to the non-root user
RUN chown -R nodeuser:nodejs /app

# Switch to the non-root user
USER nodeuser

# Set environment variable
ENV NODE_ENV=production

# Expose port
EXPOSE 3000

# Define the command to run the app
CMD ["node", "dist/index.js"]
