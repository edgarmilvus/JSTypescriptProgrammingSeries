/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * PREREQUISITES:
 * This code assumes the following packages are installed:
 * npm install zod
 */

import { z } from 'zod';

// ==========================================
// 1. DEFINE THE TARGET DATA STRUCTURE
// ==========================================

/**
 * We define a Zod schema that represents the "JSON Schema" we want the LLM to output.
 * In a real scenario, you might send this schema definition to the LLM's API
 * (e.g., via OpenAI's `response_format: { type: "json_object", schema: ... }`).
 *
 * Here, we are modeling a simple User Profile entity for a SaaS dashboard.
 */
const UserProfileSchema = z.object({
  username: z.string().min(3, "Username must be at least 3 characters"),
  role: z.enum(["admin", "user", "guest"]),
  lastLogin: z.string().datetime(), // Expects ISO 8601 format
  isActive: z.boolean(),
});

// Infer the TypeScript type for later use
type UserProfile = z.infer<typeof UserProfileSchema>;

// ==========================================
// 2. SIMULATE THE LLM INTERACTION
// ==========================================

/**
 * In a real production environment, this function would make an API call to
 * OpenAI, Anthropic, or a local model.
 *
 * CRITICAL: We are simulating the LLM's response here. Notice that the raw
 * string contains the JSON data, but it is wrapped in a standard text response.
 * LLMs rarely return *just* the JSON; they often include conversational fluff.
 */
async function callLLMWithJsonInstruction(): Promise<string> {
  // Simulating a raw response from an AI model
  // Note: This mimics the "hallucination" or "fluff" that LLMs generate.
  return Promise.resolve(`
    Here is the user profile you requested:
    {
      "username": "dev_ops_sue",
      "role": "admin",
      "lastLogin": "2023-10-27T14:30:00Z",
      "isActive": true
    }
    Let me know if you need anything else!
  `);
}

// ==========================================
// 3. PARSE AND VALIDATE
// ==========================================

/**
 * The main logic flow.
 * 1. Fetch raw string from LLM.
 * 2. Extract JSON (often requires regex or string manipulation).
 * 3. Validate against the Zod schema.
 */
async function processSaaSRequest() {
  console.log("--- Starting SaaS User Profile Fetch ---");

  // Step A: Get the raw string
  const rawResponse = await callLLMWithJsonInstruction();
  
  // Step B: Extract the JSON object from the string
  // We use a regex to find the object block.
  // NOTE: This is a common parsing strategy for unstructured LLM text.
  const jsonMatch = rawResponse.match(/\{[\s\S]*\}/);
  
  if (!jsonMatch) {
    console.error("Error: No JSON object found in LLM response.");
    return;
  }

  const jsonString = jsonMatch[0];

  try {
    // Step C: Parse the string into a JavaScript Object
    const parsedData = JSON.parse(jsonString);

    // Step D: Validate using the Zod Schema (The JSON Schema Output check)
    // If the LLM hallucinated a field or used the wrong type, this will throw.
    const validatedData = UserProfileSchema.parse(parsedData);

    // Success! We now have a strongly typed object.
    console.log("✅ Validation Successful:");
    console.log(validatedData);
    
    // Example of type safety: TypeScript knows 'role' is strictly 'admin' | 'user' | 'guest'
    if (validatedData.role === 'admin') {
      console.log("Access Level: Full Privileges Granted.");
    }

  } catch (error) {
    // If the LLM returned malformed JSON or wrong types
    if (error instanceof z.ZodError) {
      console.error("❌ Validation Failed:", error.errors);
    } else {
      console.error("❌ Parsing Failed:", error);
    }
  }
}

// Execute the example
processSaaSRequest();
