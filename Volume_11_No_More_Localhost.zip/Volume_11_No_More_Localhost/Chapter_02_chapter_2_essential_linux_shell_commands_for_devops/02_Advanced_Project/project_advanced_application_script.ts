/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

/**
 * @fileoverview Advanced Application Script: Automating AI Model Deployment
 * This script demonstrates Linux shell command usage for DevOps tasks in a SaaS context.
 * It cleans up Docker containers running AI models, processes logs for errors, and manages state immutably.
 * Intended for a Next.js API route or Node.js service on a Linux server.
 * 
 * Key Concepts:
 * - Linux Commands: `docker ps`, `docker logs | grep`, `kill`, `rm`.
 * - Utility Types: Partial<Config> for flexible overrides.
 * - Immutable State: New objects for state updates to avoid side effects.
 * - SharedArrayBuffer: Conceptual for parallel log processing (uncomment for full Web Worker impl).
 */

import { exec, ExecException } from 'child_process';
import { promisify } from 'util';
import { promises as fs } from 'fs';
import { join } from 'path';

// Promisify exec for async/await usage
const execAsync = promisify(exec);

// --- 1. Configuration and Type Definitions ---

/**
 * Deployment configuration for an AI model container.
 * @typedef {Object} DeploymentConfig
 * @property {string} containerName - Name of the Docker container (e.g., 'ai-inference-service').
 * @property {string} logDir - Directory for logs (e.g., '/var/log/ai-apps').
 * @property {number} maxMemoryMB - Max memory threshold for AI processes (e.g., 4096 for GPU models).
 * @property {string[]} errorPatterns - Patterns to grep in logs (e.g., ['out of memory', 'CUDA error']).
 */
interface DeploymentConfig {
  containerName: string;
  logDir: string;
  maxMemoryMB: number;
  errorPatterns: string[];
}

// Use Partial<T> for optional overrides in SaaS multi-tenant scenarios
type PartialDeploymentConfig = Partial<DeploymentConfig>;

/**
 * Immutable state after automation.
 * @typedef {Object} DeploymentState
 * @property {string} status - 'success', 'error', or 'cleaned'.
 * @property {string[]} cleanedContainers - List of terminated container IDs.
 * @property {string[]} errorsFound - Parsed error messages from logs.
 * @property {number} timestamp - Unix timestamp for audit logs.
 */
interface DeploymentState {
  status: 'success' | 'error' | 'cleaned';
  cleanedContainers: string[];
  errorsFound: string[];
  timestamp: number;
}

// Readonly ensures state is never mutated post-creation
type ReadonlyDeploymentState = Readonly<DeploymentState>;

// --- 2. Linux Command Execution Wrapper ---

/**
 * Executes a Linux shell command and returns stdout/stderr.
 * Wraps child_process.exec for DevOps automation.
 * 
 * @param command - The shell command to run (e.g., 'docker ps -a').
 * @returns Promise<{ stdout: string; stderr: string }>
 * @throws {Error} If command fails (non-zero exit code).
 * 
 * Under the Hood:
 * - Spawns a shell process on the host Linux machine.
 * - For AI apps, commands like 'docker logs' can be heavy; we handle them asynchronously.
 * - Text processing (grep/awk) is done in-shell for efficiency, avoiding Node.js parsing overhead.
 */
async function executeShellCommand(command: string): Promise<{ stdout: string; stderr: string }> {
  try {
    console.log(`[DevOps] Executing: ${command}`);
    const { stdout, stderr } = await execAsync(command, { maxBuffer: 10 * 1024 * 1024 }); // 10MB buffer for large logs
    if (stderr) console.warn(`[DevOps] Stderr: ${stderr}`);
    return { stdout, stderr };
  } catch (error: any) {
    const execError = error as ExecException;
    console.error(`[DevOps] Command failed: ${command}`, execError.message);
    throw new Error(`Shell command error: ${execError.message}`);
  }
}

/**
 * Lists all Docker containers, filtering for AI-related ones.
 * Uses 'docker ps -a' and 'grep' for text processing.
 * 
 * @param config - Partial config for filtering.
 * @returns Array of container IDs.
 * 
 * Example Command: docker ps -a --filter "name=ai" --format "{{.ID}} {{.Names}}"
 * Parses output with awk/sed in-shell.
 */
async function listAIContainers(config: PartialDeploymentConfig): Promise<string[]> {
  const containerName = config.containerName || 'ai';
  const command = `docker ps -a --filter "name=${containerName}" --format "{{.ID}}"`;
  const { stdout } = await executeShellCommand(command);
  return stdout.split('\n').filter(id => id.trim().length > 0);
}

/**
 * Checks container health by grepping logs for error patterns.
 * Uses 'docker logs <id> | grep -i' for efficient text processing.
 * 
 * @param containerId - ID of the container.
 * @param patterns - Error patterns to search.
 * @returns Array of matched error lines.
 * 
 * Under the Hood:
 * - Pipes output from 'docker logs' to 'grep' to avoid loading full logs into Node.js memory.
 * - For AI apps, logs may contain stack traces from PyTorch/TensorFlow; this isolates issues quickly.
 */
async function checkContainerHealth(containerId: string, patterns: string[]): Promise<string[]> {
  const patternStr = patterns.map(p => `-e "${p}"`).join(' ');
  const command = `docker logs ${containerId} 2>&1 | grep -i ${patternStr} | head -20`; // Limit to 20 lines for brevity
  const { stdout } = await executeShellCommand(command);
  return stdout.split('\n').filter(line => line.trim().length > 0);
}

/**
 * Kills a process (container) if unhealthy.
 * Uses 'docker kill' (which sends SIGKILL) or 'kill <pid>' for host processes.
 * 
 * @param containerId - ID to terminate.
 * @returns void
 * 
 * Process Management:
 * - 'docker kill' stops the container abruptly; for graceful shutdown, use 'docker stop' (SIGTERM).
 * - In production, monitor with 'ps aux | grep <container>' to find zombie processes.
 */
async function killContainer(containerId: string): Promise<void> {
  const command = `docker kill ${containerId}`;
  await executeShellCommand(command);
  console.log(`[DevOps] Killed container: ${containerId}`);
}

/**
 * Cleans up log files in the directory using 'rm -f'.
 * Uses 'ls' to list files first, then removes old ones (>1 day).
 * 
 * @param logDir - Directory path.
 * @returns Number of files removed.
 * 
 * File Manipulation:
 * - 'find . -name "*.log" -mtime +1 -delete' for age-based cleanup.
 * - Why? AI logs grow fast; this prevents disk exhaustion on servers.
 */
async function cleanupLogs(logDir: string): Promise<number> {
  const listCommand = `ls -la ${logDir}/*.log 2>/dev/null | wc -l`;
  const { stdout: fileCount } = await executeShellCommand(listCommand);
  if (parseInt(fileCount) === 0) return 0;

  const rmCommand = `find ${logDir} -name "*.log" -mtime +1 -delete`;
  await executeShellCommand(rmCommand);
  console.log(`[DevOps] Cleaned logs in: ${logDir}`);
  return parseInt(fileCount);
}

// --- 3. Immutable State Management ---

/**
 * Creates a new immutable state object.
 * Uses spread syntax to ensure no mutation of original.
 * 
 * @param previous - Optional previous state.
 * @param updates - Partial updates.
 * @returns New ReadonlyDeploymentState.
 * 
 * Why Immutable?
 * - In SaaS, state might be shared across API calls or workers.
 * - Mutation leads to bugs in concurrent environments (e.g., two requests cleaning the same container).
 * - Under the hood: JavaScript objects are references; spreading creates a shallow copy.
 */
function updateState(
  previous: ReadonlyDeploymentState | null,
  updates: Partial<DeploymentState>
): ReadonlyDeploymentState {
  const baseState: DeploymentState = previous || {
    status: 'pending',
    cleanedContainers: [],
    errorsFound: [],
    timestamp: Date.now(),
  };

  // Create new object without mutating baseState
  const newState: DeploymentState = {
    ...baseState,
    ...updates,
    cleanedContainers: [...(baseState.cleanedContainers || []), ...(updates.cleanedContainers || [])],
    errorsFound: [...(baseState.errorsFound || []), ...(updates.errorsFound || [])],
    timestamp: updates.timestamp || Date.now(),
  };

  // Enforce readonly for return
  return Object.freeze(newState) as ReadonlyDeploymentState;
}

// --- 4. Parallel Processing with SharedArrayBuffer (Conceptual) ---

/**
 * Conceptual: Parallel log processing using SharedArrayBuffer.
 * In a full impl, this would be in a Web Worker for Node.js or browser.
 * 
 * @param logData - Large array of log lines (simulated as string[]).
 * @returns SharedArrayBuffer for zero-copy sharing.
 * 
 * Why SAB?
 * - AI logs can be gigabytes; copying between threads is expensive.
 * - SAB allows multiple workers to read/write shared memory atomically.
 * - Under the Hood: Requires 'SharedArrayBuffer' enabled in Node.js (via --experimental-sharedarraybuffer flag).
 *   For Next.js, this runs in API routes or workers, not browser (due to COOP/COEP headers).
 * 
 * Example Usage (Uncomment in production):
 * const sharedBuffer = new SharedArrayBuffer(logData.length * 4); // 4 bytes per char
 * const sharedView = new Uint8Array(sharedBuffer);
 * // Copy data: sharedView.set(new TextEncoder().encode(logData.join('\n')));
 * // Post to worker: worker.postMessage({ buffer: sharedBuffer });
 */
function conceptualParallelLogProcessing(logData: string[]): SharedArrayBuffer {
  // Simulate: Allocate shared memory for log string
  const encoder = new TextEncoder();
  const encoded = encoder.encode(logData.join('\n'));
  const buffer = new SharedArrayBuffer(encoded.length);
  const view = new Uint8Array(buffer);
  view.set(encoded);
  console.log(`[DevOps] Conceptual SAB allocated: ${buffer.byteLength} bytes for parallel processing.`);
  return buffer;
}

// --- 5. Main Automation Function ---

/**
 * Orchestrates the DevOps automation: List → Check → Kill → Clean.
 * Returns immutable state for SaaS dashboard.
 * 
 * @param config - Deployment configuration.
 * @returns Promise<ReadonlyDeploymentState>
 * 
 * Logic Breakdown:
 * 1. List AI containers using shell commands.
 * 2. For each, check health via log grep.
 * 3. If errors exceed threshold (>0), kill container.
 * 4. Clean up old logs.
 * 5. Update state immutably.
 * 6. Simulate SAB for any parallel tasks (e.g., multi-container scanning).
 */
async function automateAIDeployment(config: PartialDeploymentConfig): Promise<ReadonlyDeploymentState> {
  const fullConfig: DeploymentConfig = {
    containerName: 'ai-inference',
    logDir: '/var/log/ai-apps',
    maxMemoryMB: 4096,
    errorPatterns: ['out of memory', 'CUDA error', 'segmentation fault'],
    ...config, // Partial<T> allows safe overrides
  };

  let state = updateState(null, { status: 'processing' });

  try {
    // Step 1: List containers
    const containerIds = await listAIContainers(fullConfig);
    console.log(`[DevOps] Found ${containerIds.length} AI containers.`);

    const cleaned: string[] = [];
    const errors: string[] = [];

    // Step 2 & 3: Check and kill unhealthy (sequential for simplicity; parallelize with SAB/Workers in prod)
    for (const id of containerIds) {
      const containerErrors = await checkContainerHealth(id, fullConfig.errorPatterns);
      if (containerErrors.length > 0) {
        await killContainer(id);
        cleaned.push(id);
        errors.push(...containerErrors);
        console.log(`[DevOps] Unhealthy container ${id}: ${containerErrors.length} errors.`);
      }
    }

    // Step 4: Cleanup logs
    const filesRemoved = await cleanupLogs(fullConfig.logDir);

    // Step 5: Update state immutably
    state = updateState(state, {
      status: cleaned.length > 0 ? 'cleaned' : 'success',
      cleanedContainers: cleaned,
      errorsFound: errors,
    });

    // Step 6: Conceptual SAB for parallelism (e.g., if scanning multiple dirs)
    if (errors.length > 0) {
      const _sab = conceptualParallelLogProcessing(errors); // Unused here, but demonstrates usage
    }

    console.log(`[DevOps] Automation complete. State:`, state);
    return state;
  } catch (error) {
    console.error('[DevOps] Automation failed:', error);
    return updateState(state, { status: 'error', errorsFound: [String(error)] });
  }
}

// --- 6. Next.js Integration Example ---

/**
 * Sample Next.js API Route (pages/api/deploy.ts).
 * Exposes automation as a SaaS endpoint.
 * 
 * Usage: POST /api/deploy with JSON body for config overrides.
 * 
 * Why Next.js?
 * - SaaS apps often use Next.js for full-stack capabilities.
 * - API routes run on Node.js server, ideal for shell commands (not browser-safe).
 */
import { NextApiRequest, NextApiResponse } from 'next';

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  try {
    const configOverride = req.body as PartialDeploymentConfig;
    const state = await automateAIDeployment(configOverride);
    res.status(200).json(state);
  } catch (error) {
    res.status(500).json({ error: (error as Error).message });
  }
}

// Export for testing or standalone use
export { automateAIDeployment };
