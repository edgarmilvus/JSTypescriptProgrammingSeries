/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// parseLogs.ts
import * as crypto from 'crypto';

// Define the interface for the Log Entry
interface LogEntry {
  id: string; // Vector ID
  timestamp: string;
  message: string;
}

/**
 * Generates a unique Vector ID based on timestamp and message content.
 * Uses MD5 hashing for a unique, fixed-length identifier.
 */
function generateVectorId(timestamp: string, message: string): string {
  const hash = crypto.createHash('md5');
  hash.update(`${timestamp}-${message}`);
  return hash.digest('hex');
}

/**
 * Main function to process stdin data.
 * Reads line by line, parses, and constructs an immutable array.
 */
function processLogs(): void {
  const data: LogEntry[] = [];
  const rl = require('readline').createInterface({
    input: process.stdin,
    output: process.stdout,
    terminal: false
  });

  rl.on('line', (line: string) => {
    // Expected format from bash awk: "TIMESTAMP|MESSAGE"
    // Example: "2023-10-27T10:00:00Z|Disk full"
    const parts = line.split('|');
    
    if (parts.length >= 2) {
      const timestamp = parts[0].trim();
      const message = parts.slice(1).join('|').trim(); // Rejoin in case message contains pipes

      // Create new object (Immutability principle: do not modify input stream)
      const logEntry: LogEntry = {
        id: generateVectorId(timestamp, message),
        timestamp: timestamp,
        message: message
      };

      data.push(logEntry);
    }
  });

  rl.on('close', () => {
    // Output the immutable array as JSON string
    console.log(JSON.stringify(data, null, 2));
  });
}

processLogs();
