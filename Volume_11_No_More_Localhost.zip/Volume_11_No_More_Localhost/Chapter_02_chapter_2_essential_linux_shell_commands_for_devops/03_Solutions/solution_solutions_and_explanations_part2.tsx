/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.tsx
// Description: Solutions and Explanations
// ==========================================

// LogVisualizer.tsx
import React, { useState } from 'react';

interface LogEntry {
  id: string;
  timestamp: string;
  message: string;
}

interface LogVisualizerProps {
  logs: LogEntry[];
}

// Simple inline styles for visual feedback
const styles = {
  container: { padding: '20px', fontFamily: 'monospace' },
  list: { listStyleType: 'none', padding: 0 },
  item: { 
    padding: '10px', 
    border: '1px solid #ddd', 
    marginBottom: '5px', 
    cursor: 'pointer',
    borderRadius: '4px' 
  },
  selectedItem: {
    backgroundColor: '#e3f2fd',
    borderColor: '#2196f3',
    fontWeight: 'bold'
  },
  details: {
    marginTop: '20px',
    padding: '15px',
    backgroundColor: '#f5f5f5',
    border: '1px solid #ccc'
  }
};

export const LogVisualizer: React.FC<LogVisualizerProps> = ({ logs }) => {
  // State to store the ID of the selected log entry
  const [selectedVectorId, setSelectedVectorId] = useState<string | null>(null);

  // Handler for selecting a log entry
  const handleSelect = (id: string) => {
    setSelectedVectorId(id);
  };

  // Immutably find the selected log entry without modifying the array
  const selectedLog = selectedVectorId 
    ? logs.find(log => log.id === selectedVectorId) 
    : null;

  return (
    <div style={styles.container}>
      <h3>Log Entries</h3>
      <ul style={styles.list}>
        {logs.map((log) => (
          <li 
            key={log.id}
            onClick={() => handleSelect(log.id)}
            style={{
              ...styles.item,
              ...(selectedVectorId === log.id ? styles.selectedItem : {})
            }}
          >
            <strong>[{log.timestamp}]</strong> {log.message.substring(0, 50)}...
            <br />
            <small>Vector ID: {log.id}</small>
          </li>
        ))}
      </ul>

      {/* Conditional Rendering for Details View */}
      {selectedLog && (
        <div style={styles.details}>
          <h4>Selected Log Details</h4>
          <p><strong>Vector ID:</strong> {selectedLog.id}</p>
          <p><strong>Timestamp:</strong> {selectedLog.timestamp}</p>
          <p><strong>Message:</strong> {selectedLog.message}</p>
        </div>
      )}
    </div>
  );
};
