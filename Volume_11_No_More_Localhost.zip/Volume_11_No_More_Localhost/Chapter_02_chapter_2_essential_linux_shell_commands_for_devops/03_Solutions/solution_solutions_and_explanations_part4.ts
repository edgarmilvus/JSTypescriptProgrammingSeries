/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

#!/bin/bash

# deploy.sh

# 1. Start the Node.js server in the background
echo "Starting server..."
node server.ts &
SERVER_PID=$!

# 2. Wait for initialization
sleep 2

# 3. Verify process is running
if ps -p $SERVER_PID > /dev/null; then
    echo "Server process is running (PID: $SERVER_PID)"
else
    echo "Error: Server failed to start."
    exit 1
fi

# 4. Permission Management
echo "Creating config file..."
touch config.json

# Set permissions: Owner Read/Write only (600)
chmod 600 config.json
echo "Permissions set to 600 (rw-------)"

# Verify permissions using ls -l
echo "Verifying permissions:"
ls -l config.json

# 5. Cleanup
echo "Stopping server (PID: $SERVER_PID)..."
kill $SERVER_PID

# Verify process is killed
if ! ps -p $SERVER_PID > /dev/null; then
    echo "Cleanup successful."
else
    echo "Warning: Process did not terminate immediately."
fi
