/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part8.ts
// Description: Solutions and Explanations
// ==========================================

#!/bin/bash

# audit_fs.sh

# Configuration
SEARCH_DIR="container_fs"
MANIFEST_FILE="manifest.txt"
COUNTER=0

# Check if directory exists
if [ ! -d "$SEARCH_DIR" ]; then
    echo "Error: Directory $SEARCH_DIR does not exist."
    exit 1
fi

# Initialize manifest file (clear previous content)
> "$MANIFEST_FILE"

echo "Starting file system audit..."

# Use find to locate files with .conf or .json extensions
# -print0 and read -r -d '' handle filenames with spaces/newlines safely
find "$SEARCH_DIR" -type f \( -name "*.conf" -o -name "*.json" \) -print0 | while IFS= read -r -d '' file; do
    
    # Calculate SHA256 checksum
    # sha256sum outputs: [CHECKSUM] [FILENAME]
    CHECKSUM_LINE=$(sha256sum "$file")
    
    # Extract just the checksum (first field)
    CHECKSUM=$(echo "$CHECKSUM_LINE" | awk '{print $1}')
    
    # Append to manifest: [CHECKSUM] [FILE_PATH]
    echo "$CHECKSUM $file" >> "$MANIFEST_FILE"
    
    # Increment counter
    ((COUNTER++))
    
done

echo "Audit complete."
echo "Files audited: $COUNTER"
echo "Manifest generated at: $MANIFEST_FILE"

# Verification: Display the first few lines of the manifest
echo "--- Manifest Preview ---"
head -n 5 "$MANIFEST_FILE"
