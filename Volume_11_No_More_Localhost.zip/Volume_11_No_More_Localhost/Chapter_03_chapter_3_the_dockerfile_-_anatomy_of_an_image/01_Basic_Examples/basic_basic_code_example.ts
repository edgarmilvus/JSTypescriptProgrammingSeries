/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

# syntax=docker/dockerfile:1.4

# STAGE 1: Builder
# This stage compiles the TypeScript code, bundles the application, and installs all dependencies.
# It uses a full Node.js image with build tools.
FROM node:20-alpine AS builder

# Set the working directory inside the container
WORKDIR /app

# Copy package.json and package-lock.json (or yarn.lock)
# We copy these separately to leverage Docker layer caching.
# If package.json doesn't change, Docker can reuse the cached node_modules layer,
# significantly speeding up subsequent builds.
COPY package.json package-lock.json* ./

# Install dependencies
# We use the '--only=production' flag for the builder stage to avoid installing dev dependencies
# that are not needed for the build itself. However, for a Next.js build, we often need devDependencies
# like typescript, eslint, etc. So we install everything here.
# We also use the '--no-optional' flag to skip optional dependencies (like puppeteer or sharp if not needed for build)
# to keep the image slim.
RUN npm ci --only=production --no-optional

# Copy the rest of the application source code
COPY . .

# Build the Next.js application
# This command runs 'next build' which optimizes the app for production.
# It generates static files, server-side rendered pages, and API routes.
RUN npm run build

# STAGE 2: Runner
# This stage creates the final lightweight image for production.
# We start from a minimal Node.js Alpine image.
FROM node:20-alpine AS runner

# Set the working directory
WORKDIR /app

# Install 'tini' (Tiny Init) as PID 1 (Process ID 1) to handle signals properly.
# Node.js apps running as PID 1 don't handle signals (like SIGTERM from Kubernetes) correctly by default.
# Tini ensures that signals are forwarded to the Node process and zombie processes are reaped.
RUN apk add --no-cache tini

# Create a non-root user for security
# Running containers as root is a security risk. We create a dedicated user.
RUN addgroup -g 1001 -S nodejs && \
    adduser -S nextjs -u 1001

# Copy the built application from the 'builder' stage
# We only copy the necessary files for running the app.
COPY --from=builder /app/.next ./.next
COPY --from=builder /app/public ./public
COPY --from=builder /app/package.json ./package.json
COPY --from=builder /app/node_modules ./node_modules

# Change ownership of the app directory to the non-root user
RUN chown -R nextjs:nodejs /app

# Switch to the non-root user
USER nextjs

# Expose the port the app will run on
EXPOSE 3000

# Set the Node.js environment to production
# This disables development-only features like source maps and enables optimizations.
ENV NODE_ENV=production

# Use 'tini' as the entrypoint
# This ensures that our 'node' command is run as a child of tini.
ENTRYPOINT ["/sbin/tini", "--"]

# The command to run the application
# This starts the Next.js production server.
CMD ["node", ".next/server/pages/api/index.js"]
