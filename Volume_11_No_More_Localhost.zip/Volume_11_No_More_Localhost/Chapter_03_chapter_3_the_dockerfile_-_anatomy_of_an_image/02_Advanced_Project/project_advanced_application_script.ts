/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

/**
 * RAG Pipeline API Route for Next.js
 * 
 * This script implements a Retrieval-Augmented Generation (RAG) pipeline endpoint.
 * It processes uploaded documents (e.g., PDFs, Markdown) by chunking them semantically,
 * generating embeddings using a lightweight model (simulated here for demo), and performing
 * cosine similarity searches to retrieve relevant context for AI queries.
 * 
 * Key Concepts Applied:
 * - Chunking Strategy: Hybrid approach combining paragraph splitting with sliding window overlap.
 * - Cosine Similarity: Computes vector similarity to rank chunks by relevance.
 * - Containerization-Ready: Stateless, async operations; minimal dependencies for Docker efficiency.
 * 
 * Endpoints:
 * - POST /api/ingest: Uploads and processes a document.
 * - POST /api/query: Performs a semantic search against processed chunks.
 * 
 * Dependencies (assumed installed via package.json):
 * - pdf-parse (for PDF processing, omitted in demo for brevity)
 * - @huggingface/inference (for embeddings, simulated here)
 * 
 * @module RAGPipeline
 * @version 1.0.0
 */

import { NextApiRequest, NextApiResponse } from 'next';
import fs from 'fs';
import path from 'path';
import { Readable } from 'stream';

// ============================================================================
// 1. CONFIGURATION & TYPES
// ============================================================================
// Centralized config for easy Docker environment variable injection.
const CONFIG = {
  CHUNK_SIZE: 512, // Tokens or characters; adjust based on embedding model limits.
  OVERLAP: 64,     // Overlap between chunks to preserve context.
  MAX_CHUNKS: 1000, // Safety limit to prevent memory bloat in containers.
  EMBEDDING_MODEL: 'all-MiniLM-L6-v2', // Lightweight model for JS/AI workloads.
  STORAGE_DIR: '/tmp/rag-storage',     // Ephemeral storage; mount volume in production.
};

// Document type for processing.
interface DocumentChunk {
  id: string;
  text: string;
  embedding: number[]; // Vector representation.
  metadata: {
    source: string;
    chunkIndex: number;
    totalChunks: number;
  };
}

// Query input type.
interface QueryInput {
  query: string;
  topK?: number; // Number of results to return.
}

// ============================================================================
// 2. UTILITY FUNCTIONS
// ============================================================================
/**
 * Generates a unique ID for chunks.
 * Why: Ensures traceability in storage and search results.
 */
const generateId = (): string => `chunk_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;

/**
 * Simulates text embedding generation.
 * Why: In a real app, this would call an AI model (e.g., via Hugging Face API).
 * Under the Hood: Uses a placeholder cosine-based similarity for demo; replace with actual model inference.
 * For Docker: Offload to a GPU-enabled container or external service to keep this image lightweight.
 */
async function generateEmbedding(text: string): Promise<number[]> {
  // Placeholder: In production, integrate with a model like `@huggingface/inference`.
  // Simulate vector by hashing words and normalizing (for demo only).
  const words = text.split(/\s+/);
  const vector = words.map((word, idx) => {
    let hash = 0;
    for (let i = 0; i < word.length; i++) {
      hash = ((hash << 5) - hash) + word.charCodeAt(i);
      hash |= 0; // Convert to 32-bit integer.
    }
    return Math.sin(hash + idx) * 100; // Pseudo-embedding.
  });
  // Normalize to unit vector for cosine similarity.
  const norm = Math.sqrt(vector.reduce((sum, val) => sum + val * val, 0));
  return vector.map(v => (norm > 0 ? v / norm : 0));
}

/**
 * Computes cosine similarity between two vectors.
 * Why: Core metric for RAG; measures angular alignment (0 to 1).
 * How: (A · B) / (||A|| * ||B||). Assumes normalized vectors for efficiency.
 */
function cosineSimilarity(a: number[], b: number[]): number {
  if (a.length !== b.length) return 0;
  let dotProduct = 0;
  for (let i = 0; i < a.length; i++) {
    dotProduct += a[i] * b[i];
  }
  // Vectors are normalized in generation, so denominator is ~1.
  return Math.max(0, Math.min(1, dotProduct));
}

/**
 * Saves chunks to ephemeral storage.
 * Why: Decouples processing from query; enables caching in Docker volumes.
 */
async function saveChunks(chunks: DocumentChunk[], source: string): Promise<void> {
  const dir = path.join(CONFIG.STORAGE_DIR, source);
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
  const filePath = path.join(dir, 'chunks.json');
  fs.writeFileSync(filePath, JSON.stringify(chunks, null, 2));
}

/**
 * Loads chunks from storage.
 */
async function loadChunks(source: string): Promise<DocumentChunk[]> {
  const filePath = path.join(CONFIG.STORAGE_DIR, source, 'chunks.json');
  if (!fs.existsSync(filePath)) return [];
  const data = fs.readFileSync(filePath, 'utf-8');
  return JSON.parse(data);
}

// ============================================================================
// 3. CORE LOGIC: CHUNKING STRATEGY
// ============================================================================
/**
 * Applies a hybrid chunking strategy to break down large documents.
 * Why: Raw text splitting loses context; this balances granularity with semantic coherence.
 * How It Works:
 * 1. Split by paragraphs (semantic boundaries).
 * 2. For each paragraph, apply sliding window with overlap if length > CHUNK_SIZE.
 * 3. Filter empty chunks and enforce limits for resource constraints (Docker-friendly).
 * 
 * Under the Hood:
 * - Paragraph Splitting: Uses regex for Markdown/PDF text; preserves structure.
 * - Sliding Window: Ensures overlapping text (e.g., last 64 chars of prev chunk) to maintain flow.
 * - Optimization: Parallel processing for large docs; limits chunks to avoid OOM in containers.
 */
async function chunkDocument(text: string, source: string): Promise<DocumentChunk[]> {
  // Step 1: Normalize and split by paragraphs (handles Markdown/PDF text).
  const paragraphs = text
    .replace(/\r\n/g, '\n') // Normalize line endings.
    .split(/\n\s*\n/)       // Split on double newlines (paragraphs).
    .filter(p => p.trim().length > 0);

  const chunks: DocumentChunk[] = [];
  let chunkIndex = 0;

  for (const para of paragraphs) {
    if (chunks.length >= CONFIG.MAX_CHUNKS) break;

    // Step 2: If paragraph is short, treat as one chunk.
    if (para.length <= CONFIG.CHUNK_SIZE) {
      const embedding = await generateEmbedding(para);
      chunks.push({
        id: generateId(),
        text: para,
        embedding,
        metadata: { source, chunkIndex: chunkIndex++, totalChunks: 0 }, // Total updated later.
      });
      continue;
    }

    // Step 3: Sliding window for long paragraphs.
    let start = 0;
    while (start < para.length && chunks.length < CONFIG.MAX_CHUNKS) {
      const end = Math.min(start + CONFIG.CHUNK_SIZE, para.length);
      let chunkText = para.substring(start, end);

      // Apply overlap: prepend last OVERLAP chars from previous chunk.
      if (start > 0) {
        const overlapStart = Math.max(0, start - CONFIG.OVERLAP);
        const overlapText = para.substring(overlapStart, start);
        chunkText = overlapText + chunkText;
      }

      const embedding = await generateEmbedding(chunkText);
      chunks.push({
        id: generateId(),
        text: chunkText,
        embedding,
        metadata: { source, chunkIndex: chunkIndex++, totalChunks: 0 },
      });

      start += CONFIG.CHUNK_SIZE - CONFIG.OVERLAP; // Slide with overlap.
    }
  }

  // Update total chunks in metadata.
  const total = chunks.length;
  chunks.forEach(c => c.metadata.totalChunks = total);

  // Step 4: Persist to storage.
  await saveChunks(chunks, source);

  return chunks;
}

// ============================================================================
// 4. SEMANTIC SEARCH: COSINE SIMILARITY ENGINE
// ============================================================================
/**
 * Performs semantic search over chunks using cosine similarity.
 * Why: Retrieves top-K most relevant chunks for RAG context.
 * How: Embeds query, computes similarity for all chunks, sorts, and returns.
 * Under the Hood: In production, use a vector database (e.g., Pinecone, pgvector) for scalability.
 * For Docker: This is CPU-bound; optimize with WebAssembly or offload to a dedicated service.
 */
async function semanticSearch(query: string, source: string, topK: number = 3): Promise<DocumentChunk[]> {
  const chunks = await loadChunks(source);
  if (chunks.length === 0) return [];

  const queryEmbedding = await generateEmbedding(query);

  // Compute similarities in parallel (Node.js event loop friendly).
  const scoredChunks = await Promise.all(
    chunks.map(async (chunk) => ({
      ...chunk,
      score: cosineSimilarity(queryEmbedding, chunk.embedding),
    }))
  );

  // Sort by score descending and take top-K.
  return scoredChunks
    .sort((a, b) => b.score - a.score)
    .slice(0, topK)
    .map(({ score, ...rest }) => rest); // Exclude score from output if needed.
}

// ============================================================================
// 5. NEXT.JS API HANDLERS
// ============================================================================
// Note: In a real Next.js app, these would be in separate files or a single route handler.
// For brevity, we simulate the handlers here as async functions.

/**
 * Ingestion Handler: Processes uploaded document.
 * Input: { file: Buffer, source: string }
 * Output: { success: boolean, chunksCount: number }
 */
async function handleIngest(req: NextApiRequest, res: NextApiResponse): Promise<void> {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  try {
    // Simulate file upload (in real app, use Multer or Next.js file handling).
    const { text, source } = req.body as { text: string; source: string };
    if (!text || !source) {
      return res.status(400).json({ error: 'Missing text or source' });
    }

    // Core chunking logic.
    const chunks = await chunkDocument(text, source);

    res.status(200).json({
      success: true,
      chunksCount: chunks.length,
      message: `Document '${source}' processed with ${chunks.length} chunks.`,
    });
  } catch (error) {
    console.error('Ingest error:', error);
    res.status(500).json({ error: 'Failed to ingest document' });
  }
}

/**
 * Query Handler: Performs semantic search and returns context.
 * Input: { query: string, source: string, topK?: number }
 * Output: { context: string[], metadata: any[] }
 */
async function handleQuery(req: NextApiRequest, res: NextApiResponse): Promise<void> {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  try {
    const { query, source, topK } = req.body as QueryInput & { source: string };
    if (!query || !source) {
      return res.status(400).json({ error: 'Missing query or source' });
    }

    // Core search logic.
    const results = await semanticSearch(query, source, topK);

    const context = results.map(r => r.text);
    const metadata = results.map(r => r.metadata);

    res.status(200).json({
      context,
      metadata,
      message: `Retrieved ${results.length} relevant chunks for query.`,
    });
  } catch (error) {
    console.error('Query error:', error);
    res.status(500).json({ error: 'Failed to process query' });
  }
}

// Export handlers for Next.js route (e.g., in pages/api/rag.ts).
// In a full app, wrap in a single handler with method switching.
export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  const { endpoint } = req.query; // e.g., /api/rag/ingest or /api/rag/query

  if (endpoint === 'ingest') {
    await handleIngest(req, res);
  } else if (endpoint === 'query') {
    await handleQuery(req, res);
  } else {
    res.status(404).json({ error: 'Endpoint not found' });
  }
}
