/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

# Dockerfile

# 1. Base Image: Use the lightweight Alpine Linux distribution with Node.js 20
FROM node:20-alpine

# 2. Working Directory: Set the container context to /app
WORKDIR /app

# 3. Dependency Installation (Layer Caching):
# Copy package files first to leverage Docker layer caching.
# If package.json doesn't change, this layer is reused, speeding up builds.
COPY package*.json ./

# Install production dependencies only, removing dev dependencies to keep image small
RUN npm ci --only=production

# 4. Application Copy: Copy the rest of the application source code
COPY . .

# 5. Exposure: Document the port the app listens on (documentation only)
EXPOSE 3000

# 6. Execution: Define the startup command using exec form for signal handling
CMD ["node", "server.js"]
