/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

# Dockerfile

# --- Stage 1: Builder ---
# Build the Next.js application
FROM node:20-alpine AS builder

WORKDIR /app

# Install all dependencies (including dev dependencies like typescript, eslint)
COPY package*.json ./
RUN npm ci

# Build the application (generates .next folder)
RUN npm run build

# --- Stage 2: Production ---
# Run the application
FROM node:20-alpine AS runner

WORKDIR /app

# Create a non-root user for security
RUN addgroup -g 1001 -S nodejs
RUN adduser -S nextjs -u 1001

# Copy package files again
COPY package*.json ./

# Install ONLY production dependencies (no dev tools)
RUN npm ci --only=production && npm cache clean --force

# Copy the build output from the builder stage
COPY --from=builder /app/.next ./.next

# Copy public assets if any (Next.js specific)
COPY --from=builder /app/public ./public

# Change ownership of the app directory to the non-root user
RUN chown -R nextjs:nodejs /app

# Switch to the non-root user
USER nextjs

# Expose the port (Next.js default is 3000)
EXPOSE 3000

# Environment Variable Handling:
# Next.js automatically loads .env.local at build time, but for runtime variables,
# we rely on Docker's runtime injection or next.config.js.
# This CMD runs the production server.
CMD ["npm", "start"]
