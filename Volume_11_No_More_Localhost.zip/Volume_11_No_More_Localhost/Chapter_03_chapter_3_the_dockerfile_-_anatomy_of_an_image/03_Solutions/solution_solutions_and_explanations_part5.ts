/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

# Dockerfile (CORRECTED)

# --- Stage 1: Builder ---
FROM node:20-alpine AS builder

WORKDIR /app

# Install ALL dependencies (including dev dependencies needed for building)
COPY package*.json ./
RUN npm ci

# (Optional: If this were a Next.js app, we would run 'npm run build' here)
# For a standard Node app, we just install deps.

# --- Stage 2: Production ---
FROM node:20-alpine AS runner

# Create a non-root user (security fix)
RUN addgroup -g 1001 -S nodejs
RUN adduser -S nodeuser -u 1001

WORKDIR /app

# Copy package files
COPY package*.json ./

# Install ONLY production dependencies (efficiency fix)
# This removes the node_modules from the builder that contained dev deps
RUN npm ci --only=production && npm cache clean --force

# Copy source code from builder
COPY . .

# Change ownership to the non-root user
RUN chown -R nodeuser:nodejs /app

# Switch to non-root user (security fix)
USER nodeuser

EXPOSE 3000

# Use exec form
CMD ["node", "server.js"]
