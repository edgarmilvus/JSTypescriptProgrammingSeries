/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.ts
// Description: Basic Code Example
// ==========================================

# docker-compose.yml
version: '3.8'

services:
  # Service 1: The Node.js Backend Application
  api:
    build:
      context: .                # Build context is the current directory
      dockerfile: Dockerfile     # Specific Dockerfile for the API
    container_name: hello_world_api
    ports:
      - "3000:3000"             # Map host port 3000 to container port 3000
    environment:
      - DB_HOST=db              # Uses the service name 'db' as the hostname
      - DB_PORT=5432
      - DB_USER=postgres
      - DB_PASSWORD=secret
      - DB_NAME=hello_db
    depends_on:
      - db                      # Ensures 'db' starts before 'api'
    networks:
      - app-network

  # Service 2: The PostgreSQL Database
  db:
    image: postgres:15-alpine   # Use a lightweight official Postgres image
    container_name: hello_world_db
    environment:
      - POSTGRES_USER=postgres
      - POSTGRES_PASSWORD=secret
      - POSTGRES_DB=hello_db
    volumes:
      - db-data:/var/lib/postgresql/data  # Persist data across restarts
    ports:
      - "5432:5432"             # Expose port for external debugging (optional)
    networks:
      - app-network

# Define a custom network so services can discover each other by name
networks:
  app-network:
    driver: bridge

# Define a named volume for database persistence
volumes:
  db-data:
