/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example_part3.ts
// Description: Basic Code Example
// ==========================================

# Dockerfile

# 1. Base Image: Use a lightweight Node.js image with Alpine Linux
FROM node:18-alpine

# 2. Working Directory: Set the working directory inside the container
WORKDIR /usr/src/app

# 3. Dependency Installation: Copy package files first to leverage Docker cache
COPY package*.json ./

# Install production dependencies only (optimizes image size)
RUN npm install --only=production

# 4. Source Code: Copy the rest of the application code
COPY . .

# 5. Build: Compile TypeScript (if needed, or use ts-node in dev)
# For this example, we assume we are running ts-node directly or pre-building.
# Let's install dev dependencies for runtime execution of TS.
RUN npm install

# 6. Expose Port: Document that the container listens on port 3000
EXPOSE 3000

# 7. Entry Point: The command to start the app
CMD ["npm", "start"]
