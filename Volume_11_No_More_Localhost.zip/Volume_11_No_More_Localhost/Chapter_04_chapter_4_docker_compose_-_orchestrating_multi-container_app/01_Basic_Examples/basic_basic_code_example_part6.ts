/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example_part6.ts
// Description: Basic Code Example
// ==========================================

// src/index.ts
import express, { Request, Response } from 'express';
import { Pool } from 'pg';

// 1. Configuration
// We read database credentials from environment variables injected by Docker Compose.
const dbConfig = {
  host: process.env.DB_HOST || 'localhost',
  port: parseInt(process.env.DB_PORT || '5432'),
  user: process.env.DB_USER || 'postgres',
  password: process.env.DB_PASSWORD || 'secret',
  database: process.env.DB_NAME || 'hello_db',
};

// 2. Database Connection Pool
// Using a pool is more efficient than creating a new client for every request.
const pool = new Pool(dbConfig);

// 3. Initialize Express App
const app = express();
const PORT = 3000;

// 4. Health Check Endpoint
// Simple route to verify the API is running and DB is accessible.
app.get('/', async (req: Request, res: Response) => {
  try {
    // 5. Execute Query
    // We attempt to query a specific table. 
    // Note: In a real app, we'd create the table via migrations. 
    // For this "Hello World", we'll just select a static string from the DB 
    // to prove connectivity.
    
    // Let's assume we have a table 'messages' with a column 'content'.
    // To make this self-contained, we will just query the PostgreSQL version 
    // to prove the connection works without needing schema migrations.
    const result = await pool.query('SELECT version()');
    
    const dbVersion = result.rows[0].version;
    
    res.json({
      message: 'Hello World from Docker Compose!',
      database_connected: true,
      database_version: dbVersion
    });
  } catch (error) {
    console.error('Database connection error:', error);
    res.status(500).json({
      message: 'Failed to connect to database',
      error: (error as Error).message
    });
  }
});

// 6. Start Server
app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
