/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script_part2.ts
// Description: Advanced Application Script
// ==========================================

/**
 * ============================================================================
 * FILE: pages/api/generate.ts & Dashboard.tsx
 * CONTEXT: SaaS AI Image Generation Dashboard
 * GOAL: Orchestrate communication between Next.js and a Dockerized AI Service
 * ============================================================================
 */

import { useState, useEffect } from 'react';
import type { NextPage, GetServerSideProps } from 'next';

// -----------------------------------------------------------------------------
// 1. DATA MODELS & TYPES
// -----------------------------------------------------------------------------
// Defines the shape of the response from the AI Service container.
// In a complex app, this would be shared via a private npm package.
interface AIImageResponse {
  jobId: string;
  status: 'pending' | 'processing' | 'completed';
  imageUrl?: string;
  meta: {
    inferenceTime: number;
    model: string;
  };
}

interface DashboardProps {
  serverStatus: 'healthy' | 'unreachable';
}

// -----------------------------------------------------------------------------
// 2. SERVER-SIDE ORCHESTRATION (GetServerSideProps)
// -----------------------------------------------------------------------------
// This runs on the server (Node.js) during the initial request.
// It acts as a "Supervisor Node" checking the health of the AI container
// before the page even renders. This prevents the client from attempting
// to talk to a dead service.
//
// DOCKER COMPOSE CONTEXT:
// We use the service name 'ai-service' defined in docker-compose.yml.
// This resolves to the internal IP of the container.
export const getServerSideProps: GetServerSideProps = async () => {
  const AI_BACKEND_URL = process.env.AI_BACKEND_URL || 'http://localhost:8000';

  try {
    // We perform a lightweight health check on the AI container.
    // This mimics the "Graph State" analysis of a Supervisor Node.
    const res = await fetch(`${AI_BACKEND_URL}/health`, {
      method: 'GET',
      signal: AbortSignal.timeout(2000), // Fail fast
    });

    if (!res.ok) throw new Error('AI Service Unhealthy');

    return {
      props: {
        serverStatus: 'healthy',
      },
    };
  } catch (error) {
    // If the AI container is down, we fail gracefully.
    // In a real multi-agent system, the Supervisor would log this
    // and route to a fallback worker.
    console.error('Orchestration Error: AI Service unreachable', error);
    return {
      props: {
        serverStatus: 'unreachable',
      },
    };
  }
};

// -----------------------------------------------------------------------------
// 3. CLIENT-SIDE COMPONENT (The Dashboard)
// -----------------------------------------------------------------------------
const AIDashboard: NextPage<DashboardProps> = ({ serverStatus }) => {
  // State management for the job queue
  const [job, setJob] = useState<AIImageResponse | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // -------------------------------------------------------------------------
  // 4. THE ORCHESTRATOR FUNCTION
  // -------------------------------------------------------------------------
  // Handles the lifecycle of an AI request.
  const handleGenerate = async () => {
    if (serverStatus !== 'healthy') {
      setError('AI Service is offline. Check Docker Compose logs.');
      return;
    }

    setLoading(true);
    setError(null);
    setJob(null);

    try {
      // Step A: Submit the task to the AI Service
      // Note: We use the internal Docker network URL here.
      // In development (localhost), this proxies via Next.js API routes or direct call.
      const response = await fetch('/api/proxy/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt: 'A futuristic city with neon lights' }),
      });

      if (!response.ok) throw new Error('Failed to submit job');

      const data: AIImageResponse = await response.json();
      
      // Step B: Polling for completion (Simulating async WASM thread completion)
      // In a real scenario, WebSockets would be used, but polling demonstrates
      // the state management of a long-running container task.
      await pollForCompletion(data.jobId);

    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unknown error');
    } finally {
      setLoading(false);
    }
  };

  // -------------------------------------------------------------------------
  // 5. ASYNC POLLING LOGIC (Stateful Dependency Management)
  // -------------------------------------------------------------------------
  // Checks the status of the job until it is 'completed'.
  const pollForCompletion = async (jobId: string) => {
    const maxAttempts = 10;
    let attempts = 0;

    while (attempts < maxAttempts) {
      await new Promise(resolve => setTimeout(resolve, 1500)); // Wait 1.5s
      
      try {
        const res = await fetch(`/api/proxy/jobs/${jobId}`);
        if (!res.ok) throw new Error('Polling failed');
        
        const statusData: AIImageResponse = await res.json();
        
        if (statusData.status === 'completed') {
          setJob(statusData);
          return; // Task complete
        }
        
        // Update UI with processing state
        setJob(statusData); 
      } catch (err) {
        console.warn('Polling attempt failed', attempts);
      }
      
      attempts++;
    }

    throw new Error('Job timed out');
  };

  // -------------------------------------------------------------------------
  // 6. UI RENDERING
  // -------------------------------------------------------------------------
  return (
    <div style={{ padding: '2rem', fontFamily: 'sans-serif' }}>
      <h1>AI Image Generator (Dockerized)</h1>
      
      <div style={{ marginBottom: '1rem', padding: '1rem', border: '1px solid #ddd' }}>
        <strong>System Status:</strong> 
        <span style={{ color: serverStatus === 'healthy' ? 'green' : 'red' }}>
          {serverStatus.toUpperCase()}
        </span>
      </div>

      <button 
        onClick={handleGenerate} 
        disabled={loading || serverStatus !== 'healthy'}
        style={{ padding: '10px 20px', cursor: loading ? 'wait' : 'pointer' }}
      >
        {loading ? 'Generating...' : 'Generate Image'}
      </button>

      {error && <p style={{ color: 'red' }}>Error: {error}</p>}

      {/* Displaying the result from the AI Container */}
      {job && (
        <div style={{ marginTop: '2rem' }}>
          <h3>Job Status: {job.status.toUpperCase()}</h3>
          {job.imageUrl ? (
            <img 
              src={job.imageUrl} 
              alt="Generated AI" 
              style={{ maxWidth: '500px', border: '2px solid #333' }} 
            />
          ) : (
            <p>Processing... (Simulating WASM inference)</p>
          )}
          <pre>{JSON.stringify(job.meta, null, 2)}</pre>
        </div>
      )}
    </div>
  );
};

export default AIDashboard;
