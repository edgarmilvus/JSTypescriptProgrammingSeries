/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.tsx
// Description: Solutions and Explanations
// ==========================================

// ServiceStatus.tsx
import React, { useState, useEffect } from 'react';

interface ServiceStatusResponse {
  api: string;
  db: string;
}

type StatusState = 'loading' | 'healthy' | 'unhealthy' | 'error';

export const ServiceStatus: React.FC = () => {
  const [apiStatus, setApiStatus] = useState<StatusState>('loading');
  const [dbStatus, setDbStatus] = useState<StatusState>('loading');
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchStatus = async () => {
      try {
        // The API is proxied via Nginx at localhost:8080/api/status
        const response = await fetch('http://localhost:8080/api/status');
        
        if (!response.ok) {
          throw new Error(`HTTP error! status: ${response.status}`);
        }

        const data: ServiceStatusResponse = await response.json();
        
        // Map API response strings to our state types
        setApiStatus(data.api === 'healthy' ? 'healthy' : 'unhealthy');
        setDbStatus(data.db === 'healthy' ? 'healthy' : 'unhealthy');
        setError(null);
      } catch (e) {
        setApiStatus('error');
        setDbStatus('error');
        setError('Failed to fetch status. Is the network or service down?');
      }
    };

    // Fetch immediately on mount
    fetchStatus();

    // Optional: Set up an interval to poll for status updates
    const interval = setInterval(fetchStatus, 10000);

    // Cleanup interval on unmount
    return () => clearInterval(interval);
  }, []);

  // Helper to render a status indicator
  const renderIndicator = (serviceName: string, state: StatusState) => {
    let color = 'gray';
    let text = 'Unknown';

    switch (state) {
      case 'loading':
        color = 'orange';
        text = 'Loading...';
        break;
      case 'healthy':
        color = 'green';
        text = 'Healthy';
        break;
      case 'unhealthy':
      case 'error':
        color = 'red';
        text = 'Down/Error';
        break;
    }

    return (
      <div style={{ display: 'flex', alignItems: 'center', margin: '5px 0' }}>
        <div 
          style={{ 
            width: '12px', 
            height: '12px', 
            borderRadius: '50%', 
            backgroundColor: color, 
            marginRight: '8px' 
          }} 
        />
        <strong>{serviceName}:</strong> <span style={{ marginLeft: '5px', color: color }}>{text}</span>
      </div>
    );
  };

  return (
    <div style={{ padding: '20px', border: '1px solid #ccc', borderRadius: '8px', fontFamily: 'sans-serif' }}>
      <h3>Service Status Monitor</h3>
      
      {renderIndicator('Backend API', apiStatus)}
      {renderIndicator('Database', dbStatus)}

      {error && (
        <div style={{ color: 'red', marginTop: '10px', fontSize: '0.9em' }}>
          Error: {error}
        </div>
      )}
    </div>
  );
};
