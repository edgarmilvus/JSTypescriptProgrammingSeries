/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

# docker-compose.yml
version: '3.8'

services:
  worker:
    build: ./worker # Assumes a Dockerfile in ./worker directory
    # In v3, we use 'deploy' for replicas (requires docker-compose v2+ or Swarm mode)
    # For local 'docker-compose up' without Swarm, we can use the scale flag or 'replicas' if supported by the version.
    # Here is the v3 syntax which works with 'docker stack deploy' or recent compose versions:
    deploy:
      replicas: 3
    volumes:
      - shared-data:/data
    networks:
      - consensus-net

  supervisor:
    build: ./supervisor # Assumes a Dockerfile in ./supervisor directory
    depends_on:
      - worker
    volumes:
      - shared-data:/data:ro # Mount read-only
    networks:
      - consensus-net
    command: ["npm", "start"] # Assumes this command reads /data and calculates consensus

volumes:
  shared-data:

networks:
  consensus-net:
    driver: bridge
