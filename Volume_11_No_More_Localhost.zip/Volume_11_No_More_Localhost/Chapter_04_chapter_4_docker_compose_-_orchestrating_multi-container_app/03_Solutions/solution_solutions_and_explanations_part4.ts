/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

digraph Architecture {
    rankdir=TB;
    compound=true;
    fontname="Helvetica";
    node [fontname="Helvetica", shape=box, style=filled, fillcolor="#f0f0f0"];
    edge [fontname="Helvetica", fontsize=10];

    // Host Machine Boundary
    subgraph cluster_host {
        label = "Host Machine";
        style = dashed;
        color = blue;

        // Browser Node (External to Docker but interacting with it)
        browser [label="User Browser", shape=ellipse, fillcolor="#e1f5fe"];

        // Docker Engine Boundary
        subgraph cluster_docker {
            label = "Docker Engine";
            style = solid;
            color = black;
            shape = component;

            // Network Boundary
            subgraph cluster_network {
                label = "app-network (Bridge)";
                style = dotted;
                color = grey;
                
                nginx [label="Nginx\n(Reverse Proxy)\nPort 8080", fillcolor="#ffccbc"];
                api [label="API Service\n(Node.js)\nPort 3000", fillcolor="#fff9c4"];
                db [label="DB Service\n(Postgres)\nInternal:5432", fillcolor="#e1bee7"];
            }

            // React Build (Served by Nginx)
            react_build [label="React Static Build\n(Mounted Volume)", fillcolor="#c8e6c9", shape=folder];
        }
    }

    // Data Flow Arrows
    browser -> nginx [label="HTTP Request\nlocalhost:8080", dir=both];
    nginx -> api [label="Proxy /api/*", constraint=false];
    nginx -> react_build [label="Serve /*", constraint=false];
    api -> db [label="SQL Query\n(DNS: db)", dir=both];
}
