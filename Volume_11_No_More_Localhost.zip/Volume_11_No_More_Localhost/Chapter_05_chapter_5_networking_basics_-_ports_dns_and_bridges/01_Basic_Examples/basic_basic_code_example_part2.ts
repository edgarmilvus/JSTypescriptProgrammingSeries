/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.ts
// Description: Basic Code Example
// ==========================================

# Use the official Node.js 18 Alpine Linux image as the base image.
# Alpine is a lightweight Linux distribution, ideal for containerized applications.
FROM node:18-alpine

# Set the working directory inside the container to /app.
# All subsequent commands (COPY, RUN, CMD) will be executed from this directory.
WORKDIR /app

# Copy the package.json and package-lock.json files first.
# This leverages Docker's layer caching. If these files don't change,
# subsequent steps can use the cached layers, speeding up the build process.
COPY package*.json ./

# Install production dependencies only.
# This keeps the image size small and reduces the attack surface.
RUN npm ci --only=production

# Copy the rest of the application source code into the container.
COPY . .

# Expose port 3000 to the Docker host.
# This is metadata and does not actually publish the port.
# It documents the port the container is designed to listen on.
EXPOSE 3000

# Define the command to run the application.
# This command is executed when the container starts.
CMD ["node", "dist/index.js"]
