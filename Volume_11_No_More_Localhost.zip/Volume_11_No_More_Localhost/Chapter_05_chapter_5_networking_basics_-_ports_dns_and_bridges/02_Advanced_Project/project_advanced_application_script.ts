/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

/**
 * ============================================================================
 * ADVANCED APPLICATION SCRIPT: Hybrid AI Networking & Service Architecture
 * ============================================================================
 * 
 * CONTEXT:
 * This script represents a Next.js 14+ application (App Router) designed to 
 * run within a Dockerized environment. It demonstrates:
 * 
 * 1. SERVICE WORKER CACHING: Caching large ONNX model weights locally in the 
 *    browser to reduce network traffic and enable offline inference.
 * 2. BACKEND BRIDGING: Using Next.js API routes as a secure bridge between the 
 *    client and a PostgreSQL database (pgvector) running in a separate Docker 
 *    container.
 * 3. DNS RESOLUTION: Leveraging Docker's internal DNS to resolve the database 
 *    host via service names rather than IP addresses.
 * 
 * TARGET: 80-120 Lines (TypeScript/TSX)
 */

import { NextResponse } from 'next/server';
import type { NextRequest } from 'next/server';
import { Pool } from 'pg';

// ============================================================================
// 1. SERVICE WORKER REGISTRATION & CACHING STRATEGY (Client-Side Simulation)
// ============================================================================

/**
 * Registers a Service Worker to cache AI model assets (e.g., ONNX weights).
 * 
 * WHY: Transformers.js models can be several hundred megabytes. Downloading them
 * on every visit is expensive and slow. We use a Service Worker to intercept 
 * fetch requests and serve them from the browser's Cache API.
 * 
 * HOW: This function is typically called in a React `useEffect` hook or a 
 * root layout file.
 */
export function registerServiceWorker() {
  if (typeof window !== 'undefined' && 'serviceWorker' in navigator) {
    navigator.serviceWorker
      .register('/sw.js') // The worker script served by Next.js static assets
      .then((registration) => {
        console.log('Service Worker registered with scope:', registration.scope);
        
        // Listen for updates
        registration.addEventListener('updatefound', () => {
          const newWorker = registration.installing;
          if (newWorker) {
            newWorker.addEventListener('statechange', () => {
              if (newWorker.state === 'installed' && navigator.serviceWorker.controller) {
                console.log('New AI model weights available. Updating cache...');
              }
            });
          }
        });
      })
      .catch((error) => {
        console.error('Service Worker registration failed:', error);
      });
  }
}

/**
 * Simulated Client Component for AI Model Loading.
 * In a real app, this would be a React component using `useEffect`.
 */
const ClientSideAILoader = () => {
  // Simulate loading a cached model
  const loadModel = async () => {
    // The browser fetches this URL. The Service Worker intercepts it.
    // If cached, it returns from local storage. If not, it fetches from the server.
    const modelUrl = '/models/onnx/bert-base-uncased.onnx';
    
    try {
      const response = await fetch(modelUrl);
      if (!response.ok) throw new Error('Model fetch failed');
      console.log('Model loaded successfully (potentially from cache).');
    } catch (err) {
      console.error('Failed to load model:', err);
    }
  };

  return null; // In a real component, this would return JSX
};

// ============================================================================
// 2. BACKEND BRIDGE: API Route with Database Networking
// ============================================================================

/**
 * API Route Handler: POST /api/vector-search
 * 
 * CONTEXT: This runs on the server (Node.js environment). It connects to a 
 * PostgreSQL database running in a separate Docker container.
 * 
 * NETWORKING CONCEPT: DOCKER BRIDGE & DNS
 * - In a docker-compose setup, the database container is usually named `db`.
 * - Docker's internal DNS resolves the hostname `db` to the container's internal IP.
 * - We do NOT use `localhost` here, as `localhost` inside a container refers to 
 *   the container itself, not the host machine or other containers.
 * - We use standard ports (5432 for Postgres).
 */
export async function POST(request: NextRequest) {
  try {
    // 1. Parse the incoming request (e.g., a user query for semantic search)
    const { queryEmbedding } = await request.json();

    if (!queryEmbedding || !Array.isArray(queryEmbedding)) {
      return NextResponse.json(
        { error: 'Invalid embedding vector provided.' },
        { status: 400 }
      );
    }

    // 2. Configure Database Connection using Environment Variables.
    // These variables are injected by Docker at runtime.
    const dbConfig = {
      host: process.env.DB_HOST || 'db', // 'db' is the DNS name provided by Docker Bridge
      port: parseInt(process.env.DB_PORT || '5432', 10),
      user: process.env.DB_USER || 'postgres',
      password: process.env.DB_PASSWORD || 'secret_password',
      database: process.env.DB_NAME || 'app_db',
      // SSL is often required for cloud providers like Supabase, 
      // but can be disabled for local Docker development.
      ssl: process.env.NODE_ENV === 'production' ? { rejectUnauthorized: false } : false,
    };

    // 3. Initialize Connection Pool
    // Using a pool is crucial for performance in containerized environments.
    const pool = new Pool(dbConfig);

    // 4. Execute pgvector Similarity Search
    // We use the '<=>' operator (cosine distance) provided by the pgvector extension.
    // This query runs inside the 'db' container.
    const queryText = `
      SELECT content, 1 - (embedding <=> $1::vector) AS similarity
      FROM documents
      WHERE 1 - (embedding <=> $1::vector) > 0.7
      ORDER BY embedding <=> $1::vector
      LIMIT 5;
    `;

    const result = await pool.query(queryText, [JSON.stringify(queryEmbedding)]);

    // 5. Clean up connection
    await pool.end();

    // 6. Return results to the client
    return NextResponse.json({
      success: true,
      data: result.rows,
      source: 'Docker-Bridge-Resolved-DB'
    });

  } catch (error) {
    console.error('Database Connection Error:', error);
    
    // Specific error handling for Docker networking issues
    const errorMessage = (error as any).message;
    const isDnsError = errorMessage.includes('getaddrinfo ENOTFOUND db');
    
    return NextResponse.json(
      { 
        error: isDnsError 
          ? 'Docker DNS Resolution Failed: Ensure the database container is named "db" and attached to the same network.' 
          : 'Internal Server Error',
        details: errorMessage
      },
      { status: 500 }
    );
  }
}

// ============================================================================
// 3. DOCKER NETWORKING VISUALIZATION
// ============================================================================

/**
 * The following Graphviz DOT diagram illustrates the network topology 
 * described in the code above.
 * 
 * VISUALIZATION:
 * - The Host Machine runs the Docker Daemon.
 * - A Docker Bridge Network isolates the containers.
 * - The Next.js App container communicates with the DB container via the 
 *   internal bridge interface using the DNS name "db".
 */
const DOT_DIAGRAM = `


[ERROR: Failed to render diagram.]


`;

// ============================================================================
// 4. SCRIPT ARCHITECTURE BREAKDOWN
// ============================================================================

/**
 * 1. SERVICE WORKER LAYER (Client-Side)
 *    - **Purpose**: Handles the "Last Mile" of networking for AI assets.
 *    - **Logic**: Intercepts fetch requests for model files (.onnx, .bin).
 *    - **Benefit**: Drastically reduces bandwidth usage for heavy AI models.
 *    - **Docker Relation**: The Service Worker downloads assets served by the 
 *      Next.js container, caching them locally on the user's device.
 *
 * 2. API ROUTE LAYER (Server-Side)
 *    - **Purpose**: Acts as a secure bridge for sensitive operations.
 *    - **Logic**: 
 *      a. Receives a request from the client.
 *      b. Connects to the database using environment variables.
 *      c. Performs vector similarity search using pgvector.
 *    - **Benefit**: Keeps database credentials secure (never exposed to browser).
 *
 * 3. NETWORKING LAYER (Docker Infrastructure)
 *    - **DNS Resolution**: The code uses `process.env.DB_HOST || 'db'`. 
 *      In a Docker Compose file, we define a service named `db`. Docker's internal 
 *      DNS automatically maps this hostname to the container's IP address.
 *    - **Port Mapping**: 
 *      - The Next.js container exposes port 3000 to the host (e.g., `docker run -p 3000:3000`).
 *      - The Postgres container exposes port 5432 internally to the bridge network, 
 *        but NOT to the host (for security).
 *    - **Isolation**: The database is not accessible from the outside world directly; 
 *      it only accepts connections from the Next.js container on the bridge network.
 *
 * 4. ERROR HANDLING & DEBUGGING
 *    - The script specifically checks for `ENOTFOUND db`. This is a common error 
 *      when developers try to connect to `localhost` inside a container. 
 *      The error message guides the user to fix the Docker networking configuration.
 */
