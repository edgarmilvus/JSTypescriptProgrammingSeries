/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part12.ts
// Description: Solutions and Explanations
// ==========================================

import { Client } from 'pg';

// Connection string using the container name 'db-container' as the host
const connectionString = 'postgres://user:pass@db-container:5432/mydb';

const client = new Client({
  connectionString: connectionString,
});

async function runQuery() {
  try {
    console.log('Attempting to connect to database...');
    await client.connect();
    console.log('Connected successfully!');

    const res = await client.query('SELECT version()');
    console.log('Database Version:', res.rows[0].version);

  } catch (error) {
    console.error('Connection Error:', error);
  } finally {
    // Ensure client is closed in a real app, 
    // but for this demo we might leave it open or close it.
    await client.end();
  }
}

runQuery();
