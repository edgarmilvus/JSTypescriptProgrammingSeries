/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part14.ts
// Description: Solutions and Explanations
// ==========================================

# Build the app image
docker build -t node-db-app .

# Run the app on the internal-net
# We use --rm to automatically remove the container after it exits (since it's a script)
docker run --rm --network internal-net node-db-app

# --- Simulate Failure ---
# Disconnect the app from the network
# (Assuming the container ID is stored in a variable or found via docker ps)
# For this example, we run a new container specifically to disconnect it manually
docker run -d --name test-app --network internal-net node-db-app
docker network disconnect internal-net test-app

# Try to run the query again inside the disconnected container
# This will fail because the route to 'db-container' is lost
docker exec test-app ts-node app.ts

# --- Fix the Issue ---
docker network connect internal-net test-app
docker exec test-app ts-node app.ts

# Cleanup
docker stop test-app
docker rm test-app
docker network rm internal-net
