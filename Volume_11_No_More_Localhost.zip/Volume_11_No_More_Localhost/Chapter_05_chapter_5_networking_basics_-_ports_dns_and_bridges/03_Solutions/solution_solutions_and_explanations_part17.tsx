/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part17.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState, useEffect } from 'react';
import { ContainerNetworkInfo } from './types';
import { fetchContainerNetworkInfo } from './api';

interface Props {
  containerId: string;
}

export const NetworkStatusCard: React.FC<Props> = ({ containerId }) => {
  const [data, setData] = useState<ContainerNetworkInfo | null>(null);
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const loadData = async () => {
    setLoading(true);
    setError(null);
    try {
      const info = await fetchContainerNetworkInfo(containerId);
      setData(info);
    } catch (err) {
      setError('Failed to fetch network info');
    } finally {
      setLoading(false);
    }
  };

  // Load on mount
  useEffect(() => {
    loadData();
  }, [containerId]);

  if (loading) return <div className="card">Loading network stats...</div>;
  if (error) return <div className="card error">{error}</div>;
  if (!data) return null;

  return (
    <div className="card" style={{ border: '1px solid #ccc', padding: '16px', borderRadius: '8px' }}>
      <h3>Network Status: {data.containerName}</h3>
      <p><strong>Container ID:</strong> {data.containerId.substring(0, 12)}</p>
      <p><strong>Network:</strong> {data.networkName}</p>
      <p><strong>IP Address:</strong> {data.ipAddress}</p>
      <p><strong>Gateway:</strong> {data.gatewayIp}</p>
      
      <div style={{ marginTop: '10px' }}>
        <strong>Status: </strong>
        <span style={{ 
          color: data.isReachable ? 'green' : 'red', 
          fontWeight: 'bold' 
        }}>
          {data.isReachable ? 'ONLINE' : 'OFFLINE'}
        </span>
      </div>

      <button onClick={loadData} style={{ marginTop: '15px' }}>
        Refresh
      </button>
    </div>
  );
};
