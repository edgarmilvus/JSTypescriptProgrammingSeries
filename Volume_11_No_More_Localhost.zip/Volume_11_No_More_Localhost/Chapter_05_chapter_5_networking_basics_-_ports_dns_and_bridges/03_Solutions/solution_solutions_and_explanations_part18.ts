/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part18.ts
// Description: Solutions and Explanations
// ==========================================

digraph NetworkTopology {
    rankdir=TB;
    node [shape=box, style=filled, fillcolor=lightgray];

    // Host Node
    Host [shape=ellipse, fillcolor=lightblue, label="Host Machine\n(User's Browser)"];

    // Networks
    subgraph cluster_frontend_net {
        label = "Frontend Network (frontend-net)";
        style = dashed;
        color = blue;
        FrontendContainer [label="Frontend (Nginx/React)\nPort 80", fillcolor=white];
    }

    subgraph cluster_internal_net {
        label = "Internal Network (internal-net)";
        style = dashed;
        color = red;
        BackendContainer [label="Backend (Node.js)\nPort 3000", fillcolor=white];
        DBContainer [label="Database (PostgreSQL)\nPort 5432", fillcolor=white];
        CacheContainer [label="Cache (Redis)\nPort 6379", fillcolor=white];
    }

    // Connections
    // Host to Frontend (Port Mapping)
    Host -> FrontendContainer [label="8080:80", color="blue", fontcolor="blue"];

    // Frontend to Backend (Cross-network communication via Docker routing)
    // Note: In Docker, if frontend is on frontend-net and backend is on internal-net,
    // they cannot talk unless both are on a shared network. 
    // Requirement says "Frontend should only talk to backend".
    // To achieve this in Docker, the Frontend container must be connected to BOTH networks 
    // (frontend-net for external access, internal-net for backend comms).
    FrontendContainer -> BackendContainer [label="3000", color="green", fontcolor="green"];

    // Backend to Data Stores (Internal only)
    BackendContainer -> DBContainer [label="5432", color="black", fontcolor="black"];
    BackendContainer -> CacheContainer [label="6379", color="black", fontcolor="black"];
}
