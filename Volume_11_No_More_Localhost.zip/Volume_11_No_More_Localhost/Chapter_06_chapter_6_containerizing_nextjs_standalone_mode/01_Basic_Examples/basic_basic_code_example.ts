/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

# syntax=docker/dockerfile:1

# 1. Base Stage: Install dependencies
# We use the official Node.js Alpine Linux image for a small footprint.
# Alpine is a minimal Linux distribution, ideal for containerized applications.
FROM node:20-alpine AS base

# 2. Builder Stage: Build the Next.js application
# This stage isolates the build process, including dev dependencies.
FROM base AS builder
WORKDIR /app

# Copy package.json and package-lock.json to leverage Docker layer caching.
COPY package*.json ./
RUN npm ci

# Copy the rest of the application source code.
COPY . .

# Configure Next.js for standalone output.
# This bundles the necessary server files into a 'standalone' folder.
# We also set the output directory to 'standalone' for clarity.
ENV NEXT_TELEMETRY_DISABLED=1
RUN npm run build

# 3. Runner Stage: Create the final production image
# This stage starts from a fresh Alpine image to exclude build tools.
FROM base AS runner
WORKDIR /app

# Create a non-root user for security best practices.
RUN addgroup --system --gid 1001 nodejs
RUN adduser --system --uid 1001 --shell /bin/sh --no-create-home --ingroup nodejs nextjs

# Copy the standalone output from the builder stage.
# The 'standalone' folder contains the server, static assets, and a minimal node_modules.
COPY --from=builder --chown=nextjs:nodejs /app/.next/standalone ./
COPY --from=builder --chown=nextjs:nodejs /app/.next/static ./.next/static

# Expose the port the app will run on.
EXPOSE 3000

# Switch to the non-root user.
USER nextjs

# Define the command to run the app using the standalone server.
CMD ["node", "server.js"]
