/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

/**
 * @fileoverview Advanced Application Script for Next.js Standalone Docker Configuration.
 * 
 * This script generates a dynamic Next.js configuration and a Docker health check utility.
 * It ensures that the application is optimized for containerization, specifically targeting
 * the 'standalone' output mode which separates the core server from node_modules.
 * 
 * Usage:
 * 1. Run this script to generate 'next.config.js' and 'scripts/docker-healthcheck.ts'.
 * 2. The generated config enables 'output: "standalone"' for minimal Docker image size.
 * 3. The health check script provides a lightweight endpoint for Docker/K8s orchestration.
 */

import { writeFileSync, existsSync, mkdirSync } from 'fs';
import { join } from 'path';

// -----------------------------------------------------------------------------
// 1. Types & Interfaces
// -----------------------------------------------------------------------------

/**
 * Represents the structure of the Next.js configuration object.
 * We define this strictly to enforce best practices and type safety during generation.
 */
interface NextJsConfig {
  reactStrictMode: boolean;
  swcMinify: boolean;
  output?: 'standalone' | 'export';
  images?: {
    unoptimized?: boolean;
    remotePatterns?: {
      protocol: string;
      hostname: string;
    }[];
  };
  env?: Record<string, string>;
}

/**
 * Configuration for the Docker Health Check.
 * Defines the endpoint and expected status codes.
 */
interface HealthCheckConfig {
  endpoint: string;
  port: number;
  timeoutSeconds: number;
  intervalSeconds: number;
}

// -----------------------------------------------------------------------------
// 2. Configuration Constants
// -----------------------------------------------------------------------------

/**
 * Application Metadata.
 * In a real SaaS context, these would be injected via environment variables (CI/CD).
 */
const APP_ENV = {
  name: 'saas-analytics-platform',
  version: process.env.APP_VERSION || '1.0.0',
  nodeEnv: process.env.NODE_ENV || 'production',
};

/**
 * Next.js Configuration Builder.
 * 
 * Why 'standalone' mode?
 * - It creates a `.next/standalone` folder containing only the required code.
 * - It drastically reduces the Docker image size by excluding unused node_modules.
 * 
 * Why 'unoptimized' images?
 * - In a containerized environment, we often rely on a CDN or a separate image optimization service.
 * - Disabling the default Next.js image optimizer reduces CPU usage inside the container.
 */
const nextConfig: NextJsConfig = {
  reactStrictMode: true,
  swcMinify: true, // Uses Rust-based SWC for faster compilation
  output: 'standalone', // CRITICAL for Docker optimization
  images: {
    unoptimized: true, // Recommended for standalone mode to reduce container load
    remotePatterns: [
      {
        protocol: 'https',
        hostname: '**.unsplash.io', // Example: Allow specific image sources
      },
    ],
  },
  env: {
    APP_VERSION: APP_ENV.version,
  },
};

/**
 * Docker Health Check Configuration.
 * Kubernetes and Docker Swarm use this to determine if a container is ready to receive traffic.
 */
const healthCheckConfig: HealthCheckConfig = {
  endpoint: '/api/health',
  port: 3000,
  timeoutSeconds: 5,
  intervalSeconds: 30,
};

// -----------------------------------------------------------------------------
// 3. Script Logic: File Generators
// -----------------------------------------------------------------------------

/**
 * Generates the `next.config.js` file.
 * 
 * Note: We write to `next.config.js` rather than `next.config.ts` because Next.js
 * loads the config file in a separate context where TypeScript compilation might not be available
 * during the build phase in Docker (unless explicitly configured with `ts-node`).
 */
function generateNextConfig(): void {
  const configPath = join(process.cwd(), 'next.config.js');
  
  // We convert the TypeScript object to a string representation for the JS file.
  // We explicitly set 'standalone' mode here.
  const configContent = `
/** @type {import('next').NextConfig} */
const nextConfig = ${JSON.stringify(nextConfig, null, 2)};

module.exports = nextConfig;
`;

  try {
    writeFileSync(configPath, configContent, { encoding: 'utf-8' });
    console.log(`✅ Generated Next.js config at: ${configPath}`);
    console.log(`   Mode: ${nextConfig.output}`);
  } catch (error) {
    console.error('❌ Failed to generate next.config.js:', error);
    process.exit(1);
  }
}

/**
 * Generates a lightweight Health Check script.
 * 
 * Why a separate script?
 * - The Docker HEALTHCHECK instruction needs a command that exits with code 0 (healthy) or 1 (unhealthy).
 * - Using `curl` is common, but a Node.js script allows for more complex logic (e.g., checking DB connections)
 *   without adding heavy dependencies to the base image.
 */
function generateHealthCheckScript(): void {
  const scriptsDir = join(process.cwd(), 'scripts');
  const healthScriptPath = join(scriptsDir, 'docker-healthcheck.ts');

  // Ensure the scripts directory exists
  if (!existsSync(scriptsDir)) {
    mkdirSync(scriptsDir, { recursive: true });
  }

  const healthScriptContent = `
/**
 * Docker Health Check Utility
 * 
 * This script checks if the Next.js application is responsive.
 * It is designed to be lightweight and has zero external dependencies.
 * 
 * Usage in Dockerfile:
 * HEALTHCHECK --interval=${healthCheckConfig.intervalSeconds}s --timeout=${healthCheckConfig.timeoutSeconds}s \\
 *   CMD node /app/scripts/docker-healthcheck.js
 */

import http from 'http';

const options = {
  host: 'localhost',
  port: ${healthCheckConfig.port},
  path: '${healthCheckConfig.endpoint}',
  timeout: ${healthCheckConfig.timeoutSeconds} * 1000,
};

const request = http.request(options, (res) => {
  console.log(\`STATUS: \${res.statusCode}\`);
  if (res.statusCode === 200) {
    process.exit(0); // Healthy
  } else {
    process.exit(1); // Unhealthy
  }
});

request.on('error', (err) => {
  console.log('ERROR:', err.message);
  process.exit(1); // Unhealthy
});

request.on('timeout', () => {
  console.log('TIMEOUT');
  request.destroy();
  process.exit(1); // Unhealthy
});

request.end();
`;

  try {
    writeFileSync(healthScriptPath, healthScriptContent, { encoding: 'utf-8' });
    console.log(`✅ Generated Health Check script at: ${healthScriptPath}`);
  } catch (error) {
    console.error('❌ Failed to generate health check script:', error);
    process.exit(1);
  }
}

// -----------------------------------------------------------------------------
// 4. Execution Entry Point
// -----------------------------------------------------------------------------

/**
 * Main execution function.
 * Orchestrates the generation of all required Docker artifacts.
 */
function main(): void {
  console.log('🚀 Starting Advanced Application Script for Docker Containerization...');
  console.log(\`   Environment: \${APP_ENV.nodeEnv}\`);
  
  // 1. Generate Next.js Configuration
  generateNextConfig();
  
  // 2. Generate Docker Health Check
  generateHealthCheckScript();
  
  console.log('✅ All artifacts generated successfully.');
  console.log('   Next step: Build the Docker image using the standalone mode.');
}

// Execute the script
if (require.main === module) {
  main();
}
