/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// next.config.js

/** @type {import('next').NextConfig} */
const nextConfig = {
  // Enable standalone output mode to generate a minimal server build
  output: 'standalone',
  
  // Optional: Ensure static assets are copied to the standalone folder
  // Note: Next.js 14+ automatically copies public assets in standalone mode,
  // but explicit configuration ensures compatibility across versions.
  experimental: {
    // This ensures the standalone folder includes the public directory
    // and other necessary files for the server to serve static assets.
    // In older versions, manual copying via a script might be required.
  },
};

/**
 * BENEFIT FOR DOCKER:
 * The standalone mode creates a .next/standalone folder containing:
 * - server.js: A custom Node.js server entry point.
 * - static/: Optimized static assets (CSS, JS chunks).
 * - .next/: Minimal runtime files (excluding source code and heavy dev dependencies).
 * 
 * This structure significantly reduces the final Docker image size because:
 * 1. It excludes the entire source code directory (except what's needed for runtime).
 * 2. It excludes devDependencies (like TypeScript, ESLint, Jest).
 * 3. It allows the runner stage to copy only ~50MB of artifacts instead of the full project.
 * 4. The server.js entry point is lightweight and optimized for production execution.
 */

module.exports = nextConfig;
