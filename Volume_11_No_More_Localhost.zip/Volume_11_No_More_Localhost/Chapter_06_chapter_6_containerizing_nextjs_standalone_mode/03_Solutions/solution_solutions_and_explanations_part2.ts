/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

# Dockerfile

# Stage 1: Builder
# Use a full Node.js image to install dependencies and build the app.
FROM node:20-alpine AS builder

# Set working directory
WORKDIR /app

# Copy package files
COPY package*.json ./
COPY next.config.js ./

# Install ALL dependencies (including devDependencies for building)
# --prefer-offline and --no-audit speed up the install
RUN npm ci --prefer-offline --no-audit

# Copy the entire source code
COPY . .

# Run the build command. 
# This generates the .next/standalone folder (thanks to output: 'standalone')
RUN npm run build

# Stage 2: Runner
# Use a minimal Node.js image for the production runtime.
FROM node:20-alpine AS runner

WORKDIR /app

# Install only production dependencies. 
# We need this to run the server.js file generated in standalone mode.
COPY package*.json ./
RUN npm ci --only=production --omit=dev --no-audit --prefer-offline

# Copy the standalone artifacts from the builder stage
# This includes server.js, static assets, and the minimal .next runtime folder
COPY --from=builder /app/.next/standalone ./

# Copy the public folder (if not automatically handled by Next.js standalone)
# Note: Next.js 14+ usually handles this, but explicit copying is safer.
COPY --from=builder /app/public ./public

# Copy the .next/static folder (required for client-side JS/CSS chunks)
# Standalone mode puts static assets in .next/static, which must be served.
COPY --from=builder /app/.next/static ./.next/static

# Expose the port the server will run on
EXPOSE 3000

# Set environment variable (optional but good practice)
ENV NODE_ENV=production

# Command to run the standalone server
# Note: We run 'node server.js' directly, NOT 'next start'
CMD ["node", "server.js"]
