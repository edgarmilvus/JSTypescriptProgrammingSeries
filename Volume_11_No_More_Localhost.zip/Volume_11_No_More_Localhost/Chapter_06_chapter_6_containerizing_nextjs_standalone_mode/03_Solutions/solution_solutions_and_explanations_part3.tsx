/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

// ContainerStatusCard.tsx

import React from 'react';

// 1. Define the ContainerMetrics interface
export interface ContainerMetrics {
  id: string;
  name: string;
  cpuUsage: number; // percentage
  memoryUsage: number; // MB
  status: 'running' | 'stopped' | 'restarting';
}

// 2. Define the props interface using Partial<ContainerMetrics>
interface Props {
  metrics: Partial<ContainerMetrics>;
}

export const ContainerStatusCard: React.FC<Props> = ({ metrics }) => {
  // 3. Conditional Rendering: Check for ID existence
  if (!metrics.id) {
    return (
      <div className="border rounded p-4 shadow-sm bg-gray-50 animate-pulse">
        <div className="h-4 bg-gray-300 rounded w-1/3 mb-2"></div>
        <div className="h-4 bg-gray-300 rounded w-1/2"></div>
      </div>
    );
  }

  // 4. Formatting Logic
  const formattedCpu = metrics.cpuUsage !== undefined 
    ? `${metrics.cpuUsage.toFixed(1)}%` 
    : 'N/A';
    
  const formattedMemory = metrics.memoryUsage !== undefined 
    ? `${metrics.memoryUsage.toFixed(2)} MB` 
    : 'N/A';

  // 5. Status Indicator Logic
  const getStatusColor = (status: string | undefined) => {
    switch (status) {
      case 'running': return 'bg-green-100 text-green-800 border-green-200';
      case 'stopped': return 'bg-red-100 text-red-800 border-red-200';
      case 'restarting': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const statusClass = getStatusColor(metrics.status);

  return (
    <div className="border rounded p-4 shadow-sm bg-white hover:shadow-md transition-shadow">
      <div className="flex justify-between items-center mb-3">
        <h3 className="font-bold text-lg text-gray-800">{metrics.name || 'Unknown Container'}</h3>
        <span className={`px-2 py-1 rounded-full text-xs font-semibold border ${statusClass}`}>
          {metrics.status || 'Unknown'}
        </span>
      </div>
      
      <div className="grid grid-cols-2 gap-4 text-sm">
        <div className="bg-gray-50 p-2 rounded">
          <span className="block text-gray-500 text-xs">CPU Usage</span>
          <span className="font-mono font-medium">{formattedCpu}</span>
        </div>
        <div className="bg-gray-50 p-2 rounded">
          <span className="block text-gray-500 text-xs">Memory</span>
          <span className="font-mono font-medium">{formattedMemory}</span>
        </div>
      </div>
    </div>
  );
};
