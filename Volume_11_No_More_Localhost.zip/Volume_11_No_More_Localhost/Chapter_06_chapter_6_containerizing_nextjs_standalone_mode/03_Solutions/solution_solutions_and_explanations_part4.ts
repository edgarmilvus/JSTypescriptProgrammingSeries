/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

// dockerfile-schema.ts

/**
 * JSON Schema for Dockerfile Generation Response.
 * This schema ensures the LLM returns structured data that can be validated.
 */
export const dockerfileSchema = {
  $schema: "http://json-schema.org/draft-07/schema#",
  type: "object",
  properties: {
    baseImage: {
      type: "string",
      description: "The base Docker image to use (e.g., 'node:20-alpine')."
    },
    stage: {
      type: "string",
      enum: ["builder", "runner"],
      description: "The build stage this snippet belongs to."
    },
    instructions: {
      type: "array",
      items: {
        type: "string"
      },
      description: "An ordered list of Dockerfile commands (e.g., 'WORKDIR /app')."
    },
    exposedPort: {
      type: "integer",
      description: "The network port the application listens on.",
      minimum: 1,
      maximum: 65535
    }
  },
  required: ["baseImage", "stage", "instructions", "exposedPort"],
  additionalProperties: false,
};

/**
 * TypeScript Interface
 * Mirrors the JSON Schema to enable type-safe handling of the LLM response.
 */
export interface DockerfileResponse {
  baseImage: string;
  stage: 'builder' | 'runner';
  instructions: string[];
  exposedPort: number;
}

/**
 * PROMPT CONSTRUCTION STRATEGY:
 * To ensure the LLM adheres to this structure, the system prompt should include:
 * 
 * "You are a Dockerfile generator. You must respond with a JSON object 
 * strictly adhering to the following schema. Do not include any markdown 
 * formatting or conversational text outside the JSON object.
 * 
 * Schema:
 * ${JSON.stringify(dockerfileSchema, null, 2)}
 * 
 * Example Response:
 * {
 *   \"baseImage\": \"node:20-alpine\",
 *   \"stage\": \"builder\",
 *   \"instructions\": [\"WORKDIR /app\", \"COPY package*.json ./\", \"RUN npm ci\"],
 *   \"exposedPort\": 3000
 * }"
 */
