/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

// docker-build-pipeline.dot

digraph DockerBuildPipeline {
    rankdir=LR; // Layout from Left to Right
    node [shape=box, style="rounded,filled", fontname="Helvetica"];

    // Define Nodes
    source [label="Source Code\n(Local Directory)", fillcolor="#e3f2fd", shape=folder];
    
    builder [label="Builder Stage\n(Node.js Alpine)", fillcolor="#fff3e0"];
    
    artifacts [label="Artifacts\n(.next/standalone, public)", fillcolor="#e8f5e9", shape=note];
    
    runner [label="Runner Stage\n(Minimal Node.js)", fillcolor="#fce4ec"];
    
    dockerHost [label="Docker Host\n(Running Container)", fillcolor="#f3e5f5", shape=ellipse];

    // Define Edges and Data Flow
    source -> builder [
        label="Copy Context\n(package.json, src, config)", 
        fontcolor="#555", 
        color="#555"
    ];

    builder -> artifacts [
        label="Generate Build Output\n(npm run build)", 
        fontcolor="#555", 
        color="#555",
        style="dashed"
    ];

    artifacts -> runner [
        label="Copy Artifacts\n(.next/standalone, public)", 
        fontcolor="#555", 
        color="#555"
    ];

    runner -> dockerHost [
        label="Deploy Image\n(CMD: node server.js)", 
        fontcolor="#555", 
        color="#555",
        style="bold"
    ];

    // Subgraph for logical grouping (Optional visual aid)
    subgraph cluster_build {
        label = "Build Phase";
        style = "dashed";
        source;
        builder;
    }
    
    subgraph cluster_runtime {
        label = "Runtime Phase";
        style = "dashed";
        runner;
        dockerHost;
    }
}
