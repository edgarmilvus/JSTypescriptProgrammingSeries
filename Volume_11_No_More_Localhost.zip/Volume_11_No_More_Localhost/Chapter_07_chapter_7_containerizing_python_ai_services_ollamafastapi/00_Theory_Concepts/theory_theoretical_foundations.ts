/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: theory_theoretical_foundations.ts
// Description: Theoretical Foundations
// ==========================================

// A conceptual representation of a Dockerfile's layered structure
// This is NOT executable code, but a conceptual model of the build process.
// Each FROM, COPY, RUN instruction creates a new immutable layer in the final image.

// Layer 1: Base Image (e.g., a minimal Linux distribution with Python)
// This layer is cached. If we change our code, we don't need to re-download this.
FROM python:3.10-slim

// Layer 2: Install system dependencies
// This layer is cached if the base image or the dependency list doesn't change.
RUN apt-get update && apt-get install -y some-system-library

// Layer 3: Copy requirements and install Python packages
// This layer is cached if requirements.txt hasn't changed.
COPY requirements.txt .
RUN pip install -r requirements.txt

// Layer 4: Copy application source code
// This is the layer that changes most frequently during development.
COPY . /app

// Set the command to run when the container starts
CMD ["uvicorn", "main:app", "--host", "0.0.0.0"]
