/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part2.ts
// Description: Theoretical Foundations
// ==========================================

// Conceptual representation of a multi-stage build process.
// Stage 1: The Builder
// This stage has all the tools needed to build the application.
// It's a large, heavy environment.
FROM python:3.10 AS builder

WORKDIR /app
COPY requirements.txt .
// Install dependencies into a virtual environment within the container
RUN pip install --user -r requirements.txt

// Stage 2: The Final Image
// This stage is minimal and optimized for runtime.
FROM python:3.10-slim

WORKDIR /app
// Copy only the installed packages from the builder stage
COPY --from=builder /root/.local /root/.local
// Copy the application source code
COPY . .

// Ensure the user's local bin is in the PATH
ENV PATH=/root/.local/bin:$PATH

// The final command to run the application
CMD ["uvicorn", "main:app", "--host", "0.0.0.0"]
