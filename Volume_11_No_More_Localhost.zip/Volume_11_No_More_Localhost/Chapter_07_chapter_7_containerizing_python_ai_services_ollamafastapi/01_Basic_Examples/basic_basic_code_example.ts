/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

// File: app/api/chat/route.ts
// This file handles HTTP requests for the AI chat feature.

import { NextRequest, NextResponse } from 'next/server';
import { StreamingTextResponse, CoreMessage } from 'ai';

/**
 * IMPORTANT: This code assumes the 'ai' package is installed:
 * npm install ai
 * 
 * It also assumes Ollama is running locally (default port 11434).
 * 
 * @param request - The incoming HTTP request from the client.
 * @returns A StreamingTextResponse that the client can consume as a stream.
 */
export async function POST(request: NextRequest) {
  try {
    // 1. Parse the incoming JSON body from the client.
    // The client (using Vercel AI SDK's useChat hook) sends an array of messages.
    const { messages } = await request.json();

    // 2. Extract the latest user prompt from the conversation history.
    // In a real app, you might send the full history, but for this example,
    // we grab the last message to keep it simple.
    const lastMessage: CoreMessage = messages[messages.length - 1];

    // 3. Prepare the payload for the Ollama API.
    // Ollama expects a specific JSON structure for generating responses.
    const ollamaPayload = {
      model: 'llama2', // The model name running in your Ollama container
      prompt: lastMessage.content, // The user's text input
      stream: true, // CRITICAL: Enable streaming for real-time responses
      options: {
        temperature: 0.7, // Controls randomness (0.0 to 1.0)
      },
    };

    // 4. Forward the request to the Ollama container.
    // We use fetch to call the Ollama API endpoint.
    // Note: 'OLLAMA_HOST' should be configured in your .env file (e.g., http://localhost:11434)
    const ollamaResponse = await fetch(`${process.env.OLLAMA_HOST || 'http://localhost:11434'}/api/generate`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(ollamaPayload),
    });

    // 5. Handle potential errors from the Ollama service.
    if (!ollamaResponse.ok) {
      throw new Error(`Ollama API error: ${ollamaResponse.statusText}`);
    }

    // 6. Create a ReadableStream to process the Ollama response chunks.
    // Ollama sends JSON objects line-by-line. We need to parse these and extract the 'response' field.
    const stream = new ReadableStream({
      async start(controller) {
        // Get a reader to consume the Ollama response body
        const reader = ollamaResponse.body?.getReader();
        if (!reader) {
          controller.close();
          return;
        }

        const decoder = new TextDecoder();
        try {
          while (true) {
            const { done, value } = await reader.read();
            if (done) break;

            // Decode the chunk (Uint8Array) to a string
            const chunk = decoder.decode(value, { stream: true });
            
            // Ollama sends JSON objects separated by newlines. 
            // We split by newline to handle potential multiple objects in one chunk.
            const lines = chunk.split('\n').filter((line) => line.trim() !== '');

            for (const line of lines) {
              try {
                const parsed = JSON.parse(line);
                if (parsed.response) {
                  // Enqueue the text content to the stream
                  controller.enqueue(parsed.response);
                }
              } catch (e) {
                // Ignore malformed JSON lines (e.g., empty lines)
                continue;
              }
            }
          }
          controller.close();
        } catch (error) {
          controller.error(error);
        }
      },
    });

    // 7. Return the stream to the client using the Vercel AI SDK helper.
    // This sets the correct headers (Content-Type: text/plain; charset=utf-8) and
    // handles the streaming logic for the client-side SDK.
    return new StreamingTextResponse(stream);

  } catch (error) {
    // 8. Global error handling for the API route.
    console.error('Error in chat API route:', error);
    return NextResponse.json(
      { error: 'Internal Server Error' },
      { status: 500 }
    );
  }
}
