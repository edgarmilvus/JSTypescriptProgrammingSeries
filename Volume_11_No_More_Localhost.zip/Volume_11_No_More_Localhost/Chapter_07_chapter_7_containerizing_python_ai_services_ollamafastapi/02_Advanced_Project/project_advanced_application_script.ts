/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

/**
 * ==============================================================================
 * ADVANCED APPLICATION SCRIPT: PARALLEL AI AGENT ORCHESTRATION
 * ==============================================================================
 * Context: Chapter 7 - Containerizing Python AI Services (Ollama/FastAPI)
 * 
 * Objective:
 * Demonstrate a Next.js API route that orchestrates parallel tool calls to 
 * containerized AI services. This script handles the aggregation of results 
 * into a Graph State and persists the context via a Vector Store interface.
 * 
 * Dependencies (assumed installed):
 * - @langchain/langgraph
 * - @langchain/core
 * - zod
 * - langchain
 * ==============================================================================
 */

import { NextResponse } from 'next/server';
import { StateGraph, Annotation, NodeInterrupt } from '@langchain/langgraph';
import { BaseMessage, HumanMessage, AIMessage } from '@langchain/core/messages';
import { z } from 'zod';

// ==============================================================================
// 1. GRAPH STATE DEFINITION
// ==============================================================================
// The Graph State is the canonical data structure passed between nodes.
// We use Zod for strict typing to ensure data integrity across container boundaries.

const GraphStateAnnotation = Annotation.Root({
  // The conversation history
  messages: Annotation<BaseMessage[]>({
    reducer: (curr, update) => curr.concat(update),
    default: () => [],
  }),
  // The specific code snippet provided by the user
  codeSnippet: Annotation<string>({
    reducer: (curr, update) => update ?? curr,
    default: () => '',
  }),
  // Aggregated output from parallel tools
  analysisResults: Annotation<{
    review: string;
    documentation: string;
  }>({
    reducer: (curr, update) => ({ ...curr, ...update }),
    default: () => ({ review: '', documentation: '' }),
  }),
  // Flag to trigger vector store persistence
  shouldPersist: Annotation<boolean>({
    reducer: (curr, update) => update ?? curr,
    default: () => false,
  }),
});

type GraphState = typeof GraphStateAnnotation.State;

// ==============================================================================
// 2. TOOL DEFINITIONS (SIMULATED CONTAINERIZED SERVICES)
// ==============================================================================
/**
 * In a real production environment, these functions would make HTTP requests 
 * to containerized services:
 * 
 * 1. Ollama Service (e.g., http://ollama-container:11434/api/generate)
 *    - Handles heavy LLM inference (Code Review / Doc Generation).
 * 2. FastAPI Service (e.g., http://fastapi-vector-service:8000/vectors)
 *    - Handles vector storage and retrieval via pgvector/Milvus.
 * 
 * Here, we mock the network latency and response structure to focus on the 
 * orchestration logic (LangGraph).
 */

/**
 * Simulates a request to a containerized Ollama instance for code review.
 * Why parallel? Code review and documentation require different reasoning 
 * paths; running them concurrently reduces total latency.
 */
async function callCodeReviewAgent(state: GraphState): Promise<{ review: string }> {
  console.log(`[Ollama Container] Processing Code Review for snippet: ${state.codeSnippet.substring(0, 20)}...`);
  
  // Simulate network delay (e.g., 1.5s for LLM inference)
  await new Promise(resolve => setTimeout(resolve, 1500));

  // Mock response from the LLM
  return {
    review: "CRITICAL: Potential memory leak in loop. SUGGESTION: Use `useEffect` cleanup."
  };
}

/**
 * Simulates a request to a containerized Ollama instance for documentation.
 */
async function callDocGeneratorAgent(state: GraphState): Promise<{ documentation: string }> {
  console.log(`[Ollama Container] Generating Documentation...`);
  
  // Simulate network delay
  await new Promise(resolve => setTimeout(resolve, 1500));

  return {
    documentation: "## Function Analysis\nThis function calculates the sum of an array. It accepts an array of numbers and returns a number."
  };
}

/**
 * Simulates a request to a FastAPI container wrapping a Vector Store (e.g., pgvector).
 * This persists the aggregated Graph State for semantic search in future interactions.
 */
async function persistToVectorStore(state: GraphState): Promise<boolean> {
  console.log(`[FastAPI/Vector Store] Persisting state context to vector database...`);
  
  // In a real scenario, we would POST to http://fastapi-service:8000/ingest
  // with payload: { content: state.analysisResults, embedding: [...] }
  
  await new Promise(resolve => setTimeout(resolve, 500));
  return true;
}

// ==============================================================================
// 3. LANGGRAPH NODES
// ==============================================================================
// Nodes encapsulate the logic for invoking tools or processing state.

/**
 * Router Node: Determines if parallel execution is needed.
 * In a full implementation, this would be an LLM call deciding tool usage.
 * For this demo, we hardcode the trigger for parallel execution.
 */
async function routerNode(state: GraphState): Promise<GraphState> {
  // If code snippet exists, trigger parallel agents
  if (state.codeSnippet && state.analysisResults.review === '') {
    return { 
      ...state, 
      messages: [new AIMessage("Initiating parallel analysis...")] 
    };
  }
  return state;
}

/**
 * Parallel Node A: Code Reviewer
 * Executes the specific tool and updates the state.
 */
async function reviewerNode(state: GraphState): Promise<Partial<GraphState>> {
  const result = await callCodeReviewAgent(state);
  return { analysisResults: { review: result.review, documentation: '' } };
}

/**
 * Parallel Node B: Documentation Generator
 * Executes the specific tool and updates the state.
 */
async function documenterNode(state: GraphState): Promise<Partial<GraphState>> {
  const result = await callDocGeneratorAgent(state);
  return { analysisResults: { review: '', documentation: result.documentation } };
}

/**
 * Aggregator Node: Merges Parallel Results
 * Since LangGraph reducers handle merging, this node acts as a checkpoint 
 * to verify completion or format the final output.
 */
async function aggregatorNode(state: GraphState): Promise<GraphState> {
  const hasReview = state.analysisResults.review !== '';
  const hasDocs = state.analysisResults.documentation !== '';

  if (hasReview && hasDocs) {
    console.log("Parallel execution complete. Results merged.");
    return { 
      ...state, 
      shouldPersist: true,
      messages: [new AIMessage("Analysis complete. Persisting to vector store.")] 
    };
  }
  
  // If one tool failed or hasn't finished (unlikely in this sync mock), 
  // we could trigger a retry or interrupt.
  throw new NodeInterrupt("Waiting for parallel tools to complete.");
}

/**
 * Persistence Node: Vector Store Ingestion
 * Connects to the FastAPI container to store the Graph State context.
 */
async function storageNode(state: GraphState): Promise<GraphState> {
  if (!state.shouldPersist) return state;

  const success = await persistToVectorStore(state);
  
  if (success) {
    return {
      ...state,
      messages: [new AIMessage("Context successfully stored in Vector DB.")],
      shouldPersist: false
    };
  }
  
  return state;
}

// ==============================================================================
// 4. WORKFLOW ORCHESTRATION (LANGGRAPH DEFINITION)
// ==============================================================================
// We define the graph structure here. Note the edges allow for conditional 
// routing and parallel execution.

function createWorkflow() {
  const workflow = new StateGraph(GraphStateAnnotation);

  // Define Nodes
  workflow.addNode('router', routerNode);
  workflow.addNode('code_reviewer', reviewerNode);
  workflow.addNode('doc_generator', documenterNode);
  workflow.addNode('aggregator', aggregatorNode);
  workflow.addNode('vector_store', storageNode);

  // Define Edges
  // Start -> Router
  workflow.setEntryPoint('router');

  // Router -> Parallel Nodes (Fan-out)
  // In LangGraph, we connect the router to multiple nodes to achieve parallelism.
  // The graph runtime will execute these concurrently if they don't share dependencies.
  workflow.addEdge('router', 'code_reviewer');
  workflow.addEdge('router', 'doc_generator');

  // Parallel Nodes -> Aggregator (Join)
  // We use a conditional edge or a shared node to wait for completion.
  // Here, we route both parallel nodes to the aggregator.
  // Note: In complex graphs, we might use `addConditionalEdges` to wait for specific state updates.
  workflow.addEdge('code_reviewer', 'aggregator');
  workflow.addEdge('doc_generator', 'aggregator');

  // Aggregator -> Vector Store
  workflow.addEdge('aggregator', 'vector_store');

  // Vector Store -> End
  workflow.setFinishPoint('vector_store');

  return workflow.compile();
}

// ==============================================================================
// 5. NEXT.JS API ROUTER HANDLER
// ==============================================================================
// This is the entry point for the web application.

export async function POST(request: Request) {
  try {
    const { codeSnippet } = await request.json();

    if (!codeSnippet) {
      return NextResponse.json(
        { error: "Code snippet is required." }, 
        { status: 400 }
      );
    }

    // Initialize the Graph
    const app = createWorkflow();

    // Initial State
    const initialState: GraphState = {
      messages: [new HumanMessage("Please analyze this code.")],
      codeSnippet: codeSnippet,
      analysisResults: { review: '', documentation: '' },
      shouldPersist: false,
    };

    // Execute the Graph
    // The `stream` method handles the async execution of nodes.
    // We await the full execution for this API response.
    const stream = await app.stream(initialState);
    
    let finalState: GraphState | null = null;

    // Consume the stream to get the final state
    for await (const step of stream) {
      // Optional: Log steps for debugging
      // console.log(`Step: ${Object.keys(step)[0]}`);
      const lastKey = Object.keys(step)[0];
      finalState = step[lastKey];
    }

    if (!finalState) {
      return NextResponse.json({ error: "Workflow failed to execute." }, { status: 500 });
    }

    // Return the aggregated results from the Graph State
    return NextResponse.json({
      status: 'success',
      analysis: finalState.analysisResults,
      contextStored: !finalState.shouldPersist, // Should be false if stored successfully
      conversationHistoryLength: finalState.messages.length,
    });

  } catch (error) {
    console.error("Workflow Error:", error);
    return NextResponse.json(
      { error: "Internal Server Error", details: (error as Error).message }, 
      { status: 500 }
    );
  }
}
