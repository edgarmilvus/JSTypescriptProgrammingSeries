/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

digraph Architecture {
    rankdir=TB;
    node [shape=box, style=filled];

    // Define Nodes
    User_Browser [label="User Browser\n(React Frontend)", fillcolor="#ffcccc"];
    FastAPI_Backend [label="FastAPI Backend\n(Python Container)", fillcolor="#ccffcc"];
    Ollama_Service [label="Ollama Service\n(LLM Container)", fillcolor="#ffffcc"];
    Redis_Cache [label="Redis Cache\n(Key-Value Store)", fillcolor="#ffccff", shape=cylinder];
    Host_GPU [label="Host GPU\n(NVIDIA)", fillcolor="#eeeeee", shape=ellipse];

    // Define Edges / Data Flow
    User_Browser -> FastAPI_Backend [label="HTTP Request\n(Port 8000)"];
    
    // Logic: Check Cache -> If Miss -> Call Ollama
    FastAPI_Backend -> Redis_Cache [label="1. Check Cache\n(GET key)", style=dashed];
    FastAPI_Backend -> Ollama_Service [label="2. Generate (If Miss)\n(HTTP /api/generate\nPort 11434)"];
    
    // Ollama requires GPU
    Ollama_Service -> Host_GPU [label="CUDA / GPU Access", style=dashed];

    // Grouping Container Boundaries
    subgraph cluster_0 {
        label = "Container 1: Frontend";
        style = dashed;
        User_Browser;
    }

    subgraph cluster_1 {
        label = "Container 2: Backend API";
        style = dashed;
        FastAPI_Backend;
    }

    subgraph cluster_2 {
        label = "Container 3: Inference Engine";
        style = dashed;
        Ollama_Service;
    }

    subgraph cluster_3 {
        label = "Container 4: Data Store";
        style = dashed;
        Redis_Cache;
    }
}
