/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

# ==========================================
# STAGE 1: The Builder
# Purpose: Install ALL dependencies and compile TypeScript.
# This image is temporary and discarded after build.
# ==========================================
FROM node:20-alpine AS builder

# Set working directory inside the container
WORKDIR /app

# 1. Copy dependency definitions first to leverage Docker layer caching
COPY package*.json ./

# 2. Install EVERYTHING (including devDependencies for TypeScript compilation)
# We use the 'frozen-lockfile' flag for production stability
RUN npm ci

# 3. Copy the rest of the source code
COPY . .

# 4. Run the build script (assumes package.json has "build": "tsc")
RUN npm run build

# 5. Prune devDependencies to reduce the size of the artifacts we copy over
# This step is optional but recommended for maximum optimization
RUN npm prune --production

# ==========================================
# STAGE 2: The Runner
# Purpose: Run the compiled application.
# This is the only image that gets pushed to the registry.
# ==========================================
FROM node:20-alpine AS runner

# Set working directory
WORKDIR /app

# 1. Copy the package files again (so we can install ONLY production deps cleanly)
COPY package*.json ./

# 2. Install ONLY production dependencies (lightweight, no TypeScript)
RUN npm ci --production

# 3. COPY THE ARTIFACTS from the builder stage
# We copy the compiled JS files from /app/dist and the node_modules
COPY --from=builder /app/dist ./dist
# If you had static assets, you'd copy them here too: COPY --from=builder /app/public ./public

# 4. Security: Run as a non-root user (best practice)
RUN addgroup -g 1001 -S nodejs
RUN adduser -S nextjs -u 1001
USER nextjs

# 5. Expose the port the app runs on
EXPOSE 3000

# 6. The command to run the compiled app
CMD ["node", "dist/index.js"]
