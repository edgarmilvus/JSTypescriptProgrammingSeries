/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

# Stage 1: Builder
# Uses a full Node.js image to compile native modules and install dependencies.
FROM node:18 AS builder

# Set working directory
WORKDIR /app

# Copy package.json and package-lock.json first to leverage Docker cache
COPY package*.json ./

# Install ALL dependencies (including devDependencies and build tools)
RUN npm ci

# Copy source code
COPY . .

# Run the build script (if applicable, e.g., for TypeScript)
# If purely JS, this step might be skipped, but included for completeness
# RUN npm run build

# Stage 2: Final
# Uses a minimal Alpine image for a smaller footprint and reduced attack surface
FROM node:18-alpine AS final

# Install dumb-init to handle signal propagation properly
RUN apk add --no-cache dumb-init

# Create a non-root user 'node' (already exists in node:18-alpine, but ensuring ownership)
RUN addgroup -g 1001 -S nodejs && adduser -S nodejs -u 1001

# Set working directory
WORKDIR /app

# Copy package.json and package-lock.json again (needed for npm ci --production)
COPY package*.json ./

# Install ONLY production dependencies
# --only=production skips devDependencies
# We use npm ci here for deterministic builds, though npm install --production works too
RUN npm ci --only=production && npm cache clean --force

# Copy compiled code and node_modules from the builder stage
COPY --from=builder /app/node_modules ./node_modules
COPY --from=builder /app/src ./src
# If you had a build step (e.g., TypeScript compiled to dist), copy that instead:
# COPY --from=builder /app/dist ./dist

# Change ownership of the app directory to the non-root user
RUN chown -R nodejs:nodejs /app

# Switch to the non-root user
USER nodejs

# Use dumb-init as the entrypoint to forward signals (like SIGTERM) to Node.js
ENTRYPOINT ["dumb-init", "--"]

# Start the application
# Assuming the entry file is src/index.js
CMD ["node", "src/index.js"]
