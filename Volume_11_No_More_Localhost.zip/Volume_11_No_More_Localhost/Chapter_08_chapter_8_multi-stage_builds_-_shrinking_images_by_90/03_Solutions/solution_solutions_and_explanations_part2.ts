/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

# Stage 1: Frontend Builder
# Build the React static assets
FROM node:18-alpine AS frontend-builder

WORKDIR /app/frontend

COPY ./frontend/package*.json ./
RUN npm ci

COPY ./frontend/ .
RUN npm run build

# Stage 2: Backend Builder
# Install Python dependencies and PyTorch
FROM python:3.9-slim AS backend-builder

WORKDIR /app/backend

# Install build tools if required for specific C++ extensions
# (PyTorch wheels usually handle this, but good practice for custom C++ code)
RUN apt-get update && apt-get install -y build-essential && rm -rf /var/lib/apt/lists/*

COPY ./backend/requirements.txt .
# Install dependencies into the stage
RUN pip install --no-cache-dir -r requirements.txt

COPY ./backend/ .

# Stage 3: Final
# Combine artifacts and run the server
FROM python:3.9-slim AS final

# Set environment variables for Python optimization
ENV PYTHONUNBUFFERED=1 \
    PYTHONDONTWRITEBYTECODE=1 \
    PIP_NO_CACHE_DIR=1 \
    PIP_DISABLE_PIP_VERSION_CHECK=1

WORKDIR /app

# Install runtime dependencies only (no build-essential)
COPY ./backend/requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

# Copy the backend application code
COPY ./backend/ ./backend

# Copy the built React static files from the frontend-builder stage
COPY --from=frontend-builder /app/frontend/build ./backend/static

# Install Gunicorn (WSGI server) if not in requirements.txt
RUN pip install gunicorn

# Expose the port the app runs on
EXPOSE 8000

# Healthcheck to verify API responsiveness
HEALTHCHECK --interval=30s --timeout=3s --start-period=5s --retries=3 \
    CMD curl -f http://localhost:8000/health || exit 1

# Command to run the application using Gunicorn
# Assuming the Flask app instance is named 'app' in 'main.py'
CMD ["gunicorn", "--bind", "0.0.0.0:8000", "--workers", "2", "backend.main:app"]
