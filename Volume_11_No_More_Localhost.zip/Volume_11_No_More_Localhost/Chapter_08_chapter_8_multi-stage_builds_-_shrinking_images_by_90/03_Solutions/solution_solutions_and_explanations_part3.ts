/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

// server.ts
import express from 'express';
import path from 'path';

const app = express();
const PORT = process.env.PORT || 3000;
// In the Docker container, the build output is usually copied to /app/dist or similar
// Adjusting path to point to the copied React build directory
const BUILD_DIR = path.join(__dirname, 'public');

// Middleware to set security headers for WASM Threads and SharedArrayBuffer
app.use((req, res, next) => {
    // Critical headers for enabling SharedArrayBuffer and WASM Threads
    res.setHeader('Cross-Origin-Opener-Policy', 'same-origin');
    res.setHeader('Cross-Origin-Embedder-Policy', 'require-corp');
    
    // Optional: Cache static assets for performance, but don't cache index.html
    if (req.url !== '/') {
        res.setHeader('Cache-Control', 'public, max-age=31536000');
    }
    next();
});

// Serve static files from the React build directory
app.use(express.static(BUILD_DIR));

// Fallback for SPA routing
app.get('*', (req, res) => {
    // Ensure this serves index.html for client-side routing
    // but does not interfere with API routes if any.
    // Note: If you have API routes (e.g., /api/*), place this * after* those routes.
    res.sendFile(path.join(BUILD_DIR, 'index.html'));
});

app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});
