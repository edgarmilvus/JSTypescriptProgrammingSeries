/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part6.ts
// Description: Solutions and Explanations
// ==========================================

# Stage 1: Builder
FROM node:18 AS builder

WORKDIR /app

# 1. Copy ONLY the package.json files from the root and all packages
# This layer is cached until package.json changes.
COPY package*.json ./
COPY packages/ui/package.json ./packages/ui/
COPY packages/utils/package.json ./packages/utils/
COPY apps/main-app/package.json ./apps/main-app/

# 2. Install ALL dependencies (including devDependencies for building)
# We use npm ci for deterministic builds based on lock files.
RUN npm ci

# 3. Copy ALL source code
COPY . .

# 4. Build the monorepo
# Assuming a build script in root package.json that builds all packages (e.g., using Turborepo, Lerna, or npm workspaces)
RUN npm run build

# Stage 2: Final
FROM node:18-alpine AS final

WORKDIR /app

# Copy package.json files again (needed to identify production dependencies)
COPY package*.json ./
COPY packages/ui/package.json ./packages/ui/
COPY packages/utils/package.json ./packages/utils/
COPY apps/main-app/package.json ./apps/main-app/

# Install ONLY production dependencies for the workspace
RUN npm ci --only=production && npm cache clean --force

# Copy the built artifacts from the builder stage
# Assuming the build output is in a 'dist' or 'build' folder inside each package/app
COPY --from=builder /app/packages/ui/dist ./packages/ui/dist
COPY --from=builder /app/packages/utils/dist ./packages/utils/dist
COPY --from=builder /app/apps/main-app/build ./apps/main-app/build

# Set the command to run the main app
CMD ["node", "apps/main-app/build/index.js"]
