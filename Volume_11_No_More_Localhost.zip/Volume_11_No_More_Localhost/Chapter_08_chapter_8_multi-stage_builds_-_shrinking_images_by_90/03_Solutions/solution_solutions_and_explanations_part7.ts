/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part7.ts
// Description: Solutions and Explanations
// ==========================================

# Stage 1: Builder
FROM node:18 AS builder

# Set working directory
WORKDIR /app

# Copy dependency definitions
COPY package*.json ./

# Use npm ci for deterministic builds (requires package-lock.json)
# This installs devDependencies and build tools
RUN npm ci

# Copy source code
COPY . .

# (Optional) Build step if using TypeScript/Bundlers
# RUN npm run build

# Stage 2: Final
FROM node:18-alpine AS final

# Security: Create a dedicated non-root user
RUN addgroup -g 1001 -S nodejs && adduser -S nodejs -u 1001

WORKDIR /app

# Copy dependency definitions
COPY package*.json ./

# Security & Size: Install ONLY production dependencies
# This removes devDependencies like nodemon, jest, typescript, etc.
RUN npm ci --only=production --ignore-scripts && npm cache clean --force

# Copy application source code (or build output if using a build step)
COPY --from=builder /app/src ./src

# Security: Switch to the non-root user
USER nodejs

# Use dumb-init or node directly
CMD ["node", "src/index.js"]
