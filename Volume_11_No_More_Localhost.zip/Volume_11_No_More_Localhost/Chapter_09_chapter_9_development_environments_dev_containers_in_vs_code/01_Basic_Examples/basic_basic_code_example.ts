/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * @fileoverview SaaS Dashboard State Manager demonstrating Immutable State Management.
 * This module handles the state of AI models within a SaaS application, ensuring
 * that state updates are performed immutably to prevent side effects.
 */

// --- 1. Type Definitions ---

/**
 * Represents the status of an AI model in the SaaS ecosystem.
 */
type ModelStatus = 'training' | 'active' | 'archived' | 'error';

/**
 * Represents a single AI model entity within the dashboard.
 * Uses `readonly` to enforce immutability at the type level where possible.
 */
interface AIModel {
  readonly id: string;
  readonly name: string;
  readonly version: string;
  status: ModelStatus;
  accuracy: number;
}

/**
 * The shape of the entire application state.
 */
interface AppState {
  readonly models: ReadonlyArray<AIModel>;
  readonly lastUpdated: Date;
}

// --- 2. Initial State (The "Source of Truth") ---

/**
 * The initial state of our SaaS dashboard.
 * We freeze the object to prevent accidental mutation during initialization.
 */
const initialAppState: AppState = Object.freeze({
  models: Object.freeze([
    { id: 'model-1', name: 'Sentiment Analyzer', version: 'v1.2', status: 'active', accuracy: 0.94 },
    { id: 'model-2', name: 'Image Classifier', version: 'v2.0', status: 'training', accuracy: 0.0 },
  ]),
  lastUpdated: new Date(),
});

// --- 3. The State Manager (Immutability Logic) ---

/**
 * Manages the application state and exposes methods to update it immutably.
 */
class SaaSStateManager {
  private state: AppState;

  constructor(initialState: AppState) {
    this.state = initialState;
  }

  /**
   * Retrieves a deep copy of the current state.
   * In a real app (React/Redux), this is the selector pattern.
   */
  getState(): AppState {
    return { ...this.state, models: [...this.state.models] };
  }

  /**
   * Adds a new AI model to the state immutably.
   * @param newModel - The model to add.
   */
  addModel(newModel: Omit<AIModel, 'id'>): void {
    // 1. Create a unique ID (simulated)
    const id = `model-${Math.random().toString(36).substr(2, 9)}`;

    // 2. Create the new model object
    const modelToAdd: AIModel = { ...newModel, id };

    // 3. IMMUTABLE UPDATE: Create a new array with the existing items + the new item
    const updatedModels = [...this.state.models, modelToAdd];

    // 4. IMMUTABLE UPDATE: Create a new state object
    this.state = {
      ...this.state,
      models: updatedModels,
      lastUpdated: new Date(),
    };
  }

  /**
   * Updates the status of a specific model immutably.
   * @param modelId - The ID of the model to update.
   * @param newStatus - The new status.
   */
  updateModelStatus(modelId: string, newStatus: ModelStatus): void {
    // 1. IMMUTABLE UPDATE: Map over the array to find the target model.
    // We return a NEW object for the changed model, and the existing object for others.
    const updatedModels = this.state.models.map((model) => {
      if (model.id === modelId) {
        // We use the spread operator to create a new object
        return { ...model, status: newStatus };
      }
      return model; // Return the original object reference (safe because it's immutable)
    });

    // 2. IMMUTABLE UPDATE: Create a new state object
    this.state = {
      ...this.state,
      models: updatedModels,
      lastUpdated: new Date(),
    };
  }
}

// --- 4. Execution / Usage Example ---

// Initialize the manager
const manager = new SaaSStateManager(initialAppState);

console.log('--- Initial State ---');
console.log(manager.getState().models);

// Action: Add a new model
manager.addModel({
  name: 'Text Summarizer',
  version: 'v0.9',
  status: 'training',
  accuracy: 0.0,
});

console.log('\n--- State After Adding Model ---');
console.log(manager.getState().models);

// Action: Update an existing model's status
manager.updateModelStatus('model-1', 'archived');

console.log('\n--- State After Updating Model Status ---');
const finalState = manager.getState();
console.log(finalState.models);

// Verification of Immutability
const firstModelRef = finalState.models[0];
const secondStateCall = manager.getState();
// This check proves that while the array is new, the object references for unchanged items remain stable
// (or strictly speaking, we aren't mutating the original objects).
console.log('\n--- Immutability Check ---');
console.log('Is the first model object reference the same as a fresh get?', 
  firstModelRef === secondStateCall.models[0] ? 'Yes (Optimization)' : 'No');
