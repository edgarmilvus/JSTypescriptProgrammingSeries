/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

/**
 * ============================================================================
 *  ADVANCED APPLICATION SCRIPT: AGENT SUPERVISOR WITH DEV CONTAINER CONTEXT
 * ============================================================================
 * 
 * CONTEXT: This script is designed to run inside a VS Code Dev Container 
 * (Node.js/Python multi-stage). It simulates a backend service that manages
 * a pool of specialized AI agents.
 * 
 * CONCEPTS APPLIED:
 * 1. Type Inference: Automatic type detection in async functions and map operations.
 * 2. Generics: <T, R> allows the Supervisor to handle any data type and return
 *    any result type while maintaining strict type safety.
 * 3. Worker Agent Pool: A collection of specialized agents managed by a supervisor.
 */

import { setTimeout } from 'timers/promises';

// --- 1. TYPE DEFINITIONS & GENERICS ---

/**
 * Represents the status of a worker execution.
 */
type ExecutionStatus = 'PENDING' | 'RUNNING' | 'COMPLETED' | 'FAILED';

/**
 * The generic structure of a task passed to an agent.
 * T = Input Data Type
 */
interface AgentTask<T> {
    id: string;
    payload: T;
    timestamp: Date;
}

/**
 * The generic structure of a task result.
 * R = Output Data Type
 */
interface AgentResult<R> {
    taskId: string;
    status: ExecutionStatus;
    result: R | null;
    error?: string;
}

/**
 * Interface for any specialized worker agent.
 * Uses Generics to enforce that the input (T) and output (R) types are consistent.
 */
interface IWorkerAgent<T, R> {
    name: string;
    execute(task: AgentTask<T>): Promise<AgentResult<R>>;
}

// --- 2. SPECIALIZED WORKER AGENTS ---

/**
 * AGENT 1: Code Generator Agent
 * Simulates generating code snippets based on a natural language prompt.
 * 
 * Type Inference: The compiler infers 'string' for the input and 'string' for the output
 * based on the implementation, even if we didn't explicitly annotate the method return types.
 */
class CodeGeneratorAgent implements IWorkerAgent<string, string> {
    name = 'CodeGenerator';

    async execute(task: AgentTask<string>): Promise<AgentResult<string>> {
        console.log(`[${this.name}] Processing task: ${task.id}`);
        
        // Simulate processing delay (e.g., calling an LLM API)
        await setTimeout(100); 

        const prompt = task.payload;
        const generatedCode = `// Generated from prompt: "${prompt}"\nconst hello = () => console.log('Hello World');`;

        return {
            taskId: task.id,
            status: 'COMPLETED',
            result: generatedCode
        };
    }
}

/**
 * AGENT 2: Database Query Agent
 * Simulates executing a SQL query against a containerized database.
 * 
 * Here, the input is a SQL string, and the output is an array of objects.
 */
interface DbRow {
    id: number;
    value: string;
}

class DatabaseQueryAgent implements IWorkerAgent<string, DbRow[]> {
    name = 'DatabaseQuery';

    async execute(task: AgentTask<string>): Promise<AgentResult<DbRow[]>> {
        console.log(`[${this.name}] Executing query: ${task.payload}`);
        
        await setTimeout(150); // Simulate I/O latency

        // Mock result
        const mockData: DbRow[] = [
            { id: 1, value: 'Result A' },
            { id: 2, value: 'Result B' }
        ];

        return {
            taskId: task.id,
            status: 'COMPLETED',
            result: mockData
        };
    }
}

// --- 3. THE SUPERVISOR (WORKER AGENT POOL) ---

/**
 * Supervisor Class
 * Manages a pool of agents and routes tasks to the appropriate worker.
 * 
 * This utilizes Generics at the class level to allow the Supervisor to be
 * instantiated for specific task/result types, or left generic to handle mixed types.
 */
class AgentSupervisor {
    private agents: Map<string, IWorkerAgent<any, any>> = new Map();

    /**
     * Registers a new agent to the pool.
     * Uses Generics <T, R> to capture the specific capabilities of the agent.
     */
    registerAgent<T, R>(agent: IWorkerAgent<T, R>): void {
        this.agents.set(agent.name, agent);
        console.log(`[Supervisor] Registered Agent: ${agent.name}`);
    }

    /**
     * Dispatches a task to a specific agent.
     * 
     * @param agentName - The name of the target agent.
     * @param task - The task object containing payload.
     * @returns Promise<AgentResult<R>> - Returns the result inferred by the specific agent.
     */
    async dispatchTask<T, R>(
        agentName: string, 
        task: AgentTask<T>
    ): Promise<AgentResult<R>> {
        const agent = this.agents.get(agentName);

        if (!agent) {
            return {
                taskId: task.id,
                status: 'FAILED',
                result: null,
                error: `Agent '${agentName}' not found in pool.`
            };
        }

        // Type Assertion is safe here because we checked the map existence,
        // but in a complex system, we might validate the agent signature matches T/R.
        return (agent as IWorkerAgent<T, R>).execute(task);
    }

    /**
     * Broadcasts a task to ALL agents (Fan-out pattern).
     * Useful for system-wide updates or logging.
     */
    async broadcast<T>(payload: T): Promise<void> {
        const timestamp = new Date();
        const tasks = Array.from(this.agents.values()).map(async (agent) => {
            const genericTask: AgentTask<T> = {
                id: `broadcast-${Date.now()}`,
                payload,
                timestamp
            };
            
            // We cast here because broadcast doesn't care about specific return types
            await (agent as any).execute(genericTask);
        });

        await Promise.all(tasks);
    }
}

// --- 4. MAIN EXECUTION (DEV CONTAINER CONTEXT) ---

/**
 * Main Application Entry Point.
 * 
 * In a real Next.js app, this logic would likely reside in an API Route 
 * (e.g., /pages/api/agents/dispatch.ts) or a Server Action.
 * 
 * Here, we simulate the application lifecycle.
 */
async function main() {
    console.log('🚀 Starting Agent Supervisor in Dev Container Environment...\n');

    const supervisor = new AgentSupervisor();

    // 1. Initialize Agents
    const codeAgent = new CodeGeneratorAgent();
    const dbAgent = new DatabaseQueryAgent();

    // 2. Register Agents to the Pool
    supervisor.registerAgent(codeAgent);
    supervisor.registerAgent(dbAgent);

    console.log('\n--- Dispatching Tasks ---\n');

    // 3. Dispatch Task 1: Code Generation
    // Type Inference automatically detects 'string' for payload and return type.
    const codeTask: AgentTask<string> = {
        id: 'task-101',
        payload: 'Write a React hook for fetching data',
        timestamp: new Date()
    };

    const codeResult = await supervisor.dispatchTask<string, string>('CodeGenerator', codeTask);
    console.log('Result [CodeGenerator]:', codeResult.result);

    // 4. Dispatch Task 2: Database Query
    // The Generic types <string, DbRow[]> ensure strict typing for the DB agent.
    const dbTask: AgentTask<string> = {
        id: 'task-102',
        payload: 'SELECT * FROM users',
        timestamp: new Date()
    };

    const dbResult = await supervisor.dispatchTask<string, DbRow[]>('DatabaseQuery', dbTask);
    console.log('Result [DatabaseQuery]:', dbResult.result);

    // 5. Error Handling Simulation
    console.log('\n--- Testing Error Handling ---\n');
    const failTask: AgentTask<any> = {
        id: 'task-999',
        payload: 'Invalid Request',
        timestamp: new Date()
    };

    const failResult = await supervisor.dispatchTask('NonExistentAgent', failTask);
    if (failResult.error) {
        console.error(`Error caught: ${failResult.error}`);
    }

    console.log('\n✅ Script execution complete.');
}

// Execute main function
if (require.main === module) {
    main().catch(console.error);
}

// Export for testing or module usage
export { AgentSupervisor, CodeGeneratorAgent, DatabaseQueryAgent };
