/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// .devcontainer/Dockerfile
# Stage 1: Base - Install system dependencies and Node.js
FROM mcr.microsoft.com/devcontainers/javascript-node:20 as base

# Install common build essentials for native modules (e.g., node-gyp)
# and python3 which is often required for compiling native modules.
RUN apt-get update && apt-get install -y \
    build-essential \
    python3 \
    && rm -rf /var/lib/apt/lists/*

# Stage 2: Dev - Copy base and install global dev tools
FROM base as dev

# Install global development tools
# These persist in the 'dev' stage image but not in a hypothetical production stage
RUN npm install -g eslint prettier

# .devcontainer/devcontainer.json
{
    "name": "Multi-Stage Node.js Dev",
    "build": {
        "dockerfile": "Dockerfile",
        "context": "..",
        // Target the 'dev' stage of the Dockerfile
        "target": "dev"
    },
    "features": {
        // Interactive Challenge: Use the feature to install Python 3.11
        // This replaces the manual 'apt-get install python3' in the Dockerfile base stage.
        "ghcr.io/devcontainers/features/python:1": {
            "version": "3.11"
        }
    },
    "customizations": {
        "vscode": {
            "extensions": [
                "dbaeumer.vscode-eslint",
                "esbenp.prettier-vscode"
            ]
        }
    },
    // Run npm install after the container is created
    "postCreateCommand": "npm install"
}
