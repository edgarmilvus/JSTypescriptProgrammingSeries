/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

// .devcontainer/devcontainer.json
{
    "name": "Python AI Environment",
    "image": "mcr.microsoft.com/devcontainers/python:3.10",
    "features": {
        // Optional: Install Node.js if needed for frontend tools
        "ghcr.io/devcontainers/features/node:1": {
            "version": "lts"
        }
    },
    "customizations": {
        "vscode": {
            "extensions": [
                "ms-python.python",
                "ms-toolsai.jupyter"
            ],
            "settings": {
                // Focus on enabling the native notebook interface
                "jupyter.interactiveWindowMode": "perFile",
                "python.defaultInterpreterPath": "/usr/local/bin/python"
            }
        }
    },
    "forwardPorts": [8888, 6006],
    
    // Install heavy dependencies once during creation
    "postCreateCommand": "pip install torch jupyter ipykernel tensorboard --quiet",

    // Interactive Challenge: Start Jupyter in the background on container start
    "postStartCommand": "nohup jupyter notebook --ip=0.0.0.0 --port=8888 --no-browser --allow-root --NotebookApp.token='' > jupyter.log 2>&1 &",
    
    // Wait for the Jupyter port to be open before declaring the container ready
    // Note: 'waitForPort' is a common pattern, but VS Code Dev Containers 
    // natively wait for the remote server. This custom script ensures the app is ready.
    "onCreateCommand": "echo 'Container created. Dependencies installed.'"
}

// .devcontainer/wait-for-jupyter.sh (Optional helper script for complex scenarios)
#!/bin/bash
echo "Waiting for Jupyter port 8888..."
while ! nc -z localhost 8888; do   
  sleep 1
done
echo "Jupyter is up!"
