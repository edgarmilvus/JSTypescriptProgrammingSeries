/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

// .devcontainer/devcontainer.json (Docker-in-Docker Approach)
{
    "name": "Docker-in-Docker AI Builder",
    "image": "mcr.microsoft.com/devcontainers/base:alpine",
    "features": {
        "ghcr.io/devcontainers/features/docker-in-docker:2": {
            "version": "latest",
            "moby": true, // Use Docker CE instead of Docker Engine
            "installDockerBuildx": true
        }
    },
    "remoteUser": "root",
    "postCreateCommand": "echo 'Docker installed. Ready to build.'",
    
    // SECURITY NOTE:
    // Running DinD with 'privileged' mode (often default for DinD features) 
    // grants the container full access to the host kernel. 
    // This is a security risk in shared environments (e.g., CI runners) 
    // as a container escape vulnerability could compromise the host.
    // Use 'docker-outside-of-docker' for better isolation if possible.
}

// .devcontainer/Dockerfile (The image to be built inside the container)
FROM python:3.9-slim
WORKDIR /app
COPY . .
RUN pip install -r requirements.txt

// .devcontainer/build.sh
#!/bin/bash
echo "Building custom AI image..."
# This command runs inside the container but uses the container's Docker daemon
docker build -t my-ai-model:latest -f Dockerfile ..
echo "Build complete. Image 'my-ai-model' is available locally."

// --- Interactive Challenge: Switch to Docker-outside-of-Docker ---
/*
// Updated .devcontainer/devcontainer.json
{
    "name": "Docker-outside-of-Docker",
    "image": "mcr.microsoft.com/devcontainers/base:alpine",
    "features": {
        "ghcr.io/devcontainers/features/docker-outside-of-docker:1": {}
    },
    "remoteUser": "root"
}
*/
