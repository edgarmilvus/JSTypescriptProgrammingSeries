/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.tsx
// Description: Solutions and Explanations
// ==========================================

import React from 'react';

// 1. Define the interface for column definitions
interface ColumnDef<T> {
    header: string;
    accessor: keyof T; // Strictly enforce this is a key of T
}

// 2. Define the Props interface using Generics
interface TableProps<T> {
    data: T[];
    columns: ColumnDef<T>[];
    onRowClick?: (item: T) => void;
    // Interactive Challenge: Optional custom render function
    renderCell?: (column: ColumnDef<T>, item: T) => React.ReactNode;
}

// 3. Implement the Component
// We use <T,> to distinguish the generic type from JSX tags
export const Table = <T,>({ 
    data, 
    columns, 
    onRowClick, 
    renderCell 
}: TableProps<T>) => {
    if (!data || data.length === 0) {
        return <div>No data available</div>;
    }

    return (
        <table style={{ width: '100%', borderCollapse: 'collapse' }}>
            <thead>
                <tr>
                    {columns.map((col, index) => (
                        <th key={index} style={{ borderBottom: '2px solid #ddd', padding: '8px', textAlign: 'left' }}>
                            {col.header}
                        </th>
                    ))}
                </tr>
            </thead>
            <tbody>
                {data.map((item, rowIndex) => (
                    <tr 
                        key={rowIndex} 
                        onClick={() => onRowClick && onRowClick(item)}
                        style={{ cursor: onRowClick ? 'pointer' : 'default' }}
                    >
                        {columns.map((col, colIndex) => (
                            <td key={colIndex} style={{ padding: '8px', borderBottom: '1px solid #eee' }}>
                                {/* 
                                    Interactive Challenge Logic: 
                                    Use renderCell if provided, otherwise fallback to standard property access.
                                    TypeScript ensures 'col.accessor' is valid for 'item'.
                                */}
                                {renderCell 
                                    ? renderCell(col, item) 
                                    : (item[col.accessor] as React.ReactNode)
                                }
                            </td>
                        ))}
                    </tr>
                ))}
            </tbody>
        </table>
    );
};

// --- Usage Example ---

interface User {
    id: number;
    name: string;
    joinDate: Date;
    isActive: boolean;
}

const UserTable = () => {
    const users: User[] = [
        { id: 1, name: 'Alice', joinDate: new Date('2023-01-15'), isActive: true },
        { id: 2, name: 'Bob', joinDate: new Date('2023-02-20'), isActive: false },
    ];

    const userColumns: ColumnDef<User>[] = [
        { header: 'ID', accessor: 'id' },
        { header: 'Name', accessor: 'name' },
        { header: 'Joined', accessor: 'joinDate' },
        { header: 'Active', accessor: 'isActive' },
    ];

    // Example of custom rendering
    const customCellRenderer = (column: ColumnDef<User>, item: User) => {
        if (column.accessor === 'joinDate') {
            return <span>{item.joinDate.toLocaleDateString()}</span>;
        }
        if (column.accessor === 'isActive') {
            return <button>{item.isActive ? 'Deactivate' : 'Activate'}</button>;
        }
        return item[column.accessor];
    };

    return (
        <Table 
            data={users} 
            columns={userColumns} 
            onRowClick={(user) => console.log('Clicked:', user.name)}
            renderCell={customCellRenderer}
        />
    );
};
