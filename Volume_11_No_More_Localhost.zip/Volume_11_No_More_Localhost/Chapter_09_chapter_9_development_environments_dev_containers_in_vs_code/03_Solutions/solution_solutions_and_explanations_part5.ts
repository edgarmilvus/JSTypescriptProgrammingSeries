/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

digraph DevContainerLifecycle {
    rankdir=TB;
    node [shape=rect, style=filled, fillcolor=lightblue, fontname="Helvetica"];
    decision [shape=diamond, fillcolor=lightgrey, label="Is Container\nNew?"];

    // Creation Phase
    subgraph cluster_creation {
        label = "Creation Phase";
        style = dashed;
        node [fillcolor=lightblue];
        onCreate [label="onCreateCommand"];
        postCreate [label="postCreateCommand"];
        installDeps [label="Install Heavy Dependencies\n(e.g., npm install)"];
    }

    // Start Phase
    subgraph cluster_start {
        label = "Start Phase";
        style = dashed;
        node [fillcolor=lightgreen];
        onStart [label="onStartCommand"];
        postStart [label="postStartCommand"];
        startServer [label="VS Code Server Initialization"];
    }

    // Port Forwarding Phase
    subgraph cluster_ports {
        label = "Post-Start Actions";
        style = dashed;
        node [fillcolor=lightyellow];
        portForward [label="Port Forwarding\n(e.g., 8888, 6006)"];
    }

    // Flow Logic
    Start [label="Open Folder in Container", shape=ellipse, fillcolor=white];
    End [label="Environment Ready", shape=ellipse, fillcolor=white];

    Start -> decision;
    
    // Creation Path
    decision -> onCreate [label="Yes"];
    onCreate -> postCreate;
    postCreate -> installDeps;
    installDeps -> onStart;

    // Start Path
    decision -> onStart [label="No (Existing)"];
    
    onStart -> postStart;
    postStart -> startServer;
    startServer -> portForward;
    portForward -> End;
}
