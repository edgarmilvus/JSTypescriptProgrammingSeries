/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

// index.ts
import * as fs from 'fs/promises';
import * as path from 'path';

/**
 * Configuration for the persistence layer.
 * In a real SaaS app, this would likely be a database connection string,
 * but for this chapter, we simulate state via a local JSON file.
 */
const STATE_FILE_PATH = path.join('/data', 'app_state.json');

/**
 * Represents the shape of our persisted state.
 * @typedef {Object} AppState
 * @property {string} lastUpdated - ISO timestamp of the last write.
 * @property {number} sessionCount - A counter to simulate session activity.
 */
interface AppState {
  lastUpdated: string;
  sessionCount: number;
}

/**
 * Writes the current application state to the Docker Volume mount point.
 * This mimics a Checkpointer saving Graph State after a node execution.
 * 
 * @param {AppState} state - The state object to serialize.
 */
async function persistState(state: AppState): Promise<void> {
  try {
    // Serialize the state object to a JSON string
    const data = JSON.stringify(state, null, 2);
    
    // Write to the file. 
    // Note: '/data' is the directory we will map to a Docker Volume.
    await fs.writeFile(STATE_FILE_PATH, data, 'utf-8');
    
    console.log(`[PERSISTENCE LAYER] State saved to ${STATE_FILE_PATH}`);
    console.log(`[DATA] ${data}`);
  } catch (error) {
    console.error('[ERROR] Failed to write state:', error);
  }
}

/**
 * Main application loop.
 * 1. Initializes state if file doesn't exist.
 * 2. Updates state every 5 seconds.
 * 3. Persists state to disk.
 */
async function main() {
  console.log('🚀 Starting Stateful Node.js Service...');

  let currentState: AppState = {
    lastUpdated: new Date().toISOString(),
    sessionCount: 0,
  };

  // Check if state file exists to resume session (Hydration)
  try {
    const fileData = await fs.readFile(STATE_FILE_PATH, 'utf-8');
    currentState = JSON.parse(fileData);
    console.log('✅ Resumed from previous state:', currentState);
  } catch (error) {
    console.log('ℹ️ No previous state found. Initializing fresh state.');
    await persistState(currentState);
  }

  // Simulate an active service loop (e.g., processing AI requests)
  setInterval(async () => {
    currentState.sessionCount += 1;
    currentState.lastUpdated = new Date().toISOString();
    
    console.log(`\n--- Interval Tick #${currentState.sessionCount} ---`);
    await persistState(currentState);
  }, 5000);
}

// Execute the main function
main().catch(console.error);
