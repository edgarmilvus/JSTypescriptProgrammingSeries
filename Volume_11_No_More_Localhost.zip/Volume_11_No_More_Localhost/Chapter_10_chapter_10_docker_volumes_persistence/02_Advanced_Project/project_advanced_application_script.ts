/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// pages/api/agent.ts
// Next.js API Route for Stateful AI Agent
import { NextApiRequest, NextApiResponse } from 'next';

/**
 * ============================================================================
 * 1. TYPE DEFINITIONS & GENERICS
 * ============================================================================
 * We use TypeScript Generics to ensure our state management is reusable
 * and type-safe. 'T' represents the specific shape of our agent's memory.
 */

// The shape of the data we want to persist across container restarts
interface AgentState {
  conversationId: string;
  messages: Array<{ role: 'user' | 'assistant'; content: string }>;
  toolCalls: number;
  status: 'idle' | 'processing' | 'paused';
}

// Abstract interface for our persistence layer (Docker Volume / Redis)
interface Checkpointer<T> {
  saveState: (id: string, state: T) => Promise<void>;
  loadState: (id: string) => Promise<T | null>;
}

/**
 * ============================================================================
 * 2. PERSISTENCE LAYER (DOCKER VOLUME INTEGRATION)
 * ============================================================================
 * In a real scenario, this connects to Redis running in a sibling container.
 * For this script, we simulate the behavior to demonstrate the logic.
 * The 'redisClient' represents the bridge to the Docker Volume.
 */

class RedisCheckpointer implements Checkpointer<AgentState> {
  // Simulating a Redis client connection
  private redisClient: Map<string, string> = new Map();

  /**
   * Saves the complete graph state to the persistent volume.
   * @param id - The unique ID for the conversation (Graph ID)
   * @param state - The current state of the agent
   */
  async saveState(id: string, state: AgentState): Promise<void> {
    // In a real Docker setup, this writes to /data/dump.rdb inside the volume
    // We serialize the state to JSON for storage
    const serializedState = JSON.stringify(state);
    this.redisClient.set(id, serializedState);
    
    // Simulate disk I/O latency
    await new Promise(resolve => setTimeout(resolve, 50));
    console.log(`[Docker Volume] State saved for ID: ${id}`);
  }

  /**
   * Hydrates the state from the persistent volume.
   * This is crucial for resuming workflows after container restarts.
   */
  async loadState(id: string): Promise<AgentState | null> {
    const rawState = this.redisClient.get(id);
    if (!rawState) return null;

    // Simulate retrieval latency
    await new Promise(resolve => setTimeout(resolve, 50));
    console.log(`[Docker Volume] State loaded for ID: ${id}`);
    return JSON.parse(rawState) as AgentState;
  }
}

// Singleton instance to simulate the container's internal dependency
const checkpointer = new RedisCheckpointer();

/**
 * ============================================================================
 * 3. TOOL INVOCATION SIGNATURE
 * ============================================================================
 * LangGraph requires tools to adhere to a specific signature.
 * This ensures the graph executor knows how to call them regardless of logic.
 */

type ToolResult = {
  output: string;
  metadata: Record<string, unknown>;
};

/**
 * A tool handler compatible with the LangGraph framework.
 * Accepts a params object and returns a result.
 * In a Dockerized environment, this might trigger side-effects (e.g., writing to a shared volume).
 */
async function webSearchTool(params: { query: string }): Promise<ToolResult> {
  // Simulating an external API call
  console.log(`Executing Tool: webSearch with query "${params.query}"`);
  
  // In a real app, this might save a cache file to a mounted volume
  return {
    output: `Search results for: ${params.query}`,
    metadata: { timestamp: Date.now(), source: 'web' }
  };
}

/**
 * ============================================================================
 * 4. AGENT LOGIC (LANGGRAPH SIMULATION)
 * ============================================================================
 * This section simulates the logic of a LangGraph node execution.
 * It demonstrates how state is mutated and persisted.
 */

async function processAgentStep(
  state: AgentState, 
  input: string
): Promise<AgentState> {
  // 1. Update state with new user input
  const updatedState: AgentState = {
    ...state,
    messages: [...state.messages, { role: 'user', content: input }],
    status: 'processing',
    toolCalls: state.toolCalls + 1
  };

  // 2. Invoke a tool (simulating a node in the graph)
  const toolResult = await webSearchTool({ query: input });
  
  // 3. Add tool output to state
  updatedState.messages.push({
    role: 'assistant',
    content: toolResult.output
  });
  
  updatedState.status = 'idle';

  return updatedState;
}

/**
 * ============================================================================
 * 5. NEXT.JS API ROUTE HANDLER
 * ============================================================================
 * The entry point for the web application.
 */

export default async function handler(
  req: NextApiRequest, 
  res: NextApiResponse
) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  const { conversationId, message } = req.body;

  if (!conversationId || !message) {
    return res.status(400).json({ error: 'Missing conversationId or message' });
  }

  try {
    // ---------------------------------------------------------------------
    // CRITICAL STEP: HYDRATION FROM DOCKER VOLUME
    // ---------------------------------------------------------------------
    // Before processing, we check the persistent storage.
    // If the container just restarted, this fetches the lost memory.
    
    let currentState = await checkpointer.loadState(conversationId);

    if (!currentState) {
      // Initialize new state if no persistence record exists
      currentState = {
        conversationId,
        messages: [],
        toolCalls: 0,
        status: 'idle'
      };
    }

    // ---------------------------------------------------------------------
    // EXECUTE AGENT LOGIC
    // ---------------------------------------------------------------------
    // Process the input based on the (potentially recovered) state.
    const newState = await processAgentStep(currentState, message);

    // ---------------------------------------------------------------------
    // CRITICAL STEP: PERSISTENCE TO DOCKER VOLUME
    // ---------------------------------------------------------------------
    // Save the new state immediately after processing.
    // This ensures data safety even if the process crashes immediately after.
    
    await checkpointer.saveState(conversationId, newState);

    // Return the updated state to the client
    res.status(200).json({
      success: true,
      state: newState
    });

  } catch (error) {
    console.error('Agent Error:', error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
}
