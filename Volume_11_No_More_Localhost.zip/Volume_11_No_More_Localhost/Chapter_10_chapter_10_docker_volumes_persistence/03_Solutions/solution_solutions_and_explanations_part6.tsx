/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part6.tsx
// Description: Solutions and Explanations
// ==========================================

import React from 'react';

// 1. Define the DockerVolume interface
export interface DockerVolume {
  name: string;
  mountpoint: string;
  usage: number; // Percentage (0-100)
}

// 2. Helper function to determine color based on usage
const getUsageColor = (usage: number): string => {
  if (usage > 80) return '#ff4d4f'; // Red
  if (usage >= 50) return '#faad14'; // Yellow
  return '#52c41a'; // Green
};

// 3. Implement the VolumeStatusPanel component
const VolumeStatusPanel: React.FC<{ volumes: DockerVolume[] }> = ({ volumes }) => {
  return (
    <div style={{ fontFamily: 'Arial, sans-serif', padding: '20px', border: '1px solid #d9d9d9', borderRadius: '8px' }}>
      <h2>Docker Volume Status</h2>
      {volumes.length === 0 ? (
        <p>No volumes found.</p>
      ) : (
        <ul style={{ listStyleType: 'none', padding: 0 }}>
          {volumes.map((vol, index) => (
            <li key={index} style={{ marginBottom: '15px', padding: '10px', backgroundColor: '#f5f5f5', borderRadius: '4px' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '5px' }}>
                <strong>{vol.name}</strong>
                <span>{vol.usage}%</span>
              </div>
              <div style={{ backgroundColor: '#e0e0e0', borderRadius: '4px', height: '10px', overflow: 'hidden' }}>
                <div
                  style={{
                    width: `${vol.usage}%`,
                    backgroundColor: getUsageColor(vol.usage),
                    height: '100%',
                    transition: 'width 0.3s ease',
                  }}
                />
              </div>
              <small style={{ color: '#888', display: 'block', marginTop: '4px' }}>
                {vol.mountpoint}
              </small>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
};

// 4. Mock Data for demonstration
const mockVolumes: DockerVolume[] = [
  { name: 'db-data', mountpoint: '/var/lib/docker/volumes/db-data/_data', usage: 45 },
  { name: 'app-logs', mountpoint: '/var/lib/docker/volumes/app-logs/_data', usage: 85 },
  { name: 'cache', mountpoint: '/var/lib/docker/volumes/cache/_data', usage: 20 },
];

// Example usage (would typically be in App.tsx)
const App = () => {
  return <VolumeStatusPanel volumes={mockVolumes} />;
};

export default App;
