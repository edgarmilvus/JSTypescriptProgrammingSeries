/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part8.ts
// Description: Solutions and Explanations
// ==========================================

// src/checkpointer.ts
// Note: Pseudo-code assuming the structure of @langchain/langgraph-checkpoint-redis
// In a real scenario, ensure these packages are installed via npm/yarn.

import { RedisCheckpointSaver } from '@langchain/langgraph-checkpoint-redis';
import { StateGraph, END } from '@langchain/langgraph';
import { Redis } from 'ioredis';

// 1. Initialize the Checkpointer
export async function initializeCheckpointer() {
  // Connect to the redis container using the internal network hostname
  const client = new Redis({
    host: process.env.REDIS_HOST || 'localhost',
    port: parseInt(process.env.REDIS_PORT || '6379'),
    // retryStrategy is recommended for production to handle startup delays
  });

  client.on('error', (err) => console.error('Redis Client Error', err));

  // Initialize the checkpointer
  const checkpointer = new RedisCheckpointSaver({
    client,
    // ttl: 86400, // Optional: expire keys after 24 hours
  });

  return { checkpointer, client };
}

// 2. State Hydration Logic
export async function resumeGraph(threadId: string, checkpointer: any) {
  // Define the graph structure (must match the original graph definition)
  const graph = new StateGraph({
    // ... state schema
  });

  // ... define nodes and edges ...

  // Compile the graph with the checkpointer
  const app = graph.compile({ checkpointer });

  // Retrieve the previous state using the threadId
  // The checkpointer usually provides a method like `getTuple` or `list`
  const savedState = await checkpointer.get({ configurable: { thread_id: threadId } });

  if (savedState) {
    console.log(`Resuming graph for thread: ${threadId}`);
    // When invoking the graph, pass the threadId and the saved state (if required by the API)
    // or simply invoke with the threadId, and the checkpointer handles the loading internally.
    return { app, threadId };
  } else {
    console.log(`No saved state found for thread: ${threadId}. Starting new.`);
    return { app, threadId };
  }
}

// Usage Example
/*
async function main() {
  const { checkpointer } = await initializeCheckpointer();
  const { app, threadId } = await resumeGraph('my-conversation-1', checkpointer);
  
  // Run the graph
  // await app.invoke({ ... }, { configurable: { thread_id: threadId } });
}
*/
