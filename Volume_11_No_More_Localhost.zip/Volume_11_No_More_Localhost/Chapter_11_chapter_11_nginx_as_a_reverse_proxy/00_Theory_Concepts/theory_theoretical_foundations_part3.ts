/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part3.ts
// Description: Theoretical Foundations
// ==========================================

// This is a conceptual representation, NOT actual code.
// It illustrates the flow in a professional, reverse-proxied architecture.

// User's Browser
//    |
//    |  (Request to https://api.yourdomain.com)
//    v
// Docker Host Server (Only ports 80 and 443 are open to the internet)
//    |
//    +--> [Nginx Container] (Listens on ports 80/443)
//         |  (SSL Termination, Routing, Load Balancing)
//         |
//         |  (Internal Docker Network - e.g., 'app-network')
//         |
//         +--> [Node.js Container 1] (Listens on port 3000, not exposed)
//         |
//         +--> [Node.js Container 2] (Listens on port 3000, not exposed)
//         |
//         +--> [Python Container] (Listens on port 5000, not exposed)
//         |
//         +--> [React Container] (Listens on port 8080, not exposed)
//
// Solution: Single, secure entry point. Centralized SSL. Internal routing.
//           Scalable and easy to manage.
