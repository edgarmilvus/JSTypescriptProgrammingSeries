/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example_part3.ts
// Description: Basic Code Example
// ==========================================

# file: nginx.conf

# Define the upstream servers (our backend containers)
# This allows Nginx to load balance if we add more instances later.
upstream service_a_backend {
    server host.docker.internal:3000; # Maps to Service A
}

upstream service_b_backend {
    server host.docker.internal:3001; # Maps to Service B
}

server {
    listen 80;
    server_name localhost;

    # Route 1: Requests to /api go to Service A
    location /api/ {
        # Rewrite the path to remove /api prefix so the app receives '/'
        rewrite ^/api/(.*) /$1 break;
        
        proxy_pass http://service_a_backend;
        
        # Standard headers for proxying
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }

    # Route 2: Requests to /dashboard go to Service B
    location /dashboard/ {
        # Rewrite the path
        rewrite ^/dashboard/(.*) /$1 break;

        proxy_pass http://service_b_backend;

        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }

    # Catch-all (optional)
    location / {
        return 404 "Route not found. Use /api or /dashboard\n";
    }
}
