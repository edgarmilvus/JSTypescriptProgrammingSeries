/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example_part4.ts
// Description: Basic Code Example
// ==========================================

# file: docker-compose.yml
version: '3.8'

services:
  # The Reverse Proxy
  nginx-proxy:
    image: nginx:alpine
    ports:
      - "80:80" # Expose port 80 on host
    volumes:
      - ./nginx.conf:/etc/nginx/nginx.conf:ro # Mount our config
    depends_on:
      - service-a
      - service-b
    networks:
      - app-network

  # Backend Service A
  service-a:
    build:
      context: .
      dockerfile: Dockerfile.service-a
    ports:
      - "3000" # Internal port
    networks:
      - app-network

  # Backend Service B
  service-b:
    build:
      context: .
      dockerfile: Dockerfile.service-b
    ports:
      - "3001" # Internal port
    networks:
      - app-network

networks:
  app-network:
    driver: bridge
