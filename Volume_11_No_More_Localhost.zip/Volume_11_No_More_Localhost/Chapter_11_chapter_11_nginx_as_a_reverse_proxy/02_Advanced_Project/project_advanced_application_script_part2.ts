/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script_part2.ts
// Description: Advanced Application Script
// ==========================================

// app/api/chat/stream/route.ts
import { NextRequest, NextResponse } from 'next/server';

/**
 * ------------------------------------------------------------------
 * 1. INTERFACES & TYPES
 * ------------------------------------------------------------------
 * Using TypeScript interfaces to define the contract for our 
 * streaming data packets. This ensures type safety between the 
 * server generating the stream and the client parsing it.
 */

interface StreamMessage {
  id: string;
  object: string;
  created: number;
  model: string;
  choices: Array<{
    index: number;
    delta: {
      content?: string;
      role?: string;
    };
    finish_reason: string | null;
  }>;
}

/**
 * ------------------------------------------------------------------
 * 2. SERVER-SIDE: NEXT.JS API ROUTE
 * ------------------------------------------------------------------
 * This route simulates an AI response stream. It uses the Web Streams API
 * to push data chunks immediately, bypassing Node.js buffering issues.
 * 
 * CRITICAL FOR NGINX: 
 * This implementation relies on Nginx being configured with:
 *   proxy_buffering off;
 *   proxy_cache off;
 *   proxy_read_timeout 86400; (Keep connection alive)
 */

export async function POST(req: NextRequest) {
  // Parse the incoming user prompt
  const { prompt } = await req.json();

  // Create a ReadableStream to handle the data generation
  const stream = new ReadableStream({
    async start(controller) {
      // Simulate an AI model generating tokens one by one
      const mockAITokens = ["Hello", " ", "world", "!"];
      
      for (const token of mockAITokens) {
        // Create the SSE-compliant data packet
        const streamPayload: StreamMessage = {
          id: `chatcmpl-${Date.now()}`,
          object: 'chat.completion.chunk',
          created: Math.floor(Date.now() / 1000),
          model: 'gpt-4-turbo',
          choices: [
            {
              index: 0,
              delta: { content: token }, // The actual token being sent
              finish_reason: null,
            },
          ],
        };

        // Format as SSE: "data: {JSON}\n\n"
        const sseString = `data: ${JSON.stringify(streamPayload)}\n\n`;
        
        // Encode string to Uint8Array for transmission
        const chunk = new TextEncoder().encode(sseString);
        
        // Enqueue the chunk to the stream (immediate flush)
        controller.enqueue(chunk);
        
        // Simulate network latency for realism
        await new Promise(resolve => setTimeout(resolve, 200));
      }

      // Send the final [DONE] signal common in OpenAI-style streams
      controller.enqueue(new TextEncoder().encode(`data: [DONE]\n\n`));
      
      // Close the stream
      controller.close();
    },
  });

  // Return the response with headers that allow streaming
  return new Response(stream, {
    headers: {
      'Content-Type': 'text/event-stream',
      'Cache-Control': 'no-cache, no-transform',
      'Connection': 'keep-alive',
    },
  });
}
