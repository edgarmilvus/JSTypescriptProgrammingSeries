/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script_part3.tsx
// Description: Advanced Application Script
// ==========================================

// app/components/ChatInterface.tsx
'use client';

import React, { useState, useEffect, useRef } from 'react';

/**
 * ------------------------------------------------------------------
 * 3. CLIENT-SIDE: REACT COMPONENT
 * ------------------------------------------------------------------
 * This component handles the connection to the SSE API route.
 * It uses a standard browser EventSource to maintain the connection.
 */

interface ChatMessage {
  role: 'user' | 'assistant';
  content: string;
}

export default function ChatInterface() {
  const [input, setInput] = useState<string>('');
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [isStreaming, setIsStreaming] = useState<boolean>(false);
  
  // Ref to track the EventSource instance to allow cleanup
  const eventSourceRef = useRef<EventSource | null>(null);

  /**
   * Handles sending the prompt and initiating the stream.
   */
  const handleSend = async () => {
    if (!input.trim()) return;

    // 1. Add user message immediately to UI
    const userMessage: ChatMessage = { role: 'user', content: input };
    setMessages((prev) => [...prev, userMessage]);
    setInput('');
    setIsStreaming(true);

    // 2. Initialize Server-Sent Events connection
    // In a real app, this URL would be proxied via Nginx (e.g., /api/chat/stream)
    const eventSource = new EventSource('/api/chat/stream', {
      withCredentials: false, // Adjust based on auth needs
    });

    eventSourceRef.current = eventSource;

    // 3. Handle incoming stream messages
    eventSource.onmessage = (event) => {
      if (event.data === '[DONE]') {
        eventSource.close();
        setIsStreaming(false);
        return;
      }

      try {
        // Parse the JSON payload sent by the server
        const data = JSON.parse(event.data);
        const token = data.choices[0]?.delta?.content;

        if (token) {
          // Update state with the new token
          setMessages((prev) => {
            const newMessages = [...prev];
            // Append to the last assistant message or create a new one
            const lastMsg = newMessages[newMessages.length - 1];
            
            if (lastMsg && lastMsg.role === 'assistant') {
              lastMsg.content += token;
            } else {
              newMessages.push({ role: 'assistant', content: token });
            }
            return newMessages;
          });
        }
      } catch (err) {
        console.error("Error parsing stream data:", err);
      }
    };

    // 4. Handle errors (e.g., Nginx connection issues)
    eventSource.onerror = (err) => {
      console.error("EventSource failed:", err);
      eventSource.close();
      setIsStreaming(false);
    };
  };

  // Cleanup effect to close connection if component unmounts
  useEffect(() => {
    return () => {
      if (eventSourceRef.current) {
        eventSourceRef.current.close();
      }
    };
  }, []);

  return (
    <div className="max-w-2xl mx-auto p-6 bg-white shadow-lg rounded-lg">
      <div className="border-b pb-4 mb-4 h-64 overflow-y-auto space-y-3">
        {messages.map((msg, idx) => (
          <div key={idx} className={`p-3 rounded ${msg.role === 'user' ? 'bg-blue-100 text-right' : 'bg-gray-100 text-left'}`}>
            <p className="font-semibold text-sm text-gray-600 mb-1">
              {msg.role === 'user' ? 'You' : 'AI Assistant'}
            </p>
            <p className="text-gray-800">{msg.content}</p>
          </div>
        ))}
        {isStreaming && (
          <div className="text-gray-400 italic">AI is typing...</div>
        )}
      </div>

      <div className="flex gap-2">
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && handleSend()}
          placeholder="Ask the AI something..."
          className="flex-1 border rounded px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
          disabled={isStreaming}
        />
        <button
          onClick={handleSend}
          disabled={isStreaming}
          className={`px-4 py-2 rounded font-medium text-white ${
            isStreaming ? 'bg-gray-400 cursor-not-allowed' : 'bg-blue-600 hover:bg-blue-700'
          }`}
        >
          Send
        </button>
      </div>
    </div>
  );
}
