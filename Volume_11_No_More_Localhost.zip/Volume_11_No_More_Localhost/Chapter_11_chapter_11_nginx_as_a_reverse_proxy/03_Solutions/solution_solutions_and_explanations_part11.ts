/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part11.ts
// Description: Solutions and Explanations
// ==========================================

// File: load-test.ts (Logic Outline)
// Run with: npx ts-node load-test.ts
import axios from 'axios';

const URL = 'http://localhost/status'; // Nginx Proxy
const REQUESTS = 100;

async function runLoadTest() {
    const results: Record<string, number> = {};
    
    const promises = Array(REQUESTS).fill(null).map(() => 
        axios.get(URL).then(res => {
            const serverId = res.headers['x-server-id'];
            results[serverId] = (results[serverId] || 0) + 1;
        }).catch(err => console.error(err.message))
    );

    await Promise.all(promises);

    console.log('Load Distribution:', results);
    // Expected Output approx: { 'Server-Primary': 70, 'Server-Secondary': 30 }
}

runLoadTest();
