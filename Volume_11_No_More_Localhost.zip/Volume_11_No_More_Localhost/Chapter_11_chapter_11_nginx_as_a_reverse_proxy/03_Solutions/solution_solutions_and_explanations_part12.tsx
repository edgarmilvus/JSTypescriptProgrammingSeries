/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part12.tsx
// Description: Solutions and Explanations
// ==========================================

// File: UpstreamStatusMonitor.tsx
import React, { useState, useEffect } from 'react';

// Define types for the server status
type ServerStatus = 'up' | 'down' | 'unhealthy';
interface Server {
  name: string;
  url: string;
  status: ServerStatus;
}

const UpstreamStatusMonitor: React.FC = () => {
  const [servers, setServers] = useState<Server[]>([
    { name: 'API Primary', url: 'http://app-api-primary:3000', status: 'unhealthy' },
    { name: 'API Secondary', url: 'http://app-api-secondary:3000', status: 'unhealthy' },
    { name: 'Worker Service', url: 'http://app-worker:4000', status: 'unhealthy' },
  ]);

  // Simulate polling every 5 seconds
  useEffect(() => {
    const interval = setInterval(() => {
      // In a real app, we would fetch status from an API endpoint.
      // Here, we simulate random status changes.
      setServers(prevServers => 
        prevServers.map(server => {
          const random = Math.random();
          let newStatus: ServerStatus = 'up';
          
          if (random < 0.1) newStatus = 'down';
          else if (random < 0.25) newStatus = 'unhealthy';
          
          return { ...server, status: newStatus };
        })
      );
    }, 5000);

    // Cleanup interval on unmount
    return () => clearInterval(interval);
  }, []);

  // Helper to get color based on status
  const getStatusColor = (status: ServerStatus): string => {
    switch (status) {
      case 'up': return 'green';
      case 'down': return 'red';
      case 'unhealthy': return 'orange';
      default: return 'gray';
    }
  };

  return (
    <div style={{ padding: '20px', fontFamily: 'Arial, sans-serif' }}>
      <h3>Upstream Status Monitor</h3>
      <ul style={{ listStyle: 'none', padding: 0 }}>
        {servers.map((server, index) => (
          <li key={index} style={{ marginBottom: '10px', display: 'flex', alignItems: 'center' }}>
            <span 
              style={{ 
                display: 'inline-block', 
                width: '12px', 
                height: '12px', 
                borderRadius: '50%', 
                backgroundColor: getStatusColor(server.status),
                marginRight: '10px'
              }}
            ></span>
            <strong>{server.name}</strong>: <span style={{ marginLeft: '5px' }}>{server.status}</span>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default UpstreamStatusMonitor;
