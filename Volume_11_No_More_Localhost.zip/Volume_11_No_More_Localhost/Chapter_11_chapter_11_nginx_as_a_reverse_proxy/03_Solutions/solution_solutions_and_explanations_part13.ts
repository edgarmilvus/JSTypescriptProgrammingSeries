/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part13.ts
// Description: Solutions and Explanations
// ==========================================

# File: nginx-advanced.conf
events {
    worker_connections 1024;
}

http {
    # Standard User App Upstream
    upstream user_app {
        server app-user:3000;
    }

    # Admin Tool Upstream
    upstream admin_app {
        server app-admin:4000;
    }

    # Server Block 1: User Facing
    server {
        listen 80;
        server_name app.example.com;

        location / {
            proxy_pass http://user_app;
            proxy_set_header Host $host;
        }
    }

    # Server Block 2: Internal Admin
    server {
        listen 80;
        server_name admin.example.com;

        location / {
            # Check for the custom header
            # $http_ prefix maps to headers (e.g., X-Internal-Access -> http_x_internal_access)
            if ($http_x_internal_access = "true") {
                proxy_pass http://admin_app;
                break;
            }

            # If header is missing or incorrect
            return 403 "Forbidden: Invalid or missing internal access header.\n";
        }
    }
}
