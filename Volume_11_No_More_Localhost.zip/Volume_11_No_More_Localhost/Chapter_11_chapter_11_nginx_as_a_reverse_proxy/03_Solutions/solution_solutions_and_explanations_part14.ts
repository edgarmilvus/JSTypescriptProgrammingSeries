/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part14.ts
// Description: Solutions and Explanations
// ==========================================

# File: docker-compose.yml (Networking snippet)
services:
  # ... other services ...
  nginx-proxy:
    # ... config ...
    ports:
      - "80:80"
    # Docker Compose automatically creates a network where service names 
    # can be used as hostnames. 
    # However, 'app.example.com' is an external domain.
    # To resolve external domains inside the container, we rely on:
    # 1. The host's /etc/hosts (if manually mapped)
    # 2. Or, for this specific Nginx config, the Host header is just a string 
    #    Nginx uses for routing, not necessarily a resolvable IP inside Docker 
    #    unless we define those services in the compose file.
    
    # For the config above to work with Docker Compose, we need services 
    # named 'app-user' and 'app-admin' defined in this file.
