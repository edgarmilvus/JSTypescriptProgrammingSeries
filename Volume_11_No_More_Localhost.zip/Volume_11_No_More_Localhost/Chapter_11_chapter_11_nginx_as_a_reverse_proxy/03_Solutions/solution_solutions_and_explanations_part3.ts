/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

# File: nginx.conf
events {
    worker_connections 1024;
}

http {
    # Define upstreams using Docker Compose service names
    upstream api_backend {
        server app-api:3000;
    }

    upstream worker_backend {
        server app-worker:4000;
    }

    server {
        listen 80;
        server_name localhost;

        # Route for API
        # Matches /api/v1/ and captures everything after it
        location /api/v1/ {
            # Rewrite the URI to remove the prefix /api/v1/
            # $1 contains the regex capture group (the path after /api/v1/)
            rewrite ^/api/v1/(.*)$ /$1 break;
            
            proxy_pass http://api_backend;
            proxy_set_header Host $host;
            proxy_set_header X-Real-IP $remote_addr;
        }

        # Route for Worker
        # Matches /worker/ and captures everything after it
        location /worker/ {
            # Rewrite the URI to remove the prefix /worker/
            rewrite ^/worker/(.*)$ /$1 break;
            
            proxy_pass http://worker_backend;
            proxy_set_header Host $host;
            proxy_set_header X-Real-IP $remote_addr;
        }

        # Optional: Handle root or unmatched routes
        location / {
            return 404 "Route not found. Use /api/v1/ or /worker/\n";
        }
    }
}
