/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * @file registry-client.ts
 * @description A minimal TypeScript client to interact with a Docker Registry API (v2).
 * This script demonstrates authenticating, uploading a blob, and initiating a pull.
 * 
 * Note: This uses native 'fetch' available in Node.js 18+.
 */

import * as crypto from 'crypto';
import * as fs from 'fs';
import * as path from 'path';

// --- Configuration ---
const REGISTRY_URL = 'http://localhost:5000'; // Localhost registry
const IMAGE_NAME = 'my-ai-app';
const TAG = 'v1';
const IMAGE_PATH = './layers.tar'; // A dummy tarball representing our image layer

// --- Types ---
interface RegistryAuth {
    realm: string;
    service: string;
    scope: string;
}

interface RegistryLayer {
    digest: string;
    size: number;
}

/**
 * Calculates the SHA256 digest of a file.
 * @param filePath - Path to the file to hash.
 * @returns Promise<string> The sha256 hash prefixed with 'sha256:'.
 */
async function calculateDigest(filePath: string): Promise<string> {
    return new Promise((resolve, reject) => {
        const hash = crypto.createHash('sha256');
        const stream = fs.createReadStream(filePath);
        stream.on('data', (data) => hash.update(data));
        stream.on('end', () => resolve(`sha256:${hash.digest('hex')}`));
        stream.on('error', reject);
    });
}

/**
 * Parses the 'WWW-Authenticate' header to extract realm, service, and scope.
 * Example Header: Bearer realm="http://localhost:5000/v2/token",service="registry.docker.io",scope="repository:my-ai-app:pull,push"
 * @param authHeader - The string from the WWW-Authenticate header.
 */
function parseAuthHeader(authHeader: string): RegistryAuth {
    const parts = authHeader.split(',').map(p => p.trim());
    const config: any = {};
    parts.forEach(part => {
        const [key, value] = part.split('=');
        config[key] = value.replace(/"/g, '');
    });
    return {
        realm: config.realm,
        service: config.service,
        scope: config.scope
    };
}

/**
 * Step 1: Initiate Upload
 * Requests to start a new upload session for a specific image.
 * @param imageName - Name of the image.
 * @returns The URL for the upload location.
 */
async function startUpload(imageName: string): Promise<string> {
    const url = `${REGISTRY_URL}/v2/${imageName}/blobs/uploads/`;
    const response = await fetch(url, { method: 'POST' });
    
    if (!response.ok) {
        throw new Error(`Failed to start upload: ${response.status}`);
    }
    
    const location = response.headers.get('Location');
    if (!location) {
        throw new Error('No upload location provided by registry');
    }
    
    console.log(`[+] Upload session started at: ${location}`);
    return location;
}

/**
 * Step 2: Upload Blob
 * Pushes the actual file data to the registry.
 * @param uploadUrl - The URL provided by startUpload.
 * @param filePath - Path to the image layer file.
 * @param digest - The calculated SHA256 digest of the file.
 */
async function uploadBlob(uploadUrl: string, filePath: string, digest: string): Promise<void> {
    const fileBuffer = fs.readFileSync(filePath);
    const url = `${uploadUrl}?digest=${digest}`;
    
    const response = await fetch(url, {
        method: 'PUT',
        body: fileBuffer,
        headers: {
            'Content-Type': 'application/octet-stream'
        }
    });

    if (!response.ok) {
        throw new Error(`Failed to upload blob: ${response.status}`);
    }
    
    console.log(`[+] Blob uploaded successfully. Digest: ${digest}`);
}

/**
 * Step 3: Manifest Upload
 * Pushes the manifest JSON which defines the image structure.
 * @param imageName - Name of the image.
 * @param tag - Tag (e.g., 'v1').
 * @param digest - The digest of the layer blob.
 */
async function pushManifest(imageName: string, tag: string, digest: string): Promise<void> {
    // In a real scenario, this JSON is complex (config, layers). 
    // Here we create a minimal manifest pointing to our single layer.
    const manifest = {
        schemaVersion: 2,
        mediaType: "application/vnd.docker.distribution.manifest.v2+json",
        config: {
            mediaType: "application/vnd.docker.container.image.v1+json",
            size: 1024, // Dummy size
            digest: digest // Pointing to the same digest for simplicity
        },
        layers: [
            {
                mediaType: "application/vnd.docker.image.rootfs.diff.tar.gzip",
                size: 1024,
                digest: digest
            }
        ]
    };

    const url = `${REGISTRY_URL}/v2/${imageName}/manifests/${tag}`;
    const response = await fetch(url, {
        method: 'PUT',
        body: JSON.stringify(manifest),
        headers: {
            'Content-Type': 'application/vnd.docker.distribution.manifest.v2+json'
        }
    });

    if (!response.ok) {
        const errText = await response.text();
        throw new Error(`Failed to push manifest: ${response.status} - ${errText}`);
    }

    console.log(`[+] Manifest pushed: ${imageName}:${tag}`);
}

/**
 * Step 4: Pull Check (Simulated)
 * Verifies the image exists and is accessible.
 * @param imageName - Name of the image.
 * @param tag - Tag to check.
 */
async function checkPull(imageName: string, tag: string): Promise<void> {
    const url = `${REGISTRY_URL}/v2/${imageName}/manifests/${tag}`;
    const response = await fetch(url, { method: 'HEAD' });

    if (response.ok) {
        console.log(`[✓] Image ${imageName}:${tag} is ready for pull.`);
    } else {
        throw new Error(`Image ${imageName}:${tag} not found.`);
    }
}

/**
 * Main Orchestrator
 * 1. Creates a dummy file (simulating an image layer).
 * 2. Calculates Digest.
 * 3. Starts Upload.
 * 4. Uploads Blob.
 * 5. Pushes Manifest.
 * 6. Verifies Pull.
 */
async function main() {
    try {
        console.log('--- Docker Registry Client Demo ---');
        
        // Setup: Create a dummy layer file if it doesn't exist
        if (!fs.existsSync(IMAGE_PATH)) {
            console.log(`[+] Creating dummy layer file: ${IMAGE_PATH}`);
            fs.writeFileSync(IMAGE_PATH, 'Simulated container layer content');
        }

        // 1. Calculate Digest
        console.log('[*] Calculating file digest...');
        const digest = await calculateDigest(IMAGE_PATH);
        console.log(`[+] Digest calculated: ${digest}`);

        // 2. Start Upload Session
        const uploadLocation = await startUpload(IMAGE_NAME);

        // 3. Upload the Blob (Layer)
        await uploadBlob(uploadLocation, IMAGE_PATH, digest);

        // 4. Push the Manifest
        await pushManifest(IMAGE_NAME, TAG, digest);

        // 5. Verify
        await checkPull(IMAGE_NAME, TAG);

        console.log('\n--- Process Complete ---');
        console.log(`You can now run: docker pull ${REGISTRY_URL}/${IMAGE_NAME}:${TAG}`);

    } catch (error) {
        console.error('❌ Error occurred:', error);
    }
}

// Execute
main();
