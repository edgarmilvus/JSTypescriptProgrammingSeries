/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// pages/api/build-and-push.ts
// Next.js API Route for orchestrating Docker builds and pushes to GHCR.

import { NextApiRequest, NextApiResponse } from 'next';
import Docker from 'dockerode';
import stream from 'stream';
import path from 'path';
import fs from 'fs';

/**
 * @description Configuration interface for registry credentials.
 * In a production environment, these should be injected via environment variables
 * or a secrets manager (e.g., AWS Secrets Manager, HashiCorp Vault).
 */
interface RegistryConfig {
  registryUrl: string; // e.g., 'ghcr.io'
  username: string;
  token: string; // GitHub Personal Access Token (PAT) with write:packages scope
}

/**
 * @description Request body interface for the API endpoint.
 */
interface BuildRequest {
  modelName: string;
  version: string; // Semantic versioning (e.g., '1.0.0')
  baseImage: string; // e.g., 'node:18-alpine' or 'python:3.9-slim'
  dockerfileContent: string; // The Dockerfile content as a string
}

/**
 * @description Main handler for the API route.
 * 
 * UNDER THE HOOD:
 * 1. It receives a request to build a specific AI model container.
 * 2. It creates a temporary Dockerfile on disk (simulating a build context).
 * 3. It initializes the Docker daemon connection via Dockerode.
 * 4. It builds the image, streams logs, and tags it for GHCR.
 * 5. It authenticates against GHCR and pushes the image.
 * 6. It cleans up temporary files.
 */
export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  // Only allow POST requests
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method Not Allowed' });
  }

  const { modelName, version, baseImage, dockerfileContent } = req.body as BuildRequest;

  // 1. Validate Inputs
  if (!modelName || !version || !baseImage || !dockerfileContent) {
    return res.status(400).json({ error: 'Missing required fields: modelName, version, baseImage, dockerfileContent' });
  }

  // 2. Setup Registry Configuration (Simulated for GHCR)
  const registryConfig: RegistryConfig = {
    registryUrl: 'ghcr.io',
    username: process.env.GHCR_USERNAME || 'your-github-username',
    token: process.env.GHCR_TOKEN || 'your-github-pat',
  };

  // 3. Construct Image Tag
  // Format: ghcr.io/{username}/{modelName}:{version}
  const imageName = `${registryConfig.registryUrl}/${registryConfig.username}/${modelName.toLowerCase()}`;
  const fullTag = `${imageName}:${version}`;

  try {
    // 4. Initialize Docker Daemon Connection
    // Note: In a containerized environment (like Vercel), this requires mounting the Docker socket.
    // For local development, this connects to the local Docker Desktop.
    const docker = new Docker({
      socketPath: '/var/run/docker.sock',
    });

    // 5. Create a Temporary Build Context
    // We write the Dockerfile content to a temporary directory to create a valid build context.
    const tempDir = path.join(process.cwd(), 'tmp', `build-${Date.now()}`);
    if (!fs.existsSync(tempDir)) {
      fs.mkdirSync(tempDir, { recursive: true });
    }

    const dockerfilePath = path.join(tempDir, 'Dockerfile');
    fs.writeFileSync(dockerfilePath, dockerfileContent);

    // 6. Build the Docker Image
    // We use docker.buildImage with a tar stream (simulated here by pointing to the directory).
    // The `emulateTerminal` option helps in capturing detailed logs.
    console.log(`Starting build for image: ${fullTag}`);
    
    const buildStream = await docker.buildImage(
      {
        context: tempDir,
        src: ['Dockerfile'], // In a real scenario, include model artifacts here
      },
      {
        t: fullTag,
        buildargs: {
          BASE_IMAGE: baseImage,
        }
      }
    );

    // Stream build logs to the console (or a logging service)
    await new Promise((resolve, reject) => {
      docker.modem.followProgress(buildStream, (err, res) => err ? reject(err) : resolve(res), (event) => {
        if (event.stream) process.stdout.write(event.stream);
      });
    });

    // 7. Authenticate with the Registry
    // Dockerode requires an authconfig object to push to a private/protected registry like GHCR.
    const authConfig = {
      username: registryConfig.username,
      password: registryConfig.token,
      serveraddress: registryConfig.registryUrl,
    };

    console.log(`Authenticating with ${registryConfig.registryUrl}...`);

    // 8. Push the Image
    // We retrieve the image object by the tag and call push().
    const image = docker.getImage(fullTag);
    const pushStream = await image.push({ authconfig: authConfig });

    // Stream push logs
    await new Promise((resolve, reject) => {
      docker.modem.followProgress(pushStream, (err, res) => err ? reject(err) : resolve(res), (event) => {
        if (event.status) console.log(`Push Status: ${event.status} ${event.progress || ''}`);
        if (event.error) {
          console.error(`Push Error: ${event.error}`);
          reject(new Error(event.error));
        }
      });
    });

    // 9. Cleanup
    // Remove the temporary directory and the local image to save space
    fs.rmSync(tempDir, { recursive: true, force: true });
    // Optionally remove the local image: await image.remove();

    // 10. Return Success Response
    return res.status(200).json({
      success: true,
      message: 'Image built and pushed successfully',
      imageUrl: `${fullTag}`,
      digest: 'sha256:...', // In production, parse the push logs for the actual digest
    });

  } catch (error: any) {
    console.error('Build Pipeline Error:', error.message);
    
    // Ensure cleanup happens even on error
    // (Logic for temp dir cleanup would go here in a finally block)
    
    return res.status(500).json({
      success: false,
      error: 'Failed to build or push image',
      details: error.message,
    });
  }
}
