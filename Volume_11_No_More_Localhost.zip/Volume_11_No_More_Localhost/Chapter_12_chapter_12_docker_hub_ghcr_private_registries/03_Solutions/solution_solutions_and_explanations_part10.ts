/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part10.ts
// Description: Solutions and Explanations
// ==========================================

# 1. Create a volume for the registry data
docker volume create registry-data

# 2. Generate htpasswd file (Requires 'htpasswd' utility usually found in 'apache2-utils')
# Create a temporary directory for auth
mkdir auth
# Create a new file with user 'admin' and password 'password123'
docker run --entrypoint htpasswd httpd:2 -Bbn admin password123 > auth/htpasswd

# 3. Create a volume for the auth file
docker volume create registry-auth
# We need to copy the file into the volume. 
# A trick is to run a temporary container to copy the file into the volume.
docker run --rm -v $(pwd)/auth:/source -v registry-auth:/dest alpine cp /source/htpasswd /dest/htpasswd

# 4. Run the Private Registry
docker run -d \
  -p 5000:5000 \
  --name private-registry \
  -v registry-data:/var/lib/registry \
  -v registry-auth:/auth \
  -e REGISTRY_AUTH=htpasswd \
  -e REGISTRY_AUTH_HTPASSWD_PATH=/auth/htpasswd \
  -e REGISTRY_AUTH_HTPASSWD_REALM="Registry Realm" \
  registry:2
