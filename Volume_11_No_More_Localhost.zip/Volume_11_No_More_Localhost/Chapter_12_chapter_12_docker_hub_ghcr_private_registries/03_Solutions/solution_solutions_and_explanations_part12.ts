/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part12.ts
// Description: Solutions and Explanations
// ==========================================

# 1. Login to the local registry (will prompt for password: password123)
docker login localhost:5000 -u admin -p password123

# 2. Push the image
docker push localhost:5000/my-ai-model:1.0

# 3. Remove local image to simulate clean environment
docker rmi localhost:5000/my-ai-model:1.0

# 4. Pull the image (Success - logged in)
docker pull localhost:5000/my-ai-model:1.0

# 5. Verify content
docker run --rm localhost:5000/my-ai-model:1.0

# 6. Test Security (Failure - not logged in)
# First, log out to clear credentials from the Docker config
docker logout localhost:5000

# Attempt to pull again (This should fail with 'no basic auth credentials')
docker pull localhost:5000/my-ai-model:1.0 || echo "Security check passed: Pull failed as expected."
