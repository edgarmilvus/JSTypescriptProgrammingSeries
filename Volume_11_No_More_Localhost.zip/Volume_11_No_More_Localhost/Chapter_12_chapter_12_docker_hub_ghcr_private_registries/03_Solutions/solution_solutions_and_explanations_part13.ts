/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part13.ts
// Description: Solutions and Explanations
// ==========================================

import express, { Request, Response } from 'express';

const app = express();
app.use(express.json());

// SIMULATED WASM FUNCTION
// In a real app, this would be: const instance = await WebAssembly.instantiate(wasmBuffer);
// and we would call instance.exports.parallel_multiply(...)
function simulateWasmParallelMultiply(a: number[], b: number[], threads: number): number[] {
    console.log(`Processing with ${threads} threads...`);
    // Simulate heavy computation delay based on thread count (inverse scaling)
    // Real WASM threads would utilize WebWorkers or pthreads.
    const delay = 1000 / threads; 
    const start = Date.now();
    
    // Simulate computation
    const result = a.map((val, idx) => val * (b[idx] || 1));
    
    // Artificial delay to simulate CPU load
    const end = Date.now();
    if (end - start < delay) {
        const wait = delay - (end - start);
        const busyWait = Date.now();
        while (Date.now() - busyWait < wait) {} 
    }
    
    return result;
}

app.post('/compute', (req: Request, res: Response) => {
    const { a, b, threads } = req.body;
    
    if (!a || !b || !threads) {
        return res.status(400).json({ error: "Missing inputs" });
    }

    const startTime = Date.now();
    
    // Call the "WASM" function
    const result = simulateWasmParallelMultiply(a, b, threads);
    
    const duration = Date.now() - startTime;

    res.json({
        result_length: result.length,
        threads_used: threads,
        duration_ms: duration
    });
});

app.listen(8080, () => {
    console.log("WASM Compute Server running on port 8080");
});
