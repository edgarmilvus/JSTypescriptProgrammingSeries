/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part15.ts
// Description: Solutions and Explanations
// ==========================================

// Run this locally or in another container to test the API
async function testScaling() {
    const baseUrl = "http://localhost:8080"; // Adjust if running in Docker
    const threadCounts = [1, 2, 4, 8];
    const inputSize = 1000000; // 1 million elements

    // Generate dummy data
    const a = new Array(inputSize).fill(1);
    const b = new Array(inputSize).fill(2);

    console.log(`Testing scaling with input size: ${inputSize}`);

    for (const threads of threadCounts) {
        try {
            const start = Date.now();
            const res = await fetch(`${baseUrl}/compute`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ a, b, threads })
            });
            const data = await res.json();
            const totalTime = Date.now() - start;
            
            console.log(`Threads: ${threads} | Server Duration: ${data.duration_ms}ms | Total Request Time: ${totalTime}ms`);
        } catch (e) {
            console.error(`Error with ${threads} threads:`, e);
        }
    }
}

// Execute if running directly
if (require.main === module) {
    testScaling();
}
