/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part16.ts
// Description: Solutions and Explanations
// ==========================================

# Performance Scaling Hypothesis

## Observation
When running the containerized WASM/Node.js server, increasing the thread count (e.g., from 1 to 8) may not result in linear performance improvement.

## Hypothesis
The lack of linear scaling is due to **CPU Resource Constraints**:

1.  **Docker CPU Limits:** By default, Docker containers have access to all host CPU cores. However, if the container is run with a limit (e.g., `--cpus="1.0"`), the container is capped at the equivalent of 1 CPU core. Even if the WASM code spawns 8 threads, they must share that 1 core, leading to context switching overhead rather than parallel execution.
2.  **Host Core Count:** If the host machine has fewer physical cores than the requested threads (e.g., requesting 8 threads on a 4-core machine), the OS scheduler cannot run all threads simultaneously.
3.  **WASM Threading Overhead:** In JavaScript environments, WASM threads often rely on Web Workers (or Node.js Worker Threads), which have overhead for data serialization and thread management. For small computations, this overhead can outweigh the benefits of parallelism.

## Conclusion
To achieve true linear scaling, the Docker container must be granted sufficient CPU resources (matching or exceeding the thread count), and the underlying host must have enough physical cores to support the workload.
