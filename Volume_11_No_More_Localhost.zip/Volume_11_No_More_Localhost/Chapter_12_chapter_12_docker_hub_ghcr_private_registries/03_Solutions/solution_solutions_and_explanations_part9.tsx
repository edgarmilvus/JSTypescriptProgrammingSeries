/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part9.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState, useEffect, useCallback } from 'react';
import { RegistryImage, ImageRegistryStatusProps } from './types';
import { useDebounce } from './useDebounce';

const ImageRegistryStatus: React.FC<ImageRegistryStatusProps> = ({ registry, imageName }) => {
  const [data, setData] = useState<RegistryImage | null>(null);
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [refreshCount, setRefreshCount] = useState<number>(0);

  // Debounce the refresh count to prevent rapid API calls
  const debouncedRefresh = useDebounce(refreshCount, 500);

  const fetchData = useCallback(async () => {
    setLoading(true);
    setError(null);
    console.log(`Fetching data at: ${new Date().toISOString()}`);

    try {
      // SIMULATED API CALL
      // In a real app, this would be fetch(`https://api.${registry}/v2/${imageName}/tags`)
      await new Promise(resolve => setTimeout(resolve, 1000)); // Simulate network delay

      const mockResponse: RegistryImage = {
        name: imageName,
        registry: registry,
        tags: [
          { tag: 'latest', size: '12.4 MB', lastPushed: '2023-10-27T10:00:00Z' },
          { tag: '1.0.0', size: '12.4 MB', lastPushed: '2023-10-26T14:30:00Z' },
          { tag: 'sha-abc1234', size: '12.4 MB', lastPushed: '2023-10-25T09:15:00Z' },
        ],
      };
      setData(mockResponse);
    } catch (err) {
      setError("Failed to fetch image data.");
    } finally {
      setLoading(false);
    }
  }, [registry, imageName]);

  useEffect(() => {
    if (debouncedRefresh > 0) {
      fetchData();
    }
  }, [debouncedRefresh, fetchData]);

  const handleCopyPullCommand = (tag: string) => {
    const registryUrl = registry === 'docker-hub' ? '' : `${registry}/`;
    const command = `docker pull ${registryUrl}${imageName}:${tag}`;
    navigator.clipboard.writeText(command);
    alert(`Copied: ${command}`);
  };

  const handleRefresh = () => {
    setRefreshCount(prev => prev + 1);
  };

  if (loading && refreshCount === 0) return <div>Loading initial data...</div>;
  if (error) return <div style={{ color: 'red' }}>Error: {error}</div>;

  return (
    <div style={{ border: '1px solid #ccc', padding: '16px', borderRadius: '8px', maxWidth: '600px' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <h3>{data?.name} <small>({data?.registry})</small></h3>
        <button onClick={handleRefresh} disabled={loading}>
          {loading ? 'Refreshing...' : 'Refresh'}
        </button>
      </div>

      <ul style={{ listStyle: 'none', padding: 0 }}>
        {data?.tags.map((tagInfo) => (
          <li key={tagInfo.tag} style={{ marginBottom: '10px', padding: '10px', background: '#f9f9f9' }}>
            <strong>{tagInfo.tag}</strong> - Size: {tagInfo.size} <br />
            <small>Last Pushed: {tagInfo.lastPushed}</small>
            <button 
              onClick={() => handleCopyPullCommand(tagInfo.tag)} 
              style={{ marginLeft: '10px', fontSize: '0.8rem' }}
            >
              Copy Pull Command
            </button>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default ImageRegistryStatus;
