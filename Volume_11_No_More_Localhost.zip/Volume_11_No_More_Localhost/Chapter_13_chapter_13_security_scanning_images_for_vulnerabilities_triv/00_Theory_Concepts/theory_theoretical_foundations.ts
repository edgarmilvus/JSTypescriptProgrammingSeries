/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: theory_theoretical_foundations.ts
// Description: Theoretical Foundations
// ==========================================

digraph VulnerabilityLayers {
    rankdir=TB;
    node [shape=box, style=filled, fillcolor=lightgrey];

    subgraph cluster_image {
        label = "Docker Image Layers (The Meal Kit)";
        style = dashed;
        
        L1 [label="Your Application Code\n(Copy of your .ts files)", fillcolor="#a7c7e7"];
        L2 [label="Node.js Dependencies\n(node_modules from package-lock.json)", fillcolor="#ffd700"];
        L3 [label="System Packages\n(apk add / apt-get install)", fillcolor="#ff9999"];
        L4 [label="Base OS Image\n(e.g., node:20-alpine)", fillcolor="#ff6666"];
        
        L1 -> L2 -> L3 -> L4;
    }

    DB [label="Vulnerability Database\n(NVD / CVE List)", shape=database, fillcolor="#c3e6cb"];

    Scanner [label="Trivy Scanner\n(The Security Audit)", shape=ellipse, fillcolor="#fff3cd"];

    // Scanner inspects the image layers
    Scanner -> L1 [label="Scans"];
    Scanner -> L2;
    Scanner -> L3;
    Scanner -> L4;

    // Scanner cross-references with the DB
    Scanner -> DB [label="Cross-references", dir=both, constraint=false];

    // Outputs
    Report [label="Vulnerability Report\n(CVEs, Severity, Fix Version)", shape=note, fillcolor="#f8d7da"];
    Scanner -> Report;
}
