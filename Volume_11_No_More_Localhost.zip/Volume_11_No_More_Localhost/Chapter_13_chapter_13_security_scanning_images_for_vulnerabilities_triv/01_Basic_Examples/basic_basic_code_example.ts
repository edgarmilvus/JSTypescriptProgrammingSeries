/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * @file security-gatekeeper.ts
 * @description A TypeScript script to scan a Docker image using Trivy and enforce security policies.
 * @context SaaS/CI-CD Pipeline Context
 */

import { execSync, spawnSync } from 'child_process';
import { readFileSync, unlinkSync, existsSync } from 'fs';
import path from 'path';

// ============================================================================
// 1. CONFIGURATION & TYPES
// ============================================================================

/**
 * Represents a vulnerability entry in Trivy's JSON output.
 * We focus on the essential fields for this 'Hello World' example.
 */
interface TrivyVulnerability {
  Target: string;          // The file/package where the vulnerability exists (e.g., package.json)
  VulnerabilityID: string; // The CVE ID (e.g., CVE-2023-1234)
  Severity: string;        // CRITICAL, HIGH, MEDIUM, LOW, UNKNOWN
  Title: string;           // Human-readable description
  PkgName: string;         // The npm package name
}

/**
 * Configuration for the security scan.
 * In a real app, these would come from environment variables.
 */
const CONFIG = {
  // The Docker image to scan (e.g., your built AI app image)
  IMAGE_NAME: 'my-nodejs-ai-app:latest',
  // Path to save the temporary Trivy report
  OUTPUT_PATH: path.join(__dirname, 'trivy-report.json'),
  // Policy: Fail the build if vulnerabilities of this severity or higher are found
  BLOCK_THRESHOLD: 'HIGH' 
};

// ============================================================================
// 2. HELPER FUNCTIONS
// ============================================================================

/**
 * Checks if Trivy is installed on the system.
 * @throws {Error} If Trivy is not found.
 */
function checkTrivyInstallation(): void {
  try {
    // We run 'trivy --version' to check existence.
    // execSync throws an error if the command fails (non-zero exit code).
    execSync('trivy --version', { stdio: 'ignore' });
    console.log('✅ Trivy is installed.');
  } catch (error) {
    console.error('❌ Error: Trivy is not installed or not in PATH.');
    console.error('Please install Trivy: https://aquasecurity.github.io/trivy/latest/getting-started/installation/');
    process.exit(1);
  }
}

/**
 * Executes the Trivy scan command.
 * Runs: `trivy image --format json --output OUTPUT_PATH IMAGE_NAME`
 * @param imageName - The Docker image to scan.
 * @param outputPath - Where to save the JSON report.
 */
function runTrivyScan(imageName: string, outputPath: string): void {
  console.log(`🔍 Scanning image: ${imageName}...`);
  
  const command = `trivy image --format json --output ${outputPath} ${imageName}`;
  
  try {
    // We use spawnSync to execute the shell command synchronously.
    // stdio: 'inherit' allows us to see Trivy's progress output in the console.
    const result = spawnSync(command, { shell: true, stdio: 'inherit' });

    if (result.status !== 0) {
      // Trivy returns exit code 1 if vulnerabilities are found, but we handle that in parsing.
      // We only want to fail here if Trivy itself crashed (e.g., permission denied).
      if (result.status !== 1) {
        throw new Error(`Trivy execution failed with exit code ${result.status}`);
      }
    }
    console.log('✅ Scan complete. Report generated.');
  } catch (error) {
    console.error('❌ Failed to execute Trivy scan:', error);
    process.exit(1);
  }
}

/**
 * Reads and parses the Trivy JSON report.
 * @param outputPath - Path to the JSON file.
 * @returns Array of vulnerabilities.
 */
function parseTrivyReport(outputPath: string): TrivyVulnerability[] {
  if (!existsSync(outputPath)) {
    throw new Error(`Report file not found at ${outputPath}`);
  }

  try {
    const rawData = readFileSync(outputPath, 'utf-8');
    const jsonData = JSON.parse(rawData);

    // Trivy's JSON structure is an array of 'Results', each containing 'Vulnerabilities'.
    // We flatten this into a single list for easier processing.
    const vulnerabilities: TrivyVulnerability[] = [];

    if (Array.isArray(jsonData)) {
      jsonData.forEach((result) => {
        if (result.Vulnerabilities && Array.isArray(result.Vulnerabilities)) {
          vulnerabilities.push(...result.Vulnerabilities);
        }
      });
    }

    return vulnerabilities;
  } catch (error) {
    console.error('❌ Error parsing Trivy report:', error);
    process.exit(1);
  }
}

/**
 * Evaluates vulnerabilities against the security policy.
 * @param vulnerabilities - List of found CVEs.
 * @param threshold - The severity level to block (e.g., 'HIGH').
 * @returns True if the build passes, False if it should be blocked.
 */
function evaluatePolicy(vulnerabilities: TrivyVulnerability[], threshold: string): boolean {
  // Define severity hierarchy for comparison
  const severityOrder = ['CRITICAL', 'HIGH', 'MEDIUM', 'LOW', 'UNKNOWN'];
  const thresholdIndex = severityOrder.indexOf(threshold);

  if (thresholdIndex === -1) {
    throw new Error(`Invalid severity threshold: ${threshold}`);
  }

  console.log(`\n📊 Policy Check: Blocking vulnerabilities with severity >= ${threshold}`);
  
  const blockedVulnerabilities = vulnerabilities.filter((vuln) => {
    const vulnIndex = severityOrder.indexOf(vuln.Severity);
    // If the vulnerability severity is higher or equal to the threshold, it's a blocker.
    return vulnIndex !== -1 && vulnIndex <= thresholdIndex;
  });

  if (blockedVulnerabilities.length === 0) {
    console.log('✅ Policy Check PASSED: No blocking vulnerabilities found.');
    return true;
  } else {
    console.error(`\n🚨 Policy Check FAILED: Found ${blockedVulnerabilities.length} vulnerabilities of severity >= ${threshold}:`);
    
    // Log details for the first 5 failures to avoid clutter
    blockedVulnerabilities.slice(0, 5).forEach((vuln) => {
      console.error(`   - [${vuln.Severity}] ${vuln.VulnerabilityID} in ${vuln.PkgName}: ${vuln.Title}`);
    });
    
    if (blockedVulnerabilities.length > 5) {
      console.error(`   ... and ${blockedVulnerabilities.length - 5} more.`);
    }
    
    return false;
  }
}

/**
 * Cleans up the temporary report file.
 */
function cleanup(outputPath: string): void {
  if (existsSync(outputPath)) {
    try {
      unlinkSync(outputPath);
      console.log('🧹 Temporary report file cleaned up.');
    } catch (error) {
      console.warn('⚠️ Could not delete temporary report file:', error);
    }
  }
}

// ============================================================================
// 3. MAIN EXECUTION LOGIC
// ============================================================================

/**
 * Main entry point for the Security Gatekeeper.
 * Orchestrates the scan, parsing, and policy enforcement.
 */
function main(): void {
  console.log('🚀 Starting Security Gatekeeper...');
  
  try {
    // Step 1: Ensure environment is ready
    checkTrivyInstallation();

    // Step 2: Run the scan
    runTrivyScan(CONFIG.IMAGE_NAME, CONFIG.OUTPUT_PATH);

    // Step 3: Parse the results
    const vulnerabilities = parseTrivyReport(CONFIG.OUTPUT_PATH);

    // Step 4: Evaluate against policy
    const isSecure = evaluatePolicy(vulnerabilities, CONFIG.BLOCK_THRESHOLD);

    // Step 5: Final decision
    if (!isSecure) {
      console.error('\n⛔ DEPLOYMENT BLOCKED: Security policy violation detected.');
      process.exit(1); // Exit with error code to fail the CI/CD pipeline
    }

    console.log('\n✅ DEPLOYMENT APPROVED: Image is secure.');
    process.exit(0); // Exit successfully

  } catch (error) {
    console.error('\n💥 Unexpected error in Security Gatekeeper:', error);
    process.exit(1);
  } finally {
    // Always clean up the temp file
    cleanup(CONFIG.OUTPUT_PATH);
  }
}

// Run the main function if this file is executed directly
if (require.main === module) {
  main();
}
