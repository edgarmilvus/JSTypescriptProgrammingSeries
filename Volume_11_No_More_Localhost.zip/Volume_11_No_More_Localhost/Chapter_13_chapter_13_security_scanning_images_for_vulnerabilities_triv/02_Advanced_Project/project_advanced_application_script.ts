/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// app/actions/scanImage.ts
'use server';

import { exec } from 'child_process';
import { promisify } from 'util';
import { z } from 'zod';

// Promisify exec to use with async/await
const execAsync = promisify(exec);

/**
 * @typedef {Object} Vulnerability
 * @property {string} VulnerabilityID - The CVE ID (e.g., CVE-2023-1234)
 * @property {string} Severity - CRITICAL, HIGH, MEDIUM, LOW
 * @property {string} Title - Brief description of the vulnerability
 * @property {string} Description - Detailed description
 */

/**
 * @typedef {Object} ScanResult
 * @property {string} image - The scanned image name
 * @property {number} criticalCount - Number of critical vulnerabilities
 * @property {number} highCount - Number of high vulnerabilities
 * @property {Array<Vulnerability>} vulnerabilities - Detailed list
 */

// Input validation schema using Zod
const scanSchema = z.object({
  imageName: z.string().min(1, "Image name is required"),
});

/**
 * SERVER ACTION: Triggers a Trivy scan on a Docker image.
 * 
 * Why Server-Side?
 * 1. Security: Trivy requires installation on the host machine. We cannot run it in the browser.
 * 2. Isolation: The scanning process can be resource-intensive; keeping it on the server protects client performance.
 * 3. Secrets: Access to private registries can be handled securely via server environment variables.
 * 
 * @param {Object} prevState - Previous form state (for Next.js useFormState)
 * @param {Object} formData - Form data containing the image name
 * @returns {Promise<ScanResult | { error: string }>}
 */
export async function triggerImageScan(prevState: any, formData: FormData) {
  try {
    // 1. VALIDATE INPUT
    const rawInput = {
      imageName: formData.get('imageName')?.toString().trim(),
    };
    const result = scanSchema.safeParse(rawInput);

    if (!result.success) {
      return { error: result.error.errors[0].message };
    }

    const { imageName } = result.data;

    // 2. EXECUTE TRIVY SCAN
    // We use 'trivy image' with '--format json' for machine-readable output.
    // '--severity CRITICAL,HIGH' filters results to focus on high-impact issues.
    // '--no-progress' suppresses the progress bar for cleaner logs.
    const command = `trivy image --format json --severity CRITICAL,HIGH --no-progress ${imageName}`;

    // Exhaustive Asynchronous Resilience: Wrap in try/catch
    const { stdout, stderr } = await execAsync(command);

    if (stderr && !stderr.includes("Warning")) {
      // Log stderr but don't necessarily fail if it's just warnings
      console.warn(`Trivy stderr: ${stderr}`);
    }

    // 3. PARSE AND TRANSFORM OUTPUT
    // Trivy JSON output is complex. We flatten it for the frontend.
    const scanData = JSON.parse(stdout);
    
    // Handle case where Trivy returns an empty array (no vulnerabilities found)
    if (!scanData || !Array.isArray(scanData.Results) || scanData.Results.length === 0) {
      return {
        image: imageName,
        criticalCount: 0,
        highCount: 0,
        vulnerabilities: [],
        message: "Scan completed. No vulnerabilities detected or image not found."
      };
    }

    // Extract vulnerabilities from the first result (usually OS packages + language packages)
    const vulnerabilities = scanData.Results.flatMap((result: any) => result.Vulnerabilities || [])
      .map((vuln: any) => ({
        VulnerabilityID: vuln.VulnerabilityID,
        Severity: vuln.Severity,
        Title: vuln.Title || "No title",
        Description: vuln.Description || "No description available",
      }));

    // 4. AGGREGATE METRICS
    const criticalCount = vulnerabilities.filter((v: any) => v.Severity === 'CRITICAL').length;
    const highCount = vulnerabilities.filter((v: any) => v.Severity === 'HIGH').length;

    // 5. RETURN STRUCTURED DATA
    return {
      image: imageName,
      criticalCount,
      highCount,
      vulnerabilities,
    };

  } catch (error: any) {
    // 6. ERROR HANDLING
    // Specifically handle "Trivy not installed" or "Image not found" errors
    console.error("Scan Error:", error);
    
    let errorMessage = "An unexpected error occurred during the scan.";
    
    if (error.stderr) {
      if (error.stderr.includes("command not found") || error.stderr.includes("executable file not found")) {
        errorMessage = "Trivy is not installed on the server. Please install Trivy to use this feature.";
      } else if (error.stderr.includes("No such image")) {
        errorMessage = "The specified Docker image could not be found in the registry.";
      } else {
        errorMessage = error.stderr;
      }
    }

    return { error: errorMessage };
  }
}
