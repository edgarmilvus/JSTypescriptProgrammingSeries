/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script_part3.ts
// Description: Advanced Application Script
// ==========================================

// Example usage in a Client Component
'use client';

import { useActionState } from 'react';
import { triggerImageScan } from '@/app/actions/scanImage';

export default function ScannerForm() {
  const [state, formAction, isPending] = useActionState(triggerImageScan, null);

  return (
    <div>
      <form action={formAction}>
        <input name="imageName" placeholder="e.g., node:18-alpine" />
        <button type="submit" disabled={isPending}>
          {isPending ? 'Scanning...' : 'Scan Image'}
        </button>
      </form>

      {state?.error && <p style={{ color: 'red' }}>{state.error}</p>}
      
      {state?.vulnerabilities && (
        <div>
          <h3>Results for {state.image}</h3>
          <p>Critical: {state.criticalCount} | High: {state.highCount}</p>
          <ul>
            {state.vulnerabilities.map((v: any) => (
              <li key={v.VulnerabilityID} style={{ color: v.Severity === 'CRITICAL' ? 'red' : 'orange' }}>
                <strong>{v.VulnerabilityID}</strong>: {v.Title}
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
}
