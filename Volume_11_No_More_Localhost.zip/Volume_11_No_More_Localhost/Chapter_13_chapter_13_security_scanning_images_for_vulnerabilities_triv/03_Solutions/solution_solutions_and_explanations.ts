/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// Note: This exercise primarily involves CLI commands, but we can create a Node.js script
// to automate the execution of these commands and generate the markdown report programmatically.

// File: audit-script.ts
import { execSync } from 'child_process';
import * as fs from 'fs';

// Configuration
const IMAGE_NAME = 'ai-chatbot:v1.0';
const JSON_REPORT_FILE = 'v1.0-scan-report.json';
const MARKDOWN_REPORT_FILE = 'vulnerability-audit.md';

try {
    console.log(`Starting security audit for ${IMAGE_NAME}...`);

    // 1. Scan the Image and output structured JSON
    console.log(`Generating JSON report at ${JSON_REPORT_FILE}...`);
    const jsonScanCommand = `trivy image --format json --output ${JSON_REPORT_FILE} ${IMAGE_NAME}`;
    execSync(jsonScanCommand, { stdio: 'inherit' });

    // 2. Filter by Severity (High and Critical) to console
    console.log('\n--- High and Critical Vulnerabilities ---');
    const severityScanCommand = `trivy image --severity HIGH,CRITICAL ${IMAGE_NAME}`;
    execSync(severityScanCommand, { stdio: 'inherit' });

    // 3. Identify Root Cause & 4. Documentation
    console.log(`\nGenerating Markdown report at ${MARKDOWN_REPORT_FILE}...`);
    
    // Read the generated JSON report
    const rawData = fs.readFileSync(JSON_REPORT_FILE, 'utf8');
    const scanData = JSON.parse(rawData);

    let totalVulnerabilities = 0;
    const criticalVulns: any[] = [];

    // Parse results
    if (scanData.Results) {
        scanData.Results.forEach((result: any) => {
            if (result.Vulnerabilities) {
                totalVulnerabilities += result.Vulnerabilities.length;
                
                // Filter for Critical vulnerabilities for the top 3 list
                const criticals = result.Vulnerabilities.filter((v: any) => v.Severity === 'CRITICAL');
                criticalVulns.push(...criticals);
            }
        });
    }

    // Sort critical vulnerabilities by CVSS score or ID (mock sorting here by ID)
    criticalVulns.sort((a, b) => (a.VulnerabilityID > b.VulnerabilityID ? 1 : -1));
    const topCriticals = criticalVulns.slice(0, 3);

    // Create Markdown Content
    let mdContent = `# Security Audit Report: ${IMAGE_NAME}\n\n`;
    mdContent += `**Date:** ${new Date().toISOString()}\n`;
    mdContent += `**Total Vulnerabilities Found:** ${totalVulnerabilities}\n\n`;
    
    mdContent += `## Top 3 Critical Vulnerabilities\n\n`;
    mdContent += `| CVE ID | Package | Installed Version | Fixed Version | Severity |\n`;
    mdContent += `|--------|---------|-------------------|---------------|----------|\n`;

    if (topCriticals.length === 0) {
        mdContent += `| No Critical vulnerabilities found | - | - | - | - |\n`;
    } else {
        topCriticals.forEach(v => {
            mdContent += `| ${v.VulnerabilityID} | ${v.PkgName} | ${v.InstalledVersion} | ${v.FixedVersion} | ${v.Severity} |\n`;
        });
    }

    fs.writeFileSync(MARKDOWN_REPORT_FILE, mdContent);
    console.log('Audit complete.');

} catch (error) {
    console.error('Error during audit process:', error);
    process.exit(1);
}
