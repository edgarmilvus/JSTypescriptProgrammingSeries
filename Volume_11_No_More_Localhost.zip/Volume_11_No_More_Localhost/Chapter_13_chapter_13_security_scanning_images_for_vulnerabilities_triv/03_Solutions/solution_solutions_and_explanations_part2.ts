/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

# File: .github/workflows/security-scan.yml
name: Trivy Security Scan

on:
  push:
    branches: [ "main" ]
  pull_request:
    branches: [ "main" ]

jobs:
  security-scan:
    runs-on: ubuntu-latest
    steps:
      - name: Checkout code
        uses: actions/checkout@v3

      - name: Build Docker Image
        run: |
          # Tagging based on event type
          if [ "${{ github.event_name }}" = "pull_request" ]; then
            TAG="my-app:pr-${{ github.event.pull_request.number }}"
          else
            TAG="my-app:latest"
          fi
          docker build -t $TAG .
          # Save image to a tar file for Trivy to scan (optional, but Trivy can scan local images)
          echo "IMAGE_TAG=$TAG" >> $GITHUB_ENV

      - name: Install Trivy
        uses: aquasecurity/setup-trivy-action@v0
        with:
          version: 'latest'
          # Optional: caching for faster runs
          cache: true

      - name: Run Trivy Scan
        # We use the exit-code flag to fail the job if CRITICAL vulnerabilities are found
        # We also generate a full report in SARIF format (standard for security tools) or JSON
        run: |
          trivy image \
            --exit-code 1 \
            --severity CRITICAL \
            --format template \
            --template "@contrib/sarif.tpl" \
            -o trivy-results.sarif \
            ${{ env.IMAGE_TAG }}

      - name: Upload Trivy Scan Results to GitHub Security Tab
        if: always()
        uses: github/codeql-action/upload-sarif@v2
        with:
          sarif_file: 'trivy-results.sarif'

      - name: Upload Build Artifact (Full Report)
        if: always()
        uses: actions/upload-artifact@v3
        with:
          name: trivy-full-report
          path: trivy-results.sarif
