/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.tsx
// Description: Solutions and Explanations
// ==========================================

// File: VulnerabilityDashboard.tsx
import React, { useState, useMemo } from 'react';

// 1. Type Safety: Define interfaces for Trivy JSON structure
interface Vulnerability {
  VulnerabilityID: string;
  PkgName: string;
  InstalledVersion: string;
  FixedVersion: string;
  Severity: 'CRITICAL' | 'HIGH' | 'MEDIUM' | 'LOW' | 'UNKNOWN';
}

interface ScanResult {
  Target: string;
  Vulnerabilities?: Vulnerability[];
}

interface TrivyReport {
  Results: ScanResult[];
}

interface DashboardProps {
  scanResults: TrivyReport;
  imageName?: string;
}

// Helper for Severity Colors
const getSeverityColor = (severity: string) => {
  switch (severity) {
    case 'CRITICAL': return '#ff4d4f'; // Red
    case 'HIGH': return '#faad14'; // Orange
    case 'MEDIUM': return '#1890ff'; // Blue
    case 'LOW': return '#52c41a'; // Green
    default: return '#8c8c8c'; // Grey
  }
};

export const VulnerabilityDashboard: React.FC<DashboardProps> = ({ scanResults, imageName = 'Unknown Image' }) => {
  const [filter, setFilter] = useState('');

  // 2. Data Processing
  // Flatten all vulnerabilities from all targets into a single array
  const allVulnerabilities = useMemo(() => {
    if (!scanResults?.Results) return [];
    return scanResults.Results.reduce((acc, result) => {
      if (result.Vulnerabilities) {
        return [...acc, ...result.Vulnerabilities];
      }
      return acc;
    }, [] as Vulnerability[]);
  }, [scanResults]);

  // Calculate Metrics
  const totalVulnerabilities = allVulnerabilities.length;
  const criticalCount = allVulnerabilities.filter(v => v.Severity === 'CRITICAL').length;
  const highCount = allVulnerabilities.filter(v => v.Severity === 'HIGH').length;

  // Filter Logic
  const filteredVulnerabilities = useMemo(() => {
    return allVulnerabilities.filter(v => 
      v.PkgName.toLowerCase().includes(filter.toLowerCase())
    );
  }, [allVulnerabilities, filter]);

  return (
    <div style={{ fontFamily: 'Arial, sans-serif', padding: '20px' }}>
      {/* Header */}
      <h2>Security Dashboard: {imageName}</h2>

      {/* Stat Cards */}
      <div style={{ display: 'flex', gap: '20px', marginBottom: '20px' }}>
        <div style={{ border: '1px solid #ddd', padding: '15px', borderRadius: '8px', textAlign: 'center', flex: 1 }}>
          <h3 style={{ margin: 0, color: '#666' }}>Total</h3>
          <p style={{ fontSize: '24px', fontWeight: 'bold', margin: 0 }}>{totalVulnerabilities}</p>
        </div>
        <div style={{ border: '1px solid #ff4d4f', padding: '15px', borderRadius: '8px', textAlign: 'center', flex: 1, backgroundColor: '#fff1f0' }}>
          <h3 style={{ margin: 0, color: '#ff4d4f' }}>Critical</h3>
          <p style={{ fontSize: '24px', fontWeight: 'bold', margin: 0, color: '#ff4d4f' }}>{criticalCount}</p>
        </div>
        <div style={{ border: '1px solid #faad14', padding: '15px', borderRadius: '8px', textAlign: 'center', flex: 1, backgroundColor: '#fffbe6' }}>
          <h3 style={{ margin: 0, color: '#faad14' }}>High</h3>
          <p style={{ fontSize: '24px', fontWeight: 'bold', margin: 0, color: '#faad14' }}>{highCount}</p>
        </div>
      </div>

      {/* Interactive Filter */}
      <div style={{ marginBottom: '15px' }}>
        <input
          type="text"
          placeholder="Filter by package name..."
          value={filter}
          onChange={(e) => setFilter(e.target.value)}
          style={{ padding: '8px', width: '300px', border: '1px solid #ccc', borderRadius: '4px' }}
        />
        <span style={{ marginLeft: '10px', color: '#666' }}>Showing {filteredVulnerabilities.length} items</span>
      </div>

      {/* Vulnerability Table */}
      <table style={{ width: '100%', borderCollapse: 'collapse', marginTop: '10px' }}>
        <thead>
          <tr style={{ backgroundColor: '#f5f5f5', textAlign: 'left' }}>
            <th style={{ padding: '10px', border: '1px solid #ddd' }}>CVE ID</th>
            <th style={{ padding: '10px', border: '1px solid #ddd' }}>Package</th>
            <th style={{ padding: '10px', border: '1px solid #ddd' }}>Installed</th>
            <th style={{ padding: '10px', border: '1px solid #ddd' }}>Fixed</th>
            <th style={{ padding: '10px', border: '1px solid #ddd' }}>Severity</th>
          </tr>
        </thead>
        <tbody>
          {filteredVulnerabilities.map((vuln, index) => (
            <tr key={index}>
              <td style={{ padding: '10px', border: '1px solid #ddd' }}>{vuln.VulnerabilityID}</td>
              <td style={{ padding: '10px', border: '1px solid #ddd' }}>{vuln.PkgName}</td>
              <td style={{ padding: '10px', border: '1px solid #ddd' }}>{vuln.InstalledVersion}</td>
              <td style={{ padding: '10px', border: '1px solid #ddd' }}>{vuln.FixedVersion}</td>
              <td style={{ padding: '10px', border: '1px solid #ddd' }}>
                <span style={{
                  backgroundColor: getSeverityColor(vuln.Severity),
                  color: '#fff',
                  padding: '2px 8px',
                  borderRadius: '4px',
                  fontSize: '12px',
                  fontWeight: 'bold'
                }}>
                  {vuln.Severity}
                </span>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};
