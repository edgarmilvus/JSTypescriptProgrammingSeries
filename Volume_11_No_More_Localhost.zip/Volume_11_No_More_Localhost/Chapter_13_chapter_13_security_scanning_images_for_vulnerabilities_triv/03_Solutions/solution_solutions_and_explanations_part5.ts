/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

# File: Dockerfile

# --- Stage 1: Builder ---
# Installs dependencies and builds the application
FROM node:18-alpine AS builder
WORKDIR /app
COPY package*.json ./
RUN npm ci --only=production
COPY . .
# Assuming a build script exists (e.g., compiling TypeScript)
RUN npm run build

# --- Stage 2: Production ---
# Creates the final lightweight image
FROM node:18-alpine AS production
WORKDIR /app
COPY --from=builder /app/dist ./dist
COPY --from=builder /app/node_modules ./node_modules
COPY --from=builder /app/package.json .
EXPOSE 3000
CMD ["node", "dist/index.js"]

# --- Stage 3: Scanner ---
# Scans the production image and fails build if vulnerabilities are found
FROM aquasec/trivy:latest AS scanner
WORKDIR /scan

# We need to copy the production image context to scan it. 
# However, Trivy usually scans images from a registry or local daemon.
# A common pattern in multi-stage builds for scanning is to use the 'builder' 
# to create a tarball of the final image, or scan the filesystem directly.
# Since Trivy works best on images, we will simulate the scan by scanning 
# the 'production' stage's filesystem using Trivy's 'fs' mode, 
# OR we can use a shell script to build the image and scan it.
# 
# NOTE: Dockerfile syntax alone cannot "scan an image" that hasn't been pushed 
# to a registry or saved to the local daemon within the build process without 
# advanced features (like BuildKit) or external scripts.
#
# Below is the pragmatic approach using Trivy to scan the filesystem of the 
# production stage directly, which detects OS package vulnerabilities.

COPY --from=production / /
# Run Trivy filesystem scan on the root directory (which contains the production OS)
# --exit-code 1 fails the build if CRITICAL is found.
# --severity CRITICAL focuses only on critical issues.
RUN trivy fs --exit-code 1 --severity CRITICAL /

# --- Final Stage (Optional) ---
# If the scanner stage passes, we can proceed to tag/push.
# In a real scenario, the scanner stage is often the last step before pushing.
FROM production AS final
# Final image is ready, having passed the scanner check.
