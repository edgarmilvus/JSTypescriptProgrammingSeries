/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part2.ts
// Description: Theoretical Foundations
// ==========================================

// src/config/schema.ts
import { z } from 'zod';

/**
 * This schema defines the complete shape of our application's environment.
 * It separates public configuration from sensitive secrets for clarity.
 */
export const appConfigSchema = z.object({
  // --- Public Configuration ---
  // These are non-sensitive values that control application behavior.
  NODE_ENV: z.enum(['development', 'test', 'production']).default('development'),
  PORT: z.string().transform((val) => parseInt(val, 10)).pipe(z.number().positive().max(65535)),
  LOG_LEVEL: z.enum(['debug', 'info', 'warn', 'error']).default('info'),

  // --- Sensitive Secrets ---
  // These are injected securely at runtime. We validate their presence and format.
  // We use .min(1) to ensure the string is not empty.
  DATABASE_URL: z.string().url().min(1, { message: "DATABASE_URL is required" }),
  JWT_SECRET: z.string().min(32, { message: "JWT_SECRET must be at least 32 characters long" }),
  API_KEY_SERVICE_A: z.string().min(1, { message: "API_KEY_SERVICE_A is required" }),
});

/**
 * Infer the TypeScript type from the Zod schema.
 * This gives us a single source of truth for both runtime validation
 * and compile-time type safety.
 */
export type AppConfig = z.infer<typeof appConfigSchema>;
