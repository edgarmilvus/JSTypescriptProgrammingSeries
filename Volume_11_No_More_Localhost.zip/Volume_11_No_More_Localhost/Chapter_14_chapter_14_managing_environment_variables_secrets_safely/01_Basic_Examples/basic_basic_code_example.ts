/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * @file configLoader.ts
 * A self-contained example demonstrating Type Guards and Generics for secure configuration management.
 * 
 * Context: SaaS Web Application Backend
 * Goal: Safely load and validate environment secrets and configuration.
 */

// 1. Define the shape of our expected configuration.
// We use an interface to enforce structure. This is our "Type Contract".
interface AppConfig {
  databaseUrl: string;
  apiKey: string;
  featureFlags: {
    enableCache: boolean;
    maxRetries: number;
  };
}

// 2. Mock Data Source.
// In a real scenario, this would be process.env, a JSON file, or a remote secret store.
// For this example, we simulate a JSON object that might be loaded from a file.
const mockRawConfig: unknown = {
  databaseUrl: "postgresql://user:pass@localhost:5432/mydb",
  apiKey: "sk_live_1234567890abcdef",
  featureFlags: {
    enableCache: true,
    maxRetries: 3
  }
};

/**
 * 3. Type Guard Function.
 * 
 * This function performs a runtime check to determine if an unknown value
 * conforms to the `AppConfig` interface.
 * 
 * The return type `value is AppConfig` is a special TypeScript syntax called
 * a "Type Predicate". It tells the compiler that if this function returns true,
 * the variable passed in can be treated as `AppConfig` in that scope.
 * 
 * @param config - The unknown value to check.
 * @returns True if the value matches the AppConfig interface, false otherwise.
 */
function isAppConfig(config: unknown): config is AppConfig {
  // Basic null/undefined check
  if (!config || typeof config !== 'object') {
    return false;
  }

  // We cast to a partial type to check properties safely without TypeScript complaining
  const candidate = config as Partial<AppConfig>;

  // Check existence and type of top-level required properties
  if (typeof candidate.databaseUrl !== 'string' || !candidate.databaseUrl) {
    return false;
  }
  
  if (typeof candidate.apiKey !== 'string' || !candidate.apiKey) {
    return false;
  }

  // Check nested objects (featureFlags)
  if (
    !candidate.featureFlags ||
    typeof candidate.featureFlags !== 'object' ||
    typeof candidate.featureFlags.enableCache !== 'boolean' ||
    typeof candidate.featureFlags.maxRetries !== 'number'
  ) {
    return false;
  }

  // If all checks pass, TypeScript knows `candidate` is `AppConfig`
  return true;
}

/**
 * 4. Generic Configuration Loader.
 * 
 * This function uses a Generic Type Variable `<T>`.
 * It allows us to load *any* configuration shape, not just `AppConfig`,
 * while enforcing strict type safety for the result.
 * 
 * @param rawSource - The raw data source (unknown type).
 * @param validator - A type guard function that validates the shape of T.
 * @returns The validated configuration object of type T.
 * @throws Error if validation fails.
 */
function loadConfig<T>(rawSource: unknown, validator: (data: unknown) => data is T): T {
  // Attempt to validate the source data using the provided type guard
  if (validator(rawSource)) {
    console.log("✅ Configuration validated successfully.");
    return rawSource; // TypeScript now knows this is of type T
  }

  // If validation fails, we throw an error. 
  // In a real app, this should trigger a graceful shutdown or retry logic.
  console.error("❌ Configuration validation failed.");
  throw new Error("Invalid configuration format. Ensure all required secrets and flags are present.");
}

/**
 * 5. Application Entry Point (Simulated)
 * 
 * Demonstrates the usage of the loader in a secure context.
 */
function main() {
  try {
    console.log("--- Starting Configuration Load ---");

    // Load the configuration using the generic loader and the specific type guard
    const config = loadConfig<AppConfig>(mockRawConfig, isAppConfig);

    // --- Usage ---
    // Because of the type guard, we can now safely access properties
    // without optional chaining or runtime checks.
    
    console.log(`Database Connected: ${config.databaseUrl}`);
    console.log(`API Key Loaded: ${config.apiKey.substring(0, 8)}...`); // Masking for security
    console.log(`Cache Enabled: ${config.featureFlags.enableCache}`);

    // If we tried to access a non-existent property, TypeScript would error at compile time:
    // console.log(config.nonExistentProperty); // Error: Property 'nonExistentProperty' does not exist on type 'AppConfig'.

  } catch (error) {
    console.error("Application failed to start due to configuration error:", error);
    // process.exit(1); // In a real server, you would exit here
  }
}

// Execute the simulation
main();
