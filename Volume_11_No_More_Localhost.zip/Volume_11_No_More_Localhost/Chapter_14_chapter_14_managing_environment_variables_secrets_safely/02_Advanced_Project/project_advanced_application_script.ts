/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

import { z } from 'zod';

// ============================================================================
// 1. CONFIGURATION SCHEMAS & TYPES
// ============================================================================

/**
 * Defines the supported AI providers.
 * Using a union type ensures we only accept valid providers.
 */
type AIProvider = 'openai' | 'anthropic' | 'local-llama';

/**
 * Base interface for generic configuration validation.
 * Uses Generics <T> to allow flexible schema definitions while maintaining
 * a strict structure for environment variable keys.
 */
interface EnvConfigSchema<T extends string> {
  required: T[];
  optional?: string[];
}

/**
 * Specific configuration schema for our AI Model Router.
 * We separate sensitive secrets (keys) from standard configuration (model names).
 */
const aiProviderSchema: EnvConfigSchema<AIProvider> = {
  required: ['openai', 'anthropic'], // These correspond to API_KEY variables
  optional: ['local-llama']          // Local models might not need external keys
};

/**
 * Zod Schema for runtime validation.
 * This ensures that even if TypeScript compiles, the runtime data matches expectations.
 */
const configSchema = z.object({
  // Database (Non-secret, but sensitive)
  DATABASE_URL: z.string().url(),

  // AI Provider Keys (Secrets)
  OPENAI_API_KEY: z.string().min(1),
  ANTHROPIC_API_KEY: z.string().min(1),
  
  // Feature Flags
  ENABLE_DEBUG_MODE: z.enum(['true', 'false']).transform(val => val === 'true'),
});

/**
 * Parsed configuration type inferred from Zod schema.
 * This represents the immutable state of our application's environment.
 */
type AppConfig = z.infer<typeof configSchema>;

// ============================================================================
// 2. IMMUTABLE CONFIGURATION BUILDER
// ============================================================================

/**
 * Validates and constructs the application configuration.
 * 
 * Why Immutable?
 * Once loaded, the config object should never be modified. This prevents
 * accidental leakage of secrets or modification of runtime settings.
 * 
 * Why Fail-Fast?
 * If a required secret is missing, the application should crash immediately
 * on startup rather than failing silently during a user request.
 */
class ConfigBuilder {
  private static instance: AppConfig;

  /**
   * Retrieves the singleton configuration instance.
   * Throws an error if configuration hasn't been initialized yet.
   */
  static get(): AppConfig {
    if (!this.instance) {
      throw new Error('Configuration not initialized. Call ConfigBuilder.load() first.');
    }
    return this.instance;
  }

  /**
   * Loads, validates, and freezes the configuration.
   * 
   * @param env - The process.env object (or a mock for testing)
   */
  static load(env: NodeJS.ProcessEnv): void {
    try {
      // 1. Parse and Validate
      const validatedConfig = configSchema.parse(env);

      // 2. Apply Immutable Freezing
      // Object.freeze prevents accidental mutations at runtime.
      // Note: This is a shallow freeze; for deep immutability, 
      // libraries like Immer or recursive freezing would be used.
      this.instance = Object.freeze(validatedConfig);

      console.log('✅ Configuration loaded and secured.');
    } catch (error) {
      console.error('❌ Configuration validation failed:', error);
      // In a real serverless or containerized environment, 
      // we might want to exit(1) here to trigger a restart loop
      // until the environment is fixed.
      process.exit(1);
    }
  }
}

// ============================================================================
// 3. MODEL ROUTER SERVICE (Business Logic)
// ============================================================================

/**
 * Represents a request context, potentially carrying user ID or tier.
 */
interface RequestContext {
  userId: string;
  tier: 'free' | 'pro' | 'enterprise';
}

/**
 * The core service that routes requests to appropriate AI providers
 * based on the immutable configuration and user context.
 */
class ModelRouter {
  private config: AppConfig;

  constructor() {
    this.config = ConfigBuilder.get();
  }

  /**
   * Selects the provider based on user tier.
   * This logic abstracts the secret retrieval from the business logic.
   * 
   * How it uses Secrets:
   * The router never exposes the raw API key. It selects the provider,
   * and the underlying SDK (e.g., Vercel AI SDK) would inject the key
   * from the Config object securely.
   */
  getProviderForUser(user: RequestContext): AIProvider {
    // Immutable Logic: Pure function based on input and frozen config
    switch (user.tier) {
      case 'enterprise':
        return 'anthropic'; // Uses ANTHROPIC_API_KEY
      case 'pro':
        return 'openai';    // Uses OPENAI_API_KEY
      case 'free':
        return 'local-llama'; // Uses local hardware, no external key
      default:
        throw new Error(`Unknown user tier: ${user.tier}`);
    }
  }

  /**
   * Simulates generating a completion request.
   * In a real app, this would pass the specific API key to the AI SDK.
   */
  async generateResponse(user: RequestContext, prompt: string): Promise<string> {
    const provider = this.getProviderForUser(user);
    
    // Simulate API call logic
    // In production, we would fetch the key from this.config securely here
    const apiKey = provider === 'openai' 
      ? this.config.OPENAI_API_KEY 
      : this.config.ANTHROPIC_API_KEY;

    console.log(`Routing request for user ${user.userId} to ${provider}...`);
    
    // Simulate processing delay
    await new Promise(resolve => setTimeout(resolve, 100));

    return `Generated response using ${provider} for prompt: "${prompt}"`;
  }
}

// ============================================================================
// 4. EXECUTION EXAMPLE (Simulating a Production Environment)
// ============================================================================

/**
 * Main execution block.
 * Simulates a server startup where environment variables are injected
 * via Docker Secrets or a .env file (in development).
 */
async function main() {
  // 1. Simulate Environment Injection
  // In Docker, these would be injected from secrets, not hardcoded here.
  const mockEnv = {
    DATABASE_URL: "postgresql://user:pass@localhost:5432/mydb",
    OPENAI_API_KEY: "sk-1234567890abcdef", // Secret
    ANTHROPIC_API_KEY: "sk-ant-123456",    // Secret
    ENABLE_DEBUG_MODE: "true"
  };

  // 2. Load Configuration (Fail-Fast)
  ConfigBuilder.load(mockEnv);

  // 3. Initialize Service
  const router = new ModelRouter();

  // 4. Simulate Incoming Requests
  const requests: RequestContext[] = [
    { userId: 'user_1', tier: 'free' },
    { userId: 'user_2', tier: 'pro' },
    { userId: 'user_3', tier: 'enterprise' },
  ];

  console.log('\n--- Processing Request Queue ---\n');

  for (const req of requests) {
    try {
      const result = await router.generateResponse(req, "Explain Docker Secrets.");
      console.log(`✅ Result: ${result}\n`);
    } catch (err) {
      console.error(`❌ Error: ${(err as Error).message}\n`);
    }
  }

  // 5. Attempting to mutate config (Security Test)
  console.log('--- Attempting Security Violation (Mutation) ---\n');
  const config = ConfigBuilder.get();
  
  // @ts-ignore - Intentionally trying to break immutability
  config.OPENAI_API_KEY = "HACKED_KEY"; 
  
  // Verify immutability
  console.log(`Key after mutation attempt: ${config.OPENAI_API_KEY}`);
  console.log('ℹ️  If the key remains unchanged, immutability is enforced.\n');
}

// Execute
if (require.main === module) {
  main();
}
