/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.tsx
// Description: Solutions and Explanations
// ==========================================

// 1. Component Definition (Props Interface)
import React, { useState, useEffect, Suspense } from 'react';

interface ModelConfig {
  id: string;
  name: string;
  endpoint: string;
}

interface SecureModelSelectorProps {
  // Props can be extended here if needed, e.g., onSelect callback
  onSelectModel: (modelId: string) => void;
}

// 2. Backend API Route (Conceptual - e.g., /app/api/config/models/route.ts)
/*
import { NextResponse } from 'next/server';
import fs from 'fs';

export async function GET() {
  try {
    // Securely read from Docker Secret mount
    const secretPath = '/run/secrets/model_config';
    const rawData = fs.readFileSync(secretPath, 'utf8');
    const models: ModelConfig[] = JSON.parse(rawData);
    
    return NextResponse.json(models);
  } catch (error) {
    return NextResponse.json(
      { error: 'Configuration unavailable' }, 
      { status: 500 }
    );
  }
}
*/

// 3. Frontend Component Implementation
export const SecureModelSelector: React.FC<SecureModelSelectorProps> = ({ onSelectModel }) => {
  const [models, setModels] = useState<ModelConfig[]>([]);
  const [selectedModel, setSelectedModel] = useState<string>('');

  useEffect(() => {
    // Fetch from the secure backend API
    const fetchModels = async () => {
      try {
        const response = await fetch('/api/config/models');
        if (!response.ok) throw new Error('Failed to fetch models');
        
        const data: ModelConfig[] = await response.json();
        
        // 4. Immutable State Management
        // setModels creates a new array reference, ensuring immutability
        setModels(data);
        
        // Initialize selection if desired
        if (data.length > 0) {
            setSelectedModel(data[0].id);
            onSelectModel(data[0].id);
        }
      } catch (error) {
        console.error(error);
        // Handle error state (not shown for brevity)
      }
    };

    fetchModels();
  }, [onSelectModel]); // Dependency array ensures effect runs once on mount

  const handleSelectionChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const newModelId = e.target.value;
    setSelectedModel(newModelId);
    
    // Trigger parent callback immutably
    onSelectModel(newModelId);
  };

  return (
    // 3. Suspense for Loading State
    // Note: In Next.js App Router, <Suspense> is often used with loading.tsx 
    // or wrapped around the component in the parent layout.
    // Here we simulate a manual Suspense boundary or loading check.
    <div>
      {models.length === 0 ? (
        <div className="loading-spinner">Loading models...</div>
      ) : (
        <select value={selectedModel} onChange={handleSelectionChange}>
          {models.map((model) => (
            <option key={model.id} value={model.id}>
              {model.name}
            </option>
          ))}
        </select>
      )}
    </div>
  );
};
