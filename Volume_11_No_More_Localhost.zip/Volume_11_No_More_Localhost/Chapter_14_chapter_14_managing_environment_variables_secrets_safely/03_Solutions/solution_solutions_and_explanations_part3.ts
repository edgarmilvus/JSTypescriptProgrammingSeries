/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

# docker-compose.yml

version: '3.8'

# 1. Define Secrets
secrets:
  database_url:
    # The source file 'db_secret.txt' must exist locally and contain the connection string.
    # It should NOT be committed to version control.
    file: ./db_secret.txt

services:
  # 2. Backend Service (Node.js)
  backend:
    build:
      context: ./backend
      dockerfile: Dockerfile
    environment:
      # Public config (safe to pass via environment)
      - NODE_ENV=production
    secrets:
      - database_url
    # 3. Dependency Management
    # The healthcheck allows the frontend to wait for the backend to be fully ready.
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:3001/health"]
      interval: 10s
      timeout: 5s
      retries: 5
      start_period: 10s

  # 3. Frontend Service (Next.js)
  frontend:
    build:
      context: ./frontend
      dockerfile: Dockerfile
    environment:
      # 3. Public Configuration Variable
      # This tells the frontend where the API is located.
      - NEXT_PUBLIC_API_URL=http://backend:3001
    ports:
      - "3000:3000"
    # 3. Secret Isolation
    # Intentionally omitted: 'secrets' key. 
    # The frontend does NOT have access to 'database_url'.
    depends_on:
      backend:
        # 4. Dependency Management
        # Wait for the backend service to report 'healthy' before starting the frontend.
        condition: service_healthy
