/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

digraph SecureSecretFlow {
    rankdir=TB;
    node [shape=box, style="rounded,filled", color="#E0E0E0"];

    // Nodes representing the stages
    Start [label="Developer creates Secret\n(e.g., OPENAI_API_KEY)", fillcolor="#FFEBEE"];
    Storage [label="Secure Storage\n(HashiCorp Vault / AWS Secrets Manager)", fillcolor="#FFF3E0"];
    Filesystem [label="Local Secret File\n(db_secret.txt)\n.gitignore protected", fillcolor="#FFF9C4"];
    Compose [label="Docker Compose Definition\n(secrets: - db_secret)", fillcolor="#E8F5E9"];
    Build [label="Docker Build Stage\n(No secrets embedded)", fillcolor="#E3F2FD"];
    Runtime [label="Runtime Container\n(Secret mounted at /run/secrets)", fillcolor="#F3E5F5"];
    App [label="Application Process\n(Reads file, drops privileges)", fillcolor="#E0F7FA"];

    // Edges representing the flow
    Start -> Storage [label="Push to Vault"];
    Storage -> Filesystem [label="Pull to local\n(Dev environment only)"];
    Filesystem -> Compose [label="Referenced in config"];
    
    // Parallel flow for Build vs Runtime
    Compose -> Build [label="Build Context", style="dashed"];
    Compose -> Runtime [label="Runtime Mount", penwidth=2];

    // Runtime flow
    Runtime -> App [label="Filesystem Read\n(Strict Permissions)"];

    // Security Gates
    subgraph cluster_security {
        label = "Security Boundaries";
        style = "dashed";
        color = "#D32F2F";
        
        Gate1 [label="Git History Scrubbed\n(git filter-repo)", shape=note, fillcolor="white"];
        Gate2 [label="Container User != Root\n(USER 1001)", shape=note, fillcolor="white"];
        Gate3 [label="Secret Not in ENV\n(No env_file)", shape=note, fillcolor="white"];
    }

    // Associations
    Filesystem -> Gate1 [style="invis"]; // Visual grouping
    App -> Gate2;
    Runtime -> Gate3;
}
