/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

// server.ts
// A simple Express server with a simulated bug in an async function.
import express, { Request, Response } from 'express';

const app = express();
const PORT = 3000;

/**
 * Simulates a database fetch or a complex AI model inference call.
 * This function intentionally contains a bug to demonstrate debugging.
 * @returns A promise that resolves with user data.
 */
const fetchUserData = async (): Promise<{ id: string; name: string }> => {
    console.log("Starting data fetch simulation...");
    // Simulate network delay
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    // BUG: This will throw a TypeError because we are trying to access a property on null.
    const userData: { id: string; name: string } | null = null;
    console.log("Fetched data:", userData);
    
    // This line will never be reached due to the bug above.
    return userData; 
};

/**
 * Main route handler for the application.
 * It attempts to fetch user data and returns it as JSON.
 */
app.get('/', async (req: Request, res: Response) => {
    try {
        const userData = await fetchUserData();
        res.json({ status: 'success', data: userData });
    } catch (error) {
        // Log the error to the console (captured by Docker logs)
        console.error("Error in main route:", error);
        
        // Send a 500 Internal Server Error response
        res.status(500).json({ status: 'error', message: 'Internal Server Error' });
    }
});

/**
 * Health check endpoint for Docker liveness probes.
 */
app.get('/health', (req: Request, res: Response) => {
    res.json({ status: 'ok' });
});

// Start the server
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});
