/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// pages/api/debug.ts
// Next.js API Route for Debugging Containerized Inference
import type { NextApiRequest, NextApiResponse } from 'next';

/**
 * @description Configuration for the Zero-Shot Classification model.
 * Immutability is enforced by freezing this object.
 */
const MODEL_CONFIG = Object.freeze({
  model: 'Xenova/bert-base-uncased-mnli',
  labels: ['finance', 'health', 'technology', 'politics'],
  hypothesis_template: 'This example is about {}.',
  multi_label: false,
  // Headless Inference requires no GPU flags in this specific mock, 
  // but in production, this would contain device settings.
});

/**
 * @type {InferenceSnapshot}
 * @description Represents a immutable record of a single inference execution.
 */
type InferenceSnapshot = {
  id: string;
  timestamp: Date;
  input: string;
  predictions: Array<{ label: string; score: number }>;
  configHash: string;
};

/**
 * @class ModelInspector
 * @description A singleton class to manage the state of the headless inference engine.
 * It uses immutable patterns to store history, ensuring debugging data remains consistent
 * even under high load.
 */
class ModelInspector {
  private static instance: ModelInspector;
  // The history is an array of immutable snapshots.
  private history: ReadonlyArray<InferenceSnapshot> = [];
  
  private constructor() {}

  public static getInstance(): ModelInspector {
    if (!ModelInspector.instance) {
      ModelInspector.instance = new ModelInspector();
    }
    return ModelInspector.instance;
  }

  /**
   * @description Logs a new inference result. 
   * Demonstrates Immutable State Management: we do not push to the array directly,
   * but create a new array with the new entry.
   */
  public logInference(snapshot: Omit<InferenceSnapshot, 'id' | 'timestamp' | 'configHash'>): void {
    const newSnapshot: InferenceSnapshot = {
      ...snapshot,
      id: Math.random().toString(36).substr(2, 9),
      timestamp: new Date(),
      configHash: JSON.stringify(MODEL_CONFIG), // In real app, use a hash function
    };

    // Immutable update: Create a new array reference
    this.history = [...this.history, newSnapshot];
    
    console.log(`[DEBUG] Inference logged. Total snapshots: ${this.history.length}`);
  }

  /**
   * @description Retrieves the current debugging state.
   * Used by the remote debugging endpoint.
   */
  public getDebugState() {
    return {
      modelConfig: MODEL_CONFIG,
      historyCount: this.history.length,
      // Return a safe slice of history (last 10 entries) to prevent memory bloat in response
      recentHistory: this.history.slice(-10),
      uptime: process.uptime(),
    };
  }

  /**
   * @description Clears the history (for debugging purposes only).
   */
  public clearHistory(): void {
    this.history = [];
    console.log('[DEBUG] History cleared via remote command.');
  }
}

/**
 * @description Mock Headless Inference Function.
 * In a real scenario, this would call TensorFlow.js or a Python subprocess.
 * Here, we simulate a classification result.
 */
const runHeadlessInference = async (input: string): Promise<{ label: string; score: number }[]> => {
  // Simulate processing delay
  await new Promise(resolve => setTimeout(resolve, 100));
  
  // Mock logic: simple keyword matching to simulate model behavior
  const scores = MODEL_CONFIG.labels.map(label => {
    let score = Math.random() * 0.3; // Low base score
    if (input.toLowerCase().includes(label)) score = 0.95;
    return { label, score };
  });

  // Sort by score descending
  return scores.sort((a, b) => b.score - a.score).slice(0, 3);
};

/**
 * @description Main API Handler.
 * Routes requests between Inference execution and Debugging inspection.
 */
export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  const inspector = ModelInspector.getInstance();
  const { method, query } = req;

  // ---------------------------------------------------------
  // 1. Remote Debugging Interface (GET /api/debug)
  // ---------------------------------------------------------
  if (method === 'GET') {
    // Check for specific debug commands in query params
    if (query.action === 'clear') {
      inspector.clearHistory();
      return res.status(200).json({ message: 'Debug history cleared.' });
    }

    // Expose the internal state of the container
    const debugState = inspector.getDebugState();
    
    // ---------------------------------------------------------
    // LOGGING: Leveraging `docker logs` output
    // ---------------------------------------------------------
    // This console.log will be captured by 'docker logs <container_id>'
    console.log(`[REMOTE_DEBUG] State requested. Uptime: ${debugState.uptime.toFixed(2)}s`);

    return res.status(200).json({
      status: 'debug_mode_active',
      data: debugState,
    });
  }

  // ---------------------------------------------------------
  // 2. Inference Execution (POST /api/debug)
  // ---------------------------------------------------------
  if (method === 'POST') {
    const { input } = req.body;

    if (!input || typeof input !== 'string') {
      return res.status(400).json({ error: 'Invalid input string.' });
    }

    try {
      // Run the headless inference
      const predictions = await runHeadlessInference(input);

      // Log the immutable snapshot for debugging
      inspector.logInference({ input, predictions });

      return res.status(200).json({
        result: predictions,
        debugId: inspector.getDebugState().historyCount, // Return the index for tracking
      });
    } catch (error) {
      console.error('[INFERENCE_ERROR]', error);
      return res.status(500).json({ error: 'Inference failed.' });
    }
  }

  // Handle unsupported methods
  res.setHeader('Allow', ['GET', 'POST']);
  res.status(405).end(`Method ${method} Not Allowed`);
}
