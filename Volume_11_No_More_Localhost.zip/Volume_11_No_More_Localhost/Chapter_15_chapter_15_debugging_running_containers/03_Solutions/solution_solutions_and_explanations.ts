/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// File: src/inference.ts
// This file contains the bug: a failure to handle the model's output structure correctly.

import { HfInference } from '@huggingface/inference';

const hf = new HfInference(process.env.HF_API_KEY);

// Simulated endpoint handler
export async function classifyText(text: string) {
  try {
    // BUG: We are using a zero-shot classification model, but we are not providing
    // the required 'candidate_labels' parameter in the options object.
    // This will cause the API to return an error or an unexpected structure
    // that the code below cannot handle, leading to an unhandled promise rejection.
    const result = await hf.zeroShotClassification({
      model: 'facebook/bart-large-mnli',
      inputs: [text],
      // candidate_labels: ['politics', 'finance', 'sports'] // <--- Missing parameter
    });

    // This code assumes 'result' is an array, but if the API fails, it might be undefined or an error object.
    // Accessing result[0] will throw a TypeError.
    const topLabel = result[0].labels[0];
    console.log(`Top classification: ${topLabel}`);
    return { label: topLabel, score: result[0].scores[0] };

  } catch (error) {
    // The error is caught here, but the promise might still reject globally if not handled correctly upstream.
    console.error('Inference failed:', error);
    throw error;
  }
}

// File: Dockerfile
# Use a minimal Node.js image
FROM node:18-alpine AS builder

WORKDIR /app
COPY package*.json ./
RUN npm ci --only=production

# Copy source code
COPY src ./src

# Final stage
FROM node:18-alpine
WORKDIR /app
COPY --from=builder /app ./

# Run as non-root user for security
USER node

# Command to run the application
CMD ["node", "src/index.js"]
