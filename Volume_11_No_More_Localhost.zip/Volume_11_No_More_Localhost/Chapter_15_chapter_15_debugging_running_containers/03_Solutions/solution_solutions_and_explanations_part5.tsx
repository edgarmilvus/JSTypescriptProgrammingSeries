/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.tsx
// Description: Solutions and Explanations
// ==========================================

// File: src/components/ServiceStateViewer.tsx
import React, { useState, useMemo } from 'react';

// Define the shape of a service health object
interface ServiceStatus {
  id: string;
  status: 'healthy' | 'unhealthy';
  config: Record<string, unknown>;
}

interface ServiceStateViewerProps {
  services: ServiceStatus[];
  onSimulateFailure: (id: string) => void; // Callback to parent
}

const ServiceStateViewer: React.FC<ServiceStateViewerProps> = React.memo(({ services, onSimulateFailure }) => {
  // 1. Immutable Handling: Create a deep clone of the services prop.
  // We use structuredClone to ensure nested objects (like 'config') are also cloned.
  // This prevents accidental mutation of the prop, which is read-only.
  const localState = useMemo(() => {
    return services.map(service => ({
      ...structuredClone(service),
      // Add a display-specific property without mutating the original
      lastChecked: new Date().toISOString()
    }));
  }, [services]); // Re-run only when the 'services' prop reference changes

  return (
    <div className="service-dashboard">
      <h3>Service Status Dashboard</h3>
      <table>
        <thead>
          <tr>
            <th>ID</th>
            <th>Status</th>
            <th>Last Checked</th>
            <th>Config Snapshot</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          {localState.map((service) => (
            <tr key={service.id}>
              <td>{service.id}</td>
              <td style={{ color: service.status === 'healthy' ? 'green' : 'red' }}>
                {service.status}
              </td>
              <td>{service.lastChecked}</td>
              <td>
                <pre>{JSON.stringify(service.config, null, 2)}</pre>
              </td>
              <td>
                <button onClick={() => onSimulateFailure(service.id)}>
                  Simulate Failure
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
});

export default ServiceStateViewer;
