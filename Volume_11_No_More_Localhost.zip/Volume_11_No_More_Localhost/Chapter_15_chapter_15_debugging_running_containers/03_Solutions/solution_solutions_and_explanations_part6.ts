/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part6.ts
// Description: Solutions and Explanations
// ==========================================

# File: docker-compose.yml
version: '3.8'

services:
  # 1. Frontend Service (React)
  frontend:
    build: ./frontend
    ports:
      - "3000:3000"
    depends_on:
      - backend
    networks:
      - ai-network

  # 2. Backend API (Node.js)
  backend:
    build: ./backend
    ports:
      - "4000:4000"
    environment:
      - INFERENCE_URL=http://inference-service:8000
    # 3. Simulate Failure: We intentionally omit a wait-for script here
    # and rely on naive startup. In a real fix, we would use a script or healthcheck.
    command: ["node", "dist/index.js"]
    depends_on:
      - inference-service
    networks:
      - ai-network

  # 3. Inference Service (Python/PyTorch - simulated)
  inference-service:
    image: python:3.9-slim
    ports:
      - "8000:8000"
    # Simulate slow startup (e.g., loading a large model)
    command: ["bash", "-c", "sleep 10 && python -m http.server 8000"]
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:8000"]
      interval: 5s
      timeout: 3s
      retries: 5
      start_period: 12s # Allow time for the sleep command
    networks:
      - ai-network

networks:
  ai-network:
    driver: bridge
