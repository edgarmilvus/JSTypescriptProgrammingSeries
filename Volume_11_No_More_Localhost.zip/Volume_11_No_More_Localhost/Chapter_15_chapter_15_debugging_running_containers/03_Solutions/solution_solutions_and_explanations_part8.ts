/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part8.ts
// Description: Solutions and Explanations
// ==========================================

// File: src/service.ts (The main application)
import express from 'express';

const app = express();
app.use(express.json());

// In-memory state (Mutable)
const userSessions = new Map<string, object>();

// Endpoint to view state
app.get('/state', (req, res) => {
  // Convert Map to object for JSON serialization
  const stateObj = Object.fromEntries(userSessions);
  res.json(stateObj);
});

// Endpoint to update state
app.post('/update-state', (req, res) => {
  const { userId, data } = req.body;
  if (userId && data) {
    userSessions.set(userId, data);
    res.status(200).send('State updated');
  } else {
    res.status(400).send('Missing data');
  }
});

app.listen(3000, () => {
  console.log('Service running on port 3000');
});
