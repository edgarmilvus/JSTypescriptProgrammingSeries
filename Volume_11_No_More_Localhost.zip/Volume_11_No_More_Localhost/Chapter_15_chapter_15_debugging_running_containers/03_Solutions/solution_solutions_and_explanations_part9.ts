/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part9.ts
// Description: Solutions and Explanations
// ==========================================

// File: src/diagnostic.ts (The injected script)
import http from 'http';

// Function to fetch state and create an immutable snapshot
async function inspectState() {
  return new Promise((resolve, reject) => {
    const req = http.get('http://localhost:3000/state', (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        const liveState = JSON.parse(data);
        
        // Create an immutable copy using structuredClone
        const immutableSnapshot = structuredClone(liveState);
        
        console.log('--- Immutable Snapshot Captured ---');
        console.log(JSON.stringify(immutableSnapshot, null, 2));
        
        // Demonstrate immutability: modifying the snapshot does not affect live state
        if (immutableSnapshot['user123']) {
          immutableSnapshot['user123'].corrupted = true;
        }
        
        resolve(immutableSnapshot);
      });
    });
    req.on('error', reject);
  });
}

// Run inspection
inspectState().catch(console.error);
