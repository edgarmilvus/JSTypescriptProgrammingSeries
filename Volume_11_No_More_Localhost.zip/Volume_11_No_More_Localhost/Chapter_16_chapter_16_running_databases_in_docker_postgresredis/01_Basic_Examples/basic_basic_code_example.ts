/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

// File: vector-db-client.ts
// Dependencies: pg (node-postgres), dotenv (optional, for local dev)
// Note: Ensure you have a running Docker container with PostgreSQL + pgvector.
// Example Docker command:
// docker run --name pgvector-hello -e POSTGRES_PASSWORD=mysecretpassword -p 5432:5432 -d pgvector/pgvector:pg16

import { Client } from 'pg';

/**
 * Configuration interface for the database connection.
 * In a real SaaS app, these would be injected via environment variables.
 */
interface DbConfig {
  host: string;
  port: number;
  user: string;
  password: string;
  database: string;
}

/**
 * Represents a vector embedding record in our database.
 */
interface VectorRecord {
  id: number;
  content: string;
  embedding: number[];
  similarity_score?: number; // Added during query execution
}

/**
 * Manages interactions with a Dockerized PostgreSQL database containing pgvector.
 * This class encapsulates connection lifecycle and vector-specific SQL queries.
 */
class VectorStoreClient {
  private client: Client;

  constructor(config: DbConfig) {
    this.client = new Client({
      host: config.host,
      port: config.port,
      user: config.user,
      password: config.password,
      database: config.database,
    });
  }

  /**
   * Initializes the database connection.
   * CRITICAL: This must be awaited before performing any operations.
   */
  public async connect(): Promise<void> {
    try {
      await this.client.connect();
      console.log('✅ Connected to Dockerized PostgreSQL (pgvector)');
    } catch (error) {
      console.error('❌ Failed to connect to database:', error);
      throw error;
    }
  }

  /**
   * Sets up the necessary table and extension if they don't exist.
   * This is idempotent and safe to run on startup.
   */
  public async initializeSchema(): Promise<void> {
    // 1. Enable the pgvector extension if not already enabled.
    await this.client.query('CREATE EXTENSION IF NOT EXISTS vector;');

    // 2. Create a table to store embeddings.
    // We use the 'vector(3)' type for 3-dimensional vectors (simplified for demo).
    await this.client.query(`
      CREATE TABLE IF NOT EXISTS embeddings (
        id SERIAL PRIMARY KEY,
        content TEXT,
        embedding vector(3)
      );
    `);
    console.log('✅ Schema initialized (pgvector extension and embeddings table)');
  }

  /**
   * Inserts a vector embedding into the database.
   * @param content - The text content associated with the vector.
   * @param vector - An array of numbers representing the embedding.
   */
  public async insertVector(content: string, vector: number[]): Promise<void> {
    const query = `
      INSERT INTO embeddings (content, embedding)
      VALUES ($1, $2)
    `;
    await this.client.query(query, [content, vector]);
    console.log(`✅ Inserted vector for: "${content}"`);
  }

  /**
   * Performs a cosine similarity search against stored vectors.
   * @param queryVector - The vector to compare against the database.
   * @param limit - The number of results to return.
   * @returns An array of records with similarity scores.
   */
  public async searchSimilarity(
    queryVector: number[],
    limit: number = 3
  ): Promise<VectorRecord[]> {
    // The '<=>' operator calculates cosine distance (0 to 2).
    // 0 means identical, 2 means opposite.
    // We order by the distance (ascending) to find the closest matches.
    const query = `
      SELECT 
        id, 
        content, 
        embedding, 
        1 - (embedding <=> $1::vector) AS similarity_score 
      FROM embeddings 
      ORDER BY embedding <=> $1::vector 
      LIMIT $2
    `;

    const result = await this.client.query(query, [queryVector, limit]);
    
    // Map the raw database row to our interface
    return result.rows.map(row => ({
      id: row.id,
      content: row.content,
      embedding: row.embedding, // pg driver returns this as a string or array depending on config
      similarity_score: row.similarity_score
    }));
  }

  /**
   * Closes the database connection.
   * Essential for graceful shutdowns in serverless or containerized environments.
   */
  public async close(): Promise<void> {
    await this.client.end();
    console.log('🛑 Database connection closed');
  }
}

/**
 * Main execution function simulating a SaaS AI feature (e.g., Semantic Search).
 */
async function main() {
  // Configuration (usually from process.env in production)
  const config: DbConfig = {
    host: 'localhost', // Docker maps port 5432 to localhost
    port: 5432,
    user: 'postgres',
    password: 'mysecretpassword', // Must match the Docker run command
    database: 'postgres',
  };

  const store = new VectorStoreClient(config);

  try {
    // 1. Connect
    await store.connect();

    // 2. Ensure table exists
    await store.initializeSchema();

    // 3. Clear previous data (for a clean "Hello World" run)
    await store.client.query('DELETE FROM embeddings;');
    console.log('🧹 Cleaned up previous data.');

    // 4. Insert dummy data (Simulating Headless Inference generating embeddings)
    // These numbers represent semantic meaning of the text.
    const embeddingsData = [
      { content: 'A cute dog', vector: [0.1, 0.2, 0.9] },
      { content: 'A fast car', vector: [0.8, 0.1, 0.1] },
      { content: 'A cute cat', vector: [0.15, 0.25, 0.85] }, // Similar to dog
      { content: 'A heavy truck', vector: [0.9, 0.1, 0.2] }, // Similar to car
    ];

    for (const data of embeddingsData) {
      await store.insertVector(data.content, data.vector);
    }

    // 5. Perform a Search
    // We search for something semantically close to "A cute dog" but not exact.
    const searchVector = [0.12, 0.22, 0.88];
    console.log(`\n🔍 Searching for vectors similar to: [${searchVector.join(', ')}]`);
    
    const results = await store.searchSimilarity(searchVector, 2);

    // 6. Log Results
    console.log('\n--- Search Results ---');
    results.forEach((res, index) => {
      console.log(
        `${index + 1}. "${res.content}" (Score: ${res.similarity_score?.toFixed(4)})`
      );
    });

  } catch (error) {
    console.error('Application Error:', error);
  } finally {
    // 7. Cleanup
    await store.close();
  }
}

// Execute the main function
// We check if require.main is the entry point to allow importing this module without running main
if (require.main === module) {
  main();
}
