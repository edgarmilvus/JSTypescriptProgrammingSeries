/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

/**
 * Smart Document Ingestion & Semantic Search Script
 * 
 * Context: Book 11, Chapter 16 - Running Databases in Docker
 * Objective: Demonstrate Dockerized PostgreSQL with pgvector for AI-driven data retrieval.
 * 
 * This script connects to a Docker-hosted Postgres instance, creates a table 
 * capable of storing vector embeddings, and performs semantic searches.
 */

import { Pool, QueryResult } from 'pg';
import { pipeline, FeatureExtractionPipeline } from '@xenova/transformers';
import * as dotenv from 'dotenv';

// Load environment variables (Docker host, Port, Credentials)
dotenv.config();

// -----------------------------------------------------------------------------
// 1. Configuration & Environment Setup
// -----------------------------------------------------------------------------

/**
 * Interface defining the structure of our document record.
 * Includes the vector column which will be mapped to Postgres 'vector' type.
 */
interface Document {
    id: number;
    content: string;
    category: string;
    embedding: number[]; // The vector representation
}

/**
 * Database Configuration.
 * In a real SaaS app, these would be injected via Docker Secrets or .env.
 * Note: We target 'localhost' because we mapped the container port 5432 to host.
 */
const dbConfig = {
    host: process.env.DB_HOST || 'localhost',
    port: parseInt(process.env.DB_PORT || '5432'),
    user: process.env.DB_USER || 'postgres',
    password: process.env.DB_PASSWORD || 'mysecretpassword',
    database: process.env.DB_NAME || 'postgres', // Default DB in the container
};

// -----------------------------------------------------------------------------
// 2. Vector Embedding Service (Local AI)
// -----------------------------------------------------------------------------

class EmbeddingService {
    private extractor: FeatureExtractionPipeline | null = null;

    /**
     * Initializes the local Transformer model.
     * Uses 'Xenova/all-MiniLM-L6-v2' for efficient, local CPU-based embeddings.
     * Why Local? Reduces latency and cost for high-volume ingestion compared to API calls.
     */
    async initialize() {
        console.log('🤖 Loading local embedding model...');
        // @ts-ignore - Type definitions for transformers are dynamic
        this.extractor = await pipeline('feature-extraction', 'Xenova/all-MiniLM-L6-v2');
        console.log('✅ Model loaded.');
    }

    /**
     * Generates a vector (384 dimensions) from raw text.
     * @param text - The input string to vectorize.
     * @returns Promise<number[]> - A normalized vector array.
     */
    async generateEmbedding(text: string): Promise<number[]> {
        if (!this.extractor) throw new Error('Embedding service not initialized');
        
        // Generate embeddings with normalization
        const output = await this.extractor(text, { pooling: 'mean', normalize: true });
        return Array.from(output.data);
    }
}

// -----------------------------------------------------------------------------
// 3. Database Manager (Dockerized Postgres)
// -----------------------------------------------------------------------------

class VectorDatabase {
    private pool: Pool;

    constructor(config: any) {
        this.pool = new Pool(config);
    }

    /**
     * Initializes the database schema.
     * Critical: Uses the 'vector' extension provided by pgvector.
     * We create a table with a column of type 'vector(384)' (matching MiniLM dimensions).
     */
    async setupSchema(): Promise<void> {
        const client = await this.pool.connect();
        try {
            // Enable the pgvector extension (required once per DB)
            await client.query('CREATE EXTENSION IF NOT EXISTS vector;');

            // Create the documents table
            await client.query(`
                CREATE TABLE IF NOT EXISTS documents (
                    id SERIAL PRIMARY KEY,
                    content TEXT NOT NULL,
                    category VARCHAR(50),
                    embedding VECTOR(384) -- Fixed dimension for our model
                );
            `);

            // Create an index for efficient Approximate Nearest Neighbor (ANN) search.
            // 'ivfflat' is a standard index for vector data in Postgres.
            // 'cosine' distance is used for semantic similarity.
            await client.query(`
                CREATE INDEX IF NOT EXISTS idx_documents_embedding 
                ON documents 
                USING ivfflat (embedding vector_cosine_ops);
            `);

            console.log('✅ Database schema verified (Table + Vector Index).');
        } catch (error) {
            console.error('❌ Schema setup failed:', error);
        } finally {
            client.release();
        }
    }

    /**
     * Upsert Operation: Inserts a new document or updates if it exists.
     * In a real app, we might check for duplicate content hashes first.
     * @param doc - The document object containing the vector.
     */
    async upsertDocument(doc: { content: string; category: string; embedding: number[] }): Promise<void> {
        const query = `
            INSERT INTO documents (content, category, embedding)
            VALUES ($1, $2, $3)
            ON CONFLICT (id) DO UPDATE 
            SET content = EXCLUDED.content, embedding = EXCLUDED.embedding;
        `;
        await this.pool.query(query, [doc.content, doc.category, doc.embedding]);
    }

    /**
     * Semantic Search: Finds documents similar to the query vector.
     * Uses the '<=>' operator (cosine distance) provided by pgvector.
     * @param queryVector - The vector representation of the search query.
     * @param limit - Number of results to return.
     */
    async semanticSearch(queryVector: number[], limit: number = 3): Promise<QueryResult> {
        // Note: We order by 'embedding <=> $1' which sorts by cosine similarity (lower is better).
        const query = `
            SELECT content, category, 1 - (embedding <=> $1::vector) as similarity
            FROM documents
            ORDER BY embedding <=> $1::vector
            LIMIT $2;
        `;
        
        return this.pool.query(query, [JSON.stringify(queryVector), limit]);
    }

    /**
     * Cleanup: Removes all data (for demo purposes).
     */
    async clearData(): Promise<void> {
        await this.pool.query('DELETE FROM documents;');
        console.log('🗑️  Database cleared.');
    }

    async close() {
        await this.pool.end();
    }
}

// -----------------------------------------------------------------------------
// 4. Main Application Logic
// -----------------------------------------------------------------------------

/**
 * Main execution function.
 * Orchestrates the Docker DB connection, AI embedding, and data retrieval.
 */
async function main() {
    console.log('🚀 Starting Smart Document SaaS Demo...\n');

    // 1. Initialize Services
    const embeddingService = new EmbeddingService();
    await embeddingService.initialize();

    const db = new VectorDatabase(dbConfig);

    try {
        // 2. Ensure DB is ready (Docker container must be running)
        await db.setupSchema();
        await db.clearData(); // Start fresh for the demo

        // 3. Ingest Data (Simulating SaaS User Uploads)
        console.log('\n📥 Ingesting documents...');
        const documents = [
            { content: "Docker containers provide isolated environments for applications.", category: "DevOps" },
            { content: "PostgreSQL is a powerful, open-source object-relational database system.", category: "Database" },
            { content: "React is a JavaScript library for building user interfaces.", category: "Frontend" },
            { content: "Kubernetes orchestrates containerized applications at scale.", category: "DevOps" },
            { content: "pgvector allows storing embeddings in Postgres for AI search.", category: "AI" }
        ];

        for (const doc of documents) {
            const embedding = await embeddingService.generateEmbedding(doc.content);
            await db.upsertDocument({ ...doc, embedding });
            console.log(`  - Indexed: "${doc.content.substring(0, 30)}..."`);
        }

        // 4. Perform Semantic Search (The "Smart" Feature)
        console.log('\n🔍 Performing Semantic Search...');
        
        // Query: "How do I manage software packages?" 
        // This query doesn't match keywords in our data, but "DevOps" concepts are related.
        const searchQuery = "How do I manage software packages?";
        const queryVector = await embeddingService.generateEmbedding(searchQuery);

        const results = await db.semanticSearch(queryVector, 2);

        console.log(`\n📊 Results for: "${searchQuery}"`);
        results.rows.forEach((row, index) => {
            console.log(`\n  Rank ${index + 1} (Score: ${(row.similarity * 100).toFixed(2)}%)`);
            console.log(`  Category: ${row.category}`);
            console.log(`  Content:  ${row.content}`);
        });

    } catch (error) {
        console.error('🔴 Application Error:', error);
        console.log('\n💡 Troubleshooting: Ensure your Docker container is running:');
        console.log('   docker run --name pgvector-db -e POSTGRES_PASSWORD=mysecretpassword -p 5432:5432 -d pgvector/pgvector:pg16');
    } finally {
        await db.close();
    }
}

// Execute
main();
