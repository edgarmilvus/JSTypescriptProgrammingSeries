/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

import { Pool, PoolClient } from 'pg';

// Configuration for connecting to the Dockerized PostgreSQL container
const pool = new Pool({
  user: 'admin',
  host: 'localhost',
  database: 'semantic_search',
  password: 'secret_password',
  port: 5432,
  max: 1, // Keep connections low for this script example
});

/**
 * Performs an upsert operation on the embeddings table.
 * If the ID exists, it updates the content, embedding, and metadata.
 * If it does not exist, it inserts a new record.
 */
async function upsertVector(
  client: PoolClient,
  id: string,
  content: string,
  embedding: number[],
  metadata: Record<string, any>
): Promise<void> {
  const query = `
    INSERT INTO embeddings (id, content, embedding, metadata)
    VALUES ($1, $2, $3::vector, $4)
    ON CONFLICT (id) 
    DO UPDATE SET 
      content = EXCLUDED.content,
      embedding = EXCLUDED.embedding,
      metadata = EXCLUDED.metadata;
  `;

  try {
    await client.query(query, [id, content, embedding, JSON.stringify(metadata)]);
    console.log(`[Success] Upserted record with ID: ${id}`);
  } catch (error) {
    console.error(`[Error] Failed to upsert record ${id}:`, error);
    throw error;
  }
}

// Helper function to generate a random vector of specific length
function generateRandomVector(length: number): number[] {
  return Array.from({ length }, () => Math.random());
}

async function main() {
  const client = await pool.connect();
  
  try {
    // Test Data
    const testId = 'doc_123';
    const initialContent = 'This is the initial content.';
    const initialVector = generateRandomVector(1536);
    const initialMetadata = { source: 'manual', version: 1 };

    console.log('\n--- Step 1: Initial Upsert (Insert) ---');
    await upsertVector(client, testId, initialContent, initialVector, initialMetadata);

    // Verify Insert
    const result1 = await client.query('SELECT metadata FROM embeddings WHERE id = $1', [testId]);
    console.log('Verified Metadata:', result1.rows[0].metadata);

    console.log('\n--- Step 2: Second Upsert (Update) ---');
    const updatedContent = 'This is the updated content.';
    const updatedVector = generateRandomVector(1536); // Simulate a change in embedding
    const updatedMetadata = { source: 'auto', version: 2, status: 'active' };

    await upsertVector(client, testId, updatedContent, updatedVector, updatedMetadata);

    // Verify Update
    const result2 = await client.query('SELECT content, metadata FROM embeddings WHERE id = $1', [testId]);
    console.log('Verified Updated Content:', result2.rows[0].content);
    console.log('Verified Updated Metadata:', result2.rows[0].metadata);

  } catch (error) {
    console.error('Test execution failed:', error);
  } finally {
    // Clean up the connection
    client.release();
    await pool.end();
  }
}

main();
