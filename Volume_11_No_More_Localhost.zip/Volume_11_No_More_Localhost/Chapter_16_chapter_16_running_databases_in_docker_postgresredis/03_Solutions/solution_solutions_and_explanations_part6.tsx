/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part6.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState } from 'react';

// Define the shape of the search results
interface SearchResult {
  content: string;
  similarity_score: number;
}

export const SemanticSearchBar: React.FC = () => {
  const [query, setQuery] = useState<string>('');
  const [results, setResults] = useState<SearchResult[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(false);

  // Helper to simulate generating a 1536-dimensional vector
  const generateMockEmbedding = (text: string): number[] => {
    // In a real app, this would call an LLM API (e.g., OpenAI)
    // Here we just generate random floats based on text length to simulate uniqueness
    const seed = text.length;
    return Array.from({ length: 1536 }, (_, i) => (Math.sin(seed + i) + 1) / 2);
  };

  const handleSearch = async () => {
    if (!query.trim()) return;

    setIsLoading(true);
    setResults([]);

    try {
      // 1. Generate the mock embedding
      const embedding = generateMockEmbedding(query);

      // 2. Send POST request to the hypothetical backend
      // Note: We mock the response since the backend doesn't exist for this exercise
      const response = await fetch('/api/search', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ vector: embedding }),
      });

      // Mocking the response data because the endpoint doesn't exist
      // In a real scenario: const data = await response.json();
      const mockData: SearchResult[] = [
        { content: "Result 1: Docker allows containerization.", similarity_score: 0.92 },
        { content: "Result 2: Postgres is a relational database.", similarity_score: 0.85 },
        { content: "Result 3: Vectors are high-dimensional data.", similarity_score: 0.78 },
      ];

      if (!response.ok) throw new Error('API Error');
      
      setResults(mockData);
    } catch (error) {
      console.error("Search failed:", error);
      setResults([{ content: "Error fetching results.", similarity_score: 0 }]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div style={{ padding: '20px', maxWidth: '600px', margin: '0 auto' }}>
      <div style={{ display: 'flex', gap: '10px', marginBottom: '20px' }}>
        <input
          type="text"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Enter text to search..."
          style={{ flex: 1, padding: '8px' }}
          disabled={isLoading}
        />
        <button onClick={handleSearch} disabled={isLoading}>
          {isLoading ? 'Searching...' : 'Search'}
        </button>
      </div>

      {isLoading && <div style={{ textAlign: 'center' }}>Loading Spinner...</div>}

      <ul style={{ listStyle: 'none', padding: 0 }}>
        {results.map((result, index) => (
          <li key={index} style={{ marginBottom: '15px', border: '1px solid #ddd', padding: '10px' }}>
            <div style={{ marginBottom: '5px' }}>{result.content}</div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
              <span>Similarity:</span>
              <div style={{ flex: 1, height: '8px', backgroundColor: '#eee', borderRadius: '4px', overflow: 'hidden' }}>
                <div 
                  style={{ 
                    width: `${result.similarity_score * 100}%`, 
                    height: '100%', 
                    backgroundColor: '#4caf50' 
                  }} 
                />
              </div>
              <span style={{ fontSize: '0.8em' }}>{(result.similarity_score * 100).toFixed(0)}%</span>
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
};
