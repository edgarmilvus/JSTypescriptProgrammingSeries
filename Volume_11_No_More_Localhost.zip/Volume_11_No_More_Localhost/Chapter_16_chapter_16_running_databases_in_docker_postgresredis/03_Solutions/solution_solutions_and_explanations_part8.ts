/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part8.ts
// Description: Solutions and Explanations
// ==========================================

1. Service Discovery via DNS:
   When a custom bridge network is created (e.g., 'backend-internal'), Docker embeds an internal DNS server.
   This DNS server automatically resolves the service name to the container's internal IP address.
   Therefore, the 'api' container can connect to 'redis' simply by using the hostname 'redis' (as defined in REDIS_URL).
   This eliminates the need for hardcoded IP addresses, which can change when containers restart.

2. Security Implications:
   - Isolation from Host: By not mapping ports (e.g., "6379:6379") for the Redis service, the database is not accessible from the host machine (your laptop). 
     This prevents unauthorized access from outside the Docker environment.
   - Isolation from Default Bridge: Containers on the default bridge network can communicate via IPs, but they lack automatic DNS resolution (unless using legacy links).
     More importantly, the default bridge exposes all container ports to the host by default unless explicitly blocked.
   - Firewall Rules: On a user-defined bridge, containers only communicate if explicitly connected to that network. Containers not on 'backend-internal' cannot reach Redis, creating a strict perimeter.
