/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * @fileoverview GPU-Accelerated Inference Service
 * 
 * This TypeScript module demonstrates how to structure a SaaS backend 
 * that offloads heavy AI computations to a GPU-backed Docker container.
 * 
 * It uses the native 'fetch' API available in Node.js 18+ to communicate 
 * with the inference server.
 */

// -----------------------------------------------------------------------------
// 1. TYPE DEFINITIONS
// -----------------------------------------------------------------------------

/**
 * Represents the structure of the request payload sent to the AI model.
 * @typedef {Object} InferenceRequest
 * @property {string} prompt - The text prompt for the AI model.
 * @property {number} [maxTokens] - Optional limit on output length.
 */
type InferenceRequest = {
  prompt: string;
  maxTokens?: number;
};

/**
 * Represents the response structure received from the AI model.
 * @typedef {Object} InferenceResponse
 * @property {string} result - The generated text or data.
 * @property {number} latencyMs - Processing time in milliseconds.
 */
type InferenceResponse = {
  result: string;
  latencyMs: number;
};

/**
 * Configuration for the Inference Service.
 * In a real SaaS app, these would be loaded from environment variables.
 */
type ServiceConfig = {
  host: string; // The Docker container host (localhost if running locally)
  port: number; // The port exposed by the container
  endpoint: string; // The specific API route
};

// -----------------------------------------------------------------------------
// 2. SERVICE CONFIGURATION
// -----------------------------------------------------------------------------

/**
 * Configuration for the local GPU-accelerated container.
 * 
 * NOTE: In a production Docker Compose setup, 'host' might be the service name
 * (e.g., 'inference-model') defined in docker-compose.yml.
 */
const config: ServiceConfig = {
  host: 'localhost',
  port: 8000, // Example port for the inference server (e.g., FastAPI/Flask)
  endpoint: '/generate',
};

// -----------------------------------------------------------------------------
// 3. CORE LOGIC: INFERENCE CLIENT
// -----------------------------------------------------------------------------

/**
 * Constructs the full URL for the inference API endpoint.
 * @param {ServiceConfig} cfg - The service configuration object.
 * @returns {string} The complete URL.
 */
const buildUrl = (cfg: ServiceConfig): string => {
  return `http://${cfg.host}:${cfg.port}${cfg.endpoint}`;
};

/**
 * Sends a prompt to the GPU-accelerated container and retrieves the result.
 * 
 * This function simulates the interaction between a Node.js backend and a 
 * Python-based AI model running in Docker.
 * 
 * @async
 * @param {InferenceRequest} request - The user's input data.
 * @returns {Promise<InferenceResponse>} The AI-generated result.
 * @throws {Error} If the network request fails or the container is unreachable.
 */
async function performInference(request: InferenceRequest): Promise<InferenceResponse> {
  const url = buildUrl(config);
  const startTime = performance.now();

  try {
    // Simulate network latency to the container
    const response = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(request),
    });

    if (!response.ok) {
      throw new Error(`Inference Server Error: ${response.statusText}`);
    }

    // Parse the JSON response from the AI model
    const data = await response.json() as { generated_text: string };
    
    const endTime = performance.now();
    const latency = Math.round(endTime - startTime);

    return {
      result: data.generated_text,
      latencyMs: latency,
    };
  } catch (error) {
    // Handle network errors specifically
    if (error instanceof Error) {
      console.error(`[Error] Failed to reach GPU container at ${url}:`, error.message);
      throw error;
    }
    throw new Error('An unknown error occurred during inference.');
  }
}

// -----------------------------------------------------------------------------
// 4. MOCK EXECUTION (For Demonstration Purposes)
// -----------------------------------------------------------------------------

/**
 * A mock function to simulate the response from a GPU container.
 * In a real scenario, this is handled by the Docker container running the model.
 */
const mockContainerResponse = async (req: InferenceRequest): Promise<void> => {
  console.log(`\n[Simulated Container] Received prompt: "${req.prompt}"`);
  console.log('[Simulated Container] GPU (NVIDIA A100) allocated. Processing...');
  
  // Simulate heavy computation time (e.g., 1.5 seconds)
  await new Promise(resolve => setTimeout(resolve, 1500));
  
  console.log('[Simulated Container] Inference complete.');
};

/**
 * Main entry point to demonstrate the flow.
 */
async function main() {
  const userPrompt = "Explain the concept of Docker GPU passthrough in one sentence.";

  console.log("--- SaaS Backend: AI Inference Request ---");
  console.log(`User Prompt: "${userPrompt}"`);

  // 1. Prepare the request
  const requestPayload: InferenceRequest = {
    prompt: userPrompt,
    maxTokens: 50,
  };

  // 2. Simulate the container's processing (since we aren't actually running Docker here)
  await mockContainerResponse(requestPayload);

  // 3. Execute the inference call
  try {
    // NOTE: In a real environment, performInference would succeed here.
    // For this standalone example, we catch the expected network error 
    // because the container isn't actually running.
    const result = await performInference(requestPayload);
    
    console.log("\n--- Result ---");
    console.log(`Generated Text: ${result.result}`);
    console.log(`Latency: ${result.latencyMs}ms`);
  } catch (error) {
    // Fallback for the standalone code example
    console.log("\n--- Result (Mocked for Standalone Example) ---");
    console.log("Generated Text: Docker GPU passthrough allows containers to access host GPU hardware directly via the NVIDIA Container Toolkit.");
    console.log("Latency: 1520ms");
  }
}

// Run the main function
if (require.main === module) {
  main();
}
