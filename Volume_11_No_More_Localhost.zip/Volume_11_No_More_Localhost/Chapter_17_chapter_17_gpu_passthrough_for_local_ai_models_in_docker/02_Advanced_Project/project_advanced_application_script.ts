/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

/**
 * ============================================================================
 * File: ai-orchestrator.ts
 * Description: Advanced TypeScript implementation for handling local GPU 
 *              inference with Optimistic UI updates and Tool Calling logic.
 * ============================================================================
 */

// ----------------------------------------------------------------------------
// 1. Type Definitions & Interfaces
// ----------------------------------------------------------------------------

/**
 * Represents the status of an AI task within the UI.
 * 'optimistic': The task is pending; we are showing a placeholder.
 * 'confirmed': The GPU has finished; we have the real data.
 */
type TaskStatus = 'optimistic' | 'confirmed';

/**
 * The base structure for any AI task handled by the orchestrator.
 */
interface AITask {
    id: string;
    type: 'image_generation' | 'text_summarization';
    prompt: string;
    status: TaskStatus;
}

/**
 * An optimistic task contains the prompt and a placeholder (e.g., a loading skeleton).
 */
interface OptimisticTask extends AITask {
    status: 'optimistic';
    placeholder: string; // e.g., "Generating visual..."
}

/**
 * A confirmed task contains the actual result returned from the GPU.
 */
interface ConfirmedTask extends AITask {
    status: 'confirmed';
    result: string; // e.g., Base64 image data or summarized text
    latency: number; // Time taken by the GPU
}

/**
 * The shape of the global application state.
 */
interface AppState {
    tasks: (OptimisticTask | ConfirmedTask)[];
}

// ----------------------------------------------------------------------------
// 2. The GPU Inference Service (Simulating Docker Container Access)
// ----------------------------------------------------------------------------

/**
 * Simulates the connection to a local Docker container running a GPU-accelerated
 * inference server (e.g., via FastAPI or Node.js C++ bindings).
 * 
 * In a real scenario, this method would make an HTTP POST request to the 
 * containerized service exposed on localhost.
 * 
 * @param type - The type of AI model to invoke.
 * @param prompt - The input data for the model.
 * @returns Promise<string> - The raw output from the GPU.
 */
async function callLocalGPUContainer(type: 'image_generation' | 'text_summarization', prompt: string): Promise<string> {
    console.log(`[GPU Service] Dispatching to Docker Container...`);
    
    // SIMULATION: We mock the latency of a GPU processing a heavy tensor operation.
    // In reality, this is the time the GPU spends on the Compute Shader.
    const processingTime = type === 'image_generation' ? 2500 : 800;
    
    return new Promise((resolve) => {
        setTimeout(() => {
            if (type === 'image_generation') {
                resolve(`[GPU_RESULT] Image generated for prompt: "${prompt}" (Base64 Data...)`);
            } else {
                resolve(`[GPU_RESULT] Summary: "${prompt.substring(0, 30)}..." is about AI development.`);
            }
        }, processingTime);
    });
}

// ----------------------------------------------------------------------------
// 3. The Optimistic Store (State Management & Reconciliation)
// ----------------------------------------------------------------------------

/**
 * Manages the application state and handles the "Reconciliation" process.
 * This mimics the behavior of libraries like Redux or Zustand.
 */
class OptimisticStore {
    private state: AppState = { tasks: [] };

    /**
     * Pure function to update state.
     */
    private setState(newState: AppState) {
        this.state = newState;
        this.renderUI(); // Trigger UI update (console log for this demo)
    }

    /**
     * STEP A: Optimistic Update.
     * Immediately adds a task to the UI with a placeholder, before the GPU finishes.
     */
    addOptimisticTask(type: 'image_generation' | 'text_summarization', prompt: string) {
        const newTask: OptimisticTask = {
            id: Math.random().toString(36).substr(2, 9),
            type,
            prompt,
            status: 'optimistic',
            placeholder: type === 'image_generation' 
                ? '🎨 Rendering visual via GPU...' 
                : '📝 Summarizing text on NPU...'
        };

        this.setState({
            ...this.state,
            tasks: [...this.state.tasks, newTask]
        });
    }

    /**
     * STEP B: Reconciliation.
     * Compares the temporary optimistic state with the confirmed data from the GPU.
     * It replaces the placeholder with the actual high-fidelity result.
     */
    reconcileTask(id: string, result: string, latency: number) {
        const updatedTasks = this.state.tasks.map((task) => {
            if (task.id === id && task.status === 'optimistic') {
                // Promote the optimistic task to a confirmed one
                const confirmedTask: ConfirmedTask = {
                    ...task,
                    status: 'confirmed',
                    result: result,
                    latency: latency
                };
                return confirmedTask;
            }
            return task;
        });

        this.setState({
            ...this.state,
            tasks: updatedTasks
        });
    }

    /**
     * Helper to visualize the state changes in the console.
     */
    private renderUI() {
        console.log("\n--- 🖥️  CURRENT UI STATE 🖥️ ---");
        this.state.tasks.forEach(task => {
            console.log(`[${task.status.toUpperCase()}] Type: ${task.type}`);
            if (task.status === 'optimistic') {
                console.log(`   └─ Placeholder: "${task.placeholder}"`);
            } else {
                console.log(`   └─ Result: "${task.result}"`);
                console.log(`   └─ GPU Latency: ${task.latency}ms`);
            }
        });
        console.log("--------------------------------\n");
    }
}

// ----------------------------------------------------------------------------
// 4. Tool Calling Logic (The "Agent")
// ----------------------------------------------------------------------------

/**
 * Simulates an LLM's "Tool Calling" capability.
 * The LLM analyzes the user input and decides which function to execute.
 */
class ToolOrchestrator {
    private store: OptimisticStore;

    constructor(store: OptimisticStore) {
        this.store = store;
    }

    /**
     * The entry point for user requests.
     * In a real app, an LLM would generate this JSON structure.
     */
    async processUserRequest(userPrompt: string) {
        console.log(`\n[Agent] Received: "${userPrompt}"`);
        
        // 1. Decision Logic (Simulating LLM Tool Selection)
        let tool: 'generate_image' | 'summarize_text';
        
        if (userPrompt.toLowerCase().includes("draw") || userPrompt.toLowerCase().includes("image")) {
            tool = 'generate_image';
        } else {
            tool = 'summarize_text';
        }

        console.log(`[Agent] Decided to use tool: ${tool}`);

        // 2. Optimistic UI Update
        // We don't wait for the GPU here. We update the UI immediately.
        const taskType = tool === 'generate_image' ? 'image_generation' : 'text_summarization';
        this.store.addOptimisticTask(taskType, userPrompt);

        // 3. Background GPU Processing
        // We fire and forget, but we need to handle the callback for reconciliation.
        const startTime = Date.now();
        
        try {
            // Call the Docker container
            const gpuResult = await callLocalGPUContainer(taskType, userPrompt);
            const endTime = Date.now();
            const latency = endTime - startTime;

            // 4. Reconciliation Step
            // Find the specific optimistic task and update it with real data.
            // In a React app, we would find the task by ID in the array.
            // Here we access the store directly for simplicity, but in a real app,
            // the store would expose a method to handle this specific update.
            const tasks = (this.store as any).state.tasks; 
            const targetTask = tasks.find((t: any) => t.status === 'optimistic' && t.prompt === userPrompt);
            
            if (targetTask) {
                this.store.reconcileTask(targetTask.id, gpuResult, latency);
            }

        } catch (error) {
            console.error("GPU Inference Failed:", error);
            // Handle error state (e.g., remove optimistic task, show error toast)
        }
    }
}

// ----------------------------------------------------------------------------
// 5. Execution Simulation (The "Main" Block)
// ----------------------------------------------------------------------------

/**
 * Simulates the application lifecycle.
 */
async function runSimulation() {
    console.log("🚀 Initializing Local AI SaaS Application...");
    console.log("🔗 Checking Docker Connection (localhost:8000)... OK");
    console.log("🧠 Loading GPU Drivers... OK\n");

    // Initialize the Store
    const store = new OptimisticStore();
    const agent = new ToolOrchestrator(store);

    // Scenario 1: User requests an Image Generation
    // The UI will update instantly with a "Generating..." message.
    // The heavy lifting happens in the background.
    await agent.processUserRequest("Draw a cyberpunk cityscape at night");

    // Simulate a delay where the user sees the optimistic UI
    console.log("⏳ (User sees the 'Generating visual...' placeholder for 2.5 seconds...)");
    
    // Wait for the background task to complete (simulated inside the agent)
    // In a real async flow, we wouldn't await this, but for the script we need to see the result.
    await new Promise(r => setTimeout(r, 2600)); 

    // Scenario 2: User requests a Text Summarization
    // This happens while the first task is still running (concurrency).
    await agent.processUserRequest("Summarize the latest research on WebGPU compute shaders");

    // Wait for the second task
    await new Promise(r => setTimeout(r, 900));

    // Final State
    console.log("\n✅ Simulation Complete. All tasks reconciled.");
}

// Run the simulation
runSimulation();
