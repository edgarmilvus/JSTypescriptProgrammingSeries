/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// src/gpuMonitor.ts
import { spawn } from 'child_process';
import { parseStringPromise } from 'xml2js';
import express, { Request, Response } from 'express';

// Define the structure of the parsed GPU data
interface GpuStats {
  name: string;
  totalMemory: number; // in MB
  usedMemory: number;  // in MB
  utilization: number; // in %
  temperature: number; // in Celsius
}

/**
 * Executes nvidia-smi with XML output flag and parses the result.
 * Throws an error if nvidia-smi is not found or fails.
 */
async function getGpuStats(): Promise<GpuStats> {
  return new Promise((resolve, reject) => {
    // Using '-x' for XML output which is easier to parse reliably
    const child = spawn('nvidia-smi', ['-x']);

    let stdout = '';
    let stderr = '';

    child.stdout.on('data', (data) => {
      stdout += data.toString();
    });

    child.stderr.on('data', (data) => {
      stderr += data.toString();
    });

    child.on('close', async (code) => {
      if (code !== 0) {
        return reject(new Error(`nvidia-smi failed: ${stderr}`));
      }

      try {
        // Parse the XML output
        const parsed = await parseStringPromise(stdout);
        
        // Extract data from the XML structure (nvidia-smi specific format)
        const gpu = parsed.nvidia_smi_log.gpu[0];
        
        const stats: GpuStats = {
          name: gpu.product_name[0],
          // Parse memory strings like "8192 MiB" to integer
          totalMemory: parseInt(gpu.fb_memory_usage[0].total[0]),
          usedMemory: parseInt(gpu.fb_memory_usage[0].used[0]),
          // Parse utilization strings like "98 %" to integer
          utilization: parseInt(gpu.utilization[0].gpu_util[0]),
          temperature: parseInt(gpu.temperature[0].gpu_temp[0]),
        };

        resolve(stats);
      } catch (err) {
        reject(new Error(`Failed to parse nvidia-smi output: ${err}`));
      }
    });

    child.on('error', (err) => {
      reject(new Error(`Failed to spawn nvidia-smi: ${err.message}`));
    });
  });
}

// Express Server Setup
const app = express();
const PORT = process.env.PORT || 3000;

app.get('/api/gpu-stats', async (req: Request, res: Response) => {
  try {
    const stats = await getGpuStats();
    res.json(stats);
  } catch (error) {
    console.error(error);
    // Graceful error handling if driver is missing or command fails
    res.status(500).json({ 
      error: 'Failed to retrieve GPU stats', 
      message: (error instanceof Error) ? error.message : 'Unknown error' 
    });
  }
});

if (require.main === module) {
  app.listen(PORT, () => {
    console.log(`GPU Monitor running on port ${PORT}`);
  });
}

export { getGpuStats };
