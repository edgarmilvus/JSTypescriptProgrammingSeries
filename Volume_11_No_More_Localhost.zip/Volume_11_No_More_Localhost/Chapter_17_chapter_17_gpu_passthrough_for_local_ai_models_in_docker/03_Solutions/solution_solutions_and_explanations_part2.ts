/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

# docker-compose.yml
version: '3.8'

services:
  # Service 1: Lightweight Vector Database (Redis)
  vector-db:
    image: redis:7-alpine
    container_name: vector_db
    ports:
      - "6379:6379"
    # Redis typically doesn't need GPU, so we omit GPU resources here.
    # We can add resource limits for CPU/Memory to ensure stability.
    deploy:
      resources:
        limits:
          cpus: '1.0'
          memory: 512M
    networks:
      - ai-network

  # Service 2: LLM Inference Server (GPU Required)
  llm-server:
    # Example image: HuggingFace Text Generation Inference (TGI) or similar
    image: ghcr.io/huggingface/text-generation-inference:latest
    container_name: llm_server
    ports:
      - "8080:80"
    # Volume mount to persist model weights downloaded from HuggingFace
    # This prevents re-downloading on container restart.
    volumes:
      - model_weights:/data
    
    # CRITICAL: GPU Configuration
    runtime: nvidia
    environment:
      # Depending on the image, you might need to specify the model to load
      - MODEL_ID=meta-llama/Llama-2-7b-chat-hf 
      - CUDA_VISIBLE_DEVICES=0
    deploy:
      resources:
        reservations:
          devices:
            - driver: nvidia
              count: 1
              capabilities: [gpu]
    
    # Networking: Allows llm-server to communicate with vector-db via hostname
    depends_on:
      - vector-db
    networks:
      - ai-network

networks:
  ai-network:
    driver: bridge

volumes:
  model_weights:
    driver: local
