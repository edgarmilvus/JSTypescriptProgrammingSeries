/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

// src/components/GpuMatrixMultiplier.tsx
import React, { useState } from 'react';

// Matrix dimensions
const SIZE = 1024;
const MATRIX_SIZE = SIZE * SIZE;

const GpuMatrixMultiplier: React.FC = () => {
  const [status, setStatus] = useState<string>('Ready');
  const [cpuTime, setCpuTime] = useState<number>(0);
  const [gpuTime, setGpuTime] = useState<number>(0);

  // Initialize random matrices
  const initMatrices = () => {
    const a = new Float32Array(MATRIX_SIZE).map(() => Math.random());
    const b = new Float32Array(MATRIX_SIZE).map(() => Math.random());
    return { a, b };
  };

  const runOnCpu = () => {
    setStatus('Running on CPU...');
    const { a, b } = initMatrices();
    const result = new Float32Array(MATRIX_SIZE);
    
    const start = performance.now();
    
    // Naive O(N^3) multiplication
    for (let i = 0; i < SIZE; i++) {
      for (let j = 0; j < SIZE; j++) {
        let sum = 0;
        for (let k = 0; k < SIZE; k++) {
          sum += a[i * SIZE + k] * b[k * SIZE + j];
        }
        result[i * SIZE + j] = sum;
      }
    }
    
    const end = performance.now();
    setCpuTime(end - start);
    setStatus('CPU calculation complete.');
  };

  const runOnGpu = async () => {
    if (!navigator.gpu) {
      setStatus('WebGPU not supported in this browser.');
      return;
    }

    setStatus('Initializing WebGPU...');
    const { a, b } = initMatrices();

    try {
      const adapter = await navigator.gpu.requestAdapter();
      if (!adapter) throw new Error('No WebGPU adapter found');
      
      const device = await adapter.requestDevice();
      
      // Create Buffers
      const bufferA = device.createBuffer({
        size: a.byteLength,
        usage: GPUBufferUsage.STORAGE | GPUBufferUsage.COPY_DST,
      });
      const bufferB = device.createBuffer({
        size: b.byteLength,
        usage: GPUBufferUsage.STORAGE | GPUBufferUsage.COPY_DST,
      });
      const bufferResult = device.createBuffer({
        size: a.byteLength,
        usage: GPUBufferUsage.STORAGE | GPUBufferUsage.COPY_SRC,
      });

      // Copy data to GPU
      device.queue.writeBuffer(bufferA, 0, a);
      device.queue.writeBuffer(bufferB, 0, b);

      // Shader Code (WGSL)
      const shaderCode = `
        @group(0) @binding(0) var<storage, read> a: array<f32>;
        @group(0) @binding(1) var<storage, read> b: array<f32>;
        @group(0) @binding(2) var<storage, read_write> result: array<f32>;

        @compute @workgroup_size(8, 8, 1)
        fn main(@builtin(global_invocation_id) global_id: vec3<u32>) {
          let row = global_id.x;
          let col = global_id.y;
          
          if (row >= ${SIZE}u || col >= ${SIZE}u) {
            return;
          }

          var sum = 0.0;
          for (var k = 0u; k < ${SIZE}u; k++) {
            sum += a[row * ${SIZE}u + k] * b[k * ${SIZE}u + col];
          }
          result[row * ${SIZE}u + col] = sum;
        }
      `;

      const shaderModule = device.createShaderModule({ code: shaderCode });

      const computePipeline = device.createComputePipeline({
        layout: 'auto',
        compute: {
          module: shaderModule,
          entryPoint: 'main',
        },
      });

      const bindGroup = device.createBindGroup({
        layout: computePipeline.getBindGroupLayout(0),
        entries: [
          { binding: 0, resource: { buffer: bufferA } },
          { binding: 1, resource: { buffer: bufferB } },
          { binding: 2, resource: { buffer: bufferResult } },
        ],
      });

      // Command Encoder
      const commandEncoder = device.createCommandEncoder();
      const passEncoder = commandEncoder.beginComputePass();
      passEncoder.setPipeline(computePipeline);
      passEncoder.setBindGroup(0, bindGroup);
      
      // Dispatch work (1024/8 = 128 workgroups per dimension)
      passEncoder.dispatchWorkgroups(SIZE / 8, SIZE / 8);
      passEncoder.end();

      // Read back buffer (Mapped for reading)
      const readBuffer = device.createBuffer({
        size: a.byteLength,
        usage: GPUBufferUsage.COPY_DST | GPUBufferUsage.MAP_READ,
      });

      commandEncoder.copyBufferToBuffer(bufferResult, 0, readBuffer, 0, a.byteLength);

      // Measure GPU time (excluding data transfer)
      const start = performance.now();
      
      const gpuCommands = commandEncoder.finish();
      device.queue.submit([gpuCommands]);

      // Wait for compute to finish
      await device.queue.onSubmittedWorkDone();
      
      const end = performance.now();
      setGpuTime(end - start);

      // Verify correctness (optional, by mapping and checking a few values)
      await readBuffer.mapAsync(GPUMapMode.READ);
      const resultData = new Float32Array(readBuffer.getMappedRange());
      // Unmap immediately after reading
      readBuffer.unmap();
      
      setStatus('GPU calculation complete.');

    } catch (error) {
      console.error(error);
      setStatus(`GPU Error: ${(error as Error).message}`);
    }
  };

  return (
    <div style={{ padding: '20px', fontFamily: 'sans-serif' }}>
      <h2>Matrix Multiplication: CPU vs GPU (WebGPU)</h2>
      <p>Matrix Size: {SIZE}x{SIZE} (Total Elements: {MATRIX_SIZE.toLocaleString()})</p>
      
      <div style={{ marginBottom: '20px' }}>
        <button onClick={runOnCpu} style={{ marginRight: '10px', padding: '10px' }}>
          Run on CPU
        </button>
        <button onClick={runOnGpu} style={{ padding: '10px' }}>
          Run on GPU
        </button>
      </div>

      <div>
        <h3>Results:</h3>
        <p><strong>Status:</strong> {status}</p>
        <p><strong>CPU Time:</strong> {cpuTime.toFixed(2)} ms</p>
        <p><strong>GPU Time (Compute Only):</strong> {gpuTime.toFixed(2)} ms</p>
        {cpuTime > 0 && gpuTime > 0 && (
          <p>
            <strong>Speedup:</strong> {(cpuTime / gpuTime).toFixed(2)}x
          </p>
        )}
      </div>
    </div>
  );
};

export default GpuMatrixMultiplier;
