/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

// src/exercises/loadTest.ts
import axios from 'axios';

// Configuration for the mock server delay
const PROCESSING_FACTOR_MS = 2; // Simulates 2ms per token
const BASE_LATENCY_MS = 10;

// Mock server simulation (if running locally without a real server)
// In a real scenario, this would be an actual API endpoint URL.
const MOCK_ENDPOINT = 'http://localhost:8000/inference'; 

/**
 * Simulates a single request delay based on batch size.
 * In a real test, this would be an axios.post call.
 */
const simulateRequest = (batchSize: number): Promise<number> => {
  return new Promise((resolve) => {
    // Calculate synthetic latency: Base + (Batch Size * Factor)
    const duration = BASE_LATENCY_MS + (batchSize * PROCESSING_FACTOR_MS);
    
    // Simulate network latency variance (random jitter +/- 10%)
    const jitter = duration * (Math.random() * 0.2 - 0.1);
    const totalDelay = Math.max(1, duration + jitter);

    setTimeout(() => {
      resolve(totalDelay);
    }, totalDelay);
  });
};

/**
 * Runs a load test with specific batch size and concurrency.
 */
async function runLoadTest(batchSize: number, concurrency: number) {
  console.log(`\n--- Testing Batch Size: ${batchSize} | Concurrency: ${concurrency} ---`);
  const startTime = performance.now();

  // Create an array of promises representing concurrent requests
  const requests = Array.from({ length: concurrency }, () => simulateRequest(batchSize));

  try {
    const results = await Promise.all(requests);
    const endTime = performance.now();
    const totalTime = endTime - startTime;

    // Calculate metrics
    const avgLatency = results.reduce((a, b) => a + b, 0) / results.length;
    const throughput = (concurrency * batchSize) / (totalTime / 1000); // tokens per second

    console.log(`Total Execution Time: ${totalTime.toFixed(2)} ms`);
    console.log(`Average Request Latency: ${avgLatency.toFixed(2)} ms`);
    console.log(`Estimated Throughput: ${throughput.toFixed(2)} tokens/sec`);
    
    return { batchSize, totalTime, throughput };
  } catch (error) {
    console.error('Load test failed:', error);
    return null;
  }
}

/**
 * Main runner to iterate through batch sizes and visualize results.
 */
async function main() {
  const batchSizes = [1, 4, 16, 32, 64];
  const concurrency = 10; // Fixed number of concurrent users
  
  console.log("Starting Latency vs. Throughput Analysis...");
  console.log("Simulating inference server with base latency and linear scaling per token.");

  const results = [];

  for (const size of batchSizes) {
    const result = await runLoadTest(size, concurrency);
    if (result) results.push(result);
    
    // Small delay between tests
    await new Promise(r => setTimeout(r, 100));
  }

  // Output ASCII Table
  console.log("\n\n=== FINAL ANALYSIS ===");
  console.log("Batch Size | Total Time (ms) | Throughput (tokens/sec)");
  console.log("-".repeat(60));
  
  results.forEach(r => {
    console.log(
      `${r.batchSize.toString().padEnd(10)} | ${r.totalTime.toFixed(2).padEnd(15)} | ${r.throughput.toFixed(2)}`
    );
  });

  console.log("\nObservation:");
  console.log("As batch size increases, total execution time generally increases (latency penalty).");
  console.log("However, throughput (tokens/sec) usually improves up to a point (GPU saturation),");
  console.log("demonstrating the trade-off between processing individual requests quickly (low latency)");
  console.log("and maximizing hardware utilization (high throughput).");
}

if (require.main === module) {
  main();
}
