/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

// src/checkpointer/RedisCheckpointer.ts
import Redis from 'ioredis';

// Basic interface for LangGraph checkpointing
interface Checkpoint {
  v: number; // version
  ts: string; // timestamp
  data: any;  // graph state data
}

export class RedisCheckpointer {
  private redis: Redis;
  private keyPrefix: string = 'langgraph:';

  constructor(host: string = 'localhost', port: number = 6379) {
    this.redis = new Redis({
      host,
      port,
      retryStrategy: (times) => {
        const delay = Math.min(times * 50, 2000);
        return delay;
      },
    });

    this.redis.on('error', (err) => {
      console.error('Redis Checkpointer Error:', err.message);
    });
  }

  /**
   * Saves the current state of the graph to Redis.
   * @param threadId - Unique identifier for the conversation thread.
   * @param state - The current state object from LangGraph.
   */
  async saveState(threadId: string, state: any): Promise<void> {
    try {
      const checkpoint: Checkpoint = {
        v: 1,
        ts: new Date().toISOString(),
        data: state,
      };

      // Serialize the checkpoint to a JSON string
      const serialized = JSON.stringify(checkpoint);
      
      // Store in Redis with an expiration (optional, e.g., 24 hours)
      await this.redis.setex(`${this.keyPrefix}${threadId}`, 86400, serialized);
      console.log(`State saved for thread: ${threadId}`);
    } catch (error) {
      console.error('Failed to save state:', error);
      throw error;
    }
  }

  /**
   * Loads the state from Redis for a given thread.
   * @param threadId - Unique identifier for the conversation thread.
   * @returns The parsed state or null if not found.
   */
  async loadState(threadId: string): Promise<Checkpoint | null> {
    try {
      const data = await this.redis.get(`${this.keyPrefix}${threadId}`);
      if (!data) return null;

      const checkpoint: Checkpoint = JSON.parse(data);
      console.log(`State loaded for thread: ${threadId}`);
      return checkpoint;
    } catch (error) {
      console.error('Failed to load state:', error);
      return null;
    }
  }

  /**
   * Deletes the state for a specific thread.
   * @param threadId - Unique identifier for the conversation thread.
   */
  async deleteState(threadId: string): Promise<void> {
    try {
      await this.redis.del(`${this.keyPrefix}${threadId}`);
      console.log(`State deleted for thread: ${threadId}`);
    } catch (error) {
      console.error('Failed to delete state:', error);
    }
  }

  /**
   * Closes the Redis connection.
   */
  async close(): Promise<void> {
    await this.redis.quit();
  }
}
