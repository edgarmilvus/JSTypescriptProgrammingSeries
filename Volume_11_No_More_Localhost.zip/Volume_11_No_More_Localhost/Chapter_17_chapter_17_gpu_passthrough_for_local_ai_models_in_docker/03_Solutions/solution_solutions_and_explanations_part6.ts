/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part6.ts
// Description: Solutions and Explanations
// ==========================================

# docker-compose.yml (for Exercise 5)
version: '3.8'

services:
  # Redis Service for State Persistence
  redis:
    image: redis:7-alpine
    container_name: langgraph_redis
    ports:
      - "6379:6379"
    # Persist Redis data to a volume to survive container restarts
    volumes:
      - redis_data:/data
    networks:
      - langgraph-net

  # Agent Service (Node.js Application)
  agent:
    build: 
      context: .
      dockerfile: Dockerfile # Assumes a Dockerfile exists for the Node/TS app
    container_name: langgraph_agent
    environment:
      # Connect to Redis using the service name defined above
      - REDIS_HOST=redis
      - REDIS_PORT=6379
      - NODE_ENV=production
    depends_on:
      - redis
    volumes:
      # Mount source code for hot-reloading in development
      - .:/app
      - /app/node_modules
    networks:
      - langgraph-net
    # Ensure the agent restarts if it crashes
    restart: unless-stopped

networks:
  langgraph-net:
    driver: bridge

volumes:
  redis_data:
    driver: local
