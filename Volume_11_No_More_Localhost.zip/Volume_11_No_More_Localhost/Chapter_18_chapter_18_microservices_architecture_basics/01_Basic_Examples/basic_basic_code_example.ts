/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

// chat-service/index.ts
import { createServer, IncomingMessage, ServerResponse } from 'http';

/**
 * @description Simulates an interaction with an LLM (e.g., GPT-4).
 * In a real app, this would be an API call to OpenAI or a local model.
 * @param {string} userMessage - The input from the user.
 * @returns {string} - The simulated AI response.
 */
const getAIResponse = (userMessage: string): string => {
  // Simple logic to simulate an AI agent
  if (userMessage.toLowerCase().includes('hello')) {
    return "Hello! I am your AI assistant. How can I help you today?";
  }
  if (userMessage.toLowerCase().includes('time')) {
    return "I cannot tell the time, but I can tell you that time is relative.";
  }
  return "I'm just a simple chat service, but I heard you say: " + userMessage;
};

/**
 * @description Handles incoming HTTP requests specifically for the Chat Service.
 * It parses the JSON body, processes the message, and returns a JSON response.
 * @param {IncomingMessage} req - The HTTP request object.
 * @param {ServerResponse} res - The HTTP response object.
 */
const handleChatRequest = (req: IncomingMessage, res: ServerResponse) => {
  let body = '';

  // 1. Accumulate data chunks from the request stream
  req.on('data', (chunk) => {
    body += chunk.toString();
  });

  // 2. Process the complete request body
  req.on('end', () => {
    try {
      // Parse the incoming JSON payload
      const { message } = JSON.parse(body);

      if (!message) {
        res.writeHead(400, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: 'Message is required' }));
        return;
      }

      // 3. Generate the AI response
      const aiResponse = getAIResponse(message);

      // 4. Send the response back to the caller (Gateway)
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({
        response: aiResponse,
        service: 'chat-service',
        timestamp: new Date().toISOString()
      }));

    } catch (error) {
      res.writeHead(400, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ error: 'Invalid JSON format' }));
    }
  });
};

// Create and start the server
const PORT = 3001;
const server = createServer(handleChatRequest);

server.listen(PORT, () => {
  console.log(`🚀 Chat Service running on http://localhost:${PORT}`);
});
