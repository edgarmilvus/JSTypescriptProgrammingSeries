/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.ts
// Description: Basic Code Example
// ==========================================

// gateway/index.ts
import { createServer, IncomingMessage, ServerResponse } from 'http';
import { request, RequestOptions } from 'http';

/**
 * @description Proxies the request to the internal Chat Service.
 * This demonstrates the "Gateway Routing" pattern.
 * @param {IncomingMessage} clientReq - The request from the client.
 * @param {ServerResponse} clientRes - The response to send back to the client.
 */
const proxyToChatService = (clientReq: IncomingMessage, clientRes: ServerResponse) => {
  let body = '';

  clientReq.on('data', (chunk) => {
    body += chunk.toString();
  });

  clientReq.on('end', () => {
    // Configuration for the internal service call
    const options: RequestOptions = {
      hostname: 'localhost',
      port: 3001, // The Chat Service port
      path: '/api/chat', // The internal endpoint
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Content-Length': Buffer.byteLength(body),
      },
    };

    // Create a request to the internal Chat Service
    const internalReq = request(options, (internalRes) => {
      let internalBody = '';

      internalRes.on('data', (chunk) => {
        internalBody += chunk.toString();
      });

      internalRes.on('end', () => {
        // Forward the internal service response back to the original client
        clientRes.writeHead(internalRes.statusCode || 200, internalRes.headers);
        clientRes.end(internalBody);
      });
    });

    // Handle errors in the internal request
    internalReq.on('error', (err) => {
      console.error('Error connecting to Chat Service:', err);
      clientRes.writeHead(502, { 'Content-Type': 'application/json' });
      clientRes.end(JSON.stringify({ error: 'Bad Gateway: Chat Service unavailable' }));
    });

    // Write the body to the internal request and end it
    internalReq.write(body);
    internalReq.end();
  });
};

/**
 * @description Main request handler for the Gateway.
 * It routes requests based on the path and method.
 * @param {IncomingMessage} req - The HTTP request object.
 * @param {ServerResponse} res - The HTTP response object.
 */
const handleGatewayRequest = (req: IncomingMessage, res: ServerResponse) => {
  // Only handle POST requests to /chat
  if (req.method === 'POST' && req.url === '/chat') {
    proxyToChatService(req, res);
  } else {
    res.writeHead(404, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ error: 'Endpoint not found' }));
  }
};

// Create and start the Gateway server
const GATEWAY_PORT = 3000;
const gatewayServer = createServer(handleGatewayRequest);

gatewayServer.listen(GATEWAY_PORT, () => {
  console.log(`🌐 API Gateway running on http://localhost:${GATEWAY_PORT}`);
  console.log(`   (Forwarding requests to Chat Service on port 3001)`);
});
