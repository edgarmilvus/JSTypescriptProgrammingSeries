/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// app/actions/chat.ts
'use server';

import { z } from 'zod';
import { VectorService } from '@/lib/services/vector-service';
import { ModelService } from '@/lib/services/model-service';

/**
 * ============================================================================
 * 1. DATA MODELS & SCHEMAS
 * ============================================================================
 * Defines the contract for data entering and leaving our microservices.
 * Using Zod ensures type safety and validation at the API boundary.
 */

// Schema for incoming user messages
const UserMessageSchema = z.object({
  message: z.string().min(1, "Message cannot be empty").max(500),
  sessionId: z.string().uuid(),
});

// Type inference for the message payload
export type UserMessage = z.infer<typeof UserMessageSchema>;

// Schema for the response from the AI service
const AiResponseSchema = z.object({
  response: z.string(),
  contextSources: z.array(z.string()), // Simulating sources from vector DB
  timestamp: z.date(),
});

export type AiResponse = z.infer<typeof AiResponseSchema>;

/**
 * ============================================================================
 * 2. SERVER ACTIONS (INTER-SERVICE COMMUNICATION)
 * ============================================================================
 * These functions act as the "API Gateway" and internal orchestration layer.
 * They are invoked directly from the Client Component but execute securely on the server.
 */

/**
 * Handles the incoming chat message, orchestrates the microservices,
 * and returns the AI response.
 * 
 * @param prevState - Previous form state (for Next.js useFormState)
 * @param formData - Form data containing the user message
 * @returns Promise<AiResponse> - The structured response
 */
export async function handleChatAction(
  prevState: any,
  formData: FormData
): Promise<AiResponse> {
  try {
    // 1. Parse and Validate Input (Boundary Check)
    const rawData = {
      message: formData.get('message'),
      sessionId: formData.get('sessionId') || crypto.randomUUID(),
    };
    
    const parsed = UserMessageSchema.safeParse(rawData);
    
    if (!parsed.success) {
      throw new Error("Invalid input format");
    }
    
    const { message, sessionId } = parsed.data;

    // 2. Orchestrate Microservices
    // We instantiate services here. In a real containerized app, 
    // these might be separate microservices communicating via HTTP/gRPC.
    
    // A. Vector Service: Retrieve relevant context
    const vectorService = new VectorService();
    const context = await vectorService.retrieveContext(message);

    // B. Model Service: Generate response based on context
    const modelService = new ModelService();
    const responseText = await modelService.generate({
      prompt: message,
      context: context,
      sessionId,
    });

    // 3. Return Structured Response
    return {
      response: responseText,
      contextSources: context.sources,
      timestamp: new Date(),
    };

  } catch (error) {
    console.error("Chat Service Error:", error);
    // In a production app, we would return a structured error object
    // matching the AiResponseSchema but with an error flag.
    return {
      response: "Sorry, I encountered an error processing your request.",
      contextSources: [],
      timestamp: new Date(),
    };
  }
}

/**
 * ============================================================================
 * 3. SERVICE LAYER IMPLEMENTATIONS
 * ============================================================================
 * These classes simulate distinct microservices. In a real architecture,
 * these would likely live in separate repositories or containers.
 */

/**
 * Service responsible for interacting with the Vector Database (e.g., Pinecone, pgvector).
 * It abstracts the complexity of embeddings and similarity search.
 */
export class VectorService {
  /**
   * Simulates querying a vector index for semantic search.
   * Under the hood, this would:
   * 1. Convert query text to an embedding vector.
   * 2. Query the HNSW index for nearest neighbors.
   * 3. Return top-k relevant text chunks.
   */
  async retrieveContext(query: string): Promise<{ text: string; sources: string[] }> {
    // Simulate network latency
    await new Promise(resolve => setTimeout(resolve, 150));

    // Mock vector index response
    // In reality: const embedding = await createEmbedding(query);
    // const results = await pineconeIndex.query({ vector: embedding, topK: 3 });
    
    const mockSources = [
      "Documentation on Next.js Server Actions",
      "Microservices Architecture Patterns",
      "Docker Containerization Guide"
    ];

    return {
      text: `Context: ${mockSources.join('. ')}.`,
      sources: mockSources
    };
  }
}

/**
 * Service responsible for interacting with the LLM (e.g., OpenAI, Anthropic).
 * It handles prompt engineering and temperature settings.
 */
export class ModelService {
  /**
   * Generates a chat completion using the provided prompt and context.
   * Under the hood, this constructs a system prompt and calls the LLM API.
   */
  async generate(input: { prompt: string; context: { text: string }; sessionId: string }): Promise<string> {
    // Simulate network latency for LLM generation
    await new Promise(resolve => setTimeout(resolve, 800));

    // Mock LLM Response
    // In reality: await openai.chat.completions.create({ model: 'gpt-4', ... })
    
    const systemPrompt = `
      You are a helpful AI assistant for a SaaS platform.
      User Query: "${input.prompt}"
      Context: "${input.context.text}"
      
      Please provide a helpful answer based on the context provided.
    `;

    // Simulating a generated response based on the prompt
    return `Based on the context regarding "${input.context.text}", here is your answer: You should use Server Components for data fetching and Server Actions for secure logic processing.`;
  }
}
