/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script_part2.tsx
// Description: Advanced Application Script
// ==========================================

// app/components/ChatInterface.tsx
'use client';

import { useActionState } from 'react';
import { handleChatAction, AiResponse } from '@/app/actions/chat';

const initialState: AiResponse = {
  response: "Ask me anything about Microservices...",
  contextSources: [],
  timestamp: new Date(),
};

export function ChatInterface() {
  // useActionState handles the pending state and result of the server action
  const [state, formAction, isPending] = useActionState(
    handleChatAction,
    initialState
  );

  return (
    <div className="max-w-2xl mx-auto p-6 bg-white rounded-lg shadow-lg border border-gray-200">
      <div className="mb-6 p-4 bg-gray-50 rounded border min-h-[200px]">
        <p className="font-semibold text-gray-700 mb-2">AI Response:</p>
        <p className="text-gray-900">{state.response}</p>
        
        {state.contextSources.length > 0 && (
          <div className="mt-4 pt-4 border-t border-gray-200">
            <p className="text-xs font-bold text-gray-500 uppercase">Sources:</p>
            <ul className="list-disc list-inside text-xs text-gray-600 mt-1">
              {state.contextSources.map((src, idx) => (
                <li key={idx}>{src}</li>
              ))}
            </ul>
          </div>
        )}
      </div>

      <form action={formAction} className="flex gap-2">
        <input
          type="text"
          name="message"
          placeholder="Type your question..."
          className="flex-1 px-4 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
          disabled={isPending}
        />
        <input type="hidden" name="sessionId" value="user-session-123" />
        <button
          type="submit"
          disabled={isPending}
          className="px-6 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 disabled:opacity-50 transition-colors"
        >
          {isPending ? 'Thinking...' : 'Send'}
        </button>
      </form>
    </div>
  );
}
