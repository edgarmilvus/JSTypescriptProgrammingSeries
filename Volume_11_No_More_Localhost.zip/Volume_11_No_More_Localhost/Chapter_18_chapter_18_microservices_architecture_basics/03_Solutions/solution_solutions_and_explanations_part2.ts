/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

// 1. API CONTRACT DEFINITION
// File: shared/types/auth.types.ts

export interface UserPurchaseHistoryResponse {
  userId: string;
  purchaseHistoryIds: string[]; // Only non-sensitive data needed for recommendations
  lastActive: string;
}

export interface AuthApiError {
  error: string;
  code: number;
}

// 2. CLIENT WRAPPER IMPLEMENTATION
// File: recommendation-service/utils/authClient.ts

import axios, { AxiosError, AxiosInstance } from 'axios';

// Service Discovery: In a real scenario, this would resolve via DNS or a Service Mesh (e.g., Consul).
// For this example, we use an environment variable.
const AUTH_SERVICE_URL = process.env.AUTH_SERVICE_URL || 'http://auth-service:3000';

// Create an Axios instance with default configurations
const authApiClient: AxiosInstance = axios.create({
  baseURL: AUTH_SERVICE_URL,
  timeout: 2000, // Fail fast: 2 second timeout
});

export async function fetchUserContext(userId: string): Promise<UserPurchaseHistoryResponse> {
  try {
    // Assuming internal service-to-service auth (e.g., mTLS or shared secret)
    const response = await authApiClient.get(`/internal/users/${userId}/history`, {
      headers: { 'X-Internal-Secret': process.env.SERVICE_SECRET }
    });
    return response.data;
  } catch (error) {
    const axiosError = error as AxiosError;
    
    // Error Handling Strategy
    if (axiosError.code === 'ECONNABORTED') {
      console.error('Auth-Service timeout');
      throw new Error('ServiceUnavailable');
    }
    
    if (axiosError.response?.status >= 500) {
      console.error('Auth-Service internal error');
      // In a real scenario, trigger a Circuit Breaker here
      throw new Error('UpstreamError');
    }

    throw error;
  }
}

// 3. API GATEWAY EXPLANATION
/*
An API Gateway (e.g., Kong, NGINX, AWS API Gateway) sits between the client and the microservices.

1. Request Routing: The Gateway maps external URLs to internal services. 
   Example: `/api/recommendations` routes to `Recommendation-Service`, while `/api/auth/login` routes to `Auth-Service`.
   This hides the internal network topology from the client.

2. Rate Limiting: It prevents abuse by limiting how many requests a specific user or IP can make per minute, protecting the backend services (especially the heavy Recommendation-Service) from being overwhelmed.

3. Authentication Offloading: Instead of every service implementing JWT verification logic, the Gateway handles it.
   - The Gateway validates the JWT on incoming requests.
   - If valid, it forwards the request to the internal service, often adding headers like `X-User-ID` to the request so the internal service knows who the user is without parsing the token again.
*/
