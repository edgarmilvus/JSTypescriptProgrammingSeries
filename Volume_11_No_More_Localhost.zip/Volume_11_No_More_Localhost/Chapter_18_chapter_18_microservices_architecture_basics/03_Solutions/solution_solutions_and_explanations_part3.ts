/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

// 1. EVENT SCHEMA DESIGN
// File: shared/events/userProfileUpdated.event.ts

export interface UserProfileUpdatedEvent {
  userId: string;
  timestamp: Date;
  newAvatarUrl: string;
  eventId: string; // Unique ID for idempotency
}

// 2. PRODUCER LOGIC (User-Service)
// File: user-service/controllers/updateAvatar.ts

import { publishToQueue } from '../services/messageQueue'; // Abstracted MQ client

export async function updateAvatar(userId: string, newAvatarUrl: string) {
  // 1. Update the database synchronously
  await db.query('UPDATE users SET avatar_url = $1 WHERE id = $2', [newAvatarUrl, userId]);

  // 2. Prepare the event payload
  const event: UserProfileUpdatedEvent = {
    userId,
    timestamp: new Date(),
    newAvatarUrl,
    eventId: crypto.randomUUID(),
  };

  // 3. Publish event to the queue (e.g., RabbitMQ 'user_events' exchange)
  // This is "fire and forget" in terms of the HTTP response, but reliable via the queue.
  try {
    await publishToQueue('user_events', event);
  } catch (error) {
    // Log error but do not fail the request (consider a retry mechanism or storing in a fallback DB)
    console.error('Failed to publish profile update event', error);
  }

  return { success: true, message: 'Profile updated' };
}

// 3. CONSUMER LOGIC (Image-Processing-Service)
// File: image-service/workers/processAvatar.ts

import { consumeQueue } from '../services/messageQueue'; // Abstracted MQ client
import { UserProfileUpdatedEvent } from '@shared/events/userProfileUpdated.event';

const DLQ_NAME = 'user_events_dlq';

export async function startImageWorker() {
  await consumeQueue('user_events', async (message: UserProfileUpdatedEvent) => {
    try {
      console.log(`Processing avatar for user: ${message.userId}`);
      
      // Simulate heavy image processing
      await generateThumbnail(message.newAvatarUrl);

      // CRITICAL: Acknowledge only after successful processing
      // If the consumer crashes before this, the message is re-delivered.
      return true; // Ack
    } catch (error) {
      console.error(`Error processing avatar ${message.newAvatarUrl}:`, error);
      
      // Error Handling & Dead Letter Queue (DLQ)
      // If the error is unrecoverable (e.g., corrupt URL), send to DLQ for manual inspection.
      // Usually, we might retry X times first, then move to DLQ.
      if (error instanceof CorruptImageError) {
        await moveToDLQ(message, DLQ_NAME, error.message);
        return true; // Ack to remove from main queue to prevent blocking
      }
      
      return false; // Nack: Requeue for retry
    }
  });
}
