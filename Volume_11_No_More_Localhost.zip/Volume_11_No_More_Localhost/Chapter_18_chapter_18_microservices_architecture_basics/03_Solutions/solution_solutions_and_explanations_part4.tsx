/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.tsx
// Description: Solutions and Explanations
// ==========================================

// File: app/dashboard/page.tsx (Server Component)

import { Suspense } from 'react';
import { ChatSummary } from './_components/ChatSummary.client'; // Client Component
import { getUserProfile, getRecentChats } from './_lib/data';
import { exportChatsToCsv } from './_actions/exportChats';

// 1. & 3. Server Component with Data Fetching and Caching
// Using React.cache (Next.js specific) to deduplicate data fetches if multiple components need the same data.
import { cache } from 'react';

const getCachedUserProfile = cache(getUserProfile);

export default async function DashboardView() {
  // Fetch data in parallel
  const [profile, chats] = await Promise.all([
    getCachedUserProfile(), // Slow DB call, cached
    getRecentChats(),
  ]);

  return (
    <div className="p-4">
      <h1>AI Dashboard</h1>
      
      {/* User Profile Summary */}
      <section className="mb-6">
        <h2>Profile</h2>
        <p>Name: {profile.name}</p>
        <p>Credits: {profile.credits}</p>
      </section>

      {/* 4. Client Interaction */}
      <Suspense fallback={<div>Loading chats...</div>}>
        <ChatSummary chats={chats} onExport={exportChatsToCsv} />
      </Suspense>
    </div>
  );
}

// File: app/dashboard/_components/ChatSummary.client.tsx
'use client';

import { useState } from 'react';

// Define prop types
interface ChatSummaryProps {
  chats: Array<{ id: string; title: string; date: string }>;
  onExport: (chatIds: string[]) => Promise<void>;
}

export function ChatSummary({ chats, onExport }: ChatSummaryProps) {
  const [isExporting, setIsExporting] = useState(false);

  const handleExport = async () => {
    setIsExporting(true);
    try {
      const ids = chats.map(c => c.id);
      await onExport(ids); // Calls the Server Action
      alert('Export started!');
    } catch (error) {
      alert('Export failed');
    } finally {
      setIsExporting(false);
    }
  };

  return (
    <div>
      <h2>Recent Chats</h2>
      <ul>
        {chats.map((chat) => (
          <li key={chat.id}>{chat.title} ({chat.date})</li>
        ))}
      </ul>
      <button onClick={handleExport} disabled={isExporting}>
        {isExporting ? 'Exporting...' : 'Export Chats to CSV'}
      </button>
    </div>
  );
}

// File: app/dashboard/_actions/exportChats.ts
'use server';

export async function exportChatsToCsv(chatIds: string[]) {
  // Server-side logic to generate CSV
  // In a real app, this might query the DB again or generate a file stream
  console.log(`Generating CSV for chats: ${chatIds.join(', ')}`);
  
  // Simulate processing
  await new Promise((resolve) => setTimeout(resolve, 1000));
  
  return { success: true };
}
