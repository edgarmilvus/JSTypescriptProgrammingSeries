/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises.ts
// Description: Practical Exercises
// ==========================================

// LEGACY MONOLITHIC CODE SNIPPET
// app.ts

// Shared Database Connection
const db = new Database('postgres://user:pass@localhost/totally_unscaled_db');

// 1. Auth Logic
app.post('/login', async (req, res) => {
  const user = await db.query('SELECT * FROM users WHERE email = $1', [req.body.email]);
  // ... JWT generation logic ...
  res.json({ token });
});

// 2. Catalog Logic
app.get('/products', async (req, res) => {
  const products = await db.query('SELECT * FROM products');
  res.json(products);
});

// 3. AI Recommendation Logic (The Bottleneck)
app.get('/recommendations', async (req, res) => {
  // Heavy CPU-bound operation: Fetches embeddings, calculates cosine similarity
  const userId = req.user.id; // Assumes auth middleware ran
  const userHistory = await db.query('SELECT * FROM orders WHERE user_id = $1', [userId]);
  const recommendations = await calculateAiRecommendations(userHistory); // Blocks event loop
  res.json(recommendations);
});
