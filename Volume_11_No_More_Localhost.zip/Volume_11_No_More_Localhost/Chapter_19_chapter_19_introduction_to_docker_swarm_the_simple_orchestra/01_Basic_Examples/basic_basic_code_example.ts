/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

// server.ts
import express from 'express';
import { z } from 'zod';

// 1. Runtime Validation Schema
// We define a schema to validate the incoming request body.
// This ensures that even in a distributed environment, data integrity is maintained.
const RequestBodySchema = z.object({
  message: z.string().min(1),
});

// 2. Application Initialization
const app = express();
app.use(express.json());

// 3. Health Check Endpoint
// Swarm uses health checks to determine if a container is healthy enough to receive traffic.
app.get('/health', (req, res) => {
  res.status(200).json({ status: 'healthy' });
});

// 4. Main Endpoint with Load Balancing Proof
app.post('/api/v1/greet', async (req, res) => {
  try {
    // Parse and validate the input at runtime
    const validatedData = RequestBodySchema.parse(req.body);

    // Simulate processing (e.g., AI inference or DB lookup)
    // In a real app, this might be an async call to a model or database.
    await new Promise((resolve) => setTimeout(resolve, 100));

    // Construct the response
    const responsePayload = {
      greeting: `Hello, ${validatedData.message}!`,
      servedBy: process.env.HOSTNAME || 'unknown', // Docker injects the container ID/hostname
      timestamp: new Date().toISOString(),
    };

    // Respond with the validated data
    res.json(responsePayload);
  } catch (error) {
    // Handle validation errors specifically
    if (error instanceof z.ZodError) {
      return res.status(400).json({ error: 'Invalid input', details: error.errors });
    }
    // Handle generic errors
    res.status(500).json({ error: 'Internal Server Error' });
  }
});

// 5. Start the Server
const PORT = 3000;
app.listen(PORT, () => {
  console.log(`Service running on port ${PORT}`);
});
