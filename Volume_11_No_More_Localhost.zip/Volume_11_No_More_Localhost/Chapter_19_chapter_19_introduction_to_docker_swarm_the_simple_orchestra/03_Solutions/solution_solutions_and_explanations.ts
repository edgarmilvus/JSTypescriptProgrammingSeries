/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

/**
 * NOTE: This solution provides the exact shell commands and Docker configuration files
 * required to complete the exercise. As this is an infrastructure orchestration task,
 * "TypeScript" refers to the generation of necessary configuration files (Dockerfile)
 * and the precise command sequences.
 */

// 1. SERVER PREPARATION (Run on all 3 nodes)
/*
sudo apt-get update
sudo apt-get install -y docker.io
sudo systemctl enable --now docker

# Allow Swarm ports (UFW example)
sudo ufw allow 2377/tcp
sudo ufw allow 7946/tcp
sudo ufw allow 7946/udp
sudo ufw allow 4789/udp
sudo ufw reload
*/

// 2. CLUSTER INITIALIZATION
/*
# On the designated Manager Node (e.g., 192.168.1.10)
sudo docker swarm init --advertise-addr 192.168.1.10

# Copy the token output from the previous command, e.g.:
# docker swarm join --token SWMTKN-1-xxx 192.168.1.10:2377
# Run this on both Worker Nodes.
*/

// 3. SERVICE DEPLOYMENT

// File: Dockerfile
const dockerfileContent = `
FROM node:18-alpine
WORKDIR /app
COPY package*.json ./
RUN npm install
COPY . .
EXPOSE 3000
CMD ["node", "server.js"]
`;

// File: server.js (Simple Node.js Server)
const serverJsContent = `
const http = require('http');
const os = require('os');
const server = http.createServer((req, res) => {
  res.writeHead(200, { 'Content-Type': 'text/plain' });
  res.end('Hello World from container on host: ' + os.hostname() + '\\n');
});
server.listen(3000);
`;

/*
# Build and Push Image (Run on Manager)
docker build -t yourusername/hello-swarm:v1 .
docker push yourusername/hello-swarm:v1

# Deploy the Service
docker service create --name web-service \
  --replicas 3 \
  --publish 80:3000 \
  --update-parallelism 1 \
  --update-delay 10s \
  yourusername/hello-swarm:v1
*/

// 4. VERIFICATION
/*
# Check Service Status
docker service ps web-service

# Access Application (curl loop to demonstrate load balancing)
for i in {1..10}; do curl http://localhost; done
*/
