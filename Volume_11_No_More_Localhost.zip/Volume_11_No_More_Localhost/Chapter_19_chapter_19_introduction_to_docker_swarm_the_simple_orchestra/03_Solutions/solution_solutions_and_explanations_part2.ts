/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

/**
 * This solution provides the shell command sequences to manage the service lifecycle.
 */

// 1. INITIAL STATE DEPLOYMENT
/*
# Deploy the initial service with update policies defined
docker service create --name web-service \
  --replicas 3 \
  --publish 80:3000 \
  --update-parallelism 1 \
  --update-delay 10s \
  --update-failure-action rollback \
  yourusername/hello-swarm:v1
*/

// 2. UPDATE EXECUTION
/*
# Simulate a new version (v2.0) that changes the response text
# Build and push v2.0
docker build -t yourusername/hello-swarm:v2 .
docker push yourusername/hello-swarm:v2

# Trigger the update
docker service update --image yourusername/hello-swarm:v2 web-service

# Watch the update live (in a separate terminal)
docker service ps web-service
# You will see tasks transition from "Running" -> "Shutdown" -> "New" -> "Running"
*/

// 3. ROLLBACK SCENARIO
/*
# Simulate a failure (e.g., if v2.0 crashes on start, Swarm waits for the update-delay
# before proceeding to the next replica. If it detects a crash loop, it halts.)

# Manually trigger a rollback (or rely on the --update-failure-action=rollback flag)
docker service update --rollback web-service

# Verify the rollback
docker service ps web-service
# You will see the v2 tasks shutting down and v1 tasks spinning back up.
*/

// 4. AVAILABILITY VERIFICATION SCRIPT
/*
# Run this loop in a terminal. It should return "Hello World..." continuously
# even during the update/rollback.
while true; do curl -s http://localhost && sleep 1; done
*/
