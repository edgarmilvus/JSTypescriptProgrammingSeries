/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

// File: app/components/SwarmStatusCard.tsx
// This is a React Server Component (no 'use client' directive)

import { execSync } from 'child_process';

// 1. Type Safety Interfaces
interface SwarmServiceSpec {
  Mode: {
    Replicated: {
      Replicas: number;
    };
  };
}

interface SwarmUpdateStatus {
  State: 'completed' | 'updating' | 'paused' | 'rejected';
  Message: string;
}

interface SwarmInspectOutput {
  Spec: SwarmServiceSpec;
  UpdateStatus?: SwarmUpdateStatus;
}

// 2. Helper Function to Fetch Data
function getServiceData(serviceName: string): SwarmInspectOutput | null {
  try {
    // Execute shell command securely
    const output = execSync(
      `docker service inspect ${serviceName} --format=json`,
      { encoding: 'utf8' }
    );
    
    // Parse the JSON output (Array of objects, we take the first one)
    const parsed = JSON.parse(output) as SwarmInspectOutput[];
    return parsed[0];
  } catch (error) {
    console.error(`Failed to inspect service ${serviceName}:`, error);
    return null;
  }
}

// 3. UI Helper for Status Color
function getStatusColor(state: string | undefined): string {
  switch (state) {
    case 'completed':
    case 'updating':
      return 'green';
    case 'rejected':
    case 'paused':
      return 'red';
    default:
      return 'gray';
  }
}

// 4. Main Component
export default function SwarmStatusCard({ serviceName }: { serviceName: string }) {
  const data = getServiceData(serviceName);

  if (!data) {
    return (
      <div style={{ border: '1px solid #ccc', padding: '1rem', borderRadius: '8px' }}>
        <h3>Error</h3>
        <p>Could not fetch status for {serviceName}. Is the Docker CLI available?</p>
      </div>
    );
  }

  const replicaCount = data.Spec.Mode.Replicated.Replicas;
  const statusState = data.UpdateStatus?.State || 'completed';
  const statusColor = getStatusColor(statusState);

  return (
    <div style={{ border: '1px solid #ccc', padding: '1rem', borderRadius: '8px', maxWidth: '300px' }}>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <h3 style={{ margin: 0 }}>{serviceName}</h3>
        {/* Visual Indicator */}
        <span 
          style={{ 
            width: '12px', 
            height: '12px', 
            borderRadius: '50%', 
            backgroundColor: statusColor,
            display: 'inline-block'
          }} 
          title={`State: ${statusState}`}
        ></span>
      </div>
      <div style={{ marginTop: '0.5rem' }}>
        <p style={{ margin: 0 }}>Replicas: <strong>{replicaCount}</strong></p>
        <p style={{ margin: 0, fontSize: '0.8rem', color: '#666' }}>Status: {statusState}</p>
      </div>
    </div>
  );
}
