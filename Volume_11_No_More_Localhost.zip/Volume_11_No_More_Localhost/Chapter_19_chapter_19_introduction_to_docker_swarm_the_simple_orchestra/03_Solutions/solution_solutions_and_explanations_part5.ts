/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

/**
 * 1. Docker Compose YAML Definition
 * This file defines the stack deployment.
 */

const dockerComposeYaml = `
version: '3.8'

services:
  # Frontend Service
  frontend:
    image: nginx:alpine  # Using nginx as a placeholder for React
    ports:
      - "80:80"
    networks:
      - app-net
    deploy:
      replicas: 2
      placement:
        constraints:
          - node.role == worker

  # API Service
  api:
    image: node:18-alpine
    command: ["node", "server.js"] # Assume server.js is in the image
    networks:
      - app-net
      - backend-net
    deploy:
      replicas: 3
      update_config:
        parallelism: 1
        delay: 5s

  # Redis Database
  redis:
    image: redis:alpine
    networks:
      - backend-net
    deploy:
      replicas: 1
      placement:
        constraints:
          - node.role == manager

networks:
  app-net:
    driver: overlay
    attachable: true
  backend-net:
    driver: overlay
    internal: true  # Isolated from external access
`;

/**
 * 2. Graphviz DOT Diagram
 * This string represents the visual structure of the architecture.
 */
const graphvizDot = `
digraph SwarmArchitecture {
    rankdir=TB;
    node [shape=box, style=filled, fillcolor=lightblue];

    // Cluster Nodes
    subgraph cluster_nodes {
        label = "Docker Swarm Cluster";
        style = dashed;
        
        Manager [label="Manager Node\\n(192.168.1.10)"];
        Worker1 [label="Worker Node 1\\n(192.168.1.11)"];
        Worker2 [label="Worker Node 2\\n(192.168.1.12)"];
    }

    // Networks
    Ingress [shape=cylinder, fillcolor=orange, label="Ingress Network\\n(External Traffic)"];
    AppNet [shape=cylinder, fillcolor=lightgreen, label="Overlay: app-net"];
    BackendNet [shape=cylinder, fillcolor=lightcoral, label="Overlay: backend-net (Internal)"];

    // Services / Tasks
    FrontendTask [label="Frontend (Nginx)\\nPort 80"];
    APITask1 [label="API Task 1"];
    APITask2 [label="API Task 2"];
    APITask3 [label="API Task 3"];
    RedisTask [label="Redis Master"];

    // Relationships & Traffic Flow
    
    // External Traffic
    External [shape=ellipse, label="User", fillcolor=white];
    External -> Ingress [label="HTTP:80"];

    // Ingress to Frontend
    Ingress -> FrontendTask [label="Routing Mesh"];

    // Frontend to API (via app-net)
    FrontendTask -> AppNet [arrowhead=none];
    AppNet -> APITask1 [arrowhead=none];
    AppNet -> APITask2 [arrowhead=none];
    AppNet -> APITask3 [arrowhead=none];

    // API to Redis (via backend-net)
    APITask1 -> BackendNet [arrowhead=none];
    APITask2 -> BackendNet [arrowhead=none];
    APITask3 -> BackendNet [arrowhead=none];
    BackendNet -> RedisTask [arrowhead=none];

    // Placement Constraints (Visual grouping)
    { rank = same; Worker1; FrontendTask; APITask1; }
    { rank = same; Worker2; APITask2; APITask3; }
    { rank = same; Manager; RedisTask; }

    // Node connections to Networks (Simplified for clarity)
    Worker1 -> AppNet [style=invis];
    Worker2 -> AppNet [style=invis];
}
`;

// Export or log these configurations
// console.log(dockerComposeYaml);
// console.log(graphvizDot);
