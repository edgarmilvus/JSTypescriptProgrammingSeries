/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState, useRef } from 'react';

// Define the Message interface as requested
interface Message {
  id: string;
  text: string;
  isOptimistic: boolean;
  isPending: boolean;
}

// Helper to generate unique IDs
const generateId = () => Math.random().toString(36).substr(2, 9);

// Helper to simulate network delay (1-3 seconds)
const simulateInference = (text: string): Promise<string> => {
  return new Promise((resolve) => {
    const delay = Math.floor(Math.random() * 2000) + 1000;
    setTimeout(() => {
      resolve(`AI Analysis for "${text}": Processed successfully.`);
    }, delay);
  });
};

export const OptimisticChat: React.FC = () => {
  const [inputValue, setInputValue] = useState('');
  const [messages, setMessages] = useState<Message[]>([]);
  
  // We use a Ref to track the ID of the last sent message.
  // This allows us to identify "orphaned" responses (responses that belong to a message
  // that has been visually replaced by a newer one).
  const lastMessageIdRef = useRef<string | null>(null);

  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputValue.trim()) return;

    const userMessageId = generateId();
    
    // 1. Update UI State Immediately (Optimistic)
    const newMessage: Message = {
      id: userMessageId,
      text: inputValue,
      isOptimistic: false, // User messages are not "optimistic" placeholders
      isPending: false
    };

    const pendingPlaceholder: Message = {
      id: generateId(), // Temporary ID for the AI placeholder
      text: 'Thinking...',
      isOptimistic: true,
      isPending: true
    };

    setMessages((prev) => [...prev, newMessage, pendingPlaceholder]);
    
    // Update the ref to track the placeholder we just added
    const currentPlaceholderId = pendingPlaceholder.id;
    lastMessageIdRef.current = currentPlaceholderId;

    setInputValue(''); // Clear input

    // 2. Trigger Background Process
    const actualResponse = await simulateInference(inputValue);

    // 3. Reconciliation Logic
    setMessages((prevMessages) => {
      // Check if the placeholder is still the last message in the list.
      // If the user sent a new message while we were waiting, the placeholder
      // would have been pushed back or removed (depending on design), but strictly 
      // speaking, we check if the ID matches the current last message ID.
      const isLastMessage = prevMessages[prevMessages.length - 1].id === currentPlaceholderId;

      if (isLastMessage) {
        // Case A: No new messages. Replace the placeholder with the real response.
        return prevMessages.map((msg) => 
          msg.id === currentPlaceholderId 
            ? { ...msg, text: actualResponse, isPending: false, isOptimistic: false } 
            : msg
        );
      } else {
        // Case B: New messages exist. The placeholder is "orphaned".
        // Append the confirmed response to the end of the list.
        // We keep the placeholder in the list (it might show "Thinking..." still)
        // or we can remove it. Let's append the real response as a new entry.
        return [
          ...prevMessages,
          {
            id: generateId(),
            text: actualResponse,
            isOptimistic: false,
            isPending: false
          }
        ];
      }
    });
  };

  return (
    <div className="chat-container" style={{ border: '1px solid #ccc', padding: '10px', maxWidth: '500px', margin: 'auto' }}>
      <div style={{ height: '300px', overflowY: 'auto', marginBottom: '10px', border: '1px solid #eee', padding: '5px' }}>
        {messages.map((msg) => (
          <div key={msg.id} style={{ margin: '5px 0', color: msg.isPending ? '#999' : '#000' }}>
            <strong>{msg.isOptimistic ? 'AI: ' : 'You: '}</strong>
            <span>{msg.text}</span>
            {msg.isPending && <span style={{ marginLeft: '5px', color: 'blue' }}>●</span>}
          </div>
        ))}
      </div>
      <form onSubmit={handleSend} style={{ display: 'flex', gap: '5px' }}>
        <input
          type="text"
          value={inputValue}
          onChange={(e) => setInputValue(e.target.value)}
          placeholder="Type a message..."
          style={{ flex: 1 }}
        />
        <button type="submit">Send</button>
      </form>
    </div>
  );
};
