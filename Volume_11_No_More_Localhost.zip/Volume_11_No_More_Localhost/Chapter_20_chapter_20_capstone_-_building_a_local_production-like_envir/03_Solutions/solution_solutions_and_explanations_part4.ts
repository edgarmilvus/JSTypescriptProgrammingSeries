/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

# Exercise 4: Multi-Stage Dockerfile

# Stage 1: Builder
FROM node:18-alpine AS builder
WORKDIR /app

# Copy dependency manifests first to leverage Docker layer caching
COPY package*.json ./

# Install ALL dependencies (including devDependencies like typescript, ts-node)
RUN npm ci

# Copy the TypeScript source code
COPY . .

# Run the build script (assuming "build" runs tsc or similar)
RUN npm run build

# ---------------------------------------------------------

# Stage 2: Runner
FROM node:18-alpine AS runner
WORKDIR /app

# Copy dependency manifests
COPY package*.json ./

# Install ONLY production dependencies. 
# This removes devDependencies, significantly reducing image size.
# Note: We use "npm ci --only=production" but we need the package-lock.json
# for it to work strictly.
RUN npm ci --only=production && npm cache clean --force

# Copy the compiled JavaScript from the builder stage
# Assuming the build output is in a 'dist' folder
COPY --from=builder /app/dist ./dist

# Set the command to run the compiled code
CMD ["node", "dist/server.js"]
