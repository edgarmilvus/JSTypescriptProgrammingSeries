/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState, useEffect, useReducer } from 'react';

// Define the shape of the API response
interface HealthStatus {
  db: 'healthy' | 'unhealthy';
  backend: 'healthy' | 'unhealthy';
  latency: number;
}

// Define State shape for the reducer
interface DashboardState {
  health: { db: string; backend: string };
  latencyHistory: number[];
}

// Define Action types
type Action = 
  | { type: 'UPDATE_HEALTH'; payload: { db: string; backend: string } }
  | { type: 'UPDATE_LATENCY'; payload: number };

// Reducer to manage state updates
const dashboardReducer = (state: DashboardState, action: Action): DashboardState => {
  switch (action.type) {
    case 'UPDATE_HEALTH':
      return { ...state, health: action.payload };
    case 'UPDATE_LATENCY':
      // Keep only the last 10 latency values
      const newHistory = [...state.latencyHistory, action.payload].slice(-10);
      return { ...state, latencyHistory: newHistory };
    default:
      return state;
  }
};

export const PerformanceDashboard: React.FC = () => {
  // Use useReducer for complex state logic
  const [state, dispatch] = useReducer(dashboardReducer, {
    health: { db: 'unhealthy', backend: 'unhealthy' },
    latencyHistory: []
  });

  // Helper to fetch data (simulated here, but would be fetch('/api/health') in real app)
  const fetchHealthData = async () => {
    try {
      // Simulating API call
      // const response = await fetch('/api/health');
      // const data: HealthStatus = await response.json();
      
      // Mock Data for demonstration
      const data: HealthStatus = {
        db: Math.random() > 0.1 ? 'healthy' : 'unhealthy',
        backend: 'healthy',
        latency: Math.floor(Math.random() * 200) + 20
      };

      dispatch({ type: 'UPDATE_HEALTH', payload: { db: data.db, backend: data.backend } });
      dispatch({ type: 'UPDATE_LATENCY', payload: data.latency });
    } catch (error) {
      console.error("Failed to fetch health data", error);
    }
  };

  useEffect(() => {
    // Poll every 2 seconds
    const interval = setInterval(fetchHealthData, 2000);
    
    // Cleanup interval on unmount
    return () => clearInterval(interval);
  }, []);

  // Helper to render the graph nodes
  const renderNode = (label: string, status: string) => {
    const color = status === 'healthy' ? '#4caf50' : '#f44336';
    return (
      <div style={{
        border: `2px solid ${color}`,
        padding: '10px',
        margin: '5px',
        borderRadius: '5px',
        backgroundColor: '#f9f9f9',
        textAlign: 'center',
        fontWeight: 'bold'
      }}>
        {label} <br />
        <small style={{ color }}>{status.toUpperCase()}</small>
      </div>
    );
  };

  // Helper to render the latency chart (Simple SVG Line)
  const renderChart = () => {
    const width = 400;
    const height = 100;
    const maxLatency = Math.max(...state.latencyHistory, 100); // Scale based on data
    const points = state.latencyHistory
      .map((val, index) => {
        const x = (index / (state.latencyHistory.length - 1 || 1)) * width;
        const y = height - (val / maxLatency) * height;
        return `${x},${y}`;
      })
      .join(' ');

    return (
      <svg width={width} height={height} style={{ border: '1px solid #ccc', background: '#fff' }}>
        <polyline
          points={points}
          fill="none"
          stroke="blue"
          strokeWidth="2"
        />
        {/* Axis lines */}
        <line x1={0} y1={height} x2={width} y2={height} stroke="black" />
        <line x1={0} y1={0} x2={0} y2={height} stroke="black" />
      </svg>
    );
  };

  return (
    <div className="dashboard" style={{ padding: '20px', fontFamily: 'sans-serif' }}>
      <h2>Perceived Performance Monitor</h2>
      
      {/* Dependency Graph Visualization */}
      <div className="graph-container" style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', gap: '20px', margin: '20px 0' }}>
        {/* User Node (Always Healthy visually for context) */}
        <div style={{ border: '1px solid #333', padding: '10px', borderRadius: '5px' }}>User</div>
        <div style={{ fontSize: '20px' }}>→</div>
        
        {/* Backend Node */}
        {renderNode('Backend', state.health.backend)}
        <div style={{ fontSize: '20px' }}>→</div>
        
        {/* Database Node */}
        {renderNode('Database', state.health.db)}
      </div>

      {/* Latency Chart Visualization */}
      <div className="chart-container" style={{ marginTop: '30px' }}>
        <h3>Request Latency (Last 10 requests)</h3>
        {state.latencyHistory.length > 0 ? renderChart() : <p>Waiting for data...</p>}
        <div>Current History: {state.latencyHistory.join(', ')} ms</div>
      </div>
    </div>
  );
};
