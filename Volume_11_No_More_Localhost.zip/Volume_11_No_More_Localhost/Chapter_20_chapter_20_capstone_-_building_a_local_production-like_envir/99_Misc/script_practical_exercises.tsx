/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises.tsx
// Description: Practical Exercises
// ==========================================

// Exercise 1: OptimisticChat Component Structure
// Implement the following component interface in TypeScript.

import React, { useState } from 'react';

interface Message {
  id: string;
  text: string;
  isOptimistic: boolean;
  isPending: boolean;
}

export const OptimisticChat: React.FC = () => {
  // TODO: Implement state for messages, input value, and pending inference promises.
  // TODO: Implement handleSend to update UI immediately and trigger background simulation.
  // TODO: Implement reconciliation logic when background task resolves.
  
  return (
    <div className="chat-container">
      {/* Message List Rendering */}
      {/* Input Form */}
    </div>
  );
};
