/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part3.ts
// Description: Practical Exercises
// ==========================================

# Exercise 3: nginx.conf snippet
# Complete the configuration for SSL termination and caching.

events {
    worker_connections 1024;
}

http {
    upstream backend {
        # TODO: Define the backend service address
    }

    server {
        listen 80;
        # TODO: Redirect HTTP to HTTPS
    }

    server {
        listen 443 ssl;
        
        # TODO: Point to the self-signed certificate and key paths
        
        location /api/ {
            # TODO: Proxy pass to the backend upstream
        }

        location / {
            root /usr/share/nginx/html;
            index index.html index.htm;
            
            # TODO: Add cache-control headers for static assets
            # (JS, CSS, Images) but NOT for index.html
        }
    }
}
