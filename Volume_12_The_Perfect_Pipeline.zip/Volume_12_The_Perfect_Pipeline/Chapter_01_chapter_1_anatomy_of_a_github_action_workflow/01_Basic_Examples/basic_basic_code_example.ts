/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * @fileoverview A simulation of a GitHub Actions Workflow runner in TypeScript.
 * This script mimics the execution flow of a CI/CD pipeline for a SaaS web app.
 * 
 * Context: SaaS Web App
 * Scenario: A developer pushes code to the 'main' branch. 
 * The workflow triggers, checks out the code, installs dependencies, and runs tests.
 */

// --- Type Definitions ---

/**
 * Represents the event that triggered the workflow.
 * In GitHub Actions, this is defined in the `on:` block.
 */
type WorkflowEvent = 'push' | 'pull_request' | 'schedule';

/**
 * Represents the operating system the job runs on.
 * In GitHub Actions, this is defined in `runs-on:`.
 */
type RunnerOS = 'ubuntu-latest' | 'windows-latest' | 'macos-latest';

/**
 * Represents a single step in a job.
 * In GitHub Actions, this is defined under `steps:`.
 */
interface WorkflowStep {
  name: string;
  run: string; // The shell command to execute
  uses?: string; // Reference to a pre-built action (e.g., actions/checkout@v4)
}

/**
 * Represents a Job within the workflow.
 * In GitHub Actions, this is defined under `jobs:`.
 */
interface WorkflowJob {
  name: string;
  runsOn: RunnerOS;
  steps: WorkflowStep[];
}

// --- Workflow Simulation Logic ---

/**
 * Simulates the GitHub Actions Runner environment.
 * It parses the event, selects the appropriate job, and executes steps sequentially.
 */
class WorkflowRunner {
  private eventName: WorkflowEvent;
  private branch: string;

  constructor(event: WorkflowEvent, branch: string) {
    this.eventName = event;
    this.branch = branch;
    console.log(`🚀 [Runner] Initializing for event: '${event}' on branch: '${branch}'`);
  }

  /**
   * Checks if the workflow should trigger based on the 'on' configuration.
   * This mimics the `on: push: branches: [ main ]` logic.
   */
  private shouldTrigger(): boolean {
    if (this.eventName === 'push' && this.branch === 'main') {
      return true;
    }
    console.log(`🚫 [Trigger Check] Workflow skipped. Event '${this.eventName}' on branch '${this.branch}' does not match criteria.`);
    return false;
  }

  /**
   * Executes a specific job defined in the workflow.
   * @param job - The job configuration object.
   */
  public async executeJob(job: WorkflowJob): Promise<void> {
    if (!this.shouldTrigger()) return;

    console.log(`\n📋 [Job] Starting Job: ${job.name}`);
    console.log(`💻 [Runner] Using OS: ${job.runsOn}`);

    // Iterate through steps (Sequential Execution)
    for (let i = 0; i < job.steps.length; i++) {
      const step = job.steps[i];
      console.log(`\n⚙️  [Step ${i + 1}] Running: ${step.name}`);
      
      try {
        // Simulate the execution of the step command
        await this.runStep(step);
        console.log(`✅ [Step ${i + 1}] Success`);
      } catch (error) {
        console.error(`❌ [Step ${i + 1}] Failed: ${error}`);
        // In a real CI/CD pipeline, a failed step usually stops the job immediately.
        throw new Error(`Job failed at step ${i + 1}`);
      }
    }

    console.log(`\n🎉 [Job] Job '${job.name}' completed successfully.`);
  }

  /**
   * Simulates the execution of a shell command or action.
   * In a real runner, this would spawn a shell process.
   */
  private async runStep(step: WorkflowStep): Promise<void> {
    // Simulate processing time
    await new Promise(resolve => setTimeout(resolve, 500));

    if (step.uses) {
      console.log(`   -> Downloading/Using Action: ${step.uses}`);
      // Simulate 'actions/checkout' behavior
      if (step.uses.includes('checkout')) {
        console.log(`   -> Repository code checked out to /home/runner/work/project`);
      }
      return;
    }

    if (step.run) {
      console.log(`   -> Executing command: "${step.run}"`);
      // Simulate specific command logic
      if (step.run.includes('npm install')) {
        console.log(`   -> Installing dependencies... (node_modules created)`);
      } else if (step.run.includes('npm test')) {
        console.log(`   -> Running test suite... (Tests passed)`);
      }
      return;
    }
  }
}

// --- Configuration: The "Workflow File" ---

/**
 * Defines the workflow structure equivalent to a .github/workflows/main.yml file.
 */
const basicWorkflowConfig: WorkflowJob = {
  name: 'Build and Test',
  runsOn: 'ubuntu-latest',
  steps: [
    {
      name: 'Checkout Code',
      uses: 'actions/checkout@v4'
    },
    {
      name: 'Setup Node.js',
      uses: 'actions/setup-node@v4'
    },
    {
      name: 'Install Dependencies',
      run: 'npm install'
    },
    {
      name: 'Run Unit Tests',
      run: 'npm test'
    }
  ]
};

// --- Execution Entry Point ---

/**
 * Main function to simulate the workflow trigger.
 */
async function main() {
  console.log("--- GitHub Actions Workflow Simulation ---");
  
  // Scenario 1: Push to main branch (Should Trigger)
  const runnerOnMain = new WorkflowRunner('push', 'main');
  try {
    await runnerOnMain.executeJob(basicWorkflowConfig);
  } catch (error) {
    console.error("Workflow execution failed.");
  }

  console.log("\n-------------------------------------------\n");

  // Scenario 2: Push to feature branch (Should Skip)
  const runnerOnFeature = new WorkflowRunner('push', 'feature/login-page');
  await runnerOnFeature.executeJob(basicWorkflowConfig);
}

// Run the simulation
if (require.main === module) {
  main();
}
