/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// app/api/agent-pipeline/route.ts
/**
 * @fileoverview A Next.js Server Action implementation demonstrating the 
 * 'streamable-ui' architectural pattern. This mimics a CI/CD pipeline 
 * by dynamically streaming interactive React components based on 
 * hierarchical agent execution.
 * 
 * Target Framework: Next.js 14+ (App Router)
 * Dependencies: react, ai (Vercel AI SDK), lucide-react (icons)
 */

import { createStreamableUI, createStreamableValue } from 'ai/rsc';
import { OpenAIStream, StreamingTextResponse } from 'ai';
import { BotMessage, UserMessage, SystemStatus, ActionButton } from '@/components/agent-ui';
import { ShieldCheck, Terminal, Cloud, AlertCircle } from 'lucide-react';
import { ReactNode } from 'react';

// ==========================================
// 1. WORKFLOW DEFINITION (The "Workflow File")
// ==========================================

/**
 * Defines the structure of our agentic pipeline.
 * Mirrors the `jobs` block in a GitHub Actions YAML file.
 */
type AgentJob = {
  id: string;
  name: string;
  executor: 'security' | 'build' | 'deploy';
  description: string;
};

const PIPELINE_JOBS: AgentJob[] = [
  { id: 'job-1', name: 'Security Scan', executor: 'security', description: 'Running vulnerability analysis...' },
  { id: 'job-2', name: 'Build Artifacts', executor: 'build', description: 'Compiling TypeScript and bundling assets...' },
  { id: 'job-3', name: 'Deploy to Staging', executor: 'deploy', description: 'Provisioning resources on Vercel Edge...' },
];

// ==========================================
// 2. THE SERVER ACTION (The "Runner")
// ==========================================

/**
 * The main entry point. Acts as the `runner` in GitHub Actions terminology.
 * It manages the state of the pipeline and streams UI updates to the client.
 * 
 * @param input - The user prompt triggering the pipeline.
 * @returns An object containing the streamed UI component.
 */
export async function runAgentPipeline(input: string) {
  // Create a streamable UI container. This is analogous to a GitHub Actions 
  // job container that holds the logs and status.
  const uiStream = createStreamableUI(
    <div className="flex flex-col gap-4 p-4 bg-slate-900 rounded-lg border border-slate-800">
      <h2 className="text-lg font-bold text-slate-100">Initializing Pipeline...</h2>
    </div>
  );

  // Create a streamable text value for raw logs (like `run: echo "log"`).
  const textStream = createStreamableValue('');

  // ==========================================
  // 3. HIERARCHICAL AGENTIC WORKFLOW (The "Steps")
  // ==========================================

  /**
   * (async) executeJob
   * Represents a single `step` in the workflow.
   * 
   * @param job - The configuration for the current job.
   * @param index - The order of execution.
   */
  const executeJob = async (job: AgentJob, index: number) => {
    // 1. Update Status: Job Started
    uiStream.update(
      <div className="flex flex-col gap-2 animate-pulse">
        <SystemStatus 
          icon={ShieldCheck} 
          label={`Job ${index + 1}: ${job.name}`} 
          status="running" 
          description={job.description}
        />
      </div>
    );

    // 2. Simulate "Runner" Execution (Network latency, processing)
    await new Promise(resolve => setTimeout(resolve, 1500));

    // 3. Determine Outcome (Mocking LLM Logic or Exit Codes)
    const isSuccess = job.id !== 'job-3'; // Force a failure on the last job for demonstration

    if (isSuccess) {
      // 4a. Success: Stream a specific interactive component
      uiStream.append(
        <div className="ml-6 border-l-2 border-green-500 pl-4 py-2">
          <SystemStatus 
            icon={ShieldCheck} 
            label="Passed" 
            status="success" 
            description="No vulnerabilities found."
          />
          {/* Interactive Button Component streamed dynamically */}
          <ActionButton label="View Logs" onClick={() => console.log(`Logs for ${job.id}`)} />
        </div>
      );
    } else {
      // 4b. Failure: Stream an error component
      uiStream.append(
        <div className="ml-6 border-l-2 border-red-500 pl-4 py-2">
          <SystemStatus 
            icon={AlertCircle} 
            label="Failed" 
            status="error" 
            description="Deployment token expired."
          />
          <div className="mt-2 text-xs text-red-300 font-mono">
            Error: EAUTH_401_INVALID_TOKEN
          </div>
        </div>
      );
      // Stop the pipeline (like `if: failure()` in GitHub Actions)
      throw new Error("Pipeline Halted: Critical failure in deployment step.");
    }
  };

  // ==========================================
  // 4. ORCHESTRATION LOGIC (The "Workflow Execution")
  // ==========================================

  (async () => {
    try {
      // Iterate through defined jobs
      for (const job of PIPELINE_JOBS) {
        await executeJob(job, PIPELINE_JOBS.indexOf(job));
      }

      // Finalize the stream
      uiStream.done(
        <div className="mt-4 p-3 bg-green-900/20 border border-green-500/30 rounded text-green-400 text-sm font-medium">
          ✅ Pipeline Completed Successfully
        </div>
      );
    } catch (error) {
      // Handle pipeline failure
      if (error instanceof Error) {
        uiStream.append(
          <div className="mt-4 p-3 bg-red-900/20 border border-red-500/30 rounded text-red-400 text-sm font-medium">
            ❌ {error.message}
          </div>
        );
        uiStream.done();
      }
    }
  })();

  // Return the streamable UI to the client immediately
  return { 
    ui: uiStream.value, 
    status: textStream.value 
  };
}
