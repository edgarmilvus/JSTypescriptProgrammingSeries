/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

# .github/workflows/conditional-ci.yml
name: Conditional CI

on:
  push:
    branches: [ "main", "develop" ]

jobs:
  detect-changes:
    runs-on: ubuntu-latest
    # Set permissions to read contents for git diff
    permissions:
      contents: read
    # Map outputs to pass to downstream jobs
    outputs:
      docs_changed: ${{ steps.filter.outputs.docs }}
      app_changed: ${{ steps.filter.outputs.app }}
    steps:
      - uses: actions/checkout@v4
      
      # Uses a popular action to detect changes efficiently
      - uses: dorny/paths-filter@v2
        id: filter
        with:
          filters: |
            docs:
              - 'docs/**'
            app:
              - 'app/**'

  build-docs:
    runs-on: ubuntu-latest
    needs: detect-changes
    # Run if docs changed OR if commit message contains [full-ci]
    if: ${{ needs.detect-changes.outputs.docs_changed == 'true' || contains(github.event.head_commit.message, '[full-ci]') }}
    steps:
      - uses: actions/checkout@v4
      - name: Build Docs
        run: echo "Building documentation..."

  test-app:
    runs-on: ubuntu-latest
    needs: detect-changes
    # Run if app changed OR if commit message contains [full-ci]
    if: ${{ needs.detect-changes.outputs.app_changed == 'true' || contains(github.event.head_commit.message, '[full-ci]') }}
    steps:
      - uses: actions/checkout@v4
      - name: Test App
        run: echo "Running application tests..."
