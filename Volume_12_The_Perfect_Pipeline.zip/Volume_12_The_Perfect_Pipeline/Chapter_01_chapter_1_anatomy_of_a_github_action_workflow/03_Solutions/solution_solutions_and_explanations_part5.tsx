/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.tsx
// Description: Solutions and Explanations
// ==========================================

// WorkflowVisualizer.tsx
import React, { useState, useMemo } from 'react';
import yaml from 'js-yaml';
import ReactFlow, {
  Node,
  Edge,
  Position,
  Handle,
  ConnectionLineType,
  useNodesState,
  useEdgesState,
} from 'reactflow';
import 'reactflow/dist/style.css';

// Define types for the parsed workflow structure
interface WorkflowJob {
  'runs-on'?: string;
  needs?: string | string[];
  steps?: Array<{ name?: string }>;
  strategy?: {
    matrix?: Record<string, any>;
  };
  [key: string]: any;
}

interface WorkflowYaml {
  jobs: Record<string, WorkflowJob>;
}

const WorkflowVisualizer = ({ workflowYaml }: { workflowYaml: string }) => {
  const [selectedNode, setSelectedNode] = useState<Node | null>(null);

  // Parse the YAML string
  const parsedWorkflow = useMemo(() => {
    try {
      return yaml.load(workflowYaml) as WorkflowYaml;
    } catch (error) {
      console.error("Failed to parse YAML", error);
      return null;
    }
  }, [workflowYaml]);

  // Transform YAML data into React Flow nodes and edges
  const { nodes, edges } = useMemo(() => {
    if (!parsedWorkflow || !parsedWorkflow.jobs) return { nodes: [], edges: [] };

    const flowNodes: Node[] = [];
    const flowEdges: Edge[] = [];
    const jobNames = Object.keys(parsedWorkflow.jobs);

    jobNames.forEach((jobName, index) => {
      const job = parsedWorkflow.jobs[jobName];
      
      // Handle Matrix Strategy Visualization
      if (job.strategy?.matrix) {
        const matrixKeys = Object.keys(job.strategy.matrix);
        const matrixValues = job.strategy.matrix[matrixKeys[0]]; // Simplified: assuming 1D matrix for demo
        
        // Create a parent node for the matrix group (optional, or just spread them)
        // Here we spread them as individual nodes for clarity
        matrixValues.forEach((val: any, mIndex: number) => {
          const nodeId = `${jobName}-${val}`;
          flowNodes.push({
            id: nodeId,
            data: {
              label: `Test (Node ${val})`,
              details: job.steps?.map(s => s.name).join(', ') || 'No steps',
              runsOn: job['runs-on']
            },
            position: { x: 100 + (index * 200), y: 100 + (mIndex * 80) },
            type: 'default',
          });

          // Add edges based on needs
          if (job.needs) {
            const deps = Array.isArray(job.needs) ? job.needs : [job.needs];
            deps.forEach(dep => {
              // If dependency is also matrix, we simplify for this demo by connecting to the first instance
              // In a real app, you'd handle matrix-to-matrix dependencies carefully
              flowEdges.push({
                id: `e-${dep}-${nodeId}`,
                source: dep,
                target: nodeId,
                type: 'smoothstep',
              });
            });
          }
        });
      } else {
        // Standard Job Node
        const nodeId = jobName;
        flowNodes.push({
          id: nodeId,
          data: {
            label: jobName,
            details: job.steps?.map(s => s.name).join(', ') || 'No steps',
            runsOn: job['runs-on']
          },
          position: { x: 100 + (index * 250), y: 100 },
          type: 'default',
        });

        // Add edges
        if (job.needs) {
          const deps = Array.isArray(job.needs) ? job.needs : [job.needs];
          deps.forEach(dep => {
            flowEdges.push({
              id: `e-${dep}-${nodeId}`,
              source: dep,
              target: nodeId,
              type: 'smoothstep',
            });
          });
        }
      }
    });

    return { nodes: flowNodes, edges: flowEdges };
  }, [parsedWorkflow]);

  const [rfNodes, setRfNodes, onNodesChange] = useNodesState(nodes);
  const [rfEdges, setRfEdges, onEdgesChange] = useEdgesState(edges);

  // Update state when parsed data changes
  React.useEffect(() => {
    setRfNodes(nodes);
    setRfEdges(edges);
  }, [nodes, edges, setRfNodes, setRfEdges]);

  const onNodeClick = (event: React.MouseEvent, node: Node) => {
    setSelectedNode(node);
  };

  const CustomNodeComponent = ({ data }: any) => {
    return (
      <div style={{ border: '1px solid #777', padding: '10px', background: '#fff', borderRadius: '5px', width: '150px' }}>
        <Handle type="target" position={Position.Top} />
        <div style={{ fontWeight: 'bold', marginBottom: '5px' }}>{data.label}</div>
        <div style={{ fontSize: '0.8em', color: '#555' }}>{data.runsOn}</div>
        <Handle type="source" position={Position.Bottom} />
      </div>
    );
  };

  if (!workflowYaml) return <div>Enter YAML to visualize.</div>;

  return (
    <div style={{ height: '500px', border: '1px solid #ccc', position: 'relative' }}>
      <ReactFlow
        nodes={rfNodes}
        edges={rfEdges}
        onNodesChange={onNodesChange}
        onEdgesChange={onEdgesChange}
        onNodeClick={onNodeClick}
        fitView
        nodeTypes={{ default: CustomNodeComponent }}
        connectionLineType={ConnectionLineType.SmoothStep}
      />
      
      {/* Tooltip / Detail View */}
      {selectedNode && (
        <div style={{
          position: 'absolute',
          top: 10,
          right: 10,
          background: 'white',
          border: '1px solid #333',
          padding: '15px',
          zIndex: 1000,
          boxShadow: '0 4px 6px rgba(0,0,0,0.1)',
          maxWidth: '300px'
        }}>
          <h3>Job Details: {selectedNode.data.label}</h3>
          <p><strong>Runner:</strong> {selectedNode.data.runsOn || 'Not specified'}</p>
          <p><strong>Steps:</strong></p>
          <ul>
            {selectedNode.data.details.split(', ').map((step: string, i: number) => (
              <li key={i}>{step}</li>
            ))}
          </ul>
          <button onClick={() => setSelectedNode(null)}>Close</button>
        </div>
      )}
    </div>
  );
};

export default WorkflowVisualizer;
