/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// pages/api/review-code.ts
// Next.js API Route for the Intelligent Code Review Pipeline

import { NextApiRequest, NextApiResponse } from 'next';
import { StateGraph, Annotation, StateSendMessage } from '@langchain/langgraph';
import { ChatOpenAI } from '@langchain/openai';

/**
 * ============================================================================
 * 1. STATE DEFINITION (The Shared Data Structure)
 * ============================================================================
 * Defines the "mutable, shared Graph State" mentioned in the definitions.
 * This acts as the context carrier throughout the pipeline execution.
 */
const GraphState = Annotation.Root({
  // The raw code submitted by the user
  code: Annotation<string>,
  
  // The current review status
  status: Annotation<'pending' | 'analyzing' | 'needs_revision' | 'approved'>,
  
  // Accumulated review feedback
  feedback: Annotation<string[]>({
    reducer: (curr, update) => [...curr, ...update],
    default: () => [],
  }),

  // Iteration counter to prevent infinite loops
  iteration: Annotation<number>({
    reducer: (curr, update) => curr + update,
    default: () => 0,
  }),
});

/**
 * ============================================================================
 * 2. TOOL DEFINITION (Simulated Tool Use)
 * ============================================================================
 * In a real scenario, this would call a linter or a security scanner.
 * For this demo, we simulate a "Static Analysis Tool" that returns issues.
 */
function runStaticAnalysisTool(code: string): { issues: string[]; passed: boolean } {
  // Simulated logic: Check for console.log statements
  const hasLogs = code.includes('console.log');
  const issues = hasLogs ? ['Found console.log statement (consider removing for prod)'] : [];
  return { issues, passed: !hasLogs };
}

/**
 * ============================================================================
 * 3. AGENT NODES (The "Steps")
 * ============================================================================
 * Each function represents a discrete step in the CI/CD pipeline.
 * In GitHub Actions, these would be distinct `- run:` commands.
 */

/**
 * Step A: Initial Analysis
 * Uses an LLM to perform a high-level code review.
 */
const analyzeNode = async (state: typeof GraphState.State) => {
  console.log(`[Step 1] Analyzing code... Iteration: ${state.iteration}`);
  
  const model = new ChatOpenAI({ model: 'gpt-4-turbo-preview', temperature: 0 });
  
  // Prompt engineering acts as the "Job Configuration"
  const prompt = `
    You are a senior code reviewer. Analyze the following code for logic errors 
    and best practices. Be concise.
    
    Code:
    ${state.code}
  `;

  const result = await model.invoke(prompt);
  
  return {
    feedback: [`LLM Analysis: ${result.content}`],
    status: 'analyzing' as const,
    iteration: 0, // No iteration change here, just analysis
  };
};

/**
 * Step B: Tool Use (Reflection Trigger)
 * Runs the static analysis tool and decides if the graph should cycle.
 */
const toolUseNode = async (state: typeof GraphState.State) => {
  console.log('[Step 2] Running Static Analysis Tool...');
  
  // Execute the external tool
  const toolResult = runStaticAnalysisTool(state.code);
  
  const newFeedback = toolResult.passed 
    ? ['Tool Check: Passed.'] 
    : [`Tool Check: Failed. Issues: ${toolResult.issues.join(', ')}`];

  return {
    feedback: newFeedback,
    status: toolResult.passed ? 'approved' : 'needs_revision',
    iteration: 1, // Increment iteration count
  };
};

/**
 * Step C: Finalization
 * Aggregates all feedback and concludes the job.
 */
const finalizeNode = async (state: typeof GraphState.State) => {
  console.log('[Step 3] Finalizing review...');
  return {
    status: 'approved' as const,
    feedback: ['Review Complete. No further iterations required.'],
    iteration: 0,
  };
};

/**
 * ============================================================================
 * 4. EDGES & CYCLICAL LOGIC (The Control Flow)
 * ============================================================================
 * Defines transitions between steps based on state changes.
 */

/**
 * Conditional Edge: Should we iterate?
 * If the tool detected issues ('needs_revision'), we loop back to the 
 * analyzeNode. This implements the "Cyclical Graph Structure".
 */
const shouldIterate = (state: typeof GraphState.State) => {
  if (state.status === 'needs_revision' && state.iteration < 3) {
    return 'analyze'; // Route back to analysis node
  }
  return 'finalize'; // Route to finalization
};

/**
 * ============================================================================
 * 5. WORKFLOW COMPILATION (The Pipeline Assembly)
 * ============================================================================
 * Assembles the graph, similar to how a GitHub Actions YAML file compiles jobs.
 */
const compileWorkflow = () => {
  const workflow = new StateGraph(GraphState)
    // Define Nodes (Steps)
    .addNode('analyze', analyzeNode)
    .addNode('tool_check', toolUseNode)
    .addNode('finalize', finalizeNode)
    
    // Define Entry Point
    .addEdge('__start__', 'analyze')
    
    // Define Sequential Flow (Analysis -> Tool Check)
    .addEdge('analyze', 'tool_check')
    
    // Define Conditional Flow (Cyclical Logic)
    .addConditionalEdges('tool_check', shouldIterate, {
      analyze: 'analyze',
      finalize: 'finalize',
    });

  return workflow.compile();
};

/**
 * ============================================================================
 * 6. NEXT.JS API HANDLER (The Trigger)
 * ============================================================================
 * This function acts as the "Trigger" defined in Chapter 2.
 * It accepts the HTTP request and initiates the workflow execution.
 */
export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  // TRIGGER: Check for POST method
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  const { code } = req.body;

  if (!code) {
    return res.status(400).json({ error: 'Code snippet is required' });
  }

  try {
    // Initialize the compiled workflow
    const app = compileWorkflow();

    // Execute the graph (The "Job")
    // Initial state is injected here
    const finalState = await app.invoke({
      code: code,
      status: 'pending',
      feedback: [],
      iteration: 0,
    });

    // Return the aggregated results
    res.status(200).json({
      success: true,
      status: finalState.status,
      iterations: finalState.iteration,
      feedbackLog: finalState.feedback,
    });

  } catch (error) {
    console.error('Workflow execution failed:', error);
    res.status(500).json({ error: 'Internal pipeline error' });
  }
}
