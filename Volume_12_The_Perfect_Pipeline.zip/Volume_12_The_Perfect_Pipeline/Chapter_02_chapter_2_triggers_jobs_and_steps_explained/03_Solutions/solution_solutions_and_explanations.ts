/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// Linear Graph: Build and Test Pipeline
digraph LinearWorkflow {
    rankdir=LR;
    node [shape=box, style=rounded];

    Trigger [label="push to main", shape=ellipse, style=filled, fillcolor="#e1f5fe"];
    Lint [label="Job: lint", style=filled, fillcolor="#bbdefb"];
    Test [label="Job: test", style=filled, fillcolor="#bbdefb"];
    Build [label="Job: build", style=filled, fillcolor="#bbdefb"];

    Trigger -> Lint;
    Lint -> Test;
    Test -> Build;
}

// Conditional Graph: Deploy to Staging Pipeline
digraph ConditionalWorkflow {
    rankdir=LR;
    node [shape=box, style=rounded];

    Trigger [label="workflow_dispatch", shape=ellipse, style=filled, fillcolor="#e1f5fe"];
    BuildArtifact [label="Job: build-artifact", style=filled, fillcolor="#bbdefb"];
    DeployStaging [label="Job: deploy-staging\n(Environment: staging)", style=filled, fillcolor="#fff9c4", color="#fbc02d", penwidth=2];
    SmokeTests [label="Job: run-smoke-tests", style=filled, fillcolor="#bbdefb"];

    Trigger -> BuildArtifact;
    BuildArtifact -> DeployStaging [label="needs"];
    DeployStaging -> SmokeTests [label="on success"];
}
