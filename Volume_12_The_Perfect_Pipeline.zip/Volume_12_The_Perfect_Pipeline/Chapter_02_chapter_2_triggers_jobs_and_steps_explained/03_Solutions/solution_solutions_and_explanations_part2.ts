/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

// Exercise 2: LangGraph State and Node Definitions

// 1. Define the State interface
interface WorkflowState {
    iterationCount: number;
    hasErrors: boolean;
    logs: string[];
}

// 2. Define the node functions

// Simulates checking code. Randomly sets hasErrors to true (70% chance) for first 2 iterations.
async function staticAnalysis(state: WorkflowState): Promise<WorkflowState> {
    const newState = { ...state };
    newState.logs.push(`[Iteration ${state.iterationCount}] Running static analysis...`);

    // Logic: 70% chance of error, but only if we haven't exceeded iteration limit
    if (state.iterationCount < 3 && Math.random() < 0.7) {
        newState.hasErrors = true;
        newState.logs.push("  -> Errors found.");
    } else {
        newState.hasErrors = false;
        newState.logs.push("  -> Clean.");
    }
    return newState;
}

// Simulates applying fixes. Resets hasErrors and increments iteration count.
async function fixAndRetry(state: WorkflowState): Promise<WorkflowState> {
    const newState = { ...state };
    newState.iterationCount += 1;
    newState.hasErrors = false; // Fix applied
    newState.logs.push(`[Iteration ${state.iterationCount}] Applying fixes and retrying...`);
    return newState;
}

// The terminal node. Only runs if no errors and iteration count is valid.
async function merge(state: WorkflowState): Promise<WorkflowState> {
    const newState = { ...state };
    newState.logs.push("Merging code into main branch.");
    return newState;
}

// 3. Define edges (Control Flow Logic)
// This logic is typically handled by the graph compiler (StateGraph), but here is the logic:
// Start -> staticAnalysis
// staticAnalysis -> fixAndRetry (if state.hasErrors === true && state.iterationCount < 3)
// staticAnalysis -> merge (if state.hasErrors === false)
// fixAndRetry -> staticAnalysis (Cycle)
