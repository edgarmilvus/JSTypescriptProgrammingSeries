/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState, useEffect } from 'react';

// 1. Define TypeScript Interfaces
interface WorkflowNode {
    id: string;
    label: string;
    status: 'queued' | 'in_progress' | 'completed' | 'failed';
}

interface WorkflowEdge {
    source: string;
    target: string;
}

// 2. React Component
const WorkflowGraph: React.FC<{ nodes: WorkflowNode[]; edges: WorkflowEdge[] }> = ({ nodes, edges }) => {
    const [currentNodes, setCurrentNodes] = useState(nodes);

    // 3. State Management Simulation
    useEffect(() => {
        // Simulate progression: queued -> in_progress -> completed
        const timer1 = setTimeout(() => {
            setCurrentNodes(prev => 
                prev.map(n => n.status === 'queued' ? { ...n, status: 'in_progress' } : n)
            );
        }, 1000);

        const timer2 = setTimeout(() => {
            setCurrentNodes(prev => 
                prev.map(n => n.status === 'in_progress' ? { ...n, status: 'completed' } : n)
            );
        }, 2000);

        return () => {
            clearTimeout(timer1);
            clearTimeout(timer2);
        };
    }, []);

    // Helper to simulate failure
    const simulateFailure = (id: string) => {
        setCurrentNodes(prev => 
            prev.map(n => n.id === id ? { ...n, status: 'failed' } : n)
        );
    };

    // Helper to get status color
    const getStatusColor = (status: string) => {
        switch (status) {
            case 'queued': return '#f0f0f0';
            case 'in_progress': return '#fff9c4';
            case 'completed': return '#d4edda';
            case 'failed': return '#f8d7da';
            default: return '#fff';
        }
    };

    // 4. Rendering Logic
    return (
        <div style={{ position: 'relative', width: '100%', height: '400px', border: '1px solid #ccc', padding: '20px' }}>
            {/* Render Edges (Simple SVG Lines) */}
            <svg style={{ position: 'absolute', top: 0, left: 0, width: '100%', height: '100%', zIndex: 1 }}>
                {edges.map((edge, idx) => {
                    const sourceNode = currentNodes.find(n => n.id === edge.source);
                    const targetNode = currentNodes.find(n => n.id === edge.target);
                    if (!sourceNode || !targetNode) return null;
                    
                    // Simple hardcoded positions for demo purposes
                    const sourceX = 50 + (currentNodes.indexOf(sourceNode) * 150);
                    const targetX = 50 + (currentNodes.indexOf(targetNode) * 150);
                    
                    return (
                        <line 
                            key={idx} 
                            x1={sourceX + 60} y1={100} 
                            x2={targetX} y2={100} 
                            stroke="#555" 
                            strokeWidth="2" 
                        />
                    );
                })}
            </svg>

            {/* Render Nodes */}
            <div style={{ display: 'flex', justifyContent: 'space-around', alignItems: 'center', height: '100%', position: 'relative', zIndex: 2 }}>
                {currentNodes.map((node) => (
                    <div 
                        key={node.id}
                        onClick={() => simulateFailure(node.id)}
                        style={{
                            padding: '10px 20px',
                            border: '1px solid #333',
                            borderRadius: '5px',
                            backgroundColor: getStatusColor(node.status),
                            cursor: 'pointer',
                            userSelect: 'none',
                            minWidth: '100px',
                            textAlign: 'center'
                        }}
                        title="Click to simulate failure"
                    >
                        <strong>{node.label}</strong>
                        <div style={{ fontSize: '0.8em', marginTop: '5px' }}>{node.status}</div>
                    </div>
                ))}
            </div>
            
            <div style={{ marginTop: '20px', fontSize: '0.9em', color: '#666' }}>
                * Click a node to simulate a failure state.
            </div>
        </div>
    );
};

export default WorkflowGraph;
