/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: theory_theoretical_foundations.ts
// Description: Theoretical Foundations
// ==========================================

// A Zod schema defines the runtime shape and constraints.
// It acts as the single source of truth.
const userInputSchema = z.object({
  email: z.string().email(),
  age: z.number().min(18),
});

// The schema infers a precise TypeScript type automatically.
type UserInput = z.infer<typeof userInputSchema>;

// In a Server Action, we validate the input before processing.
export async function createUser(input: unknown) {
  // 1. Runtime Validation (The Border Check)
  const parsed = userInputSchema.safeParse(input);
  
  if (!parsed.success) {
    throw new Error("Invalid input data");
  }

  // 2. Type Safety (The Permit)
  // 'parsed.data' is now typed as 'UserInput'
  // We can access properties with full confidence.
  const { email, age } = parsed.data;
  
  // ... database logic ...
}
