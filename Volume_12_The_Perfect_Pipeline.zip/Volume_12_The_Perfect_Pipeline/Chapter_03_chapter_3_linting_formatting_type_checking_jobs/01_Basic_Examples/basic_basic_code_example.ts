/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

// src/app/actions/userActions.ts

'use server'; // Marks this file as containing Server Actions

import { z } from 'zod';

/**
 * SCHEMA DEFINITION
 * Defines the shape and validation rules for the input data.
 * We use Zod to create a schema that matches our desired runtime structure.
 */
const updateUserSchema = z.object({
  userId: z.string().uuid('User ID must be a valid UUID'),
  email: z.string().email('Invalid email address format'),
});

/**
 * TYPE INFERENCE
 * We infer the TypeScript type directly from the Zod schema.
 * This ensures our TypeScript types and runtime validation rules are always in sync.
 * No manual interface definitions required.
 */
type UpdateUserInput = z.infer<typeof updateUserSchema>;

/**
 * SERVER ACTION
 * An asynchronous function that executes on the server.
 * It accepts raw input, validates it against the schema, and processes the result.
 *
 * @param input - The raw data coming from the client (e.g., form submission).
 * @returns A promise resolving to a result object indicating success or error.
 */
export async function updateUserEmail(input: unknown) {
  // 1. RUNTIME VALIDATION
  // We parse the incoming 'unknown' data against the Zod schema.
  // 'safeParse' is used instead of 'parse' to avoid throwing exceptions on invalid data,
  // allowing us to handle validation errors gracefully.
  const validation = updateUserSchema.safeParse(input);

  // 2. ERROR HANDLING
  // Check if the validation failed.
  if (!validation.success) {
    // Return a structured error object containing the Zod error map.
    return {
      success: false,
      error: validation.error.flatten().fieldErrors,
    };
  }

  // 3. TYPE-SAFE ACCESS
  // If validation passed, 'validation.data' is now typed strictly as 'UpdateUserInput'.
  // We can access properties without fear of undefined or incorrect types.
  const { userId, email } = validation.data;

  // 4. BUSINESS LOGIC (Simulated Database Update)
  // In a real app, you would query your database here.
  // We simulate an async database operation.
  try {
    // Simulate DB call
    await simulateDatabaseUpdate(userId, email);

    return {
      success: true,
      message: `User ${userId} updated to ${email}`,
    };
  } catch (dbError) {
    return {
      success: false,
      error: { database: ['Failed to update user in database'] },
    };
  }
}

/**
 * SIMULATED DATABASE FUNCTION
 * A mock function to represent database interaction logic.
 */
async function simulateDatabaseUpdate(id: string, email: string): Promise<void> {
  return new Promise((resolve) => {
    setTimeout(() => {
      console.log(`Database updated: ID ${id} -> ${email}`);
      resolve();
    }, 500);
  });
}
