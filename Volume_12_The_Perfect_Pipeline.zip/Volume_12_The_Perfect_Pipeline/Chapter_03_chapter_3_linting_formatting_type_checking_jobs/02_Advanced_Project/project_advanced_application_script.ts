/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

/**
 * ============================================================================
 * 1. DATA MODELS & UTILITY TYPES
 * ============================================================================
 * 
 * We define a base interface representing a Project entity in our SaaS.
 * We then use Utility Types to derive specific variations for different
 * UI contexts (Editing vs. Read-only).
 */

// Base interface for a Project entity
interface Project {
  id: string;
  name: string;
  description: string;
  status: 'active' | 'archived' | 'pending';
  createdAt: Date;
  budget?: number; // Optional property
}

/**
 * Represents the shape of a project when editing.
 * We use `Partial<Project>` to make all properties optional,
 * allowing users to update only specific fields.
 * We also omit the `id` and `createdAt` as they are immutable.
 */
type ProjectEditForm = Omit<Partial<Project>, 'id' | 'createdAt'>;

/**
 * Represents a read-only view of a project.
 * We use `Readonly<Project>` to enforce immutability at the type level.
 */
type ReadonlyProject = Readonly<Project>;

/**
 * ============================================================================
 * 2. GENERIC UTILITY FUNCTIONS
 * ============================================================================
 * 
 * These functions use Generics to operate on various types while maintaining
 * type safety.
 */

/**
 * Validates if an object conforms to a specific shape (simplified runtime check).
 * 
 * @param obj - The object to validate.
 * @param requiredKeys - The keys that must be present.
 * @returns A boolean indicating validity.
 * 
 * Under the Hood: This uses Generics `<T>` to capture the type of the object
 * passed in. The `keyof T` ensures we are checking valid properties of the type.
 */
function validateShape<T>(obj: unknown, requiredKeys: (keyof T)[]): obj is T {
  if (!obj || typeof obj !== 'object') return false;
  
  // Check if all required keys exist in the object
  return requiredKeys.every(key => key in obj);
}

/**
 * Merges partial update data with an existing entity.
 * 
 * @param existing - The current entity (Readonly).
 * @param update - The partial data to apply.
 * @returns A new object merging the two.
 * 
 * Under the Hood: We use the spread operator to create a new object.
 * The return type is inferred by TypeScript based on the intersection of inputs.
 */
function mergeUpdates<T extends object>(existing: T, update: Partial<T>): T {
  return { ...existing, ...update };
}

/**
 * ============================================================================
 * 3. REUSABLE API SERVICE (GENERIC CLASS)
 * ============================================================================
 * 
 * A class designed to handle CRUD operations for any entity type.
 * This demonstrates how Generics allow us to write logic once and reuse it
 * across different resources (Users, Projects, Tasks).
 */

class ApiService<T extends { id: string }> {
  private baseUrl: string;

  constructor(resourcePath: string) {
    this.baseUrl = `https://api.saas-dashboard.com/v1/${resourcePath}`;
  }

  /**
   * Fetches an entity by ID.
   * 
   * Note: We use `Promise<T>` to explicitly type the async return.
   * In a real app, we would use a library like Zod for runtime schema validation
   * to ensure the API response matches T.
   */
  async getById(id: string): Promise<T> {
    const response = await fetch(`${this.baseUrl}/${id}`);
    if (!response.ok) {
      throw new Error(`Failed to fetch resource ${id}`);
    }
    
    const data = await response.json();
    
    // Type Inference occurs here: TypeScript knows `data` should be shape T
    // based on the generic constraint of the class.
    return data as T;
  }

  /**
   * Updates an entity.
   * Accepts a partial update object.
   */
  async update(id: string, payload: Partial<T>): Promise<T> {
    const response = await fetch(`${this.baseUrl}/${id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });

    if (!response.ok) {
      throw new Error(`Failed to update resource ${id}`);
    }

    return response.json() as Promise<T>;
  }
}

/**
 * ============================================================================
 * 4. COMPONENT LOGIC SIMULATION (NEXT.JS APP ROUTER STYLE)
 * ============================================================================
 * 
 * This block simulates a server-side function (e.g., a Next.js Server Component
 * or API Route) that utilizes the generic service and utility types.
 */

// Instantiate the service for the 'Project' resource
const projectApi = new ApiService<Project>('projects');

/**
 * Simulates a Server Action or API Handler for updating a project.
 * 
 * @param projectId - The ID of the project to update.
 * @param formData - Raw form data (simulated as unknown).
 * @returns The updated project or an error message.
 */
async function handleProjectUpdate(projectId: string, formData: unknown) {
  try {
    // 1. Fetch the current project (ReadonlyProject)
    const currentProject = await projectApi.getById(projectId);
    
    // 2. Validate the incoming form data against ProjectEditForm requirements
    // In this case, we just check if it's an object, but in reality,
    // we'd check specific keys required for an update.
    if (!validateShape<ProjectEditForm>(formData, ['name', 'description', 'status'])) {
      return { success: false, error: 'Invalid form data structure' };
    }

    // 3. Type Inference in Action:
    // TypeScript infers that `formData` is of type `ProjectEditForm`
    // because of the type guard in validateShape.
    
    // 4. Merge updates
    const updatedProjectData = mergeUpdates(currentProject, formData);
    
    // 5. Send update to API
    // The ApiService expects Partial<Project>, which ProjectEditForm satisfies.
    const result = await projectApi.update(projectId, updatedProjectData);

    return { success: true, data: result };
  } catch (error) {
    console.error(error);
    return { success: false, error: 'Internal Server Error' };
  }
}

// Example Usage Simulation
const mockFormInput = {
  name: "Updated Project Name",
  description: "New description",
  status: "active" as const
};

// This function call demonstrates the flow
handleProjectUpdate("proj_123", mockFormInput).then(console.log);
