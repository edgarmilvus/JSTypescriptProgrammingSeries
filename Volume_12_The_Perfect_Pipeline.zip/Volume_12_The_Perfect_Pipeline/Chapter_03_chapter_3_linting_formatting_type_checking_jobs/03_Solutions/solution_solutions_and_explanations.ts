/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

import { z } from 'zod';

// 1. Define the Zod schema with strict validation rules
const UserSchema = z.object({
  id: z.string().min(1, "ID cannot be empty"), // Non-empty string
  username: z.string().min(3, "Username must be at least 3 characters"), // Min length 3
  email: z.string().email("Invalid email format"), // Valid email format
  age: z.number().int().positive().optional().refine(
    (val) => val === undefined || val > 18, 
    { message: "Age must be greater than 18 if provided" }
  ), // Optional number > 18
});

// Infer the TypeScript type from the schema for internal use
export type User = z.infer<typeof UserSchema>;

export async function fetchAndValidateUser(userId: string): Promise<User> {
  const url = `https://api.example.com/users/${userId}`;

  try {
    const response = await fetch(url);

    // Check for HTTP errors (e.g., 404, 500)
    if (!response.ok) {
      throw new Error(`HTTP error! Status: ${response.status}`);
    }

    // Parse JSON
    const rawData = await response.json();

    // Validate against schema
    // .parse() throws a ZodError if validation fails
    const validatedUser = UserSchema.parse(rawData);

    return validatedUser;

  } catch (error) {
    if (error instanceof z.ZodError) {
      // Handle validation errors specifically
      const errorMessage = `Validation failed: ${JSON.stringify(error.errors)}`;
      throw new Error(errorMessage);
    } else if (error instanceof Error) {
      // Re-throw network or parsing errors
      throw error;
    } else {
      // Handle unknown errors
      throw new Error("An unknown error occurred during data fetching");
    }
  }
}
