/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

import { z } from 'zod';

/**
 * A generic API client that fetches data and validates it against a Zod schema.
 * @param url - The endpoint to fetch from.
 * @param schema - The Zod schema to validate the response.
 * @returns A Promise resolving to the validated type T.
 */
export async function apiClient<T>(url: string, schema: z.ZodSchema<T>): Promise<T> {
  try {
    const response = await fetch(url);

    if (!response.ok) {
      throw new Error(`API Error: ${response.statusText}`);
    }

    const data = unknown; // We don't trust the data yet
    
    // Validate and return
    return schema.parse(data);
    
  } catch (error) {
    if (error instanceof z.ZodError) {
      // Enhance error with validation details
      throw new Error(`Validation Error: ${JSON.stringify(error.errors)}`);
    }
    throw error;
  }
}

// --- Demonstration Usage ---

// 1. Define Schemas
const ProductSchema = z.object({
  id: z.string(),
  name: z.string(),
  price: z.number(),
});

const PostSchema = z.object({
  id: z.number(),
  title: z.string(),
  body: z.string(),
  tags: z.array(z.string()),
});

// 2. Infer Types (optional, but good for explicit typing)
type Product = z.infer<typeof ProductSchema>;
type Post = z.infer<typeof PostSchema>;

// 3. Usage Example
async function fetchResources() {
  // T is inferred as Product based on the schema argument
  const product = await apiClient('https://api.example.com/products/1', ProductSchema);
  console.log(product.name); // TypeScript knows 'name' exists and is a string

  // T is inferred as Post based on the schema argument
  const post = await apiClient('https://api.example.com/posts/1', PostSchema);
  console.log(post.tags.length); // TypeScript knows 'tags' is an array of strings
}
