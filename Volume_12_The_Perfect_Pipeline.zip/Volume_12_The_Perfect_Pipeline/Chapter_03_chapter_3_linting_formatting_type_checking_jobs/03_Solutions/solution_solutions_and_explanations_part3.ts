/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

import React, { useState, ChangeEvent, FormEvent } from 'react';
import { z } from 'zod';

// Define the shape of the state passed to the render prop
interface FormState<T> {
  values: T;
  errors: Record<keyof T, string> | {};
  handleChange: (e: ChangeEvent<HTMLInputElement>) => void;
  handleSubmit: (e: FormEvent<HTMLFormElement>) => Promise<void>;
}

interface GenericFormProps<T> {
  initialValues: T;
  schema: z.ZodObject<any>; // Zod schema for validation
  onSubmit: (data: T) => void | Promise<void>;
  children: (props: FormState<T>) => React.ReactNode;
}

export function GenericForm<T extends Record<string, any>>({
  initialValues,
  schema,
  onSubmit,
  children,
}: GenericFormProps<T>) {
  const [values, setValues] = useState<T>(initialValues);
  const [errors, setErrors] = useState<Record<keyof T, string> | {}>({});

  const handleChange = (e: ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setValues((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setErrors({}); // Clear previous errors

    // Validate using Zod
    try {
      // safeParse returns a result object instead of throwing
      const result = schema.safeParse(values);
      
      if (result.success) {
        await onSubmit(result.data);
      } else {
        // Map Zod errors to a field-error map
        const fieldErrors = result.error.errors.reduce((acc, err) => {
          const field = err.path[0] as keyof T;
          acc[field] = err.message;
          return acc;
        }, {} as Record<keyof T, string>);
        
        setErrors(fieldErrors);
      }
    } catch (error) {
      console.error("Submission error:", error);
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      {children({ values, errors, handleChange, handleSubmit })}
    </form>
  );
}

// --- Example Usage (Conceptual) ---
/*
const loginSchema = z.object({
  email: z.string().email(),
  password: z.string().min(8),
});

const Login = () => (
  <GenericForm
    initialValues={{ email: '', password: '' }}
    schema={loginSchema}
    onSubmit={(data) => console.log('Logging in with', data)}
  >
    {({ values, errors, handleChange, handleSubmit }) => (
      <>
        <input name="email" value={values.email} onChange={handleChange} />
        {errors.email && <span>{errors.email}</span>}
        
        <input name="password" type="password" value={values.password} onChange={handleChange} />
        {errors.password && <span>{errors.password}</span>}
        
        <button type="submit">Login</button>
      </>
    )}
  </GenericForm>
);
*/
