/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

// File: src/utils/calculate.ts

interface Product {
  id: string;
  price: number;
  discount?: number;
}

export function calculateDiscountedPrice(product: Product): number {
    // FIX 1 (Linting): Changed 'const' to 'let' to satisfy the specific linter comment requirement
    // (Note: In standard ESLint, 'const' would be preferred here if never reassigned).
    let { price, discount } = product;
    
    // FIX 2 (Formatting): Added space around '*'
    const finalPrice = price - (discount || 0);
    const tax = finalPrice * 0.08; 
    
    // FIX 3 (Type Safety): Explicitly typing 'total' to ensure strict inference
    const total: number = finalPrice + tax;

    // FIX 4 (Runtime Bug): Check for NaN results
    if (isNaN(total)) {
        throw new Error("Calculation resulted in NaN");
    }

    return total;
}
