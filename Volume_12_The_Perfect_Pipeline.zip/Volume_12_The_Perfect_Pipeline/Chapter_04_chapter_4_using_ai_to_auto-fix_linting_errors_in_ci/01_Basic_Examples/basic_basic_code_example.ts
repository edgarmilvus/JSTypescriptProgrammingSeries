/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * @fileoverview AI-Assisted Linting Agent
 * 
 * This script demonstrates the core logic of an automated code fixer.
 * It uses 'fs' to manipulate files and a mock LLM client to simulate
 * AI interaction. In a real environment, this would be a GitHub Action.
 */

import * as fs from 'fs';
import * as path from 'path';

// -----------------------------------------------------------------------------
// 1. TYPE DEFINITIONS & CONFIGURATION
// -----------------------------------------------------------------------------

/**
 * Represents a single linting error detected by the tool.
 * Strict typing ensures we know exactly what data the linter provides.
 */
interface LintError {
    filePath: string;
    line: number;
    column: number;
    message: string;
    ruleId: string; // e.g., "no-unused-vars"
}

/**
 * Represents the structured response expected from the AI model.
 * We use JSON Schema output constraints to force the LLM to adhere to this.
 */
interface AIResponse {
    originalCode: string;
    fixedCode: string;
    explanation: string;
}

// Configuration for our "SaaS" environment
const CONFIG = {
    sourceFile: './src/example.ts',
    // In a real app, this would be an actual API endpoint or SDK instance
    aiModelEndpoint: 'mock-llm-provider.com/v1/chat',
};

// -----------------------------------------------------------------------------
// 2. MOCK DATA & SIMULATION
// -----------------------------------------------------------------------------

/**
 * Simulates a linter's output.
 * In a real scenario, this would be the result of running `eslint --format json`.
 */
const MOCK_LINT_REPORT: LintError[] = [
    {
        filePath: CONFIG.sourceFile,
        line: 3,
        column: 1,
        message: "Variable 'count' is assigned a value but never used.",
        ruleId: "@typescript-eslint/no-unused-vars"
    }
];

/**
 * Simulates the source code with an intentional error.
 */
const MOCK_SOURCE_CODE = `
// Example SaaS API Handler
function processUserInput(input: string) {
    const count = 10; // Unused variable (Lint Error)
    console.log("Processing:", input);
    return input.toUpperCase();
}
`;

/**
 * Simulates the AI-generated fix.
 * Note: The AI removes the unused variable and adjusts formatting.
 */
const MOCK_AI_FIX = `
// Example SaaS API Handler
function processUserInput(input: string) {
    console.log("Processing:", input);
    return input.toUpperCase();
}
`;

// -----------------------------------------------------------------------------
// 3. CORE LOGIC
// -----------------------------------------------------------------------------

/**
 * Step 1: Read the file and simulate linting.
 * 
 * @returns {Promise<LintError[]>} A list of detected issues.
 */
async function runLinter(): Promise<LintError[]> {
    console.log("🔍 [CI] Running linter...");
    
    // In a real app, we would spawn a process: `exec('eslint src/ --format json')`
    // Here, we return our mock data to simulate the detection of the unused variable.
    return new Promise((resolve) => {
        setTimeout(() => {
            console.log(`   Found ${MOCK_LINT_REPORT.length} issue(s).`);
            resolve(MOCK_LINT_REPORT);
        }, 500);
    });
}

/**
 * Step 2: Construct the prompt and query the AI.
 * 
 * This function demonstrates "JSON Schema Output" by explicitly requesting
 * a structured JSON response from the LLM.
 * 
 * @param code - The raw source code string.
 * @param errors - The list of linting errors.
 * @returns {Promise<AIResponse>} The parsed AI response.
 */
async function queryAIForFix(code: string, errors: LintError[]): Promise<AIResponse> {
    console.log("🤖 [AI] Requesting code fix...");

    // Construct the prompt context
    const errorContext = errors.map(e => `Line ${e.line}: ${e.message} (${e.ruleId})`).join('\n');
    
    const prompt = `
    You are an automated code quality bot.
    Fix the following linting errors in the provided TypeScript code.
    Return ONLY a valid JSON object matching this schema:
    {
      "originalCode": "string",
      "fixedCode": "string",
      "explanation": "string"
    }
    
    Errors:
    ${errorContext}
    
    Code:
    ${code}
    `;

    // SIMULATION: In a real app, we would use `fetch` or an SDK (e.g., OpenAI SDK).
    // We enforce JSON parsing to simulate the strict type discipline required.
    return new Promise((resolve) => {
        setTimeout(() => {
            // Simulating the JSON parsing step
            const response: AIResponse = {
                originalCode: code,
                fixedCode: MOCK_AI_FIX,
                explanation: "Removed unused variable 'count' to satisfy @typescript-eslint/no-unused-vars."
            };
            console.log("   Received structured AI response.");
            resolve(response);
        }, 1000);
    });
}

/**
 * Step 3: Apply the fix to the file system.
 * 
 * @param filePath - Path to the file to update.
 * @param fixedCode - The corrected code string.
 */
async function applyFix(filePath: string, fixedCode: string): Promise<void> {
    console.log("💾 [CI] Applying fix to disk...");

    // Ensure directory exists (basic safety check)
    const dir = path.dirname(filePath);
    if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
    }

    // Write the file
    return new Promise((resolve, reject) => {
        fs.writeFile(filePath, fixedCode, 'utf8', (err) => {
            if (err) {
                console.error("   Failed to write file:", err);
                reject(err);
            } else {
                console.log("   File updated successfully.");
                resolve();
            }
        });
    });
}

// -----------------------------------------------------------------------------
// 4. ORCHESTRATION (Main Execution)
// -----------------------------------------------------------------------------

/**
 * Main entry point simulating the CI job execution.
 */
async function main() {
    console.log("🚀 Starting AI-Assisted Linting Pipeline...\n");

    try {
        // 1. Initialize: Read the source file
        const rawCode = fs.readFileSync(CONFIG.sourceFile, 'utf-8');

        // 2. Detect Issues
        const errors = await runLinter();

        if (errors.length === 0) {
            console.log("✅ No errors found. Exiting.");
            return;
        }

        // 3. AI Intervention
        const aiResult = await queryAIForFix(rawCode, errors);
        
        // 4. Validation (Strict Type Discipline)
        // In a real app, we would use Zod here: const parsed = z.object({ ... }).parse(aiResult);
        if (!aiResult.fixedCode || aiResult.fixedCode === rawCode) {
            console.warn("⚠️  AI did not generate a valid fix or code is unchanged.");
            return;
        }

        // 5. Apply Changes
        await applyFix(CONFIG.sourceFile, aiResult.fixedCode);

        console.log("\n✅ Pipeline Complete: Code auto-fixed and ready for commit.");

    } catch (error) {
        console.error("\n❌ Pipeline Failed:", error);
        process.exit(1);
    }
}

// Create the dummy file for demonstration purposes
if (!fs.existsSync(CONFIG.sourceFile)) {
    fs.mkdirSync(path.dirname(CONFIG.sourceFile), { recursive: true });
    fs.writeFileSync(CONFIG.sourceFile, MOCK_SOURCE_CODE);
}

// Execute if run directly
if (require.main === module) {
    main();
}
