/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// pages/api/auto-fix-lint.ts
// Next.js API Route Handler
import type { NextApiRequest, NextApiResponse } from 'next';
import { z } from 'zod';

// ============================================================================
// 1. TYPE DEFINITIONS & SCHEMAS
// ============================================================================

/**
 * Strict Type Discipline: We define the shape of data using Zod.
 * This allows us to infer TypeScript types directly from the schema,
 * ensuring runtime validation matches compile-time expectations.
 */

// Schema for the incoming CI payload (simulating a GitHub Actions webhook)
const CiLintPayloadSchema = z.object({
  repo: z.string(),
  owner: z.string(),
  branch: z.string(),
  lintErrors: z.array(
    z.object({
      file: z.string(),
      line: z.number(),
      rule: z.string(),
      message: z.string(),
      originalCode: z.string(),
    })
  ),
});

// Infer TypeScript type from the Zod schema
type CiLintPayload = z.infer<typeof CiLintPayloadSchema>;

// Schema for the expected AI response.
// This is the "JSON Schema Output" concept: forcing the LLM to adhere to this structure.
const AiFixResponseSchema = z.object({
  status: z.enum(['success', 'failure']),
  fixes: z.array(
    z.object({
      file: z.string(),
      line: z.number(),
      fixedCode: z.string(),
      explanation: z.string(), // Why the change was made
    })
  ),
});

type AiFixResponse = z.infer<typeof AiFixResponseSchema>;

// ============================================================================
// 2. AI ORCHESTRATION LOGIC
// ============================================================================

/**
 * Constructs the prompt for the LLM.
 * Includes context, constraints, and the strict JSON schema requirement.
 */
function buildPrompt(payload: CiLintPayload): string {
  const errors = payload.lintErrors
    .map((e) => `- File: ${e.file}, Line: ${e.line}, Rule: ${e.rule}, Error: ${e.message}\n  Code: ${e.originalCode}`)
    .join('\n');

  return `
    You are an expert TypeScript developer. Your task is to fix linting errors in a Next.js project.
    
    **Context:**
    - Repository: ${payload.owner}/${payload.repo}
    - Branch: ${payload.branch}

    **Errors to Fix:**
    ${errors}

    **Instructions:**
    1. Analyze the code snippets provided.
    2. Generate a valid JSON object matching the following schema:
       {
         "status": "success" | "failure",
         "fixes": [
           {
             "file": "string",
             "line": number,
             "fixedCode": "string",
             "explanation": "string"
           }
         ]
       }
    3. Do not include markdown formatting or text outside the JSON object.
    4. If you cannot fix an error, set status to "failure".
  `;
}

/**
 * Mocks the call to an LLM API (e.g., OpenAI).
 * In a production environment, this would be an actual fetch request.
 */
async function callLLM(prompt: string): Promise<AiFixResponse> {
  // SIMULATION: In a real scenario, we would call the LLM API here.
  // For this script, we return a mock response that matches our schema.
  
  console.log("Sending prompt to LLM...");
  
  // Simulating a delay
  await new Promise(resolve => setTimeout(resolve, 500));

  // Mocking a response based on the prompt (just for demonstration)
  // In reality, the LLM generates this based on the prompt's context.
  const mockResponse: AiFixResponse = {
    status: 'success',
    fixes: [
      {
        file: 'components/Button.tsx',
        line: 12,
        fixedCode: 'const Button = () => <button type="button">Click</button>;',
        explanation: 'Added explicit type="button" to prevent default form submission and adhered to ESLint react/button-has-type rule.',
      },
    ],
  };

  return mockResponse;
}

// ============================================================================
// 3. GIT COMMIT LOGIC
// ============================================================================

/**
 * Simulates committing the fixed code to the repository.
 * Uses the GitHub REST API (or similar) in a real implementation.
 */
async function commitFixesToRepo(payload: CiLintPayload, fixes: AiFixResponse['fixes']): Promise<void> {
  console.log(`Preparing to commit ${fixes.length} fixes to ${payload.repo}...`);

  // In a real scenario, we would:
  // 1. Fetch the current file content using GitHub API (octokit).
  // 2. Apply the text replacement based on line numbers.
  // 3. Create a new commit with the changes.
  // 4. Push to the branch.

  fixes.forEach((fix) => {
    console.log(`- Applying fix to ${fix.file} (Line ${fix.line}): ${fix.explanation}`);
    // Logic to update file content would go here
  });

  // Mock commit
  console.log("Changes committed and pushed successfully.");
}

// ============================================================================
// 4. API HANDLER (NEXT.JS ROUTE)
// ============================================================================

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  // Only allow POST requests
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method Not Allowed' });
  }

  try {
    // 1. VALIDATE INPUT
    // Using Zod to parse the request body ensures strict type discipline.
    // If the payload doesn't match CiLintPayloadSchema, it throws an error.
    const payload = CiLintPayloadSchema.parse(req.body);

    // 2. GENERATE PROMPT
    const prompt = buildPrompt(payload);

    // 3. CALL AI
    const aiResponseRaw = await callLLM(prompt);
    
    // 4. VALIDATE AI OUTPUT
    // Even though we prompted the AI for JSON, we must validate it strictly.
    const aiResponse = AiFixResponseSchema.parse(aiResponseRaw);

    if (aiResponse.status === 'failure') {
      return res.status(200).json({ 
        message: 'AI analyzed errors but could not generate fixes.', 
        details: aiResponse 
      });
    }

    // 5. EXECUTE FIXES
    await commitFixesToRepo(payload, aiResponse.fixes);

    return res.status(200).json({ 
      success: true, 
      message: 'Auto-fix completed successfully.',
      fixesApplied: aiResponse.fixes.length 
    });

  } catch (error) {
    // Detailed error handling
    if (error instanceof z.ZodError) {
      console.error("Validation Error:", error.errors);
      return res.status(400).json({ error: 'Invalid payload structure', details: error.errors });
    }
    
    console.error("Internal Error:", error);
    return res.status(500).json({ error: 'Internal Server Error' });
  }
}
