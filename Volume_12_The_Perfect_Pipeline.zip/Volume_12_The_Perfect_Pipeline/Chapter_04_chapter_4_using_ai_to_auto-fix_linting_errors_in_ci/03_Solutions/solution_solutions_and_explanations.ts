/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// src/config/env.ts
import { z } from 'zod';

// 1. Define the EnvSchema using Zod
const EnvSchema = z.object({
  // Required URL validation
  VITE_API_URL: z.string().url("VITE_API_URL must be a valid URL"),
  
  // Positive integer with default value
  VITE_MAX_RETRIES: z.coerce.number().int().positive().default(3),
  
  // Boolean coercion with default value
  VITE_ENABLE_DEBUG: z.coerce.boolean().default(false),
});

// 2. Parse the environment variables
// We use safeParse to handle errors gracefully rather than crashing immediately
const parsed = EnvSchema.safeParse(import.meta.env);

if (!parsed.success) {
  // 3. Error Handling: Format errors for readability
  const formattedErrors = parsed.error.flatten().fieldErrors;
  const errorMessage = `Invalid environment configuration:\n${Object.entries(formattedErrors)
    .map(([field, errors]) => `  - ${field}: ${errors?.join(', ')}`)
    .join('\n')}`;
  
  throw new Error(errorMessage);
}

// 4. Export the typed object
export const env = parsed.data;
