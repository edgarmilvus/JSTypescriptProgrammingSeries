/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.tsx
// Description: Solutions and Explanations
// ==========================================

// src/components/UserCard.tsx
import { z } from 'zod';
import { useEffect } from 'react';

// 1. Define UserSchema
const UserSchema = z.object({
  id: z.string().uuid(),
  name: z.string().min(1, "Name cannot be empty"),
  email: z.string().email(),
  role: z.enum(['admin', 'user', 'guest']),
  avatarUrl: z.string().url().optional(),
});

// 2. Infer the 'User' type
type User = z.infer<typeof UserSchema>;

// 3. Update Props interface using the inferred type
interface UserCardProps {
  user: User;
}

export const UserCard: React.FC<UserCardProps> = ({ user }) => {
  // 4. Runtime Validation (Development Only)
  useEffect(() => {
    if (import.meta.env.DEV) {
      const result = UserSchema.safeParse(user);
      if (!result.success) {
        console.error('Invalid User prop passed to UserCard:', result.error.issues);
      }
    }
  }, [user]);

  return (
    <div className="user-card">
      <h2>{user.name}</h2>
      <p>{user.email}</p>
      <span className={`role-badge ${user.role}`}>{user.role}</span>
      {user.avatarUrl && <img src={user.avatarUrl} alt={user.name} />}
    </div>
  );
};
