/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

# .github/workflows/lint-ai.yml
name: AI Lint Fixer

on:
  pull_request:
    branches: [ main ]

jobs:
  lint:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      
      - name: Setup Node
        uses: actions/setup-node@v3
        with:
          node-version: '18'
          
      - name: Install Dependencies
        run: npm ci

      # 1. Run ESLint with JSON output
      # We use 'continue-on-error: true' to allow the workflow to proceed to the next step
      # even if linting fails (which is expected if we are trying to fix errors).
      - name: Run ESLint (JSON Output)
        id: lint
        continue-on-error: true
        run: |
          npx eslint src/ --ext .ts,.tsx --format json > eslint-report.json || true

      # 2. AI Integration Step
      # This step runs only if the linting step failed (exit code != 0)
      - name: AI Suggestion
        if: steps.lint.outcome == 'failure'
        run: |
          echo "Linting failed. Analyzing errors..."
          # Run the AI fix script (simulated)
          node scripts/ai-fix.ts eslint-report.json
          
      # 3. Verify Fix (Optional but recommended)
      - name: Verify Linting
        if: steps.lint.outcome == 'failure'
        run: npx eslint src/ --ext .ts,.tsx
