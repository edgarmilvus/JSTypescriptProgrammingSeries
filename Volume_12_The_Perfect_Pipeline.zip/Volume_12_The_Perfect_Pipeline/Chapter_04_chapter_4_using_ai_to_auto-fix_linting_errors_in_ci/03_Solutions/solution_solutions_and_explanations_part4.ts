/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

// src/agent/workflow.ts
import { StateGraph, END, MemorySaver, StateSnapshot } from '@langchain/langgraph';
import { z } from 'zod';

// 1. Define State Schema
const StateSchema = z.object({
  fileContent: z.string(),
  errors: z.array(z.string()).optional(),
  fixedContent: z.string().optional(),
});

// Type inference for the state
type State = z.infer<typeof StateSchema>;

// 2. Define Nodes
const parseNode = (state: State): Partial<State> => {
  console.log("Node: Parsing file...");
  // Simulate extracting errors
  return { errors: ["Error 1: Missing type", "Error 2: Unused variable"] };
};

const analyzeNode = (state: State): Partial<State> => {
  console.log("Node: Analyzing errors...");
  // Simulate analysis logic
  return {}; 
};

const fixNode = (state: State): Partial<State> => {
  console.log("Node: Applying fixes...");
  // Simulate generating fixed content
  return { fixedContent: state.fileContent.replace('any', 'string') };
};

const commitNode = (state: State): Partial<State> => {
  console.log("Node: Committing changes...");
  // Simulate a failure (e.g., git permission error)
  throw new Error("Simulated Git Commit Failure");
};

// 3. Initialize Graph with Checkpointer
const checkpointer = new MemorySaver();
const workflow = new StateGraph(StateSchema);

// Add nodes
workflow.addNode("parse", parseNode);
workflow.addNode("analyze", analyzeNode);
workflow.addNode("fix", fixNode);
workflow.addNode("commit", commitNode);

// Define edges
workflow.setEntryPoint("parse");
workflow.addEdge("parse", "analyze");
workflow.addEdge("analyze", "fix");
workflow.addEdge("fix", "commit");
workflow.addEdge("commit", END);

// Compile with checkpointer
const app = workflow.compile({ checkpointer });

// 4. Execution and Recovery Logic
async function runWorkflow() {
  const config = { configurable: { thread_id: "session_1" } };
  const initialState = { fileContent: "const x: any = 'hello';" };

  try {
    // Run until commit (which will fail)
    await app.invoke(initialState, config);
  } catch (error) {
    console.log(`Workflow failed: ${error.message}`);
    
    // Retrieve state from checkpointer
    const savedState = await app.getState(config);
    
    console.log("\n--- Retrieved State from Checkpointer ---");
    console.log("Fixed Content exists:", !!savedState.fixedContent);
    console.log("Errors:", savedState.errors);
    
    // Resume from the failed node (or retry commit)
    console.log("\nRetrying commit...");
    // In a real scenario, we might fix the git error here
    // await app.invoke(null, config); 
  }
}

runWorkflow();
