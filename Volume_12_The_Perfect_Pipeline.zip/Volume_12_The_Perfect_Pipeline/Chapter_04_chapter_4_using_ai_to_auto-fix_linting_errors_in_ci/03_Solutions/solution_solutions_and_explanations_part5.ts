/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

// scripts/simulate-lint.ts
import * as fs from 'fs';

// 1. Mock ESLint JSON Report
const mockReport = [
  {
    filePath: "/src/utils/api.ts",
    messages: [
      {
        ruleId: "@typescript-eslint/no-explicit-any",
        severity: 2,
        message: "Unexpected any. Specify a different type.",
        line: 10,
        column: 15,
        fix: {
          range: [150, 153],
          text: "string"
        }
      },
      {
        ruleId: "@typescript-eslint/no-explicit-any",
        severity: 2,
        message: "Unexpected any. Specify a different type.",
        line: 25,
        column: 20,
        fix: {
          range: [300, 303],
          text: "number"
        }
      }
    ],
    errorCount: 2,
    warningCount: 0,
    fixableErrorCount: 2,
    fixableWarningCount: 0
  },
  {
    filePath: "/src/components/Button.tsx",
    messages: [
      {
        ruleId: "@typescript-eslint/no-explicit-any",
        severity: 2,
        message: "Unexpected any. Specify a different type.",
        line: 5,
        column: 10,
        fix: {
          range: [50, 53],
          text: "unknown"
        }
      }
    ],
    errorCount: 1,
    warningCount: 0,
    fixableErrorCount: 1,
    fixableWarningCount: 0
  }
];

// 2. Write to file
fs.writeFileSync('eslint-report.json', JSON.stringify(mockReport, null, 2));
console.log("Generated eslint-report.json with 3 fixable 'no-explicit-any' errors.");

// 3. Simulate AI Fix Logic (Text Replacement)
// In a real scenario, this would be an LLM call. Here we just overwrite the file.
const targetFile = "/src/utils/api.ts";
const originalContent = `
export const fetchData = (id: any): any => {
  return fetch(\`/api/\${id}\`);
};
`;

// Simple simulation: replace 'any' with 'string' based on the mock report
const patchedContent = originalContent.replace(/: any/g, ": string");
fs.writeFileSync(targetFile, patchedContent);
console.log(`Simulated AI patch applied to ${targetFile}`);
