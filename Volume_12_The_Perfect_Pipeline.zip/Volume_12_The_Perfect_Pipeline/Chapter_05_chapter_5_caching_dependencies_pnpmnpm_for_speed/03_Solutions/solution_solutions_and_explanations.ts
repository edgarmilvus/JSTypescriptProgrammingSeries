/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// .github/workflows/ci.yml
name: Monorepo CI with pnpm Caching

on:
  push:
    branches: [main]
  pull_request:
    branches: [main]

jobs:
  install-and-build:
    runs-on: ubuntu-latest
    steps:
      - name: Checkout repository
        uses: actions/checkout@v4

      # 1. Setup pnpm (Official Action)
      - name: Setup pnpm
        uses: pnpm/action-setup@v2
        with:
          version: 8 # Use specific version or 'latest'

      # 2. Setup Node.js
      - name: Setup Node.js
        uses: actions/setup-node@v4
        with:
          node-version: '20'
          # We rely on pnpm for caching, so disable npm/yarn caching here
          cache: 'pnpm'

      # 3. Cache the pnpm store directory
      - name: Get pnpm store directory
        shell: bash
        run: |
          echo "STORE_PATH=$(pnpm store path --silent)" >> $GITHUB_ENV

      - name: Cache pnpm store
        uses: actions/cache@v4
        id: pnpm-store-cache
        with:
          path: ${{ env.STORE_PATH }}
          # Key strategy: Hash of lockfile + OS
          # Note: In a true monorepo, we might hash all package.json files, 
          # but pnpm-lock.yaml is the single source of truth for dependency resolution.
          key: ${{ runner.os }}-pnpm-store-${{ hashFiles('pnpm-lock.yaml') }}
          restore-keys: |
            ${{ runner.os }}-pnpm-store-

      # 4. Install dependencies
      - name: Install dependencies
        # --frozen-lockfile ensures install fails if lockfile is out of sync
        run: pnpm install --frozen-lockfile

      # 5. Build the project
      - name: Build
        run: pnpm run build

      # 6. Verification: Print cache status
      - name: Cache Status
        run: |
          echo "Cache Hit Status: ${{ steps.pnpm-store-cache.outputs.cache-hit }}"
          if [ "${{ steps.pnpm-store-cache.outputs.cache-hit }}" == "true" ]; then
            echo "✅ Cache hit! Dependencies restored from cache."
          else
            echo "⚠️ Cache miss! Dependencies downloaded fresh."
          fi
