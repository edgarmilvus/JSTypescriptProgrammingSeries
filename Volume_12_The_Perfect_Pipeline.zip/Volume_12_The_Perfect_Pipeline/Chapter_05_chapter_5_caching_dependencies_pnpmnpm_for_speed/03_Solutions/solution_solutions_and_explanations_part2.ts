/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

// .github/workflows/matrix-ci.yml
name: Node.js Matrix Compatibility

on:
  push:
    branches: [main]
  pull_request:
    branches: [main]

jobs:
  test-matrix:
    runs-on: ubuntu-latest
    # 1. Matrix Setup
    strategy:
      matrix:
        node-version: ['16.x', '18.x', '20.x']

    steps:
      - name: Checkout repository
        uses: actions/checkout@v4

      # 2. Setup Node.js with Matrix Version
      - name: Setup Node.js ${{ matrix.node-version }}
        uses: actions/setup-node@v4
        with:
          node-version: ${{ matrix.node-version }}
          # We disable the native setup-node cache here to implement a custom shared cache strategy
          cache: 'npm' # or 'pnpm' depending on your package manager

      # 3. Shared Cache Strategy
      - name: Cache node_modules
        uses: actions/cache@v4
        id: node-modules-cache
        with:
          path: node_modules
          # Primary Key: OS + Lockfile Hash (Excludes Node Version)
          # This allows different Node versions to share the same dependency cache
          key: ${{ runner.os }}-node-modules-${{ hashFiles('package-lock.json', 'yarn.lock', 'pnpm-lock.yaml') }}
          restore-keys: |
            # Fallback to previous lockfile hashes if exact match not found
            ${{ runner.os }}-node-modules-

      # 4. Install dependencies
      - name: Install Dependencies
        # Even if node_modules is restored, package managers might need to sync
        run: npm ci 

      # 5. Run Tests
      - name: Run Tests
        run: npm test

      # 6. Verification
      - name: Cache Status
        run: |
          echo "Cache Hit for Node ${{ matrix.node-version }}: ${{ steps.node-modules-cache.outputs.cache-hit }}"
