/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

// CacheMetrics.tsx
import React from 'react';

// 1. Define Props Interface
interface CacheMetricsProps {
  jobId: string;
  totalSteps: number;
  cacheHits: number;
  cacheMisses: number;
  restoreTimeMs: number;
}

export const CacheMetrics: React.FC<CacheMetricsProps> = ({
  jobId,
  cacheHits,
  cacheMisses,
  restoreTimeMs,
}) => {
  // 2. Visualization Logic: Calculate Hit Rate
  const totalRequests = cacheHits + cacheMisses;
  const hitRate = totalRequests > 0 ? (cacheHits / totalRequests) * 100 : 0;
  
  // Format time to seconds
  const restoreTimeSec = (restoreTimeMs / 1000).toFixed(2);

  // 3. Conditional Rendering Logic
  let statusBadge = null;
  if (totalRequests > 0) {
    if (hitRate < 50) {
      statusBadge = (
        <span className="px-2 py-1 text-xs font-semibold text-white bg-red-500 rounded-full">
          ⚠️ Optimization Recommended
        </span>
      );
    } else if (hitRate >= 90) {
      statusBadge = (
        <span className="px-2 py-1 text-xs font-semibold text-white bg-green-500 rounded-full">
          ✅ Optimal Efficiency
        </span>
      );
    }
  }

  return (
    // 4. Styling with Tailwind CSS
    <div className="w-full max-w-md p-6 bg-white rounded-lg shadow-md border border-gray-200">
      <div className="flex justify-between items-center mb-4">
        <h3 className="text-lg font-bold text-gray-800">Job: {jobId}</h3>
        {statusBadge}
      </div>

      {/* Progress Bar for Hit Rate */}
      <div className="mb-4">
        <div className="flex justify-between text-sm text-gray-600 mb-1">
          <span>Cache Hit Rate</span>
          <span className="font-mono">{hitRate.toFixed(1)}%</span>
        </div>
        <div className="w-full bg-gray-200 rounded-full h-2.5">
          <div 
            className="bg-blue-600 h-2.5 rounded-full transition-all duration-500" 
            style={{ width: `${hitRate}%` }}
          ></div>
        </div>
      </div>

      {/* Metrics Grid */}
      <div className="grid grid-cols-2 gap-4 text-sm">
        <div className="bg-gray-50 p-2 rounded">
          <div className="text-gray-500">Hits</div>
          <div className="font-bold text-green-600">{cacheHits}</div>
        </div>
        <div className="bg-gray-50 p-2 rounded">
          <div className="text-gray-500">Misses</div>
          <div className="font-bold text-red-600">{cacheMisses}</div>
        </div>
        <div className="bg-gray-50 p-2 rounded col-span-2">
          <div className="text-gray-500">Restore Time</div>
          <div className="font-bold text-gray-800">{restoreTimeSec}s</div>
        </div>
      </div>
    </div>
  );
};
