/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

// cache-simulation.ts

// 1. Define Types
interface BranchDependency {
  branchName: string;
  dependencies: Record<string, string>; // e.g., { "axios": "1.0.0" }
}

// 2. Simulation Logic
function simulateCacheRestoration(branches: BranchDependency[]): void {
  console.log("🔍 Starting Cache Key Collision Simulation...\n");

  const keyMap = new Map<string, string>(); // Maps generated key -> branch name
  let collisionDetected = false;

  branches.forEach((branch) => {
    // 3. Key Generation (Simplified)
    // We simulate a "broad" key strategy: sorting keys to ensure consistent order,
    // then concatenating names and versions.
    const depEntries = Object.entries(branch.dependencies).sort();
    
    // Example of a potentially flawed key: just concatenating values without specific version pinning context
    // or using a hash that doesn't account for specific lockfile integrity.
    const rawString = depEntries.map(([name, version]) => `${name}@${version}`).join('|');
    
    // In a real scenario, this would be a hash function (e.g., SHA1)
    // For simulation, we use the raw string as the key.
    const generatedKey = `cache-key-${hashString(rawString)}`;

    console.log(`Branch: ${branch.branchName}`);
    console.log(`Dependencies: ${JSON.stringify(branch.dependencies)}`);
    console.log(`Generated Key: ${generatedKey}\n`);

    // 4. Collision Detection
    if (keyMap.has(generatedKey)) {
      const existingBranch = keyMap.get(generatedKey);
      console.warn(`⚠️ COLLISION DETECTED!`);
      console.warn(`   Current Branch: ${branch.branchName}`);
      console.warn(`   Existing Branch: ${existingBranch}`);
      console.warn(`   Both generated the same key: ${generatedKey}`);
      console.warn(`   Risk: Restoring 'node_modules' from ${existingBranch} could break ${branch.branchName}.\n`);
      collisionDetected = true;
    } else {
      keyMap.set(generatedKey, branch.branchName);
    }
  });

  if (!collisionDetected) {
    console.log("✅ No collisions detected in this simulation set.");
  }
}

// Helper: Simple string hash function for simulation purposes
function hashString(str: string): number {
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    const char = str.charCodeAt(i);
    hash = ((hash << 5) - hash) + char;
    hash = hash & hash; // Convert to 32bit integer
  }
  return hash;
}

// 5. Run Simulation with Scenario Data
const scenario: BranchDependency[] = [
  {
    branchName: "feature/auth",
    dependencies: {
      "axios": "^1.2.0",
      "react": "^18.0.0"
    }
  },
  {
    branchName: "feature/ui",
    dependencies: {
      "axios": "^1.1.0", // Different version
      "react": "^18.0.0"
    }
  }
];

// Execute
simulateCacheRestoration(scenario);
