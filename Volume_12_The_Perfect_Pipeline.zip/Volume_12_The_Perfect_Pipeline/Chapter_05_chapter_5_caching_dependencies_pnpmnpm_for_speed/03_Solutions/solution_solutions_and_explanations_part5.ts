/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

// .github/workflows/build-artifacts.yml
name: Cache Build Artifacts

on:
  push:
    branches: [main]

jobs:
  build-and-cache:
    runs-on: ubuntu-latest
    steps:
      - name: Checkout repository
        uses: actions/checkout@v4

      - name: Setup Node.js
        uses: actions/setup-node@v4
        with:
          node-version: '20'
          cache: 'pnpm'

      - name: Install Dependencies
        run: pnpm install --frozen-lockfile

      # 1. Artifact Identification
      # We assume the build output goes to 'dist/'

      # 2. Cache Key Determination
      - name: Get Source Hash
        id: source-hash
        run: echo "sha=$(git rev-parse HEAD)" >> $GITHUB_OUTPUT

      - name: Cache Build Artifacts
        id: build-cache
        uses: actions/cache@v4
        with:
          path: dist/
          # Key includes OS, Lockfile hash, and Source Code SHA
          # This ensures that if code changes, the cache is invalidated.
          key: ${{ runner.os }}-build-dist-${{ hashFiles('pnpm-lock.yaml') }}-${{ steps.source-hash.outputs.sha }}
          restore-keys: |
            ${{ runner.os }}-build-dist-${{ hashFiles('pnpm-lock.yaml') }}-

      # 3. Workflow Integration: Restore Check
      - name: Build Project
        # Only run build if cache was missed
        if: steps.build-cache.outputs.cache-hit != 'true'
        run: pnpm run build

      # 4. Save Logic (Implicit in actions/cache)
      # The 'actions/cache' action automatically saves the cache at the end of the job 
      # if the path content has changed compared to the key.
      
      # Verification
      - name: Verify Artifact
        run: |
          if [ -d "dist" ]; then
            echo "✅ Build artifacts exist."
            ls -R dist
          else
            echo "❌ No artifacts found."
          fi
