/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

// File: src/services/userService.ts
/**
 * Represents a user in the system.
 * This is a core data structure for our SaaS application.
 */
interface User {
    id: string;
    email: string;
    isActive: boolean;
    createdAt: Date;
}

/**
 * A mock database service to simulate data persistence.
 * In a real application, this would be a connection to PostgreSQL, MongoDB, etc.
 */
class MockDatabase {
    private users: User[] = [];

    /**
     * Saves a user to the mock in-memory database.
     * @param user - The user object to save.
     * @returns A promise that resolves to the saved user.
     */
    async save(user: Omit<User, 'id' | 'createdAt'>): Promise<User> {
        const newUser: User = {
            ...user,
            id: Math.random().toString(36).substring(7),
            createdAt: new Date(),
        };
        this.users.push(newUser);
        return Promise.resolve(newUser);
    }

    /**
     * Finds a user by their email address.
     * @param email - The email to search for.
     * @returns A promise that resolves to the user if found, otherwise null.
     */
    async findByEmail(email: string): Promise<User | null> {
        const user = this.users.find((u) => u.email === email);
        return Promise.resolve(user || null);
    }
}

/**
 * The main service class for handling user-related business logic.
 */
export class UserService {
    private db: MockDatabase;

    constructor(db: MockDatabase) {
        this.db = db;
    }

    /**
     * Registers a new user in the system.
     * Includes basic validation: checks if the email is already registered.
     * @param userData - The user's data (email and password, but we only store email here for simplicity).
     * @returns A promise that resolves to the newly created user.
     * @throws Error if the email is already in use.
     */
    async registerUser(userData: { email: string; password: string }): Promise<User> {
        // Step 1: Check for existing user
        const existingUser = await this.db.findByEmail(userData.email);
        if (existingUser) {
            throw new Error('Email already in use');
        }

        // Step 2: Create and save the new user
        const newUser = await this.db.save({
            email: userData.email,
            isActive: true, // New users are active by default
        });

        return newUser;
    }
}

// File: src/services/__tests__/userService.test.ts
import { UserService, MockDatabase } from '../userService';

/**
 * Test Suite for the UserService.
 * Describes a group of related tests for the user registration functionality.
 */
describe('UserService', () => {
    let userService: UserService;
    let mockDb: MockDatabase;

    // Setup: Run before each test to ensure a clean state
    beforeEach(() => {
        mockDb = new MockDatabase();
        userService = new UserService(mockDb);
    });

    /**
     * Test Case 1: Successful User Registration
     * Verifies that a new user can be registered successfully.
     */
    it('should register a new user successfully', async () => {
        // Arrange: Prepare the test data
        const userData = { email: 'test@example.com', password: 'password123' };

        // Act: Execute the method under test
        const registeredUser = await userService.registerUser(userData);

        // Assert: Verify the outcome
        expect(registeredUser).toBeDefined();
        expect(registeredUser.email).toBe(userData.email);
        expect(registeredUser.isActive).toBe(true);
        expect(registeredUser.id).toBeDefined();
        expect(registeredUser.createdAt).toBeInstanceOf(Date);
    });

    /**
     * Test Case 2: Registration with Duplicate Email
     * Verifies that the system correctly rejects registration with an existing email.
     */
    it('should throw an error when registering with an existing email', async () => {
        // Arrange: Register a user first
        const userData = { email: 'duplicate@example.com', password: 'password123' };
        await userService.registerUser(userData);

        // Act & Assert: Try to register the same email again and expect an error
        await expect(userService.registerUser(userData)).rejects.toThrow('Email already in use');
    });
});
