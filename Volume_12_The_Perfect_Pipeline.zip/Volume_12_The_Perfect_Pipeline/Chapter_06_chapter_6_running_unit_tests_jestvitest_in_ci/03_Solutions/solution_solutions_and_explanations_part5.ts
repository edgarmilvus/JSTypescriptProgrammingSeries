/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

// src/AsyncDataFetcher.test.tsx
import React from 'react';
import { render, screen, waitFor } from '@testing-library/react';
import { AsyncDataFetcher } from './AsyncDataFetcher';
import { rest } from 'msw';
import { setupServer } from 'msw/node';

const server = setupServer(
  rest.get('/api/success', (req, res, ctx) => {
    return res(ctx.json({ message: 'Hello World' }));
  }),
  rest.get('/api/error', (req, res, ctx) => {
    return res(ctx.status(500));
  })
);

beforeAll(() => server.listen());
afterEach(() => server.resetHandlers());
afterAll(() => server.close());

describe('AsyncDataFetcher', () => {
  it('renders loading state initially', () => {
    render(<AsyncDataFetcher endpoint="/api/success" />);
    expect(screen.getByText('Loading...')).toBeInTheDocument();
  });

  it('renders data message upon successful fetch', async () => {
    render(<AsyncDataFetcher endpoint="/api/success" />);
    // Using findBy* waits for the element to appear
    const messageElement = await screen.findByText('Hello World');
    expect(messageElement).toBeInTheDocument();
  });

  it('renders error message upon fetch failure', async () => {
    render(<AsyncDataFetcher endpoint="/api/error" />);
    const errorElement = await screen.findByText('Network response was not ok');
    expect(errorElement).toBeInTheDocument();
  });
});
