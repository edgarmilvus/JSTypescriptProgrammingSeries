/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part6.ts
// Description: Solutions and Explanations
// ==========================================

# .github/workflows/ai-test-review.yml
name: AI Test Review

on:
  pull_request:
    types: [opened, synchronize]

jobs:
  test-job:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
      - run: npm ci
      - run: npm test -- --coverage --coverageReporters="json-summary"

  ai-review:
    needs: test-job
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      
      - name: Generate AI Review
        id: ai-review
        uses: actions/github-script@v7
        with:
          script: |
            const fs = require('fs');
            const path = './coverage/coverage-summary.json';
            
            let commentBody = "## 🤖 AI Test Reliability Review\n\n";
            
            if (fs.existsSync(path)) {
              const coverage = JSON.parse(fs.readFileSync(path, 'utf8'));
              
              // Iterate over files in coverage report
              for (const [filePath, metrics] of Object.entries(coverage)) {
                if (filePath === 'total') continue;
                
                const branches = metrics.branches;
                if (branches.pct < 80) {
                  commentBody += `⚠️ **Low Branch Coverage:** \`${filePath}\` has only **${branches.pct}%** branch coverage.\n`;
                  commentBody += `   - *Suggestion:* Check for missing tests for error handling or conditional logic.\n\n`;
                }
              }
              
              if (commentBody === "## 🤖 AI Test Reliability Review\n\n") {
                commentBody += "✅ Great job! Coverage looks healthy across all modified files.";
              }
            } else {
              commentBody += "❌ Coverage report not found. Please ensure tests run with coverage enabled.";
            }

            // Post the comment
            github.rest.issues.createComment({
              issue_number: context.issue.number,
              owner: context.repo.owner,
              repo: context.repo.repo,
              body: commentBody
            });
