/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

// test/login.spec.ts
import { test, expect } from '@playwright/test';

/**
 * @description
 * A simple E2E test case for a SaaS login flow.
 * 
 * Context:
 * - 'test' is the main function provided by Playwright.
 * - 'page' is a browser tab provided by the test runner.
 */
test('should log in successfully and redirect to dashboard', async ({ page }) => {
  // 1. Navigate to the login page
  // We assume the app is running locally at localhost:3000
  await page.goto('http://localhost:3000/login');

  // 2. Fill in credentials
  // Locate the email input by its 'data-testid' attribute (best practice for stability)
  const emailInput = page.getByTestId('email-input');
  await emailInput.fill('user@example.com');

  // Locate the password input
  const passwordInput = page.getByTestId('password-input');
  await passwordInput.fill('secure_password_123');

  // 3. Submit the form
  // Locate the submit button and click it
  const submitButton = page.getByTestId('login-submit');
  await submitButton.click();

  // 4. Assertions
  // Wait for the navigation to complete and verify the URL
  await expect(page).toHaveURL(/.*\/dashboard/);

  // Verify that a specific element unique to the dashboard is visible
  const welcomeMessage = page.getByTestId('dashboard-welcome');
  await expect(welcomeMessage).toBeVisible();
  
  // Optional: Take a screenshot for debugging artifacts
  // This is saved to the 'test-results' folder by default
  await page.screenshot({ path: 'test-results/login-success.png' });
});
