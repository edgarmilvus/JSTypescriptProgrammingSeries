/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

/**
 * =============================================================================
 * PART 1: NEXT.JS APPLICATION (Simulated Client-Side Inference)
 * Location: pages/api/infer.ts
 * 
 * This API route simulates a local Transformer model running on the server.
 * In a real-world scenario, this might be a Web Worker handling a ONNX model
 * or a Python backend proxy. We simulate the latency and logic here.
 * =============================================================================
 */

import type { NextApiRequest, NextApiResponse } from 'next';

/**
 * Types for the Inference Payload
 * @typedef {Object} InferenceRequest
 * @property {string} text - The input text to classify.
 */
type InferenceRequest = {
  text: string;
};

/**
 * Types for the Inference Response
 * @typedef {Object} InferenceResponse
 * @property {string} label - The predicted class (e.g., 'Positive', 'Negative').
 * @property {number} confidence - The confidence score (0.0 to 1.0).
 * @property {string} processedIn - Simulated processing time.
 */
type InferenceResponse = {
  label: 'Positive' | 'Negative' | 'Neutral';
  confidence: number;
  processedIn: string;
};

/**
 * Mock Zero-Shot Classification Logic
 * In a real app, this would call a local model (e.g., via Transformers.js).
 * Here, we use simple keyword matching to simulate the inference.
 * 
 * @param {string} text - The text to analyze.
 * @returns {Promise<InferenceResponse>}
 */
const runLocalInference = async (text: string): Promise<InferenceResponse> => {
  // Simulate Headless Inference latency (model warm-up/processing)
  await new Promise((resolve) => setTimeout(resolve, 300));

  const lowerText = text.toLowerCase();
  
  // Simple heuristic-based classification (Mocking a Neural Network)
  if (lowerText.includes('great') || lowerText.includes('love') || lowerText.includes('fast')) {
    return { label: 'Positive', confidence: 0.95, processedIn: '300ms' };
  }
  if (lowerText.includes('bad') || lowerText.includes('slow') || lowerText.includes('bug')) {
    return { label: 'Negative', confidence: 0.92, processedIn: '300ms' };
  }
  
  return { label: 'Neutral', confidence: 0.50, processedIn: '300ms' };
};

/**
 * API Handler
 * @param {NextApiRequest} req
 * @param {NextApiResponse<InferenceResponse>} res
 */
export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse<InferenceResponse>
) {
  if (req.method !== 'POST') {
    // In a real app, handle error properly, but for E2E simplicity:
    res.status(405).end(); 
    return;
  }

  const { text } = req.body as InferenceRequest;

  if (!text || typeof text !== 'string') {
    res.status(400).json({ label: 'Neutral', confidence: 0, processedIn: '0ms' });
    return;
  }

  try {
    const result = await runLocalInference(text);
    // Return JSON response
    res.status(200).json(result);
  } catch (error) {
    res.status(500).json({ label: 'Neutral', confidence: 0, processedIn: '0ms' });
  }
}
