/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script_part2.ts
// Description: Advanced Application Script
// ==========================================

/**
 * =============================================================================
 * PART 2: PLAYWRIGHT E2E TEST SUITE
 * Location: tests/inference.spec.ts
 * 
 * This script runs in a Headless Node.js environment. It automates a browser
 * to test the "Happy Path" and "Edge Cases" of the Client-side Inference app.
 * =============================================================================
 */

import { test, expect } from '@playwright/test';

// Configuration for the test environment
const BASE_URL = process.env.BASE_URL || 'http://localhost:3000';

/**
 * TEST CASE 1: Positive Sentiment Inference
 * Objective: Verify the app correctly identifies a positive review using headless automation.
 * 
 * Steps:
 * 1. Navigate to the app.
 * 2. Locate the input field (using data-testid for resilience).
 * 3. Type a positive sentence.
 * 4. Click the "Analyze" button.
 * 5. Assert the DOM updates with the correct label and confidence.
 */
test.describe('SaaS AI Inference Engine - E2E', () => {
  test('should classify positive sentiment correctly', async ({ page }) => {
    // 1. Navigation
    await page.goto(BASE_URL);

    // 2. Input Selection & Interaction
    // We use Playwright's locator engine. 'data-testid' is preferred over CSS selectors
    // to decouple tests from styling changes.
    const inputLocator = page.getByTestId('inference-input');
    await inputLocator.fill('The product is great and the speed is amazing!');

    // 3. Execution
    const buttonLocator = page.getByTestId('analyze-btn');
    await buttonLocator.click();

    // 4. Assertion
    // Wait for the result container to be visible (handling async inference)
    const resultLabel = page.getByTestId('result-label');
    const resultConfidence = page.getByTestId('result-confidence');

    // Verify the text content matches expected inference
    await expect(resultLabel).toHaveText('Label: Positive');
    
    // Verify the confidence score is high (simulating model threshold)
    const confidenceText = await resultConfidence.textContent();
    expect(confidenceText).toContain('95%');
  });

  /**
   * TEST CASE 2: Negative Sentiment Inference
   * Objective: Verify the logic branch for negative inputs.
   */
  test('should classify negative sentiment correctly', async ({ page }) => {
    await page.goto(BASE_URL);

    const inputLocator = page.getByTestId('inference-input');
    // Simulating a user complaint
    await inputLocator.fill('The interface is slow and buggy.');

    await page.getByTestId('analyze-btn').click();

    const resultLabel = page.getByTestId('result-label');
    await expect(resultLabel).toHaveText('Label: Negative');
  });

  /**
   * TEST CASE 3: Visual Regression & Artifact Capture
   * Objective: Capture artifacts (screenshot/trace) for debugging CI failures.
   * This is crucial for Headless environments where you cannot "see" the failure.
   */
  test('should render the UI correctly and capture artifacts', async ({ page }) => {
    await page.goto(BASE_URL);

    // Capture a screenshot of the initial state
    // In CI, these are uploaded as build artifacts
    await page.screenshot({ path: 'test-results/initial-state.png', fullPage: true });

    // Perform an action
    await page.getByTestId('inference-input').fill('Testing artifact capture');
    await page.getByTestId('analyze-btn').click();

    // Wait for loading state to finish (if any)
    await page.waitForTimeout(500);

    // Capture the final state
    await page.screenshot({ path: 'test-results/final-state.png', fullPage: true });
  });
});
