/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// journey.spec.ts
import { test, expect } from '@playwright/test';

test.describe('User Journey Smoke Test', () => {
  // Hook to capture screenshot on failure
  test.afterEach(async ({ page }, testInfo) => {
    if (testInfo.status !== testInfo.expectedStatus) {
      // Save screenshot to test-results directory
      await page.screenshot({ path: `test-results/${testInfo.title}.png`, fullPage: true });
    }
  });

  test('should navigate from homepage to pricing via Get Started button', async ({ page }) => {
    // 1. Navigate to the homepage
    // Note: Using a placeholder URL. Replace with your actual local server URL.
    await page.goto('http://localhost:3000');

    // 2. Locate and click the "Get Started" button
    // Strategy: Using text content. If a data-testid exists, prefer: page.getByTestId('get-started-btn')
    const getStartedButton = page.getByRole('button', { name: /get started/i });
    await expect(getStartedButton).toBeVisible();
    await getStartedButton.click();

    // 3. Assert the URL contains '/pricing'
    // Using regex for flexibility (e.g., handles query params)
    await expect(page).toHaveURL(/.*\/pricing/);

    // 4. Assert the visible heading exists
    const heading = page.getByRole('heading', { name: 'Pricing Plans' });
    await expect(heading).toBeVisible();
  });
});
