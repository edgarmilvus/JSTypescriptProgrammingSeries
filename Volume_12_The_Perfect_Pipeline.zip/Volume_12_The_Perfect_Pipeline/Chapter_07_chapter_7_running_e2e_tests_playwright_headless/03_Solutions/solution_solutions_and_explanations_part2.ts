/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

// 1. global-setup.ts
import { chromium, type FullConfig } from '@playwright/test';

async function globalSetup(config: FullConfig) {
  const { baseURL } = config.projects[0].use;
  const browser = await chromium.launch();
  const page = await browser.newPage();

  // Navigate to login page
  await page.goto(`${baseURL}/login`);

  // Perform Login (Replace selectors with actual app selectors)
  await page.fill('input[name="username"]', 'alice');
  await page.fill('input[name="password"]', 'secret-password');
  await page.click('button[type="submit"]');

  // Wait for navigation to dashboard or success indicator
  await page.waitForURL(`${baseURL}/dashboard`);

  // Save storage state to a file
  await page.context().storageState({ path: './auth/user.json' });

  await browser.close();
}

export default globalSetup;

// 2. dashboard.spec.ts
import { test, expect } from '@playwright/test';

// Use the authenticated project defined in config
test.use({ storageState: './auth/user.json' });

test.describe('Authenticated Dashboard', () => {
  test('should display user specific content', async ({ page }) => {
    // Navigate directly to dashboard
    await page.goto('/dashboard');

    // Assert welcome message
    const welcomeMsg = page.getByText('Welcome, Alice');
    await expect(welcomeMsg).toBeVisible();

    // Assert profile icon is visible
    const profileIcon = page.locator('.profile-icon');
    await expect(profileIcon).toBeVisible();
  });
});
