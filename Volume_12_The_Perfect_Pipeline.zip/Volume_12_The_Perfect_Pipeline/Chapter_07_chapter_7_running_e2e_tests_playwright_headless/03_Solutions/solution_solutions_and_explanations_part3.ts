/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

// visual-regression.spec.ts
import { test, expect } from '@playwright/test';

test.describe('Visual Regression Tests', () => {
  // Technique to reduce flakiness: Hide dynamic elements (like cookie banners or timestamps)
  // before taking the snapshot.
  const hideDynamicElements = async (page) => {
    // Example: Hide a cookie banner if it exists
    const cookieBanner = page.locator('#cookie-banner');
    if (await cookieBanner.isVisible()) {
      await cookieBanner.evaluate((el) => el.style.display = 'none');
    }
  };

  test('homepage should look correct on desktop', async ({ page }) => {
    // Set viewport for desktop
    await page.setViewportSize({ width: 1280, height: 720 });
    
    await page.goto('/');
    await hideDynamicElements(page);

    // Wait for network idle to ensure fonts/images are loaded
    await page.waitForLoadState('networkidle');

    // Compare snapshot
    await expect(page).toHaveScreenshot('homepage-desktop.png', {
      fullPage: true,
      // Threshold allows for minor antialiasing differences
      maxDiffPixelRatio: 0.02 
    });
  });

  test('homepage should look correct on mobile', async ({ page }) => {
    // Set viewport for mobile
    await page.setViewportSize({ width: 375, height: 667 });
    
    await page.goto('/');
    await hideDynamicElements(page);
    
    // Wait for network idle
    await page.waitForLoadState('networkidle');

    // Compare snapshot
    await expect(page).toHaveScreenshot('homepage-mobile.png', {
      fullPage: true,
      maxDiffPixelRatio: 0.02
    });
  });
});
