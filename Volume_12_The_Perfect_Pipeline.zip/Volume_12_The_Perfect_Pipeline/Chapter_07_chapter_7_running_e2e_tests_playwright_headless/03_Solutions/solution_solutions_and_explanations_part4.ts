/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

// ai-categorizer.spec.ts
import { test, expect } from '@playwright/test';

test.describe('AI Task Categorizer', () => {
  test('should show loading state and result on success', async ({ page }) => {
    await page.goto('/task-manager');

    // 1. Input task description
    const input = page.locator('#task-input');
    await input.fill('Prepare quarterly financial report');

    // 2. Click Suggest Category
    const suggestBtn = page.getByRole('button', { name: 'Suggest Category' });
    await suggestBtn.click();

    // 3. Assertion: Loading State
    // Check button is disabled or text changes
    await expect(suggestBtn).toBeDisabled();
    // Or if text changes: await expect(suggestBtn).toHaveText('Analyzing...');

    // 4. Assertion: Result
    // Wait for the category tag to appear with a 5s timeout
    const categoryTag = page.locator('.category-tag');
    await expect(categoryTag).toBeVisible({ timeout: 5000 });
    
    // Verify content is one of the expected categories
    const text = await categoryTag.textContent();
    expect(['Work', 'Personal', 'Urgent']).toContain(text);

    // 5. Assertion: Button returns to active state
    await expect(suggestBtn).toBeEnabled();
  });

  test('should handle inference failure gracefully', async ({ page }) => {
    // To test failure, we need to intercept the internal model call or mock the API.
    // Assuming the app has a mock utility or we intercept a specific route.
    
    // Route interception to simulate server error (if the model uses a fetch call internally)
    await page.route('**/api/suggest-category', async (route) => {
      await route.abort('failed'); // Simulate network failure
    });

    await page.goto('/task-manager');
    await page.locator('#task-input').fill('Some task');
    
    const suggestBtn = page.getByRole('button', { name: 'Suggest Category' });
    await suggestBtn.click();

    // Wait for error message
    const errorMsg = page.locator('.error-message');
    await expect(errorMsg).toBeVisible();
    await expect(errorMsg).toHaveText('Could not suggest a category. Please try again.');

    // Verify button is active again
    await expect(suggestBtn).toBeEnabled();
  });
});
