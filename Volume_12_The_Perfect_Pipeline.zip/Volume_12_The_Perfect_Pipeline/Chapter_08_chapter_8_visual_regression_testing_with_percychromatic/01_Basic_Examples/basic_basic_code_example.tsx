/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.tsx
// Description: Basic Code Example
// ==========================================

// File: src/components/DashboardCard.tsx
import React from 'react';

/**
 * Props for the DashboardCard component.
 * @typedef {Object} DashboardCardProps
 * @property {string} title - The title of the card.
 * @property {string} value - The metric value to display.
 * @property {string} [color] - Optional color for the value text.
 */
interface DashboardCardProps {
  title: string;
  value: string;
  color?: string;
}

/**
 * A simple dashboard card component for visual regression testing.
 * This component represents a typical UI element in a SaaS analytics dashboard.
 */
export const DashboardCard: React.FC<DashboardCardProps> = ({ title, value, color = 'black' }) => {
  return (
    <div style={{ 
      border: '1px solid #e0e0e0', 
      borderRadius: '8px', 
      padding: '16px', 
      width: '250px',
      boxShadow: '0 2px 4px rgba(0,0,0,0.1)'
    }}>
      <h3 style={{ margin: 0, color: '#666', fontSize: '14px', textTransform: 'uppercase' }}>
        {title}
      </h3>
      <p style={{ margin: '8px 0 0 0', fontSize: '24px', fontWeight: 'bold', color: color }}>
        {value}
      </p>
    </div>
  );
};
