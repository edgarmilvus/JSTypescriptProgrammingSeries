/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.ts
// Description: Basic Code Example
// ==========================================

// File: src/components/DashboardCard.stories.tsx
import React from 'react';
import { StoryObj, Meta } from '@storybook/react';
import { DashboardCard } from './DashboardCard';

/**
 * Meta configuration for the DashboardCard component.
 * This object configures how Storybook renders the component and
 * sets up the parameters for Chromatic visual testing.
 */
const meta: Meta<typeof DashboardCard> = {
  title: 'SaaS Components/DashboardCard',
  component: DashboardCard,
  parameters: {
    // Chromatic specific parameters
    chromatic: { 
      delay: 300, // Wait for fonts/animations to settle
      viewports: [320, 1200] // Test on mobile and desktop widths
    }
  }
};

export default meta;
type Story = StoryObj<typeof DashboardCard>;

/**
 * Default story representing the standard state of the DashboardCard.
 * This will serve as the baseline for visual regression testing.
 */
export const Default: Story = {
  args: {
    title: 'Total Revenue',
    value: '$12,450',
    color: '#22c55e' // Green text
  }
};

/**
 * Story with a different value to test text overflow or layout changes.
 * This helps catch issues where long text might break the UI.
 */
export const LongText: Story = {
  args: {
    title: 'Monthly Recurring Revenue (MRR)',
    value: '$124,500.00',
    color: '#3b82f6'
  }
};
