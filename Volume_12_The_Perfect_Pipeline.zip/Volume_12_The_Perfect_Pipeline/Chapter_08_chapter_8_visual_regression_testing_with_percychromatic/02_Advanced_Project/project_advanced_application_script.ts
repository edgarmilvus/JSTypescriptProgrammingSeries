/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// app/actions/visual-regression.action.ts

'use server';

import { z } from 'zod';
import { chromaticApi } from '@/lib/chromatic-client'; // Hypothetical API client wrapper

/**
 * @fileoverview Visual Regression Analysis Server Action.
 * Handles the retrieval and AI-powered analysis of visual diffs from Chromatic.
 * This runs exclusively on the server to protect API keys and perform heavy computations.
 */

// 1. INPUT VALIDATION
// We strictly define the expected payload from our CI pipeline or frontend trigger.
const VisualReviewSchema = z.object({
  buildId: z.string().min(1, "Chromatic Build ID is required"),
  projectId: z.string().min(1, "Chromatic Project ID is required"),
  threshold: z.number().min(0).max(1).default(0.05), // 5% pixel change tolerance
});

type VisualReviewInput = z.infer<typeof VisualReviewSchema>;

// 2. DATA STRUCTURES
// Interfaces for the response sent back to the client or GitHub PR.
interface AnalysisResult {
  status: 'success' | 'failure' | 'manual-review';
  summary: string;
  diffs: Array<{
    component: string;
    changeType: 'layout' | 'color' | 'content' | 'unknown';
    severity: 'low' | 'medium' | 'high';
    aiDescription: string; // Simulated AI output
  }>;
}

/**
 * Server Action: analyzeVisualDiffs
 * 
 * 1. Validates input.
 * 2. Fetches build details and visual diffs from Chromatic.
 * 3. Analyzes diff metadata (pixel percentage, bounding boxes) to categorize changes.
 * 4. Returns a structured analysis report.
 * 
 * @param input - Object containing buildId, projectId, and optional threshold.
 * @returns Promise<AnalysisResult> - The detailed report.
 */
export async function analyzeVisualDiffs(
  input: VisualReviewInput
): Promise<AnalysisResult> {
  // Step 1: Validate Inputs
  const parsed = VisualReviewSchema.safeParse(input);
  if (!parsed.success) {
    throw new Error(`Invalid input: ${JSON.stringify(parsed.error.errors)}`);
  }
  const { buildId, projectId, threshold } = parsed.data;

  try {
    // Step 2: Fetch Build Data from Chromatic API
    // In a real scenario, this uses the official 'chromatic' npm package or REST API.
    // We simulate fetching the list of components that changed in this build.
    const buildData = await chromaticApi.getBuild(buildId, projectId);
    
    if (buildData.status !== 'passed' && buildData.status !== 'pending') {
      return {
        status: 'failure',
        summary: 'Build failed before visual comparison.',
        diffs: [],
      };
    }

    // Step 3: Retrieve Visual Diff Information
    // We fetch the "visual diffs" which contain pixel change percentages and 
    // snapshot IDs. This is where we would typically get bounding box data.
    const diffs = await chromaticApi.getVisualDiffs(buildId);

    // Step 4: AI-Powered Analysis Simulation
    // We iterate through diffs and apply logic to categorize the change.
    // In a production environment, this might call an LLM (like GPT-4 Vision)
    // or use computer vision libraries (like OpenCV) to detect specific element shifts.
    const analyzedDiffs = diffs.map((diff) => {
      const changePercentage = diff.pixelDifferencePercentage;
      
      // Heuristic Logic (Simulating AI)
      let changeType: AnalysisResult['diffs'][0]['changeType'] = 'unknown';
      let severity: AnalysisResult['diffs'][0]['severity'] = 'low';
      let description = '';

      if (changePercentage < threshold) {
        description = "Negligible change detected. Likely anti-aliasing differences.";
        severity = 'low';
      } else {
        // Advanced: Analyze metadata if available (e.g., bounding box changes)
        // If the bounding box center shifted significantly, it's a layout shift.
        if (diff.boundingBoxChange && diff.boundingBoxChange.shift > 5) {
          changeType = 'layout';
          severity = 'high';
          description = `Critical Layout Shift: Element moved ${diff.boundingBoxChange.shift}px vertically.`;
        } else if (diff.colorChangeScore > 0.8) {
          changeType = 'color';
          severity = 'medium';
          description = `Color Palette Update: Background or text color detected.`;
        } else {
          changeType = 'content';
          severity = 'medium';
          description = `Content Change: Text or image replacement detected.`;
        }
      }

      return {
        component: diff.componentName,
        changeType,
        severity,
        aiDescription: description,
      };
    });

    // Step 5: Determine Overall Status
    const hasHighSeverity = analyzedDiffs.some(d => d.severity === 'high');
    const status = hasHighSeverity ? 'manual-review' : 'success';
    
    const summary = hasHighSeverity 
      ? `Analysis complete. ${analyzedDiffs.length} diffs found. Requires manual review due to layout shifts.` 
      : `Analysis complete. All visual changes within acceptable thresholds or are cosmetic.`;

    return {
      status,
      summary,
      diffs: analyzedDiffs,
    };

  } catch (error) {
    console.error("Error analyzing visual diffs:", error);
    return {
      status: 'failure',
      summary: 'Failed to retrieve or analyze visual data from provider.',
      diffs: [],
    };
  }
}

/**
 * Helper: Format Analysis for GitHub PR Comment
 * This utility transforms the AnalysisResult into a Markdown string.
 * It is typically called by a separate webhook handler after analysis completes.
 */
export function formatPrComment(result: AnalysisResult): string {
  if (result.diffs.length === 0) return "## 🎨 Visual Regression Test\nNo visual changes detected.";

  const diffList = result.diffs.map(diff => {
    const emoji = diff.severity === 'high' ? '🔴' : diff.severity === 'medium' ? '🟡' : '🟢';
    return `- ${emoji} **${diff.component}**: ${diff.aiDescription} (${diff.changeType})`;
  }).join('\n');

  return `## 🎨 Visual Regression Analysis
**Status:** ${result.status.toUpperCase()}
**Summary:** ${result.summary}

### Detected Changes
${diffList}

> _Analysis generated by Next.js Server Action using Chromatic metadata._`;
}
