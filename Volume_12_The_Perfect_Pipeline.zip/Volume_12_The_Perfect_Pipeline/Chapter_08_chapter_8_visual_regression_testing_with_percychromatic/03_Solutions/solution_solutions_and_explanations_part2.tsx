/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.tsx
// Description: Solutions and Explanations
// ==========================================

// src/components/ProductCard/ProductCard.tsx (Updated)
import React from 'react';
import styles from './ProductCard.module.css';

interface ProductCardProps {
  title: string;
  price: number;
  imageUrl: string;
  isOnSale?: boolean; // New optional prop
}

export const ProductCard: React.FC<ProductCardProps> = ({ 
  title, 
  price, 
  imageUrl, 
  isOnSale = false 
}) => {
  return (
    <div className={styles.card} data-testid="product-card">
      <img src={imageUrl} alt={title} className={styles.image} />
      <div className={styles.content}>
        <h3 className={styles.title}>{title}</h3>
        
        {/* Price Container with Flexbox */}
        <div className={styles.priceContainer}>
          <p className={styles.price}>${price.toFixed(2)}</p>
          {isOnSale && <span className={styles.badge}>SALE</span>}
        </div>

        <button className={styles.button}>Add to Cart</button>
      </div>
    </div>
  );
};

// src/components/ProductCard/ProductCard.module.css (Updated)
.priceContainer {
  display: flex;
  align-items: center;
  gap: 8px; /* Ensures consistent spacing between price and badge */
  margin-bottom: 16px;
  min-height: 24px; /* Prevents collapse when badge is missing */
}

.badge {
  background-color: #dc3545;
  color: white;
  font-size: 0.75rem;
  padding: 2px 6px;
  border-radius: 4px;
  font-weight: bold;
  text-transform: uppercase;
}

/* Storybook Stories for Scenarios */
export const Standard = () => (
  <ProductCard
    title="Standard Item"
    price={50.00}
    imageUrl="https://via.placeholder.com/300x200"
  />
);

export const OnSale = () => (
  <ProductCard
    title="Sale Item"
    price={40.00}
    imageUrl="https://via.placeholder.com/300x200"
    isOnSale={true}
  />
);
