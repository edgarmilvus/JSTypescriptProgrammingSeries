/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

// src/components/ProductCard/ProductCard.tsx (With Interaction)
import React, { useState, useTransition } from 'react';
import styles from './ProductCard.module.css';

// Mock Spinner Component
const Spinner = () => <span className={styles.spinner}>Loading...</span>;

export const ProductCardWithTransition = () => {
  const [isPending, startTransition] = useTransition();
  const [count, setCount] = useState(0);

  const handleClick = () => {
    startTransition(() => {
      // Simulate async action
      return new Promise(resolve => setTimeout(resolve, 2000));
    });
  };

  return (
    <div className={styles.card}>
      <div className={styles.content}>
        <h3 className={styles.title}>Interactive Product</h3>
        <button 
          disabled={isPending} 
          onClick={handleClick}
          className={`${styles.button} ${isPending ? styles.pending : ''}`}
          data-testid="add-to-cart-btn"
        >
          {isPending ? <Spinner /> : 'Add to Cart'}
        </button>
      </div>
    </div>
  );
};

// ProductCard.module.css (Additions)
.pending {
  opacity: 0.7;
  cursor: not-allowed;
}

.spinner {
  display: inline-block;
  width: 1em;
  height: 1em;
  border: 2px solid rgba(255,255,255,0.3);
  border-radius: 50%;
  border-top-color: #fff;
  animation: spin 1s ease-in-out infinite;
}

@keyframes spin {
  to { transform: rotate(360deg); }
}

// Visual Test File (e.g., ProductCard.test.tsx using Jest + Testing Library)
import { render, screen, fireEvent } from '@testing-library/react';
import { ProductCardWithTransition } from './ProductCard';
import { act } from 'react-dom/test-utils';

// Mock timers for deterministic testing
jest.useFakeTimers();

test('visualizes the pending state correctly', () => {
  const { container } = render(<ProductCardWithTransition />);
  const button = screen.getByTestId('add-to-cart-btn');

  // 1. Simulate click
  fireEvent.click(button);

  // 2. Advance timers to trigger the state update inside useTransition
  act(() => {
    jest.advanceTimersByTime(100); // Advance past the initial render cycle
  });

  // 3. Verify the loading state is active
  expect(button).toBeDisabled();
  expect(screen.getByText('Loading...')).toBeInTheDocument();
  
  // At this point, a visual snapshot tool (like Percy/Jest) would capture the DOM
  // console.log(container.innerHTML); // Visual snapshot would occur here
});
