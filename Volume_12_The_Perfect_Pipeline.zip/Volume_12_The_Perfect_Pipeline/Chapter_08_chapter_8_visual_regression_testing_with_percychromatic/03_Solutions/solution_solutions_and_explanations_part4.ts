/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

// src/components/ProductCard/ProductCard.tsx (Reused from Exercise 2)
// We assume the component with the 'isOnSale' prop is used here.

// .github/workflows/ci.yml
name: Cross-Browser Visual Tests
on: [push, pull_request]

jobs:
  visual-test-matrix:
    runs-on: ubuntu-latest
    strategy:
      matrix:
        # Define the browsers to test against
        browser: [chrome, firefox]
    steps:
      - name: Checkout Code
        uses: actions/checkout@v3
        with:
          fetch-depth: 0 # Required by Chromatic for baseline comparison

      - name: Setup Node.js
        uses: actions/setup-node@v3
        with:
          node-version: '18'
          cache: 'npm'

      - name: Install Dependencies
        run: npm ci

      - name: Run Visual Tests
        # This command simulates running the visual build for the specific matrix browser.
        # In a real scenario with Chromatic, you might use the '--only-changed' flag 
        # or specific environment variables to target the browser.
        run: |
          echo "Running visual build for ${{ matrix.browser }}"
          # Example command structure (pseudocode for the service):
          # npm run chromatic -- --project-token=${{ secrets.CHROMATIC_TOKEN }} \
          # --browser=${{ matrix.browser }} \
          # --storybook-build-dir=./storybook-static
          
      - name: Upload Report
        if: failure()
        uses: actions/upload-artifact@v3
        with:
          name: visual-report-${{ matrix.browser }}
          path: chromatic-diagnostics.json # Or relevant report file
