/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

// scripts/analyze-diffs.ts
import * as fs from 'fs';
import * as path from 'path';

// Define the structure of the element data we expect from the report
interface ElementDiff {
  id: string;
  boundingBox: {
    width: number;
    height: number;
    x: number;
    y: number;
  };
  baselineBoundingBox: {
    width: number;
    height: number;
    x: number;
    y: number;
  };
}

interface DiffReport {
  elements: ElementDiff[];
}

/**
 * Analyzes visual diffs for critical layout shifts.
 * A critical shift is defined as a change in width or height > 1px.
 */
function analyzeVisualDiffs(report: DiffReport): string[] {
  const criticalIssues: string[] = [];
  const SHIFT_THRESHOLD = 1; // Pixel threshold

  report.elements.forEach((el) => {
    const widthDiff = Math.abs(el.boundingBox.width - el.baselineBoundingBox.width);
    const heightDiff = Math.abs(el.boundingBox.height - el.baselineBoundingBox.height);

    // Check for width shift
    if (widthDiff > SHIFT_THRESHOLD) {
      criticalIssues.push(
        `CRITICAL: Element '${el.id}' width shifted by ${widthDiff.toFixed(2)}px (Baseline: ${el.baselineBoundingBox.width}px, Current: ${el.boundingBox.width}px)`
      );
    }

    // Check for height shift
    if (heightDiff > SHIFT_THRESHOLD) {
      criticalIssues.push(
        `CRITICAL: Element '${el.id}' height shifted by ${heightDiff.toFixed(2)}px (Baseline: ${el.baselineBoundingBox.height}px, Current: ${el.boundingBox.height}px)`
      );
    }
  });

  return criticalIssues;
}

// Main execution logic
function main() {
  // In a real scenario, this path would be an output from the visual testing service
  const reportPath = path.join(__dirname, '../mock-visual-report.json');
  
  // Check if file exists, if not, exit gracefully (for demo purposes)
  if (!fs.existsSync(reportPath)) {
    console.log("No visual report found. Skipping analysis.");
    process.exit(0);
  }

  const rawData = fs.readFileSync(reportPath, 'utf-8');
  const report: DiffReport = JSON.parse(rawData);

  console.log("🔍 Analyzing visual diffs for layout shifts...");
  const issues = analyzeVisualDiffs(report);

  if (issues.length > 0) {
    console.error("\n❌ Critical Layout Shifts Detected:");
    issues.forEach((issue) => console.error(`   - ${issue}`));
    
    // Generate JSON report
    fs.writeFileSync('ai-report.json', JSON.stringify({ issues, severity: 'HIGH' }, null, 2));
    
    // Fail the build
    process.exit(1);
  } else {
    console.log("✅ No critical layout shifts detected.");
    fs.writeFileSync('ai-report.json', JSON.stringify({ issues: [], severity: 'NONE' }, null, 2));
    process.exit(0);
  }
}

main();
