/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * @fileoverview A "Hello World" example of a multi-agent PR review system.
 * This file simulates a Supervisor Node coordinating a Worker Agent Pool
 * to perform automated code reviews.
 */

// --- 1. TYPE DEFINITIONS ---

/**
 * Represents the input context for a PR review.
 * @typedef {Object} PRContext
 * @property {string} prId - The unique identifier for the Pull Request.
 * @property {string} codeSnippet - The code changes to be reviewed.
 * @property {string} description - The PR description provided by the developer.
 */
type PRContext = {
    prId: string;
    codeSnippet: string;
    description: string;
};

/**
 * Represents a finding from an agent. A collection of these forms a review report.
 * @typedef {Object} ReviewFinding
 * @property {'style' | 'security' | 'info'} category - The category of the finding.
 * @property {string} message - A descriptive message for the developer.
 * @property {number} severity - A score from 1 (low) to 5 (critical).
 */
type ReviewFinding = {
    category: 'style' | 'security' | 'info';
    message: string;
    severity: number;
};

/**
 * The standardized output format from any worker agent.
 * @typedef {Object} AgentReport
 * @property {string} agentName - The name of the agent that generated the report.
 * @property {string} prId - The PR this report pertains to.
 * @property {ReviewFinding[]} findings - A list of issues detected by the agent.
 */
type AgentReport = {
    agentName: string;
    prId: string;
    findings: ReviewFinding[];
};

// --- 2. WORKER AGENT POOL ---

/**
 * Simulates the StyleCheckerAgent.
 * This agent focuses on code quality, formatting, and best practices.
 * In a real-world scenario, this would use an LLM or a linter like ESLint.
 */
class StyleCheckerAgent {
    public readonly name = 'StyleCheckerAgent';

    /**
     * Analyzes code for style violations.
     * NOTE: This is an async function to simulate network latency (calling an LLM API).
     */
    public async review(ctx: PRContext): Promise<AgentReport> {
        console.log(`[${this.name}] Starting review for PR #${ctx.prId}...`);

        // Simulate an asynchronous tool call (e.g., API request to an LLM)
        await new Promise(resolve => setTimeout(resolve, 500)); // Simulate 500ms delay

        const findings: ReviewFinding[] = [];

        // Basic heuristic simulation
        if (ctx.codeSnippet.includes('var ')) {
            findings.push({
                category: 'style',
                message: 'Use of "var" is discouraged. Use "const" or "let".',
                severity: 2
            });
        }
        if (ctx.codeSnippet.includes('  ')) { // Simple check for double spaces
            findings.push({
                category: 'style',
                message: 'Inconsistent indentation detected. Use 4 spaces.',
                severity: 1
            });
        }

        console.log(`[${this.name}] Finished review for PR #${ctx.prId}.`);
        return {
            agentName: this.name,
            prId: ctx.prId,
            findings: findings.length > 0 ? findings : [{ category: 'info', message: 'No style issues found.', severity: 0 }]
        };
    }
}

/**
 * Simulates the SecurityVulnerabilityAgent.
 * This agent focuses on identifying potential security risks.
 */
class SecurityVulnerabilityAgent {
    public readonly name = 'SecurityVulnerabilityAgent';

    /**
     * Scans code for security vulnerabilities.
     * NOTE: This is an async function to simulate network latency.
     */
    public async review(ctx: PRContext): Promise<AgentReport> {
        console.log(`[${this.name}] Starting security scan for PR #${ctx.prId}...`);

        // Simulate an asynchronous tool call (e.g., API request to a security scanning service)
        await new Promise(resolve => setTimeout(resolve, 800)); // Simulate 800ms delay

        const findings: ReviewFinding[] = [];

        // Basic heuristic simulation
        if (ctx.codeSnippet.includes('password')) {
            findings.push({
                category: 'security',
                message: 'Potential hardcoded password or secret detected.',
                severity: 5
            });
        }
        if (ctx.codeSnippet.includes('eval(')) {
            findings.push({
                category: 'security',
                message: 'Use of "eval()" is a critical security vulnerability.',
                severity: 5
            });
        }

        console.log(`[${this.name}] Finished security scan for PR #${ctx.prId}.`);
        return {
            agentName: this.name,
            prId: ctx.prId,
            findings: findings.length > 0 ? findings : [{ category: 'info', message: 'No critical vulnerabilities detected.', severity: 0 }]
        };
    }
}

// --- 3. SUPERVISOR NODE & CONSENSUS MECHANISM ---

/**
 * The Supervisor Node orchestrates the review process.
 * It manages the worker agents and performs the consensus mechanism.
 */
class SupervisorNode {
    private agents: (StyleCheckerAgent | SecurityVulnerabilityAgent)[];

    constructor() {
        // Initialize the Worker Agent Pool
        this.agents = [
            new StyleCheckerAgent(),
            new SecurityVulnerabilityAgent()
        ];
    }

    /**
     * The main entry point for the Supervisor.
     * It dispatches tasks to agents and synthesizes the final report.
     * @param {PRContext} ctx - The PR context.
     * @returns {Promise<string>} - The final, human-readable review report.
     */
    public async processPullRequest(ctx: PRContext): Promise<string> {
        console.log(`\n[Supervisor] Received new PR #${ctx.prId}. Dispatching to worker pool...`);

        // --- ASYNCHRONOUS TOOL HANDLING ---
        // We use Promise.all to run agent reviews in parallel for efficiency.
        // This is a critical pattern for non-blocking execution in Node.js.
        const agentPromises = this.agents.map(agent => agent.review(ctx));
        
        // Await all worker agents to complete their tasks
        const agentReports: AgentReport[] = await Promise.all(agentPromises);

        // --- CONSENSUS MECHANISM ---
        // The Supervisor acts as the "Reviewer Node" here. It compares, filters,
        // and synthesizes the raw reports into a single, actionable summary.
        const finalReview = this.synthesizeReports(agentReports);

        return finalReview;
    }

    /**
     * Compiles multiple agent reports into a single, prioritized summary.
     * This is a simple implementation of the Consensus Mechanism pattern.
     * @param {AgentReport[]} reports - An array of reports from the worker pool.
     * @returns {string} - A formatted, human-readable string.
     */
    private synthesizeReports(reports: AgentReport[]): string {
        let output = `--- Automated PR Review Summary ---\n`;
        output += `Generated by Supervisor Node\n\n`;

        let criticalIssues = 0;
        let totalFindings = 0;

        // Sort findings by severity to prioritize critical issues
        const allFindings = reports.flatMap(r => r.findings);
        allFindings.sort((a, b) => b.severity - a.severity);

        if (allFindings.length === 0 || (allFindings.length === 1 && allFindings[0].severity === 0)) {
            output += `✅ All checks passed! No issues found.\n`;
            return output;
        }

        for (const finding of allFindings) {
            totalFindings++;
            const severityIcon = finding.severity >= 5 ? '🔴' : (finding.severity >= 3 ? '🟡' : '🔵');
            output += `${severityIcon} [${finding.category.toUpperCase()}] (Sev: ${finding.severity})\n`;
            output += `   - ${finding.message}\n\n`;
            if (finding.severity >= 5) criticalIssues++;
        }

        output += `--- Summary ---\n`;
        output += `Total Findings: ${totalFindings}\n`;
        output += `Critical Issues (Sev 5): ${criticalIssues}\n`;
        
        if (criticalIssues > 0) {
            output += `\n⚠️ ACTION REQUIRED: Please address critical issues before merging.\n`;
        }

        return output;
    }
}

// --- 4. MAIN EXECUTION (SIMULATION) ---

/**
 * Main function to run the simulation.
 * It represents a developer pushing a new PR to the SaaS platform.
 */
async function main() {
    // SCENARIO 1: A PR with both style and security issues
    const badPR: PRContext = {
        prId: 'PR-402',
        description: 'Feat: Add new user login endpoint',
        codeSnippet: `
            function login(req, res) {
                var user = req.body.username; // Bad practice
                const password = "secret123"; // Security risk!
                eval("console.log('Authenticating ' + user)"); // Critical vulnerability
            }
        `
    };

    // SCENARIO 2: A "clean" PR
    const goodPR: PRContext = {
        prId: 'PR-403',
        description: 'Fix: Update documentation',
        codeSnippet: `
            function updateDocs() {
                const newContent = "Updated README";
                console.log(newContent);
            }
        `
    };

    // Initialize the Supervisor
    const supervisor = new SupervisorNode();

    // Process the bad PR
    console.log('=================================================');
    console.log('SIMULATION START: Processing a problematic PR...');
    console.log('=================================================');
    const review1 = await supervisor.processPullRequest(badPR);
    console.log(review1);

    // Process the good PR
    console.log('\n=================================================');
    console.log('SIMULATION START: Processing a clean PR...');
    console.log('=================================================');
    const review2 = await supervisor.processPullRequest(goodPR);
    console.log(review2);
}

// Run the main function
if (require.main === module) {
    main().catch(error => {
        console.error("An unhandled error occurred in the simulation:", error);
        process.exit(1);
    });
}
