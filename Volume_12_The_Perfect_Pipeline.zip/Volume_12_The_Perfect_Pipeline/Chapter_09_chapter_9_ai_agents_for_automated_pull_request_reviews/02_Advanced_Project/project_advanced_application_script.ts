/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// pages/api/review-pr.ts
// Next.js API Route Handler
import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';

// ==========================================
// 1. TYPE DEFINITIONS & SCHEMAS
// ==========================================

/**
 * Represents the state of our review agent.
 * Using Zod for runtime validation is critical because data coming from
 * external webhooks or APIs cannot be trusted implicitly.
 */
const PRStateSchema = z.object({
  prId: z.string().uuid(),
  diff: z.string().min(1, "Diff cannot be empty"),
  author: z.string(),
  reviewComments: z.array(z.object({
    line: z.number(),
    comment: z.string(),
    severity: z.enum(["low", "high"])
  })),
  status: z.enum(["pending", "analyzed", "failed"])
});

type PRState = z.infer<typeof PRStateSchema>;

/**
 * Simulated API Response for fetching code diffs.
 */
interface ExternalDiffAPIResponse {
  content: string;
  sha: string;
}

// ==========================================
// 2. ASYNCHRONOUS TOOL HANDLERS
// ==========================================

/**
 * Simulates fetching a PR diff from an external source (e.g., GitHub API).
 * 
 * CRITICAL: This function returns a Promise. In a real-world scenario, 
 * this involves `fetch()`. We wrap it to demonstrate Asynchronous Tool Handling.
 * The caller must `await` this to prevent race conditions.
 */
async function fetchPRDiff(prId: string): Promise<ExternalDiffAPIResponse> {
  console.log(`[Tool] Fetching diff for PR #${prId}...`);
  
  // Simulate network latency (Non-Blocking I/O simulation)
  await new Promise(resolve => setTimeout(resolve, 500));

  // Mock data representing a code change
  return {
    content: `
      - const secret = "password123";
      + const secret = process.env.SECRET_KEY;
      
      - function calculateTotal(a, b) { return a + b; }
      + function calculateTotal(a: number, b: number): number { return a + b; }
    `,
    sha: "abc123def456"
  };
}

/**
 * Simulates an AI Code Review analysis.
 * In a real app, this would call an LLM API (e.g., OpenAI, Anthropic).
 * 
 * We treat the AI model as an external tool that requires specific input
 * and returns structured data.
 */
async function analyzeWithAI(diffContent: string): Promise<Omit<PRState, 'status' | 'prId'>> {
  console.log("[Tool] Sending diff to AI Model for security and logic review...");

  // Simulate processing time
  await new Promise(resolve => setTimeout(resolve, 800));

  // Simulated AI response based on the diff content
  // The AI detects the hardcoded password (High Severity) and missing types (Low Severity)
  const simulatedAIOutput = {
    reviewComments: [
      {
        line: 1,
        comment: "Detected potential hardcoded credential. Switch to environment variables.",
        severity: "high" as const
      },
      {
        line: 4,
        comment: "Added TypeScript types, good practice.",
        severity: "low" as const
      }
    ]
  };

  return simulatedAIOutput;
}

/**
 * Posts the review comments back to the PR (e.g., via GitHub PR Review API).
 * This is an "Effect" or "Side Effect" of the agent's execution.
 */
async function postReviewComments(prId: string, comments: PRState['reviewComments']): Promise<void> {
  console.log(`[Tool] Posting ${comments.length} comments to PR #${prId}...`);
  
  // Simulate API write operation
  await new Promise(resolve => setTimeout(resolve, 300));
  
  console.log("[Tool] Comments successfully posted.");
}

// ==========================================
// 3. THE AGENT LOGIC (LANGGRAPH.JS STYLE)
// ==========================================

/**
 * Orchestrates the PR review process.
 * 
 * This function acts as the "Graph" execution. It manages the state transitions
 * and ensures all I/O operations are awaited.
 */
async function runReviewAgent(prId: string): Promise<NextResponse> {
  try {
    // Step 1: Initialize State
    let state: PRState = {
      prId,
      diff: "",
      author: "contributor-bot",
      reviewComments: [],
      status: "pending"
    };

    // Step 2: Fetch External Data (Tool Call)
    // We use `await` here to handle the Promise. This is Non-Blocking I/O:
    // The Node.js event loop can handle other requests while waiting for the API.
    const diffData = await fetchPRDiff(prId);
    state.diff = diffData.content;

    // Step 3: Runtime Validation
    // We validate the data structure before passing it to the next stage.
    // This prevents "garbage in, garbage out" scenarios.
    const validatedState = PRStateSchema.safeParse(state);
    if (!validatedState.success) {
      throw new Error(`Validation Failed: ${JSON.stringify(validatedState.error.errors)}`);
    }
    state = validatedState.data;

    // Step 4: AI Analysis (Complex Tool Call)
    // The AI analysis is also asynchronous.
    const aiResult = await analyzeWithAI(state.diff);
    
    // Merge AI results into state
    state = {
      ...state,
      ...aiResult,
      status: "analyzed"
    };

    // Step 5: Post Process (Side Effects)
    // Only post comments if high severity issues are found
    const highSeverityComments = state.reviewComments.filter(c => c.severity === 'high');
    if (highSeverityComments.length > 0) {
      await postReviewComments(state.prId, highSeverityComments);
    }

    // Return success response
    return NextResponse.json({ 
      message: "Review completed successfully", 
      data: state 
    }, { status: 200 });

  } catch (error) {
    console.error("Agent Execution Failed:", error);
    
    // Handle errors gracefully
    const errorMessage = error instanceof Error ? error.message : "Unknown error";
    return NextResponse.json({ 
      message: "Review failed", 
      error: errorMessage 
    }, { status: 500 });
  }
}

// ==========================================
// 4. NEXT.JS API HANDLER
// ==========================================

/**
 * POST /api/review-pr
 * Entry point for the AI Agent.
 * 
 * Accepts a JSON body: { "prId": "uuid" }
 */
export async function POST(req: NextRequest) {
  const body = await req.json();
  
  // Validate Input ID
  const { prId } = body;
  
  if (!prId || typeof prId !== 'string') {
    return NextResponse.json({ error: "Invalid PR ID" }, { status: 400 });
  }

  // Execute the Agent
  // Because this is an async function, Next.js automatically waits for it 
  // to finish before closing the connection.
  return await runReviewAgent(prId);
}
