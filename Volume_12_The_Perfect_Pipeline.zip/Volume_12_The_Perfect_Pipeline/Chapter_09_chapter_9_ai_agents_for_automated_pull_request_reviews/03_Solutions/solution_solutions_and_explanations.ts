/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

import { Annotation, StateGraph } from "@langchain/langgraph";

// 1. Define the Input Type
type PRContext = {
  prId: number;
  files: Array<{
    filename: string;
    patch?: string;
  }>;
};

// 2. Define the Output Type
type AnalysisResult = {
  prId: number;
  issues: Array<{
    type: 'MISSING_JSDOC' | 'USE_OF_ANY';
    file: string;
    line: number;
    message: string;
  }>;
};

// 3. Simulate the External API Service (Non-blocking I/O)
// This mimics a slow, external code analysis tool.
const simulateCodeAnalysisService = async (context: PRContext): Promise<AnalysisResult> => {
  return new Promise((resolve, reject) => {
    // Simulate network latency
    setTimeout(() => {
      // Randomly fail to test error handling (10% chance)
      if (Math.random() < 0.1) {
        return reject(new Error("Analysis Service Timeout"));
      }

      const issues: AnalysisResult['issues'] = [];

      context.files.forEach(file => {
        if (!file.patch) return;

        const lines = file.patch.split('\n');
        let lastFunctionLineIndex = -1;

        lines.forEach((line, index) => {
          // Check for 'any' type usage
          if (line.includes(': any')) {
            issues.push({
              type: 'USE_OF_ANY',
              file: file.filename,
              line: index + 1,
              message: 'Avoid using "any" type. Use explicit types.'
            });
          }

          // Check for function declaration
          if (line.trim().match(/^function.*\{/)) {
            lastFunctionLineIndex = index;
            
            // Look backwards for JSDoc
            const prevLine = index > 0 ? lines[index - 1] : '';
            if (!prevLine.includes('/**')) {
              issues.push({
                type: 'MISSING_JSDOC',
                file: file.filename,
                line: index + 1,
                message: 'Exported functions must have JSDoc comments.'
              });
            }
          }
        });
      });

      resolve({ prId: context.prId, issues });
    }, 500); // 500ms simulated delay
  });
};

// 4. The LangGraph Node
const staticAnalysisNode = async (state: PRContext): Promise<Partial<AnalysisResult>> => {
  try {
    console.log(`[Static Analysis] Starting analysis for PR #${state.prId}...`);
    const result = await simulateCodeAnalysisService(state);
    console.log(`[Static Analysis] Completed for PR #${state.prId}. Found ${result.issues.length} issues.`);
    return result;
  } catch (error) {
    console.error(`[Static Analysis] Error: ${error.message}`);
    // Return empty result on failure to prevent graph crash
    return { prId: state.prId, issues: [] };
  }
};

// Export for use in the graph
export { staticAnalysisNode, type PRContext, type AnalysisResult };
