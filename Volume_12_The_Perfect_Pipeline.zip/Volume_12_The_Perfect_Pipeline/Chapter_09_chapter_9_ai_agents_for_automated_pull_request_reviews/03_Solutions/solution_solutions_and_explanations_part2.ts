/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

import { z } from "zod";
import { PRContext } from "./Exercise1"; // Assuming shared types

// 1. Define Zod Schema for Runtime Validation
const SecurityIssueSchema = z.object({
  severity: z.enum(['HIGH', 'MEDIUM', 'LOW']),
  cveId: z.string().min(1),
  file: z.string(),
  line: z.number(),
});

const SecurityResultSchema = z.object({
  prId: z.number(),
  vulnerabilities: z.array(SecurityIssueSchema),
});

// Infer TypeScript type from Zod schema
type SecurityResult = z.infer<typeof SecurityResultSchema>;

// 2. Simulate External Security Tool
const simulateSecurityScanner = async (context: PRContext): Promise<unknown> => {
  return new Promise((resolve) => {
    setTimeout(() => {
      // Randomly generate data to test validation
      const isMalformed = Math.random() < 0.2; // 20% chance of bad data
      
      if (isMalformed) {
        // Intentionally return invalid structure (missing cveId)
        resolve({
          prId: context.prId,
          vulnerabilities: [{
            severity: 'HIGH',
            // cveId: 'CVE-2023-1234', // Missing field
            file: 'src/app.ts',
            line: 42
          }]
        });
      } else {
        // Return valid structure
        resolve({
          prId: context.prId,
          vulnerabilities: [{
            severity: 'HIGH',
            cveId: 'CVE-2023-1234',
            file: 'src/app.ts',
            line: 42
          }]
        });
      }
    }, 400);
  });
};

// 3. The LangGraph Node with Validation
const securityScannerNode = async (state: PRContext): Promise<SecurityResult> => {
  console.log(`[Security Scanner] Scanning PR #${state.prId}...`);
  
  try {
    // Fetch raw data
    const rawData = await simulateSecurityScanner(state);
    
    // Validate using Zod
    const parsedData = SecurityResultSchema.parse(rawData);
    
    console.log(`[Security Scanner] Validation passed. Found ${parsedData.vulnerabilities.length} vulnerabilities.`);
    return parsedData;
  } catch (error) {
    // Handle Zod parsing errors specifically
    if (error instanceof z.ZodError) {
      console.error("[Security Scanner] Validation Failed:", error.errors);
      throw new Error("Security tool returned invalid data format");
    }
    // Re-throw other errors
    throw error;
  }
};

export { securityScannerNode, type SecurityResult };
