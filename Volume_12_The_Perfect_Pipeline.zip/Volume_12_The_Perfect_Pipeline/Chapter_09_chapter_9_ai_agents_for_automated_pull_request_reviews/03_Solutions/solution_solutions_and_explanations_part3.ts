/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

import { Annotation, StateGraph, START, END } from "@langchain/langgraph";
import { staticAnalysisNode, type AnalysisResult } from "./Exercise1";
import { securityScannerNode, type SecurityResult } from "./Exercise2";

// 1. Define Graph State
const StateAnnotation = Annotation.Root({
  prId: Annotation<number>,
  staticAnalysisResults: Annotation<AnalysisResult | null>(),
  securityResults: Annotation<SecurityResult | null>(),
  finalSummary: Annotation<string | null>(),
});

// 2. Define Nodes
const aggregateResultsNode = async (state: typeof StateAnnotation.State) => {
  const styleIssues = state.staticAnalysisResults?.issues || [];
  const vulns = state.securityResults?.vulnerabilities || [];

  let summary = `Review Summary for PR #${state.prId}:\n`;
  summary += `Style Issues: ${styleIssues.length}\n`;
  summary += `Security Vulns: ${vulns.length}\n`;

  return { finalSummary: summary };
};

const decisionNode = async (state: typeof StateAnnotation.State) => {
  const vulns = state.securityResults?.vulnerabilities || [];
  const hasHighSeverity = vulns.some(v => v.severity === 'HIGH');

  if (hasHighSeverity) {
    console.log("Decision: Blocking PR due to High Severity vulnerability.");
    return { finalSummary: (state.finalSummary || "") + "\nACTION: PR BLOCKED." };
  } else {
    console.log("Decision: Proceeding to comment.");
    return { finalSummary: (state.finalSummary || "") + "\nACTION: PR APPROVED." };
  }
};

// 3. Build the Graph
const graph = new StateGraph(StateAnnotation)
  // Define Nodes
  .addNode("staticAnalysisNode", staticAnalysisNode)
  .addNode("securityScannerNode", securityScannerNode)
  .addNode("aggregateResultsNode", aggregateResultsNode)
  .addNode("decisionNode", decisionNode)
  .addNode("BLOCK_PR", async (state) => console.log("Executing Block PR Logic...", state.finalSummary))
  .addNode("POST_COMMENT", async (state) => console.log("Executing Post Comment Logic...", state.finalSummary))
  
  // Define Edges
  .addEdge(START, "staticAnalysisNode") // Start with analysis
  .addEdge(START, "securityScannerNode") // Parallel execution
  
  // Join parallel branches
  .addEdge("staticAnalysisNode", "aggregateResultsNode")
  .addEdge("securityScannerNode", "aggregateResultsNode")
  
  // Decision making
  .addEdge("aggregateResultsNode", "decisionNode")
  
  // Conditional Routing
  .addConditionalEdges(
    "decisionNode",
    (state) => {
      // Check if the summary contains the block action
      if (state.finalSummary?.includes("PR BLOCKED")) {
        return "BLOCK_PR";
      }
      return "POST_COMMENT";
    }
  )
  
  // Terminal Edges
  .addEdge("BLOCK_PR", END)
  .addEdge("POST_COMMENT", END);

// Compile the graph
const compiledGraph = graph.compile();

// 4. Visualization (Graphviz DOT Code)
const graphvizDot = `
digraph G {
    rankdir=LR;
    node [shape=box];

    START [shape=circle];
    END [shape=circle];

    START -> staticAnalysisNode;
    START -> securityScannerNode;

    staticAnalysisNode -> aggregateResultsNode;
    securityScannerNode -> aggregateResultsNode;

    aggregateResultsNode -> decisionNode;

    decisionNode -> BLOCK_PR [label="High Severity"];
    decisionNode -> POST_COMMENT [label="Safe"];

    BLOCK_PR -> END;
    POST_COMMENT -> END;
}
`;

export { compiledGraph, graphvizDot };
