/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState, useEffect } from 'react';

// 1. Type Definitions
interface ReviewIssue {
  type: 'SECURITY' | 'STYLE';
  severity?: 'HIGH' | 'MEDIUM' | 'LOW';
  message: string;
  file: string;
  line: number;
}

interface ReviewSummary {
  prId: number;
  issues: ReviewIssue[];
  overallStatus: 'BLOCKED' | 'APPROVED' | 'NEEDS_REVIEW';
}

// 2. Mock API Function
const fetchReviewData = async (prId: number): Promise<ReviewSummary> => {
  // Simulate network delay
  await new Promise(resolve => setTimeout(resolve, 1000));
  
  // Mock data
  return {
    prId,
    overallStatus: 'NEEDS_REVIEW',
    issues: [
      { type: 'SECURITY', severity: 'HIGH', message: 'SQL Injection risk', file: 'db.ts', line: 10 },
      { type: 'STYLE', message: 'Missing JSDoc', file: 'utils.ts', line: 5 },
      { type: 'SECURITY', severity: 'MEDIUM', message: 'Unsafe eval', file: 'parser.ts', line: 22 },
    ]
  };
};

// 3. The Component
const PRReviewDashboard: React.FC<{ prId: number }> = ({ prId }) => {
  const [data, setData] = useState<ReviewSummary | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const [filter, setFilter] = useState<'ALL' | 'SECURITY' | 'STYLE'>('ALL');

  useEffect(() => {
    const loadData = async () => {
      try {
        setLoading(true);
        const result = await fetchReviewData(prId);
        setData(result);
      } catch (err) {
        setError("Failed to fetch review data.");
      } finally {
        setLoading(false);
      }
    };

    loadData();
  }, [prId]);

  // 4. Filtering Logic
  const filteredIssues = data?.issues.filter(issue => {
    if (filter === 'ALL') return true;
    return issue.type === filter;
  }) || [];

  // 5. Render Logic
  if (loading) return <div className="dashboard-loading">Loading Review...</div>;
  if (error) return <div className="dashboard-error">Error: {error}</div>;
  if (!data) return null;

  return (
    <div className="dashboard-container" style={{ padding: '20px', fontFamily: 'sans-serif' }}>
      <div className="summary-card" style={{ border: '1px solid #ccc', padding: '15px', marginBottom: '20px' }}>
        <h2>PR #{data.prId} Review Status</h2>
        <span style={{ 
          fontWeight: 'bold', 
          color: data.overallStatus === 'BLOCKED' ? 'red' : 'green' 
        }}>
          {data.overallStatus}
        </span>
      </div>

      <div className="controls">
        <button onClick={() => setFilter('ALL')} disabled={filter === 'ALL'}>All</button>
        <button onClick={() => setFilter('SECURITY')} disabled={filter === 'SECURITY'}>Security</button>
        <button onClick={() => setFilter('STYLE')} disabled={filter === 'STYLE'}>Style</button>
      </div>

      <ul style={{ listStyle: 'none', padding: 0 }}>
        {filteredIssues.map((issue, idx) => (
          <li 
            key={idx} 
            style={{ 
              borderBottom: '1px solid #eee', 
              padding: '10px',
              borderLeft: `4px solid ${issue.severity === 'HIGH' ? 'red' : issue.severity === 'MEDIUM' ? 'orange' : 'blue'}`
            }}
          >
            <strong>{issue.type}</strong> {issue.severity && `(${issue.severity})`}: {issue.message}
            <br />
            <small>{issue.file}:{issue.line}</small>
          </li>
        ))}
        {filteredIssues.length === 0 && <li>No issues found for this filter.</li>}
      </ul>
    </div>
  );
};

export default PRReviewDashboard;
