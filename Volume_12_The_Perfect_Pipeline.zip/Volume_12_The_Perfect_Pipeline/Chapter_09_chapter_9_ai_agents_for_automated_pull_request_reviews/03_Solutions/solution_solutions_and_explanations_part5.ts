/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

import { Annotation, StateGraph, START, END } from "@langchain/langgraph";
import { staticAnalysisNode, type AnalysisResult } from "./Exercise1";
import { securityScannerNode, type SecurityResult } from "./Exercise2";

// 1. Define Enhanced State
const StateAnnotation = Annotation.Root({
  prId: Annotation<number>,
  staticAnalysisResults: Annotation<AnalysisResult | null>(),
  securityResults: Annotation<SecurityResult | null>(),
  humanApproved: Annotation<boolean>({ default: false }),
  finalStatus: Annotation<string>({ default: "PENDING" }),
});

// 2. Define New Nodes

// Wait for human approval (Simulated)
const waitForHumanApprovalNode = async (state: typeof StateAnnotation.State) => {
  console.log("[Human Loop] Waiting for manual review...");
  
  // Simulate non-blocking delay for human action (e.g., 2 seconds)
  await new Promise(resolve => setTimeout(resolve, 2000));
  
  // Simulate human approval logic:
  // In a real app, this would be a webhook or database check.
  // Here, we assume if we reached this node, the human approved.
  console.log("[Human Loop] Human approved minor issues.");
  
  return { humanApproved: true };
};

// Post Final Comment Node
const postFinalCommentNode = async (state: typeof StateAnnotation.State) => {
  let message = "";

  // Determine message based on history
  const hasHighSeverity = state.securityResults?.vulnerabilities.some(v => v.severity === 'HIGH');
  
  if (hasHighSeverity) {
    message = `PR #${state.prId}: BLOCKED automatically due to High Severity vulnerabilities.`;
  } else if (state.humanApproved) {
    message = `PR #${state.prId}: APPROVED after manual review of minor issues.`;
  } else {
    message = `PR #${state.prId}: APPROVED automatically (Clean scan).`;
  }

  console.log(`[Final Output] Posting comment: ${message}`);
  return { finalStatus: message };
};

// Decision Node (Refined)
const decisionNode = async (state: typeof StateAnnotation.State) => {
  const vulns = state.securityResults?.vulnerabilities || [];
  const hasHighSeverity = vulns.some(v => v.severity === 'HIGH');

  if (hasHighSeverity) {
    return "BLOCK_PR";
  }
  
  // If we have medium/low issues or style issues, go to human loop
  const hasOtherIssues = vulns.length > 0 || (state.staticAnalysisResults?.issues.length || 0) > 0;
  if (hasOtherIssues) {
    return "WAIT_FOR_HUMAN";
  }

  return "POST_COMMENT";
};

// 3. Build Graph
const graph = new StateGraph(StateAnnotation)
  .addNode("staticAnalysisNode", staticAnalysisNode)
  .addNode("securityScannerNode", securityScannerNode)
  .addNode("waitForHumanApprovalNode", waitForHumanApprovalNode)
  .addNode("postFinalCommentNode", postFinalCommentNode)
  .addNode("BLOCK_PR", async (state) => ({ finalStatus: `PR #${state.prId} BLOCKED` }))

  // Edges
  .addEdge(START, "staticAnalysisNode")
  .addEdge(START, "securityScannerNode")
  
  // Join parallel analysis
  .addEdge("staticAnalysisNode", "decisionNode") // We use decision as a join point logic-wise
  .addEdge("securityScannerNode", "decisionNode")

  // Conditional Routing
  .addConditionalEdges(
    "decisionNode",
    (state) => {
      const vulns = state.securityResults?.vulnerabilities || [];
      const hasHighSeverity = vulns.some(v => v.severity === 'HIGH');
      
      if (hasHighSeverity) return "BLOCK_PR";
      
      const hasOtherIssues = vulns.length > 0 || (state.staticAnalysisResults?.issues.length || 0) > 0;
      if (hasOtherIssues) return "waitForHumanApprovalNode";
      
      return "postFinalCommentNode";
    }
  )

  // Flow after Human Approval
  .addEdge("waitForHumanApprovalNode", "postFinalCommentNode")

  // Terminal Edges
  .addEdge("BLOCK_PR", END)
  .addEdge("postFinalCommentNode", END);

const compiledPipeline = graph.compile();

// 4. Test Script (Conceptual)
// To run this, you would create a separate file (e.g., test.ts):
/*
import { compiledPipeline } from "./Exercise5";

async function runTests() {
  console.log("--- TEST 1: Clean PR ---");
  await compiledPipeline.invoke({ prId: 101, files: [] });
  
  console.log("\n--- TEST 2: PR with High Severity Bug ---");
  // Note: We inject files that trigger the security scanner mock to return high severity
  await compiledPipeline.invoke({ 
    prId: 102, 
    files: [{ filename: "hack.js", patch: "eval('x')" }] 
  });

  console.log("\n--- TEST 3: PR with Style Issues ---");
  // Triggers static analysis issues, goes to human loop
  await compiledPipeline.invoke({ 
    prId: 103, 
    files: [{ filename: "func.ts", patch: "function foo() { return 1; }" }] 
  });
}

runTests();
*/

export { compiledPipeline };
