/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// File: app/api/ai-review/route.ts
// Runtime: Edge Runtime (Optimized for low-latency API calls)
// Context: SaaS Application - CI/CD Integration Layer

import { NextResponse } from 'next/server';

// -----------------------------------------------------------------------------
// 1. CONFIGURATION & TYPES
// -----------------------------------------------------------------------------
// Strict typing ensures that the coverage data structure is predictable.
interface CoverageReport {
  total: {
    lines: { total: number; covered: number; percentage: number };
    branches: { total: number; covered: number; percentage: number };
  };
  files: Record<string, { lines: number[] }>;
}

interface ReviewDecision {
  passed: boolean;
  summary: string;
  details: string[];
}

// -----------------------------------------------------------------------------
// 2. CORE LOGIC: COVERAGE ANALYZER (SRP: Data Analysis)
// -----------------------------------------------------------------------------
// This module is responsible solely for parsing raw data and enforcing thresholds.
// It has no knowledge of HTTP requests or external API calls.

/**
 * Analyzes a raw coverage report against defined quality gates.
 * 
 * @param report - The JSON object containing line and branch coverage stats.
 * @param thresholds - The minimum acceptable coverage percentages.
 * @returns A decision object indicating pass/fail status and specific violations.
 */
function analyzeCoverage(
  report: CoverageReport,
  thresholds: { lines: number; branches: number }
): ReviewDecision {
  const { lines, branches } = report.total;
  
  const linePass = lines.percentage >= thresholds.lines;
  const branchPass = branches.percentage >= thresholds.branches;
  
  const passed = linePass && branchPass;
  
  const details: string[] = [];
  
  if (!linePass) {
    details.push(`Line coverage (${lines.percentage}%) is below the threshold (${thresholds.lines}%).`);
  }
  
  if (!branchPass) {
    details.push(`Branch coverage (${branches.percentage}%) is below the threshold (${thresholds.branches}%).`);
  }

  const summary = passed 
    ? "✅ Code coverage meets all quality gates." 
    : "⚠️ Code coverage failed to meet quality gates. Review required.";

  return { passed, summary, details };
}

// -----------------------------------------------------------------------------
// 3. CORE LOGIC: AI REVIEW GENERATOR (SRP: Content Generation)
// -----------------------------------------------------------------------------
// This module generates context-aware review text based on analysis results.
// It simulates an AI agent's reasoning process (ReAct Loop pattern).

/**
 * Generates a structured AI review comment based on coverage violations.
 * 
 * @param decision - The result from the coverage analyzer.
 * @returns A formatted markdown string ready for GitHub PR comment.
 */
function generateAIReviewComment(decision: ReviewDecision): string {
  if (decision.passed) {
    return `## 🤖 AI Code Review: Coverage Check\n\n${decision.summary}\n\n**Status:** Approved automatically.`;
  }

  // Simulating ReAct Loop: Reasoning -> Action
  // Reasoning: Low coverage indicates potential untested logic paths.
  // Action: Suggest specific testing strategies.
  
  let reasoning = "### Reasoning\n";
  reasoning += "The analysis indicates gaps in test coverage. Uncovered lines increase the risk of regressions in production. ";
  reasoning += "Specifically, missing branch coverage suggests edge cases are not being handled.\n\n";

  let recommendations = "### Recommendations\n";
  recommendations += "1. **Add Unit Tests:** Write tests for the specific files identified below.\n";
  recommendations += "2. **Edge Case Testing:** Ensure conditional logic (if/else) is fully exercised.\n";
  recommendations += "3. **Mock External Dependencies:** Isolate logic from external services.\n\n";

  let specifics = "### Violations\n";
  decision.details.forEach((detail) => {
    specifics += `- ${detail}\n`;
  });

  return `## 🤖 AI Code Review: Coverage Check\n\n${decision.summary}\n\n${reasoning}${recommendations}${specifics}`;
}

// -----------------------------------------------------------------------------
// 4. API ROUTE HANDLER (SRP: HTTP Interface)
// -----------------------------------------------------------------------------
// This function acts as the entry point, handling the request and response lifecycle.
// It orchestrates the flow: Fetch -> Analyze -> Generate -> Respond.

export const runtime = 'edge'; // Use Edge Runtime for optimal performance

/**
 * POST /api/ai-review
 * 
 * Expects a JSON payload containing a mock coverage report (simulating a GitHub Actions artifact).
 * In a real scenario, this would be triggered by a workflow run ID.
 * 
 * @param request - The incoming HTTP request.
 * @returns A NextResponse containing the AI review comment.
 */
export async function POST(request: Request) {
  try {
    // 1. Parse Input (Simulating fetching a coverage artifact)
    const body = await request.json();
    const coverageData: CoverageReport = body.coverageReport;
    
    if (!coverageData) {
      return NextResponse.json(
        { error: "No coverage report provided." },
        { status: 400 }
      );
    }

    // 2. Define Quality Gates (SRP: Configuration is separate from logic)
    const thresholds = {
      lines: 80.0,      // Require 80% line coverage
      branches: 75.0    // Require 75% branch coverage
    };

    // 3. Execute Analysis Pipeline
    const decision = analyzeCoverage(coverageData, thresholds);
    const aiComment = generateAIReviewComment(decision);

    // 4. Return Result (In a real app, this would post to GitHub API)
    return NextResponse.json({
      status: decision.passed ? "approved" : "rejected",
      reviewComment: aiComment,
      metrics: coverageData.total,
      thresholds: thresholds
    });

  } catch (error) {
    console.error("Error in AI Review Pipeline:", error);
    return NextResponse.json(
      { error: "Internal server error during analysis." },
      { status: 500 }
    );
  }
}
