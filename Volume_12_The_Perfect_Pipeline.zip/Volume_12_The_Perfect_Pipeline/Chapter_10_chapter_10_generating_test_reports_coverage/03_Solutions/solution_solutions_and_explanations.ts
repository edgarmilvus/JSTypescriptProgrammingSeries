/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// src/pipeline.ts

/**
 * Validates the input structure.
 * Checks for existence, object type, and presence of the 'data' property.
 */
export function validateInput(input: any): input is { data: { value: number } } {
  return !!input && typeof input === 'object' && 'data' in input;
}

/**
 * Validates and extracts the numeric value.
 * Returns null if the value is not a valid number.
 */
export function extractValue(data: any): number | null {
  const value = data.value;
  if (typeof value !== 'number' || isNaN(value)) {
    return null;
  }
  return value;
}

/**
 * Performs the mathematical transformation.
 * Multiplies the input value by 2.
 */
export function transformValue(value: number): number {
  return value * 2;
}

/**
 * Applies a threshold check to the transformed value.
 * Caps the result at 100 if it exceeds that limit.
 */
export function applyThreshold(value: number): number {
  if (value > 100) {
    return 100;
  }
  return value;
}

/**
 * The main entry point for the pipeline.
 * Orchestrates the validation, extraction, transformation, and threshold application.
 */
export function processRawData(input: any): number | null {
  if (!validateInput(input)) {
    return null;
  }

  const value = extractValue(input.data);
  if (value === null) {
    return null;
  }

  const transformed = transformValue(value);
  return applyThreshold(transformed);
}
