/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

// src/pipeline.test.ts
import { describe, it, expect } from 'vitest';
import { 
  processRawData, 
  validateInput, 
  extractValue, 
  transformValue, 
  applyThreshold 
} from './pipeline';

describe('Pipeline Unit Tests', () => {
  // Unit tests for helper functions
  describe('validateInput', () => {
    it('should return true for valid object with data property', () => {
      expect(validateInput({ data: { value: 1 } })).toBe(true);
    });
    it('should return false for null', () => {
      expect(validateInput(null)).toBe(false);
    });
    it('should return false for non-object types', () => {
      expect(validateInput('string')).toBe(false);
    });
    it('should return false for object missing data property', () => {
      expect(validateInput({ value: 1 })).toBe(false);
    });
  });

  describe('extractValue', () => {
    it('should return the number if valid', () => {
      expect(extractValue({ value: 42 })).toBe(42);
    });
    it('should return null for non-number', () => {
      expect(extractValue({ value: 'string' })).toBe(null);
    });
    it('should return null for NaN', () => {
      expect(extractValue({ value: NaN })).toBe(null);
    });
  });

  describe('transformValue', () => {
    it('should multiply by 2', () => {
      expect(transformValue(10)).toBe(20);
    });
  });

  describe('applyThreshold', () => {
    it('should return value if under 100', () => {
      expect(applyThreshold(50)).toBe(50);
    });
    it('should cap at 100 if over 100', () => {
      expect(applyThreshold(150)).toBe(100);
    });
    it('should return 100 exactly at boundary', () => {
      expect(applyThreshold(100)).toBe(100);
    });
  });

  // Integration tests for the main function
  describe('processRawData', () => {
    it('should handle valid input under threshold', () => {
      const input = { data: { value: 20 } };
      expect(processRawData(input)).toBe(40);
    });

    it('should handle valid input over threshold', () => {
      const input = { data: { value: 60 } };
      expect(processRawData(input)).toBe(100);
    });

    it('should return null for invalid structure', () => {
      expect(processRawData(null)).toBe(null);
      expect(processRawData({})).toBe(null);
    });

    it('should return null for invalid value type', () => {
      expect(processRawData({ data: { value: 'string' } })).toBe(null);
    });

    it('should return null for NaN value', () => {
      expect(processRawData({ data: { value: NaN } })).toBe(null);
    });
  });
});
