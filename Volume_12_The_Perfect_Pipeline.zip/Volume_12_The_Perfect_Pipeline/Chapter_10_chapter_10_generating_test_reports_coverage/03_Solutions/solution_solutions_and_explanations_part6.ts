/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part6.ts
// Description: Solutions and Explanations
// ==========================================

name: Coverage Gate

on:
  pull_request:
    branches: [ "main" ]

jobs:
  coverage-check:
    runs-on: ubuntu-latest
    steps:
      - name: Checkout Repository
        uses: actions/checkout@v4
        with:
          fetch-depth: 0 # Fetch full history for comparison

      - name: Setup Node.js
        uses: actions/setup-node@v4
        with:
          node-version: '20'

      - name: Install Dependencies
        run: npm ci

      - name: Generate Base Branch Coverage
        run: |
          git checkout origin/main
          npm run test:coverage-json # Assumes a script that outputs coverage/coverage-summary.json
          mv coverage/coverage-summary.json coverage-main.json

      - name: Generate Feature Branch Coverage
        run: |
          git checkout ${{ github.sha }}
          npm run test:coverage-json
          mv coverage/coverage-summary.json coverage-feature.json

      - name: Compare Coverage
        id: compare
        uses: actions/github-script@v7
        with:
          script: |
            const fs = require('fs');
            
            // Read coverage files
            const mainReport = JSON.parse(fs.readFileSync('coverage-main.json', 'utf8'));
            const featureReport = JSON.parse(fs.readFileSync('coverage-feature.json', 'utf8'));
            
            // Extract total percentages (using 'total' key from summary)
            const mainTotal = mainReport.total.lines.pct;
            const featureTotal = featureReport.total.lines.pct;
            
            console.log(`Main Branch Coverage: ${mainTotal}%`);
            console.log(`Feature Branch Coverage: ${featureTotal}%`);
            
            const drop = mainTotal - featureTotal;
            
            // Threshold Logic: 2% drop allowed
            if (drop > 2) {
              core.setFailed(`Coverage dropped by ${drop.toFixed(2)}%. Threshold is 2%.`);
              
              // Post Comment
              const { context, github } = require('@actions/github');
              const prNumber = context.issue.number;
              
              github.rest.issues.createComment({
                issue_number: prNumber,
                owner: context.repo.owner,
                repo: context.repo.repo,
                body: `🚨 **Coverage Gate Failed**\n\nTest coverage dropped from **${mainTotal}%** to **${featureTotal}%** (Difference: **-${drop.toFixed(2)}%**).\n\nPlease add tests to increase coverage before merging.`
              });
            } else {
              console.log("Coverage check passed.");
            }
