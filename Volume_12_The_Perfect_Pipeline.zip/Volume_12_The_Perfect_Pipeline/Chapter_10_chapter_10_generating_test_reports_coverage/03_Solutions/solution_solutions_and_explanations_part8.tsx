/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part8.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState } from 'react';

// Define the type for a single step in the ReAct loop
type ReActStep = {
  id: number;
  thought: string;
  action: {
    tool: string;
    args: any;
  };
  observation: string;
};

// Props for the component
interface ReActLoopVisualizerProps {
  steps: ReActStep[];
}

export const ReActLoopVisualizer: React.FC<ReActLoopVisualizerProps> = ({ steps }) => {
  // State to track which observation is expanded
  const [expandedObservation, setExpandedObservation] = useState<number | null>(null);
  // State to track hover state for tooltips
  const [hoveredAction, setHoveredAction] = useState<number | null>(null);

  const toggleObservation = (id: number) => {
    setExpandedObservation(expandedObservation === id ? null : id);
  };

  return (
    <div style={styles.container}>
      {steps.map((step, index) => (
        <div key={step.id} style={styles.stepContainer}>
          {/* Connection Line to next step (except for last) */}
          {index < steps.length - 1 && <div style={styles.connector}></div>}
          
          {/* Thought Node */}
          <div style={{ ...styles.node, ...styles.thought }}>
            <strong>Thought {step.id}</strong>
            <div style={styles.smallText}>{step.thought}</div>
          </div>

          {/* Action Node (Interactive: Hover for Tooltip) */}
          <div 
            style={{ ...styles.node, ...styles.action }}
            onMouseEnter={() => setHoveredAction(step.id)}
            onMouseLeave={() => setHoveredAction(null)}
          >
            <strong>Action</strong>
            <div style={styles.smallText}>{step.action.tool}</div>
            
            {/* Tooltip */}
            {hoveredAction === step.id && (
              <div style={styles.tooltip}>
                <pre style={styles.pre}>{JSON.stringify(step.action.args, null, 2)}</pre>
              </div>
            )}
          </div>

          {/* Observation Node (Interactive: Click to Expand) */}
          <div 
            style={{ 
              ...styles.node, 
              ...styles.observation,
              ...(expandedObservation === step.id ? styles.expandedObservation : {})
            }}
            onClick={() => toggleObservation(step.id)}
          >
            <strong>Observation</strong>
            <div style={styles.smallText}>
              {expandedObservation === step.id ? step.observation : 'Click to expand...'}
            </div>
          </div>
        </div>
      ))}
    </div>
  );
};

// Basic CSS-in-JS styles for visualization
const styles: { [key: string]: React.CSSProperties } = {
  container: {
    display: 'flex',
    flexDirection: 'column',
    gap: '40px',
    padding: '20px',
    fontFamily: 'Arial, sans-serif',
    backgroundColor: '#f9f9f9',
    borderRadius: '8px',
  },
  stepContainer: {
    display: 'flex',
    gap: '20px',
    alignItems: 'center',
    position: 'relative',
  },
  connector: {
    position: 'absolute',
    left: '50%',
    bottom: '-25px',
    width: '2px',
    height: '25px',
    backgroundColor: '#ccc',
    zIndex: 0,
  },
  node: {
    padding: '15px',
    borderRadius: '8px',
    border: '1px solid #ddd',
    minWidth: '150px',
    textAlign: 'center' as const,
    position: 'relative' as const,
    cursor: 'pointer',
    boxShadow: '0 2px 4px rgba(0,0,0,0.1)',
  },
  thought: {
    backgroundColor: '#e3f2fd', // Light Blue
  },
  action: {
    backgroundColor: '#fff9c4', // Light Yellow
  },
  observation: {
    backgroundColor: '#e8f5e9', // Light Green
  },
  expandedObservation: {
    width: '300px', // Expand on click
    boxShadow: '0 4px 8px rgba(0,0,0,0.2)',
  },
  smallText: {
    fontSize: '0.9em',
    marginTop: '5px',
    overflow: 'hidden',
    textOverflow: 'ellipsis',
  },
  tooltip: {
    position: 'absolute',
    bottom: '110%',
    left: '50%',
    transform: 'translateX(-50%)',
    backgroundColor: '#333',
    color: '#fff',
    padding: '10px',
    borderRadius: '4px',
    zIndex: 100,
    width: '200px',
    textAlign: 'left' as const,
  },
  pre: {
    margin: 0,
    whiteSpace: 'pre-wrap',
    fontSize: '0.8em',
  }
};
