/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

name: Zero-Downtime Blue-Green Deployment

on:
  push:
    branches: [main]

env:
  # Configuration for the target Kubernetes cluster
  KUBE_NAMESPACE: production-saas
  # Image registry details
  REGISTRY: ghcr.io
  IMAGE_NAME: ${{ github.repository }}
  # The service names for Blue and Green environments
  SERVICE_BLUE: app-service-blue
  SERVICE_GREEN: app-service-green

jobs:
  deploy:
    runs-on: ubuntu-latest
    permissions:
      contents: read
      packages: write

    steps:
      # 1. Checkout Code
      - name: Checkout code
        uses: actions/checkout@v4

      # 2. Build and Push Docker Image
      - name: Build and Push Image
        run: |
          docker build -t ${{ env.REGISTRY }}/${{ env.IMAGE_NAME }}:${{ github.sha }} .
          echo "${{ secrets.GITHUB_TOKEN }}" | docker login ${{ env.REGISTRY }} -u ${{ github.actor }} --password-stdin
          docker push ${{ env.REGISTRY }}/${{ env.IMAGE_NAME }}:${{ github.sha }}

      # 3. Configure Kubernetes Context
      - name: Set up Kubeconfig
        uses: azure/k8s-set-context@v4
        with:
          method: kubeconfig
          kubeconfig: ${{ secrets.KUBE_CONFIG }}

      # 4. Deploy to "Green" Environment
      - name: Deploy to Green Environment
        run: |
          # Update the Green deployment with the new image
          kubectl set image deployment/app-deployment-green \
            container-0=${{ env.REGISTRY }}/${{ env.IMAGE_NAME }}:${{ github.sha }} \
            -n ${{ env.KUBE_NAMESPACE }}

      # 5. Health Check (The Critical Safety Net)
      - name: Verify Green Environment Health
        run: |
          echo "Waiting for Green environment to stabilize..."
          # Poll the Green service endpoint until it returns 200 OK
          # We use a loop with a timeout to prevent infinite hanging
          TIMEOUT=60
          until curl -s -o /dev/null -w "%{http_code}" http://${{ env.SERVICE_GREEN }}.${{ env.KUBE_NAMESPACE }}.svc.cluster.local/health | grep -q "200"; do
            sleep 2
            TIMEOUT=$((TIMEOUT - 1))
            if [ $TIMEOUT -eq 0 ]; then
              echo "Health check failed for Green environment. Aborting deployment."
              exit 1
            fi
          done
          echo "Green environment is healthy."

      # 6. Traffic Shift (The Zero-Downtime Switch)
      - name: Shift Traffic to Green
        run: |
          # In a real scenario, this might involve updating an Ingress controller or Service selector.
          # Here, we simulate the switch by updating the selector on the primary service.
          # This assumes a "Service per Environment" pattern or a label-based routing mechanism.
          
          # Example: Updating a generic 'app-service' to point to Green pods
          kubectl patch service app-service -n ${{ env.KUBE_NAMESPACE }} \
            -p '{"spec":{"selector":{"app":"app-green"}}}'
          
          echo "Traffic successfully shifted to Green."

      # 7. Automated Rollback Trigger (Simulated)
      - name: Post-Deployment Monitoring & Rollback
        if: failure()
        run: |
          echo "Deployment failed. Initiating automated rollback..."
          # Revert traffic to Blue immediately
          kubectl patch service app-service -n ${{ env.KUBE_NAMESPACE }} \
            -p '{"spec":{"selector":{"app":"app-blue"}}}'
          echo "Traffic reverted to Blue. Green environment marked for investigation."
