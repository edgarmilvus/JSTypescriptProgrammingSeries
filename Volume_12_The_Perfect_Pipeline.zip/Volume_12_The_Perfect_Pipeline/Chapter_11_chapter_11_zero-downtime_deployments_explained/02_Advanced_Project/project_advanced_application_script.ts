/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

/**
 * Zero-Downtime Deployment Orchestrator
 * 
 * Context: SaaS Web Application
 * Strategy: Canary Deployment with Automated Rollback
 * 
 * This script orchestrates a deployment by:
 * 1. Spinning up a new version (Green/Canary) alongside the stable version (Blue/Stable).
 * 2. Shifting traffic incrementally (10% -> 50% -> 100%).
 * 3. Monitoring health metrics (Latency, Error Rate) at each step.
 * 4. Triggering an automated rollback if anomalies are detected (using a local heuristic model).
 */

// ============================================================================
// 1. TYPE DEFINITIONS & INTERFACES
// ============================================================================

/**
 * Represents the state of a deployment target (e.g., a Kubernetes Deployment).
 */
interface DeploymentTarget {
  name: string;
  version: string;
  replicas: number;
  status: 'Pending' | 'Running' | 'Failed' | 'Terminated';
}

/**
 * Represents the traffic routing configuration (e.g., Kubernetes Service or Ingress).
 */
interface TrafficConfig {
  stableWeight: number; // Percentage (0-100)
  canaryWeight: number; // Percentage (0-100)
}

/**
 * Metrics data point for health evaluation.
 */
interface HealthMetrics {
  latencyP95: number; // Milliseconds
  errorRate: number;  // Percentage (0-1)
  cpuUsage: number;   // Percentage (0-1)
}

/**
 * Configuration for the deployment strategy.
 */
interface DeploymentConfig {
  canaryReplicas: number;
  steps: number[];
  healthThresholds: {
    maxErrorRate: number;
    maxLatency: number;
  };
}

// ============================================================================
// 2. MOCK KUBERNETES CLIENT (Simulating kubernetes-client library)
// ============================================================================

/**
 * Mock class simulating interactions with the Kubernetes API.
 * In a real scenario, this would wrap `@kubernetes/client-node`.
 */
class KubernetesClient {
  async createDeployment(name: string, version: string, replicas: number): Promise<DeploymentTarget> {
    console.log(`[K8s API] Creating Deployment '${name}' (v${version}) with ${replicas} replicas...`);
    // Simulate network latency
    await new Promise(resolve => setTimeout(resolve, 500));
    return { name, version, replicas, status: 'Running' };
  }

  async updateServiceTraffic(serviceName: string, stableWeight: number, canaryWeight: number): Promise<void> {
    console.log(`[K8s API] Updating Service '${serviceName}': Stable=${stableWeight}%, Canary=${canaryWeight}%`);
    // In reality, this might involve updating Istio VirtualService or Nginx Ingress annotations
    await new Promise(resolve => setTimeout(resolve, 300));
  }

  async getMetrics(deploymentName: string): Promise<HealthMetrics> {
    // Simulate fetching metrics from Prometheus or Datadog
    // Introduce randomness to simulate real-world fluctuation
    const baseLatency = 120;
    const baseError = 0.01; // 1%
    
    const jitter = Math.random() * 0.2; // 0-20% variance
    
    return {
      latencyP95: baseLatency * (1 + jitter),
      errorRate: baseError * (1 + jitter),
      cpuUsage: 45 + (jitter * 10)
    };
  }

  async rollback(serviceName: string, stableVersion: string): Promise<void> {
    console.log(`[K8s API] CRITICAL: Rolling back '${serviceName}' to version ${stableVersion}.`);
    console.log(`[K8s API] Terminating Canary pods...`);
    await new Promise(resolve => setTimeout(resolve, 500));
    console.log(`[K8s API] Resetting Traffic to 100% Stable.`);
  }
}

// ============================================================================
// 3. AI-DRIVEN ANOMALY DETECTION (Local Zero-Shot Classification)
// ============================================================================

/**
 * Simulates a local Zero-Shot Classification model (e.g., using ONNX Runtime or Transformers.js).
 * Instead of training on specific metrics, it uses generalized knowledge to classify system state.
 * 
 * Input: HealthMetrics
 * Output: Classification Label ('Healthy', 'Degraded', 'Critical')
 */
class LocalAnomalyDetector {
  private modelWeights = {
    Healthy: { threshold: 0.8 },
    Degraded: { threshold: 0.5 },
    Critical: { threshold: 0.0 } // Always catch critical
  };

  /**
   * Evaluates metrics against a generalized understanding of system stability.
   * Simulates zero-shot inference by mapping raw data to abstract concepts.
   */
  public classify(metrics: HealthMetrics, thresholds: DeploymentConfig['healthThresholds']): 'Healthy' | 'Degraded' | 'Critical' {
    // Logic: Heuristic-based classification (simulating model inference)
    
    if (metrics.errorRate > thresholds.maxErrorRate || metrics.latencyP95 > thresholds.maxLatency) {
      return 'Critical';
    }

    // Context Augmentation: The model considers relative degradation
    const degradationScore = (metrics.errorRate * 100) + (metrics.latencyP95 / 10);
    
    if (degradationScore > 15) return 'Degraded'; // Arbitrary boundary for simulation
    return 'Healthy';
  }
}

// ============================================================================
// 4. ORCHESTRATOR LOGIC
// ============================================================================

class DeploymentOrchestrator {
  private k8s: KubernetesClient;
  private aiDetector: LocalAnomalyDetector;
  private config: DeploymentConfig;
  
  constructor(config: DeploymentConfig) {
    this.k8s = new KubernetesClient();
    this.aiDetector = new LocalAnomalyDetector();
    this.config = config;
  }

  /**
   * Main entry point for the deployment pipeline.
   * @param appName - Name of the SaaS application
   * @param newVersion - The semantic version being deployed (e.g., '2.1.0')
   * @param stableVersion - The current stable version (e.g., '2.0.0')
   */
  public async executeCanaryDeployment(appName: string, newVersion: string, stableVersion: string): Promise<void> {
    console.log(`\n🚀 Starting Canary Deployment for ${appName}`);
    console.log(`--------------------------------------------------`);

    try {
      // Step 1: Provision Canary Infrastructure
      const canaryDeployment = await this.k8s.createDeployment(`${appName}-canary`, newVersion, this.config.canaryReplicas);
      
      if (canaryDeployment.status !== 'Running') throw new Error("Canary deployment failed to initialize.");

      // Step 2: Iterative Traffic Shifting & Monitoring
      for (let i = 0; i < this.config.steps.length; i++) {
        const canaryWeight = this.config.steps[i];
        const stableWeight = 100 - canaryWeight;

        console.log(`\n[Step ${i + 1}/${this.config.steps.length}] Shifting Traffic: Canary ${canaryWeight}% / Stable ${stableWeight}%`);
        
        // Apply Traffic Shift
        await this.k8s.updateServiceTraffic(`${appName}-service`, stableWeight, canaryWeight);

        // Wait for stabilization (e.g., 2 minutes in real world, 2s here)
        console.log("Waiting for stabilization...");
        await new Promise(resolve => setTimeout(resolve, 1000));

        // Collect Metrics
        const metrics = await this.k8s.getMetrics(`${appName}-canary`);
        console.log(`Metrics -> Latency: ${metrics.latencyP95}ms | Error Rate: ${(metrics.errorRate * 100).toFixed(2)}%`);

        // AI-Driven Health Check (Zero-Shot Classification)
        const healthStatus = this.aiDetector.classify(metrics, this.config.healthThresholds);
        console.log(`AI Analysis -> Status: ${healthStatus}`);

        // Step 3: Decision Logic
        if (healthStatus === 'Critical') {
          console.error(`\n❌ ALERT: Critical anomaly detected at ${canaryWeight}% traffic.`);
          await this.handleRollback(appName, stableVersion);
          return; // Stop execution
        }

        if (healthStatus === 'Degraded') {
          console.warn(`⚠️  WARNING: Performance degradation detected. Pausing for manual review.`);
          // In a fully automated pipeline, we might pause or rollback depending on strictness.
          // Here we pause execution to simulate a manual gate.
          break; 
        }
      }

      // Step 4: Finalize Deployment (Promote Canary to Stable)
      console.log(`\n✅ Canary verification passed. Promoting v${newVersion} to Stable.`);
      // In reality: Update the stable deployment image and scale down canary
      console.log(`[K8s API] Updating '${appName}-stable' to v${newVersion}.`);
      console.log(`[K8s API] Scaling down '${appName}-canary'.`);
      console.log(`\n🎉 Deployment Complete: Zero Downtime Achieved.`);

    } catch (error) {
      console.error("Deployment Pipeline Error:", error);
      await this.handleRollback(appName, stableVersion);
    }
  }

  /**
   * Handles the automated rollback procedure.
   * This ensures system stability by reverting to the last known good state.
   */
  private async handleRollback(appName: string, stableVersion: string): Promise<void> {
    console.log("\n🛡️  Initiating Automated Rollback Protocol...");
    await this.k8s.rollback(`${appName}-service`, stableVersion);
    console.log("🛡️  Rollback Complete. System restored to stable state.");
  }
}

// ============================================================================
// 5. EXECUTION BLOCK (Simulating a GitHub Actions Job)
// ============================================================================

/**
 * Main execution function.
 * This simulates the entry point of a GitHub Actions workflow step.
 */
async function main() {
  // Configuration for the SaaS App "Nexus Dashboard"
  const deploymentConfig: DeploymentConfig = {
    canaryReplicas: 2, // Small subset of pods for canary
    steps: [10, 25, 50, 100], // Traffic shifting percentages
    healthThresholds: {
      maxErrorRate: 0.05, // 5%
      maxLatency: 300     // 300ms
    }
  };

  const orchestrator = new DeploymentOrchestrator(deploymentConfig);

  // Simulate deploying version 3.0.0 over 2.9.0
  await orchestrator.executeCanaryDeployment("nexus-dashboard", "3.0.0", "2.9.0");
}

// Execute the script
if (require.main === module) {
  main().catch(console.error);
}
