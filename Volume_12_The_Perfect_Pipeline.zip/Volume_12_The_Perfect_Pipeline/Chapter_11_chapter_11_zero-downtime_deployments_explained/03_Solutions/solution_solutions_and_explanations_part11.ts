/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part11.ts
// Description: Solutions and Explanations
// ==========================================

name: AI-Driven Canary Deployment

on:
  push:
    branches: [ main ]

jobs:
  canary-deploy:
    runs-on: ubuntu-latest
    steps:
    - name: Checkout code
      uses: actions/checkout@v2

    - name: Configure Kubectl & Istio
      run: |
        # Setup kubectl and istioctl (assumed installed/configured)

    - name: Deploy Canary Version
      run: |
        # Deploy canary deployment (omitted for brevity)
        kubectl apply -f deployment-canary.yaml
        # Update VirtualService to 95/5 split
        kubectl apply -f checkout-vs.yaml

    - name: AI Anomaly Detection Loop
      run: |
        for i in {1..5}; do
          echo "Check $i/5..."
          # Run the TypeScript script (assuming ts-node is installed)
          ts-node anomaly-detector.ts
          EXIT_CODE=$?
          
          if [ $EXIT_CODE -eq 1 ]; then
            echo "CRITICAL FAILURE DETECTED. Initiating Rollback."
            # Update VS to 0% canary
            kubectl patch virtualservice checkout-vs --type='json' -p='[{"op": "replace", "path": "/spec/http/0/route/1/weight", "value": 0}]'
            kubectl patch virtualservice checkout-vs --type='json' -p='[{"op": "replace", "path": "/spec/http/0/route/0/weight", "value": 100}]'
            exit 1
          elif [ $EXIT_CODE -eq 0 ]; then
            echo "Normal behavior. Continuing..."
          else
            echo "Degradation detected. Waiting..."
          fi
          sleep 60
        done
        
        echo "All checks passed. Promoting to 100%."
        kubectl patch virtualservice checkout-vs --type='json' -p='[{"op": "replace", "path": "/spec/http/0/route/1/weight", "value": 100}]'
        kubectl patch virtualservice checkout-vs --type='json' -p='[{"op": "replace", "path": "/spec/http/0/route/0/weight", "value": 0}]'
