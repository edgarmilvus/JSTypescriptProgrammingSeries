/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part13.ts
// Description: Solutions and Explanations
// ==========================================

digraph DeploymentStrategies {
    rankdir=TB;
    node [shape=box, style=rounded, fontname="Helvetica"];

    subgraph cluster_blue_green {
        label = "Blue-Green Deployment";
        style = dashed;
        
        // Nodes
        User_BG [label="User Traffic", shape=ellipse];
        Service_BG [label="Service", shape=cylinder];
        
        subgraph cluster_blue {
            label = "Blue (Current)";
            style = filled;
            color = lightblue;
            B1 [label="Pod v1.0"];
            B2 [label="Pod v1.0"];
        }
        
        subgraph cluster_green {
            label = "Green (New)";
            style = filled;
            color = lightgreen;
            G1 [label="Pod v1.1"];
            G2 [label="Pod v1.1"];
        }

        // Edges
        User_BG -> Service_BG [label="Traffic"];
        Service_BG -> B1 [label="100%", color="blue", fontcolor="blue"];
        Service_BG -> G1 [style="dotted", label="0%", color="gray"];
        
        // Transition annotation
        Switch [label="Switch Selector\nInstant Traffic Shift", shape=note, fillcolor=yellow];
        Service_BG -> Switch [style="dotted"];
    }

    subgraph cluster_rolling {
        label = "Rolling Update";
        style = dashed;
        
        Time [label="Timeline", shape=plaintext];
        
        // Time steps
        T1 [label="t=0\n(Start)", shape=plaintext];
        T2 [label="t=1\n(Step 1)", shape=plaintext];
        T3 [label="t=2\n(Step 2)", shape=plaintext];
        T4 [label="t=3\n(Finish)", shape=plaintext];

        // Pods at different times
        P_Old1 [label="Old", fillcolor="#ffcccc", style=filled];
        P_Old2 [label="Old", fillcolor="#ffcccc", style=filled];
        P_New1 [label="New", fillcolor="#ccffcc", style=filled];
        P_New2 [label="New", fillcolor="#ccffcc", style=filled];

        // Layout edges (invisible for rank)
        {rank=same; T1; P_Old1; P_Old2}
        {rank=same; T2; P_Old1; P_New1}
        {rank=same; T3; P_Old2; P_New1}
        {rank=same; T4; P_New1; P_New2}

        // Flow
        T1 -> T2 [style=invis];
        T2 -> T3 [style=invis];
        T3 -> T4 [style=invis];
        
        // Traffic label
        Traffic_Roll [label="Traffic distributed\namong available pods", shape=note];
    }

    subgraph cluster_canary {
        label = "Canary Release";
        style = dashed;
        
        User_C [label="User Traffic", shape=ellipse];
        VS [label="VirtualService", shape=component];
        
        subgraph cluster_stable {
            label = "Stable (v1)";
            style = filled;
            color = lightblue;
            S1 [label="Pod"];
        }
        
        subgraph cluster_canary_node {
            label = "Canary (v2)";
            style = filled;
            color = orange;
            C1 [label="Pod"];
        }

        // Edges
        User_C -> VS;
        VS -> S1 [label="95%", penwidth=2];
        VS -> C1 [label="5%", penwidth=1];
        
        // Progression
        Promote [label="Promote:\n0% -> 100%", shape=note];
        Rollback [label="Rollback:\n5% -> 0%", shape=note];
        VS -> Promote [style="dotted"];
        VS -> Rollback [style="dotted"];
    }
}
