/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part14.ts
// Description: Solutions and Explanations
// ==========================================

// File: migration-expand.ts (Idempotent Expand Step)

import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

async function expandMigration() {
  console.log("Starting Expand Migration...");

  // 1. Add new column 'handle' if it doesn't exist
  // Note: Prisma doesn't support raw schema changes directly in migration files easily without raw SQL
  // This is the raw SQL logic usually wrapped in a migration tool
  /*
    ALTER TABLE "users" 
    ADD COLUMN IF NOT EXISTS "handle" VARCHAR(255);
  */
  await prisma.$executeRaw`ALTER TABLE "users" ADD COLUMN IF NOT EXISTS "handle" VARCHAR(255);`;

  // 2. Backfill existing data
  // Sync 'username' to 'handle' where 'handle' is currently null
  /*
    UPDATE "users" 
    SET "handle" = "username" 
    WHERE "handle" IS NULL;
  */
  await prisma.$executeRaw`UPDATE "users" SET "handle" = "username" WHERE "handle" IS NULL;`;

  // 3. Dual-Write Logic (Simulated in Application Code, see below)
  
  console.log("Expand Migration Complete.");
  await prisma.$disconnect();
}

expandMigration().catch(e => {
  console.error(e);
  process.exit(1);
});
