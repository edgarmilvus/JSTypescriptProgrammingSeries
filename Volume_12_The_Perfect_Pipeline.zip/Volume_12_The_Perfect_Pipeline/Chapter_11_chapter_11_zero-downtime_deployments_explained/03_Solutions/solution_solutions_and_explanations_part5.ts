/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

name: Blue-Green Deployment

on:
  push:
    branches: [ main ]

jobs:
  deploy:
    runs-on: ubuntu-latest
    steps:
    - name: Checkout code
      uses: actions/checkout@v2

    - name: Configure Kubectl
      uses: azure/k8s-set-context@v1
      with:
        method: kubeconfig
        kubeconfig: ${{ secrets.KUBE_CONFIG }}

    - name: Build Docker Image
      run: |
        docker build -t your-registry/nextjs-app:v1.1 .
        docker push your-registry/nextjs-app:v1.1

    - name: Deploy Green Environment
      run: kubectl apply -f deployment-green.yaml

    - name: Wait for Green Pods to be Ready
      run: kubectl rollout status deployment/nextjs-green --timeout=300s

    - name: Verify Green Health
      id: health_check
      run: |
        # Get the external IP of the service (assuming LoadBalancer)
        # In a real scenario, you might use port-forwarding or a specific test URL
        # For this exercise, we simulate a curl check against the Green pods directly or a test endpoint
        echo "Performing health check on Green deployment..."
        # Simulating a health check command. In real life, you'd wait for Service switch or use NodePort
        kubectl exec deployment/nextjs-green -- curl -f http://localhost:3000/health || exit 1
        
    - name: Switch Traffic to Green
      if: success()
      run: |
        kubectl patch service nextjs-service -p '{"spec":{"selector":{"app":"nextjs","version":"green"}}}'

    - name: Rollback to Blue (On Failure)
      if: failure()
      run: |
        echo "Health check failed. Rolling back to Blue..."
        # Revert Service selector
        kubectl patch service nextjs-service -p '{"spec":{"selector":{"app":"nextjs","version":"blue"}}}'
        # Delete Green deployment to clean up
        kubectl delete deployment nextjs-green
