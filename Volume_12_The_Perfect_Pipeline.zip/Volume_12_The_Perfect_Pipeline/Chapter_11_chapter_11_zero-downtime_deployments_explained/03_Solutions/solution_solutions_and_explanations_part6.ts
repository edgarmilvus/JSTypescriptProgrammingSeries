/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part6.ts
// Description: Solutions and Explanations
// ==========================================

// File: bad-api-server.ts
// This script simulates a Node.js API that fails readiness after 10 seconds.

import * as http from 'http';

let isReady = true;
const PORT = 3000;

// Simulate regression after 10 seconds
setTimeout(() => {
    console.log("SIMULATING REGRESSION: Failing readiness probe.");
    isReady = false;
}, 10000);

const server = http.createServer((req, res) => {
    if (req.url === '/healthz') {
        // Liveness probe: Always return 200 until process dies
        res.writeHead(200);
        res.end('OK');
    } else if (req.url === '/ready') {
        // Readiness probe: Fail after 10s
        if (isReady) {
            res.writeHead(200);
            res.end('Ready');
        } else {
            res.writeHead(500);
            res.end('Not Ready');
        }
    } else {
        res.writeHead(200);
        res.end('API Endpoint');
    }
});

server.listen(PORT, () => {
    console.log(`Bad API running on port ${PORT}`);
});
