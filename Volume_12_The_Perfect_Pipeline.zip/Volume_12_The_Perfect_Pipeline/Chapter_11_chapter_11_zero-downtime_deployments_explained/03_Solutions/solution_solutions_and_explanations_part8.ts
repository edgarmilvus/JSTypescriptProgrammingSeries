/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part8.ts
// Description: Solutions and Explanations
// ==========================================

name: Rolling Update with Auto-Rollback

on:
  push:
    branches: [ main ]

jobs:
  deploy:
    runs-on: ubuntu-latest
    steps:
    - name: Checkout code
      uses: actions/checkout@v2

    - name: Configure Kubectl
      uses: azure/k8s-set-context@v1
      with:
        method: kubeconfig
        kubeconfig: ${{ secrets.KUBE_CONFIG }}

    - name: Build and Push Bad Image
      run: |
        docker build -t your-registry/bad-api:v1.0 .
        docker push your-registry/bad-api:v1.0

    - name: Apply Deployment
      run: kubectl apply -f deployment-rolling.yaml

    - name: Monitor Rollout Status
      id: rollout
      run: |
        # Wait for rollout to finish, but if it fails, catch the error
        if ! kubectl rollout status deployment/node-api --timeout=120s; then
          echo "ROLLOUT_FAILED=true" >> $GITHUB_ENV
        fi

    - name: Detect Failure and Rollback
      if: env.ROLLOUT_FAILED == 'true'
      run: |
        echo "Detected rollout failure. Checking pod status..."
        kubectl get pods -l app=api
        echo "Triggering rollback..."
        kubectl rollout undo deployment/node-api
        echo "Rollback initiated."
