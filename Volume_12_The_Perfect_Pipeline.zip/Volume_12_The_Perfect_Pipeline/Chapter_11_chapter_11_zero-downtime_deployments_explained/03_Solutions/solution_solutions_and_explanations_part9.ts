/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part9.ts
// Description: Solutions and Explanations
// ==========================================

// File: anomaly-detector.ts

// Simulated Prometheus metrics response
interface Metric {
  metric: { [key: string]: string };
  value: [number, string];
}

interface PrometheusResponse {
  data: {
    result: Metric[];
  };
}

// Simulated AI Classification Logic
function classifyBehavior(errorRate: number): "Normal" | "Performance Degradation" | "Critical Failure" {
  if (errorRate > 1.0) {
    return "Critical Failure";
  } else if (errorRate > 0.5) {
    return "Performance Degradation";
  }
  return "Normal";
}

async function analyzeCanary(): Promise<void> {
  console.log("Querying Prometheus for canary metrics...");
  
  // In a real scenario, we would fetch from Prometheus API:
  // const response = await fetch('http://prometheus:9090/api/v1/query?query=...');
  
  // SIMULATION: Randomly generate metrics for the exercise
  const simulatedErrorRate = Math.random() * 2.0; // 0.0 to 2.0%
  
  console.log(`Simulated Canary Error Rate: ${simulatedErrorRate.toFixed(2)}%`);
  
  const classification = classifyBehavior(simulatedErrorRate);
  
  console.log(`AI Classification: ${classification}`);

  // Output classification for GitHub Actions to parse
  // In a real workflow, we might write this to a file or exit with a specific code
  if (classification === "Critical Failure") {
    console.log("ACTION: ROLLBACK");
    process.exit(1); // Signal failure to workflow
  } else if (classification === "Normal") {
    console.log("ACTION: PROMOTE");
    process.exit(0); // Signal success
  } else {
    // Degradation: Monitor longer
    console.log("ACTION: MONITOR");
    process.exit(2); // Signal monitoring state
  }
}

analyzeCanary();
