/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example_part3.ts
// Description: Basic Code Example
// ==========================================

// src/index.ts

// 1. IMPORTS
// We import the 'scheduleJob' function from the 'node-schedule' library.
// This library provides a robust way to schedule jobs in Node.js.
import { scheduleJob } from 'node-schedule';

// 2. ASYNC TOOL SIMULATION
/**
 * Simulates an asynchronous tool call, such as a database query or an external API request.
 * In a real-world scenario, this function would perform an I/O operation.
 * @returns {Promise<string>} A promise that resolves with a success message after a short delay.
 */
async function simulateAsyncToolCall(): Promise<string> {
  console.log('[Tool] Starting simulated async operation (e.g., fetching user data)...');
  
  // Simulate a network delay of 500ms using a Promise.
  // In a real app, this would be 'await fetch(...)' or 'await db.query(...)'.
  await new Promise(resolve => setTimeout(resolve, 500));
  
  console.log('[Tool] Async operation complete.');
  return 'Data processed successfully';
}

// 3. THE JOB HANDLER
/**
 * The main job handler function. This is an async function that will be executed
 * by the scheduler. It demonstrates the pattern of awaiting external tools.
 * 
 * @param {Date} fireDate - The date the job was scheduled to run (provided by node-schedule).
 */
async function jobHandler(fireDate: Date): Promise<void> {
  console.log(`\n--- Job Triggered at: ${fireDate.toISOString()} ---`);
  
  try {
    // This is the core of Asynchronous Tool Handling.
    // We 'await' the result of our simulated tool before proceeding.
    const result = await simulateAsyncToolCall();
    
    // Once the tool completes, we can use its result.
    console.log(`[Job] Result from tool: "${result}"`);
    console.log('[Job] Task finished. Waiting for next schedule...');
    
  } catch (error) {
    // Always handle potential errors from async operations.
    console.error('[Job] An error occurred during execution:', error);
  }
}

// 4. SCHEDULER INITIALIZATION
/**
 * Initializes the scheduler to run the job every minute.
 * Cron-style syntax: '* * * * *' means 'at every minute'.
 * 
 * In a SaaS context, this could be a daily report generator, a data cleanup task,
 * or a user notification checker.
 */
const rule = new scheduleJob('*/1 * * * *', jobHandler);

// 5. APPLICATION STARTUP LOG
console.log('🚀 Async Scheduler Service Started.');
console.log(`Next job will run at: ${rule.nextInvocation()}`);
console.log('Press Ctrl+C to exit.');
