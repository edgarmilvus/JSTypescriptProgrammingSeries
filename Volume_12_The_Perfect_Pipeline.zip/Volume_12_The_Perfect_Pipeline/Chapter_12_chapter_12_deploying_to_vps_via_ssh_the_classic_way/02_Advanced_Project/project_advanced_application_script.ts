/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// pages/api/deploy-documentation.ts
// Next.js API Route (TypeScript)

import { NextApiRequest, NextApiResponse } from 'next';
import { Pinecone } from '@pinecone-database/pinecone';
import { openai } from '@ai-sdk/openai';
import { generateText } from 'ai';
import { NodeSSH } from 'node-ssh';
import fs from 'fs';
import path from 'path';
import os from 'os';

// ============================================================================
// 1. CONFIGURATION & TYPES
// ============================================================================

/**
 * Represents the secure configuration for the VPS deployment target.
 * In a production environment, these secrets should be injected via 
 * environment variables (e.g., AWS Secrets Manager or Vercel Env Vars).
 */
interface DeploymentConfig {
  host: string;
  username: string;
  privateKeyPath: string; // Path to SSH Key (e.g., ~/.ssh/id_rsa)
  targetDir: string;      // Remote directory path (e.g., /var/www/docs-app)
}

/**
 * Represents the payload expected from the frontend client.
 */
interface DeploymentRequest {
  documentationTopic: string;
  userId: string;
  version: string;
}

// ============================================================================
// 2. HELPER: AI CONTENT GENERATION (Vercel AI SDK)
// ============================================================================

/**
 * Generates structured documentation content using the Vercel AI SDK.
 * 
 * Why: We use AI to generate the artifacts that will be deployed.
 * How: Uses 'generateText' with a structured prompt.
 * Under the Hood: This calls the OpenAI GPT-4o-mini model via the Vercel AI SDK's unified interface.
 */
async function generateDocumentation(topic: string): Promise<string> {
  const prompt = `
    You are a technical writer. Write a concise, high-quality documentation page 
    about the following topic: "${topic}".
    
    Format the output in raw Markdown. Include:
    1. Introduction
    2. Key Features
    3. Code Example
    4. Conclusion
  `;

  const { text } = await generateText({
    model: openai('gpt-4o-mini'),
    prompt: prompt,
    temperature: 0.7,
  });

  return text;
}

// ============================================================================
// 3. HELPER: VECTOR DATABASE STORAGE (Pinecone)
// ============================================================================

/**
 * Upserts the generated documentation into Pinecone for semantic search.
 * 
 * Why: To make the generated content searchable by future users.
 * How: Converts text to a vector embedding (via OpenAI) and stores it.
 * Under the Hood: Uses the Pinecone Node.js Client to interact with the vector index.
 */
async function storeInPinecone(content: string, topic: string, userId: string): Promise<void> {
  try {
    const pc = new Pinecone({
      apiKey: process.env.PINECONE_API_KEY!,
    });
    
    const index = pc.Index('documentation-search');
    
    // Note: In a real app, we would generate embeddings using 'embed' from 'ai'.
    // For this script, we simulate the vector ID generation.
    const vectorId = `${userId}-${topic.toLowerCase().replace(/\s+/g, '-')}`;

    await index.upsert([
      {
        id: vectorId,
        values: Array(1536).fill(0).map(() => Math.random()), // Mock embedding vector
        metadata: {
          topic: topic,
          content: content.substring(0, 1000), // Store snippet
          userId: userId,
        },
      },
    ]);

    console.log(`[Pinecone] Successfully indexed content for ${topic}`);
  } catch (error) {
    console.error('[Pinecone] Error upserting vector:', error);
    // Non-critical failure: Log but continue deployment
  }
}

// ============================================================================
// 4. HELPER: SSH & SCP DEPLOYMENT (The Classic Way)
// ============================================================================

/**
 * Establishes an SSH connection and transfers files via SCP.
 * 
 * Why: Secure, passwordless authentication is required for CI/CD pipelines.
 * How: Uses 'node-ssh' wrapper around the native SSH protocol.
 * Under the Hood: 
 * 1. Reads the local private key.
 * 2. Connects to the VPS on port 22.
 * 3. Uses SCP to upload the artifact.
 * 4. Executes a remote command to restart the service.
 */
async function deployToVPS(
  config: DeploymentConfig, 
  artifactContent: string, 
  filename: string
): Promise<void> {
  const ssh = new NodeSSH();

  try {
    console.log(`[SSH] Connecting to ${config.host}...`);
    
    // 1. Connect using Private Key (Passwordless Auth)
    await ssh.connect({
      host: config.host,
      username: config.username,
      privateKey: fs.readFileSync(config.privateKeyPath, 'utf8'),
      port: 22,
    });

    console.log('[SSH] Connection established.');

    // 2. Prepare Artifact Locally
    // In a real pipeline, this would be the build output (e.g., .next/ folder).
    // Here, we write the AI-generated markdown to a temp file.
    const localTempDir = os.tmpdir();
    const localArtifactPath = path.join(localTempDir, filename);
    
    fs.writeFileSync(localArtifactPath, artifactContent);

    // 3. Transfer File (SCP)
    // This mimics the 'scp' command: scp local.file user@host:/remote/dir
    await ssh.putFile(localArtifactPath, `${config.targetDir}/${filename}`);
    
    console.log(`[SCP] File transferred to ${config.targetDir}/${filename}`);

    // 4. Post-Deployment Command (Hardening & Activation)
    // Example: Set permissions and restart the Nginx service.
    const commands = [
      `chmod 644 ${config.targetDir}/${filename}`,
      `sudo systemctl reload nginx`, // Assuming Nginx serves the static file
    ];

    for (const cmd of commands) {
      const result = await ssh.execCommand(cmd);
      if (result.code !== 0) {
        console.warn(`[SSH] Command failed: ${cmd}`, result.stderr);
      } else {
        console.log(`[SSH] Executed: ${cmd}`);
      }
    }

  } catch (error) {
    console.error('[SSH] Deployment failed:', error);
    throw new Error('VPS Deployment failed. Check SSH credentials or Firewall rules.');
  } finally {
    ssh.dispose();
  }
}

// ============================================================================
// 5. MAIN API HANDLER
// ============================================================================

/**
 * Next.js API Route Handler.
 * 
 * Flow:
 * 1. Validate Request & Auth.
 * 2. Generate Content (AI).
 * 3. Index Content (Pinecone).
 * 4. Deploy to VPS (SSH/SCP).
 * 5. Return Success Response.
 */
export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  // Only allow POST requests
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method Not Allowed' });
  }

  // Security: Basic Input Validation
  const { documentationTopic, userId, version } = req.body as DeploymentRequest;
  if (!documentationTopic || !userId) {
    return res.status(400).json({ error: 'Missing required fields.' });
  }

  try {
    // Step 1: Generate Documentation using Vercel AI SDK
    console.log('Step 1: Generating content via AI...');
    const markdownContent = await generateDocumentation(documentationTopic);

    // Step 2: Store Metadata in Pinecone
    console.log('Step 2: Indexing in Pinecone...');
    await storeInPinecone(markdownContent, documentationTopic, userId);

    // Step 3: Define VPS Configuration
    // In production, fetch this from a database based on userId/tenantId.
    const deploymentConfig: DeploymentConfig = {
      host: process.env.VPS_HOST_IP!,
      username: 'deploy_user', // Least privilege user
      privateKeyPath: path.join(os.homedir(), '.ssh', 'id_rsa'), // Standard SSH location
      targetDir: '/var/www/docs-app/public', // Production web root
    };

    // Step 4: Deploy via SSH/SCP
    console.log('Step 3: Deploying to VPS...');
    const filename = `doc-${Date.now()}.md`;
    await deployToVPS(deploymentConfig, markdownContent, filename);

    // Step 5: Success Response
    return res.status(200).json({
      success: true,
      message: 'Documentation generated and deployed successfully.',
      deploymentDetails: {
        topic: documentationTopic,
        file: filename,
        server: deploymentConfig.host,
      },
    });

  } catch (error) {
    console.error('Deployment Pipeline Error:', error);
    return res.status(500).json({
      success: false,
      error: 'Internal Server Error during deployment pipeline.',
    });
  }
}

// ============================================================================
// 6. UTILITY: FIREWALL HARDENING CHECK (Simulated)
// ============================================================================

/**
 * Simulates a pre-flight check for VPS firewall rules.
 * 
 * Why: Ensures port 22 (SSH) is open for the CI runner IP but blocked globally.
 * Under the Hood: This would typically be a separate script or Ansible playbook.
 */
async function checkFirewallRules(vpsIp: string): Promise<boolean> {
  // In a real scenario, this would use 'node-ssh' to run:
  // sudo ufw status verbose
  console.log(`[Security] Checking firewall rules for ${vpsIp}...`);
  // Mock return
  return true; 
}
