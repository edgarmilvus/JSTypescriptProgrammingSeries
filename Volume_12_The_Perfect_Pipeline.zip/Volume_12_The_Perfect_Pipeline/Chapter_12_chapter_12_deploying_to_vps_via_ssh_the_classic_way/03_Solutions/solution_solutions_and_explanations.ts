/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// This script simulates the steps required for the Secure SSH Handshake.
// It prints the commands you would run in your terminal to achieve the goal.

console.log("--- Exercise 1: Secure SSH Handshake Simulation ---\n");

// 1. Generate Keys (Local Machine)
console.log("Step 1: Generating ED25519 SSH Key Pair (Local)");
console.log("Command: ssh-keygen -t ed25519 -f ~/.ssh/vps_key -N ''");
console.log("Result: Created private key 'vps_key' and public key 'vps_key.pub'.\n");

// 2. Copy Public Key
console.log("Step 2: Copying Public Key to Remote VPS");
const remoteUser = "user";
const remoteIP = "192.168.1.100";
console.log(`Command: ssh-copy-id -i ~/.ssh/vps_key.pub ${remoteUser}@${remoteIP}`);
console.log("Result: Public key appended to remote ~/.ssh/authorized_keys.\n");

// 3. Verify Passwordless Login
console.log("Step 3: Verifying Passwordless Login");
console.log(`Command: ssh -i ~/.ssh/vps_key ${remoteUser}@${remoteIP} "echo 'Connection Successful'"`);
console.log("Result: Should output 'Connection Successful' without a password prompt.\n");

// 4. Firewall Hardening (Remote VPS)
console.log("Step 4: Hardening Firewall (Run on Remote VPS)");
console.log("Command: sudo ufw default deny incoming");
console.log("Command: sudo ufw default allow outgoing");
console.log("Command: sudo ufw allow 22/tcp");
console.log("Command: sudo ufw allow 80/tcp");
console.log("Command: sudo ufw allow 443/tcp");
console.log("Command: sudo ufw --force enable");
console.log("Result: UFW is active, restricting access to ports 22, 80, 443 only.\n");

// 5. Security Audit & Fail2Ban
console.log("Step 5: Configuring Fail2Ban for SSH Protection (Remote VPS)");
console.log("Command: sudo apt install fail2ban");
console.log("Command: sudo cp /etc/fail2ban/jail.conf /etc/fail2ban/jail.local");
console.log("Command: sudo nano /etc/fail2ban/jail.local");
console.log("   -> Set: maxretry = 3, bantime = 600");
console.log("Command: sudo systemctl restart fail2ban");
console.log("Command: sudo fail2ban-client status sshd");
console.log("Result: Monitoring active. 4 failed attempts will ban the IP for 10 minutes.");
