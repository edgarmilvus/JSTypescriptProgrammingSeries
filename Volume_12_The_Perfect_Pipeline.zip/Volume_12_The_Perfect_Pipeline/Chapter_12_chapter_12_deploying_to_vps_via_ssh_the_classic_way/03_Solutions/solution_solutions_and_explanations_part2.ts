/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

// This script generates the content for the 'deploy.sh' file required in Exercise 2.

const deployScriptContent = `
#!/bin/bash

# Exit immediately if a command exits with a non-zero status.
set -e

# 1. Argument Parsing
VPS_IP=\${1:-}
TARGET_DIR=\${2:-/var/www/html}

if [ -z "\$VPS_IP" ]; then
    echo "Usage: ./deploy.sh <vps_ip> [target_directory]"
    exit 1
fi

echo "🚀 Starting deployment to \$VPS_IP..."

# 2. Artifact Packaging (Excluding node_modules, .git, dist)
TIMESTAMP=\$(date +%Y%m%d_%H%M%S)
ARCHIVE_NAME="deploy_\${TIMESTAMP}.tar.gz"

echo "📦 Packaging artifacts..."
tar --exclude="node_modules" --exclude=".git" --exclude="dist" --exclude="build" -czf \$ARCHIVE_NAME ./*

if [ ! -f "\$ARCHIVE_NAME" ]; then
    echo "❌ Error: Archive creation failed."
    exit 1
fi

# 3. Secure Transfer (SCP)
echo "📡 Transferring archive to server..."
# The '||' operator handles the error case if scp fails (e.g., network timeout)
scp \$ARCHIVE_NAME deploy_user@\$VPS_IP:/tmp/ || { echo "❌ Error: SCP transfer failed (Network Timeout)"; rm \$ARCHIVE_NAME; exit 1; }

# 4. Remote Extraction & Cleanup
echo "🏗️  Extracting and cleaning up on remote server..."
ssh deploy_user@\$VPS_IP << EOF
    set -e
    # Create target directory if it doesn't exist
    mkdir -p \$TARGET_DIR
    
    # Create backup of current deployment
    if [ -d "\$TARGET_DIR" ]; then
        tar -czf /tmp/backup_\${TIMESTAMP}.tar.gz -C \$TARGET_DIR .
    fi

    # Extract new archive
    tar -xzf /tmp/\$ARCHIVE_NAME -C \$TARGET_DIR
    
    # Remove remote archive
    rm /tmp/\$ARCHIVE_NAME
EOF

# 5. Local Cleanup
rm \$ARCHIVE_NAME

echo "✅ Deployment successful to \$TARGET_DIR"
`;

// Outputting the generated script for the user to save as deploy.sh
console.log("--- Generated deploy.sh ---");
console.log(deployScriptContent);
