/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState, useEffect, useCallback } from 'react';
import { z } from 'zod';

// 1. Runtime Validation Schema
const ProductSchema = z.object({
  id: z.number(),
  name: z.string(),
  stock: z.number(),
});

const InventorySchema = z.array(ProductSchema);

type Product = z.infer<typeof ProductSchema>;

// Mock API function that simulates unreliability (50% failure rate)
const fetchInventoryMock = async (): Promise<Product[]> => {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      // Randomly decide success or failure
      const isSuccess = Math.random() > 0.5;

      if (!isSuccess) {
        reject(new Error("Network Error: API Timeout"));
        return;
      }

      // Randomly decide valid or malformed data
      const isMalformed = Math.random() > 0.5;
      
      if (isMalformed) {
        // @ts-ignore - Intentionally returning bad data
        resolve([{ id: 1, name: "Broken Item" }]); // Missing 'stock'
      } else {
        resolve([
          { id: 1, name: "Laptop", stock: 10 },
          { id: 2, name: "Mouse", stock: 50 },
        ]);
      }
    }, 1000); // 1 second delay
  });
};

export const InventoryList: React.FC = () => {
  const [data, setData] = useState<Product[]>([]);
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  // 2. Async Resilience Logic
  const loadData = useCallback(async () => {
    setLoading(true);
    setError(null);
    
    try {
      const response = await fetchInventoryMock();
      
      // 3. Runtime Validation (Zod)
      // If this fails, it throws a ZodError, caught below
      const validatedData = InventorySchema.parse(response);
      
      setData(validatedData);
    } catch (err: any) {
      // Handle both network errors and Zod validation errors
      if (err.issues) {
        setError("Data Integrity Error: Response format invalid.");
      } else {
        setError(err.message || "An unknown error occurred.");
      }
    } finally {
      setLoading(false);
    }
  }, []);

  // Trigger on mount
  useEffect(() => {
    loadData();
  }, [loadData]);

  // 4. Reconciliation (Skeleton UI vs Actual Data)
  if (loading) {
    return (
      <div className="skeleton-ui">
        <div className="skeleton-item">Loading...</div>
        <div className="skeleton-item">Loading...</div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="error-state">
        <p>Error: {error}</p>
        {/* 5. Retry Mechanism */}
        <button onClick={loadData} disabled={loading}>
          Retry
        </button>
      </div>
    );
  }

  return (
    <ul>
      {data.map((item) => (
        <li key={item.id}>
          {item.name} - Stock: {item.stock}
        </li>
      ))}
    </ul>
  );
};
