/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

import { Client, SFTPWrapper } from 'ssh2';
import * as fs from 'fs';
import * as path from 'path';

// Configuration (In production, use environment variables)
const config = {
  host: '192.168.1.100',
  username: 'user',
  privateKey: fs.readFileSync('/path/to/your/private/key'), // e.g., vps_key
};

const client = new Client();

// Helper to promisify the SSH command execution
const executeCommand = (conn: Client, command: string): Promise<{ stdout: string; stderr: string }> => {
  return new Promise((resolve, reject) => {
    conn.exec(command, (err, stream) => {
      if (err) {
        reject(err);
        return;
      }

      let stdout = '';
      let stderr = '';

      stream.on('data', (data: any) => {
        stdout += data.toString();
      }).stderr.on('data', (data: any) => {
        stderr += data.toString();
      }).on('close', (code: number) => {
        if (code !== 0) {
          reject(new Error(`Command failed with code ${code}: ${stderr}`));
        } else {
          resolve({ stdout, stderr });
        }
      });
    });
  });
};

// Helper to promisify SFTP upload
const uploadFile = (sftp: SFTPWrapper, localPath: string, remotePath: string): Promise<void> => {
  return new Promise((resolve, reject) => {
    // Ensure remote directory exists (basic check, usually done via exec)
    const remoteDir = path.dirname(remotePath);
    
    // We need to ensure the directory exists before uploading.
    // A robust way is executing mkdir via the main connection before SFTP.
    // However, strictly within SFTP flow, we rely on the stream.
    
    const writeStream = sftp.createWriteStream(remotePath);
    const readStream = fs.createReadStream(localPath);

    readStream.pipe(writeStream);

    writeStream.on('close', () => {
      resolve();
    });

    writeStream.on('error', (err) => {
      reject(err);
    });
  });
};

// Main Execution Block
(async () => {
  try {
    // 1. Establish Connection
    console.log('Connecting to server...');
    await new Promise<void>((resolve, reject) => {
      client.on('ready', resolve).on('error', reject).connect(config);
    });
    console.log('Connected.');

    // 2. Check Disk Usage (Requirement 3 & 4)
    console.log('\n--- Executing: df -h ---');
    const { stdout, stderr } = await executeCommand(client, 'df -h');
    if (stderr) console.warn('Stderr:', stderr);
    console.log('Result:\n', stdout);

    // 3. SFTP Upload (Interactive Challenge)
    console.log('--- Starting SFTP Upload ---');
    
    // Ensure remote directory exists first
    const remoteDir = '/home/user/uploads';
    await executeCommand(client, `mkdir -p ${remoteDir}`);

    const sftp = await new Promise<SFTPWrapper>((resolve, reject) => {
      client.sftp((err, sftp) => {
        if (err) reject(err);
        else resolve(sftp);
      });
    });

    const localFile = './config.json';
    const remoteFile = `${remoteDir}/config.json`;

    // Create a dummy file locally for upload
    fs.writeFileSync(localFile, JSON.stringify({ setting: "production", debug: false }));

    await uploadFile(sftp, localFile, remoteFile);
    console.log(`Uploaded ${localFile} to ${remoteFile}`);

    // 4. Verify Upload
    console.log('\n--- Verifying Upload (cat command) ---');
    const { stdout: catOutput } = await executeCommand(client, `cat ${remoteFile}`);
    console.log('Remote File Content:', catOutput);

    // Cleanup local file
    fs.unlinkSync(localFile);

  } catch (error) {
    console.error('❌ Operation Failed:', error);
  } finally {
    // 5. Resilience: Ensure connection closes
    console.log('\nClosing connection...');
    client.end();
  }
})();
