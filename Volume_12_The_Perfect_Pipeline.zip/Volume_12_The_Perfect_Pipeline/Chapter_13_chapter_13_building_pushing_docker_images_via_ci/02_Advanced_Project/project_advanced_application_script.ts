/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

/**
 * Pipeline Orchestrator for Dockerized SaaS Microservices
 * 
 * Context: Chapter 13 - Advanced Application Script
 * 
 * This script simulates a CI/CD runner that:
 * 1. Validates build configuration using JSON Schema validation.
 * 2. Handles concurrent Docker builds for multiple services.
 * 3. Manages multi-architecture image tagging (SHA, Semantic Version, 'latest').
 * 4. Authenticates and pushes to a container registry (simulated).
 * 
 * Dependencies: @types/node, typescript, zod (for schema validation)
 */

import { spawn, exec } from 'child_process';
import { promises as fs } from 'fs';
import path from 'path';
import { z } from 'zod'; // Used to simulate JSON Schema Output validation

// ============================================================================
// 1. CONFIGURATION & SCHEMA VALIDATION
// ============================================================================

/**
 * We define a strict schema for our build configuration. In a real scenario,
 * this replaces manual parsing of JSON files, ensuring type safety.
 * 
 * "Why": Prevents pipeline failures due to malformed config files.
 */
const BuildConfigSchema = z.object({
  projectName: z.string().min(3),
  registryUrl: z.string().url(),
  services: z.array(
    z.object({
      name: z.string(),
      dockerfilePath: z.string(),
      context: z.string(),
      platforms: z.array(z.enum(['linux/amd64', 'linux/arm64'])),
    })
  ),
  version: z.string().regex(/^\d+\.\d+\.\d+$/), // Semantic Versioning
});

type BuildConfig = z.infer<typeof BuildConfigSchema>;

// Mock configuration file content (simulating reading a 'pipeline.config.json')
const rawConfig = {
  projectName: "saas-core-engine",
  registryUrl: "https://hub.docker.com/u/mycompany",
  version: "1.2.0",
  services: [
    {
      name: "api-gateway",
      dockerfilePath: "./apps/api/Dockerfile",
      context: "./apps/api",
      platforms: ["linux/amd64", "linux/arm64"]
    },
    {
      name: "dashboard-frontend",
      dockerfilePath: "./apps/web/Dockerfile",
      context: "./apps/web",
      platforms: ["linux/amd64"]
    }
  ]
};

// ============================================================================
// 2. UTILITY FUNCTIONS (DOCKER & EXECUTION)
// ============================================================================

/**
 * Executes a shell command and returns the stdout.
 * Wraps child_process.spawn in a Promise to utilize the Event Loop efficiently.
 * 
 * @param command - The command to execute (e.g., 'docker')
 * @param args - Array of arguments
 * @returns Promise<string> - The stdout output
 */
const executeCommand = (command: string, args: string[]): Promise<string> => {
  return new Promise((resolve, reject) => {
    const child = spawn(command, args, { stdio: ['ignore', 'pipe', 'pipe'] });
    let stdout = '';
    let stderr = '';

    child.stdout.on('data', (data) => {
      stdout += data.toString();
    });

    child.stderr.on('data', (data) => {
      stderr += data.toString();
    });

    child.on('close', (code) => {
      if (code !== 0) {
        reject(new Error(`Command failed: ${command} ${args.join(' ')}\n${stderr}`));
      } else {
        resolve(stdout.trim());
      }
    });

    child.on('error', (err) => {
      reject(err);
    });
  });
};

/**
 * Generates Docker tags based on the strategy:
 * 1. Specific Version (e.g., 1.2.0)
 * 2. Major.Minor (e.g., 1.2)
 * 3. Latest (for the primary architecture)
 */
const generateTags = (projectName: string, serviceName: string, version: string): string[] => {
  const base = `${projectName}/${serviceName}`;
  return [
    `${base}:${version}`,
    `${base}:${version.split('.').slice(0, 2).join('.')}`, // Minor version alias
    `${base}:latest`
  ];
};

// ============================================================================
// 3. CORE LOGIC: BUILD & PUSH
// ============================================================================

/**
 * Builds a Docker image for a specific service using Buildx for multi-arch support.
 * 
 * Under the Hood:
 * - Uses 'docker buildx build' which creates a builder instance if needed.
 * - The '--platform' flag triggers QEMU emulation or cross-compilation.
 * - '--push' handles the upload directly to the registry.
 */
async function buildAndPushService(
  config: BuildConfig,
  service: BuildConfig['services'][0]
): Promise<void> {
  console.log(`\n[🚀] Starting build for: ${service.name}`);
  
  const tags = generateTags(config.projectName, service.name, config.version);
  
  // Construct arguments for Docker CLI
  const buildArgs = [
    'buildx', 'build',
    '--platform', service.platforms.join(','),
    ...tags.flatMap(t => ['-t', t]),
    '--push', // Automatically pushes to registry
    '-f', service.dockerfilePath,
    service.context
  ];

  try {
    console.log(`[⚙️] Executing: docker ${buildArgs.join(' ')}`);
    
    // In a real CI environment, we would stream this output to the logger.
    // Here we await the completion.
    const output = await executeCommand('docker', buildArgs);
    
    console.log(`[✅] Successfully built and pushed ${service.name}`);
    if (output) console.log(`[ℹ️] Build Output:\n${output}`);
  } catch (error) {
    console.error(`[❌] Build failed for ${service.name}:`, error.message);
    throw error; // Propagate to stop the pipeline
  }
}

/**
 * Orchestrates the entire pipeline flow.
 * 
 * 1. Validates Input (JSON Schema).
 * 2. Checks Docker environment.
 * 3. Executes builds (concurrently).
 * 4. Reports status.
 */
async function runPipeline(configData: unknown): Promise<void> {
  console.log('=== Starting SaaS Docker Pipeline ===');

  // Step 1: Validate Input (JSON Schema Output Simulation)
  console.log('[1/4] Validating configuration schema...');
  const parsedConfig = BuildConfigSchema.safeParse(configData);
  
  if (!parsedConfig.success) {
    console.error('[❌] Configuration Error:', parsedConfig.error.errors);
    process.exit(1);
  }
  
  const config = parsedConfig.data;

  // Step 2: Pre-flight Check
  console.log('[2/4] Checking Docker environment...');
  try {
    const version = await executeCommand('docker', ['--version']);
    console.log(`[ℹ️] Docker found: ${version}`);
  } catch (e) {
    console.error('[❌] Docker is not installed or not in PATH.');
    process.exit(1);
  }

  // Step 3: Concurrent Build Execution
  console.log(`[3/4] Processing ${config.services.length} services...`);
  
  // We use Promise.all to build services in parallel, leveraging Node.js concurrency.
  const buildPromises = config.services.map(service => 
    buildAndPushService(config, service)
  );

  try {
    await Promise.all(buildPromises);
  } catch (error) {
    console.error('[❌] Pipeline failed due to build errors.');
    process.exit(1);
  }

  // Step 4: Finalize
  console.log('[4/4] Pipeline Complete.');
  console.log('=====================================');
  
  // Generate a JSON artifact for the next CI step (e.g., deployment)
  const artifact = {
    timestamp: new Date().toISOString(),
    registry: config.registryUrl,
    project: config.projectName,
    version: config.version,
    images: config.services.map(s => ({
      service: s.name,
      tags: generateTags(config.projectName, s.name, config.version)
    }))
  };
  
  await fs.writeFile('pipeline-artifact.json', JSON.stringify(artifact, null, 2));
  console.log('[ℹ️] Artifact saved to pipeline-artifact.json');
}

// ============================================================================
// 4. EXECUTION ENTRY POINT
// ============================================================================

// Simulate running the script
runPipeline(rawConfig).catch(console.error);
