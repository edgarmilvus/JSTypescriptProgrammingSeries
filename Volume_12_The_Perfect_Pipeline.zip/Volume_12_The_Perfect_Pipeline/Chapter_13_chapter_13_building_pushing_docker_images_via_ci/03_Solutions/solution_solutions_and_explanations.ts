/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

# Stage 1: Builder
# Uses a lightweight Node.js Alpine image to compile TypeScript and install dependencies.
FROM node:18-alpine AS builder

# Set the working directory inside the container
WORKDIR /app

# Copy package manifests first to leverage Docker layer caching.
# If package.json and package-lock.json don't change, this layer is reused.
COPY package*.json ./

# Install ALL dependencies (including devDependencies like TypeScript and Jest)
# strictly using the lockfile for reproducible builds.
RUN npm ci

# Copy the entire source code into the builder stage
COPY . .

# Run the build script (assumed to compile TS to JS in a 'dist' folder)
RUN npm run build

# Stage 2: Production
# Start from a fresh Alpine image to ensure no build tools or source code remain.
FROM node:18-alpine AS production

# Install dumb-init to handle PID 1 signals gracefully
RUN apk add --no-cache dumb-init

# Create a non-root user for security
RUN addgroup -g 1001 -S nodejs && \
    adduser -S nodejs -u 1001

# Set the working directory
WORKDIR /app

# Copy package manifests again
COPY package*.json ./

# Install ONLY production dependencies (no devDependencies)
RUN npm ci --only=production && npm cache clean --force

# Copy the built artifacts from the builder stage
# --chown ensures the non-root user has permission to access the files
COPY --from=builder --chown=nodejs:nodejs /app/dist ./dist

# Switch to the non-root user
USER nodejs

# Set the entrypoint using dumb-init to manage processes
ENTRYPOINT ["dumb-init", "--"]

# Command to run the compiled application
CMD ["node", "dist/index.js"]
