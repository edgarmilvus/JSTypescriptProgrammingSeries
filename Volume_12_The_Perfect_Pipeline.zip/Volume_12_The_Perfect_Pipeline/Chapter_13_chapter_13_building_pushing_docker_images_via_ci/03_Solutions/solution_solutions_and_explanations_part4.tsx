/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState, useEffect } from 'react';

// Define the interface for the API response
interface BuildStatusData {
  status: 'queued' | 'in_progress' | 'completed';
  conclusion: 'success' | 'failure' | null;
  updatedAt: string;
}

// Mock API function to simulate fetching data
const fetchMockBuildStatus = async (repository: string, branch: string): Promise<BuildStatusData> => {
  // Simulate network delay
  await new Promise(resolve => setTimeout(resolve, 500));
  
  // Simulate random status changes for demonstration
  const statuses: BuildStatusData[] = [
    { status: 'queued', conclusion: null, updatedAt: new Date().toISOString() },
    { status: 'in_progress', conclusion: null, updatedAt: new Date().toISOString() },
    { status: 'completed', conclusion: 'success', updatedAt: new Date().toISOString() },
    { status: 'completed', conclusion: 'failure', updatedAt: new Date().toISOString() },
  ];
  
  // Return a random status (weighted towards success for demo)
  return statuses[Math.floor(Math.random() * 3)]; 
};

const DockerBuildStatus: React.FC<{ repository: string; branch?: string }> = ({ repository, branch = 'main' }) => {
  const [status, setStatus] = useState<'idle' | 'building' | 'success' | 'failed'>('idle');
  const [lastUpdated, setLastUpdated] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const checkStatus = async () => {
    setIsLoading(true);
    try {
      const data = await fetchMockBuildStatus(repository, branch);
      
      // Map API status to UI status
      if (data.status === 'queued' || data.status === 'in_progress') {
        setStatus('building');
      } else if (data.status === 'completed') {
        setStatus(data.conclusion === 'success' ? 'success' : 'failed');
      }
      setLastUpdated(data.updatedAt);
    } catch (error) {
      setStatus('failed');
      console.error("Failed to fetch build status", error);
    } finally {
      setIsLoading(false);
    }
  };

  // Poll every 10 seconds
  useEffect(() => {
    checkStatus(); // Initial fetch
    const interval = setInterval(checkStatus, 10000);
    return () => clearInterval(interval); // Cleanup on unmount
  }, [repository, branch]);

  // Helper to render visual indicator
  const renderStatusIndicator = () => {
    const baseStyle = { height: '12px', width: '12px', borderRadius: '50%', display: 'inline-block', marginRight: '8px' };
    
    switch (status) {
      case 'building':
        return <span style={{ ...baseStyle, backgroundColor: '#fbbf24' }} title="Building..."></span>; // Yellow
      case 'success':
        return <span style={{ ...baseStyle, backgroundColor: '#10b981' }} title="Success"></span>; // Green
      case 'failed':
        return <span style={{ ...baseStyle, backgroundColor: '#ef4444' }} title="Failed"></span>; // Red
      default:
        return <span style={{ ...baseStyle, backgroundColor: '#9ca3af' }} title="Idle"></span>; // Gray
    }
  };

  return (
    <div style={{ border: '1px solid #e5e7eb', padding: '16px', borderRadius: '8px', fontFamily: 'sans-serif', maxWidth: '300px' }}>
      <h3 style={{ margin: '0 0 8px 0', fontSize: '16px' }}>Docker Build Status</h3>
      <div style={{ display: 'flex', alignItems: 'center', marginBottom: '8px' }}>
        {renderStatusIndicator()}
        <span style={{ textTransform: 'capitalize', fontWeight: 600 }}>{status}</span>
      </div>
      <div style={{ fontSize: '12px', color: '#6b7280', marginBottom: '12px' }}>
        Last Updated: {lastUpdated ? new Date(lastUpdated).toLocaleTimeString() : 'Never'}
      </div>
      <button 
        onClick={checkStatus} 
        disabled={isLoading}
        style={{
          padding: '6px 12px',
          backgroundColor: '#3b82f6',
          color: 'white',
          border: 'none',
          borderRadius: '4px',
          cursor: isLoading ? 'not-allowed' : 'pointer',
          opacity: isLoading ? 0.7 : 1
        }}
      >
        {isLoading ? 'Checking...' : 'Manual Refresh'}
      </button>
    </div>
  );
};

export default DockerBuildStatus;
