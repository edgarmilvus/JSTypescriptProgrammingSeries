/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

digraph MultiStageBuild {
    rankdir=TB;
    node [shape=box, style="rounded,filled", fontname="Helvetica"];

    // Define Nodes
    subgraph cluster_builder {
        label = "Builder Stage (Build Environment)";
        style = dashed;
        color = blue;
        
        node [fillcolor="#e1f5fe"];
        B_Base [label="FROM node:18-alpine"];
        B_CopyDeps [label="COPY package*.json ./"];
        B_InstallDeps [label="RUN npm ci\n(Installs ALL dependencies)"];
        B_CopySrc [label="COPY . ."];
        B_Build [label="RUN npm run build\n(Compiles TS -> JS)"];
    }

    subgraph cluster_final {
        label = "Final Stage (Production)";
        style = dashed;
        color = green;
        
        node [fillcolor="#e8f5e9"];
        F_Base [label="FROM node:18-alpine"];
        F_User [label="RUN adduser nodejs\n(non-root user)"];
        F_CopyDeps [label="COPY package*.json ./\nRUN npm ci --only=production"];
        F_Artifacts [label="COPY --from=builder /app/dist ./dist"];
        F_Entry [label="USER nodejs\nENTRYPOINT/CMD"];
    }

    // Define Output
    Output [label="Production Image\n(node:alpine, dist/, prod node_modules, nodejs user)", shape=ellipse, fillcolor="#fff3e0"];

    // Define Edges / Flow
    B_Base -> B_CopyDeps -> B_InstallDeps -> B_CopySrc -> B_Build;

    // Artifact Transfer (Dashed Arrow)
    B_Build -> F_Artifacts [style=dashed, label="Transfer Artifacts\n(dist folder)", color=gray, fontcolor=gray];

    // Final Stage Flow
    F_Base -> F_User -> F_CopyDeps -> F_Artifacts -> F_Entry -> Output;

    // Styling for clarity
    {rank=same; B_Build; F_CopyDeps}
}
