/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * @fileoverview A "Hello World" example demonstrating a vector store upsert operation.
 * This simulates a SaaS feature for managing document embeddings for semantic search.
 * 
 * @author AI Instructor
 * @version 1.0
 */

// --- Type Definitions ---

/**
 * Represents a single vector record in our store.
 * @property id - A unique identifier for the document (e.g., a UUID).
 * @property vector - An array of numbers representing the document's embedding.
 * @property metadata - Optional metadata (e.g., source URL, timestamp).
 */
interface VectorRecord {
    id: string;
    vector: number[];
    metadata?: {
        source: string;
        lastUpdated: Date;
    };
}

/**
 * A simple in-memory representation of a Vector Store.
 * In a real-world scenario, this would be a connection to Pinecone, Milvus, or a PostgreSQL `pgvector` table.
 */
type VectorStore = Map<string, VectorRecord>;

// --- Core Logic ---

/**
 * Performs an upsert operation on a local, in-memory vector store.
 * 
 * Upsert Logic:
 * 1. Check if a record with the given ID already exists.
 * 2. If it exists: Update the vector and metadata.
 * 3. If it does not exist: Insert a new record.
 * 
 * @param store - The in-memory vector store (Map).
 * @param id - The unique ID for the document.
 * @param vector - The embedding vector to store.
 * @param metadata - Optional metadata associated with the document.
 * @returns The updated or newly created VectorRecord.
 */
function vectorStoreUpsert(
    store: VectorStore,
    id: string,
    vector: number[],
    metadata?: { source: string }
): VectorRecord {
    // 1. Define the record to be inserted or updated.
    const record: VectorRecord = {
        id,
        vector,
        metadata: {
            ...metadata,
            lastUpdated: new Date(), // Always update the timestamp on upsert
        },
    };

    // 2. Perform the upsert using the Map's `set` method.
    // In a real database, this would be a SQL query like:
    // INSERT INTO vectors (id, vector) VALUES ($1, $2) ON CONFLICT (id) DO UPDATE SET vector = $2;
    store.set(id, record);

    // 3. Return the record for confirmation or further processing.
    return record;
}

/**
 * A helper function to simulate vector generation.
 * In a real app, this would come from an AI model (e.g., OpenAI's text-embedding-ada-002).
 * 
 * @param text - The input text to embed.
 * @returns A dummy vector (array of 3 numbers for simplicity).
 */
function generateEmbedding(text: string): number[] {
    // This is a mock. A real embedding is a high-dimensional vector (e.g., 1536 dimensions).
    // We'll use a simple hash-like function to create deterministic "vectors" for this demo.
    let hash = 0;
    for (let i = 0; i < text.length; i++) {
        hash = ((hash << 5) - hash) + text.charCodeAt(i);
        hash |= 0; // Convert to 32bit integer
    }
    
    // Generate 3 pseudo-random numbers based on the hash
    const vec1 = Math.abs(Math.sin(hash)) * 10;
    const vec2 = Math.abs(Math.cos(hash)) * 10;
    const vec3 = Math.abs(Math.tan(hash)) * 10;
    
    return [parseFloat(vec1.toFixed(4)), parseFloat(vec2.toFixed(4)), parseFloat(vec3.toFixed(4))];
}

// --- Execution Flow (Main) ---

/**
 * Main execution function to demonstrate the upsert flow.
 * This simulates a user uploading a document to a SaaS platform.
 */
async function main() {
    console.log("🚀 Initializing Vector Store Upsert Demo...\n");

    // 1. Initialize our local "database".
    const myVectorStore: VectorStore = new Map();
    console.log("✅ Vector Store initialized (in-memory).");

    // 2. Define a document to process.
    const docId = "doc-123";
    const docText = "The quick brown fox jumps over the lazy dog.";
    console.log(`📄 Processing Document ID: ${docText}`);

    // 3. Generate an embedding for the text.
    const embedding = generateEmbedding(docText);
    console.log(`🔢 Generated Embedding: [${embedding.join(", ")}]`);

    // 4. Perform the initial UPSERT (Insert).
    console.log("\n--- Operation 1: Initial Insert ---");
    const result1 = vectorStoreUpsert(myVectorStore, docId, embedding, { source: "user-upload" });
    console.log("✅ Upsert successful. Result:", JSON.stringify(result1, null, 2));
    console.log(`📊 Store now contains ${myVectorStore.size} record(s).`);

    // 5. Simulate a document update (e.g., user edits the text).
    const updatedText = "The quick brown fox jumps over the **very** lazy dog.";
    const updatedEmbedding = generateEmbedding(updatedText); // New embedding for new text
    console.log("\n--- Operation 2: Update Existing (Upsert) ---");
    console.log(`📄 Updated Text: ${updatedText}`);
    console.log(`🔢 New Embedding: [${updatedEmbedding.join(", ")}]`);

    const result2 = vectorStoreUpsert(myVectorStore, docId, updatedEmbedding, { source: "user-edit" });
    console.log("✅ Upsert successful. Result:", JSON.stringify(result2, null, 2));
    console.log(`📊 Store still contains ${myVectorStore.size} record(s). (No duplicate created)`);

    // 6. Verify the update.
    const storedRecord = myVectorStore.get(docId);
    if (storedRecord && storedRecord.metadata?.source === "user-edit") {
        console.log("\n🔍 Verification: Record was successfully updated.");
    } else {
        console.error("\n❌ Verification failed: Record was not updated correctly.");
    }
}

// Run the main function
main().catch(console.error);
