/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

import { Client } from 'pg';
import { Pinecone, Vector } from '@pinecone-database/pinecone';
import { z } from 'zod';

// ==========================================
// 1. CONFIGURATION & STRICT TYPE DISCIPLINE
// ==========================================

/**
 * Environment variable validation using Zod.
 * Enforces strict type discipline at the runtime boundary (CI/CD pipeline).
 * This prevents deployment if required secrets are missing or malformed.
 */
const EnvSchema = z.object({
  DATABASE_URL: z.string().url(),
  PINECONE_API_KEY: z.string().min(1),
  PINECONE_ENVIRONMENT: z.string().min(1),
  PINECONE_INDEX_NAME: z.string().min(1),
});

const env = EnvSchema.parse(process.env);

/**
 * Application Data Model.
 * We define the shape of the data we expect to fetch from Postgres.
 * Using an interface ensures that `product.description` is strictly typed as string,
 * preventing runtime errors during vector generation.
 */
interface ProductRecord {
  id: number;
  name: string;
  description: string;
  category: string;
  updated_at: Date;
}

// ==========================================
// 2. SERVICE CLIENTS
// ==========================================

/**
 * Initialize PostgreSQL Client.
 * In a real CI/CD pipeline, this might be a connection pool.
 */
const pgClient = new Client({
  connectionString: env.DATABASE_URL,
  ssl: { rejectUnauthorized: false }, // Required for most cloud SQL providers
});

/**
 * Initialize Pinecone Client.
 * This interacts with the vector database to perform upserts.
 */
const pcClient = new Pinecone({
  apiKey: env.PINECONE_API_KEY,
  environment: env.PINECONE_ENVIRONMENT,
});

// ==========================================
// 3. MOCK AI EMBEDDING GENERATOR
// ==========================================

/**
 * Simulates an external AI embedding service (like OpenAI's text-embedding-ada-002).
 * In production, this would be an async API call.
 * 
 * @param text - The text to vectorize.
 * @returns A Promise resolving to an array of numbers (the vector).
 */
async function generateEmbedding(text: string): Promise<number[]> {
  // Simulating a 1536-dimensional vector (common for OpenAI models)
  // In a real scenario: const response = await openai.createEmbedding({ ... });
  const vector: number[] = Array.from({ length: 1536 }, () => Math.random());
  return vector;
}

// ==========================================
// 4. CORE LOGIC: MIGRATION SCRIPT
// ==========================================

/**
 * Orchestrates the synchronization of new Product records to the Pinecone vector index.
 * 
 * Logic Flow:
 * 1. Connect to the primary database.
 * 2. Fetch records that require vectorization (e.g., new or updated since last run).
 * 3. Generate embeddings for each record.
 * 4. Upsert vectors into Pinecone.
 * 5. Handle errors and ensure strict transactional awareness.
 * 
 * @param lastProcessedTimestamp - ISO string of the last time this script ran successfully.
 */
export async function syncVectorsToIndex(lastProcessedTimestamp: string): Promise<void> {
  console.log(`[Migration] Starting sync from: ${lastProcessedTimestamp}`);

  try {
    // --- Step 1: Connect to Primary DB ---
    await pgClient.connect();

    // --- Step 2: Fetch Delta Data ---
    // We use parameterized queries to prevent SQL injection.
    // This fetches products updated since the last migration run.
    const queryText = `
      SELECT id, name, description, category, updated_at 
      FROM products 
      WHERE updated_at > $1 
      ORDER BY updated_at ASC;
    `;
    
    const res = await pgClient.query<ProductRecord>(queryText, [lastProcessedTimestamp]);
    const records = res.rows;

    if (records.length === 0) {
      console.log('[Migration] No new records to process.');
      await pgClient.end();
      return;
    }

    console.log(`[Migration] Processing ${records.length} records...`);

    // --- Step 3: Vector Generation & Transformation ---
    // We map database rows to Pinecone Vector objects.
    // This is a critical transformation layer in the pipeline.
    const upsertPayloads: Vector[] = await Promise.all(
      records.map(async (record) => {
        // Combine fields for a richer semantic context
        const textToEmbed = `${record.name}. ${record.description}. Category: ${record.category}`;
        
        // Generate the vector (simulated AI call)
        const values = await generateEmbedding(textToEmbed);

        return {
          id: record.id.toString(), // Pinecone requires string IDs
          values: values,
          metadata: {
            name: record.name,
            category: record.category,
            // We store the timestamp to verify sync integrity later
            synced_at: new Date().toISOString(),
          },
        };
      })
    );

    // --- Step 4: Upsert to Pinecone (Vector DB) ---
    // We access the specific index defined in our environment.
    const index = pcClient.Index(env.PINECONE_INDEX_NAME);

    // Batch upsert to optimize network calls (Pinecone limit: 1000 vectors per upsert)
    const batchSize = 100;
    for (let i = 0; i < upsertPayloads.length; i += batchSize) {
      const batch = upsertPayloads.slice(i, i + batchSize);
      console.log(`[Migration] Upserting batch ${i / batchSize + 1}...`);
      
      // The core operation: Update or Insert based on ID
      await index.upsert(batch);
    }

    console.log('[Migration] Sync completed successfully.');

  } catch (error) {
    console.error('[Migration] Critical failure:', error);
    // In a CI/CD pipeline, throwing an error here should fail the deployment step
    throw new Error('Vector synchronization failed');
  } finally {
    // Ensure connection is closed to prevent hanging processes
    await pgClient.end();
  }
}

// ==========================================
// 5. EXECUTION ENTRY POINT
// ==========================================

/**
 * Script Entry Point.
 * In a CI/CD pipeline (GitHub Actions), this script is invoked via `ts-node`.
 * 
 * Example GitHub Actions Step:
 * - name: Run Vector Migration
 *   run: ts-node scripts/vector-sync.ts
 *   env:
 *     DATABASE_URL: ${{ secrets.DATABASE_URL }}
 *     PINECONE_API_KEY: ${{ secrets.PINECONE_API_KEY }}
 */
if (require.main === module) {
  // Simulating a "last run" timestamp (in reality, this might be stored in a state file or DB)
  const yesterday = new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString();
  
  syncVectorsToIndex(yesterday)
    .then(() => process.exit(0))
    .catch(() => process.exit(1));
}
