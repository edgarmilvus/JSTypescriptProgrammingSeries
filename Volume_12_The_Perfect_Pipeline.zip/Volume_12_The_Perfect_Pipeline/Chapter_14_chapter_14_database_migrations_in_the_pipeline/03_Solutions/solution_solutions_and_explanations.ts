/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

# .github/workflows/migrate.yml
name: Database Migration Pipeline

on:
  push:
    branches: [ main ]
  pull_request:
    branches: [ main ]

jobs:
  migrate:
    runs-on: ubuntu-latest
    
    # Service container to run PostgreSQL
    services:
      postgres:
        image: postgres:13
        env:
          POSTGRES_PASSWORD: postgres
          POSTGRES_DB: staging_db
        options: >-
          --health-cmd pg_isready
          --health-interval 10s
          --health-timeout 5s
          --health-retries 5
        ports:
          - 5432:5432

    steps:
      - name: Checkout repository
        uses: actions/checkout@v3

      # 1. Validate pending migrations first (Bonus Requirement)
      # This checks for version conflicts or checksum mismatches without applying changes.
      - name: Flyway Validate
        uses: flyway/flyway-action@v1
        with:
          url: jdbc:postgresql://localhost:5432/staging_db
          user: postgres
          password: postgres
          command: validate

      # 2. Apply Migrations
      # Uses the official Flyway Docker container action.
      # Credentials are passed via environment variables (securely mapped from Secrets).
      - name: Flyway Migrate
        uses: flyway/flyway-action@v1
        with:
          url: jdbc:postgresql://localhost:5432/staging_db
          user: postgres
          password: postgres
          command: migrate
          # Locations assumes a 'sql' folder in the repo root
          locations: filesystem:./sql

      # 3. Deploy Application (Placeholder)
      # This step only runs if the previous migration step succeeds.
      - name: Deploy to Staging
        run: |
          echo "Deploying application code..."
          # Actual deployment logic would go here (e.g., AWS CLI, kubectl)
