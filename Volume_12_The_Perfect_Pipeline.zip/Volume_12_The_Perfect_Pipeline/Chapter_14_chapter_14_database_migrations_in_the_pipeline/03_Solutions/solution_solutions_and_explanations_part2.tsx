/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.tsx
// Description: Solutions and Explanations
// ==========================================

// MigrationDashboard.tsx
import React, { useState, useEffect } from 'react';

// 1. Define TypeScript interfaces for type safety
interface ServiceStatus {
  name: string;
  currentVersion: string;
  pendingMigrations: string[];
  status: 'current' | 'outdated';
}

interface MigrationApiResponse {
  services: ServiceStatus[];
}

// Helper component for visual badge
const StatusBadge: React.FC<{ status: string }> = ({ status }) => {
  const color = status === 'current' ? 'green' : 'red';
  return (
    <span style={{ 
      backgroundColor: color, 
      color: 'white', 
      padding: '4px 8px', 
      borderRadius: '4px',
      fontSize: '0.8rem'
    }}>
      {status.toUpperCase()}
    </span>
  );
};

const MigrationDashboard: React.FC = () => {
  const [data, setData] = useState<ServiceStatus[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchStatus = async () => {
      try {
        // Simulating API call
        const response = await fetch('/api/migrations/status');
        
        if (!response.ok) {
          throw new Error(`HTTP error! status: ${response.status}`);
        }

        // Type assertion ensures the response matches our interface
        const result: MigrationApiResponse = await response.json();
        setData(result.services);
      } catch (err) {
        setError(err instanceof Error ? err.message : 'An unknown error occurred');
      } finally {
        setLoading(false);
      }
    };

    fetchStatus();
  }, []); // Run once on mount

  if (loading) return <div className="loader">Loading migration status...</div>;
  
  if (error) return <div className="error" style={{ color: 'red' }}>Error: {error}</div>;

  return (
    <div style={{ fontFamily: 'Arial, sans-serif', padding: '20px' }}>
      <h2>Database Migration Status</h2>
      {data.length === 0 ? (
        <p>No services found.</p>
      ) : (
        <ul style={{ listStyleType: 'none', padding: 0 }}>
          {data.map((service) => (
            <li key={service.name} style={{ 
              border: '1px solid #ddd', 
              margin: '10px 0', 
              padding: '15px', 
              borderRadius: '8px' 
            }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <strong>{service.name}</strong>
                <StatusBadge status={service.status} />
              </div>
              <div style={{ marginTop: '8px', fontSize: '0.9rem', color: '#555' }}>
                <p>Current Version: <code>{service.currentVersion}</code></p>
                
                {service.pendingMigrations.length > 0 ? (
                  <div>
                    <strong>Pending:</strong>
                    <ul style={{ margin: '4px 0', paddingLeft: '20px', color: 'orange' }}>
                      {service.pendingMigrations.map((mig, idx) => (
                        <li key={idx}>{mig}</li>
                      ))}
                    </ul>
                  </div>
                ) : (
                  <p style={{ color: 'green' }}>No pending migrations.</p>
                )}
              </div>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
};

export default MigrationDashboard;
