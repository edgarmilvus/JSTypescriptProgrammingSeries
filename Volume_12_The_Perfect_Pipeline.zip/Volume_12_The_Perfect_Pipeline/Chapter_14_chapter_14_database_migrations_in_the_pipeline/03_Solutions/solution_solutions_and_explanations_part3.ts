/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

// check-sql.ts
import * as fs from 'fs';
import * as path from 'path';

// Define the directory to scan
const MIGRATIONS_DIR = './migrations';

// Define anti-patterns with regex and risk levels
const ANTI_PATTERNS = [
  {
    name: 'Data Loss Risk (DROP TABLE)',
    regex: /DROP\s+TABLE/i,
    risk: 'high'
  },
  {
    name: 'Data Loss Risk (DROP COLUMN)',
    regex: /ALTER\s+TABLE\s+.*DROP\s+COLUMN/i,
    risk: 'high'
  },
  {
    name: 'Select All (SELECT *)',
    regex: /SELECT\s+\*/i,
    risk: 'medium'
  },
  {
    name: 'Missing Index (Potential)',
    // Heuristic: Detect FK definition without index creation in the same file
    // Note: This is a simplified check. Real analysis requires parsing the AST.
    regex: /CONSTRAINT\s+.*_fk\s+FOREIGN\s+KEY/i, 
    risk: 'medium'
  }
];

function scanFiles(directory: string): boolean {
  let hasHighRiskIssues = false;

  // Recursively read directory
  const files = fs.readdirSync(directory, { recursive: true });

  files.forEach(file => {
    const filePath = path.join(directory, file.toString());
    
    // Skip if not a .sql file
    if (!filePath.endsWith('.sql')) return;

    const content = fs.readFileSync(filePath, 'utf-8');
    const lines = content.split('\n');

    ANTI_PATTERNS.forEach(pattern => {
      lines.forEach((line, index) => {
        if (pattern.regex.test(line)) {
          const lineNumber = index + 1;
          console.warn(`[WARNING] ${pattern.name} detected in ${filePath}:${lineNumber}`);
          console.warn(`          Line: ${line.trim()}`);
          
          if (pattern.risk === 'high') {
            hasHighRiskIssues = true;
          }
        }
      });
    });
  });

  return hasHighRiskIssues;
}

// Main execution
try {
  if (!fs.existsSync(MIGRATIONS_DIR)) {
    console.error(`Directory ${MIGRATIONS_DIR} does not exist.`);
    process.exit(1);
  }

  console.log(`Scanning ${MIGRATIONS_DIR} for SQL anti-patterns...`);
  const highRiskFound = scanFiles(MIGRATIONS_DIR);

  if (highRiskFound) {
    console.error('\n❌ High-risk anti-patterns detected. Deployment blocked.');
    process.exit(1); // Non-zero exit code triggers CI failure
  } else {
    console.log('\n✅ Scan complete. No high-risk issues found.');
    process.exit(0);
  }
} catch (error) {
  console.error('Error during scan:', error);
  process.exit(1);
}
