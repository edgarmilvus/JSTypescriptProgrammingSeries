/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

// rollback-simulator.ts
import { Command } from 'commander';
import inquirer from 'inquirer';
import fs from 'fs';

const program = new Command();
const STATE_FILE = 'db_state.json';
const HISTORY_FILE = 'migration_history.json';

// Ensure state files exist
if (!fs.existsSync(STATE_FILE)) {
  fs.writeFileSync(STATE_FILE, JSON.stringify({ currentVersion: 'V0', history: ['V0'] }));
}

// Helper to read/write state
const getState = () => JSON.parse(fs.readFileSync(STATE_FILE, 'utf-8'));
const saveState = (state: any) => fs.writeFileSync(STATE_FILE, JSON.stringify(state, null, 2));

// Generate Graphviz DOT diagram
function generateDiagram(history: string[], targetVersion: string) {
  let dot = 'digraph MigrationHistory {\n';
  dot += '  rankdir=LR;\n'; // Left to Right layout
  
  history.forEach((ver, idx) => {
    // Highlight the rollback target or current path
    const isTarget = ver === targetVersion;
    const color = isTarget ? 'red' : 'black';
    const style = isTarget ? 'filled, style=filled, fillcolor="lightcoral"' : '';
    
    dot += `  "${ver}" [${style}, color="${color}"];\n`;
    
    if (idx < history.length - 1) {
      dot += `  "${ver}" -> "${history[idx + 1]}";\n`;
    }
  });

  dot += '}';
  
  fs.writeFileSync('migration_graph.dot', dot);
  console.log('\n📊 Graphviz diagram generated: migration_graph.dot');
  console.log('   (Visualize this file using a Graphviz viewer)');
}

program
  .command('migrate')
  .description('Apply a new migration')
  .requiredOption('-v, --version <version>', 'Migration version ID')
  .action((options) => {
    const state = getState();
    console.log(`Applying migration: ${options.version}...`);
    
    state.currentVersion = options.version;
    state.history.push(options.version);
    
    saveState(state);
    console.log(`✅ Database updated to ${options.version}`);
  });

program
  .command('rollback')
  .description('Rollback database to a previous version')
  .requiredOption('-t, --to <version>', 'Target version to rollback to')
  .action(async (options) => {
    const state = getState();
    const targetVersion = options.to;

    // Validation: Check if target exists in history
    if (!state.history.includes(targetVersion)) {
      console.error(`❌ Error: Version ${targetVersion} not found in history.`);
      process.exit(1);
    }

    // Interactive Confirmation
    const answers = await inquirer.prompt([
      {
        type: 'confirm',
        name: 'confirmRollback',
        message: `⚠️  WARNING: This will revert from ${state.currentVersion} to ${targetVersion}. Proceed?`,
        default: false
      }
    ]);

    if (answers.confirmRollback) {
      console.log(`Rolling back to ${targetVersion}...`);
      
      // Simulate logic: In a real DB, we would run down-migrations.
      // Here we just update state.
      state.currentVersion = targetVersion;
      
      // Visualize the path
      generateDiagram(state.history, targetVersion);
      
      saveState(state);
      console.log(`✅ Database rolled back to ${targetVersion}`);
    } else {
      console.log('Rollback cancelled.');
    }
  });

program.parse(process.argv);
