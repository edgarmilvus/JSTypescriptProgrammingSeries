/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

// server.ts
import express, { Request, Response } from 'express';

const app = express();
const PORT = 3000;

/**
 * Simulates a heavy database migration (e.g., adding an index to a large table).
 * 
 * IMPORTANT: We use `setTimeout` wrapped in a Promise. This allows the operation
 * to be asynchronous. Node.js places the timer in the event loop and executes
 * the callback when the time expires, allowing other I/O events (like HTTP requests)
 * to be processed in the meantime.
 */
const runMigration = (): Promise<void> => {
  return new Promise((resolve) => {
    console.log('Starting database migration...');
    
    // Simulate 5 seconds of work
    setTimeout(() => {
      console.log('Migration completed successfully.');
      resolve();
    }, 5000);
  });
};

// Health Check Endpoint
app.get('/health', (req: Request, res: Response) => {
  // This will respond immediately even if migration is running
  res.status(200).json({ status: 'OK', uptime: process.uptime() });
});

// Start Server
const server = app.listen(PORT, () => {
  console.log(`Server listening on port ${PORT}`);
});

/**
 * Non-Blocking Migration Execution
 * 
 * We use an Immediately Invoked Function Expression (IIFE) with async/await.
 * 
 * WHY THIS WORKS:
 * 1. `await runMigration()` suspends the execution of the IIFE.
 * 2. Because `runMigration` returns a Promise (and uses `setTimeout` internally),
 *    it does not block the main thread. It registers the timeout and yields control.
 * 3. The Node.js Event Loop remains free to process incoming HTTP requests
 *    (like hitting /health) while the timer counts down.
 * 
 * WHY A NAIVE APPROACH FAILS:
 * If we used a synchronous blocking loop (e.g., `while(Date.now() < start + 5000)`),
 * the single Node.js thread would be stuck in that loop, unable to execute the 
 * callback for the HTTP server. The /health request would hang until the loop finished.
 */
(async () => {
  try {
    await runMigration();
  } catch (error) {
    console.error('Migration failed:', error);
    // In a real scenario, we might want to shut down the server if migration fails
    // server.close();
  }
})();
