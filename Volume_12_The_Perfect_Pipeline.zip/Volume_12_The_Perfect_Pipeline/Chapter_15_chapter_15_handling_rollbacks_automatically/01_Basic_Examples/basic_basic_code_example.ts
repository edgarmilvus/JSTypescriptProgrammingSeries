/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * @fileoverview A simulation of an automated rollback system for a SaaS deployment.
 * This script monitors error rates and triggers a rollback if thresholds are breached.
 */

// --- Types & Interfaces ---

/**
 * Represents the health status of a deployed service instance.
 */
interface DeploymentMetrics {
  deploymentId: string;
  version: string;
  errorRate: number; // Percentage (0-100)
  latencyP95: number; // Milliseconds
  timestamp: Date;
}

/**
 * Represents the result of a rollback operation.
 */
interface RollbackResult {
  success: boolean;
  targetVersion: string;
  reason: string;
}

// --- Configuration ---

const CONFIG = {
  ERROR_RATE_THRESHOLD: 5.0, // 5% error rate triggers rollback
  POLL_INTERVAL_MS: 2000, // Check every 2 seconds
  STABLE_VERSION: 'v1.0.0',
  CURRENT_VERSION: 'v1.1.0', // The version currently being deployed
};

// --- Mock Services ---

/**
 * Simulates fetching metrics from an APM (Application Performance Monitoring) tool.
 * In a real scenario, this would be a fetch call to Datadog, New Relic, or Prometheus.
 */
const fetchMetrics = async (version: string): Promise<DeploymentMetrics> => {
  // Simulate network latency
  await new Promise((resolve) => setTimeout(resolve, 100));

  // Simulate a scenario where v1.1.0 introduces a bug causing high error rates
  let errorRate = 0.5; // Baseline healthy error rate
  
  if (version === 'v1.1.0') {
    // Simulate a spike in errors after 3 seconds (simulating time passing)
    const now = Date.now();
    if (now > Date.now() + 1000) { // Logic placeholder for time-based simulation
       errorRate = 8.5; // Critical failure
    }
  }

  return {
    deploymentId: `dep-${Math.random().toString(36).substring(7)}`,
    version: version,
    errorRate: errorRate,
    latencyP95: 120,
    timestamp: new Date(),
  };
};

/**
 * Simulates the execution of a rollback command (e.g., `kubectl rollout undo`).
 */
const executeRollback = async (targetVersion: string): Promise<RollbackResult> => {
  console.log(`[ACTION] Initiating rollback to ${targetVersion}...`);
  
  // Simulate the time it takes to replace pods/containers
  await new Promise((resolve) => setTimeout(resolve, 500));

  return {
    success: true,
    targetVersion: targetVersion,
    reason: `Automated trigger: Error rate exceeded ${CONFIG.ERROR_RATE_THRESHOLD}%`,
  };
};

// --- Core Logic ---

/**
 * Analyzes metrics and decides whether to trigger a rollback.
 * This represents the "Brain" of the self-healing pipeline.
 */
const analyzeAndReact = async (metrics: DeploymentMetrics): Promise<void> => {
  console.log(
    `[MONITOR] Version: ${metrics.version} | Error Rate: ${metrics.errorRate.toFixed(2)}% | Threshold: ${CONFIG.ERROR_RATE_THRESHOLD}%`
  );

  // 1. Check if the error rate breaches the safety threshold
  if (metrics.errorRate > CONFIG.ERROR_RATE_THRESHOLD) {
    console.warn(`[ALERT] Critical threshold breached! Current: ${metrics.errorRate}%`);

    // 2. Trigger the rollback mechanism
    const result = await executeRollback(CONFIG.STABLE_VERSION);

    // 3. Log the outcome and stop monitoring
    if (result.success) {
      console.log(`[SUCCESS] Rollback complete. System reverted to ${result.targetVersion}.`);
      console.log(`[REASON] ${result.reason}`);
      
      // In a real app, we might exit the process here or stop the loop
      process.exit(0); 
    }
  } else {
    console.log(`[OK] System is healthy. No action taken.`);
  }
};

/**
 * The main entry point that starts the monitoring loop.
 */
const startMonitoring = async () => {
  console.log('--- Starting Automated Rollback Watchdog ---');
  
  // Simulate a loop (in production, this might be a cron job or a while loop)
  const iterations = 5;
  
  for (let i = 0; i < iterations; i++) {
    try {
      // 1. Fetch current metrics
      const metrics = await fetchMetrics(CONFIG.CURRENT_VERSION);
      
      // 2. Analyze and potentially react
      await analyzeAndReact(metrics);
      
    } catch (error) {
      console.error('[ERROR] Failed to fetch metrics:', error);
    }

    // Wait before next poll
    await new Promise((resolve) => setTimeout(resolve, CONFIG.POLL_INTERVAL_MS));
  }
  
  console.log('--- Monitoring Cycle Complete ---');
};

// --- Execution ---

// Run the simulation
startMonitoring();
