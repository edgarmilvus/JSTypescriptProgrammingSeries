/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

'use server';

import { z } from 'zod';
import { revalidatePath } from 'next/cache';

/**
 * ============================================================================
 * 1. SERVER-SIDE LOGIC (Server Actions & Data Validation)
 * ============================================================================
 */

// Define the schema for health check data using Zod for runtime validation.
// This ensures that even if client-side checks are bypassed, the server
// rejects invalid data, a key security aspect of Server Actions.
const HealthCheckSchema = z.object({
  errorRate: z.number().min(0).max(100),
  p95Latency: z.number().min(0),
  deploymentId: z.string().uuid(),
});

type HealthCheckInput = z.infer<typeof HealthCheckSchema>;

// Mock Database / External CI/CD System State
// In a real scenario, this would be an API call to GitHub Actions or a database entry.
const deploymentHistory: Record<string, { status: 'healthy' | 'rollback_triggered' }> = {};

/**
 * Server Action: `analyzeAndRollback`
 * 
 * This function runs exclusively on the server. It receives telemetry data
 * from the client, validates it, checks against KPI thresholds, and simulates
 * a rollback trigger if necessary.
 * 
 * @param input - Health metrics from the client.
 * @returns - A result object indicating the action taken.
 */
export async function analyzeAndRollback(input: HealthCheckInput) {
  // 1. Validate Input
  // Using Zod ensures type safety and prevents malicious payloads.
  const result = HealthCheckSchema.safeParse(input);

  if (!result.success) {
    return {
      success: false,
      message: 'Invalid health data provided.',
      error: result.error.flatten(),
    };
  }

  const { errorRate, p95Latency, deploymentId } = result.data;

  // 2. Define KPI Thresholds (The "Rollback Triggers")
  // These represent the SLOs (Service Level Objectives) defined in Chapter 15.
  const MAX_ERROR_RATE = 5.0; // 5%
  const MAX_LATENCY = 500;    // 500ms

  // 3. Decision Logic
  let action: string = 'none';
  let message: string = '';

  if (errorRate > MAX_ERROR_RATE || p95Latency > MAX_LATENCY) {
    // 4. Trigger Rollback
    // In a real pipeline, this would call the GitHub Actions API via a PAT (Personal Access Token)
    // or trigger a webhook to revert a Git tag.
    deploymentHistory[deploymentId] = { status: 'rollback_triggered' };
    
    action = 'rollback';
    message = `Threshold breached. Initiating automated rollback for Deployment ${deploymentId}. Error Rate: ${errorRate}%, Latency: ${p95Latency}ms.`;
    
    // Log the incident for AI analysis (simulated)
    console.error(`[CRITICAL] ${message}`);
  } else {
    // 5. Mark Healthy
    deploymentHistory[deploymentId] = { status: 'healthy' };
    
    action = 'maintain';
    message = `Deployment ${deploymentId} is stable within KPI limits.`;
  }

  // 6. Revalidate Cache
  // Updates the UI immediately without a full page reload.
  revalidatePath('/dashboard');

  return {
    success: true,
    action,
    message,
    timestamp: new Date().toISOString(),
  };
}

/**
 * ============================================================================
 * 2. CLIENT-SIDE LOGIC (Interactive Dashboard)
 * ============================================================================
 */

// TSX Component: `DeploymentMonitor`
// This is a Client Component (CC) responsible for UI interactivity and
// simulating the collection of browser-side metrics (e.g., Web Vitals).

'use client';

import { useState, useTransition } from 'react';
import { analyzeAndRollback } from './actions'; // Import the Server Action

interface MonitorState {
  status: 'idle' | 'analyzing' | 'rolled_back' | 'healthy';
  lastMessage: string | null;
  metrics: {
    errorRate: number;
    latency: number;
  };
}

export default function DeploymentMonitor() {
  // State for managing UI transitions and pending requests
  const [isPending, startTransition] = useTransition();
  const [state, setState] = useState<MonitorState>({
    status: 'idle',
    lastMessage: null,
    metrics: { errorRate: 0, latency: 100 }, // Initial safe values
  });

  /**
   * Handles the simulation of metrics generation.
   * In a real app, this would aggregate data from `window.performance` 
   * or an error boundary (e.g., Sentry).
   */
  const generateMetrics = (scenario: 'healthy' | 'unhealthy') => {
    if (scenario === 'healthy') {
      setState((prev) => ({
        ...prev,
        metrics: { errorRate: 1.2, latency: 150 },
      }));
    } else {
      // Simulate a bad deployment (High Error Rate)
      setState((prev) => ({
        ...prev,
        metrics: { errorRate: 8.5, latency: 400 },
      }));
    }
  };

  /**
   * Triggers the Server Action.
   * Wrapped in `startTransition` to mark this update as non-urgent,
   * keeping the UI responsive during the server round-trip.
   */
  const triggerHealthCheck = async () => {
    startTransition(async () => {
      // Generate a mock UUID for the deployment
      const deploymentId = crypto.randomUUID();

      // Call the Server Action
      const result = await analyzeAndRollback({
        errorRate: state.metrics.errorRate,
        p95Latency: state.metrics.latency,
        deploymentId: deploymentId,
      });

      if (result.success) {
        setState((prev) => ({
          ...prev,
          status: result.action === 'rollback' ? 'rolled_back' : 'healthy',
          lastMessage: result.message,
        }));
      }
    });
  };

  return (
    <div className="p-6 border rounded-lg max-w-md mx-auto bg-white shadow-sm">
      <h2 className="text-xl font-bold mb-4 text-slate-800">
        Deployment Health Monitor
      </h2>

      {/* Metric Display */}
      <div className="grid grid-cols-2 gap-4 mb-4 text-sm">
        <div className="p-3 bg-slate-50 rounded">
          <span className="block text-slate-500">Error Rate</span>
          <span className="font-mono font-semibold">
            {state.metrics.errorRate}%
          </span>
        </div>
        <div className="p-3 bg-slate-50 rounded">
          <span className="block text-slate-500">Latency (P95)</span>
          <span className="font-mono font-semibold">
            {state.metrics.latency}ms
          </span>
        </div>
      </div>

      {/* Simulation Controls */}
      <div className="flex gap-2 mb-4">
        <button
          onClick={() => generateMetrics('healthy')}
          className="px-3 py-1 text-xs bg-green-100 text-green-700 rounded hover:bg-green-200"
        >
          Simulate Healthy
        </button>
        <button
          onClick={() => generateMetrics('unhealthy')}
          className="px-3 py-1 text-xs bg-red-100 text-red-700 rounded hover:bg-red-200"
        >
          Simulate Failure
        </button>
      </div>

      {/* Action Trigger */}
      <button
        onClick={triggerHealthCheck}
        disabled={isPending}
        className="w-full py-2 bg-blue-600 text-white rounded hover:bg-blue-700 disabled:opacity-50 font-medium"
      >
        {isPending ? 'Analyzing...' : 'Run Automated Health Check'}
      </button>

      {/* Result Display */}
      {state.lastMessage && (
        <div className="mt-4 p-3 text-sm rounded border"
             style={{
               borderColor: state.status === 'rolled_back' ? '#ef4444' : '#22c55e',
               backgroundColor: state.status === 'rolled_back' ? '#fef2f2' : '#f0fdf4',
               color: state.status === 'rolled_back' ? '#991b1b' : '#166534'
             }}
        >
          <strong className="block mb-1">
            {state.status === 'rolled_back' ? '⚠️ Rollback Triggered' : '✅ System Stable'}
          </strong>
          {state.lastMessage}
        </div>
      )}
    </div>
  );
}
