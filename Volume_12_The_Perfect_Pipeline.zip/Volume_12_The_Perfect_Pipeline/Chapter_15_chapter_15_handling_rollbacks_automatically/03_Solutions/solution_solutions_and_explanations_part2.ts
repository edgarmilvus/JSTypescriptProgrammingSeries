/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

interface DeploymentMetrics {
  errorRate: number;       // 0 to 1
  p95Latency: number;      // in milliseconds
  requestsPerSecond: number;
}

interface RollbackThresholds {
  maxErrorRate: number;
  maxLatency: number;
  minRequestsPerSecond: number;
}

function evaluateRollbackCondition(metrics: DeploymentMetrics, thresholds: RollbackThresholds): boolean {
  // Check Error Rate
  if (metrics.errorRate > thresholds.maxErrorRate) {
    console.error(`Rollback triggered: Error rate (${metrics.errorRate}) exceeded threshold (${thresholds.maxErrorRate}).`);
    return true;
  }

  // Check Latency
  if (metrics.p95Latency > thresholds.maxLatency) {
    console.error(`Rollback triggered: P95 Latency (${metrics.p95Latency}ms) exceeded threshold (${thresholds.maxLatency}ms).`);
    return true;
  }

  // Check Traffic Volume (ensure minimum traffic for valid metrics)
  if (metrics.requestsPerSecond < thresholds.minRequestsPerSecond) {
    console.warn(`Rollback triggered: Traffic volume (${metrics.requestsPerSecond}) dropped below threshold (${thresholds.minRequestsPerSecond}).`);
    return true;
  }

  // If no thresholds are breached
  console.log("Metrics within acceptable limits. No rollback needed.");
  return false;
}
