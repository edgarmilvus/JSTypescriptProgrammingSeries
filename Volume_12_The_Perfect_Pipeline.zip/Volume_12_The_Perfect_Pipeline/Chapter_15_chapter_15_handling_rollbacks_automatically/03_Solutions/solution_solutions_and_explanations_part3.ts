/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

digraph SelfHealingPipeline {
    rankdir=TB;
    node [shape=box, style="rounded,filled", color="#e1f5fe"];
    
    // Define Nodes
    Start [label="Trigger Deployment", fillcolor="#b3e5fc"];
    Deploy [label="Deploy New Version", fillcolor="#fff3e0"];
    HealthCheck [label="Run Health Checks\n(Poll Endpoint)", fillcolor="#fff3e0"];
    
    DecisionHealth [label="Service Healthy?", shape=diamond, fillcolor="#ffccbc"];
    MetricsCheck [label="Collect Metrics\n(Error Rate, Latency)", fillcolor="#fff3e0"];
    
    DecisionMetrics [label="Metrics within\nThresholds?", shape=diamond, fillcolor="#ffccbc"];
    
    AnalyzeLogs [label="Analyze Logs\n(AI Agent)", fillcolor="#e1bee7"];
    ExecuteRollback [label="Execute Rollback\n(Restore Previous)", fillcolor="#ffcdd2"];
    
    NotifySuccess [label="Notify: Success", fillcolor="#c8e6c9"];
    NotifyFailure [label="Notify: Rollback Triggered", fillcolor="#ffcdd2"];
    
    End [label="Pipeline End", fillcolor="#b3e5fc"];

    // Define Edges
    Start -> Deploy;
    Deploy -> HealthCheck;
    HealthCheck -> DecisionHealth;
    
    // Healthy Path
    DecisionHealth -> MetricsCheck [label="Yes"];
    MetricsCheck -> DecisionMetrics;
    DecisionMetrics -> NotifySuccess [label="Yes"];
    NotifySuccess -> End;
    
    // Unhealthy / Rollback Paths
    DecisionHealth -> AnalyzeLogs [label="No"];
    DecisionMetrics -> AnalyzeLogs [label="No"];
    
    AnalyzeLogs -> ExecuteRollback;
    ExecuteRollback -> NotifyFailure;
    NotifyFailure -> End;
}
