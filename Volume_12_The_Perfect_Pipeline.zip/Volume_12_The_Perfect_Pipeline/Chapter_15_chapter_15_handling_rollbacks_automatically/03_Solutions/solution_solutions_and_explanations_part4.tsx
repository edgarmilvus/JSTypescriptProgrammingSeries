/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.tsx
// Description: Solutions and Explanations
// ==========================================

import React from 'react';

// Define the allowed status types
type DeploymentStatus = 'deploying' | 'healthy' | 'unhealthy' | 'rolled_back';

interface DeploymentStatusIndicatorProps {
  status: DeploymentStatus;
}

// Basic inline styles for demonstration (in a real app, use CSS classes)
const styles = {
  container: {
    padding: '16px',
    borderRadius: '8px',
    border: '1px solid #ddd',
    margin: '10px 0',
    fontFamily: 'Arial, sans-serif',
  },
  deploying: { backgroundColor: '#e3f2fd', color: '#1565c0' },
  healthy: { backgroundColor: '#e8f5e9', color: '#2e7d32' },
  unhealthy: { backgroundColor: '#ffebee', color: '#c62828' },
  rolled_back: { backgroundColor: '#fff3e0', color: '#ef6c00' },
  icon: { marginRight: '8px', fontWeight: 'bold' },
};

const DeploymentStatusIndicator: React.FC<DeploymentStatusIndicatorProps> = ({ status }) => {
  const renderContent = () => {
    switch (status) {
      case 'deploying':
        return (
          <div style={{ ...styles.container, ...styles.deploying }}>
            <span style={styles.icon}>⟳</span> Deploying...
          </div>
        );
      case 'healthy':
        return (
          <div style={{ ...styles.container, ...styles.healthy }}>
            <span style={styles.icon}>✓</span> System is healthy
          </div>
        );
      case 'unhealthy':
        return (
          <div style={{ ...styles.container, ...styles.unhealthy }}>
            <span style={styles.icon}>⚠</span> Alert: System unhealthy. Initiating rollback...
          </div>
        );
      case 'rolled_back':
        return (
          <div style={{ ...styles.container, ...styles.rolled_back }}>
            <span style={styles.icon}>ℹ</span> Last deployment rolled back. Check logs for details.
          </div>
        );
      default:
        return null;
    }
  };

  return <>{renderContent()}</>;
};

export default DeploymentStatusIndicator;
