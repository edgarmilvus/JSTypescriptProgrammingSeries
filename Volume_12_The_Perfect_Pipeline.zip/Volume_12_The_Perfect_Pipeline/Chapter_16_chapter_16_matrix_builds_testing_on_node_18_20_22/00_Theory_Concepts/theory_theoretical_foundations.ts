/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: theory_theoretical_foundations.ts
// Description: Theoretical Foundations
// ==========================================

// A conceptual model of how a Supervisor Node orchestrates parallel workers.
// This is NOT the YAML configuration, but the underlying logic it represents.

interface WorkerResult {
    nodeId: string;
    status: 'success' | 'failure';
    logs: string;
}

// Represents the Supervisor's core orchestration logic.
async function supervisorNode(matrix: number[]): Promise<WorkerResult[]> {
    console.log("Supervisor: Received matrix blueprint. Spawning workers...");

    // 1. Define the delegation strategy. This is the "what" and "how" for each worker.
    const workerPromises = matrix.map(async (nodeVersion) => {
        // 2. Spawn a worker agent (asynchronously).
        // In a real system, this might be an API call to start a new container/VM.
        const workerAgent = spawnWorkerAgent(nodeVersion);

        // 3. Delegate the task and wait for the result asynchronously.
        // The supervisor does not block here; it fires off all three requests.
        const result = await workerAgent.runTests();
        
        console.log(`Worker for Node ${nodeVersion} finished with status: ${result.status}`);
        return result;
    });

    // 4. Asynchronous Tool Handling: The supervisor waits for ALL workers to complete.
    // This is like Promise.allSettled(), allowing us to see all outcomes.
    const allResults = await Promise.allSettled(workerPromises);

    // 5. Aggregate and decide.
    const finalResults: WorkerResult[] = allResults.map(r => 
        r.status === 'fulfilled' ? r.value : { nodeId: 'unknown', status: 'failure', logs: 'Worker crashed' }
    );

    // 6. Fail-Fast Logic Check (Conceptual)
    const anyFailures = finalResults.some(r => r.status === 'failure');
    if (anyFailures) {
        console.error("Supervisor: CRITICAL! One or more workers failed. Halting pipeline and cleaning up.");
        // In a real scenario, this would trigger cancellation of other in-flight jobs if not using `fail-fast`.
    } else {
        console.log("Supervisor: All workers reported success. Pipeline is green.");
    }

    return finalResults;
}

// --- Mocked functions for conceptual clarity ---

function spawnWorkerAgent(version: number): { runTests: () => Promise<WorkerResult> } {
    // This function simulates the creation of an isolated environment.
    return {
        runTests: () => new Promise((resolve) => {
            // Simulate test execution time
            setTimeout(() => {
                // Simulate a failure on Node 22 for demonstration
                if (version === 22) {
                    resolve({ nodeId: `worker-${version}`, status: 'failure', logs: `Tests failed on Node ${version}` });
                } else {
                    resolve({ nodeId: `worker-${version}`, status: 'success', logs: `All tests passed on Node ${version}` });
                }
            }, 100);
        })
    };
}

// Example Usage
// supervisorNode([18, 20, 22]);
