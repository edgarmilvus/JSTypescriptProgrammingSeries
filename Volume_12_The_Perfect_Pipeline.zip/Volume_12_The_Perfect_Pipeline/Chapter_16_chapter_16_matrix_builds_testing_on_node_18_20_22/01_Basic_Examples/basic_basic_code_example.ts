/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

// src/utils/noteProcessor.ts
// A simple utility module to demonstrate logic that needs testing across Node versions.

/**
 * Represents a raw note input from the API.
 */
export interface RawNoteInput {
  title: string;
  content: string;
  tags?: string[];
}

/**
 * Represents the processed note stored in the database.
 */
export interface ProcessedNote {
  id: string;
  title: string;
  content: string;
  normalizedTags: string[];
  processedAt: Date;
}

/**
 * Processes a raw note input into a standardized database format.
 * 
 * This function simulates business logic that must remain consistent 
 * regardless of the Node.js runtime version.
 * 
 * @param input - The raw note data from the client.
 * @param dbService - A mock dependency simulating a database connection.
 * @returns A promise resolving to the stored note.
 */
export async function processAndStoreNote(
  input: RawNoteInput,
  dbService: {
    save: (data: any) => Promise<{ id: string }>;
  }
): Promise<ProcessedNote> {
  // Simulate an async operation (e.g., waiting for DB write)
  await new Promise((resolve) => setTimeout(resolve, 10));

  // Logic: Normalize tags to lowercase and sort them
  const normalizedTags = (input.tags || [])
    .map((tag) => tag.toLowerCase().trim())
    .sort();

  // Logic: Generate a deterministic ID based on title length (mock logic)
  const id = `note_${input.title.length}_${Date.now()}`;

  // Save to the "database"
  const result = await dbService.save({
    id,
    title: input.title,
    content: input.content,
    normalizedTags,
  });

  return {
    id: result.id,
    title: input.title,
    content: input.content,
    normalizedTags,
    processedAt: new Date(),
  };
}
