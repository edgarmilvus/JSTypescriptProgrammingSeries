/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.ts
// Description: Basic Code Example
// ==========================================

// tests/noteProcessor.test.ts
// The test suite designed to run in the matrix build.

import { describe, it, expect } from 'vitest'; // Assuming Vitest for this example
import { processAndStoreNote, RawNoteInput } from '../src/utils/noteProcessor';

describe('Note Processor Logic', () => {
  
  // Test Case 1: Basic functionality
  it('should process a note with tags correctly', async () => {
    const mockInput: RawNoteInput = {
      title: 'Hello World',
      content: 'This is a test note.',
      tags: ['Typescript', 'Node', 'TEST'],
    };

    // Mock DB Service
    const mockDb = {
      save: async (data: any) => {
        // Verify data structure before "saving"
        if (!data.title || !data.content) {
          throw new Error('Missing required fields');
        }
        return { id: data.id };
      },
    };

    const result = await processAndStoreNote(mockInput, mockDb);

    // Assertions
    expect(result.id).toBeDefined();
    expect(result.title).toBe('Hello World');
    expect(result.normalizedTags).toEqual(['node', 'test', 'typescript']); // Sorted and lowercased
  });

  // Test Case 2: Edge case handling
  it('should handle missing tags gracefully', async () => {
    const mockInput: RawNoteInput = {
      title: 'No Tags',
      content: 'Empty tag list.',
    };

    const mockDb = {
      save: async (data: any) => ({ id: data.id }),
    };

    const result = await processAndStoreNote(mockInput, mockDb);

    expect(result.normalizedTags).toEqual([]);
  });
});
