/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example_part3.ts
// Description: Basic Code Example
// ==========================================

name: Node.js Matrix CI

on:
  push:
    branches: [ main ]
  pull_request:
    branches: [ main ]

jobs:
  test-matrix:
    # The name of the job in the GitHub Actions UI
    name: Test on Node.js ${{ matrix.node-version }}
    
    # Define the runner OS
    runs-on: ubuntu-latest
    
    # THE MATRIX STRATEGY
    strategy:
      # fail-fast: false ensures that if Node 18 fails, Node 20 and 22 
      # continue running. This is useful for identifying version-specific bugs.
      fail-fast: false 
      
      matrix:
        # The dimension we are testing against.
        # GitHub Actions will create 3 parallel jobs for these versions.
        node-version: [18.x, 20.x, 22.x]

    # Steps to execute in each parallel job
    steps:
      # 1. Checkout the code
      - name: Checkout code
        uses: actions/checkout@v4

      # 2. Setup Node.js environment for the specific matrix version
      - name: Use Node.js ${{ matrix.node-version }}
        uses: actions/setup-node@v4
        with:
          node-version: ${{ matrix.node-version }}
          # Cache node_modules to speed up subsequent runs
          cache: 'npm'

      # 3. Install dependencies
      - name: Install Dependencies
        run: npm ci

      # 4. Run the test suite
      # The tests in 'tests/noteProcessor.test.ts' will execute here.
      - name: Run Tests
        run: npm test
        
      # 5. (Optional) Upload Artifacts if tests pass
      # Useful if you want to deploy the build artifacts later.
      - name: Upload Test Results
        if: always() # Run even if tests fail
        uses: actions/upload-artifact@v4
        with:
          name: test-results-node-${{ matrix.node-version }}
          path: |
            coverage/
            test-results.xml
