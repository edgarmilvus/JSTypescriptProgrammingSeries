/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

/**
 * matrix-test-runner.ts
 * 
 * A TypeScript script designed to run within a GitHub Actions Matrix Build.
 * It simulates running integration tests for a SaaS API against different Node.js versions.
 * 
 * Context: This script is intended to be executed in parallel jobs defined in a 
 * GitHub Actions workflow matrix (e.g., node-version: [18, 20, 22]).
 */

import https from 'https';
import { performance } from 'perf_hooks';

// ============================================================================
// 1. Graph State & Configuration
// ============================================================================

/**
 * Represents the state of the test execution.
 * In a LangGraph context, this would be the 'State' object passed between nodes.
 * Here, it serves as the canonical data structure for the test run.
 */
interface TestRunState {
  nodeVersion: string;
  targetUrl: string;
  results: TestResult[];
  startTime: number;
  endTime: number;
  status: 'PASSED' | 'FAILED' | 'RUNNING';
}

interface TestResult {
  testName: string;
  duration: number; // ms
  status: 'PASS' | 'FAIL';
  details?: string;
}

// ============================================================================
// 2. Asynchronous Tool Handling
// ============================================================================

/**
 * A helper function to perform an HTTPS GET request.
 * 
 * Why use Promise wrapper? 
 * Node.js native 'https' module is callback-based. To integrate with modern
 * async/await syntax (standard in Next.js/TypeScript), we wrap it in a Promise.
 * This ensures non-blocking execution of the test runner.
 * 
 * @param url - The target API endpoint
 * @returns Promise<string> - The response body
 */
const fetchJson = (url: string): Promise<string> => {
  return new Promise((resolve, reject) => {
    https.get(url, (res) => {
      let data = '';

      res.on('data', (chunk) => {
        data += chunk;
      });

      res.on('end', () => {
        if (res.statusCode && res.statusCode >= 200 && res.statusCode < 300) {
          resolve(data);
        } else {
          reject(new Error(`HTTP ${res.statusCode}: ${data}`));
        }
      });

    }).on('error', (err) => {
      reject(err);
    });
  });
};

// ============================================================================
// 3. Worker Nodes (Simulated Test Cases)
// ============================================================================

/**
 * Node A: Health Check
 * Verifies the SaaS API is reachable.
 */
async function runHealthCheck(state: TestRunState): Promise<TestResult> {
  const start = performance.now();
  try {
    // In a real scenario, this would be your Next.js API route
    const response = await fetchJson(state.targetUrl);
    const duration = performance.now() - start;
    
    return {
      testName: 'Health Check (GET /api/health)',
      duration,
      status: 'PASS',
      details: `Response length: ${response.length}`
    };
  } catch (error) {
    const duration = performance.now() - start;
    return {
      testName: 'Health Check (GET /api/health)',
      duration,
      status: 'FAIL',
      details: error instanceof Error ? error.message : 'Unknown error'
    };
  }
}

/**
 * Node B: Version Compatibility
 * Verifies the response contains a 'serverVersion' field compatible with the current Node runtime.
 */
async function runVersionCheck(state: TestRunState): Promise<TestResult> {
  const start = performance.now();
  try {
    const response = await fetchJson(state.targetUrl);
    const json = JSON.parse(response);
    
    // Simulate logic where the API echoes the Node version it runs on
    const isCompatible = json.serverVersion ? true : false; 
    const duration = performance.now() - start;

    return {
      testName: 'Runtime Compatibility Check',
      duration,
      status: isCompatible ? 'PASS' : 'FAIL',
      details: isCompatible ? `Server reports: ${json.serverVersion}` : 'Missing version info'
    };
  } catch (error) {
    const duration = performance.now() - start;
    return {
      testName: 'Runtime Compatibility Check',
      duration,
      status: 'FAIL',
      details: error instanceof Error ? error.message : 'Unknown error'
    };
  }
}

// ============================================================================
// 4. The Supervisor / Main Execution Logic
// ============================================================================

/**
 * Main entry point.
 * Orchestrates the execution of test nodes and aggregates state.
 * 
 * In a LangGraph analogy, this function acts as the 'Supervisor Node' 
 * that controls the flow of the 'Graph State'.
 */
async function main() {
  // Initialize State from Environment Variables (Matrix Strategy inputs)
  const nodeVersion = process.env.NODE_VERSION || process.versions.node;
  const targetUrl = process.env.TEST_API_URL || 'https://jsonplaceholder.typicode.com/todos/1';
  
  console.log(`🚀 Starting Matrix Test Runner on Node.js ${nodeVersion}`);
  console.log(`🎯 Target: ${targetUrl}`);

  const state: TestRunState = {
    nodeVersion,
    targetUrl,
    results: [],
    startTime: performance.now(),
    status: 'RUNNING'
  };

  try {
    // Execute Nodes in Sequence (or parallel via Promise.all if independent)
    // Here we use sequence to simulate a workflow graph
    const healthResult = await runHealthCheck(state);
    const versionResult = await runVersionCheck(state);

    // Aggregate results into State
    state.results.push(healthResult, versionResult);

    // Determine Final Status
    const allPassed = state.results.every(r => r.status === 'PASS');
    state.status = allPassed ? 'PASSED' : 'FAILED';

  } catch (error) {
    console.error('Critical execution error:', error);
    state.status = 'FAILED';
  } finally {
    state.endTime = performance.now();
    const totalTime = ((state.endTime - state.startTime) / 1000).toFixed(2);

    // Output structured results for CI parsing (e.g., GitHub Actions summary)
    console.log('\n📊 Test Run Summary:');
    console.log(`------------------------------------------------`);
    console.log(`Node Version: ${state.nodeVersion}`);
    console.log(`Total Duration: ${totalTime}s`);
    console.log(`Overall Status: ${state.status}`);
    console.log(`------------------------------------------------`);
    
    state.results.forEach((res) => {
      const icon = res.status === 'PASS' ? '✅' : '❌';
      console.log(`${icon} ${res.testName} (${res.duration.toFixed(2)}ms)`);
      if (res.details) console.log(`   └─ ${res.details}`);
    });
    console.log(`------------------------------------------------`);

    // Exit with appropriate code for CI
    process.exit(state.status === 'PASSED' ? 0 : 1);
  }
}

// Execute
if (require.main === module) {
  main();
}
