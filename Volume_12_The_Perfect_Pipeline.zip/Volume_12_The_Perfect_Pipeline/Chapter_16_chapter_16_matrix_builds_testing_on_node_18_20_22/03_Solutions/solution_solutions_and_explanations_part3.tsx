/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState, useEffect, useRef } from 'react';

// 1. Define the JobStatus interface
interface JobStatus {
  id: number;
  matrixConfig: string; // e.g., "Node 18"
  status: 'queued' | 'in_progress' | 'success' | 'failure';
}

interface MatrixBuildStatusProps {
  workflowId: string;
}

export const MatrixBuildStatus: React.FC<MatrixBuildStatusProps> = ({ workflowId }) => {
  const [jobs, setJobs] = useState<JobStatus[]>([]);
  const [loading, setLoading] = useState<boolean>(false);
  
  // Ref to hold the interval ID for cleanup
  const intervalRef = useRef<NodeJS.Timeout | null>(null);

  const fetchStatus = async () => {
    setLoading(true);
    try {
      // Simulating an API call
      // In a real app: const response = await fetch(`/api/ci/status?workflowId=${workflowId}`);
      // const data = await response.json();
      
      // Mock data for demonstration
      const mockData: JobStatus[] = [
        { id: 1, matrixConfig: 'Node 18', status: 'success' },
        { id: 2, matrixConfig: 'Node 20', status: 'in_progress' },
        { id: 3, matrixConfig: 'Node 22', status: 'failure' },
      ];
      
      setJobs(mockData);
    } catch (error) {
      console.error("Failed to fetch status", error);
    } finally {
      setLoading(false);
    }
  };

  // Initial fetch and setup interval
  useEffect(() => {
    fetchStatus();

    // Auto-refresh logic
    intervalRef.current = setInterval(() => {
      fetchStatus();
    }, 5000); // 5 seconds

    // Cleanup on unmount
    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    };
  }, [workflowId]);

  // Helper to get color based on status
  const getStatusColor = (status: string) => {
    switch (status) {
      case 'success': return 'green';
      case 'failure': return 'red';
      case 'in_progress': return 'blue';
      default: return 'gray';
    }
  };

  return (
    <div style={{ padding: '20px' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '15px' }}>
        <h3>Workflow Status: {workflowId}</h3>
        <button onClick={fetchStatus} disabled={loading}>
          {loading ? 'Refreshing...' : 'Refresh Now'}
        </button>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(200px, 1fr))', gap: '15px' }}>
        {jobs.map((job) => (
          <div 
            key={job.id} 
            style={{ 
              border: '1px solid #ddd', 
              padding: '15px', 
              borderRadius: '8px', 
              boxShadow: '0 2px 4px rgba(0,0,0,0.1)' 
            }}
          >
            <h4 style={{ margin: '0 0 10px 0' }}>{job.matrixConfig}</h4>
            <span 
              style={{ 
                backgroundColor: getStatusColor(job.status), 
                color: 'white', 
                padding: '4px 8px', 
                borderRadius: '4px', 
                fontSize: '0.85rem',
                textTransform: 'uppercase'
              }}
            >
              {job.status}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
};
