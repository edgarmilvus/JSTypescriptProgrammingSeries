/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part6.ts
// Description: Solutions and Explanations
// ==========================================

digraph PipelineFlow {
    rankdir=TB;
    node [shape=box, style=filled, fillcolor=lightblue];

    Start [label="Start", shape=ellipse, fillcolor=lightgrey];
    End [label="End", shape=ellipse, fillcolor=lightgrey];

    subgraph cluster_matrix {
        label = "Matrix Strategy (Parallel)";
        style = dashed;
        node [fillcolor=lightblue];

        Node18 [label="Node 18\nRun Tests"];
        Node20 [label="Node 20\nRun Tests"];
        Node22 [label="Node 22\nRun Tests"];

        // Artifact sub-nodes
        Node18_Art [label="Upload\nCoverage", shape=note, fillcolor=white];
        Node20_Art [label="Upload\nCoverage", shape=note, fillcolor=white];
        Node22_Art [label="Upload\nCoverage", shape=note, fillcolor=white];
    }

    Aggregate [label="Aggregate\nCoverage", fillcolor=orange];
    
    // Flow connections
    Start -> Node18;
    Start -> Node20;
    Start -> Node22;

    Node18 -> Node18_Art;
    Node20 -> Node20_Art;
    Node22 -> Node22_Art;

    // Converge from matrix to aggregate
    Node18_Art -> Aggregate;
    Node20_Art -> Aggregate;
    Node22_Art -> Aggregate;

    Aggregate -> End;
}
