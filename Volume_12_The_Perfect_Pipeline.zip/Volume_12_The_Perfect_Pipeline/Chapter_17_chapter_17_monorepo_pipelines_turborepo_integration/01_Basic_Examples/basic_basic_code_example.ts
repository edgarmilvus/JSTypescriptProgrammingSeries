/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * @fileoverview A simplified simulation of an AI Code Reviewer for a monorepo.
 * This script represents the logic executed within a GitHub Action runner.
 * 
 * Dependencies: 
 * - @ai-sdk/openai (for the model)
 * - ai (Vercel AI SDK core)
 * - zod (for strict input validation)
 */

import { openai } from '@ai-sdk/openai';
import { generateText, CoreMessage } from 'ai';
import { z } from 'zod';

// ==========================================
// 1. TYPE DEFINITIONS & STRICT DISCIPLINE
// ==========================================

/**
 * Represents the input data structure expected from the CI pipeline.
 * We use Zod for runtime validation to enforce strict type discipline.
 * This prevents hallucinated inputs from reaching the AI model.
 */
const CodeDiffInputSchema = z.object({
  prId: z.number(),
  repoName: z.string(),
  diffContent: z.string().min(1, "Diff content cannot be empty"),
  fileExtension: z.string().optional(),
});

type CodeDiffInput = z.infer<typeof CodeDiffInputSchema>;

/**
 * Represents the structured output we expect from the AI model.
 * This guides the LLM to return JSON instead of free-form text.
 */
interface ReviewOutput {
  summary: string;
  riskLevel: 'low' | 'medium' | 'high';
  suggestions: string[];
}

// ==========================================
// 2. CORE LOGIC: THE AI REVIEWER
// ==========================================

/**
 * Generates an AI review for a given code diff.
 * 
 * @param input - The validated code diff input.
 * @returns A Promise resolving to the structured review object.
 * 
 * Under the Hood:
 * 1. Constructs a system prompt to define the AI's role.
 * 2. Uses `generateText` from Vercel AI SDK.
 * 3. Leverages `responseFormat: { type: 'json' }` to enforce JSON output.
 */
async function generateCodeReview(input: CodeDiffInput): Promise<ReviewOutput> {
  // Warm Start Note: In a production environment, the model instance 
  // (openai('gpt-4o')) would be initialized once outside this function 
  // to maintain state across multiple inference calls in the same runner session.

  const systemPrompt = `
    You are a senior software engineer reviewing a pull request.
    Analyze the provided code diff.
    Return a JSON object strictly matching this structure:
    {
      "summary": "Brief overview of changes",
      "riskLevel": "low" | "medium" | "high",
      "suggestions": ["List", "of", "specific", "improvements"]
    }
    Focus on logic errors, security risks, and adherence to TypeScript strict mode.
  `;

  const messages: CoreMessage[] = [
    { role: 'system', content: systemPrompt },
    { role: 'user', content: `Repository: ${input.repoName}\nFile Extension: ${input.fileExtension}\nDiff:\n${input.diffContent}` },
  ];

  try {
    // Vercel AI SDK call
    const { text } = await generateText({
      model: openai('gpt-4o-mini'), // Using a smaller model for speed/cost
      messages,
      temperature: 0.3, // Lower temp for deterministic code analysis
      responseFormat: { type: 'json' }, // Instructs the model to output JSON
    });

    // Parse the JSON string into our strict interface
    const parsedReview: ReviewOutput = JSON.parse(text);
    
    return parsedReview;

  } catch (error) {
    console.error("Error generating AI review:", error);
    throw new Error("AI Review Generation Failed");
  }
}

// ==========================================
// 3. SIMULATION: MOCKING THE CI PIPELINE
// ==========================================

/**
 * Simulates the entry point of a GitHub Action workflow.
 * In a real scenario, this would be triggered by 'pull_request' events.
 */
async function main() {
  // 1. Mock Input (Simulating `git diff` extraction)
  const rawInput = {
    prId: 101,
    repoName: "monorepo-app",
    diffContent: `
      diff --git a/src/utils/auth.ts b/src/utils/auth.ts
      index 123456..789012 100644
      --- a/src/utils/auth.ts
      +++ b/src/utils/auth.ts
      @@ -10,7 +10,7 @@
       export function validateToken(token: string) {
      -  if (!token) return null;
      +  if (!token) return false; // Changed return type inconsistency
         return jwt.verify(token, process.env.SECRET);
       }
    `,
    fileExtension: ".ts",
  };

  // 2. Strict Type Validation (Zod)
  // This step is crucial. If the CI pipeline changes or data is corrupted,
  // Zod throws a precise error before the AI call is made.
  const validationResult = CodeDiffInputSchema.safeParse(rawInput);

  if (!validationResult.success) {
    console.error("Validation Error:", validationResult.error.errors);
    process.exit(1); // Fail fast
  }

  // 3. Execute AI Review
  console.log("🚀 Starting AI Code Review...");
  const review = await generateCodeReview(validationResult.data);

  // 4. Output Results (For CI to capture)
  console.log("\n✅ Review Complete:");
  console.log(JSON.stringify(review, null, 2));
  
  // In a real pipeline, you might post this comment to the PR via GitHub API
}

// Execute the simulation
main().catch(console.error);
