/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

/**
 * FILE: scripts/ai-pre-review.ts
 * 
 * CONTEXT: Monorepo Pipeline Optimization (Chapter 17)
 * 
 * DESCRIPTION:
 * A strictly typed Node.js script that integrates with Turborepo's 
 * affected project detection and the Vercel AI SDK. It performs a 
 * static analysis on changed files, generating AI-powered feedback 
 * to enforce code quality standards before the CI pipeline completes.
 * 
 * USAGE:
 * turbo run analyze --filter=@myorg/ui-button
 */

import { generateText } from 'ai';
import { openai } from '@ai-sdk/openai';
import { z } from 'zod';
import fs from 'fs/promises';
import path from 'path';

// ============================================================================
// 1. STRICT TYPE DISCIPLINE & SCHEMA DEFINITION
// ============================================================================

/**
 * Defines the strict data contract for the AI's output.
 * We do not trust the LLM to return arbitrary text. We enforce
 * a specific structure using Zod to ensure type safety at runtime.
 */
const ReviewResultSchema = z.object({
  score: z.number().min(0).max(100),
  issues: z.array(
    z.object({
      file: z.string(),
      line: z.number(),
      severity: z.enum(['critical', 'warning', 'info']),
      message: z.string(),
      suggestedFix: z.string().optional(),
    })
  ),
  summary: z.string(),
});

// Infer the TypeScript type from the Zod schema for internal usage
type ReviewResult = z.infer<typeof ReviewResultSchema>;

/**
 * Configuration for the monorepo context.
 * In a real scenario, this would be derived from `turbo.json` or git diff.
 */
interface MonorepoContext {
  workspaceRoot: string;
  affectedPackagePath: string; // e.g., 'packages/ui'
  changedFiles: string[];      // e.g., ['src/Button.tsx']
}

// ============================================================================
// 2. FILE SYSTEM & AFFECTED PROJECT LOGIC
// ============================================================================

/**
 * Simulates Turborepo's "Affected" detection.
 * In a real pipeline, this would parse `git diff` or use `@turbo/repo`.
 * Here, we read the file system of the specific package passed in context.
 * 
 * @param context - The monorepo configuration
 * @returns Promise<string> - A concatenated string of file contents for analysis
 */
async function gatherAffectedCode(context: MonorepoContext): Promise<string> {
  console.log(`🔍 Scanning affected package: ${context.affectedPackagePath}`);
  
  let aggregatedCode = '';
  
  for (const file of context.changedFiles) {
    const fullPath = path.join(context.workspaceRoot, context.affectedPackagePath, file);
    try {
      const content = await fs.readFile(fullPath, 'utf-8');
      aggregatedCode += `\n\n--- FILE: ${file} ---\n${content}`;
    } catch (error) {
      console.warn(`⚠️  Could not read file: ${fullPath}`);
    }
  }
  
  return aggregatedCode;
}

// ============================================================================
// 3. AI INTEGRATION (Vercel AI SDK)
// ============================================================================

/**
 * Performs the AI analysis using the Vercel AI SDK.
 * 
 * Why Vercel AI SDK?
 * 1. Streaming: It handles streaming responses efficiently.
 * 2. Provider Agnostic: Easy to swap OpenAI for Anthropic or local models.
 * 3. Structured Outputs: It supports JSON mode, which we wrap with Zod.
 * 
 * @param codeContext - The aggregated code string
 * @returns Promise<ReviewResult> - The strictly typed review object
 */
async function analyzeWithAI(codeContext: string): Promise<ReviewResult> {
  console.log('🤖 Sending code to AI model for review...');

  const prompt = `
    You are a senior TypeScript engineer enforcing strict type discipline.
    Analyze the following code snippets from a monorepo package.
    Identify potential type errors, logic flaws, or violations of best practices.
    Return ONLY valid JSON matching the schema provided.
    
    Code Context:
    ${codeContext}
  `;

  try {
    // Using the Vercel AI SDK to generate text
    const { text } = await generateText({
      model: openai('gpt-4-turbo-preview'),
      prompt: prompt,
      // We instruct the model to output JSON to make parsing easier
      experimental_providerMetadata: {
        openai: {
          response_format: { type: 'json_object' },
        },
      },
    });

    // Parse and validate the response
    // This is the critical step of Strict Type Discipline:
    // We never cast the AI response. We validate it.
    const parsed = JSON.parse(text);
    const validated = ReviewResultSchema.parse(parsed);

    return validated;
  } catch (error) {
    console.error('❌ AI Analysis failed:', error);
    // Fallback or throw depending on pipeline strictness
    throw new Error('AI analysis failed to return valid structured data.');
  }
}

// ============================================================================
// 4. REPORTING & PIPELINE INTEGRATION
// ============================================================================

/**
 * Generates a human-readable report and determines pipeline exit status.
 * 
 * @param result - The validated AI review result
 * @param context - Monorepo context for path resolution
 */
function generateReport(result: ReviewResult, context: MonorepoContext): void {
  console.log('\n========================================');
  console.log('📊 AI PRE-REVIEW REPORT');
  console.log('========================================');
  console.log(`Package: ${context.affectedPackagePath}`);
  console.log(`Overall Score: ${result.score}/100`);
  console.log(`Summary: ${result.summary}`);
  console.log('----------------------------------------');

  if (result.issues.length === 0) {
    console.log('✅ No issues detected. Proceeding to build...');
    return;
  }

  console.log(`⚠️  Found ${result.issues.length} potential issues:\n`);
  
  result.issues.forEach((issue) => {
    const icon = issue.severity === 'critical' ? '⛔' : '⚠️';
    console.log(`${icon} [${issue.severity.toUpperCase()}] ${issue.file}:${issue.line}`);
    console.log(`   Message: ${issue.message}`);
    if (issue.suggestedFix) {
      console.log(`   Fix: ${issue.suggestedFix}`);
    }
    console.log('');
  });

  // Pipeline Logic: Fail the build if critical issues are found
  if (result.issues.some(i => i.severity === 'critical')) {
    console.log('🛑 CRITICAL ISSUES DETECTED. Pipeline halted.');
    process.exit(1); // Exit with error code to fail the CI step
  } else {
    console.log('⚠️  Warnings detected. Pipeline allowed to continue (soft fail).');
  }
}

// ============================================================================
// 5. MAIN EXECUTION ORCHESTRATOR
// ============================================================================

/**
 * Main entry point.
 * In a real Turborepo setup, this script would be invoked via `turbo run`.
 * Example: `turbo run analyze --filter=@myorg/ui-button`
 */
async function main() {
  // Mocking the context passed from the CI environment or CLI args
  const context: MonorepoContext = {
    workspaceRoot: process.cwd(), // Assumes running from repo root
    affectedPackagePath: 'packages/ui', // Simulating an affected package
    changedFiles: ['src/Button.tsx', 'src/index.ts'], // Simulating git diff
  };

  try {
    // Step 1: Gather code (Turborepo Affected Logic)
    const code = await gatherAffectedCode(context);
    
    if (!code) {
      console.log('ℹ️  No code changes detected or files empty. Skipping analysis.');
      return;
    }

    // Step 2: AI Analysis (Vercel AI SDK)
    const reviewResult = await analyzeWithAI(code);

    // Step 3: Report & Enforce (Strict Type Discipline)
    generateReport(reviewResult, context);

  } catch (error) {
    console.error('Pipeline execution failed:', error);
    process.exit(1);
  }
}

// Execute if run directly
if (require.main === module) {
  main();
}
