/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part6.tsx
// Description: Solutions and Explanations
// ==========================================

// apps/dashboard/components/AIReviewPanel.tsx
'use client'; // Required for Next.js App Router if using 'useChat'

import React, { useState } from 'react';
import { useChat } from 'ai/react';

// 1. Strict Type Discipline for Props
interface AIReviewPanelProps {
  diff: string;
  filePath: string;
}

export function AIReviewPanel({ diff, filePath }: AIReviewPanelProps) {
  // 2. SDK Integration: useChat hook
  // The hook manages the message state, input handling, and API communication.
  const { messages, input, handleInputChange, handleSubmit, isLoading, error } = useChat({
    api: '/api/review', // Points to our API route in Exercise 4
    body: {
      diff, // Pass the diff as part of the initial request context
      filePath,
    },
  });

  // We don't need a manual input field for the chat, 
  // but useChat requires an input state. We can hide it or manage it manually.
  // Here, we simply trigger the submission via a button click.
  
  const [showDiff, setShowDiff] = useState(true);

  return (
    <div className="w-full max-w-4xl p-4 border rounded-lg shadow-sm bg-white">
      <div className="flex justify-between items-center mb-4">
        <h3 className="font-bold text-lg">
          AI Code Review: <span className="font-normal text-gray-600">{filePath}</span>
        </h3>
        <button
          onClick={() => setShowDiff(!showDiff)}
          className="text-sm text-blue-600 hover:underline"
        >
          {showDiff ? 'Hide Diff' : 'Show Diff'}
        </button>
      </div>

      {/* 4. UI Implementation: Input Diff Display */}
      {showDiff && (
        <div className="mb-4">
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Code Diff
          </label>
          <textarea
            readOnly
            value={diff}
            className="w-full h-32 p-2 bg-gray-50 border rounded text-xs font-mono overflow-auto"
          />
        </div>
      )}

      {/* 4. UI Implementation: Trigger Button */}
      {/* We hide the default input but need to handle submit */}
      <form onSubmit={handleSubmit} className="flex gap-2 mb-4">
        {/* Hidden input to satisfy useChat hook requirements if needed, 
            but we pass data via body in useChat config */}
        <input type="hidden" name="diff" value={diff} />
        <input type="hidden" name="filePath" value={filePath} />
        
        <button
          type="submit"
          disabled={isLoading}
          className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 disabled:opacity-50"
        >
          {isLoading ? 'Reviewing...' : 'Get AI Review'}
        </button>
      </form>

      {/* 4. UI Implementation: Streaming Response Display */}
      <div className="space-y-4">
        {messages.map((m) => (
          <div key={m.id} className="p-3 bg-gray-50 rounded">
            <div className="font-semibold text-sm mb-1">
              {m.role === 'user' ? 'You' : 'AI Assistant'}
            </div>
            <div className="text-sm text-gray-800 whitespace-pre-wrap">
              {m.content}
            </div>
          </div>
        ))}
      </div>

      {/* 5. Error Handling */}
      {error && (
        <div className="mt-4 p-3 bg-red-50 text-red-700 border border-red-200 rounded">
          <strong>Error:</strong> {error.message}
          <p className="text-xs mt-1">Please try again later.</p>
        </div>
      )}
    </div>
  );
}
