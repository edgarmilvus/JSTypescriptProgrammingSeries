/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part7.ts
// Description: Solutions and Explanations
// ==========================================

// app/api/review/route.ts
import { NextRequest } from 'next/server';
import { StreamingTextResponse, streamText } from 'ai';
import { openai } from '@ai-sdk/openai'; // Assuming @ai-sdk/openai is installed
import { z } from 'zod';

// 1. Type Safety: Define Zod schema for runtime validation
const requestSchema = z.object({
  diff: z.string().min(1, "Diff cannot be empty"),
  filePath: z.string().min(1, "File path is required"),
});

export async function POST(req: NextRequest) {
  try {
    // Parse and validate the request body
    const body = await req.json();
    const validation = requestSchema.safeParse(body);

    if (!validation.success) {
      return new Response(JSON.stringify({ error: validation.error }), {
        status: 400,
        headers: { 'Content-Type': 'application/json' },
      });
    }

    const { diff, filePath } = validation.data;

    // 2. Prompt Engineering
    const systemPrompt = `
      You are a senior code reviewer with 20 years of experience.
      Your task is to review a code change based on the provided diff.
      
      Focus on:
      1. Potential bugs or logical errors.
      2. Adherence to the shared 'ui' library patterns in this monorepo.
      3. Security vulnerabilities (e.g., XSS, SQL injection).
      4. Performance implications.
      
      Be concise, constructive, and professional.
      File: ${filePath}
    `;

    // 3. AI Integration & Streaming Logic
    const result = await streamText({
      model: openai('gpt-4-turbo-preview'),
      system: systemPrompt,
      prompt: `Here is the code diff:\n\n${diff}`,
    });

    // 4. Return the stream
    // The StreamingTextResponse handles the correct headers for chunked transfer
    return new StreamingTextResponse(result.textStream);

  } catch (error) {
    console.error('AI Review API Error:', error);
    return new Response('Internal Server Error', { status: 500 });
  }
}
