/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part8.ts
// Description: Solutions and Explanations
// ==========================================

// 1. CI Pipeline Architecture (Pipeline.dot)
digraph CI_Pipeline {
    rankdir=TB;
    node [shape=box, style="rounded,filled", fillcolor="lightgray"];
    
    "Pull Request" [shape=ellipse, fillcolor="lightblue"];
    
    subgraph cluster_job1 {
        label = "Job 1: Lint & Type Check";
        style = dashed;
        color = blue;
        "Checkout" -> "Install Deps" -> "Lint" -> "TypeCheck";
    }

    subgraph cluster_job2 {
        label = "Job 2: Build & Test";
        style = dashed;
        color = green;
        "Build" -> "Test";
    }

    // Dependencies
    "Pull Request" -> "Checkout";
    "TypeCheck" -> "Build" [label="needs: success", style=dotted, constraint=false];
    
    // Cache Interaction
    "Remote Cache (Vercel)" [shape=cylinder, fillcolor="lightyellow"];
    "Build" -> "Remote Cache (Vercel)" [label="Check Hash", style=dashed, dir=both];
    
    // Fail Fast Logic
    "Lint" -> "Fail" [label="Fails", color=red, fontcolor=red];
    "Fail" [shape=doubleoctagon, fillcolor="#ffcccc"];
    
    // Conditional Execution
    "TypeCheck" -> "Skip Build" [label="Fails", style=dashed, color=red];
    "Skip Build" [label="Skipped", shape=note, fillcolor=white];
}
