/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part9.ts
// Description: Solutions and Explanations
// ==========================================

// 2. Monorepo Dependency Graph (Dependencies.dot)
digraph Monorepo_Deps {
    rankdir=LR;
    node [shape=component, fillcolor="lightblue"];
    
    "utils" [fillcolor="lightgreen", label="utils (Changed)"];
    "ui" [fillcolor="lightyellow"];
    "web" [fillcolor="lightcoral"];
    "docs" [fillcolor="lightcoral"];
    "admin" [fillcolor="lightcoral"];

    // Dependencies
    "utils" -> "ui";
    "ui" -> "web";
    "ui" -> "admin";
    "ui" -> "docs";

    // Turborepo Filter Scope
    "utils" -> "ui" [label="Dependency", color=blue, fontcolor=blue];
    "ui" -> "web" [label="Transitive Dep", color=blue, fontcolor=blue, style=dashed];
    
    // Scope Indicator
    "Scope" [shape=star, fillcolor="gold", label="Turborepo Filter Scope\n(--filter=origin/main...)"];
    "Scope" -> "utils" [style=dotted, constraint=false];
    "Scope" -> "web" [style=dotted, constraint=false];
}
