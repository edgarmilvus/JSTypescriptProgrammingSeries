/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: theory_theoretical_foundations.ts
// Description: Theoretical Foundations
// ==========================================

<DIAGRAM>
digraph SecurityPipeline {
    rankdir=TB;
    node [shape=box, style=filled, fillcolor="#E3F2FD", fontname="Helvetica"];

    subgraph cluster_0 {
        label = "Developer's Machine";
        style = dashed;
        node [fillcolor="#FFF9C4"];
        Commit [label="Code Commit"];
    }

    subgraph cluster_1 {
        label = "CI/CD Pipeline (GitHub Actions)";
        style = solid;
        node [fillcolor="#E3F2FD"];

        PR_Check [label="Pull Request\nSAST Scan (CodeQL)"];
        Build [label="Build & Unit Test"];
        Deploy_Staging [label="Deploy to Staging"];
        DAST_Scan [label="DAST Scan (OWASP ZAP)"];
        Quality_Gate [label="Security Quality Gate", shape=diamond, fillcolor="#FFCDD2"];
        Deploy_Production [label="Deploy to Production"];
    }

    Commit -> PR_Check;
    PR_Check -> Build [label="Vulnerability-Free"];
    Build -> Deploy_Staging;
    Deploy_Staging -> DAST_Scan;
    DAST_Scan -> Quality_Gate;
    Quality_Gate -> Deploy_Production [label="Approved"];
    Quality_Gate -> Fail [label="Vulnerability Found", style=dashed, color=red];

    Fail [label="Build Blocked", shape=octagon, fillcolor="#EF9A9A", fontcolor=red];

    // Styling for clarity
    { rank=same; PR_Check }
    { rank=same; Build }
    { rank=same; Deploy_Staging; DAST_Scan }
}
</DIAGRAM>
