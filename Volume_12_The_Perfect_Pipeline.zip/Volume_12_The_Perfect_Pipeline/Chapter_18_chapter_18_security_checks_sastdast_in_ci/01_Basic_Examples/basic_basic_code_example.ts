/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

// src/app/api/user/update/route.ts
// This file represents a Next.js Server Action or API Route Handler.
// It handles incoming HTTP requests to update user profile data.

import { NextResponse } from 'next/server';
import { z } from 'zod';

/**
 * 1. DEFINE THE SCHEMA
 * We use Zod to define a strict schema for the incoming user data.
 * This schema acts as a "contract" between the client and the server.
 * 
 * Why Zod?
 * - It provides runtime validation (unlike TypeScript interfaces).
 * - It generates TypeScript types automatically.
 * - It offers granular validation rules (email format, string length, etc.).
 */
const userUpdateSchema = z.object({
  username: z
    .string()
    .min(3, "Username must be at least 3 characters long")
    .max(20, "Username cannot exceed 20 characters")
    .regex(/^[a-zA-Z0-9_]+$/, "Username can only contain letters, numbers, and underscores"),
  
  email: z
    .string()
    .email("Invalid email address format"),
  
  bio: z
    .string()
    .max(200, "Bio must be 200 characters or less")
    .optional() // Bio is optional; if not provided, it defaults to undefined
    .transform((val) => val?.trim()), // Transform: Clean whitespace immediately
});

/**
 * 2. INFER THE TYPE
 * We extract a TypeScript type from the Zod schema.
 * This gives us perfect type safety for the validated data within our logic.
 */
type UserUpdateInput = z.infer<typeof userUpdateSchema>;

/**
 * 3. THE VALIDATION LOGIC
 * An async function that handles the request.
 * This mimics a Next.js Server Action or API Route Handler.
 */
export async function POST(request: Request) {
  try {
    // A. Parse the incoming request body
    // We cannot trust the body yet; it might be malformed JSON or empty.
    const rawBody = await request.json();

    // B. Validate against the schema
    // .parse() throws a ZodError if validation fails.
    // .safeParse() returns a result object (success boolean + errors) without throwing.
    // We use .safeParse() to handle errors gracefully and return user-friendly messages.
    const validationResult = userUpdateSchema.safeParse(rawBody);

    if (!validationResult.success) {
      // C. Handle Validation Errors
      // Map Zod's field-specific errors into a clean JSON response.
      const errorMessages = validationResult.error.errors.map((err) => ({
        field: err.path.join('.'),
        message: err.message,
      }));

      return NextResponse.json(
        { 
          success: false, 
          message: "Validation failed", 
          errors: errorMessages 
        },
        { status: 400 } // 400 Bad Request
      );
    }

    // D. Access Validated Data
    // TypeScript now knows that `validatedData` is of type `UserUpdateInput`.
    // We can safely access properties without runtime checks.
    const validatedData: UserUpdateInput = validationResult.data;

    // E. Execute Business Logic
    // Here, you would typically save to a database (e.g., Prisma, Drizzle).
    // Because we validated the data, we are confident it matches our DB constraints.
    console.log("Saving user data to database:", validatedData);
    
    // Simulate database update
    // await db.user.update({ where: { id: userId }, data: validatedData });

    return NextResponse.json(
      { 
        success: true, 
        message: "Profile updated successfully",
        data: validatedData 
      },
      { status: 200 }
    );

  } catch (error) {
    // F. Handle Unexpected Errors
    // Catches JSON parsing errors or database errors.
    console.error("Unexpected server error:", error);
    return NextResponse.json(
      { success: false, message: "Internal Server Error" },
      { status: 500 }
    );
  }
}
