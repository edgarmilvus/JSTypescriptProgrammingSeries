/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// pages/api/register.ts
// Next.js API Route for User Registration with Runtime Security Validation

import { NextApiRequest, NextApiResponse } from 'next';
import { z } from 'zod';

/**
 * SECURITY CONTEXT: SAST/DAST Integration
 * 
 * 1. Runtime Validation (Zod): Acts as a DAST (Dynamic Application Security Testing) 
 *    guard at the entry point. It prevents malformed data from entering the Event Loop.
 * 2. Type Narrowing: After Zod validates the data, TypeScript infers the specific type,
 *    allowing safe access to properties without runtime errors.
 * 3. Event Loop: The async handler allows Node.js to process other requests while 
 *    waiting for database I/O, ensuring high concurrency.
 */

// --- 1. Define the Security Schema ---
// We define a strict schema for the incoming payload. 
// This prevents mass assignment vulnerabilities and ensures data integrity.
const UserRegistrationSchema = z.object({
    email: z.string().email({ message: "Invalid email address" }),
    password: z.string().min(8, { message: "Password must be at least 8 characters" }),
    role: z.enum(['user', 'admin']).default('user'), // Strictly typed enum
    metadata: z.object({
        source: z.string().optional(),
    }).optional()
});

// Infer the TypeScript type from the Zod schema for internal usage
type UserRegistrationInput = z.infer<typeof UserRegistrationSchema>;

/**
 * API Handler: POST /api/register
 * 
 * @param req - The Next.js API Request object
 * @param res - The Next.js API Response object
 */
export default async function handler(req: NextApiRequest, res: NextApiResponse) {
    // --- 2. Method Validation ---
    // Ensure the request is a POST request. 
    // This is a basic security check to prevent unintended HTTP methods.
    if (req.method !== 'POST') {
        return res.status(405).json({ 
            success: false, 
            error: 'Method Not Allowed' 
        });
    }

    // --- 3. Runtime Validation (The Security Gate) ---
    // We attempt to parse the incoming body against our Zod schema.
    // This happens at runtime, catching data that bypassed compile-time checks.
    const validationResult = UserRegistrationSchema.safeParse(req.body);

    if (!validationResult.success) {
        // SECURITY LOG: Log the validation error (omitted for brevity, but crucial in production)
        // e.g., logger.warn('Security: Invalid payload received', validationResult.error);
        
        // Return a 400 Bad Request with specific error details.
        // Note: In production, you might want to sanitize these errors to avoid leaking schema details.
        return res.status(400).json({
            success: false,
            error: 'Validation Failed',
            details: validationResult.error.flatten().fieldErrors,
        });
    }

    // --- 4. Type Narrowing & Business Logic ---
    // Because validationResult.success is true, TypeScript now knows 
    // 'validationResult.data' is of type 'UserRegistrationInput'.
    // We can safely access properties without checking if they exist.
    const { email, password, role } = validationResult.data;

    try {
        // --- 5. Asynchronous Processing (Event Loop) ---
        // Simulate a database operation. Using 'await' yields control back to the Event Loop,
        // allowing Node.js to handle other incoming requests concurrently.
        const user = await mockDatabaseInsert({ email, password, role });

        // Return success response
        return res.status(201).json({
            success: true,
            data: {
                id: user.id,
                email: user.email,
                role: user.role
            }
        });

    } catch (error) {
        // Handle internal server errors securely
        console.error('Registration Error:', error);
        return res.status(500).json({
            success: false,
            error: 'Internal Server Error'
        });
    }
}

// --- Helper: Mock Database Function ---
// Simulates an async database insertion.
async function mockDatabaseInsert(data: Pick<UserRegistrationInput, 'email' | 'password' | 'role'>) {
    // Simulate network latency (yields to Event Loop)
    await new Promise(resolve => setTimeout(resolve, 100)); 
    
    // Return a mock user object
    return {
        id: Math.random().toString(36).substring(7),
        email: data.email,
        role: data.role
    };
}
