/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part10.ts
// Description: Solutions and Explanations
// ==========================================

digraph SecurePipeline {
    rankdir=TB;
    node [shape=box, style="rounded,filled", color="#4a90e2", fontname="Arial"];
    edge [fontname="Arial"];

    // Nodes
    Developer [label="Developer", fillcolor="#a6d1fa"];
    Trigger [label="GitHub Actions Trigger\n(on: push/pull_request)", fillcolor="#e1f0ff"];
    
    subgraph cluster_jobs {
        label = "CI Pipeline Jobs";
        style = "dashed";
        color = "#333";

        SAST [label="Job 1: Static Analysis\n(SAST - CodeQL)", fillcolor="#ffcccc"];
        Build [label="Job 2: Build & Unit Test\n(TSC Strict Mode + Zod)", fillcolor="#fff2cc"];
        DAST [label="Job 3: Dynamic Analysis\n(DAST - OWASP ZAP)", fillcolor="#d9ead3"];
    }

    Decision [label="Quality Gate\nPass?", shape="diamond", fillcolor="#f0f0f0"];
    
    Deploy [label="Deploy to Production", fillcolor="#d0e0e3"];
    Block [label="Block Merge\n(Exit 1)", fillcolor="#ea9999", shape="ellipse"];

    // Edges
    Developer -> Trigger;
    Trigger -> SAST;
    SAST -> Build;
    Build -> DAST;
    DAST -> Decision;

    Decision -> Deploy [label="All Pass", color="green", fontcolor="green"];
    Decision -> Block [label="Any Fail", color="red", fontcolor="red"];
}
