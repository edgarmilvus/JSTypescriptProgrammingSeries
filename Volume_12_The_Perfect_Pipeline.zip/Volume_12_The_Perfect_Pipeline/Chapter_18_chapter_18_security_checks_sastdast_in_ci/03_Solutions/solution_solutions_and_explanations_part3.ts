/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

// actions.ts
'use server';
import { validateApiResponse, ValidationError } from './validation';
import { AiResponseSchema, AiResponse } from './types';

export async function fetchAiResponse(prompt: string) {
  try {
    // Mock fetch implementation
    const response = await fetch('https://api.llm-provider.com/v1/chat', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ prompt }),
    });

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }

    const rawData: unknown = await response.json();

    // Use validateApiResponse to parse and validate rawData
    // This ensures strict type safety before business logic
    const validatedData: AiResponse = validateApiResponse(rawData, AiResponseSchema);

    // Proceed with business logic using validatedData
    return {
      success: true,
      content: validatedData.choices[0]?.message.content,
      usage: validatedData.usage,
    };
  } catch (error) {
    if (error instanceof ValidationError) {
      // Handle validation errors specifically (e.g., log, alert)
      console.error('Validation Error:', error.message, error.details);
      return { success: false, error: 'Invalid data structure received from AI.' };
    }
    
    // Handle network or other errors
    console.error('Fetch Error:', error);
    return { success: false, error: 'Failed to fetch response.' };
  }
}
