/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

// pipeline.ts

// 1. Define explicit interfaces for the data structures
interface RawItem {
  value?: unknown; // Value is unknown/untrusted initially
}

interface ProcessedItem {
  value: string; // After processing, we guarantee it is a string
}

// 2. Implement a user-defined type guard
function isStringRecord(record: unknown): record is Record<string, string> {
  if (typeof record !== 'object' || record === null || Array.isArray(record)) {
    return false;
  }
  // Check if all values are strings (optional, depending on strictness required)
  return Object.values(record).every(val => typeof val === 'string');
}

// 3. Refactor processData for strictness
export function processData(rawData: { items: RawItem[] }): string[] {
  // We explicitly type the input to reject 'any'
  
  const result = rawData.items.map((item: RawItem) => {
    // Runtime check: Ensure item.value exists and is a string
    // This handles 'strictNullChecks' and prevents runtime errors
    if (typeof item.value === 'string' && item.value.trim().length > 0) {
      return item.value.toUpperCase();
    }
    
    // Fallback or error handling for invalid data
    // Returning an empty string or throwing an error depending on requirements
    throw new Error(`Invalid item value found: ${item.value}`);
  });

  return result;
}

// 4. Refactor calculateMetrics for strictness
export function calculateMetrics(data: string[]): number {
  // 'acc' is explicitly typed as number
  return data.reduce((acc: number, curr: string) => {
    return acc + curr.length;
  }, 0);
}

// Example usage demonstrating strict checks
const unsafeData = {
  items: [
    { value: "hello" },
    { value: null }, // This will now be caught at runtime
    { value: "world" }
  ]
};

try {
  const processed = processData(unsafeData);
  const metrics = calculateMetrics(processed);
  console.log(metrics);
} catch (e) {
  console.error("Pipeline failed:", e);
}
