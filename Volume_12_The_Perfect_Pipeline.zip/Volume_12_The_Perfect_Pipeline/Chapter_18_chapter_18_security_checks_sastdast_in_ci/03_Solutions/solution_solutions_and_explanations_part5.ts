/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

// security-gatekeeper.ts
import { readFileSync } from 'fs';
import { z } from 'zod';

// 1. Define the Zod Schema for a CodeQL finding
const CodeQlFindingSchema = z.object({
  severity: z.enum(['low', 'medium', 'high', 'critical']),
  description: z.string(),
});

// 2. Define the Schema for the Report Array
const CodeQlReportSchema = z.array(CodeQlFindingSchema);

// Thresholds
const THRESHOLDS = {
  critical: 0,
  high: 2,
};

const reportPath = process.argv[2];
if (!reportPath) {
  console.error('Usage: ts-node security-gatekeeper.ts <path-to-json>');
  process.exit(1);
}

try {
  const fileContent = readFileSync(reportPath, 'utf-8');
  const rawJson = JSON.parse(fileContent);

  // Validate rawJson using Zod
  const report = CodeQlReportSchema.parse(rawJson);

  // Count Critical/High findings
  const criticalCount = report.filter(f => f.severity === 'critical').length;
  const highCount = report.filter(f => f.severity === 'high').length;

  console.log(`Scan Results: ${criticalCount} Critical, ${highCount} High findings.`);

  // Check against thresholds
  if (criticalCount > THRESHOLDS.critical || highCount > THRESHOLDS.high) {
    console.error('❌ Security Gate: FAILED. Threshold exceeded.');
    process.exit(1); // Simulate CI failure
  }

  console.log('✅ Security Gate: PASSED.');
  process.exit(0); // Simulate CI success

} catch (error) {
  if (error instanceof z.ZodError) {
    console.error('❌ Invalid Report Format:', error.errors);
  } else {
    console.error('❌ Error processing report:', error);
  }
  process.exit(1);
}
