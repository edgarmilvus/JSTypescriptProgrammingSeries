/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part8.ts
// Description: Solutions and Explanations
// ==========================================

// actions.ts
'use server';
import { z } from 'zod';

// Define strict input validation
const promptSchema = z.string().max(1000).min(1).trim();

// Define return type for type safety
interface ActionResponse {
  success: boolean;
  data?: string;
  error?: string;
}

export async function sendMessage(prevState: any, formData: FormData): Promise<ActionResponse> {
  // 1. Extract and validate input
  const prompt = formData.get('prompt');
  const result = promptSchema.safeParse(prompt);

  if (!result.success) {
    return { success: false, error: 'Invalid prompt. Must be 1-1000 characters.' };
  }

  // 2. Call external API (securely)
  // The API key is accessed via server-side environment variables (never exposed to client)
  const apiKey = process.env.OPENAI_API_KEY;
  
  if (!apiKey) {
    return { success: false, error: 'Server configuration error.' };
  }

  try {
    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${apiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ 
        model: "gpt-3.5-turbo",
        messages: [{ role: "user", content: result.data }] 
      }),
    });

    if (!response.ok) {
      throw new Error(`API Error: ${response.statusText}`);
    }

    const data = await response.json();
    const reply = data.choices[0]?.message?.content || 'No response generated.';

    // 3. Return structured response
    return { success: true, data: reply };
  } catch (error) {
    console.error(error);
    return { success: false, error: 'Failed to generate AI response.' };
  }
}
