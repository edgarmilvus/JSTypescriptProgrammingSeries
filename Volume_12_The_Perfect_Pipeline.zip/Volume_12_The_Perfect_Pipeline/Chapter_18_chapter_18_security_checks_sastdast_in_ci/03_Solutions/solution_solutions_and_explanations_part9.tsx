/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part9.tsx
// Description: Solutions and Explanations
// ==========================================

// app/components/ChatInput.tsx (Refactored)
'use client';
import { useActionState } from 'react'; // React 19 hook, or useTransition/useEffect in older versions
import { sendMessage } from '@/actions';
import { useRef } from 'react';

export default function ChatInput() {
  const formRef = useRef<HTMLFormElement>(null);
  // useActionState handles form submissions and pending states
  const [state, formAction, isPending] = useActionState(sendMessage, null);

  return (
    <div>
      <form ref={formRef} action={formAction}>
        <input 
          name="prompt" 
          type="text" 
          placeholder="Ask the AI..." 
          disabled={isPending}
        />
        <button type="submit" disabled={isPending}>
          {isPending ? 'Sending...' : 'Send'}
        </button>
      </form>

      {/* Display Result or Error */}
      {state?.success && (
        <div className="response">
          <p>AI: {state.data}</p>
        </div>
      )}
      {state?.error && (
        <div className="error">
          <p>Error: {state.error}</p>
        </div>
      )}
    </div>
  );
}
