/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

name: Cost-Optimized CI/CD for SaaS Web App

on:
  push:
    branches: [main]
  pull_request:
    branches: [main]

jobs:
  build-and-test:
    runs-on: ubuntu-latest
    # Use matrix strategy for parallelism only if needed; here we keep it simple to avoid extra runners
    steps:
      - name: Checkout code
        uses: actions/checkout@v4

      - name: Setup Node.js with ESM support
        uses: actions/setup-node@v4
        with:
          node-version: '18'
          cache: 'npm' # Enables built-in npm caching for faster installs

      - name: Install dependencies
        run: npm ci --prefer-offline # Use offline mode to skip network fetches if cache hits

      - name: Build application
        run: npm run build
        # Outputs to ./dist directory; we'll cache this for future runs
        env:
          NODE_ENV: production

      - name: Run unit tests
        run: npm test -- --coverage
        # Conditional: Skip if only docs or config files changed (e.g., README.md, .github/workflows/)
        if: ${{ contains(github.event.head_commit.modified, 'src/') || contains(github.event.head_commit.modified, 'tests/') }}

  deploy:
    needs: build-and-test
    runs-on: ubuntu-latest
    if: ${{ github.event_name == 'push' && github.ref == 'refs/heads/main' }} # Only deploy on main branch pushes
    steps:
      - name: Checkout code
        uses: actions/checkout@v4

      - name: Setup Node.js
        uses: actions/setup-node@v4
        with:
          node-version: '18'
          cache: 'npm'

      - name: Restore build artifacts
        uses: actions/cache@v4
        with:
          path: |
            ./dist
            ./node_modules
          key: ${{ runner.os }}-build-${{ hashFiles('package-lock.json') }}-${{ hashFiles('tsconfig.json') }}
          restore-keys: |
            ${{ runner.os }}-build-
            ${{ runner.os }}-

      - name: Deploy to production
        run: npm run deploy # Hypothetical deploy script (e.g., to Vercel or AWS)
        env:
          DEPLOY_TOKEN: ${{ secrets.DEPLOY_TOKEN }}
