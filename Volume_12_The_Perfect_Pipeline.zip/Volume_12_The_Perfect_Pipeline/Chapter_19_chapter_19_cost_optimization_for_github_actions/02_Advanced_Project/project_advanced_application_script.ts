/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// File: app/api/orchestrate/route.ts
// Target: Next.js 14+ App Router (Server Component / Route Handler)
// Module System: ESM (Requires "type": "module" in package.json)

import { NextResponse } from 'next/server';
import { Pinecone } from '@pinecone-database/pinecone';
import { HuggingFaceInference } from '@langchain/community/llms/hf';

// ==========================================
// 1. CONFIGURATION & TYPES
// ==========================================

/**
 * Represents the payload received from a GitHub Webhook (push event).
 * We only extract what we need to make cost decisions.
 */
type GitHubWebhookPayload = {
  commits: Array<{ message: string; modified: string[] }>;
  repository: { name: string };
  sender: { login: string };
};

/**
 * User subscription tiers dictate concurrency limits and runner access.
 * 'self-hosted' access implies the user has provisioned their own runners.
 */
type SubscriptionTier = 'free' | 'pro' | 'enterprise';

interface UserConfig {
  tier: SubscriptionTier;
  maxConcurrency: number;
  allowedRunners: ('github-hosted' | 'self-hosted')[];
  pineconeNamespace: string; // Namespace for caching AI analysis
}

// ==========================================
// 2. COST OPTIMIZATION LOGIC
// ==========================================

/**
 * Analyzes the commit message and file changes to determine if a full workflow
 * is necessary. This is the "Conditional Job Execution" strategy.
 * 
 * Why: Docs-only changes shouldn't trigger expensive unit tests or builds.
 * How: Regex matching on commit messages and file extensions.
 */
const shouldRunBuild = (payload: GitHubWebhookPayload): boolean => {
  const commitMsg = payload.commits[0]?.message.toLowerCase() || '';
  const modifiedFiles = payload.commits.flatMap(c => c.modified);

  // Check for "skip-ci" or "docs-only" tags
  if (/\[skip-ci\]|\[docs\]/.test(commitMsg)) {
    console.log('Optimization: Skipping build due to commit tag.');
    return false;
  }

  // Check if only non-code files were modified
  const isDocsOnly = modifiedFiles.every(file => 
    file.endsWith('.md') || file.endsWith('.txt') || file.endsWith('.mdx')
  );

  if (isDocsOnly) {
    console.log('Optimization: Skipping build due to docs-only changes.');
    return false;
  }

  return true;
};

/**
 * Determines the optimal runner type based on job complexity.
 * 
 * Why: GitHub-hosted minutes are billed per minute. Self-hosted runners
 * have fixed hardware costs but $0 per-minute billing on GitHub.
 * How: Route heavy AI jobs to self-hosted, standard builds to GitHub-hosted.
 */
const selectOptimalRunner = (jobType: 'build' | 'ai-review'): 'github-hosted' | 'self-hosted' => {
  if (jobType === 'ai-review') {
    // AI review is heavy and can run on cheaper, persistent hardware
    return 'self-hosted';
  }
  // Standard builds benefit from ephemeral, clean environments
  return 'github-hosted';
};

/**
 * Calculates the dynamic concurrency limit for the workflow.
 * 
 * Why: Prevents "noisy neighbor" jobs from queueing up and blocking
 * critical pipelines, or exceeding the organization's concurrent job limit.
 * How: Maps user tier to a hard limit.
 */
const getConcurrencyLimit = (config: UserConfig): number => {
  const limits: Record<SubscriptionTier, number> = {
    free: 1,    // Strictly limit free tier to prevent abuse
    pro: 3,     // Allow parallel testing
    enterprise: 10 // High throughput
  };
  return limits[config.tier];
};

// ==========================================
// 3. INTEGRATION & AI ANALYSIS (MOCKED)
// ==========================================

/**
 * Simulates an AI Code Review using a local model or API.
 * In a real scenario, this would be a heavy operation.
 * 
 * Context: This uses the "AI Chatbot Architecture" where logic is 
 * server-side. We use Pinecone (Namespaces) to cache results.
 */
const performAiCodeReview = async (payload: GitHubWebhookPayload, userConfig: UserConfig) => {
  const pc = new Pinecone({ apiKey: process.env.PINECONE_API_KEY! });
  const index = pc.Index('code-reviews');
  
  // Use Namespace to segregate user data efficiently
  const namespace = index.namespace(userConfig.pineconeNamespace);

  // Check cache first (Cost Optimization: Avoid redundant AI calls)
  const queryResult = await namespace.query({
    topK: 1,
    filter: { commitHash: payload.commits[0].message.substring(0, 8) },
    vector: new Array(1536).fill(0.1) // Mock embedding
  });

  if (queryResult.matches.length > 0) {
    return { cached: true, review: queryResult.matches[0].metadata?.review };
  }

  // Simulate LLM call (Expensive compute)
  const model = new HuggingFaceInference({ model: "gpt2", apiKey: process.env.HF_API_KEY });
  const review = await model.invoke(`Review this code: ${payload.commits[0].message}`);

  // Cache result for future (Cost Optimization: Reduce AI token usage)
  await namespace.upsert([
    {
      id: payload.commits[0].message.substring(0, 8),
      values: new Array(1536).fill(0.1),
      metadata: { review }
    }
  ]);

  return { cached: false, review };
};

// ==========================================
// 4. MAIN HANDLER (ORCHESTRATOR)
// ==========================================

/**
 * Main Route Handler.
 * 
 * Logic Flow:
 * 1. Validate User Config (Simulated DB fetch).
 * 2. Run Cost Checks (Conditional Execution).
 * 3. Select Runner (Resource Allocation).
 * 4. Set Concurrency (Throttling).
 * 5. Trigger Workflow (via GitHub API).
 */
export async function POST(request: Request) {
  const payload: GitHubWebhookPayload = await request.json();

  // Simulate fetching user config based on repo name
  const userConfig: UserConfig = {
    tier: 'pro', // Simulated 'pro' user
    maxConcurrency: 3,
    allowedRunners: ['github-hosted', 'self-hosted'],
    pineconeNamespace: 'user-proj-alpha' // Logical partition
  };

  // --- STEP 1: Conditional Execution ---
  if (!shouldRunBuild(payload)) {
    return NextResponse.json({ 
      status: 'skipped', 
      reason: 'Docs-only or skip-ci detected' 
    }, { status: 200 });
  }

  // --- STEP 2: Resource Allocation (Runner Selection) ---
  // We might run two jobs: 'build' and 'ai-review'
  const buildRunner = selectOptimalRunner('build');
  const aiRunner = selectOptimalRunner('ai-review');

  // --- STEP 3: Concurrency Throttling ---
  const concurrency = getConcurrencyLimit(userConfig);

  // --- STEP 4: AI Analysis (Server Side) ---
  // We perform this before triggering the workflow to decide if it's worth the cost
  const aiAnalysis = await performAiCodeReview(payload, userConfig);
  
  // If AI detects a critical error, we might abort the expensive build
  if (aiAnalysis.review && aiAnalysis.review.includes('critical error')) {
    return NextResponse.json({ 
      status: 'aborted', 
      reason: 'AI detected critical error in commit', 
      analysis: aiAnalysis 
    }, { status: 200 });
  }

  // --- STEP 5: Construct GitHub Workflow Dispatch Payload ---
  // This is where we inject the optimization parameters into the workflow file
  const workflowPayload = {
    ref: 'main',
    inputs: {
      should_run_tests: 'true', // Derived from shouldRunBuild
      runner_type_build: buildRunner,
      runner_type_ai: aiRunner
    },
    // GitHub API property to limit concurrent runs for this workflow
    concurrency: {
      group: `${payload.repository.name}-${userConfig.tier}`,
      cancel_in_progress: false
    }
  };

  // Mocking the actual GitHub API call
  // await fetch(`https://api.github.com/repos/${payload.repository.name}/actions/workflows/ci.yml/dispatches`, {
  //   method: 'POST',
  //   headers: { 'Authorization': `token ${process.env.GITHUB_TOKEN}` },
  //   body: JSON.stringify(workflowPayload)
  // });

  return NextResponse.json({
    status: 'triggered',
    optimizations: {
      conditional_execution: true,
      runner_selection: { build: buildRunner, ai: aiRunner },
      concurrency_limit: concurrency,
      ai_caching: aiAnalysis.cached
    },
    cost_savings_estimate: 'Approx 40% reduction in billable minutes'
  });
}
