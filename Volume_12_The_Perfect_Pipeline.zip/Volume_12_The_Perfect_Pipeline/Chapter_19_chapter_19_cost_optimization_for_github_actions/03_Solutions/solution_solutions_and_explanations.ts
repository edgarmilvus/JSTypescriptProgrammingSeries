/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

name: Optimized CI
on:
  push:
    branches: [ main ]
  pull_request:
    branches: [ main ]

# 1. Concurrency Control: Cancel in-progress runs on the same branch
# to save minutes on stale commits.
concurrency:
  group: ${{ github.workflow }}-${{ github.ref }}
  cancel-in-progress: true

jobs:
  # Optimization: The build job is CPU-intensive. While 'ubuntu-latest' is 
  # the cheapest GitHub-hosted runner, for heavy builds, consider larger runners 
  # if speed reduces total queue time, but here we stick to standard for cost.
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - run: npm ci
      - run: npm run build
      # Optimization: Upload artifacts only if needed by downstream jobs.
      # Since 'test' runs on the same runner, we might skip artifact upload 
      # if tests run directly from the build folder. 
      # However, if 'e2e-test' needs it, we upload here.
      - uses: actions/upload-artifact@v4
        with:
          name: build-output
          path: ./dist

  test:
    runs-on: ubuntu-latest
    needs: build
    steps:
      - uses: actions/checkout@v4
      - uses: actions/download-artifact@v4
        with:
          name: build-output
      - run: npm ci
      - run: npm test

  e2e-test:
    # Optimization: macOS is expensive. We only run this on the main branch 
    # or specific PRs to avoid burning minutes on every commit.
    # Note: The requirement says it depends on 'test', so we keep the dependency.
    runs-on: macos-latest
    needs: test
    if: github.event_name == 'push' || contains(github.event.head_commit.message, '[e2e]') 
    # ^ Conditional to avoid running expensive macOS on every PR unless tagged
    steps:
      - uses: actions/checkout@v4
      - run: npm run e2e

  deploy:
    # Optimization: 'deploy' can run on Linux (cheapest). 
    # We do not need Windows for a simple echo.
    runs-on: ubuntu-latest
    needs: e2e-test
    # 3. Conditional Execution: Only run on push to main AND if e2e-test succeeded.
    # 'needs.e2e-test.result' ensures we don't deploy if e2e failed.
    if: ${{ needs.e2e-test.result == 'success' && github.ref == 'refs/heads/main' && github.event_name == 'push' }}
    steps:
      - run: echo "Deploying to production..."
