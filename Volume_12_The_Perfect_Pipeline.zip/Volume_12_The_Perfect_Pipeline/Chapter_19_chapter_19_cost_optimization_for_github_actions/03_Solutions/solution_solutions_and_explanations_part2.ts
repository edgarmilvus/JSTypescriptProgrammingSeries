/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

import * as core from '@actions/core';
import * as cache from '@actions/cache';
import * as crypto from 'crypto';
import * as fs from 'fs';
import * as path from 'path';

// 1. Cache Key Strategy: 
// Format: {os}-npm-{hash of package-lock.json}-{version}
// Using the lockfile hash ensures the cache is invalidated exactly when dependencies change.
async function generateCacheKey(): Promise<string> {
  const lockfilePath = path.join(process.cwd(), 'package-lock.json');
  let hash = 'default';
  
  if (fs.existsSync(lockfilePath)) {
    const fileBuffer = fs.readFileSync(lockfilePath);
    hash = crypto.createHash('sha256').update(fileBuffer).digest('hex').substring(0, 8);
  }
  
  const runnerOS = process.env.RUNNER_OS || 'Linux';
  return `${runnerOS}-npm-${hash}-v1`;
}

// 2. Implement Caching: Check for hit, restore, or save.
export async function restoreOrSaveCache() {
  const primaryKey = await generateCacheKey();
  const cachePaths = ['node_modules'];
  
  try {
    // Restore cache based on the specific lockfile hash
    const cacheKey = await cache.restoreCache(cachePaths, primaryKey, []);
    
    if (cacheKey) {
      core.info(`Cache hit! Key: ${cacheKey}`);
      // In a real workflow, we might set an output to skip 'npm ci'
      core.setOutput('cache-hit', 'true');
    } else {
      core.info(`Cache miss. Running 'npm ci'.`);
      // Run npm ci (pseudo-code for context)
      // await exec.exec('npm', ['ci']);
      
      // Save the cache for future runs
      // Note: We save using the PRIME key only if it wasn't found.
      core.info(`Saving cache with key: ${primaryKey}`);
      await cache.saveCache(cachePaths, primaryKey);
      core.setOutput('cache-hit', 'false');
    }
  } catch (error) {
    core.warning(`Cache operation failed: ${error}`);
  }
}

// 3. Post-Job Cleanup Logic (Pseudocode/Concept)
// This logic would typically run in a separate cleanup job or workflow.
// It queries the API for active branches/tags and deletes caches not associated with them.

interface CacheObject {
  id: number;
  key: string;
  ref: string; // e.g., refs/heads/main
  last_accessed_at: string;
}

async function cleanupOldCaches() {
  // 1. Fetch all caches for the repo (using GitHub REST API)
  // const caches: CacheObject[] = await api.get('/repos/owner/repo/actions/caches');
  
  // 2. Fetch active branches and tags
  // const activeRefs = await getActiveBranchesAndTags(); 

  // 3. Filter caches
  // const cachesToDelete = caches.filter(cache => {
  //   // Check if cache ref is still active
  //   const isRefActive = activeRefs.includes(cache.ref);
  //   // Check if cache is older than X days (e.g., 7 days)
  //   const isOld = new Date(cache.last_accessed_at) < new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);
  //   
  //   // Delete if ref is inactive OR if it's very old (even if active, to prevent bloat)
  //   return !isRefActive || isOld;
  // });

  // 4. Execute deletion
  // for (const cache of cachesToDelete) {
  //   await api.delete(`/repos/owner/repo/actions/caches/${cache.id}`);
  // }
}

// Mock execution for the exercise
(async () => {
  await restoreOrSaveCache();
})();
