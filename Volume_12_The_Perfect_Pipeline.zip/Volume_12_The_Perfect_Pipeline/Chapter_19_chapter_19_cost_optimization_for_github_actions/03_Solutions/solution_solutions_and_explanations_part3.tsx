/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

// CostMonitorChart.tsx
import React, { Suspense } from 'react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, CartesianGrid } from 'recharts';

// 1. Type Safety: Interfaces for GitHub API and Internal State
interface WorkflowRun {
  id: number;
  name: string;
  run_started_at: string;
  // Hypothetical billable seconds property from GitHub API
  billable: {
    ubuntu: { total_ms: number };
    macos: { total_ms: number };
  };
}

interface CostData {
  jobName: string;
  minutes: number;
}

// 2. Component Architecture: React Server Component accepting a Promise
type Props = {
  dataPromise: Promise<WorkflowRun[]>;
};

// Helper to convert ms to minutes
const msToMinutes = (ms: number) => Math.round(ms / 60000);

// 3. Streaming UI Implementation & Web Worker Logic
export default async function CostMonitorChart({ dataPromise }: Props) {
  // Await the data (Server Component pattern)
  const runs = await dataPromise;

  // --- Web Worker & SharedArrayBuffer Logic (Conceptual) ---
  // In a real Client Component, we would offload this calculation.
  // Since this is an RSC, we do the calculation on the server, but 
  // here is how we would handle the SharedArrayBuffer requirement in a client context:
  
  /*
    // MAIN THREAD (Client)
    const sharedBuffer = new SharedArrayBuffer(runs.length * Int32Array.BYTES_PER_ELEMENT);
    const worker = new Worker(new URL('./costWorker.ts', import.meta.url));
    worker.postMessage({ buffer: sharedBuffer, data: runs });

    // WORKER THREAD (costWorker.ts)
    self.onmessage = (e) => {
      const { buffer, data } = e.data;
      const arr = new Int32Array(buffer);
      // Perform heavy calculation (e.g., summing minutes)
      const total = data.reduce((acc, curr) => acc + msToMinutes(curr.billable.ubuntu.total_ms), 0);
      Atomics.store(arr, 0, total); // Store result in shared memory
    };
  */

  // 4. Data Transformation (Simulating the Worker's output)
  const chartData: CostData[] = runs.map((run) => ({
    jobName: run.name || `Run ${run.id}`,
    minutes: msToMinutes(run.billable.ubuntu.total_ms + run.billable.macos.total_ms),
  }));

  // Skeleton Loader Simulation (Visual aid for streaming)
  // In a real streaming setup, we would use `streamUI` to render chunks.
  // Here, we render the chart directly after awaiting data.
  
  return (
    <div style={{ padding: '20px', fontFamily: 'sans-serif' }}>
      <h2>Billable Minutes (Last 24h)</h2>
      <Suspense fallback={<div>Loading Chart Data...</div>}>
        <BarChart width={600} height={300} data={chartData}>
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis dataKey="jobName" />
          <YAxis label={{ value: 'Minutes', angle: -90, position: 'insideLeft' }} />
          <Tooltip />
          <Bar dataKey="minutes" fill="#8884d8" />
        </BarChart>
      </Suspense>
    </div>
  );
}
