/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

// TokenSimulator.ts

// Configuration
const PRICING = {
  INPUT_PER_1K: 0.002, // $ per 1000 tokens
  OUTPUT_PER_1K: 0.004, // $ per 1000 tokens
};

const OUTPUT_RATIO = 0.15; // Output is 15% of input size

/**
 * 2. Token Estimation
 * Approximates tokens based on character count. 
 * A common heuristic is 4 chars per token, but we add a buffer for word boundaries.
 */
export function estimateTokens(text: string): number {
  // Normalize whitespace
  const normalized = text.replace(/\s+/g, ' ');
  
  // Heuristic: 1 token ≈ 4 characters
  const charCount = normalized.length;
  let tokenCount = Math.ceil(charCount / 4);
  
  // Adjust for word boundaries (add ~10% for separators)
  tokenCount = Math.ceil(tokenCount * 1.1);
  
  return tokenCount;
}

/**
 * 3. Cost Calculation & 4. Optimization Logic
 */
export function runSimulation(diff: string, budget: number = 0.50) {
  const inputTokens = estimateTokens(diff);
  const outputTokens = Math.ceil(inputTokens * OUTPUT_RATIO);
  
  const inputCost = (inputTokens / 1000) * PRICING.INPUT_PER_1K;
  const outputCost = (outputTokens / 1000) * PRICING.OUTPUT_PER_1K;
  const totalCost = inputCost + outputCost;
  
  const isOverBudget = totalCost > budget;
  
  return {
    inputTokens,
    outputTokens,
    totalCost: Number(totalCost.toFixed(4)),
    budgetLimit: budget,
    isOverBudget,
    suggestion: isOverBudget 
      ? `Warning: Estimated cost $${totalCost.toFixed(4)} exceeds budget $${budget}. Suggest splitting the PR.` 
      : "Cost is within budget.",
  };
}

// --- Example Usage ---

// 5. Interactive Element: Sample Diff
const sampleDiff = `
diff --git a/src/components/App.tsx b/src/components/App.tsx
index 123456..7890ab 100644
--- a/src/components/App.tsx
+++ b/src/components/App.tsx
@@ -10,6 +10,8 @@ import { Header } from './Header';
 export const App = () => {
   const [count, setCount] = useState(0);
 
+  // Added expensive calculation
+  console.log('Expensive log triggered');
   return (
     <div>
       <Header />
`;

// Execute simulation
const result = runSimulation(sampleDiff, 0.50);

console.log("--- AI Code Review Cost Simulation ---");
console.log(`Input Tokens: ${result.inputTokens}`);
console.log(`Output Tokens: ${result.outputTokens}`);
console.log(`Estimated Cost: $${result.totalCost}`);
console.log(`Budget: $${result.budgetLimit}`);
console.log(`Status: ${result.isOverBudget ? 'EXCEEDED' : 'OK'}`);
console.log(`Recommendation: ${result.suggestion}`);
