/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

name: Conditional Docker CI

on:
  push:
    branches:
      - main
    # 2. Path Filtering: Ignore workflow if ONLY docs/markdown files change
    paths-ignore:
      - '**.md'
      - 'docs/**'
      - 'README.md'

jobs:
  # 3. Job-Level Conditional Check
  # Even if the workflow triggers (e.g., mixed code and docs changes), 
  # we check if we can skip the heavy build.
  detect-changes:
    runs-on: ubuntu-latest
    outputs:
      should-build: ${{ steps.filter.outputs.should-build }}
    steps:
      - uses: actions/checkout@v4
        with:
          fetch-depth: 0 # Required to diff against previous commit
      - name: Check for non-doc changes
        id: filter
        run: |
          # Get list of changed files
          CHANGED_FILES=$(git diff --name-only HEAD^ HEAD)
          
          # Check if any file is NOT a markdown or docs file
          if echo "$CHANGED_FILES" | grep -qvE '\.md$|docs/'; then
            echo "should-build=true" >> $GITHUB_OUTPUT
            echo "Code changes detected. Proceeding with build."
          else
            echo "should-build=false" >> $GITHUB_OUTPUT
            echo "Only documentation changes detected. Skipping build."
          fi

  build:
    needs: detect-changes
    # Only run if changes are detected
    if: ${{ needs.detect-changes.outputs.should-build == 'true' }}
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - name: Build Docker Image
        run: |
          echo "Building Docker Image..."
          # docker build -t my-app:latest .
      - name: Save Artifact
        run: echo "IMAGE_BUILT=true" >> build.env

  test:
    needs: build
    # Implicitly skips if build skips
    runs-on: ubuntu-latest
    steps:
      - run: echo "Running Integration Tests..."

  deploy:
    needs: [build, test]
    runs-on: ubuntu-latest
    # 4. Artifact Handling: Check if build actually happened
    if: ${{ needs.build.result == 'success' || needs.build.result == 'skipped' }}
    steps:
      - name: Deploy Logic
        run: |
          if [ "${{ needs.build.result }}" == "skipped" ]; then
            echo "Build was skipped. Deploying last known good image from registry..."
          else
            echo "Deploying newly built image..."
          fi
