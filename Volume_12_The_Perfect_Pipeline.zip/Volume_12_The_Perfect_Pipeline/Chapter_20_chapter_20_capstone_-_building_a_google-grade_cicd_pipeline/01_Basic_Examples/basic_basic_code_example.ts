/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * @fileoverview A basic simulation of an AI-assisted code review pipeline step.
 * This script validates a code change against strict quality standards.
 * 
 * @requires fs - Node.js file system module (simulated here via mock)
 * @requires path - Node.js path module (simulated here via mock)
 */

// ==========================================
// 1. Type Definitions & Strict Type Discipline
// ==========================================

/**
 * Represents the metadata of a code change submitted to the SaaS platform.
 * We enforce strict typing here to prevent undefined data at runtime.
 */
interface CodeChange {
  id: string;
  filePath: string;
  content: string;
  author: string;
}

/**
 * Represents the output of the AI analysis.
 * Discriminated unions are used here to handle success/failure states explicitly.
 */
type AIReviewResult = 
  | { status: 'APPROVED'; score: number; comments: string[] }
  | { status: 'REJECTED'; reason: string; score: number };

// ==========================================
// 2. Mock AI Analysis Engine
// ==========================================

/**
 * Simulates an AI engine (like GitHub Copilot or a custom LLM) that reviews code.
 * In a real-world scenario, this would involve API calls to an LLM or WASM-based local models.
 * 
 * @param change - The code change object
 * @returns A promise resolving to the AI review result
 */
async function runAIReview(change: CodeChange): Promise<AIReviewResult> {
  // Simulate processing delay (Warm Start simulation)
  await new Promise(resolve => setTimeout(resolve, 100));

  // Basic heuristic rules for the "AI" to check
  const hasConsoleLog = change.content.includes('console.log');
  const hasAnyType = change.content.includes('any');
  const hasNullCheck = change.content.includes('== null') || change.content.includes('!= null');

  let score = 100;

  // Penalize bad practices
  if (hasConsoleLog) score -= 20;
  if (hasAnyType) score -= 30;
  
  // Reward strict null checks (TypeScript best practice)
  if (hasNullCheck) score += 10;

  if (score >= 80) {
    return {
      status: 'APPROVED',
      score,
      comments: ['Code structure looks solid.', 'Good use of explicit checks.']
    };
  } else {
    return {
      status: 'REJECTED',
      score,
      reason: 'Code violates strict type discipline or contains logging artifacts.'
    };
  }
}

// ==========================================
// 3. Pipeline Orchestrator
// ==========================================

/**
 * Orchestrates the CI/CD pipeline step.
 * Handles the flow from input validation to AI review and final decision.
 * 
 * @param input - The raw code change data
 * @returns void (logs output to console)
 */
async function pipelineOrchestrator(input: unknown): Promise<void> {
  // -------------------------------------------------------
  // Step 3.1: Input Validation (Strict Type Discipline)
  // -------------------------------------------------------
  // We never trust external input. We validate against the interface.
  if (!input || typeof input !== 'object') {
    console.error('❌ Pipeline Error: Invalid input format.');
    return;
  }

  const change = input as CodeChange; // Type assertion after basic check

  // Deep validation to ensure all fields exist (preventing runtime errors)
  if (!change.id || !change.filePath || !change.content) {
    console.error('❌ Pipeline Error: Missing required fields in CodeChange.');
    return;
  }

  // -------------------------------------------------------
  // Step 3.2: Execute AI Review
  // -------------------------------------------------------
  console.log(`🔍 Analyzing Change ID: ${change.id}...`);
  
  try {
    const review = await runAIReview(change);

    // -------------------------------------------------------
    // Step 3.3: Handle Result (Discriminated Union Logic)
    // -------------------------------------------------------
    if (review.status === 'APPROVED') {
      console.log(`✅ APPROVED (Score: ${review.score})`);
      review.comments.forEach(c => console.log(`   - ${c}`));
      // In a real pipeline: Trigger build & deploy
    } else {
      console.log(`❌ REJECTED (Score: ${review.score})`);
      console.log(`   Reason: ${review.reason}`);
      // In a real pipeline: Block merge request, notify author
      process.exit(1); // Fail the CI step
    }
  } catch (error) {
    console.error('💥 Pipeline Critical Failure:', error);
    process.exit(1);
  }
}

// ==========================================
// 4. Execution (Simulating a Webhook Trigger)
// ==========================================

/**
 * Simulates a webhook event from a Git provider (e.g., GitHub Pull Request).
 */
const mockWebhookPayload: CodeChange = {
  id: 'pr-1024',
  filePath: 'src/utils/validation.ts',
  author: 'dev@example.com',
  content: `
    function validate(input: unknown) {
      // Bad practice: Implicit any
      const val: any = input;
      if (val == null) return false; // Good practice: explicit null check
      return true;
    }
  `
};

// Run the pipeline
console.log('🚀 Starting CI/CD Pipeline (Simulated)...');
pipelineOrchestrator(mockWebhookPayload);
