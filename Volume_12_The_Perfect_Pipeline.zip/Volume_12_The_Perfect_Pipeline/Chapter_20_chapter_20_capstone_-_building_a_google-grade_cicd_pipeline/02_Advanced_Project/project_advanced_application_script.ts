/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

/**
 * @fileoverview Smart Code Review Service for Next.js API Routes.
 * This script implements an AI-driven code quality gate that integrates into a CI/CD pipeline.
 * It utilizes a local LLM (via Ollama) to perform semantic analysis on code diffs.
 * 
 * Key Concepts Implemented:
 * 1. JSON Schema Output: Enforcing structured responses from the LLM.
 * 2. V8 Engine Optimization: Efficient string parsing and async execution.
 * 3. Warm Start Strategy: Assumes the model is pre-loaded to minimize inference latency.
 */

import { NextApiRequest, NextApiResponse } from 'next';

// -----------------------------------------------------------------------------
// 1. TYPE DEFINITIONS & SCHEMA CONFIGURATION
// -----------------------------------------------------------------------------

/**
 * Represents the structured output expected from the AI model.
 * This strict typing ensures the CI/CD pipeline can reliably make decisions.
 */
export type CodeReviewResult = {
  score: number; // 0-100
  verdict: 'APPROVED' | 'REJECTED' | 'NEEDS_HUMAN_REVIEW';
  reasoning: string;
  findings: Array<{
    line?: number;
    severity: 'CRITICAL' | 'WARNING' | 'INFO';
    message: string;
  }>;
};

/**
 * The JSON Schema definition used to prompt the LLM.
 * This is the "instruction manual" for the AI to format its output correctly.
 */
const JSON_SCHEMA_PROMPT = {
  type: "object",
  properties: {
    score: { type: "number", "minimum": 0, "maximum": 100 },
    verdict: { type: "string", "enum": ["APPROVED", "REJECTED", "NEEDS_HUMAN_REVIEW"] },
    reasoning: { type: "string" },
    findings: {
      type: "array",
      items: {
        type: "object",
        properties: {
          line: { type: "number" },
          severity: { type: "string", "enum": ["CRITICAL", "WARNING", "INFO"] },
          message: { type: "string" }
        },
        required: ["severity", "message"]
      }
    }
  },
  required: ["score", "verdict", "reasoning"]
};

// -----------------------------------------------------------------------------
// 2. CORE LOGIC: THE AI INFERENCE CLIENT
// -----------------------------------------------------------------------------

/**
 * Communicates with the local Ollama instance to perform the inference.
 * 
 * Under the Hood:
 * - We use `fetch` to hit the Ollama API.
 * - `keep_alive: '5m'` is a Warm Start optimization. It keeps the model loaded in VRAM/RAM
 *   for 5 minutes after this request, preventing cold-start penalties on subsequent calls.
 * - `format: 'json'` signals the API to attempt valid JSON formatting (though we validate it).
 */
async function queryLocalAI(diffContent: string): Promise<CodeReviewResult> {
  const OLLAMA_ENDPOINT = process.env.OLLAMA_ENDPOINT || 'http://localhost:11434/api/generate';
  const MODEL = 'codellama:7b-instruct-q4_0'; // A lightweight model suitable for local CI

  const prompt = `
    You are a Senior Staff Engineer. Review the following code diff.
    Focus on security, logic errors, and best practices.
    Return ONLY a raw JSON object matching this schema: ${JSON.stringify(JSON_SCHEMA_PROMPT)}.
    
    Code Diff:
    ${diffContent}
  `;

  try {
    const response = await fetch(OLLAMA_ENDPOINT, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model: MODEL,
        prompt: prompt,
        stream: false,
        format: "json", // Hint to the model to output JSON
        options: {
          temperature: 0.1, // Low temp for deterministic logic
          num_ctx: 2048,    // Context window size
        },
        keep_alive: '5m' // Warm Start optimization
      })
    });

    if (!response.ok) {
      throw new Error(`AI Service Error: ${response.statusText}`);
    }

    const data = await response.json();
    
    // The model often wraps the JSON in newlines or text. We need to extract it.
    // This regex looks for the first '{' to the last '}'.
    const jsonMatch = data.response.match(/\{[\s\S]*\}/);
    
    if (!jsonMatch) {
      throw new Error("Failed to extract JSON from AI response.");
    }

    // Strict validation using Zod or manual parsing would happen here.
    // For this example, we cast it, but in production, use Zod.
    const result: CodeReviewResult = JSON.parse(jsonMatch[0]);
    return result;

  } catch (error) {
    console.error("AI Inference failed:", error);
    // Fallback result if AI is down
    return {
      score: 0,
      verdict: 'NEEDS_HUMAN_REVIEW',
      reasoning: 'AI Service Unavailable',
      findings: []
    };
  }
}

// -----------------------------------------------------------------------------
// 3. NEXT.JS API ROUTE HANDLER
// -----------------------------------------------------------------------------

/**
 * The API Route exposed to the GitHub Actions workflow.
 * 
 * @param req - The HTTP request containing the code diff.
 * @param res - The HTTP response containing the review verdict.
 */
export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  // 1. Security: Validate Request Method
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method Not Allowed' });
  }

  // 2. Input Validation: Ensure we have code to review
  const { diff } = req.body;
  if (!diff || typeof diff !== 'string' || diff.length < 10) {
    return res.status(400).json({ error: 'Invalid or empty diff provided.' });
  }

  // 3. Execution: Run the AI Review
  try {
    // In a real pipeline, we might add a timeout here to prevent hanging
    const reviewResult = await queryLocalAI(diff);

    // 4. Decision Logic
    // If the score is low or critical issues are found, we block the pipeline.
    if (reviewResult.verdict === 'REJECTED' || reviewResult.score < 60) {
      return res.status(400).json({
        status: 'blocked',
        data: reviewResult
      });
    }

    // 5. Success Response
    return res.status(200).json({
      status: 'passed',
      data: reviewResult
    });

  } catch (error) {
    // 6. Error Handling
    // In CI/CD, an exception in the quality gate usually defaults to 'safe' (block)
    // to prevent unanalyzed code from slipping through.
    console.error(error);
    return res.status(500).json({
      status: 'error',
      message: 'Internal Review Error',
      verdict: 'NEEDS_HUMAN_REVIEW' 
    });
  }
}
