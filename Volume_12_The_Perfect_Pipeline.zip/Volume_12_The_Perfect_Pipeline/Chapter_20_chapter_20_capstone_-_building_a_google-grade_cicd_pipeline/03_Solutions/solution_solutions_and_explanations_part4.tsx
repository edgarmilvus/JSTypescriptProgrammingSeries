/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.tsx
// Description: Solutions and Explanations
// ==========================================

// File: types.ts (Schema Definition)
export const CodeReviewSchema = {
  type: "object",
  properties: {
    score: { type: "number", minimum: 0.0, maximum: 10.0 },
    summary: { type: "string" },
    issues: {
      type: "array",
      items: {
        type: "object",
        properties: {
          severity: { type: "string", enum: ["low", "medium", "high", "critical"] },
          line: { type: "integer" },
          message: { type: "string" }
        },
        required: ["severity", "line", "message"]
      }
    }
  },
  required: ["score", "summary", "issues"]
};

// File: CodeReviewFeedback.tsx (React Component)
import React from 'react';

// Mock validation function (replacing Zod for simplicity in this snippet)
const validateData = (data: any): boolean => {
  // In a real app, use Zod: const parsed = CodeReviewSchema.parse(data);
  return data && typeof data.score === 'number' && Array.isArray(data.issues);
};

export const CodeReviewFeedback = ({ reviewData }: { reviewData: any }) => {
  if (!validateData(reviewData)) {
    return <div style={{ color: 'red', border: '1px solid red', padding: '10px' }}>Error: Invalid Review Data</div>;
  }

  const getSeverityColor = (severity: string) => {
    if (severity === 'critical' || severity === 'high') return '#ff4d4f'; // Red
    if (severity === 'medium') return '#faad14'; // Yellow
    return '#d9d9d9'; // Gray
  };

  return (
    <div style={{ fontFamily: 'sans-serif', maxWidth: '600px' }}>
      <h2>AI Code Review</h2>
      <div style={{ fontSize: '2rem', fontWeight: 'bold', marginBottom: '1rem' }}>
        Score: {reviewData.score}/10.0
      </div>
      <p><strong>Summary:</strong> {reviewData.summary}</p>
      
      <h3>Issues:</h3>
      {reviewData.issues.map((issue: any, index: number) => (
        <div key={index} style={{ 
          border: `2px solid ${getSeverityColor(issue.severity)}`, 
          padding: '10px', 
          marginBottom: '10px',
          borderRadius: '5px'
        }}>
          <div style={{ fontWeight: 'bold', color: getSeverityColor(issue.severity) }}>
            {issue.severity.toUpperCase()} (Line {issue.line})
          </div>
          <div>{issue.message}</div>
        </div>
      ))}
    </div>
  );
};

// File: promptGenerator.ts
export function generatePrompt(diff: string): string {
  const fewShotExample = `
  Example Input:
  function add(a, b) { return a + b; }
  
  Expected JSON Output:
  {
    "score": 8.5,
    "summary": "Good logic, but lacks type safety.",
    "issues": [
      { "severity": "medium", "line": 1, "message": "Missing TypeScript types for parameters." }
    ]
  }
  `;

  return `
  You are an expert code reviewer. Analyze the following code diff for bugs and style issues.
  
  Code Diff:
  \`\`\`diff
  ${diff}
  \`\`\`

  Instructions:
  1. Analyze the code.
  2. Respond strictly with a JSON object matching this schema: ${JSON.stringify(CodeReviewSchema)}.
  3. Do not include any text outside the JSON object.

  ${fewShotExample}
  `;
}
