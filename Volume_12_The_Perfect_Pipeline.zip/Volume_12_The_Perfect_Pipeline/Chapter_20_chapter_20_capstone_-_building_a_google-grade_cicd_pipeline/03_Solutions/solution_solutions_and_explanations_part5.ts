/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

// File: LocalAIManager.ts

class LocalAIManager {
  private static instance: LocalAIManager;
  
  // Simulating the loaded model state
  private modelLoaded: boolean = false;
  
  // Private constructor to enforce Singleton pattern
  private constructor() {}

  public static getInstance(): LocalAIManager {
    if (!LocalAIManager.instance) {
      LocalAIManager.instance = new LocalAIManager();
    }
    return LocalAIManager.instance;
  }

  // Simulates heavy weight loading
  private async loadModel(): Promise<void> {
    console.log("⏳ [Cold Start] Loading model weights into memory...");
    return new Promise((resolve) => {
      setTimeout(() => {
        this.modelLoaded = true;
        console.log("✅ Model loaded.");
        resolve();
      }, 2000); // 2 second delay
    });
  }

  // Simulates inference generation
  private async generateResponse(prompt: string): Promise<string> {
    return new Promise((resolve) => {
      setTimeout(() => {
        resolve(`AI Response to "${prompt}": This is a generated output.`);
      }, 500); // 0.5 second delay
    });
  }

  // Public interface
  public async infer(prompt: string): Promise<string> {
    if (!this.modelLoaded) {
      await this.loadModel();
    }
    
    console.log(`🚀 Running inference for: "${prompt}"`);
    return this.generateResponse(prompt);
  }
}

// --- Simulation Script ---
async function runSimulation() {
  const aiManager = LocalAIManager.getInstance();

  console.log("--- Session Start ---");

  // 1. Cold Start
  const start1 = Date.now();
  const response1 = await aiManager.infer("Hello World");
  const end1 = Date.now();
  console.log(response1);
  console.log(`⏱️ Cold Start Duration: ${end1 - start1}ms`);

  console.log("\n---\n");

  // 2. Warm Start
  const start2 = Date.now();
  const response2 = await aiManager.infer("Hello Again");
  const end2 = Date.now();
  console.log(response2);
  console.log(`⏱️ Warm Start Duration: ${end2 - start2}ms`);
}

runSimulation();
