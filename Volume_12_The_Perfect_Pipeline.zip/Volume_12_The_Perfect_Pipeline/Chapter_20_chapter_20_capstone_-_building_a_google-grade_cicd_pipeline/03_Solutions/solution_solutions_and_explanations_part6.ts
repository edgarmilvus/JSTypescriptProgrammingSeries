/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part6.ts
// Description: Solutions and Explanations
// ==========================================

# File: .github/workflows/monorepo-ci.yml
name: Monorepo Orchestration

on:
  push:
    paths:
      - 'frontend/**'
      - 'backend/**'

jobs:
  # Job 1: Build the Backend
  build-backend:
    runs-on: ubuntu-latest
    # Only run if backend files changed
    if: contains(github.event.commits[0].modified, 'backend/')
    steps:
      - uses: actions/checkout@v4
      
      - name: Setup Node
        uses: actions/setup-node@v4
        with: { node-version: '20' }

      - name: Build Backend
        run: |
          echo "Building backend..."
          mkdir -p dist/backend
          echo "backend-artifact-content" > dist/backend/api-schema.json
          # In reality: npm ci && npm run build

      - name: Upload Backend Artifact
        uses: actions/upload-artifact@v4
        with:
          name: backend-dist
          path: dist/backend/

  # Job 2: Build the Frontend (Depends on Backend)
  build-frontend:
    runs-on: ubuntu-latest
    needs: build-backend
    steps:
      - uses: actions/checkout@v4

      - name: Setup Node
        uses: actions/setup-node@v4
        with: { node-version: '20' }

      - name: Download Backend Artifact
        uses: actions/download-artifact@v4
        with:
          name: backend-dist
          path: backend-artifacts/

      - name: Build Frontend
        run: |
          echo "Checking for backend artifacts..."
          ls -R backend-artifacts
          echo "Building frontend consuming backend schemas..."
          # In reality: npm ci && npm run build
