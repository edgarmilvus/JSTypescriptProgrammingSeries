/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: theory_theoretical_foundations.ts
// Description: Theoretical Foundations
// ==========================================

digraph KubernetesArchitecture {
    rankdir=TB;
    node [shape=box, style=rounded];

    subgraph cluster_control {
        label = "Control Plane (The Brain)";
        color = blue;
        style = dashed;

        API [label="API Server\n(Receptionist)"];
        Scheduler [label="Scheduler\n(Logistics)"];
        ControllerManager [label="Controller Manager\n(Overseers)"];
    }

    subgraph cluster_nodes {
        label = "Worker Nodes (The Muscle)";
        color = green;
        style = dashed;

        Node1 [label="Node 1"];
        Node2 [label="Node 2"];

        Kubelet1 [label="Kubelet\n(Supervisor)"];
        Kubelet2 [label="Kubelet\n(Supervisor)"];
        
        Proxy1 [label="Kube-proxy\n(Traffic Cop)"];
        Proxy2 [label="Kube-proxy\n(Traffic Cop)"];
    }

    // Connections
    User -> API [label="1. Request (YAML)"];
    API -> Scheduler [label="2. Watch for unassigned Pods"];
    Scheduler -> API [label="3. Bind Pod to Node"];
    API -> ControllerManager [label="4. Watch desired state"];
    
    API -> Node1 [label="5. Pull Pod Spec"];
    API -> Node2 [label="5. Pull Pod Spec"];

    Node1 -> Kubelet1 [label="6. Manage Local Containers"];
    Node2 -> Kubelet2 [label="6. Manage Local Containers"];

    Kubelet1 -> API [label="7. Report Status (Heartbeats)"];
    Kubelet2 -> API [label="7. Report Status (Heartbeats)"];

    // Networking
    Node1 -> Proxy1 [label="8. Enforce Network Rules"];
    Node2 -> Proxy2 [label="8. Enforce Network Rules"];
}
