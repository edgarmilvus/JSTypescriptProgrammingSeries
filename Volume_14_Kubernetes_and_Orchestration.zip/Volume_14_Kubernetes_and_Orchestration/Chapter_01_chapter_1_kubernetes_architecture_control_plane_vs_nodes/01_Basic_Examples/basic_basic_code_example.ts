/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * KUBERNETES CONTROL PLANE SIMULATION
 * 
 * This script demonstrates the reconciliation loop of a Kubernetes Control Plane.
 * It simulates the interaction between a Desired State (YAML config) and the 
 * Actual State (running pods), managed by a Controller.
 */

// --- 1. Type Definitions ---

/**
 * Represents the state of a single Pod (container instance).
 * In a real cluster, this would be complex metadata; here we simplify to status.
 */
interface Pod {
  id: string;
  status: "Pending" | "Running" | "Terminating";
}

/**
 * The "Graph State". This is the singular data structure passed through our 
 * LangGraph-style execution nodes. It represents the snapshot of the system 
 * at a specific moment in time.
 */
interface ClusterState {
  desiredReplicas: number; // The configuration (e.g., from a Deployment YAML)
  actualPods: Pod[];       // The observed reality from the API Server
  logs: string[];          // A running log of reconciliation actions
}

// --- 2. Initial State (The "API Server" Snapshot) ---

/**
 * Simulates fetching the current state from the Kubernetes API Server.
 * 
 * Scenario: We have a Deployment for a Node.js API requiring 3 replicas.
 * Currently, only 2 are running (one crashed or is being created).
 */
const initialClusterState: ClusterState = {
  desiredReplicas: 3,
  actualPods: [
    { id: "node-api-abc", status: "Running" },
    { id: "node-api-xyz", status: "Running" },
    // The 3rd pod is missing, simulating a drift from desired state
  ],
  logs: ["[INFO] Initial state fetched from API Server."],
};

// --- 3. The Logic Nodes (The "Controller Manager" Logic) ---

/**
 * Node 1: Observe & Calculate Gap
 * 
 * This node calculates the difference between the desired state and the actual state.
 * It determines if we need to scale up or down.
 */
function calculateDiscrepancy(state: ClusterState): ClusterState {
  const currentReplicas = state.actualPods.filter(
    (p) => p.status !== "Terminating"
  ).length;
  const discrepancy = state.desiredReplicas - currentReplicas;

  const updatedLogs = [
    ...state.logs,
    `[CONTROLLER] Observed ${currentReplicas} replicas. Desired: ${state.desiredReplicas}. Discrepancy: ${discrepancy}.`,
  ];

  return {
    ...state,
    logs: updatedLogs,
  };
}

/**
 * Node 2: Reconcile (Scale Up)
 * 
 * If the discrepancy is positive (we need more pods), this node creates new Pod objects.
 * In a real cluster, this would involve calling the API Server to create Pods.
 */
function scaleUpIfNecessary(state: ClusterState): ClusterState {
  const currentReplicas = state.actualPods.filter(
    (p) => p.status !== "Terminating"
  ).length;
  const needed = state.desiredReplicas - currentReplicas;

  if (needed <= 0) {
    return {
      ...state,
      logs: [...state.logs, "[CONTROLLER] No scaling action required."],
    };
  }

  // Simulate creating new Pods
  const newPods: Pod[] = Array.from({ length: needed }).map((_, i) => ({
    id: `node-api-new-${Date.now()}-${i}`,
    status: "Pending", // Pods start in Pending before Running
  }));

  const updatedLogs = [
    ...state.logs,
    `[CONTROLLER] Reconciling: Creating ${needed} new Pod(s) to match desired state.`,
  ];

  return {
    ...state,
    actualPods: [...state.actualPods, ...newPods],
    logs: updatedLogs,
  };
}

/**
 * Node 3: Simulate Pod Lifecycle (Async/Await)
 * 
 * Kubernetes operations are asynchronous. This node simulates the time it takes
 * for a container runtime (like Docker) to pull images and start containers.
 */
async function simulatePodBootup(state: ClusterState): Promise<ClusterState> {
  const updatedPods = await Promise.all(
    state.actualPods.map(async (pod) => {
      if (pod.status === "Pending") {
        // Simulate network latency / container startup time
        await new Promise((resolve) => setTimeout(resolve, 1000));
        return { ...pod, status: "Running" as const };
      }
      return pod;
    })
  );

  const pendingCount = state.actualPods.filter((p) => p.status === "Pending").length;
  
  const logs = [...state.logs];
  if (pendingCount > 0) {
    logs.push(`[KUBELET] Simulated bootup of ${pendingCount} container(s). Status updated to Running.`);
  }

  return {
    ...state,
    actualPods: updatedPods,
    logs,
  };
}

// --- 4. The Execution Graph (The "Orchestrator") ---

/**
 * A simple StateGraph executor.
 * 
 * In LangGraph, nodes are connected by edges. Here, we define a linear flow:
 * Start -> Calculate -> Reconcile -> Bootup -> End
 */
async function runControlPlaneLoop(initialState: ClusterState) {
  console.log("--- Starting Kubernetes Control Plane Simulation ---\n");

  // Step 1: Observe
  const stateAfterObservation = calculateDiscrepancy(initialState);
  
  // Step 2: Act (Plan)
  const stateAfterReconciliation = scaleUpIfNecessary(stateAfterObservation);
  
  // Step 3: Wait (Async Execution)
  // In a real cluster, the Kubelet reports back to the API Server asynchronously.
  const finalState = await simulatePodBootup(stateAfterReconciliation);

  // --- Output Results ---
  console.log("\n--- Final Cluster State ---");
  console.log("Desired Replicas:", finalState.desiredReplicas);
  console.log(
    "Actual Running Pods:",
    finalState.actualPods.filter((p) => p.status === "Running").length
  );
  
  console.log("\n--- Control Plane Logs ---");
  finalState.logs.forEach((log) => console.log(log));
  
  console.log("\n--- Simulation Complete ---");
}

// --- 5. Execution Entry Point ---

// Run the simulation
runControlPlaneLoop(initialClusterState).catch((error) => {
  console.error("Control Plane Error:", error);
});
