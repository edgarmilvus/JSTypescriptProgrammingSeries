/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

/**
 * ============================================================================
 *  AI CLUSTER ORCHESTRATOR SIMULATION
 *  Target: Next.js / TypeScript (Server Components / API Route context)
 *  Purpose: Demonstrates Control Plane vs. Node logic for AI Chatbot workloads.
 * ============================================================================
 */

// -----------------------------------------------------------------------------
// 1. DEFINITIONS & TYPES (Graph State & Domain Models)
// -----------------------------------------------------------------------------

/**
 * Represents the temperature parameter for an LLM model.
 * Low temp = deterministic (coding assistance), High temp = creative (brainstorming).
 */
export type ModelTemperature = 0.1 | 0.5 | 0.9;

/**
 * The canonical Graph State for our cluster.
 * This object is the single source of truth passed between Control Plane and Nodes.
 */
export interface ClusterState {
  clusterId: string;
  nodes: WorkerNodeStatus[];
  pendingPods: AIPod[];
  desiredReplicas: number;
  timestamp: Date;
}

/**
 * Represents a single AI workload (Pod).
 * In our context, this is a Next.js Server Action handling a specific chatbot model.
 */
export interface AIPod {
  id: string;
  model: 'gpt-4-turbo' | 'llama-3-70b';
  temperature: ModelTemperature;
  status: 'Pending' | 'Running' | 'Crashed';
  assignedNode?: string;
  resourceCost: number; // Simulated GPU/CPU units
}

/**
 * Status report from a Worker Node (The "Muscle").
 */
export interface WorkerNodeStatus {
  nodeId: string;
  capacity: number; // Total available resources
  allocated: number; // Resources currently in use
  runningPods: string[]; // IDs of pods running here
  health: 'Healthy' | 'Draining' | 'Unreachable';
}

// -----------------------------------------------------------------------------
// 2. WORKER NODE CLASS (The "Muscle")
// -----------------------------------------------------------------------------

/**
 * Simulates a physical server in the cluster.
 * Responsibilities:
 * - Runs containers (Pods).
 * - Reports resource usage to the Control Plane (Kubelet function).
 * - Handles local networking (Kube-proxy simulation).
 */
class WorkerNode {
  public status: WorkerNodeStatus;

  constructor(nodeId: string, capacity: number) {
    this.status = {
      nodeId,
      capacity,
      allocated: 0,
      runningPods: [],
      health: 'Healthy',
    };
  }

  /**
   * Attempts to schedule a pod on this node.
   * Checks resource availability (CPU/GPU).
   * @param pod - The AI workload to deploy.
   * @returns boolean - Success or Failure.
   */
  public acceptPod(pod: AIPod): boolean {
    if (this.status.health !== 'Healthy') return false;
    if (this.status.allocated + pod.resourceCost > this.status.capacity) {
      console.warn(`[Node ${this.status.nodeId}] Insufficient resources for ${pod.id}`);
      return false;
    }

    // "Mount" the container
    this.status.allocated += pod.resourceCost;
    this.status.runningPods.push(pod.id);
    
    console.log(`[Node ${this.status.nodeId}] Deployed Pod ${pod.id} (${pod.model})`);
    return true;
  }

  /**
   * Simulates a pod crash or manual termination.
   * Releases resources back to the node.
   */
  public terminatePod(podId: string): void {
    const index = this.status.runningPods.indexOf(podId);
    if (index > -1) {
      this.status.runningPods.splice(index, 1);
      // In a real scenario, we'd look up the specific resource cost of the pod
      this.status.allocated -= 1; // Simplified for demo
      console.log(`[Node ${this.status.nodeId}] Terminated Pod ${podId}`);
    }
  }
}

// -----------------------------------------------------------------------------
// 3. CONTROL PLANE CLASS (The "Brain")
// -----------------------------------------------------------------------------

/**
 * Simulates the Kubernetes Control Plane (API Server + Scheduler + Controller Manager).
 * Responsibilities:
 * - API Server: Endpoint for desired state changes.
 * - Scheduler: Assigns Pods to Nodes based on resources.
 * - Controller Manager: Reconciles actual state with desired state.
 */
class ControlPlane {
  private nodes: WorkerNode[] = [];
  private desiredState: ClusterState;

  constructor(clusterId: string) {
    this.desiredState = {
      clusterId,
      nodes: [],
      pendingPods: [],
      desiredReplicas: 0,
      timestamp: new Date(),
    };
  }

  // --- API Server Simulation ---
  
  /**
   * Public API endpoint to scale the AI Chatbot service.
   * @param count - Number of replicas desired.
   */
  public scaleService(count: number): void {
    this.desiredState.desiredReplicas = count;
    console.log(`\n[Control Plane] Desired replicas updated to ${count}. Reconciling...`);
    this.reconcileLoop();
  }

  /**
   * Adds a new AI Pod to the queue (e.g., a new user session requiring a specific model).
   */
  public createAIPod(model: 'gpt-4-turbo' | 'llama-3-70b', temp: ModelTemperature): void {
    const newPod: AIPod = {
      id: `pod-${Math.random().toString(36).substr(2, 9)}`,
      model,
      temperature: temp,
      status: 'Pending',
      resourceCost: temp < 0.5 ? 2 : 4, // Deterministic models are cheaper in this sim
    };
    this.desiredState.pendingPods.push(newPod);
    console.log(`[Control Plane] Received request for ${model} (Temp: ${temp})`);
    this.reconcileLoop();
  }

  // --- Scheduler & Controller Logic ---

  /**
   * The Core Reconciliation Loop.
   * Compares desired state (pending pods) vs actual state (running pods).
   * 1. Schedules pending pods to available nodes.
   * 2. Updates the global ClusterState (Graph State).
   */
  private reconcileLoop(): void {
    // 1. Update Node Status (Simulate Kubelet heartbeats)
    this.updateNodeStatuses();

    // 2. Schedule Pending Pods
    this.schedulePendingPods();

    // 3. Garbage Collection (Ensure replica count matches)
    this.enforceReplicaCount();

    // 4. Emit Final State (Visualize)
    this.printClusterState();
  }

  /**
   * Iterates through pending pods and assigns them to nodes with capacity.
   */
  private schedulePendingPods(): void {
    const stillPending: AIPod[] = [];

    for (const pod of this.desiredState.pendingPods) {
      let scheduled = false;

      // Simple Bin-Packing Strategy: First-Fit
      for (const node of this.nodes) {
        if (node.acceptPod(pod)) {
          pod.status = 'Running';
          pod.assignedNode = node.status.nodeId;
          scheduled = true;
          break;
        }
      }

      if (!scheduled) {
        stillPending.push(pod); // Keep in queue for next cycle
      }
    }

    this.desiredState.pendingPods = stillPending;
  }

  /**
   * Ensures the number of "System Pods" matches desiredReplicas.
   * (Simulates the Deployment controller).
   */
  private enforceReplicaCount(): void {
    let currentReplicas = 0;
    this.nodes.forEach(n => currentReplicas += n.status.runningPods.length);

    // If we have too many, kill one (simplified)
    if (currentReplicas > this.desiredState.desiredReplicas && currentReplicas > 0) {
        // Find a pod to kill (simplified logic)
        for (const node of this.nodes) {
            if (node.status.runningPods.length > 0) {
                node.terminatePod(node.status.runningPods[0]);
                break;
            }
        }
    }
  }

  /**
   * Aggregates status from all nodes to build the global Graph State.
   */
  private updateNodeStatuses(): void {
    this.desiredState.nodes = this.nodes.map(n => n.status);
    this.desiredState.timestamp = new Date();
  }

  // --- Infrastructure Management ---

  /**
   * Adds a physical server to the cluster.
   */
  public addNode(capacity: number): void {
    const nodeId = `node-${this.nodes.length + 1}`;
    this.nodes.push(new WorkerNode(nodeId, capacity));
    console.log(`[Control Plane] Node ${nodeId} joined cluster (Capacity: ${capacity})`);
  }

  // --- Visualization ---

  /**
   * Renders the current ClusterState to the console.
   * Visualizes the separation of Control Plane logic vs Node execution.
   */
  private printClusterState(): void {
    console.log('--------------------------------------------------');
    console.log(`CLUSTER STATE: ${this.desiredState.clusterId}`);
    console.log(`TIMESTAMP: ${this.desiredState.timestamp.toISOString()}`);
    console.log(`DESIRED REPLICAS: ${this.desiredState.desiredReplicas}`);
    console.log('--------------------------------------------------');
    
    this.desiredState.nodes.forEach(node => {
      console.log(`[NODE] ${node.nodeId} | CPU/GPU: ${node.allocated}/${node.capacity} | Health: ${node.health}`);
      node.runningPods.forEach(podId => console.log(`   └── POD: ${podId}`));
    });

    if (this.desiredState.pendingPods.length > 0) {
      console.log(`[SCHEDULER] Pending Queue: ${this.desiredState.pendingPods.length} pods waiting for resources.`);
    }
    console.log('==================================================\n');
  }
}

// -----------------------------------------------------------------------------
// 4. EXECUTION SCRIPT (Simulating a SaaS Dashboard)
// -----------------------------------------------------------------------------

/**
 * Simulates a SaaS Admin Dashboard interacting with the Kubernetes Cluster.
 * This function orchestrates the demo flow.
 */
export async function runOrchestratorDemo() {
  console.log("🚀 Initializing AI Chatbot Cluster...\n");

  // 1. Initialize Control Plane
  const controlPlane = new ControlPlane("ai-cluster-prod-01");

  // 2. Provision Infrastructure (Worker Nodes)
  // We add two nodes. Node 1 is powerful (GPU heavy), Node 2 is standard.
  controlPlane.addNode(10); // Node 1: Capacity 10
  controlPlane.addNode(5);  // Node 2: Capacity 5

  // 3. Scenario A: Scaling up the standard Chatbot Service
  // User traffic increases, we need 3 replicas of a standard model.
  controlPlane.scaleService(3);

  // 4. Scenario B: High-Load AI Request
  // A user requests a complex, high-temperature creative model.
  // This requires more resources (cost: 4).
  controlPlane.createAIPod('llama-3-70b', 0.9);

  // 5. Scenario C: Resource Exhaustion & Scheduling Failure
  // Let's try to add another heavy pod. Node 2 is full, Node 1 has space?
  controlPlane.createAIPod('gpt-4-turbo', 0.1); // Cost: 2

  // 6. Scenario D: Scaling Down
  // Traffic drops, scale down to 1 replica.
  controlPlane.scaleService(1);
}

// To run this in a Next.js environment, you would typically export this 
// to an API route or a Server Action.
// runOrchestratorDemo(); 
