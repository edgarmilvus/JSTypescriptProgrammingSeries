/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

digraph KubernetesArchitecture {
    rankdir=LR;
    node [fontname="Arial", shape=box, style=rounded];
    edge [fontname="Arial", fontsize=10];

    // User Interaction
    User [shape=ellipse, label="User/Admin"];

    // Control Plane Subgraph
    subgraph cluster_control_plane {
        label = "Control Plane";
        style = filled;
        color = lightgrey;
        node [style=filled, color=white];

        etcd [label="etcd\n(Key-Value Store)", shape=cylinder];
        api_server [label="API Server\n(Central Entry Point)", shape=component];
        scheduler [label="Scheduler\n(Pod Assignment)", shape=component];
        controller_manager [label="Controller Manager\n(State Reconciliation)", shape=component];
    }

    // Worker Node Subgraph
    subgraph cluster_worker_node {
        label = "Worker Node";
        style = filled;
        color = lightblue;
        node [style=filled, color=white];

        kubelet [label="Kubelet\n(Agent)", shape=component];
        kube_proxy [label="Kube-proxy\n(Network Rules)", shape=component];
        container_runtime [label="Container Runtime\n(e.g., containerd)", shape=component];
    }

    // Flows
    // 1. User to API Server
    User -> api_server [label="Commands (kubectl, API calls)"];

    // 2. API Server internal coordination
    api_server -> etcd [label="Read/Write State", style=dashed];
    api_server -> scheduler [label="Assign unscheduled Pods"];
    api_server -> controller_manager [label="Watch resource changes"];

    // 3. API Server to Node Agent
    api_server -> kubelet [label="Pod Spec", color=blue];

    // 4. Node Agent execution
    kubelet -> container_runtime [label="Run Container"];
    kubelet -> kube_proxy [label="Configure Network"];

    // 5. Status Updates (Feedback Loop)
    container_runtime -> kubelet [label="Container Status", style=dashed, color=grey];
    kubelet -> api_server [label="Node/Pod Status", style=dashed, color=grey];
    api_server -> etcd [label="Update Actual State", style=dashed, color=grey];
}
