/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

// 1. Define Interfaces
interface Node {
    name: string;
    availableCpu: number; // in millicores or arbitrary units
    availableMemory: number; // in MB or arbitrary units
}

interface Pod {
    name: string;
    requestedCpu: number;
    requestedMemory: number;
    assignedNode?: string; // Optional, as per requirements
}

// 2. Scheduler Function
function schedulePod(pod: Pod, nodes: Node[]): Node | null {
    // Iterate through the nodes to find a suitable one
    for (const node of nodes) {
        // Check resource constraints
        const hasEnoughCpu = node.availableCpu >= pod.requestedCpu;
        const hasEnoughMemory = node.availableMemory >= pod.requestedMemory;

        if (hasEnoughCpu && hasEnoughMemory) {
            // Return the node object (shallow copy to avoid accidental mutation of original array items)
            // Note: The requirement says "return the selected node object".
            // Since we are not modifying the node properties (like subtracting resources) 
            // in this specific function signature, returning the reference is acceptable.
            // If we were to update state, we would return a new object.
            return node;
        }
    }

    // Return null if no suitable node is found
    return null;
}

// 3. Test Case Scenario
function runTest() {
    const nodes: Node[] = [
        { name: 'node-1', availableCpu: 500, availableMemory: 2048 },
        { name: 'node-2', availableCpu: 1000, availableMemory: 1024 },
        { name: 'node-3', availableCpu: 200, availableMemory: 512 }
    ];

    // Scenario: An unschedulable pod (requires more resources than any node has)
    const unschedulablePod: Pod = {
        name: 'heavy-app',
        requestedCpu: 2000,
        requestedMemory: 4096
    };

    const result = schedulePod(unschedulablePod, nodes);

    console.log(`Test Result for unschedulable pod: ${result ? result.name : 'null (Expected)'}`);
    
    // Scenario 2: A schedulable pod
    const schedulablePod: Pod = {
        name: 'light-worker',
        requestedCpu: 300,
        requestedMemory: 1000
    };
    
    const result2 = schedulePod(schedulablePod, nodes);
    console.log(`Test Result for schedulable pod: ${result2 ? result2.name : 'null'}`);
}

// Execute test
runTest();
