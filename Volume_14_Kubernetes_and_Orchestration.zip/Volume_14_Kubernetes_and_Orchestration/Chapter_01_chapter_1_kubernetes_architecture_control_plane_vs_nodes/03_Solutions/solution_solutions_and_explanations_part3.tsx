/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState } from 'react';

// 1. Define Types
type ComponentStatusValue = 'healthy' | 'unhealthy';

type ComponentStatus = {
  apiServer: ComponentStatusValue;
  etcd: ComponentStatusValue;
  scheduler: ComponentStatusValue;
};

// 2. Helper for random status generation
const getRandomStatus = (): ComponentStatusValue => {
  return Math.random() > 0.5 ? 'healthy' : 'unhealthy';
};

const ControlPlaneHealth: React.FC = () => {
  // 3. State Management
  const [status, setStatus] = useState<ComponentStatus>({
    apiServer: 'healthy',
    etcd: 'healthy',
    scheduler: 'healthy',
  });

  // 4. Handler for Simulation
  const handleSimulateFailure = () => {
    setStatus(prevStatus => {
      // Select a random component key
      const keys = Object.keys(prevStatus) as (keyof ComponentStatus)[];
      const randomKey = keys[Math.floor(Math.random() * keys.length)];
      
      // Flip the status of that component
      return {
        ...prevStatus,
        [randomKey]: getRandomStatus()
      };
    });
  };

  // 5. Helper for conditional styling
  const getStatusStyle = (state: ComponentStatusValue) => {
    if (state === 'healthy') {
      return { color: 'green', backgroundColor: 'transparent' };
    }
    return { color: 'red', backgroundColor: '#ffe6e6' }; // Very light pink
  };

  return (
    <div style={{ border: '1px solid #ccc', padding: '16px', borderRadius: '8px', maxWidth: '300px' }}>
      <h3>Control Plane Health</h3>
      
      {/* Status Indicators */}
      <div style={{ display: 'flex', flexDirection: 'column', gap: '8px', marginBottom: '16px' }}>
        <div style={getStatusStyle(status.apiServer)}>
          API Server: {status.apiServer.toUpperCase()}
        </div>
        <div style={getStatusStyle(status.etcd)}>
          etcd: {status.etcd.toUpperCase()}
        </div>
        <div style={getStatusStyle(status.scheduler)}>
          Scheduler: {status.scheduler.toUpperCase()}
        </div>
      </div>

      {/* Interactive Button */}
      <button onClick={handleSimulateFailure} style={{ cursor: 'pointer' }}>
        Simulate Failure
      </button>
    </div>
  );
};

export default ControlPlaneHealth;
