/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

import { EventEmitter } from 'events';

// 1. Define the KubeletAgent class
class KubeletAgent extends EventEmitter {
    nodeName: string;

    constructor(nodeName: string) {
        super();
        this.nodeName = nodeName;
        
        // Register the event listener immediately upon instantiation
        this.on('PodScheduled', (payload: { podName: string, nodeName: string }) => {
            // Verify the node name matches (Simulating the API Server routing logic)
            if (payload.nodeName === this.nodeName) {
                console.log(`[Kubelet on ${this.nodeName}]: Received instruction to start pod ${payload.podName}`);
            } else {
                console.log(`[Kubelet on ${this.nodeName}]: Ignoring event for different node: ${payload.nodeName}`);
            }
        });
    }
}

// 2. Simulate API Server Action
function simulateApiServerAction(kubelet: KubeletAgent, podName: string) {
    // Emit the event with the payload
    const payload = {
        podName: podName,
        nodeName: kubelet.nodeName // Sending to the specific node
    };
    
    console.log(`[API Server]: Scheduling pod ${podName} to ${kubelet.nodeName}...`);
    kubelet.emit('PodScheduled', payload);
}

// 3. Demonstration
// Instantiate a Kubelet for "node-01"
const kubeletNode01 = new KubeletAgent('node-01');

// Call the simulation function
simulateApiServerAction(kubeletNode01, 'nginx-pod-1');

// Optional: Demonstrate ignoring a wrong node event
const kubeletNode02 = new KubeletAgent('node-02');
// Manually emit to node-01 from node-02 context (simulating a misrouting or broadcast)
kubeletNode02.emit('PodScheduled', { podName: 'wrong-pod', nodeName: 'node-01' }); 
