/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

// 1. Define Type
type PodEndpoint = {
    ip: string;
    port: number;
};

// 2. Create ServiceProxy Class
class ServiceProxy {
    private endpoints: PodEndpoint[];
    private currentIndex: number;

    constructor() {
        this.endpoints = [];
        this.currentIndex = 0;
    }

    // Method to register a new pod
    addEndpoint(endpoint: PodEndpoint): void {
        this.endpoints.push(endpoint);
        console.log(`Added endpoint: ${endpoint.ip}:${endpoint.port}`);
    }

    // Method to get next endpoint using Round Robin
    getNextEndpoint(): PodEndpoint | null {
        if (this.endpoints.length === 0) {
            return null;
        }

        // Get the current endpoint
        const endpoint = this.endpoints[this.currentIndex];

        // Update index for next call (circular logic)
        this.currentIndex = (this.currentIndex + 1) % this.endpoints.length;

        return endpoint;
    }
}

// 3. Usage Example
const proxy = new ServiceProxy();

// Add 3 endpoints
proxy.addEndpoint({ ip: '10.0.0.1', port: 8080 });
proxy.addEndpoint({ ip: '10.0.0.2', port: 8080 });
proxy.addEndpoint({ ip: '10.0.0.3', port: 8080 });

console.log("\n--- Simulating Traffic (5 Requests) ---");

// Call getNextEndpoint 5 times
for (let i = 1; i <= 5; i++) {
    const endpoint = proxy.getNextEndpoint();
    if (endpoint) {
        console.log(`Request ${i}: Forwarding to ${endpoint.ip}:${endpoint.port}`);
    } else {
        console.log(`Request ${i}: No endpoints available`);
    }
}
