/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: theory_theoretical_foundations.ts
// Description: Theoretical Foundations
// ==========================================

digraph LocalK8sArchitectures {
    rankdir=TB;
    node [shape=box, style=filled, fillcolor="#e0e0e0"];

    subgraph cluster_host {
        label = "Host Machine (MacOS/Windows/Linux)";
        style = dashed;
        
        subgraph minikube_arch {
            label = "Minikube (VM Driver)";
            style = solid;
            node [fillcolor="#b3d9ff"];
            
            VM [label="Virtual Machine\n(HyperKit/VirtualBox/KVM)"];
            VM_K8s [label="Kubernetes Control Plane\n& Worker Node"];
            VM_Apps [label="Pods / Containers"];
            
            VM -> VM_K8s -> VM_Apps;
        }

        subgraph kind_arch {
            label = "Kind (Docker Driver)";
            style = solid;
            node [fillcolor="#d9ffb3"];
            
            Docker_Daemon [label="Docker Daemon"];
            Control_Plane [label="Control Plane Container"];
            Worker_Node_1 [label="Worker Node Container 1"];
            Worker_Node_2 [label="Worker Node Container 2"];
            Kind_Pods [label="Pods (Sibling Containers)"];
            
            Docker_Daemon -> Control_Plane;
            Docker_Daemon -> Worker_Node_1;
            Docker_Daemon -> Worker_Node_2;
            Worker_Node_1 -> Kind_Pods;
            Worker_Node_2 -> Kind_Pods;
        }
    }
}
