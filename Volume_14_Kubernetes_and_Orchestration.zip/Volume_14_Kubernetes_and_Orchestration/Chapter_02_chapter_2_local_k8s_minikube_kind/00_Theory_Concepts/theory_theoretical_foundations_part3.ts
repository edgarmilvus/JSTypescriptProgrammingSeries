/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part3.ts
// Description: Theoretical Foundations
// ==========================================

    // Conceptual Service Worker logic for caching AI assets from a local K8s cluster
    // This represents the browser-side logic that interacts with the local cluster
    
    const MODEL_CACHE_NAME = 'ai-model-cache-v1';
    const MODEL_URL = 'http://my-local-ingress.local/models/model.onnx'; // Pointing to local K8s

    self.addEventListener('fetch', (event) => {
        if (event.request.url.includes('/models/')) {
            event.respondWith(
                caches.match(event.request).then((cachedResponse) => {
                    // If cached, return immediately (instant load)
                    if (cachedResponse) {
                        return cachedResponse;
                    }
                    // Otherwise, fetch from local K8s cluster and cache it
                    return fetch(event.request).then((response) => {
                        if (!response || response.status !== 200) {
                            return response;
                        }
                        const responseToCache = response.clone();
                        caches.open(MODEL_CACHE_NAME).then((cache) => {
                            cache.put(event.request, responseToCache);
                        });
                        return response;
                    });
                })
            );
        }
    });
    