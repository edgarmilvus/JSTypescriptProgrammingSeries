/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * @fileoverview A self-contained example of Optimistic UI with Local AI Inference and Reconciliation.
 * @context SaaS Web App - "Smart Note Tagger" feature.
 */

// --- 1. Type Definitions ---

/**
 * Represents the state of a single note in our application.
 */
type Note = {
    id: string;
    content: string;
    tags: string[];      // The tags assigned by the AI
    status: 'idle' | 'optimistic' | 'reconciled' | 'error';
    lastUpdated: number; // Timestamp for debugging order
};

/**
 * A mapping of note IDs to their state. This simulates a client-side store (like Redux or Zustand).
 */
type AppState = {
    notes: Record<string, Note>;
};

// --- 2. Mock Local AI Engine ---

/**
 * Simulates a heavy local AI inference process (e.g., running a WASM model).
 * It introduces artificial latency to mimic real-world processing time.
 * 
 * @param content The text content to analyze.
 * @returns A Promise resolving to an array of tags.
 */
const mockLocalAIEngine = async (content: string): Promise<string[]> => {
    // Simulate "Warm Start" latency (weights loaded, pipelines ready)
    // In a real app, this might be 200ms-500ms for WASM, or faster for WebGPU.
    await new Promise(resolve => setTimeout(resolve, 600)); 

    // Simple heuristic to simulate the AI model's logic
    // (In reality, this would be model inference)
    const lowerContent = content.toLowerCase();
    const tags: string[] = [];

    if (lowerContent.includes('urgent') || lowerContent.includes('asap')) tags.push('Priority: High');
    if (lowerContent.includes('bug') || lowerContent.includes('error')) tags.push('Type: Bug');
    if (lowerContent.includes('feature') || lowerContent.includes('idea')) tags.push('Type: Feature');
    if (tags.length === 0) tags.push('Type: General');

    return tags;
};

// --- 3. The State Manager & Reconciliation Logic ---

class NoteTaggerApp {
    private state: AppState = { notes: {} };

    /**
     * Renders the current state to the console (simulating DOM updates).
     * In a real app, this would trigger React/Vue re-renders.
     */
    private render(): void {
        console.log('\n--- Current UI State ---');
        Object.values(this.state.notes).forEach(note => {
            console.log(`[${note.id}] "${note.content}"`);
            console.log(`  Tags: [${note.tags.join(', ')}]`);
            console.log(`  Status: ${note.status}`);
        });
        console.log('------------------------\n');
    }

    /**
     * Adds a new note and triggers the AI tagging process.
     * This demonstrates the Optimistic UI pattern.
     * 
     * @param content The content of the new note.
     */
    public async addNote(content: string): Promise<void> {
        const id = `note-${Date.now()}`;
        
        // --- OPTIMISTIC UPDATE ---
        // 1. We assume the AI will succeed. To provide immediate feedback,
        //    we generate a temporary "optimistic" tag based on simple keywords.
        //    This prevents the UI from showing an empty tag list.
        const optimisticTags = content.toLowerCase().includes('urgent') ? ['Priority: High (Pending...)'] : ['Thinking...'];
        
        const optimisticNote: Note = {
            id,
            content,
            tags: optimisticTags,
            status: 'optimistic',
            lastUpdated: Date.now()
        };

        // Update local state immediately
        this.state.notes[id] = optimisticNote;
        
        console.log(`> Action: User added note ${id}. Optimistic UI updated.`);
        this.render();

        // --- BACKGROUND INFERENCE ---
        // 2. Trigger the heavy local AI computation asynchronously.
        //    We don't await this inside the render cycle to keep UI responsive.
        try {
            const actualTags = await mockLocalAIEngine(content);

            // --- RECONCILIATION ---
            // 3. Compare the temporary (optimistic) state with the actual confirmed state.
            this.reconcileNote(id, actualTags);
        } catch (error) {
            this.handleError(id);
        }
    }

    /**
     * Reconciles the optimistic state with the actual AI results.
     * This is the "Correction" phase.
     * 
     * @param id The note ID to reconcile.
     * @param actualTags The tags returned by the local AI engine.
     */
    private reconcileNote(id: string, actualTags: string[]): void {
        const currentNote = this.state.notes[id];
        
        if (!currentNote) return; // Note might have been deleted

        // Check for discrepancies
        const isDifferent = JSON.stringify(currentNote.tags) !== JSON.stringify(actualTags);

        if (isDifferent) {
            console.log(`> Reconciliation: Discrepancy detected for ${id}. Updating UI...`);
            
            // Update the state with the "ground truth" from the AI
            this.state.notes[id] = {
                ...currentNote,
                tags: actualTags,
                status: 'reconciled',
                lastUpdated: Date.now()
            };
            
            this.render();
        } else {
            // If optimistic guess was correct (rare, but possible)
            console.log(`> Reconciliation: Optimistic guess was correct for ${id}.`);
            this.state.notes[id].status = 'reconciled';
        }
    }

    /**
     * Handles errors during AI inference.
     * Reverts the optimistic state to reflect the failure.
     */
    private handleError(id: string): void {
        const currentNote = this.state.notes[id];
        if (!currentNote) return;

        console.error(`> Error: AI inference failed for ${id}. Reverting state.`);
        
        this.state.notes[id] = {
            ...currentNote,
            tags: ['Error: Failed to tag'],
            status: 'error',
            lastUpdated: Date.now()
        };

        this.render();
    }
}

// --- 4. Execution Simulation ---

async function runDemo() {
    const app = new NoteTaggerApp();

    // Scenario 1: User adds a note with an obvious keyword ("urgent")
    // The optimistic UI guesses 'Priority: High (Pending...)', the AI confirms 'Priority: High'.
    await app.addNote("Fix the urgent login bug ASAP.");

    // Scenario 2: User adds a note with complex context
    // The optimistic UI guesses 'Thinking...', the AI analyzes and returns specific tags.
    await app.addNote("New feature request: Add dark mode to the dashboard.");

    // Scenario 3: User adds a note that triggers no keywords
    // The optimistic UI guesses 'Thinking...', the AI returns 'Type: General'.
    await app.addNote("Meeting notes from Tuesday.");
}

// Run the simulation
runDemo();
