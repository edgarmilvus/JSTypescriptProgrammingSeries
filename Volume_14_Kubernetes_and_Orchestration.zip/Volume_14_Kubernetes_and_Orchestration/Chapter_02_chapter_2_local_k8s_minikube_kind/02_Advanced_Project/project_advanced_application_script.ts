/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// File: app/api/ai-engine/route.ts (or logic within a client-side hook)
// Note: In a real Next.js app, Service Workers are typically registered via 'use client' hooks.
// This script unifies the logic for pedagogical clarity.

/**
 * ============================================================================
 * 1. SERVICE WORKER LOGIC (The "Cluster Node")
 * ============================================================================
 * This block represents the code running inside the Service Worker scope.
 * It acts like a Kubernetes Pod: isolated, persistent, and specialized.
 */

// Mocking the ONNX Runtime or Transformers.js environment
// In production, this would be: import { pipeline } from '@xenova/transformers';
declare const self: ServiceWorkerGlobalScope;

// State management for "Warm Start"
// Kubernetes analogy: A Deployment with 'replicas: 1' kept warm.
let modelPipeline: any = null;
let isModelLoaded = false;

// Cache Name (Versioned like a Docker image tag)
const CACHE_NAME = 'ai-cluster-v1.0';
const MODEL_URL = '/models/onnx-zero-shot-model.onnx';

/**
 * Intercepts fetch events to serve cached assets or simulate inference.
 * Kubernetes analogy: Ingress Controller routing traffic.
 */
self.addEventListener('fetch', (event: FetchEvent) => {
  const url = new URL(event.request.url);

  // Route: /api/inference
  // Logic: If the model is warm, process immediately. Else, simulate cold start.
  if (url.pathname === '/api/inference') {
    event.respondWith(handleInference(event.request));
    return;
  }

  // Route: Model Assets
  // Logic: Cache-first strategy for heavy weights.
  if (url.pathname.startsWith('/models/')) {
    event.respondWith(handleModelAsset(event.request));
    return;
  }
});

/**
 * Handles the Zero-Shot Classification Request.
 * 1. Checks if "Warm Start" is active.
 * 2. If not, loads model (simulating pulling image).
 * 3. Returns result.
 */
async function handleInference(request: Request): Promise<Response> {
  try {
    const { text, labels } = await request.json();

    if (!isModelLoaded || !modelPipeline) {
      // COLD START: Simulate loading weights from disk/network
      // Kubernetes analogy: ImagePullBackOff -> ContainerCreating
      console.log('[Worker] Cold Start detected. Loading weights...');
      await new Promise(resolve => setTimeout(resolve, 1500)); // Simulate latency
      
      // "Warm Start" achieved
      modelPipeline = { 
        classify: (t: string, l: string[]) => ({ 
          label: l[Math.floor(Math.random() * l.length)], 
          score: 0.95 
        }) 
      };
      isModelLoaded = true;
      console.log('[Worker] Model Warm. Ready for inference.');
    } else {
      // WARM START: Immediate execution
      // Kubernetes analogy: Pod is Running, ready to serve traffic.
      console.log('[Worker] Warm Start. Low latency execution.');
    }

    // Execute Zero-Shot Logic
    const result = modelPipeline.classify(text, labels);

    return new Response(JSON.stringify({ 
      status: 'success', 
      source: 'ServiceWorker (Local Node)',
      result,
      wasWarmStart: isModelLoaded // Feedback for UI
    }), {
      headers: { 'Content-Type': 'application/json' }
    });

  } catch (error) {
    return new Response(JSON.stringify({ status: 'error', message: error }), { status: 500 });
  }
}

/**
 * Handles Asset Caching (Service Worker Caching Concept).
 * Ensures model weights are available offline.
 */
async function handleModelAsset(request: Request): Promise<Response> {
  const cache = await caches.open(CACHE_NAME);
  const cachedResponse = await cache.match(request);

  if (cachedResponse) {
    return cachedResponse; // Return from "Local Volume"
  }

  // If not in cache, fetch from network and store
  const networkResponse = await fetch(request);
  if (networkResponse.ok) {
    cache.put(request, networkResponse.clone());
  }
  return networkResponse;
}

/**
 * ============================================================================
 * 2. MAIN THREAD LOGIC (The "Developer Console / Client")
 * ============================================================================
 * This logic runs in the Next.js component or API route handler.
 */

/**
 * Client-side service for managing the AI Worker.
 * Encapsulates registration and communication.
 */
class AIServiceOrchestrator {
  private worker: ServiceWorker | null = null;

  /**
   * Registers the "Cluster Node" (Service Worker).
   */
  async init() {
    if ('serviceWorker' in navigator) {
      // In a real Next.js app, this points to '/sw.js'
      // Here we simulate the registration logic
      console.log('Orchestrator: Registering Local Node...');
    }
  }

  /**
   * Sends payload to the Worker for Zero-Shot Classification.
   */
  async classify(text: string, labels: string[]): Promise<any> {
    // Simulate the fetch request to the worker
    // In reality: await fetch('/api/inference', { method: 'POST', body: ... })
    
    // Since we can't actually fetch from the main thread to the worker block above 
    // in this single-file format, we will simulate the call structure:
    
    // 1. Check if "Warm"
    // 2. Send Request
    
    // NOTE: In a real environment, we would use `navigator.serviceWorker.controller.postMessage`
    // or a fetch request that the SW intercepts.
    
    // Simulating the response based on the logic above:
    const isWarm = Math.random() > 0.3; // Randomly simulate warm/cold for demo
    
    if (!isWarm) {
      // Simulate Cold Start Latency
      await new Promise(r => setTimeout(r, 1500));
    }

    return {
      status: 'success',
      result: { label: labels[0], score: 0.98 },
      wasWarmStart: isWarm
    };
  }
}

/**
 * ============================================================================
 * 3. NEXT.JS API ROUTE HANDLER (The "SaaS Backend Interface")
 * ============================================================================
 * This mimics a Next.js API Route that acts as the bridge.
 */

export async function POST(request: Request) {
  const { text, labels } = await request.json();

  // In a real deployment, this backend might offload to a GPU cluster.
  // For local development, we might route to the Service Worker or a local Python process.
  // Here, we demonstrate the logic flow.
  
  const orchestrator = new AIServiceOrchestrator();
  
  // We simulate the worker response here for the sake of the script execution
  const inferenceResult = await orchestrator.classify(text, labels);

  return new Response(JSON.stringify(inferenceResult), {
    status: 200,
    headers: { 'Content-Type': 'application/json' }
  });
}
