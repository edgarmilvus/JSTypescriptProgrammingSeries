/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// src/index.ts
import express from 'express';

const app = express();
app.use(express.json());

// In-memory state to track if the container has been "warmed up"
let isWarm = false;

app.get('/health', (req, res) => {
  res.json({ status: 'ok' });
});

app.post('/infer', (req, res) => {
  const { input } = req.body;
  const warmStart = req.query.warm === 'true';

  let delay = 500; // Standard inference delay
  let warmStatus = isWarm;

  // Logic for warm start simulation
  if (warmStart && !isWarm) {
    delay = 2000; // Long delay on first warm request
    isWarm = true; // Update state for subsequent requests
    warmStatus = true; // Report that warm start occurred
  }

  console.log(`Processing request. Input: ${input}. Delay: ${delay}ms. Warm: ${warmStatus}`);

  setTimeout(() => {
    res.json({
      result: `processed: ${input}`,
      model: 'local-sim-v1',
      warm_start: warmStatus
    });
  }, delay);
});

app.listen(3000, () => console.log('Server running on port 3000'));
