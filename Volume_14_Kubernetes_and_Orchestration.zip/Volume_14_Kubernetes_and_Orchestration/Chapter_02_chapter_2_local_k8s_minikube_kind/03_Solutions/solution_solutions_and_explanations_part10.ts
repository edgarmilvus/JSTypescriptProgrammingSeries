/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part10.ts
// Description: Solutions and Explanations
// ==========================================

#!/bin/bash
CLUSTER_NAME="ai-cluster"

# Check if cluster exists
if kind get clusters | grep -q "$CLUSTER_NAME"; then
  echo "Cluster $CLUSTER_NAME exists. Deleting..."
  kind delete cluster --name $CLUSTER_NAME
fi

echo "Creating cluster $CLUSTER_NAME..."
kind create cluster --config kind-config.yaml --name $CLUSTER_NAME

# Wait for nodes to be ready
echo "Waiting for nodes to be ready..."
kubectl wait --for=condition=Ready node --all --timeout=120s

# Load image (assuming it's built locally)
echo "Loading image into cluster..."
kind load docker-image local-ai-service:v1.0 --name $CLUSTER_NAME

# Apply deployment
echo "Applying deployment..."
kubectl apply -f deployment-multi.yaml

# Wait for pods
echo "Waiting for pods..."
sleep 10 # Simple wait, in production use 'kubectl wait --for=condition=Ready pod -l app=ai-service'

# Output table
echo "Pod Distribution:"
kubectl get pods -o wide --show-labels
