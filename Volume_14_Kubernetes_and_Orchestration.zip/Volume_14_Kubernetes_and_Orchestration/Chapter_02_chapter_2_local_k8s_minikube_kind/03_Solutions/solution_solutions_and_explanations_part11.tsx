/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part11.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState, useEffect } from 'react';

interface Pod {
  name: string;
  status: 'Pending' | 'Running' | 'CrashLoopBackOff';
  node: string;
}

// Helper to generate random IDs
const generateId = () => Math.random().toString(36).substr(2, 9);

export const ClusterStatus: React.FC<{ serviceName: string }> = ({ serviceName }) => {
  const [pods, setPods] = useState<Pod[]>([]);
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [isOptimistic, setIsOptimistic] = useState<boolean>(false);

  // Initial fetch
  useEffect(() => {
    fetchStatus();
  }, []);

  const fetchStatus = async () => {
    setLoading(true);
    setError(null);
    
    // Simulate API latency
    await new Promise(resolve => setTimeout(resolve, 1000));

    // Mock data
    const mockData: Pod[] = [
      { name: `${serviceName}-pod-1`, status: 'Running', node: 'worker-node-1' },
      { name: `${serviceName}-pod-2`, status: 'Running', node: 'worker-node-2' },
    ];

    setPods(mockData);
    setLoading(false);
  };

  const handleSimulateScaling = () => {
    // 1. Optimistic Update
    setIsOptimistic(true);
    const newPods: Pod[] = [
      { name: `${serviceName}-pod-new-1`, status: 'Pending', node: 'Pending' },
      { name: `${serviceName}-pod-new-2`, status: 'Pending', node: 'Pending' },
      { name: `${serviceName}-pod-new-3`, status: 'Pending', node: 'Pending' },
    ];
    
    // Add pending pods immediately to state
    setPods(prev => [...prev, ...newPods]);

    // 2. Reconciliation Logic (Simulate API call to "scale")
    setTimeout(() => {
      setPods(prev => 
        prev.map(pod => 
          pod.status === 'Pending' && pod.node === 'Pending'
            ? { ...pod, status: 'Running', node: `worker-node-${Math.floor(Math.random() * 2) + 1}` }
            : pod
        )
      );
      setIsOptimistic(false);
    }, 2000);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Running': return 'green';
      case 'Pending': return 'yellow';
      case 'CrashLoopBackOff': return 'red';
      default: return 'gray';
    }
  };

  return (
    <div style={{ padding: '20px', fontFamily: 'sans-serif' }}>
      <h2>Status for {serviceName}</h2>
      
      <div style={{ marginBottom: '10px' }}>
        <button onClick={fetchStatus} disabled={loading} style={{ marginRight: '10px' }}>
          {loading ? 'Refreshing...' : 'Refresh'}
        </button>
        <button onClick={handleSimulateScaling} disabled={isOptimistic}>
          {isOptimistic ? 'Scaling...' : 'Simulate Scaling'}
        </button>
      </div>

      {error && <div style={{ color: 'red' }}>Error: {error}</div>}

      <ul style={{ listStyle: 'none', padding: 0 }}>
        {pods.map((pod) => (
          <li key={pod.name + pod.node} style={{ marginBottom: '8px', padding: '8px', border: '1px solid #ccc', borderRadius: '4px' }}>
            <strong>{pod.name}</strong> - Node: {pod.node}{' '}
            <span 
              style={{ 
                color: 'white', 
                backgroundColor: getStatusColor(pod.status), 
                padding: '2px 6px', 
                borderRadius: '4px',
                fontSize: '0.8em'
              }}
            >
              {pod.status}
            </span>
          </li>
        ))}
      </ul>
      
      {isOptimistic && <div style={{ fontStyle: 'italic', color: '#666' }}>Optimistically updating cluster state...</div>}
    </div>
  );
};
