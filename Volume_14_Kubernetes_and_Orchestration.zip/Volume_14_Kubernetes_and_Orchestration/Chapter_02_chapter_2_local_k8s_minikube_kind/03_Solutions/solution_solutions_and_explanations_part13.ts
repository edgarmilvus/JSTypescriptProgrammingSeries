/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part13.ts
// Description: Solutions and Explanations
// ==========================================

# 1. Update the deployment
kubectl apply -f deployment.yaml

# 2. Stream logs from the most recently created pod (using jsonpath)
kubectl logs -f $(kubectl get pods -l app=ai-service -o jsonpath="{.items[0].metadata.name}") --tail=10

# 3. Search logs for "Warm" (Simulating the log output from the TS code)
# Note: The TS code logs "Warm: true/false". We grep for "Warm".
kubectl logs $(kubectl get pods -l app=ai-service -o jsonpath="{.items[0].metadata.name}") | grep "Warm"

# 4. Scale deployment to 3 replicas
kubectl scale deployment ai-service-deployment --replicas=3

# 5. View logs from all pods simultaneously (aggregated)
kubectl logs -f -l app=ai-service --tail=10
