/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part14.ts
// Description: Solutions and Explanations
// ==========================================

#!/bin/bash

SERVICE_NAME="ai-service"
NAMESPACE="default"

echo "Starting Smoke Test for $SERVICE_NAME..."

# 1. Port-forward in background
echo "Setting up port-forward..."
kubectl port-forward svc/$SERVICE_NAME 3000:80 &
PF_PID=$!

# Wait for port-forward to establish
sleep 3

# 2. Send Warm Request
echo "Sending warm request..."
curl -s -X POST "http://localhost:3000/infer?warm=true" -H "Content-Type: application/json" -d '{"input":"warm test"}' > /dev/null

# 3. Send Standard Request
echo "Sending standard request..."
curl -s -X POST "http://localhost:3000/infer" -H "Content-Type: application/json" -d '{"input":"standard test"}' > /dev/null

# Kill port-forward
kill $PF_PID

# 4. Capture Logs
# Get the pod name handling the requests (assuming the first one listed)
POD_NAME=$(kubectl get pods -l app=ai-service -o jsonpath="{.items[0].metadata.name}")
echo "Analyzing logs from pod: $POD_NAME"

# 5. Parse and Report
# We look for the console.log lines: "Processing request... Delay: Xms..."
echo "Log Analysis Report:"
echo "-------------------"
kubectl logs $POD_NAME | grep "Processing request" | tail -n 2 | while read line; do
    # Extract delay value using sed or awk
    DELAY=$(echo "$line" | sed -n 's/.*Delay: \([0-9]*\)ms.*/\1/p')
    INPUT=$(echo "$line" | sed -n 's/.*Input: \(.*\)\. Delay.*/\1/p')
    
    if [ "$DELAY" == "2000" ]; then
        echo "✅ Warm Start Detected: Input '$INPUT' took ${DELAY}ms (Simulated Cold Boot)"
    else
        echo "✅ Standard Inference: Input '$INPUT' took ${DELAY}ms"
    fi
done
echo "-------------------"
