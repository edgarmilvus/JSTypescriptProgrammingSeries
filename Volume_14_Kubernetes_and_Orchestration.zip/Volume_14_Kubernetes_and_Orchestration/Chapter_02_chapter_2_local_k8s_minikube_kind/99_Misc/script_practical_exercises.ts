/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises.ts
// Description: Practical Exercises
// ==========================================

// Example structure for the Node.js server (TSX)
// src/index.ts
import express from 'express';

const app = express();
app.use(express.json());

let isWarm = false;

app.get('/health', (req, res) => {
  res.json({ status: 'ok' });
});

app.post('/infer', (req, res) => {
  const { input } = req.body;
  const warmStart = req.query.warm === 'true';

  // Simulate inference delay
  // TODO: Implement logic to handle warm start simulation
  // If warmStart is true and !isWarm, delay 2000ms, set isWarm = true
  // Else, delay 500ms
  
  const delay = 0; // Placeholder

  setTimeout(() => {
    res.json({
      result: `processed: ${input}`,
      model: 'local-sim-v1',
      warm_start: isWarm
    });
  }, delay);
});

app.listen(3000, () => console.log('Server running on port 3000'));
