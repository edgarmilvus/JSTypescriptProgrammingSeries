/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

// app/actions.ts
'use server';

import { generateId } from 'ai';
import { createAIState, streamUI } from 'ai/rsc';
import { OpenAI } from 'openai';
import { z } from 'zod';

// 1. Define the UI State structure
// This represents the presentation layer of our app.
type UIState = {
  id: string;
  display: React.ReactNode; // The actual component to render
}[];

// 2. Define the AI State structure
// This represents the model's memory of the conversation.
type AIState = {
  role: 'user' | 'assistant' | 'system';
  content: string;
}[];

// 3. Initialize the AI State
// We create a server-side state container for the conversation history.
export const AI = createAIState<AIState>({
  initialAIState: [],
  initialUIState: [],
});

// 4. Define a Tool Schema using Zod
// This ensures the LLM outputs structured data, preventing hallucinations.
const weatherSchema = z.object({
  location: z.string().describe('The city and state, e.g. San Francisco, CA'),
  temperature: z.number().describe('The temperature in fahrenheit'),
  condition: z.string().describe('The weather condition (e.g., sunny, rainy)'),
});

/**
 * Server Action: getWeather
 * Handles the logic for generating a response and updating both AI and UI states.
 */
export async function getWeather(userInput: string) {
  'use server';

  const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY! });

  // Update AI State with user input
  AI.update([...AI.get(), { role: 'user', content: userInput }]);

  // 5. Stream UI with Tool Calling
  // streamUI allows us to return React components as the LLM generates them.
  const { value: stream } = await streamUI({
    model: 'gpt-3.5-turbo',
    messages: AI.get(), // Pass current conversation history
    initial: <div>Thinking...</div>, // Initial loading state
    
    // Define tools the LLM can use
    tools: {
      getWeather: {
        description: 'Get the current weather for a location',
        parameters: weatherSchema,
        // Generate the UI component based on the tool's structured output
        generate: async function* ({ location, temperature, condition }) {
          // Yield a loading state
          yield <div className="p-4 bg-blue-100 text-blue-800 rounded-lg">Fetching weather data for {location}...</div>;
          
          // Simulate async work (e.g., API call)
          await new Promise(resolve => setTimeout(resolve, 1000));

          // Return the final component
          return (
            <div className="p-4 bg-white shadow-lg rounded-lg border border-gray-200">
              <h3 className="font-bold text-lg text-gray-800">Weather in {location}</h3>
              <p className="text-gray-600">Temperature: {temperature}°F</p>
              <p className="text-gray-600 capitalize">Condition: {condition}</p>
            </div>
          );
        },
      },
    },
  });

  // 6. Update UI State
  // We append the generated component to the UI state array.
  const uiState: UIState = [
    ...AI.getUI(), // Preserve existing UI
    {
      id: generateId(),
      display: stream,
    },
  ];

  AI.updateUI(uiState);

  return {
    success: true,
    uiState,
  };
}
