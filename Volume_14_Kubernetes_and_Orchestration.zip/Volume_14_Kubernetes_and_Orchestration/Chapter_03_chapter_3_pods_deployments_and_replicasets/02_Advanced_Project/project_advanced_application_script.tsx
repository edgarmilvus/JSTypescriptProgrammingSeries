/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.tsx
// Description: Advanced Application Script
// ==========================================

// app/dashboard/cluster-status/page.tsx

import React from 'react';

/**
 * ============================================================================
 * 1. TYPE DEFINITIONS & NARROWING GUARDS
 * ============================================================================
 * We define strict types to represent the Kubernetes resources. This mimics
 * the strict schema of a Deployment or Pod manifest.
 */

// Base interface for all Kubernetes resources
interface K8sResource {
  uid: string;
  name: string;
  namespace: string;
  createdAt: Date;
}

// Specific status types for our Pods
type PodStatus = 'Pending' | 'Running' | 'Failed' | 'Unknown';
type ContainerType = 'NodeJS-API' | 'AI-Inference';

// The shape of a Pod object
interface Pod extends K8sResource {
  kind: 'Pod';
  status: PodStatus;
  containerType: ContainerType;
  restartCount: number;
  ipAddress?: string;
}

// The shape of a Deployment object
interface Deployment extends K8sResource {
  kind: 'Deployment';
  replicas: number;
  readyReplicas: number;
  pods: Pod[]; // In a real cluster, we'd query Pods separately, but we aggregate here for the demo
}

// A union type for the data we expect from the cluster
type ClusterResource = Pod | Deployment;

/**
 * Type Guard: Checks if a resource is a Pod.
 * This is the "Runtime Check" that informs the TypeScript compiler.
 * @param resource - The generic resource object to check.
 * @returns boolean - True if the resource is a Pod.
 */
function isPod(resource: ClusterResource): resource is Pod {
  return resource.kind === 'Pod';
}

/**
 * Type Guard: Checks if a resource is a Deployment.
 * @param resource - The generic resource object to check.
 * @returns boolean - True if the resource is a Deployment.
 */
function isDeployment(resource: ClusterResource): resource is Deployment {
  return resource.kind === 'Deployment';
}

/**
 * ============================================================================
 * 2. DATA SIMULATION (MOCKING THE KUBERNETES API)
 * ============================================================================
 * In a real scenario, this would be an async call to the K8s API via
 * 'kubernetes-client' or 'client-go'. Here we simulate the raw JSON response.
 */

async function fetchClusterData(): Promise<ClusterResource[]> {
  // Simulate network latency
  await new Promise((resolve) => setTimeout(resolve, 500));

  // Mock data representing a Deployment with 3 Replicas (Pods)
  const mockData: ClusterResource[] = [
    {
      kind: 'Deployment',
      uid: 'deploy-123',
      name: 'nodejs-microservice',
      namespace: 'production',
      createdAt: new Date(Date.now() - 86400000), // 24 hours ago
      replicas: 3,
      readyReplicas: 3,
      pods: [
        {
          kind: 'Pod',
          uid: 'pod-1',
          name: 'nodejs-microservice-1',
          namespace: 'production',
          createdAt: new Date(),
          status: 'Running',
          containerType: 'NodeJS-API',
          restartCount: 0,
          ipAddress: '10.244.1.5',
        },
        {
          kind: 'Pod',
          uid: 'pod-2',
          name: 'nodejs-microservice-2',
          namespace: 'production',
          createdAt: new Date(),
          status: 'Running',
          containerType: 'NodeJS-API',
          restartCount: 1,
          ipAddress: '10.244.1.6',
        },
        {
          kind: 'Pod',
          uid: 'pod-3',
          name: 'nodejs-microservice-3',
          namespace: 'production',
          createdAt: new Date(),
          status: 'Pending', // Simulating a cold start or scheduling delay
          containerType: 'NodeJS-API',
          restartCount: 0,
        },
      ],
    },
    {
      kind: 'Deployment',
      uid: 'deploy-456',
      name: 'ai-inference-service',
      namespace: 'production',
      createdAt: new Date(Date.now() - 172800000), // 48 hours ago
      replicas: 2,
      readyReplicas: 2,
      pods: [
        {
          kind: 'Pod',
          uid: 'pod-4',
          name: 'ai-inference-1',
          namespace: 'production',
          createdAt: new Date(),
          status: 'Running',
          containerType: 'AI-Inference',
          restartCount: 0,
          ipAddress: '10.244.2.10',
        },
        {
          kind: 'Pod',
          uid: 'pod-5',
          name: 'ai-inference-2',
          namespace: 'production',
          createdAt: new Date(),
          status: 'Running',
          containerType: 'AI-Inference',
          restartCount: 0,
          ipAddress: '10.244.2.11',
        },
      ],
    },
  ];

  return mockData;
}

/**
 * ============================================================================
 * 3. LOGIC & COMPONENT RENDERING
 * ============================================================================
 * This Server Component processes the data using Type Narrowing to ensure
 * safety before rendering the UI.
 */

export default async function ClusterStatusPage() {
  // Fetch data on the server
  const resources = await fetchClusterData();

  // We will separate Deployments and Pods for structured rendering
  const deployments: Deployment[] = [];
  const orphanePods: Pod[] = [];

  // LOGIC BLOCK: Type Narrowing in a loop
  resources.forEach((resource) => {
    // The 'if' statement acts as a Type Guard.
    // Inside this block, TypeScript knows 'resource' is strictly a Deployment.
    if (isDeployment(resource)) {
      deployments.push(resource);
    } 
    // Inside this block, TypeScript knows 'resource' is strictly a Pod.
    // Note: In this specific mock data structure, pods are nested, 
    // but this demonstrates the narrowing logic for flat lists.
    else if (isPod(resource)) {
      orphanePods.push(resource);
    }
  });

  return (
    <div className="p-6 bg-gray-50 min-h-screen font-sans text-gray-800">
      <header className="mb-8">
        <h1 className="text-3xl font-bold text-indigo-900">Kubernetes Cluster Status</h1>
        <p className="text-gray-600">
          Real-time monitoring of Deployments and Pod lifecycles.
        </p>
      </header>

      <main className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Section 1: Deployment Overview */}
        <section className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <h2 className="text-xl font-semibold mb-4 text-indigo-700 border-b pb-2">
            Active Deployments
          </h2>
          <div className="space-y-4">
            {deployments.map((deploy) => (
              <div key={deploy.uid} className="border-l-4 border-indigo-500 pl-4 py-2 bg-indigo-50">
                <div className="flex justify-between items-center">
                  <h3 className="font-bold">{deploy.name}</h3>
                  <span className="text-xs bg-white px-2 py-1 rounded border">
                    {deploy.namespace}
                  </span>
                </div>
                <div className="mt-2 text-sm">
                  <div className="flex items-center gap-2">
                    <span className="font-medium">Replicas:</span>
                    <div className="w-24 bg-gray-200 rounded-full h-2.5">
                      <div 
                        className="bg-indigo-600 h-2.5 rounded-full" 
                        style={{ width: `${(deploy.readyReplicas / deploy.replicas) * 100}%` }}
                      ></div>
                    </div>
                    <span>{deploy.readyReplicas}/{deploy.replicas}</span>
                  </div>
                </div>

                {/* Nested Pod List for this Deployment */}
                <div className="mt-3 pl-2 border-l border-gray-300 space-y-2">
                  {deploy.pods.map((pod) => (
                    <div key={pod.uid} className="text-sm flex justify-between">
                      <span>{pod.name}</span>
                      <span className={`px-2 py-0.5 rounded text-xs font-bold ${
                        pod.status === 'Running' ? 'bg-green-100 text-green-800' : 
                        pod.status === 'Pending' ? 'bg-yellow-100 text-yellow-800' : 'bg-red-100 text-red-800'
                      }`}>
                        {pod.status}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* Section 2: AI Inference & Specifics */}
        <section className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <h2 className="text-xl font-semibold mb-4 text-purple-700 border-b pb-2">
            AI Inference Cluster
          </h2>
          <p className="text-sm text-gray-500 mb-4">
            Monitoring GPU utilization and vector dimensionality alignment.
          </p>
          
          <div className="space-y-4">
            {deployments
              .filter(d => d.name.includes('ai-inference'))
              .map((aiDeploy) => (
                <div key={aiDeploy.uid} className="bg-purple-50 p-4 rounded border border-purple-100">
                  <h3 className="font-bold text-purple-900 mb-2">{aiDeploy.name}</h3>
                  
                  {/* Simulated AI Metrics */}
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <span className="block text-gray-500">Model Dimension</span>
                      <span className="font-mono font-bold">1536</span>
                    </div>
                    <div>
                      <span className="block text-gray-500">Vector Index</span>
                      <span className="text-green-600 font-bold">Healthy</span>
                    </div>
                  </div>

                  {/* Status Logic */}
                  <div className="mt-3">
                    {aiDeploy.pods.every(p => p.status === 'Running') ? (
                      <div className="flex items-center text-green-700 text-sm">
                        <svg className="w-4 h-4 mr-1" fill="currentColor" viewBox="0 0 20 20">
                          <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                        </svg>
                        All replicas ready for inference
                      </div>
                    ) : (
                      <div className="text-yellow-600 text-sm font-medium">
                        Scaling up...
                      </div>
                    )}
                  </div>
                </div>
              ))}
          </div>
        </section>
      </main>
    </div>
  );
}
