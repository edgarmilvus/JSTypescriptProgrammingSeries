/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.tsx
// Description: Solutions and Explanations
// ==========================================

// File: DeploymentStatusCard.tsx
import React from 'react';

// 1. Define the TypeScript interface for the Kubernetes Deployment resource.
// We use optional chaining (?) for nested properties to handle undefined states.
interface KubernetesDeployment {
  metadata: {
    name: string;
  };
  status?: {
    replicas?: number;
    readyReplicas?: number;
  };
}

interface DeploymentStatusCardProps {
  deployment: KubernetesDeployment;
}

const DeploymentStatusCard: React.FC<DeploymentStatusCardProps> = ({ deployment }) => {
  // 2. Extract data safely using optional chaining and nullish coalescing.
  const name = deployment.metadata.name;
  const replicas = deployment.status?.replicas ?? 0;
  const readyReplicas = deployment.status?.readyReplicas ?? 0;

  // 3. Determine status logic.
  const isReady = replicas > 0 && readyReplicas === replicas;
  const statusColor = isReady ? 'green' : 'red';
  const statusText = isReady ? 'Healthy' : 'Unhealthy/Pending';

  // 4. Calculate progress percentage for the visual gauge.
  // Avoid division by zero.
  const progress = replicas > 0 ? Math.round((readyReplicas / replicas) * 100) : 0;

  // Styles for simple UI (inline for portability)
  const cardStyle: React.CSSProperties = {
    border: '1px solid #ddd',
    borderRadius: '8px',
    padding: '16px',
    width: '300px',
    boxShadow: '0 2px 4px rgba(0,0,0,0.1)',
    fontFamily: 'Arial, sans-serif'
  };

  const headerStyle: React.CSSProperties = {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: '10px'
  };

  const dotStyle: React.CSSProperties = {
    width: '12px',
    height: '12px',
    borderRadius: '50%',
    backgroundColor: statusColor,
    display: 'inline-block',
    marginRight: '8px'
  };

  const progressBarContainerStyle: React.CSSProperties = {
    height: '8px',
    backgroundColor: '#e0e0e0',
    borderRadius: '4px',
    overflow: 'hidden',
    marginTop: '10px'
  };

  const progressBarFillStyle: React.CSSProperties = {
    height: '100%',
    backgroundColor: statusColor,
    width: `${progress}%`,
    transition: 'width 0.3s ease'
  };

  return (
    <div style={cardStyle}>
      <div style={headerStyle}>
        <h3 style={{ margin: 0 }}>{name}</h3>
        <span style={{ fontSize: '0.9rem', color: '#666' }}>
          <span style={dotStyle}></span>
          {statusText}
        </span>
      </div>
      
      <div>
        {/* Display text summary */}
        <p style={{ margin: '5px 0', fontSize: '0.9rem' }}>
          <strong>Ready:</strong> {readyReplicas}/{replicas} pods
        </p>

        {/* Visual Gauge (Bonus) */}
        <div style={progressBarContainerStyle}>
          <div style={progressBarFillStyle} />
        </div>
        <p style={{ margin: '5px 0 0', fontSize: '0.8rem', textAlign: 'right', color: '#888' }}>
          {progress}%
        </p>
      </div>
    </div>
  );
};

export default DeploymentStatusCard;
