/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * k8s-networking-demo.ts
 * 
 * A self-contained TypeScript example demonstrating how to deploy a Node.js
 * microservice and expose it via a ClusterIP Service using the official
 * Kubernetes client library.
 * 
 * Prerequisites:
 * 1. npm install @kubernetes/client-node
 * 2. A valid kubeconfig (default location: ~/.kube/config) or in-cluster config.
 */

import * as k8s from '@kubernetes/client-node';

/**
 * Configuration for the Node.js application.
 * In a real SaaS, this would be injected via ConfigMaps or environment variables.
 */
const APP_CONFIG = {
  namespace: 'default',
  appName: 'hello-service',
  image: 'node:18-alpine', // Base image
  port: 3000,
  replicaCount: 1,
};

/**
 * 1. Initialize the Kubernetes Client
 * 
 * The KubeConfig class loads cluster configuration. By default, it looks for
 * the file at KUBE_CONFIG_LOCATION (~/.kube/config). In a production environment
 * running inside a Pod, we would use `kc.loadFromCluster()`.
 */
const kc = new k8s.KubeConfig();
kc.loadFromDefault(); 

// Create API clients for the core V1 API group (Pods, Services, etc.)
const k8sApi = kc.makeApiClient(k8s.CoreV1Api);
const appsApi = kc.makeApiClient(k8s.AppsV1Api);

/**
 * 2. Define the Deployment Manifest
 * 
 * We construct a Deployment object programmatically rather than using YAML.
 * This allows for dynamic configuration and type safety.
 * 
 * The Pod template includes a simple Node.js script that starts an HTTP server.
 * We use `command` to run a shell script that writes the server code and executes it,
 * ensuring the example requires no external Docker image build.
 */
const deploymentManifest: k8s.V1Deployment = {
  apiVersion: 'apps/v1',
  kind: 'Deployment',
  metadata: { name: APP_CONFIG.appName, namespace: APP_CONFIG.namespace },
  spec: {
    replicas: APP_CONFIG.replicaCount,
    selector: { matchLabels: { app: APP_CONFIG.appName } },
    template: {
      metadata: { labels: { app: APP_CONFIG.appName } },
      spec: {
        containers: [
          {
            name: 'node-server',
            image: APP_CONFIG.image,
            ports: [{ containerPort: APP_CONFIG.port }],
            // Inline script to start a server without a Dockerfile
            command: [
              'sh',
              '-c',
              `echo "const http = require('http'); const server = http.createServer((req, res) => { res.writeHead(200); res.end('Hello from ClusterIP!'); }); server.listen(${APP_CONFIG.port}, () => console.log('Server running on port ${APP_CONFIG.port}'));" > server.js && node server.js`
            ],
          },
        ],
      },
    },
  },
};

/**
 * 3. Define the ClusterIP Service Manifest
 * 
 * This Service acts as an internal load balancer.
 * - Type: ClusterIP (default) exposes the service on an internal IP.
 * - Selector: Matches the labels on the Pods created by the Deployment.
 * - Ports: Maps the Service port (80) to the Container port (3000).
 */
const serviceManifest: k8s.V1Service = {
  apiVersion: 'v1',
  kind: 'Service',
  metadata: { name: `${APP_CONFIG.appName}-svc`, namespace: APP_CONFIG.namespace },
  spec: {
    type: 'ClusterIP', // Exposes IP only within the cluster
    selector: { app: APP_CONFIG.appName }, // Targets Pods with this label
    ports: [
      {
        protocol: 'TCP',
        port: 80, // Port exposed by the Service
        targetPort: APP_CONFIG.port, // Port on the Pod
      },
    ],
  },
};

/**
 * 4. Main Execution Logic
 * 
 * An async function to orchestrate the deployment. It uses try/catch for error
 * handling, which is critical when interacting with external APIs.
 */
async function deployService() {
  console.log(`🚀 Starting deployment of '${APP_CONFIG.appName}'...`);

  try {
    // --- Step A: Create the Deployment ---
    console.log('1. Creating Deployment...');
    const deploymentResult = await appsApi.createNamespacedDeployment(
      APP_CONFIG.namespace,
      deploymentManifest
    );
    console.log(`✅ Deployment created: ${deploymentResult.body.metadata?.name}`);

    // Wait for Pods to be ready (simplified logic)
    console.log('⏳ Waiting for Pods to be ready...');
    await new Promise(resolve => setTimeout(resolve, 5000)); // Simulating a wait

    // --- Step B: Create the ClusterIP Service ---
    console.log('2. Creating ClusterIP Service...');
    const serviceResult = await k8sApi.createNamespacedService(
      APP_CONFIG.namespace,
      serviceManifest
    );
    
    console.log(`✅ Service created: ${serviceResult.body.metadata?.name}`);
    console.log(`📍 ClusterIP Address: ${serviceResult.body.spec?.clusterIP}`);
    console.log(`🔗 Internal Endpoint: ${serviceResult.body.metadata?.name}.${APP_CONFIG.namespace}.svc.cluster.local:${serviceResult.body.spec?.ports?.[0].port}`);

    console.log('\n🎉 Deployment Complete. The service is now accessible internally via ClusterIP.');
    console.log('   Note: To access this from outside the cluster, you would change type to NodePort or LoadBalancer.');

  } catch (error) {
    console.error('❌ Error during deployment:', (error as any).body?.message || error);
  }
}

// Execute the script
deployService();
