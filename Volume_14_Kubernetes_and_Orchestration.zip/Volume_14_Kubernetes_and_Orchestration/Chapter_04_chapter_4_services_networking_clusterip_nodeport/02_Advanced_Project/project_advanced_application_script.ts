/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// app/chat/page.tsx
// Target: Next.js 14+ (App Router)
// Framework: React Server Components (RSC) + Client Components

import { Suspense } from 'react';
import ChatInterface from './_components/ChatInterface';

/**
 * @description
 * SERVER COMPONENT: Data Fetching in SCs.
 * This component runs exclusively on the server. It performs the initial data fetching
 * to hydrate the page with context before sending HTML to the client.
 *
 * NETWORKING CONCEPT (Kubernetes ClusterIP):
 * In a K8s cluster, the AI Backend Service is exposed internally via ClusterIP.
 * The DNS name 'http://ai-backend-service:8000' resolves to the stable internal IP.
 * This allows the Next.js server pod to fetch context without exposing the AI service
 * to the public internet.
 */
async function getInitialSystemContext() {
  // In a real K8s deployment, this URL is the internal ClusterIP service name.
  // For local development, we might use an environment variable.
  const internalAiServiceUrl = process.env.AI_SERVICE_INTERNAL_URL || 'http://localhost:8000';

  try {
    const res = await fetch(`${internalAiServiceUrl}/v1/context`, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
        // Add internal auth headers if required by the AI service
        'X-Internal-Secret': process.env.INTERNAL_SECRET || 'dev-secret',
      },
      // Next.js data fetching cache options
      next: { revalidate: 3600 }, // Cache for 1 hour
    });

    if (!res.ok) {
      throw new Error(`Failed to fetch context: ${res.statusText}`);
    }

    return res.json();
  } catch (error) {
    console.error('Error fetching initial context:', error);
    // Return fallback context to ensure the UI still renders
    return { prompt: 'You are a helpful assistant.', version: 'v1.0' };
  }
}

export default async function ChatPage() {
  // 1. Fetch initial data on the server (Data Fetching in SCs)
  const initialContext = await getInitialSystemContext();

  return (
    <main className="flex min-h-screen flex-col items-center justify-between p-24 bg-gray-50">
      <div className="z-10 w-full max-w-5xl items-center justify-between font-mono text-sm">
        <header className="mb-8">
          <h1 className="text-4xl font-bold text-gray-900">AI Assistant Cluster</h1>
          <p className="text-gray-600 mt-2">
            Context loaded: {initialContext.version} | Mode: Internal Service Mesh
          </p>
        </header>

        {/* 
          Suspense boundary allows the UI to stream in. 
          While the server fetches data, the fallback is shown.
        */}
        <Suspense fallback={<div className="animate-pulse bg-gray-200 h-64 rounded-lg" />}>
          <ChatInterface initialPrompt={initialContext.prompt} />
        </Suspense>
      </div>
    </main>
  );
}
