/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script_part2.ts
// Description: Advanced Application Script
// ==========================================

// app/chat/_components/ChatInterface.tsx
// Target: Client Component (use client)
// Purpose: Handles real-time streaming via SSE and user interaction.

'use client';

import { useState, useRef, useEffect } from 'react';

interface ChatInterfaceProps {
  initialPrompt: string;
}

/**
 * @description
 * CLIENT COMPONENT: Real-time Interaction.
 * Uses Server-Sent Events (SSE) to stream tokens from the backend.
 *
 * NETWORKING CONCEPT (Kubernetes NodePort):
 * The AI Backend Service is exposed to the external world via NodePort.
 * The client (browser) connects to the Node IP and the high port (e.g., 30000-32767).
 * In a real scenario, this might be an Ingress or LoadBalancer, but NodePort
 * demonstrates the basic external exposure concept.
 */
export default function ChatInterface({ initialPrompt }: ChatInterfaceProps) {
  const [messages, setMessages] = useState<Array<{ role: string; content: string }>>([
    { role: 'system', content: initialPrompt },
  ]);
  const [input, setInput] = useState('');
  const [isStreaming, setIsStreaming] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Auto-scroll to bottom
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim()) return;

    const userMessage = { role: 'user', content: input };
    setMessages((prev) => [...prev, userMessage]);
    setInput('');
    setIsStreaming(true);

    // Construct the external URL for the AI Service
    // In K8s, this would be the NodePort (e.g., http://<node-ip>:30080)
    // or an Ingress hostname.
    const aiServiceUrl = process.env.NEXT_PUBLIC_AI_SERVICE_URL || 'http://localhost:8000';

    try {
      // Initiate SSE connection
      const eventSource = new EventSource(
        `${aiServiceUrl}/v1/chat-stream?prompt=${encodeURIComponent(input)}`
      );

      let accumulatedContent = '';

      // Listener for standard messages
      eventSource.onmessage = (event) => {
        if (event.data === '[DONE]') {
          eventSource.close();
          setIsStreaming(false);
          return;
        }

        try {
          const data = JSON.parse(event.data);
          if (data.content) {
            accumulatedContent += data.content;
            // Update UI with the accumulated stream
            setMessages((prev) => {
              const newMessages = [...prev];
              // Update the last AI message or append a new one
              const lastMsg = newMessages[newMessages.length - 1];
              if (lastMsg.role === 'assistant') {
                lastMsg.content = accumulatedContent;
              } else {
                newMessages.push({ role: 'assistant', content: accumulatedContent });
              }
              return newMessages;
            });
          }
        } catch (e) {
          console.error('Error parsing SSE data', e);
        }
      };

      eventSource.onerror = (error) => {
        console.error('SSE Error:', error);
        eventSource.close();
        setIsStreaming(false);
      };

    } catch (err) {
      console.error('Connection failed:', err);
      setIsStreaming(false);
    }
  };

  return (
    <div className="flex flex-col h-[600px] border border-gray-300 rounded-lg bg-white shadow-sm">
      {/* Message Container */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.map((msg, idx) => (
          <div
            key={idx}
            className={`p-3 rounded-lg max-w-[80%] ${
              msg.role === 'user'
                ? 'bg-blue-100 ml-auto text-blue-900'
                : msg.role === 'system'
                ? 'bg-gray-100 text-gray-600 text-xs'
                : 'bg-green-100 text-green-900'
            }`}
          >
            <div className="font-semibold text-xs uppercase mb-1 opacity-70">
              {msg.role}
            </div>
            <div className="whitespace-pre-wrap">{msg.content}</div>
          </div>
        ))}
        <div ref={messagesEndRef} />
      </div>

      {/* Input Area */}
      <div className="p-4 border-t border-gray-200 bg-gray-50">
        <div className="flex gap-2">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSend()}
            placeholder="Type a message..."
            disabled={isStreaming}
            className="flex-1 p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 disabled:bg-gray-200"
          />
          <button
            onClick={handleSend}
            disabled={isStreaming || !input.trim()}
            className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 disabled:bg-gray-400 transition-colors"
          >
            {isStreaming ? 'Thinking...' : 'Send'}
          </button>
        </div>
      </div>
    </div>
  );
}
