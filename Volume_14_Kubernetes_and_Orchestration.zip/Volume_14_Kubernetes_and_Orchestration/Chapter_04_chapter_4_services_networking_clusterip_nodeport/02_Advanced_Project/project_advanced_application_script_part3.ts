/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script_part3.ts
// Description: Advanced Application Script
// ==========================================

digraph Architecture {
    rankdir=TB;
    splines=ortho;
    
    node [shape=box, style="rounded,filled", fillcolor="#e1f5fe", fontname="Helvetica"];
    
    Client [label="User Browser", fillcolor="#fff3e0"];
    
    subgraph cluster_k8s {
        label="Kubernetes Cluster";
        style="dashed,filled";
        fillcolor="#f3e5f5";
        
        NextJS_Pod [label="Next.js Pod\n(Next.js App Router)", fillcolor="#e8f5e9"];
        AI_Pod [label="AI Backend Pod\n(Python/FastAPI)", fillcolor="#e8f5e9"];
        
        // Services
        NodePort_Svc [label="NodePort Service\n(External Access)", shape="ellipse", fillcolor="#b3e5fc"];
        ClusterIP_Svc [label="ClusterIP Service\n(Internal Only)", shape="ellipse", fillcolor="#b2dfdb"];
    }

    // Connections
    Client -> NodePort_Svc [label="1. Chat Request (HTTP/SSE)\nPort: 30080", color="#ff9800", penwidth=2];
    NodePort_Svc -> AI_Pod [label="2. Route to Pod", color="#ff9800", style="dashed"];
    
    NextJS_Pod -> ClusterIP_Svc [label="3. Initial Context Fetch\n(Internal DNS)", color="#4caf50", penwidth=2];
    ClusterIP_Svc -> AI_Pod [label="4. Secure Internal Traffic", color="#4caf50", style="dashed"];
    
    // Feedback loop for streaming
    AI_Pod -> Client [label="5. Stream Tokens (SSE)", color="#ff9800", dir=back, style="dashed"];
}
