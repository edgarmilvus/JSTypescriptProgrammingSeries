/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part11.ts
// Description: Solutions and Explanations
// ==========================================

digraph ServiceMesh {
    rankdir=TB;
    node [shape=box];

    // External Traffic
    Client [shape=ellipse, label="External Client"];

    // Services (Ellipses)
    subgraph cluster_services {
        rank=same;
        S_Frontend [shape=ellipse, label="Frontend Service (ClusterIP)"];
        S_Pre [shape=ellipse, label="Preprocessing Service (ClusterIP)"];
        S_InfV1 [shape=ellipse, label="Inference Service (ClusterIP)"];
        S_InfV2 [shape=ellipse, label="Inference-v2 Service (ClusterIP)"];
        S_Post [shape=ellipse, label="Postprocessing Service (ClusterIP)"];
    }

    // Pods (Rectangles)
    P_Frontend [label="Frontend Pod"];
    P_Pre [label="Preprocessing Pod"];
    P_InfV1 [label="Inference Pod (v1)"];
    P_InfV2 [label="Inference Pod (v2)"];
    P_Post [label="Postprocessing Pod"];

    // Connections
    Client -> S_Frontend [label="HTTP/80"];
    S_Frontend -> P_Frontend;

    P_Frontend -> S_Pre [label="HTTP/8080"];
    S_Pre -> P_Pre;

    // Traffic Splitting Logic
    P_Pre -> S_InfV1 [label="HTTP/8501 (50%)", style=dashed];
    P_Pre -> S_InfV2 [label="HTTP/8501 (50%)", style=dashed];
    
    S_InfV1 -> P_InfV1;
    S_InfV2 -> P_InfV2;

    P_InfV1 -> S_Post [label="HTTP/8080"];
    P_InfV2 -> S_Post [label="HTTP/8080"];
    S_Post -> P_Post;
}
