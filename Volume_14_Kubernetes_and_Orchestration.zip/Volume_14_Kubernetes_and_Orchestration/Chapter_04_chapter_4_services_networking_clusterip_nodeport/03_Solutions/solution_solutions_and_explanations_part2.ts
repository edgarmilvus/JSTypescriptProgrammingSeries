/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

import express, { Request, Response } from 'express';
import axios from 'axios';

const app = express();
const PORT = 3000;

// Retrieve the User Service URL from environment variables
// Defaults to localhost for local testing, but K8s will inject the service name
const USER_SERVICE_URL = process.env.USER_SERVICE_URL || 'http://localhost:3000';

app.get('/validate/:id', async (req: Request, res: Response) => {
  const { id } = req.params;

  try {
    // Make internal HTTP request using the service name
    const response = await axios.get(`${USER_SERVICE_URL}/users/${id}`);
    
    if (response.data) {
      return res.json({ status: 'valid' });
    }
  } catch (error: any) {
    console.error(`Error fetching user ${id}:`, error.message);
    return res.json({ status: 'invalid' });
  }
});

app.listen(PORT, () => {
  console.log(`Auth Service running on port ${PORT}`);
});
