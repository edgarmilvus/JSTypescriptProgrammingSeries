/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part9.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState, useEffect } from 'react';

interface Metrics {
  loss: number;
  epoch: number;
}

const MetricsFetcher: React.FC = () => {
  const [metrics, setMetrics] = useState<Metrics | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  // FQDN for cross-namespace access: service.namespace.svc.cluster.local
  const METRICS_URL = "http://ai-training-service.training-ns.svc.cluster.local:9090/metrics";

  useEffect(() => {
    const fetchMetrics = async () => {
      try {
        const response = await fetch(METRICS_URL);
        if (!response.ok) throw new Error('Failed to fetch metrics');
        
        // Assuming the API returns JSON like { "loss": 0.05, "epoch": 10 }
        const data = await response.json();
        setMetrics(data);
      } catch (err: any) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };

    fetchMetrics();
    // Optional: Set interval for real-time updates
    const interval = setInterval(fetchMetrics, 5000);
    return () => clearInterval(interval);
  }, []);

  if (loading) return <div>Loading metrics...</div>;
  if (error) return <div style={{ color: 'red' }}>Error: {error}</div>;

  return (
    <div className="metrics-panel">
      <h3>AI Training Status</h3>
      {metrics ? (
        <ul>
          <li>Loss: {metrics.loss}</li>
          <li>Epoch: {metrics.epoch}</li>
        </ul>
      ) : (
        <p>No data available</p>
      )}
    </div>
  );
};

export default MetricsFetcher;
