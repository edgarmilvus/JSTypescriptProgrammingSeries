/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

// config/appConfig.ts
/**
 * @fileoverview Application Configuration Loader
 * 
 * This module demonstrates how to consume Kubernetes ConfigMaps and Secrets
 * injected as environment variables into a Node.js process.
 * 
 * It uses Zod for runtime validation to prevent "hallucinated" or missing
 * configuration errors common in dynamic environments.
 */

import { z } from 'zod';

// 1. Define the Schema
// We explicitly define what we expect from the Kubernetes environment.
// This separates the concept of "ConfigMap data" from "Secret data".
const AppConfigSchema = z.object({
  // Non-sensitive ConfigMap values
  NODE_ENV: z.enum(['development', 'production', 'test']).default('production'),
  API_BASE_URL: z.string().url().min(1),
  FEATURE_FLAG_AI_CHAT: z.enum(['true', 'false']).transform((val) => val === 'true'),
  
  // Sensitive Secret values
  // Note: In Kubernetes, these are injected as strings, but we treat them as secrets.
  DATABASE_URL: z.string().min(1),
  OPENAI_API_KEY: z.string().min(1).startsWith('sk-'), // Basic validation pattern
});

// 2. Infer the TypeScript Type
// This creates a static type definition based on our schema for type safety.
export type AppConfig = z.infer<typeof AppConfigSchema>;

/**
 * Loads and validates the application configuration from process environment.
 * 
 * @throws {Error} If required environment variables are missing or invalid.
 * @returns {AppConfig} The validated configuration object.
 */
export function loadConfig(): AppConfig {
  // 3. Parse the Environment
  // We pass process.env to the schema. Zod will coerce types and throw errors
  // if validation fails.
  const result = AppConfigSchema.safeParse(process.env);

  if (!result.success) {
    console.error('❌ Configuration Error: Invalid environment variables.');
    console.error(JSON.stringify(result.error.format(), null, 2));
    
    // In a Kubernetes environment, this crash is intentional.
    // It triggers a restart loop (CrashLoopBackOff) until the config is fixed,
    // preventing the app from running in an undefined state.
    process.exit(1);
  }

  return result.data;
}

// 4. Singleton Instance
// We export a frozen instance to ensure the config is loaded once and immutable
// throughout the application lifecycle.
export const config = Object.freeze(loadConfig());
