/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// pages/api/summarize.ts
// Next.js API Route for AI Text Summarization with Dynamic Config Loading

import type { NextApiRequest, NextApiResponse } from 'next';
import { Pinecone } from '@pinecone-database/pinecone';

/**
 * @interface AppConfig
 * @description Represents the non-sensitive configuration (ConfigMap equivalent).
 * These values can be safely committed to source control (except in strict security models).
 */
interface AppConfig {
  modelName: string;
  temperature: number;
  enableDebugLogging: boolean;
}

/**
 * @interface AppSecrets
 * @description Represents sensitive configuration (Secret equivalent).
 * These values MUST be injected at runtime and never committed.
 */
interface AppSecrets {
  pineconeApiKey: string;
  pineconeEnvironment: string;
  pineconeIndexName: string;
}

/**
 * @interface AppState
 * @description Immutable state structure for the application context.
 * Using immutable state management ensures that configuration objects
 * are not mutated accidentally during request processing.
 */
interface AppState {
  config: AppConfig;
  secrets: AppSecrets;
  initializedAt: Date;
}

/**
 * @class ConfigurationService
 * @description A singleton service to load and validate configuration.
 * This mimics the Kubernetes init-container pattern where config is loaded
 * before the main application starts.
 */
class ConfigurationService {
  private static instance: ConfigurationService;
  public state: AppState;

  private constructor() {
    // 1. Load ConfigMap-like values (Non-sensitive)
    const config: AppConfig = {
      modelName: process.env.MODEL_NAME || 'gpt-4-turbo-preview',
      temperature: parseFloat(process.env.MODEL_TEMPERATURE || '0.7'),
      enableDebugLogging: process.env.DEBUG_LOGGING === 'true',
    };

    // 2. Load Secret-like values (Sensitive)
    // In K8s, these are mounted as files or injected as env vars from Secrets.
    // We validate their presence strictly.
    const pineconeApiKey = process.env.PINECONE_API_KEY;
    if (!pineconeApiKey) {
      throw new Error('Missing PINECONE_API_KEY. Ensure this is mounted via Kubernetes Secrets.');
    }

    const secrets: AppSecrets = {
      pineconeApiKey,
      pineconeEnvironment: process.env.PINECONE_ENVIRONMENT || 'us-west1-gcp',
      pineconeIndexName: process.env.PINECONE_INDEX_NAME || 'summary-vectors',
    };

    // 3. Freeze the state (Immutable State Management)
    // Once loaded, the configuration should not change during the lifecycle of the process.
    this.state = Object.freeze({
      config,
      secrets,
      initializedAt: new Date(),
    });
  }

  /**
   * @method getInstance
   * @description Returns the singleton instance of the ConfigurationService.
   */
  public static getInstance(): ConfigurationService {
    if (!ConfigurationService.instance) {
      ConfigurationService.instance = new ConfigurationService();
    }
    return ConfigurationService.instance;
  }
}

/**
 * @function initializePinecone
 * @description Initializes the Pinecone Client using the loaded secrets.
 * This abstracts the client instantiation logic.
 * @param {AppSecrets} secrets - The sensitive configuration object.
 * @returns {Promise<Pinecone>} - The initialized Pinecone client instance.
 */
const initializePinecone = async (secrets: AppSecrets): Promise<Pinecone> => {
  try {
    const pc = new Pinecone({
      apiKey: secrets.pineconeApiKey,
      environment: secrets.pineconeEnvironment,
    });
    
    // Test connection (optional but recommended)
    await pc.listIndexes();
    return pc;
  } catch (error) {
    console.error('Failed to initialize Pinecone:', error);
    throw new Error('Dependency Failure: Pinecone');
  }
};

/**
 * @function handler
 * @description The main Next.js API Route Handler.
 * It utilizes the ConfigurationService to inject dependencies dynamically.
 */
export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse
) {
  // 1. Load Immutable Configuration
  // In a real K8s pod, this happens once at pod startup.
  const service = ConfigurationService.getInstance();
  const { config, secrets } = service.state;

  // 2. Log initialization (Conditional based on ConfigMap flag)
  if (config.enableDebugLogging) {
    console.log(`[${service.state.initializedAt.toISOString()}] Request received. Using model: ${config.modelName}`);
  }

  // 3. Handle Request Methods
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method Not Allowed' });
  }

  const { text } = req.body;

  if (!text || typeof text !== 'string') {
    return res.status(400).json({ error: 'Invalid input: "text" is required.' });
  }

  try {
    // 4. Initialize External Services (Dependency Injection)
    // We pass the secrets to the initializer. In a complex app, this would be a dependency container.
    const pineconeClient = await initializePinecone(secrets);

    // 5. Simulate AI Processing & Vectorization
    // In a real scenario, this would call an LLM (e.g., OpenAI) and then store the result.
    // We simulate generating a vector embedding for the summary.
    const mockEmbedding: number[] = Array.from({ length: 1536 }, () => Math.random());

    // 6. Immutable Data Transformation
    // We create a new object for the metadata rather than mutating the request body.
    const metadata = Object.freeze({
      source: 'api-summarizer',
      model: config.modelName,
      timestamp: new Date().toISOString(),
    });

    // 7. Upsert to Vector Database
    // Using the client initialized with secrets.
    const indexName = secrets.pineconeIndexName;
    const index = pineconeClient.Index(indexName);

    await index.upsert([
      {
        id: `summary-${Date.now()}`,
        values: mockEmbedding,
        metadata: metadata,
      },
    ]);

    // 8. Return Response
    // We do NOT return secrets, only the public config info for debugging if enabled.
    return res.status(200).json({
      success: true,
      summary: `Processed text of length ${text.length}.`,
      configUsed: config.enableDebugLogging ? config.modelName : undefined,
    });

  } catch (error) {
    console.error('API Error:', error);
    return res.status(500).json({ error: 'Internal Server Error' });
  }
}
