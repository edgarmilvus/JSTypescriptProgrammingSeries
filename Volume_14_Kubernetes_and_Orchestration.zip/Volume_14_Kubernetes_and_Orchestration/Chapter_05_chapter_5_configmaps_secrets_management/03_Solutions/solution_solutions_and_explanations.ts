/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// verify-config.ts
// Purpose: To confirm that the Kubernetes ConfigMap has been successfully mounted
// as environment variables within the running container.

// 1. Define an interface for expected configuration
interface AppConfig {
  DB_HOST: string;
  DB_PORT: string;
  REDIS_URL: string;
  LOG_LEVEL: string;
}

// 2. Create a function to validate and log the configuration
function validateAndLogConfig(): void {
  // Extract expected variables from process.env
  const {
    DB_HOST,
    DB_PORT,
    REDIS_URL,
    LOG_LEVEL
  } = process.env;

  // Validate that all required variables are present
  const requiredKeys: (keyof AppConfig)[] = ['DB_HOST', 'DB_PORT', 'REDIS_URL', 'LOG_LEVEL'];
  const missingKeys = requiredKeys.filter(key => !process.env[key]);

  if (missingKeys.length > 0) {
    console.error(`❌ Configuration Error: Missing environment variables: ${missingKeys.join(', ')}`);
    process.exit(1); // Exit with error code if config is incomplete
  }

  // Construct the configuration object
  const config: AppConfig = {
    DB_HOST: DB_HOST!,
    DB_PORT: DB_PORT!,
    REDIS_URL: REDIS_URL!,
    LOG_LEVEL: LOG_LEVEL!
  };

  // Log the configuration in a structured JSON format
  console.log('✅ Application Configuration Loaded Successfully:');
  console.log(JSON.stringify(config, null, 2));
}

// 3. Execute the validation
validateAndLogConfig();
