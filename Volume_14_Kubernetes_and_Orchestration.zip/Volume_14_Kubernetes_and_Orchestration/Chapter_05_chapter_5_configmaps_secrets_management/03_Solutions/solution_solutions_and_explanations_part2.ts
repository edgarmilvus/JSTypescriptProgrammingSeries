/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

// secret-loader.ts
// Purpose: To securely load credentials from mounted secret files
// without exposing them in logs or stack traces.

import * as fs from 'fs/promises';
import * as path from 'path';

// 1. Define an interface for the loaded secrets
interface Secrets {
  pgPassword: string;
  apiKey: string;
}

// 2. Implement the secure loader function
export async function loadSecrets(): Promise<Secrets> {
  // Define the base directory where secrets are mounted
  const secretsDir = '/etc/secrets';

  try {
    // Read files asynchronously and trim whitespace/newlines
    // Note: We use path.join for cross-platform safety, though Linux paths work in containers
    const pgPassword = (await fs.readFile(path.join(secretsDir, 'pg_password'), 'utf8')).trim();
    const apiKey = (await fs.readFile(path.join(secretsDir, 'api_key'), 'utf8')).trim();

    // Basic validation to ensure files aren't empty
    if (!pgPassword || !apiKey) {
      throw new Error('Secret file is empty or could not be read.');
    }

    return {
      pgPassword,
      apiKey
    };
  } catch (error) {
    // Secure error handling: Log the type of error but NOT the secret values
    if (error instanceof Error) {
      console.error(`Failed to load secrets: ${error.message}`);
    } else {
      console.error('An unknown error occurred while loading secrets.');
    }
    // Re-throw the error to stop the application if secrets are missing
    throw error;
  }
}
