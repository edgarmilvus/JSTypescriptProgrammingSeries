/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

// DashboardPage.tsx
'use client';

import { useState, useEffect } from 'react';

// 1. Define the expected environment variables
// In Next.js, public environment variables are accessed via process.env
const WELCOME_MESSAGE = process.env.NEXT_PUBLIC_WELCOME_MESSAGE || "Welcome to the Dashboard";
const SHOW_AI_WIDGET = process.env.NEXT_PUBLIC_SHOW_AI_WIDGET === 'true';

export default function DashboardPage() {
  // 2. Implement state and rendering logic
  // We use state to track if the component has mounted to handle hydration mismatches.
  // Environment variables are static, but we need to ensure the client-side render matches the server.
  
  const [isMounted, setIsMounted] = useState(false);

  useEffect(() => {
    // Set mounted to true only after the component has hydrated on the client
    setIsMounted(true);
  }, []);

  // If we need to strictly ensure server/client match for the boolean check:
  // The variable SHOW_AI_WIDGET is determined at build time (static) or runtime (server/client).
  // Since it's NEXT_PUBLIC_, it is embedded in the JS bundle sent to the client.
  // The hydration mismatch risk is low here because the value is constant, 
  // but using a mounted check is a robust pattern for dynamic client logic.

  if (!isMounted) {
    // Return a loading state or null to match the initial server render exactly
    // This prevents hydration errors if the server and client calculation differed (unlikely here, but good practice).
    return <div>Loading Dashboard...</div>;
  }

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-4">{WELCOME_MESSAGE}</h1>
      
      {/* Conditional rendering based on the environment variable */}
      {SHOW_AI_WIDGET && (
        <div className="border p-4 bg-gray-50 rounded">
          <h2 className="text-lg font-semibold">AI Analytics Widget Area</h2>
          <p>Advanced metrics and insights would appear here.</p>
        </div>
      )}
      
      {!SHOW_AI_WIDGET && (
        <div className="text-sm text-gray-500">
          (AI Analytics feature is currently disabled)
        </div>
      )}
    </div>
  );
}
