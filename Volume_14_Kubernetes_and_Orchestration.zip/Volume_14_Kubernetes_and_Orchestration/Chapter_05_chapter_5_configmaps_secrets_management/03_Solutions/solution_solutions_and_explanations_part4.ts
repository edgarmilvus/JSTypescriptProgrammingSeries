/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

// drift-detector.ts
// Purpose: To detect configuration drift between the declared ConfigMap
// and the actual environment variables running in production pods.

import * as yaml from 'js-yaml';
import * as fs from 'fs';
import { execSync } from 'child_process';

// 1. Define types for the configuration data and comparison results
type ConfigMapData = Record<string, string>;
type DriftReport = {
  podName: string;
  variable: string;
  expectedValue: string;
  actualValue: string;
};

// 2. Implement the core logic
async function detectDrift(): Promise<DriftReport[]> {
  const driftReport: DriftReport[] = [];

  // a. Parse source-config.yaml
  // Assuming source-config.yaml contains a standard Kubernetes ConfigMap YAML structure
  try {
    const fileContents = fs.readFileSync('./source-config.yaml', 'utf8');
    const sourceYaml = yaml.load(fileContents) as any;
    
    // Extract the data section (key-value pairs)
    // We assume the file structure is: apiVersion: v1, kind: ConfigMap, data: { ... }
    const sourceData: ConfigMapData = sourceYaml.data || {};
    
    console.log(`Source of Truth loaded. Expected ConfigMap keys: ${Object.keys(sourceData).join(', ')}`);

    // b. Query pods for environment variables
    // We filter by label app=legacy-app and output specific environment variables.
    // Using kubectl to fetch pod names first.
    const podListCommand = `kubectl get pods -l app=legacy-app -o jsonpath="{.items[*].metadata.name}"`;
    const podNamesOutput = execSync(podListCommand, { encoding: 'utf8' }).trim();
    
    if (!podNamesOutput) {
      console.warn("No pods found matching label app=legacy-app.");
      return [];
    }

    const podNames = podNamesOutput.split(' ');

    for (const podName of podNames) {
      console.log(`\nChecking pod: ${podName}`);
      
      // For each expected key in sourceData, check the actual env var in the pod
      for (const [key, expectedValue] of Object.entries(sourceData)) {
        // Construct command to get specific env var value from the pod
        // We use 'env' command inside the pod to get the variable.
        // Note: This assumes the pod has a shell and the 'env' command available.
        const getEnvCommand = `kubectl exec ${podName} -- sh -c "echo \\$${key}"`;
        
        try {
          const actualValue = execSync(getEnvCommand, { encoding: 'utf8' }).trim();

          // c. Compare and collect drift
          if (actualValue !== expectedValue) {
            driftReport.push({
              podName,
              variable: key,
              expectedValue,
              actualValue: actualValue || "<UNSET>" // Handle empty strings or unset variables
            });
          }
        } catch (error) {
          console.error(`Failed to query variable ${key} on pod ${podName}`);
        }
      }
    }

    return driftReport;

  } catch (error) {
    console.error("Error during drift detection:", error);
    return [];
  }
}

// 3. Execute and log results
detectDrift().then(report => {
  if (report.length > 0) {
    console.error('\n❌ Configuration Drift Detected:');
    console.table(report);
  } else {
    console.log('\n✅ All pods are in sync with the source configuration.');
  }
});
