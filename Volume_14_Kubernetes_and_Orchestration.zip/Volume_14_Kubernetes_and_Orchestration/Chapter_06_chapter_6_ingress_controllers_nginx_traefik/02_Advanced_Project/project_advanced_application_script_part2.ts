/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script_part2.ts
// Description: Advanced Application Script
// ==========================================

// app/api/analyze/route.ts
// Target Runtime: Edge (Optimized for low latency and streaming)
export const runtime = 'edge';

import { NextResponse } from 'next/server';
import { streamText } from 'ai';
import { createOpenAI } from '@ai-sdk/openai';

// -----------------------------------------------------------------------------
// 1. Configuration & Constants
// -----------------------------------------------------------------------------
// In a real SaaS app, these would be stored in environment variables (Kubernetes Secrets).
// The OPENAI_API_KEY is injected into the pod via the Kubernetes Secret manifest.
const OPENAI_API_KEY = process.env.OPENAI_API_KEY || '';

// Initialize the OpenAI provider with the Edge-compatible SDK.
// Note: We use a custom provider instance to ensure compatibility with the Edge runtime.
const openai = createOpenAI({
  apiKey: OPENAI_API_KEY,
  compatibility: 'experimental', // Ensures streaming works with Edge fetch
});

// -----------------------------------------------------------------------------
// 2. POST Request Handler
// -----------------------------------------------------------------------------
/**
 * Handles incoming POST requests to analyze documents.
 * 
 * Why Edge Runtime?
 * - Low Latency: Edge functions have faster cold starts than standard Node.js serverless functions.
 * - Streaming: The Edge runtime handles streaming responses (SSE/ReadableStream) natively and efficiently.
 * - Global Distribution: If deployed via Vercel or a global Edge network, logic runs closer to the user.
 * 
 * @param {Request} request - The incoming HTTP request object.
 * @returns {Promise<NextResponse>} - A streaming response or an error message.
 */
export async function POST(request: Request) {
  try {
    // Parse the incoming JSON body.
    // In a real app, we would validate this input using a schema library (e.g., Zod).
    const { documentText, prompt } = await request.json();

    if (!documentText || !prompt) {
      return NextResponse.json(
        { error: 'Missing documentText or prompt fields.' },
        { status: 400 }
      );
    }

    // Construct the system prompt for the AI model.
    const systemPrompt = `
      You are an expert document analyst. 
      Analyze the following document and respond to the user's prompt.
      Document: "${documentText}"
    `;

    // -----------------------------------------------------------------------------
    // 3. Model Streaming Logic
    // -----------------------------------------------------------------------------
    // The 'streamText' function from the Vercel AI SDK handles the complex logic of:
    // 1. Connecting to the LLM provider (OpenAI).
    // 2. Receiving tokens as they are generated.
    // 3. Converting them into a standard ReadableStream.
    const result = await streamText({
      model: openai('gpt-4-turbo-preview'),
      system: systemPrompt,
      prompt: prompt,
      temperature: 0.7,
    });

    // -----------------------------------------------------------------------------
    // 4. Response Streaming
    // -----------------------------------------------------------------------------
    // We convert the AI SDK's result into a Next.js Response.
    // This creates a Server-Sent Events (SSE) stream that the client can consume.
    // The Ingress controller (NGINX/Traefik) buffers this stream efficiently,
    // ensuring the client receives data immediately without waiting for the full generation.
    return result.toAIStreamResponse();
    
  } catch (error) {
    console.error('Error in AI Analysis API:', error);
    
    // Return a structured error response.
    // In a production SaaS, we might log this to a centralized service (e.g., Datadog).
    return NextResponse.json(
      { error: 'Internal Server Error during analysis.' },
      { status: 500 }
    );
  }
}
