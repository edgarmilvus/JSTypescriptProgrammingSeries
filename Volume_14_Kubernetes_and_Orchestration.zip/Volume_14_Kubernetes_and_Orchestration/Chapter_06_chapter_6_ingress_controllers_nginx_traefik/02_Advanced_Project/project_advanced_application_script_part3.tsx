/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script_part3.tsx
// Description: Advanced Application Script
// ==========================================

// app/components/DocumentAnalyzer.tsx
'use client';

import { useState, useRef, useEffect } from 'react';

export default function DocumentAnalyzer() {
  const [documentText, setDocumentText] = useState('');
  const [userPrompt, setUserPrompt] = useState('');
  const [analysisResult, setAnalysisResult] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const abortControllerRef = useRef<AbortController | null>(null);

  // -----------------------------------------------------------------------------
  // 1. Stream Handling Logic
  // -----------------------------------------------------------------------------
  const handleAnalyze = async () => {
    if (!documentText || !userPrompt) return;

    setIsLoading(true);
    setAnalysisResult('');
    
    // Initialize AbortController to allow canceling the request
    abortControllerRef.current = new AbortController();

    try {
      const response = await fetch('/api/analyze', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          documentText,
          prompt: userPrompt,
        }),
        signal: abortControllerRef.current.signal,
      });

      if (!response.ok) {
        throw new Error('Network response was not ok');
      }

      // -----------------------------------------------------------------------------
      // 2. Reading the Stream
      // -----------------------------------------------------------------------------
      // The response body is a ReadableStream. We read it chunk by chunk.
      const reader = response.body?.getReader();
      const decoder = new TextDecoder();

      if (reader) {
        while (true) {
          const { done, value } = await reader.read();
          if (done) break;

          // Decode the chunk (Uint8Array) to a string
          const chunk = decoder.decode(value, { stream: true });
          
          // The Vercel AI SDK streams JSON objects.
          // We accumulate the text content to update the UI.
          // Note: In a complex app, you might parse specific JSON fields.
          setAnalysisResult((prev) => prev + chunk);
        }
      }
    } catch (error) {
      if (error instanceof Error && error.name !== 'AbortError') {
        console.error('Stream error:', error);
        setAnalysisResult('Error processing document.');
      }
    } finally {
      setIsLoading(false);
      abortControllerRef.current = null;
    }
  };

  const handleCancel = () => {
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
      setIsLoading(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto p-6 space-y-6">
      <h1 className="text-2xl font-bold">AI Document Analyzer</h1>
      
      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium mb-2">Document Text</label>
          <textarea
            className="w-full h-40 p-3 border rounded-md"
            value={documentText}
            onChange={(e) => setDocumentText(e.target.value)}
            placeholder="Paste your document here..."
          />
        </div>
        <div>
          <label className="block text-sm font-medium mb-2">Analysis Prompt</label>
          <input
            type="text"
            className="w-full p-3 border rounded-md mb-4"
            value={userPrompt}
            onChange={(e) => setUserPrompt(e.target.value)}
            placeholder="e.g., Summarize key points"
          />
          
          <div className="flex gap-2">
            <button
              onClick={handleAnalyze}
              disabled={isLoading}
              className="px-4 py-2 bg-blue-600 text-white rounded disabled:bg-gray-400"
            >
              {isLoading ? 'Analyzing...' : 'Analyze'}
            </button>
            
            {isLoading && (
              <button
                onClick={handleCancel}
                className="px-4 py-2 bg-red-500 text-white rounded"
              >
                Cancel
              </button>
            )}
          </div>
        </div>
      </div>

      {/* -----------------------------------------------------------------------------
      // 3. Result Display
      // ----------------------------------------------------------------------------- */}
      <div className="mt-6">
        <h2 className="text-lg font-semibold mb-2">Analysis Result</h2>
        <div className="w-full p-4 bg-gray-50 border rounded-md min-h-[150px] whitespace-pre-wrap">
          {analysisResult || <span className="text-gray-400">Result will appear here...</span>}
        </div>
      </div>
    </div>
  );
}
