/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

# profile-ingress.yaml
apiVersion: networking.k8s.io/v1
kind: Ingress
metadata:
  name: profile-ingress
  namespace: default
  annotations:
    # 1. Ingress Class Specification
    kubernetes.io/ingress.class: "nginx"
    
    # 2. Security Annotation for Internal-Only Access
    # This injects raw NGINX config into the location block for the specific path.
    # It denies all requests to /api/v1/admin, effectively making it internal-only
    # if the cluster network policies allow internal traffic but block external.
    nginx.ingress.kubernetes.io/configuration-snippet: |
      location ~* "^/api/v1/admin" {
        deny all;
        return 403;
      }
spec:
  rules:
  - host: profiles.example.com
    http:
      paths:
      # Path-Based Routing for the root path
      - path: /
        pathType: Prefix
        backend:
          service:
            name: profile-service
            port:
              number: 3000
