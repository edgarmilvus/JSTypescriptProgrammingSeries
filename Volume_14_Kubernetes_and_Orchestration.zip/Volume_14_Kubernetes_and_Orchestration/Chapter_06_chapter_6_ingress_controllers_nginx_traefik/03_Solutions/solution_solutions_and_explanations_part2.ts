/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

# ai-cluster-ingress.yaml
apiVersion: networking.k8s.io/v1
kind: Ingress
metadata:
  name: ai-cluster-ingress
  namespace: default
  annotations:
    # 1. Backend Protocol Configuration
    # Explicitly set to HTTP/1.1 as required
    nginx.ingress.kubernetes.io/backend-protocol: "HTTP"
    
    # 2. Authentication Configuration
    # This annotation applies Basic Auth to the specific Ingress Path
    # referencing the existing secret 'gen-auth-secret'
    nginx.ingress.kubernetes.io/auth-type: basic
    nginx.ingress.kubernetes.io/auth-secret: gen-auth-secret
    nginx.ingress.kubernetes.io/auth-path: /generate # Applies auth only to this path context
spec:
  rules:
  - host: ai-cluster.example.com
    http:
      paths:
      # Route for Text Generation (Authenticated)
      - path: /generate
        pathType: Prefix
        backend:
          service:
            name: text-generation-service
            port:
              number: 8080
      
      # Route for Embeddings (Unauthenticated)
      - path: /embed
        pathType: Prefix
        backend:
          service:
            name: embedding-service
            port:
              number: 5000
