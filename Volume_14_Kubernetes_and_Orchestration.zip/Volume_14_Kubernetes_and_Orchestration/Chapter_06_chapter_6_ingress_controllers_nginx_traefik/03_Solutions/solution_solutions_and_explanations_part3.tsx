/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState, useEffect } from 'react';

interface LogEntry {
  id: string;
  status: string;
  tokens: number;
}

const InferenceLogStream: React.FC = () => {
  // State to store the array of log entries
  const [logs, setLogs] = useState<LogEntry[]>([]);
  // State to track connection errors (optional but good practice)
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    // Establish the SSE connection
    const eventSource = new EventSource('/api/inference/logs');

    // Handler for incoming messages
    const handleMessage = (event: MessageEvent) => {
      try {
        // Parse the JSON data from the event
        const parsedData: LogEntry = JSON.parse(event.data);
        
        // Update state by appending the new log entry
        // Using functional update to ensure we have the latest state
        setLogs((prevLogs) => [...prevLogs, parsedData]);
      } catch (e) {
        console.error("Failed to parse log data:", e);
      }
    };

    // Handler for errors
    const handleError = (event: Event) => {
      setError("Connection lost or error occurred.");
      console.error("SSE Error:", event);
    };

    // Attach event listeners
    eventSource.addEventListener('message', handleMessage);
    eventSource.addEventListener('error', handleError);

    // Cleanup function: Runs when component unmounts
    return () => {
      eventSource.removeEventListener('message', handleMessage);
      eventSource.removeEventListener('error', handleError);
      eventSource.close();
    };
  }, []); // Empty dependency array ensures this runs once on mount

  return (
    <div style={{ maxHeight: '400px', overflowY: 'auto', border: '1px solid #ccc', padding: '10px' }}>
      <h3>Real-Time Inference Logs</h3>
      {error && <div style={{ color: 'red' }}>{error}</div>}
      {logs.length === 0 && !error && <p>Waiting for logs...</p>}
      
      <ul style={{ listStyleType: 'none', padding: 0 }}>
        {logs.map((log, index) => (
          <li key={`${log.id}-${index}`} style={{ marginBottom: '5px', borderBottom: '1px solid #eee' }}>
            <strong>ID:</strong> {log.id} | <strong>Status:</strong> {log.status} | <strong>Tokens:</strong> {log.tokens}
          </li>
        ))}
      </ul>
    </div>
  );
};

export default InferenceLogStream;
