/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// lib/helm-config-loader.ts
/**
 * @fileoverview A TypeScript module for loading and validating Helm chart configurations
 *              into a Next.js application context. This ensures type-safe access to
 *              environment variables injected via Kubernetes ConfigMaps or Secrets.
 * 
 * Context: Chapter 7 - Helm Charts. In a real-world scenario, Helm generates a ConfigMap
 * containing the 'values.yaml' data. This script simulates parsing that data structure
 * to configure the application runtime.
 */

import fs from 'fs';
import path from 'path';
import yaml from 'js-yaml'; // Assuming usage of a YAML parser for parsing values.yaml

// -----------------------------------------------------------------------------
// 1. TYPE DEFINITIONS & SCHEMA
// -----------------------------------------------------------------------------

/**
 * Represents the structure of a Helm values.yaml file relevant to a Next.js microservice.
 * We use strict typing to prevent runtime errors caused by malformed configuration.
 */
export interface HelmChartValues {
  replicaCount: number;
  image: {
    repository: string;
    tag: string;
    pullPolicy: 'Always' | 'IfNotPresent' | 'Never';
  };
  service: {
    type: string;
    port: number;
  };
  config: {
    // Mapped from helm/values.yaml -> k8s ConfigMap -> process.env
    databaseUrl: string;
    redisHost: string;
    featureFlags: {
      enableAnalytics: boolean;
      maintenanceMode: boolean;
    };
  };
  resources: {
    limits: {
      cpu: string;
      memory: string;
    };
    requests: {
      cpu: string;
      memory: string;
    };
  };
}

/**
 * Validation schema helper (simplified for this example).
 * In production, use Zod or Joi for runtime validation.
 */
const validateConfig = (data: any): data is HelmChartValues => {
  if (!data || typeof data !== 'object') return false;
  // Basic check for required nested properties
  return (
    typeof data.replicaCount === 'number' &&
    typeof data.config === 'object' &&
    typeof data.config.databaseUrl === 'string'
  );
};

// -----------------------------------------------------------------------------
// 2. CONFIGURATION LOADER LOGIC
// -----------------------------------------------------------------------------

/**
 * Loads Helm values from a file system path (simulating a mounted ConfigMap volume).
 * 
 * Under the Hood:
 * In a Kubernetes Pod, a ConfigMap is often mounted as a volume at /etc/config.
 * This function abstracts the source, allowing it to read from a local file for
 * development or a mounted volume in production.
 * 
 * @param filePath - The path to the values.yaml or JSON file.
 * @returns Parsed configuration object.
 */
async function loadHelmValues(filePath: string): Promise<HelmChartValues> {
  try {
    // Check if file exists (essential for robust startup)
    if (!fs.existsSync(filePath)) {
      throw new Error(`Helm values file not found at: ${filePath}`);
    }

    const fileContent = fs.readFileSync(filePath, 'utf-8');
    
    // Parse YAML (or JSON). 
    // Note: In a real Next.js build, we might parse JSON from a generated ConfigMap.
    const parsedValues = yaml.load(fileContent) as any;

    if (!validateConfig(parsedValues)) {
      throw new Error('Invalid Helm values schema. Check values.yaml structure.');
    }

    return parsedValues;
  } catch (error) {
    console.error('Failed to load Helm configuration:', error);
    // In a critical SaaS app, we might want to exit gracefully or throw to prevent startup
    throw error;
  }
}

/**
 * Hydrates the Node.js process environment variables from the Helm configuration.
 * 
 * Why this matters:
 * Next.js relies on process.env for runtime configuration. By mapping Helm values
 * to these variables, we decouple the code from the infrastructure definition.
 * 
 * @param helmValues - The parsed configuration object.
 */
function hydrateEnvironment(helmValues: HelmChartValues): void {
  // Map generic service config
  process.env.NEXT_PUBLIC_APP_VERSION = helmValues.image.tag;
  process.env.PORT = helmValues.service.port.toString();

  // Map sensitive/infrastructure config (usually injected via Secrets, but mapped here for demo)
  process.env.DATABASE_URL = helmValues.config.databaseUrl;
  process.env.REDIS_HOST = helmValues.config.redisHost;

  // Map feature flags
  process.env.FEATURE_ANALYTICS = helmValues.config.featureFlags.enableAnalytics.toString();
  process.env.MAINTENANCE_MODE = helmValues.config.featureFlags.maintenanceMode.toString();

  console.log(`[Helm Config] Environment hydrated. Replica Count: ${helmValues.replicaCount}`);
}

// -----------------------------------------------------------------------------
// 3. NEXT.JS INTEGRATION & EXPORT
// -----------------------------------------------------------------------------

/**
 * Main entry point for the configuration loader.
 * In a Next.js lifecycle, this could be invoked in `next.config.js` (for build-time)
 * or in a custom server script (for runtime).
 * 
 * @param configPath - Optional path override.
 */
export async function initHelmConfiguration(configPath?: string): Promise<void> {
  // Default path simulates a Kubernetes ConfigMap mount
  const defaultPath = configPath || path.join(process.cwd(), 'helm-values.yaml');
  
  try {
    const helmValues = await loadHelmValues(defaultPath);
    hydrateEnvironment(helmValues);
    
    // Optional: Export the config for direct usage in API routes
    // This avoids re-reading the file repeatedly.
    module.exports.helmConfig = helmValues; 
  } catch (error) {
    // Critical failure handling
    console.error('Initialization failed:', error);
    process.exit(1);
  }
}

// -----------------------------------------------------------------------------
// 4. EXAMPLE USAGE (Mock Execution for Demonstration)
// -----------------------------------------------------------------------------

/**
 * This block demonstrates how the loader would be used in a typical Next.js setup.
 * 
 * Usage Scenario:
 * 1. Create a 'helm-values.yaml' file in the project root.
 * 2. Run this script to validate and inject variables.
 * 3. Use process.env variables in Next.js getServerSideProps or API routes.
 */

// Mock helm-values.yaml content for demonstration purposes
const mockHelmValuesContent = `
replicaCount: 3
image:
  repository: my-registry/nextjs-app
  tag: "v1.2.0"
  pullPolicy: IfNotPresent
service:
  type: ClusterIP
  port: 3000
config:
  databaseUrl: "postgresql://user:pass@postgres-svc:5432/saas_db"
  redisHost: "redis-svc"
  featureFlags:
    enableAnalytics: true
    maintenanceMode: false
resources:
  limits:
    cpu: "500m"
    memory: "512Mi"
  requests:
    cpu: "250m"
    memory: "256Mi"
`;

// (For the sake of this script being runnable, we would write this mock file)
// In a real deployment, this file exists on the filesystem.
const MOCK_FILE_PATH = './temp-helm-values.yaml';

// --- Execution Block ---
(async () => {
  // 1. Setup mock file
  if (!fs.existsSync(MOCK_FILE_PATH)) {
    fs.writeFileSync(MOCK_FILE_PATH, mockHelmValuesContent);
  }

  // 2. Initialize
  console.log('--- Starting Helm Configuration Loader ---');
  await initHelmConfiguration(MOCK_FILE_PATH);

  // 3. Verify Injection
  console.log('\n--- Verification ---');
  console.log('Database URL Injected:', !!process.env.DATABASE_URL);
  console.log('Analytics Flag:', process.env.FEATURE_ANALYTICS);
  
  // 4. Cleanup (Optional)
  fs.unlinkSync(MOCK_FILE_PATH);
})();
