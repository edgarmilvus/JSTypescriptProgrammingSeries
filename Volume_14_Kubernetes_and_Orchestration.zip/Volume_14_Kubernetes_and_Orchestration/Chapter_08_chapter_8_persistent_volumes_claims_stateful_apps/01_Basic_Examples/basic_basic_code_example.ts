/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

// ============================================================
// 1. IMPORTS & TYPE DEFINITIONS
// ============================================================

/**
 * Represents the canonical data structure for our SaaS onboarding agent.
 * This is the "Graph State" that will be passed between all nodes.
 */
interface OnboardingState {
  userId: string;
  userName?: string;
  companySize?: 'startup' | 'enterprise' | 'solo';
  currentStep: 'ask_name' | 'ask_company_size' | 'complete';
  conversationHistory: string[];
}

/**
 * A simple in-memory "database" to simulate persistent storage (e.g., Redis, PostgreSQL).
 * In a real app, this would be an external service.
 */
const mockDatabase: Map<string, OnboardingState> = new Map();

// ============================================================
// 2. CORE STATE MANAGEMENT & PERSISTENCE FUNCTIONS
// ============================================================

/**
 * Simulates saving the Graph State to a persistent store.
 * @param state - The current onboarding state to save.
 * @returns A promise that resolves when the state is saved.
 */
async function saveStateToDb(state: OnboardingState): Promise<void> {
  // In a real-world scenario, this would be an async database call (e.g., `redis.set(...)`)
  mockDatabase.set(state.userId, state);
  console.log(`💾 [DB] State saved for user: ${state.userId}`);
  console.log(`   -> State: ${JSON.stringify(state, null, 2)}`);
  // Simulate network latency
  await new Promise(resolve => setTimeout(resolve, 100));
}

/**
 * Retrieves a previously saved Graph State from the persistent store.
 * This is the "Hydration" step.
 * @param userId - The unique identifier for the user/session.
 * @returns The hydrated OnboardingState, or null if not found.
 */
async function loadStateFromDb(userId: string): Promise<OnboardingState | null> {
  // Simulate async database retrieval
  await new Promise(resolve => setTimeout(resolve, 100));
  
  const savedState = mockDatabase.get(userId);
  if (savedState) {
    console.log(`📂 [DB] State hydrated for user: ${userId}`);
    return savedState;
  }
  console.log(`❌ [DB] No state found for user: ${userId}`);
  return null;
}

// ============================================================
// 3. LANGGRAPH NODES (LOGIC UNITS)
// ============================================================

/**
 * Node 1: Asks for the user's name.
 * This node runs only if the name is not already in the state.
 */
async function askNameNode(state: OnboardingState): Promise<Partial<OnboardingState>> {
  console.log(`\n[Node: askNameNode] Executing...`);
  
  // Check if we already have the name (e.g., from a previous hydrated run)
  if (state.userName) {
    console.log(`   -> Name already known: ${state.userName}. Skipping.`);
    return { currentStep: 'ask_company_size' };
  }

  // In a real app, this would be an API call to an LLM or a direct user input.
  // For this example, we simulate the agent "thinking" and generating a response.
  const response = "Hello! Welcome to our SaaS platform. What should I call you?";
  
  // Update the state with the new information and the next step.
  return {
    currentStep: 'ask_company_size', // The next logical step
    conversationHistory: [...state.conversationHistory, `AI: ${response}`],
  };
}

/**
 * Node 2: Asks for the user's company size.
 * This node runs only if the name is known but the company size is not.
 */
async function askCompanySizeNode(state: OnboardingState): Promise<Partial<OnboardingState>> {
  console.log(`\n[Node: askCompanySizeNode] Executing...`);
  
  // This node's logic is conditional on the state.
  if (!state.userName) {
    // This shouldn't happen if the graph is structured correctly, but it's a safety check.
    throw new Error("Cannot ask for company size without a user name.");
  }

  if (state.companySize) {
    console.log(`   -> Company size already known: ${state.companySize}. Skipping.`);
    return { currentStep: 'complete' };
  }

  const response = `Thanks, ${state.userName}! What's the size of your company? (startup, enterprise, or solo)`;
  
  return {
    currentStep: 'complete', // The final step after this
    conversationHistory: [...state.conversationHistory, `AI: ${response}`],
  };
}

/**
 * Node 3: Completes the onboarding.
 */
async function completeOnboardingNode(state: OnboardingState): Promise<Partial<OnboardingState>> {
  console.log(`\n[Node: completeOnboardingNode] Executing...`);
  
  const response = `Onboarding complete! Welcome aboard, ${state.userName}. Your company size is ${state.companySize}.`;
  
  return {
    conversationHistory: [...state.conversationHistory, `AI: ${response}`],
    currentStep: 'complete', // Ensure it stays complete
  };
}

// ============================================================
// 4. SIMULATED LANGGRAPH RUNNER
// ============================================================

/**
 * A simplified function to simulate a LangGraph execution.
 * It determines which nodes to run based on the current state and the `currentStep` flag.
 * Crucially, it handles the "interruption" by saving state after a node runs.
 * 
 * @param state - The current state (either newly created or hydrated).
 * @param isResuming - Flag to indicate if this is a resumed run.
 */
async function runOnboardingGraph(state: OnboardingState, isResuming: boolean = false): Promise<void> {
  console.log(`\n==================================================`);
  console.log(`🚀 [Graph Runner] Starting execution. Resuming: ${isResuming}`);
  console.log(`==================================================`);

  let currentState = { ...state };

  // This is a simplified loop. A real LangGraph would have a more complex
  // execution model with conditional edges and cycles.
  while (currentState.currentStep !== 'complete') {
    console.log(`\n--- Step: ${currentState.currentStep} ---`);
    
    let newState: Partial<OnboardingState>;

    try {
      switch (currentState.currentStep) {
        case 'ask_name':
          newState = await askNameNode(currentState);
          // **SIMULATED USER INPUT**: In a real app, this would come from an HTTP request.
          // For this demo, we inject it here after the AI asks.
          if (!currentState.userName) {
            console.log("   -> [Simulated User Input] User provides name: 'Alice'");
            newState.userName = 'Alice';
          }
          break;
        
        case 'ask_company_size':
          newState = await askCompanySizeNode(currentState);
          // **SIMULATED USER INPUT**: User provides company size.
          if (!currentState.companySize) {
            console.log("   -> [Simulated User Input] User provides company size: 'startup'");
            newState.companySize = 'startup';
          }
          break;

        default:
          throw new Error(`Unknown step: ${currentState.currentStep}`);
      }

      // Merge the new state changes
      currentState = { ...currentState, ...newState };

      // *** CRITICAL: PERSISTENCE & INTERRUPTION ***
      // After each meaningful step, we save the state.
      // In a real web app, this would happen before sending the response to the client,
      // allowing the server to forget the state until the next request.
      await saveStateToDb(currentState);

      // In a real LangGraph, this is where the graph would "interrupt".
      // For this simulation, we break the loop to show the state is saved.
      console.log("   -> [INTERRUPTION] Graph paused. State saved. Waiting for next event...");
      break; // Exit the loop to simulate an interruption.

    } catch (error) {
      console.error("Error in graph execution:", error);
      break;
    }
  }

  if (currentState.currentStep === 'complete') {
    console.log("\n🎉 [Graph Runner] Onboarding workflow completed!");
  }
}

// ============================================================
// 5. MAIN EXECUTION SIMULATION
// ============================================================

/**
 * This function orchestrates the entire lifecycle:
 * 1. Start a new session.
 * 2. Simulate an interruption.
 * 3. Simulate a new request (hydration) and resume.
 */
async function main() {
  const USER_ID = 'user-123';

  // --- SCENARIO 1: NEW SESSION ---
  console.log("\n### SCENARIO 1: Starting a NEW onboarding session ###");
  
  // Create a fresh, empty state for a new user.
  const initialState: OnboardingState = {
    userId: USER_ID,
    currentStep: 'ask_name',
    conversationHistory: [],
  };

  // Run the graph. It will ask for the name, receive it, save state, and pause.
  await runOnboardingGraph(initialState, false);

  // --- SCENARIO 2: RESUME SESSION (HYDRATION) ---
  console.log("\n\n### SCENARIO 2: User returns. RESUMING session via Hydration ###");
  
  // 1. Retrieve the saved state from the database.
  const hydratedState = await loadStateFromDb(USER_ID);

  if (hydratedState) {
    // 2. Inject the hydrated state into a new graph execution instance.
    // This is the essence of Persistent Graph State Hydration.
    await runOnboardingGraph(hydratedState, true);
  } else {
    console.error("Could not resume session: state not found.");
  }
}

// Run the main simulation
main().catch(console.error);
