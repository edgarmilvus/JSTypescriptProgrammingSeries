/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// pages/api/agent/stream.ts
// Target: Next.js 13+ App Router (or Pages Router)
// Context: SaaS AI Agent Platform

import { NextRequest, NextResponse } from 'next/server';
import { StateGraph, END, MemorySaver } from '@langchain/langgraph';
import { BaseMessage, HumanMessage } from '@langchain/core/messages';
import * as fs from 'fs/promises';
import * as path from 'path';

/**
 * ============================================================================
 * 1. INTERFACE DEFINITIONS
 * ============================================================================
 * Defines the structure of the Graph State. This is the "canonical data 
 * structure" passed between nodes.
 */
interface AgentState {
  messages: BaseMessage[];
  currentStep: string;
  metadata: {
    sessionId: string;
    lastUpdated: number;
  };
}

/**
 * ============================================================================
 * 2. STORAGE CONFIGURATION (KUBERNETES PVC MOUNT)
 * ============================================================================
 * In Kubernetes, a PersistentVolumeClaim is mounted to the pod at a specific 
 * path (e.g., /mnt/data). We simulate this here.
 * 
 * WHY: This abstracts the physical disk. If the pod moves to another node, 
 * the Kubernetes control plane re-attaches the volume to the new node.
 */
const STORAGE_PATH = process.env.PERSISTENT_STORAGE_PATH || '/mnt/data/checkpoints';
const CHECKPOINT_FILE = 'agent_state.json';

/**
 * ============================================================================
 * 3. STATE PERSISTENCE & HYDRATION LOGIC
 * ============================================================================
 * Functions to handle saving and retrieving the Graph State from the PVC.
 */

/**
 * Retrieves the complete Graph State from the persistent volume.
 * If the file doesn't exist, it returns null (indicating a new session).
 * 
 * @param sessionId - Unique ID for the user session.
 * @returns The parsed AgentState or null.
 */
async function loadState(sessionId: string): Promise<AgentState | null> {
  try {
    // Ensure the directory exists (Kubernetes volumes might be empty on first mount)
    await fs.mkdir(STORAGE_PATH, { recursive: true });
    
    const filePath = path.join(STORAGE_PATH, `${sessionId}.json`);
    const data = await fs.readFile(filePath, 'utf-8');
    
    console.log(`[PVC] State loaded from: ${filePath}`);
    return JSON.parse(data) as AgentState;
  } catch (error) {
    // File not found is expected for new sessions
    if ((error as NodeJS.ErrnoException).code === 'ENOENT') {
      return null;
    }
    throw error;
  }
}

/**
 * Persists the current Graph State to the Persistent Volume.
 * 
 * @param sessionId - Unique ID for the user session.
 * @param state - The current state object to save.
 */
async function saveState(sessionId: string, state: AgentState): Promise<void> {
  try {
    const filePath = path.join(STORAGE_PATH, `${sessionId}.json`);
    // Add timestamp for metadata tracking
    state.metadata.lastUpdated = Date.now();
    
    await fs.writeFile(filePath, JSON.stringify(state, null, 2), 'utf-8');
    console.log(`[PVC] State saved to: ${filePath}`);
  } catch (error) {
    console.error('[PVC] Failed to save state:', error);
    throw error;
  }
}

/**
 * ============================================================================
 * 4. LANGGRAPH AGENT DEFINITION
 * ============================================================================
 * A simple 2-step agent: 'analyze' -> 'respond'.
 */

// Node 1: Analyze the input
const analyzeNode = async (state: AgentState) => {
  const lastMessage = state.messages[state.messages.length - 1].content;
  console.log(`[Agent] Analyzing: ${lastMessage}`);
  
  // Simulate AI processing
  const analysis = `Analysis of input: "${lastMessage}"`;
  
  return {
    ...state,
    currentStep: 'respond',
    messages: [...state.messages, new HumanMessage(analysis)]
  };
};

// Node 2: Formulate response
const respondNode = async (state: AgentState) => {
  console.log(`[Agent] Formulating response...`);
  
  const response = "I have processed your request based on previous context.";
  
  return {
    ...state,
    currentStep: 'finished',
    messages: [...state.messages, new HumanMessage(response)]
  };
};

/**
 * ============================================================================
 * 5. NEXT.JS API ROUTE (SSE ENDPOINT)
 * ============================================================================
 * Handles the incoming request, manages the lifecycle of the LangGraph,
 * and streams results back to the client.
 */
export async function GET(req: NextRequest) {
  // Extract Session ID from query params or headers
  const { searchParams } = new URL(req.url);
  const sessionId = searchParams.get('sessionId') || 'default-session';

  // Create a TransformStream for SSE
  const encoder = new TextEncoder();
  const stream = new ReadableStream({
    async start(controller) {
      try {
        // ---------------------------------------------------------
        // STEP A: HYDRATE STATE (The "Advanced" Part)
        // ---------------------------------------------------------
        // We attempt to load the state from the PVC. If found, the agent
        // resumes context. If not, we initialize a fresh state.
        const existingState = await loadState(sessionId);
        
        let currentState: AgentState;
        
        if (existingState) {
          currentState = existingState;
          controller.enqueue(encoder.encode(`data: ${JSON.stringify({ type: 'info', msg: 'Resuming from saved state...' })}\n\n`));
        } else {
          currentState = {
            messages: [new HumanMessage("Hello")],
            currentStep: 'analyze',
            metadata: { sessionId, lastUpdated: Date.now() }
          };
          controller.enqueue(encoder.encode(`data: ${JSON.stringify({ type: 'info', msg: 'Starting new session...' })}\n\n`));
        }

        // ---------------------------------------------------------
        // STEP B: EXECUTE GRAPH
        // ---------------------------------------------------------
        // Define the graph structure
        const workflow = new StateGraph<AgentState>({
          channels: {
            messages: { value: (x: BaseMessage[], y: BaseMessage[]) => (y ? x.concat(y) : x) },
            currentStep: { value: (x: string, y: string) => (y ? y : x) },
            metadata: { value: (x: any, y: any) => (y ? { ...x, ...y } : x) }
          }
        });

        workflow.addNode('analyze', analyzeNode);
        workflow.addNode('respond', respondNode);
        workflow.setEntryPoint('analyze');
        workflow.addEdge('analyze', 'respond');
        workflow.addEdge('respond', END);

        // Compile the graph
        const app = workflow.compile();

        // Run the graph
        // Note: In a real streaming scenario, we would use app.stream()
        // Here we simulate a single step execution for brevity, but the 
        // hydration logic applies to full stream runs.
        const finalState = await app.invoke(currentState);

        // ---------------------------------------------------------
        // STEP C: PERSIST STATE
        // ---------------------------------------------------------
        // Save the updated state back to the PVC for the next request
        await saveState(sessionId, finalState);

        // ---------------------------------------------------------
        // STEP D: STREAM RESPONSE
        // ---------------------------------------------------------
        // Send the final result via SSE
        const payload = {
          type: 'result',
          messages: finalState.messages.map(m => m.content),
          step: finalState.currentStep
        };
        
        controller.enqueue(encoder.encode(`data: ${JSON.stringify(payload)}\n\n`));
        controller.enqueue(encoder.encode(`event: end\ndata: stream_closed\n\n`));
        
        controller.close();

      } catch (error) {
        console.error(error);
        controller.enqueue(encoder.encode(`data: ${JSON.stringify({ type: 'error', msg: 'Internal Server Error' })}\n\n`));
        controller.close();
      }
    },
  });

  return new NextResponse(stream, {
    headers: {
      'Content-Type': 'text/event-stream',
      'Cache-Control': 'no-cache',
      'Connection': 'keep-alive',
    },
  });
}
