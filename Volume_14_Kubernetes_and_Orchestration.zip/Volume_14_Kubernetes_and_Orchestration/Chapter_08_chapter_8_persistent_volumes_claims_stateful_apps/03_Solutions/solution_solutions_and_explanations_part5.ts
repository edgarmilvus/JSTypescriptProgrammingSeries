/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

// src/utils/waitForModelVolume.ts
import * as fs from 'fs/promises';
import * as path from 'path';

const MODEL_DIR = '/var/models';
const MODEL_FILE = 'model.bin';
const MAX_RETRIES = 10;
const POLL_INTERVAL_MS = 2000;

export async function waitForModelVolume(): Promise<void> {
  console.log('Checking model volume readiness...');
  
  for (let i = 0; i < MAX_RETRIES; i++) {
    try {
      // Check if directory exists
      await fs.access(MODEL_DIR, fs.constants.R_OK);
      
      // Check if model file exists
      const modelPath = path.join(MODEL_DIR, MODEL_FILE);
      const stats = await fs.stat(modelPath);
      
      // Optional: Check if file has size > 0
      if (stats.size > 0) {
        console.log(`Model volume ready. Found ${MODEL_FILE} (${stats.size} bytes).`);
        return;
      }
      
      console.log(`Volume mounted but file size is 0. Retrying... (${i + 1}/${MAX_RETRIES})`);
    } catch (error) {
      console.log(`Volume not ready yet. Retrying... (${i + 1}/${MAX_RETRIES})`);
    }
    
    // Wait before next poll
    await new Promise(resolve => setTimeout(resolve, POLL_INTERVAL_MS));
  }

  throw new Error('Failed to access model volume within timeout period.');
}

// Usage in main.ts
// waitForModelVolume().then(() => startServer()).catch(err => process.exit(1));
