/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part5.tsx
// Description: Practical Exercises
// ==========================================

// src/components/InferenceStreamViewer.tsx
import React, { useState, useEffect } from 'react';

interface StreamEvent {
  content: string;
  status: 'thinking' | 'generating' | 'done';
}

const InferenceStreamViewer: React.FC = () => {
  const [streamData, setStreamData] = useState<string>('');
  const [status, setStatus] = useState<'thinking' | 'generating' | 'done' | 'error'>('thinking');
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    // Initialize EventSource connection
    const eventSource = new EventSource('/api/inference/stream');

    // Handler for incoming messages
    eventSource.onmessage = (event) => {
      try {
        const parsedData: StreamEvent = JSON.parse(event.data);
        setStreamData((prev) => prev + parsedData.content);
        setStatus(parsedData.status);
      } catch (e) {
        console.error("Failed to parse stream data", e);
      }
    };

    // Handler for errors
    eventSource.onerror = (err) => {
      console.error("EventSource failed:", err);
      setStatus('error');
      setError("Connection to inference stream lost.");
      eventSource.close();
    };

    // Cleanup function
    return () => {
      eventSource.close();
    };
  }, []);

  if (error) {
    return <div className="error-banner">Error: {error}</div>;
  }

  return (
    <div className="stream-viewer">
      <div className="status-bar">
        Status: <span className={`badge ${status}`}>{status.toUpperCase()}</span>
      </div>
      <div className="stream-content">
        {streamData || "Waiting for inference..."}
      </div>
    </div>
  );
};

export default InferenceStreamViewer;
