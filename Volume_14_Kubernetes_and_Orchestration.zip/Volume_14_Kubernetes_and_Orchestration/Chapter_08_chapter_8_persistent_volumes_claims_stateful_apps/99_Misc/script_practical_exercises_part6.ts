/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part6.ts
// Description: Practical Exercises
// ==========================================

// src/checkpointer/PVCheckpointer.ts
import * as fs from 'fs/promises';
import * as path from 'path';

// 1. Define the Graph State Interface
export interface GraphState {
  messages: Array<{ role: string; content: string }>;
  intermediate_steps: Array<{ action: string; observation: string }>;
  metadata: {
    threadId: string;
    timestamp: number;
  };
}

// 2. Checkpointer Class
export class PVCheckpointer {
  private storagePath: string;

  constructor(storagePath: string) {
    this.storagePath = storagePath;
  }

  // 3. Save Method
  async save(threadId: string, state: GraphState): Promise<void> {
    try {
      const filePath = path.join(this.storagePath, `${threadId}.json`);
      const serializedState = JSON.stringify(state, null, 2);
      await fs.writeFile(filePath, serializedState, 'utf-8');
      console.log(`State saved for thread ${threadId}`);
    } catch (error) {
      console.error(`Failed to save state: ${error}`);
      throw error;
    }
  }

  // 4. Load Method
  async load(threadId: string): Promise<GraphState | null> {
    try {
      const filePath = path.join(this.storagePath, `${threadId}.json`);
      const data = await fs.readFile(filePath, 'utf-8');
      console.log(`State loaded for thread ${threadId}`);
      return JSON.parse(data) as GraphState;
    } catch (error) {
      if ((error as NodeJS.ErrnoException).code === 'ENOENT') {
        return null; // File not found
      }
      console.error(`Failed to load state: ${error}`);
      throw error;
    }
  }
}

// Interactive Challenge: Crash Recovery Simulation
async function simulateCrashRecovery() {
  // Assume /data is mounted from a PVC
  const checkpointer = new PVCheckpointer('/data');

  const mockState: GraphState = {
    messages: [{ role: 'user', content: 'Explain quantum physics' }],
    intermediate_steps: [
      { action: 'search_wikipedia', observation: 'Quantum mechanics...' }
    ],
    metadata: { threadId: 'thread-123', timestamp: Date.now() }
  };

  // Step 1: Save initial state
  await checkpointer.save('thread-123', mockState);
  
  // Step 2: Simulate crash (e.g., pod restart)
  console.log("Simulating pod crash...");
  // In a real scenario, the process would terminate here.
  // We just wait to simulate the restart delay.
  await new Promise(resolve => setTimeout(resolve, 1000));

  // Step 3: Hydrate state (Resume execution)
  const restoredState = await checkpointer.load('thread-123');
  
  if (restoredState) {
    console.log("Recovery successful!");
    console.log("Intact intermediate steps:", restoredState.intermediate_steps);
  } else {
    console.log("Recovery failed: No state found.");
  }
}

// simulateCrashRecovery();
