/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part7.ts
// Description: Practical Exercises
// ==========================================

# api-deployment.yaml snippet
apiVersion: apps/v1
kind: Deployment
metadata:
  name: ai-model-api
spec:
  replicas: 1
  selector:
    matchLabels:
      app: ai-model-api
  template:
    metadata:
      labels:
        app: ai-model-api
    spec:
      containers:
      - name: api
        image: node-ai-api:latest
        volumeMounts:
        - name: model-storage
          mountPath: /var/models
        startupProbe:
          httpGet:
            path: /health
            port: 3000
          initialDelaySeconds: 5
          periodSeconds: 5
          failureThreshold: 6
        # OR using exec for strict file checks:
        # startupProbe:
        #   exec:
        #     command:
        #     - sh
        #     - -c
        #     - test -f /var/models/model.bin && [ $(stat -c%s /var/models/model.bin) -gt 1000000 ]
        #   initialDelaySeconds: 5
        #   periodSeconds: 5
        #   failureThreshold: 6
      volumes:
      - name: model-storage
        persistentVolumeClaim:
          claimName: model-weights-pvc
