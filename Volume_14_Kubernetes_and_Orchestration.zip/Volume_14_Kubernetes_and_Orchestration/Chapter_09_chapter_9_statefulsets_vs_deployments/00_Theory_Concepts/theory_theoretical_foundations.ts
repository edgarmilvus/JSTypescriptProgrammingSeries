/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: theory_theoretical_foundations.ts
// Description: Theoretical Foundations
// ==========================================

// Conceptual TypeScript representation of the logic difference
// (Not executable Kubernetes code, but illustrates the algorithmic difference)

interface Pod {
  id: string;
  ordinal: number;
  ready: boolean;
  volumeAttached: boolean;
}

// DEPLOYMENT LOGIC: "Cattle"
class DeploymentController {
  scale(targetReplicas: number, currentPods: Pod[]) {
    const diff = targetReplicas - currentPods.length;
    if (diff > 0) {
      // Create all missing pods in parallel immediately
      for (let i = 0; i < diff; i++) {
        createPod(`random-id-${Date.now()}`);
      }
    } else if (diff < 0) {
      // Terminate any pods to match count
      terminatePods(Math.abs(diff));
    }
  }
}

// STATEFULSET LOGIC: "Pets"
class StatefulSetController {
  scale(targetReplicas: number, currentPods: Pod[]) {
    // Sort pods by ordinal index to ensure order
    currentPods.sort((a, b) => a.ordinal - b.ordinal);
    
    const highestExistingOrdinal = currentPods.length > 0 
      ? currentPods[currentPods.length - 1].ordinal 
      : -1;

    if (targetReplicas > highestExistingOrdinal + 1) {
      // Only create ONE pod at a time
      const nextOrdinal = highestExistingOrdinal + 1;
      const nextPodName = `my-app-${nextOrdinal}`;
      
      // Wait for the previous pod to be Ready before proceeding
      // (This is handled by the controller's reconciliation loop)
      createPod(nextPodName);
    }
    // Scaling down happens in reverse order (omitted for brevity)
  }
}
