/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// This is a Kubernetes YAML manifest, not executable TypeScript code.
// However, to adhere to the requested format, we present it within a TypeScript string literal for documentation purposes.

const deploymentManifest = `
apiVersion: apps/v1
kind: Deployment
metadata:
  name: analytics-api
spec:
  replicas: 3
  strategy:
    type: RollingUpdate
    rollingUpdate:
      maxUnavailable: 0 # Ensures that available replicas never drop below the desired count
      maxSurge: 1       # Allows creating one extra pod above the desired count during update
  selector:
    matchLabels:
      app: analytics-api
  template:
    metadata:
      labels:
        app: analytics-api
    spec:
      containers:
      - name: analytics-api
        image: node:18-alpine
        ports:
        - containerPort: 3000
        readinessProbe:
          httpGet:
            path: /health
            port: 3000
          initialDelaySeconds: 5   # Wait 5 seconds before first check
          periodSeconds: 10        # Check every 10 seconds
          timeoutSeconds: 1        # Assume failure if no response within 1s
          successThreshold: 1
          failureThreshold: 3
`;

// Explanation of behavior:
// When applying this manifest to an existing deployment, Kubernetes performs a Rolling Update.
// 1. It creates a new Pod (surge) because maxSurge is 1. Total pods = 4.
// 2. It waits for the new Pod to pass the Readiness Probe (checking /health).
// 3. Only when the new Pod is Ready does it terminate an old Pod.
// 4. Because maxUnavailable is 0, it ensures at least 3 pods are available at all times.
// 5. The readinessProbe ensures traffic is not sent to the new pod until the application is fully initialized and ready to handle requests.
