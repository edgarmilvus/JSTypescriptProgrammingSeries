/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

// Kubernetes YAML manifest for the StatefulSet
const statefulSetManifest = `
apiVersion: v1
kind: Service
metadata:
  name: ai-headless
spec:
  clusterIP: None # This makes it a headless service
  selector:
    app: ai-trainer
---
apiVersion: apps/v1
kind: StatefulSet
metadata:
  name: ai-trainer
spec:
  serviceName: "ai-headless" # Must match the headless service name
  replicas: 2
  selector:
    matchLabels:
      app: ai-trainer
  template:
    metadata:
      labels:
        app: ai-trainer
    spec:
      containers:
      - name: trainer
        image: python:3.9-slim
        command: ["/bin/sh", "-c", "hostname && sleep 3600"] # Echo hostname to prove stable identity
        volumeMounts:
        - name: checkpoint-storage
          mountPath: /checkpoints
  volumeClaimTemplates:
  - metadata:
      name: checkpoint-storage
    spec:
      accessModes: [ "ReadWriteOnce" ]
      resources:
        requests:
          storage: 1Gi
`;

// Why StatefulSet is mandatory:
// 1. Stable Identity: Unlike Deployments where pods get random hashes, StatefulSet pods get predictable names (ai-trainer-0, ai-trainer-1).
//    This allows workers to discover the master (e.g., via DNS: ai-trainer-0.ai-headless) and maintain stable connections.
// 2. Persistent Storage: The volumeClaimTemplates create a unique PersistentVolume for each pod index. 
//    If ai-trainer-1 dies, the replacement pod (still named ai-trainer-1) re-attaches the same volume, recovering the training checkpoint.
//    A Deployment would lose data because a new pod gets a new volume, and the old volume might be detached or inaccessible depending on the storage class.
