/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

import * as http from 'http';

/**
 * Simulates a CPU-bound blocking task that halts the Event Loop.
 * This mimics a heavy calculation or synchronous I/O that prevents the server from accepting new connections.
 */
function simulateBlockingTask(): number {
    console.log('Starting heavy calculation...');
    let result = 0;
    // Blocking the main thread for ~2 seconds
    const start = Date.now();
    while (Date.now() - start < 2000) {
        // Intentional busy wait to block the Event Loop
        result += Math.random() * Math.random();
    }
    console.log('Calculation finished.');
    return result;
}

const server = http.createServer((req, res) => {
    if (req.url === '/heavy') {
        // This blocks the Event Loop, delaying the response to the liveness probe
        const result = simulateBlockingTask();
        res.writeHead(200);
        res.end(`Heavy task done. Result: ${result}`);
    } else if (req.url === '/') {
        res.writeHead(200);
        res.end('OK');
    } else {
        res.writeHead(404);
        res.end('Not Found');
    }
});

server.listen(3000, () => {
    console.log('Server running on port 3000');
});

/*
 * DIAGNOSIS:
 * 
 * The Kubernetes livenessProbe configuration is critical here. A standard HTTP probe might look like this:
 * 
 *   livenessProbe:
 *     httpGet:
 *       path: /
 *       port: 3000
 *     initialDelaySeconds: 15
 *     periodSeconds: 5
 *     timeoutSeconds: 1
 * 
 * THE PROBLEM: 
 * If the /heavy endpoint is hit, the Event Loop is blocked for 2 seconds. If the liveness probe fires during this time,
 * the Node.js process cannot process the incoming HTTP request for the probe because the Event Loop is saturated.
 * 
 * THE FAILURE MODE:
 * 1. The probe request sits in the TCP queue.
 * 2. The `timeoutSeconds` (e.g., 1s) expires before the Event Loop is free to handle the request.
 * 3. Kubernetes marks the probe as failed.
 * 4. After `failureThreshold` retries, Kubernetes kills and restarts the pod.
 * 
 * THE "SPLIT-HEART" (False Positive):
 * The pod is technically "alive" (the process exists and will finish the calculation), but it is "unresponsive."
 * Kubernetes cannot distinguish between a dead process and a blocked Event Loop via a simple HTTP probe.
 * 
 * SOLUTION:
 * To detect this, one might use a `exec` probe that runs a lightweight script, but that also runs in the same process space.
 * The best mitigation is code-level: offload heavy tasks to worker threads or separate microservices, ensuring the main Event Loop remains responsive to health checks.
 * Alternatively, configure a very aggressive `timeoutSeconds` (e.g., 0.5s) to fail fast, but this increases flapping risk under normal load.
 */
