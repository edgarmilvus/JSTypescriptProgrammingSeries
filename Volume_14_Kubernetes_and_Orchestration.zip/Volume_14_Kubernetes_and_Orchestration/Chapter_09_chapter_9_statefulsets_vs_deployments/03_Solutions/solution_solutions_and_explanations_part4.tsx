/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.tsx
// Description: Solutions and Explanations
// ==========================================

import React from 'react';

// 1. Define the specific status type
type PodStatus = 'Pending' | 'Running' | 'Terminating' | 'Failed';

// 2. Define the interface for the component props
interface Pod {
  name: string;
  status: PodStatus;
}

// 3. Define the larger backend payload (RawPod)
interface RawPod {
  name: string;
  status: PodStatus;
  lastUpdated: string;
  nodeIp: string;
  restartCount: number;
}

// 4. Derive the component props type using Omit utility type
// We strip 'lastUpdated' and 'nodeIp' because the dashboard doesn't need them.
type DashboardPodProps = Omit<RawPod, 'lastUpdated' | 'nodeIp'>;

// Alternatively, using Pick:
// type DashboardPodProps = Pick<RawPod, 'name' | 'status'>;

const PodStatusIndicator: React.FC<DashboardPodProps> = ({ name, status }) => {
  
  // Helper function to render UI based on status
  const renderStatus = () => {
    switch (status) {
      case 'Pending':
        return (
          <span style={{ color: 'orange' }}>
            {/* Spinning Icon Simulation */}
            ⟳ Pending
          </span>
        );
      case 'Running':
        return (
          <span style={{ color: 'green' }}>
            {/* Green Checkmark Simulation */}
            ✓ Running
          </span>
        );
      case 'Terminating':
        return (
          <span style={{ color: 'red' }}>
            {/* Red Hourglass Simulation */}
            ⌛ Terminating
          </span>
        );
      case 'Failed':
        return (
          <span style={{ color: 'darkred', fontWeight: 'bold' }}>
            ⚠ Failed
          </span>
        );
      default:
        return <span>Unknown</span>;
    }
  };

  return (
    <div className="pod-card">
      <h4>{name}</h4>
      <div className="status-indicator">
        {renderStatus()}
      </div>
    </div>
  );
};

// Example Usage (Mock Data)
const mockRawData: RawPod = {
  name: 'ai-trainer-0',
  status: 'Running',
  lastUpdated: '2023-10-27T10:00:00Z',
  nodeIp: '10.0.0.5',
  restartCount: 0
};

// The component only accepts the filtered props
// <PodStatusIndicator name={mockRawData.name} status={mockRawData.status} />
