/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

// Since Graphviz DOT is a text-based graph description language, 
// we represent the solution as string constants containing the DOT syntax.

/**
 * DIAGRAM 1: DEPLOYMENT LIFECYCLE
 * 
 * Concept:
 * Deployments create pods in parallel (subject to surge limits).
 * They do not wait for a pod to be "Ready" before creating the next one.
 * All pods are created almost simultaneously.
 */
const deploymentDiagram = `
digraph DeploymentLifecycle {
  rankdir=TB; // Top to Bottom layout
  node [shape=box, style=filled, color=lightblue];

  // Start State
  Start [label="Scale Request: 0 -> 3", shape=ellipse]

  // Parallel Creation
  Start -> Pod0 [label="Create"]
  Start -> Pod1 [label="Create"]
  Start -> Pod2 [label="Create"]

  // State Labels
  Pod0 [label="Pod 0 (Pending)"]
  Pod1 [label="Pod 1 (Pending)"]
  Pod2 [label="Pod 2 (Pending)"]

  // Note on Parallelism
  subgraph cluster_parallel {
    rank=same;
    Pod0; Pod1; Pod2;
    label="Parallel Creation (Simultaneous)";
    style=dashed;
  }
  
  // Final State
  Pod0 -> Ready [label="Probe OK"]
  Pod1 -> Ready [label="Probe OK"]
  Pod2 -> Ready [label="Probe OK"]
  
  Ready [label="All Pods Running", shape=doublecircle]
}
`;

/**
 * DIAGRAM 2: STATEFULSET LIFECYCLE
 * 
 * Concept:
 * StatefulSets enforce strict ordering (ordinal index).
 * Pod N must be Running and Ready before Pod N+1 is created.
 */
const statefulSetDiagram = `
digraph StatefulSetLifecycle {
  rankdir=TB; // Top to Bottom layout
  node [shape=box, style=filled, color=lightgreen];

  // Start State
  Start [label="Scale Request: 0 -> 3", shape=ellipse]

  // Sequential Creation Flow
  Start -> Pod0_Create [label="Create Pod 0"]
  Pod0_Create -> Pod0_Running [label="Start Container"]
  Pod0_Running -> Pod0_Ready [label="Readiness Probe OK"]
  
  // Wait for Pod 0 before starting Pod 1
  Pod0_Ready -> Pod1_Create [label="Create Pod 1"]
  Pod1_Create -> Pod1_Running [label="Start Container"]
  Pod1_Running -> Pod1_Ready [label="Readiness Probe OK"]

  // Wait for Pod 1 before starting Pod 2
  Pod1_Ready -> Pod2_Create [label="Create Pod 2"]
  Pod2_Create -> Pod2_Running [label="Start Container"]
  Pod2_Running -> Pod2_Ready [label="Readiness Probe OK"]
  
  // Final State
  Pod2_Ready -> Complete [label="Scale Complete", shape=doublecircle]

  // Styling for clarity
  Pod0_Create [label="Pod 0 (Pending)"]
  Pod1_Create [label="Pod 1 (Pending)"]
  Pod2_Create [label="Pod 2 (Pending)"]
}
`;

// Exporting for documentation purposes
export { deploymentDiagram, statefulSetDiagram };
