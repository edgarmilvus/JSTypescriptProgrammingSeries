/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * HPA Simulator - Basic Code Example
 * 
 * Context: SaaS Web Application
 * Scenario: A Node.js API service experiencing fluctuating user traffic.
 * Goal: Simulate the HPA decision loop to scale replicas based on CPU utilization.
 */

// --- 1. Type Definitions (Using Utility Types for Scalability) ---

/**
 * Represents the state of a single application pod/node.
 * Using `Readonly<T>` to ensure individual pod states cannot be mutated directly,
 * enforcing immutability patterns often found in Kubernetes controllers.
 */
type PodState = Readonly<{
  id: string;
  status: 'Running' | 'Pending' | 'Terminating';
  cpuUsage: number; // Percentage (0-100)
}>;

/**
 * Represents the Deployment configuration.
 * Using `Pick<T, K>` to select only the relevant fields for scaling decisions.
 */
type DeploymentSpec = Pick<K8sDeployment, 'minReplicas' | 'maxReplicas' | 'targetCPUUtilization'>;

/**
 * Full Deployment object (Mocking Kubernetes API response).
 */
interface K8sDeployment {
  name: string;
  namespace: string;
  replicas: number;
  minReplicas: number;
  maxReplicas: number;
  targetCPUUtilization: number;
  pods: PodState[];
}

// --- 2. Mock Data Generators ---

/**
 * Simulates fetching current metrics from the Metrics Server.
 * In production, this would be an API call to Prometheus or the Metrics Server API.
 * 
 * @returns {number} A simulated CPU load percentage.
 */
function getMockCPUMetrics(): number {
  // Simulate fluctuating traffic: Random spikes between 20% and 90%
  return Math.floor(Math.random() * 70) + 20;
}

/**
 * Simulates the Kubernetes API call to update the Deployment replica count.
 * 
 * @param deployment - The current deployment state.
 * @param newReplicaCount - The calculated target replica count.
 */
function updateDeploymentReplicas(deployment: K8sDeployment, newReplicaCount: number): void {
  if (deployment.replicas === newReplicaCount) {
    console.log(`[INFO] No change needed. Current replicas: ${deployment.replicas}`);
    return;
  }

  console.log(`[ACTION] Scaling Deployment '${deployment.name}' from ${deployment.replicas} to ${newReplicaCount} replicas.`);
  
  // Update the internal state
  deployment.replicas = newReplicaCount;
  
  // Simulate pod creation/deletion logic
  deployment.pods = Array.from({ length: newReplicaCount }, (_, i) => ({
    id: `pod-${i + 1}`,
    status: 'Running',
    cpuUsage: getMockCPUMetrics() / newReplicaCount // Distribute load
  }));

  console.log(`[SUCCESS] Deployment scaled successfully.`);
}

// --- 3. The HPA Logic Core ---

/**
 * Calculates the desired replica count based on observed metrics.
 * This mimics the HPA algorithm: DesiredReplicas = ceil[CurrentReplicas * ( CurrentMetricValue / DesiredMetricValue )]
 * 
 * @param deployment - The current deployment state.
 * @param currentMetricValue - The observed CPU usage percentage.
 * @returns {number} The calculated desired replica count.
 */
function calculateDesiredReplicas(deployment: DeploymentSpec, currentMetricValue: number): number {
  const { minReplicas, maxReplicas, targetCPUUtilization } = deployment;

  // 1. Calculate the ratio of current load to target load
  const ratio = currentMetricValue / targetCPUUtilization;

  // 2. Calculate raw desired replicas (assuming we have current replicas in scope)
  // Note: In this simplified example, we rely on the deployment object passed in, 
  // but in a real loop, we'd track current replicas separately.
  // For simulation, we will assume we are scaling *from* the current state.
  // However, to keep this function pure, we will handle the scaling logic in the main loop.
  
  return ratio; 
}

// --- 4. The Main Simulation Loop ---

/**
 * Main execution function.
 * Runs a loop simulating the HPA control loop.
 */
async function runHPASimulation() {
  console.log("--- Starting HPA Simulation ---");

  // Initial State
  const deployment: K8sDeployment = {
    name: 'nodejs-api-service',
    namespace: 'production',
    replicas: 2,
    minReplicas: 2,
    maxReplicas: 10,
    targetCPUUtilization: 50, // Target 50% CPU per pod
    pods: [
      { id: 'pod-1', status: 'Running', cpuUsage: 45 },
      { id: 'pod-2', status: 'Running', cpuUsage: 55 }
    ]
  };

  console.log(`Initial State: Replicas = ${deployment.replicas}, Target CPU = ${deployment.targetCPUUtilization}%`);

  // Simulate 5 ticks of the control loop
  for (let i = 1; i <= 5; i++) {
    console.log(`\n--- Tick ${i} ---`);
    
    // 1. OBSERVE: Get metrics
    const currentCPU = getMockCPUMetrics();
    console.log(`Observed Average CPU Load: ${currentCPU}%`);

    // 2. CALCULATE: Determine desired replicas
    // Formula: ceil( CurrentReplicas * ( CurrentCPU / TargetCPU ) )
    const desiredReplicas = Math.ceil(
      deployment.replicas * (currentCPU / deployment.targetCPUUtilization)
    );

    // 3. BOUND: Apply Min/Max constraints
    const boundedReplicas = Math.max(
      deployment.minReplicas, 
      Math.min(desiredReplicas, deployment.maxReplicas)
    );

    console.log(`Calculated Desired Replicas: ${desiredReplicas} -> Bounded: ${boundedReplicas}`);

    // 4. ACT: Update Deployment if necessary
    updateDeploymentReplicas(deployment, boundedReplicas);

    // Simulate time passing
    await new Promise(resolve => setTimeout(resolve, 1000));
  }

  console.log("\n--- Simulation Complete ---");
}

// Execute the simulation
runHPASimulation().catch(console.error);
