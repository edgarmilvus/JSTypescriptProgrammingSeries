/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// pages/api/admin/scale-controller.ts
// Next.js API Route for Advanced HPA Management
// Target: Kubernetes Cluster via ServiceAccount

import type { NextApiRequest, NextApiResponse } from 'next';
import { KubeConfig, AppsV1Api, AutoscalingV2Api, V2HorizontalPodAutoscaler } from '@kubernetes/client-node';
import { z } from 'zod';

/**
 * ============================================================================
 * 1. CONFIGURATION & ZOD SCHEMA
 * ============================================================================
 * We use Zod to validate environment variables and incoming payloads.
 * This ensures strict typing and prevents runtime errors in the cluster.
 */

// Schema for validating the incoming request payload from the dashboard
const ScaleRequestSchema = z.object({
  deploymentName: z.string().min(1),
  namespace: z.string().default('default'),
  // Custom metric: e.g., "requests_per_second" or "queue_depth"
  customMetricValue: z.number().min(0),
  // Threshold: If metric > threshold, scale up
  threshold: z.number().min(1),
});

type ScaleRequest = z.infer<typeof ScaleRequestSchema>;

/**
 * ============================================================================
 * 2. KUBERNETES CLIENT SETUP
 * ============================================================================
 * Loads config from /var/run/secrets/kubernetes.io/serviceaccount for in-cluster access.
 * In a local dev environment, this falls back to ~/.kube/config.
 */

const kc = new KubeConfig();
kc.loadFromDefault();

const k8sApps = kc.makeApiClient(AppsV1Api);
const k8sAutoscaling = kc.makeApiClient(AutoscalingV2Api);

/**
 * ============================================================================
 * 3. HELPER: CALCULATE DESIRED REPLICAS
 * ============================================================================
 * Logic: Implements a simple predictive algorithm.
 * If (CurrentMetric > Threshold), we calculate a new maxReplicas to handle the load.
 * This prevents the lag associated with standard CPU-based HPA.
 */

function calculateDesiredReplicas(
  currentMetric: number,
  threshold: number,
  currentMaxReplicas: number
): { minReplicas: number; maxReplicas: number } {
  // Under heavy load, we want to scale aggressively.
  // Formula: New Max = Current Metric / Threshold * 2 (Buffer)
  const loadFactor = currentMetric / threshold;
  
  if (loadFactor > 1) {
    // Scale up: Set min to current max to prevent thrashing, increase max
    const newMax = Math.ceil(currentMaxReplicas * loadFactor * 1.5); // 1.5x buffer
    return {
      minReplicas: currentMaxReplicas, // Lock min to current capacity
      maxReplicas: Math.max(newMax, currentMaxReplicas + 1),
    };
  } else {
    // Scale down: Allow min to drop slowly
    return {
      minReplicas: 1,
      maxReplicas: currentMaxReplicas, // Maintain max, but allow idle scaling
    };
  }
}

/**
 * ============================================================================
 * 4. API HANDLER
 * ============================================================================
 * Main logic flow: Validate -> Fetch HPA -> Calculate -> Update.
 */

export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse
) {
  // Only allow POST requests
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method Not Allowed' });
  }

  try {
    // A. Validate Input
    const validationResult = ScaleRequestSchema.safeParse(req.body);
    if (!validationResult.success) {
      return res.status(400).json({ error: 'Invalid payload', details: validationResult.error });
    }
    const { deploymentName, namespace, customMetricValue, threshold } = validationResult.data;

    // B. Fetch Current HPA State
    // We need to know the current limits to calculate the delta
    const { body: hpaList } = await k8sAutoscaling.listNamespacedHorizontalPodAutoscaler(
      namespace,
      undefined,
      undefined,
      undefined,
      undefined,
      `metadata.name=${deploymentName}-hpa`
    );

    if (!hpaList.items || hpaList.items.length === 0) {
      return res.status(404).json({ error: 'HPA not found for deployment', deploymentName });
    }

    const currentHPA = hpaList.items[0];
    const currentMax = currentHPA.spec.maxReplicas;
    const currentMin = currentHPA.spec.minReplicas || 1;

    // C. Calculate New Scaling Targets
    const { minReplicas, maxReplicas } = calculateDesiredReplicas(
      customMetricValue,
      threshold,
      currentMax
    );

    // Optimization: If no change is needed, return early
    if (minReplicas === currentMin && maxReplicas === currentMax) {
      return res.status(200).json({ 
        message: 'No scaling action required', 
        currentMetrics: { min: currentMin, max: currentMax } 
      });
    }

    // D. Construct the Update Payload (V2 HPA Spec)
    // We update the HPA object directly via the API
    const updatedHPA: V2HorizontalPodAutoscaler = {
      ...currentHPA,
      spec: {
        ...currentHPA.spec,
        minReplicas: minReplicas,
        maxReplicas: maxReplicas,
        // Note: We are dynamically adjusting the bounds of the HPA.
        // The HPA controller will then handle the actual pod creation based on CPU/Memory.
        // Alternatively, we could inject a custom metric here, but adjusting bounds 
        // is often safer for predictive scaling of infrastructure.
      },
    };

    // E. Apply Update to Kubernetes
    await k8sAutoscaling.replaceNamespacedHorizontalPodAutoscaler(
      deploymentName + '-hpa', // Name of the HPA resource
      namespace,
      updatedHPA
    );

    // F. Log and Respond
    console.log(`[ScaleController] Scaled ${deploymentName}: ${currentMin}->${minReplicas} (min), ${currentMax}->${maxReplicas} (max) due to metric ${customMetricValue}`);

    res.status(200).json({
      success: true,
      action: 'updated_hpa',
      details: {
        previous: { min: currentMin, max: currentMax },
        new: { min: minReplicas, max: maxReplicas },
        reason: `Custom metric ${customMetricValue} exceeded threshold ${threshold}`,
      },
    });

  } catch (error) {
    console.error('Scale Controller Error:', error);
    res.status(500).json({ error: 'Internal Server Error', details: error });
  }
}
