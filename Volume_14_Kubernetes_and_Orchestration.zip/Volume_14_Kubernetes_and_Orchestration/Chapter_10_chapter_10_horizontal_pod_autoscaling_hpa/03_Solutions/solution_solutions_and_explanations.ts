/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// deployment.yaml
// This manifest defines the Node.js application deployment.
// It includes resource requests, which are required for HPA to calculate utilization percentages.
apiVersion: apps/v1
kind: Deployment
metadata:
  name: node-cpu-worker
  labels:
    app: node-cpu-worker
spec:
  replicas: 2
  selector:
    matchLabels:
      app: node-cpu-worker
  template:
    metadata:
      labels:
        app: node-cpu-worker
    spec:
      containers:
      - name: node-worker
        image: node:18-alpine
        # Simulate CPU load with a loop calculating prime numbers
        command: ["node", "-e", "setInterval(() => { let n = 0; while (n < 1e7) n = Math.pow(n, 2) + 1; }, 100);"]
        resources:
          # Requests are essential for HPA CPU metrics
          requests:
            cpu: "250m"
            memory: "64Mi"
          limits:
            cpu: "500m"
            memory: "128Mi"
---
# hpa.yaml
# This manifest configures the Horizontal Pod Autoscaler.
# It targets the 'node-cpu-worker' deployment and scales based on CPU utilization.
apiVersion: autoscaling/v2
kind: HorizontalPodAutoscaler
metadata:
  name: node-cpu-hpa
spec:
  scaleTargetRef:
    apiVersion: apps/v1
    kind: Deployment
    name: node-cpu-worker
  minReplicas: 2
  maxReplicas: 10
  metrics:
  - type: Resource
    resource:
      name: cpu
      target:
        type: Utilization
        averageUtilization: 60
