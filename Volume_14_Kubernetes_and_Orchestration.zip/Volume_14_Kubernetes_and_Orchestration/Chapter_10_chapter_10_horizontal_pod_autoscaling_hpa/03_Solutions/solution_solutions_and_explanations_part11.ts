/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part11.ts
// Description: Solutions and Explanations
// ==========================================

// scaling-utils.ts
/**
 * Calculates the maximum number of pods that can be added in a single scaling cycle
 * based on burst capacity, without exceeding the maxReplicas limit.
 * 
 * @param currentReplicas - The current number of running pods.
 * @param burstFactor - The number of pods allowed to be added per cycle (from HPA policy value).
 * @param maxReplicas - The absolute maximum replicas defined in the HPA spec.
 * @returns The calculated target replica count for the next scaling cycle.
 */
function calculateBurstCapacity(
    currentReplicas: number,
    burstFactor: number,
    maxReplicas: number
): number {
    // 1. Calculate the potential target if we apply the full burst
    const potentialTarget = currentReplicas + burstFactor;

    // 2. Cap the target at the hard maximum limit
    const cappedTarget = Math.min(potentialTarget, maxReplicas);

    // 3. Ensure we don't return fewer replicas than we currently have (though logic implies growth)
    return Math.max(currentReplicas, cappedTarget);
}

// Example Usage:
// Current: 2 pods, Burst: 4, Max: 10 -> Result: 6 pods
// Current: 8 pods, Burst: 4, Max: 10 -> Result: 10 pods (Capped)
// Current: 10 pods, Burst: 4, Max: 10 -> Result: 10 pods
