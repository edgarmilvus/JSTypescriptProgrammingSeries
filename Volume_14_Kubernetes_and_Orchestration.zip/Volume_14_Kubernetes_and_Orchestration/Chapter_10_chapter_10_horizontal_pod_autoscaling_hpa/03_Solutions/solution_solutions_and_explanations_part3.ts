/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

// diagnostic-script.ts
// Requires: npm install @kubernetes/client-node
import * as k8s from '@kubernetes/client-node';

async function diagnoseHPA() {
    const kc = new k8s.KubeConfig();
    kc.loadFromDefault();

    const k8sApi = kc.makeApiClient(k8s.CoreV1Api);
    const metricsApi = kc.makeApiClient(k8s.MetricsV1beta1Api);
    const appsApi = kc.makeApiClient(k8s.AppsV1Api);

    const namespace = 'default';
    const deploymentName = 'node-cpu-worker';
    const hpaName = 'node-cpu-hpa';

    console.log('--- Starting HPA Diagnosis ---');

    // 1. Check if Deployment exists and has CPU requests
    try {
        const { body: deployment } = await appsApi.readNamespacedDeployment(deploymentName, namespace);
        const containers = deployment.spec?.template.spec?.containers;
        if (!containers || containers.length === 0) {
            console.error('❌ No containers found in Deployment spec.');
        } else {
            const cpuRequest = containers[0].resources?.requests?.cpu;
            if (cpuRequest) {
                console.log(`✅ CPU Request found: ${cpuRequest}`);
            } else {
                console.error('❌ CRITICAL: CPU request is missing in Deployment. HPA cannot calculate utilization.');
            }
        }
    } catch (e) {
        console.error(`❌ Error reading Deployment: ${e.body?.message || e.message}`);
    }

    // 2. Check Metrics Server Reachability
    try {
        // Attempt to list pods via the metrics API
        await metricsApi.listPodMetrics(namespace);
        console.log('✅ Metrics Server API is reachable.');
    } catch (e) {
        console.error('❌ Metrics Server API not reachable. Check if metrics-server is installed.');
    }

    // 3. Check HPA Status
    try {
        const autoscalingApi = kc.makeApiClient(k8s.AutoscalingV2Api);
        const { body: hpa } = await autoscalingApi.readNamespacedHorizontalPodAutoscaler(hpaName, namespace);
        
        const conditions = hpa.status?.conditions || [];
        const activeCondition = conditions.find(c => c.type === 'AbleToScale');
        
        if (activeCondition) {
            console.log(`HPA Status: ${activeCondition.reason} - ${activeCondition.message}`);
        }
        
        const metrics = hpa.status?.currentMetrics || [];
        if (metrics.length === 0) {
            console.log('ℹ️ No current metrics reported in HPA status yet.');
        } else {
            console.log('Current Metrics:');
            metrics.forEach(m => {
                if (m.resource) {
                    console.log(`  - ${m.resource.name}: Current=${m.resource.current?.averageUtilization || 'N/A'}%`);
                }
            });
        }
    } catch (e) {
        console.error(`❌ Error reading HPA: ${e.body?.message || e.message}`);
    }
}

diagnoseHPA();
