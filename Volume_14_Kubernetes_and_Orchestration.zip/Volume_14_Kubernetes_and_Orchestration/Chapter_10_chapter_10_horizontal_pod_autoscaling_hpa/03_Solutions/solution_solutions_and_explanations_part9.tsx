/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part9.tsx
// Description: Solutions and Explanations
// ==========================================

// HPAStatusCard.tsx
import React, { useState } from 'react';
import styled from 'styled-components';

// 1. Interfaces
interface MetricStatus {
    type: 'Resource' | 'External' | 'Pods';
    name: string;
    current: string;
    target: string;
}

interface HPAStatusProps {
    name: string;
    namespace: string;
    currentReplicas: number;
    desiredReplicas: number;
    metrics: MetricStatus[];
    statusMessage?: string;
}

// 2. Styled Components
const Card = styled.div<{ hasError: boolean }>`
    border: 1px solid ${props => props.hasError ? '#ff4d4f' : '#d9d9d9'};
    border-radius: 8px;
    padding: 16px;
    background: #fff;
    box-shadow: 0 2px 8px rgba(0,0,0,0.1);
    max-width: 400px;
    font-family: sans-serif;
`;

const Header = styled.div`
    display: flex;
    justify-content: space-between;
    margin-bottom: 12px;
    font-weight: bold;
    font-size: 1.1em;
    color: #1890ff;
`;

const ProgressBarContainer = styled.div`
    background: #f0f0f0;
    border-radius: 4px;
    height: 20px;
    margin-bottom: 16px;
    overflow: hidden;
    position: relative;
`;

const ProgressBarFill = styled.div<{ percentage: number }>`
    background: #52c41a;
    height: 100%;
    width: ${props => Math.min(props.percentage, 100)}%;
    transition: width 0.5s ease;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 12px;
    color: white;
    font-weight: bold;
`;

const MetricList = styled.ul`
    list-style: none;
    padding: 0;
    margin: 0;
`;

const MetricItem = styled.li`
    display: flex;
    justify-content: space-between;
    padding: 8px 0;
    border-bottom: 1px solid #eee;
    font-size: 0.9em;
`;

const AlertBox = styled.div`
    background: #fff1f0;
    border: 1px solid #ffa39e;
    color: #d63031;
    padding: 8px;
    border-radius: 4px;
    margin-top: 12px;
    font-size: 0.85em;
`;

const LoadingSpinner = styled.div`
    text-align: center;
    padding: 20px;
    color: #888;
`;

// 3. Component Implementation
export const HPAStatusCard: React.FC<HPAStatusProps & { isLoading?: boolean }> = ({
    name,
    namespace,
    currentReplicas,
    desiredReplicas,
    metrics,
    statusMessage,
    isLoading = false
}) => {
    // Calculate percentage for visual bar (assuming maxReplicas is 10 for visualization context, 
    // or strictly current/desired ratio)
    const ratio = desiredReplicas > 0 ? (currentReplicas / desiredReplicas) * 100 : 0;

    if (isLoading) {
        return <Card hasError={false}><LoadingSpinner>Loading HPA Status...</LoadingSpinner></Card>;
    }

    return (
        <Card hasError={!!statusMessage}>
            <Header>
                <span>{name}</span>
                <span style={{ fontSize: '0.8em', color: '#666' }}>{namespace}</span>
            </Header>

            <div style={{ marginBottom: '8px', fontSize: '0.9em' }}>
                Replicas: <strong>{currentReplicas}</strong> / <strong>{desiredReplicas}</strong> desired
            </div>

            <ProgressBarContainer>
                <ProgressBarFill percentage={100}>
                     {/* Visualizing the current load relative to desired */}
                     {currentReplicas} / {desiredReplicas}
                </ProgressBarFill>
            </ProgressBarContainer>

            <MetricList>
                {metrics.map((m, idx) => (
                    <MetricItem key={idx}>
                        <span>{m.name} ({m.type})</span>
                        <span>{m.current} / {m.target}</span>
                    </MetricItem>
                ))}
            </MetricList>

            {statusMessage && (
                <AlertBox>
                    <strong>Status:</strong> {statusMessage}
                </AlertBox>
            )}
        </Card>
    );
};

// Usage Example (Mock Data)
// <HPAStatusCard 
//     name="ai-inference-hpa" 
//     namespace="default" 
//     currentReplicas={3} 
//     desiredReplicas={5} 
//     metrics={[
//         { type: 'Resource', name: 'cpu', current: '75%', target: '70%' },
//         { type: 'Resource', name: 'memory', current: '60%', target: '80%' }
//     ]}
//     statusMessage="Scaling up due to high CPU"
// />
