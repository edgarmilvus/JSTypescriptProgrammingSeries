/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

// server.ts
import express, { Request, Response } from 'express';
import { Readable } from 'stream';

// ============================================================================
// 1. Configuration & State
// ============================================================================

const app = express();
const PORT = 8080;

/**
 * Simulates the state of a heavy AI Model loading process.
 * In a real scenario, this would be a TensorFlow.js or ONNX runtime instance.
 */
let isModelLoaded = false;

/**
 * Simulates a request counter to demonstrate readiness logic.
 */
let requestCount = 0;

// ============================================================================
// 2. Simulated AI Model Loader (Async/Await)
// ============================================================================

/**
 * Simulates the asynchronous loading of a large AI model.
 * We use a timeout to mimic network latency or disk I/O.
 */
async function loadAIModel(): Promise<void> {
  console.log('[System] Loading AI Model...');
  return new Promise((resolve) => {
    setTimeout(() => {
      isModelLoaded = true;
      console.log('[System] AI Model Loaded successfully.');
      resolve();
    }, 3000); // 3-second simulation
  });
}

// ============================================================================
// 3. Health Check Endpoints
// ============================================================================

/**
 * READINESS PROBE: /health/ready
 * Kubernetes uses this to determine if the pod is ready to accept traffic.
 * Logic: Returns 200 OK only if the AI model is fully loaded.
 */
app.get('/health/ready', (req: Request, res: Response) => {
  if (isModelLoaded) {
    res.status(200).json({ status: 'ready', timestamp: new Date().toISOString() });
  } else {
    // 503 Service Unavailable tells K8s "I exist, but I can't work yet"
    res.status(503).json({ status: 'loading', message: 'Model not initialized' });
  }
});

/**
 * LIVENESS PROBE: /health/live
 * Kubernetes uses this to check if the container is still running.
 * Logic: Returns 200 OK if the process is responsive.
 * Note: We intentionally do NOT check 'isModelLoaded' here to prevent
 * restart loops during heavy loading.
 */
app.get('/health/live', (req: Request, res: Response) => {
  // If the process can respond, it is alive.
  res.status(200).json({ status: 'alive', uptime: process.uptime() });
});

// ============================================================================
// 4. Streaming API Route (SaaS Context)
// ============================================================================

/**
 * Simulates an AI Inference endpoint.
 * Returns a streaming response (common for LLMs) to the client.
 */
app.get('/api/generate', (req: Request, res: Response) => {
  requestCount++;

  // Check readiness explicitly in the route handler
  if (!isModelLoaded) {
    return res.status(503).json({ error: 'Model is warming up. Please try again later.' });
  }

  // Create a simple Readable Stream to simulate AI output
  const stream = new Readable({
    read() {
      // Push chunks of data to simulate a streaming response
      this.push(`Data chunk ${requestCount}... `);
      this.push('Processing complete.\n');
      this.push(null); // End stream
    },
  });

  // Set headers for streaming
  res.setHeader('Content-Type', 'text/plain');
  res.setHeader('Transfer-Encoding', 'chunked');

  // Pipe the stream to the response
  stream.pipe(res);
});

// ============================================================================
// 5. Server Initialization
// ============================================================================

/**
 * Starts the server and initializes dependencies.
 * In Kubernetes, the container starts immediately, but the readiness probe
 * will block traffic until this function completes.
 */
async function startServer() {
  // Start listening immediately (common pattern for K8s readiness)
  app.listen(PORT, () => {
    console.log(`[Server] Listening on port ${PORT}`);
  });

  // Asynchronously load the model (non-blocking to the server startup)
  await loadAIModel();
}

// Execute
startServer().catch(console.error);
