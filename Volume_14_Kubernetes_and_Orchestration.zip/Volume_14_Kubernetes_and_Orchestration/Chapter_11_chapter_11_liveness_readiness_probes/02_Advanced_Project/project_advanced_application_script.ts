/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

/**
 * File: health-check-server.ts
 * 
 * Description:
 * A standalone Node.js server simulating Kubernetes Liveness and Readiness probes
 * for a Next.js application serving AI models. This acts as a sidecar pattern
 * or a dedicated health check endpoint within the main Next.js API routes.
 * 
 * Context: Book 14, Chapter 11 - Advanced Application Script
 */

import { createServer, Server, IncomingMessage, ServerResponse } from 'http';

// ============================================================================
// 1. Configuration & State Management
// ============================================================================

/**
 * ApplicationState
 * Represents the lifecycle status of the AI service.
 * - INITIALIZING: App is starting up (loading models, connecting to DB).
 * - READY: All dependencies are met; traffic can be routed.
 * - UNHEALTHY: Critical failure detected (e.g., model crash).
 */
enum ApplicationState {
  INITIALIZING = 'INITIALIZING',
  READY = 'READY',
  UNHEALTHY = 'UNHEALTHY',
}

/**
 * ServiceConfig
 * Configuration for the health check server and simulated AI workload.
 */
const ServiceConfig = {
  port: 9090, // Port for health checks (separate from Next.js port 3000)
  aiModelLoadTimeMs: 3000, // Simulated time to load a heavy AI model
  maxFailureThreshold: 3, // Consecutive failures allowed before marking Unhealthy
  checkIntervalMs: 1000, // Frequency of internal health checks
};

/**
 * Global State
 * Tracks the current status of the application and failure counts.
 */
const AppState: {
  status: ApplicationState;
  readinessFailureCount: number;
  isDatabaseConnected: boolean;
  isModelLoaded: boolean;
} = {
  status: ApplicationState.INITIALIZING,
  readinessFailureCount: 0,
  isDatabaseConnected: false,
  isModelLoaded: false,
};

// ============================================================================
// 2. Simulated AI & Infrastructure Logic (The "Why" of Probes)
// ============================================================================

/**
 * Simulates a heavy asynchronous operation, such as initializing a 
 * TensorFlow.js model or establishing a connection to a Vector Database (Pinecone/Milvus).
 * 
 * In a real RAG Pipeline, this would be:
 * 1. Loading embedding models (e.g., 'Xenova/all-MiniLM-L6-v2').
 * 2. Connecting to the vector store.
 * 3. Warming up the LLM inference engine.
 */
async function initializeAIWorkload(): Promise<void> {
  console.log(`[System] Initializing AI Model (Estimated: ${ServiceConfig.aiModelLoadTimeMs}ms)...`);
  
  return new Promise((resolve) => {
    setTimeout(() => {
      AppState.isModelLoaded = true;
      console.log('[System] AI Model Loaded successfully.');
      resolve();
    }, ServiceConfig.aiModelLoadTimeMs);
  });
}

/**
 * Simulates a database connection check.
 * In a real app, this would query the database to ensure connectivity.
 */
function checkDatabaseConnection(): boolean {
  // Simulate a random network blip causing DB connection to drop
  const randomBlip = Math.random() > 0.95; 
  if (randomBlip) {
    AppState.isDatabaseConnected = false;
    console.warn('[System] Database connection lost!');
    return false;
  }
  
  // Reconnect if dropped
  if (!AppState.isDatabaseConnected) {
    console.log('[System] Re-establishing DB connection...');
    AppState.isDatabaseConnected = true;
  }
  return true;
}

/**
 * The "Max Iteration Policy" equivalent for startup.
 * Prevents the app from staying in an infinite initialization loop.
 * If startup takes too long, we mark it as Unhealthy to trigger a restart.
 */
function enforceStartupGuardrail(): void {
  // In a real scenario, we might track elapsed time since start.
  // Here, we simply ensure we don't get stuck in INITIALIZING forever.
  if (AppState.status === ApplicationState.INITIALIZING && AppState.isModelLoaded) {
    AppState.status = ApplicationState.READY;
    console.log(`[System] Transitioned to state: ${AppState.status}`);
  }
}

// ============================================================================
// 3. Probe Logic (Liveness vs. Readiness)
// ============================================================================

/**
 * Liveness Probe Logic.
 * Checks: "Is the process running?"
 * 
 * In Node.js/Next.js context:
 * - If the event loop is blocked, this endpoint might not even respond.
 * - We check basic internal consistency. If the app is in a fatal state,
 *   we return 500 to signal Kubernetes to restart the pod.
 * 
 * Note: For Node.js, a liveness probe should be lightweight. 
 * Do not check external dependencies (DB, Redis) here.
 */
function handleLivenessCheck(res: ServerResponse): void {
  // If the app has explicitly crashed or entered a fatal state
  if (AppState.status === ApplicationState.UNHEALTHY) {
    res.writeHead(500, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ status: 'FAIL', message: 'Fatal internal error' }));
    return;
  }

  // If we are just initializing, we are technically "alive" but not ready.
  // Kubernetes usually considers 200 OK as alive, regardless of readiness.
  res.writeHead(200, { 'Content-Type': 'application/json' });
  res.end(JSON.stringify({ status: 'OK', state: AppState.status }));
}

/**
 * Readiness Probe Logic.
 * Checks: "Can this pod accept user traffic?"
 * 
 * Logic:
 * 1. Check internal dependencies (Model loaded).
 * 2. Check external dependencies (Database, Redis, 3rd party APIs).
 * 3. Increment failure counter if checks fail.
 * 4. If failures exceed threshold, return 503 (Service Unavailable).
 * 
 * Kubernetes Action: 503 removes the pod from the Service Endpoint.
 */
function handleReadinessCheck(res: ServerResponse): void {
  let isReady = true;
  let reason = '';

  // Check 1: Is the AI Model Loaded?
  if (!AppState.isModelLoaded) {
    isReady = false;
    reason = 'AI Model not loaded';
  }

  // Check 2: Is Database Connected? (Simulate check)
  if (!checkDatabaseConnection()) {
    isReady = false;
    reason = 'Database disconnected';
  }

  // Logic: Failure Thresholding
  if (!isReady) {
    AppState.readinessFailureCount++;
    console.warn(`[Readiness] Check failed (${AppState.readinessFailureCount}/${ServiceConfig.maxFailureThreshold}): ${reason}`);

    if (AppState.readinessFailureCount >= ServiceConfig.maxFailureThreshold) {
      // Traffic is blocked
      res.writeHead(503, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ status: 'FAIL', reason: reason, failures: AppState.readinessFailureCount }));
      return;
    } else {
      // Still within grace period, return 200 (Kubernetes 'successThreshold' logic handles this)
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ status: 'OK', warning: 'Transient issue, within grace period' }));
      return;
    }
  }

  // Reset failure count on success
  AppState.readinessFailureCount = 0;
  res.writeHead(200, { 'Content-Type': 'application/json' });
  res.end(JSON.stringify({ status: 'OK', message: 'Ready to accept traffic' }));
}

// ============================================================================
// 4. Server Initialization & Routing
// ============================================================================

/**
 * Main Server Entry Point.
 * Initializes the AI workload and starts the HTTP server for probes.
 */
async function startHealthCheckServer(): Promise<void> {
  // 1. Start background initialization
  initializeAIWorkload().then(() => {
    enforceStartupGuardrail();
  });

  // 2. Create HTTP Server
  const server: Server = createServer((req: IncomingMessage, res: ServerResponse) => {
    // Route based on URL path
    if (req.url === '/live' && req.method === 'GET') {
      handleLivenessCheck(res);
    } else if (req.url === '/ready' && req.method === 'GET') {
      handleReadinessCheck(res);
    } else {
      res.writeHead(404);
      res.end('Not Found');
    }
  });

  // 3. Start Listening
  server.listen(ServiceConfig.port, () => {
    console.log(`\n🚀 Health Check Server running on http://localhost:${ServiceConfig.port}`);
    console.log(`   Liveness:  http://localhost:${ServiceConfig.port}/live`);
    console.log(`   Readiness: http://localhost:${ServiceConfig.port}/ready`);
    console.log(`\n[Sim] Next.js App (Main) would run on port 3000.`);
    console.log(`[K8s] In a real cluster, the container is killed if /live fails, and removed from LB if /ready fails.\n`);
  });
}

// Start the simulation
startHealthCheckServer();
