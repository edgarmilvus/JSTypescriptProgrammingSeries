/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

// server.ts (Extended)
import express, { Request, Response } from 'express';

const app = express();
const PORT = 3000;

// Simulate database connection state
let isDatabaseConnected = false;

// Mock database connection function
const connectToDatabase = async () => {
  console.log('Connecting to database...');
  await new Promise(resolve => setTimeout(resolve, 15000)); // 15 seconds delay
  isDatabaseConnected = true;
  console.log('Database connected.');
};

// Trigger connection on startup
connectToDatabase();

app.get('/healthz', (req: Request, res: Response) => {
  // Liveness: Process is running
  res.status(200).send('OK');
});

app.get('/ready', (req: Request, res: Response) => {
  // Readiness: Dependencies are ready
  if (isDatabaseConnected) {
    res.status(200).send('Ready');
  } else {
    res.status(503).send('Service Unavailable');
  }
});

app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
