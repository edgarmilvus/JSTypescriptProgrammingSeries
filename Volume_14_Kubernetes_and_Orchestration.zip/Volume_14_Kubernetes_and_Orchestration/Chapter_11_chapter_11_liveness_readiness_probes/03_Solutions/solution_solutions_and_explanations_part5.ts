/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

// ai_server.ts
import express, { Request, Response } from 'express';

const app = express();
const PORT = 3000;

const modelCorrupted = process.env.MODEL_CORRUPTED === 'true';
let isModelLoaded = false;
let crashSimulated = false;

// Simulate model loading (20 seconds)
const loadModel = async () => {
  console.log('Loading AI Model...');
  await new Promise(resolve => setTimeout(resolve, 20000));
  isModelLoaded = true;
  console.log('AI Model loaded.');
};

loadModel();

app.get('/healthz', async (req: Request, res: Response) => {
  // Liveness: Check if process is alive and model isn't corrupted
  if (modelCorrupted && !crashSimulated) {
    // Simulate a crash after 10 seconds of checking
    crashSimulated = true;
    await new Promise(resolve => setTimeout(resolve, 10000));
    return res.status(500).send('Crashing...');
  }
  res.status(200).send('Alive');
});

app.get('/ready', (req: Request, res: Response) => {
  // Readiness: Check if model is loaded
  if (isModelLoaded) {
    res.status(200).send('Ready');
  } else {
    res.status(503).send('Model Loading...');
  }
});

app.listen(PORT, () => {
  console.log(`AI Server running on port ${PORT}`);
});
