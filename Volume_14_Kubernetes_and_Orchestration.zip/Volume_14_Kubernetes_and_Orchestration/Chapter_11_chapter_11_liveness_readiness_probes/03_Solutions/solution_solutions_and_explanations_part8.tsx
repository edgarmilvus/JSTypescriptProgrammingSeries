/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part8.tsx
// Description: Solutions and Explanations
// ==========================================

// ProbeDashboard.tsx
import React, { useState, useEffect } from 'react';

type PodStatus = {
  name: string;
  livenessStatus: 'Healthy' | 'Unhealthy';
  readinessStatus: 'Ready' | 'Not Ready';
  lastChecked: string;
};

type ProbeDashboardProps = {
  pods: PodStatus[];
};

const ProbeDashboard: React.FC<ProbeDashboardProps> = ({ initialPods }) => {
  const [pods, setPods] = useState<PodStatus[]>(initialPods);

  // Helper to get current timestamp
  const getTimestamp = () => new Date().toLocaleTimeString();

  // Simulate automatic background checks
  useEffect(() => {
    const interval = setInterval(() => {
      simulateProbeCheck();
    }, 5000);

    // Cleanup interval on unmount
    return () => clearInterval(interval);
  }, []);

  const simulateProbeCheck = () => {
    setPods(currentPods => 
      currentPods.map(pod => {
        // Randomly flip status for simulation
        const isLivenessHealthy = Math.random() > 0.1; // 10% chance of failure
        const isReadinessReady = Math.random() > 0.2; // 20% chance of not ready

        return {
          ...pod,
          livenessStatus: isLivenessHealthy ? 'Healthy' : 'Unhealthy',
          readinessStatus: isReadinessReady ? 'Ready' : 'Not Ready',
          lastChecked: getTimestamp(),
        };
      })
    );
  };

  // Manual trigger for specific pod
  const handleManualCheck = (podName: string) => {
    setPods(currentPods => 
      currentPods.map(pod => {
        if (pod.name === podName) {
          // Force a "Ready" state for the manual check interaction
          return {
            ...pod,
            readinessStatus: 'Ready',
            lastChecked: getTimestamp(),
          };
        }
        return pod;
      })
    );
  };

  return (
    <div style={{ fontFamily: 'sans-serif', padding: '20px' }}>
      <h2>Kubernetes Probe Dashboard</h2>
      <table style={{ width: '100%', borderCollapse: 'collapse', marginTop: '20px' }}>
        <thead>
          <tr style={{ backgroundColor: '#f2f2f2', textAlign: 'left' }}>
            <th style={{ padding: '12px', border: '1px solid #ddd' }}>Pod Name</th>
            <th style={{ padding: '12px', border: '1px solid #ddd' }}>Liveness</th>
            <th style={{ padding: '12px', border: '1px solid #ddd' }}>Readiness</th>
            <th style={{ padding: '12px', border: '1px solid #ddd' }}>Last Checked</th>
            <th style={{ padding: '12px', border: '1px solid #ddd' }}>Actions</th>
          </tr>
        </thead>
        <tbody>
          {pods.map(pod => (
            <tr key={pod.name}>
              <td style={{ padding: '10px', border: '1px solid #ddd' }}>{pod.name}</td>
              <td style={{ 
                  padding: '10px', 
                  border: '1px solid #ddd', 
                  color: pod.livenessStatus === 'Healthy' ? 'green' : 'red',
                  fontWeight: 'bold'
                }}>
                {pod.livenessStatus}
              </td>
              <td style={{ 
                  padding: '10px', 
                  border: '1px solid #ddd', 
                  color: pod.readinessStatus === 'Ready' ? 'green' : 'red',
                  fontWeight: 'bold'
                }}>
                {pod.readinessStatus}
              </td>
              <td style={{ padding: '10px', border: '1px solid #ddd' }}>{pod.lastChecked}</td>
              <td style={{ padding: '10px', border: '1px solid #ddd' }}>
                <button onClick={() => handleManualCheck(pod.name)}>
                  Check Readiness
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default ProbeDashboard;
