/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * @fileoverview KEDA ScaledObject configuration for an AI Inference Service.
 * This file defines the scaling logic based on a queue length metric.
 * 
 * Context: SaaS Application providing AI Inference.
 * Target: Kubernetes Pods running a Node.js/Python model server.
 */

// 1. CONFIGURATION CONSTANTS
// These represent environment variables or configuration files in a real app.
const CONFIG = {
  namespace: 'ai-inference-ns',
  deploymentName: 'sentiment-analysis-deployment',
  queueName: 'inference-requests-queue',
  minReplicas: 0, // Scale to zero to save costs
  maxReplicas: 10, // Limit costs during traffic spikes
  targetQueueLength: 5, // Scale up if more than 5 messages are waiting
};

/**
 * 2. TYPE DEFINITIONS
 * Using TypeScript interfaces to ensure our KEDA configuration is strictly typed.
 * This prevents common YAML configuration errors like misspelled keys.
 */
interface KedaScaledObject {
  apiVersion: string;
  kind: 'ScaledObject';
  metadata: {
    name: string;
    namespace: string;
  };
  spec: {
    scaleTargetRef: {
      name: string;
    };
    minReplicaCount: number;
    maxReplicaCount: number;
    triggers: Trigger[];
  };
}

interface Trigger {
  type: string;
  metadata: {
    queueName: string;
    messageCount: string; // KEDA expects string values in metadata
  };
}

/**
 * 3. INFRASTRUCTURE AS CODE (IAC)
 * Generates the KEDA ScaledObject manifest programmatically.
 * 
 * @param config - The configuration object defining scaling boundaries.
 * @returns A fully typed KEDA ScaledObject definition.
 */
function createKedaScaledObject(config: typeof CONFIG): KedaScaledObject {
  return {
    apiVersion: 'keda.sh/v1alpha1',
    kind: 'ScaledObject',
    metadata: {
      name: `${config.deploymentName}-scaler`,
      namespace: config.namespace,
    },
    spec: {
      // Reference the Kubernetes Deployment to scale
      scaleTargetRef: {
        name: config.deploymentName,
      },
      // Scaling boundaries
      minReplicaCount: config.minReplicaCount,
      maxReplicaCount: config.maxReplicas,
      // The Triggers: This is the core of event-driven scaling
      triggers: [
        {
          // We use the 'aws-sqs-queue' scaler (simulated here as generic 'queue')
          // In production, this would be 'aws-sqs-queue', 'azure-queue', or 'prometheus'
          type: 'queue', 
          metadata: {
            queueName: config.queueName,
            // KEDA polls this metric. If 'messageCount' > target, KEDA scales the deployment.
            messageCount: config.targetQueueLength.toString(), 
          },
        },
      ],
    },
  };
}

/**
 * 4. EXECUTION BLOCK
 * Simulates the generation and logging of the configuration.
 * In a real scenario, this would be passed to a Kubernetes client or Pulumi stack.
 */
function main() {
  console.log('--- Generating KEDA ScaledObject Configuration ---');
  
  const scaledObject = createKedaScaledObject(CONFIG);
  
  // Outputting the configuration as JSON (simulating a YAML conversion)
  console.log(JSON.stringify(scaledObject, null, 2));
  
  console.log('\n--- Explanation of Scaling Behavior ---');
  console.log(`1. When queue "${CONFIG.queueName}" has 0-5 messages:`);
  console.log(`   -> KEDA maintains ${CONFIG.minReplicaCount} replica(s) (Scale to Zero active).`);
  console.log(`2. When queue "${CONFIG.queueName}" has > ${CONFIG.targetQueueLength} messages:`);
  console.log(`   -> KEDA calculates replicas: ceil(5 / 5) = 1 pod.`);
  console.log(`3. As queue grows, KEDA calculates: ceil(20 / 5) = 4 pods.`);
}

// Run the simulation
main();
