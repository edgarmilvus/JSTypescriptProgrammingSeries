/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// pages/api/infer.ts
// pages/api/metrics.ts
// components/InferenceClient.tsx

import { NextApiRequest, NextApiResponse } from 'next';
import { useEffect, useState } from 'react';

/**
 * ============================================================================
 * 1. SHARED TYPES & STATE MANAGEMENT
 * ============================================================================
 * In a real distributed system, this state would reside in Redis or a Database.
 * For this local simulation, we use a global in-memory map.
 */

interface InferenceJob {
  id: string;
  status: 'pending' | 'processing' | 'completed';
  timestamp: number;
}

// Global store to simulate a shared queue across potential pods
const jobStore = new Map<string, InferenceJob>();

/**
 * ============================================================================
 * 2. API ROUTE: /api/infer
 * ============================================================================
 * Simulates an AI Inference endpoint.
 * 
 * Logic:
 * 1. Receives a request payload.
 * 2. Adds the job to the global queue (Status: 'pending').
 * 3. Simulates an asynchronous heavy computation (e.g., LLM generation).
 * 4. Updates status to 'completed' after a delay.
 * 
 * KEDA Context: The duration a job stays in 'pending' or 'processing' 
 * directly contributes to the queue depth metric exposed by /api/metrics.
 */

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  const jobId = `job_${Date.now()}`;
  const { prompt } = req.body;

  // 1. Initialize Job
  jobStore.set(jobId, {
    id: jobId,
    status: 'pending',
    timestamp: Date.now(),
  });

  // 2. Simulate Async Processing (Non-blocking)
  // In a real app, this would be a background worker or a server action.
  processInferenceJob(jobId, prompt).catch(console.error);

  // 3. Immediate Response
  // We return immediately, acknowledging the request. 
  // The client can poll for status or we use WebSockets (omitted for brevity).
  res.status(202).json({ 
    message: 'Inference request accepted', 
    jobId,
    estimatedTime: '5 seconds' 
  });
}

/**
 * Simulates the AI workload processing.
 * @param jobId - The unique identifier for the job.
 * @param prompt - The input text.
 */
async function processInferenceJob(jobId: string, prompt: string) {
  const job = jobStore.get(jobId);
  if (!job) return;

  // Update to processing
  job.status = 'processing';
  jobStore.set(jobId, job);

  // Simulate GPU inference latency (e.g., 3 to 8 seconds)
  const processingTime = Math.floor(Math.random() * 5000) + 3000;
  
  await new Promise(resolve => setTimeout(resolve, processingTime));

  // Mark as completed
  const completedJob = jobStore.get(jobId);
  if (completedJob) {
    completedJob.status = 'completed';
    jobStore.set(jobId, completedJob);
  }
}

/**
 * ============================================================================
 * 3. API ROUTE: /api/metrics
 * ============================================================================
 * Exposes custom metrics for KEDA to consume.
 * 
 * KEDA Configuration Context:
 * In your Kubernetes ScaledObject, you would configure a 'prometheus' scaler:
 * 
 * metrics:
 *   - type: prometheus
 *     metadata:
 *       serverAddress: http://nextjs-app.default.svc.cluster.local
 *       metricName: inference_queue_depth
 *       query: inference_queue_depth
 *       threshold: '10'
 * 
 * This query calculates the number of jobs NOT in 'completed' status.
 */

export function getMetrics() {
  const jobs = Array.from(jobStore.values());
  
  // Calculate Queue Depth: Pending + Processing jobs
  const queueDepth = jobs.filter(j => j.status !== 'completed').length;
  
  // Prometheus Exposition Format
  // HELP: Describes the metric
  # TYPE: Defines the metric type (gauge, counter, histogram)
  return `# HELP inference_queue_depth Number of pending or processing inference jobs.
# TYPE inference_queue_depth gauge
inference_queue_depth ${queueDepth}\n`;
}

export function metricsHandler(req: NextApiRequest, res: NextApiResponse) {
  // KEDA expects a text/plain response in Prometheus format
  res.setHeader('Content-Type', 'text/plain');
  res.status(200).send(getMetrics());
}

// We need to export the handler specifically for the metrics route
// (Assuming separate files in a real Next.js app, but combined here for the snippet)
export { metricsHandler as handler as MetricsHandler }; 
// Note: In a real setup, this logic would be in pages/api/metrics.ts
// and the infer logic in pages/api/infer.ts.

/**
 * ============================================================================
 * 4. CLIENT COMPONENT: /components/InferenceClient.tsx
 * ============================================================================
 * A React component to trigger requests and visualize the queue state.
 */

export function InferenceClient() {
  const [queueDepth, setQueueDepth] = useState<number>(0);
  const [loading, setLoading] = useState<boolean>(false);
  const [logs, setLogs] = useState<string[]>([]);

  // Poll metrics every 2 seconds to visualize scaling potential
  useEffect(() => {
    const interval = setInterval(async () => {
      try {
        // In a real app, this hits the /api/metrics endpoint
        // For this demo, we simulate the calculation locally
        const response = await fetch('/api/metrics');
        const text = await response.text();
        const match = text.match(/inference_queue_depth (\d+)/);
        if (match) {
          setQueueDepth(parseInt(match[1], 10));
        }
      } catch (err) {
        console.error('Failed to fetch metrics', err);
      }
    }, 2000);
    return () => clearInterval(interval);
  }, []);

  const triggerInference = async () => {
    setLoading(true);
    const prompt = "Generate a summary of KEDA scaling principles.";
    
    try {
      const res = await fetch('/api/infer', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt })
      });
      
      const data = await res.json();
      setLogs(prev => [`[${new Date().toLocaleTimeString()}] Job ${data.jobId} accepted.`, ...prev]);
    } catch (error) {
      setLogs(prev => [`Error triggering inference`, ...prev]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{ padding: '20px', fontFamily: 'monospace' }}>
      <h2>AI Inference Simulator</h2>
      
      <div style={{ marginBottom: '20px', border: '1px solid #ccc', padding: '10px' }}>
        <h3>Current State (Simulated KEDA Metrics)</h3>
        <p>Queue Depth: <strong>{queueDepth}</strong></p>
        <p>
          <em>
            (KEDA would scale pods if this number exceeds the threshold. 
            Threshold = 10 requests per pod in this scenario.)
          </em>
        </p>
      </div>

      <button 
        onClick={triggerInference} 
        disabled={loading}
        style={{ padding: '10px 20px', cursor: 'pointer' }}
      >
        {loading ? 'Processing...' : 'Trigger Inference Job'}
      </button>

      <div style={{ marginTop: '20px' }}>
        <h4>Job Logs:</h4>
        <ul>
          {logs.map((log, idx) => <li key={idx}>{log}</li>)}
        </ul>
      </div>
    </div>
  );
}
