/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useEffect } from 'react';
import useSWR from 'swr';

// Define the type for the health response
type HealthStatus = {
  status: 'ready' | 'warming' | 'unreachable';
  replicas: number;
};

// Mock fetcher for demonstration
const fetcher = (url: string) => 
  fetch(url).then(res => res.json()) as Promise<HealthStatus>;

export default function SmartHealthDashboard() {
  // 1. State Management: useSWR to poll the health endpoint every 2 seconds
  const { data, error } = useSWR<HealthStatus>('/api/health', fetcher, {
    refreshInterval: 2000,
    revalidateOnFocus: false,
  });

  // 2. Pre-warming Logic: Trigger immediately if replicas are 0
  useEffect(() => {
    // Ensure data exists and replicas are 0
    if (data && data.replicas === 0) {
      console.log("Cluster is cold. Triggering pre-warm...");
      
      // Fire-and-forget request to wake up the cluster
      // We don't await this, nor do we care about the response for the UI state
      fetch('/api/prewarm', { method: 'POST' }).catch(() => {
        // Silently fail or log to telemetry
        console.error("Pre-warm request failed");
      });
    }
  }, [data]); // Rerun effect when data changes

  // 3. Type Narrowing & UI Feedback
  if (error) {
    return <div className="status-error">Error connecting to service.</div>;
  }

  if (!data) {
    return <div className="status-loading">Checking service status...</div>;
  }

  // Narrowing the type based on replicas count
  if (data.replicas === 0) {
    return (
      <div className="status-warming">
        {/* Visual feedback indicating the wake-up process */}
        Waking up the cluster... (Current status: {data.status})
      </div>
    );
  }

  // Service is active
  return (
    <div className="status-ready">
      Ready ({data.replicas} replica(s) active)
    </div>
  );
}
