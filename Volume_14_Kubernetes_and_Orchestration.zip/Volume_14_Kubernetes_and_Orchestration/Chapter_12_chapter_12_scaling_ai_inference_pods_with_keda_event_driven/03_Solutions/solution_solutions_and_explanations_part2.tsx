/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState, useCallback } from 'react';

// 1. Type Safety: Define the interface for metrics
interface QueueMetrics {
  queueDepth: number;
  maxQueue: number;
}

// Mock API call as requested
const fetchQueueMetrics = async (): Promise<QueueMetrics> => {
  // Simulate network delay
  await new Promise(resolve => setTimeout(resolve, 300));
  
  // Mock return values (randomized for demo purposes)
  return {
    queueDepth: Math.floor(Math.random() * 60), // Simulates varying load
    maxQueue: 100
  };
};

export default function ChatInput({ onSubmit }: { onSubmit: (msg: string) => void }) {
  const [message, setMessage] = useState('');
  const [isBusy, setIsBusy] = useState(false);
  const [tooltip, setTooltip] = useState<string | null>(null);

  // 2. Debouncing & Logic: Handle submission with queue check
  const handleSubmit = useCallback(async (e: React.FormEvent) => {
    e.preventDefault();
    if (!message.trim()) return;

    setIsBusy(true);
    setTooltip(null);

    try {
      // Check metrics before allowing submission
      const metrics = await fetchQueueMetrics();
      
      // 3. Capacity Check: 80% threshold
      const capacityRatio = metrics.queueDepth / metrics.maxQueue;
      
      if (capacityRatio >= 0.8) {
        setTooltip("System is under heavy load. Please wait a moment.");
        setIsBusy(false);
        return; // Stop execution here
      }

      // If clear, submit
      onSubmit(message);
      setMessage('');
    } catch (error) {
      setTooltip("Error checking system load.");
    } finally {
      setIsBusy(false);
    }
  }, [message, onSubmit]);

  // Determine if button should be disabled
  const isDisabled = isBusy || (tooltip !== null && tooltip.length > 0);

  return (
    <div className="chat-input-container">
      <form onSubmit={handleSubmit}>
        <input
          type="text"
          value={message}
          onChange={(e) => {
            setMessage(e.target.value);
            // Clear tooltip on typing to give user immediate feedback
            if (tooltip) setTooltip(null);
          }}
          placeholder="Type a message..."
          disabled={isBusy}
        />
        <button type="submit" disabled={isDisabled}>
          {isBusy ? 'Checking...' : 'Send'}
        </button>
      </form>
      
      {/* 4. UI State: Tooltip for capacity warning */}
      {tooltip && (
        <div className="queue-tooltip" style={{ color: 'orange', marginTop: '5px' }}>
          ⚠️ {tooltip}
        </div>
      )}
    </div>
  );
}
