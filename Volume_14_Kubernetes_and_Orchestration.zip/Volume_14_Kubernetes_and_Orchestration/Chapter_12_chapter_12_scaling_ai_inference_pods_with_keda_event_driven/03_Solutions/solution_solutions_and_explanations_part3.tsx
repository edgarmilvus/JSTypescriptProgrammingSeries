/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState, useEffect, useCallback } from 'react';

// Mock hooks provided in the prompt
const useAIState = () => {
  const [state, setState] = useState({ status: 'idle' });
  return [state, setState] as const;
};
const useUIState = () => {
  const [ui, setUi] = useState({ message: '' });
  return [ui, setUi] as const;
};

// 1. Keyword Detection Logic
const detectComplexity = (input: string): boolean => {
  const complexKeywords = ['analyze', 'reason', 'code', 'debug', 'explain logic'];
  const lowerInput = input.toLowerCase();
  return complexKeywords.some(keyword => lowerInput.includes(keyword));
};

// 2. Predictive Scaling Hook
function usePredictiveScale(model: 'A' | 'B', isComplex: boolean) {
  const [, setUiState] = useUIState();

  useEffect(() => {
    if (model === 'B' && isComplex) {
      // Trigger pre-warm for Model B
      console.log(`Predictive scaling: Waking up Model ${model}...`);
      
      // Update UI state for user feedback
      setUiState({ message: 'Preparing advanced reasoning engine...' });

      // Fire-and-forget fetch
      fetch(`/api/model-${model.toLowerCase()}/prewarm`, { method: 'POST' })
        .then(() => {
          // Reset UI message after a short delay or success
          setTimeout(() => setUiState({ message: '' }), 2000);
        })
        .catch(() => setUiState({ message: '' }));
    }
  }, [model, isComplex, setUiState]);
}

export default function IntelligentModelRouter() {
  const [input, setInput] = useState('');
  const [uiState] = useUIState();
  const [aiState, setAiState] = useAIState();
  
  // Detect complexity on every input change
  const isComplex = detectComplexity(input);

  // 3. Trigger predictive scaling
  // We pass 'B' because that is the model used for complex tasks
  usePredictiveScale('B', isComplex);

  // 4. Routing Logic
  const handleSubmit = useCallback(async () => {
    if (!input.trim()) return;

    setAiState({ status: 'loading' });

    // Dynamic URL construction based on complexity
    const targetModel = isComplex ? 'B' : 'A';
    const endpoint = `/api/model-${targetModel}/inference`;

    console.log(`Routing to Model ${targetModel} at ${endpoint}`);

    // Simulate API call
    const response = await fetch(endpoint, {
      method: 'POST',
      body: JSON.stringify({ prompt: input })
    });
    
    const result = await response.json();
    setAiState({ status: 'idle' });
    alert(`Response from Model ${targetModel}: ${result.text}`);
  }, [input, isComplex, setAiState]);

  return (
    <div className="router-container">
      <div className="status-bar">
        <strong>Current Mode:</strong> {isComplex ? 'Advanced (Model B)' : 'Standard (Model A)'}
      </div>

      <textarea
        value={input}
        onChange={(e) => setInput(e.target.value)}
        placeholder="Ask a question..."
        rows={4}
        style={{ width: '100%', marginBottom: '10px' }}
      />

      {/* UI State Integration */}
      {uiState.message && (
        <div className="predictive-indicator" style={{ color: '#007bff', fontSize: '0.9rem', marginBottom: '10px' }}>
          ℹ️ {uiState.message}
        </div>
      )}

      <button onClick={handleSubmit} disabled={aiState.status === 'loading'}>
        {aiState.status === 'loading' ? 'Processing...' : 'Send Request'}
      </button>
    </div>
  );
}
