/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.tsx
// Description: Solutions and Explanations
// ==========================================

/**
 * -------------------------------------------------------------------------
 * TECHNICAL EXPLANATION: KEDA ScaledObject Flow (minReplicaCount: 0)
 * -------------------------------------------------------------------------
 * 
 * When `minReplicaCount` is set to 0, KEDA allows the application to scale 
 * down to zero replicas when there are no external metrics or events to process.
 * 
 * FLOW:
 * 1. Idle State: The application has 0 pods. The KEDA Operator is monitoring 
 *    the metric source (e.g., RabbitMQ queue length, Prometheus custom metric).
 * 
 * 2. Request Initiation: A user sends a request to the Ingress/Gateway.
 *    - The Ingress routes traffic to the Kubernetes Service.
 *    - The Service attempts to route to a Pod.
 *    - Since no Pods exist (Endpoints list is empty), the request fails 
 *      immediately with a 503 Service Unavailable (or connection refused).
 * 
 * 3. KEDA Activation (The "Cold Start" Trigger):
 *    - Although the request failed, the KEDA Operator detects a change in 
 *      the metric value (e.g., queue depth increases from 0 to 1).
 *    - KEDA calculates the required replicas based on the ScaledObject formula.
 *    - KEDA scales the Deployment from 0 to N replicas.
 *    - Kubernetes starts pulling images and initializing pods (this takes time).
 * 
 * 4. Subsequent Requests:
 *    - The user (or client) must retry the request.
 *    - Once the first pod becomes Ready (passes health checks), traffic is routed.
 *    - The request succeeds.
 * 
 * -------------------------------------------------------------------------
 * VISUALIZATION: Graphviz DOT Diagram
 * -------------------------------------------------------------------------
 */

export const kedaFlowDiagram = `
digraph KEDA_Flow {
    rankdir=LR;
    node [shape=box, style="rounded,filled", fontname="Arial"];
    
    // Nodes
    User [label="User Request", shape=ellipse, fillcolor="#e1f5fe"];
    Ingress [label="Ingress / Gateway", fillcolor="#fff3e0"];
    Service [label="Kubernetes Service", fillcolor="#fff3e0"];
    Keda [label="KEDA Operator", fillcolor="#e8f5e9", shape="cylinder"];
    Pod1 [label="AI Pod (Running)", fillcolor="#c8e6c9"];
    Pod0 [label="No Pods (0 Replicas)", fillcolor="#ffcdd2"];
    
    // Happy Path (Warm State)
    subgraph cluster_happy {
        label = "HAPPY PATH (Warm)";
        style = dashed;
        color = green;
        
        User -> Ingress [label="1. HTTP Request"];
        Ingress -> Service;
        Service -> Pod1 [label="Routes to Pod"];
    }

    // Cold Start Path
    subgraph cluster_cold {
        label = "COLD START PATH (Scaled to 0)";
        style = dashed;
        color = red;
        
        User -> Ingress_Cold [label="1. HTTP Request"];
        Ingress_Cold -> Service_Cold;
        Service_Cold -> Pod0 [label="Fails (No Endpoints)", fontcolor="red", color="red"];
        
        // Trigger Mechanism
        Service_Cold -> Keda [label="2. Metric Spike Detected", style="dotted", color="blue"];
        Keda -> Deployment [label="3. Scale Up (0 -> N)", style="dotted", color="blue"];
        Deployment -> Pod1 [label="4. Pod Initialization", style="dotted", color="blue"];
        
        // Retry
        User_Retry [label="User Retries", shape=ellipse, fillcolor="#e1f5fe"];
        User_Retry -> Pod1 [label="5. Success", style="bold", color="green"];
        
        // Hidden nodes for layout
        Ingress_Cold [label="Ingress / Gateway", fillcolor="#fff3e0"];
        Service_Cold [label="Kubernetes Service", fillcolor="#fff3e0"];
        Deployment [label="Deployment Controller", fillcolor="#fff3e0"];
    }
}
`;
