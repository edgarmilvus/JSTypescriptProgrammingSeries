/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

// src/index.ts
/**
 * A simple Node.js application to simulate a GPU-intensive workload.
 * This script performs matrix multiplication to demonstrate CPU vs. GPU load.
 * In a real AI application, this would be replaced by a model inference call.
 */

/**
 * Generates a matrix of a given size filled with random numbers.
 * @param size - The dimension of the square matrix (e.g., 1000x1000).
 * @returns A 2D array representing the matrix.
 */
function generateMatrix(size: number): number[][] {
    const matrix: number[][] = [];
    for (let i = 0; i < size; i++) {
        const row: number[] = [];
        for (let j = 0; j < size; j++) {
            row.push(Math.random());
        }
        matrix.push(row);
    }
    return matrix;
}

/**
 * Performs matrix multiplication of two matrices.
 * NOTE: This is a naive O(n^3) implementation for demonstration purposes.
 * @param a - The first matrix.
 * @param b - The second matrix.
 * @returns The resulting matrix.
 */
function multiplyMatrices(a: number[][], b: number[][]): number[][] {
    const aRows = a.length;
    const aCols = a[0].length;
    const bCols = b[0].length;
    const result: number[][] = new Array(aRows);

    for (let i = 0; i < aRows; i++) {
        result[i] = new Array(bCols).fill(0);
        for (let j = 0; j < bCols; j++) {
            for (let k = 0; k < aCols; k++) {
                result[i][j] += a[i][k] * b[k][j];
            }
        }
    }
    return result;
}

/**
 * Main execution function.
 * Logs the start and end of the computation to demonstrate execution time.
 */
async function main() {
    console.log("🚀 Starting GPU-intensive simulation (Matrix Multiplication)...");
    const matrixSize = 2000; // A size that is noticeable on CPU but fast on GPU
    
    console.log(`Generating two ${matrixSize}x${matrixSize} matrices...`);
    const startGen = Date.now();
    const matrixA = generateMatrix(matrixSize);
    const matrixB = generateMatrix(matrixSize);
    console.log(`Generation took ${Date.now() - startGen}ms.`);

    console.log("Multiplying matrices...");
    const startMult = Date.now();
    // In a real scenario, we would offload this to a GPU library
    const result = multiplyMatrices(matrixA, matrixB);
    const duration = Date.now() - startMult;
    
    console.log(`✅ Multiplication completed in ${duration}ms.`);
    console.log(`Result matrix dimensions: ${result.length}x${result[0].length}`);
    
    // Keep the container running for liveness probes
    setInterval(() => {
        console.log("Worker heartbeat...");
    }, 60000);
}

// Execute the main function
main().catch(console.error);
