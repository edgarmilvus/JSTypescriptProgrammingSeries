/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.ts
// Description: Basic Code Example
// ==========================================

# k8s/gpu-deployment.yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: gpu-matrix-worker
  namespace: default
spec:
  replicas: 1
  selector:
    matchLabels:
      app: gpu-worker
  template:
    metadata:
      labels:
        app: gpu-worker
    spec:
      # 1. NODE SELECTOR: Directs the scheduler to nodes labeled with 'accelerator: nvidia-tesla-t4'
      # This ensures the pod lands on a node pool configured with specific GPU hardware.
      nodeSelector:
        accelerator: nvidia-tesla-t4

      # 2. TOLERATION: Allows the pod to be scheduled on nodes with specific taints.
      # Often, GPU nodes are tainted to prevent non-GPU workloads from consuming them.
      tolerations:
      - key: "nvidia.com/gpu"
        operator: "Exists"
        effect: "NoSchedule"

      containers:
      - name: matrix-worker
        # A lightweight Node.js image (ensure it has the necessary dependencies for your app)
        image: node:18-alpine
        command: ["node", "/app/dist/index.js"]
        
        # 3. RESOURCE LIMITS: The critical part for GPU scheduling.
        # 'nvidia.com/gpu' is the standard resource name for NVIDIA GPUs managed by the device plugin.
        # Requesting '1' GPU tells Kubernetes to allocate one full GPU device to this container.
        resources:
          limits:
            nvidia.com/gpu: 1
            # Note: You typically do not request CPU/Memory limits for GPUs explicitly here unless needed,
            # but it's good practice to define them to avoid resource starvation.
            cpu: "1"
            memory: "2Gi"
          requests:
            cpu: "500m"
            memory: "1Gi"

        # Mount the source code (in production, build the image with code baked in)
        volumeMounts:
        - name: app-volume
          mountPath: /app
      volumes:
      - name: app-volume
        hostPath:
          path: /path/to/your/local/project # Replace with actual path
          type: Directory
