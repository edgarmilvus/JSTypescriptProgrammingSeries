/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// pages/api/generate-stream.ts
// Next.js API Route for handling GPU-accelerated AI inference with streaming.

import type { NextApiRequest, NextApiResponse } from 'next';

/**
 * @description Configuration for Kubernetes GPU Node Pools.
 * In a real scenario, these would be labels applied to Nodes via the NVIDIA Device Plugin.
 * We use Taints to prevent non-GPU workloads from scheduling on these nodes.
 */
const GPU_NODE_POOL_CONFIG = {
  // Label selector for nodes with NVIDIA GPUs
  nodeSelector: 'accelerator=nvidia-tesla-t4',
  // Taint key that requires a specific toleration
  taintKey: 'nvidia.com/gpu',
  taintValue: 'present',
  taintEffect: 'NoSchedule',
};

/**
 * @description Simulates the Kubernetes Scheduler logic.
 * Checks if the requesting pod has the correct tolerations to run on a GPU node.
 * In a real cluster, this logic is handled by the Kubernetes API Server and the GPU Device Plugin.
 */
const validateGPUToleration = (podSpec: any): boolean => {
  const tolerations = podSpec.tolerations || [];
  return tolerations.some(
    (t: any) =>
      t.key === GPU_NODE_POOL_CONFIG.taintKey &&
      t.operator === 'Equal' &&
      t.value === GPU_NODE_POOL_CONFIG.taintValue &&
      t.effect === GPU_NODE_POOL_CONFIG.taintEffect
  );
};

/**
 * @description Mocks the execution of an AI model on a GPU.
 * Simulates "Model Streaming" by yielding tokens sequentially.
 * In production, this would be a gRPC call to a separate inference service (e.g., Triton Inference Server)
 * running in the cluster, or a direct call to a library like ONNX Runtime with CUDA bindings.
 */
async function* mockGPUInference(prompt: string): AsyncGenerator<string, void, unknown> {
  // Simulate GPU warm-up time (common in high-throughput inference)
  await new Promise(resolve => setTimeout(resolve, 300));

  const responseTokens = [
    `Processing prompt: "${prompt}" on GPU...`,
    '\n\n[Token 1] Initiating model layers...',
    ' [Token 2] Loading weights...',
    ' [Token 3] Computing attention mechanism...',
    ' [Token 4] Generating response stream...',
    `\n\nResult: The GPU scheduled workload for "${prompt}" completed successfully.`
  ];

  for (const token of responseTokens) {
    // Simulate network latency and compute time per token
    await new Promise(resolve => setTimeout(resolve, 150));
    yield token;
  }
}

/**
 * @description Main API Handler.
 * Establishes SSE connection, validates GPU scheduling constraints, and streams data.
 */
export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  // 1. Validate Request Method
  if (req.method !== 'POST') {
    res.status(405).json({ error: 'Method Not Allowed' });
    return;
  }

  // 2. Parse Input
  const { prompt } = req.body;
  if (!prompt) {
    res.status(400).json({ error: 'Prompt is required' });
    return;
  }

  // 3. Setup Server-Sent Events (SSE) Headers
  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache');
  res.setHeader('Connection', 'keep-alive');
  res.flushHeaders(); // Flush headers immediately to open the connection

  // 4. Simulate Pod Spec (Client-side context passed via headers or body)
  // In a real K8s setup, the 'scheduler' inspects the Pod spec. Here we simulate that check.
  const incomingPodSpec = {
    tolerations: [
      {
        key: 'nvidia.com/gpu',
        operator: 'Equal',
        value: 'present',
        effect: 'NoSchedule',
      },
    ],
  };

  // 5. Enforce GPU Scheduling Constraints
  if (!validateGPUToleration(incomingPodSpec)) {
    res.write(`data: ${JSON.stringify({ error: 'Pod lacks GPU toleration. Scheduling failed.' })}\n\n`);
    res.end();
    return;
  }

  // 6. Stream Processing Loop
  try {
    // Simulate the request being routed to a Node with available GPU resources
    res.write(`data: ${JSON.stringify({ status: 'Scheduling: Node selected (GPU available).' })}\n\n`);

    const inferenceStream = mockGPUInference(prompt);

    for await (const chunk of inferenceStream) {
      // 7. Send Data Chunk via SSE
      // Format: "data: { ...json }\n\n"
      const payload = {
        token: chunk,
        timestamp: new Date().toISOString(),
      };
      res.write(`data: ${JSON.stringify(payload)}\n\n`);
    }

    // 8. End Stream
    res.write(`data: ${JSON.stringify({ status: 'complete' })}\n\n`);
    res.end();
  } catch (error) {
    console.error('GPU Inference Error:', error);
    res.write(`data: ${JSON.stringify({ error: 'Internal GPU Error' })}\n\n`);
    res.end();
  }
}
