/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

# deployment-image-processor.yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: image-processor
  labels:
    app: image-processor
spec:
  replicas: 1
  selector:
    matchLabels:
      app: image-processor
  template:
    metadata:
      labels:
        app: image-processor
    spec:
      # 4. Node Selection: Target nodes labeled with accelerator=nvidia
      nodeSelector:
        accelerator: nvidia
      
      containers:
      - name: tensorflow-container
        # Using nvidia/cuda base image for verification of GPU drivers
        image: nvidia/cuda:11.8.0-base-ubuntu22.04
        command: ["/bin/bash", "-c"]
        args:
          - |
            echo "Checking GPU availability..."
            # Check if nvidia-smi is present (verify drivers) and list devices
            if command -v nvidia-smi &> /dev/null; then
              echo "nvidia-smi found:"
              nvidia-smi --query-gpu=name,memory.total --format=csv
            else
              echo "nvidia-smi not found. Check container runtime."
            fi
            # Keep container running
            sleep infinity
        
        # 2. Resource Specification: Request exactly 1 NVIDIA GPU
        # Note: Kubernetes does not support fractional GPU requests.
        resources:
          requests:
            nvidia.com/gpu: 1
          limits:
            nvidia.com/gpu: 1
            # 3. CPU/Memory Limits
            cpu: "2"
            memory: "4Gi"
