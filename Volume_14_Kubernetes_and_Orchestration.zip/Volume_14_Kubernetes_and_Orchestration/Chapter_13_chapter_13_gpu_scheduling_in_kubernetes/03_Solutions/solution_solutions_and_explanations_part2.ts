/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

# Step 1: Taint the GPU Nodes (kubectl command)
# This command finds all nodes with the label accelerator=nvidia and applies the taint.
# Run this in your terminal:
# kubectl taint nodes -l accelerator=nvidia nvidia.com/gpu=present:NoSchedule

# Step 2: Deployment for AI Inference (ai-inference.yaml)
apiVersion: apps/v1
kind: Deployment
metadata:
  name: ai-inference
  labels:
    app: ai-inference
spec:
  replicas: 1
  selector:
    matchLabels:
      app: ai-inference
  template:
    metadata:
      labels:
        app: ai-inference
    spec:
      # 3. Toleration Configuration
      # Matches the taint applied to the GPU nodes to allow scheduling.
      tolerations:
      - key: "nvidia.com/gpu"
        operator: "Equal"
        value: "present"
        effect: "NoSchedule"
      
      # Still requesting the GPU resource
      containers:
      - name: inference-container
        image: nvidia/cuda:11.8.0-base-ubuntu22.04
        command: ["/bin/bash", "-c", "echo 'AI Inference Ready'; sleep infinity"]
        resources:
          requests:
            nvidia.com/gpu: 1
          limits:
            nvidia.com/gpu: 1

# Step 3: Verification Logic (Comment Block)
/*
To verify the isolation:
1. Apply the taint to Node A (GPU node) using the kubectl command above.
2. Deploy a standard NGINX pod (without the toleration defined above).
   - Result: The NGINX pod will remain in 'Pending' state.
   - Reason: The scheduler will reject it due to the taint on the GPU node, and if no other nodes exist, it cannot be placed.
3. Deploy the 'ai-inference' pod defined above.
   - Result: The pod will schedule successfully on the GPU node.
   - Reason: The toleration matches the taint, allowing the scheduler to bypass the NoSchedule restriction.
*/
