/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

# deployment-trainer-worker.yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: trainer-worker
  labels:
    app: trainer-worker
spec:
  replicas: 2
  selector:
    matchLabels:
      app: trainer-worker
  template:
    metadata:
      labels:
        app: trainer-worker
        # This label is used for topology spread if needed
        role: worker
    spec:
      containers:
      - name: worker-container
        image: python:3.9-slim
        command: ["python", "-c", "import torch; print('Torch loaded'); import time; time.sleep(3600)"]
        resources:
          requests:
            nvidia.com/gpu: 1
          limits:
            nvidia.com/gpu: 1

      # 3. Inter-Pod Affinity
      # Ensures this worker pod is scheduled on a node where a pod 
      # labeled 'app=trainer-coordinator' is already running.
      affinity:
        podAffinity:
          requiredDuringSchedulingIgnoredDuringExecution:
          - labelSelector:
              matchExpressions:
              - key: app
                operator: In
                values:
                - trainer-coordinator
            topologyKey: kubernetes.io/hostname

        # 4. Node Affinity Combination
        # Ensures the node has the specific topology label.
        nodeAffinity:
          requiredDuringSchedulingIgnoredDuringExecution:
            nodeSelectorTerms:
            - matchExpressions:
              - key: gpu-topology
                operator: In
                values:
                - high-speed

      # 5. Topology Spread Constraints (Optional)
      # Tries to spread workers across distinct nodes to minimize risk,
      # but respects the affinity rules (coordinator placement takes precedence).
      topologySpreadConstraints:
      - maxSkew: 1
        topologyKey: kubernetes.io/hostname
        whenUnsatisfiable: DoNotSchedule
        labelSelector:
          matchLabels:
            app: trainer-worker
