/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.tsx
// Description: Solutions and Explanations
// ==========================================

// GPUDashboard.tsx
import React, { useState, useEffect } from 'react';

// 3. Type Safety: Define the interface for the API response
interface NodeGPUStats {
  nodeName: string;
  totalGpus: number;
  allocatedGpus: number;
}

const GPUDashboard: React.FC = () => {
  const [nodes, setNodes] = useState<NodeGPUStats[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const [filterAvailable, setFilterAvailable] = useState<boolean>(false);

  // 2. Data Fetching: useEffect to fetch data on mount
  useEffect(() => {
    const fetchGpuMetrics = async () => {
      try {
        setLoading(true);
        // Simulating the API call
        const response = await fetch('/api/gpu-metrics');
        if (!response.ok) {
          throw new Error('Failed to fetch metrics');
        }
        const data: NodeGPUStats[] = await response.json();
        setNodes(data);
        setError(null);
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Unknown error');
      } finally {
        setLoading(false);
      }
    };

    fetchGpuMetrics();

    // Optional: Refresh every 30 seconds
    const interval = setInterval(fetchGpuMetrics, 30000);
    return () => clearInterval(interval);
  }, []);

  // 5. Interactivity: Filter logic
  const displayedNodes = filterAvailable
    ? nodes.filter(node => node.allocatedGpus < node.totalGpus)
    : nodes;

  // 4. Visualization: Helper to render progress bar
  const renderProgressBar = (allocated: number, total: number) => {
    const percentage = (allocated / total) * 100;
    return (
      <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
        <progress value={allocated} max={total} style={{ width: '100px' }} />
        <span>{percentage.toFixed(0)}%</span>
      </div>
    );
  };

  if (loading) return <div>Loading GPU Metrics...</div>;
  if (error) return <div style={{ color: 'red' }}>Error: {error}</div>;

  return (
    <div style={{ padding: '20px', fontFamily: 'Arial, sans-serif' }}>
      <h2>Cluster GPU Dashboard</h2>
      
      {/* Interactivity: Toggle Button */}
      <button onClick={() => setFilterAvailable(!filterAvailable)}>
        {filterAvailable ? 'Show All Nodes' : 'Show Nodes with Available GPUs'}
      </button>
      <p>Displaying {displayedNodes.length} of {nodes.length} nodes.</p>

      {/* Visualization: Data Table */}
      <table border={1} cellPadding={10} style={{ width: '100%', borderCollapse: 'collapse', marginTop: '20px' }}>
        <thead>
          <tr style={{ backgroundColor: '#f2f2f2' }}>
            <th>Node Name</th>
            <th>Total GPUs</th>
            <th>Allocated GPUs</th>
            <th>Utilization</th>
            <th>Availability Status</th>
          </tr>
        </thead>
        <tbody>
          {displayedNodes.map((node) => (
            <tr key={node.nodeName}>
              <td>{node.nodeName}</td>
              <td>{node.totalGpus}</td>
              <td>{node.allocatedGpus}</td>
              <td>{renderProgressBar(node.allocatedGpus, node.totalGpus)}</td>
              <td>
                {node.allocatedGpus < node.totalGpus 
                  ? <span style={{ color: 'green', fontWeight: 'bold' }}>Available</span> 
                  : <span style={{ color: 'red' }}>Saturated</span>}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default GPUDashboard;
