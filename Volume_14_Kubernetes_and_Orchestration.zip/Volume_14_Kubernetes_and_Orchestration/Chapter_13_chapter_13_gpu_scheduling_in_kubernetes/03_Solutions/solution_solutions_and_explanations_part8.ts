/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part8.ts
// Description: Solutions and Explanations
// ==========================================

digraph SchedulingSimulator {
    rankdir=LR;
    node [shape=box, style=filled];

    subgraph cluster_nodes {
        label = "Cluster Nodes";
        style = dashed;

        NodeA [label="Node A\nLabels: accelerator=nvidia\nTaints: dedicated:NoSchedule\nResources: 1 GPU", fillcolor="lightblue"];
        NodeB [label="Node B\nLabels: accelerator=nvidia\nTaints: None\nResources: 1 GPU", fillcolor="lightgreen"];
        NodeC [label="Node C\nLabels: None\nTaints: None\nResources: 0 GPU", fillcolor="lightgrey"];
    }

    subgraph cluster_pods {
        label = "Pending Pods";
        style = dashed;

        Pod1 [label="Pod-1\nRequests: 1 GPU\nTolerations: None", fillcolor="orange"];
        Pod2 [label="Pod-2\nRequests: 1 GPU\nTolerations: dedicated", fillcolor="orange"];
        Pod3 [label="Pod-3\nRequests: 2 GPUs\nTolerations: dedicated", fillcolor="red"];
    }

    // Scheduling Logic Edges
    // Pod 1 can go to Node B (Green), but not Node A (Red) due to taint
    Pod1 -> NodeB [label="Allowed", color="green", fontcolor="green"];
    Pod1 -> NodeA [label="Blocked: No Toleration", color="red", fontcolor="red"];

    // Pod 2 can go to Node A or B
    Pod2 -> NodeA [label="Allowed", color="green", fontcolor="green"];
    Pod2 -> NodeB [label="Allowed", color="green", fontcolor="green"];

    // Pod 3 cannot go anywhere (Insufficient GPU)
    Pod3 -> NodeA [label="Blocked: Insufficient GPU (1 < 2)", color="red", fontcolor="red"];
    Pod3 -> NodeB [label="Blocked: Insufficient GPU (1 < 2)", color="red", fontcolor="red"];
}
