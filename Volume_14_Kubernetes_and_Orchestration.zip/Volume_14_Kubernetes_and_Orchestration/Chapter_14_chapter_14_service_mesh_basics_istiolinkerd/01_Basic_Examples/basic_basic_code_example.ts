/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

import { StateGraph, Annotation, START, END } from "@langchain/langgraph";
import { ChatOpenAI } from "@langchain/openai";

// 1. Define the State Annotation
// This represents the shared state passed between nodes in the graph.
const AgentState = Annotation.Root({
  // The user's query (e.g., "What is the status of user 123?")
  input: Annotation<string>,
  // The agent's internal reasoning steps (Thoughts)
  thoughts: Annotation<string[]>,
  // The tool to execute (Action)
  action: Annotation<string>,
  // The result returned from the tool (Observation)
  observation: Annotation<string>,
  // The final answer to the user
  finalAnswer: Annotation<string>,
});

// 2. Define the Tools (Mock Database)
// In a real app, this would be a call to a database or external API.
// We use JSDoc to describe the tool for the LLM.
/**
 * Tool: get_user_status
 * Description: Retrieves the current subscription status and usage metrics for a specific user ID.
 * @param userId - The unique identifier for the user.
 * @returns A string describing the user's status.
 */
async function getUserStatus(userId: string): Promise<string> {
  // Simulating a database lookup
  const mockDb = {
    "123": { status: "Active", plan: "Pro", usage: "High" },
    "456": { status: "Inactive", plan: "Free", usage: "Low" },
  };
  const user = mockDb[userId as keyof typeof mockDb];
  if (!user) return `Error: User ${userId} not found.`;
  return `User ${userId} is ${user.status} on the ${user.plan} plan with ${user.usage} usage.`;
}

// 3. Initialize the LLM
// We use a lightweight model for this example.
const llm = new ChatOpenAI({ model: "gpt-3.5-turbo", temperature: 0 });

// 4. Define Graph Nodes (Logic Steps)

/**
 * Node: Reasoner
 * Purpose: The LLM analyzes the state and decides the next step.
 * It determines if it needs to call a tool or if it has the final answer.
 */
async function reasonerNode(state: typeof AgentState.State) {
  const { input, thoughts, observation } = state;
  
  // Construct a prompt for the LLM
  const systemPrompt = `
    You are an AI assistant for a SaaS platform. 
    You have access to a tool: 'get_user_status'.
    Analyze the user's input. If you need specific user data, use the tool.
    If you have the observation, provide the final answer.
    
    User Input: "${input}"
    Previous Thoughts: ${thoughts.join(", ")}
    Last Observation: ${observation || "None"}
    
    Respond in JSON format: { "thought": "...", "action": "...", "answer": "..." }
    If you are done, set "action" to "FINISH" and put the final answer in "answer".
  `;

  const response = await llm.invoke(systemPrompt);
  
  // Parse the LLM response (Handling potential hallucinations)
  let parsed;
  try {
    // Clean up markdown code blocks if present
    const content = response.content.toString().replace(/