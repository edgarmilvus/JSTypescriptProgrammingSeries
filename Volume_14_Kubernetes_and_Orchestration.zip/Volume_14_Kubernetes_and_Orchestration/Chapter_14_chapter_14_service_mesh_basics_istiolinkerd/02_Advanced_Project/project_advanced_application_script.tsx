/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.tsx
// Description: Advanced Application Script
// ==========================================

/**
 * @fileoverview AI Orchestration Frontend & Backend
 * 
 * This script demonstrates a full-stack Next.js application integrating:
 * 1. Service Worker Caching: For local storage of heavy AI model weights.
 * 2. Server Actions: For secure, type-safe backend mutations.
 * 3. Service Mesh Resilience: Simulating Istio/Linkerd traffic policies 
 *    (timeout/retry) via code logic and structured observability logs.
 * 
 * Target: SaaS AI Document Summarizer
 */

'use client'; // For the Client Component
'use server'; // For the Server Actions

import { useState, useEffect } from 'react';
import { z } from 'zod';

// -----------------------------------------------------------------------------
// 1. SERVICE WORKER REGISTRATION & CACHING STRATEGY
// -----------------------------------------------------------------------------
// Objective: Cache large ONNX model weights (e.g., 500MB+) locally to ensure
// instant loading on subsequent visits, reducing load on the AI Inference Cluster.
// -----------------------------------------------------------------------------

/**
 * Registers a Service Worker to handle caching of AI assets.
 * This mimics the "Data Plane" sidecar intercepting requests for static assets.
 */
async function registerServiceWorker() {
  if ('serviceWorker' in navigator) {
    try {
      const registration = await navigator.serviceWorker.register('/sw.js');
      console.log('Service Worker registered for AI asset caching.');
      
      // Trigger caching of critical model weights immediately
      if (registration.active) {
        registration.active.postMessage({ 
          type: 'CACHE_MODEL', 
          url: '/models/summarization-onnx-weights.bin' 
        });
      }
    } catch (error) {
      console.error('Service Worker registration failed:', error);
    }
  }
}

// -----------------------------------------------------------------------------
// 2. DATA VALIDATION & TYPES
// -----------------------------------------------------------------------------
// Objective: Ensure type safety across the client-server boundary.
// -----------------------------------------------------------------------------

const InputSchema = z.object({
  documentText: z.string().min(10, "Document must be at least 10 characters."),
  modelVersion: z.enum(["v1.0", "v2.0-beta"]).default("v1.0"),
});

type InputType = z.infer<typeof InputSchema>;
type SummaryResult = {
  summary: string;
  processingTimeMs: number;
  inferencePodId: string; // For observability
};

// -----------------------------------------------------------------------------
// 3. SERVER ACTIONS (THE CONTROL PLANE LOGIC)
// -----------------------------------------------------------------------------
// Objective: Execute secure logic on the server. Here we simulate interaction
// with a backend AI Inference Service (Kubernetes Cluster).
// -----------------------------------------------------------------------------

/**
 * Server Action: Handles the document summarization request.
 * 
 * ARCHITECTURAL NOTE:
 * In a real Service Mesh (Istio/Linkerd) environment:
 * 1. This action acts as the "Gateway" or Ingress.
 * 2. The fetch call to the AI Cluster is intercepted by a Sidecar Proxy.
 * 3. The Sidecar enforces policies: Retries, Timeouts, and mTLS.
 * 
 * We simulate these policies here to demonstrate resilience patterns.
 */
export async function summarizeDocument(input: InputType): Promise<SummaryResult> {
  // 1. Validate Input (Zod)
  const validated = InputSchema.parse(input);
  
  // 2. Simulate Service Mesh Observability (Structured Logging)
  // In a real mesh, this correlates with Trace IDs (Jaeger/Zipkin).
  const traceId = crypto.randomUUID();
  console.log(`[ServiceMesh-Observability] TraceID: ${traceId} | Request received | Target: AI-Cluster`);
  
  // 3. Simulate Service Mesh Traffic Policy: Timeout & Retry
  // Istio/Linkerd handle this at the network level. We handle it at the 
  // application level if the mesh is not fully configured, or to fail fast.
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), 5000); // 5s Timeout (Istio default)

  try {
    // 4. Call Downstream AI Inference Service
    // In a K8s cluster, this URL would be: http://ai-inference-service.ai-namespace.svc.cluster.local
    const response = await fetch('https://api.mock-ai-cluster/v1/inference', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model: validated.modelVersion,
        prompt: `Summarize the following: ${validated.documentText}`,
        stream: false,
      }),
      signal: controller.signal,
    });

    clearTimeout(timeoutId);

    if (!response.ok) {
      // Simulate Circuit Breaker logic: If downstream is failing, we fail gracefully.
      throw new Error(`AI Cluster responded with ${response.status}`);
    }

    const data = await response.json();
    
    // 5. Log Success for Observability
    console.log(`[ServiceMesh-Observability] TraceID: ${traceId} | Success | Latency: ${data.processingTimeMs}ms`);

    return {
      summary: data.summary || "Generated summary based on weights.",
      processingTimeMs: data.processingTimeMs || 1200,
      inferencePodId: data.podId || "pod-xyz-123",
    };

  } catch (error) {
    if (error.name === 'AbortError') {
      console.error(`[ServiceMesh-Observability] TraceID: ${traceId} | Timeout - Upstream Service Unavailable`);
      throw new Error("Request timed out. The AI inference cluster is currently overloaded.");
    }
    console.error(`[ServiceMesh-Observability] TraceID: ${traceId} | Error: ${error.message}`);
    throw new Error("Failed to generate summary. Please try again.");
  }
}

// -----------------------------------------------------------------------------
// 4. REACT COMPONENT (FRONTEND)
// -----------------------------------------------------------------------------

export default function AISummarizerApp() {
  const [result, setResult] = useState<SummaryResult | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    // Initialize Service Worker on mount
    registerServiceWorker();
  }, []);

  const handleSubmit = async (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setLoading(true);
    setError(null);
    setResult(null);

    const formData = new FormData(event.currentTarget);
    const text = formData.get('document') as string;

    try {
      // Call the Server Action
      const summary = await summarizeDocument({ 
        documentText: text, 
        modelVersion: "v1.0" 
      });
      setResult(summary);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Unknown error");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-2xl mx-auto p-6 bg-white shadow-lg rounded-lg">
      <h1 className="text-2xl font-bold mb-4 text-gray-800">
        AI Document Summarizer (Service Mesh Enabled)
      </h1>
      
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label htmlFor="document" className="block text-sm font-medium text-gray-700">
            Document Text
          </label>
          <textarea
            id="document"
            name="document"
            rows={5}
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 border p-2"
            placeholder="Paste a long document here..."
            required
          />
        </div>
        
        <button
          type="submit"
          disabled={loading}
          className={`w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white ${
            loading ? 'bg-gray-400' : 'bg-blue-600 hover:bg-blue-700'
          } focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500`}
        >
          {loading ? 'Processing via AI Cluster...' : 'Generate Summary'}
        </button>
      </form>

      {error && (
        <div className="mt-4 p-3 bg-red-50 border border-red-200 text-red-700 rounded">
          <strong>Error:</strong> {error}
        </div>
      )}

      {result && (
        <div className="mt-6 p-4 bg-green-50 border border-green-200 rounded-lg">
          <h2 className="text-lg font-semibold text-green-800">Summary</h2>
          <p className="mt-2 text-gray-700">{result.summary}</p>
          <div className="mt-3 text-xs text-gray-500">
            <span>Processed by Pod: {result.inferencePodId}</span> |{' '}
            <span>Latency: {result.processingTimeMs}ms</span>
          </div>
        </div>
      )}
    </div>
  );
}
