/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

import http, { IncomingMessage, ServerResponse } from 'http';

// Configuration
const BACKEND_PORT = 3002;
const SIDECAR_PORT = 3001;

// 1. Simulate the Backend Service
const backendServer = http.createServer((req: IncomingMessage, res: ServerResponse) => {
    console.log(`[Backend Service] Received ${req.method} request on ${req.url}`);
    
    // Simulate processing time
    setTimeout(() => {
        // Simulate occasional failure for demonstration
        if (Math.random() > 0.8) {
            res.writeHead(500, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify({ error: 'Internal Server Error' }));
        } else {
            res.writeHead(200, { 'Content-Type': 'application/json', 'X-Backend-Id': 'service-v1' });
            res.end(JSON.stringify({ message: 'Data processed successfully', timestamp: Date.now() }));
        }
    }, 100);
});

// 2. Simulate the Sidecar Proxy
const sidecarServer = http.createServer((req: IncomingMessage, clientRes: ServerResponse) => {
    const timestamp = new Date().toISOString();
    
    // --- LOGGING (Data Plane Visibility) ---
    console.log(`[Sidecar] ${timestamp} - Intercepted Request`);
    console.log(`[Sidecar] Method: ${req.method}, URL: ${req.url}`);
    console.log(`[Sidecar] Headers: ${JSON.stringify(req.headers)}`);

    // Prepare options to forward to backend
    const options = {
        hostname: 'localhost',
        port: BACKEND_PORT,
        path: req.url,
        method: req.method,
        headers: req.headers
    };

    // Create a request object to forward to the backend
    const backendReq = http.request(options, (backendRes: IncomingMessage) => {
        // --- LOGGING RESPONSE ---
        console.log(`[Sidecar] Received Backend Response: Status ${backendRes.statusCode}`);
        console.log(`[Sidecar] Response Headers: ${JSON.stringify(backendRes.headers)}`);

        // Forward response headers to client
        clientRes.writeHead(backendRes.statusCode!, backendRes.headers);

        // Pipe the backend response directly to the client
        backendRes.pipe(clientRes);
    });

    // Handle Backend Unavailability (Graceful Failure)
    backendReq.on('error', (err) => {
        console.error(`[Sidecar] Error connecting to backend: ${err.message}`);
        clientRes.writeHead(503, { 'Content-Type': 'application/json' });
        clientRes.end(JSON.stringify({ 
            error: 'Service Unavailable', 
            message: 'The sidecar could not reach the backend service.' 
        }));
    });

    // If the client sends a body, pipe it to the backend request
    req.pipe(backendReq);
});

// 3. Start Servers
backendServer.listen(BACKEND_PORT, () => {
    console.log(`[System] Backend Service listening on port ${BACKEND_PORT}`);
});

sidecarServer.listen(SIDECAR_PORT, () => {
    console.log(`[System] Sidecar Proxy listening on port ${SIDECAR_PORT}`);
    console.log(`[System] Send requests to http://localhost:${SIDECAR_PORT}`);
});
