/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

import crypto from 'crypto';
import { X509Certificate } from 'crypto';

// Helper to generate a self-signed certificate and key pair
function generateCertificate(commonName: string) {
    const { privateKey, publicKey } = crypto.generateKeyPairSync('rsa', {
        modulusLength: 2048,
    });

    const cert = crypto.createCertificate({
        subject: { CN: commonName },
        issuer: { CN: commonName }, // Self-signed
        publicKey: publicKey,
        serialNumber: crypto.randomBytes(16).toString('hex'),
        notBefore: new Date(),
        notAfter: new Date(new Date().setFullYear(new Date().getFullYear() + 1)),
        signingAlgorithm: 'sha256WithRSAEncryption',
    });

    cert.sign(privateKey, 'sha256WithRSAEncryption');

    return {
        key: privateKey.export({ type: 'pkcs8', format: 'pem' }) as string,
        cert: cert.export({ type: 'pem', format: 'pem' }) as string,
    };
}

// Simulate the mTLS Handshake / Verification
function establishSecureChannel(
    serviceACert: string, 
    serviceAKey: string, 
    serviceBCert: string, 
    serviceBKey: string
): void {
    console.log("\n[Control Plane] Initiating mTLS Handshake Simulation...");

    try {
        // 1. Service A presents its certificate to Service B
        const certA = new X509Certificate(serviceACert);
        
        // 2. Service B verifies Service A's certificate
        // In a real scenario, B checks if A's cert is signed by a trusted CA.
        // Here, we simulate verification by checking validity dates and signature.
        const isVerifiedA = certA.checkPrivateKey(serviceAKey); // Simulates ownership check
        
        // 3. Service B presents its certificate to Service A
        const certB = new X509Certificate(serviceBCert);

        // 4. Service A verifies Service B's certificate
        const isVerifiedB = certB.checkPrivateKey(serviceBKey);

        if (isVerifiedA && isVerifiedB) {
            console.log("[Data Plane] Service A verified Service B's identity.");
            console.log("[Data Plane] Service B verified Service A's identity.");

            // 5. Derive Session Key (Simulation)
            const sharedSecret = crypto.randomBytes(32).toString('hex');
            console.log(`[Data Plane] Handshake Complete. Derived Session Key: ${sharedSecret.substring(0, 10)}...`);
            console.log("[Result] Secure Channel Established Successfully.");
        } else {
            throw new Error("Certificate verification failed.");
        }
    } catch (error) {
        console.error("[Result] Secure Channel Failed:", (error as Error).message);
    }
}

// --- Execution ---

// Generate certificates for Service A and Service B
const serviceA = generateCertificate("service-a.namespace.svc.cluster.local");
const serviceB = generateCertificate("service-b.namespace.svc.cluster.local");

// Generate a malicious certificate to test failure
const maliciousService = generateCertificate("evil-service.namespace.svc.cluster.local");

// Run successful handshake
establishSecureChannel(serviceA.cert, serviceA.key, serviceB.cert, serviceB.key);

// Run failed handshake (Service A trying to verify malicious Service B)
// Note: We use the malicious key which won't match the expected verification logic
// or simply simulate a mismatch by swapping keys incorrectly.
establishSecureChannel(serviceA.cert, serviceA.key, maliciousService.cert, serviceA.key); 
