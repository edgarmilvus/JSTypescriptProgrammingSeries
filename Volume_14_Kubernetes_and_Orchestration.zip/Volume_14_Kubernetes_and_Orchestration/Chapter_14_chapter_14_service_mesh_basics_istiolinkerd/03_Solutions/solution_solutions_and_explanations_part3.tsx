/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState } from 'react';

// 1. Define Types
interface Service {
    name: string;
    status: 'healthy' | 'unhealthy';
    trafficRate: number; // Requests per second
}

interface DashboardProps {
    initialServices: Service[];
}

// 2. Styles (Inline for simplicity)
const styles = {
    container: { fontFamily: 'sans-serif', padding: '20px', border: '1px solid #ddd', borderRadius: '8px', maxWidth: '600px' },
    header: { display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '20px' },
    list: { listStyle: 'none', padding: 0 },
    item: { 
        display: 'flex', 
        alignItems: 'center', 
        padding: '10px', 
        borderBottom: '1px solid #eee',
        justifyContent: 'space-between'
    },
    statusDot: (status: string) => ({
        width: '12px',
        height: '12px',
        borderRadius: '50%',
        backgroundColor: status === 'healthy' ? '#28a745' : '#dc3545',
        marginRight: '10px',
        display: 'inline-block'
    }),
    trafficBar: (rate: number) => ({
        height: '8px',
        width: `${Math.min(rate, 100)}%`, // Cap at 100% for visual
        backgroundColor: '#007bff',
        borderRadius: '4px',
        marginTop: '4px'
    }),
    button: {
        padding: '8px 12px',
        cursor: 'pointer',
        backgroundColor: '#007bff',
        color: 'white',
        border: 'none',
        borderRadius: '4px',
        marginRight: '5px'
    }
};

const ServiceMeshDashboard: React.FC<DashboardProps> = ({ initialServices }) => {
    const [services, setServices] = useState<Service[]>(initialServices);
    const [filter, setFilter] = useState<'all' | 'healthy' | 'unhealthy'>('all');

    // --- Interactive Challenge: Simulate Traffic ---
    const simulateTraffic = () => {
        setServices(prevServices => {
            return prevServices.map(service => {
                // Randomly update traffic rate
                const newRate = Math.floor(Math.random() * 100);
                
                // 10% chance to flip health status
                const shouldFlip = Math.random() < 0.1;
                const newStatus = shouldFlip 
                    ? (service.status === 'healthy' ? 'unhealthy' : 'healthy')
                    : service.status;

                return {
                    ...service,
                    trafficRate: newRate,
                    status: newStatus
                };
            });
        });
    };

    // --- Filtering Logic ---
    const filteredServices = services.filter(s => 
        filter === 'all' ? true : s.status === filter
    );

    return (
        <div style={styles.container}>
            <div style={styles.header}>
                <h2>Service Mesh Dashboard</h2>
                <button onClick={simulateTraffic} style={styles.button}>
                    Simulate Traffic
                </button>
            </div>

            {/* Filter Controls */}
            <div style={{ marginBottom: '15px' }}>
                <span style={{ marginRight: '10px', fontWeight: 'bold' }}>Filter:</span>
                {(['all', 'healthy', 'unhealthy'] as const).map(status => (
                    <button 
                        key={status}
                        onClick={() => setFilter(status)}
                        style={{
                            ...styles.button,
                            backgroundColor: filter === status ? '#0056b3' : '#007bff',
                            opacity: filter === status ? 1 : 0.7
                        }}
                    >
                        {status.charAt(0).toUpperCase() + status.slice(1)}
                    </button>
                ))}
            </div>

            {/* Service List */}
            <ul style={styles.list}>
                {filteredServices.map((service, index) => (
                    <li key={index} style={styles.item}>
                        <div style={{ display: 'flex', flexDirection: 'column', flex: 1 }}>
                            <div style={{ display: 'flex', alignItems: 'center' }}>
                                <span style={styles.statusDot(service.status)}></span>
                                <strong>{service.name}</strong>
                            </div>
                            <div style={{ fontSize: '0.85em', color: '#666', marginTop: '2px' }}>
                                Traffic: {service.trafficRate} req/s
                            </div>
                            {/* Visual Bar Chart */}
                            <div style={styles.trafficBar(service.trafficRate)}></div>
                        </div>
                        <div style={{ fontWeight: 'bold', color: service.status === 'healthy' ? '#28a745' : '#dc3545' }}>
                            {service.status.toUpperCase()}
                        </div>
                    </li>
                ))}
            </ul>
        </div>
    );
};

export default ServiceMeshDashboard;

// --- Usage Example (Mock Data) ---
/*
const mockServices: Service[] = [
    { name: 'reviews-v1', status: 'healthy', trafficRate: 45 },
    { name: 'ratings-v1', status: 'healthy', trafficRate: 30 },
    { name: 'payment-v2', status: 'unhealthy', trafficRate: 0 },
];

render(<ServiceMeshDashboard initialServices={mockServices} />, document.getElementById('root'));
*/
