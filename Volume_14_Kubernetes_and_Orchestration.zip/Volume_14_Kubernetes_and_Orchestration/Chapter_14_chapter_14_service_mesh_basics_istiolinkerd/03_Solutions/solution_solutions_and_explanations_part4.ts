/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

// The output of this function is a string in Graphviz DOT format.
// You can copy and paste this string into a tool like https://dreampuf.github.io/GraphvizOnline/
// or a VS Code extension like "Graphviz (dot) language support".

function generateMeshDiagram(): string {
    return `
digraph ServiceMeshArchitecture {
    rankdir=LR;
    node [shape=box, style="rounded", fontname="Helvetica"];
    
    subgraph cluster_0 {
        label = "Kubernetes Cluster / Network";
        style = dashed;
        color = grey;

        // Control Plane Node
        node [fillcolor="#e3f2fd", shape=component];
        ControlPlane [label="Control Plane\\n(istiod)\\nConfig & Discovery"];

        // Data Plane Subgraph
        subgraph cluster_1 {
            label = "Data Plane";
            style = solid;
            color = black;
            node [fillcolor="#fff3e0", shape=component];

            // Service A (App + Sidecar)
            subgraph cluster_a {
                label = "Pod A";
                style = dotted;
                node [width=1.5];
                AppA [label="Application\\n(Service A)"];
                SidecarA [label="Envoy Sidecar"];
            }

            // Service B (App + Sidecar)
            subgraph cluster_b {
                label = "Pod B";
                style = dotted;
                node [width=1.5];
                AppB [label="Application\\n(Service B)"];
                SidecarB [label="Envoy Sidecar"];
            }
        }
    }

    // External Client
    Client [label="External Client", shape=ellipse, fillcolor="#f3e5f5"];

    // --- Connections ---

    // 1. Control Plane to Sidecars (Configuration Push)
    // Dashed line indicates configuration/mgmt traffic
    ControlPlane -> SidecarA [label="Config\\n(Envoy Filters)", style=dashed, color=blue];
    ControlPlane -> SidecarB [label="Config", style=dashed, color=blue];

    // 2. Client to Service A (Ingress)
    Client -> SidecarA [label="HTTP Request", color=black, penwidth=2.0];

    // 3. Service A to Service B (East-West Traffic)
    // The App talks to the Sidecar, and the Sidecar talks to the other Sidecar
    AppA -> SidecarA [label="Localhost", style=dotted, constraint=false];
    SidecarA -> SidecarB [label="mTLS Encrypted\\nTraffic", color=red, penwidth=2.0];
    SidecarB -> AppB [label="Localhost", style=dotted, constraint=false];

    // 4. Telemetry back to Control Plane (Dashed)
    SidecarA -> ControlPlane [label="Telemetry\\n(Metrics/Logs)", style=dashed, dir=both, color=green];
    SidecarB -> ControlPlane [label="Telemetry", style=dashed, dir=both, color=green];
}
`;
}

// Output the diagram code
console.log(generateMeshDiagram());
