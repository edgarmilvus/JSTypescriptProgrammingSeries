/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

/**
 * Simulates a supervisor agent aggregating responses from worker agents.
 * Uses a voting mechanism to determine consensus.
 * 
 * @param workerResponses - An array of Promises resolving to string responses.
 * @returns A Promise resolving to the consensus string.
 */
async function resolveConsensus(workerResponses: Promise<string>[]): Promise<string> {
    // 1. Wait for all promises to settle (either resolve or reject)
    // Promise.allSettled is crucial here to handle failures without crashing the whole process.
    const results = await Promise.allSettled(workerResponses);

    // 2. Filter out rejections and extract values from successful promises
    const successfulResponses = results
        .filter((result): result is PromiseFulfilledResult<string> => result.status === 'fulfilled')
        .map(result => result.value);

    // Edge case: No valid responses
    if (successfulResponses.length === 0) {
        return "No Consensus: All workers failed.";
    }

    // 3. Count frequencies using a Map
    const frequencyMap = new Map<string, number>();
    successfulResponses.forEach(response => {
        const count = frequencyMap.get(response) || 0;
        frequencyMap.set(response, count + 1);
    });

    // 4. Determine the winner (Highest frequency)
    let consensus = '';
    let maxCount = 0;

    for (const [response, count] of frequencyMap) {
        if (count > maxCount) {
            maxCount = count;
            consensus = response;
        }
        // In case of a tie, the requirement says "return the first one encountered".
        // Since we iterate the map, which preserves insertion order (roughly), 
        // the first one with the highest count wins.
    }

    return consensus;
}

// --- Test Scenarios ---

async function runTests() {
    console.log("--- Test 1: Clear Majority ---");
    const workers1 = [
        Promise.resolve("Model A Output"),
        Promise.resolve("Model B Output"),
        Promise.resolve("Model A Output"), // Winner
        Promise.resolve("Model C Output"),
        Promise.reject("Model D Failed"),  // Ignored
    ];
    console.log("Result:", await resolveConsensus(workers1)); // Expected: "Model A Output"

    console.log("\n--- Test 2: All Failures ---");
    const workers2 = [
        Promise.reject("Worker 1 Error"),
        Promise.reject("Worker 2 Error"),
    ];
    console.log("Result:", await resolveConsensus(workers2)); // Expected: "No Consensus..."

    console.log("\n--- Test 3: Tie Breaker (First Encountered) ---");
    const workers3 = [
        Promise.resolve("Response X"),
        Promise.resolve("Response Y"),
        Promise.resolve("Response X"),
        Promise.resolve("Response Y"),
    ];
    // Depending on map iteration order, X or Y wins. 
    // If X is added first, X wins.
    console.log("Result:", await resolveConsensus(workers3)); 
}

runTests();
