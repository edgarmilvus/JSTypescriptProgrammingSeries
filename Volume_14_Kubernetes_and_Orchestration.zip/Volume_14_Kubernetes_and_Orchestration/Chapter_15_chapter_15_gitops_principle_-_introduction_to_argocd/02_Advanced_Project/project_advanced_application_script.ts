/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// pages/api/deployments/update.ts (or app/api/deployments/update/route.ts)

import { NextApiRequest, NextApiResponse } from 'next';
import { Octokit } from '@octokit/rest';
import yaml from 'js-yaml';

// =============================================================================
// 1. TYPES & INTERFACES (SRP: Data Contract Definition)
// =============================================================================

/**
 * Interface defining the shape of the deployment configuration received
 * from the client-side form. This enforces strict typing for the user intent.
 */
interface DeploymentConfig {
  serviceName: string;
  modelVersion: string;
  replicas: number;
  resourceLimit: {
    cpu: string;
    memory: string;
  };
}

/**
 * Interface for the Git commit payload.
 */
interface GitCommitPayload {
  path: string;
  message: string;
  content: string; // Base64 encoded
  sha?: string;    // Required for updates (overwrites)
}

// =============================================================================
// 2. KUBERNETES MANIFEST GENERATOR (SRP: Pure Logic)
// =============================================================================

/**
 * Generates a Kubernetes Deployment manifest as a YAML string.
 * 
 * Why Immutable? This function takes a configuration object and returns a 
 * completely new string. It does not modify any global state or existing 
 * files. It represents the desired state based on current inputs.
 * 
 * @param config - The deployment configuration
 * @returns YAML string representing the K8s Deployment
 */
const generateK8sManifest = (config: DeploymentConfig): string => {
  const manifest = {
    apiVersion: 'apps/v1',
    kind: 'Deployment',
    metadata: {
      name: `ai-inference-${config.serviceName}`,
      labels: {
        app: config.serviceName,
        version: config.modelVersion.replace(/\./g, '-'), // Sanitize labels
      },
    },
    spec: {
      replicas: config.replicas,
      selector: {
        matchLabels: {
          app: config.serviceName,
        },
      },
      template: {
        metadata: {
          labels: {
            app: config.serviceName,
          },
        },
        spec: {
          containers: [
            {
              name: 'inference-service',
              image: `my-registry/ai-model:${config.modelVersion}`,
              ports: [
                {
                  containerPort: 8080,
                },
              ],
              resources: {
                limits: {
                  cpu: config.resourceLimit.cpu,
                  memory: config.resourceLimit.memory,
                },
                requests: {
                  cpu: '100m',
                  memory: '128Mi',
                },
              },
            },
          ],
        },
      },
    },
  };

  // Convert JS object to YAML string
  return yaml.dump(manifest);
};

// =============================================================================
// 3. GITOPS SERVICE (SRP: External Interaction)
// =============================================================================

/**
 * Service class encapsulating all Git interactions.
 * This adheres to SRP by isolating I/O operations (GitHub API) from 
 * business logic (manifest generation).
 */
class GitOpsService {
  private octokit: Octokit;
  private owner: string;
  private repo: string;

  constructor() {
    if (!process.env.GITHUB_TOKEN) {
      throw new Error('GITHUB_TOKEN is not defined in environment variables.');
    }
    
    this.octokit = new Octokit({ auth: process.env.GITHUB_TOKEN });
    this.owner = process.env.GITHUB_OWNER || 'default-owner';
    this.repo = process.env.GITHUB_REPO || 'ai-cluster-configs';
  }

  /**
   * Fetches the current file SHA from GitHub.
   * Required for updating an existing file via the GitHub API.
   * 
   * @param path - The path to the file in the repo
   * @returns The SHA string if the file exists, otherwise null.
   */
  private async getFileSha(path: string): Promise<string | null> {
    try {
      const { data } = await this.octokit.repos.getContent({
        owner: this.owner,
        repo: this.repo,
        path,
      });

      if (Array.isArray(data)) return null; // It's a directory, not a file
      return data.sha;
    } catch (error: any) {
      // 404 means file doesn't exist yet (first commit)
      if (error.status === 404) return null;
      throw error;
    }
  }

  /**
   * Commits a new or updated manifest to the GitOps repository.
   * 
   * @param config - The deployment configuration
   * @param filePath - Path in Git repo (e.g., 'prod/inference/deployment.yaml')
   * @param commitMessage - Descriptive message for the Git log
   */
  async commitManifest(
    config: DeploymentConfig, 
    filePath: string, 
    commitMessage: string
  ): Promise<void> {
    // 1. Generate the immutable manifest content
    const manifestContent = generateK8sManifest(config);
    
    // 2. Encode content to Base64 (GitHub API requirement)
    const content = Buffer.from(manifestContent).toString('base64');

    // 3. Check for existing file to get SHA (for update vs create)
    const sha = await this.getFileSha(filePath);

    // 4. Prepare the commit payload
    const payload: GitCommitPayload = {
      path: filePath,
      message: commitMessage,
      content,
    };

    if (sha) {
      payload.sha = sha; // Update existing file
    }

    // 5. Push to GitHub
    await this.octokit.repos.createOrUpdateFileContents({
      owner: this.owner,
      repo: this.repo,
      ...payload,
    });
  }
}

// =============================================================================
// 4. NEXT.JS API ROUTE HANDLER
// =============================================================================

/**
 * API Route: POST /api/deployments/update
 * 
 * Handles the form submission from the SaaS UI. It validates input,
 * constructs the GitOps payload, and executes the Git commit.
 * 
 * @param req - NextApiRequest
 * @param res - NextApiResponse
 */
export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method Not Allowed' });
  }

  try {
    // 1. Parse and Validate Input
    // In a real app, use a validator like Zod here.
    const config: DeploymentConfig = req.body;

    if (!config.serviceName || !config.modelVersion) {
      return res.status(400).json({ error: 'Missing required fields: serviceName, modelVersion' });
    }

    // 2. Define the target path in Git
    // Structure: environments/{env}/{service}/deployment.yaml
    const gitFilePath = `environments/prod/${config.serviceName}/deployment.yaml`;
    
    // 3. Initialize GitOps Service
    const gitOps = new GitOpsService();

    // 4. Execute GitOps Action
    // This triggers the "Git Push" phase of the GitOps cycle.
    await gitOps.commitManifest(
      config, 
      gitFilePath, 
      `chore: Update ${config.serviceName} to v${config.modelVersion} [skip ci]`
    );

    // 5. Return Success
    // ArgoCD will now detect the change and reconcile the cluster state.
    res.status(200).json({ 
      message: 'Configuration committed to Git. ArgoCD synchronization initiated.',
      path: gitFilePath 
    });

  } catch (error: any) {
    console.error('GitOps Deployment Error:', error);
    res.status(500).json({ 
      error: 'Failed to commit configuration', 
      details: error.message 
    });
  }
}
