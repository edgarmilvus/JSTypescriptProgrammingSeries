/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// Note: This solution provides the YAML manifests and Dockerfile content requested.
// Since TypeScript is not used for infrastructure definition in this context,
// the "code" block contains the declarative configuration files.

// 1. server.js (Node.js Application)
const http = require('http');

const server = http.createServer((req, res) => {
  if (req.url === '/') {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ status: "ok", message: "Hello from GitOps!" }));
  } else {
    res.writeHead(404);
    res.end();
  }
});

const PORT = 3000;
server.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});

// 2. Dockerfile (Multi-stage, Non-root)
# Stage 1: Build
FROM node:18-alpine AS builder
WORKDIR /app
COPY package*.json ./
RUN npm ci --only=production

# Stage 2: Runtime
FROM node:18-alpine
WORKDIR /app

# Create a non-root user
RUN addgroup -g 1001 -S nodejs
RUN adduser -S nextjs -u 1001

# Copy built artifacts from builder
COPY --from=builder --chown=nextjs:nodejs /app/node_modules ./node_modules
COPY --from=builder --chown=nextjs:nodejs /app/package.json ./
COPY --from=builder --chown=nextjs:nodejs /app/server.js ./

USER nextjs

EXPOSE 3000
CMD ["node", "server.js"]

// 3. namespace.yaml
apiVersion: v1
kind: Namespace
metadata:
  name: gitops-demo

// 4. deployment.yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: nodejs-app
  namespace: gitops-demo
spec:
  replicas: 1
  selector:
    matchLabels:
      app: nodejs-app
  template:
    metadata:
      labels:
        app: nodejs-app
    spec:
      containers:
      - name: nodejs-app
        image: your-dockerhub-username/nodejs-app:1.0.0 # Replace with actual image
        ports:
        - containerPort: 3000
        resources:
          requests:
            memory: "64Mi"
            cpu: "250m"
          limits:
            memory: "128Mi"
            cpu: "500m"
        readinessProbe:
          httpGet:
            path: /
            port: 3000
          initialDelaySeconds: 5
          periodSeconds: 10
        livenessProbe:
          httpGet:
            path: /
            port: 3000
          initialDelaySeconds: 15
          periodSeconds: 20

// 5. service.yaml
apiVersion: v1
kind: Service
metadata:
  name: nodejs-app
  namespace: gitops-demo
spec:
  selector:
    app: nodejs-app
  ports:
    - protocol: TCP
      port: 80
      targetPort: 3000
  type: ClusterIP

// 6. app.yaml (ArgoCD Application CRD)
apiVersion: argoproj.io/v1alpha1
kind: Application
metadata:
  name: gitops-demo-app
  namespace: argocd # The namespace where ArgoCD is installed
spec:
  project: default
  source:
    repoURL: https://github.com/your-username/your-git-repo.git # Replace with actual Git URL
    targetRevision: HEAD
    path: manifests # Directory containing deployment.yaml, service.yaml, etc.
  destination:
    server: https://kubernetes.default.svc
    namespace: gitops-demo
  syncPolicy:
    automated:
      prune: true
      selfHeal: true
    syncOptions:
    - CreateNamespace=true

// 7. README.md (Documentation Steps)
/*
# GitOps Setup

## 1. Push to Remote Repository
git init
git add .
git commit -m "Initial GitOps setup"
git remote add origin https://github.com/your-username/your-git-repo.git
git push -u origin master

## 2. Apply to ArgoCD
Ensure ArgoCD is installed. Then apply the Application manifest:
kubectl apply -f app.yaml
*/

// 8. Interactive Challenge: Drift Simulation
/*
Command to simulate drift:
kubectl scale deployment nodejs-app --replicas=3 -n gitops-demo

Expected Behavior in ArgoCD:
1. ArgoCD detects the cluster state (3 replicas) differs from the Git state (1 replica).
2. The Application in the ArgoCD UI will turn "OutOfSync" (Yellow/Red indicator).
3. Because `selfHeal: true` is set in the syncPolicy, ArgoCD automatically triggers a sync operation.
4. ArgoCD applies the manifest from Git, scaling the deployment back down to 1 replica.
5. The Application status returns to "Synced".
*/
