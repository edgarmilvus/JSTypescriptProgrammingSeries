/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

// 1. server.js (Refactored for Environment Variables)
const http = require('http');

const APP_ENV = process.env.APP_ENV || 'development';
const LOG_LEVEL = process.env.LOG_LEVEL || 'info';
const API_KEY = process.env.API_KEY ? '***REDACTED***' : 'Missing';

const server = http.createServer((req, res) => {
  if (req.url === '/') {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ 
      env: APP_ENV, 
      logLevel: LOG_LEVEL, 
      apiKeyStatus: "Present" 
    }));
  } else {
    res.writeHead(404);
    res.end();
  }
});

console.log(`Starting App in ${APP_ENV} mode with ${LOG_LEVEL} logging.`);
server.listen(3000);

// 2. configmap.yaml
apiVersion: v1
kind: ConfigMap
metadata:
  name: nodejs-config
  namespace: gitops-demo
data:
  APP_ENV: "production"
  LOG_LEVEL: "info"

// 3. secret.yaml (Example - Base64 encoded values)
# To generate: echo -n "supersecretkey" | base64
apiVersion: v1
kind: Secret
metadata:
  name: nodejs-secret
  namespace: gitops-demo
type: Opaque
data:
  API_KEY: c3VwZXJzZWNyZXRrZXk= # "supersecretkey" in base64

// 4. deployment.yaml (Updated with Env Vars)
apiVersion: apps/v1
kind: Deployment
metadata:
  name: nodejs-app
  namespace: gitops-demo
spec:
  replicas: 1
  selector:
    matchLabels:
      app: nodejs-app
  template:
    metadata:
      labels:
        app: nodejs-app
    spec:
      containers:
      - name: nodejs-app
        image: your-dockerhub-username/nodejs-app:1.0.0
        ports:
        - containerPort: 3000
        env:
          - name: APP_ENV
            valueFrom:
              configMapKeyRef:
                name: nodejs-config
                key: APP_ENV
          - name: LOG_LEVEL
            valueFrom:
              configMapKeyRef:
                name: nodejs-config
                key: LOG_LEVEL
          - name: API_KEY
            valueFrom:
              secretKeyRef:
                name: nodejs-secret
                key: API_KEY
        # ... (resources and probes remain the same)

// 5. .gitignore
node_modules
secret.yaml

// 6. secret.example.yaml
# Copy this file to secret.yaml and replace the value with your actual base64 encoded key.
apiVersion: v1
kind: Secret
metadata:
  name: nodejs-secret
  namespace: gitops-demo
type: Opaque
data:
  API_KEY: <BASE64_ENCODED_VALUE_HERE>

// 7. Interactive Challenge: Updating LOG_LEVEL
/*
1. Edit configmap.yaml: Change `LOG_LEVEL: "info"` to `LOG_LEVEL: "debug"`.
2. Commit: `git add configmap.yaml && git commit -m "feat: increase log level to debug"`
3. Push: `git push origin master`
4. ArgoCD Behavior: 
   - ArgoCD detects the change in the Git repository.
   - It updates the ConfigMap resource in the cluster.
   - **Note:** Simply updating a ConfigMap does not automatically restart the Pod to apply the new env var.
   - To force a restart (and apply the new LOG_LEVEL), we typically use a checksum annotation in the Deployment spec (e.g., `checksum/config: {{ include (print $.Template.BasePath "/configmap.yaml") . | sha256sum }}` if using Helm).
   - Alternatively, ArgoCD can be configured to perform a `RollingUpdate` if the Deployment manifest is also touched, or we rely on the application to reload config (though Node.js typically reads env vars at startup).
   - ArgoCD applies the change without downtime by respecting the Deployment's update strategy (RollingUpdate by default).
*/
