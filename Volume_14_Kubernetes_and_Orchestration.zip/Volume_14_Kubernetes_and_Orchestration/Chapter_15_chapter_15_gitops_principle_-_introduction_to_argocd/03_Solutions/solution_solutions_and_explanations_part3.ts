/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

// 1. Installation Command
/*
kubectl create namespace argo-rollouts
kubectl apply -n argo-rollouts -f https://github.com/argoproj/argo-rollouts/releases/latest/download/install.yaml
*/

// 2. rollout.yaml (Canary Strategy)
apiVersion: argoproj.io/v1alpha1
kind: Rollout
metadata:
  name: nodejs-app
  namespace: gitops-demo
spec:
  replicas: 5
  selector:
    matchLabels:
      app: nodejs-app
  template:
    metadata:
      labels:
        app: nodejs-app
    spec:
      containers:
      - name: nodejs-app
        image: your-dockerhub-username/nodejs-app:1.0.0 # Update this to trigger rollout
        ports:
        - containerPort: 3000
        resources:
          requests:
            memory: "64Mi"
            cpu: "250m"
          limits:
            memory: "128Mi"
            cpu: "500m"
  strategy:
    canary:
      steps:
      - setWeight: 20
      - pause: { duration: 60s }
      - setWeight: 50
      - pause: { duration: 60s }
      - setWeight: 100
      analysis:
        templateName: success-rate
        startingStep: 1 # Start analysis after the first pause

// 3. service.yaml (Updated for Rollout)
# The service selector remains the same (app: nodejs-app).
# ArgoCD Rollouts dynamically manages the pods behind this selector.
apiVersion: v1
kind: Service
metadata:
  name: nodejs-app
  namespace: gitops-demo
spec:
  selector:
    app: nodejs-app
  ports:
    - protocol: TCP
      port: 80
      targetPort: 3000
  type: ClusterIP

// 4. analysis-template.yaml (Health Check)
apiVersion: argoproj.io/v1alpha1
kind: AnalysisTemplate
metadata:
  name: success-rate
  namespace: gitops-demo
spec:
  args:
  - name: service-name
    value: nodejs-app
  metrics:
  - name: check-health
    interval: 10s
    successCondition: result == true
    failureLimit: 2
    provider:
      prometheus:
        address: http://prometheus-server.monitoring.svc.cluster.local:80 # Example Prometheus address
        query: |
          sum(rate(http_requests_total{service="{{args.service-name}}",status=~"5.."}[5m])) / sum(rate(http_requests_total{service="{{args.service-name}}"}[5m]))
    # Note: For a simple curl check without Prometheus, we might use a Job provider, 
    # but Prometheus is standard for Argo Rollouts analysis.
    # Alternatively, a simple check using curl in a Job:
    # provider:
    #   job:
    #     spec:
    #       template:
    #         spec:
    #           containers:
    #           - name: check
    #             image: curlimages/curl
    #             command: ["curl", "-f", "http://nodejs-app.gitops-demo.svc.cluster.local/health"]
    #           restartPolicy: Never

// 5. Interactive Challenge: Rollback Scenario
/*
Scenario: Deploying v1.2 (buggy version) with high latency.

1. Canary Start: The Rollout creates a ReplicaSet for v1.2 with 20% weight (1 pod if replicas=5).
2. Analysis Trigger: The `AnalysisTemplate` starts checking the health endpoint every 10s.
3. Detection: The analysis queries (e.g., Prometheus) detect high 5xx error rates or latency exceeding the `successCondition`.
4. Failure State: The analysis metric fails the `successCondition`. The failure count increments.
5. Automatic Rollback: Once `failureLimit` is reached, ArgoCD Rollouts aborts the rollout.
6. Traffic Shift: It immediately sets the canary weight to 0% and shifts 100% traffic back to the stable version (v1.1).
7. Rollout State: The `Rollout` resource status updates to `Aborted`. The new pods are scaled down, and the system remains on the previous stable version without manual intervention.
*/
