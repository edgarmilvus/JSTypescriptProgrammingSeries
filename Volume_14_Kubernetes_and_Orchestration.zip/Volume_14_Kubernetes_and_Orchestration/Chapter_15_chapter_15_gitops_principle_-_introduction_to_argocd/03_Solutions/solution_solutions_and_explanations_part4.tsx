/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.tsx
// Description: Solutions and Explanations
// ==========================================

// 1. types.ts (Data Structure)
export interface ArgoApp {
  metadata: { name: string; namespace: string; };
  status: {
    sync: { status: 'Synced' | 'OutOfSync' | 'Unknown'; };
    health: { status: 'Healthy' | 'Degraded' | 'Unknown'; };
  };
}

// 2. useArgoApps.ts (Custom Hook - SRP: Data Fetching)
import { useState, useEffect, useCallback } from 'react';
import { ArgoApp } from './types';

interface UseArgoAppsReturn {
  apps: ArgoApp[];
  loading: boolean;
  error: string | null;
  refresh: () => void;
}

export const useArgoApps = (): UseArgoAppsReturn => {
  const [apps, setApps] = useState<ArgoApp[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  // Trigger state for manual refresh
  const [refreshToken, setRefreshToken] = useState(0);

  const fetchData = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      // Simulating API call. In real app: fetch('/api/argo/applications')
      const response = await fetch(`https://jsonplaceholder.typicode.com/posts?_limit=5`); 
      // Mapping dummy data to ArgoApp structure for demonstration
      const data = await response.json();
      const mappedData: ArgoApp[] = data.map((item: any) => ({
        metadata: { name: `app-${item.id}`, namespace: 'gitops-demo' },
        status: {
          sync: { status: item.id % 2 === 0 ? 'Synced' : 'OutOfSync' },
          health: { status: item.id % 3 === 0 ? 'Degraded' : 'Healthy' },
        },
      }));
      setApps(mappedData);
    } catch (err) {
      setError('Failed to fetch ArgoCD data');
    } finally {
      setLoading(false);
    }
  }, [refreshToken]);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  const refresh = useCallback(() => {
    setRefreshToken(prev => prev + 1);
  }, []);

  return { apps, loading, error, refresh };
};

// 3. ArgoAppStatusList.tsx (UI Component)
import React from 'react';
import { useArgoApps } from './useArgoApps';
import styles from './ArgoAppStatusList.module.css'; // Assuming CSS Modules

const ArgoAppStatusList: React.FC = () => {
  const { apps, loading, error, refresh } = useArgoApps();

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Synced':
      case 'Healthy':
        return 'green';
      case 'OutOfSync':
      case 'Degraded':
        return 'red';
      default:
        return 'gray';
    }
  };

  if (loading) return <div className={styles.spinner}>Loading...</div>;
  if (error) return <div className={styles.error}>{error}</div>;

  return (
    <div className={styles.container}>
      <div className={styles.header}>
        <h2>ArgoCD Applications</h2>
        <button onClick={refresh} className={styles.refreshBtn}>Refresh</button>
      </div>
      <div className={styles.list}>
        {apps.map((app) => (
          <div key={app.metadata.name} className={styles.card}>
            <h3>{app.metadata.name}</h3>
            <p>Namespace: {app.metadata.namespace}</p>
            <div className={styles.badges}>
              <span 
                className={styles.badge} 
                style={{ backgroundColor: getStatusColor(app.status.sync.status) }}
              >
                Sync: {app.status.sync.status}
              </span>
              <span 
                className={styles.badge} 
                style={{ backgroundColor: getStatusColor(app.status.health.status) }}
              >
                Health: {app.status.health.status}
              </span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default ArgoAppStatusList;

// 4. ArgoAppStatusList.module.css (Basic Styling)
/*
.container { padding: 20px; font-family: sans-serif; }
.header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; }
.refreshBtn { padding: 8px 16px; cursor: pointer; background-color: #007bff; color: white; border: none; border-radius: 4px; }
.list { display: grid; grid-template-columns: repeat(auto-fill, minmax(250px, 1fr)); gap: 15px; }
.card { border: 1px solid #ddd; padding: 15px; border-radius: 8px; background: #fff; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
.badges { display: flex; gap: 10px; margin-top: 10px; }
.badge { padding: 4px 8px; border-radius: 4px; color: white; font-size: 0.85rem; }
.spinner, .error { text-align: center; padding: 20px; }
*/

// 5. Interactive Challenge: SRP and Complexity
/*
How does the design adhere to SRP?
- The `ArgoAppStatusList` component is solely responsible for presentation (rendering UI based on props/state).
- The `useArgoApps` hook is solely responsible for data fetching logic and state management (loading, error, data).

Separating Logic for Complexity:
If the application grows, we would further decouple by:
1.  **Service Layer:** Create an `argoService.ts` file that handles the actual HTTP requests and data mapping. The hook would call this service.
2.  **Context/Redux:** For global state (e.g., user auth, cluster selection), we could move the hook logic into a React Context or Redux slice to avoid prop drilling.
3.  **UI Library:** Extract the `Card` component into its own file (`ArgoAppCard.tsx`) to be reusable elsewhere.
*/
