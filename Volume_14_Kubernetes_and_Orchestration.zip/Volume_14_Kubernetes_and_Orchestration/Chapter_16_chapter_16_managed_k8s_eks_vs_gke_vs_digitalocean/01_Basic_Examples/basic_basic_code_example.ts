/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * @file supervisor-worker-demo.ts
 * @description A self-contained TypeScript example demonstrating the Supervisor Node
 *              and Worker Agent Pool pattern for a SaaS application.
 */

// ============================================================================
// 1. TYPE DEFINITIONS & INTERFACES
// ============================================================================

/**
 * Defines the types of tasks available in our system.
 * Using a union of string literals for type safety.
 */
type TaskType = 'DATABASE_QUERY' | 'REPORT_GENERATION' | 'SEARCH';

/**
 * Represents a generic task dispatched by the Supervisor to a worker.
 * @property id - A unique identifier for the task.
 * @property type - The type of task, determining which worker will handle it.
 * @property payload - The data required by the worker to execute the task.
 */
interface AgentTask<T = any> {
  id: string;
  type: TaskType;
  payload: T;
}

/**
 * Represents the result returned by a worker agent.
 * @property taskId - The ID of the task that was completed.
 * @property success - Indicates if the task was successful.
 * @property data - The output from the worker (e.g., database rows, generated text).
 */
interface AgentResult<T = any> {
  taskId: string;
  success: boolean;
  data: T | null;
  error?: string;
}

// ============================================================================
// 2. WORKER AGENT IMPLEMENTATIONS
// ============================================================================

/**
 * Simulates a Database Agent responsible for fetching user data.
 * In a real-world scenario, this would connect to a PostgreSQL or MongoDB instance.
 * @param task - The task containing the user ID to query.
 * @returns A promise resolving to the query result.
 */
const databaseWorker = async (
  task: AgentTask<{ userId: string }>
): Promise<AgentResult<{ id: string; name: string; email: string }>> => {
  console.log(`[DB Worker] Executing task ${task.id}: Fetching user ${task.payload.userId}`);

  // Simulate network latency and database I/O
  await new Promise((resolve) => setTimeout(resolve, 1000));

  // Simulate a database record
  const mockUser = {
    id: task.payload.userId,
    name: "Alice",
    email: "alice@example.com",
  };

  return {
    taskId: task.id,
    success: true,
    data: mockUser,
  };
};

/**
 * Simulates a Report Generation Agent responsible for creating a summary.
 * This worker is CPU-intensive and could be scaled independently in Kubernetes.
 * @param task - The task containing the raw data to summarize.
 * @returns A promise resolving to the generated report.
 */
const reportWorker = async (
  task: AgentTask<{ userData: any }>
): Promise<AgentResult<{ summary: string; generatedAt: Date }>> => {
  console.log(`[Report Worker] Executing task ${task.id}: Generating report for user ${task.payload.userData.id}`);

  // Simulate CPU-bound processing time
  await new Promise((resolve) => setTimeout(resolve, 1500));

  const summary = `Summary for ${task.payload.userData.name} (${task.payload.userData.email}): Account active. Last login: Today.`;

  return {
    taskId: task.id,
    success: true,
    data: {
      summary,
      generatedAt: new Date(),
    },
  };
};

// ============================================================================
// 3. SUPERVISOR NODE IMPLEMENTATION
// ============================================================================

/**
 * The Supervisor Node manages the Worker Agent Pool.
 * It does not execute tasks itself; it routes them to the appropriate worker.
 */
class SupervisorNode {
  // A map to register worker functions to specific task types.
  private workerPool: Map<TaskType, Function>;

  constructor() {
    this.workerPool = new Map();
    this.registerWorkers();
  }

  /**
   * Registers available workers into the pool.
   * In a distributed system, this might involve service discovery or HTTP endpoints.
   */
  private registerWorkers(): void {
    this.workerPool.set('DATABASE_QUERY', databaseWorker);
    this.workerPool.set('REPORT_GENERATION', reportWorker);
    // 'SEARCH' worker is intentionally omitted to demonstrate error handling later.
  }

  /**
   * Dispatches a task to the appropriate worker in the pool.
   * @param task - The task to be executed.
   * @returns A promise resolving to the worker's result.
   */
  async dispatch(task: AgentTask): Promise<AgentResult> {
    const worker = this.workerPool.get(task.type);

    if (!worker) {
      // Error handling: No worker is registered for this task type.
      return {
        taskId: task.id,
        success: false,
        data: null,
        error: `No worker registered for task type: ${task.type}`,
      };
    }

    try {
      // Execute the task using the registered worker.
      const result = await worker(task);
      return result;
    } catch (error) {
      // Error handling: Worker execution failed.
      return {
        taskId: task.id,
        success: false,
        data: null,
        error: `Worker execution failed: ${error instanceof Error ? error.message : 'Unknown error'}`,
      };
    }
  }

  /**
   * Orchestrates a complex workflow by dispatching multiple tasks and aggregating results.
   * This simulates the logic of a SaaS API endpoint.
   * @param userId - The ID of the user for whom the report is being generated.
   * @returns The final aggregated report.
   */
  async generateUserReport(userId: string): Promise<{ summary: string } | { error: string }> {
    console.log(`\n[Supervisor] Starting workflow for user: ${userId}`);

    // Step 1: Dispatch Database Query
    const dbTaskId = `task-db-${Date.now()}`;
    const dbTask: AgentTask<{ userId: string }> = {
      id: dbTaskId,
      type: 'DATABASE_QUERY',
      payload: { userId },
    };

    const dbResult = await this.dispatch(dbTask);

    if (!dbResult.success || !dbResult.data) {
      return { error: `Failed to fetch user data: ${dbResult.error}` };
    }

    // Step 2: Dispatch Report Generation using data from Step 1
    const reportTaskId = `task-report-${Date.now()}`;
    const reportTask: AgentTask<{ userData: any }> = {
      id: reportTaskId,
      type: 'REPORT_GENERATION',
      payload: { userData: dbResult.data },
    };

    const reportResult = await this.dispatch(reportTask);

    if (!reportResult.success || !reportResult.data) {
      return { error: `Failed to generate report: ${reportResult.error}` };
    }

    // Step 3: Return aggregated result
    console.log(`[Supervisor] Workflow completed successfully.`);
    return { summary: reportResult.data.summary };
  }
}

// ============================================================================
// 4. MAIN EXECUTION (SIMULATING A WEB APP REQUEST)
// ============================================================================

/**
 * Main entry point to simulate a SaaS application handling an API request.
 */
async function main() {
  console.log("=== SaaS Application: Report Generator ===");
  
  const supervisor = new SupervisorNode();
  
  // Simulate an incoming API request for user 'u123'
  const userId = 'u123';
  const report = await supervisor.generateUserReport(userId);
  
  console.log("\n--- Final Report ---");
  if ('error' in report) {
    console.error("ERROR:", report.error);
  } else {
    console.log(report.summary);
  }

  // Demonstrate error handling with an unsupported task type
  console.log("\n--- Testing Error Handling ---");
  const unsupportedTask: AgentTask = {
    id: 'task-unsupported-001',
    type: 'SEARCH', // This worker is not registered
    payload: { query: 'test' },
  };
  const errorResult = await supervisor.dispatch(unsupportedTask);
  console.log(`Result for unsupported task: ${errorResult.error}`);
}

// Run the simulation
main();
