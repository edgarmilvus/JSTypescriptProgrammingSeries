/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// app/api/ai-cluster-supervisor/route.ts
import { NextResponse } from 'next/server';
import { z } from 'zod';

/**
 * ============================================================================
 * 1. TYPE DEFINITIONS & SCHEMAS
 * ============================================================================
 * Defining the structure of our AI State and Agent Requests.
 * This ensures type safety across the cluster nodes.
 */

// Represents the AIState mentioned in the definitions: 
// The model's understanding including raw output and tool calls.
interface AIState {
  conversationId: string;
  currentGoal: string;
  rawOutput?: string;
  structuredData?: Record<string, any>;
  toolCalls: Array<{ name: string; args: any }>;
}

// Schema for validating incoming requests to the Supervisor
const requestSchema = z.object({
  prompt: z.string().min(1),
  userId: z.string(),
  priority: z.enum(['low', 'high']).default('low'),
});

// Enum for our Worker Agent Types
enum AgentType {
  CODE_GENERATOR = 'CODE_GENERATOR', // Requires GPU
  DATABASE_QUERY = 'DATABASE_QUERY', // CPU intensive
  WEB_SEARCH = 'WEB_SEARCH',         // I/O intensive
}

/**
 * ============================================================================
 * 2. WORKER AGENT POOL SIMULATION
 * ============================================================================
 * In a real Kubernetes environment, these would be separate microservices
 * deployed as Pods. For this script, we simulate the network calls and 
 * resource constraints.
 */

class WorkerAgent {
  constructor(
    public type: AgentType,
    public endpoint: string, // Internal K8s Service DNS (e.g., http://code-agent.svc.cluster.local)
    public resourceRequirements: { cpu: string; memory: string; gpu?: boolean }
  ) {}

  /**
   * Simulates dispatching a task to a specific worker pod.
   * In production, this uses fetch() or gRPC to the internal service.
   */
  async execute(task: string, context: AIState): Promise<AIState> {
    console.log(`[Supervisor] Dispatching to ${this.type} at ${this.endpoint}`);
    
    // Simulate network latency
    await new Promise(resolve => setTimeout(resolve, 200 + Math.random() * 300));

    // Simulate Agent Processing
    let result = '';
    switch (this.type) {
      case AgentType.CODE_GENERATOR:
        result = `// Generated Kubernetes Deployment YAML\napiVersion: apps/v1\nkind: Deployment\nmetadata:\n  name: ${task}`;
        break;
      case AgentType.DATABASE_QUERY:
        result = `SELECT * FROM users WHERE request = '${task}' LIMIT 10;`;
        break;
      case AgentType.WEB_SEARCH:
        result = `Search results for: ${task}`;
        break;
    }

    return {
      ...context,
      rawOutput: result,
      toolCalls: [...context.toolCalls, { name: this.type, args: { task } }],
    };
  }
}

/**
 * ============================================================================
 * 3. SUPERVISOR NODE LOGIC
 * ============================================================================
 * The entry point. Handles routing, load balancing, and state management.
 */

class SupervisorNode {
  private agents: WorkerAgent[];

  constructor() {
    // Initialize the Worker Agent Pool
    // In K8s, these endpoints are dynamic (Service Discovery)
    this.agents = [
      new WorkerAgent(AgentType.CODE_GENERATOR, 'http://code-agent', { cpu: '2', memory: '4Gi', gpu: true }),
      new WorkerAgent(AgentType.DATABASE_QUERY, 'http://db-agent', { cpu: '1', memory: '2Gi' }),
      new WorkerAgent(AgentType.WEB_SEARCH, 'http://search-agent', { cpu: '500m', memory: '1Gi' }),
    ];
  }

  /**
   * Analyzes the prompt to determine the best suited Worker Agent.
   * This is a simplified intent recognition logic.
   */
  private routeRequest(prompt: string): WorkerAgent {
    const lowerPrompt = prompt.toLowerCase();

    if (lowerPrompt.includes('generate') || lowerPrompt.includes('code') || lowerPrompt.includes('yaml')) {
      // Route to GPU-enabled node pool
      return this.agents.find(a => a.type === AgentType.CODE_GENERATOR)!;
    } 
    else if (lowerPrompt.includes('search') || lowerPrompt.includes('find')) {
      return this.agents.find(a => a.type === AgentType.WEB_SEARCH)!;
    }
    
    // Default to Database Query Agent
    return this.agents.find(a => a.type === AgentType.DATABASE_QUERY)!;
  }

  /**
   * Main processing pipeline.
   */
  async processRequest(input: { prompt: string; userId: string }): Promise<AIState> {
    // 1. Initialize State
    const state: AIState = {
      conversationId: `conv_${Date.now()}`,
      currentGoal: input.prompt,
      toolCalls: [],
    };

    // 2. Route to appropriate Worker
    const targetAgent = this.routeRequest(input.prompt);

    // 3. Execute Task
    const finalState = await targetAgent.execute(input.prompt, state);

    // 4. Post-Processing (e.g., formatting response for UI)
    return {
      ...finalState,
      structuredData: {
        agentUsed: targetAgent.type,
        timestamp: new Date().toISOString(),
        costEstimate: targetAgent.resourceRequirements.gpu ? 0.05 : 0.01, // Mock cost calculation
      }
    };
  }
}

/**
 * ============================================================================
 * 4. NEXT.JS API ROUTE HANDLER
 * ============================================================================
 * The HTTP entry point exposed to the frontend.
 */

// Initialize Supervisor Singleton (simulating a persistent K8s Pod)
const supervisor = new SupervisorNode();

export async function POST(request: Request) {
  try {
    // Parse and Validate Input
    const body = await request.json();
    const { prompt, userId } = requestSchema.parse(body);

    // Process via the Supervisor Node
    const aiState = await supervisor.processRequest({ prompt, userId });

    // Return structured response
    return NextResponse.json({
      success: true,
      data: aiState.structuredData,
      content: aiState.rawOutput,
      conversationId: aiState.conversationId,
    });

  } catch (error) {
    console.error('[Supervisor] Error:', error);
    return NextResponse.json(
      { error: 'Internal Cluster Error', details: error instanceof Error ? error.message : 'Unknown' },
      { status: 500 }
    );
  }
}
