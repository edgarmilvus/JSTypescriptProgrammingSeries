/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// Interfaces for configuration
interface CloudProviderConfig {
    provider: 'eks' | 'gke';
    clusterName: string;
    namespace: string;
    serviceAccountName: string;
}

/**
 * Generates Kubernetes manifest snippets for control plane authentication
 * based on the cloud provider (EKS or GKE).
 */
function generateAuthManifest(config: CloudProviderConfig): string {
    let manifest = '';

    if (config.provider === 'eks') {
        // EKS Logic: Requires IAM OIDC Provider association
        // Mocking Account ID and Role Name for the example
        const accountId = '123456789012';
        const roleName = 'eks-service-account-role';
        
        manifest = `
# 1. Kubernetes ServiceAccount with IAM Role ARN annotation
apiVersion: v1
kind: ServiceAccount
metadata:
  name: ${config.serviceAccountName}
  namespace: ${config.namespace}
  annotations:
    eks.amazonaws.com/role-arn: arn:aws:iam::${accountId}:role/${roleName}

---
# 2. IAM Policy Document (JSON snippet) for OIDC trust
# This allows the Kubernetes SA to assume the IAM Role
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Principal": {
        "Federated": "arn:aws:iam::${accountId}:oidc-provider/oidc.eks.us-east-1.amazonaws.com/id/EXAMPLE"
      },
      "Action": "sts:AssumeRoleWithWebIdentity",
      "Condition": {
        "StringEquals": {
          "oidc.eks.us-east-1.amazonaws.com/id/EXAMPLE:sub": "system:serviceaccount:${config.namespace}:${config.serviceAccountName}"
        }
      }
    }
  ]
}`;
    } else if (config.provider === 'gke') {
        // GKE Logic: Workload Identity
        // Mocking GCP Service Account Email
        const gcpServiceAccount = `${config.serviceAccountName}@${config.clusterName}.iam.gserviceaccount.com`;

        manifest = `
# 1. Kubernetes ServiceAccount with GCP Service Account annotation
apiVersion: v1
kind: ServiceAccount
metadata:
  name: ${config.serviceAccountName}
  namespace: ${config.namespace}
  annotations:
    iam.gke.io/gcp-service-account: ${gcpServiceAccount}

---
# 2. RoleBinding to bind K8s SA to a Role (simplified example)
apiVersion: rbac.authorization.k8s.io/v1
kind: RoleBinding
metadata:
  name: ${config.serviceAccountName}-binding
  namespace: ${config.namespace}
subjects:
- kind: ServiceAccount
  name: ${config.serviceAccountName}
  namespace: ${config.namespace}
roleRef:
  kind: Role
  name: developer-role
  apiGroup: rbac.authorization.k8s.io`;
    }

    return manifest;
}

/**
 * Validates if the generated manifest contains the required provider-specific annotation.
 */
function validateManifest(manifest: string, provider: 'eks' | 'gke'): boolean {
    const requiredAnnotation = provider === 'eks' 
        ? 'eks.amazonaws.com/role-arn' 
        : 'iam.gke.io/gcp-service-account';
    
    return manifest.includes(requiredAnnotation);
}

// Example Usage:
// const config: CloudProviderConfig = { provider: 'eks', clusterName: 'prod-cluster', namespace: 'default', serviceAccountName: 'my-app-sa' };
// const output = generateAuthManifest(config);
// console.log(output);
// console.log('Valid:', validateManifest(output, 'eks'));
