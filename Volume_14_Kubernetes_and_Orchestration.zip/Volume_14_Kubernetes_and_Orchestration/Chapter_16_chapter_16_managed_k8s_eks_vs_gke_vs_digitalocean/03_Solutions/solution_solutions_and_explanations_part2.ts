/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

/**
 * Graphviz DOT script visualizing the Pod Lifecycle and HPA interaction on GKE Autopilot.
 * 
 * [ERROR: Failed to render diagram.]
 * Note: In a real environment, this string would be passed to a Graphviz renderer.
 * The visual structure represents the flow defined in the requirements.
 */
export const DOT_DIAGRAM_CONTENT = `
digraph GKEAutopilotLifecycle {
    rankdir=TB;
    node [shape=rect, style=filled, fillcolor="#e3f2fd", fontname="Helvetica"];

    // Define Nodes
    PodRunning [label="Node.js App Pod Running", fillcolor="#a5d6a7"];
    CPUMonitor [label="CPU Usage > Threshold?", shape=diamond, fillcolor="#ffcc80"];
    ScaleUp [label="Scale Up (HPA)", fillcolor="#90caf9"];
    ProvisionNode [label="GKE Autopilot: Provision Node", fillcolor="#ce93d8"];
    SchedulePod [label="K8s Scheduler: Place Pod", fillcolor="#90caf9"];
    ScaleDown [label="Scale Down (HPA)", fillcolor="#ef9a9a"];
    CordonNode [label="GKE Autopilot: Cordon & Drain", fillcolor="#ce93d8"];

    // Define Logic Flow
    PodRunning -> CPUMonitor;

    // Positive Branch (Scale Up)
    CPUMonitor -> ScaleUp [label="Yes"];
    ScaleUp -> ProvisionNode;
    ProvisionNode -> SchedulePod;
    SchedulePod -> PodRunning [label="Pod Scheduled"];

    // Negative Branch (Scale Down)
    CPUMonitor -> ScaleDown [label="No (Consistently Low)"];
    ScaleDown -> CordonNode;
    CordonNode -> NodeRemoved [label="Node Deleted"];

    // Node definition for the end state
    NodeRemoved [label="Node Removed", shape=ellipse, fillcolor="#eeeeee"];
}
`;
