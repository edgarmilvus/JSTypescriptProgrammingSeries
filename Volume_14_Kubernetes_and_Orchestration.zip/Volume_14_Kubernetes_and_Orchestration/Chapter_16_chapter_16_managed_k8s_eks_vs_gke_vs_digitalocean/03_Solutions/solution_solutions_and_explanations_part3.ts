/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

import * as readline from 'readline';

// State Management Interface
interface DeploymentState {
    activeVersion: 'blue' | 'green';
    trafficPercentage: number;
    isStable: boolean;
}

// Helper to simulate delay
const sleep = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

// Setup CLI Interface
const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

/**
 * Runs the interactive Blue/Green deployment simulation.
 */
export async function runDeploymentSimulation() {
    let state: DeploymentState = {
        activeVersion: 'blue',
        trafficPercentage: 100, // 100% on Blue initially
        isStable: true
    };

    console.log("--- Blue/Green Deployment Simulator (DigitalOcean K8s) ---");
    console.log("Commands: 'deploy v2', 'check', 'exit'");
    console.log("Current State:", state);

    // Recursive function to handle async input
    const prompt = () => {
        rl.question('\nCommand > ', async (input: string) => {
            const command = input.trim().toLowerCase();

            if (command === 'exit') {
                console.log("Exiting simulation.");
                rl.close();
                return;
            }

            if (command === 'check') {
                console.log(`Current State: Active Version=${state.activeVersion}, Traffic=${state.trafficPercentage}%, Stable=${state.isStable}`);
            } 
            else if (command === 'deploy v2') {
                if (state.activeVersion === 'green') {
                    console.log("v2 is already active. Resetting to v1 first would be required in a real scenario.");
                } else {
                    console.log("Initiating Blue/Green Switch to v2...");
                    state.isStable = false;

                    // 1. Deploy Green version (Simulated by updating internal state)
                    // In real K8s: Apply Deployment manifest with image: node-app:v2.0
                    console.log("[Simulated] K8s Deployment 'node-app-green' created with image v2.0");

                    // 2. Increment Traffic Shifting
                    const steps = [0, 25, 50, 75, 100];
                    for (const percentage of steps) {
                        state.trafficPercentage = percentage;
                        
                        // Simulate updating Service selector
                        // Real K8s: kubectl patch svc my-service -p '{"spec":{"selector":{"version":"v2"}}}'
                        console.log(`[Simulated] Service Selector Updated: Traffic to Green = ${percentage}%`);
                        
                        console.log(`Waiting 1 second...`);
                        await sleep(1000);
                    }

                    // 3. Finalize
                    state.activeVersion = 'green';
                    state.isStable = true;
                    console.log("Deployment Complete. Green is now active.");
                }
            } else {
                console.log("Unknown command. Try 'deploy v2', 'check', or 'exit'.");
            }

            // Loop
            prompt();
        });
    };

    prompt();
}

// To run this in a node environment, you would call runDeploymentSimulation();
