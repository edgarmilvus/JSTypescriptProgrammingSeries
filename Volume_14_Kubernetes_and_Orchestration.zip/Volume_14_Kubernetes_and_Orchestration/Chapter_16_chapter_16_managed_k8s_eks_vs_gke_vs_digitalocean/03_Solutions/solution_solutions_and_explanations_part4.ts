/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

interface GPUWorkloadConfig {
    modelName: string;
    gpuType: 'nvidia-tesla-t4' | 'nvidia-a10g';
    replicas: number;
    nodeSelectorRequirement: { key: string, operator: string, values: string[] };
}

/**
 * Generates a Kubernetes Deployment object for AI workloads requiring GPUs.
 */
export function generateGPUDeployment(config: GPUWorkloadConfig): object {
    // Construct the Deployment manifest as a JavaScript object
    const deployment = {
        apiVersion: 'apps/v1',
        kind: 'Deployment',
        metadata: {
            name: `ai-inference-${config.modelName.replace(/\s+/g, '-').toLowerCase()}`,
            labels: {
                app: config.modelName
            }
        },
        spec: {
            replicas: config.replicas,
            selector: {
                matchLabels: {
                    app: config.modelName
                }
            },
            template: {
                metadata: {
                    labels: {
                        app: config.modelName
                    }
                },
                spec: {
                    // 1. NodeSelector: Direct targeting of specific instance types
                    nodeSelector: {
                        [config.nodeSelectorRequirement.key]: config.nodeSelectorRequirement.values[0]
                    },
                    
                    // 2. Tolerations: Mandatory to schedule on nodes tainted with GPU resources
                    tolerations: [
                        {
                            key: "nvidia.com/gpu",
                            operator: "Exists",
                            effect: "NoSchedule"
                        }
                    ],
                    
                    containers: [
                        {
                            name: 'inference-container',
                            image: `tensorflow/tensorflow:latest-gpu`, // Example image
                            resources: {
                                limits: {
                                    // 3. Resource Limits: Requesting physical GPU hardware
                                    'nvidia.com/gpu': 1, 
                                    'cpu': '2',
                                    'memory': '4Gi'
                                },
                                requests: {
                                    'cpu': '1',
                                    'memory': '2Gi'
                                }
                            },
                            // 4. Liveness Probe: Extended initial delay for model warmup
                            livenessProbe: {
                                httpGet: {
                                    path: '/health',
                                    port: 8080
                                },
                                initialDelaySeconds: 60, // Critical for AI models
                                periodSeconds: 10
                            }
                        }
                    ]
                }
            }
        }
    };

    return deployment;
}

/* 
 * Instructor's Comments embedded in logic:
 * 
 * WHY nodeSelector?
 * - We use 'nodeSelector' here because the requirement is simple: target a specific instance type 
 *   (e.g., g4dn.xlarge) which has a specific GPU. NodeAffinity is more powerful (expressions, weights)
 *   but overkill for a hard requirement like "Must have this GPU".
 * 
 * WHY toleration?
 * - EKS GPU nodes often have a taint (e.g., `nvidia.com/gpu:NoSchedule`) to prevent general workloads 
 *   from scheduling on them (since GPUs are expensive/shared). Without this toleration, the pod 
 *   will remain in Pending state, unable to schedule.
 */
