/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState, useEffect } from 'react';

// Props Interface
interface ClusterProps {
    cluster: {
        name: string;
        provider: 'EKS' | 'GKE' | 'DigitalOcean';
        controlPlaneStatus: 'Healthy' | 'Updating' | 'Degraded';
        nodePools: Array<{ name: string; status: 'Ready' | 'NotReady' | 'Scaling' }>;
    };
}

// Helper to get color based on status
const getStatusColor = (status: string) => {
    switch (status) {
        case 'Healthy': return 'green';
        case 'Ready': return 'green';
        case 'Updating': return 'orange';
        case 'Scaling': return 'orange';
        case 'Degraded': return 'red';
        case 'NotReady': return 'red';
        default: return 'gray';
    }
};

export const ClusterStatusDashboard: React.FC<ClusterProps> = ({ cluster: initialCluster }) => {
    const [cluster, setCluster] = useState(initialCluster);

    useEffect(() => {
        // Simulate polling every 5 seconds
        const intervalId = setInterval(() => {
            // Logic to simulate random instability
            setCluster(prev => {
                // Randomly toggle Control Plane status
                const statuses: Array<'Healthy' | 'Updating' | 'Degraded'> = ['Healthy', 'Updating', 'Degraded'];
                const randomCPStatus = statuses[Math.floor(Math.random() * statuses.length)];

                // Randomly toggle Node Pool status
                const nodeStatuses: Array<'Ready' | 'NotReady' | 'Scaling'> = ['Ready', 'NotReady', 'Scaling'];
                const updatedNodePools = prev.nodePools.map(pool => ({
                    ...pool,
                    status: nodeStatuses[Math.floor(Math.random() * nodeStatuses.length)]
                }));

                return {
                    ...prev,
                    controlPlaneStatus: randomCPStatus,
                    nodePools: updatedNodePools
                };
            });
        }, 5000);

        // Cleanup function to clear interval on unmount
        return () => clearInterval(intervalId);
    }, []);

    // Render Provider Icon Placeholder
    const renderProviderIcon = () => {
        if (cluster.provider === 'EKS') return <span style={{ fontWeight: 'bold', color: '#FF9900' }}> [AWS Icon] </span>;
        if (cluster.provider === 'GKE') return <span style={{ fontWeight: 'bold', color: '#34A853' }}> [GCP Icon] </span>;
        return <span> [DO Icon] </span>;
    };

    return (
        <div style={{ fontFamily: 'Arial, sans-serif', padding: '20px', border: '1px solid #ccc', borderRadius: '8px', maxWidth: '400px' }}>
            <h3>
                {cluster.name} {renderProviderIcon()}
            </h3>

            {/* Control Plane Section */}
            <div style={{ marginBottom: '15px' }}>
                <strong>Control Plane: </strong>
                <span style={{ 
                    color: 'white', 
                    backgroundColor: getStatusColor(cluster.controlPlaneStatus), 
                    padding: '2px 8px', 
                    borderRadius: '4px',
                    fontSize: '0.9em'
                }}>
                    {cluster.controlPlaneStatus}
                </span>
            </div>

            {/* Node Pools Section */}
            <div>
                <strong>Node Pools:</strong>
                <ul style={{ listStyle: 'none', padding: 0 }}>
                    {cluster.nodePools.map((pool, index) => (
                        <li key={index} style={{ marginBottom: '5px' }}>
                            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                                <span>{pool.name}</span>
                                <div style={{ width: '100px', height: '10px', backgroundColor: '#eee', borderRadius: '5px', overflow: 'hidden' }}>
                                    {/* Visual Progress Bar simulation */}
                                    <div 
                                        style={{ 
                                            width: pool.status === 'Ready' ? '100%' : pool.status === 'Scaling' ? '50%' : '0%', 
                                            height: '100%', 
                                            backgroundColor: getStatusColor(pool.status) 
                                        }} 
                                    />
                                </div>
                            </div>
                            <small style={{ color: getStatusColor(pool.status) }}>{pool.status}</small>
                        </li>
                    ))}
                </ul>
            </div>
        </div>
    );
};
