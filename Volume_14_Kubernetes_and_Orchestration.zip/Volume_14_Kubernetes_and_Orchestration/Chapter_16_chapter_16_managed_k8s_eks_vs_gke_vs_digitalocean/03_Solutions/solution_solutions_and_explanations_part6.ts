/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part6.ts
// Description: Solutions and Explanations
// ==========================================

interface PackageJson {
    dependencies: Record<string, string>;
    devDependencies: Record<string, string>;
}

/**
 * Generates a multi-stage Dockerfile optimized for production Node.js deployments.
 * 
 * @param packageJson - The parsed package.json object
 * @returns A string containing the Dockerfile instructions
 */
export function generateDockerfile(packageJson: PackageJson): string {
    // We don't strictly need to parse the object keys for the string generation,
    // as 'npm ci' handles installation, but we check existence for logic flow.
    const hasDeps = packageJson.dependencies && Object.keys(packageJson.dependencies).length > 0;
    const hasDevDeps = packageJson.devDependencies && Object.keys(packageJson.devDependencies).length > 0;

    return `
# STAGE 1: Builder
# This stage installs ALL dependencies (including devDependencies) to build the app.
FROM node:18-alpine AS builder

WORKDIR /app

# Copy dependency manifests
COPY package*.json ./

# Install everything. 'npm ci' is faster and more reliable than 'npm install' for CI/CD.
# It installs devDependencies automatically because they might be needed for building (e.g., TypeScript).
RUN npm ci

# Copy source code and build the application (e.g., transpile TypeScript)
COPY . .
RUN npm run build

# ---------------------------------------------------------

# STAGE 2: Production
# This stage creates the final, minimal image.
FROM node:18-alpine AS production

WORKDIR /app

# Copy dependency manifests again
COPY package*.json ./

# 1. Install ONLY production dependencies.
# This significantly reduces image size by excluding dev tools and libraries.
RUN npm ci --only=production

# 2. Optional: Prune explicitly (redundant with --only=production but good for safety)
RUN npm prune --production

# Copy the built artifacts from the 'builder' stage
COPY --from=builder /app/dist ./dist

# Security: Run as non-root user
USER node

# Start the app
CMD ["node", "dist/index.js"]
`;
}

/*
 * Instructor's Analysis of Logic:
 * 
 * 1. Multi-Stage Build:
 *    - The 'builder' stage is heavy. It contains the full Node.js environment, compilers (gcc), 
 *      and all devDependencies (like typescript, jest, eslint). This ensures the app can be built.
 *    - The 'production' stage is lightweight (Alpine Linux). It does not contain build tools.
 * 
 * 2. Size Optimization:
 *    - By using 'npm ci --only=production', we avoid copying heavy devDependencies into the final image.
 *    - Example: 'nodemon' is in devDependencies and is excluded, saving space and attack surface.
 * 
 * 3. Kubernetes Impact:
 *    - Smaller images pull faster across the cluster network.
 *    - Smaller images consume less disk space on worker nodes.
 *    - Reduced attack surface (fewer binaries/libraries) improves security posture.
 */
