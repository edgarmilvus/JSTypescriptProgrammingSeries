/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: theory_theoretical_foundations.ts
// Description: Theoretical Foundations
// ==========================================

digraph G {
    rankdir=TB;
    node [shape=box, style="rounded,filled", fillcolor="lightgrey"];

    subgraph cluster_0 {
        label = "Kubernetes Cluster (Fortress)";
        style = dashed;
        color = blue;

        subgraph cluster_1 {
            label = "Namespace: 'ai-services' (Walled Garden)";
            style = dashed;
            color = green;

            pod_fe [label="Frontend Pod\n(Label: app=frontend)\nSecurity Context:\n- runAsNonRoot: true\n- readOnlyRootFilesystem: true"];
            pod_api [label="API Pod\n(Label: app=api)\nSecurity Context:\n- runAsNonRoot: true\n- readOnlyRootFilesystem: true"];
            pod_db [label="Vector DB Pod\n(Label: app=vector-db)\nSecurity Context:\n- runAsNonRoot: true\n- readOnlyRootFilesystem: true"];
        }
    }

    // Network Policy Rules (Visualized as edges with labels)
    pod_fe -> pod_api [label="Network Policy:\nAllow Ingress from 'frontend' to 'api' on port 8080", color="green", fontcolor="green", style=dashed];
    pod_api -> pod_db [label="Network Policy:\nAllow Ingress from 'api' to 'vector-db' on port 8080", color="green", fontcolor="green", style=dashed];

    // Explicitly show what is NOT allowed
    pod_fe -> pod_db [label="Blocked by Network Policy", color="red", style=dashed, fontcolor="red"];
    pod_db -> pod_fe [label="Blocked by Network Policy", color="red", style=dashed, fontcolor="red"];
}
