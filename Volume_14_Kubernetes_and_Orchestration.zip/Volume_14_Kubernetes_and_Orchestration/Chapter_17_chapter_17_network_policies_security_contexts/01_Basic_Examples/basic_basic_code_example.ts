/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * @file server.ts
 * @description A minimal Node.js Express server designed for a secure Kubernetes environment.
 * It demonstrates Non-Blocking I/O using async handlers and enforces strict input validation.
 */

import express, { Request, Response } from 'express';
import helmet from 'helmet'; // Security headers
import cors from 'cors';     // Cross-Origin Resource Sharing

/**
 * Application Constants
 * In a production environment, these should be injected via environment variables.
 */
const PORT = process.env.PORT || 3000;
const ALLOWED_ORIGIN = process.env.ALLOWED_ORIGIN || 'http://localhost:3000';

/**
 * Initialize Express Application
 * We use middleware to enforce security best practices immediately.
 */
const app = express();

// 1. Security Middleware
// Helmet helps secure Express apps by setting various HTTP headers.
app.use(helmet());

// 2. CORS Configuration
// Restricts cross-origin requests to only the defined frontend domain.
app.use(cors({
    origin: ALLOWED_ORIGIN,
    methods: ['GET', 'POST'],
    credentials: true
}));

// 3. Body Parsing
// express.json() parses incoming requests with JSON payloads.
app.use(express.json());

/**
 * Health Check Endpoint
 * Kubernetes liveness/readiness probes will hit this to verify the pod is running.
 * This is a non-blocking operation (synchronous response).
 */
app.get('/health', (req: Request, res: Response) => {
    res.status(200).json({ status: 'healthy', timestamp: new Date().toISOString() });
});

/**
 * AI Inference / Data Processing Endpoint
 * Simulates a lightweight edge computation task.
 * In a real scenario, this might validate data before passing it to a larger model.
 * 
 * @param req.body.input - The data string to process
 */
app.post('/api/process', async (req: Request, res: Response) => {
    try {
        const { input } = req.body;

        // Input Validation (Security Best Practice)
        if (!input || typeof input !== 'string') {
            return res.status(400).json({ error: 'Invalid input provided.' });
        }

        // Simulate Non-Blocking I/O
        // In a real app, this might be a database call or a lightweight model inference.
        // Using async/await ensures the event loop isn't blocked while waiting.
        const processedResult = await simulateAsyncProcessing(input);

        res.status(200).json({
            original: input,
            processed: processedResult,
            edgeProcessed: true
        });
    } catch (error) {
        console.error('Processing error:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

/**
 * Simulates an asynchronous operation (e.g., I/O or calculation).
 * This mimics the Non-Blocking I/O paradigm of Node.js.
 */
async function simulateAsyncProcessing(data: string): Promise<string> {
    return new Promise((resolve) => {
        // Delegating to the event loop (simulated delay)
        setImmediate(() => {
            resolve(data.toUpperCase());
        });
    });
}

/**
 * Start Server
 * Binds the server to the port defined by the Kubernetes environment.
 */
app.listen(PORT, () => {
    console.log(`Secure Node.js service running on port ${PORT}`);
});

export default app;
