/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.ts
// Description: Basic Code Example
// ==========================================

# 1. Security Context Definition
# This enforces privilege restrictions at the Pod level.
apiVersion: v1
kind: Pod
metadata:
  name: nodejs-api-pod
  labels:
    app: nodejs-api
    role: backend
spec:
  securityContext:
    # Run as non-root user (UID 1000)
    runAsNonRoot: true
    runAsUser: 1000
    runAsGroup: 1000
    # Restrict privilege escalation capabilities
    allowPrivilegeEscalation: false
    # Add only necessary capabilities (dropping all by default is safer)
    capabilities:
      drop:
        - ALL
  containers:
  - name: api-container
    image: my-registry/nodejs-api:latest
    ports:
    - containerPort: 3000
    # Container-level security context
    securityContext:
      # Prevents the container from writing to the root filesystem
      readOnlyRootFilesystem: true
      # Allow only specific capabilities if needed (e.g., NET_BIND_SERVICE for port 80)
      capabilities:
        drop:
          - ALL
    # Mount a temporary volume for writable logs (since root FS is read-only)
    volumeMounts:
    - name: tmp-volume
      mountPath: /tmp
  volumes:
  - name: tmp-volume
    emptyDir: {}

---
# 2. Network Policy Definition
# This acts as a firewall for the Pod, isolating it from other pods and the internet.
apiVersion: networking.k8s.io/v1
kind: NetworkPolicy
metadata:
  name: api-isolation-policy
  namespace: default
spec:
  podSelector:
    matchLabels:
      app: nodejs-api
  policyTypes:
    - Ingress
    - Egress
  
  # INGRESS RULES (Who can talk to the API?)
  ingress:
    - from:
        - podSelector:
            matchLabels:
              app: frontend # Only allow traffic from the Frontend Pod
        - namespaceSelector:
            matchLabels:
              name: frontend-namespace # Optional: Allow from specific namespace
      ports:
        - protocol: TCP
          port: 3000
  
  # EGRESS RULES (Who can the API talk to?)
  # In a secure 'Edge-First' setup, we often block all egress unless explicitly needed.
  egress:
    # Allow DNS resolution (Crucial for internal cluster communication)
    - to:
        - namespaceSelector: {}
        - podSelector:
            matchLabels:
              k8s-app: kube-dns
      ports:
        - protocol: UDP
          port: 53
    # Allow internal database access (Example: if the API needs a Postgres DB)
    - to:
        - podSelector:
            matchLabels:
              app: postgres
      ports:
        - protocol: TCP
          port: 5432
