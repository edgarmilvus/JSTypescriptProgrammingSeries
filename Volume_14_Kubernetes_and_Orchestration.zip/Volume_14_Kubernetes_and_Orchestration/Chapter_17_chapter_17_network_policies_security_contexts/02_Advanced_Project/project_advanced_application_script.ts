/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

# k8s/network-policy-ai-chatbot.yaml
apiVersion: networking.k8s.io/v1
kind: NetworkPolicy
metadata:
  name: ai-chatbot-isolation
  namespace: production
spec:
  # 1. Pod Selector: Targets only the AI Chatbot backend pods
  podSelector:
    matchLabels:
      app: ai-chatbot

  # 2. Policy Type: Explicitly defines ingress and egress rules
  policyTypes:
    - Ingress
    - Egress

  # 3. Ingress Rules: Allow traffic ONLY from the Ingress Controller (e.g., NGINX)
  # This prevents direct access to the backend, enforcing the "Edge-First" 
  # philosophy where the edge (ingress) handles routing and security.
  ingress:
    - from:
        - namespaceSelector:
            matchLabels:
              name: ingress-nginx
        - podSelector:
            matchLabels:
              app.kubernetes.io/name: ingress-nginx
      ports:
        - protocol: TCP
          port: 3000 # Next.js default port

  # 4. Egress Rules: Restrict outbound traffic to the AI Model Inference service only.
  # This prevents the chatbot from scanning the cluster or connecting to external
  # unauthorized APIs (Data Exfiltration prevention).
  egress:
    - to:
        - namespaceSelector:
            matchLabels:
              name: ai-services
        - podSelector:
            matchLabels:
              app: ai-model-inference
      ports:
        - protocol: TCP
          port: 8080 # Inference service port
