/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script_part2.ts
// Description: Advanced Application Script
// ==========================================

// app/actions/chatAction.ts
'use server';

import { NextResponse } from 'next/server';

/**
 * @interface InferenceRequest
 * @description The payload structure sent to the internal AI Model Inference service.
 */
interface InferenceRequest {
  prompt: string;
  userId: string;
  sessionId: string;
}

/**
 * @interface InferenceResponse
 * @description The response structure received from the internal AI Model Inference service.
 */
interface InferenceResponse {
  response: string;
  modelVersion: string;
}

/**
 * @function generateChatResponse
 * @description A Server Action that processes user input and calls the internal AI model.
 * 
 * SECURITY CONTEXT:
 * 1. This runs exclusively on the server (Node.js environment).
 * 2. It validates input to prevent injection attacks.
 * 3. It communicates ONLY with the internal AI service (enforced by NetworkPolicy).
 * 
 * EDGE-FIRST STRATEGY:
 * While this specific logic runs on the central server (for complex model inference),
 * the architecture allows for lightweight preprocessing (validation) at the edge
 * before the request reaches this secure backend.
 * 
 * @param {string} userInput - The raw text from the client.
 * @param {string} userId - The authenticated user ID.
 * @returns {Promise<NextResponse>} - A JSON response containing the AI answer or error.
 */
export async function generateChatResponse(
  userInput: string,
  userId: string
): Promise<NextResponse> {
  
  // --- 1. Input Sanitization & Validation ---
  // Security Context: Preventing injection and ensuring data integrity.
  if (!userInput || typeof userInput !== 'string' || userInput.length > 1000) {
    return NextResponse.json(
      { error: 'Invalid input payload' },
      { status: 400 }
    );
  }

  // --- 2. Prepare Secure Payload ---
  // We strip any potential client-side artifacts and prepare for internal transport.
  const inferencePayload: InferenceRequest = {
    prompt: userInput.trim(),
    userId: userId, // In a real app, this would come from a JWT or session
    sessionId: crypto.randomUUID(), // Generate a traceable ID for this interaction
  };

  // --- 3. Internal Service Communication ---
  // Network Policy Enforcement: The fetch call below is the ONLY egress allowed
  // for this pod. It connects to the 'ai-model-inference' service on port 8080.
  // If this pod tries to fetch external APIs (e.g., OpenAI directly), 
  // the Kubernetes NetworkPolicy will drop the packets.
  try {
    const AI_SERVICE_URL = process.env.AI_SERVICE_INTERNAL_URL || 'http://ai-model-inference.ai-services:8080/inference';

    const response = await fetch(AI_SERVICE_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        // Internal service authentication header
        'X-Internal-Secret': process.env.INTERNAL_SECRET_KEY || '',
      },
      body: JSON.stringify(inferencePayload),
      // Cache: 'no-store' ensures real-time inference, crucial for chatbots
      cache: 'no-store', 
    });

    if (!response.ok) {
      throw new Error(`Internal inference service returned ${response.status}`);
    }

    const data: InferenceResponse = await response.json();

    // --- 4. Post-Processing & Return ---
    // Security Context: Sanitize the response before sending to client.
    // (e.g., remove any internal debugging info or PII from the model output).
    const sanitizedResponse = data.response.replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, "");

    return NextResponse.json(
      { 
        message: sanitizedResponse, 
        model: data.modelVersion,
        traceId: inferencePayload.sessionId 
      },
      { status: 200 }
    );

  } catch (error) {
    // Error Handling: Log securely (do not expose stack traces to client)
    console.error(`[Chatbot Error] TraceID: ${inferencePayload.sessionId}`, error);
    
    return NextResponse.json(
      { error: 'AI Service temporarily unavailable. Please try again.' },
      { status: 503 }
    );
  }
}
