/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.tsx
// Description: Solutions and Explanations
// ==========================================

// SecureDashboard.tsx
import React, { useEffect, useState } from 'react';

interface FinancialData {
  revenue: number;
  expenses: number;
}

const SecureDashboard: React.FC = () => {
  const [data, setData] = useState<FinancialData | null>(null);
  const [error, setError] = useState<string>('');

  useEffect(() => {
    // Fetching data from the internal API
    const fetchData = async () => {
      try {
        // Note: In a real app, this might be a Server Action or proxied API call
        const response = await fetch('/api/financials');
        if (!response.ok) throw new Error('Failed to fetch');
        const result = await response.json();
        setData(result);
      } catch (err) {
        setError('Unable to load financial data.');
      }
    };
    fetchData();
  }, []);

  if (error) return <div>Error: {error}</div>;
  if (!data) return <div>Loading...</div>;

  return (
    <div className="dashboard">
      <h2>Financial Overview</h2>
      {/* Simple SVG Bar Chart Representation */}
      <svg width="200" height="100" viewBox="0 0 200 100">
        <rect x="10" y={100 - data.revenue} width="80" height={data.revenue} fill="green" />
        <rect x="110" y={100 - data.expenses} width="80" height={data.expenses} fill="red" />
      </svg>
      <p>Revenue: ${data.revenue}</p>
      <p>Expenses: ${data.expenses}</p>
    </div>
  );
};

export default SecureDashboard;
