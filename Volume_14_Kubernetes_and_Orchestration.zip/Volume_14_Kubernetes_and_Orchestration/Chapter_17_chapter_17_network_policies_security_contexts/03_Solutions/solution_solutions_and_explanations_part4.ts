/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

digraph SecureArchitecture {
    rankdir=LR;
    node [shape=box, style="rounded,filled", color="#E3F2FD"];

    // External Entities
    Client [label="Client (External User)", shape=ellipse, fillcolor="#FFF9C4"];
    
    // Infrastructure
    Ingress [label="Ingress Controller\n(Nginx/Traefik)", fillcolor="#D1C4E9"];

    // Workloads
    Frontend [label="Frontend Pod\n(React/Node.js)\nSecurity: Non-Root", fillcolor="#C8E6C9"];
    Backend [label="Backend Pod\n(Node.js API)\nSecurity: Non-Root, Read-Only FS, Drop ALL", fillcolor="#FFCCBC"];
    Database [label="Database Pod\n(PostgreSQL)\nSecurity: Non-Root, Read-Only FS", fillcolor="#B2DFDB"];

    // Traffic Flows
    Client -> Ingress [label="HTTPS/443", color="blue", fontcolor="blue"];
    Ingress -> Frontend [label="HTTP/3000", color="blue", fontcolor="blue"];
    Frontend -> Backend [label="HTTP/8080\n(NetworkPolicy: Allow)", color="green", fontcolor="green"];
    Backend -> Database [label="TCP/5432\n(NetworkPolicy: Allow)", color="green", fontcolor="green"];

    // Blocked Flows (Visualized conceptually)
    Client -> Backend [label="Blocked", color="red", style="dashed", fontcolor="red", constraint=false];
    Ingress -> Database [label="Blocked", color="red", style="dashed", fontcolor="red", constraint=false];
}
