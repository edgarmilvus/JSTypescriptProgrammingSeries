/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

// app.ts
import * as fs from 'fs';
import * as path from 'path';

// 1. Read configuration file (assumed to be in the image build)
const configPath = path.join(__dirname, 'config.json');
let config: any;

try {
  const data = fs.readFileSync(configPath, 'utf8');
  config = JSON.parse(data);
  console.log('Config loaded successfully:', config);
} catch (error) {
  console.error('Failed to load config:', error);
  process.exit(1);
}

// 2. Logger setup
const logDir = './logs';
const logFile = path.join(logDir, 'app.log');

// Ensure log directory exists (it might not if mounted fresh)
if (!fs.existsSync(logDir)) {
  fs.mkdirSync(logDir, { recursive: true });
}

// 3. Write log entry
const logEntry = `[${new Date().toISOString()}] Service started.\n`;

fs.appendFile(logFile, logEntry, (err) => {
  if (err) {
    // 4. Handle EACCES or other errors gracefully
    if (err.code === 'EACCES' || err.code === 'EROFS') {
      console.error('Permission denied: Cannot write to log file. Check volume mounts.');
    } else {
      console.error('Error writing log:', err);
    }
  } else {
    console.log('Log written successfully.');
  }
});
