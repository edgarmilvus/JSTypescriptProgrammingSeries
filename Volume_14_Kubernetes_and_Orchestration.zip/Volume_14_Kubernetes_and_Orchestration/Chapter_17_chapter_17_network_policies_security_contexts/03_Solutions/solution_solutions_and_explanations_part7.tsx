/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part7.tsx
// Description: Solutions and Explanations
// ==========================================

// ChatHistory.tsx
'use server'; // Marks this function as a Server Action (Next.js App Router)

import { sanitize } from 'dompurify'; // Hypothetical sanitization library

// Secure Fetch Function (Runs on Server)
export async function fetchChatHistory(conversationId: string) {
  // 1. Securely access environment variables (never exposed to client)
  const aiBackendUrl = process.env.AI_BACKEND_URL;
  const apiKey = process.env.AI_API_KEY;

  if (!aiBackendUrl || !apiKey) {
    throw new Error('Server configuration error');
  }

  try {
    // 2. Fetch from internal AI Inference Service
    const response = await fetch(`${aiBackendUrl}/conversations/${conversationId}`, {
      headers: {
        'Authorization': `Bearer ${apiKey}`,
      },
      cache: 'no-store', // Ensure fresh data
    });

    if (!response.ok) throw new Error('Failed to fetch history');
    
    const data = await response.json();
    return data.messages; // Return only the messages
  } catch (error) {
    console.error('Server-side fetch error:', error);
    return [];
  }
}

// Client Component
import React from 'react';
import { fetchChatHistory } from './ChatHistory';

interface ChatHistoryProps {
  conversationId: string;
}

const ChatHistory: React.FC<ChatHistoryProps> = async ({ conversationId }) => {
  // 3. Call the Server Action
  const messages = await fetchChatHistory(conversationId);

  return (
    <div className="chat-history">
      {messages.map((msg: { role: string; content: string }, idx: number) => (
        <div key={idx} className={`message ${msg.role}`}>
          {/* 4. Sanitize Content to prevent XSS */}
          <p dangerouslySetInnerHTML={{ __html: sanitize(msg.content) }} />
        </div>
      ))}
    </div>
  );
};

export default ChatHistory;
