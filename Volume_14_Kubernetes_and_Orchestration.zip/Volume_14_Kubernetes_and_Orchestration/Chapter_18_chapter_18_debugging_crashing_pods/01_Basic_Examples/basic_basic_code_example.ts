/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

// pages/api/register.ts
// This is a Next.js API route handler.
// It uses the Node.js runtime (default) for compatibility with Zod.
// The route validates a POST request body for user registration.

import type { NextApiRequest, NextApiResponse } from 'next';
import { z } from 'zod';

// Define the runtime validation schema using Zod.
// This schema enforces the shape and type of the incoming request body.
// It's immutable: once defined, it's a static blueprint for validation.
const UserRegistrationSchema = z.object({
  username: z.string().min(3).max(20),
  email: z.string().email(),
  password: z.string().min(8),
});

// Infer the TypeScript type from the Zod schema for type safety.
// This is a compile-time check, but Zod provides runtime enforcement.
type UserRegistrationData = z.infer<typeof UserRegistrationSchema>;

/**
 * POST /api/register
 * Handles user registration with runtime validation.
 * 
 * @param req - The Next.js API request object.
 * @param res - The Next.js API response object.
 * @returns A JSON response indicating success or error.
 */
export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse
) {
  // Only allow POST requests; reject others with a 405 status.
  if (req.method !== 'POST') {
    res.status(405).json({ error: 'Method Not Allowed' });
    return;
  }

  try {
    // Step 1: Parse and validate the request body using the Zod schema.
    // This is where Runtime Validation occurs. Zod will throw an error if the data is invalid.
    // We use .parse() which throws on failure. For safer parsing, .safeParse() could be used.
    const validatedData: UserRegistrationData = UserRegistrationSchema.parse(req.body);

    // Step 2: Process the validated data (immutable principle).
    // Instead of mutating the request body, we create a new user object.
    // In a real app, this would involve database operations (e.g., hashing password, saving to DB).
    const newUser = {
      id: Math.random().toString(36).substring(7), // Simulate a generated ID.
      username: validatedData.username,
      email: validatedData.email,
      createdAt: new Date().toISOString(), // Immutable timestamp.
    };

    // Step 3: Send a success response.
    // We only respond with the sanitized user object (no password).
    res.status(201).json({ success: true, user: newUser });
  } catch (error) {
    // Step 4: Handle validation errors.
    // Zod errors are caught here. We log for debugging (in a real app) and return a user-friendly error.
    if (error instanceof z.ZodError) {
      // Extract validation issues for detailed feedback.
      const validationIssues = error.issues.map((issue) => ({
        field: issue.path.join('.'),
        message: issue.message,
      }));
      res.status(400).json({ error: 'Invalid input data', issues: validationIssues });
    } else {
      // Handle unexpected errors (e.g., database failures).
      console.error('Unexpected error:', error);
      res.status(500).json({ error: 'Internal Server Error' });
    }
  }
}
