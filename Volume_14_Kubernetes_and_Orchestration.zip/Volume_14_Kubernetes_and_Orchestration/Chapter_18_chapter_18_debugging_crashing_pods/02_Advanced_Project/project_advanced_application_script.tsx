/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.tsx
// Description: Advanced Application Script
// ==========================================

/**
 * @fileoverview Pod Watcher Dashboard - Advanced Debugging Script
 * 
 * Context: Book 14, Chapter 18, Subsection 3/5
 * Topic: Debugging Crashing Pods in Kubernetes (Node.js & AI Workloads)
 * 
 * This script demonstrates:
 * 1. Immutable State Management for tracking pod lifecycle events.
 * 2. A "Supervisor Node" pattern (DiagnosticEngine) to route debugging tasks.
 * 3. Tool Calling simulation to fetch logs, describe resources, and analyze limits.
 */

import React, { useState, useEffect, useReducer } from 'react';

// ==========================================
// 1. TYPES & INTERFACES (The Graph State)
// ==========================================

/**
 * Represents the status of a container within a pod.
 * @readonly
 */
type ContainerState = 'Pending' | 'Running' | 'Terminated' | 'Unknown';

/**
 * Represents a Kubernetes Event (simplified).
 */
interface K8sEvent {
  type: 'Normal' | 'Warning' | 'Error';
  reason: string;
  message: string;
  timestamp: string;
}

/**
 * Represents a Pod's immutable state snapshot.
 */
interface PodState {
  name: string;
  namespace: string;
  status: ContainerState;
  restartCount: number;
  exitCode?: number;
  reason?: string; // e.g., OOMKilled, Error
  logs: string[];
  events: K8sEvent[];
  resourceUsage: {
    cpu: string;
    memory: string;
    gpu?: string; // For AI workloads
  };
  limits: {
    cpu: string;
    memory: string;
  };
}

/**
 * Action types for the Reducer (Immutable State Management).
 */
type PodAction =
  | { type: 'FETCH_START' }
  | { type: 'UPDATE_POD'; payload: Partial<PodState> }
  | { type: 'APPEND_LOG'; payload: string }
  | { type: 'APPEND_EVENT'; payload: K8sEvent }
  | { type: 'DIAGNOSIS_COMPLETE'; payload: string };

// ==========================================
// 2. MOCK INFRASTRUCTURE (Simulating kubectl)
// ==========================================

/**
 * Simulates a Kubernetes API Client.
 * In a real app, this would use the 'kubernetes-client' Node.js library.
 */
class MockK8sClient {
  async getPodStatus(podName: string): Promise<Partial<PodState>> {
    // Simulate network latency
    await new Promise(r => setTimeout(r, 800));
    
    // Simulate a crashing AI Node.js pod
    return {
      name: podName,
      namespace: 'ai-inference',
      status: 'Terminated',
      restartCount: 3,
      exitCode: 137, // 128 + 9 (SIGKILL) -> OOMKilled
      reason: 'OOMKilled',
      resourceUsage: { cpu: '500m', memory: '2Gi', gpu: 'NVIDIA T4' },
      limits: { cpu: '1', memory: '1Gi' } // Limit is lower than usage!
    };
  }

  async getLogs(podName: string): Promise<string[]> {
    await new Promise(r => setTimeout(r, 500));
    return [
      `[INFO] Starting Node.js AI Inference Server...`,
      `[INFO] Loading TensorFlow model...`,
      `[WARN] High memory allocation detected: 1.8GB`,
      `[ERROR] FATAL: Allocation failed - JavaScript heap out of memory`
    ];
  }

  async getEvents(podName: string): Promise<K8sEvent[]> {
    await new Promise(r => setTimeout(r, 400));
    return [
      { type: 'Warning', reason: 'BackOff', message: 'Back-off restarting failed container', timestamp: '10:00:01' },
      { type: 'Normal', reason: 'Pulling', message: 'Pulling image "node-ai:latest"', timestamp: '09:59:50' }
    ];
  }
}

// ==========================================
// 3. DIAGNOSTIC ENGINE (Supervisor Node)
// ==========================================

/**
 * The "Supervisor Node" responsible for analyzing the Graph State
 * and invoking specific "Worker Agents" (diagnostic functions).
 */
class DiagnosticEngine {
  private client = new MockK8sClient();

  /**
   * Analyzes the current state and determines the next debugging step.
   * This mimics "Tool Calling" logic where the model decides which function to execute.
   */
  async analyze(podName: string, currentState: PodState): Promise<{ diagnosis: string; action: string }> {
    console.log(`[Supervisor] Analyzing state for ${podName}...`);

    // Worker Agent 1: Resource Limit Analysis
    if (currentState.reason === 'OOMKilled' || parseInt(currentState.resourceUsage.memory) > parseInt(currentState.limits.memory)) {
      return {
        diagnosis: "Memory Limit Exceeded",
        action: "Recommend increasing memory limit or optimizing Node.js heap size."
      };
    }

    // Worker Agent 2: CrashLoop Analysis
    if (currentState.restartCount > 2 && currentState.status === 'Terminated') {
      return {
        diagnosis: "CrashLoopBackOff Pattern Detected",
        action: "Check previous termination messages and liveness probes."
      };
    }

    // Worker Agent 3: GPU Dependency Check (AI Workload specific)
    if (currentState.resourceUsage.gpu && currentState.reason === 'Error') {
      return {
        diagnosis: "GPU Driver/Dependency Mismatch",
        action: "Verify CUDA versions and Node.js binding libraries."
      };
    }

    return { diagnosis: "Investigating...", action: "Gathering more data..." };
  }

  /**
   * Orchestrates the data fetching and analysis flow.
   */
  async diagnosePod(podName: string, dispatch: React.Dispatch<PodAction>) {
    dispatch({ type: 'FETCH_START' });

    // 1. Fetch Immutable State Snapshot
    const status = await this.client.getPodStatus(podName);
    dispatch({ type: 'UPDATE_POD', payload: status });

    // 2. Fetch Logs (Worker Agent)
    const logs = await this.client.getLogs(podName);
    logs.forEach(log => dispatch({ type: 'APPEND_LOG', payload: log }));

    // 3. Fetch Events (Worker Agent)
    const events = await this.client.getEvents(podName);
    events.forEach(event => dispatch({ type: 'APPEND_EVENT', payload: event }));

    // 4. Run Analysis (Supervisor Decision)
    // Construct a temporary full state for analysis
    const fullState: PodState = {
      name: podName,
      namespace: 'ai-inference',
      status: status.status || 'Unknown',
      restartCount: status.restartCount || 0,
      exitCode: status.exitCode,
      reason: status.reason,
      logs: logs,
      events: events,
      resourceUsage: status.resourceUsage || { cpu: '0', memory: '0' },
      limits: status.limits || { cpu: '0', memory: '0' }
    };

    const result = await this.analyze(podName, fullState);
    
    // 5. Update with Diagnosis
    dispatch({ 
      type: 'DIAGNOSIS_COMPLETE', 
      payload: `DIAGNOSIS: ${result.diagnosis}\nACTION: ${result.action}` 
    });
  }
}

// ==========================================
// 4. REDUCER (Immutable State Management)
// ==========================================

/**
 * Handles state updates immutably.
 * Crucial for debugging: ensures previous states are preserved in memory
 * for time-travel debugging or audit trails.
 */
function podReducer(state: PodState, action: PodAction): PodState {
  switch (action.type) {
    case 'FETCH_START':
      return { ...state, status: 'Pending' };
    
    case 'UPDATE_POD':
      // Deep merge to maintain immutability
      return { ...state, ...action.payload };
    
    case 'APPEND_LOG':
      // Create new array instance
      return { ...state, logs: [...state.logs, action.payload] };
    
    case 'APPEND_EVENT':
      return { ...state, events: [...state.events, action.payload] };
    
    case 'DIAGNOSIS_COMPLETE':
      return { ...state, logs: [...state.logs, `>>> SYSTEM: ${action.payload}`] };
    
    default:
      return state;
  }
}

// ==========================================
// 5. REACT COMPONENT (UI Layer)
// ==========================================

export default function PodDebuggerDashboard() {
  const initialState: PodState = {
    name: 'inference-pod-7f8d9',
    namespace: 'ai-inference',
    status: 'Unknown',
    restartCount: 0,
    logs: [],
    events: [],
    resourceUsage: { cpu: '0', memory: '0' },
    limits: { cpu: '0', memory: '0' }
  };

  const [state, dispatch] = useReducer(podReducer, initialState);
  const [engine] = useState(() => new DiagnosticEngine());
  const [isDiagnosing, setIsDiagnosing] = useState(false);

  const handleRunDebug = async () => {
    setIsDiagnosing(true);
    await engine.diagnosePod('inference-pod-7f8d9', dispatch);
    setIsDiagnosing(false);
  };

  return (
    <div style={{ fontFamily: 'monospace', padding: '20px', background: '#1e1e1e', color: '#d4d4d4', borderRadius: '8px' }}>
      <h2>Kubernetes Pod Watcher</h2>
      
      <div style={{ marginBottom: '20px', border: '1px solid #444', padding: '10px' }}>
        <h3>Pod Status: {state.status}</h3>
        <p>Restarts: {state.restartCount}</p>
        <p>Resources: CPU {state.resourceUsage.cpu} / MEM {state.resourceUsage.memory} (Limit: {state.limits.memory})</p>
        {state.reason && <p style={{ color: '#ff6b6b' }}>Reason: {state.reason}</p>}
      </div>

      <button 
        onClick={handleRunDebug} 
        disabled={isDiagnosing}
        style={{ padding: '10px 20px', background: '#007acc', color: 'white', border: 'none', cursor: 'pointer' }}
      >
        {isDiagnosing ? 'Analyzing...' : 'Run Diagnostic Tool'}
      </button>

      <div style={{ marginTop: '20px', display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '20px' }}>
        
        {/* Logs View */}
        <div style={{ background: '#252526', padding: '10px', minHeight: '200px' }}>
          <h4>Container Logs (Stream)</h4>
          {state.logs.map((log, i) => (
            <div key={i} style={{ color: log.includes('ERROR') ? '#f48771' : '#dcdcaa' }}>
              {log}
            </div>
          ))}
        </div>

        {/* Events View */}
        <div style={{ background: '#252526', padding: '10px', minHeight: '200px' }}>
          <h4>Kubernetes Events</h4>
          {state.events.map((ev, i) => (
            <div key={i} style={{ color: ev.type === 'Warning' ? '#cca700' : '#4ec9b0' }}>
              [{ev.type}] {ev.reason}: {ev.message}
            </div>
          ))}
        </div>
      </div>

      <div style={{ marginTop: '20px', background: '#007acc22', padding: '15px', borderLeft: '4px solid #007acc' }}>
        <h4>Diagnostic Output</h4>
        <pre style={{ whiteSpace: 'pre-wrap' }}>
          {state.logs.find(l => l.includes('>>> SYSTEM')) || 'Run diagnostic to see analysis.'}
        </pre>
      </div>
    </div>
  );
}
