/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// 1. Faulty Node.js Application (app.js)
// This server has a deliberate memory leak by pushing data to a global array.
const express = require('express');
const app = express();

// Global array that grows indefinitely
const leakyData = [];

app.get('/', (req, res) => {
  res.send('OK');
});

// Leaky endpoint: Appends 10MB of data to the array on every request
app.get('/leak', (req, res) => {
  // Create a 10MB string
  const chunk = 'X'.repeat(10 * 1024 * 1024); 
  leakyData.push(chunk);
  res.send(`Memory leaked. Array size: ${leakyData.length}`);
});

const PORT = 3000;
app.listen(PORT, () => {
  console.log(`Leaky server running on port ${PORT}`);
});
