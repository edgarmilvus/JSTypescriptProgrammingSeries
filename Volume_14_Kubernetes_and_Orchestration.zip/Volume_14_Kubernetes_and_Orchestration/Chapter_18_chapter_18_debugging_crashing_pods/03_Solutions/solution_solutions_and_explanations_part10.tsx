/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part10.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState, useEffect, useCallback } from 'react';

// 1. Interface Definition
interface Pod {
  metadata: {
    name: string;
    creationTimestamp: string;
  };
  status: {
    phase: string;
    containerStatuses?: Array<{
      name: string;
      ready: boolean;
      restartCount: number;
      lastState?: {
        terminated?: {
          reason?: string;
          exitCode?: number;
        };
      };
      state?: {
        waiting?: {
          reason?: string;
        };
      };
    }>;
  };
}

interface PodStatusDashboardProps {
  namespace: string;
}

const PodStatusDashboard: React.FC<PodStatusDashboardProps> = ({ namespace }) => {
  const [pods, setPods] = useState<Pod[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const [selectedPodLogs, setSelectedPodLogs] = useState<string | null>(null);

  // 2. Data Fetching with Polling
  useEffect(() => {
    const fetchPods = async () => {
      try {
        // Simulating API call. In real app: fetch(`/api/v1/namespaces/${namespace}/pods`)
        const response = await fetch(`/api/v1/namespaces/${namespace}/pods`);
        if (!response.ok) throw new Error('Failed to fetch');
        const data = await response.json();
        
        // IMMUTABLE STATE UPDATE
        // We create a new array. We do not mutate 'pods' directly.
        setPods(data.items || []);
        setError(null);
      } catch (err) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };

    fetchPods();
    const interval = setInterval(fetchPods, 5000); // Poll every 5s

    return () => clearInterval(interval); // Cleanup on unmount
  }, [namespace]);

  // 3. Log Viewer Simulation
  const fetchLogs = useCallback(async (podName: string) => {
    // Simulate kubectl logs command
    setSelectedPodLogs(`Fetching logs for ${podName}...\n[Simulated Log Output]\nLast State: Terminated\nReason: OOMKilled\nExit Code: 137`);
  }, []);

  // 4. Helper for Status Color
  const getStatusColor = (pod: Pod): string => {
    const phase = pod.status.phase;
    const containerStatus = pod.status.containerStatuses?.[0];
    
    if (containerStatus?.state?.waiting?.reason === 'CrashLoopBackOff') return 'red';
    if (containerStatus?.lastState?.terminated?.reason === 'OOMKilled') return 'red';
    if (phase === 'Running') return 'green';
    if (phase === 'Pending') return 'yellow';
    return 'gray';
  };

  if (loading) return <div>Loading Dashboard...</div>;
  if (error) return <div style={{ color: 'red' }}>Error: {error}</div>;

  return (
    <div style={{ fontFamily: 'sans-serif', padding: '20px' }}>
      <h2>Pod Status Dashboard ({namespace})</h2>
      <table border={1} cellPadding={10} style={{ width: '100%', borderCollapse: 'collapse' }}>
        <thead>
          <tr>
            <th>Pod Name</th>
            <th>Status</th>
            <th>Restarts</th>
            <th>Age</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {pods.map((pod) => {
            const statusColor = getStatusColor(pod);
            const container = pod.status.containerStatuses?.[0];
            const reason = container?.lastState?.terminated?.reason || container?.state?.waiting?.reason;

            return (
              <tr key={pod.metadata.name}>
                <td>{pod.metadata.name}</td>
                <td style={{ color: statusColor, fontWeight: 'bold' }}>
                  {pod.status.phase} {reason && `(${reason})`}
                </td>
                <td>{container?.restartCount || 0}</td>
                <td>{new Date(pod.metadata.creationTimestamp).toLocaleTimeString()}</td>
                <td>
                  <button onClick={() => fetchLogs(pod.metadata.name)}>View Logs</button>
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>

      {/* Log Viewer Modal/Section */}
      {selectedPodLogs && (
        <div style={{ marginTop: '20px', padding: '10px', backgroundColor: '#f4f4f4', border: '1px solid #ccc' }}>
          <h3>Logs</h3>
          <pre>{selectedPodLogs}</pre>
          <button onClick={() => setSelectedPodLogs(null)}>Close</button>
        </div>
      )}
    </div>
  );
};

export default PodStatusDashboard;
