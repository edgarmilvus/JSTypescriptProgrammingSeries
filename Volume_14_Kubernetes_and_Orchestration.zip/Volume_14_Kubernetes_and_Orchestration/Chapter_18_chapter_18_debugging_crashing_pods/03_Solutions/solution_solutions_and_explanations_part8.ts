/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part8.ts
// Description: Solutions and Explanations
// ==========================================

// 1. Load Test Script (load-test.ts)
// Run this with ts-node or compile to JS. Uses standard fetch or axios.
import axios from 'axios';

const TARGET_URL = 'http://localhost:3000/calc'; // Assuming port-forward to service
const CONCURRENT_REQUESTS = 50;
const TOTAL_REQUESTS = 1000;

async function sendRequest(id: number) {
    try {
        const start = Date.now();
        await axios.get(TARGET_URL);
        const duration = Date.now() - start;
        console.log(`Request ${id} completed in ${duration}ms`);
    } catch (error) {
        console.error(`Request ${id} failed:`, error.message);
    }
}

async function runLoadTest() {
    console.log(`Starting load test with ${CONCURRENT_REQUESTS} concurrent users...`);
    const promises = [];
    
    for (let i = 0; i < TOTAL_REQUESTS; i += CONCURRENT_REQUESTS) {
        const batch = [];
        for (let j = 0; j < CONCURRENT_REQUESTS; j++) {
            batch.push(sendRequest(i + j));
        }
        await Promise.all(batch);
        // Small delay to prevent overwhelming the local client
        await new Promise(r => setTimeout(r, 100)); 
    }
}

runLoadTest();
