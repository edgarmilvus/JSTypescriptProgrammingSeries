/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * Represents a Kubernetes Deployment configuration for a SaaS "Job Manager" service.
 * This simulates the logic used to orchestrate a zero-downtime update.
 */
class DeploymentConfig {
  name: string;
  currentReplicas: number;
  desiredReplicas: number;
  
  // Strategy Parameters
  strategy: {
    type: 'RollingUpdate';
    rollingUpdate: {
      maxSurge: number | string;      // How many extra pods can be created over desired count
      maxUnavailable: number | string; // How many pods can be missing during update
    };
  };

  // Probes to ensure traffic only hits healthy pods
  readinessProbe: {
    httpGet: { path: string; port: number };
    initialDelaySeconds: number;
    periodSeconds: number;
  };

  constructor(currentReplicas: number) {
    this.name = "job-manager-service";
    this.currentReplicas = currentReplicas;
    this.desiredReplicas = currentReplicas; // Initially same
    
    /**
     * STRATEGY CONFIGURATION:
     * 1. maxSurge: "25%" -> Allows the cluster to spin up 1 extra pod (if replicas=4, 5 total allowed).
     * 2. maxUnavailable: "0%" -> Ensures we NEVER drop below the desired count of healthy pods.
     */
    this.strategy = {
      type: 'RollingUpdate',
      rollingUpdate: {
        maxSurge: '25%',
        maxUnavailable: '0%' 
      }
    };

    // PROBE CONFIGURATION
    this.readinessProbe = {
      httpGet: { path: '/healthz', port: 8080 },
      initialDelaySeconds: 5, // Wait 5s before first check
      periodSeconds: 5        // Check every 5s
    };
  }

  /**
   * Simulates the logic of the Kubernetes Controller Plane during an update.
   * @param newVersionImage - The container image tag for the new version (e.g., 'v2.0')
   */
  async executeRollingUpdate(newVersionImage: string): Promise<void> {
    console.log(`\n🚀 Starting Update for ${this.name} to image: ${newVersionImage}`);
    console.log(`Current State: ${this.currentReplicas} replicas running v1.0`);

    // 1. Calculate Capacity
    // Max Surge allows us to exceed desired count.
    const maxTotalPods = this.calculateMaxTotalPods();
    console.log(`Constraint: Max Total Pods allowed: ${maxTotalPods}`);

    // 2. Create New Pods (The "Surge")
    // Because maxUnavailable is 0, we must create new capacity first.
    console.log(`Phase 1: Spinning up new pods...`);
    const newPods = await this.createPods(1, newVersionImage); // Create 1 extra pod
    
    // 3. Validate New Pods (Readiness Probe Check)
    // We simulate the waiting period for the new pod to become 'Ready'.
    console.log(`Phase 2: Waiting for new pod to pass Readiness Probe...`);
    const isReady = await this.simulateReadinessCheck(newPods[0]);
    
    if (!isReady) {
      throw new Error("New pod failed to become ready. Aborting update.");
    }

    // 4. Terminate Old Pods
    // Only now that we have 5 healthy pods (4 old + 1 new) do we remove 1 old one.
    // This repeats until all are replaced.
    console.log(`Phase 3: Terminating 1 old pod (v1.0)...`);
    await this.terminatePods(1, 'v1.0');
    this.currentReplicas--; // Decrement old count

    // 5. Repeat until fully rolled out
    // In a real cluster, this loop continues until all replicas are v2.0.
    console.log(`✅ Update Complete. All pods now running ${newVersionImage}.`);
  }

  // --- Helper Simulation Methods ---

  private calculateMaxTotalPods(): number {
    // Logic: Desired + (Desired * MaxSurgePercentage)
    const surge = typeof this.strategy.rollingUpdate.maxSurge === 'string' 
      ? this.currentReplicas * (parseInt(this.strategy.rollingUpdate.maxSurge) / 100)
      : this.strategy.rollingUpdate.maxSurge;
    
    return this.currentReplicas + surge;
  }

  private async createPods(count: number, image: string): Promise<string[]> {
    const pods: string[] = [];
    for (let i = 0; i < count; i++) {
      const podId = `pod-${image}-${Date.now()}-${i}`;
      // Simulate API call to K8s API Server
      await new Promise(r => setTimeout(r, 100)); 
      console.log(`  -> Created: ${podId}`);
      pods.push(podId);
    }
    return pods;
  }

  private async simulateReadinessCheck(podId: string): Promise<boolean> {
    // Simulate the initialDelaySeconds + application startup time
    console.log(`  -> Checking /healthz for ${podId}...`);
    await new Promise(r => setTimeout(r, 300)); // Simulate latency
    console.log(`  -> ${podId} is Healthy (200 OK)`);
    return true;
  }

  private async terminatePods(count: number, version: string): Promise<void> {
    // Simulate graceful termination (SIGTERM)
    await new Promise(r => setTimeout(r, 100));
    console.log(`  -> Terminated ${count} pod(s) running v${version}`);
  }
}

// --- Execution Entry Point ---

async function main() {
  try {
    // Initialize with 4 replicas
    const deployment = new DeploymentConfig(4);
    
    // Trigger the update to v2.0
    await deployment.executeRollingUpdate('job-manager:v2.0');
  } catch (error) {
    console.error("Deployment Failed:", error);
  }
}

main();
