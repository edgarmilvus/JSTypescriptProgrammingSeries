/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.tsx
// Description: Advanced Application Script
// ==========================================

// components/SmartChatInterface.tsx
import React, { useState, useRef, useEffect, useTransition } from 'react';

/**
 * @typedef {Object} ChatMessage
 * @property {'user' | 'ai'} role - The sender of the message.
 * @property {string} content - The text content.
 * @property {string} [vectorId] - Unique ID for the AI response chunk (Vector ID).
 */

type ChatMessage = {
  role: 'user' | 'ai';
  content: string;
  vectorId?: string; // Used for tracking/deleting specific chunks in a backend vector store
};

/**
 * SmartChatInterface Component
 * 
 * Simulates a production-grade chat interface resilient to backend updates.
 * It uses SSE for streaming and useTransition for non-blocking UI updates.
 */
export default function SmartChatInterface() {
  // State to hold the conversation history
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  
  // State for the current user input
  const [inputValue, setInputValue] = useState('');
  
  // State to track connection health (simulating Kubernetes Readiness Probe)
  const [connectionStatus, setConnectionStatus] = useState<'connected' | 'reconnecting' | 'error'>('connected');

  // useTransition allows us to mark the state update as "low priority", keeping the UI responsive
  // even if the stream processing gets heavy.
  const [isPending, startTransition] = useTransition();

  // Ref to hold the AbortController for cancelling requests (simulating pod termination)
  const abortControllerRef = useRef<AbortController | null>(null);

  /**
   * Handles the stream processing from Server-Sent Events.
   * 
   * @param {ReadableStream<Uint8Array>} stream - The response body stream from the backend.
   * @param {string} vectorId - The unique ID for this specific AI chunk.
   */
  const processStream = async (stream: ReadableStream<Uint8Array>, vectorId: string) => {
    const reader = stream.getReader();
    const decoder = new TextDecoder();
    
    // Temporary buffer to accumulate the stream chunks for this specific response
    let accumulatedContent = '';

    try {
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        const chunk = decoder.decode(value, { stream: true });
        accumulatedContent += chunk;

        // Update the specific AI message in the state with the new chunk
        // This mimics a "Rolling Update" of the message content itself.
        startTransition(() => {
          setMessages((prev) => {
            const newMessages = [...prev];
            const lastMsg = newMessages[newMessages.length - 1];
            if (lastMsg && lastMsg.role === 'ai' && lastMsg.vectorId === vectorId) {
              lastMsg.content = accumulatedContent;
            } else {
              // If it's a new chunk, append it
              newMessages.push({ role: 'ai', content: accumulatedContent, vectorId });
            }
            return newMessages;
          });
        });
      }
    } catch (error) {
      console.error("Stream error:", error);
      setConnectionStatus('error');
    } finally {
      reader.releaseLock();
    }
  };

  /**
   * Sends the user message to the backend and initiates the SSE stream.
   * Handles "Zero-Downtime" logic: if a connection drops, it retries.
   */
  const sendMessage = async () => {
    if (!inputValue.trim()) return;

    const userMessage = inputValue;
    setInputValue(''); // Clear input immediately for UX

    // Add user message to state
    setMessages((prev) => [...prev, { role: 'user', content: userMessage }]);

    // Prepare a unique Vector ID for this AI response chunk
    const vectorId = `vec_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;

    // Add a placeholder for the AI response
    setMessages((prev) => [...prev, { role: 'ai', content: '', vectorId }]);

    // Abort any existing request to prevent race conditions
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
    }

    const controller = new AbortController();
    abortControllerRef.current = controller;

    // SIMULATION: We are simulating the backend endpoint.
    // In a real K8s setup, this hits a Service which routes to a Pod.
    // We will simulate a network failure to demonstrate resilience.
    try {
      setConnectionStatus('connected');
      
      // --- SIMULATION BLOCK START ---
      // In a real app, this would be: const response = await fetch('/api/chat/stream', { ... });
      
      // Simulate a backend failure (e.g., Pod restarting during Rolling Update)
      // We randomly fail 20% of the time to demonstrate the retry logic.
      if (Math.random() < 0.2) {
        throw new Error("SIMULATED_POD_RESTART"); 
      }

      // Simulate a successful stream response
      const mockStream = new ReadableStream({
        start(controller) {
          const encoder = new TextEncoder();
          const fullText = `Processed: "${userMessage}" via resilient cluster.`;
          let index = 0;
          
          // Simulate network latency and streaming tokens
          const interval = setInterval(() => {
            if (index < fullText.length) {
              controller.enqueue(encoder.encode(fullText[index]));
              index++;
            } else {
              clearInterval(interval);
              controller.close();
            }
          }, 50);
        }
      });
      // --- SIMULATION BLOCK END ---

      await processStream(mockStream, vectorId);
      setConnectionStatus('connected');

    } catch (error: any) {
      if (error.name === 'AbortError') {
        console.log("Request aborted by user or system update.");
        return;
      }

      // --- RESILIENCE LOGIC (Kubernetes Rolling Update Strategy) ---
      // If the backend is unavailable (pod down), we catch it here.
      // Instead of crashing, we update UI to show "Reconnecting" or "Rollback".
      setConnectionStatus('reconnecting');
      
      // In a real scenario, we might retry the request exponentially.
      // For this demo, we will update the message to indicate the failure
      // and allow the user to retry, mimicking a "Rollback" to the previous stable state.
      setMessages((prev) => {
        const newMessages = [...prev];
        // Find the placeholder AI message and update it to show error
        const lastMsg = newMessages[newMessages.length - 1];
        if (lastMsg && lastMsg.role === 'ai') {
          lastMsg.content = "⚠️ Connection lost. Backend updating. Click retry to restore.";
          lastMsg.vectorId = undefined; // Remove vectorId so it's not treated as a valid chunk
        }
        return newMessages;
      });
    }
  };

  /**
   * Retry mechanism to handle the "Reconnecting" state.
   * Simulates a manual rollback or reconnection attempt.
   */
  const retryConnection = () => {
    setConnectionStatus('connected');
    // In a real app, this would re-trigger the last API call.
    // For demo, we just clear the error message.
    setMessages((prev) => prev.slice(0, -1)); 
  };

  return (
    <div style={styles.container}>
      <div style={styles.statusBar}>
        <span>Status: <strong style={{ color: connectionStatus === 'connected' ? 'green' : 'orange' }}>{connectionStatus.toUpperCase()}</strong></span>
        {connectionStatus === 'reconnecting' && (
          <button onClick={retryConnection} style={styles.retryBtn}>Retry / Rollback</button>
        )}
      </div>

      <div style={styles.chatWindow}>
        {messages.map((msg, idx) => (
          <div key={idx} style={msg.role === 'user' ? styles.userMsg : styles.aiMsg}>
            <div style={styles.msgLabel}>{msg.role === 'user' ? 'You' : 'AI (Cluster)'}</div>
            <div style={styles.msgContent}>{msg.content || '...'}</div>
          </div>
        ))}
      </div>

      <div style={styles.inputArea}>
        <input
          type="text"
          value={inputValue}
          onChange={(e) => setInputValue(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && sendMessage()}
          placeholder="Ask something..."
          style={styles.input}
          disabled={isPending}
        />
        <button onClick={sendMessage} style={styles.sendBtn} disabled={isPending}>
          {isPending ? 'Streaming...' : 'Send'}
        </button>
      </div>
    </div>
  );
}

// --- Inline Styles for Demonstration ---
const styles: { [key: string]: React.CSSProperties } = {
  container: {
    fontFamily: 'monospace',
    border: '1px solid #ccc',
    borderRadius: '8px',
    maxWidth: '600px',
    margin: '20px auto',
    overflow: 'hidden',
    backgroundColor: '#f9f9f9',
  },
  statusBar: {
    padding: '10px',
    backgroundColor: '#eee',
    borderBottom: '1px solid #ddd',
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  retryBtn: {
    padding: '4px 8px',
    backgroundColor: '#ff9800',
    color: 'white',
    border: 'none',
    borderRadius: '4px',
    cursor: 'pointer',
  },
  chatWindow: {
    height: '300px',
    overflowY: 'auto',
    padding: '10px',
    display: 'flex',
    flexDirection: 'column',
    gap: '10px',
    backgroundColor: '#fff',
  },
  userMsg: {
    alignSelf: 'flex-end',
    backgroundColor: '#dcf8c6',
    padding: '8px 12px',
    borderRadius: '8px',
    maxWidth: '80%',
  },
  aiMsg: {
    alignSelf: 'flex-start',
    backgroundColor: '#e3f2fd',
    padding: '8px 12px',
    borderRadius: '8px',
    maxWidth: '80%',
  },
  msgLabel: {
    fontSize: '10px',
    color: '#666',
    marginBottom: '4px',
  },
  msgContent: {
    whiteSpace: 'pre-wrap',
  },
  inputArea: {
    display: 'flex',
    padding: '10px',
    gap: '8px',
    borderTop: '1px solid #ddd',
    backgroundColor: '#fff',
  },
  input: {
    flex: 1,
    padding: '8px',
    border: '1px solid #ccc',
    borderRadius: '4px',
  },
  sendBtn: {
    padding: '8px 16px',
    backgroundColor: '#007bff',
    color: 'white',
    border: 'none',
    borderRadius: '4px',
    cursor: 'pointer',
  },
};
