/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

digraph RollingUpdate {
    rankdir=TB;
    node [shape=rectangle, style=filled, fillcolor=lightblue];
    edge [fontsize=10];

    Start [label="Initial State\n(3 Old Pods Running)", shape=ellipse, fillcolor=lightgrey];
    CheckSurge [label="Check MaxSurge\n(Count < 3 + 1)?", shape=diamond, fillcolor=lightyellow];
    CreatePod [label="Create New Pod\n(Total: 4 Pods)", shape=rect];
    WaitReady [label="Wait for New Pod\nReadiness Probe", shape=rect];
    CheckOld [label="Check Old Pods\n(Count > 3)?", shape=diamond, fillcolor=lightyellow];
    TerminateOld [label="Terminate Oldest\nOld Pod", shape=rect];
    Complete [label="Rollout Complete\n(3 New Pods)", shape=ellipse, fillcolor=lightgreen];

    Start -> CheckSurge;
    CheckSurge -> CreatePod [label="Yes"];
    CheckSurge -> Complete [label="No (All Updated)"];
    CreatePod -> WaitReady;
    WaitReady -> CheckOld;
    CheckOld -> TerminateOld [label="Yes"];
    CheckOld -> CheckSurge [label="No"];
    TerminateOld -> CheckSurge;
}
