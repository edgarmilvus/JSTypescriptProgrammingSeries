/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part2.ts
// Description: Practical Exercises
// ==========================================

// DeploymentStatusStream.tsx
'use client';

import { useEffect, useState } from 'react';

interface DeploymentCondition {
  type: string;
  status: string;
  lastTransitionTime: string;
  reason: string;
  message: string;
}

interface DeploymentStatus {
  name: string;
  conditions: DeploymentCondition[];
}

interface DeploymentEvent {
  type: 'ADDED' | 'MODIFIED' | 'DELETED';
  object: DeploymentStatus;
  timestamp: string;
}

export default function DeploymentStatusStream({ initialEvents }: { initialEvents: DeploymentEvent[] }) {
  const [events, setEvents] = useState<DeploymentEvent[]>(initialEvents);

  useEffect(() => {
    const eventSource = new EventSource('/api/deployments/stream');

    const handleMessage = (event: MessageEvent) => {
      const data: DeploymentEvent = JSON.parse(event.data);
      setEvents((prev) => [data, ...prev]);
    };

    eventSource.addEventListener('message', handleMessage);

    return () => {
      eventSource.removeEventListener('message', handleMessage);
      eventSource.close();
    };
  }, []);

  return (
    <div style={{ maxHeight: '400px', overflowY: 'auto', border: '1px solid #ccc', padding: '10px' }}>
      <h3>Live Deployment Events</h3>
      <ul>
        {events.map((e, idx) => (
          <li key={idx} style={{ marginBottom: '8px', borderBottom: '1px solid #eee', paddingBottom: '4px' }}>
            <strong>{e.timestamp}</strong> - {e.object.name}: {e.object.conditions[0]?.type} ({e.object.conditions[0]?.status})
          </li>
        ))}
      </ul>
    </div>
  );
}
