/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part3.ts
// Description: Practical Exercises
// ==========================================

# 1. Check pod status
kubectl get pods -l app=stuck-api

# 2. Describe the stuck pod to find the specific error
kubectl describe pod stuck-api-7f8c9d-fghij

# 3. Check cluster events for broader context
kubectl get events --sort-by='.lastTimestamp'

# 4. Diagnosis: The 'FailedMount' error indicates a storage issue (e.g., PVC not found).

# 5. Abort the rollout (reverts to previous version)
kubectl rollout undo deployment/stuck-api

# 6. Pause, Fix, and Resume (Alternative strategy)
# Pause the deployment to stop the rollout loop
kubectl rollout pause deployment/stuck-api

# (Here, you would apply the fix, e.g., kubectl apply -f fixed-pvc.yaml)

# Resume the deployment after fixing the issue
kubectl rollout resume deployment/stuck-api
