/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * @fileoverview A "Hello World" example of vector indexing and semantic search
 * in a Node.js microservice context.
 * 
 * This example simulates:
 * 1. Generating embeddings (vector representations) for text.
 * 2. Storing embeddings in an in-memory vector index (simulating pgvector/HNSW).
 * 3. Querying the index for the most similar documents.
 * 
 * @module VectorSearchService
 */

// -----------------------------------------------------------------------------
// 1. TYPE DEFINITIONS
// -----------------------------------------------------------------------------

/**
 * Represents a document in our knowledge base.
 * In a real database, this would be a row in a `documents` table.
 */
type Document = {
    id: string;
    content: string;
    embedding: number[]; // The vector representation of the content
};

/**
 * Represents the query input for our search service.
 */
type QueryInput = {
    text: string;
};

// -----------------------------------------------------------------------------
// 2. MOCK EMBEDDING MODEL (Simulating ONNX Runtime Web / TensorFlow.js)
// -----------------------------------------------------------------------------

/**
 * Simulates an AI model that converts text into a high-dimensional vector.
 * 
 * In a real production environment:
 * - You would use `@xenova/transformers` (for ONNX Runtime Web) or a REST API 
 *   call to an embedding service (like OpenAI's text-embedding-ada-002).
 * - For this example, we generate a deterministic vector based on the character 
 *   codes of the string to ensure consistent results for demonstration.
 * 
 * @param text - The input string to embed.
 * @param dimension - The size of the output vector (e.g., 384 for all-MiniLM-L6-v2).
 * @returns A Promise resolving to a number array (the embedding vector).
 */
async function generateEmbedding(text: string, dimension: number = 384): Promise<number[]> {
    // Simulate async processing (e.g., model inference)
    await new Promise(resolve => setTimeout(resolve, 10)); 

    const vector: number[] = new Array(dimension).fill(0);
    
    // Simple hashing algorithm to create a deterministic vector
    // This allows us to simulate "semantic similarity" without a real model.
    for (let i = 0; i < text.length; i++) {
        const charCode = text.charCodeAt(i);
        const index = charCode % dimension;
        vector[index] += 1; 
    }

    // Normalize the vector (L2 Norm) - Crucial for Cosine Similarity
    const magnitude = Math.sqrt(vector.reduce((sum, val) => sum + val * val, 0));
    if (magnitude > 0) {
        for (let i = 0; i < dimension; i++) {
            vector[i] = vector[i] / magnitude;
        }
    }

    return vector;
}

// -----------------------------------------------------------------------------
// 3. VECTOR INDEX (Simulating HNSW in pgvector)
// -----------------------------------------------------------------------------

/**
 * A class simulating a Vector Database Index (like Pinecone or pgvector).
 * 
 * Under the Hood:
 * - Real systems use algorithms like HNSW (Hierarchical Navigable Small World).
 * - HNSW builds a multi-layered graph for O(log N) search complexity.
 * - Here, we use a brute-force Euclidean distance calculation for simplicity,
 *   but the logic is identical: store vectors and find the closest ones.
 */
class VectorIndex {
    private documents: Document[] = [];

    /**
     * Inserts a document and its embedding into the index.
     * In a real DB, this triggers the HNSW graph update.
     * @param doc - The document to index.
     */
    public async insert(doc: Document): Promise<void> {
        this.documents.push(doc);
        console.log(`[Index] Indexed document ${doc.id}`);
    }

    /**
     * Performs a vector similarity search.
     * 
     * @param queryVector - The vector representation of the user's query.
     * @param topK - Number of top results to return.
     * @returns A list of documents sorted by similarity (closest first).
     */
    public async search(queryVector: number[], topK: number = 2): Promise<Document[]> {
        // Calculate similarity (Cosine Similarity) between query and all documents
        const scoredDocs = this.documents.map(doc => {
            const similarity = cosineSimilarity(queryVector, doc.embedding);
            return { ...doc, similarity };
        });

        // Sort by similarity score descending
        scoredDocs.sort((a, b) => b.similarity - a.similarity);

        // Return top K results
        return scoredDocs.slice(0, topK);
    }
}

// -----------------------------------------------------------------------------
// 4. MATH UTILITIES
// -----------------------------------------------------------------------------

/**
 * Calculates the Cosine Similarity between two vectors.
 * Range: [-1, 1] (1 = identical, 0 = orthogonal, -1 = opposite).
 * 
 * Formula: dot(A, B) / (||A|| * ||B||)
 * Note: Since our vectors are normalized in the embedding step, 
 * we can simply calculate the dot product for efficiency.
 * 
 * @param vecA - First vector.
 * @param vecB - Second vector.
 * @returns The similarity score.
 */
function cosineSimilarity(vecA: number[], vecB: number[]): number {
    if (vecA.length !== vecB.length) {
        throw new Error("Vectors must have the same dimension");
    }

    let dotProduct = 0;
    for (let i = 0; i < vecA.length; i++) {
        dotProduct += vecA[i] * vecB[i];
    }
    
    return dotProduct;
}

// -----------------------------------------------------------------------------
// 5. MAIN SERVICE LOGIC (Simulating the Microservice)
// -----------------------------------------------------------------------------

/**
 * Orchestrates the indexing and search process.
 * In a real app, this would be split into API controllers (e.g., Express.js).
 */
async function runVectorSearchDemo() {
    console.log("🚀 Starting Vector Search Microservice Demo...\n");

    // Initialize the index (simulating a connected database)
    const index = new VectorIndex();

    // --- Step A: Ingest Data (The "ETL" Phase) ---
    const knowledgeBase = [
        { id: "doc_1", content: "Kubernetes manages containerized applications." },
        { id: "doc_2", content: "Docker is a platform for developing and shipping applications." },
        { id: "doc_3", content: "The sky is blue and the grass is green." },
        { id: "doc_4", content: "Artificial Intelligence is transforming software development." }
    ];

    console.log("1. Indexing Documents...");
    for (const item of knowledgeBase) {
        const embedding = await generateEmbedding(item.content);
        await index.insert({
            id: item.id,
            content: item.content,
            embedding: embedding
        });
    }

    // --- Step B: User Query (The "Inference" Phase) ---
    const userQuery: QueryInput = { text: "How does Docker relate to app deployment?" };
    
    console.log(`\n2. Processing Query: "${userQuery.text}"`);
    
    // 1. Convert query text to vector
    const queryVector = await generateEmbedding(userQuery.text);
    
    // 2. Search the index
    const results = await index.search(queryVector);

    // --- Step C: Output Results ---
    console.log("\n3. Search Results:");
    results.forEach((doc, idx) => {
        console.log(`   Rank ${idx + 1} (Score: ${doc.similarity.toFixed(4)}): ${doc.content}`);
    });
}

// -----------------------------------------------------------------------------
// 6. EXECUTION
// -----------------------------------------------------------------------------

// Run the demo
runVectorSearchDemo().catch(console.error);
