/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.tsx
// Description: Advanced Application Script
// ==========================================

'use client';

import React, { useState, useTransition } from 'react';

/**
 * @interface SummaryResult
 * @description Defines the structure of the AI inference response.
 */
interface SummaryResult {
  originalText: string;
  summary: string;
  confidence: number;
  processedAt: number;
}

/**
 * @function simulateLocalAIInference
 * @description Mocks a heavy local AI model (e.g., WASM-based Transformer).
 * Simulates Cold Start (initialization delay) and inference time.
 * @param text - The input text to summarize.
 * @returns Promise<SummaryResult>
 */
const simulateLocalAIInference = async (text: string): Promise<SummaryResult> => {
  // Simulate Cold Start (Model Loading/WASM Compilation)
  // In a real app, this happens only once, but we simulate it for effect.
  await new Promise(resolve => setTimeout(resolve, 1500));

  // Simulate Inference Processing
  await new Promise(resolve => setTimeout(resolve, 1000));

  // Mock AI Logic: Extract first sentence as a naive summary
  const sentences = text.split('.').filter(s => s.trim().length > 0);
  const summary = sentences.length > 0 ? sentences[0] + '.' : 'No content.';

  return {
    originalText: text,
    summary: summary,
    confidence: 0.92,
    processedAt: Date.now(),
  };
};

/**
 * @function SmartSummaryApp
 * @description The main component demonstrating Optimistic UI with useTransition.
 */
export default function SmartSummaryApp() {
  // State for the raw input text
  const [inputText, setInputText] = useState('');
  
  // State for the confirmed result (Post-Reconciliation)
  const [result, setResult] = useState<SummaryResult | null>(null);
  
  // State for the optimistic preview (Pre-Reconciliation)
  const [optimisticSummary, setOptimisticSummary] = useState<string | null>(null);

  // useTransition hook: Allows us to mark state updates as non-blocking.
  // 'isPending' tracks the async operation status.
  const [isPending, startTransition] = useTransition();

  /**
   * @function handleAnalyze
   * @description Triggered by form submission.
   * Wraps the heavy AI inference in a transition to keep the UI responsive.
   */
  const handleAnalyze = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim()) return;

    // 1. OPTIMISTIC UPDATE
    // Immediately set a temporary UI state (e.g., "Analyzing: [Preview]").
    // This happens synchronously, without waiting for the AI.
    // We create a "fake" summary based on simple string manipulation for immediate feedback.
    const preview = inputText.substring(0, 50) + '... (Processing locally)';
    setOptimisticSummary(preview);
    setResult(null); // Clear previous confirmed result

    // 2. ASYNC PROCESSING (NON-BLOCKING)
    // Start the transition. React schedules this update with lower priority.
    startTransition(async () => {
      try {
        // Call the heavy local AI function
        const aiResult = await simulateLocalAIInference(inputText);

        // 3. RECONCILIATION
        // Once the background work is done, we update the confirmed state.
        // React automatically replaces the optimistic UI with the real data.
        setResult(aiResult);
        setOptimisticSummary(null); // Clear optimistic state
      } catch (error) {
        console.error("AI Inference failed:", error);
        setOptimisticSummary(null);
      }
    });
  };

  // Determine what to display in the result area
  const displayContent = optimisticSummary || result?.summary;
  const isProcessing = isPending || !!optimisticSummary;

  return (
    <div style={styles.container}>
      <h1 style={styles.title}>Local AI Summarizer</h1>
      <p style={styles.subtitle}>
        Uses <code>useTransition</code> for Optimistic UI during local inference.
      </p>

      <form onSubmit={handleAnalyze} style={styles.form}>
        <textarea
          value={inputText}
          onChange={(e) => setInputText(e.target.value)}
          placeholder="Paste text to summarize..."
          rows={5}
          style={styles.textarea}
          disabled={isProcessing}
        />
        <button 
          type="submit" 
          style={{
            ...styles.button,
            opacity: isProcessing ? 0.6 : 1,
            cursor: isProcessing ? 'not-allowed' : 'pointer'
          }}
          disabled={isProcessing}
        >
          {isProcessing ? 'Analyzing (Local AI)...' : 'Summarize'}
        </button>
      </form>

      {/* Result Area with Reconciliation Logic */}
      {displayContent && (
        <div style={styles.resultBox}>
          <h3>Result:</h3>
          <p style={isProcessing ? styles.optimisticText : styles.confirmedText}>
            {displayContent}
          </p>
          
          {/* Metadata for Reconciliation Verification */}
          {result && (
            <div style={styles.meta}>
              <small>Confidence: {(result.confidence * 100).toFixed(0)}%</small>
              <small>Processed at: {new Date(result.processedAt).toLocaleTimeString()}</small>
            </div>
          )}
          
          {isProcessing && !result && (
            <div style={styles.spinner}>⏳</div>
          )}
        </div>
      )}
    </div>
  );
}

// Basic CSS-in-JS styles for demonstration clarity
const styles: Record<string, React.CSSProperties> = {
  container: {
    maxWidth: '600px',
    margin: '2rem auto',
    padding: '2rem',
    fontFamily: 'system-ui, sans-serif',
    border: '1px solid #eaeaea',
    borderRadius: '8px',
    backgroundColor: '#f9f9f9',
  },
  title: { marginBottom: '0.5rem' },
  subtitle: { color: '#666', marginBottom: '1.5rem' },
  form: { display: 'flex', flexDirection: 'column', gap: '1rem' },
  textarea: {
    padding: '1rem',
    borderRadius: '4px',
    border: '1px solid #ccc',
    resize: 'vertical',
    fontSize: '1rem',
  },
  button: {
    padding: '0.75rem 1.5rem',
    backgroundColor: '#0070f3',
    color: 'white',
    border: 'none',
    borderRadius: '4px',
    fontWeight: 'bold',
    transition: 'opacity 0.2s',
  },
  resultBox: {
    marginTop: '1.5rem',
    padding: '1rem',
    backgroundColor: 'white',
    borderRadius: '4px',
    border: '1px solid #eaeaea',
  },
  optimisticText: {
    color: '#888', // Gray out optimistic text to indicate pending state
    fontStyle: 'italic',
  },
  confirmedText: {
    color: '#000',
    fontWeight: 500,
  },
  meta: {
    display: 'flex',
    justifyContent: 'space-between',
    marginTop: '0.5rem',
    color: '#666',
    fontSize: '0.8rem',
  },
  spinner: {
    textAlign: 'center',
    marginTop: '0.5rem',
    fontSize: '1.2rem',
    animation: 'pulse 1.5s infinite',
  },
};
