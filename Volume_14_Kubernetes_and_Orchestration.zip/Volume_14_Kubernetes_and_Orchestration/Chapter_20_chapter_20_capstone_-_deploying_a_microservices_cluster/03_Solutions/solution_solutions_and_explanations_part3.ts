/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

digraph TrafficFlow {
    rankdir=LR;
    node [shape=box, style=filled, fillcolor="lightblue"];
    
    Client [label="External Client"];
    
    node [fillcolor="lightgreen"];
    Ingress [label="Ingress Controller\n(NGINX)"];
    
    node [fillcolor="lightyellow"];
    ServiceUser [label="Service: user-service\n(ClusterIP)"];
    ServiceAuth [label="Service: auth-service\n(ClusterIP)"];
    
    node [fillcolor="white"];
    PodUser1 [label="Pod: user-service"];
    PodUser2 [label="Pod: user-service"];
    PodAuth1 [label="Pod: auth-service"];
    
    // Connections
    Client -> Ingress [label="Request: api.cluster.local/users"];
    Ingress -> ServiceUser [label="/users -> Port 3000"];
    Ingress -> ServiceAuth [label="/auth -> Port 8080"];
    
    ServiceUser -> PodUser1 [label="Load Balance"];
    ServiceUser -> PodUser2;
    ServiceAuth -> PodAuth1;
}
