/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

// ChatInput.tsx
'use client';

import { useChat } from 'ai/react';
import { useState, useEffect } from 'react';

export default function ChatInput() {
  const { 
    messages, 
    input, 
    handleInputChange, 
    handleSubmit: originalHandleSubmit, 
    isLoading, 
    error 
  } = useChat();

  // State to hold the immediate user message before SDK confirms it
  const [optimisticMessages, setOptimisticMessages] = useState<Array<{id: string, content: string, role: 'user'}>>([]);

  // Effect to sync SDK messages and clear optimistic ones once processed
  useEffect(() => {
    if (!isLoading && messages.length > 0) {
      // Filter out optimistic messages that now exist in the main messages list
      // (Simple comparison by content or assuming the last user message is the one we added)
      // In a real app, you might match IDs if the SDK generates a temp ID.
      // Here we clear the optimistic stack because the SDK has caught up.
      setOptimisticMessages([]); 
    }
  }, [messages, isLoading]);

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    
    if (!input.trim()) return;

    // 1. Optimistic Update: Add user message immediately to local state
    const tempId = `temp-${Date.now()}`;
    setOptimisticMessages(prev => [...prev, { id: tempId, content: input, role: 'user' }]);

    // 2. Trigger the SDK's internal API call
    originalHandleSubmit(e);
  };

  // Combine SDK messages with optimistic messages for display
  // We place optimistic messages before the loading AI response
  const displayMessages = [...messages, ...optimisticMessages];

  return (
    <div>
      {/* Render chat history */}
      <div className="chat-history">
        {displayMessages.map(msg => (
          <div key={msg.id} className={`message ${msg.role}`}>
            {msg.content}
          </div>
        ))}
        {isLoading && <div className="loading">Thinking...</div>}
        {error && <div className="error">Error: {error.message}</div>}
      </div>

      <form onSubmit={handleSubmit}>
        <input 
          value={input} 
          onChange={handleInputChange} 
          disabled={isLoading} 
          placeholder="Type your message..."
        />
        <button type="submit" disabled={isLoading}>
          {isLoading ? 'Thinking...' : 'Send'}
        </button>
      </form>
    </div>
  );
}
