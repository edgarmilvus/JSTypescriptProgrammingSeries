/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.ts
// Description: Basic Code Example
// ==========================================

digraph ClientSideAI {
    rankdir=TB;
    node [shape=box, style=filled, fillcolor="#E3F2FD", fontname="Helvetica"];

    User [label="User Input\n(Query)", shape=ellipse, fillcolor="#FFF3E0"];
    
    subgraph cluster_browser {
        label = "Browser (Client)";
        style=dashed;
        
        EmbeddingModel [label="Local Model\n(WASM/ONNX)", fillcolor="#C8E6C9"];
        VectorDB [label="Local Vector DB\n(In-Memory)", fillcolor="#D1C4E9"];
        SearchLogic [label="Similarity Engine\n(Cosine Similarity)", fillcolor="#FFCCBC"];
        
        User -> EmbeddingModel;
        EmbeddingModel -> SearchLogic [label="Query Vector"];
        VectorDB -> SearchLogic [label="Document Vectors"];
        SearchLogic -> Result [label="Top K Matches"];
    }

    Result [label="Display Result\n(DOM Update)", shape=ellipse, fillcolor="#FFF3E0"];
    
    // No external network lines drawn to emphasize "Offline/Local"
}
