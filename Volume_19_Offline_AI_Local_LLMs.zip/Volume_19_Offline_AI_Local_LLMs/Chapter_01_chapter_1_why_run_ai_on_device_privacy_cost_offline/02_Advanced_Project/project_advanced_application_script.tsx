/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.tsx
// Description: Advanced Application Script
// ==========================================

/**
 * OFFLINE AI APPLICATION: LOCAL DOCUMENT SEMANTIC SEARCH
 * 
 * CONTEXT: This script demonstrates a production-ready Next.js/TypeScript implementation
 * of on-device AI processing. It solves the real-world problem of "Private Document Search"
 * where sensitive user documents (e.g., medical notes, legal contracts) are processed
 * locally without ever sending data to the cloud.
 * 
 * ARCHITECTURAL PILLARS (From Chapter 1):
 * 1. PRIVACY: Uses WebGPU/WebAssembly via Transformers.js. Data stays in browser RAM.
 * 2. COST: Zero API costs. Uses local hardware (CPU/GPU) after initial model download.
 * 3. OFFLINE: Service Worker caching ensures model weights and logic work without internet.
 * 
 * TECH STACK: Next.js (App Router), TypeScript, Transformers.js (Hugging Face), IDB (IndexedDB).
 */

'use client';

import React, { useState, useEffect, useRef } from 'react';
import { pipeline, FeatureExtractionPipeline, env } from '@xenova/transformers';

// ============================================================================
// 1. CONFIGURATION & CONSTANTS
// ============================================================================

// Disable remote model fetching to enforce local-only execution
// This ensures the app fails securely rather than leaking data to Hugging Face's API
env.allowRemoteModels = false; 

// Path to locally cached model weights (handled by Service Worker)
const MODEL_CACHE_PATH = '/models/sentence-transformers/all-MiniLM-L6-v2';

// ============================================================================
// 2. DATA LAYER: INDEXEDDB FOR OFFLINE STORAGE
// ============================================================================

/**
 * Interface for a searchable document
 */
interface IndexedDocument {
  id: string;
  title: string;
  content: string;
  embedding: number[]; // Vector representation of the content
  timestamp: number;
}

/**
 * Wrapper class for IndexedDB operations.
 * Why IndexedDB? LocalStorage is synchronous and limited to ~5MB.
 * IndexedDB is asynchronous, transactional, and handles large binary data (vectors) efficiently.
 */
class LocalVectorDB {
  private dbName = 'OfflineAI_DB';
  private storeName = 'documents';
  private dbVersion = 1;

  /**
   * Opens or creates the database connection.
   */
  private async openDB(): Promise<IDBDatabase> {
    return new Promise((resolve, reject) => {
      const request = indexedDB.open(this.dbName, this.dbVersion);
      
      request.onerror = () => reject(request.error);
      request.onsuccess = () => resolve(request.result);
      
      request.onupgradeneeded = (event) => {
        const db = (event.target as IDBOpenDBRequest).result;
        // Create an object store for documents
        if (!db.objectStoreNames.contains(this.storeName)) {
          const store = db.createObjectStore(this.storeName, { keyPath: 'id' });
          // Create an index for fast vector retrieval (though exact search is done in JS)
          store.createIndex('timestamp', 'timestamp', { unique: false });
        }
      };
    });
  }

  /**
   * Saves a document with its vector embedding to local storage.
   * This represents "Data Sovereignty" - the user owns the data locally.
   */
  async saveDocument(doc: Omit<IndexedDocument, 'timestamp'>): Promise<void> {
    const db = await this.openDB();
    const transaction = db.transaction([this.storeName], 'readwrite');
    const store = transaction.objectStore(this.storeName);
    
    const fullDoc: IndexedDocument = {
      ...doc,
      timestamp: Date.now()
    };
    
    store.put(fullDoc);
    
    return new Promise((resolve, reject) => {
      transaction.oncomplete = () => resolve();
      transaction.onerror = () => reject(transaction.error);
    });
  }

  /**
   * Retrieves all documents from local storage.
   */
  async getAllDocuments(): Promise<IndexedDocument[]> {
    const db = await this.openDB();
    const transaction = db.transaction([this.storeName], 'readonly');
    const store = transaction.objectStore(this.storeName);
    const request = store.getAll();

    return new Promise((resolve, reject) => {
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    });
  }
}

// ============================================================================
// 3. AI ENGINE: LOCAL INFERENCE & VECTOR SEARCH
// ============================================================================

/**
 * Service class handling local LLM/Transformer inference.
 * Uses Transformers.js to run PyTorch models in the browser via WebAssembly/WebGPU.
 */
class LocalAIEngine {
  private extractor: FeatureExtractionPipeline | null = null;
  private db: LocalVectorDB;

  constructor() {
    this.db = new LocalVectorDB();
  }

  /**
   * Initializes the AI model.
   * 
   * CRITICAL: This loads the model from the browser's cache (Service Worker).
   * If the model isn't cached and the user is offline, this will throw an error.
   * This enforces the "Offline Capability" pillar.
   */
  async initializeModel(): Promise<void> {
    try {
      console.log('Loading model from local cache...');
      // 'feature-extraction' pipeline generates vector embeddings
      this.extractor = await pipeline(
        'feature-extraction', 
        MODEL_CACHE_PATH, // Local path
        { quantized: true } // Use 8-bit quantization for smaller size & faster inference
      );
      console.log('Model loaded successfully.');
    } catch (error) {
      console.error('Failed to load local model:', error);
      throw new Error('Model not cached. Please connect to the internet once to download assets.');
    }
  }

  /**
   * Generates a vector embedding for a text string.
   * 
   * @param text - The input text to vectorize.
   * @returns A Float32Array representing the semantic meaning of the text.
   */
  async generateEmbedding(text: string): Promise<number[]> {
    if (!this.extractor) throw new Error('Model not initialized');

    // Run inference locally
    const output = await this.extractor(text, {
      pooling: 'mean',
      normalize: true
    });

    // Convert Tensor to standard JS array
    return Array.from(output.data);
  }

  /**
   * Performs Cosine Similarity search against local vectors.
   * 
   * Why Local? Sending vectors to a cloud API (e.g., Pinecone) exposes metadata 
   * and search patterns. Local search keeps the query context entirely private.
   * 
   * @param queryEmbedding - The vector of the user's search query.
   * @param limit - Number of top results to return.
   */
  async searchLocalVectors(queryEmbedding: number[], limit: number = 3): Promise<IndexedDocument[]> {
    const docs = await this.db.getAllDocuments();
    
    // Calculate Cosine Similarity
    const scoredDocs = docs.map(doc => {
      const similarity = this.cosineSimilarity(queryEmbedding, doc.embedding);
      return { ...doc, score: similarity };
    });

    // Sort by score descending and return top results
    return scoredDocs
      .sort((a, b) => b.score - a.score)
      .slice(0, limit);
  }

  /**
   * Helper: Calculates Cosine Similarity between two vectors.
   */
  private cosineSimilarity(vecA: number[], vecB: number[]): number {
    if (vecA.length !== vecB.length) return 0;
    
    let dotProduct = 0;
    let normA = 0;
    let normB = 0;

    for (let i = 0; i < vecA.length; i++) {
      dotProduct += vecA[i] * vecB[i];
      normA += vecA[i] * vecA[i];
      normB += vecB[i] * vecB[i];
    }

    return dotProduct / (Math.sqrt(normA) * Math.sqrt(normB));
  }

  /**
   * Adds a document to the local database and immediately indexes it.
   */
  async indexDocument(title: string, content: string): Promise<void> {
    if (!this.extractor) throw new Error('Model not initialized');
    
    console.log(`Indexing: "${title}"`);
    const embedding = await this.generateEmbedding(content);
    
    await this.db.saveDocument({
      id: crypto.randomUUID(),
      title,
      content,
      embedding
    });
  }
}

// ============================================================================
// 4. REACT COMPONENT: UI & STATE MANAGEMENT
// ============================================================================

/**
 * Main Application Component.
 * Integrates the LocalAIEngine with React state.
 */
export default function OfflineSearchApp() {
  const [engine] = useState(() => new LocalAIEngine());
  const [isReady, setIsReady] = useState(false);
  const [status, setStatus] = useState('Initializing...');
  
  // Search State
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<IndexedDocument[]>([]);
  const [isSearching, setIsSearching] = useState(false);

  // Indexing State
  const [docTitle, setDocTitle] = useState('');
  const [docContent, setDocContent] = useState('');

  // Initialize Model on Mount
  useEffect(() => {
    const init = async () => {
      try {
        await engine.initializeModel();
        setIsReady(true);
        setStatus('Ready (Offline Mode Active)');
      } catch (error) {
        setStatus('Error: Model not cached. Connect to internet to download.');
      }
    };
    init();
  }, [engine]);

  /**
   * Handler: Add a private document to local vector store.
   * Demonstrates "Data Sovereignty" - data is vectorized and stored in IDB immediately.
   */
  const handleIndexDocument = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!docTitle || !docContent) return;

    setStatus('Indexing document...');
    try {
      await engine.indexDocument(docTitle, docContent);
      setDocTitle('');
      setDocContent('');
      setStatus('Document indexed locally.');
    } catch (error) {
      setStatus('Indexing failed.');
      console.error(error);
    }
  };

  /**
   * Handler: Perform semantic search.
   * Runs entirely in the browser. No network requests are made.
   */
  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!query) return;

    setIsSearching(true);
    setStatus('Searching locally...');
    
    try {
      // 1. Generate embedding for the query
      const queryVector = await engine.generateEmbedding(query);
      
      // 2. Search local vector DB
      const searchResults = await engine.searchLocalVectors(queryVector);
      
      setResults(searchResults);
      setStatus(`Found ${searchResults.length} results.`);
    } catch (error) {
      setStatus('Search failed.');
      console.error(error);
    } finally {
      setIsSearching(false);
    }
  };

  return (
    <div style={{ fontFamily: 'system-ui, sans-serif', padding: '2rem', maxWidth: '800px', margin: '0 auto' }}>
      {/* Header & Status */}
      <div style={{ marginBottom: '2rem', padding: '1rem', background: '#f0f9ff', border: '1px solid #bae6fd', borderRadius: '8px' }}>
        <h1 style={{ margin: 0 }}>Local AI Search</h1>
        <p style={{ margin: '0.5rem 0 0', color: '#0369a1' }}>{status}</p>
        {!isReady && (
          <div style={{ marginTop: '1rem' }}>
            <div style={{ width: '100%', height: '4px', background: '#e5e7eb', overflow: 'hidden', borderRadius: '2px' }}>
              <div style={{ width: '50%', height: '100%', background: '#0ea5e9', animation: 'pulse 1.5s infinite' }}></div>
            </div>
          </div>
        )}
      </div>

      {/* Input Section: Indexing */}
      <div style={{ marginBottom: '2rem', padding: '1rem', border: '1px solid #e5e7eb', borderRadius: '8px' }}>
        <h3>1. Add Private Document (Local Only)</h3>
        <form onSubmit={handleIndexDocument}>
          <input
            type="text"
            placeholder="Document Title"
            value={docTitle}
            onChange={(e) => setDocTitle(e.target.value)}
            disabled={!isReady}
            style={{ width: '100%', marginBottom: '0.5rem', padding: '0.5rem', boxSizing: 'border-box' }}
          />
          <textarea
            placeholder="Content (e.g., 'Patient diagnosis: ...')"
            value={docContent}
            onChange={(e) => setDocContent(e.target.value)}
            disabled={!isReady}
            rows={4}
            style={{ width: '100%', marginBottom: '0.5rem', padding: '0.5rem', boxSizing: 'border-box' }}
          />
          <button 
            type="submit" 
            disabled={!isReady}
            style={{ background: '#10b981', color: 'white', border: 'none', padding: '0.5rem 1rem', borderRadius: '4px', cursor: 'pointer' }}
          >
            Index Locally
          </button>
        </form>
      </div>

      {/* Input Section: Search */}
      <div style={{ marginBottom: '2rem', padding: '1rem', border: '1px solid #e5e7eb', borderRadius: '8px' }}>
        <h3>2. Semantic Search</h3>
        <form onSubmit={handleSearch}>
          <div style={{ display: 'flex', gap: '0.5rem' }}>
            <input
              type="text"
              placeholder="Search query (e.g., 'health risks')"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              disabled={!isReady}
              style={{ flex: 1, padding: '0.5rem', boxSizing: 'border-box' }}
            />
            <button 
              type="submit" 
              disabled={!isReady || isSearching}
              style={{ background: '#2563eb', color: 'white', border: 'none', padding: '0.5rem 1rem', borderRadius: '4px', cursor: 'pointer' }}
            >
              {isSearching ? 'Searching...' : 'Search'}
            </button>
          </div>
        </form>
      </div>

      {/* Results Display */}
      <div>
        <h3>Results (Stored in IndexedDB)</h3>
        {results.length === 0 ? (
          <p style={{ color: '#6b7280' }}>No results yet. Add a document and search.</p>
        ) : (
          <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
            {results.map((result) => (
              <div key={result.id} style={{ padding: '1rem', background: '#f9fafb', borderRadius: '6px', borderLeft: '4px solid #2563eb' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                  <strong>{result.title}</strong>
                  <span style={{ color: '#6b7280', fontSize: '0.875rem' }}>Score: {result.score.toFixed(4)}</span>
                </div>
                <p style={{ margin: '0.5rem 0 0', color: '#374151' }}>{result.content}</p>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
