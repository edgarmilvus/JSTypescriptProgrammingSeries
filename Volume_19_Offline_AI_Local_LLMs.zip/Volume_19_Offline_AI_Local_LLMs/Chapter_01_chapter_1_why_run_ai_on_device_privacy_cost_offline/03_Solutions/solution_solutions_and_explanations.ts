/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// service-worker.ts

// 1. Define cache name and model asset URLs
const MODEL_CACHE_NAME = 'llama3-model-v1';
const MODEL_ASSETS = [
  'https://example.com/llama3-q4.gguf',
  'https://example.com/tokenizer.json'
];

// 2. Install Event: Cache model assets immediately
self.addEventListener('install', (event: ExtendableEvent) => {
  console.log('[Service Worker] Installing...');
  
  // Force waiting service worker to become active immediately
  self.skipWaiting();

  event.waitUntil(
    caches.open(MODEL_CACHE_NAME)
      .then((cache) => {
        console.log('[Service Worker] Caching model assets');
        return cache.addAll(MODEL_ASSETS);
      })
      .catch((err) => console.error('[Service Worker] Caching failed:', err))
  );
});

// 3. Activate Event: Clean up old caches
self.addEventListener('activate', (event: ExtendableEvent) => {
  console.log('[Service Worker] Activating...');
  event.waitUntil(
    caches.keys().then((cacheNames) => {
      return Promise.all(
        cacheNames.map((cacheName) => {
          if (cacheName !== MODEL_CACHE_NAME) {
            console.log('[Service Worker] Deleting old cache:', cacheName);
            return caches.delete(cacheName);
          }
        })
      );
    })
  );
  self.clients.claim(); // Control clients immediately
});

// 4. Fetch Event: Cache First Strategy
self.addEventListener('fetch', (event: FetchEvent) => {
  // Only intercept requests for our specific model assets
  const isModelAsset = MODEL_ASSETS.some((url) => event.request.url.includes(url));

  if (isModelAsset) {
    event.respondWith(
      caches.match(event.request)
        .then((cachedResponse) => {
          if (cachedResponse) {
            console.log('[Service Worker] Serving from cache:', event.request.url);
            return cachedResponse;
          }

          // If not in cache, fetch from network
          console.log('[Service Worker] Fetching from network:', event.request.url);
          return fetch(event.request)
            .then((networkResponse) => {
              // Clone response to cache it
              const responseClone = networkResponse.clone();
              caches.open(MODEL_CACHE_NAME)
                .then((cache) => {
                  cache.put(event.request, responseClone);
                });
              return networkResponse;
            })
            .catch((err) => {
              console.error('[Service Worker] Network request failed:', err);
              // Return a fallback response or error
              return new Response('Model unavailable offline', { status: 503 });
            });
        })
    );
  }
});
