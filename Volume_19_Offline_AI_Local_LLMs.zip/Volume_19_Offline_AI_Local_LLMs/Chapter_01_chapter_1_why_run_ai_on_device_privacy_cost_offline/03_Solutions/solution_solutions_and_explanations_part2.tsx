/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.tsx
// Description: Solutions and Explanations
// ==========================================

// TokenMonitor.tsx
import React, { useState, useEffect } from 'react';

interface TokenMonitorProps {
  prompt: string;
  maxTokens: number;
}

// 1. Utility function to estimate tokens
const estimateTokens = (text: string): number => {
  if (!text) return 0;
  // Heuristic: 1 token ≈ 4 characters
  return Math.ceil(text.length / 4);
};

const TokenMonitor: React.FC<TokenMonitorProps> = ({ prompt, maxTokens }) => {
  const [tokens, setTokens] = useState<number>(0);
  const [isWarning, setIsWarning] = useState<boolean>(false);

  // 2. Calculate tokens whenever prompt or maxTokens changes
  useEffect(() => {
    const estimated = estimateTokens(prompt);
    setTokens(estimated);
    
    // 3. Check if usage exceeds 80%
    const usagePercentage = (estimated / maxTokens) * 100;
    setIsWarning(usagePercentage > 80);
  }, [prompt, maxTokens]);

  const remaining = Math.max(0, maxTokens - tokens);
  const usagePercentage = Math.min(100, (tokens / maxTokens) * 100);

  // 4. Dynamic styling for warning
  const warningStyle: React.CSSProperties = {
    color: isWarning ? '#d9534f' : 'inherit',
    fontWeight: isWarning ? 'bold' : 'normal',
  };

  const barStyle: React.CSSProperties = {
    width: `${usagePercentage}%`,
    height: '10px',
    backgroundColor: isWarning ? '#d9534f' : '#5cb85c',
    transition: 'width 0.3s ease',
  };

  return (
    <div style={{ padding: '10px', border: '1px solid #ccc', borderRadius: '5px' }}>
      {/* Visual Progress Bar */}
      <div style={{ width: '100%', backgroundColor: '#f0f0f0', borderRadius: '5px', overflow: 'hidden', marginBottom: '8px' }}>
        <div style={barStyle}></div>
      </div>
      
      {/* Token Stats */}
      <div style={warningStyle}>
        Tokens: {tokens} / {maxTokens} (Remaining: {remaining})
      </div>
      
      {isWarning && (
        <div style={{ color: '#d9534f', fontSize: '0.85em', marginTop: '5px' }}>
          Warning: Context window 80% full. Performance may degrade.
        </div>
      )}
    </div>
  );
};

export default TokenMonitor;
