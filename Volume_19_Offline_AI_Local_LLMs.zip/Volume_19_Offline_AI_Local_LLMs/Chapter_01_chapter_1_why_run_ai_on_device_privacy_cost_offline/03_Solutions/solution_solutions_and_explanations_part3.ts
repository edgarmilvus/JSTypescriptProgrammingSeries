/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

// VectorNamespaceManager.ts

interface Vector {
  id: string;
  values: number[];
}

class VectorNamespaceManager {
  private indexName: string;
  private apiKey: string;
  private currentNamespace: string;
  
  // Simulated in-memory database for the exercise
  private storage: Map<string, Vector[]>;

  constructor(indexName: string, apiKey: string) {
    this.indexName = indexName;
    this.apiKey = apiKey;
    this.currentNamespace = 'default';
    this.storage = new Map();
    // Initialize default namespace
    this.storage.set('default', []);
  }

  // 1. Validate namespace helper
  private validateNamespace(namespace: string): void {
    if (!namespace || typeof namespace !== 'string') {
      throw new Error('Invalid namespace: Cannot be empty.');
    }
    // Regex to allow alphanumeric and hyphens only
    const validPattern = /^[a-zA-Z0-9-]+$/;
    if (!validPattern.test(namespace)) {
      throw new Error('Invalid namespace: Special characters not allowed.');
    }
  }

  // 2. Switch Namespace
  async switchNamespace(namespace: string): Promise<void> {
    try {
      this.validateNamespace(namespace);
      console.log(`[Manager] Switching active namespace to: ${namespace}`);
      
      // Create namespace in storage if it doesn't exist
      if (!this.storage.has(namespace)) {
        this.storage.set(namespace, []);
      }
      
      this.currentNamespace = namespace;
    } catch (error) {
      console.error('[Manager] Failed to switch namespace:', error);
      throw error;
    }
  }

  // 3. Insert Vectors
  async insertVectors(namespace: string, vectors: Vector[]): Promise<void> {
    try {
      this.validateNamespace(namespace);
      
      // Ensure namespace exists in storage
      if (!this.storage.has(namespace)) {
        this.storage.set(namespace, []);
      }

      const targetList = this.storage.get(namespace)!;
      // Simulate network delay
      await new Promise(resolve => setTimeout(resolve, 100));
      
      targetList.push(...vectors);
      console.log(`[Manager] Inserted ${vectors.length} vectors into namespace '${namespace}'.`);
    } catch (error) {
      console.error('[Manager] Insert failed:', error);
      throw error;
    }
  }

  // 4. Query Vectors
  async queryVectors(namespace: string, queryVector: number[], topK: number): Promise<any[]> {
    try {
      this.validateNamespace(namespace);
      
      if (!this.storage.has(namespace)) {
        return [];
      }

      const vectors = this.storage.get(namespace)!;
      
      // Simulate network delay
      await new Promise(resolve => setTimeout(resolve, 150));

      // Simulate vector similarity search (Cosine Similarity simplified)
      // We sort by dot product magnitude for simulation purposes
      const results = vectors
        .map(v => {
          // Calculate dot product
          const dotProduct = v.values.reduce((acc, val, i) => acc + val * (queryVector[i] || 0), 0);
          return { id: v.id, score: dotProduct };
        })
        .sort((a, b) => b.score - a.score) // Descending order
        .slice(0, topK);

      console.log(`[Manager] Query returned ${results.length} results from namespace '${namespace}'.`);
      return results;
    } catch (error) {
      console.error('[Manager] Query failed:', error);
      throw error;
    }
  }
}

export default VectorNamespaceManager;
