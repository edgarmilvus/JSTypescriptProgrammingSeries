/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.tsx
// Description: Solutions and Explanations
// ==========================================

// types.ts (Shared Types)
export interface LLMState {
  isModelLoaded: boolean;
  isOffline: boolean;
  loadingProgress: number;
  currentPrompt: string;
  generatedResponse: string;
}

// ModelLoader.ts (Mock Class)
export class ModelLoader {
  async loadFromCache(): Promise<boolean> {
    // Simulate checking cache (instant for simulation)
    return new Promise((resolve) => setTimeout(() => resolve(true), 500));
  }

  async downloadFromNetwork(onProgress: (progress: number) => void): Promise<void> {
    // Simulate a slow download
    const totalSteps = 10;
    for (let i = 1; i <= totalSteps; i++) {
      await new Promise(resolve => setTimeout(resolve, 300)); // 300ms per step
      onProgress((i / totalSteps) * 100);
    }
  }
}

// useLLMManager.ts (Custom Hook)
import { useState, useEffect, useCallback } from 'react';
import { LLMState, ModelLoader } from './types';

const loader = new ModelLoader();

export const useLLMManager = (initialState: LLMState) => {
  const [state, setState] = useState<LLMState>(initialState);

  // Check connectivity on mount and listen for changes
  useEffect(() => {
    const handleOnline = () => setState(prev => ({ ...prev, isOffline: false }));
    const handleOffline = () => setState(prev => ({ ...prev, isOffline: true }));

    // Initial check
    setState(prev => ({ ...prev, isOffline: !navigator.onLine }));

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  // Load Model Logic
  const loadModel = useCallback(async () => {
    setState(prev => ({ ...prev, loadingProgress: 0, isModelLoaded: false }));

    if (state.isOffline) {
      // Try cache only
      const success = await loader.loadFromCache();
      if (success) {
        setState(prev => ({ ...prev, isModelLoaded: true, loadingProgress: 100 }));
      } else {
        alert("Offline mode: Model not found in cache.");
      }
    } else {
      // Download from network
      try {
        await loader.downloadFromNetwork((progress) => {
          setState(prev => ({ ...prev, loadingProgress: progress }));
        });
        setState(prev => ({ ...prev, isModelLoaded: true }));
      } catch (error) {
        console.error("Download failed", error);
      }
    }
  }, [state.isOffline]);

  const retry = () => loadModel();

  return { state, loadModel, retry };
};

// LLMStatusDashboard.tsx (UI Component)
import React, { useState } from 'react';
import { useLLMManager } from './useLLMManager';

const LLMStatusDashboard: React.FC = () => {
  // Initialize hook
  const { state, loadModel, retry } = useLLMManager({
    isModelLoaded: false,
    isOffline: false,
    loadingProgress: 0,
    currentPrompt: '',
    generatedResponse: ''
  });

  // UI State for simulation
  const [manualOffline, setManualOffline] = useState(false);

  const handleSimulateOffline = () => {
    setManualOffline(!manualOffline);
    // Force update hook state for simulation (in real app, this might be a global context toggle)
    // For this exercise, we rely on the hook's internal listener, but we can simulate the visual trigger
    if (!manualOffline) {
      alert("Simulating Offline Mode. (Note: Browser network status remains unchanged, but logic will treat as offline)");
    }
  };

  const handleChat = () => {
    if (!state.isModelLoaded) return;
    // Simulate generation
    const response = `Generated response to: "${state.currentPrompt}" (Offline: ${state.isOffline})`;
    // Note: We can't easily update the hook's internal state from here without adding a setter, 
    // so we'll just log it or use local state for the dashboard demo.
    console.log(response);
  };

  // Determine visual status
  const isActuallyOffline = !navigator.onLine || manualOffline;

  return (
    <div style={{ padding: '20px', border: '2px solid #333', maxWidth: '400px', margin: 'auto' }}>
      <h3>LLM Status Dashboard</h3>
      
      {/* Connection Status */}
      <div style={{ marginBottom: '10px', fontWeight: 'bold', color: isActuallyOffline ? 'red' : 'green' }}>
        Status: {isActuallyOffline ? 'OFFLINE' : 'ONLINE'}
      </div>

      {/* Loading Bar */}
      {!state.isModelLoaded && state.loadingProgress > 0 && (
        <div style={{ marginBottom: '10px' }}>
          <div style={{ width: '100%', backgroundColor: '#eee' }}>
            <div style={{ width: `${state.loadingProgress}%`, backgroundColor: 'blue', height: '10px' }}></div>
          </div>
          <small>Loading: {Math.round(state.loadingProgress)}%</small>
        </div>
      )}

      {/* Controls */}
      <div style={{ marginBottom: '15px' }}>
        <button onClick={loadModel} disabled={state.isModelLoaded}>
          {state.isModelLoaded ? 'Model Loaded' : 'Load Model'}
        </button>
        <button onClick={retry} style={{ marginLeft: '5px' }}>Retry</button>
        <button onClick={handleSimulateOffline} style={{ marginLeft: '5px', backgroundColor: '#ffc107' }}>
          {manualOffline ? 'Restore Online' : 'Simulate Offline'}
        </button>
      </div>

      {/* Chat Interface */}
      <div style={{ opacity: state.isModelLoaded ? 1 : 0.5 }}>
        <input
          type="text"
          placeholder="Enter prompt..."
          value={state.currentPrompt}
          onChange={(e) => state.currentPrompt = e.target.value} // Local update for demo
          disabled={!state.isModelLoaded}
          style={{ width: '70%', marginRight: '5px' }}
        />
        <button onClick={handleChat} disabled={!state.isModelLoaded}>
          Send
        </button>
      </div>
    </div>
  );
};

export default LLMStatusDashboard;
