/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

// truncation.ts

export function truncatePrompt(prompt: string, maxTokens: number, systemPrompt?: string): string {
  // 1. Token estimation heuristic (1 token ≈ 4 characters)
  const estimateTokens = (text: string): number => Math.ceil(text.length / 4);

  // Handle empty inputs
  if (!prompt) return systemPrompt || '';

  // 2. Process System Prompt
  let systemTokens = 0;
  let processedSystem = '';
  
  if (systemPrompt) {
    systemTokens = estimateTokens(systemPrompt);
    // If system prompt alone exceeds maxTokens, we have a problem. 
    // For this exercise, we assume maxTokens is sufficient for the system prompt.
    if (systemTokens >= maxTokens) {
      console.warn("System prompt exceeds max tokens. Truncating system prompt.");
      return systemPrompt.substring(0, maxTokens * 4); // Rough char truncation
    }
    processedSystem = systemPrompt + ' '; // Add separator
  }

  // 3. Calculate available space for user prompt
  const availableTokens = maxTokens - systemTokens;
  const promptTokens = estimateTokens(prompt);

  // 4. Truncation Logic
  // If prompt fits, return full string
  if (promptTokens <= availableTokens) {
    return processedSystem + promptPrompt;
  }

  // If prompt exceeds available space, we truncate the END of the user prompt.
  // We keep the beginning/middle intact as per requirements (prioritizing recent context often means keeping the end, 
  // but the requirement says "keep beginning and middle intact" implies truncating the end).
  // However, standard LLM practice is often to keep the END (most recent) and discard the beginning.
  // The requirement states: "truncate the *end* of the user's prompt (keeping the beginning and middle intact)".
  // This is unusual for LLMs (which prefer recent info) but we will follow the specific requirement literally.
  
  // Calculate characters needed for available tokens
  const availableChars = availableTokens * 4;
  
  // Truncate user prompt to fit available characters
  const truncatedUserPrompt = prompt.substring(0, availableChars);

  return processedSystem + truncatedUserPrompt;
}
