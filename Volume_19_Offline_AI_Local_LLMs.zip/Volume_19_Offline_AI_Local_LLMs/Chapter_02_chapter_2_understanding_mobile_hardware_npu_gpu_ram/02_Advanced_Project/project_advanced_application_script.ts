/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

/**
 * Hardware-Aware Inference Orchestrator
 * 
 * Context: Book 19, Chapter 2, Subsection 3/5
 * Target: Next.js (Client Components) with ONNX Runtime Web
 * 
 * Objective: Dynamically select execution provider (WebGPU/NPU vs. CPU) 
 * based on device RAM and model requirements for Zero-Shot Classification.
 */

import { useState, useEffect, useCallback } from 'react';
import * as ort from 'onnxruntime-web';

// --- Type Definitions ---

interface HardwareProfile {
  deviceMemory: number; // GB
  isWebGPUSupported: boolean;
  recommendedExecutionProvider: 'webgpu' | 'wasm' | 'cpu';
}

interface ClassificationResult {
  label: string;
  confidence: number;
  executionTime: number; // ms
  provider: string;
}

// --- Constants & Configuration ---

const MODEL_URL = '/models/local-zero-shot.onnx'; // Placeholder URL for a quantized model
const LABELS = ['Technology', 'Health', 'Finance', 'Art'];

// Minimum RAM required to safely load a 100MB model + overhead
const MIN_RAM_GB_FOR_LOCAL_INFERENCE = 4.0; 

/**
 * Component: HardwareAwareClassifier
 * 
 * A React component that acts as the orchestrator for local LLM execution.
 * It profiles the client device and routes inference requests to the optimal hardware backend.
 */
export default function HardwareAwareClassifier() {
  const [status, setStatus] = useState<string>('Initializing...');
  const [profile, setProfile] = useState<HardwareProfile | null>(null);
  const [result, setResult] = useState<ClassificationResult | null>(null);
  const [inputText, setInputText] = useState<string>('The new quantum processor broke previous records.');

  // 1. Hardware Profiling Logic
  // ----------------------------------------------------------------
  // We query the navigator.deviceMemory (Chrome/Android) and WebGPU support.
  // This simulates the "NPU/GPU" check before committing resources.
  const detectHardware = useCallback(async (): Promise<HardwareProfile> => {
    const memory = (navigator as any).deviceMemory || 4; // Default to 4GB if unknown
    let webGPUSupported = false;

    try {
      // WebGPU is the modern API for accessing GPU/NPU acceleration on the web
      if (navigator.gpu) {
        const adapter = await navigator.gpu.requestAdapter();
        if (adapter) {
          webGPUSupported = true;
        }
      }
    } catch (e) {
      console.warn('WebGPU detection failed:', e);
    }

    // Decision Logic based on Chapter 2 concepts (RAM vs. Compute Unit)
    const provider = (memory >= MIN_RAM_GB_FOR_LOCAL_INFERENCE && webGPUSupported) 
      ? 'webgpu' 
      : 'wasm'; // Fallback to WebAssembly (CPU) if RAM is low or GPU is unavailable

    return {
      deviceMemory: memory,
      isWebGPUSupported: webGPUSupported,
      recommendedExecutionProvider: provider
    };
  }, []);

  // 2. Model Initialization & Session Creation
  // ----------------------------------------------------------------
  // This simulates the "Load" phase. ONNX Runtime creates a session bound to 
  // the specific execution provider (WebGPU vs. WASM).
  const initSession = useCallback(async (profile: HardwareProfile) => {
    setStatus(`Loading model using ${profile.recommendedExecutionProvider.toUpperCase()}...`);

    const executionProviders = profile.recommendedExecutionProvider === 'webgpu' 
      ? ['webgpu'] 
      : ['wasm']; // 'wasm' utilizes WebAssembly for CPU inference

    try {
      // In a real app, we might warm up the session here to avoid first-inference latency
      const session = await ort.InferenceSession.create(MODEL_URL, {
        executionProviders: executionProviders as any,
        graphOptimizationLevel: 'all'
      });
      
      setStatus(`Ready. Running on ${profile.recommendedExecutionProvider}.`);
      return session;
    } catch (error) {
      setStatus(`Error loading model: ${error}. Switching to server fallback.`);
      throw error;
    }
  }, []);

  // 3. Inference Execution (The "Run" Phase)
  // ----------------------------------------------------------------
  // Tokenization is omitted for brevity; assumes pre-processed tensor inputs.
  const runInference = useCallback(async (text: string, session: ort.InferenceSession) => {
    setStatus('Processing input...');
    
    // Mock input tensor generation (Batch=1, SeqLen=128)
    // In reality, this would involve a tokenizer converting text to integers.
    const inputTensor = new ort.Tensor('float32', new Float32Array(128).fill(0.5), [1, 128]);
    
    const feeds: Record<string, ort.Tensor> = {};
    feeds[session.inputNames[0]] = inputTensor;

    const start = performance.now();
    
    // EXECUTE: This is where the NPU/GPU or CPU is heavily utilized.
    const output = await session.run(feeds);
    const end = performance.now();

    // Process output (Mocking the result extraction)
    const outputData = output[session.outputNames[0]].data as Float32Array;
    const maxConfidence = Math.max(...outputData);
    const predictedIndex = outputData.indexOf(maxConfidence);
    
    const result: ClassificationResult = {
      label: LABELS[predictedIndex] || 'Unknown',
      confidence: parseFloat(maxConfidence.toFixed(4)),
      executionTime: end - start,
      provider: session.executionProvider
    };

    setResult(result);
    setStatus('Inference complete.');
  }, []);

  // 4. Main Orchestrator Hook
  // ----------------------------------------------------------------
  // Ties profiling, session creation, and execution together.
  useEffect(() => {
    const runOrchestrator = async () => {
      const hwProfile = await detectHardware();
      setProfile(hwProfile);

      // If hardware is insufficient, we might skip local init entirely
      if (hwProfile.deviceMemory < MIN_RAM_GB_FOR_LOCAL_INFERENCE) {
        setStatus('Device RAM insufficient for local inference. Offloading to server...');
        return;
      }

      await initSession(hwProfile);
    };

    runOrchestrator();
  }, [detectHardware, initSession]);

  // 5. UI Handlers
  // ----------------------------------------------------------------
  const handleAnalyze = async () => {
    if (!profile || !inputText) return;
    
    // Re-initialize session if needed (simplified for demo)
    const session = await initSession(profile);
    await runInference(inputText, session);
  };

  return (
    <div style={{ padding: '20px', fontFamily: 'system-ui' }}>
      <h2>Local LLM Inference Dashboard</h2>
      
      <div style={{ marginBottom: '20px', padding: '10px', background: '#f0f0f0' }}>
        <strong>Device Profile:</strong><br/>
        RAM: {profile?.deviceMemory || '?'} GB<br/>
        Acceleration: {profile?.isWebGPUSupported ? 'WebGPU (NPU/GPU)' : 'WebAssembly (CPU)'}<br/>
        Strategy: {profile?.recommendedExecutionProvider.toUpperCase()}
      </div>

      <textarea 
        value={inputText} 
        onChange={(e) => setInputText(e.target.value)} 
        rows={4} 
        style={{ width: '100%', marginBottom: '10px' }}
      />

      <button onClick={handleAnalyze} disabled={!profile}>
        Analyze Locally
      </button>

      <div style={{ marginTop: '20px' }}>
        <strong>Status:</strong> {status}<br/>
        {result && (
          <>
            <strong>Result:</strong> {result.label} (Confidence: {result.confidence})<br/>
            <strong>Latency:</strong> {result.executionTime.toFixed(2)} ms<br/>
            <strong>Provider:</strong> {result.provider}
          </>
        )}
      </div>
    </div>
  );
}
