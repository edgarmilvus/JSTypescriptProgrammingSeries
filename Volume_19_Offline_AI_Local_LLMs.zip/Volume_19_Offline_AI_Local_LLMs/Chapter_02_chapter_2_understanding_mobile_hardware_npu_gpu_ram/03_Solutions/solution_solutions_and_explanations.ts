/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

/**
 * Estimates the memory requirements for a model and checks against device capabilities.
 * @param modelParams - Number of parameters in the model (e.g., 7_000_000_000 for 7B).
 * @param quantizationBits - Bits per parameter (e.g., 4 for 4-bit quantization, 16 for FP16).
 * @param safetyThreshold - Percentage of available RAM allowed for the model (0.0 to 1.0).
 * @returns An object containing the feasibility decision and a detailed reason string.
 */
export function checkModelFeasibility(
  modelParams: number,
  quantizationBits: number,
  safetyThreshold: number = 0.5
): { canLoad: boolean; reason: string } {
  // 1. Calculate estimated memory in bytes
  // Formula: (Parameters * Bits per parameter) / 8 bits per byte
  const estimatedBytes = (modelParams * quantizationBits) / 8;
  
  // Convert to Gigabytes for readability
  const estimatedGB = estimatedBytes / (1024 ** 3);

  // 2. Get Device Memory
  // navigator.deviceMemory returns approximate GB (e.g., 4, 8, 12). 
  // It is undefined in some environments (like Safari or private mode).
  const deviceMemoryGB = navigator.deviceMemory || 4; // Default to 4GB if API unavailable
  
  // 3. Apply Safety Threshold
  const allowedMemoryGB = deviceMemoryGB * safetyThreshold;
  
  // 4. Decision Logic
  const canLoad = estimatedGB <= allowedMemoryGB;
  
  let reason = "";
  if (canLoad) {
    reason = `Model requires ${estimatedGB.toFixed(2)}GB. Device has ${deviceMemoryGB}GB. Within ${Math.round(safetyThreshold * 100)}% threshold.`;
  } else {
    reason = `Model requires ${estimatedGB.toFixed(2)}GB, but only ${allowedMemoryGB.toFixed(2)}GB allowed (Threshold: ${Math.round(safetyThreshold * 100)}% of ${deviceMemoryGB}GB).`;
  }

  return { canLoad, reason };
}

// Example Usage:
// const result = checkModelFeasibility(7_000_000_000, 4); // 7B model, 4-bit
// console.log(result);
