/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

/**
 * Detects the optimal hardware acceleration backend available in the browser.
 * Hierarchy: WebGPU > WebAssembly SIMD > Standard WebAssembly.
 * @returns A promise resolving to the backend string identifier.
 */
export async function detectHardwareBackend(): Promise<'webgpu' | 'wasm-simd' | 'wasm'> {
  // 1. Check for WebGPU Support (Highest Priority)
  // Modern browsers expose 'gpu' on the navigator object.
  if (navigator.gpu) {
    try {
      // Attempt to request an adapter to ensure it's actually functional, not just present.
      const adapter = await navigator.gpu.requestAdapter();
      if (adapter) {
        return 'webgpu';
      }
    } catch (e) {
      console.warn("WebGPU adapter request failed, falling back.");
    }
  }

  // 2. Check for WebAssembly SIMD Support (Middle Priority)
  // SIMD support is exposed via the WebAssembly object.
  if (WebAssembly && typeof WebAssembly.simd === 'boolean' && WebAssembly.simd) {
    return 'wasm-simd';
  }

  // 3. Fallback to Standard WebAssembly (Lowest Priority)
  // If the browser supports ONNX Runtime Web, it supports basic WASM.
  return 'wasm';
}

// Integration Example (Conceptual):
/*
import { InferenceSession } from 'onnxruntime-web';

async function initializeSession(modelPath: string) {
    const backend = await detectHardwareBackend();
    // ONRT Web allows passing execution providers in session options
    const sessionOptions = {
        executionProviders: [backend === 'webgpu' ? 'webgpu' : 'wasm'],
        graphOptimizationLevel: 'all'
    };
    const session = await InferenceSession.create(modelPath, sessionOptions);
    return { session, backend };
}
*/
