/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

/**
 * Creates a profiler to track inference performance in real-time.
 * @returns An object with methods to start/end profiling and retrieve metrics.
 */
export function createInferenceProfiler() {
  // Rolling buffer to store the last 10 inference times (in seconds)
  const history: number[] = [];
  const MAX_HISTORY = 10;
  let startTime: number | null = null;

  return {
    /**
     * Call this immediately before running the model inference.
     */
    start: () => {
      startTime = performance.now();
    },

    /**
     * Call this immediately after the model inference returns.
     * @param tokensGenerated - The number of tokens produced in this step.
     */
    end: (tokensGenerated: number) => {
      if (startTime === null) {
        throw new Error("Profiler: start() must be called before end().");
      }

      const endTime = performance.now();
      const durationMs = endTime - startTime;
      const durationSec = durationMs / 1000;

      // Calculate current TPS (avoid division by zero)
      const currentTps = tokensGenerated > 0 ? tokensGenerated / durationSec : 0;

      // Update history buffer
      history.push(currentTps);
      if (history.length > MAX_HISTORY) {
        history.shift(); // Remove oldest entry
      }

      // Calculate moving average
      const sum = history.reduce((acc, val) => acc + val, 0);
      const averageTps = sum / history.length;

      // Reset start time
      startTime = null;

      return {
        currentTps: parseFloat(currentTps.toFixed(2)),
        averageTps: parseFloat(averageTps.toFixed(2)),
        latencyMs: parseFloat(durationMs.toFixed(2))
      };
    }
  };
}
