/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState, useEffect, useMemo } from 'react';

// Define types for the conversation items
interface ChatMessage {
  id: string;
  role: 'user' | 'assistant' | 'system';
  content: string;
  tokens: number; // Estimated token count
  isPinned?: boolean;
}

interface Props {
  conversationHistory: ChatMessage[];
  maxContextTokens: number;
  onUpdateContext: (filteredHistory: ChatMessage[]) => void;
}

export const ChatContextManager: React.FC<Props> = ({ 
  conversationHistory, 
  maxContextTokens, 
  onUpdateContext 
}) => {
  // State to hold the filtered history
  const [filteredHistory, setFilteredHistory] = useState<ChatMessage[]>([]);

  useEffect(() => {
    // 1. Separate Pinned vs. Unpinned messages
    const pinnedMessages = conversationHistory.filter(msg => msg.isPinned);
    const unpinnedMessages = conversationHistory.filter(msg => !msg.isPinned);

    // Calculate tokens used by pinned messages
    const pinnedTokenCount = pinnedMessages.reduce((sum, msg) => sum + msg.tokens, 0);

    // 2. Check Constraints
    if (pinnedTokenCount > maxContextTokens) {
      // Critical: Pinned messages exceed limit. 
      // Strategy: Keep pinned messages anyway, but warn (or truncate content if strictly necessary).
      // For this exercise, we will keep them all as they are pinned.
      setFilteredHistory(conversationHistory); 
      onUpdateContext(conversationHistory);
      return;
    }

    // 3. Sliding Window Logic for Unpinned Messages
    const availableTokens = maxContextTokens - pinnedTokenCount;
    let currentTokens = 0;
    const slidingWindow: ChatMessage[] = [];

    // Iterate backwards through unpinned messages (most recent first)
    for (let i = unpinnedMessages.length - 1; i >= 0; i--) {
      const msg = unpinnedMessages[i];
      if (currentTokens + msg.tokens <= availableTokens) {
        slidingWindow.unshift(msg); // Add to beginning to maintain order
        currentTokens += msg.tokens;
      } else {
        break; // Stop adding once limit is reached
      }
    }

    // 4. Combine and Update
    // Pinned messages go at the start, followed by the sliding window of recent messages
    const result = [...pinnedMessages, ...slidingWindow];
    setFilteredHistory(result);
    onUpdateContext(result);

  }, [conversationHistory, maxContextTokens, onUpdateContext]);

  const totalTokens = useMemo(() => filteredHistory.reduce((sum, msg) => sum + msg.tokens, 0), [filteredHistory]);
  const truncatedCount = conversationHistory.length - filteredHistory.length;

  return (
    <div style={{ border: '1px solid #ccc', padding: '10px', borderRadius: '8px' }}>
      <h3>Context Manager</h3>
      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '10px' }}>
        <span>Current Tokens: <strong>{totalTokens} / {maxContextTokens}</strong></span>
        <span>Truncated Messages: <strong>{truncatedCount}</strong></span>
      </div>
      
      <ul style={{ listStyle: 'none', padding: 0 }}>
        {filteredHistory.map((msg) => (
          <li key={msg.id} style={{ 
            padding: '5px', 
            marginBottom: '5px', 
            backgroundColor: msg.isPinned ? '#e3f2fd' : '#f5f5f5',
            borderLeft: msg.isPinned ? '4px solid #2196f3' : '4px solid #ccc'
          }}>
            <strong>{msg.role.toUpperCase()}</strong> {msg.isPinned && <span>📌</span>}
            <div>{msg.content.substring(0, 50)}...</div>
            <small>Tokens: {msg.tokens}</small>
          </li>
        ))}
      </ul>
    </div>
  );
};
