/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

import { InferenceSession, Tensor } from 'onnxruntime-web';

// Mock Tokenizer (In a real app, use a library like 'bert-tokenizer' or 'transformers.js')
// This mock simizes tokenizing text into input IDs and Attention Mask.
const mockTokenizer = (text: string, maxLen: number = 128) => {
  const inputIds = new Array(maxLen).fill(0);
  const attentionMask = new Array(maxLen).fill(0);
  // Simple hashing for demo purposes to generate IDs
  for (let i = 0; i < Math.min(text.length, maxLen); i++) {
    inputIds[i] = text.charCodeAt(i) % 1000; 
    attentionMask[i] = 1;
  }
  return { inputIds: new Tensor('int64', inputIds), attentionMask: new Tensor('int64', attentionMask) };
};

/**
 * Performs zero-shot classification using a local ONNX model.
 * @param inputText - The text to classify.
 * @param candidateLabels - Array of labels to classify against.
 * @param modelPath - URL or path to the quantized ONNX model.
 * @returns Promise resolving to an array of label/score objects.
 */
export async function zeroShotClassify(
  inputText: string, 
  candidateLabels: string[], 
  modelPath: string
): Promise<{ label: string; confidence: number }[]> {
  
  // 1. Detect Backend (Reusing logic from Exercise 2)
  let executionProvider: 'webgpu' | 'wasm' = 'wasm';
  if (navigator.gpu) {
    try {
      const adapter = await navigator.gpu.requestAdapter();
      if (adapter) executionProvider = 'webgpu';
    } catch (e) { /* fallback */ }
  }

  console.log(`Running inference on backend: ${executionProvider}`);

  // 2. Load Model
  // Note: In a real scenario, ensure the model is quantized for mobile (e.g., Q4)
  const session = await InferenceSession.create(modelPath, {
    executionProviders: [executionProvider]
  });

  // 3. Preprocessing (Tokenization)
  // For zero-shot, we often concatenate the text with labels. 
  // Simplified here: We tokenize the input text once.
  const { inputIds, attentionMask } = mockTokenizer(inputText);

  // 4. Inference
  // Assuming the model expects 'input_ids' and 'attention_mask'
  const feeds = { input_ids: inputIds, attention_mask: attentionMask };
  const results = await session.run(feeds);

  // 5. Post-processing (Softmax & Mapping)
  // 'logits' is typically the output tensor name for classification
  const logits = results.logits.data as Float32Array;
  
  // Apply Softmax to convert logits to probabilities
  const exps = Array.from(logits).map(Math.exp);
  const sumExps = exps.reduce((a, b) => a + b, 0);
  const probabilities = exps.map(e => e / sumExps);

  // Map probabilities to labels
  const scores = candidateLabels.map((label, index) => ({
    label,
    confidence: probabilities[index] || 0
  }));

  // Sort by confidence descending
  return scores.sort((a, b) => b.confidence - a.confidence);
}

// Example Usage:
/*
zeroShotClassify(
  "The new processor chip is incredibly fast.", 
  ["technology", "politics", "sports"], 
  "/models/bert-4bit.onnx"
).then(console.log);
*/
