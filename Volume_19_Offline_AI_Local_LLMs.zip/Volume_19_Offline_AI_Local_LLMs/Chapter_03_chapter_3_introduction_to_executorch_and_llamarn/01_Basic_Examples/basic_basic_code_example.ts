/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

// ==========================================
// 1. Type Definitions & Interfaces
// ==========================================

/**
 * Represents the data structure the agent tracks.
 * In a real app, this might include 'userPreferences', 'cartItems', or 'searchHistory'.
 */
interface AgentState {
  goals: string[];
  currentStep: number;
  lastUserMessage: string;
  isComplete: boolean;
}

// Simulates a database response for fetching a saved state
type CheckpointPayload = {
  checkpoint: string; // The serialized state string
  metadata: Record<string, any>;
} | null;

// ==========================================
// 2. Mock Services (Simulating DB & LangGraph)
// ==========================================

/**
 * Mock Database Service.
 * In production, this would be MongoDB, Redis, or Postgres.
 */
class CheckpointStore {
  private storage = new Map<string, string>();

  async saveState(threadId: string, state: AgentState): Promise<void> {
    const serialized = JSON.stringify(state);
    this.storage.set(threadId, serialized);
    console.log(`[DB] State saved for thread ${threadId}`);
  }

  async loadState(threadId: string): Promise<CheckpointPayload> {
    const raw = this.storage.get(threadId);
    if (!raw) {
      console.log(`[DB] No checkpoint found for ${threadId}`);
      return null;
    }
    return {
      checkpoint: raw,
      metadata: { timestamp: Date.now() }
    };
  }
}

/**
 * Mock LangGraph Instance.
 * Represents the logic of `import { StateGraph } from "@langchain/langgraph"`.
 */
class MockLangGraph {
  private state: AgentState;

  constructor(initialState: AgentState) {
    this.state = initialState;
  }

  // Simulates the .fromCheckpoint() static method
  static async fromCheckpoint(
    checkpointData: string | null, 
    config: { configurable: { threadId: string } }
  ): Promise<MockLangGraph> {
    if (checkpointData) {
      const parsedState: AgentState = JSON.parse(checkpointData);
      console.log(`[GRAPH] Hydrated state from checkpoint.`);
      return new MockLangGraph(parsedState);
    }
    
    // No checkpoint found, initialize fresh
    console.log(`[GRAPH] No checkpoint. Initializing fresh state.`);
    return new MockLangGraph({
      goals: [],
      currentStep: 0,
      lastUserMessage: "",
      isComplete: false
    });
  }

  // Simulates invoking the graph to continue execution
  async invoke(input: Partial<AgentState>): Promise<AgentState> {
    // Merge input into existing state (simplified reducer logic)
    this.state = { ...this.state, ...input, currentStep: this.state.currentStep + 1 };
    
    // Simulate some async processing
    await new Promise(r => setTimeout(r, 100));
    
    if (this.state.currentStep > 3) {
      this.state.isComplete = true;
    }

    return this.state;
  }
}

// ==========================================
// 3. The Application Logic (API Handler)
// ==========================================

const db = new CheckpointStore();

/**
 * Simulates a Next.js API Route or Express controller.
 * Handles a request to interact with the agent.
 * 
 * @param threadId - Unique ID for the conversation/session
 * @param userInput - The new input from the user
 */
async function handleAgentRequest(threadId: string, userInput: string) {
  console.log(`\n--- Processing Request for Thread: ${threadId} ---`);

  // --- STEP 1: Attempt to Load Existing State ---
  const savedCheckpoint = await db.loadState(threadId);

  // --- STEP 2: Hydrate the Graph ---
  // This is the critical line. We create a graph instance based on 
  // whether we found a saved state or not.
  const graph = await MockLangGraph.fromCheckpoint(
    savedCheckpoint?.checkpoint ?? null, 
    { configurable: { threadId } }
  );

  // --- STEP 3: Update State with New Input ---
  // The graph is now "live" in memory with the old context.
  // We pass the new user message to it.
  const updatedState = await graph.invoke({ 
    lastUserMessage: userInput,
    goals: ["Answer user query"] // Appending to existing goals
  });

  // --- STEP 4: Persist the New State ---
  // Before returning the response, we save the state back to the DB
  // so the next request can pick up from here.
  await db.saveState(threadId, updatedState);

  // --- STEP 5: Return Response ---
  // In a real app, we'd return the specific output of the LLM here.
  return {
    success: true,
    currentStep: updatedState.currentStep,
    context: updatedState.lastUserMessage,
    isComplete: updatedState.isComplete
  };
}

// ==========================================
// 4. Execution Simulation
// ==========================================

async function runDemo() {
  // Scenario 1: User starts a new chat (ID: 'user-123')
  // Expect: Fresh state, step 1
  const res1 = await handleAgentRequest('user-123', 'I want to book a flight');
  console.log('Response 1:', res1);

  // Scenario 2: User sends a follow-up immediately.
  // Expect: Hydrated state, step 2, previous context retained.
  const res2 = await handleAgentRequest('user-123', 'To London specifically');
  console.log('Response 2:', res2);

  // Scenario 3: User opens a new browser tab (New request, same ID).
  // Expect: Hydrated state from res2, step 3.
  const res3 = await handleAgentRequest('user-123', 'For next Tuesday');
  console.log('Response 3:', res3);
  
  // Scenario 4: A completely different user.
  // Expect: Fresh state, step 1.
  const res4 = await handleAgentRequest('user-999', 'Hello');
  console.log('Response 4:', res4);
}

// Run the simulation
runDemo().catch(console.error);
