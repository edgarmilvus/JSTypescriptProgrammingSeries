/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.tsx
// Description: Advanced Application Script
// ==========================================

// app/page.tsx
import LocalAssistantClient from '@/components/LocalAssistantClient';
import { Suspense } from 'react';

/**
 * SERVER COMPONENT: Root Page
 * 
 * This component runs exclusively on the server. It fetches initial data
 * or renders static UI structure. It delegates the interactive inference
 * logic to the Client Component.
 * 
 * @returns {JSX.Element} The rendered page layout.
 */
export default async function HomePage() {
  // In a real scenario, we might fetch model metadata or user config here.
  // Since this is an offline AI demo, we simply render the layout.
  
  return (
    <main className="min-h-screen bg-gray-900 text-white p-8 font-sans">
      <div className="max-w-2xl mx-auto">
        <header className="mb-8">
          <h1 className="text-3xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-purple-600">
            Local LLM Inference
          </h1>
          <p className="text-gray-400 mt-2">
            Running Llama 3 via Executorch Simulation on Edge Device
          </p>
        </header>

        {/* 
          We use Suspense to handle the loading state of the client component.
          This ensures the Server Component renders the shell immediately.
        */}
        <Suspense fallback={<div className="animate-pulse bg-gray-800 h-96 rounded-xl" />}>
          <LocalAssistantClient />
        </Suspense>
      </div>
    </main>
  );
}
