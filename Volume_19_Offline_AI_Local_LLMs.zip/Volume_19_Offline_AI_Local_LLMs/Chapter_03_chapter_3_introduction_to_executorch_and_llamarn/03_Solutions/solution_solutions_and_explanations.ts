/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// Define the type for the quantization configuration
type QuantizationStrategy = 'int8' | 'int4' | 'fp16';

interface QuantizationConfig {
    strategy: QuantizationStrategy;
    approxModelSizeMB: number;
    perplexityEstimate: number;
}

// Define the input constraints interface
interface UserConstraints {
    maxStorageMB: number;
    minAccuracyScore: number; // Corresponds to perplexity reduction (lower is better)
}

/**
 * Selects the best quantization strategy based on user constraints.
 * 
 * @param constraints - The user's storage and accuracy requirements.
 * @returns The best fitting QuantizationConfig or null if none fit.
 */
function selectQuantizationStrategy(constraints: UserConstraints): QuantizationConfig | null {
    // Pre-defined dataset of available strategies and their characteristics.
    // In a real scenario, this data would come from model profiling benchmarks.
    const availableStrategies: QuantizationConfig[] = [
        { strategy: 'fp16', approxModelSizeMB: 13000, perplexityEstimate: 1.0 }, // Baseline
        { strategy: 'int8', approxModelSizeMB: 6500,  perplexityEstimate: 1.05 }, // ~2x compression
        { strategy: 'int4', approxModelSizeMB: 3500,  perplexityEstimate: 1.15 }, // ~4x compression
    ];

    // Calculate the maximum allowed perplexity based on the baseline (1.0) and the minAccuracyScore.
    // A higher minAccuracyScore implies the user is more tolerant of accuracy loss.
    // Note: The prompt states "perplexityEstimate less than or equal to 1.0 + minAccuracyScore".
    const maxAllowedPerplexity = 1.0 + constraints.minAccuracyScore;

    // Filter strategies that fit within both storage and accuracy constraints
    const validStrategies = availableStrategies.filter(config => 
        config.approxModelSizeMB <= constraints.maxStorageMB &&
        config.perplexityEstimate <= maxAllowedPerplexity
    );

    // If no strategies fit, return null
    if (validStrategies.length === 0) {
        return null;
    }

    // Prioritize strategies. We want the smallest model size that meets the criteria.
    // Sorting by 'approxModelSizeMB' in ascending order ensures we pick the most compressed valid option.
    validStrategies.sort((a, b) => a.approxModelSizeMB - b.approxModelSizeMB);

    // Return the best fit (smallest size)
    return validStrategies[0];
}
