/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

// 1. Define the TypeScript interfaces for the pipeline stages
interface UserQuery {
    queryId: string;
    text: string;
}

type EmbeddingVector = number[];

interface RetrievedContext {
    chunkId: string;
    content: string;
    similarityScore: number;
}

// Extended interface for our mock database to include embeddings
interface KnowledgeChunk {
    chunkId: string;
    content: string;
    embedding: EmbeddingVector;
}

/**
 * Helper function to calculate cosine similarity between two vectors.
 * Cosine Similarity = (A . B) / (||A|| * ||B||)
 */
function cosineSimilarity(vecA: EmbeddingVector, vecB: EmbeddingVector): number {
    if (vecA.length !== vecB.length) {
        throw new Error("Vectors must be of the same dimension");
    }

    let dotProduct = 0;
    let normA = 0;
    let normB = 0;

    for (let i = 0; i < vecA.length; i++) {
        dotProduct += vecA[i] * vecB[i];
        normA += vecA[i] * vecA[i];
        normB += vecB[i] * vecB[i];
    }

    if (normA === 0 || normB === 0) {
        return 0; // Handle zero vectors
    }

    return dotProduct / (Math.sqrt(normA) * Math.sqrt(normB));
}

/**
 * Simulates generating a mock embedding vector from a string.
 * (In production, this would call a real embedding model like text-embedding-3-small)
 */
function generateMockEmbedding(text: string): EmbeddingVector {
    const vector: number[] = [];
    let hash = 0;
    // Simple string hash to seed pseudo-random generation
    for (let i = 0; i < text.length; i++) {
        hash = ((hash << 5) - hash) + text.charCodeAt(i);
        hash |= 0; 
    }
    
    // Generate a fixed-length vector (e.g., 1536 dimensions) based on the hash
    for (let i = 0; i < 1536; i++) {
        // Pseudo-random number between -1 and 1
        vector.push((((hash * (i + 1)) % 1000) / 500) - 1);
    }
    return vector;
}

/**
 * Main function to run the RAG pipeline.
 * @param query The user's input query.
 * @param database A mock database of knowledge chunks with embeddings.
 * @returns The final augmented prompt string.
 */
function runRagPipeline(query: UserQuery, database: KnowledgeChunk[]): string {
    // Step 1: Embedding
    // Convert the user query text into a vector representation
    const queryEmbedding = generateMockEmbedding(query.text);

    // Step 2: Vector Search
    // Calculate similarity scores against all chunks in the database
    const scoredContexts = database.map(chunk => {
        const score = cosineSimilarity(queryEmbedding, chunk.embedding);
        return {
            chunkId: chunk.chunkId,
            content: chunk.content,
            similarityScore: score
        };
    });

    // Sort by score descending and take the top 2
    const topContexts = scoredContexts
        .sort((a, b) => b.similarityScore - a.similarityScore)
        .slice(0, 2);

    // Step 3: Context Augmentation
    // Construct the final prompt for the LLM
    const contextString = topContexts
        .map(ctx => `[Relevant Info: ${ctx.content}]`)
        .join('\n\n');

    const finalPrompt = `
    Answer the following question based on the context provided below.
    
    Context:
    ${contextString}
    
    Question:
    ${query.text}
    
    Answer:
    `;

    return finalPrompt.trim();
}

// Example Usage:
// const db: KnowledgeChunk[] = [...]; // Populate with data
// const userQuery: UserQuery = { queryId: '1', text: 'What is Executorch?' };
// const prompt = runRagPipeline(userQuery, db);
