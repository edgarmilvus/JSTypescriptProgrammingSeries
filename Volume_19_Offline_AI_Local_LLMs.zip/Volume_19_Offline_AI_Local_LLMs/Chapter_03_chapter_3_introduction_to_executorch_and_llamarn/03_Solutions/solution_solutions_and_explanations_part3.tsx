/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState, useEffect } from 'react';

// 1. Define the Props interface
interface StreamingTextRendererProps {
    // Using AsyncIterable as it's a common pattern for modern JS streams
    tokenStream: AsyncIterable<string>;
    isGenerating: boolean;
    placeholder: string;
}

// Mock hook for demonstration purposes (assumed to be provided by the app)
// In a real app, this would interface with native Executorch code.
const useLocalLlama = (): { stream: AsyncIterable<string>; start: () => void } => {
    // Implementation details hidden
    return { stream: (async function* () { yield "Mock "; yield "token "; })(), start: () => {} };
};

export const StreamingTextRenderer: React.FC<StreamingTextRendererProps> = ({
    tokenStream,
    isGenerating,
    placeholder,
}) => {
    // 2. State Management
    const [displayedText, setDisplayedText] = useState<string>('');
    const [isLoading, setIsLoading] = useState<boolean>(false);

    // 3. Streaming Logic & 4. Error Handling
    useEffect(() => {
        // Abort controller to handle cleanup if component unmounts or props change
        const controller = new AbortController();
        const signal = controller.signal;

        const consumeStream = async () => {
            if (!isGenerating) return;

            setIsLoading(true);
            setDisplayedText(''); // Reset text on new generation

            try {
                // Iterate over the async generator
                for await (const token of tokenStream) {
                    // Check for abort signal before updating state
                    if (signal.aborted) break;
                    
                    // Append token to the displayed text
                    setDisplayedText((prev) => prev + token);
                }
            } catch (error) {
                console.error("Stream reading error:", error);
                // Optionally set an error state here
            } finally {
                setIsLoading(false);
            }
        };

        consumeStream();

        // Cleanup function
        return () => {
            controller.abort();
        };
    }, [tokenStream, isGenerating]); // Re-run effect if stream or generating status changes

    // 5. Rendering
    return (
        <div style={{ padding: '10px', border: '1px solid #ccc', borderRadius: '8px', minHeight: '50px' }}>
            {displayedText.length > 0 ? (
                <p>{displayedText}</p>
            ) : (
                // Show placeholder if no text and not generating
                !isGenerating && <p style={{ color: '#888' }}>{placeholder}</p>
            )}

            {/* Show loading indicator if generating but text is empty or just loading */}
            {isGenerating && isLoading && displayedText.length === 0 && (
                <p style={{ color: '#555', fontStyle: 'italic' }}>Thinking...</p>
            )}
            
            {/* Visual indicator that generation is still active even if text exists */}
            {isGenerating && <span style={{ animation: 'blink 1s infinite' }}>|</span>}
        </div>
    );
};
