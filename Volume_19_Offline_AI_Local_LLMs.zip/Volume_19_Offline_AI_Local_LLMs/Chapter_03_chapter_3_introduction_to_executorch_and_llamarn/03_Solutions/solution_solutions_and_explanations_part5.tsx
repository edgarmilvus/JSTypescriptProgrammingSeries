/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState, useCallback } from 'react';
import { LlamaModelRunner } from './Exercise4'; // Assuming the class from the previous exercise

// 1. Define the LoadingState type
type LoadingState = 'idle' | 'loading' | 'success' | 'error';

// 2. Create the useModelLoader hook
const useModelLoader = (modelPath: string) => {
    const [state, setState] = useState<LoadingState>('idle');
    const [error, setError] = useState<string | undefined>(undefined);
    const [modelRunner, setModelRunner] = useState<LlamaModelRunner | null>(null);

    const load = useCallback(async () => {
        // Prevent multiple simultaneous loads
        if (state === 'loading') return;

        setState('loading');
        setError(undefined);

        const runner = new LlamaModelRunner();
        
        try {
            // 3. Asynchronously call the loadModel method
            await runner.loadModel(modelPath);
            
            // 4. Update state on success
            setState('success');
            setModelRunner(runner);
        } catch (err) {
            // 4. Update state on failure
            setState('error');
            setError(err instanceof Error ? err.message : 'An unknown error occurred');
            setModelRunner(null);
        }
    }, [modelPath, state]);

    // Optional: Add a cleanup effect if the component using this hook unmounts
    React.useEffect(() => {
        return () => {
            if (modelRunner) {
                modelRunner.dispose();
            }
        };
    }, [modelRunner]);

    return { load, state, error, modelRunner };
};

// 5. Sketch the UI Component using the hook
export const ModelLoaderUI: React.FC = () => {
    // In a real app, the path might come from props or a config file
    const MODEL_PATH = 'path/to/llama3.pte';
    const { load, state, error } = useModelLoader(MODEL_PATH);

    const renderContent = () => {
        switch (state) {
            case 'idle':
                return (
                    <button onClick={load} disabled={state === 'loading'}>
                        Load Model
                    </button>
                );
            
            case 'loading':
                return (
                    <div>
                        <p>Loading model... Please wait.</p>
                        {/* A simple spinner SVG or CSS animation would go here */}
                        <div className="spinner" style={{ border: '4px solid #f3f3f3', borderTop: '4px solid #3498db', borderRadius: '50%', width: '20px', height: '20px', animation: 'spin 1s linear infinite' }}></div>
                    </div>
                );

            case 'success':
                return (
                    <div style={{ color: 'green' }}>
                        <p>✅ Model loaded successfully!</p>
                        {/* Here you would enable the main chat interface */}
                    </div>
                );

            case 'error':
                return (
                    <div style={{ color: 'red' }}>
                        <p>❌ Error loading model: {error}</p>
                        <button onClick={load}>Retry</button>
                    </div>
                );
        }
    };

    return (
        <div style={{ padding: '20px', border: '1px solid #ddd', maxWidth: '300px', textAlign: 'center' }}>
            <h3>Model Status</h3>
            {renderContent()}
        </div>
    );
};
