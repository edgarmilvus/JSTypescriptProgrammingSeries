/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * @fileoverview QuantizationSimulation.ts
 * A simulation of 4-bit integer quantization for LLM weights.
 * This demonstrates how large models are compressed for mobile/WASM deployment.
 */

// ============================================================================
// 1. TYPE DEFINITIONS
// ============================================================================

/**
 * Represents a quantized weight matrix.
 * In a real system (like GGUF), this data is stored in binary buffers.
 */
type QuantizedMatrix = {
  data: Int8Array;      // Packed 4-bit values (2 values per byte)
  scale: Float32Array;  // Scaling factor per block
  zeroPoint: Int8Array; // Zero-point offset (usually 8 for unsigned 4-bit)
};

// ============================================================================
// 2. HELPER FUNCTIONS
// ============================================================================

/**
 * Quantizes a Float32Array into 4-bit integers (Simulated).
 * 
 * Why 4-bit? It offers the best balance between model size reduction 
 * and performance on mobile CPUs. 2-bit is too lossy; 8-bit is less efficient.
 * 
 * @param weights - The original FP16/FP32 weights.
 * @param blockSize - Group size for dynamic quantization (e.g., 32 weights).
 * @returns A QuantizedMatrix object.
 */
function quantizeTo4Bit(weights: Float32Array, blockSize: number = 32): QuantizedMatrix {
  const numWeights = weights.length;
  // We pack two 4-bit values into one Int8 byte (0-255).
  // Range of 4-bit unsigned: 0 to 15.
  const packedData = new Int8Array(Math.ceil(numWeights / 2));
  const scales = new Float32Array(Math.ceil(numWeights / blockSize));
  const zeroPoints = new Int8Array(scales.length);

  let packedIndex = 0;
  let bitShift = 0; // 0 = lower nibble, 1 = upper nibble

  for (let i = 0; i < numWeights; i += blockSize) {
    // Calculate block statistics (Min-Max scaling)
    let min = Infinity;
    let max = -Infinity;
    
    // Determine block range
    const end = Math.min(i + blockSize, numWeights);
    
    for (let j = i; j < end; j++) {
      if (weights[j] < min) min = weights[j];
      if (weights[j] > max) max = weights[j];
    }

    // Calculate scale and zero-point
    const range = max - min;
    // Avoid division by zero for constant blocks
    const scale = range === 0 ? 0 : 15 / range; 
    const zeroPoint = -min * scale;
    
    const blockIndex = Math.floor(i / blockSize);
    scales[blockIndex] = scale;
    zeroPoints[blockIndex] = Math.round(zeroPoint);

    // Quantize the block
    for (let j = i; j < end; j++) {
      const val = weights[j];
      // Map float -> [0, 15]
      let quantized = Math.round(val * scale + zeroPoint);
      
      // Clamp to valid range
      quantized = Math.max(0, Math.min(15, quantized));

      // Pack into byte (Int8)
      if (bitShift === 0) {
        // Lower nibble
        packedData[packedIndex] = quantized;
      } else {
        // Upper nibble
        packedData[packedIndex] |= (quantized << 4);
        packedIndex++;
      }
      bitShift = 1 - bitShift; // Toggle 0 -> 1 -> 0
    }
  }

  return {
    data: packedData,
    scale: scales,
    zeroPoint: zeroPoints
  };
}

/**
 * Performs Matrix Multiplication using Quantized Weights.
 * 
 * Under the Hood:
 * 1. Retrieve the scale and zero-point for the specific weight block.
 * 2. De-quantize the weight on-the-fly: W_float = (W_int - zero_point) / scale.
 * 3. Multiply with the input (usually FP16/FP32).
 * 4. Accumulate results.
 * 
 * Note: In optimized WASM kernels (like llama.cpp), this is done via SIMD instructions.
 * 
 * @param input - The activation vector (Float32Array).
 * @param weights - The quantized weight matrix.
 * @param rows - Number of rows in the weight matrix.
 * @param cols - Number of columns (must match input length).
 * @param blockSize - Must match the blockSize used in quantization.
 * @returns The result vector (Float32Array).
 */
function matMulQuantized(
  input: Float32Array, 
  weights: QuantizedMatrix, 
  rows: number, 
  cols: number, 
  blockSize: number
): Float32Array {
  const output = new Float32Array(rows);
  
  // Iterate over rows of the weight matrix
  for (let r = 0; r < rows; r++) {
    let sum = 0;
    
    // Iterate over columns (matching input dimension)
    for (let c = 0; c < cols; c++) {
      // 1. Locate the quantized weight
      const weightIndex = r * cols + c;
      const packedIndex = Math.floor(weightIndex / 2);
      const isUpperNibble = weightIndex % 2 !== 0;
      
      // Extract 4-bit value
      let byte = weights.data[packedIndex];
      let intWeight = isUpperNibble ? (byte >> 4) : (byte & 0x0F);

      // 2. Locate Scale and Zero Point
      const blockIndex = Math.floor(c / blockSize);
      const scale = weights.scale[blockIndex];
      const zeroPoint = weights.zeroPoint[blockIndex];

      // 3. De-quantize (Convert back to approximate float)
      // Formula: float_weight = (int_weight - zero_point) / scale
      // Note: In our quantization function, scale was inverted (15/range) for speed.
      // Here we reconstruct the original logic: val = (int - zp) / scale
      // However, to match our specific quantize function, we use:
      const floatWeight = (intWeight - zeroPoint) / scale;

      // 4. Multiply-Accumulate
      sum += input[c] * floatWeight;
    }
    
    output[r] = sum;
  }

  return output;
}

// ============================================================================
// 3. EXECUTION / DEMO
// ============================================================================

/**
 * Main entry point to demonstrate the quantization flow.
 */
function runQuantizationDemo() {
  console.log("--- Quantization Simulation Start ---");

  // Simulate a small layer weight matrix (e.g., 4x4)
  // In reality, this might be 4096x4096
  const originalWeights = new Float32Array([
    0.12, -0.55, 0.89, 1.20,
    -0.33, 0.45, -0.99, 0.01,
    2.10, -1.50, 0.50, -0.20,
    0.05, 0.06, -0.07, 0.08
  ]);

  // Simulate an input vector (e.g., from the previous layer)
  const inputVector = new Float32Array([1.0, 2.0, -1.0, 0.5]);

  console.log("1. Original Weights (FP32):", originalWeights);
  console.log("2. Input Vector:", inputVector);

  // Step 1: Quantize the weights to 4-bit
  // Block size 4 means we calculate scale/zero-point for every 4 weights.
  const quantized = quantizeTo4Bit(originalWeights, 4);
  console.log("3. Quantized Data (Packed Int8):", quantized.data);
  console.log("   Scale Factors:", quantized.scale);
  console.log("   Zero Points:", quantized.zeroPoint);

  // Step 2: Perform Inference using Quantized Weights
  // This simulates the forward pass in a WASM-optimized LLM.
  const result = matMulQuantized(inputVector, quantized, 4, 4, 4);

  // Step 3: Verification (Compare with Ground Truth)
  // Calculate what the result *should* be with full precision.
  const groundTruth = new Float32Array(4);
  for (let r = 0; r < 4; r++) {
    let sum = 0;
    for (let c = 0; c < 4; c++) {
      sum += inputVector[c] * originalWeights[r * 4 + c];
    }
    groundTruth[r] = sum;
  }

  console.log("\n--- Results ---");
  console.log("Quantized Output:", result);
  console.log("Ground Truth (FP32):", groundTruth);
  
  // Calculate Mean Squared Error
  let mse = 0;
  for(let i=0; i<result.length; i++) {
    mse += Math.pow(result[i] - groundTruth[i], 2);
  }
  mse /= result.length;
  console.log(`Mean Squared Error: ${mse.toFixed(6)}`);
  console.log("Note: Low error indicates successful quantization simulation.");
}

// Run the demo
runQuantizationDemo();
