/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.tsx
// Description: Advanced Application Script
// ==========================================

/**
 * Advanced Application Script: On-Device RAG with Quantized Transformers
 * 
 * Context: Book 19, Chapter 4: Quantization
 * Objective: Demonstrate running a quantized embedding model and vector search 
 * directly in a Next.js/React environment without a backend server.
 * 
 * Note: This script uses `Transformers.js` concepts. In a real Next.js app, 
 * this would likely run in a Web Worker to avoid blocking the main thread.
 */

import React, { useState, useEffect, useRef } from 'react';

// ==========================================
// 1. TYPE DEFINITIONS & INTERFACES
// ==========================================

interface DocumentChunk {
  id: string;
  text: string;
  embedding: number[] | null; // Will be populated after model load
}

interface SearchResult {
  score: number;
  text: string;
}

// ==========================================
// 2. MOCKED MODEL LOADING & QUANTIZATION LOGIC
// ==========================================

/**
 * Simulates the loading of a Quantized ONNX model.
 * 
 * In a real implementation using Transformers.js:
 * const pipe = await pipeline('feature-extraction', 'Xenova/all-MiniLM-L6-v2', {
 *   quantized: true, // <--- This flag requests the INT8 quantized version
 *   ort: ortWeb,     // ONNX Runtime Web
 * });
 * 
 * Why Quantization here?
 * - Standard models are often FP32 (32-bit floating point).
 * - Quantized models (INT8) are 4x smaller and faster on mobile CPUs.
 * - This allows the model to fit in the limited RAM of a smartphone.
 */
const loadQuantizedModel = async (): Promise<{
  embed: (text: string) => Promise<number[]>;
}> => {
  // Simulate network delay for model loading
  await new Promise(resolve => setTimeout(resolve, 1000));
  
  // Return a mock inference function that mimics vector output
  // In reality, this runs the ONNX session
  return {
    embed: async (text: string): Promise<number[]> => {
      // Deterministic pseudo-random vector generation for demo consistency
      // Real model output: [0.1, -0.5, 0.8, ...] (384 dimensions for MiniLM)
      const vector: number[] = [];
      let hash = 0;
      for (let i = 0; i < text.length; i++) {
        hash = ((hash << 5) - hash) + text.charCodeAt(i);
        hash |= 0;
      }
      
      for (let i = 0; i < 384; i++) {
        // Generate a number between -1 and 1 based on hash
        const val = Math.sin(hash + i) * 0.5;
        vector.push(val);
      }
      return vector;
    }
  };
};

// ==========================================
// 3. VECTOR SEARCH LOGIC
// ==========================================

/**
 * Calculates Cosine Similarity between two vectors.
 * Formula: (A . B) / (||A|| * ||B||)
 * Used to measure how "close" a query is to a document chunk.
 */
const cosineSimilarity = (vecA: number[], vecB: number[]): number => {
  if (vecA.length !== vecB.length) return 0;
  
  let dotProduct = 0;
  let normA = 0;
  let normB = 0;

  for (let i = 0; i < vecA.length; i++) {
    dotProduct += vecA[i] * vecB[i];
    normA += vecA[i] * vecA[i];
    normB += vecB[i] * vecB[i];
  }

  return dotProduct / (Math.sqrt(normA) * Math.sqrt(normB));
};

/**
 * Retrieves the top K relevant chunks based on query embedding.
 * This is the "Retrieval" part of RAG (Retrieval-Augmented Generation).
 */
const retrieveRelevantChunks = (
  queryEmbedding: number[],
  db: DocumentChunk[],
  topK: number = 2
): SearchResult[] => {
  const scored = db.map(doc => {
    if (!doc.embedding) return { score: -1, text: doc.text };
    
    const score = cosineSimilarity(queryEmbedding, doc.embedding);
    return { score, text: doc.text };
  });

  // Sort by score descending
  scored.sort((a, b) => b.score - a.score);

  // Return top K
  return scored.slice(0, topK).filter(item => item.score > 0);
};

// ==========================================
// 4. REACT COMPONENT (NEXT.JS APP)
// ==========================================

/**
 * OnDeviceRAGComponent
 * 
 * This component encapsulates the entire offline workflow:
 * 1. Loading the quantized model.
 * 2. Accepting user input.
 * 3. Generating embeddings locally.
 * 4. Performing vector search.
 * 5. Displaying results.
 */
export default function OnDeviceRAGComponent() {
  // State Management
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [query, setQuery] = useState<string>("");
  const [results, setResults] = useState<SearchResult[]>([]);
  const [status, setStatus] = useState<string>("Initializing...");
  
  // Refs to store the loaded model instance (to avoid re-loading on re-render)
  const modelRef = useRef<any>(null);
  
  // Mock Database: "The Company Handbook"
  // In a real app, these chunks would come from a file upload or indexedDB
  const documentDatabase: DocumentChunk[] = [
    { id: "1", text: "The company's Q4 revenue increased by 20% due to AI adoption.", embedding: null },
    { id: "2", text: "Remote work policy requires employees to be online 9am-5pm EST.", embedding: null },
    { id: "3", text: "New quantization techniques allow models to run on smartphones.", embedding: null },
    { id: "4", text: "The cafeteria serves vegan options on Tuesdays.", embedding: null },
  ];

  // Initialize Model on Mount
  useEffect(() => {
    const init = async () => {
      try {
        setStatus("Loading quantized embedding model (INT8)...");
        
        // Load the lightweight model
        const model = await loadQuantizedModel();
        modelRef.current = model;

        // Pre-compute embeddings for the database (Vectorization)
        setStatus("Vectorizing document database...");
        for (let doc of documentDatabase) {
          doc.embedding = await model.embed(doc.text);
        }

        setStatus("Ready. Ask a question about the handbook.");
        setIsLoading(false);
      } catch (error) {
        console.error(error);
        setStatus("Error loading model.");
      }
    };

    init();
  }, []);

  // Handle Search
  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!query.trim() || !modelRef.current) return;

    setIsLoading(true);
    setStatus("Generating query embedding...");
    
    // 1. Generate Embedding for User Query
    // This happens ON DEVICE. No data leaves the browser.
    const queryEmbedding = await modelRef.current.embed(query);

    setStatus("Performing vector search...");
    
    // 2. Retrieve relevant context
    const retrieved = retrieveRelevantChunks(queryEmbedding, documentDatabase);

    // 3. (Optional) Simulate LLM Generation with Context
    // In a full app, we would pass 'retrieved' to a local LLM (via llama.cpp/wasm)
    // Here we simulate the "Augmented" part by formatting the output.
    const simulatedResponse = formatResponse(retrieved, query);

    setResults(simulatedResponse);
    setStatus(`Found ${retrieved.length} relevant chunks.`);
    setIsLoading(false);
  };

  // Helper to format the RAG output
  const formatResponse = (chunks: SearchResult[], userQuery: string): SearchResult[] => {
    if (chunks.length === 0) {
      return [{ score: 0, text: "No relevant information found in the local database." }];
    }
    return chunks;
  };

  return (
    <div style={styles.container}>
      <h2 style={styles.header}>Offline RAG System</h2>
      <p style={styles.subHeader}>
        Running locally using <strong>Quantized Transformers.js</strong>
      </p>

      {/* Status Indicator */}
      <div style={styles.statusBox}>
        <strong>Status:</strong> {status}
      </div>

      {/* Input Form */}
      <form onSubmit={handleSearch} style={styles.form}>
        <input
          type="text"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Ask about revenue, policy, or AI..."
          disabled={isLoading}
          style={styles.input}
        />
        <button type="submit" disabled={isLoading} style={styles.button}>
          {isLoading ? 'Processing...' : 'Search Local DB'}
        </button>
      </form>

      {/* Results Display */}
      <div style={styles.resultsContainer}>
        {results.map((res, idx) => (
          <div key={idx} style={styles.resultCard}>
            <div style={styles.scoreBadge}>Similarity: {res.score.toFixed(4)}</div>
            <p style={styles.resultText}>{res.text}</p>
          </div>
        ))}
      </div>

      {/* Architecture Visualization */}
      <div style={styles.archSection}>
        <h3>Under the Hood: Data Flow</h3>
        <p style={{ fontSize: '0.9rem', color: '#666' }}>
          The following diagram illustrates how quantized models enable on-device processing.
        </p>
        <div style={styles.dotContainer}>
          {`digraph G {
            rankdir=TB;
            node [shape=box, style="rounded,filled", color="#3b82f6", fontcolor="white"];
            
            User [label="User Input", shape=ellipse, fillcolor="#10b981"];
            Model [label="Quantized ONNX Model\n(INT8 Precision)", fillcolor="#f59e0b"];
            VectorDB [label="In-Memory Vector DB", fillcolor="#6366f1"];
            Output [label="Local Response", shape=ellipse, fillcolor="#10b981"];

            User -> Model [label="1. Text Input"];
            Model -> VectorDB [label="2. Query Embedding"];
            VectorDB -> Output [label="3. Top-K Results"];
          }`}
        </div>
      </div>
    </div>
  );
}

// ==========================================
// 5. STYLES (Inline for portability)
// ==========================================

const styles: { [key: string]: React.CSSProperties } = {
  container: {
    maxWidth: '800px',
    margin: '0 auto',
    padding: '20px',
    fontFamily: 'system-ui, -apple-system, sans-serif',
    backgroundColor: '#f9fafb',
    borderRadius: '8px',
    boxShadow: '0 4px 6px rgba(0,0,0,0.1)',
  },
  header: {
    margin: '0 0 5px 0',
    color: '#111827',
  },
  subHeader: {
    color: '#4b5563',
    marginBottom: '20px',
  },
  statusBox: {
    padding: '10px',
    backgroundColor: '#e0e7ff',
    borderLeft: '4px solid #4f46e5',
    marginBottom: '20px',
    borderRadius: '4px',
    fontSize: '0.9rem',
  },
  form: {
    display: 'flex',
    gap: '10px',
    marginBottom: '20px',
  },
  input: {
    flex: 1,
    padding: '10px',
    borderRadius: '6px',
    border: '1px solid #d1d5db',
    fontSize: '1rem',
  },
  button: {
    padding: '10px 20px',
    backgroundColor: '#2563eb',
    color: 'white',
    border: 'none',
    borderRadius: '6px',
    cursor: 'pointer',
    fontWeight: 'bold',
  },
  resultsContainer: {
    display: 'flex',
    flexDirection: 'column',
    gap: '10px',
  },
  resultCard: {
    padding: '15px',
    backgroundColor: 'white',
    border: '1px solid #e5e7eb',
    borderRadius: '6px',
  },
  scoreBadge: {
    display: 'inline-block',
    backgroundColor: '#fef3c7',
    color: '#92400e',
    padding: '2px 8px',
    borderRadius: '12px',
    fontSize: '0.75rem',
    fontWeight: 'bold',
    marginBottom: '8px',
  },
  resultText: {
    margin: 0,
    color: '#374151',
  },
  archSection: {
    marginTop: '30px',
    padding: '15px',
    backgroundColor: '#ffffff',
    borderRadius: '8px',
    border: '1px dashed #cbd5e1',
  },
  dotContainer: {
    backgroundColor: '#f3f4f6',
    padding: '10px',
    borderRadius: '6px',
    overflowX: 'auto',
    fontFamily: 'monospace',
    fontSize: '0.8rem',
    whiteSpace: 'pre',
  }
};
