/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// calculateModelRequirements.ts

/**
 * Calculates the memory requirements for a quantized model.
 * @param paramCount - Total number of parameters (e.g., 7_000_000_000).
 * @param quantizationLevel - String like "4-bit", "8-bit", etc.
 * @param contextLength - Number of tokens in the context window.
 * @returns Object containing sizes in MB.
 */
export function calculateModelRequirements(
  paramCount: number,
  quantizationLevel: string,
  contextLength: number
) {
  // 1. Parse bit-width from string (e.g., "4-bit" -> 4)
  const bitWidthMatch = quantizationLevel.match(/(\d+)-bit/);
  const bitWidth = bitWidthMatch ? parseInt(bitWidthMatch[1], 10) : 4; // Default to 4 if parsing fails

  // 2. Calculate Weights Size (Bytes)
  // Formula: (Params * Bits) / 8 bits per byte
  const weightsBytes = (paramCount * bitWidth) / 8;

  // 3. Calculate KV Cache Size (Bytes)
  // Formula: 2 * Params * ContextLength * 16 bits (FP16) / 8
  // Note: "2" accounts for Key and Value vectors.
  const kvCacheBytes = (2 * paramCount * contextLength * 16) / 8;

  // 4. Engine Overhead (Fixed 256 MB)
  const overheadMB = 256;

  // 5. Convert to MB (1 MB = 1024 * 1024 bytes)
  const weightsSizeMB = weightsBytes / (1024 * 1024);
  const kvCacheSizeMB = kvCacheBytes / (1024 * 1024);
  const totalRamMB = weightsSizeMB + kvCacheSizeMB + overheadMB;

  return {
    weightsSizeMB: Math.round(weightsSizeMB * 100) / 100, // Round to 2 decimals
    kvCacheSizeMB: Math.round(kvCacheSizeMB * 100) / 100,
    totalRamMB: Math.round(totalRamMB * 100) / 100,
  };
}
