/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.tsx
// Description: Solutions and Explanations
// ==========================================

// RamCalculator.tsx (React Component)
import React, { useState } from 'react';
import { calculateModelRequirements } from './calculateModelRequirements';

const RamCalculator: React.FC = () => {
  const [paramCount, setParamCount] = useState(7_000_000_000);
  const [quantization, setQuantization] = useState("4-bit");
  const [contextLength, setContextLength] = useState(2048);
  const [selectedPhone, setSelectedPhone] = useState(4096); // Default 4GB

  // Calculate stats
  const stats = calculateModelRequirements(paramCount, quantization, contextLength);
  
  // Determine color based on usage
  const isOverCapacity = stats.totalRamMB > selectedPhone;
  const barColor = isOverCapacity ? 'bg-red-500' : 'bg-blue-500';
  
  // Calculate percentage for bar width (capped at 100% for visual sanity)
  const usagePercentage = Math.min((stats.totalRamMB / selectedPhone) * 100, 100);

  return (
    <div className="p-6 bg-gray-50 rounded-lg shadow-md max-w-2xl mx-auto">
      <h2 className="text-xl font-bold mb-4">RAM Calculator</h2>
      
      <div className="grid grid-cols-2 gap-4 mb-6">
        <div>
          <label className="block text-sm font-medium text-gray-700">Model Size</label>
          <select 
            className="mt-1 block w-full p-2 border rounded"
            value={paramCount}
            onChange={(e) => setParamCount(Number(e.target.value))}
          >
            <option value={7_000_000_000}>7B Parameters</option>
            <option value={13_000_000_000}>13B Parameters</option>
            <option value={70_000_000_000}>70B Parameters</option>
          </select>
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700">Quantization</label>
          <select 
            className="mt-1 block w-full p-2 border rounded"
            value={quantization}
            onChange={(e) => setQuantization(e.target.value)}
          >
            <option value="4-bit">4-bit</option>
            <option value="5-bit">5-bit</option>
            <option value="8-bit">8-bit</option>
          </select>
        </div>
      </div>

      <div className="mb-6">
        <label className="block text-sm font-medium text-gray-700">Target Device RAM</label>
        <div className="flex gap-2 mt-2">
          {[2048, 4096, 8192, 12288].map((ram) => (
            <button
              key={ram}
              onClick={() => setSelectedPhone(ram)}
              className={`px-3 py-1 rounded text-sm ${
                selectedPhone === ram 
                  ? 'bg-indigo-600 text-white' 
                  : 'bg-gray-200 text-gray-800'
              }`}
            >
              {ram / 1024}GB
            </button>
          ))}
        </div>
      </div>

      <div className="bg-white p-4 rounded border">
        <div className="flex justify-between mb-1">
          <span>Estimated Usage:</span>
          <span className="font-bold">{stats.totalRamMB} MB</span>
        </div>
        
        {/* Visual Bar */}
        <div className="w-full bg-gray-200 rounded-full h-6 overflow-hidden relative">
          <div 
            className={`h-full transition-all duration-500 ${barColor}`}
            style={{ width: `${usagePercentage}%` }}
          ></div>
        </div>
        
        <div className="mt-2 text-xs text-gray-500 flex justify-between">
          <span>Weights: {stats.weightsSizeMB} MB</span>
          <span>KV Cache: {stats.kvCacheSizeMB} MB</span>
        </div>

        {isOverCapacity && (
          <div className="mt-2 text-red-600 font-bold text-sm">
            ⚠️ Exceeds device capacity!
          </div>
        )}
      </div>
    </div>
  );
};

export default RamCalculator;
