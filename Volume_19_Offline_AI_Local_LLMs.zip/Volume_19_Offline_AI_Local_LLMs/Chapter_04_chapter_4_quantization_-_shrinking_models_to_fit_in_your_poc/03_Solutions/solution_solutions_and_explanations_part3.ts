/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

// ggufParser.ts

interface GGUFHeader {
  magic: string;
  version: number;
  tensorCount: bigint;
  metadata: Record<string, any>;
}

/**
 * Parses the header of a GGUF file.
 * Reads only the first portion of the file to extract metadata.
 * @param file - The File/Blob object.
 * @returns Promise<GGUFHeader>
 */
export async function parseGGUFHeader(file: Blob): Promise<GGUFHeader> {
  // 1. Read only the first 1024 bytes (usually sufficient for header)
  // In a real scenario, we might read dynamically, but 1024 is safe for this exercise.
  const slice = file.slice(0, 1024);
  const buffer = await slice.arrayBuffer();
  const view = new DataView(buffer);
  const decoder = new TextDecoder('utf-8');

  let offset = 0;

  // 2. Read Magic Number (4 bytes)
  const magicBytes = new Uint8Array(buffer, offset, 4);
  const magic = decoder.decode(magicBytes);
  offset += 4;

  if (magic !== 'GGUF') {
    throw new Error(`Invalid magic number: ${magic}. Expected GGUF.`);
  }

  // 3. Read Version (uint32, 4 bytes)
  const version = view.getUint32(offset, true); // Little Endian
  offset += 4;

  // 4. Read Tensor Count (uint64, 8 bytes)
  // Note: JS numbers are IEEE 754 double (53-bit safe integer). 
  // For models > 2^53 params, we use BigInt, but standard JS Number works for most consumer models.
  const tensorCount = view.getBigUint64(offset, true);
  offset += 8;

  // 5. Read Metadata KV Pairs
  // GGUF stores metadata as: [Num_KV_Pairs (uint64)] -> [Key (String) -> Value (Type + Data)]
  const kvCount = Number(view.getBigUint64(offset, true));
  offset += 8;

  const metadata: Record<string, any> = {};

  for (let i = 0; i < kvCount; i++) {
    // Read Key (String)
    const keyLen = Number(view.getBigUint64(offset, true));
    offset += 8;
    const keyBytes = new Uint8Array(buffer, offset, keyLen);
    const key = decoder.decode(keyBytes);
    offset += keyLen;

    // Read Value Type (uint32)
    const valueType = view.getUint32(offset, true);
    offset += 4;

    // Read Value Data based on type
    // GGUF Value Types: 0:uint, 1:float, 2:bool, 3:string, 4:array
    let value: any;
    switch (valueType) {
      case 0: // uint
        value = view.getBigUint64(offset, true);
        offset += 8;
        break;
      case 1: // float
        value = view.getFloat64(offset, true);
        offset += 8;
        break;
      case 2: // bool
        value = view.getUint8(offset) === 1;
        offset += 1;
        break;
      case 3: // string
        const strLen = Number(view.getBigUint64(offset, true));
        offset += 8;
        const strBytes = new Uint8Array(buffer, offset, strLen);
        value = decoder.decode(strBytes);
        offset += strLen;
        break;
      default:
        // For this exercise, we skip complex arrays or unknown types to avoid buffer overrun
        // In production, you would handle array types recursively.
        value = null; 
    }

    metadata[key] = value;
  }

  return {
    magic,
    version,
    tensorCount,
    metadata,
  };
}
