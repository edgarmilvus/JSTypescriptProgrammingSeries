/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.tsx
// Description: Solutions and Explanations
// ==========================================

// ModelUploader.tsx (React Component)
import React, { useState } from 'react';
import { parseGGUFHeader } from './ggufParser';

const ModelUploader: React.FC = () => {
  const [modelInfo, setModelInfo] = useState<any>(null);
  const [error, setError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsLoading(true);
    setError(null);
    setModelInfo(null);

    try {
      const header = await parseGGUFHeader(file);
      setModelInfo(header);
    } catch (err: any) {
      setError(err.message || "Failed to parse file.");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="p-6 border rounded-lg max-w-md mx-auto bg-white">
      <h3 className="font-bold text-lg mb-4">GGUF Model Inspector</h3>
      
      <div className="mb-4 border-2 border-dashed border-gray-300 p-6 text-center rounded hover:bg-gray-50">
        <input 
          type="file" 
          accept=".gguf" 
          onChange={handleFileChange}
          className="text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100"
        />
      </div>

      {isLoading && <p className="text-blue-600">Parsing header...</p>}

      {error && (
        <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative mb-4">
          <strong className="font-bold">Error: </strong>
          <span className="block sm:inline">{error}</span>
        </div>
      )}

      {modelInfo && (
        <div className="bg-gray-100 p-4 rounded shadow-inner">
          <div className="grid grid-cols-2 gap-2 text-sm">
            <span className="font-semibold">Name:</span>
            <span>{modelInfo.metadata['general.name'] || 'Unknown'}</span>
            
            <span className="font-semibold">Version:</span>
            <span>{modelInfo.version}</span>
            
            <span className="font-semibold">Parameters:</span>
            <span>{modelInfo.metadata['general.parameter_count']?.toString() || 'N/A'}</span>
            
            <span className="font-semibold">Tensor Count:</span>
            <span>{modelInfo.tensorCount.toString()}</span>
          </div>
        </div>
      )}
    </div>
  );
};

export default ModelUploader;
