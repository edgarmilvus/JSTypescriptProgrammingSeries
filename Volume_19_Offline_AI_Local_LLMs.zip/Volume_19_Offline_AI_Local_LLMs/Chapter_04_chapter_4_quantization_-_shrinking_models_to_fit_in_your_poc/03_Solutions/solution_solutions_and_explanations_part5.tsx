/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.tsx
// Description: Solutions and Explanations
// ==========================================

// QuantizationTradeoffChart.tsx
import React, { useState } from 'react';

type ModelStat = {
  name: string;
  sizeMB: number;
  qualityScore: number; // 0 to 1
  description: string;
};

interface Props {
  modelStats: ModelStat[];
}

const QuantizationTradeoffChart: React.FC<Props> = ({ modelStats }) => {
  const [selected, setSelected] = useState<ModelStat | null>(null);
  const [maxSize, setMaxSize] = useState<number>(3000); // Default constraint

  // Chart dimensions
  const width = 400;
  const height = 300;
  const padding = 40;

  // Find max values for scaling
  const maxMB = Math.max(...modelStats.map(s => s.sizeMB), 3000); // Minimum scale
  const maxQuality = 1.0;

  return (
    <div className="p-6 bg-white rounded-lg shadow-md max-w-2xl">
      <h2 className="text-xl font-bold mb-4">Quantization Trade-off</h2>
      
      {/* Constraint Slider */}
      <div className="mb-6">
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Device Storage Limit: <span className="text-indigo-600 font-bold">{maxSize} MB</span>
        </label>
        <input 
          type="range" 
          min="500" 
          max="5000" 
          value={maxSize}
          onChange={(e) => setMaxSize(Number(e.target.value))}
          className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer"
        />
      </div>

      {/* Scatter Plot Area */}
      <div className="relative border border-gray-200 bg-gray-50 rounded" style={{ width, height }}>
        {/* Axes (Simplified) */}
        <div className="absolute bottom-0 left-0 w-full h-px bg-gray-400"></div>
        <div className="absolute bottom-0 left-0 h-full w-px bg-gray-400"></div>
        
        {/* Data Points */}
        {modelStats.map((stat, idx) => {
          const isExceeded = stat.sizeMB > maxSize;
          const isSelected = selected?.name === stat.name;
          
          // Calculate position (0-100%)
          const x = (stat.sizeMB / maxMB) * (width - padding * 2) + padding;
          const y = height - padding - (stat.qualityScore * (height - padding * 2)) - padding;

          return (
            <div
              key={idx}
              onClick={() => !isExceeded && setSelected(stat)}
              className={`absolute w-4 h-4 rounded-full cursor-pointer transform -translate-x-1/2 -translate-y-1/2 transition-all duration-200
                ${isExceeded 
                  ? 'bg-gray-300 opacity-30 cursor-not-allowed' 
                  : 'bg-indigo-500 hover:bg-indigo-700 hover:scale-125'
                }
                ${isSelected ? 'ring-4 ring-indigo-300 shadow-lg' : ''}
              `}
              style={{ left: x, top: y }}
              title={stat.name}
            />
          );
        })}
      </div>

      {/* Tooltip / Details */}
      <div className="mt-4 p-4 bg-gray-50 rounded border min-h-[80px]">
        {selected ? (
          <div>
            <h3 className="font-bold text-lg text-indigo-700">{selected.name}</h3>
            <p className="text-sm text-gray-600 mt-1">{selected.description}</p>
            <div className="flex gap-4 mt-2 text-xs font-mono">
              <span>Size: {selected.sizeMB}MB</span>
              <span>Quality: {(selected.qualityScore * 100).toFixed(0)}%</span>
            </div>
          </div>
        ) : (
          <p className="text-gray-400 italic">Click a point to view details...</p>
        )}
      </div>
    </div>
  );
};

export default QuantizationTradeoffChart;
