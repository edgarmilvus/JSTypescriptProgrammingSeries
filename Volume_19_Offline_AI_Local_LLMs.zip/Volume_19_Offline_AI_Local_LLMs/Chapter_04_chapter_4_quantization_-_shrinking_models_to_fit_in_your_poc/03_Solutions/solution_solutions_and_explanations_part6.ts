/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part6.ts
// Description: Solutions and Explanations
// ==========================================

// generateClassificationPrompt.ts

interface ClassificationInput {
  emailContent: string;
  availableLabels: string[];
}

interface PromptOutput {
  systemPrompt: string;
  jsonSchema: string;
}

export function generateClassificationPrompt({
  emailContent,
  availableLabels
}: ClassificationInput): PromptOutput {
  // 1. Define the JSON Schema string
  const schema = {
    type: "object",
    properties: {
      label: {
        type: "string",
        enum: availableLabels,
        description: "The category that best fits the email content."
      },
      confidence: {
        type: "number",
        minimum: 0,
        maximum: 1,
        description: "The confidence score of the classification."
      }
    },
    required: ["label", "confidence"]
  };

  // 2. Construct the System Prompt
  // We instruct the model to strictly output JSON and nothing else.
  const systemPrompt = `
You are an AI assistant designed to classify emails into specific categories.
Analyze the following email content and classify it based on the available labels.

Available Labels: ${availableLabels.join(', ')}

Output Requirements:
- Respond ONLY with valid JSON.
- Do not include markdown formatting (e.g., \`\`\`json).
- The JSON object must match the following schema:
${JSON.stringify(schema, null, 2)}

Email Content:
"${emailContent}"
`.trim();

  return {
    systemPrompt,
    jsonSchema: JSON.stringify(schema)
  };
}
