/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part7.tsx
// Description: Solutions and Explanations
// ==========================================

// OfflineClassifier.tsx
import React, { useState } from 'react';
import { z } from 'zod';

// Define the Zod schema for validation
const ClassificationResponseSchema = z.object({
  label: z.string(),
  confidence: z.number().min(0).max(1),
});

type ClassificationResult = z.infer<typeof ClassificationResponseSchema>;

const OfflineClassifier: React.FC = () => {
  const [emailText, setEmailText] = useState("");
  const [result, setResult] = useState<ClassificationResult | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [status, setStatus] = useState<'idle' | 'processing' | 'done'>('idle');

  // Mock available labels
  const availableLabels = ["Work", "Personal", "Finance", "Spam"];

  const handleClassify = async () => {
    if (!emailText.trim()) return;
    
    setStatus('processing');
    setError(null);
    setResult(null);

    // Simulate LLM inference delay
    await new Promise(resolve => setTimeout(resolve, 1500));

    // 1. Generate the expected schema structure
    // In a real app, this would be sent to the local LLM
    // Here we mock a valid response based on the input length
    const mockResponseRaw = {
      label: emailText.includes("invoice") ? "Finance" : "Personal",
      confidence: 0.85
    };

    // 2. Validate using Zod
    try {
      const validated = ClassificationResponseSchema.parse(mockResponseRaw);
      setResult(validated);
      setStatus('done');
    } catch (e) {
      if (e instanceof z.ZodError) {
        setError(`Parsing Error: ${e.errors.map(err => err.message).join(', ')}`);
      } else {
        setError("Unknown validation error.");
      }
      setStatus('done');
    }
  };

  return (
    <div className="p-6 bg-gray-50 rounded-lg max-w-lg mx-auto">
      <h3 className="font-bold text-lg mb-2">Offline Email Classifier</h3>
      <p className="text-sm text-gray-600 mb-4">
        Simulates local LLM classification with schema validation.
      </p>

      <textarea
        className="w-full p-3 border rounded mb-4 h-24"
        placeholder="Paste email content here..."
        value={emailText}
        onChange={(e) => setEmailText(e.target.value)}
      />

      <button
        onClick={handleClassify}
        disabled={status === 'processing'}
        className={`w-full py-2 rounded text-white font-bold ${
          status === 'processing' ? 'bg-gray-400' : 'bg-blue-600 hover:bg-blue-700'
        }`}
      >
        {status === 'processing' ? 'Analyzing...' : 'Classify'}
      </button>

      <div className="mt-4 p-4 bg-white rounded border min-h-[60px]">
        {status === 'done' && !error && result && (
          <div className="text-green-700">
            <div className="font-bold">Result: {result.label}</div>
            <div className="text-sm">Confidence: {(result.confidence * 100).toFixed(1)}%</div>
          </div>
        )}
        
        {status === 'done' && error && (
          <div className="text-red-600 font-mono text-sm">
            {error}
          </div>
        )}
        
        {status === 'idle' && <div className="text-gray-400 italic">Waiting for input...</div>}
      </div>
    </div>
  );
};

export default OfflineClassifier;
