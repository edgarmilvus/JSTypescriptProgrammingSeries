/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part8.ts
// Description: Solutions and Explanations
// ==========================================

// createLocalAIStream.ts

type StreamPart = 
  | { type: 'start' }
  | { type: 'text'; value: string }
  | { type: 'finish' };

/**
 * Simulates a local AI stream (like llama.cpp) compatible with Vercel AI SDK format.
 * @param prompt - The user input.
 * @param modelResponse - The full text the model would generate.
 */
export async function* createLocalAIStream(
  prompt: string,
  modelResponse: string
): AsyncIterable<StreamPart> {
  // Yield start event
  yield { type: 'start' };

  // Simulate network latency and token generation
  const tokens = modelResponse.split(' '); // Split by space for simple token simulation
  
  for (const token of tokens) {
    // Random delay between 50ms and 150ms
    const delay = Math.floor(Math.random() * 100) + 50;
    await new Promise(resolve => setTimeout(resolve, delay));

    // Yield text chunk
    yield { type: 'text', value: token + ' ' };
  }

  // Yield finish event
  yield { type: 'finish' };
}
