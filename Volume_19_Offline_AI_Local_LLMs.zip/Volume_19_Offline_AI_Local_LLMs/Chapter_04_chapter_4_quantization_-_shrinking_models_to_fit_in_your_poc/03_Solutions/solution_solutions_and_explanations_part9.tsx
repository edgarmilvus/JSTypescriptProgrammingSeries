/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part9.tsx
// Description: Solutions and Explanations
// ==========================================

// LocalChatInterface.tsx
import React, { useState, useRef } from 'react';
import { createLocalAIStream } from './createLocalAIStream';

const LocalChatInterface: React.FC = () => {
  const [input, setInput] = useState("");
  const [chatHistory, setChatHistory] = useState<{ role: string; content: string }[]>([]);
  const [isGenerating, setIsGenerating] = useState(false);
  
  // Ref to hold the abort controller to stop the stream
  const abortControllerRef = useRef<AbortController | null>(null);

  const handleSend = async () => {
    if (!input.trim()) return;

    const userMessage = { role: 'user', content: input };
    setChatHistory(prev => [...prev, userMessage]);
    setInput("");
    setIsGenerating(true);

    // Initialize a new AbortController for this generation
    const controller = new AbortController();
    abortControllerRef.current = controller;
    const signal = controller.signal;

    let assistantContent = "";
    
    // Add placeholder for assistant
    setChatHistory(prev => [...prev, { role: 'assistant', content: '' }]);

    try {
      // Mock response based on input
      const mockResponse = `This is a simulated response to: "${input}". It demonstrates streaming text chunks locally.`;
      
      const stream = createLocalAIStream(input, mockResponse);

      for await (const part of stream) {
        // Check if stopped
        if (signal.aborted) {
          break;
        }

        if (part.type === 'text') {
          assistantContent += part.value;
          // Update the last message in history (the assistant one)
          setChatHistory(prev => {
            const newHistory = [...prev];
            newHistory[newHistory.length - 1] = { role: 'assistant', content: assistantContent };
            return newHistory;
          });
        }
      }
    } catch (error) {
      console.error("Stream error:", error);
    } finally {
      setIsGenerating(false);
      abortControllerRef.current = null;
    }
  };

  const handleStop = () => {
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
      setIsGenerating(false);
    }
  };

  return (
    <div className="flex flex-col h-96 border rounded-lg bg-white overflow-hidden max-w-md mx-auto">
      {/* Chat Window */}
      <div className="flex-1 overflow-y-auto p-4 space-y-3 bg-gray-50">
        {chatHistory.map((msg, idx) => (
          <div key={idx} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
            <div 
              className={`px-3 py-2 rounded-lg max-w-[80%] text-sm ${
                msg.role === 'user' ? 'bg-blue-600 text-white' : 'bg-white border border-gray-300'
              }`}
            >
              {msg.content || <span className="animate-pulse">...</span>}
            </div>
          </div>
        ))}
      </div>

      {/* Controls */}
      <div className="p-3 border-t bg-white flex gap-2">
        <input
          type="text"
          className="flex-1 border rounded px-2 py-1"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && handleSend()}
          disabled={isGenerating}
        />
        
        {!isGenerating ? (
          <button 
            onClick={handleSend}
            className="bg-blue-600 text-white px-4 py-1 rounded hover:bg-blue-700"
          >
            Send
          </button>
        ) : (
          <button 
            onClick={handleStop}
            className="bg-red-500 text-white px-4 py-1 rounded hover:bg-red-600"
          >
            Stop
          </button>
        )}
      </div>
    </div>
  );
};

export default LocalChatInterface;
