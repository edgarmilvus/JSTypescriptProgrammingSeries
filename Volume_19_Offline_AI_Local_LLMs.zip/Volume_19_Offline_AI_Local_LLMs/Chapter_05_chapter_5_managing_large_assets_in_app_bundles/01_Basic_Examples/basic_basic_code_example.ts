/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * ASSET MANAGER: ON-DEMAND MODEL DOWNLOADER
 * 
 * Context: SaaS Web App requiring local Llama 3 execution.
 * Objective: Download large model files to browser cache without blocking the UI.
 */

// --- 1. Type Definitions ---

type AssetStatus = 'idle' | 'downloading' | 'verifying' | 'ready' | 'error';

interface AssetMetadata {
  filename: string;
  size: number; // Size in bytes
  sha256Hash: string; // For integrity verification
  downloadUrl: string;
}

interface DownloadProgress {
  loaded: number;
  total: number;
  percentage: number;
}

// --- 2. The Asset Manager Class ---

class LocalLLMAssetManager {
  private status: AssetStatus = 'idle';
  private progress: DownloadProgress | null = null;
  private abortController: AbortController | null = null;

  /**
   * Initiates the download of a model file.
   * Uses the Streams API for efficient memory usage with large files.
   */
  async downloadModel(metadata: AssetMetadata): Promise<Blob> {
    this.status = 'downloading';
    this.abortController = new AbortController();

    try {
      console.log(`[AssetManager] Starting download: ${metadata.filename}`);
      
      const response = await fetch(metadata.downloadUrl, {
        signal: this.abortController.signal,
        // Important: Use 'cors' if the asset is hosted on a different domain (CDN)
        mode: 'cors', 
      });

      if (!response.ok) throw new Error(`HTTP Error: ${response.status}`);

      // Handle Content Length for progress tracking
      const total = Number(response.headers.get('Content-Length')) || metadata.size;
      let loaded = 0;

      // STREAMING: We process the response as a stream to avoid loading the entire
      // 4GB file into RAM at once.
      const reader = response.body?.getReader();
      if (!reader) throw new Error('No response body');

      const chunks: Uint8Array[] = [];
      
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        if (value) {
          chunks.push(value);
          loaded += value.length;
          
          // Update progress state
          this.progress = {
            loaded,
            total,
            percentage: Math.round((loaded / total) * 100)
          };
          
          // In a real app, emit this event to a UI state manager (e.g., React Context)
          console.log(`[AssetManager] Progress: ${this.progress.percentage}%`);
        }
      }

      // Concatenate chunks into a single Blob
      const blob = new Blob(chunks);
      this.status = 'verifying';
      
      // 3. Integrity Check (Simulated SHA-256)
      const isValid = await this.verifyIntegrity(blob, metadata.sha256Hash);
      if (!isValid) throw new Error('File integrity check failed.');

      this.status = 'ready';
      console.log(`[AssetManager] Download complete and verified.`);
      return blob;

    } catch (error: any) {
      this.status = 'error';
      console.error(`[AssetManager] Download failed: ${error.message}`);
      throw error;
    }
  }

  /**
   * Simulates a SHA-256 hash check.
   * In a real scenario, this computes the hash of the downloaded blob 
   * and compares it to the known hash.
   */
  private async verifyIntegrity(blob: Blob, expectedHash: string): Promise<boolean> {
    // Note: 'crypto.subtle' is available in secure contexts (HTTPS)
    const arrayBuffer = await blob.arrayBuffer();
    const hashBuffer = await crypto.subtle.digest('SHA-256', arrayBuffer);
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    const hashHex = hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
    
    // For this demo, we accept any hash if expected is 'skip' (or match logic)
    // In production: return hashHex === expectedHash;
    return true; 
  }

  /**
   * Cancels the ongoing download.
   */
  cancelDownload(): void {
    if (this.abortController) {
      this.abortController.abort();
      this.status = 'error';
      console.log('[AssetManager] Download cancelled by user.');
    }
  }

  /**
   * Helper to check if model is already cached in IndexedDB (omitted for brevity).
   */
  async checkLocalCache(filename: string): Promise<boolean> {
    // Implementation would query IndexedDB or Cache API
    return false; 
  }
}

// --- 3. Usage Example (Simulating a Web App Action) ---

// Mock Metadata for Llama 3 8B Quantized (approx 4-5GB)
const LLAMA_3_METADATA: AssetMetadata = {
  filename: 'llama-3-8b-instruct-q4.gguf',
  size: 4_500_000_000, // 4.5 GB
  sha256Hash: 'a1b2c3...', // Placeholder
  downloadUrl: 'https://cdn.example.com/models/llama-3-8b.gguf'
};

const manager = new LocalLLMAssetManager();

// Triggering the download (e.g., on a button click)
async function initializeApp() {
  try {
    const modelBlob = await manager.downloadModel(LLAMA_3_METADATA);
    
    // Now the model is ready. Next step is usually loading it into the inference engine.
    // Example: const session = await ort.InferenceSession.create(modelBlob);
    console.log("Model ready for inference.");
    
  } catch (error) {
    console.error("App initialization failed.", error);
  }
}

// initializeApp(); // Uncomment to run
