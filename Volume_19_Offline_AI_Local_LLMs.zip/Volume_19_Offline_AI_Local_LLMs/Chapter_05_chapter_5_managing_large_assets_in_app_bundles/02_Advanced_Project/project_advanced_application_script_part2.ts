/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script_part2.ts
// Description: Advanced Application Script
// ==========================================

digraph Architecture {
    rankdir=TB;
    node [shape=box, style=filled, fillcolor="#e3f2fd", fontname="Helvetica"];
    
    Client [label="Client (Browser)", fillcolor="#fff3e0"];
    API [label="Next.js API Route", fillcolor="#e8f5e9"];
    AssetCheck [label="Integrity Check\n(Hash Comparison)", fillcolor="#f3e5f5"];
    Downloader [label="Asset Downloader\n(Stream to Disk)", fillcolor="#ffebee"];
    VectorDB [label="Supabase (pgvector)", fillcolor="#e0f7fa"];
    Inference [label="LLM Inference\n(Context Injection)", fillcolor="#fff9c4"];

    Client -> API [label="1. Query + Embedding"];
    
    API -> AssetCheck [label="2. Check Local Model"];
    AssetCheck -> Downloader [label="3. If Missing/Invalid", style=dashed];
    Downloader -> API [label="4. Model Ready"];
    
    API -> VectorDB [label="5. Search Similarity"];
    VectorDB -> API [label="6. Retrieved Context"];
    
    API -> Inference [label="7. Prompt Engineering"];
    Inference -> Client [label="8. JSON Response"];
}
