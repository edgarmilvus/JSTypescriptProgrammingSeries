/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// useModelDownloader.ts

import { useState, useEffect, useRef } from 'react';

// Assuming react-native-fs for mobile or File System Access API for web.
// For this example, we will use a generic interface to abstract the file system.
interface FileSystem {
  writeFile: (path: string, data: ArrayBuffer, position: number) => Promise<void>;
  exists: (path: string) => Promise<boolean>;
  getFileInfo: (path: string) => Promise<{ size: number }>;
}

// Mock implementation for demonstration
const mockFs: FileSystem = {
  writeFile: async (path, data, position) => {
    console.log(`Writing ${data.byteLength} bytes to ${path} at offset ${position}`);
    // Actual implementation would write to disk
  },
  exists: async (path) => false, // Simulate file not found initially
  getFileInfo: async (path) => ({ size: 0 }),
};

type DownloadStatus = 'idle' | 'downloading' | 'paused' | 'error' | 'ready';

interface DownloadState {
  status: DownloadStatus;
  progress: number;
  downloadedBytes: number;
  totalBytes: number;
  error: string | null;
}

export const useModelDownloader = (modelUrl: string, fs: FileSystem = mockFs) => {
  const [state, setState] = useState<DownloadState>({
    status: 'idle',
    progress: 0,
    downloadedBytes: 0,
    totalBytes: 0,
    error: null,
  });

  // Use refs to keep values without triggering re-renders
  const abortControllerRef = useRef<AbortController | null>(null);
  const fileHandleRef = useRef<any>(null); // Generic handle for file system
  const downloadedBytesRef = useRef<number>(0);
  const totalBytesRef = useRef<number>(0);

  useEffect(() => {
    // Check for existing file on mount
    const checkLocalFile = async () => {
      try {
        const exists = await fs.exists('llama-model.gguf');
        if (exists) {
          const info = await fs.getFileInfo('llama-model.gguf');
          // In a real app, verify hash here. For now, assume valid if size matches.
          // We need to fetch total size first to verify
          const headResponse = await fetch(modelUrl, { method: 'HEAD' });
          const remoteSize = parseInt(headResponse.headers.get('Content-Length') || '0', 10);
          
          if (info.size === remoteSize && remoteSize > 0) {
            setState(prev => ({ ...prev, status: 'ready', progress: 100, totalBytes: remoteSize, downloadedBytes: remoteSize }));
            return;
          }
        }
      } catch (e) {
        console.error("Error checking local file", e);
      }
    };
    checkLocalFile();
  }, [modelUrl, fs]);

  const startDownload = async () => {
    if (state.status === 'downloading') return;

    try {
      // 1. Get total file size
      const headResponse = await fetch(modelUrl, { method: 'HEAD' });
      const contentLength = headResponse.headers.get('Content-Length');
      if (!contentLength) throw new Error("Cannot determine file size");
      const total = parseInt(contentLength, 10);
      totalBytesRef.current = total;
      downloadedBytesRef.current = 0;

      setState(prev => ({ ...prev, status: 'downloading', totalBytes: total, progress: 0 }));

      // 2. Start Fetch with stream
      await downloadStream(0);
    } catch (err) {
      setState(prev => ({ ...prev, status: 'error', error: (err as Error).message }));
    }
  };

  const resumeDownload = async () => {
    if (state.status !== 'paused') return;
    
    // Resume from current downloadedBytes
    setState(prev => ({ ...prev, status: 'downloading' }));
    await downloadStream(downloadedBytesRef.current);
  };

  const pauseDownload = () => {
    if (state.status !== 'downloading') return;
    
    // Abort the current fetch
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
      abortControllerRef.current = null;
    }
    setState(prev => ({ ...prev, status: 'paused' }));
  };

  const downloadStream = async (startByte: number) => {
    abortControllerRef.current = new AbortController();
    
    const headers: Record<string, string> = {};
    if (startByte > 0) {
      headers['Range'] = `bytes=${startByte}-`;
    }

    const response = await fetch(modelUrl, { 
      headers,
      signal: abortControllerRef.current.signal 
    });

    if (!response.ok && !response.status.toString().startsWith('206')) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }

    const reader = response.body?.getReader();
    if (!reader) throw new Error("No readable stream");

    // Handle Content-Range for resumption if 206 Partial Content
    const totalSize = response.headers.get('Content-Range') 
      ? parseInt(response.headers.get('Content-Range')!.split('/')[1], 10)
      : totalBytesRef.current;
    totalBytesRef.current = totalSize;

    let currentOffset = startByte;

    while (true) {
      const { done, value } = await reader.read();
      if (done) break;

      // Write chunk to disk
      // In a real app, you would buffer these chunks to avoid too many small IO ops
      // or use a dedicated file writer library.
      await fs.writeFile('llama-model.gguf', value.buffer, currentOffset);

      currentOffset += value.byteLength;
      downloadedBytesRef.current = currentOffset;

      const progress = Math.min(100, Math.round((currentOffset / totalSize) * 100));
      
      // Update state occasionally to avoid UI thrashing
      if (progress !== state.progress) {
        setState(prev => ({ ...prev, progress, downloadedBytes: currentOffset }));
      }
    }

    if (currentOffset >= totalSize) {
      setState(prev => ({ ...prev, status: 'ready', progress: 100 }));
    }
  };

  return {
    ...state,
    startDownload,
    pauseDownload,
    resumeDownload,
  };
};
