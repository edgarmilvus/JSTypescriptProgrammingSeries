/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

// sw.ts

const MODEL_CACHE_NAME = 'llama-v1-model-cache';
const MODEL_URL = '/models/llama-3-8b-q4.gguf';

self.addEventListener('install', (event: ExtendableEvent) => {
  // We skip waiting to activate the new service worker immediately
  self.skipWaiting();

  // Pre-caching strategy:
  // For large assets, we do NOT waitUntil() the caching inside install.
  // Waiting for a 4GB download to finish installing would stall the SW registration.
  // Instead, we cache in the 'activate' phase or on the first fetch.
  // However, to strictly follow the prompt's request to "pre-cache" without blocking:
  event.waitUntil(
    (async () => {
      const cache = await caches.open(MODEL_CACHE_NAME);
      // We add the URL, but the browser fetches it asynchronously.
      // If the user closes the app before it finishes, it resumes next time.
      try {
        await cache.add(MODEL_URL);
      } catch (error) {
        console.warn('Pre-caching failed (likely offline or network error). Will fetch on demand.');
      }
    })()
  );
});

self.addEventListener('activate', (event: ExtendableEvent) => {
  // Clean up old caches
  event.waitUntil(
    (async () => {
      const cacheNames = await caches.keys();
      await Promise.all(
        cacheNames
          .filter(name => name !== MODEL_CACHE_NAME)
          .map(name => caches.delete(name))
      );
      self.clients.claim();
    })()
  );
});

self.addEventListener('fetch', (event: FetchEvent) => {
  // Only intercept requests for the specific model file
  if (event.request.url.includes(MODEL_URL)) {
    event.respondWith(
      (async () => {
        const cache = await caches.open(MODEL_CACHE_NAME);
        
        // 1. Check Cache Storage API
        const cachedResponse = await cache.match(event.request);

        // 2. Stale-While-Revalidate Logic
        const fetchPromise = fetch(event.request).then(networkResponse => {
          // If network request is successful, update the cache
          if (networkResponse.ok) {
            cache.put(event.request, networkResponse.clone());
          }
          return networkResponse;
        }).catch(err => {
          // Network failed, but we might still have the cached version
          console.error('Fetch failed:', err);
        });

        // 3. Return cached response immediately if available
        if (cachedResponse) {
          // Trigger the network fetch in the background (non-blocking)
          event.waitUntil(fetchPromise);
          return cachedResponse;
        }

        // 4. If not in cache, wait for network response
        try {
          const networkResponse = await fetchPromise;
          if (networkResponse) return networkResponse;
        } catch (e) {
          // Handle offline scenario if no cache exists
          return new Response('Model not available offline', { status: 503 });
        }

        // Fallback (should not be reached in this logic flow)
        return new Response('Error', { status: 500 });
      })()
    );
  }
});
