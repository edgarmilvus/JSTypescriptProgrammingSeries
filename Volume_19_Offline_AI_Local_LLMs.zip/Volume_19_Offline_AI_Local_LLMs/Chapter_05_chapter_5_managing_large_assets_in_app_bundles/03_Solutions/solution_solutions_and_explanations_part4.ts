/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

// assetVerifier.ts

// Helper to convert ArrayBuffer to Hex String
const bufferToHex = (buffer: ArrayBuffer): string => {
  const bytes = new Uint8Array(buffer);
  const hexParts: string[] = [];
  for (let i = 0; i < bytes.length; i++) {
    const hex = bytes[i].toString(16).padStart(2, '0');
    hexParts.push(hex);
  }
  return hexParts.join('');
};

export const verifyFileIntegrity = async (
  filePath: string, 
  expectedHash: string
): Promise<boolean> => {
  try {
    // 1. Read file from filePath
    // Note: In a browser environment, we might use FileReader or fetch.
    // In React Native, we would use react-native-fs.
    // Here we simulate reading the file content as an ArrayBuffer.
    // const fileBuffer = await readFileSync(filePath); // Pseudo-code for FS read
    
    // For this exercise, we will assume we fetch the file from the local system
    // or use a generic file reader abstraction.
    // Since we can't access real FS here, we will simulate the logic.
    
    // Simulate getting the buffer (in real app: fs.readFile(filePath))
    const fileBuffer = new ArrayBuffer(0); // Placeholder for actual file data
    
    // 2. Calculate SHA-256
    // The Web Crypto API works on ArrayBuffer
    const hashBuffer = await crypto.subtle.digest('SHA-256', fileBuffer);
    const hashHex = bufferToHex(hashBuffer);

    // 3. Compare
    return hashHex === expectedHash;
  } catch (error) {
    console.error("Integrity check failed", error);
    return false;
  }
};

interface RemoteManifest {
  version: string;
  modelUrl: string;
  sha256: string;
  changelog: string;
}

export const checkForUpdates = async (
  manifestUrl: string, 
  currentVersion: string
): Promise<{ hasUpdate: boolean; manifest?: RemoteManifest }> => {
  try {
    // 1. Fetch manifest.json
    const response = await fetch(manifestUrl);
    if (!response.ok) throw new Error('Failed to fetch manifest');
    
    // 2. Parse JSON
    const data: RemoteManifest = await response.json();

    // 3. Compare versions (Simple string comparison for this exercise)
    // In a real app, use a semantic versioning library like 'semver'
    if (data.version !== currentVersion) {
      // 4. Return update status
      return { hasUpdate: true, manifest: data };
    }

    return { hasUpdate: false };
  } catch (error) {
    console.error("Error checking for updates", error);
    return { hasUpdate: false };
  }
};
