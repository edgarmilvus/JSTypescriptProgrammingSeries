/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.tsx
// Description: Solutions and Explanations
// ==========================================

// LazyAIChat.tsx

import React, { Suspense, lazy } from 'react';

// 1. Dynamic Import
// We use lazy() to tell React to load this component only when it is rendered.
// Webpack (or Vite/Rollup) will automatically create a separate chunk (JS file) for this import.
const HeavyAIComponent = lazy(() => import('./HeavyAIComponent'));

// Fallback UI displayed while the chunk is being downloaded
const LoadingSpinner = () => (
  <div style={{ padding: '20px', textAlign: 'center' }}>
    <div className="spinner">Loading AI Engine...</div>
    <p>Downloading heavy assets (4.5GB)...</p>
  </div>
);

export const LazyAIChat: React.FC = () => {
  return (
    // 2. Suspense Boundary
    // Suspense catches the lazy component's promise and renders the fallback
    // while the code is being fetched.
    <Suspense fallback={<LoadingSpinner />}>
      <HeavyAIComponent />
    </Suspense>
  );
};
