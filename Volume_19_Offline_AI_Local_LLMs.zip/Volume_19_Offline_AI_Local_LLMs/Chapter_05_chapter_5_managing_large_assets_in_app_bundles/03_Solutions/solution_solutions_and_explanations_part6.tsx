/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part6.tsx
// Description: Solutions and Explanations
// ==========================================

// HeavyAIComponent.tsx

import React, { useEffect } from 'react';

// Simulating a heavy dependency import
// In a real scenario, this might import 'onnxruntime-web' or a large ML library
const initializeModel = () => {
  console.log("Initializing ONNX session...");
  // Simulate delay for model loading
  return "Model Ready";
};

export const HeavyAIComponent: React.FC = () => {
  useEffect(() => {
    const status = initializeModel();
    console.log(status);
  }, []);

  return (
    <div>
      <h2>Local Llama 3 Chat</h2>
      <p>This component is loaded dynamically.</p>
      <p>It only adds to the main bundle size when the user clicks the AI tab.</p>
      <div style={{ border: '1px solid #007acc', padding: '10px', marginTop: '10px' }}>
        [Chat Interface Placeholder]
      </div>
    </div>
  );
};

export default HeavyAIComponent;
