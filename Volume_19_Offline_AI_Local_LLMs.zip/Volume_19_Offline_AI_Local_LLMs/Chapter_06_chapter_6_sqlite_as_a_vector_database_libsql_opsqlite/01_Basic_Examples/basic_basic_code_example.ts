/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

// Import necessary dependencies
// 'better-sqlite3' is used here for Node.js environment simulation.
// In a mobile app (React Native/Expo), you would import 'expo-sqlite' or 'react-native-sqlite-storage'.
import Database from 'better-sqlite3';
import path from 'path';

/**
 * ============================================================================
 * 1. DATABASE INITIALIZATION & SCHEMA SETUP
 * ============================================================================
 */

// Initialize the database connection.
// In a mobile app, this is handled by the SQLite plugin.
// We use an in-memory database for this demo to keep it self-contained.
const db = new Database(':memory:');

/**
 * Sets up the database schema.
 * We create a table 'notes' to store text and its vector representation.
 * 
 * Note: In a real environment with libSQL/OPSQLite, we would create a 
 * virtual table using 'vector' extension or use a BLOB column specifically 
 * optimized for vector storage.
 */
function initializeDatabase(): void {
    console.log('Initializing database schema...');
    
    const sql = `
        CREATE TABLE IF NOT EXISTS notes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            content TEXT NOT NULL,
            -- In a real vector DB, this column type would be 'VECTOR(384)' or similar.
            -- Here we store it as JSON string to simulate the array of floats.
            embedding TEXT NOT NULL 
        );
    `;

    db.exec(sql);
    console.log('Database schema created successfully.');
}

/**
 * ============================================================================
 * 2. MOCK EMBEDDING GENERATION
 * ============================================================================
 */

/**
 * Simulates an AI embedding model (like 'all-MiniLM-L6-v2').
 * In a real mobile app, you would use a local model (e.g., via TensorFlow.js 
 * or ONNX Runtime) or a remote API call (OpenAI, Cohere).
 * 
 * This function converts a string into a fixed-size array of numbers (floats).
 * 
 * @param text - The input string to embed.
 * @returns - A Float32Array representing the vector embedding.
 */
function generateEmbedding(text: string): Float32Array {
    // A simple mock hash function to generate deterministic "random" numbers
    // This ensures that the same text always produces the same vector.
    let hash = 0;
    for (let i = 0; i < text.length; i++) {
        const char = text.charCodeAt(i);
        hash = ((hash << 5) - hash) + char;
        hash = hash & hash; // Convert to 32bit integer
    }

    // Generate a vector of size 384 (common for small models like MiniLM)
    const vectorSize = 384;
    const vector = new Float32Array(vectorSize);
    
    for (let i = 0; i < vectorSize; i++) {
        // Create a pseudo-random float between 0 and 1 based on the hash
        const seed = (hash + i * 1337) % 10000;
        const randomVal = Math.abs(Math.sin(seed)) * 2 - 1; // Normalize to [-1, 1]
        vector[i] = randomVal;
    }

    return vector;
}

/**
 * ============================================================================
 * 3. DATA INGESTION (INSERTION)
 * ============================================================================
 */

/**
 * Inserts a new note into the database.
 * 
 * @param content - The text content of the note.
 */
function insertNote(content: string): void {
    // 1. Generate the embedding for the content
    const embedding = generateEmbedding(content);
    
    // 2. Convert the Float32Array to a JSON string for storage in SQLite.
    // In a real vector DB, we would bind the raw buffer directly.
    const embeddingString = JSON.stringify(Array.from(embedding));

    const stmt = db.prepare('INSERT INTO notes (content, embedding) VALUES (?, ?)');
    stmt.run(content, embeddingString);
    
    console.log(`Inserted note: "${content.substring(0, 20)}..."`);
}

/**
 * ============================================================================
 * 4. VECTOR SEARCH LOGIC (ANN SIMULATION)
 * ============================================================================
 */

/**
 * Calculates Euclidean Distance between two vectors.
 * Formula: sqrt(sum((x_i - y_i)^2))
 * 
 * @param vecA - First vector (query)
 * @param vecB - Second vector (db record)
 * @returns - The distance score (lower is better)
 */
function calculateDistance(vecA: Float32Array, vecB: Float32Array): number {
    let sum = 0;
    for (let i = 0; i < vecA.length; i++) {
        sum += Math.pow(vecA[i] - vecB[i], 2);
    }
    return Math.sqrt(sum);
}

/**
 * Performs a semantic search against the database.
 * In a real scenario with libSQL, this would be a single SQL query:
 * `SELECT content, vector_distance(embedding, ?) AS distance FROM notes ORDER BY distance LIMIT 5`
 * 
 * Here, we fetch all rows and calculate distance in JavaScript to simulate the logic.
 * 
 * @param query - The user's search string.
 * @param limit - Number of results to return.
 * @returns - Array of results with content and distance.
 */
function semanticSearch(query: string, limit: number = 3) {
    console.log(`\nSearching for: "${query}"`);
    
    // 1. Generate embedding for the query
    const queryEmbedding = generateEmbedding(query);

    // 2. Fetch all notes from DB
    const rows = db.prepare('SELECT id, content, embedding FROM notes').all();

    // 3. Map over rows, parse embeddings, and calculate distance
    const results = rows.map((row: any) => {
        // Parse the JSON string back into an array
        const dbEmbeddingArray = JSON.parse(row.embedding);
        // Convert back to Float32Array for calculation
        const dbEmbedding = new Float32Array(dbEmbeddingArray);
        
        // Calculate distance
        const distance = calculateDistance(queryEmbedding, dbEmbedding);
        
        return {
            id: row.id,
            content: row.content,
            distance: distance
        };
    });

    // 4. Sort by distance (ascending - closest matches first)
    results.sort((a, b) => a.distance - b.distance);

    // 5. Return top N results
    return results.slice(0, limit);
}

/**
 * ============================================================================
 * 5. MAIN EXECUTION FLOW
 * ============================================================================
 */
async function main() {
    // Setup
    initializeDatabase();

    // Ingest Data
    insertNote("The quick brown fox jumps over the lazy dog.");
    insertNote("Artificial Intelligence is transforming mobile computing.");
    insertNote("SQLite is a lightweight, serverless database engine.");
    insertNote("JavaScript is the language of the web.");
    insertNote("Vector embeddings capture semantic meaning of text.");

    // Perform Search 1: Semantic similarity to "AI on mobile phones"
    const search1 = semanticSearch("AI on mobile phones");
    console.log("\n--- Search Results 1 ---");
    search1.forEach(res => {
        console.log(`[Dist: ${res.distance.toFixed(4)}] ${res.content}`);
    });

    // Perform Search 2: Semantic similarity to "Database engines"
    const search2 = semanticSearch("Database engines");
    console.log("\n--- Search Results 2 ---");
    search2.forEach(res => {
        console.log(`[Dist: ${res.distance.toFixed(4)}] ${res.content}`);
    });
}

// Run the main function
main().catch(console.error);
