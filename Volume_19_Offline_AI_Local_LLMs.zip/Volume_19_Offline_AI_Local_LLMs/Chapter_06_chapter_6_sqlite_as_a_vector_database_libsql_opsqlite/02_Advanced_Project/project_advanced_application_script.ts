/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// app/api/search/route.ts
import { NextResponse } from 'next/server';
import { createClient } from '@libsql/client';

/**
 * ============================================================================
 * CONFIGURATION & TYPES
 * ============================================================================
 */

// Configuration for the local SQLite database.
// In a real mobile or edge environment, this might point to a file path 
// or an in-memory database instance.
const db = createClient({
  url: 'file:./local.db', // Local file-based SQLite
});

// Type definition for a document record stored in the database.
interface DocumentChunk {
  id: number;
  content: string;
  embedding: number[]; // Stored as JSON in DB
}

// Type definition for the search response.
interface SearchResult {
  id: number;
  content: string;
  score: number; // Similarity score (1 - distance)
}

/**
 * ============================================================================
 * DATABASE INITIALIZATION
 * ============================================================================
 * 
 * This function ensures the database table exists with the necessary 
 * schema for vector storage. In a production app, this would run 
 * as a migration script on startup.
 */
async function initializeVectorTable(): Promise<void> {
  const sql = `
    CREATE TABLE IF NOT EXISTS documents (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      content TEXT NOT NULL,
      embedding TEXT NOT NULL  -- Storing vector as JSON string for portability
    );
    
    -- Create an index for faster retrieval (optional, depends on extension)
    -- CREATE INDEX IF NOT EXISTS idx_doc_embedding ON documents(embedding);
  `;
  
  try {
    await db.execute(sql);
    console.log('Vector table initialized successfully.');
  } catch (error) {
    console.error('Failed to initialize vector table:', error);
    throw error;
  }
}

/**
 * ============================================================================
 * HELPER: EMBEDDING GENERATION (Simulated)
 * ============================================================================
 * 
 * In a real-world scenario, this would call a local model (e.g., via ONNX)
 * or a lightweight external API. We simulate a 384-dimension vector 
 * (standard for 'all-MiniLM-L6-v2').
 * 
 * @param text - The input text to embed.
 * @returns Promise<number[]> - The vector embedding.
 */
async function generateEmbedding(text: string): Promise<number[]> {
  // SIMULATION: Replace this with actual model inference.
  // Creating a deterministic pseudo-vector based on string length for demo purposes.
  const baseVector = Array(384).fill(0).map((_, i) => {
    return (text.length * (i + 1)) % 100 / 100; 
  });
  
  // Simulate network latency
  await new Promise(resolve => setTimeout(resolve, 100));
  
  return baseVector;
}

/**
 * ============================================================================
 * API ROUTE: INGEST DATA
 * ============================================================================
 * 
 * Endpoint: POST /api/search
 * Action: Takes raw text, generates embedding, and inserts into SQLite.
 * 
 * This mimics the "Worker Agent" pattern where the Embedding Agent 
 * processes the text and hands off the vector to the Database Agent.
 */
export async function POST(request: Request) {
  try {
    // 1. Initialize DB if needed (usually done in a separate migration)
    await initializeVectorTable();

    const { action, text } = await request.json();

    if (action === 'ingest') {
      if (!text) {
        return NextResponse.json({ error: 'Text is required for ingestion' }, { status: 400 });
      }

      // 2. Generate Embedding (Async Processing)
      const embedding = await generateEmbedding(text);

      // 3. Store in SQLite
      // We serialize the array to a JSON string for storage.
      const sql = `INSERT INTO documents (content, embedding) VALUES (?, ?)`;
      const params = [text, JSON.stringify(embedding)];

      await db.execute({ sql, args: params });

      return NextResponse.json({ 
        success: true, 
        message: 'Document ingested and embedded.' 
      });
    }

    // ...
    // (Search logic follows below)
    // ...

  } catch (error) {
    console.error('API Error:', error);
    return NextResponse.json({ error: 'Internal Server Error' }, { status: 500 });
  }
}

/**
 * ============================================================================
 * API ROUTE: SEMANTIC SEARCH
 * ============================================================================
 * 
 * Endpoint: POST /api/search
 * Action: Generates query vector and performs ANN search using SQL.
 * 
 * Note: The SQL syntax below assumes the 'libsql_vector' syntax.
 * Standard syntax often looks like: 
 * SELECT *, vector_distance(embedding, ?) as dist FROM documents ...
 */
export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const query = searchParams.get('q');

    if (!query) {
      return NextResponse.json({ error: 'Query parameter "q" is required' }, { status: 400 });
    }

    // 1. Generate Query Vector
    // This is the "Query Vector" concept from the definitions.
    const queryVector = await generateEmbedding(query);
    const queryVectorJson = JSON.stringify(queryVector);

    // 2. Execute ANN Search
    // We use the vector_distance function provided by the extension.
    // We limit results to the top 5 most similar documents.
    const sql = `
      SELECT 
        id, 
        content,
        -- Calculate Cosine Similarity: 1 - (a · b / (|a| * |b|))
        -- Depending on extension, this might be vector_distance(embedding, ?, 'cosine')
        1 - vector_distance(embedding, ?) as score
      FROM documents
      ORDER BY score DESC
      LIMIT 5;
    `;

    const result = await db.execute({ sql, args: [queryVectorJson] });

    // 3. Format Results
    const results: SearchResult[] = result.rows.map((row: any) => ({
      id: row.id,
      content: row.content,
      score: parseFloat(row.score).toFixed(4)
    }));

    return NextResponse.json({ 
      query, 
      results,
      vectorDimensions: queryVector.length
    });

  } catch (error) {
    console.error('Search Error:', error);
    return NextResponse.json({ error: 'Internal Server Error' }, { status: 500 });
  }
}
