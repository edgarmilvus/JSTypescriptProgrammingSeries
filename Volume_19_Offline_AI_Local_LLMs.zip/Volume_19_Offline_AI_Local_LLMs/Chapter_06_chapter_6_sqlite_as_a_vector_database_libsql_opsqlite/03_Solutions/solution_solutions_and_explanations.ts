/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

import { Database } from 'react-native-sqlite-storage';

// 1. Define the TypeScript interface for type safety
export interface DocumentChunk {
  id?: number; // Optional because it's auto-incrementing
  content: string;
  embedding: Float32Array;
  metadata?: Record<string, any>; // JSON object
}

/**
 * Initializes the vector database by loading the extension and creating the table.
 * Note: The specific SQL command to load the extension depends on the SQLite distribution
 * (e.g., libSQL vs. OPSqlite). This example assumes a hypothetical `load_extension` command.
 * In a real mobile environment, extensions are often loaded via native modules or pre-compiled.
 */
export const initializeVectorDatabase = async (db: Database): Promise<void> => {
  try {
    // 1. Load Vector Extension
    // In a real scenario, this might be handled by the native module initialization.
    // For libSQL/OPSqlite, you might execute:
    // await db.executeSql("SELECT load_extension('libsqlite_vector.so');");
    
    // 2. Create the document_chunks table
    const createTableSQL = `
      CREATE TABLE IF NOT EXISTS document_chunks (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        content TEXT NOT NULL,
        embedding VECTOR NOT NULL,
        metadata JSON
      );
    `;

    await db.executeSql(createTableSQL);
    console.log('Vector database initialized successfully.');
  } catch (error) {
    console.error('Failed to initialize vector database:', error);
    throw error;
  }
};
