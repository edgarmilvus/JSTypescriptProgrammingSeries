/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

import { Database } from 'react-native-sqlite-storage';
import { DocumentChunk } from './Exercise1'; // Assuming interface is imported

// 1. Mock Embedding Function
// Simulates an API call or local model inference with latency
export const generateEmbedding = async (text: string): Promise<Float32Array> => {
  // Simulate network/processing delay (e.g., 100ms)
  await new Promise(resolve => setTimeout(resolve, 100));
  
  // Generate a random vector of size 1536 (standard for many embedding models)
  const vectorSize = 1536;
  const embedding = new Float32Array(vectorSize);
  
  for (let i = 0; i < vectorSize; i++) {
    embedding[i] = Math.random(); // Random values between 0 and 1
  }
  
  return embedding;
};

// Helper to serialize Float32Array to a string format for SQLite
// Many vector extensions accept a string like "[0.1, 0.2, ...]" or a binary blob.
// We will use a JSON string representation for simplicity here.
const serializeEmbedding = (embedding: Float32Array): string => {
  return JSON.stringify(Array.from(embedding));
};

// 2. Batch Insertion with Transaction
export const ingestDocuments = async (
  db: Database, 
  documents: Array<{ content: string }>
): Promise<void> => {
  const insertSQL = `
    INSERT INTO document_chunks (content, embedding, metadata) 
    VALUES (?, ?, ?)
  `;

  // Start a transaction
  await db.transaction(async (tx) => {
    for (const doc of documents) {
      try {
        // Generate embedding
        const embedding = await generateEmbedding(doc.content);
        
        // Serialize embedding
        const embeddingString = serializeEmbedding(embedding);
        
        // Execute insert
        await tx.executeSql(
          insertSQL,
          [doc.content, embeddingString, JSON.stringify({ source: 'manual_ingest' })]
        );
        
        console.log(`Inserted document: ${doc.content.substring(0, 20)}...`);
      } catch (error) {
        console.error('Error inserting document, rolling back:', error);
        // Transaction will automatically rollback if an error is thrown here
        throw error; 
      }
    }
  });
};
