/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

import { Database } from 'react-native-sqlite-storage';
import { generateEmbedding } from './Exercise2'; // Reuse embedding logic

// 1. & 2. Search Function and SQL Query
export const semanticSearch = async (
  db: Database,
  query: string,
  k: number = 3
): Promise<Array<{ content: string; distance: number }>> => {
  try {
    // 1. Generate query vector
    const queryVector = await generateEmbedding(query);
    const queryVectorString = JSON.stringify(Array.from(queryVector));

    // 2. Construct SQL Query
    // Note: The function name for distance calculation depends on the extension.
    // Common names are 'vector_distance', 'cosine_similarity', or operators like <->.
    // We assume a function `vector_distance(a, b)` returns a float.
    // We order by distance ASC (lower distance = more similar).
    const searchSQL = `
      SELECT content, vector_distance(embedding, ?) as distance
      FROM document_chunks
      ORDER BY distance ASC
      LIMIT ?
    `;

    // 3. Execute Query
    const [results] = await db.executeSql(searchSQL, [queryVectorString, k]);
    
    // 4. Format Results
    const formattedResults = [];
    const rows = results.rows;
    for (let i = 0; i < rows.length; i++) {
      const row = rows.item(i);
      formattedResults.push({
        content: row.content,
        distance: row.distance,
      });
    }

    return formattedResults;
  } catch (error) {
    console.error('Search failed:', error);
    return [];
  }
};
