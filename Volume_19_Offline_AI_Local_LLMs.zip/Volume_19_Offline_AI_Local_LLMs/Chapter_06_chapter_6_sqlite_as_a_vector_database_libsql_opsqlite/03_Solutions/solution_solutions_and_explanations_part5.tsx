/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState, useMemo } from 'react';
import { View, Text, Button, Slider, StyleSheet, Dimensions } from 'react-native';

// 1. Vector Generation
const generate2DVector = () => ({
  x: Math.random() * 2 - 1, // Range -1 to 1
  y: Math.random() * 2 - 1,
});

// 2. Distance Calculations
const calculateEuclidean = (v1: {x: number, y: number}, v2: {x: number, y: number}) => {
  return Math.sqrt(Math.pow(v2.x - v1.x, 2) + Math.pow(v2.y - v1.y, 2));
};

const calculateDotProduct = (v1: {x: number, y: number}, v2: {x: number, y: number}) => {
  return v1.x * v2.x + v1.y * v2.y;
};

const calculateMagnitude = (v: {x: number, y: number}) => {
  return Math.sqrt(v.x * v.x + v.y * v.y);
};

const calculateCosineSimilarity = (v1: {x: number, y: number}, v2: {x: number, y: number}) => {
  const dot = calculateDotProduct(v1, v2);
  const mag1 = calculateMagnitude(v1);
  const mag2 = calculateMagnitude(v2);
  if (mag1 === 0 || mag2 === 0) return 0;
  return dot / (mag1 * mag2);
};

export const VectorSandbox = () => {
  const [vec1, setVec1] = useState(generate2DVector());
  const [vec2, setVec2] = useState(generate2DVector());
  const [magnitude, setMagnitude] = useState(1.0); // Slider for magnitude

  // 3. Visualization Configuration
  const canvasSize = 300;
  const center = canvasSize / 2;
  const scale = 80; // Pixels per unit

  // Calculate metrics whenever vectors or magnitude change
  const metrics = useMemo(() => {
    // Apply magnitude scaling to vec2 for interaction
    const scaledVec2 = { x: vec2.x * magnitude, y: vec2.y * magnitude };
    
    return {
      euclidean: calculateEuclidean(vec1, scaledVec2),
      dotProduct: calculateDotProduct(vec1, scaledVec2),
      cosine: calculateCosineSimilarity(vec1, scaledVec2),
      scaledVec2
    };
  }, [vec1, vec2, magnitude]);

  // 4. Interactive Controls
  const randomize = () => {
    setVec1(generate2DVector());
    setVec2(generate2DVector());
  };

  // Helper to map cartesian to SVG coordinates (y is inverted in SVG)
  const toScreen = (v: {x: number, y: number}) => ({
    x: center + v.x * scale,
    y: center - v.y * scale
  });

  const p1 = toScreen(vec1);
  const p2 = toScreen(metrics.scaledVec2);

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Vector Math Sandbox</Text>
      
      {/* SVG Visualization */}
      <View style={styles.canvasContainer}>
        <Text>Origin (0,0) is center</Text>
        <View style={[styles.canvas, { width: canvasSize, height: canvasSize }]}>
           {/* Coordinate System Lines */}
           <View style={styles.axis} />
           <View style={[styles.axis, { transform: [{ rotate: '90deg'}] }]} />
           
           {/* Vector 1 (Blue) */}
           <View style={[styles.vectorLine, { 
             width: Math.sqrt(Math.pow(p1.x - center, 2) + Math.pow(p1.y - center, 2)),
             transform: [{ rotate: `${Math.atan2(center - p1.y, p1.x - center)}rad` }, { translateX: 0 }] 
           }]} />
           <View style={[styles.vectorHead, { left: p1.x - 4, top: p1.y - 4, backgroundColor: 'blue' }]} />

           {/* Vector 2 (Red - Scaled) */}
           <View style={[styles.vectorLine, { 
             width: Math.sqrt(Math.pow(p2.x - center, 2) + Math.pow(p2.y - center, 2)),
             transform: [{ rotate: `${Math.atan2(center - p2.y, p2.x - center)}rad` }, { translateX: 0 }] 
           }]} />
           <View style={[styles.vectorHead, { left: p2.x - 4, top: p2.y - 4, backgroundColor: 'red' }]} />
        </View>
      </View>

      {/* Metrics Display */}
      <View style={styles.metrics}>
        <Text style={styles.metricText}>Euclidean Dist: {metrics.euclidean.toFixed(3)}</Text>
        <Text style={styles.metricText}>Dot Product: {metrics.dotProduct.toFixed(3)}</Text>
        <Text style={styles.metricText}>Cosine Similarity: {metrics.cosine.toFixed(3)}</Text>
      </View>

      {/* Controls */}
      <View style={styles.controls}>
        <Button title="Randomize Vectors" onPress={randomize} />
        <Text style={styles.sliderLabel}>Magnitude of Red Vector: {magnitude.toFixed(2)}</Text>
        <Slider
          minimumValue={0.1}
          maximumValue={3.0}
          step={0.1}
          value={magnitude}
          onValueChange={setMagnitude}
        />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, padding: 20, backgroundColor: '#fff' },
  title: { fontSize: 20, fontWeight: 'bold', marginBottom: 10, textAlign: 'center' },
  canvasContainer: { alignItems: 'center', marginBottom: 20 },
  canvas: { borderWidth: 1, borderColor: '#ddd', position: 'relative' },
  axis: { position: 'absolute', width: 1, height: '100%', backgroundColor: '#eee', left: '50%', top: 0 },
  vectorLine: { position: 'absolute', height: 2, backgroundColor: '#555', left: '50%', top: '50%', transformOrigin: 'left center' },
  vectorHead: { position: 'absolute', width: 8, height: 8, borderRadius: 4 },
  metrics: { marginBottom: 20 },
  metricText: { fontSize: 16, marginVertical: 4, fontFamily: 'monospace' },
  controls: { gap: 10 },
  sliderLabel: { marginTop: 10, textAlign: 'center' }
});

export default VectorSandbox;
