/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

// file: embedding-demo.ts

/**
 * Imports the necessary pipeline function from Transformers.js.
 * In a real project, you would install the library via npm:
 * `npm install @xenova/transformers`
 */
import { pipeline, env, FeatureExtractionPipeline } from '@xenova/transformers';

/**
 * CONFIGURATION
 * We explicitly set the WASM paths to ensure the ONNX runtime
 * can locate the necessary binaries in a browser environment.
 * This is a critical step often missed in basic setups.
 */
env.wasm.wasmPaths = 'https://cdn.jsdelivr.net/npm/@xenova/transformers@2.17.2/dist/';

/**
 * Generates embeddings for a given text string using an on-device model.
 * 
 * @param text - The input string to be vectorized.
 * @returns A Promise that resolves to a Float32Array representing the embedding vector.
 */
async function generateEmbedding(text: string): Promise<Float32Array> {
    console.log(`[1] Starting embedding generation for: "${text}"`);

    // Step 1: Initialize the pipeline
    // We use 'feature-extraction' to get embeddings.
    // 'Xenova/all-MiniLM-L6-v2' is chosen for its small size (~80MB) and speed,
    // making it ideal for mobile/web constraints.
    console.log('[2] Loading model...');
    
    let extractor: FeatureExtractionPipeline;
    try {
        extractor = await pipeline('feature-extraction', 'Xenova/all-MiniLM-L6-v2', {
            quantized: true, // Use quantized model for smaller file size
            progress_callback: (data) => {
                // Optional: Log download progress
                if (data.status === 'progress') {
                    console.log(`Downloading: ${data.file}%`);
                }
            }
        });
    } catch (error) {
        console.error("Failed to load model:", error);
        throw new Error("Model loading failed. Check network connection and console.");
    }

    // Step 2: Process the text
    // The extractor returns a Tensor object. We request a Float32Array
    // for easier manipulation in vector databases.
    console.log('[3] Processing text...');
    const output = await extractor(text, {
        pooling: 'mean', // Averages token embeddings to get a single sentence vector
        normalize: true, // Normalizes the vector to unit length (crucial for cosine similarity)
        return_tensor: false // Returns a standard JS array/Float32Array instead of a Tensor object
    }) as Float32Array;

    console.log(`[4] Embedding generated. Dimensions: ${output.length}`);
    return output;
}

/**
 * MAIN EXECUTION BLOCK
 * (Simulating a button click event in a web app)
 */
(async () => {
    const inputText = "Offline AI enables private data processing.";
    
    try {
        const embeddingVector = await generateEmbedding(inputText);
        
        // Displaying the result (truncated for readability)
        console.log("Result Vector (first 5 dims):", embeddingVector.slice(0, 5));
        console.log("Result Vector (last 5 dims):", embeddingVector.slice(-5));
        
        // In a real SaaS app, this vector would be passed to a local vector store
        // e.g., await localVectorStore.add(embeddingVector);
        
    } catch (error) {
        console.error("Execution failed:", error);
    }
})();
