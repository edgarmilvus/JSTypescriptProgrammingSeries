/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.tsx
// Description: Advanced Application Script
// ==========================================

import React, { useState, useEffect, useCallback } from 'react';

// -----------------------------------------------------------------------------
// 1. TYPE DEFINITIONS & CONFIGURATION
// -----------------------------------------------------------------------------

/**
 * Represents a single document in our local database.
 * In a real app, this might be fetched from IndexedDB or a local JSON file.
 */
interface LocalDocument {
  id: string;
  content: string;
  embedding?: Float32Array; // The pre-computed vector
}

/**
 * Configuration for the Transformers.js model.
 * We use 'Xenova/all-MiniLM-L6-v2' because it's small (approx 80MB) 
 * and highly efficient for browser-based semantic search.
 */
const MODEL_CONFIG = {
  model: 'Xenova/all-MiniLM-L6-v2',
  quantized: true, // Use quantized model for faster download and lower memory usage
};

// -----------------------------------------------------------------------------
// 2. MOCK DATA STORE (SIMULATING LOCAL DB)
// -----------------------------------------------------------------------------

const LOCAL_DOCUMENTS: LocalDocument[] = [
  { id: '1', content: 'React is a JavaScript library for building user interfaces.' },
  { id: '2', content: 'TypeScript adds static types to JavaScript.' },
  { id: '3', content: 'Next.js is a framework for server-rendered React applications.' },
  { id: '4', content: 'Transformers.js enables running ML models in the browser.' },
  { id: '5', content: 'CSS is used for styling web pages.' },
];

// -----------------------------------------------------------------------------
// 3. DYNAMIC IMPORT FOR SERVER-SIDE EXCLUSION
// -----------------------------------------------------------------------------

/**
 * We dynamically import 'transformers' only on the client side.
 * Server-side rendering (SSR) is disabled for this page to avoid 
 * Node.js compatibility issues with the browser-specific library.
 */
const loadTransformers = async () => {
  // @ts-ignore - Library type definitions might vary based on version
  const { pipeline, env } = await import('@xenova/transformers');
  
  // Configure environment to use local models and avoid CORS issues
  env.allowLocalModels = true;
  env.useBrowserCache = true;
  
  return { pipeline };
};

// -----------------------------------------------------------------------------
// 4. REACT COMPONENT
// -----------------------------------------------------------------------------

export default function OfflineSemanticSearch() {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<Array<{ id: string; score: number; content: string }>>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isGenerating, setIsGenerating] = useState(false);
  const [error, setError] = useState<string | null>(null);
  
  // References to hold the loaded feature extraction pipeline
  const featureExtractorRef = React.useRef<any>(null);

  // -------------------------------------------------------------------------
  // 4.1 INITIALIZATION (MOUNTING)
  // -------------------------------------------------------------------------

  useEffect(() => {
    const initModel = async () => {
      try {
        setIsLoading(true);
        const { pipeline } = await loadTransformers();
        
        // Initialize the feature extractor (embedding generator)
        // 'feature-extraction' task returns the vector representation of text
        featureExtractorRef.current = await pipeline(
          'feature-extraction', 
          MODEL_CONFIG.model,
          { 
            quantized: MODEL_CONFIG.quantized,
            progress_callback: (event: any) => {
              // Optional: Hook into download progress here
              console.log('Model loading:', event.status);
            }
          }
        );

        // Pre-compute embeddings for our local documents (One-time cost)
        // In a real app, you would save these vectors to IndexedDB.
        await precomputeDocumentEmbeddings();

        setIsLoading(false);
      } catch (err) {
        console.error(err);
        setError('Failed to load AI model. Please check your internet connection.');
        setIsLoading(false);
      }
    };

    initModel();

    // Cleanup function to free up memory if component unmounts
    return () => {
      featureExtractorRef.current = null;
    };
  }, []);

  // -------------------------------------------------------------------------
  // 4.2 EMBEDDING GENERATION LOGIC
  // -------------------------------------------------------------------------

  /**
   * Generates a vector embedding for a given text string using the loaded model.
   * 
   * @param text - The input string to vectorize.
   * @returns A Promise resolving to a Float32Array (the embedding vector).
   */
  const generateEmbedding = async (text: string): Promise<Float32Array> => {
    if (!featureExtractorRef.current) {
      throw new Error('Model not loaded yet.');
    }

    // The pipeline returns a Tensor. We need to extract the data.
    // 'all-MiniLM-L6-v2' returns a 384-dimensional vector.
    const output = await featureExtractorRef.current(text, {
      pooling: 'mean', // Averages token embeddings to get a sentence embedding
      normalize: true,  // Normalizes the vector to unit length for cosine similarity
    });

    return output.data;
  };

  /**
   * Pre-computes embeddings for all documents in the local store.
   * This simulates an offline indexing process.
   */
  const precomputeDocumentEmbeddings = async () => {
    for (const doc of LOCAL_DOCUMENTS) {
      if (!doc.embedding) {
        doc.embedding = await generateEmbedding(doc.content);
      }
    }
  };

  // -------------------------------------------------------------------------
  // 4.3 SEARCH & SIMILARITY LOGIC
  // -------------------------------------------------------------------------

  /**
   * Calculates the Cosine Similarity between two vectors.
   * Formula: (A . B) / (||A|| * ||B||)
   * Note: Since our vectors are normalized (length 1), this simplifies to dot product.
   * 
   * @param vecA - The query vector.
   * @param vecB - The document vector.
   * @returns A number between -1 and 1 (1 = identical meaning).
   */
  const cosineSimilarity = (vecA: Float32Array, vecB: Float32Array): number => {
    let dotProduct = 0;
    for (let i = 0; i < vecA.length; i++) {
      dotProduct += vecA[i] * vecB[i];
    }
    // Since vectors are normalized, we don't need to divide by magnitudes
    return dotProduct;
  };

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!query.trim()) return;

    setIsGenerating(true);
    setResults([]);

    try {
      // 1. Generate embedding for the user query
      const queryEmbedding = await generateEmbedding(query);

      // 2. Compare against local documents
      const scoredResults = LOCAL_DOCUMENTS.map((doc) => {
        if (!doc.embedding) return { id: doc.id, score: 0, content: doc.content };
        
        const score = cosineSimilarity(queryEmbedding, doc.embedding);
        return {
          id: doc.id,
          content: doc.content,
          score: score,
        };
      });

      // 3. Filter and Sort (Descending order)
      const sortedResults = scoredResults
        .filter((r) => r.score > 0.3) // Threshold to filter out irrelevant results
        .sort((a, b) => b.score - a.score);

      setResults(sortedResults);
    } catch (err) {
      console.error('Search failed:', err);
      setError('Search failed. Ensure the model is loaded.');
    } finally {
      setIsGenerating(false);
    }
  };

  // -------------------------------------------------------------------------
  // 4.4 UI RENDERING
  // -------------------------------------------------------------------------

  return (
    <div style={{ fontFamily: 'system-ui, sans-serif', maxWidth: '800px', margin: '0 auto', padding: '20px' }}>
      <h1>Offline Semantic Search</h1>
      
      <div style={{ marginBottom: '20px', padding: '10px', background: '#f0f0f0', borderRadius: '4px' }}>
        <strong>Status: </strong>
        {isLoading ? 'Loading AI Model (this happens once)...' : 'Ready (Model loaded in browser)'}
      </div>

      <form onSubmit={handleSearch} style={{ display: 'flex', gap: '10px', marginBottom: '20px' }}>
        <input
          type="text"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Ask a question (e.g., 'React vs CSS')..."
          disabled={isLoading || isGenerating}
          style={{ flex: 1, padding: '10px', fontSize: '16px' }}
        />
        <button 
          type="submit" 
          disabled={isLoading || isGenerating || !query}
          style={{ padding: '10px 20px', cursor: 'pointer' }}
        >
          {isGenerating ? 'Searching...' : 'Search'}
        </button>
      </form>

      {error && <p style={{ color: 'red' }}>{error}</p>}

      <div>
        <h3>Results (Local & Private):</h3>
        {results.length === 0 && !isGenerating && <p>No results found. Try a different query.</p>}
        
        <ul style={{ listStyle: 'none', padding: 0 }}>
          {results.map((result) => (
            <li key={result.id} style={{ marginBottom: '15px', border: '1px solid #ddd', padding: '10px', borderRadius: '4px' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                <span style={{ fontWeight: 'bold' }}>Score: {result.score.toFixed(4)}</span>
                <span style={{ color: '#888' }}>ID: {result.id}</span>
              </div>
              <p style={{ marginTop: '5px' }}>{result.content}</p>
            </li>
          ))}
        </ul>
      </div>

      <div style={{ marginTop: '40px', fontSize: '12px', color: '#666' }}>
        <h4>Under the Hood:</h4>
        <ul>
          <li><strong>Model:</strong> {MODEL_CONFIG.model}</li>
          <li><strong>Vector Dimension:</strong> 384</li>
          <li><strong>Processing:</strong> Client-side (No data sent to server)</li>
          <li><strong>Similarity Metric:</strong> Cosine Similarity</li>
        </ul>
      </div>
    </div>
  );
}
