/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// types.ts
export type EmbeddingVector = number[];

export interface EmbeddingModel {
    tokenizer: any; // Reference to the Transformers.js tokenizer
    model: any;     // Reference to the ONNX model
}

// embeddingUtility.ts
import { pipeline, env } from '@xenova/transformers';

// Configuration to allow local usage
env.allowLocalModels = true;
env.allowRemoteModels = true; // Set to false if strictly local
env.useBrowserCache = true;

let activeModel: EmbeddingModel | null = null;

export async function initializeEmbeddingModel(modelName: string = 'Xenova/all-MiniLM-L6-v2'): Promise<EmbeddingModel> {
    if (activeModel) {
        console.log('Reusing existing model instance.');
        return activeModel;
    }

    try {
        console.log(`Loading model: ${modelName}...`);
        // Initialize the feature extraction pipeline
        const extractor = await pipeline('feature-extraction', modelName);
        
        // Transformers.js pipeline returns an object containing tokenizer and model
        activeModel = {
            tokenizer: extractor.tokenizer,
            model: extractor.model
        };
        
        console.log('Model loaded successfully.');
        return activeModel;
    } catch (error) {
        console.error('Error loading model:', error);
        throw error;
    }
}

export async function generateEmbedding(model: EmbeddingModel, text: string): Promise<EmbeddingVector> {
    if (!model || !model.tokenizer || !model.model) {
        throw new Error('Model not initialized. Call initializeEmbeddingModel first.');
    }

    // 1. Tokenize
    const inputs = await model.tokenizer(text, { 
        padding: true, 
        truncation: true 
    });

    // 2. Inference
    // Note: Transformers.js pipeline handles the tensor creation and disposal internally usually,
    // but when accessing the model directly, we might need to manage tensors.
    // However, the high-level pipeline API is safer. 
    // To stick to the interface defined, we simulate the pipeline behavior manually or use the internal model.
    
    // Using the model directly (lower level)
    const output = await model.model(inputs);
    
    // 3. Mean Pooling
    // output is a Tensor. We need to calculate mean along the sequence length dimension (dim 1)
    // Assuming output.dims is [batchSize, sequenceLength, hiddenSize]
    const data = output.data; // Float32Array
    const dims = output.dims;
    const batchSize = dims[0];
    const seqLen = dims[1];
    const hiddenSize = dims[2];

    // Since we process one text at a time, batchSize is 1
    const embedding: number[] = new Array(hiddenSize).fill(0);
    
    // Sum over sequence length
    for (let i = 0; i < seqLen; i++) {
        for (let j = 0; j < hiddenSize; j++) {
            embedding[j] += data[i * hiddenSize + j];
        }
    }
    
    // Divide by sequence length (Mean Pooling)
    for (let j = 0; j < hiddenSize; j++) {
        embedding[j] /= seqLen;
    }

    // 4. Normalize (L2 Norm)
    const norm = Math.sqrt(embedding.reduce((sum, val) => sum + val * val, 0));
    const normalizedEmbedding = embedding.map(val => val / norm);

    // Clean up the tensor to free GPU memory immediately
    output.dispose();

    return normalizedEmbedding;
}

export function disposeModel(model: EmbeddingModel): void {
    if (model) {
        console.log('Disposing model and tokenizer...');
        // Dispose the model (frees WASM/GPU memory)
        if (model.model) model.model.dispose();
        // Dispose the tokenizer (frees memory)
        if (model.tokenizer) model.tokenizer.dispose();
        
        activeModel = null;
        console.log('Memory cleared.');
    }
}
