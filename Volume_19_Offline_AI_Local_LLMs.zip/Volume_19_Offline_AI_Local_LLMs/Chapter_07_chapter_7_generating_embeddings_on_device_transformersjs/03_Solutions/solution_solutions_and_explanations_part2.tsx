/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.tsx
// Description: Solutions and Explanations
// ==========================================

// SmartSearch.tsx
import React, { useState, useEffect, useMemo } from 'react';
import { initializeEmbeddingModel, generateEmbedding, EmbeddingVector } from './embeddingUtility';

// Cosine Similarity Implementation
const cosineSimilarity = (vecA: number[], vecB: number[]): number => {
    if (vecA.length !== vecB.length) return 0;
    let dotProduct = 0;
    let normA = 0;
    let normB = 0;
    for (let i = 0; i < vecA.length; i++) {
        dotProduct += vecA[i] * vecB[i];
        normA += vecA[i] * vecA[i];
        normB += vecB[i] * vecB[i];
    }
    if (normA === 0 || normB === 0) return 0;
    return dotProduct / (Math.sqrt(normA) * Math.sqrt(normB));
};

const documents = [
    "The quick brown fox jumps over the lazy dog.",
    "Artificial Intelligence is transforming the mobile landscape.",
    "Local LLMs allow for private data processing.",
    "Vector databases are essential for semantic search."
];

export const SmartSearch: React.FC = () => {
    const [query, setQuery] = useState('');
    const [results, setResults] = useState<{ text: string; score: number }[]>([]);
    const [isLoading, setIsLoading] = useState(false);
    const [model, setModel] = useState<any>(null);
    const [docEmbeddings, setDocEmbeddings] = useState<{ text: string; embedding: EmbeddingVector }[]>([]);

    // Initialize model and pre-compute document embeddings on mount
    useEffect(() => {
        const init = async () => {
            setIsLoading(true);
            try {
                const loadedModel = await initializeEmbeddingModel();
                setModel(loadedModel);

                // Pre-compute embeddings for the static dataset
                const embeddings = await Promise.all(
                    documents.map(async (doc) => {
                        const emb = await generateEmbedding(loadedModel, doc);
                        return { text: doc, embedding: emb };
                    })
                );
                setDocEmbeddings(embeddings);
            } catch (error) {
                console.error("Failed to load model", error);
            } finally {
                setIsLoading(false);
            }
        };
        init();
    }, []);

    // Debounce Logic
    useEffect(() => {
        if (!query.trim() || !model) {
            setResults([]); // Clear results if empty
            return;
        }

        const handler = setTimeout(async () => {
            setIsLoading(true);
            try {
                // Generate embedding for the query
                const queryEmbedding = await generateEmbedding(model, query);

                // Calculate similarity against all docs
                const similarities = docEmbeddings.map(doc => ({
                    text: doc.text,
                    score: cosineSimilarity(queryEmbedding, doc.embedding)
                }));

                // Sort descending and take top 3
                const sorted = similarities.sort((a, b) => b.score - a.score).slice(0, 3);
                setResults(sorted);
            } catch (e) {
                console.error(e);
            } finally {
                setIsLoading(false);
            }
        }, 500); // 500ms debounce

        return () => clearTimeout(handler);
    }, [query, model, docEmbeddings]);

    return (
        <div style={{ padding: '20px', fontFamily: 'sans-serif' }}>
            <h2>Semantic Search</h2>
            <input
                type="text"
                placeholder="Search semantically (e.g., 'canine companion')..."
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                style={{ width: '100%', padding: '10px', fontSize: '16px' }}
            />
            
            {isLoading && <p style={{ color: 'gray' }}>Processing...</p>}
            
            <ul>
                {results.map((res, idx) => (
                    <li key={idx} style={{ margin: '10px 0', padding: '10px', border: '1px solid #ddd' }}>
                        <strong>Score: {res.score.toFixed(4)}</strong><br />
                        {res.text}
                    </li>
                ))}
            </ul>
            
            {!query && !isLoading && (
                <div>
                    <p>Start typing to search. Showing all documents initially.</p>
                    {docEmbeddings.map((doc, idx) => (
                        <li key={idx}>{doc.text}</li>
                    ))}
                </div>
            )}
        </div>
    );
};
