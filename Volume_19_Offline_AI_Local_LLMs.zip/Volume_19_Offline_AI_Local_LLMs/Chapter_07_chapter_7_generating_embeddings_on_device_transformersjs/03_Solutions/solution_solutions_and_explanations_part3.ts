/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

// reactAgent.ts
import { generateEmbedding } from './embeddingUtility'; // Assuming imported
import { LocalVectorStore } from './localVectorStore'; // Assuming imported from Ex 5

interface ReActStep {
    thought: string;
    action: 'answer' | 'search';
    observation?: string;
    finalAnswer?: string;
}

// Mock Vector Store for this exercise
const mockVectorStore = [
    { text: "Local AI runs on-device using ONNX.", embedding: [0.1, 0.2, 0.9] }, // Mock embeddings
    { text: "Transformers.js enables browser inference.", embedding: [0.1, 0.3, 0.8] }
];

// Simulated LLM Logic (since we can't run a full LLM in this snippet)
// In a real app, this would be a prompt to a local model like Phi-3 or Gemma
async function simulateLLM(prompt: string): Promise<{ thought: string; action: 'answer' | 'search' }> {
    // Simple rule-based logic for the exercise
    // Real implementation would parse JSON from model output
    if (prompt.includes("2+2") || prompt.includes("capital of France")) {
        return { thought: "This is a simple factual question I know.", action: "answer" };
    }
    return { thought: "I need specific context from the user's documents.", action: "search" };
}

async function simulateFinalAnswer(context: string, question: string): Promise<string> {
    // Simulates generating a final response based on context
    return `Based on the retrieved context: ${context}, the answer is generated.`;
}

export async function runReActLoop(userQuestion: string): Promise<ReActStep> {
    // Step 1: Initial Thought & Action Decision
    const initialDecision = await simulateLLM(userQuestion);
    
    if (initialDecision.action === 'answer') {
        return {
            thought: initialDecision.thought,
            action: 'answer',
            finalAnswer: "The answer is 4." // Hardcoded for demo
        };
    }

    // Step 2: Action (Search)
    // In a real scenario, we would generate an embedding for the question here
    // const queryEmbedding = await generateEmbedding(model, userQuestion);
    
    // Simulate retrieval
    const observation = mockVectorStore.map(item => item.text).join(', ');
    
    // Step 3: Final Reasoning with Observation
    const finalAnswer = await simulateFinalAnswer(observation, userQuestion);

    return {
        thought: initialDecision.thought,
        action: 'search',
        observation: `Retrieved: ${observation}`,
        finalAnswer: finalAnswer
    };
}
