/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.tsx
// Description: Solutions and Explanations
// ==========================================

// ReActChat.tsx
import React, { useState } from 'react';
import { runReActLoop } from './reactAgent';

export const ReActChat: React.FC = () => {
    const [input, setInput] = useState('');
    const [history, setHistory] = useState<any[]>([]);

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!input) return;

        // Add user message
        const userMsg = { type: 'user', text: input };
        setHistory(prev => [...prev, userMsg]);

        // Run Agent
        const step = await runReActLoop(input);

        // Visualize steps
        setHistory(prev => [
            ...prev,
            { type: 'agent-thought', text: `🤔 Thought: ${step.thought}` },
            { type: 'agent-action', text: `🔍 Action: ${step.action}` },
            ...(step.observation ? [{ type: 'agent-obs', text: `👁️ Observation: ${step.observation}` }] : []),
            { type: 'agent-final', text: `🤖 Final: ${step.finalAnswer}` }
        ]);
        
        setInput('');
    };

    return (
        <div style={{ padding: '20px', maxWidth: '600px', margin: '0 auto' }}>
            <div style={{ border: '1px solid #ccc', padding: '10px', height: '400px', overflowY: 'auto' }}>
                {history.map((msg, idx) => (
                    <div key={idx} style={{ marginBottom: '10px', color: msg.type === 'user' ? 'blue' : 'black' }}>
                        <strong>{msg.type === 'user' ? 'You: ' : ''}</strong>
                        {msg.text}
                    </div>
                ))}
            </div>
            <form onSubmit={handleSubmit} style={{ marginTop: '10px', display: 'flex' }}>
                <input
                    type="text"
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    style={{ flexGrow: 1, padding: '8px' }}
                    placeholder="Ask a question..."
                />
                <button type="submit" style={{ padding: '8px 16px' }}>Send</button>
            </form>
        </div>
    );
};
