/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

// batchProcessor.ts
export class BatchEmbeddingProcessor {
    private batchSize: number;
    private model: any;

    constructor(model: any, batchSize: number = 4) {
        this.model = model;
        this.batchSize = batchSize;
    }

    public async process(texts: string[]): Promise<number[][]> {
        const results: number[][] = [];
        
        // 1. Chunking
        for (let i = 0; i < texts.length; i += this.batchSize) {
            const batch = texts.slice(i, i + this.batchSize);
            
            // 2. Batch Tokenization & Inference
            // Transformers.js pipeline handles batching automatically if input is an array
            // However, manual tensor management ensures no memory leaks
            try {
                // We use the tokenizer to create inputs for the batch
                const inputs = await this.model.tokenizer(batch, {
                    padding: true,
                    truncation: true,
                    return_tensors: 'pt' // or 'np' depending on backend
                });

                // Run inference on the batch
                const output = await this.model.model(inputs);
                
                // 3. Post-processing (Mean Pooling for the batch)
                // Output dims: [batchSize, seqLen, hiddenSize]
                const batchSizeActual = output.dims[0];
                const hiddenSize = output.dims[2];
                const data = output.data;

                for (let b = 0; b < batchSizeActual; b++) {
                    const embedding: number[] = new Array(hiddenSize).fill(0);
                    // Calculate mean for this item in the batch
                    // Note: We need to know the actual sequence length per item if using padding
                    // For simplicity, we assume averaging over the whole sequence length (padded zeros don't hurt much in mean pooling for short texts, or we can use attention_mask)
                    const seqLen = output.dims[1]; 
                    
                    for (let s = 0; s < seqLen; s++) {
                        for (let h = 0; h < hiddenSize; h++) {
                            // Index calculation: (batch_index * seqLen + seq_index) * hiddenSize + hidden_index
                            const index = (b * seqLen + s) * hiddenSize + h;
                            embedding[h] += data[index];
                        }
                    }

                    // Normalize
                    const norm = Math.sqrt(embedding.reduce((sum, val) => sum + val * val, 0));
                    const normalized = embedding.map(v => v / norm);
                    results.push(normalized);
                }

                // 4. Memory Cleanup
                // Dispose inputs and output immediately after processing the batch
                output.dispose();
                // Depending on the tokenizer version, inputs might need disposal too
                if (inputs.input_ids) inputs.input_ids.dispose();
                if (inputs.attention_mask) inputs.attention_mask.dispose();

            } catch (error) {
                console.error(`Error processing batch ${i / this.batchSize}:`, error);
            }
        }
        return results;
    }
}
