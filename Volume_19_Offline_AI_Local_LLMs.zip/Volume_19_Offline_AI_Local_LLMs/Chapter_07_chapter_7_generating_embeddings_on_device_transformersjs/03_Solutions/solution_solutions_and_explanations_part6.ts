/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part6.ts
// Description: Solutions and Explanations
// ==========================================

digraph BatchPipeline {
    rankdir=TB;
    node [shape=box, style=rounded, filled, fontname="Arial", fontsize=10];
    
    // Nodes
    Input [label="Raw Text Inputs\n(Array of Strings)", fillcolor="#e1f5fe"];
    Queue [label="Input Queue\n(FIFO Buffer)", fillcolor="#fff3e0"];
    Tokenizer [label="Batch Tokenization\n(Padding/Truncation)", fillcolor="#e8f5e9"];
    Inference [label="ONNX Inference\n(Batch Size = 4)", fillcolor="#fce4ec"];
    PostProc [label="Post-Processing\n(Mean Pooling + Norm)", fillcolor="#f3e5f5"];
    Cleanup [label="Tensor Disposal\n(GPU Memory Free)", fillcolor="#ffebee"];
    Output [label="Final Embeddings\n(Array of Vectors)", fillcolor="#e0f2f1"];

    // Edges
    Input -> Queue [label="Chunking"];
    Queue -> Tokenizer [label="Batch of 4"];
    Tokenizer -> Inference [label="Token IDs"];
    Inference -> PostProc [label="Raw Tensors"];
    PostProc -> Cleanup [label="Extract Data"];
    Cleanup -> Output [label="Result"];

    // Visual emphasis on constraints
    Inference -> Inference [label="Parallel (WebGL)" style=dashed dir=none];
    Cleanup -> Cleanup [label="Loop until empty" style=dashed dir=none];
}
