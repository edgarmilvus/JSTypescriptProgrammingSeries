/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part7.ts
// Description: Solutions and Explanations
// ==========================================

// localVectorStore.ts
interface StoredItem {
    id: string;
    text: string;
    embedding: number[];
}

// Helper for Cosine Similarity
const cosineSimilarity = (vecA: number[], vecB: number[]): number => {
    let dotProduct = 0, normA = 0, normB = 0;
    for (let i = 0; i < vecA.length; i++) {
        dotProduct += vecA[i] * vecB[i];
        normA += vecA[i] * vecA[i];
        normB += vecB[i] * vecB[i];
    }
    if (normA === 0 || normB === 0) return 0;
    return dotProduct / (Math.sqrt(normA) * Math.sqrt(normB));
};

export class LocalVectorStore {
    private store: StoredItem[] = [];
    private storageKey = 'vector_store_db';

    constructor() {
        this.loadFromStorage();
    }

    public async addDocument(text: string, embedding: number[]): Promise<void> {
        const item: StoredItem = {
            id: crypto.randomUUID(),
            text: text,
            embedding: embedding
        };
        this.store.push(item);
        this.saveToStorage();
    }

    public async search(queryEmbedding: number[], k: number = 3, keywordFilter?: string): Promise<StoredItem[]> {
        // 1. Calculate Similarity
        let candidates = this.store.map(item => ({
            ...item,
            score: cosineSimilarity(queryEmbedding, item.embedding)
        }));

        // 2. Hybrid Filter (Keyword)
        if (keywordFilter && keywordFilter.trim() !== '') {
            const term = keywordFilter.toLowerCase();
            candidates = candidates.filter(item => item.text.toLowerCase().includes(term));
        }

        // 3. Sort and Return Top K
        return candidates
            .sort((a, b) => b.score - a.score)
            .slice(0, k)
            .map(({ score, ...keep }) => keep); // Remove score from final return if not needed
    }

    private saveToStorage() {
        try {
            localStorage.setItem(this.storageKey, JSON.stringify(this.store));
        } catch (e) {
            console.error("LocalStorage quota exceeded", e);
        }
    }

    private loadFromStorage() {
        const data = localStorage.getItem(this.storageKey);
        if (data) {
            try {
                this.store = JSON.parse(data);
            } catch (e) {
                console.error("Failed to parse stored data", e);
                this.store = [];
            }
        }
    }
}
