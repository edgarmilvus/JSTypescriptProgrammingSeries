/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part8.tsx
// Description: Solutions and Explanations
// ==========================================

// DocumentManager.tsx
import React, { useState, useEffect } from 'react';
import { initializeEmbeddingModel, generateEmbedding } from './embeddingUtility';
import { LocalVectorStore } from './localVectorStore';

export const DocumentManager: React.FC = () => {
    const [inputText, setInputText] = useState('');
    const [searchTerm, setSearchTerm] = useState('');
    const [results, setResults] = useState<any[]>([]);
    const [model, setModel] = useState<any>(null);
    const [store] = useState(() => new LocalVectorStore());
    const [status, setStatus] = useState('Ready');

    // Initialize Model
    useEffect(() => {
        const init = async () => {
            setStatus('Loading Model...');
            const m = await initializeEmbeddingModel();
            setModel(m);
            setStatus('Ready');
        };
        init();
    }, []);

    const handleAddDocument = async () => {
        if (!inputText.trim() || !model) return;
        setStatus('Generating Embedding...');
        
        const embedding = await generateEmbedding(model, inputText);
        await store.addDocument(inputText, embedding);
        
        setStatus('Saved!');
        setInputText('');
        setTimeout(() => setStatus('Ready'), 1000);
    };

    const handleSearch = async () => {
        if (!searchTerm.trim() || !model) return;
        setStatus('Searching...');
        
        // Generate embedding for the search query
        const queryEmbedding = await generateEmbedding(model, searchTerm);
        
        // Perform Hybrid Search (Semantic + Keyword)
        // We pass the search term as the keyword filter
        const hits = await store.search(queryEmbedding, 5, searchTerm);
        
        setResults(hits);
        setStatus('Ready');
    };

    return (
        <div style={{ display: 'flex', height: '100vh', fontFamily: 'sans-serif' }}>
            {/* Left Panel: Input */}
            <div style={{ flex: 1, padding: '20px', borderRight: '1px solid #ccc' }}>
                <h3>Add Document</h3>
                <p style={{ fontSize: '12px', color: '#666' }}>Status: {status}</p>
                <textarea 
                    value={inputText} 
                    onChange={(e) => setInputText(e.target.value)}
                    style={{ width: '100%', height: '100px', marginBottom: '10px' }}
                    placeholder="Enter text to index..."
                />
                <button onClick={handleAddDocument} disabled={!model} style={{ width: '100%', padding: '10px' }}>
                    Add to Knowledge Base
                </button>
            </div>

            {/* Right Panel: Search */}
            <div style={{ flex: 1, padding: '20px' }}>
                <h3>Semantic Search</h3>
                <div style={{ display: 'flex', gap: '10px', marginBottom: '20px' }}>
                    <input 
                        type="text" 
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        style={{ flexGrow: 1, padding: '8px' }}
                        placeholder="Search semantically..."
                    />
                    <button onClick={handleSearch} disabled={!model} style={{ padding: '8px 16px' }}>Search</button>
                </div>

                <div>
                    <h4>Results</h4>
                    {results.length === 0 ? (
                        <p>No results found.</p>
                    ) : (
                        <ul>
                            {results.map((res, idx) => (
                                <li key={idx} style={{ marginBottom: '10px', padding: '10px', background: '#f9f9f9' }}>
                                    {res.text}
                                </li>
                            ))}
                        </ul>
                    )}
                </div>
            </div>
        </div>
    );
};
