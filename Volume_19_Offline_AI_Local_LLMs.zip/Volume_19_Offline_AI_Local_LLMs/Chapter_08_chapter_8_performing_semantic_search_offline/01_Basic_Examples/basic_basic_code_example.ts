/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * @fileoverview A 'Hello World' example of a local semantic search engine in TypeScript.
 * This simulates the process of generating embeddings, storing them in a local vector store,
 * and performing K-Nearest Neighbors (KNN) search using cosine similarity.
 */

// --- 1. Type Definitions ---

/**
 * Represents a single document chunk stored in our vector database.
 * @property id - A unique identifier for the chunk.
 * @property content - The raw text content of the chunk.
 * @property embedding - The vector representation of the content.
 */
type DocumentChunk = {
    id: string;
    content: string;
    embedding: number[];
};

/**
 * Represents the result of a similarity search.
 * @property chunk - The document chunk that matched the query.
 * @property score - The similarity score (e.g., cosine similarity).
 */
type SearchResult = {
    chunk: DocumentChunk;
    score: number;
};

// --- 2. Mock Services (Simulating Local LLM & pgvector) ---

/**
 * A mock embedding function.
 * In a real-world scenario, this would be a local Llama 3 model that converts
 * text into a high-dimensional vector (e.g., 384 or 768 dimensions).
 * Here, we simulate this by generating a deterministic pseudo-random vector
 * based on the input text's character codes.
 * @param text - The input text to embed.
 * @returns A number array representing the vector embedding.
 */
function generateEmbedding(text: string): number[] {
    // Simulate a 5-dimensional vector for simplicity in this example.
    const vectorSize = 5;
    const embedding: number[] = new Array(vectorSize).fill(0);

    // Create a deterministic "hash" from the text to generate a stable vector.
    let hash = 0;
    for (let i = 0; i < text.length; i++) {
        hash = text.charCodeAt(i) + ((hash << 5) - hash);
    }

    // Fill the vector with pseudo-random values based on the hash.
    for (let i = 0; i < vectorSize; i++) {
        // Use sine and bit-shifting to create varied but deterministic values.
        const val = Math.sin(hash + i * 123.45) * 10000;
        embedding[i] = val - Math.floor(val); // Normalize to [0, 1)
    }

    return embedding;
}

/**
 * A mock Vector Database class simulating a local pgvector store.
 * This class handles the storage and retrieval of document embeddings.
 */
class LocalVectorStore {
    private store: DocumentChunk[] = [];

    /**
     * Adds a new document chunk with its embedding to the store.
     * @param chunk - The document chunk to store.
     */
    public add(chunk: DocumentChunk): void {
        this.store.push(chunk);
        console.log(`[VectorStore] Added chunk with ID: ${chunk.id}`);
    }

    /**
     * Performs a K-Nearest Neighbors (KNN) search using Cosine Similarity.
     * @param queryEmbedding - The vector representation of the user's query.
     * @param k - The number of top results to return.
     * @returns A sorted array of search results.
     */
    public search(queryEmbedding: number[], k: number): SearchResult[] {
        const results: SearchResult[] = [];

        // Calculate similarity for each chunk in the store
        for (const chunk of this.store) {
            const score = this.cosineSimilarity(queryEmbedding, chunk.embedding);
            results.push({ chunk, score });
        }

        // Sort results by score in descending order (most similar first)
        results.sort((a, b) => b.score - a.score);

        // Return the top K results
        return results.slice(0, k);
    }

    /**
     * Calculates the cosine similarity between two vectors.
     * Cosine Similarity = (A . B) / (||A|| * ||B||)
     * It measures the cosine of the angle between two vectors, ranging from -1 to 1.
     * In text embedding, values are typically in [0, 1], where 1 means identical direction.
     * @param vecA - The first vector.
     * @param vecB - The second vector.
     * @returns The similarity score.
     */
    private cosineSimilarity(vecA: number[], vecB: number[]): number {
        if (vecA.length !== vecB.length) {
            throw new Error('Vectors must have the same dimension.');
        }

        let dotProduct = 0;
        let normA = 0;
        let normB = 0;

        for (let i = 0; i < vecA.length; i++) {
            dotProduct += vecA[i] * vecB[i];
            normA += vecA[i] * vecA[i];
            normB += vecB[i] * vecB[i];
        }

        if (normA === 0 || normB === 0) {
            return 0; // Avoid division by zero
        }

        return dotProduct / (Math.sqrt(normA) * Math.sqrt(normB));
    }
}

// --- 3. Main Application Logic ---

/**
 * The main function that orchestrates the semantic search process.
 * It simulates a web app's backend logic or a client-side search function.
 */
async function runSemanticSearchDemo() {
    console.log('--- Starting Local Semantic Search Demo ---\n');

    // Step 1: Initialize the local vector store
    const vectorStore = new LocalVectorStore();

    // Step 2: Ingest and index sample documents
    // In a real app, this would be done once during data processing.
    const documents = [
        { id: 'doc1', content: 'The quick brown fox jumps over the lazy dog.' },
        { id: 'doc2', content: 'A fast red fox leaps over a sleepy hound.' },
        { id: 'doc3', content: 'The weather is sunny and warm today.' },
        { id: 'doc4', content: 'I enjoy reading books about artificial intelligence.' },
    ];

    console.log('Step 1: Ingesting documents and generating embeddings...');
    for (const doc of documents) {
        const embedding = generateEmbedding(doc.content);
        vectorStore.add({ ...doc, embedding });
    }
    console.log('--- Ingestion Complete ---\n');

    // Step 3: Define a user query and generate its embedding
    const userQuery = 'What is the weather like?';
    console.log(`Step 2: Processing user query: "${userQuery}"`);
    const queryEmbedding = generateEmbedding(userQuery);
    console.log('Query Vector:', queryEmbedding);
    console.log('--- Query Processing Complete ---\n');

    // Step 4: Perform the search
    console.log('Step 3: Performing K-Nearest Neighbors search...');
    const searchResults = vectorStore.search(queryEmbedding, 2); // K=2

    // Step 5: Display results
    console.log('--- Search Results ---');
    searchResults.forEach((result, index) => {
        console.log(
            `${index + 1}. Score: ${result.score.toFixed(4)} | ID: ${result.chunk.id} | Content: "${result.chunk.content}"`
        );
    });
}

// Execute the demo
runSemanticSearchDemo().catch(console.error);
