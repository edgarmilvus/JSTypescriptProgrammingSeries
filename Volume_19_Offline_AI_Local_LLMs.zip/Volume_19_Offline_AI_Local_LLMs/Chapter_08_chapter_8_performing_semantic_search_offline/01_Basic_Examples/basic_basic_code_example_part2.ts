/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.ts
// Description: Basic Code Example
// ==========================================

digraph G {
    rankdir=TB;
    node [shape=box, style="rounded,filled", fillcolor="#e1f5fe", fontname="Arial"];
    edge [fontname="Arial", fontsize=10];

    subgraph cluster_0 {
        label = "Offline Phase (Data Indexing)";
        style="filled, dashed";
        color=lightgrey;
        node [fillcolor="#f3e5f5"];

        Ingest [label="1. Ingest Documents", shape=ellipse];
        Chunk [label="2. Text Chunking", shape=ellipse];
        EmbedDoc [label="3. Generate Document Embeddings\n(Local LLM)", shape=ellipse];
        Store [label="4. Store in Vector DB\n(pgvector)", shape=ellipse];
    }

    subgraph cluster_1 {
        label = "Online Phase (Query Time)";
        style="filled, dashed";
        color=lightgrey;
        node [fillcolor="#e8f5e8"];

        Query [label="User Query", shape=ellipse];
        EmbedQuery [label="Generate Query Embedding\n(Local LLM)", shape=ellipse];
        Search [label="5. KNN Search\n(Cosine Similarity)", shape=ellipse];
        Results [label="6. Return Top-K Results", shape=ellipse];
    }

    Ingest -> Chunk;
    Chunk -> EmbedDoc;
    EmbedDoc -> Store;

    Query -> EmbedQuery;
    EmbedQuery -> Search;
    Store -> Search [label="Compare Vectors", dir=both];
    Search -> Results;
}
