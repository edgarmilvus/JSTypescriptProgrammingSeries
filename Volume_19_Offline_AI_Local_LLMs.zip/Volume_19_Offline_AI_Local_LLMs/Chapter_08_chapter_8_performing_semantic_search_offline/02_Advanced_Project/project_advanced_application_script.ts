/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// pages/api/offline-search.ts (or as a standalone Node.js script)
import type { NextApiRequest, NextApiResponse } from 'next';
import localForage from 'localforage';
import { pipeline, FeatureExtractionPipeline } from '@xenova/transformers';

// -----------------------------------------------------------------------------
// 1. TYPES & INTERFACES
// -----------------------------------------------------------------------------

/**
 * Represents a single chunk of text with its vector embedding.
 * This is the fundamental unit of our vector database.
 */
interface VectorDocument {
  id: string;
  content: string;
  embedding: number[]; // The vector representation
  metadata: {
    source: string;
    chunkIndex: number;
  };
}

/**
 * The response structure for the API endpoint.
 */
interface SearchResponse {
  query: string;
  queryEmbedding: number[] | null;
  results: Array<{ content: string; score: number }>;
  status: 'success' | 'error';
  message?: string;
}

// -----------------------------------------------------------------------------
// 2. SERVICE WORKER & CACHING STRATEGY (Conceptual Implementation)
// -----------------------------------------------------------------------------

/**
 * In a real Next.js Service Worker (public/sw.js), we would cache the ONNX/WASM model files.
 * This ensures the heavy ML models (approx. 50-100MB) are downloaded once and served locally.
 * 
 * Example Service Worker Logic:
 * 
 * self.addEventListener('install', (event) => {
 *   event.waitUntil(
 *     caches.open('ai-models-v1').then((cache) => {
 *       return cache.addAll([
 *         '/models/onnx/encoder_model.onnx',
 *         '/models/tokenizer.json',
 *       ]);
 *     })
 *   );
 * });
 * 
 * This script assumes the model is available via the local cache or CDN fallback.
 */

// -----------------------------------------------------------------------------
// 3. CORE ENGINE: LOCAL VECTOR DATABASE
// -----------------------------------------------------------------------------

class LocalVectorDB {
  private storeName: string;

  constructor(storeName: string) {
    this.storeName = storeName;
    // Configure localForage to use IndexedDB for high capacity storage
    localForage.config({
      name: 'OfflineRAG',
      storeName: this.storeName,
    });
  }

  /**
   * Stores a vector document in the local IndexedDB.
   * @param doc - The document containing text and embedding.
   */
  async save(doc: VectorDocument): Promise<void> {
    await localForage.setItem(doc.id, doc);
  }

  /**
   * Retrieves all documents from the local database.
   * @returns Array of VectorDocuments.
   */
  async getAll(): Promise<VectorDocument[]> {
    const keys = await localForage.keys();
    const docs: VectorDocument[] = [];
    for (const key of keys) {
      const doc = await localForage.getItem<VectorDocument>(key);
      if (doc) docs.push(doc);
    }
    return docs;
  }

  /**
   * Clears the database (useful for resetting the app).
   */
  async clear(): Promise<void> {
    await localForage.clear();
  }
}

// -----------------------------------------------------------------------------
// 4. EMBEDDING GENERATOR (ON-DEVICE)
// -----------------------------------------------------------------------------

class EmbeddingEngine {
  private model: FeatureExtractionPipeline | null = null;
  private modelName = 'Xenova/all-MiniLM-L6-v2'; // Lightweight model suitable for browser

  /**
   * Initializes the transformer pipeline.
   * This is the heavy lifting part that downloads/caches the model.
   * In a real app, this is called once on app load.
   */
  async initialize(): Promise<void> {
    if (this.model) return;
    console.log('Loading local embedding model...');
    // @ts-ignore: Type definitions for transformers.js pipeline
    this.model = await pipeline('feature-extraction', this.modelName);
    console.log('Model loaded.');
  }

  /**
   * Generates a vector embedding for a given text string.
   * @param text - The input text to vectorize.
   * @returns A Promise resolving to an array of numbers (the vector).
   */
  async embed(text: string): Promise<number[]> {
    if (!this.model) {
      throw new Error('Embedding engine not initialized. Call initialize() first.');
    }
    
    // Generate embeddings (pooling is handled by the pipeline)
    const result = await this.model(text, {
      pooling: 'mean',
      normalize: true,
    });

    // Convert Tensor to standard JS Array
    return Array.from(result.data);
  }
}

// -----------------------------------------------------------------------------
// 5. RAG PIPELINE ORCHESTRATOR
// -----------------------------------------------------------------------------

class OfflineRAGPipeline {
  private db: LocalVectorDB;
  private embedder: EmbeddingEngine;

  constructor() {
    this.db = new LocalVectorDB('knowledge_base');
    this.embedder = new EmbeddingEngine();
  }

  /**
   * Step A: Ingestion & Chunking
   * Simulates processing a raw document into manageable chunks.
   * In a real scenario, this would parse PDF/Text files.
   * @param rawText - The full text of the document.
   * @param chunkSize - Characters per chunk (approx).
   */
  private chunkText(rawText: string, chunkSize: number = 500): string[] {
    const words = rawText.split(' ');
    const chunks: string[] = [];
    let currentChunk = '';

    for (const word of words) {
      if ((currentChunk + word).length > chunkSize) {
        chunks.push(currentChunk.trim());
        currentChunk = word + ' ';
      } else {
        currentChunk += word + ' ';
      }
    }
    if (currentChunk.trim().length > 0) {
      chunks.push(currentChunk.trim());
    }
    return chunks;
  }

  /**
   * Step B: Indexing
   * Takes raw text, chunks it, generates embeddings, and saves to DB.
   * This is an asynchronous, non-blocking operation.
   * @param rawText - The document to index.
   * @param sourceName - Name of the file/source.
   */
  async indexDocument(rawText: string, sourceName: string): Promise<void> {
    console.time('Indexing');
    await this.embedder.initialize();
    
    const chunks = this.chunkText(rawText);
    console.log(`Processing ${chunks.length} chunks...`);

    // Process sequentially to avoid freezing the UI (Async/Await loop)
    for (let i = 0; i < chunks.length; i++) {
      const chunk = chunks[i];
      const embedding = await this.embedder.embed(chunk);
      
      const doc: VectorDocument = {
        id: `${sourceName}_chunk_${i}`,
        content: chunk,
        embedding: embedding,
        metadata: {
          source: sourceName,
          chunkIndex: i,
        },
      };

      await this.db.save(doc);
      console.log(`Indexed chunk ${i + 1}/${chunks.length}`);
    }
    console.timeEnd('Indexing');
  }

  /**
   * Step C: Retrieval & Ranking
   * Performs vector similarity search (Cosine Similarity) against the DB.
   * @param query - The user's search query.
   * @param topK - Number of results to return.
   */
  async search(query: string, topK: number = 3): Promise<Array<{ content: string; score: number }>> {
    await this.embedder.initialize();
    
    // 1. Embed the query
    const queryEmbedding = await this.embedder.embed(query);
    
    // 2. Retrieve all stored documents
    const allDocs = await this.db.getAll();
    if (allDocs.length === 0) return [];

    // 3. Calculate Cosine Similarity
    const results = allDocs.map((doc) => {
      const score = this.cosineSimilarity(queryEmbedding, doc.embedding);
      return {
        content: doc.content,
        score: score,
        source: doc.metadata.source,
      };
    });

    // 4. Sort by score (descending) and slice
    return results.sort((a, b) => b.score - a.score).slice(0, topK);
  }

  /**
   * Helper: Calculates Cosine Similarity between two vectors.
   * Formula: dot(A, B) / (||A|| * ||B||)
   */
  private cosineSimilarity(vecA: number[], vecB: number[]): number {
    let dotProduct = 0;
    let normA = 0;
    let normB = 0;
    
    for (let i = 0; i < vecA.length; i++) {
      dotProduct += vecA[i] * vecB[i];
      normA += vecA[i] * vecA[i];
      normB += vecB[i] * vecB[i];
    }
    
    return dotProduct / (Math.sqrt(normA) * Math.sqrt(normB));
  }

  /**
   * Step D: Synthesis (Mock LLM)
   * In a full app, this would send the retrieved context to a local Llama 3 model.
   * Here, we simulate the synthesis step.
   */
  async synthesize(query: string, context: Array<{ content: string; score: number }>): Promise<string> {
    const contextText = context.map(c => `- ${c.content}`).join('\n');
    
    // Simulating a local LLM prompt
    const prompt = `
      Based on the following context, answer the question.
      Question: ${query}
      Context:
      ${contextText}
      
      Answer:
    `;

    // In a real scenario, we would run:
    // const llm = await pipeline('text-generation', 'Xenova/Llama-3-8B-Instruct');
    // const output = await llm(prompt, { max_new_tokens: 100 });
    
    return `[Simulated LLM Response]\nI found relevant information in the context:\n${contextText.substring(0, 200)}...\n(Truncated for demo)`;
  }
}

// -----------------------------------------------------------------------------
// 6. NEXT.JS API ROUTE HANDLER
// -----------------------------------------------------------------------------

/**
 * API Route: /api/offline-search
 * Handles POST requests to index documents and GET requests to search.
 */
export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse<SearchResponse>
) {
  // Initialize the pipeline singleton (in memory for the serverless function)
  // Note: In a real serverless environment, this resets on every cold start.
  // For persistent offline usage, this logic belongs in the Client (Browser).
  const pipeline = new OfflineRAGPipeline();

  try {
    if (req.method === 'POST') {
      // INDEXING FLOW
      const { document, filename } = req.body;
      
      if (!document) {
        return res.status(400).json({ status: 'error', message: 'No document provided' });
      }

      await pipeline.indexDocument(document, filename || 'uploaded_doc');
      
      return res.status(200).json({ 
        status: 'success', 
        message: 'Document indexed successfully offline' 
      });

    } else if (req.method === 'GET') {
      // SEARCH FLOW
      const { q } = req.query;
      
      if (!q || typeof q !== 'string') {
        return res.status(400).json({ status: 'error', message: 'Query parameter "q" is required' });
      }

      const context = await pipeline.search(q);
      const answer = await pipeline.synthesize(q, context);

      return res.status(200).json({
        status: 'success',
        query: q,
        queryEmbedding: null, // Omitted for brevity
        results: context,
        message: answer, // The synthesized answer
      });
    } else {
      res.setHeader('Allow', ['GET', 'POST']);
      res.status(405).end(`Method ${req.method} Not Allowed`);
    }
  } catch (error) {
    console.error(error);
    res.status(500).json({ 
      status: 'error', 
      message: 'Internal Server Error (Check console for model loading issues)' 
    });
  }
}
