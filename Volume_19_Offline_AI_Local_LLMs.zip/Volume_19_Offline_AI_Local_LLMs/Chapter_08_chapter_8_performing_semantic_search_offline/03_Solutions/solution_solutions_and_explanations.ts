/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

interface ChunkingConfig {
  maxChunkSize: number; // Maximum number of characters per chunk.
  overlap: number;      // Number of overlapping characters between consecutive chunks.
  separator: string;    // The primary delimiter to split on (e.g., '\n\n', '.', '?', '!').
}

/**
 * Splits text into semantically coherent chunks with overlap.
 * @param text - The raw text to chunk.
 * @param config - Configuration for chunking logic.
 * @returns An array of text chunks.
 */
export function chunkText(text: string, config: ChunkingConfig): string[] {
  if (!text || text.trim().length === 0) {
    return [];
  }

  const { maxChunkSize, overlap, separator } = config;
  
  // 1. Split text by the semantic separator.
  const units = text.split(separator).map(unit => unit.trim()).filter(unit => unit.length > 0);

  const chunks: string[] = [];
  let currentChunk = "";

  for (const unit of units) {
    // If adding the next unit (plus separator) exceeds the limit, finalize current chunk.
    // We add a small buffer for the separator length.
    if (currentChunk.length + unit.length + separator.length > maxChunkSize && currentChunk.length > 0) {
      chunks.push(currentChunk);
      
      // Apply overlap: start the next chunk with the end of the previous one.
      if (overlap > 0) {
        const overlapText = currentChunk.slice(-overlap);
        currentChunk = overlapText + separator + unit;
      } else {
        currentChunk = unit;
      }
    } else {
      // Append to current chunk.
      if (currentChunk.length === 0) {
        currentChunk = unit;
      } else {
        currentChunk += separator + unit;
      }
    }
  }

  // Push the remaining chunk if it exists.
  if (currentChunk.length > 0) {
    chunks.push(currentChunk);
  }

  // 2. Handle "hard splits" for units larger than maxChunkSize.
  // This iterates through the chunks and splits any that are still too long by character count.
  const finalChunks: string[] = [];
  
  for (const chunk of chunks) {
    if (chunk.length <= maxChunkSize) {
      finalChunks.push(chunk);
      continue;
    }

    // If a single semantic unit is massive, we must split it by character count.
    let start = 0;
    while (start < chunk.length) {
      const end = start + maxChunkSize;
      let subChunk = chunk.substring(start, end);
      
      // If we are not at the very end, try to avoid cutting words if possible (optional polish)
      // but for strict requirements, we cut by character limit.
      
      finalChunks.push(subChunk);
      
      // Apply overlap for hard splits
      if (overlap > 0 && end < chunk.length) {
         start = end - overlap;
      } else {
         start = end;
      }
    }
  }

  return finalChunks;
}
