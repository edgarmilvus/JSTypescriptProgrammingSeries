/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

import { Pinecone, PineconeRecord, RecordMetadata } from '@pinecone-database/pinecone';

// Define metadata interface for type safety
export interface ChunkMetadata extends RecordMetadata {
  text: string;
  source: string;
}

/**
 * Initializes a Pinecone index or creates one if it doesn't exist.
 * @param pinecone - The initialized Pinecone client instance.
 * @param indexName - The name of the index to initialize.
 * @param dimension - The vector dimension (e.g., 384 for all-MiniLM-L6-v2).
 */
export async function initializePineconeIndex(
  pinecone: Pinecone,
  indexName: string,
  dimension: number
) {
  try {
    console.log(`Checking for index: ${indexName}...`);
    const existingIndexes = await pinecone.listIndexes();
    
    if (!existingIndexes.includes(indexName)) {
      console.log(`Index not found. Creating new index: ${indexName}`);
      await pinecone.createIndex({
        name: indexName,
        dimension: dimension,
        metric: 'cosine', // Common metric for semantic similarity
        waitUntilReady: true, // Wait for the index to be ready before proceeding
      });
    } else {
      console.log(`Index ${indexName} already exists.`);
    }

    // Connect to the specific index
    const index = pinecone.Index<ChunkMetadata>(indexName);
    return index;
  } catch (error) {
    console.error("Error initializing Pinecone index:", error);
    throw error;
  }
}

/**
 * Generates embeddings and upserts chunks into the Pinecone index.
 * @param index - The Pinecone index instance.
 * @param chunks - Array of text strings to upsert.
 * @param sourceName - The source document name for metadata.
 * @param generateEmbedding - Function to generate vector embeddings.
 */
export async function upsertChunks(
  index: any, // Typing as 'any' or specific Pinecone Index type depending on SDK version
  chunks: string[],
  sourceName: string,
  generateEmbedding: (text: string) => Promise<Float32Array>
): Promise<void> {
  const batchSize = 10;
  
  for (let i = 0; i < chunks.length; i += batchSize) {
    const batch = chunks.slice(i, i + batchSize);
    console.log(`Processing batch ${Math.floor(i / batchSize) + 1}...`);

    const records: PineconeRecord<ChunkMetadata>[] = [];

    for (let j = 0; j < batch.length; j++) {
      const chunkText = batch[j];
      const id = `chunk-${i + j}`;
      
      // Generate embedding (simulated or actual model call)
      const vector = await generateEmbedding(chunkText);

      records.push({
        id: id,
        values: Array.from(vector), // Pinecone expects number[]
        metadata: {
          text: chunkText,
          source: sourceName,
        },
      });
    }

    try {
      await index.upsert(records);
      console.log(`Upserted ${records.length} vectors.`);
    } catch (error) {
      console.error(`Error upserting batch starting at index ${i}:`, error);
      // In a production app, you might implement retry logic here
    }
  }
}
