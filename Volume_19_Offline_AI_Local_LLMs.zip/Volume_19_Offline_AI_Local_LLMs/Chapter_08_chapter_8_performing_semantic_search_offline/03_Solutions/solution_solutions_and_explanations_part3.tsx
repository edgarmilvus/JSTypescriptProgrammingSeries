/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState, useEffect, useCallback } from 'react';
import { 
  View, 
  TextInput, 
  FlatList, 
  Text, 
  StyleSheet, 
  ActivityIndicator, 
  Keyboard 
} from 'react-native';

// Define the type for a search result item
export interface SearchResult {
  id: string;
  text: string;
  source: string;
  score: number;
}

// Mock search function to simulate the backend logic
const mockSearch = async (query: string): Promise<SearchResult[]> => {
  return new Promise((resolve) => {
    setTimeout(() => {
      if (!query.trim()) return resolve([]);
      
      // Simulated results
      const results: SearchResult[] = [
        {
          id: '1',
          text: `Simulated result for: "${query}". This demonstrates the UI component's rendering capabilities.`,
          source: 'document.txt',
          score: 0.95
        },
        {
          id: '2',
          text: 'Another relevant chunk of text found in the local index.',
          source: 'notes.md',
          score: 0.82
        }
      ];
      resolve(results);
    }, 500); // Simulate network delay
  });
};

export const SemanticSearchBar: React.FC = () => {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<SearchResult[]>([]);
  const [isLoading, setIsLoading] = useState(false);

  // Debounce logic to avoid searching on every keystroke
  useEffect(() => {
    const handler = setTimeout(() => {
      if (query.trim().length > 0) {
        performSearch();
      } else {
        setResults([]);
      }
    }, 300); // 300ms debounce

    return () => clearTimeout(handler);
  }, [query]);

  const performSearch = async () => {
    setIsLoading(true);
    try {
      const searchResults = await mockSearch(query);
      setResults(searchResults);
    } catch (error) {
      console.error("Search failed:", error);
      setResults([]);
    } finally {
      setIsLoading(false);
    }
  };

  // Hide keyboard when scrolling through results
  const handleScroll = () => Keyboard.dismiss();

  return (
    <View style={styles.container}>
      <TextInput
        style={styles.input}
        placeholder="Type your semantic query..."
        value={query}
        onChangeText={setQuery}
        autoCorrect={false}
      />
      
      {isLoading && (
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="small" color="#007AFF" />
          <Text style={styles.loadingText}>Searching local index...</Text>
        </View>
      )}

      <FlatList
        data={results}
        keyExtractor={(item) => item.id}
        onScroll={handleScroll}
        scrollEventThrottle={16}
        renderItem={({ item }) => (
          <View style={styles.resultItem}>
            <Text style={styles.resultText}>"{item.text}"</Text>
            <View style={styles.metaContainer}>
              <Text style={styles.sourceText}>Source: {item.source}</Text>
              <Text style={styles.scoreText}>Similarity: {item.score.toFixed(2)}</Text>
            </View>
          </View>
        )}
        ListEmptyComponent={
          !isLoading && query.length > 0 ? (
            <Text style={styles.emptyText}>No results found.</Text>
          ) : null
        }
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
    backgroundColor: '#f5f5f5',
  },
  input: {
    backgroundColor: '#fff',
    padding: 12,
    borderRadius: 8,
    fontSize: 16,
    borderWidth: 1,
    borderColor: '#ddd',
    marginBottom: 16,
  },
  loadingContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 10,
  },
  loadingText: {
    marginLeft: 8,
    color: '#555',
  },
  resultItem: {
    backgroundColor: '#fff',
    padding: 16,
    borderRadius: 8,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: '#eee',
  },
  resultText: {
    fontSize: 15,
    lineHeight: 22,
    marginBottom: 8,
  },
  metaContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    borderTopWidth: 1,
    borderTopColor: '#f0f0f0',
    paddingTop: 8,
  },
  sourceText: {
    fontSize: 12,
    color: '#888',
    fontStyle: 'italic',
  },
  scoreText: {
    fontSize: 12,
    color: '#007AFF',
    fontWeight: '600',
  },
  emptyText: {
    textAlign: 'center',
    color: '#999',
    marginTop: 20,
  },
});
