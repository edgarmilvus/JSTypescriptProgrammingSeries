/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

// search-app.ts
import { Pinecone } from '@pinecone-database/pinecone';
import fs from 'fs/promises';
import path from 'path';
import yargs from 'yargs/yargs';
import { hideBin } from 'yargs/helpers';
import { chunkText, ChunkingConfig } from './exercise1'; // Assuming previous exercises are in separate files
import { initializePineconeIndex, upsertChunks, ChunkMetadata } from './exercise2';

// Mock embedding generator (Replace with actual model inference in production)
const mockGenerateEmbedding = async (text: string): Promise<Float32Array> => {
  // Simulating a 384-dimension vector filled with random floats
  const vector = new Float32Array(384);
  for (let i = 0; i < 384; i++) {
    vector[i] = Math.random();
  }
  // Simple hash-based tweak to make vectors slightly distinct for demo purposes
  const hash = text.split('').reduce((a, b) => ((a << 5) - a) + b.charCodeAt(0), 0);
  vector[0] = (hash % 100) / 100; 
  return vector;
};

// --- CLI Logic ---

const argv = yargs(hideBin(process.argv))
  .command('index', 'Index a text file', {
    file: { type: 'string', demandOption: true, alias: 'f' }
  })
  .command('query', 'Query the index', {
    query: { type: 'string', demandOption: true, alias: 'q' },
    index: { type: 'string', demandOption: true, alias: 'i' } // Specify which index to query
  })
  .demandCommand(1, 'You need at least one command')
  .help()
  .argv;

async function main() {
  const command = argv._[0];

  if (command === 'index') {
    const filePath = argv.file as string;
    const indexName = path.basename(filePath, path.extname(filePath)).replace(/[^a-zA-Z0-9]/g, '-').toLowerCase();
    
    try {
      console.log(`--- Starting Indexing for ${filePath} ---`);
      
      // 1. Read File
      const content = await fs.readFile(filePath, 'utf-8');
      
      // 2. Chunk Text
      const config: ChunkingConfig = {
        maxChunkSize: 500,
        overlap: 50,
        separator: '\n\n'
      };
      const chunks = chunkText(content, config);
      console.log(`Generated ${chunks.length} chunks.`);

      // 3. Initialize Pinecone
      const pinecone = new Pinecone();
      const dimension = 384; // Dimension for all-MiniLM-L6-v2
      const index = await initializePineconeIndex(pinecone, indexName, dimension);

      // 4. Upsert Chunks
      await upsertChunks(index, chunks, filePath, mockGenerateEmbedding);
      
      console.log(`--- Indexing Complete. Index Name: ${indexName} ---`);

    } catch (error) {
      console.error("Indexing failed:", error);
    }

  } else if (command === 'query') {
    const queryString = argv.query as string;
    const indexName = argv.index as string;

    try {
      console.log(`--- Querying Index: ${indexName} ---`);
      console.log(`Query: "${queryString}"\n`);

      const pinecone = new Pinecone();
      // Connect to the specific index
      const index = pinecone.Index<ChunkMetadata>(indexName);

      // 1. Generate Query Embedding
      const queryVector = await mockGenerateEmbedding(queryString);

      // 2. Perform KNN Search (K=3)
      const queryResponse = await index.query({
        vector: Array.from(queryVector),
        topK: 3,
        includeMetadata: true,
      });

      if (!queryResponse.matches || queryResponse.matches.length === 0) {
        console.log("No matches found.");
        return;
      }

      // 3. Display Results
      queryResponse.matches.forEach((match, idx) => {
        const metadata = match.metadata;
        if (metadata) {
          console.log(`Result ${idx + 1} (Score: ${match.score?.toFixed(2)}):`);
          console.log(`"${metadata.text}"`);
          console.log(`Source: ${metadata.source}\n`);
        }
      });

    } catch (error) {
      console.error("Query failed:", error);
    }
  }
}

main();
