/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * MOCK INFRASTRUCTURE
 * We simulate the Supabase client and the local device storage 
 * to keep this example runnable in a browser console.
 */

// 1. Mock Supabase Client (Simulating the Cloud DB)
class MockSupabaseClient {
  // Simulates a PostgreSQL table 'documents' with a pgvector column 'embedding'
  private db: Array<{ id: string; content: string; embedding: number[] }> = [];

  async upsert(vectorData: { id: string; content: string; embedding: number[] }) {
    console.log(`☁️  [Cloud] Receiving sync for ID: ${vectorData.id}`);
    this.db.push(vectorData);
    console.log(`☁️  [Cloud] Stored. Total records: ${this.db.length}`);
  }

  async fetchAllVectors(): Promise<Array<{ id: string; content: string; embedding: number[] }>> {
    console.log(`☁️  [Cloud] Fetching full vector index for offline cache...`);
    return [...this.db]; // Return a copy
  }
}

// 2. Mock Local Storage (Simulating SQLite/IndexedDB on the Phone)
class LocalDeviceStorage {
  private cache: Array<{ id: string; content: string; embedding: number[] }> = [];

  async saveLocal(vectorData: { id: string; content: string; embedding: number[] }) {
    console.log(`📱 [Local] Saving to on-device DB: ${vectorData.id}`);
    this.cache.push(vectorData);
  }

  async getLocalCache(): Promise<Array<{ id: string; content: string; embedding: number[] }>> {
    return this.cache;
  }
}

// 3. Mock Headless Inference (Simulating a local LLM/Transformer model)
// In a real app, this would be `transformers.js` or `onnxruntime-web`.
class LocalInferenceEngine {
  /**
   * Generates a vector embedding for a text string.
   * Returns a dummy 384-dimension vector for demonstration.
   */
  async generateEmbedding(text: string): Promise<number[]> {
    console.log(`🧠 [Local Inference] Generating embedding for: "${text}"`);
    // Simulate async model inference delay
    await new Promise(r => setTimeout(r, 100)); 
    // Return a deterministic dummy vector based on string length (for demo only)
    return new Array(384).fill(text.length / 100); 
  }
}

/**
 * MAIN SYNC LOGIC
 * This class orchestrates the hybrid architecture.
 */
class HybridSyncManager {
  private cloud: MockSupabaseClient;
  private local: LocalDeviceStorage;
  private inference: LocalInferenceEngine;

  constructor() {
    this.cloud = new MockSupabaseClient();
    this.local = new LocalDeviceStorage();
    this.inference = new LocalInferenceEngine();
  }

  /**
   * SCENARIO A: Offline-First Sync (Local -> Cloud)
   * User creates data on the phone while offline.
   * We generate the vector locally and sync to cloud when online.
   */
  public async syncLocalToCloud(content: string): Promise<void> {
    console.log("\n--- Starting Sync: Local -> Cloud ---");
    
    // 1. Generate Embedding On-Device (Headless Inference)
    const embedding = await this.inference.generateEmbedding(content);
    
    const payload = {
      id: crypto.randomUUID(), // Generate ID locally
      content: content,
      embedding: embedding
    };

    // 2. Save to Local DB (Immediate feedback for UI)
    await this.local.saveLocal(payload);

    // 3. Sync to Cloud (Network Request)
    try {
      await this.cloud.upsert(payload);
      console.log("✅ Sync successful.");
    } catch (error) {
      console.error("❌ Sync failed. Retrying logic would go here.");
    }
  }

  /**
   * SCENARIO B: Cache Warming (Cloud -> Local)
   * App startup: Fetch global index to enable fast offline search.
   */
  public async syncCloudToLocal(): Promise<void> {
    console.log("\n--- Starting Sync: Cloud -> Local ---");
    
    // 1. Fetch global vectors from Cloud
    const cloudData = await this.cloud.fetchAllVectors();

    // 2. Batch insert into Local DB
    // In a real app, this involves diffing (e.g., checking updated_at timestamps)
    // to avoid overwriting local changes.
    for (const item of cloudData) {
      await this.local.saveLocal(item);
    }

    console.log(`✅ Cache warming complete. Local DB has ${cloudData.length} records.`);
  }
}

/**
 * EXECUTION
 * Simulating the app lifecycle.
 */
async function main() {
  const app = new HybridSyncManager();

  // 1. Simulate User creating data offline on their phone
  await app.syncLocalToCloud("Hello World: Local LLM on Smartphone");

  // 2. Simulate App Startup (Syncing Cloud data down to phone)
  await app.syncCloudToLocal();
}

// Run the example
main();
