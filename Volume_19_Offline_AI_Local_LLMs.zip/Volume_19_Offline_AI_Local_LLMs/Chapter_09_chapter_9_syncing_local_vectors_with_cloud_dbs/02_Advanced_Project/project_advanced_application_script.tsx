/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.tsx
// Description: Advanced Application Script
// ==========================================

// app/components/KnowledgeSync.tsx
'use client';

import React, { useState, useTransition } from 'react';

// -----------------------------------------------------------------------------
// 1. TYPE DEFINITIONS & GUARDS
// -----------------------------------------------------------------------------
// We define strict types for our vector data to ensure consistency across 
// client-server boundaries. This is crucial for hybrid architectures.

/**
 * Represents a local vector item before it is synced.
 * In a real scenario, the embedding would be a number[] or Float32Array.
 */
export interface LocalVectorItem {
  id: string;
  content: string;
  embedding: number[]; // The vector representation
  timestamp: number;
}

/**
 * Represents the response from the server after a successful sync.
 */
export interface CloudSyncResponse {
  success: boolean;
  cloudId: string;
  syncedAt: string;
  message?: string;
}

/**
 * Type Guard: Validates if an unknown object is a CloudSyncResponse.
 * This ensures we don't access properties on undefined or malformed objects.
 * 
 * @param data - The unknown data to check.
 * @returns boolean indicating if data matches the CloudSyncResponse interface.
 */
export function isCloudSyncResponse(data: unknown): data is CloudSyncResponse {
  return (
    typeof data === 'object' &&
    data !== null &&
    'success' in data &&
    typeof (data as CloudSyncResponse).success === 'boolean' &&
    'cloudId' in data &&
    typeof (data as CloudSyncResponse).cloudId === 'string'
  );
}

// -----------------------------------------------------------------------------
// 2. CLIENT COMPONENT
// -----------------------------------------------------------------------------

export default function KnowledgeSync() {
  // State for the input text (the knowledge snippet)
  const [inputValue, setInputValue] = useState('');
  
  // State to store locally generated vectors (simulating an on-device vector DB)
  const [localVectors, setLocalVectors] = useState<LocalVectorItem[]>([]);
  
  // State for sync status feedback
  const [syncStatus, setSyncStatus] = useState<string>('Ready');

  // useTransition: Allows us to mark the sync process as a non-urgent update.
  // This keeps the UI responsive (e.g., typing in the input box remains fast)
  // even while the embedding generation and cloud sync are happening in the background.
  const [isPending, startTransition] = useTransition();

  /**
   * Handles the creation of a new vector locally and initiates the cloud sync.
   * Wraps the server action in a transition to maintain UI responsiveness.
   */
  const handleAddAndSync = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputValue.trim()) return;

    const newItemId = crypto.randomUUID();

    // 1. Prepare the local vector item (Mocking local embedding generation)
    // In a real app, this would use a WebAssembly-based LLM (like WebLLM) 
    // or a browser-based embedding model (like Transformers.js).
    const newItem: LocalVectorItem = {
      id: newItemId,
      content: inputValue,
      embedding: generateMockEmbedding(inputValue), // Simulated vector
      timestamp: Date.now(),
    };

    // 2. Optimistically update the local UI
    setLocalVectors((prev) => [...prev, newItem]);
    setInputValue('');
    setSyncStatus('Generating embeddings...');

    // 3. Start the transition for the server-side sync
    startTransition(async () => {
      try {
        // Call the Server Action
        const result = await syncVectorToCloud(newItem);

        // Type Guard usage: Ensure the result is what we expect
        if (isCloudSyncResponse(result)) {
          if (result.success) {
            setSyncStatus(`Synced to Cloud ID: ${result.cloudId}`);
            // In a real app, we would update the local item with the cloudId
            // to establish a link for future updates/deletes.
          } else {
            setSyncStatus(`Sync failed: ${result.message || 'Unknown error'}`);
          }
        } else {
          setSyncStatus('Invalid response from server');
        }
      } catch (error) {
        setSyncStatus(`Error: ${error instanceof Error ? error.message : 'Unknown'}`);
      }
    });
  };

  return (
    <div style={{ fontFamily: 'sans-serif', padding: '20px', maxWidth: '600px', margin: '0 auto' }}>
      <h2>Hybrid Vector Sync</h2>
      <p style={{ color: '#666' }}>
        Add content to generate a local vector. The system will attempt to sync it to the cloud asynchronously.
      </p>

      {/* Input Form */}
      <form onSubmit={handleAddAndSync} style={{ marginBottom: '20px' }}>
        <input
          type="text"
          value={inputValue}
          onChange={(e) => setInputValue(e.target.value)}
          placeholder="Enter knowledge snippet..."
          disabled={isPending} // Disable input during heavy processing
          style={{ padding: '8px', width: '70%', marginRight: '10px' }}
        />
        <button 
          type="submit" 
          disabled={isPending || !inputValue.trim()}
          style={{ padding: '8px 16px', cursor: isPending ? 'wait' : 'pointer' }}
        >
          {isPending ? 'Syncing...' : 'Add & Sync'}
        </button>
      </form>

      {/* Status Indicator */}
      <div style={{ 
        padding: '10px', 
        backgroundColor: isPending ? '#e3f2fd' : '#f5f5f5', 
        borderLeft: `4px solid ${isPending ? '#2196f3' : '#4caf50'}`,
        marginBottom: '20px'
      }}>
        <strong>Status:</strong> {syncStatus}
      </div>

      {/* Local Vector List (Client-side view) */}
      <h3>Local Vectors (Device)</h3>
      <ul style={{ listStyle: 'none', padding: 0 }}>
        {localVectors.map((vec) => (
          <li key={vec.id} style={{ 
            borderBottom: '1px solid #eee', 
            padding: '10px 0',
            display: 'flex',
            justifyContent: 'space-between'
          }}>
            <span>{vec.content}</span>
            <span style={{ fontSize: '0.8rem', color: '#888' }}>
              Dim: {vec.embedding.length}
            </span>
          </li>
        ))}
        {localVectors.length === 0 && <li style={{ color: '#999' }}>No local vectors yet.</li>}
      </ul>
    </div>
  );
}

// -----------------------------------------------------------------------------
// 3. SERVER ACTIONS
// -----------------------------------------------------------------------------
// These functions run only on the server. They are secure and have access to 
// environment variables (like database connection strings).

/**
 * Server Action: Syncs a vector item to the cloud database.
 * 
 * @param item - The LocalVectorItem to sync.
 * @returns Promise<CloudSyncResponse | { success: false; error: string }>
 */
async function syncVectorToCloud(item: LocalVectorItem) {
  'use server'; // Marks this function as a Server Action

  // Import necessary dependencies (simulated here)
  // In a real app, you would import your vector database client (e.g., Pinecone, Qdrant, pgvector)
  
  try {
    console.log(`[Server] Processing sync for ID: ${item.id}`);
    
    // SIMULATED CLOUD PROCESSING
    // 1. Vector Compression: In a real scenario, we might quantize the vector 
    //    (e.g., float32 to int8) to save bandwidth before sending to the DB.
    const compressedVector = compressVector(item.embedding);
    
    // 2. Database Insertion (Simulated)
    // await db.vectors.create({ data: { ...item, embedding: compressedVector } });
    await new Promise(resolve => setTimeout(resolve, 1500)); // Simulate network/DB latency

    // 3. Return success response
    const response: CloudSyncResponse = {
      success: true,
      cloudId: `cloud_${item.id}`, // Generated ID from DB
      syncedAt: new Date().toISOString(),
      message: 'Vector compressed and stored successfully'
    };

    return response;

  } catch (error) {
    console.error('[Server] Sync Error:', error);
    return {
      success: false,
      error: error instanceof Error ? error.message : 'Unknown database error'
    };
  }
}

// -----------------------------------------------------------------------------
// 4. HELPER UTILITIES
// -----------------------------------------------------------------------------

/**
 * Generates a mock embedding vector for demonstration purposes.
 * In production, this would be handled by a local WebAssembly model.
 */
function generateMockEmbedding(text: string): number[] {
  // Simple hash-based mock embedding
  let hash = 0;
  for (let i = 0; i < text.length; i++) {
    hash = ((hash << 5) - hash) + text.charCodeAt(i);
    hash |= 0;
  }
  
  // Generate a 384-dimension vector (common for models like all-MiniLM-L6-v2)
  const dims = 384;
  const vector = new Array(dims).fill(0).map((_, i) => {
    // Pseudo-random but deterministic based on input
    return Math.abs(Math.sin(hash + i * 0.1)); 
  });
  
  return vector;
}

/**
 * Simulates vector compression for bandwidth efficiency.
 * Real-world: Scalar Quantization (SQ8) or Product Quantization (PQ).
 */
function compressVector(vector: number[]): number[] {
  // Truncate decimals to 2 places to simulate lower precision
  return vector.map(v => Math.round(v * 100) / 100);
}
