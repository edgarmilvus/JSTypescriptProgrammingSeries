/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// Type definitions
interface TagState {
  isDeleted: boolean;
  timestamp: number;
}

interface VectorMetadataCRDT {
  vectorId: string;
  tags: Map<string, TagState>;
}

/**
 * Merges two CRDT states based on timestamp precedence.
 * - If a tag exists in both, the state with the newer timestamp wins.
 * - If a tag is deleted in one and active in the other, the newer timestamp determines the final state.
 * - If a tag exists only in one state, it is included in the result.
 */
function mergeMetadata(local: VectorMetadataCRDT, remote: VectorMetadataCRDT): VectorMetadataCRDT {
  // Ensure we are merging the same vector ID (basic sanity check)
  if (local.vectorId !== remote.vectorId) {
    throw new Error("Cannot merge metadata for different vectors");
  }

  const mergedTags = new Map<string, TagState>();

  // Collect all unique keys from both maps
  const allKeys = new Set([...local.tags.keys(), ...remote.tags.keys()]);

  for (const key of allKeys) {
    const localTag = local.tags.get(key);
    const remoteTag = remote.tags.get(key);

    if (!localTag) {
      // Tag only exists in remote
      mergedTags.set(key, remoteTag!);
    } else if (!remoteTag) {
      // Tag only exists in local
      mergedTags.set(key, localTag);
    } else {
      // Tag exists in both - Conflict Resolution Strategy:
      // Compare timestamps. The newer timestamp wins.
      if (localTag.timestamp > remoteTag.timestamp) {
        mergedTags.set(key, localTag);
      } else {
        mergedTags.set(key, remoteTag);
      }
    }
  }

  return {
    vectorId: local.vectorId,
    tags: mergedTags
  };
}

// Helper function for simulation
function simulateSync() {
  const now = Date.now();
  const vectorId = "vec_123";

  // Initial State
  const initial: VectorMetadataCRDT = {
    vectorId,
    tags: new Map([
      ["science", { isDeleted: false, timestamp: now - 1000 }],
      ["fiction", { isDeleted: false, timestamp: now - 1000 }]
    ])
  };

  // Local Modification: User adds "history" and deletes "science" (offline)
  const localState: VectorMetadataCRDT = {
    vectorId,
    tags: new Map([
      ["science", { isDeleted: true, timestamp: now + 500 }], // Deleted locally, newer timestamp
      ["fiction", { isDeleted: false, timestamp: now - 1000 }],
      ["history", { isDeleted: false, timestamp: now + 500 }] // Added locally
    ])
  };

  // Remote Modification: Another device adds "art" and modifies "science" (online)
  const remoteState: VectorMetadataCRDT = {
    vectorId,
    tags: new Map([
      ["science", { isDeleted: false, timestamp: now + 200 }], // Modified remotely, older than local deletion
      ["fiction", { isDeleted: false, timestamp: now - 1000 }],
      ["art", { isDeleted: false, timestamp: now + 300 }] // Added remotely
    ])
  };

  const result = mergeMetadata(localState, remoteState);

  console.log("Merged Result:", result);
  // Expected: 
  // science -> deleted (timestamp +500 > +200)
  // fiction -> active
  // history -> active
  // art -> active
}

// Run simulation
// simulateSync(); 
