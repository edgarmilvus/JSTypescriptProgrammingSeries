/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState, useEffect } from 'react';

interface PendingVector {
  id: string;
  data: Float32Array;
  originalSize: number;
  compressedSize: number;
}

// Helper to format bytes
const formatBytes = (bytes: number): string => {
  if (bytes === 0) return '0 Bytes';
  const k = 1024;
  const sizes = ['Bytes', 'KB', 'MB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
};

// Simulates compression by reducing precision (mock logic)
const compressVector = (vector: Float32Array): Uint8Array => {
  // In a real scenario, this might quantize to int8 or use bit-packing.
  // Here we simulate a 50% reduction in size.
  const compressedLength = Math.floor(vector.length / 2);
  return new Uint8Array(compressedLength);
};

export const SyncStatusDashboard: React.FC = () => {
  const [queue, setQueue] = useState<PendingVector[]>([]);
  const [isSyncing, setIsSyncing] = useState<boolean>(false);
  const [totalSavedBytes, setTotalSavedBytes] = useState<number>(0);
  const [progress, setProgress] = useState<number>(0);

  // Calculate total savings whenever queue changes
  useEffect(() => {
    const saved = queue.reduce((acc, item) => acc + (item.originalSize - item.compressedSize), 0);
    setTotalSavedBytes(saved);
  }, [queue]);

  // Simulate adding a vector to the queue
  const addVectorToQueue = () => {
    // Generate dummy vector data (e.g., 768 dimensions * 4 bytes)
    const dim = 768;
    const data = new Float32Array(dim).fill(0.5); 
    const originalSize = data.byteLength;
    
    // Compress
    const compressed = compressVector(data);
    const compressedSize = compressed.byteLength;

    const newVector: PendingVector = {
      id: Math.random().toString(36).substring(7),
      data,
      originalSize,
      compressedSize
    };

    setQueue(prev => [...prev, newVector]);
  };

  const handleSync = async () => {
    if (queue.length === 0) return;
    
    setIsSyncing(true);
    setProgress(0);

    // Simulate network delay and progress
    const interval = setInterval(() => {
      setProgress(prev => {
        if (prev >= 100) {
          clearInterval(interval);
          return 100;
        }
        return prev + 10;
      });
    }, 200);

    // Simulate async request
    await new Promise(resolve => setTimeout(resolve, 2000));

    // Clear queue after "upload"
    setQueue([]);
    setIsSyncing(false);
    setProgress(0);
    clearInterval(interval);
  };

  return (
    <div style={{ padding: '20px', fontFamily: 'sans-serif', maxWidth: '600px', margin: '0 auto' }}>
      <h2>Vector Sync Dashboard</h2>
      
      <div style={{ marginBottom: '20px', display: 'flex', gap: '10px' }}>
        <button onClick={addVectorToQueue} disabled={isSyncing}>
          Add Vector to Queue
        </button>
        <button onClick={handleSync} disabled={isSyncing || queue.length === 0}>
          {isSyncing ? 'Syncing...' : 'Trigger Sync'}
        </button>
      </div>

      {/* Progress Bar */}
      {isSyncing && (
        <div style={{ marginBottom: '20px' }}>
          <div style={{ background: '#e0e0e0', height: '10px', borderRadius: '5px', overflow: 'hidden' }}>
            <div 
              style={{ 
                width: `${progress}%`, 
                background: '#4caf50', 
                height: '100%', 
                transition: 'width 0.2s' 
              }} 
            />
          </div>
          <small>{progress}% Uploaded</small>
        </div>
      )}

      {/* Summary Card */}
      <div style={{ 
        border: '1px solid #ccc', 
        padding: '10px', 
        marginBottom: '20px', 
        background: '#f9f9f9' 
      }}>
        <strong>Total Data Saved: {formatBytes(totalSavedBytes)}</strong>
      </div>

      {/* Queue List */}
      <h3>Pending Uploads ({queue.length})</h3>
      <ul style={{ listStyle: 'none', padding: 0 }}>
        {queue.map(item => (
          <li key={item.id} style={{ 
            borderBottom: '1px solid #eee', 
            padding: '8px 0', 
            display: 'flex', 
            justifyContent: 'space-between' 
          }}>
            <span>Vector {item.id}</span>
            <span style={{ color: '#666' }}>
              {formatBytes(item.originalSize)} → {formatBytes(item.compressedSize)}
            </span>
          </li>
        ))}
      </ul>
    </div>
  );
};
