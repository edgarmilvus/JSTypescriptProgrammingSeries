/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

// Main Thread Script

// Define the worker code as a Blob to keep this single-file for the example
// In a real app, this would be a separate 'inference.worker.ts' file.
const workerCode = `
self.onmessage = function(e) {
    const { sharedBuffer, dimension } = e.data;
    
    // Create a view into the shared memory
    const sharedArray = new Float32Array(sharedBuffer);
    
    // Simulate Inference: Fill array with deterministic random-like values
    // In reality, this would run the WASM model here.
    for (let i = 0; i < dimension; i++) {
        sharedArray[i] = Math.sin(i + Date.now()) * 10; // Dummy calculation
    }

    // Notify main thread that data is ready
    self.postMessage({ status: 'complete', dimension });
};
`;

const blob = new Blob([workerCode], { type: 'application/javascript' });
const workerUrl = URL.createObjectURL(blob);

// 1. Setup Shared Memory
const VECTOR_DIMENSION = 384;
const BYTES_PER_FLOAT = 4;
const byteLength = VECTOR_DIMENSION * BYTES_PER_FLOAT;

// NOTE: SharedArrayBuffer requires Cross-Origin-Opener-Policy: same-origin headers
// If running in a standard environment without headers, this might fail.
let sharedBuffer: SharedArrayBuffer;

try {
    sharedBuffer = new SharedArrayBuffer(byteLength);
} catch (e) {
    console.error("SharedArrayBuffer is not supported. Ensure COOP/COEP headers are set.");
    throw e;
}

// 2. Instantiate Worker
const inferenceWorker = new Worker(workerUrl);

// 3. Send Shared Buffer to Worker
console.log("Main: Sending shared buffer to worker...");
inferenceWorker.postMessage({
    sharedBuffer: sharedBuffer,
    dimension: VECTOR_DIMENSION
}, [sharedBuffer]); // Transfer ownership to worker for safety

// 4. Listen for completion
inferenceWorker.onmessage = function(e) {
    if (e.data.status === 'complete') {
        // Since we transferred ownership, we can't access 'sharedBuffer' here directly 
        // in the main thread unless we transfer it back or keep a reference.
        // However, for the simulation, let's assume we kept a reference or transferred back.
        
        // To read data, we would need the buffer back. 
        // In this specific code snippet, we transferred ownership away. 
        // In a real loop, we would ping-pong the buffer back and forth.
        
        console.log("Main: Inference complete. Worker generated the vector.");
        // To visualize the result (if we had the buffer back):
        // const resultView = new Float32Array(sharedBuffer);
        // console.log("First 5 elements:", resultView.slice(0, 5));
    }
};
