/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

// Interfaces
interface LocalVector {
  id: string;
  embedding: number[];
  timestamp: number;
  text: string;
}

interface CloudVector {
  id: string;
  embedding: number[];
  timestamp: number;
}

// State
const state: {
  localDb: LocalVector[];
  cloudDb: CloudVector[];
} = {
  localDb: [],
  cloudDb: []
};

// --- Vector Math ---

// Simple hash-based pseudo-random generator for deterministic embeddings
function seededRandom(seed: string): number {
  let hash = 0;
  for (let i = 0; i < seed.length; i++) {
    hash = (hash << 5) - hash + seed.charCodeAt(i);
    hash |= 0;
  }
  return (Math.sin(hash) + 1) / 2; // Normalized 0-1
}

function generateEmbedding(text: string): number[] {
  const dim = 5; // Small dimension for easy visualization
  const vector: number[] = [];
  for (let i = 0; i < dim; i++) {
    // Create a vector based on text length and char codes
    vector.push(seededRandom(text + i));
  }
  return vector;
}

function cosineSimilarity(a: number[], b: number[]): number {
  if (a.length !== b.length) return 0;
  let dotProduct = 0;
  let normA = 0;
  let normB = 0;
  for (let i = 0; i < a.length; i++) {
    dotProduct += a[i] * b[i];
    normA += a[i] * a[i];
    normB += b[i] * b[i];
  }
  if (normA === 0 || normB === 0) return 0;
  return dotProduct / (Math.sqrt(normA) * Math.sqrt(normB));
}

// --- Logic ---

function addLocalVector(text: string) {
  const vector: LocalVector = {
    id: `vec_${Date.now()}`,
    embedding: generateEmbedding(text),
    timestamp: Date.now(),
    text: text
  };
  state.localDb.push(vector);
  updateLogs(`Added local vector: "${text}" (ID: ${vector.id})`);
}

function searchLocal(query: string) {
  const queryVector = generateEmbedding(query);
  const results = state.localDb
    .map(v => ({
      ...v,
      score: cosineSimilarity(queryVector, v.embedding)
    }))
    .sort((a, b) => b.score - a.score)
    .slice(0, 3);

  const resultDiv = document.getElementById('searchResults');
  if (resultDiv) {
    resultDiv.innerHTML = results.map(r => 
      `<div>Match: "${r.text}" (Score: ${r.score.toFixed(4)})</div>`
    ).join('');
  }
}

function syncLocalToCloud() {
  updateLogs("--- Starting Sync ---");
  
  // 1. Simulate uploading 50% of local vectors
  const uploadCount = Math.ceil(state.localDb.length / 2);
  const vectorsToUpload = state.localDb.slice(0, uploadCount);

  vectorsToUpload.forEach(v => {
    // Check for conflict
    const existingInCloud = state.cloudDb.find(c => c.id === v.id);
    
    if (existingInCloud) {
      // Conflict detected
      updateLogs(`Conflict on ID: ${v.id}. Local TS: ${v.timestamp}, Cloud TS: ${existingInCloud.timestamp}`);
      
      if (v.timestamp > existingInCloud.timestamp) {
        updateLogs(`Resolved: Local wins (Newer). Updating cloud.`);
        existingInCloud.embedding = v.embedding;
        existingInCloud.timestamp = v.timestamp;
      } else {
        updateLogs(`Resolved: Cloud wins (Newer). Updating local.`);
        v.embedding = existingInCloud.embedding;
        v.timestamp = existingInCloud.timestamp;
      }
    } else {
      // No conflict, upload
      state.cloudDb.push({
        id: v.id,
        embedding: v.embedding,
        timestamp: v.timestamp
      });
      updateLogs(`Uploaded: ${v.text}`);
    }
  });

  // 2. Introduce a random conflict for demonstration
  if (state.localDb.length > 0) {
    const randomIdx = Math.floor(Math.random() * state.localDb.length);
    const conflictVec = state.localDb[randomIdx];
    
    // Modify local version
    conflictVec.embedding = generateEmbedding(conflictVec.text + "_modified");
    conflictVec.timestamp = Date.now() + 1000; // Future timestamp
    
    // Ensure cloud has an older version
    const cloudIdx = state.cloudDb.findIndex(c => c.id === conflictVec.id);
    if (cloudIdx !== -1) {
        state.cloudDb[cloudIdx].timestamp = Date.now() - 1000; // Make cloud older
    } else {
        state.cloudDb.push({ ...conflictVec, timestamp: Date.now() - 1000 });
    }
    
    updateLogs(`Simulated external modification on Cloud for ID: ${conflictVec.id}`);
  }
  
  updateLogs("--- Sync Complete ---");
}

// --- UI Glue ---

function updateLogs(msg: string) {
  const logDiv = document.getElementById('logs');
  if (logDiv) {
    const p = document.createElement('div');
    p.textContent = `> ${msg}`;
    p.style.fontSize = '12px';
    p.style.borderBottom = '1px solid #eee';
    logDiv.prepend(p);
  }
}

// Attach events
document.addEventListener('DOMContentLoaded', () => {
  const btnAdd = document.getElementById('btnAdd') as HTMLButtonElement;
  const btnSearch = document.getElementById('btnSearch') as HTMLButtonElement;
  const btnSync = document.getElementById('btnSync') as HTMLButtonElement;
  const inputText = document.getElementById('inputText') as HTMLInputElement;
  const inputSearch = document.getElementById('inputSearch') as HTMLInputElement;

  if (btnAdd && inputText) {
    btnAdd.onclick = () => {
      if (inputText.value) {
        addLocalVector(inputText.value);
        inputText.value = '';
      }
    };
  }

  if (btnSearch && inputSearch) {
    btnSearch.onclick = () => {
      if (inputSearch.value) {
        searchLocal(inputSearch.value);
      }
    };
  }

  if (btnSync) {
    btnSync.onclick = syncLocalToCloud;
  }
});
