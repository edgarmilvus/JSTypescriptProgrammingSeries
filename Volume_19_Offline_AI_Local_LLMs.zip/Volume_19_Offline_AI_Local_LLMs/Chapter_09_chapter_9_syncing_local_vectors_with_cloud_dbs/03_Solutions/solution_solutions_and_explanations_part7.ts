/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part7.ts
// Description: Solutions and Explanations
// ==========================================

// --- Types and Interfaces ---

type SyncPayload = {
  vectorId: string;
  embedding: Float32Array;
  metadata: object;
};

// Custom Error Classes
class SyncConflictError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "SyncConflictError";
  }
}

class RateLimitError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "RateLimitError";
  }
}

class ValidationError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "ValidationError";
  }
}

// --- Mock Fetch Implementation ---

// A simple store to simulate backend state
const mockBackendStore = new Map<string, any>();

function mockFetch(url: string, options: RequestInit): Promise<Response> {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      const method = options.method || 'GET';
      
      // Simulate Network Errors
      if (url.includes('rate-limit')) {
        resolve(new Response(JSON.stringify({ error: "Too many requests" }), { status: 429 }));
        return;
      }

      // Simulate Logic
      if (method === 'POST') {
        const body = JSON.parse(options.body as string);
        
        // Simulate Conflict
        if (mockBackendStore.has(body.vectorId)) {
          const existing = mockBackendStore.get(body.vectorId);
          if (body.timestamp <= existing.timestamp) {
             resolve(new Response(JSON.stringify({ error: "Conflict: Newer version exists" }), { status: 409 }));
             return;
          }
        }

        mockBackendStore.set(body.vectorId, body);
        resolve(new Response(JSON.stringify({ success: true, id: body.vectorId }), { status: 200 }));
      } else {
        resolve(new Response(JSON.stringify({ data: "Mock GET response" }), { status: 200 }));
      }
    }, 500); // Simulate latency
  });
}

// --- API Client Class ---

class VectorSyncClient {
  private baseUrl: string;
  private token: string;

  constructor(baseUrl: string, token: string) {
    this.baseUrl = baseUrl;
    this.token = token;
  }

  // Type Guard for Payload Validation
  private isValidPayload(payload: any): payload is SyncPayload {
    return (
      typeof payload === 'object' &&
      payload !== null &&
      typeof payload.vectorId === 'string' &&
      payload.embedding instanceof Float32Array
    );
  }

  /**
   * Generic request method with validation and error mapping.
   */
  async request<T>(endpoint: string, method: 'GET' | 'POST', data?: any): Promise<T> {
    // 1. Validation (only for POST)
    if (method === 'POST' && data) {
      if (!this.isValidPayload(data)) {
        throw new ValidationError("Invalid payload: vectorId or embedding missing.");
      }
    }

    // 2. Prepare Request
    const url = `${this.baseUrl}${endpoint}`;
    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${this.token}`
    };

    const options: RequestInit = {
      method,
      headers
    };

    if (method === 'POST' && data) {
      // Convert Float32Array to standard array for JSON serialization in mock
      const serializedData = {
        ...data,
        embedding: Array.from(data.embedding)
      };
      options.body = JSON.stringify(serializedData);
    }

    // 3. Execute (using mockFetch here, but would be global fetch in production)
    const response = await mockFetch(url, options);

    // 4. Error Mapping
    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}));
      
      switch (response.status) {
        case 409:
          throw new SyncConflictError(errorData.error || "Data conflict detected");
        case 429:
          throw new RateLimitError(errorData.error || "Rate limit exceeded");
        case 400:
        case 422:
          throw new ValidationError(errorData.error || "Validation failed on server");
        default:
          throw new Error(`Sync failed: ${response.status} ${response.statusText}`);
      }
    }

    // 5. Return Typed Result
    return (await response.json()) as T;
  }
}

// --- Usage Example ---

async function runClientDemo() {
  const client = new VectorSyncClient('https://api.cloud-vectors.com/v1/', 'secret_token_123');

  const payload: SyncPayload = {
    vectorId: 'vec_001',
    embedding: new Float32Array([0.1, 0.5, 0.9]),
    metadata: { tags: ['demo'] }
  };

  try {
    console.log("Sending vector...");
    const result = await client.request<{ success: boolean; id: string }>('sync', 'POST', payload);
    console.log("Success:", result);

    // Try to send invalid data
    // await client.request('sync', 'POST', { vectorId: 'missing_embedding' });
    
  } catch (error) {
    if (error instanceof SyncConflictError) {
      console.error("Conflict detected! Resolve manually.", error.message);
    } else if (error instanceof ValidationError) {
      console.error("Validation failed:", error.message);
    } else {
      console.error("Unknown error:", error);
    }
  }
}

// runClientDemo();
