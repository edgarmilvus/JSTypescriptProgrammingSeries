/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

// Import necessary Node.js crypto module for AES-256 encryption
import crypto from 'crypto';

// ============================================================================
// 1. TYPE DEFINITIONS
// ============================================================================

/**
 * Represents the structure of a secure AI request.
 * @property prompt - The raw user input.
 * @property userId - Identifier for the user.
 */
interface SecurePromptRequest {
  prompt: string;
  userId: string;
}

/**
 * Represents the encrypted payload sent to the external service.
 * @property iv - Initialization Vector for AES-GCM.
 * @property encryptedData - The ciphertext.
 * @property authTag - Authentication tag for integrity verification.
 */
interface EncryptedPayload {
  iv: Buffer;
  encryptedData: Buffer;
  authTag: Buffer;
}

/**
 * Represents the response from the mock embedding service.
 * @property embedding - The generated vector (simulated as an array of numbers).
 */
interface EmbeddingResponse {
  embedding: number[];
}

// ============================================================================
// 2. CONFIGURATION & CONSTANTS
// ============================================================================

// In a real app, these keys should be managed via Hardware Security Modules (HSM)
// or Environment Variables injected at runtime, never hardcoded.
const ALGORITHM = 'aes-256-gcm';
const SECRET_KEY = crypto.scryptSync('secure_password_salt', 'salt', 32); // 256-bit key

// ============================================================================
// 3. ENCRYPTION/DECRYPTION UTILITIES
// ============================================================================

/**
 * Encrypts sensitive text using AES-256-GCM.
 * GCM provides both confidentiality and integrity.
 * 
 * @param text - The plaintext prompt.
 * @returns EncryptedPayload object containing IV, ciphertext, and auth tag.
 */
function encrypt(text: string): EncryptedPayload {
  const iv = crypto.randomBytes(16); // Initialization Vector (12 bytes for GCM is standard)
  const cipher = crypto.createCipheriv(ALGORITHM, SECRET_KEY, iv);
  
  let encrypted = cipher.update(text, 'utf8', 'hex');
  encrypted += cipher.final('hex');
  
  const authTag = cipher.getAuthTag();
  
  return {
    iv: iv,
    encryptedData: Buffer.from(encrypted, 'hex'),
    authTag: authTag
  };
}

/**
 * Decrypts the payload back to plaintext.
 * 
 * @param payload - The EncryptedPayload object.
 * @returns The original plaintext string.
 */
function decrypt(payload: EncryptedPayload): string {
  const decipher = crypto.createDecipheriv(ALGORITHM, SECRET_KEY, payload.iv);
  
  // Set the authentication tag for integrity checking
  decipher.setAuthTag(payload.authTag);
  
  let decrypted = decipher.update(payload.encryptedData.toString('hex'), 'hex', 'utf8');
  decrypted += decipher.final('utf8');
  
  return decrypted;
}

// ============================================================================
// 4. MOCK EXTERNAL SERVICE (SIMULATION)
// ============================================================================

/**
 * Simulates an external AI Embedding Service (e.g., a local WASM model or cloud API).
 * This function mimics network latency and returns a fixed vector.
 * 
 * @param encryptedPayload - The data to process (in reality, sent over HTTP).
 * @returns A Promise that resolves with a mock embedding vector.
 */
async function mockEmbeddingService(encryptedPayload: EncryptedPayload): Promise<EmbeddingResponse> {
  // Simulate network delay (e.g., 500ms to generate embeddings)
  return new Promise((resolve) => {
    setTimeout(() => {
      // In a real scenario, the service would decrypt internally or process encrypted data homomorphically.
      // Here, we simulate returning a vector.
      const mockVector: number[] = [0.1, 0.2, 0.3, 0.4, 0.5]; 
      resolve({ embedding: mockVector });
    }, 500);
  });
}

// ============================================================================
// 5. MAIN ASYNCHRONOUS WORKFLOW
// ============================================================================

/**
 * The main entry point for the secure AI processing pipeline.
 * 1. Receives raw prompt.
 * 2. Encrypts sensitive data.
 * 3. Awaits the async embedding generation.
 * 4. Decrypts/Processes the result.
 * 
 * @param request - The incoming user request.
 */
async function processSecurePrompt(request: SecurePromptRequest): Promise<void> {
  console.log(`[1] Received request from User: ${request.userId}`);
  console.log(`[2] Raw Prompt: "${request.prompt}"`);

  // --- Step A: Encryption (Data at Rest Security) ---
  const encryptedData = encrypt(request.prompt);
  console.log(`[3] Data Encrypted. Ciphertext length: ${encryptedData.encryptedData.length} bytes`);

  // --- Step B: Asynchronous Processing ---
  // We 'await' the external service. The Node.js event loop is free to handle other requests here.
  console.log(`[4] Sending to Embedding Service (Async)...`);
  
  try {
    const embeddingResult = await mockEmbeddingService(encryptedData);
    
    // --- Step C: Post-Processing ---
    console.log(`[5] Received Embedding Vector: [${embeddingResult.embedding.join(', ')}]`);
    
    // In a real app, you might store this vector in a database or pass it to the LLM.
    // For this demo, we verify the original data can be decrypted.
    const decryptedPrompt = decrypt(encryptedData);
    console.log(`[6] Verification: Decrypted Prompt matches original? ${decryptedPrompt === request.prompt}`);
    
  } catch (error) {
    console.error("Error during async processing:", error);
  }
}

// ============================================================================
// 6. EXECUTION
// ============================================================================

// Simulate an incoming web request
const demoRequest: SecurePromptRequest = {
  userId: "user_12345",
  prompt: "My social security number is 123-45-6789."
};

// Execute the workflow
processSecurePrompt(demoRequest);
