/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// pages/api/secure-ai-pipeline.ts
// This is a Next.js Server Action or API Route handler.
// It demonstrates the secure handling of sensitive AI data.

import { NextApiRequest, NextApiResponse } from 'next';
import CryptoJS from 'crypto-js';
import { v4 as uuidv4 } from 'uuid';

// ==========================================
// 1. SECURE KEY MANAGEMENT (Hardware Backed Simulation)
// ==========================================

/**
 * Simulates a hardware-backed keystore (e.g., Android Keystore or iOS Keychain).
 * In a real mobile environment, this key would be generated and stored securely
 * at the device level, never exposed to the application memory directly.
 * For this script, we derive a key from a secure environment variable.
 */
const getHardwareBackedKey = (): string => {
  // CRITICAL: In production, this key is retrieved from the secure enclave
  // or a Key Management Service (KMS), not a process environment variable.
  // This simulates the retrieval of a master key for AES-256.
  const masterKey = process.env.NEXT_PUBLIC_ENCRYPTION_KEY;
  if (!masterKey) {
    throw new Error('Encryption key not found. Check environment variables.');
  }
  return masterKey;
};

// ==========================================
// 2. ENCRYPTION MODULE (SRP: Data Protection)
// ==========================================

/**
 * Handles AES-256 encryption and decryption of raw sensitive data.
 * Strictly isolated to ensure no raw data leaks outside this module.
 */
class SecureEncryptor {
  private key: string;

  constructor(key: string) {
    this.key = key;
  }

  /**
   * Encrypts a string payload using AES-256.
   * @param plaintext - The sensitive raw data (e.g., user note).
   * @returns The encrypted ciphertext string.
   */
  public encrypt(plaintext: string): string {
    try {
      const ciphertext = CryptoJS.AES.encrypt(plaintext, this.key).toString();
      return ciphertext;
    } catch (error) {
      console.error('Encryption failed:', error);
      throw new Error('Data encryption error');
    }
  }

  /**
   * Decrypts ciphertext back to plaintext.
   * Only used inside the Secure Enclave (Inference Module).
   * @param ciphertext - The encrypted data.
   * @returns The original plaintext string.
   */
  public decrypt(ciphertext: string): string {
    try {
      const bytes = CryptoJS.AES.decrypt(ciphertext, this.key);
      const originalText = bytes.toString(CryptoJS.enc.Utf8);
      if (!originalText) throw new Error('Decryption failed (invalid key or data)');
      return originalText;
    } catch (error) {
      console.error('Decryption failed:', error);
      throw new Error('Data decryption error');
    }
  }
}

// ==========================================
// 3. VECTOR DATABASE MODULE (SRP: Storage & Retrieval)
// ==========================================

/**
 * Simulates interaction with a pgvector database via Supabase.
 * Handles storage of encrypted vectors and retrieval for similarity search.
 * Note: In a real scenario, the vector embedding generation happens 
 * BEFORE encryption, but the stored vector represents the encrypted content's metadata.
 */
class VectorDatabaseService {
  private encryptor: SecureEncryptor;

  constructor(encryptor: SecureEncryptor) {
    this.encryptor = encryptor;
  }

  /**
   * Ingests sensitive data: Encrypts text -> Generates Vector -> Stores.
   * In a real app, vector generation (via ONNX model) happens here.
   * @param userId - The owner of the data.
   * @param content - The raw sensitive text.
   * @returns A promise resolving to the stored record ID.
   */
  public async ingestSensitiveData(userId: string, content: string): Promise<string> {
    // 1. Encrypt the content immediately upon ingestion
    const encryptedContent = this.encryptor.encrypt(content);

    // 2. Simulate Vector Embedding Generation (Client-side or Server-side)
    // For this demo, we generate a fake 1536-dimension vector (standard for OpenAI ada-002)
    const vector: number[] = Array.from({ length: 1536 }, () => Math.random());

    // 3. Simulate Database Insertion (pgvector syntax)
    // SQL: INSERT INTO document_embeddings (user_id, content_encrypted, embedding) VALUES ($1, $2, $3)
    const recordId = uuidv4();
    console.log(`[DB Service] Storing encrypted vector for user ${userId}. ID: ${recordId}`);
    
    // Mock DB call
    await new Promise(resolve => setTimeout(resolve, 100)); // Simulate network latency

    return recordId;
  }

  /**
   * Simulates a similarity search query on encrypted data.
   * Returns the encrypted content blobs that match the query vector.
   * @param queryVector - The vector representation of the user's prompt.
   * @returns A list of encrypted content strings.
   */
  public async searchSimilarEncrypted(queryVector: number[]): Promise<string[]> {
    // SQL: SELECT content_encrypted FROM document_embeddings ORDER BY embedding <=> $1 LIMIT 3
    console.log('[DB Service] Performing pgvector similarity search...');
    
    // Mock retrieval of encrypted strings
    const mockEncryptedResults = [
      "U2FsdGVkX1+MockEncryptedString1==", // "My secret meeting is at 5 PM"
      "U2FsdGVkX1+MockEncryptedString2=="  // "Project Alpha budget: $50k"
    ];

    return mockEncryptedResults;
  }
}

// ==========================================
// 4. SECURE ENCLAVE (SRP: Inference & Processing)
// ==========================================

/**
 * Simulates a Trusted Execution Environment (TEE) or Secure Enclave.
 * This module is responsible for:
 * 1. Receiving encrypted data.
 * 2. Decrypting data ONLY in memory.
 * 3. Processing (Inference) using the raw data.
 * 4. Returning the result (never returning raw data unless necessary).
 */
class SecureEnclave {
  private encryptor: SecureEncryptor;

  constructor(encryptor: SecureEncryptor) {
    this.encryptor = encryptor;
  }

  /**
   * Executes a sensitive prompt within the secure boundary.
   * @param encryptedContext - The retrieved encrypted data from DB.
   * @param userPrompt - The user's current query.
   * @returns The AI-generated response.
   */
  public async executeInference(encryptedContext: string[], userPrompt: string): Promise<string> {
    console.log('[Secure Enclave] Entering trusted execution environment...');

    // 1. Decrypt context strictly within this scope
    const rawContexts = encryptedContext.map(enc => this.encryptor.decrypt(enc));
    
    // 2. Construct prompt (Context + User Query)
    // In a real LLM, this is passed to the model weights.
    const fullPrompt = `
      Context: ${rawContexts.join('\n')}
      User Prompt: ${userPrompt}
      Generate a helpful response based strictly on the context.
    `;

    // 3. Simulate Local LLM Inference (e.g., Llama 3 running via ONNX/WebGPU)
    // This is where the heavy computation happens.
    const inferenceResult = await this.simulateLocalLLM(fullPrompt);

    // 4. Cleanup: Ensure raw strings are cleared from memory (garbage collection dependent)
    rawContexts.forEach(ctx => {
      // In low-level languages, we would zero-out memory here.
      // In JS/TS, we rely on GC, but we nullify references immediately.
      ctx = null as any;
    });

    return inferenceResult;
  }

  private async simulateLocalLLM(prompt: string): Promise<string> {
    // Simulate inference latency
    await new Promise(resolve => setTimeout(resolve, 200));
    return `AI Response based on: "${prompt.substring(0, 50)}..." [Generated Locally]`;
  }
}

// ==========================================
// 5. ORCHESTRATOR (Main Logic)
// ==========================================

/**
 * Main Server Action Handler.
 * Orchestrates the flow: Key Gen -> Encryption -> Storage -> Search -> Inference.
 */
export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  try {
    // 1. Initialize Modules (Dependency Injection)
    const masterKey = getHardwareBackedKey();
    const encryptor = new SecureEncryptor(masterKey);
    const dbService = new VectorDatabaseService(encryptor);
    const secureEnclave = new SecureEnclave(encryptor);

    // 2. Scenario: User ingests sensitive data
    const userId = 'user_123';
    const sensitiveNote = 'My private API key is sk-1234567890abcdef and I have a meeting with the board at 2 PM.';
    
    console.log('--- Step 1: Ingestion & Encryption ---');
    await dbService.ingestSensitiveData(userId, sensitiveNote);

    // 3. Scenario: User queries the AI
    const userQuery = 'What is my schedule and secret key?';
    const queryVector = Array.from({ length: 1536 }, () => Math.random()); // Simulated query embedding

    console.log('\n--- Step 2: Vector Search (Encrypted) ---');
    const encryptedResults = await dbService.searchSimilarEncrypted(queryVector);

    console.log('\n--- Step 3: Secure Enclave Inference ---');
    const aiResponse = await secureEnclave.executeInference(encryptedResults, userQuery);

    // 4. Return result to client
    // Note: We never send the raw sensitive data back to the client in this flow.
    res.status(200).json({ 
      success: true, 
      response: aiResponse,
      note: "Raw data never left the secure enclave." 
    });

  } catch (error) {
    console.error('Pipeline Error:', error);
    res.status(500).json({ success: false, error: 'Internal Security Error' });
  }
}
