/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// Mocking a local persistence layer (e.g., file system or IndexedDB)
const storage = new Map<string, { iv: Uint8Array; data: ArrayBuffer }>();

export class SecureVectorStore {
  private key: CryptoKey | null = null;
  private salt: Uint8Array;

  constructor(password: string, salt?: Uint8Array) {
    // If a salt is provided, we use it (for existing store). 
    // Otherwise, generate a new one (for new store).
    this.salt = salt || window.crypto.getRandomValues(new Uint8Array(16));
    this.initializeKey(password);
  }

  private async initializeKey(password: string): Promise<void> {
    const enc = new TextEncoder();
    const keyMaterial = await window.crypto.subtle.importKey(
      "raw",
      enc.encode(password),
      { name: "PBKDF2" },
      false,
      ["deriveKey"]
    );

    this.key = await window.crypto.subtle.deriveKey(
      {
        name: "PBKDF2",
        salt: this.salt,
        iterations: 100000,
        hash: "SHA-256",
      },
      keyMaterial,
      { name: "AES-GCM", length: 256 },
      false, // Key is non-extractable
      ["encrypt", "decrypt"]
    );
  }

  public async addVector(vectorId: string, vector: Float32Array): Promise<void> {
    if (!this.key) throw new Error("Key not initialized.");

    // 1. Serialize Float32Array to ArrayBuffer
    const dataBuffer = vector.buffer.slice(
      vector.byteOffset,
      vector.byteOffset + vector.byteLength
    );

    // 2. Generate IV
    const iv = window.crypto.getRandomValues(new Uint8Array(12));

    // 3. Encrypt
    const encryptedData = await window.crypto.subtle.encrypt(
      {
        name: "AES-GCM",
        iv: iv,
      },
      this.key,
      dataBuffer
    );

    // 4. Store (Mocking file write)
    storage.set(vectorId, { iv, data: encryptedData });
  }

  public async getVector(vectorId: string): Promise<Float32Array> {
    if (!this.key) throw new Error("Key not initialized.");

    const record = storage.get(vectorId);
    if (!record) throw new Error("Vector ID not found.");

    try {
      // 1. Decrypt
      const decryptedBuffer = await window.crypto.subtle.decrypt(
        {
          name: "AES-GCM",
          iv: record.iv,
        },
        this.key,
        record.data
      );

      // 2. Deserialize back to Float32Array
      return new Float32Array(decryptedBuffer);
    } catch (e) {
      throw new Error("Decryption failed: Wrong password or corrupted data.");
    }
  }

  // Helper to get salt for persistence (needed to re-initialize later)
  public getSalt(): Uint8Array {
    return this.salt;
  }
}
