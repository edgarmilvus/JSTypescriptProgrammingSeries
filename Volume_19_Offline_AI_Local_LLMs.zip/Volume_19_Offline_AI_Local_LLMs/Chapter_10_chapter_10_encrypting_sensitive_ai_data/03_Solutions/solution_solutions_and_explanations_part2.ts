/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

export class KeyManager {
  private key: CryptoKey | null = null;
  private static readonly STORAGE_KEY = "app_key_exists";

  constructor() {
    this.loadOrGenerateKey();
  }

  private async loadOrGenerateKey(): Promise<void> {
    const keyExists = localStorage.getItem(KeyManager.STORAGE_KEY);

    if (keyExists) {
      // SIMULATION: In a real hardware keystore, we would get a handle/reference here.
      // Since we are in a browser environment without a real TPM/HSM, we must store the key.
      // However, to simulate "Hardware" behavior, we assume the key is stored securely 
      // by the browser's internal storage mechanism (e.g., if using OS-level auth).
      // For this exercise, we regenerate if not present in memory, assuming the 
      // "Hardware" is unlocked.
      console.log("Simulating loading key from hardware reference...");
      // In a real simulation, we might re-hydrate from a secure context, 
      // but here we will just generate a new one if the app restarted 
      // (since we can't persist CryptoKey objects directly to localStorage).
      // To make this work for the exercise, we will generate a new one if the flag exists
      // but the memory context is lost (simulating a reboot).
      await this.generateNewKey();
    } else {
      await this.generateNewKey();
      localStorage.setItem(KeyManager.STORAGE_KEY, "true");
    }
  }

  private async generateNewKey(): Promise<void> {
    this.key = await window.crypto.subtle.generateKey(
      {
        name: "AES-GCM",
        length: 256,
      },
      false, // Non-extractable (Hardware simulation)
      ["encrypt", "decrypt"]
    );
  }

  // Simulates the hardware restriction: You cannot ask the hardware for the raw key bytes.
  public getRawKeyBytes(): never {
    throw new Error("Security Violation: Cannot export raw key material from Hardware Keystore.");
  }

  public async encrypt(data: ArrayBuffer): Promise<{ iv: Uint8Array; ciphertext: ArrayBuffer }> {
    if (!this.key) throw new Error("Key not initialized.");
    
    const iv = window.crypto.getRandomValues(new Uint8Array(12));
    const ciphertext = await window.crypto.subtle.encrypt(
      { name: "AES-GCM", iv },
      this.key,
      data
    );

    return { iv, ciphertext };
  }

  public async decrypt(ciphertext: ArrayBuffer, iv: Uint8Array): Promise<ArrayBuffer> {
    if (!this.key) throw new Error("Key not initialized.");

    return await window.crypto.subtle.decrypt(
      { name: "AES-GCM", iv },
      this.key,
      ciphertext
    );
  }
}
