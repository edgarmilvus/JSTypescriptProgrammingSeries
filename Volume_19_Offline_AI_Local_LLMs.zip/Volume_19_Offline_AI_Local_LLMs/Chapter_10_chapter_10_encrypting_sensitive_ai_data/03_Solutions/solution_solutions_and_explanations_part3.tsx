/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState } from 'react';

// --- The "Enclave" Utility ---
class PromptEnclave {
  // Hardcoded key for exercise purposes (in reality, injected securely)
  private static key: CryptoKey | null = null;

  private static async getKey(): Promise<CryptoKey> {
    if (!PromptEnclave.key) {
      const enc = new TextEncoder();
      const keyMaterial = await window.crypto.subtle.importKey(
        "raw",
        enc.encode("hardcoded-secret-key-32bytes"), 
        { name: "AES-GCM" },
        false,
        ["encrypt", "decrypt"]
      );
      PromptEnclave.key = keyMaterial;
    }
    return PromptEnclave.key;
  }

  public static async encrypt(text: string): Promise<ArrayBuffer> {
    const key = await this.getKey();
    const iv = window.crypto.getRandomValues(new Uint8Array(12));
    const data = new TextEncoder().encode(text);
    
    return window.crypto.subtle.encrypt(
      { name: "AES-GCM", iv },
      key,
      data
    );
  }

  public static async decrypt(ciphertext: ArrayBuffer, iv: Uint8Array): Promise<string> {
    const key = await this.getKey();
    const decryptedBuffer = await window.crypto.subtle.decrypt(
      { name: "AES-GCM", iv },
      key,
      ciphertext
    );
    return new TextDecoder().decode(decryptedBuffer);
  }
}

// --- React Component ---
export const SecurePromptInput: React.FC = () => {
  const [input, setInput] = useState('');
  const [encryptedPayload, setEncryptedPayload] = useState<string | null>(null);
  const [decryptedStatus, setDecryptedStatus] = useState<'LOCKED' | 'UNLOCKED'>('LOCKED');
  const [decryptedText, setDecryptedText] = useState<string | null>(null);
  const [iv, setIv] = useState<Uint8Array | null>(null); // Need to store IV for decryption

  const handleSecureClick = async () => {
    if (!input.trim()) return;

    // 1. Call Enclave to encrypt
    const ciphertext = await PromptEnclave.encrypt(input);
    
    // 2. Generate IV (must be stored alongside ciphertext)
    const newIv = new Uint8Array(12); // In real code, this is generated inside enclave and returned
    window.crypto.getRandomValues(newIv); 
    // Note: For the enclave pattern to work perfectly, the IV should be returned with the blob.
    // Assuming the enclave handles IV internally or we mock it here for simplicity.
    
    // Convert ArrayBuffer to Base64 for display/storage
    const base64 = btoa(String.fromCharCode(...new Uint8Array(ciphertext)));
    
    setEncryptedPayload(base64);
    setIv(newIv); // Storing IV (this is safe, IV is not secret)
    
    setInput(''); // Clear input immediately
    setDecryptedStatus('LOCKED');
    setDecryptedText(null);
  };

  const handleDecryptClick = async () => {
    if (!encryptedPayload || !iv) return;

    // Mock password check
    const password = prompt("Enter decryption password (hint: 'secret')");
    if (password !== "secret") {
      alert("Access Denied");
      return;
    }

    try {
      // Convert Base64 back to ArrayBuffer
      const binaryString = atob(encryptedPayload);
      const bytes = new Uint8Array(binaryString.length);
      for (let i = 0; i < binaryString.length; i++) {
        bytes[i] = binaryString.charCodeAt(i);
      }

      const text = await PromptEnclave.decrypt(bytes.buffer, iv);
      
      setDecryptedText(text);
      setDecryptedStatus('UNLOCKED');
    } catch (e) {
      alert("Decryption failed");
    }
  };

  const getStatusColor = () => {
    return decryptedStatus === 'UNLOCKED' ? 'green' : 'red';
  };

  return (
    <div style={{ border: `2px solid ${getStatusColor()}`, padding: '10px', borderRadius: '8px' }}>
      <h3>Secure Prompt Input ({decryptedStatus})</h3>
      
      {decryptedStatus === 'LOCKED' && (
        <>
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Enter sensitive prompt..."
          />
          <button onClick={handleSecureClick} disabled={!input}>
            Secure & Encrypt
          </button>
        </>
      )}

      {encryptedPayload && (
        <div style={{ marginTop: '10px', background: '#f0f0f0', padding: '5px' }}>
          <p><strong>Encrypted Blob (Base64):</strong> {encryptedPayload.substring(0, 20)}...</p>
          <button onClick={handleDecryptClick}>Decrypt</button>
        </div>
      )}

      {decryptedStatus === 'UNLOCKED' && decryptedText && (
        <div style={{ marginTop: '10px', color: 'green' }}>
          <strong>Decrypted Content:</strong> {decryptedText}
        </div>
      )}
    </div>
  );
};
