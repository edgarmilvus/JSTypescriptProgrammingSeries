/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

export class SecureNamespaceManager {
  private masterPassword: string;
  private globalSalt: Uint8Array;

  constructor(masterPassword: string) {
    this.masterPassword = masterPassword;
    // In a real app, this global salt is stored permanently (unencrypted)
    this.globalSalt = window.crypto.getRandomValues(new Uint8Array(16));
  }

  /**
   * Derives a unique key for a specific namespace.
   * The salt is a combination of the global salt AND the namespace string.
   */
  private async getNamespaceKey(namespace: string): Promise<CryptoKey> {
    const enc = new TextEncoder();
    
    // Combine global salt with namespace to create a unique salt per namespace
    const namespaceBuffer = enc.encode(namespace);
    const combinedSalt = new Uint8Array(this.globalSalt.byteLength + namespaceBuffer.byteLength);
    combinedSalt.set(this.globalSalt);
    combinedSalt.set(namespaceBuffer, this.globalSalt.byteLength);

    const keyMaterial = await window.crypto.subtle.importKey(
      "raw",
      enc.encode(this.masterPassword),
      { name: "PBKDF2" },
      false,
      ["deriveKey"]
    );

    return window.crypto.subtle.deriveKey(
      {
        name: "PBKDF2",
        salt: combinedSalt,
        iterations: 100000,
        hash: "SHA-256",
      },
      keyMaterial,
      { name: "AES-GCM", length: 256 },
      false,
      ["encrypt", "decrypt"]
    );
  }

  public async writeToNamespace(
    namespace: string,
    vectorId: string,
    vector: Float32Array
  ): Promise<void> {
    const key = await this.getNamespaceKey(namespace);
    
    const dataBuffer = vector.buffer.slice(
      vector.byteOffset,
      vector.byteOffset + vector.byteLength
    );
    const iv = window.crypto.getRandomValues(new Uint8Array(12));

    const encryptedData = await window.crypto.subtle.encrypt(
      { name: "AES-GCM", iv },
      key,
      dataBuffer
    );

    // Mock storage: Key format "namespace:vectorId"
    const storageKey = `${namespace}:${vectorId}`;
    // Save to persistent storage (mocked as Map)
    storage.set(storageKey, { iv, data: encryptedData });
  }

  public async readFromNamespace(
    namespace: string,
    vectorId: string
  ): Promise<Float32Array | null> {
    const key = await this.getNamespaceKey(namespace);
    const storageKey = `${namespace}:${vectorId}`;
    
    const record = storage.get(storageKey);
    if (!record) return null;

    try {
      const decryptedBuffer = await window.crypto.subtle.decrypt(
        { name: "AES-GCM", iv: record.iv },
        key,
        record.data
      );
      return new Float32Array(decryptedBuffer);
    } catch (e) {
      // This will throw if the namespace key is different (cross-contamination attempt)
      throw new Error(`Decryption failed for namespace '${namespace}'. Data may belong to a different tenant.`);
    }
  }
}

// Mock Storage for the example
const storage = new Map<string, { iv: Uint8Array; data: ArrayBuffer }>();
