/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * @fileoverview Client-side Zero-Shot Classification Example
 * @description This module demonstrates loading a local Transformer model
 *              and performing inference entirely within the browser.
 * @requires @xenova/transformers
 */

// Import the necessary library for in-browser Transformers
// Note: In a real project, you would install this via npm:
// npm install @xenova/transformers
import { pipeline, PipelineType } from '@xenova/transformers';

// Define types for better type safety
type ClassificationResult = {
  label: string;
  score: number;
};

/**
 * Performs zero-shot classification on a given text string.
 * 
 * @param text - The input text to classify.
 * @param candidateLabels - An array of potential labels to classify the text into.
 * @returns A promise that resolves to an array of classification results.
 */
async function classifyText(
  text: string,
  candidateLabels: string[]
): Promise<ClassificationResult[]> {
  try {
    console.log('Initializing pipeline...');
    
    // Initialize the zero-shot classification pipeline.
    // 'distilbert-base-uncased-mnli' is a lightweight model suitable for this demo.
    // 'quantized' versions (int8) are often used in mobile contexts to reduce size.
    const classifier = await pipeline(
      'zero-shot-classification' as PipelineType,
      'Xenova/distilbert-base-uncased-mnli'
    );

    console.log('Model loaded. Running inference...');
    
    // Perform the classification
    const result = await classifier(text, candidateLabels, {
      multi_label: false, // Set to true if multiple labels can apply
    });

    // Format and return the top results
    return result.labels.map((label: string, index: number) => ({
      label,
      score: result.scores[index],
    }));
  } catch (error) {
    console.error('Error during classification:', error);
    throw new Error('Classification failed. Check console logs.');
  }
}

// --- Execution Logic (Simulating a Web App Event) ---

/**
 * Main entry point to simulate a web application context.
 * This would typically be triggered by a user event (e.g., button click).
 */
async function main() {
  const inputText = "The new update significantly improves battery life and adds dark mode.";
  const labels = ["positive", "negative", "neutral"];

  try {
    const results = await classifyText(inputText, labels);
    
    // Log the results (In a real app, this would update the DOM)
    console.log('--- Classification Results ---');
    results.forEach((res) => {
      console.log(`${res.label}: ${(res.score * 100).toFixed(2)}%`);
    });
  } catch (e) {
    console.error(e);
  }
}

// Execute the main function
// In a browser environment, this might be called inside a window.onload event
main();
