/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// src/hooks/useLocalInference.ts
import { useState, useEffect, useRef } from 'react';

// --- Types & Interfaces ---

/**
 * Represents the structure of a classification result.
 * @typedef {Object} ClassificationResult
 * @property {string} label - The predicted category (e.g., 'Support', 'Sales').
 * @property {number} confidence - The probability score (0.0 to 1.0).
 */
interface ClassificationResult {
  label: string;
  confidence: number;
}

/**
 * Configuration for the inference worker.
 * In a real scenario, this would point to the model URL (e.g., 'phi-3-quantized.onnx').
 */
interface InferenceConfig {
  modelUrl?: string;
  labels: string[];
}

// --- Constants ---

// Simulated vocabulary for tokenization (simplified for demonstration).
// In a real app, this would be the tokenizer.json from the Hugging Face repo.
const VOCABULARY: Record<string, number> = {
  hello: 1,
  help: 2,
  buy: 3,
  price: 4,
  support: 5,
  issue: 6,
  error: 7,
  hello: 8,
  hi: 9,
  purchase: 10,
  cost: 11,
};

/**
 * Web Worker Script (Inline for portability, usually a separate file).
 * This simulates the "Headless Inference" environment where heavy computation occurs.
 * It mimics tokenization and a simple embedding dot-product for classification.
 */
const workerScript = `
self.onmessage = function(e) {
  const { type, text, labels } = e.data;

  if (type === 'CLASSIFY') {
    // 1. Tokenization (Simulated)
    // Real Phi-3/Gemma would use BPE/WordPiece tokenization here.
    const tokens = text.toLowerCase().split(/\\s+/);
    
    // 2. Embedding & Scoring (Simulated Zero-Shot)
    // We map tokens to a simple vector space and calculate similarity with label keywords.
    const scores: Record<string, number> = {};
    
    labels.forEach(label => {
      scores[label] = 0;
      // Simple keyword matching to simulate embedding similarity
      if (label.toLowerCase().includes('support') && (tokens.includes('help') || tokens.includes('issue'))) {
        scores[label] += 0.8;
      }
      if (label.toLowerCase().includes('sales') && (tokens.includes('buy') || tokens.includes('price'))) {
        scores[label] += 0.8;
      }
      // Add noise to simulate real-world variance
      scores[label] += Math.random() * 0.1;
    });

    // 3. Softmax Normalization
    const expScores = Object.values(scores).map(x => Math.exp(x));
    const sumExp = expScores.reduce((a, b) => a + b, 0);
    const probabilities = expScores.map(x => x / sumExp);

    // 4. Format Result
    const result = labels.map((label, i) => ({
      label,
      confidence: probabilities[i]
    })).sort((a, b) => b.confidence - a.confidence);

    // 5. Send back to Main Thread
    self.postMessage({ type: 'RESULT', result });
  }
};
`;

/**
 * Custom Hook for Mobile-Optimized LLM Inference.
 * Manages the Web Worker lifecycle and handles the inference pipeline.
 */
export const useLocalInference = (config: InferenceConfig) => {
  const [isReady, setIsReady] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [result, setResult] = useState<ClassificationResult | null>(null);
  
  // Use a ref to hold the worker instance to avoid re-renders
  const workerRef = useRef<Worker | null>(null);

  useEffect(() => {
    // 1. Initialize Web Worker
    // We create a Blob URL from the script string to avoid external file dependencies in this demo.
    const blob = new Blob([workerScript], { type: 'application/javascript' });
    const workerUrl = URL.createObjectURL(blob);
    
    const worker = new Worker(workerUrl);
    workerRef.current = worker;

    // 2. Setup Message Listener
    worker.onmessage = (e) => {
      if (e.data.type === 'RESULT') {
        setResult(e.data.result[0]); // Take the highest confidence result
        setIsProcessing(false);
      }
    };

    // 3. Simulate Model Loading (Warm-up)
    // In a real app, this is where we would await ort.InferenceSession.create(config.modelUrl)
    setTimeout(() => setIsReady(true), 500);

    // 4. Cleanup
    return () => {
      worker.terminate();
      URL.revokeObjectURL(workerUrl);
    };
  }, [config.modelUrl]);

  /**
   * Triggers the classification of input text.
   * @param {string} text - The user input to classify.
   */
  const classify = (text: string) => {
    if (!workerRef.current || !isReady) return;

    setIsProcessing(true);
    setResult(null);

    // Send data to the Headless Worker
    workerRef.current.postMessage({
      type: 'CLASSIFY',
      text,
      labels: config.labels
    });
  };

  return { isReady, isProcessing, result, classify };
};
