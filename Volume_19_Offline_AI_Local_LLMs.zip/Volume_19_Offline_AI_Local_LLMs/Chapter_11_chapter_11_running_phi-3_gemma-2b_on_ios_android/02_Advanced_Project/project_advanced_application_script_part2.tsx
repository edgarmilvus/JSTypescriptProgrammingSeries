/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script_part2.tsx
// Description: Advanced Application Script
// ==========================================

// src/components/IntentClassifierApp.tsx
import React, { useState } from 'react';
import { useLocalInference } from '../hooks/useLocalInference';

const IntentClassifierApp: React.FC = () => {
  const [inputText, setInputText] = useState('');
  
  // Initialize the local inference engine
  // We define our zero-shot labels here. No training required.
  const { isReady, isProcessing, result, classify } = useLocalInference({
    labels: ['Customer Support', 'Sales Inquiry', 'Technical Issue']
  });

  const handleAnalyze = () => {
    if (inputText.trim()) {
      classify(inputText);
    }
  };

  return (
    <div style={styles.container}>
      {/* Header */}
      <header style={styles.header}>
        <h2>Offline Intent Classifier</h2>
        <small style={{ color: isReady ? '#4caf50' : '#ff9800' }}>
          {isReady ? '✓ Local Model Ready' : 'Loading Model...'}
        </small>
      </header>

      {/* Input Area */}
      <div style={styles.inputGroup}>
        <textarea
          value={inputText}
          onChange={(e) => setInputText(e.target.value)}
          placeholder="Type a message (e.g., 'My app is crashing')..."
          style={styles.textarea}
          rows={4}
          disabled={!isReady || isProcessing}
        />
        <button 
          onClick={handleAnalyze} 
          style={{
            ...styles.button,
            opacity: (!isReady || isProcessing || !inputText) ? 0.5 : 1
          }}
          disabled={!isReady || isProcessing || !inputText}
        >
          {isProcessing ? 'Analyzing Locally...' : 'Analyze (Offline)'}
        </button>
      </div>

      {/* Results Display */}
      <div style={styles.resultsPanel}>
        <h3>Local Inference Result:</h3>
        {isProcessing && <div style={styles.loader}>Processing on Device...</div>}
        
        {result && !isProcessing && (
          <div style={styles.resultCard}>
            <div style={styles.resultHeader}>
              <span style={styles.resultLabel}>{result.label}</span>
              <span style={styles.resultScore}>
                {(result.confidence * 100).toFixed(1)}%
              </span>
            </div>
            {/* Visual Confidence Bar */}
            <div style={styles.progressBarContainer}>
              <div 
                style={{
                  ...styles.progressBar,
                  width: `${result.confidence * 100}%`,
                  backgroundColor: result.confidence > 0.7 ? '#4caf50' : '#ff9800'
                }} 
              />
            </div>
            <p style={styles.explanation}>
              This classification was performed entirely client-side using a simulated Phi-3 architecture. 
              No data was sent to the cloud.
            </p>
          </div>
        )}
      </div>

      {/* System Info */}
      <footer style={styles.footer}>
        <p>Running on {navigator.hardwareConcurrency} CPU Cores</p>
      </footer>
    </div>
  );
};

// --- Mobile-First Styles (Inline for Demo) ---
const styles: Record<string, React.CSSProperties> = {
  container: {
    maxWidth: '480px',
    margin: '0 auto',
    padding: '20px',
    fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif',
    backgroundColor: '#f5f5f5',
    minHeight: '100vh',
    boxSizing: 'border-box'
  },
  header: {
    textAlign: 'center',
    marginBottom: '20px',
    borderBottom: '1px solid #ddd',
    paddingBottom: '10px'
  },
  inputGroup: {
    display: 'flex',
    flexDirection: 'column',
    gap: '10px',
    marginBottom: '20px'
  },
  textarea: {
    width: '100%',
    padding: '12px',
    borderRadius: '8px',
    border: '1px solid #ccc',
    fontSize: '16px', // Prevents zoom on iOS
    resize: 'vertical'
  },
  button: {
    padding: '12px 20px',
    backgroundColor: '#007aff',
    color: 'white',
    border: 'none',
    borderRadius: '8px',
    fontSize: '16px',
    fontWeight: 'bold',
    cursor: 'pointer'
  },
  resultsPanel: {
    marginTop: '20px',
    background: 'white',
    padding: '15px',
    borderRadius: '12px',
    boxShadow: '0 2px 8px rgba(0,0,0,0.05)'
  },
  loader: {
    textAlign: 'center',
    color: '#666',
    fontStyle: 'italic'
  },
  resultCard: {
    animation: 'fadeIn 0.3s ease'
  },
  resultHeader: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: '8px'
  },
  resultLabel: {
    fontSize: '18px',
    fontWeight: 'bold',
    color: '#333'
  },
  resultScore: {
    fontSize: '16px',
    color: '#666'
  },
  progressBarContainer: {
    height: '6px',
    backgroundColor: '#e0e0e0',
    borderRadius: '3px',
    overflow: 'hidden',
    marginBottom: '10px'
  },
  progressBar: {
    height: '100%',
    transition: 'width 0.5s ease'
  },
  explanation: {
    fontSize: '12px',
    color: '#888',
    lineHeight: '1.4'
  },
  footer: {
    textAlign: 'center',
    marginTop: '30px',
    fontSize: '12px',
    color: '#999'
  }
};

export default IntentClassifierApp;
