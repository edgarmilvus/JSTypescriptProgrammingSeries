/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// Import the transformers library (assumed to be available in the environment)
// In a real setup, this would be: import { pipeline, env } from '@huggingface/transformers';
// For this solution, we will mock the library functions to demonstrate the logic structure.
import { pipeline, env } from '@huggingface/transformers';

interface GenerationOptions {
  max_new_tokens?: number;
  temperature?: number;
  do_sample?: boolean;
}

interface InferenceStatus {
  state: 'idle' | 'loading' | 'ready' | 'generating' | 'error';
  progress?: number; // 0.0 to 1.0
  message?: string;
}

class LocalInferenceEngine {
  private model: any | null = null;
  private tokenizer: any | null = null;
  private status: InferenceStatus = { state: 'idle' };
  private generationPipeline: any = null;

  constructor(private modelUrl: string) {
    // Allow usage in environments without WebGL (e.g., specific mobile browsers)
    env.allowLocalModels = true;
    env.allowRemoteModels = true;
    env.useBrowserCache = true;
  }

  async init(): Promise<void> {
    if (this.status.state === 'ready' || this.status.state === 'loading') {
      return;
    }

    this.status = { state: 'loading', progress: 0, message: 'Initializing engine...' };
    
    try {
      // Initialize the pipeline. 
      // 'pipeline' handles model downloading, caching (via IndexedDB/Cache API), and tokenizer setup.
      // We use 'text-generation' task for Phi-3.
      this.generationPipeline = await pipeline(
        'text-generation', 
        this.modelUrl,
        {
          progress_callback: (data: any) => {
            // Update progress during download
            if (data.status === 'progress') {
              this.status.progress = data.loaded / data.total;
              this.status.message = `Downloading model... ${Math.round(this.status.progress * 100)}%`;
            }
          }
        }
      );
      
      this.status = { state: 'ready', progress: 1, message: 'Model loaded successfully' };
    } catch (error) {
      this.status = { state: 'error', message: `Failed to load model: ${error}` };
      console.error(error);
      throw error;
    }
  }

  async generate(prompt: string, options?: GenerationOptions): Promise<string> {
    if (this.status.state !== 'ready' || !this.generationPipeline) {
      throw new Error('Engine not initialized. Call init() first.');
    }

    this.status = { state: 'generating', message: 'Generating response...' };
    
    try {
      // Run inference. In a real Web Worker scenario, this would be offloaded.
      // Here we simulate the blocking nature by awaiting the pipeline call.
      const output = await this.generationPipeline(prompt, {
        max_new_tokens: options?.max_new_tokens || 100,
        temperature: options?.temperature || 0.7,
        do_sample: options?.do_sample ?? true,
        // For Phi-3, specific generation config might be needed to match the chat template
      });

      // Extract the generated text
      const generatedText = output[0].generated_text;
      
      this.status = { state: 'ready', message: 'Generation complete' };
      return generatedText;
    } catch (error) {
      this.status = { state: 'error', message: 'Generation failed' };
      console.error(error);
      throw error;
    }
  }

  dispose(): void {
    // Explicitly free memory by nullifying references
    // In a real WASM environment, we might call specific cleanup functions provided by the library
    if (this.generationPipeline) {
      // Depending on the library implementation, there might be a dispose() method
      // this.generationPipeline.dispose(); 
    }
    
    this.model = null;
    this.tokenizer = null;
    this.generationPipeline = null;
    this.status = { state: 'idle', message: 'Resources disposed' };
    
    // Force garbage collection hint (optional)
    if (global.gc) {
      global.gc();
    }
  }

  getStatus(): InferenceStatus {
    return this.status;
  }
}

// Usage Example:
// const engine = new LocalInferenceEngine('microsoft/Phi-3-mini-4k-instruct-q4f16_ort');
// await engine.init();
// const response = await engine.generate('Hello, how are you?');
// console.log(response);
// engine.dispose();
