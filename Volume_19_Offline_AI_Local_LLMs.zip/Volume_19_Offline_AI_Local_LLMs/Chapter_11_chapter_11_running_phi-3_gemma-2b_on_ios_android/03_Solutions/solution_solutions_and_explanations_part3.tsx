/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState, useEffect, useRef } from 'react';

// Define the structure of messages sent to and received from the worker
type WorkerMessage = {
  type: 'INIT' | 'GENERATE' | 'DISPOSE';
  payload?: any;
};

type WorkerResponse = {
  type: 'STATUS' | 'TOKEN' | 'RESULT' | 'ERROR';
  payload?: any;
};

export const ChatInterface: React.FC = () => {
  const [input, setInput] = useState('');
  const [output, setOutput] = useState('');
  const [status, setStatus] = useState('Idle');
  const workerRef = useRef<Worker | null>(null);

  useEffect(() => {
    // Create the worker. 
    // Note: In a bundler like Vite, we use new URL() syntax to ensure the worker is bundled separately.
    // For this example, we assume a standard worker setup.
    const worker = new Worker(new URL('./inference.worker.ts', import.meta.url), {
      type: 'module',
    });

    workerRef.current = worker;

    worker.onmessage = (event: MessageEvent<WorkerResponse>) => {
      const { type, payload } = event.data;

      switch (type) {
        case 'STATUS':
          setStatus(payload);
          break;
        case 'TOKEN':
          // Append token to existing output for streaming effect
          setOutput((prev) => prev + payload);
          break;
        case 'RESULT':
          setStatus('Finished');
          break;
        case 'ERROR':
          setStatus('Error: ' + payload);
          break;
      }
    };

    // Initialize the model in the worker immediately
    worker.postMessage({ type: 'INIT' });

    return () => {
      // Cleanup: Terminate worker to free memory
      worker.postMessage({ type: 'DISPOSE' });
      worker.terminate();
    };
  }, []);

  const handleGenerate = () => {
    if (!workerRef.current || !input.trim()) return;

    // Reset output before new generation
    setOutput('');
    setStatus('Generating...');

    // Send message to worker
    workerRef.current.postMessage({
      type: 'GENERATE',
      payload: {
        prompt: input,
        options: { max_new_tokens: 100 }
      }
    });
  };

  return (
    <div style={{ padding: '20px', fontFamily: 'sans-serif' }}>
      <h3>Web Worker Inference Chat</h3>
      <textarea 
        value={input} 
        onChange={(e) => setInput(e.target.value)} 
        rows={3} 
        style={{ width: '100%', marginBottom: '10px' }}
        placeholder="Enter prompt..."
      />
      <button 
        onClick={handleGenerate} 
        disabled={status === 'Generating'}
        style={{ padding: '8px 16px', cursor: status === 'Generating' ? 'not-allowed' : 'pointer' }}
      >
        {status === 'Generating' ? 'Thinking...' : 'Generate'}
      </button>
      
      <div style={{ marginTop: '15px', padding: '10px', background: '#f0f0f0', borderRadius: '4px' }}>
        <strong>Status:</strong> {status}
      </div>
      
      <div style={{ marginTop: '10px', minHeight: '100px', border: '1px solid #ddd', padding: '10px' }}>
        <strong>Response:</strong>
        <p>{output}</p>
      </div>
    </div>
  );
};
