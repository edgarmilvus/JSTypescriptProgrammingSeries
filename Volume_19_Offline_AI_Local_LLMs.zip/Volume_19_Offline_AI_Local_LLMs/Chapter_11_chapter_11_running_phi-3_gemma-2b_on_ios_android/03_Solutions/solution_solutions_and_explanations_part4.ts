/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

// ZeroShotClassifier.ts
// Assuming the availability of a feature extraction pipeline from transformers.js

interface ClassificationResult {
  label: string;
  score: number;
}

class ZeroShotClassifier {
  private featurePipeline: any = null;
  private modelName: string = 'Xenova/bge-small-en-v1.5'; // Optimized for mobile (<50MB)

  async init() {
    // Load the feature extraction pipeline
    // this.featurePipeline = await pipeline('feature-extraction', this.modelName);
  }

  // Helper: Calculate Cosine Similarity
  private cosineSimilarity(vecA: number[], vecB: number[]): number {
    const dotProduct = vecA.reduce((acc, val, i) => acc + val * vecB[i], 0);
    const magA = Math.sqrt(vecA.reduce((acc, val) => acc + val * val, 0));
    const magB = Math.sqrt(vecB.reduce((acc, val) => acc + val * val, 0));
    return dotProduct / (magA * magB);
  }

  // Helper: Average pooling of embeddings (common for sentence embeddings)
  private averagePool(embeddings: number[][]): number[] {
    const dim = embeddings[0].length;
    const avg = new Array(dim).fill(0);
    for (const emb of embeddings) {
      for (let i = 0; i < dim; i++) avg[i] += emb[i];
    }
    return avg.map(v => v / embeddings.length);
  }

  async classify(text: string, candidateLabels: string[]): Promise<ClassificationResult[]> {
    if (!this.featurePipeline) {
      throw new Error('Model not initialized');
    }

    // 1. Generate embedding for the input text
    // The model returns a tensor (array of arrays). We average pool to get a sentence vector.
    const inputTensor = await this.featurePipeline(text, { pooling: 'mean', normalize: true });
    // In real implementation, inputTensor would be a Float32Array or similar. 
    // We simulate the result structure here.
    const inputEmbedding = Array.from(inputTensor.data || [0.1, 0.2, 0.3]); // Simulated vector

    const results: ClassificationResult[] = [];

    // 2. Iterate through candidate labels
    for (const label of candidateLabels) {
      // Generate embedding for the label
      const labelTensor = await this.featurePipeline(label, { pooling: 'mean', normalize: true });
      const labelEmbedding = Array.from(labelTensor.data || [0.1, 0.2, 0.3]); // Simulated vector

      // 3. Calculate Cosine Similarity
      const score = this.cosineSimilarity(inputEmbedding, labelEmbedding);
      
      results.push({ label, score });
    }

    // 4. Sort by score descending
    return results.sort((a, b) => b.score - a.score);
  }
}

// Usage Example:
// const classifier = new ZeroShotClassifier();
// await classifier.init();
// const results = await classifier.classify("Apple released the new M3 chip", ["Finance", "Sports", "Technology"]);
// console.log(results); 
// Expected: [{ label: "Technology", score: 0.85 }, ...]
