/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState } from 'react';

type QuantizationLevel = 'FP32' | 'FP16' | 'INT8';
type Status = 'Idle' | 'Processing' | 'Success' | 'Failed';

export const ModelConverterDashboard: React.FC = () => {
  const [modelId, setModelId] = useState('microsoft/Phi-3-mini-4k-instruct');
  const [quantization, setQuantization] = useState<QuantizationLevel>('INT8');
  const [status, setStatus] = useState<Status>('Idle');
  const [logs, setLogs] = useState<string[]>([]);

  const addLog = (msg: string) => {
    setLogs(prev => [...prev, `[${new Date().toLocaleTimeString()}] ${msg}`]);
  };

  const simulateStep = (msg: string, delay: number): Promise<void> => {
    return new Promise(resolve => {
      setTimeout(() => {
        addLog(msg);
        resolve();
      }, delay);
    });
  };

  const handleConvert = async () => {
    if (status === 'Processing') return;
    
    setStatus('Processing');
    setLogs([]);
    addLog(`> Starting conversion for "${modelId}"...`);
    addLog(`> Target format: TFLite / CoreML | Quantization: ${quantization}`);

    try {
      // Step 1: Fetching
      await simulateStep("Fetching model weights from Hugging Face Hub...", 1000);
      
      // Step 2: Quantization
      await simulateStep(`Applying ${quantization} quantization...`, 1500);
      if (quantization === 'INT8') {
        await simulateStep("Calibrating quantization ranges...", 800);
      }

      // Step 3: Conversion
      await simulateStep("Converting PyTorch -> ONNX -> CoreML/TFLite...", 2000);

      // Step 4: Optimization
      await simulateStep("Optimizing for mobile Neural Engine/GPU...", 1200);

      addLog("SUCCESS: Conversion complete.");
      setStatus('Success');

    } catch (error) {
      addLog(`ERROR: ${error.message}`);
      setStatus('Failed');
    }
  };

  return (
    <div style={{ maxWidth: '600px', margin: '0 auto', fontFamily: 'monospace', padding: '20px', border: '1px solid #333', background: '#1e1e1e', color: '#00ff00' }}>
      <h3 style={{ color: '#fff', marginTop: 0 }}>Model Converter Dashboard</h3>
      
      <div style={{ marginBottom: '15px' }}>
        <label style={{ display: 'block', marginBottom: '5px', color: '#aaa' }}>Model ID:</label>
        <input 
          type="text" 
          value={modelId} 
          onChange={(e) => setModelId(e.target.value)} 
          disabled={status === 'Processing'}
          style={{ width: '100%', background: '#333', color: '#fff', border: '1px solid #555', padding: '5px' }}
        />
      </div>
      
      <div style={{ marginBottom: '15px' }}>
        <label style={{ display: 'block', marginBottom: '5px', color: '#aaa' }}>Quantization:</label>
        <select 
          value={quantization} 
          onChange={(e) => setQuantization(e.target.value as QuantizationLevel)}
          disabled={status === 'Processing'}
          style={{ width: '100%', background: '#333', color: '#fff', border: '1px solid #555', padding: '5px' }}
        >
          <option value="FP32">FP32 (High Precision)</option>
          <option value="FP16">FP16 (Balanced)</option>
          <option value="INT8">INT8 (Low Size/Power)</option>
        </select>
      </div>

      <button 
        onClick={handleConvert} 
        disabled={status === 'Processing'}
        style={{ width: '100%', padding: '10px', background: status === 'Processing' ? '#555' : '#007acc', color: '#fff', border: 'none', cursor: 'pointer' }}
      >
        {status === 'Processing' ? 'Processing...' : 'Convert Model'}
      </button>

      <div style={{ marginTop: '15px', background: '#000', padding: '10px', height: '200px', overflowY: 'auto', border: '1px solid #333' }}>
        {logs.map((log, idx) => (
          <div key={idx} style={{ marginBottom: '4px' }}>{log}</div>
        ))}
      </div>

      {status === 'Success' && (
        <div style={{ marginTop: '15px', padding: '10px', background: '#004400', border: '1px solid #00ff00' }}>
          <p style={{ margin: '0 0 10px 0' }}>✅ Model ready for deployment.</p>
          <div style={{ display: 'flex', gap: '10px' }}>
            <button style={{ flex: 1, padding: '5px', background: '#444', color: '#fff', border: '1px solid #666' }}>Download .tflite</button>
            <button style={{ flex: 1, padding: '5px', background: '#444', color: '#fff', border: '1px solid #666' }}>Download .mlmodelc</button>
          </div>
        </div>
      )}
    </div>
  );
};
