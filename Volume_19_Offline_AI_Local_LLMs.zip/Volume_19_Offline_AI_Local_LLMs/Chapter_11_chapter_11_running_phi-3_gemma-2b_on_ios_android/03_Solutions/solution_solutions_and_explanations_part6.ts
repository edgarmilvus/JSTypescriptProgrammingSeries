/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part6.ts
// Description: Solutions and Explanations
// ==========================================

import { useState, useEffect } from 'react';

export interface DeviceMetrics {
  batteryLevel: number; // 0.0 to 1.0
  thermalState: 'nominal' | 'fair' | 'serious' | 'critical';
  isPowerSaving: boolean;
}

export const useDeviceMetrics = (checkIntervalMs: number = 5000): DeviceMetrics => {
  const [metrics, setMetrics] = useState<DeviceMetrics>({ 
    batteryLevel: 1.0, 
    thermalState: 'nominal',
    isPowerSaving: false
  });

  useEffect(() => {
    const interval = setInterval(() => {
      // SIMULATION LOGIC:
      // In a real app, we would use navigator.getBattery() for batteryLevel.
      // Thermal state is not exposed by browsers, so we simulate it based on usage history or randomness.
      
      const currentBattery = navigator.getBattery ? 0.8 : 0.5; // Fallback if API unavailable
      
      // Simulate thermal degradation if battery is low or random chance
      let thermalState: 'nominal' | 'fair' | 'serious' | 'critical' = 'nominal';
      if (currentBattery < 0.2) thermalState = 'serious';
      if (Math.random() > 0.9) thermalState = 'critical'; // Random thermal spike

      const isPowerSaving = currentBattery < 0.2 || thermalState === 'critical';

      setMetrics({
        batteryLevel: currentBattery,
        thermalState: thermalState,
        isPowerSaving: isPowerSaving
      });
    }, checkIntervalMs);

    return () => clearInterval(interval);
  }, [checkIntervalMs]);

  return metrics;
};
