/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part2.tsx
// Description: Practical Exercises
// ==========================================

import React, { useState, useEffect, useRef } from 'react';

// Define the structure of messages sent to and received from the worker
type WorkerMessage = {
  type: 'INIT' | 'GENERATE' | 'DISPOSE';
  payload?: any;
};

type WorkerResponse = {
  type: 'STATUS' | 'TOKEN' | 'RESULT' | 'ERROR';
  payload?: any;
};

export const ChatInterface: React.FC = () => {
  const [input, setInput] = useState('');
  const [output, setOutput] = useState('');
  const [status, setStatus] = useState('Idle');
  const workerRef = useRef<Worker | null>(null);

  useEffect(() => {
    // Initialize Web Worker here
    // Note: In a bundler environment (Vite/Webpack), you might use new URL('./inference.worker.ts', import.meta.url)
    
    return () => {
      // Cleanup: Terminate worker
    };
  }, []);

  const handleGenerate = async () => {
    if (!workerRef.current) return;
    
    // Send message to worker
    // Handle streaming updates
  };

  return (
    <div>
      <textarea value={input} onChange={(e) => setInput(e.target.value)} />
      <button onClick={handleGenerate} disabled={status === 'Generating'}>
        Generate
      </button>
      <div>Status: {status}</div>
      <div>Response: {output}</div>
    </div>
  );
};
