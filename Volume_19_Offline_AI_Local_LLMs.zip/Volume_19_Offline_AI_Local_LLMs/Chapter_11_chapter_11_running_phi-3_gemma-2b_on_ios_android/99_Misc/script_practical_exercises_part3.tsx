/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part3.tsx
// Description: Practical Exercises
// ==========================================

import React, { useState } from 'react';

type QuantizationLevel = 'FP32' | 'FP16' | 'INT8';

export const ModelConverterDashboard: React.FC = () => {
  const [modelId, setModelId] = useState('microsoft/Phi-3-mini-4k-instruct');
  const [quantization, setQuantization] = useState<QuantizationLevel>('INT8');
  const [status, setStatus] = useState<'Idle' | 'Processing' | 'Success' | 'Failed'>('Idle');
  const [logs, setLogs] = useState<string[]>([]);

  const addLog = (msg: string) => {
    setLogs(prev => [...prev, `[${new Date().toLocaleTimeString()}] ${msg}`]);
  };

  const handleConvert = async () => {
    if (status === 'Processing') return;
    
    setStatus('Processing');
    setLogs([]);
    addLog(`Starting conversion for ${modelId} with ${quantization} quantization...`);

    // Simulate the conversion pipeline
    // Implement a sequence of setTimeouts to mimic the steps:
    // 1. Fetch weights
    // 2. Quantize
    // 3. Convert format
    // 4. Finalize
    
    // On completion:
    // setStatus('Success');
    // addLog('Conversion complete. Artifact ready for deployment.');
  };

  return (
    <div className="converter-dashboard">
      <h3>Mobile Model Converter</h3>
      
      <div className="controls">
        <label>Model ID:</label>
        <input 
          type="text" 
          value={modelId} 
          onChange={(e) => setModelId(e.target.value)} 
          disabled={status === 'Processing'}
        />
        
        <label>Quantization:</label>
        <select 
          value={quantization} 
          onChange={(e) => setQuantization(e.target.value as QuantizationLevel)}
          disabled={status === 'Processing'}
        >
          <option value="FP32">FP32 (High Precision)</option>
          <option value="FP16">FP16 (Balanced)</option>
          <option value="INT8">INT8 (Low Size/Power)</option>
        </select>

        <button onClick={handleConvert} disabled={status === 'Processing'}>
          {status === 'Processing' ? 'Converting...' : 'Convert Model'}
        </button>
      </div>

      <div className="terminal-output">
        {/* Map over logs to display them */}
        {logs.map((log, idx) => <div key={idx}>{log}</div>)}
      </div>

      {status === 'Success' && (
        <div className="success-message">
          <p>Model ready for deployment.</p>
          <button>Download .tflite (Android)</button>
          <button>Download .mlmodelc (iOS)</button>
        </div>
      )}
    </div>
  );
};
