/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: theory_theoretical_foundations.ts
// Description: Theoretical Foundations
// ==========================================

// Example of a structured prompt for a small model (Llama 3 8B)
const systemPrompt = `
You are a precise logic engine. 
You must solve math word problems by breaking them down into explicit steps.
Do not provide the final answer until you have listed the steps.
`;

const userPrompt = `
Problem: If a train leaves Station A at 10:00 AM traveling at 60 mph, 
and another train leaves Station B at 11:00 AM traveling at 80 mph, 
when will they meet if the stations are 280 miles apart?

Step 1: Calculate the distance Train A covers in the first hour (10:00-11:00 AM).
Step 2: Determine the remaining distance between the trains at 11:00 AM.
Step 3: Calculate the relative speed of the two trains moving towards each other.
Step 4: Divide the remaining distance by the relative speed to find the time until they meet.
Step 5: Add the time found in Step 4 to 11:00 AM to get the meeting time.

Final Answer:
`;
