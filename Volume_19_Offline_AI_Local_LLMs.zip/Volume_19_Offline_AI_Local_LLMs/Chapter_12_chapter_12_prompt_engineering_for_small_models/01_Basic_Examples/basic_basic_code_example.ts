/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * ============================================================================
 * 1. TYPE DEFINITIONS & CONFIGURATION
 * ============================================================================
 */

// Strict typing for our vector store entries.
interface VectorEntry {
  id: string;
  content: string;
  embedding: number[]; // Simulated vector representation
}

// Configuration for the LLM context window (token limit).
// Small models often have 4k-8k context windows.
const MAX_CONTEXT_TOKENS = 2048; 

/**
 * ============================================================================
 * 2. MODULE: LOCAL VECTOR STORE (SRP: Data Storage)
 * ============================================================================
 * Responsibility: Pure storage and retrieval of vectors. 
 * In a real mobile app, this would be SQLite or Realm.
 */

class LocalVectorStore {
  private store: VectorEntry[] = [];

  /**
   * Adds a document to the local vector index.
   * @param content - The text chunk to index.
   * @param embedding - The numerical vector representation.
   */
  public add(content: string, embedding: number[]): void {
    const entry: VectorEntry = {
      id: Math.random().toString(36).substr(2, 9),
      content,
      embedding,
    };
    this.store.push(entry);
  }

  /**
   * Simulates vector similarity search (Cosine Similarity).
   * In production, use a library like `hnswlib-wasm` or `onnxruntime-web`.
   * @param queryEmbedding - The vector of the user query.
   * @param topK - Number of results to return.
   * @returns The top K matching text chunks.
   */
  public search(queryEmbedding: number[], topK: number = 2): string[] {
    // Calculate dot products (simulating similarity)
    const scores = this.store.map((item) => {
      const dotProduct = item.embedding.reduce(
        (sum, val, i) => sum + val * queryEmbedding[i],
        0
      );
      return { ...item, score: dotProduct };
    });

    // Sort by score descending
    scores.sort((a, b) => b.score - a.score);

    // Return content of top matches
    return scores.slice(0, topK).map((item) => item.content);
  }
}

/**
 * ============================================================================
 * 3. MODULE: EMBEDDING SERVICE (SRP: Data Transformation)
 * ============================================================================
 * Responsibility: Convert raw text into numerical vectors.
 * We simulate this using a hashing function for deterministic output.
 */

class EmbeddingService {
  /**
   * Generates a pseudo-vector based on string hashing.
   * Real implementation would use a Mobile-Optimized ONNX model (e.g., BERT-small).
   * @param text - Input text.
   * @returns A 128-dimension vector (array of floats).
   */
  public async embed(text: string): Promise<number[]> {
    // Simulation: Create a deterministic array based on char codes
    const vector: number[] = [];
    const seed = text.split('').reduce((acc, char) => acc + char.charCodeAt(0), 0);
    
    for (let i = 0; i < 128; i++) {
      // Pseudo-random generator based on seed and index
      const x = Math.sin(seed + i) * 10000;
      vector.push(x - Math.floor(x)); // Normalize to 0-1
    }
    
    // Simulate async processing delay (typical for NN inference)
    await new Promise(r => setTimeout(r, 10));
    return vector;
  }
}

/**
 * ============================================================================
 * 4. MODULE: PROMPT ENGINE (SRP: Prompt Logic)
 * ============================================================================
 * Responsibility: Constructing the exact string sent to the LLM.
 * Handles System Prompts, Context Injection, and Token Management.
 */

class PromptEngine {
  private systemPrompt: string;

  constructor(systemPrompt: string) {
    this.systemPrompt = systemPrompt;
  }

  /**
   * Builds the final prompt string using Few-Shot prompting principles.
   * @param userQuery - The user's question.
   * @param context - Retrieved documents from vector search.
   * @returns The fully formatted prompt string.
   */
  public buildPrompt(userQuery: string, context: string[]): string {
    // Join context chunks
    const contextBlock = context.join('\n\n---\n\n');

    // Format: System + Context + User Query
    // Note: For small models, explicit separators are crucial.
    const finalPrompt = `
<|system|>
${this.systemPrompt}

Context:
${contextBlock}
<|user|>
${userQuery}
<|assistant|>
`;
    return finalPrompt.trim();
  }

  /**
   * Validates if the context fits within the model's token window.
   * @param context - Array of context strings.
   * @returns boolean
   */
  public validateContextWindow(context: string[]): boolean {
    const totalLength = context.join('').length;
    // Rough estimation: 1 token ~= 4 chars
    const estimatedTokens = totalLength / 4;
    return estimatedTokens < MAX_CONTEXT_TOKENS;
  }
}

/**
 * ============================================================================
 * 5. MODULE: LOCAL INFERENCE (SRP: Model Execution)
 * ============================================================================
 * Responsibility: Interface with the local Llama 3 model.
 * In a browser, this typically uses WebAssembly (WASM) or WebGL.
 */

class LocalLlamaInference {
  /**
   * "Runs" the Llama 3 model locally.
   * In a real implementation, this calls a WASM binding or WebGPU context.
   * @param prompt - The constructed prompt string.
   * @returns The generated text response.
   */
  public async generate(prompt: string): Promise<string> {
    console.log(`[Local Llama 3] Generating tokens for prompt length: ${prompt.length}`);
    
    // SIMULATION: We are not actually running Llama 3 here to keep code portable.
    // However, this is where the `llama.cpp` or `transformers.js` call would happen.
    
    // Simulate inference latency
    await new Promise(r => setTimeout(r, 200));

    // Check if context was retrieved (mock logic)
    if (prompt.includes("Context:\n\n")) {
      return "Based on the retrieved context, the answer is: The capital of France is Paris.";
    } else {
      return "I don't have enough context to answer that accurately.";
    }
  }
}

/**
 * ============================================================================
 * 6. MAIN ORCHESTRATOR (SRP: Composition)
 * ============================================================================
 * Responsibility: Wiring the modules together.
 * This represents the API Route handler (e.g., Next.js App Router).
 */

// Initialize Modules
const vectorStore = new LocalVectorStore();
const embedder = new EmbeddingService();
const promptEngine = new PromptEngine(
  "You are a helpful AI assistant running entirely on-device. Answer strictly based on the provided context."
);
const llm = new LocalLlamaInference();

// Seed Data (Simulating Knowledge Base Ingestion)
async function seedKnowledgeBase() {
  const docs = [
    "Paris is the capital of France.",
    "Berlin is the capital of Germany.",
    "The Eiffel Tower is located in Paris.",
  ];
  
  for (const doc of docs) {
    const vector = await embedder.embed(doc);
    vectorStore.add(doc, vector);
  }
}

/**
 * The main API handler function.
 * @param userQuestion - The input from the user.
 * @returns The AI response.
 */
async function handleApiRequest(userQuestion: string): Promise<string> {
  // 1. Embed the user query
  const queryVector = await embedder.embed(userQuestion);

  // 2. Retrieve relevant context from local vector store
  const relevantDocs = vectorStore.search(queryVector);

  // 3. Validate Context Window (Critical for Small Models)
  if (!promptEngine.validateContextWindow(relevantDocs)) {
    return "Error: Context too large for local model constraints.";
  }

  // 4. Construct Prompt (System Prompt + Context + Query)
  const finalPrompt = promptEngine.buildPrompt(userQuestion, relevantDocs);

  // 5. Run Local Inference
  const response = await llm.generate(finalPrompt);

  return response;
}

/**
 * ============================================================================
 * 7. EXECUTION SIMULATION
 * ============================================================================
 */

(async () => {
  // Setup
  await seedKnowledgeBase();
  console.log("--- Knowledge Base Seeded ---");

  // Example 1: RAG Query
  const query1 = "Where is the Eiffel Tower?";
  console.log(`\nUser: ${query1}`);
  const answer1 = await handleApiRequest(query1);
  console.log(`Assistant: ${answer1}`);

  // Example 2: Query requiring context
  const query2 = "What is the capital of France?";
  console.log(`\nUser: ${query2}`);
  const answer2 = await handleApiRequest(query2);
  console.log(`Assistant: ${answer2}`);
})();
