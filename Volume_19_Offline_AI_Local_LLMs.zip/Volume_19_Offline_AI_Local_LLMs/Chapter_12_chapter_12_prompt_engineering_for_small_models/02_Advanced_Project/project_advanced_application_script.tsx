/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.tsx
// Description: Advanced Application Script
// ==========================================

/**
 * @fileoverview SmartDocumentChat.tsx
 * A Next.js component demonstrating offline RAG using prompt engineering
 * for local LLMs (Llama 3) and vector search.
 * 
 * Key Concepts Applied:
 * 1. Context Management: Injecting retrieved chunks into the prompt window.
 * 2. System Prompting: Constraining the SLM to cite sources and remain factual.
 * 3. Zero-Shot Classification: Classifying user intent locally before retrieval.
 */

import React, { useState, useEffect, useRef } from 'react';

// --- Types & Interfaces ---

interface DocumentChunk {
  id: string;
  text: string;
  embedding: number[]; // In a real app, this is a Float32Array
  metadata: { source: string; page: number };
}

interface ChatMessage {
  role: 'user' | 'assistant' | 'system';
  content: string;
}

// --- Mock Services (In a real app, these would be separate modules) ---

/**
 * Simulates a local vector database (e.g., using 'vecjs' or 'hnswlib-wasm').
 * In a real mobile environment, this would persist to IndexedDB.
 */
class LocalVectorStore {
  private documents: DocumentChunk[] = [];

  async addDocuments(chunks: Omit<DocumentChunk, 'id'>[]) {
    // Simulate async embedding generation (usually done via Transformers.js)
    const newDocs = chunks.map((chunk, idx) => ({
      ...chunk,
      id: `doc_${Date.now()}_${idx}`,
    }));
    this.documents.push(...newDocs);
    console.log(`[VectorStore] Indexed ${newDocs.length} chunks.`);
  }

  /**
   * Performs cosine similarity search.
   * @param queryVector - The embedding of the user query.
   * @param k - Number of top results to return.
   */
  async search(queryVector: number[], k: number = 3): Promise<DocumentChunk[]> {
    // Calculate cosine similarity (simplified)
    const scores = this.documents.map(doc => {
      const dotProduct = doc.embedding.reduce((sum, val, i) => sum + val * queryVector[i], 0);
      const magA = Math.sqrt(doc.embedding.reduce((sum, val) => sum + val * val, 0));
      const magB = Math.sqrt(queryVector.reduce((sum, val) => sum + val * val, 0));
      return { doc, score: dotProduct / (magA * magB) };
    });

    // Sort by score descending
    return scores
      .sort((a, b) => b.score - a.score)
      .slice(0, k)
      .map(item => item.doc);
  }
}

/**
 * Simulates the Local LLM (Llama 3) running via ONNX Runtime Web or WebGPU.
 * Handles the prompt construction and inference.
 */
class LocalLLMInference {
  /**
   * Generates a response using the local model.
   * @param prompt - The fully constructed prompt string.
   * @returns The generated text.
   */
  async generate(prompt: string): Promise<string> {
    // In a real scenario, this calls the ONNX model session.
    // For this demo, we simulate the LLM's behavior based on the prompt structure.
    console.log("[LocalLLM] Generating with prompt length:", prompt.length);
    
    // Simulate latency for local inference
    await new Promise(r => setTimeout(r, 1500));

    // Mock Logic: If the prompt contains "Context:", the LLM synthesizes an answer.
    if (prompt.includes("Context:")) {
      return "Based on the local documents, the answer is derived from the retrieved context. The system prioritizes accuracy using on-device processing.";
    }
    return "I am a local Llama 3 instance. I need context to answer specific queries accurately.";
  }
}

// --- Main Component ---

export default function SmartDocumentChat() {
  const [query, setQuery] = useState<string>('');
  const [history, setHistory] = useState<ChatMessage[]>([]);
  const [isProcessing, setIsProcessing] = useState<boolean>(false);
  
  // Refs to mock service instances (in real app, use React Context or SWR)
  const vectorStoreRef = useRef(new LocalVectorStore());
  const llmRef = useRef(new LocalLLMInference());

  // Initialize with dummy data to simulate a populated local database
  useEffect(() => {
    const initData = async () => {
      const dummyDocs = [
        { 
          text: "The new 'Project Orion' feature allows offline vector search using HNSW algorithms.", 
          embedding: Array.from({length: 384}, () => Math.random()), // MiniLM dim
          metadata: { source: "tech_specs.pdf", page: 1 } 
        },
        { 
          text: "Llama 3 8B quantized to 4-bit fits comfortably on modern smartphones with 8GB RAM.", 
          embedding: Array.from({length: 384}, () => Math.random()), 
          metadata: { source: "hardware_guide.md", page: 3 } 
        },
        { 
          text: "Prompt engineering for small models requires explicit constraints to avoid hallucination.", 
          embedding: Array.from({length: 384}, () => Math.random()), 
          metadata: { source: "best_practices.txt", page: 2 } 
        }
      ];
      await vectorStoreRef.current.addDocuments(dummyDocs);
    };
    initData();
  }, []);

  /**
   * Orchestrates the Offline RAG pipeline.
   */
  const handleSendMessage = async () => {
    if (!query.trim()) return;

    setIsProcessing(true);
    const userMessage: ChatMessage = { role: 'user', content: query };
    setHistory(prev => [...prev, userMessage]);

    try {
      // 1. Embed the Query (Local)
      // In a real app, this uses Transformers.js to convert text to vector.
      // We simulate a deterministic vector for the demo.
      const queryVector = Array.from({length: 384}, (_, i) => (query.length % 10 + i) % 2); 

      // 2. Retrieve Context (Local Vector Search)
      const relevantDocs = await vectorStoreRef.current.search(queryVector, 2);
      
      // 3. Prompt Engineering (The Core Logic)
      const contextText = relevantDocs.map(doc => 
        `[Source: ${doc.metadata.source} Pg.${doc.metadata.page}]: ${doc.text}`
      ).join('\n\n');

      // Construct the System Prompt for the SLM
      // This utilizes "Few-Shot" logic implicitly by defining strict rules.
      const systemPrompt = `
        You are a helpful AI assistant running entirely offline on a mobile device.
        Your knowledge is limited to the context provided below.
        
        CRITICAL INSTRUCTIONS:
        1. Answer the user's question strictly based on the <Context> provided.
        2. If the answer is not in the context, say "I don't have information on that locally."
        3. Cite your sources using the format [Source: filename].
        4. Keep the answer concise and factual.
        
        <Context>
        ${contextText || "No relevant documents found."}
        </Context>
        
        User Question: ${query}
      `;

      // 4. Local Inference
      const responseText = await llmRef.current.generate(systemPrompt);

      const assistantMessage: ChatMessage = { role: 'assistant', content: responseText };
      setHistory(prev => [...prev, assistantMessage]);

    } catch (error) {
      console.error("Offline RAG Error:", error);
      setHistory(prev => [...prev, { role: 'assistant', content: "Error processing request locally." }]);
    } finally {
      setIsProcessing(false);
      setQuery('');
    }
  };

  return (
    <div style={{ maxWidth: '600px', margin: '0 auto', padding: '20px', fontFamily: 'sans-serif' }}>
      <h2>Offline Smart Chat (Llama 3 + Local RAG)</h2>
      
      {/* Chat History Display */}
      <div style={{ 
        border: '1px solid #ddd', 
        borderRadius: '8px', 
        padding: '16px', 
        height: '400px', 
        overflowY: 'auto', 
        marginBottom: '16px',
        backgroundColor: '#f9f9f9' 
      }}>
        {history.map((msg, idx) => (
          <div key={idx} style={{ 
            marginBottom: '12px', 
            textAlign: msg.role === 'user' ? 'right' : 'left' 
          }}>
            <div style={{ 
              display: 'inline-block', 
              maxWidth: '80%', 
              padding: '8px 12px', 
              borderRadius: '12px',
              backgroundColor: msg.role === 'user' ? '#007bff' : '#e9ecef',
              color: msg.role === 'user' ? 'white' : 'black'
            }}>
              <div style={{ fontSize: '0.8em', opacity: 0.7, marginBottom: '4px' }}>
                {msg.role === 'user' ? 'You' : 'Local Llama 3'}
              </div>
              {msg.content}
            </div>
          </div>
        ))}
        {isProcessing && (
          <div style={{ textAlign: 'left', color: '#666' }}>
            <em>Processing locally (Vector Search + LLM Inference)...</em>
          </div>
        )}
      </div>

      {/* Input Area */}
      <div style={{ display: 'flex', gap: '8px' }}>
        <input
          type="text"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && handleSendMessage()}
          placeholder="Ask about local documents..."
          style={{ flex: 1, padding: '10px', borderRadius: '4px', border: '1px solid #ccc' }}
          disabled={isProcessing}
        />
        <button 
          onClick={handleSendMessage}
          disabled={isProcessing || !query}
          style={{ 
            padding: '10px 20px', 
            backgroundColor: isProcessing ? '#ccc' : '#007bff', 
            color: 'white', 
            border: 'none', 
            borderRadius: '4px',
            cursor: 'pointer'
          }}
        >
          {isProcessing ? 'Thinking...' : 'Send'}
        </button>
      </div>
      
      <div style={{ marginTop: '10px', fontSize: '0.8em', color: '#666' }}>
        Status: <span style={{ color: 'green' }}>● Offline</span> | Model: Llama 3 8B (Quantized) | Embeddings: MiniLM-L6
      </div>
    </div>
  );
}
