/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

/**
 * Estimates the number of tokens in a string based on a simple heuristic.
 * In a real scenario, use a library like 'gpt-tokenizer' or the model's specific tokenizer.
 * For this exercise, we assume 1 token ≈ 4 characters.
 * @param text The text to estimate.
 * @returns The estimated token count.
 */
function estimateTokens(text: string): number {
    // Heuristic: 1 token is roughly 4 characters for English text.
    return Math.ceil(text.length / 4);
}

/**
 * Generates a few-shot prompt for parsing user voice inputs into structured JSON.
 * 
 * @param userInput The current user input string.
 * @returns The constructed prompt string.
 */
export function generateFewShotPrompt(userInput: string): string {
    // System instruction defining the role and strict output format.
    const systemInstruction = `You are a precise task parser. Convert the user's voice input into a JSON object.
The JSON must strictly follow this schema: {"task": string, "priority": "low" | "medium" | "high", "dueDate": ISO string (YYYY-MM-DDTHH:MM:SSZ)}.
If a field is missing or ambiguous, infer a reasonable default (e.g., priority: "medium", dueDate: 24 hours from now).
Output ONLY the JSON object, no other text.`;

    // Few-shot examples covering edge cases.
    // Example 1: Complete information.
    const example1Input = "Remind me to buy groceries tomorrow at 5 PM with high priority.";
    const example1Output = `{"task": "Buy groceries", "priority": "high", "dueDate": "2023-10-15T17:00:00Z"}`;

    // Example 2: Missing due date (requires inference).
    const example2Input = "Call the dentist to schedule an appointment, high priority.";
    const example2Output = `{"task": "Call the dentist to schedule an appointment", "priority": "high", "dueDate": "2023-10-16T12:00:00Z"}`;

    // Example 3: Ambiguous priority and informal phrasing.
    const example3Input = "Clean the garage sometime this weekend.";
    const example3Output = `{"task": "Clean the garage", "priority": "medium", "dueDate": "2023-10-22T09:00:00Z"}`;

    // Construct the prompt using template literals for clarity.
    const prompt = `
${systemInstruction}

Example 1:
Input: "${example1Input}"
Output: ${example1Output}

Example 2:
Input: "${example2Input}"
Output: ${example2Output}

Example 3:
Input: "${example3Input}"
Output: ${example3Output}

Current Input:
Input: "${userInput}"
Output:`;

    // Check token count to ensure it stays under the 500-token constraint.
    const tokenCount = estimateTokens(prompt);
    if (tokenCount > 500) {
        console.warn(`Prompt exceeds token limit: ${tokenCount} > 500. Consider shortening examples.`);
        // In a production app, we might dynamically truncate examples.
    }

    return prompt;
}

// Mock usage for demonstration:
// const prompt = generateFewShotPrompt("Remind me to buy groceries tomorrow at 5 PM with high priority.");
// console.log(prompt);
