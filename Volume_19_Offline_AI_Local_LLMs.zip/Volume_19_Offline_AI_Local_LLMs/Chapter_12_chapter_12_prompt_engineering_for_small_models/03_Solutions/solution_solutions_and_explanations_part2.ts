/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

/**
 * Estimates the number of tokens in a string based on a simple heuristic (1 token ≈ 4 chars).
 * @param text The text to estimate.
 * @returns The estimated token count.
 */
function estimateTokens(text: string): number {
    return Math.ceil(text.length / 4);
}

/**
 * Creates a system prompt that manages context by summarizing history if needed.
 * 
 * @param history An array of conversation history strings (user and assistant turns).
 * @param maxTokens The total context window size (e.g., 8192 for Llama 3).
 * @returns The generated system prompt string.
 */
export function createSystemPrompt(history: string[], maxTokens: number): string {
    const systemTokenLimit = maxTokens * 0.2; // System prompt should use max 20% of context.
    const historyTokenLimit = maxTokens * 0.8; // Remaining 80% for history + new input.

    // Calculate total tokens in history.
    const historyText = history.join(" ");
    const historyTokens = estimateTokens(historyText);

    let contextSection: string;

    if (historyTokens > historyTokenLimit * 0.8) { // If history exceeds 80% of available space, summarize.
        // Simple summarization: extract key entities and intents.
        // In a real app, this could use a separate small model or NLP library.
        // Here, we simulate by taking the first and last few turns and creating a summary string.
        const summary = summarizeHistory(history);
        contextSection = `Conversation Summary: ${summary}`;
    } else {
        // Use full history if it fits comfortably.
        contextSection = `Recent Conversation History:\n${history.map((turn, i) => `${i + 1}. ${turn}`).join("\n")}`;
    }

    // Construct the system prompt with clear instructions for context management.
    const baseSystemPrompt = `You are a helpful assistant for a mobile app. Your context window is limited.
    - Prioritize recent information.
    - Reference the provided context below to answer the user's query.
    - If the context is a summary, base your response on that summary and do not invent details.
    - Keep responses concise to save tokens for future interactions.`;

    const fullPrompt = `${baseSystemPrompt}\n\nContext:\n${contextSection}`;

    // Ensure the system prompt itself doesn't exceed its token allocation.
    const systemPromptTokens = estimateTokens(fullPrompt);
    if (systemPromptTokens > systemTokenLimit) {
        // Fallback: truncate the context section if necessary.
        console.warn("System prompt exceeds token limit; truncating context.");
        const truncatedContext = contextSection.substring(0, systemTokenLimit * 3); // Rough char truncation.
        return `${baseSystemPrompt}\n\nContext (Truncated):\n${truncatedContext}`;
    }

    return fullPrompt;
}

/**
 * Helper function to simulate history summarization.
 * In a real implementation, this would use more sophisticated NLP.
 * @param history Array of history strings.
 * @returns A summary string.
 */
function summarizeHistory(history: string[]): string {
    // Extract key points: assume last user intent and a few key entities.
    // This is a mock implementation for demonstration.
    const lastUserTurn = history.length > 0 ? history[history.length - 1] : "No recent activity.";
    return "User discussed project deadlines and requested reminders. Recent query: " + lastUserTurn;
}

// Mock usage for demonstration:
// const history = ["I need to finish the report by Friday.", "Set a reminder for the meeting tomorrow."];
// const prompt = createSystemPrompt(history, 8192);
// console.log(prompt);
