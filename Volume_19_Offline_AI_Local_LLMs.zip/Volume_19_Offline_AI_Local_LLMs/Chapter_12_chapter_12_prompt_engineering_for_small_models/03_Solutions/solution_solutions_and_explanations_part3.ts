/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

/**
 * Estimates the number of tokens in a string based on a simple heuristic (1 token ≈ 4 chars).
 * @param text The text to estimate.
 * @returns The estimated token count.
 */
function estimateTokens(text: string): number {
    return Math.ceil(text.length / 4);
}

/**
 * Builds a RAG prompt by integrating top-K retrieved documents.
 * 
 * @param query The user's query string.
 * @param retrievedDocs Array of retrieved documents with id, content, and score.
 * @returns The constructed prompt string.
 */
export function buildRAGPrompt(query: string, retrievedDocs: Array<{id: string, content: string, score: number}>): string {
    // Sort by score descending and select top 3.
    const topDocs = retrievedDocs
        .sort((a, b) => b.score - a.score)
        .slice(0, 3);

    // Format snippets: limit to 100 characters each, add ellipsis if truncated.
    const contextSection = topDocs.map(doc => {
        const truncatedContent = doc.content.length > 100 
            ? doc.content.substring(0, 97) + "..." 
            : doc.content;
        return `[${doc.id}]: ${truncatedContent}`;
    }).join("\n");

    // Construct the RAG prompt with clear sections.
    const systemRole = "You are a helpful assistant. Answer the user's query based ONLY on the provided context below. Do not use external knowledge.";
    const contextHeader = "Context (Relevant Passages):";
    const querySection = `Query: ${query}`;
    const instruction = "Provide a concise answer and cite the source IDs (e.g., [doc1]) where applicable.";

    const prompt = `${systemRole}\n\n${contextHeader}\n${contextSection}\n\n${querySection}\n\n${instruction}`;

    // Enforce token limit (under 1000 tokens for mobile efficiency).
    const tokenCount = estimateTokens(prompt);
    if (tokenCount > 1000) {
        console.warn(`RAG prompt exceeds token limit: ${tokenCount} > 1000. Consider reducing context snippets.`);
        // In a real app, we might further truncate snippets or reduce K.
    }

    return prompt;
}

// Mock example for demonstration:
// const query = "Best practices for mobile AI";
// const retrievedDocs = [
//     {id: "doc1", content: "Optimize prompts for token limits to fit within mobile context windows.", score: 0.95},
//     {id: "doc2", content: "Use vector search to ground responses in user-specific data.", score: 0.88},
//     {id: "doc3", content: "Small models benefit from concise, structured inputs to reduce hallucination.", score: 0.85},
//     {id: "doc4", content: "Irrelevant content should be filtered out.", score: 0.70}
// ];
// const prompt = buildRAGPrompt(query, retrievedDocs);
// console.log(prompt);
