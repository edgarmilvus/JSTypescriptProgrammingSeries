/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

import * as readline from 'readline';

// Mock token estimation function.
function estimateTokens(text: string): number {
    return Math.ceil(text.length / 4);
}

/**
 * Simulates an LLM response based on prompt quality.
 * Rewards concise, structured prompts with better outputs.
 * @param prompt The input prompt.
 * @returns A mock response string.
 */
function simulateLLMResponse(prompt: string): string {
    const tokenCount = estimateTokens(prompt);
    if (tokenCount > 800) {
        return "Draft: [Response truncated due to token limit. Please shorten the prompt.]";
    }
    
    if (prompt.includes("concise") && prompt.includes("bullet points")) {
        return "Draft: Subject: Project Update\n\n- Schedule meeting with team by Friday.\n- Follow up on email from client.\n\nBest regards,\nAssistant";
    } else if (prompt.includes("structured") || prompt.includes("examples")) {
        return "Draft: [Good structure, but could be more concise.]";
    } else {
        return "Draft: [Vague response. Consider adding more instructions.]";
    }
}

/**
 * Tunes the prompt based on user feedback.
 * @param basePrompt The current prompt.
 * @param feedback User's feedback string.
 * @returns The modified prompt.
 */
function tunePrompt(basePrompt: string, feedback: string): string {
    let modifiedPrompt = basePrompt;
    
    if (feedback.toLowerCase().includes("wordy")) {
        // Add instruction for conciseness.
        modifiedPrompt += "\nBe concise and use bullet points.";
    } else if (feedback.toLowerCase().includes("vague")) {
        // Add a few-shot example for clarity.
        modifiedPrompt += "\nExample: Input: 'Schedule meeting, follow up email' Output: 'Draft: [Structured response]'";
    } else if (feedback.toLowerCase().includes("good")) {
        // No change, but could add refinement.
        modifiedPrompt += "\nRefine for better structure.";
    }
    
    // Ensure token limit is respected.
    if (estimateTokens(modifiedPrompt) > 800) {
        // Truncate non-essential parts (e.g., remove old examples).
        modifiedPrompt = modifiedPrompt.substring(0, 800 * 3); // Rough truncation.
    }
    
    return modifiedPrompt;
}

/**
 * Main CLI function for interactive prompt tuning.
 */
async function main() {
    const rl = readline.createInterface({
        input: process.stdin,
        output: process.stdout
    });

    let basePrompt = "Generate an email draft from the following bullet points.";
    let iteration = 0;
    const maxIterations = 5;

    console.log("Welcome to Adaptive Prompt Tuning for Mobile LLMs.");
    console.log("Initial Prompt:", basePrompt);

    while (iteration < maxIterations) {
        const bullets = await new Promise<string>(resolve => {
            rl.question(`\nIteration ${iteration + 1}: Enter bullet points (or 'quit' to exit): `, resolve);
        });

        if (bullets.toLowerCase() === 'quit') break;

        // Append bullets to prompt.
        let currentPrompt = `${basePrompt}\nBullet Points: ${bullets}`;
        
        // Simulate LLM response.
        const response = simulateLLMResponse(currentPrompt);
        console.log("LLM Response:", response);

        // Get feedback.
        const feedback = await new Promise<string>(resolve => {
            rl.question("Feedback (e.g., 'too wordy', 'vague', 'good'): ", resolve);
        });

        // Tune the prompt.
        basePrompt = tunePrompt(currentPrompt, feedback);
        console.log("Refined Prompt:", basePrompt);
        console.log("Token Estimate:", estimateTokens(basePrompt));

        iteration++;
        
        if (feedback.toLowerCase().includes('good')) {
            console.log("Prompt tuning successful! Exiting.");
            break;
        }
    }

    rl.close();
    console.log("Tuning session ended.");
}

// Run the main function if this module is executed directly.
if (require.main === module) {
    main().catch(console.error);
}

// Export for testing if needed.
export { simulateLLMResponse, tunePrompt };
