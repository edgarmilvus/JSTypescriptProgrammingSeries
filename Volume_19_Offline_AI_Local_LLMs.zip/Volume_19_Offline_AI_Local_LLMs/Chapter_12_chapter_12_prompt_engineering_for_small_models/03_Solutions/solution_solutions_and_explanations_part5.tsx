/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useEffect, useState } from 'react';

// Mock token estimation function.
function estimateTokens(text: string): number {
    return Math.ceil(text.length / 4);
}

// Define types for props.
interface FewShotExample {
    input: string;
    output: string;
}

interface PromptPreviewProps {
    systemPrompt: string;
    fewShotExamples: FewShotExample[];
    userInput: string;
}

/**
 * React component that displays a real-time preview of the prompt,
 * including token count and breakdown, with warnings for limits.
 */
const PromptPreview: React.FC<PromptPreviewProps> = ({ systemPrompt, fewShotExamples, userInput }) => {
    const [tokenCounts, setTokenCounts] = useState({
        system: 0,
        examples: 0,
        userInput: 0,
        total: 0,
    });
    const [isOverLimit, setIsOverLimit] = useState(false);

    // Recalculate token counts on prop changes.
    useEffect(() => {
        const systemTokens = estimateTokens(systemPrompt);
        const examplesText = fewShotExamples.map(ex => `${ex.input} ${ex.output}`).join(" ");
        const examplesTokens = estimateTokens(examplesText);
        const userInputTokens = estimateTokens(userInput);
        const totalTokens = systemTokens + examplesTokens + userInputTokens;

        setTokenCounts({
            system: systemTokens,
            examples: examplesTokens,
            userInput: userInputTokens,
            total: totalTokens,
        });

        // Check against 80% of a typical mobile context window (e.g., 8192 tokens for Llama 3).
        const contextWindow = 8192;
        setIsOverLimit(totalTokens > contextWindow * 0.8);
    }, [systemPrompt, fewShotExamples, userInput]);

    return (
        <div>
            <h3>Prompt Preview</h3>
            
            <section>
                <h4>System Prompt:</h4>
                <p>{systemPrompt}</p>
            </section>

            <section>
                <h4>Few-Shot Examples:</h4>
                {fewShotExamples.length > 0 ? (
                    <ul>
                        {fewShotExamples.map((ex, index) => (
                            <li key={index}>
                                <strong>Input:</strong> {ex.input}<br />
                                <strong>Output:</strong> {ex.output}
                            </li>
                        ))}
                    </ul>
                ) : (
                    <p>No examples provided.</p>
                )}
            </section>

            <section>
                <h4>User Input:</h4>
                <p>{userInput}</p>
            </section>

            <section>
                <h4>Token Breakdown:</h4>
                <table border={1} cellPadding={5}>
                    <thead>
                        <tr>
                            <th>Section</th>
                            <th>Tokens</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>System</td>
                            <td>{tokenCounts.system}</td>
                        </tr>
                        <tr>
                            <td>Examples</td>
                            <td>{tokenCounts.examples}</td>
                        </tr>
                        <tr>
                            <td>User Input</td>
                            <td>{tokenCounts.userInput}</td>
                        </tr>
                        <tr>
                            <td><strong>Total</strong></td>
                            <td><strong>{tokenCounts.total}</strong></td>
                        </tr>
                    </tbody>
                </table>
            </section>

            {isOverLimit && (
                <div style={{ color: 'red', fontWeight: 'bold' }}>
                    Warning: Total tokens exceed 80% of the mobile context window (6400/8192). Consider shortening the prompt.
                </div>
            )}
        </div>
    );
};

export default PromptPreview;

// Sample usage in a parent component:
/*
import PromptPreview from './PromptPreview';

function App() {
    const systemPrompt = "You are an assistant.";
    const fewShotExamples = [{ input: "Hi", output: "Hello" }];
    const userInput = "Tell me a joke";

    return (
        <div>
            <PromptPreview 
                systemPrompt={systemPrompt} 
                fewShotExamples={fewShotExamples} 
                userInput={userInput} 
            />
        </div>
    );
}
*/
