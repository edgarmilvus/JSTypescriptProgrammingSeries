/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

// streamer.ts

// 1. IMPORTS
// We use the 'events' module to implement the Observer pattern.
// In a browser, this might be 'EventTarget' or a library like 'mitt'.
import { EventEmitter } from 'events';

// 2. TYPE DEFINITIONS
// Strict typing ensures we don't pass invalid data between the model and UI.
interface TokenEvent {
  token: string;
  isComplete: boolean;
}

// 3. THE LOCAL LLM INFERENCE SIMULATOR
/**
 * Simulates a local LLM (e.g., Llama 3 8B Quantized) generating tokens.
 * In a real scenario, this would call a C++/Rust binding like 'llama.cpp'.
 */
class LocalLLMInference {
  private modelWeights: string;
  private prompt: string;

  constructor(weights: string) {
    this.modelWeights = weights;
    this.prompt = "";
  }

  /**
   * Sets the prompt for the next generation.
   */
  setPrompt(input: string) {
    this.prompt = input;
  }

  /**
   * Simulates the asynchronous generation of tokens.
   * Uses a generator function to yield tokens one by one.
   * @returns An async generator of strings (tokens).
   */
  async *generateTokens(): AsyncGenerator<string, void, unknown> {
    // Simulate model warm-up latency
    await new Promise(resolve => setTimeout(resolve, 100));

    // A mock response based on the prompt (very basic logic)
    const responseText = this.prompt.includes("hello")
      ? "Hello! How can I assist you with your local AI tasks today?"
      : "I am a local model running on your device. I can help with text generation.";

    // Split text into words/tokens to simulate LLM output
    const tokens = responseText.split(" ");

    for (const token of tokens) {
      // Simulate the compute time for each token (varies based on hardware)
      const delay = Math.random() * 50 + 20; // 20-70ms per token
      await new Promise(resolve => setTimeout(resolve, delay));
      
      yield token + " "; // Yield the token with a space
    }
  }
}

// 4. THE STREAM MANAGER (THE BRIDGE)
/**
 * Manages the connection between the LLM and the UI.
 * Adheres to Single Responsibility Principle (SRP): 
 * It only cares about event routing, not inference logic or UI rendering.
 */
class TokenStreamManager extends EventEmitter {
  private llm: LocalLLMInference;

  constructor(modelPath: string) {
    super();
    this.llm = new LocalLLMInference(modelPath);
  }

  /**
   * Starts the streaming process.
   * This acts as the controller in our MVC-like architecture.
   */
  public async startStream(prompt: string) {
    this.llm.setPrompt(prompt);
    
    // Get the async generator from the model
    const tokenGenerator = this.llm.generateTokens();

    // Loop through the generator as tokens become available
    for await (const token of tokenGenerator) {
      // Emit the token immediately to listeners (UI)
      this.emit('token', { token, isComplete: false } as TokenEvent);
    }

    // Emit a final event indicating the stream is finished
    this.emit('token', { token: '', isComplete: true } as TokenEvent);
  }
}

// 5. THE UI RENDERER (THE CONSUMER)
/**
 * Simulates the mobile UI component (e.g., React Native View).
 * It listens for events and updates the display buffer.
 */
class MobileUIRenderer {
  private displayBuffer: string = "";
  private streamManager: TokenStreamManager;

  constructor(manager: TokenStreamManager) {
    this.streamManager = manager;
    this.setupListeners();
  }

  /**
   * Sets up the event listeners.
   * Decouples the UI update logic from the data fetching logic.
   */
  private setupListeners() {
    // Listen for 'token' events emitted by the manager
    this.streamManager.on('token', (event: TokenEvent) => {
      if (event.isComplete) {
        this.finalizeRender();
      } else {
        this.appendTokenToUI(event.token);
      }
    });
  }

  /**
   * Updates the UI with the new token.
   * In a real app (React/React Native), this would trigger a setState().
   */
  private appendTokenToUI(token: string) {
    this.displayBuffer += token;
    // Simulate UI repaint
    console.log(`[UI Update]: ${this.displayBuffer}`); 
  }

  /**
   * Handles the end of the stream.
   */
  private finalizeRender() {
    console.log("\n--- Stream Complete ---");
    console.log(`Final Output: ${this.displayBuffer.trim()}`);
  }

  /**
   * Public method to trigger the generation from UI interaction.
   */
  public requestResponse(prompt: string) {
    console.log(`\n[User Input]: "${prompt}"`);
    console.log("--- Starting Stream ---");
    this.displayBuffer = ""; // Reset buffer
    this.streamManager.startStream(prompt);
  }
}

// 6. EXECUTION SIMULATION
// This simulates the app booting up and user interaction.
async function runApp() {
  // Initialize the system
  const modelPath = "./models/llama-3-8b-quantized.gguf"; // Placeholder path
  const streamManager = new TokenStreamManager(modelPath);
  const ui = new MobileUIRenderer(streamManager);

  // Simulate User Interaction 1
  ui.requestResponse("Hello there!");

  // Wait for the first stream to finish before starting the second
  // (In a real app, these would happen asynchronously based on user taps)
  await new Promise(resolve => setTimeout(resolve, 2000));

  // Simulate User Interaction 2
  ui.requestResponse("What are you?");
}

// Run the simulation
runApp().catch(console.error);
