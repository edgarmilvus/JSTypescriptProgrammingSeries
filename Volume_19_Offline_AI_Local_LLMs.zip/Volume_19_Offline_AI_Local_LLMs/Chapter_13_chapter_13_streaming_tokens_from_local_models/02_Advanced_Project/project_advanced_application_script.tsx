/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.tsx
// Description: Advanced Application Script
// ==========================================

import React, { useState, useRef, useEffect, useCallback } from 'react';

// ============================================================================
// 1. TYPE DEFINITIONS & UTILITY TYPES
// ============================================================================

/**
 * Represents a single message in the chat history.
 * Using `Readonly` ensures that message objects are immutable once created,
 * preventing accidental state mutations.
 */
type ChatMessage = Readonly<{
  id: string;
  role: 'user' | 'assistant';
  content: string;
}>;

/**
 * Utility Type: Represents the state of the streaming connection.
 * 'idle': No active request.
 * 'streaming': Tokens are being received.
 * 'error': The connection failed or the stream threw an error.
 */
type StreamStatus = 'idle' | 'streaming' | 'error';

/**
 * Expected structure of the SSE payload from the local LLM server.
 * In a real-world scenario (like Ollama), this might be more complex,
 * but we normalize it to this shape for the client.
 */
type SSEPayload = {
  token: string; // The incremental token chunk
  done: boolean; // Flag indicating the end of generation
};

// ============================================================================
// 2. THE REACT COMPONENT
// ============================================================================

/**
 * LocalLLMChat Component
 * 
 * @description
 * A React component that connects to a local LLM endpoint, sends user prompts,
 * and displays the response in a real-time streaming fashion. It handles
 * backpressure and UI updates efficiently using React state and refs.
 */
export default function LocalLLMChat() {
  // -- State Management --
  const [inputValue, setInputValue] = useState('');
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [status, setStatus] = useState<StreamStatus>('idle');
  
  // -- Refs for Performance --
  // We use a ref to accumulate the stream content without triggering
  // a re-render on every single token. We only update the state periodically
  // or when the stream completes to maintain high performance.
  const accumulatedContentRef = useRef<string>('');
  
  // AbortController to cancel the stream if the user navigates away
  // or triggers a new request prematurely.
  const abortControllerRef = useRef<AbortController | null>(null);

  /**
   * Core Logic: The Streaming Handler
   * 
   * Why use `useCallback`?
   * It memoizes the function, preventing unnecessary re-creations on re-renders.
   * This is crucial for event listeners and async operations.
   */
  const handleStream = useCallback(async (prompt: string) => {
    // 1. Optimistic UI Update: Add the user message immediately
    const userMessage: ChatMessage = {
      id: `user-${Date.now()}`,
      role: 'user',
      content: prompt
    };
    
    // We use the functional update form to ensure we have the latest state
    setMessages(prev => [...prev, userMessage]);
    
    // 2. Prepare the Assistant Placeholder
    const assistantMessageId = `assistant-${Date.now()}`;
    const assistantMessage: ChatMessage = {
      id: assistantMessageId,
      role: 'assistant',
      content: '' // Empty initially
    };
    
    setMessages(prev => [...prev, assistantMessage]);
    
    // 3. Reset Streaming State
    setStatus('streaming');
    accumulatedContentRef.current = '';
    
    // 4. Initialize Abort Controller (for cleanup)
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
    }
    abortControllerRef.current = new AbortController();
    const { signal } = abortControllerRef.current;

    try {
      // 5. The Fetch Request
      // NOTE: In a real app, this URL points to your local server (e.g., Ollama, LocalAI).
      // We are simulating the endpoint here for demonstration.
      const response = await fetch('/api/local-llm/stream', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt }),
        signal, // Attach the signal for cancellation
      });

      if (!response.ok || !response.body) {
        throw new Error('Network response was not ok');
      }

      // 6. The Streaming Pipeline
      const reader = response.body.getReader();
      const decoder = new TextDecoder();
      
      // We process the stream in a loop
      while (true) {
        const { done, value } = await reader.read();
        
        // Stream finished
        if (done) {
          setStatus('idle');
          
          // Final state update: Commit the accumulated content to React state
          setMessages(prev => 
            prev.map(msg => 
              msg.id === assistantMessageId 
                ? { ...msg, content: accumulatedContentRef.current } 
                : msg
            )
          );
          break;
        }

        // Decode the chunk (chunks can be partial tokens)
        const chunk = decoder.decode(value, { stream: true });
        
        // 7. Parsing Logic (SSE Format Simulation)
        // Real SSE comes as "data: {json}\n\n". We need to extract the JSON.
        // This regex handles multiple events in one chunk if necessary.
        const lines = chunk.split('\n').filter(line => line.trim() !== '');
        
        for (const line of lines) {
          if (line.startsWith('data: ')) {
            try {
              const data: SSEPayload = JSON.parse(line.replace('data: ', ''));
              
              // Append token to the ref
              accumulatedContentRef.current += data.token;

              // UI Optimization: Update state periodically (e.g., every 5 tokens)
              // or just on 'done'. For this demo, we update on every chunk 
              // to show the "typing" effect, but in heavy apps, you'd throttle this.
              setMessages(prev => 
                prev.map(msg => 
                  msg.id === assistantMessageId 
                    ? { ...msg, content: accumulatedContentRef.current } 
                    : msg
                )
              );

              if (data.done) {
                // Handle explicit done signal from server
                setStatus('idle');
                return; 
              }
            } catch (e) {
              // Ignore parsing errors for keep-alive or malformed lines
              console.warn("SSE Parse Error:", e);
            }
          }
        }
      }
    } catch (error) {
      if (error.name === 'AbortError') {
        console.log('Stream aborted');
      } else {
        setStatus('error');
        console.error('Stream Error:', error);
      }
    }
  }, []);

  // Cleanup effect: Abort stream if component unmounts
  useEffect(() => {
    return () => {
      if (abortControllerRef.current) {
        abortControllerRef.current.abort();
      }
    };
  }, []);

  // -- Render Logic --
  return (
    <div style={{ padding: '20px', fontFamily: 'sans-serif', maxWidth: '600px', margin: '0 auto' }}>
      <h2>Local LLM Streamer</h2>
      
      {/* Chat History */}
      <div style={{ border: '1px solid #ccc', height: '400px', overflowY: 'auto', padding: '10px', marginBottom: '10px' }}>
        {messages.map((msg) => (
          <div key={msg.id} style={{ marginBottom: '8px', textAlign: msg.role === 'user' ? 'right' : 'left' }}>
            <strong>{msg.role === 'user' ? 'You' : 'AI'}: </strong>
            <span style={{ 
              background: msg.role === 'user' ? '#e3f2fd' : '#f5f5f5', 
              padding: '4px 8px', 
              borderRadius: '4px',
              whiteSpace: 'pre-wrap' // Preserves token formatting
            }}>
              {msg.content}
              {/* Blinking cursor during streaming */}
              {status === 'streaming' && msg.role === 'assistant' && msg.id === messages[messages.length-1]?.id && (
                <span style={{ animation: 'blink 1s infinite' }}>|</span>
              )}
            </span>
          </div>
        ))}
      </div>

      {/* Controls */}
      <div style={{ display: 'flex', gap: '10px' }}>
        <input
          type="text"
          value={inputValue}
          onChange={(e) => setInputValue(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && handleStream(inputValue)}
          placeholder="Ask a local model..."
          style={{ flex: 1, padding: '8px' }}
          disabled={status === 'streaming'}
        />
        <button 
          onClick={() => handleStream(inputValue)} 
          disabled={status === 'streaming' || !inputValue}
          style={{ padding: '8px 16px' }}
        >
          {status === 'streaming' ? 'Generating...' : 'Send'}
        </button>
      </div>

      {status === 'error' && (
        <p style={{ color: 'red' }}>Error connecting to local model. Is the server running?</p>
      )}

      <style jsx>{`
        @keyframes blink {
          0%, 100% { opacity: 1; }
          50% { opacity: 0; }
        }
      `}</style>
    </div>
  );
}
