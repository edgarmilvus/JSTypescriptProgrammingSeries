/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

/**
 * A utility class to smooth the flow of tokens from an asynchronous source
 * by buffering them and flushing them at a controlled rate.
 */
class TokenBuffer {
    private buffer: string[] = [];
    private flushTimer: NodeJS.Timeout | null = null;
    private tokenCallback: ((token: string) => void) | null = null;
    private completeCallback: (() => void) | null = null;
    private readonly flushInterval: number;
    private isFlushing: boolean = false; // Flag to prevent re-entrancy issues

    constructor(flushInterval: number = 50) {
        this.flushInterval = flushInterval;
    }

    /**
     * Registers a callback to be invoked for each token flushed from the buffer.
     */
    public onTokenAvailable(callback: (token: string) => void): void {
        this.tokenCallback = callback;
    }

    /**
     * Registers a callback to be invoked when the stream ends.
     */
    public onComplete(callback: () => void): void {
        this.completeCallback = callback;
    }

    /**
     * Accepts a new token from the inference engine.
     * If the token is null/undefined, it signals the end of the stream.
     * @param token The token string or null for end-of-stream.
     */
    public pushToken(token: string | null): void {
        if (token === null || token === undefined) {
            this.handleEndOfStream();
            return;
        }

        this.buffer.push(token);

        // Start the flush timer if it's not already running
        if (!this.flushTimer) {
            this.flushTimer = setInterval(() => this.flush(), this.flushInterval);
        }
    }

    /**
     * Flushes the current buffer contents to the registered callback.
     * This is called internally by the timer or manually on stream end.
     */
    private flush(): void {
        // Prevent concurrent flushes if the operation is slow
        if (this.isFlushing || this.buffer.length === 0) return;

        this.isFlushing = true;

        // Copy the current buffer and clear it immediately to accept new tokens
        const tokensToFlush = [...this.buffer];
        this.buffer = [];

        // If we have a callback, invoke it with the batch of tokens
        if (this.tokenCallback) {
            // For a typewriter effect, we might want to send one by one, 
            // but for UI optimization, sending a batch is often better.
            // Here we'll send them individually to simulate a stream, 
            // but controlled by the interval.
            for (const token of tokensToFlush) {
                this.tokenCallback(token);
            }
        }

        this.isFlushing = false;
    }

    /**
     * Handles the termination of the stream.
     * Flushes any remaining tokens and triggers the complete callback.
     */
    private handleEndOfStream(): void {
        // Stop the periodic timer
        if (this.flushTimer) {
            clearInterval(this.flushTimer);
            this.flushTimer = null;
        }

        // Flush any remaining tokens in the buffer
        this.flush();

        // Invoke the completion callback
        if (this.completeCallback) {
            this.completeCallback();
        }
    }
}

// Example usage
const buffer = new TokenBuffer(50); // 50ms flush interval
buffer.onTokenAvailable((token) => console.log('UI Render:', token));
buffer.onComplete(() => console.log('Stream finished'));

// Simulate an LLM stream with bursty timing
async function simulateStream() {
    const tokens = ["The", " quick", " brown", " fox", " jumps", " over", " the", " lazy", " dog."];
    for (const token of tokens) {
        buffer.pushToken(token);
        // Random delay between 10ms and 100ms to simulate burstiness
        await new Promise(r => setTimeout(r, Math.random() * 90 + 10));
    }
    buffer.pushToken(null); // End of stream
}

simulateStream();
