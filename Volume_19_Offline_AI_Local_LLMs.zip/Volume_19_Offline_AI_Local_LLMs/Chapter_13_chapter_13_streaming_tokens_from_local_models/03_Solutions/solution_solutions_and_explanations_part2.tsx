/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState, useEffect, useRef } from 'react';

interface StreamingTextProps {
    tokenStream: AsyncIterable<string>;
}

const StreamingText: React.FC<StreamingTextProps> = ({ tokenStream }) => {
    const [displayedText, setDisplayedText] = useState('');
    
    // We use a ref to accumulate tokens without triggering re-renders on every token.
    // This acts as a local buffer within the component.
    const textAccumulator = useRef<string>('');
    
    // Ref to hold the animation frame ID or timeout ID for batching
    const animationFrameId = useRef<number | null>(null);

    useEffect(() => {
        let isMounted = true;

        const processStream = async () => {
            // Reset accumulator on new stream
            textAccumulator.current = '';

            for await (const token of tokenStream) {
                if (!isMounted) break;

                // Append token to the accumulator
                textAccumulator.current += token;

                // If an update is not already scheduled, schedule one
                if (animationFrameId.current === null) {
                    // Using requestAnimationFrame for smooth UI updates (syncs with browser repaint)
                    animationFrameId.current = requestAnimationFrame(() => {
                        if (isMounted) {
                            setDisplayedText(textAccumulator.current);
                        }
                        animationFrameId.current = null;
                    });
                }
            }
        };

        processStream();

        // Cleanup function
        return () => {
            isMounted = false;
            if (animationFrameId.current) {
                cancelAnimationFrame(animationFrameId.current);
            }
        };
    }, [tokenStream]);

    return <div style={{ fontFamily: 'monospace', whiteSpace: 'pre-wrap' }}>{displayedText}</div>;
};

export default StreamingText;
