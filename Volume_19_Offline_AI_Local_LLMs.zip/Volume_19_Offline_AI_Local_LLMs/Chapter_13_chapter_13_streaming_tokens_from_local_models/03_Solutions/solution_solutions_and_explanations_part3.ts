/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

// This solution assumes a basic HTML structure with elements like:
// #start-btn, #stop-btn, #flush-interval, #latency-slider
// #engine-indicator, #buffer-visual, #display-text

class SimulationController {
    private isRunning: boolean = false;
    private buffer: TokenBuffer;
    private flushInterval: number = 50;
    private latency: number = 0;
    private simulationInterval: NodeJS.Timeout | null = null;

    constructor() {
        // Initialize the buffer with a default interval
        this.buffer = new TokenBuffer(this.flushInterval);
        
        // Connect buffer callbacks to UI
        this.buffer.onTokenAvailable((token) => {
            // Simulate network latency before updating the display
            setTimeout(() => {
                const displayEl = document.getElementById('display-text');
                if (displayEl) {
                    displayEl.textContent += token;
                }
            }, this.latency);
        });

        this.buffer.onComplete(() => {
            console.log("Simulation Stream Complete");
        });
    }

    async startSimulation() {
        if (this.isRunning) return;
        this.isRunning = true;
        
        const words = ["Data", " flows", " like", " water.", " Buffer", " regulates", " the", " stream."];
        let index = 0;

        // Simulate the LLM inference engine loop
        this.simulationInterval = setInterval(() => {
            if (!this.isRunning || index >= words.length) {
                this.stopSimulation();
                return;
            }

            const token = words[index++];
            
            // 1. Visualize Inference Engine (Flash effect)
            const engineEl = document.getElementById('engine-indicator');
            if (engineEl) {
                engineEl.style.backgroundColor = '#4CAF50'; // Green
                setTimeout(() => engineEl.style.backgroundColor = '#ddd', 100);
            }
            
            // 2. Push to Buffer
            this.buffer.pushToken(token);
            
            // 3. Update Buffer Visualization (Queue)
            this.updateBufferVisual();

        }, Math.random() * 150 + 50); // Random delay 50-200ms
    }

    stopSimulation() {
        this.isRunning = false;
        if (this.simulationInterval) {
            clearInterval(this.simulationInterval);
            this.simulationInterval = null;
        }
        // Signal end of stream to buffer
        this.buffer.pushToken(null);
    }

    setFlushInterval(ms: number) {
        this.flushInterval = ms;
        // Note: In a real implementation, we might need to recreate the buffer 
        // or add a method to update the interval dynamically.
        // For this exercise, we assume the buffer handles dynamic updates or we restart.
        console.log(`Flush interval set to ${ms}ms`);
    }

    setLatency(ms: number) {
        this.latency = ms;
    }

    // Helper to visualize the internal buffer state
    // In a real app, the TokenBuffer would need a way to expose its internal state
    // or we would hook into the push/flush events.
    private updateBufferVisual() {
        // This is a simulation. In a real TokenBuffer, we would query the length.
        // Since we can't easily access private buffer length here without modifying the class,
        // we will simulate the visual lag.
        const bufferEl = document.getElementById('buffer-visual');
        if (bufferEl) {
            // Simple visual feedback: flash the buffer area
            bufferEl.style.borderColor = '#ff9800';
            setTimeout(() => bufferEl.style.borderColor = '#ccc', 100);
        }
    }
}

// Initialize (assuming DOM elements exist)
// const controller = new SimulationController();
