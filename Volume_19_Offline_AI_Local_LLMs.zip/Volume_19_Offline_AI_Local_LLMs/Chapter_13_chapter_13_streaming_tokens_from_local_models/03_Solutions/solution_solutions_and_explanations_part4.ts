/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

import { InferenceSession, Tensor } from 'onnxruntime-web';

// Mock types for demonstration purposes
type InferenceSession = any; // Actual ONNX type
type Tensor = any; // Actual ONNX type

declare function tokenIdToString(id: number): string;
const EOS_TOKEN_ID = 50256; // Example End of Sequence ID

/**
 * Creates an async generator that yields tokens one by one from an ONNX model.
 * 
 * @param session - The initialized ONNX Runtime session.
 * @param prompt - The initial text prompt.
 * @returns AsyncIterable<string>
 */
async function* createTokenStream(session: InferenceSession, prompt: string): AsyncIterable<string> {
    // 1. Encode the prompt into token IDs (Mock function)
    // In reality, use a tokenizer library like 'tokenizers' or 'gpt-tokenizer'
    let inputIds = encodePrompt(prompt); 
    
    // 2. Initialize the KV-Cache
    // The KV-cache stores the Key and Value tensors for previous tokens 
    // to avoid recomputing attention for the entire sequence at every step.
    // Structure: Array of objects { key: Tensor, value: Tensor } for each layer.
    let kvCache: Array<{ key: Tensor; value: Tensor }> = [];

    // Main generation loop
    while (true) {
        // 3. Prepare Inputs
        // The model expects 'input_ids' (current token) and 'past_key_values' (cache)
        const inputs: Record<string, Tensor> = {
            input_ids: new Tensor('int64', BigInt64Array.from(inputIds.map(BigInt)), [1, inputIds.length]),
            past_key_values: kvCache // Pass the cache (might be empty on first run)
        };

        // 4. Run Inference
        const outputs = await session.run(inputs);

        // 5. Extract Logits and Next Token
        // Outputs usually contain 'logits' (next token probabilities) 
        // and 'past_key_values' (updated cache).
        const logits = outputs.logits.data; // Flat array of scores
        const nextTokenId = logits.indexOf(Math.max(...logits)); // Greedy search (simplified)
        
        // 6. Decode Token
        const tokenString = tokenIdToString(nextTokenId);
        
        // 7. Yield to Consumer
        yield tokenString;

        // 8. Update State for Next Iteration
        // Update the KV-Cache with the new output
        kvCache = outputs.past_key_values;
        
        // Update input_ids for the next step (append the new token)
        inputIds = [nextTokenId];

        // 9. Check for End of Sequence
        if (nextTokenId === EOS_TOKEN_ID) {
            break;
        }
    }
}

// Mock helper for the exercise
function encodePrompt(prompt: string): number[] {
    return [15496, 11, 995, 33]; // Dummy IDs for "Hello, world"
}

/**
 * Under the Hood: KV-Cache Management
 * 
 * Why is it needed?
 * A Transformer model calculates attention by comparing every token to every other token.
 * Without a cache, for a sequence of length N, generating token N+1 requires processing 
 * all N previous tokens again. This is O(N^2) complexity.
 * 
 * With KV-Cache:
 * 1. On the first run (processing the prompt), we compute Keys and Values for all tokens 
 *    and store them.
 * 2. On subsequent runs (generating one token at a time), we only compute the Key/Value 
 *    for the *new* token.
 * 3. We append this new Key/Value to the existing cache and feed it back into the model.
 * 4. This reduces the complexity to O(N) for generation, making it significantly faster.
 * 
 * Data Structure:
 * Usually an array of objects, where each object corresponds to a transformer layer.
 * { key: Tensor [batch, heads, seq_len, dim], value: Tensor [batch, heads, seq_len, dim] }
 */
