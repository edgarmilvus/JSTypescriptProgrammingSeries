/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

// Example Edge Runtime endpoint (Vercel Edge Functions / Cloudflare Workers)

export async function POST(request: Request) {
    const { prompt, modelId } = await request.json();

    // 1. Simulate the Inference Engine (Async Generator)
    // In a real scenario, this might be a call to a local WASM model or a queue system.
    async function* simulateInference(prompt: string): AsyncGenerator<string, void, unknown> {
        const tokens = ["Here", " are", " some", " tokens", " from", " the", " edge."];
        for (const token of tokens) {
            // Simulate processing time
            await new Promise(resolve => setTimeout(resolve, 50));
            yield token;
        }
    }

    // 2. Create a ReadableStream from the Async Generator
    // This bridges the async generator world with the Web Stream API.
    const rawTokenStream = new ReadableStream({
        async start(controller) {
            try {
                for await (const token of simulateInference(prompt)) {
                    // Enqueue the raw token string
                    controller.enqueue(token);
                }
                controller.close();
            } catch (error) {
                controller.error(error);
            }
        },
    });

    // 3. Define the SSE Transformer
    // This transforms raw strings into the SSE format: "data: ...\n\n"
    const sseTransformer = new TransformStream<string, string>({
        transform(chunk, controller) {
            // SSE format requires "data: " prefix and double newline terminator
            const sseMessage = `data: ${JSON.stringify({ token: chunk })}\n\n`;
            controller.enqueue(sseMessage);
        },
        flush(controller) {
            // Send a termination event if needed
            controller.enqueue(`data: [DONE]\n\n`);
        }
    });

    // 4. Pipe the streams and return the response
    // The rawTokenStream is piped through the sseTransformer.
    const responseStream = rawTokenStream.pipeThrough(sseTransformer);

    return new Response(responseStream, {
        headers: {
            // Crucial header for SSE
            'Content-Type': 'text/event-stream',
            // Disable caching for streaming
            'Cache-Control': 'no-cache',
            'Connection': 'keep-alive',
        },
    });
}

/**
 * Instructor's Analysis: Why TransformStream is Efficient
 * 
 * 1. Backpressure Handling:
 *    When you pipe streams (source.pipeThrough(transformer).pipeTo(destination)),
 *    the underlying implementation handles backpressure automatically.
 *    If the network is slow (consumer), the destination signals back to the transformer,
 *    which signals back to the source. The source pauses generation.
 *    Manual string concatenation in a loop ignores backpressure, potentially leading to
 *    high memory usage if the consumer is slower than the producer.
 * 
 * 2. Memory Efficiency:
 *    TransformStream processes data in chunks. It doesn't require holding the entire
 *    response body in memory before sending it. It transforms and flushes data incrementally.
 *    Manual concatenation (e.g., `let result = ""; result += chunk`) creates new strings
 *    repeatedly, which is expensive in terms of garbage collection.
 * 
 * 3. Standardization:
 *    Using Web Streams API is standard across Edge runtimes (Deno, V8 isolates).
 *    It provides a robust, optimized implementation written in C++/Rust, whereas
 *    manual string manipulation is purely JavaScript-bound and less optimized.
 */
