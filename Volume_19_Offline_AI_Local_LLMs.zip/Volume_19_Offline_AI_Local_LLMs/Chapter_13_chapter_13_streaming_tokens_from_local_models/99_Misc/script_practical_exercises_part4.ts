/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part4.ts
// Description: Practical Exercises
// ==========================================

// Example structure for the token stream creator (DO NOT IMPLEMENT)
import { InferenceSession, Tensor } from 'onnxruntime-web';

// Assume this is provided
declare function tokenIdToString(id: number): string;

/**
 * Creates an async generator that yields tokens one by one.
 * @param session The initialized ONNX Runtime session.
 * @param prompt The initial text prompt.
 */
async function* createTokenStream(session: InferenceSession, prompt: string): AsyncIterable<string> {
    // TODO: Encode the prompt into initial token IDs.
    // TODO: Initialize an empty KV-cache structure (e.g., an array of tensors for each layer).
    
    let currentTokens = encodePrompt(prompt);
    
    // Main generation loop
    while (true) {
        // TODO: Prepare input tensor for the model, including the current tokens and the KV-cache.
        // const inputs = { input_ids: currentTokens, past_key_values: ... };
        
        // TODO: Run inference
        // const outputs = await session.run(inputs);
        
        // TODO: Extract the next token ID from the output tensor.
        // const nextTokenId = outputs.logits.data[...];
        
        // TODO: Decode the token ID to a string.
        // const tokenString = tokenIdToString(nextTokenId);
        
        // TODO: Yield the token string to the consumer.
        // yield tokenString;
        
        // TODO: Update the KV-cache with the new token's key/value states.
        // TODO: Update currentTokens for the next iteration.
        
        // TODO: Check for end-of-sequence token and break the loop.
        // if (nextTokenId === eos_token_id) break;
    }
}

// Usage with the React component from Exercise 2
// const tokenStream = await createTokenStream(onnxSession, "Hello, world!");
// <StreamingText tokenStream={tokenStream} />
