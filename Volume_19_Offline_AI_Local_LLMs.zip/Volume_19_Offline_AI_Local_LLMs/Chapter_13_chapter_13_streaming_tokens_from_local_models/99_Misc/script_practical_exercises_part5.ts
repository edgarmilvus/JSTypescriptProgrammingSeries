/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part5.ts
// Description: Practical Exercises
// ==========================================

// Example Edge Runtime endpoint (DO NOT IMPLEMENT)
// This is for a runtime like Vercel Edge Functions or Cloudflare Workers

export async function POST(request: Request) {
    const { prompt, modelId } = await request.json();

    // Simulate an async token generator (in reality, this would call a local model or another service)
    async function* simulateInference(prompt: string): AsyncGenerator<string, void, unknown> {
        const tokens = prompt.split(' ').concat(['is', 'a', 'test', 'stream']);
        for (const token of tokens) {
            await new Promise(resolve => setTimeout(resolve, 100));
            yield token;
        }
    }

    // Create a ReadableStream from our async generator
    const tokenStream = new ReadableStream({
        async start(controller) {
            for await (const token of simulateInference(prompt)) {
                // TODO: Enqueue the token into the controller
                // controller.enqueue(...)
            }
            controller.close();
        },
    });

    // TODO: Create a TransformStream to convert raw tokens to SSE format.
    // The SSE format is: `data: ${JSON.stringify({ token })}\n\n`
    // const sseTransformer = new TransformStream({ ... });

    // TODO: Pipe the tokenStream through the sseTransformer and return the response.
    // return new Response(tokenStream.pipeThrough(sseTransformer), {
    //     headers: { 'Content-Type': 'text/event-stream' },
    // });
}
