/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.tsx
// Description: Basic Code Example
// ==========================================

// File: components/MobileAIChat.tsx

import React, { useState, useCallback } from 'react';
import { useChat } from 'ai/react'; // Vercel AI SDK

// --- MOCK DEFINITIONS (Simulating external libraries) ---

/**
 * Mock interface for a Supabase client interacting with pgvector.
 * In a real app, this would be `import { createClient } from '@supabase/supabase-js'`
 */
interface SupabaseClient {
  from: (table: string) => {
    rpc: (fn: string, params: any) => Promise<{ data: any[]; error: any }>;
  };
}

/**
 * Mock interface for a local LLM engine (e.g., Llama.cpp via WASM).
 * This abstracts the heavy computation away from the React component.
 */
interface LocalLLMEngine {
  generate: (prompt: string, onToken: (token: string) => void) => Promise<void>;
}

// --- MOCK IMPLEMENTATIONS ---

// Simulates a database connection to a local vector store
const mockSupabaseClient: SupabaseClient = {
  from: (table: string) => ({
    rpc: async (fn: string, params: any) => {
      // Simulate network latency for vector search
      await new Promise(r => setTimeout(r, 300)); 
      return {
        data: [
          { content: "Thermal throttling occurs when the CPU exceeds safe temperatures." },
          { content: "Optimizing battery involves reducing CPU frequency." }
        ],
        error: null
      };
    }
  })
};

// Simulates the local Llama 3 model running on the device
const mockLocalLLM: LocalLLMEngine = {
  generate: async (prompt: string, onToken: (token: string) => void) => {
    const response = `Based on local context, here is the answer: ${prompt}`;
    // Simulate streaming tokens (crucial for UI responsiveness)
    for (const char of response) {
      await new Promise(r => setTimeout(r, 20)); // Simulate inference time per token
      onToken(char);
    }
  }
};

// --- CORE LOGIC: HOOK FOR LOCAL AI WITH CONSTRAINT MANAGEMENT ---

/**
 * Custom hook to manage local AI inference with mobile constraints.
 * It wraps the Vercel `useChat` hook to inject local logic.
 */
function useLocalAIChat() {
  // Standard Vercel hook for managing chat UI state
  const { messages, input, setInput, append, isLoading, stop } = useChat({
    api: '/api/chat', // Not actually used in this mock, but required by SDK
  });

  // State to track thermal/battery status (simulated)
  const [systemStatus, setSystemStatus] = useState<'normal' | 'throttling' | 'low_power'>('normal');

  /**
   * Performs a local vector search using pgvector via Supabase.
   * @param query - The user's text query.
   * @returns Relevant context strings.
   */
  const performVectorSearch = async (query: string): Promise<string[]> => {
    // 1. Embed the query (mocked: usually done via a local model like Transformers.js)
    const embedding = [0.1, 0.2, 0.3]; 

    // 2. Query local Supabase/pgvector
    const { data, error } = await mockSupabaseClient
      .from('documents')
      .rpc('match_documents', {
        query_embedding: embedding,
        match_threshold: 0.7,
      });

    if (error) throw error;
    return data.map((d) => d.content);
  };

  /**
   * Handles the submission of a message.
   * Integrates vector search and local LLM generation.
   */
  const handleLocalSubmit = useCallback(async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim()) return;

    // 1. Check Mobile Constraints (Simulated)
    // In a real app, this would check `navigator.getBattery()` or device temperature APIs.
    if (systemStatus === 'low_power') {
      alert("Battery low. Switching to text-only mode (no vector search).");
      // Fallback logic would go here
    }

    // 2. Add user message to UI immediately
    await append({ role: 'user', content: input });

    // 3. Perform Local Vector Search (Context Retrieval)
    // This is a blocking operation; on mobile, we might want to offload this.
    const contextDocs = await performVectorSearch(input);
    const systemContext = contextDocs.join('\n');

    // 4. Construct Prompt with Context
    const fullPrompt = `Context:\n${systemContext}\n\nUser Query: ${input}`;

    // 5. Local LLM Inference (Streaming)
    // We simulate streaming to keep the UI responsive (prevents "thermal throttling" by not blocking main thread)
    setSystemStatus('throttling'); // Simulate entering high load state
    
    let streamedResponse = '';
    
    // Create a dummy assistant message to append to
    const tempId = `temp-${Date.now()}`;
    const assistantMessage = { id: tempId, role: 'assistant', content: '' };
    
    // Optimistically update UI
    // (Note: Vercel SDK handles this internally, but we simulate the manual update here for clarity)
    // In a real Vercel SDK implementation, we would use `useChat`'s `onResponse` or `onStreamUpdate`.

    try {
      await mockLocalLLM.generate(fullPrompt, (token) => {
        streamedResponse += token;
        
        // Simulate updating UI state (UIState in Vercel SDK)
        // This is where we would call `setMessages` or stream to the client.
        console.log(`Streaming token: ${token}`); 
      });

      // Finalize
      await append({ role: 'assistant', content: streamedResponse });
    } catch (error) {
      console.error("Local inference failed:", error);
    } finally {
      setSystemStatus('normal');
    }

    // Reset input
    setInput('');
  }, [input, append, setInput, systemStatus]);

  return {
    messages,
    input,
    setInput: handleLocalSubmit, // Overriding standard submit
    isLoading,
    systemStatus
  };
}

// --- REACT COMPONENT ---

/**
 * A simple chat component demonstrating local AI on mobile.
 */
export default function MobileAIChat() {
  const { messages, input, setInput, isLoading, systemStatus } = useLocalAIChat();

  return (
    <div style={{ padding: '20px', fontFamily: 'sans-serif', maxWidth: '600px', margin: '0 auto' }}>
      <div style={{ marginBottom: '10px', fontSize: '12px', color: '#666' }}>
        Status: <strong>{systemStatus}</strong> | Battery/Thermal Simulation
      </div>

      <div style={{ border: '1px solid #ddd', padding: '10px', height: '300px', overflowY: 'auto' }}>
        {messages.map((msg) => (
          <div key={msg.id} style={{ marginBottom: '8px' }}>
            <strong>{msg.role === 'user' ? 'You: ' : 'AI: '}</strong>
            {msg.content}
          </div>
        ))}
        {isLoading && <div style={{ fontStyle: 'italic' }}>Thinking locally...</div>}
      </div>

      <form onSubmit={setInput} style={{ marginTop: '10px', display: 'flex', gap: '10px' }}>
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Ask about thermal throttling..."
          style={{ flex: 1, padding: '8px' }}
        />
        <button type="submit" disabled={isLoading} style={{ padding: '8px 16px' }}>
          Send
        </button>
      </form>
    </div>
  );
}
