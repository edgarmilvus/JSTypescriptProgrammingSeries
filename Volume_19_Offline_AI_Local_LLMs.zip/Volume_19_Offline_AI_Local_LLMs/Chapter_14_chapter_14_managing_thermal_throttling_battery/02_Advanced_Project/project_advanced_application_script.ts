/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// pages/api/chat/thermal-aware.ts
// Next.js API Route for Thermal & Battery Aware LLM Inference

import { NextRequest, NextResponse } from 'next/server';
import { SupabaseClient } from '@supabase/supabase-js';
import { createClient } from '@supabase/supabase-js';

// -----------------------------------------------------------------------------
// 1. TYPE DEFINITIONS & CONFIGURATION
// -----------------------------------------------------------------------------

/**
 * Represents the telemetry data sent from the mobile client to the server.
 * This data is crucial for making informed decisions about inference load.
 */
interface DeviceTelemetry {
  batteryLevel: number;       // 0.0 to 1.0
  isThermalThrottling: boolean; // True if OS has throttled CPU
  cpuTemperature: number;     // Celsius
  memoryPressure: number;     // 0.0 to 1.0 (iOS/Android memory warnings)
}

/**
 * Configuration for inference parameters based on thermal states.
 * 'eco': High battery saving, lower quality
 * 'balanced': Standard operation
 * 'performance': High energy cost, max quality (disabled if throttling)
 */
type ThermalMode = 'eco' | 'balanced' | 'performance';

const THERMAL_CONFIG: Record<ThermalMode, any> = {
  eco: {
    temperature: 0.3,       // Lower randomness
    maxTokens: 64,          // Shorter responses
    vectorSearchLimit: 50,  // Fewer DB rows to scan
    streamDelay: 100,       // ms delay between chunks to reduce CPU load
  },
  balanced: {
    temperature: 0.7,
    maxTokens: 256,
    vectorSearchLimit: 100,
    streamDelay: 10,
  },
  performance: {
    temperature: 0.9,
    maxTokens: 512,
    vectorSearchLimit: 200,
    streamDelay: 0,
  },
};

// Initialize Supabase Client for Vector Search
const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL!;
const supabaseKey = process.env.SUPABASE_SERVICE_ROLE_KEY!;
const supabase = createClient(supabaseUrl, supabaseKey);

// -----------------------------------------------------------------------------
// 2. HELPER FUNCTIONS: HARDWARE CONSTRAINT LOGIC
// -----------------------------------------------------------------------------

/**
 * Determines the optimal inference mode based on real-time telemetry.
 * 
 * @param telemetry - The incoming device metrics.
 * @returns {ThermalMode} The calculated mode.
 * 
 * LOGIC:
 * 1. If battery is critical (< 15%) OR thermal throttling is active -> 'eco'.
 * 2. If CPU temp > 50C -> Force 'eco' regardless of battery to prevent hardware damage.
 * 3. If memory pressure is high -> Reduce context size (handled in inference step).
 * 4. Default -> 'balanced'.
 */
function getInferenceMode(telemetry: DeviceTelemetry): ThermalMode {
  // Critical Battery Safety Check
  if (telemetry.batteryLevel < 0.15) return 'eco';

  // Thermal Throttling Override
  if (telemetry.isThermalThrottling) return 'eco';

  // Temperature Safety Check (Hardware protection)
  if (telemetry.cpuTemperature > 50) return 'eco';

  // Performance Mode (Requires good conditions)
  if (telemetry.batteryLevel > 0.5 && telemetry.cpuTemperature < 40) {
    return 'performance';
  }

  return 'balanced';
}

/**
 * Simulates a vector search against a Supabase table with pgvector.
 * Includes a synthetic delay to simulate processing load.
 * 
 * @param query - The user's text to embed and search.
 * @param limit - Max rows to retrieve (controlled by thermal mode).
 * @returns {Promise<string[]>} Relevant context chunks.
 */
async function performVectorSearch(query: string, limit: number): Promise<string[]> {
  // In a real app, we would generate an embedding here (e.g., via Edge Function or local model)
  // For this script, we assume the query is already embedded or we mock the search.
  
  // Simulate network latency and processing load
  await new Promise(resolve => setTimeout(resolve, 150)); 

  // Mocking Supabase pgvector query
  // const { data, error } = await supabase
  //   .rpc('match_documents', {
  //     query_embedding: embedding,
  //     match_count: limit
  //   });

  if (limit === 50) return ['Context chunk 1 (Eco mode limited)'];
  return ['Context chunk 1', 'Context chunk 2', 'Context chunk 3'];
}

// -----------------------------------------------------------------------------
// 3. CORE API ROUTE HANDLER
// -----------------------------------------------------------------------------

export default async function handler(req: NextRequest) {
  if (req.method !== 'POST') {
    return NextResponse.json({ error: 'Method not allowed' }, { status: 405 });
  }

  try {
    // -------------------------------------------------------------------------
    // A. Parse Client Telemetry
    // -------------------------------------------------------------------------
    // In a real mobile app, this data is extracted from the Battery API 
    // and Thermal API (iOS/Android specific) and sent in headers or body.
    const body = await req.json();
    const telemetry: DeviceTelemetry = body.telemetry || {
      batteryLevel: 0.8,
      isThermalThrottling: false,
      cpuTemperature: 35,
      memoryPressure: 0.2,
    };

    const { prompt, messages } = body;

    // -------------------------------------------------------------------------
    // B. Determine Operational Mode
    // -------------------------------------------------------------------------
    const mode = getInferenceMode(telemetry);
    const config = THERMAL_CONFIG[mode];

    // -------------------------------------------------------------------------
    // C. Battery-Conscious Vector Search (RAG)
    // -------------------------------------------------------------------------
    // If the device is in 'eco' mode, we reduce the search scope to save 
    // database I/O and local processing power.
    const relevantContext = await performVectorSearch(prompt, config.vectorSearchLimit);
    
    // Construct the prompt with context
    const systemPrompt = `Context: ${relevantContext.join('\n')}\n\nUser: ${prompt}`;
    
    // -------------------------------------------------------------------------
    // D. Simulated LLM Inference & Thermal-Aware Streaming
    // -------------------------------------------------------------------------
    // We simulate the stream response. In production, this would be a fetch 
    // to Ollama (local) or a standard OpenAI endpoint.
    
    const encoder = new TextEncoder();
    const customReadable = new ReadableStream({
      async start(controller) {
        const responseText = `Simulated response in ${mode} mode. Context retrieved: ${relevantContext.length} chunks.`;
        
        // Simulate streaming chunks
        const words = responseText.split(' ');
        for (const word of words) {
          // THERMAL SAFETY: Inject delay if in Eco mode to reduce CPU duty cycle
          if (mode === 'eco' || mode === 'balanced') {
            await new Promise(resolve => setTimeout(resolve, config.streamDelay));
          }
          
          controller.enqueue(encoder.encode(word + ' '));
        }
        
        controller.close();
      },
    });

    // -------------------------------------------------------------------------
    // E. Return Stream Response
    // -------------------------------------------------------------------------
    return new NextResponse(customReadable, {
      headers: {
        'Content-Type': 'text/event-stream',
        'Cache-Control': 'no-cache',
        'Connection': 'keep-alive',
        // Pass back the detected mode to client for UI updates
        'X-Thermal-Mode': mode,
      },
    });

  } catch (error) {
    console.error('Thermal Aware API Error:', error);
    return NextResponse.json(
      { error: 'Internal Server Error' }, 
      { status: 500 }
    );
  }
}
