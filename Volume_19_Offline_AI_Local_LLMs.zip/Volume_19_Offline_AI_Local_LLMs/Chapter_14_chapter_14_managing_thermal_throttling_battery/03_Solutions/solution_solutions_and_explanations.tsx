/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState, useEffect, useRef } from 'react';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from 'recharts';

// --- 1. Custom Hook Implementation ---

interface ThermalState {
  temperature: number;
  status: 'normal' | 'warning' | 'critical';
}

export function useDeviceThermalState(): ThermalState {
  const [thermalState, setThermalState] = useState<ThermalState>({
    temperature: 30,
    status: 'normal',
  });

  useEffect(() => {
    const interval = setInterval(() => {
      // Simulate temperature fluctuation
      const fluctuation = (Math.random() - 0.5) * 5; // +/- 2.5 degrees
      const baseTemp = 40; // Base temp around 40C
      const newTemp = Math.max(25, Math.min(70, baseTemp + fluctuation + (Math.random() > 0.95 ? 15 : 0))); // Occasional spike

      let newStatus: 'normal' | 'warning' | 'critical' = 'normal';
      if (newTemp > 55) {
        newStatus = 'critical';
      } else if (newTemp > 45) {
        newStatus = 'warning';
      }

      setThermalState({ temperature: parseFloat(newTemp.toFixed(1)), status: newStatus });
    }, 1000); // Update every second

    return () => clearInterval(interval);
  }, []);

  return thermalState;
}

// --- 2. Visualization Component ---

interface DataPoint {
  time: string;
  temp: number;
}

const ThermalMonitor: React.FC = () => {
  const { temperature, status } = useDeviceThermalState();
  const [history, setHistory] = useState<DataPoint[]>([]);
  const startTimeRef = useRef<number>(Date.now());

  useEffect(() => {
    const now = Date.now();
    const timeElapsed = ((now - startTimeRef.current) / 1000).toFixed(0);
    
    // Keep only the last 60 data points
    const newHistory = [...history, { time: timeElapsed, temp: temperature }];
    if (newHistory.length > 60) {
      newHistory.shift();
    }
    
    setHistory(newHistory);
  }, [temperature]);

  // Determine line color based on status
  const lineColor = status === 'critical' ? '#ff4d4f' : status === 'warning' ? '#faad14' : '#52c41a';
  const alertStyle = status === 'critical' ? { border: '2px solid red', animation: 'pulse 1s infinite' } : {};

  return (
    <div style={{ padding: '20px', border: '1px solid #ddd', borderRadius: '8px', ...alertStyle }}>
      <h3>Thermal Monitor</h3>
      <div style={{ marginBottom: '10px' }}>
        <strong>Current:</strong> {temperature}°C | <strong>Status:</strong> {status.toUpperCase()}
      </div>
      <div style={{ height: '250px', width: '100%' }}>
        <ResponsiveContainer>
          <LineChart data={history}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="time" label={{ value: 'Seconds', position: 'insideBottomRight', offset: -5 }} />
            <YAxis domain={[20, 70]} label={{ value: 'Temp (°C)', angle: -90, position: 'insideLeft' }} />
            <Tooltip />
            <Legend />
            <Line
              type="monotone"
              dataKey="temp"
              stroke={lineColor}
              strokeWidth={2}
              dot={false}
              isAnimationActive={false}
            />
          </LineChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
};

export default ThermalMonitor;
