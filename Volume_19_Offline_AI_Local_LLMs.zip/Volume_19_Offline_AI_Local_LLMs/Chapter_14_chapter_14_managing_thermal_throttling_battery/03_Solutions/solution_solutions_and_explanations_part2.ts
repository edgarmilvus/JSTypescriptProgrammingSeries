/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

import { useState, useEffect, useRef, useCallback } from 'react';

// --- 1. Battery Status Hook ---

interface BatteryStatus {
  level: number; // 0 to 1
  charging: boolean;
}

export function useBatteryStatus(): BatteryStatus {
  const [battery, setBattery] = useState<BatteryStatus>({ level: 0.8, charging: false });

  useEffect(() => {
    // Simulate battery drain
    const drainInterval = setInterval(() => {
      setBattery(prev => {
        if (prev.charging) {
          return { ...prev, level: Math.min(1, prev.level + 0.01) };
        }
        return { ...prev, level: Math.max(0, prev.level - 0.005) };
      });
    }, 2000); // Drain/charge every 2 seconds

    // Simulate user plugging/unplugging
    const toggleChargeInterval = setInterval(() => {
      setBattery(prev => ({ ...prev, charging: !prev.charging }));
    }, 30000); // Toggle charging status every 30 seconds

    return () => {
      clearInterval(drainInterval);
      clearInterval(toggleChargeInterval);
    };
  }, []);

  return battery;
}

// --- 2. Throttled Vector Search Hook ---

export function useThrottledVectorSearch(
  searchFunction: (query: string) => Promise<any>,
  batteryStatus: BatteryStatus
) {
  const timeoutRef = useRef<NodeJS.Timeout | null>(null);

  // Determine delay based on battery rules
  const getDelay = useCallback((): number => {
    const { level, charging } = batteryStatus;
    if (level < 0.2 && !charging) return 2000;
    if (level >= 0.2 && level < 0.5 && !charging) return 1000;
    return 300; // Default for > 50% or charging
  }, [batteryStatus]);

  const throttledSearch = useCallback((query: string) => {
    if (timeoutRef.current) {
      clearTimeout(timeoutRef.current);
    }

    const delay = getDelay();
    
    timeoutRef.current = setTimeout(() => {
      console.log(`Executing search for "${query}" after ${delay}ms delay.`);
      searchFunction(query);
    }, delay);

  }, [searchFunction, getDelay]);

  return throttledSearch;
}

// --- 3. Example Usage Component ---

export const SearchComponent: React.FC = () => {
  const battery = useBatteryStatus();
  
  // Mock search function
  const performSearch = async (query: string) => {
    console.log(`Searching for: ${query}`);
    // In a real app, this would fetch data
  };

  const handleSearch = useThrottledVectorSearch(performSearch, battery);

  return (
    <div>
      <h3>Search Throttler</h3>
      <p>Battery: {(battery.level * 100).toFixed(0)}% | Charging: {battery.charging ? 'Yes' : 'No'}</p>
      <input 
        type="text" 
        placeholder="Type to search..." 
        onChange={(e) => handleSearch(e.target.value)} 
      />
    </div>
  );
};
