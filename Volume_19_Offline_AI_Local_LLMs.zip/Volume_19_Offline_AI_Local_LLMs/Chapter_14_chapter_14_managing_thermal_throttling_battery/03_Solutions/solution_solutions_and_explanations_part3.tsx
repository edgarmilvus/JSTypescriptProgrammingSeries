/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState } from 'react';

// --- 1. Type Definitions and Configuration ---

export type PowerProfile = 'performance' | 'balanced' | 'battery_saver';

export interface InferenceConfig {
  maxTokens: number;
  contextWindow: number;
  searchDebounceMs: number;
  description: string;
}

const PROFILE_CONFIGS: Record<PowerProfile, InferenceConfig> = {
  performance: {
    maxTokens: 2048,
    contextWindow: 4096,
    searchDebounceMs: 300,
    description: 'Prioritizes speed. High token count and context, minimal search delay. Drains battery faster.',
  },
  balanced: {
    maxTokens: 1024,
    contextWindow: 2048,
    searchDebounceMs: 1000,
    description: 'A mix of speed and efficiency. Good for general use.',
  },
  battery_saver: {
    maxTokens: 256,
    contextWindow: 512,
    searchDebounceMs: 2000,
    description: 'Maximizes battery life. Low token count and context, aggressive search throttling.',
  },
};

// --- 2. UI Component Implementation ---

export const PowerProfileConfigurator: React.FC = () => {
  const [activeProfile, setActiveProfile] = useState<PowerProfile>('balanced');
  const currentConfig = PROFILE_CONFIGS[activeProfile];

  const handleProfileChange = (profile: PowerProfile) => {
    setActiveProfile(profile);
  };

  return (
    <div style={{ border: '1px solid #ccc', padding: '16px', borderRadius: '8px', maxWidth: '500px' }}>
      <h3>Power Profile Configurator</h3>
      <div style={{ display: 'flex', gap: '10px', marginBottom: '16px' }}>
        {(['performance', 'balanced', 'battery_saver'] as PowerProfile[]).map((profile) => (
          <button
            key={profile}
            onClick={() => handleProfileChange(profile)}
            style={{
              padding: '8px 16px',
              fontWeight: activeProfile === profile ? 'bold' : 'normal',
              backgroundColor: activeProfile === profile ? '#e6f7ff' : '#f5f5f5',
              border: activeProfile === profile ? '1px solid #1890ff' : '1px solid #d9d9d9',
              cursor: 'pointer',
            }}
          >
            {profile.replace('_', ' ').toUpperCase()}
          </button>
        ))}
      </div>

      <div style={{ background: '#f9f9f9', padding: '12px', borderRadius: '4px' }}>
        <h4>Current Configuration: {activeProfile.toUpperCase()}</h4>
        <ul style={{ listStyle: 'none', padding: 0, margin: 0 }}>
          <li><strong>Max Tokens:</strong> {currentConfig.maxTokens}</li>
          <li><strong>Context Window:</strong> {currentConfig.contextWindow}</li>
          <li><strong>Search Debounce:</strong> {currentConfig.searchDebounceMs}ms</li>
        </ul>
        <p style={{ marginTop: '12px', fontStyle: 'italic', color: '#555' }}>
          {currentConfig.description}
        </p>
      </div>
    </div>
  );
};
