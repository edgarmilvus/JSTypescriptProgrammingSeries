/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { createContext, useContext, useState, useEffect, useMemo } from 'react';

// --- 1. Imports from Previous Exercises (Mocked for standalone context) ---

// Mocking the hooks to make this file runnable
const useDeviceThermalState = () => {
  const [temp, setTemp] = useState(30);
  useEffect(() => {
    const id = setInterval(() => setTemp(t => t + (Math.random() - 0.5) * 2), 2000);
    return () => clearInterval(id);
  }, []);
  return { temperature: temp, status: temp > 55 ? 'critical' : temp > 45 ? 'warning' : 'normal' as any };
};

const useBatteryStatus = () => {
  const [level, setLevel] = useState(0.5);
  useEffect(() => {
    const id = setInterval(() => setLevel(l => Math.max(0, l - 0.01)), 5000);
    return () => clearInterval(id);
  }, []);
  return { level, charging: false };
};

// Re-using types from Exercise 3
type PowerProfile = 'performance' | 'balanced' | 'battery_saver';
interface InferenceConfig {
  maxTokens: number;
  contextWindow: number;
  searchDebounceMs: number;
}

const PROFILE_CONFIGS: Record<PowerProfile, InferenceConfig> = {
  performance: { maxTokens: 2048, contextWindow: 4096, searchDebounceMs: 300 },
  balanced: { maxTokens: 1024, contextWindow: 2048, searchDebounceMs: 1000 },
  battery_saver: { maxTokens: 256, contextWindow: 512, searchDebounceMs: 2000 },
};

// --- 2. Context and Governor Component ---

const InferenceConfigContext = createContext<InferenceConfig | null>(null);

export const useInferenceConfig = () => {
  const context = useContext(InferenceConfigContext);
  if (!context) {
    throw new Error('useInferenceConfig must be used within an AdaptiveInferenceGovernor');
  }
  return context;
};

export const AdaptiveInferenceGovernor: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const thermal = useDeviceThermalState();
  const battery = useBatteryStatus();
  const [currentProfile, setCurrentProfile] = useState<PowerProfile>('balanced');

  useEffect(() => {
    // --- Adaptive Logic Engine ---
    let newProfile: PowerProfile = 'balanced';

    // Rule 1: Critical thermal state overrides everything
    if (thermal.status === 'critical') {
      newProfile = 'battery_saver';
    }
    // Rule 2: Low battery state
    else if (battery.level < 0.15 && !battery.charging) {
      newProfile = 'battery_saver';
    }
    // Rule 3: High battery and normal temp allows performance
    else if (battery.level > 0.5 && thermal.status === 'normal') {
      newProfile = 'performance';
    }
    // Rule 4: Default to balanced for other cases (e.g., normal temp but low battery)
    else {
      newProfile = 'balanced';
    }

    // Only update state and log if the profile actually changes
    if (newProfile !== currentProfile) {
      console.log(`[Governor] Hardware constraints changed. Switching profile from '${currentProfile}' to '${newProfile}'. (Temp: ${thermal.temperature}°C, Battery: ${(battery.level*100).toFixed(0)}%)`);
      setCurrentProfile(newProfile);
    }
  }, [thermal, battery, currentProfile]);

  const config = useMemo(() => PROFILE_CONFIGS[currentProfile], [currentProfile]);

  return (
    <InferenceConfigContext.Provider value={config}>
      {children}
    </InferenceConfigContext.Provider>
  );
};

// --- 3. Example Consumer Component ---

export const ChatUI: React.FC = () => {
  const config = useInferenceConfig();
  return (
    <div style={{ border: '1px solid blue', padding: '10px', margin: '10px' }}>
      <h3>AI Chat Interface</h3>
      <p>Current Engine Config:</p>
      <pre>{JSON.stringify(config, null, 2)}</pre>
      <small>The governor is automatically adjusting these settings based on device health.</small>
    </div>
  );
};
