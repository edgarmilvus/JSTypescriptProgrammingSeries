/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

digraph PowerManagementSystem {
    rankdir=LR;
    node [shape=box, style=rounded, fontname="Helvetica"];

    // --- External & Hardware ---
    subgraph cluster_hardware {
        label = "Device Hardware Layer";
        style = dashed;
        DeviceHardware [shape=ellipse, label="Physical Sensors\n(Battery, Temperature)"];
    }

    // --- Data Acquisition Layer ---
    subgraph cluster_hooks {
        label = "Data Acquisition Hooks";
        style = dashed;
        ThermalHook [label="useDeviceThermalState"];
        BatteryHook [label="useBatteryStatus"];
    }

    // --- Logic & State Layer ---
    subgraph cluster_logic {
        label = "Adaptive Logic Layer";
        style = dashed;
        Governor [label="AdaptiveInferenceGovernor", fillcolor="#e6f7ff", style="filled"];
        ManualConfig [label="PowerProfileConfigurator", fillcolor="#fff7e6", style="filled"];
    }

    Context [label="InferenceConfigContext", shape=component];

    // --- Consumption Layer ---
    subgraph cluster_consumption {
        label = "Application & AI Engine";
        style = dashed;
        UI [label="User Interface / Chat", shape=invhouse];
        LLM [label="LLM Engine"];
        VSearch [label="Vector Search Engine"];
    }

    // --- Data Flow Edges ---

    // 1. Data from Hardware to Hooks
    DeviceHardware -> ThermalHook [label="Temperature Data"];
    DeviceHardware -> BatteryHook [label="Battery % / Charging Status"];

    // 2. Hooks feed the Governor and Manual Config
    ThermalHook -> Governor [label="Real-time State"];
    BatteryHook -> Governor [label="Real-time State"];
    
    // 3. Manual Config can override or feed into the system
    ManualConfig -> Governor [label="User Override\n(Optional Flow)"];

    // 4. Governor calculates and updates Context
    Governor -> Context [label="Provides InferenceConfig\n(Updates on change)"];

    // 5. Consumers read from Context
    Context -> UI [label="Reads Config"];
    Context -> LLM [label="Reads Config\n(maxTokens, context)"];
    Context -> VSearch [label="Reads Config\n(debounce)"];
}
