/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

import { useState, useEffect } from 'react';
import { z } from 'zod';

// ==========================================
// 1. DATA SCHEMA & TYPE INFERENCE
// ==========================================
// We use Zod to define the structure of our mobile-centric dataset.
// This ensures runtime validation of fetched data and infers TypeScript types automatically.
const MobileFeedbackSchema = z.object({
  id: z.string().uuid(),
  text: z.string().min(10).max(500), // Mobile reviews are typically concise
  sentiment: z.enum(['positive', 'negative', 'neutral']), // Target labels
  context: z.object({
    os: z.enum(['iOS', 'Android']),
    version: z.string(),
  }),
});

type MobileFeedback = z.infer<typeof MobileFeedbackSchema>;

// Mock dataset simulating an API response from a SaaS dashboard
const MOCK_TRAINING_DATA: MobileFeedback[] = [
  {
    id: "123e4567-e89b-12d3-a456-426614174000",
    text: "App crashes on scroll when battery is low. Very frustrating.",
    sentiment: "negative",
    context: { os: "Android", version: "12.0" }
  },
  {
    id: "123e4567-e89b-12d3-a456-426614174001",
    text: "UI is clean and intuitive. Love the dark mode!",
    sentiment: "positive",
    context: { os: "iOS", version: "16.1" }
  },
  {
    id: "123e4567-e89b-12d3-a456-426614174002",
    text: "The app opens fine, but I can't find the settings menu.",
    sentiment: "neutral",
    context: { os: "iOS", version: "15.0" }
  }
];

// ==========================================
// 2. WEBASSEMBLY COMPUTE KERNEL (SIMULATED)
// ==========================================
/**
 * In a production environment, this interface would bind to a WASM module
 * compiled from Rust/C++ containing the WebGPU Compute Shader logic.
 * 
 * The WASM module handles the heavy lifting:
 * - Matrix multiplication for the LoRA A and B weight updates.
 * - Gradient descent calculations.
 * - Merging the low-rank matrices into the base model weights.
 */
interface LoraComputeKernel {
  /**
   * Initializes the WebGPU context and loads the base model weights (quantized).
   * @param baseModelId - Identifier for the pre-trained model (e.g., 'TinyLlama-1.1B')
   */
  init(baseModelId: string): Promise<void>;

  /**
   * Executes the LoRA fine-tuning loop on the device.
   * @param trainingData - The validated array of MobileFeedback objects.
   * @param epochs - Number of training iterations.
   * @param rank - The rank 'r' for the LoRA decomposition (lower = faster, less accurate).
   */
  trainLora(
    trainingData: MobileFeedback[], 
    epochs: number, 
    rank: number
  ): Promise<{ loss: number; adapterWeights: Float32Array }>;

  /**
   * Merges the trained LoRA adapter weights into the base model weights.
   * This results in a single, deployable model file without the adapter overhead.
   */
  mergeAdapters(baseWeights: Float32Array, loraWeights: Float32Array): Promise<Float32Array>;
}

// Mock implementation of the WASM Kernel for demonstration
class MockWasmKernel implements LoraComputeKernel {
  private isInitialized = false;

  async init(baseModelId: string): Promise<void> {
    console.log(`[WASM] Loading base model: ${baseModelId} via WebGPU...`);
    // Simulate async loading of weights into GPU memory
    await new Promise(r => setTimeout(r, 500));
    this.isInitialized = true;
  }

  async trainLora(
    trainingData: MobileFeedback[], 
    epochs: number, 
    rank: number
  ): Promise<{ loss: number; adapterWeights: Float32Array }> {
    if (!this.isInitialized) throw new Error("Kernel not initialized");

    console.log(`[WASM] Starting LoRA training. Rank: ${rank}, Epochs: ${epochs}`);
    
    // Simulate the training loop (Forward/Backward pass)
    let currentLoss = 1.5; // Initial high loss
    for (let i = 0; i < epochs; i++) {
      // In reality, this loop runs inside the WASM/WebGPU thread
      // calculating gradients for the LoRA matrices A and B.
      currentLoss = currentLoss * 0.8; // Simulate loss decay
      console.log(`[WASM] Epoch ${i + 1}/${epochs} - Loss: ${currentLoss.toFixed(4)}`);
      await new Promise(r => setTimeout(r, 100)); // Simulate compute time
    }

    // Return dummy LoRA adapter weights (simulated tensor)
    const adapterSize = 1024 * rank; // Example size
    return {
      loss: currentLoss,
      adapterWeights: new Float32Array(adapterSize).fill(0.5)
    };
  }

  async mergeAdapters(baseWeights: Float32Array, loraWeights: Float32Array): Promise<Float32Array> {
    console.log("[WASM] Merging LoRA adapters into base model...");
    // Simulate matrix addition: W_merged = W_base + (B * A) * scale
    const merged = new Float32Array(baseWeights.length);
    for(let i = 0; i < merged.length; i++) {
        merged[i] = baseWeights[i] + (loraWeights[i % loraWeights.length] * 0.01); 
    }
    await new Promise(r => setTimeout(r, 300));
    return merged;
  }
}

// ==========================================
// 3. REACT COMPONENT: FINE-TUNING DASHBOARD
// ==========================================
/**
 * The main UI component that orchestrates the fine-tuning process.
 * It manages state, validates inputs, and communicates with the WASM kernel.
 */
export default function MobileFineTuningDashboard() {
  const [status, setStatus] = useState<'idle' | 'loading' | 'training' | 'merging' | 'complete'>('idle');
  const [logs, setLogs] = useState<string[]>([]);
  const [kernel] = useState(() => new MockWasmKernel());
  const [trainedModel, setTrainedModel] = useState<Float32Array | null>(null);

  // Helper to append logs to the UI
  const log = (msg: string) => setLogs(prev => [...prev, `[${new Date().toLocaleTimeString()}] ${msg}`]);

  /**
   * Orchestrates the 3-step process:
   * 1. Data Validation (Zod)
   * 2. LoRA Training (WASM)
   * 3. Model Merging (WASM)
   */
  const handleFineTune = async () => {
    setStatus('loading');
    setLogs([]);
    log("Starting on-device fine-tuning pipeline...");

    try {
      // --- Step 1: Data Preparation & Validation ---
      log("Validating mobile feedback dataset...");
      // Zod parses the data. If invalid, it throws a detailed error.
      const validatedData = z.array(MobileFeedbackSchema).parse(MOCK_TRAINING_DATA);
      log(`Dataset valid. Found ${validatedData.length} samples.`);

      // --- Step 2: Initialize Compute Kernel ---
      setStatus('loading');
      await kernel.init('MobileLLM-v1.1B');
      log("Compute kernel ready (WebGPU).");

      // --- Step 3: LoRA Training ---
      setStatus('training');
      log("Executing LoRA training loop...");
      
      // We train specifically on the text/sentiment pairs
      // LoRA allows us to freeze the base model and only update ~1% of parameters
      const { loss, adapterWeights } = await kernel.trainLora(validatedData, 5, 8); // Rank 8
      
      log(`Training complete. Final Loss: ${loss.toFixed(4)}`);
      log(`Generated Adapter Weights: ${adapterWeights.length} parameters.`);

      // --- Step 4: Merging Adapters ---
      setStatus('merging');
      log("Merging LoRA adapter into base model...");
      
      // Create dummy base weights for the simulation
      const baseWeights = new Float32Array(adapterWeights.length).fill(1.0);
      
      const mergedWeights = await kernel.mergeAdapters(baseWeights, adapterWeights);
      setTrainedModel(mergedWeights);
      
      log("Merge complete. Model is ready for deployment.");
      setStatus('complete');

    } catch (error) {
      if (error instanceof z.ZodError) {
        log(`VALIDATION ERROR: ${JSON.stringify(error.errors)}`);
      } else {
        log(`ERROR: ${(error as Error).message}`);
      }
      setStatus('idle');
    }
  };

  return (
    <div style={{ fontFamily: 'monospace', padding: '20px', border: '1px solid #333', maxWidth: '600px' }}>
      <h2>Mobile LLM Fine-Tuning (Local)</h2>
      
      <div style={{ marginBottom: '10px' }}>
        <button 
          onClick={handleFineTune} 
          disabled={status !== 'idle'}
          style={{ padding: '8px 16px', cursor: status === 'idle' ? 'pointer' : 'not-allowed' }}
        >
          {status === 'loading' ? 'Initializing...' : 
           status === 'training' ? 'Training LoRA...' : 
           status === 'merging' ? 'Merging Weights...' : 
           status === 'complete' ? 'Done' : 'Start Fine-Tuning'}
        </button>
      </div>

      <div style={{ 
        height: '300px', 
        overflowY: 'scroll', 
        background: '#111', 
        color: '#0f0', 
        padding: '10px',
        border: '1px solid #444'
      }}>
        {logs.map((line, idx) => <div key={idx}>{line}</div>)}
      </div>

      {status === 'complete' && trainedModel && (
        <div style={{ marginTop: '10px', padding: '10px', background: '#e0f7fa' }}>
          <strong>Deployment Ready:</strong> 
          <br />
          Merged model size: {trainedModel.length} floats.
          <br />
          <small>Ready to export to .wasm or .gguf format for mobile inference.</small>
        </div>
      )}
    </div>
  );
}
