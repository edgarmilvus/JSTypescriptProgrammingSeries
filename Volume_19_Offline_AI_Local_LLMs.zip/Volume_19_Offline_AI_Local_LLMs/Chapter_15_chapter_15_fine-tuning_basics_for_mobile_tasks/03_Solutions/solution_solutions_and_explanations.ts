/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// 1. Define the type for target attention layers
type LoraTargetModule = "q_proj" | "v_proj" | "k_proj" | "o_proj";

// 2. Define the configuration interface
interface LoraConfig {
    r: number; // Rank
    alpha: number; // Scaling factor
    targetModules: LoraTargetModule[];
    dropout: number;
    bias: "none" | "all" | "lora_only";
}

// 3. Configuration generator function with validation
function createLoraConfig(options: Partial<LoraConfig>): LoraConfig {
    // Enforce default values
    const config: LoraConfig = {
        r: options.r ?? 8,
        alpha: options.alpha ?? 16,
        targetModules: options.targetModules ?? ["q_proj", "v_proj"],
        dropout: options.dropout ?? 0.1,
        bias: options.bias ?? "none",
    };

    // Validate constraints (alpha > r for stable training dynamics)
    if (config.alpha <= config.r) {
        throw new Error(`Validation Error: alpha (${config.alpha}) must be greater than r (${config.r}).`);
    }

    // Validate rank range
    if (config.r < 4 || config.r > 64) {
        throw new Error(`Validation Error: r (${config.r}) must be between 4 and 64.`);
    }

    return config;
}

// 4. Demonstration usage
try {
    const llama3Config = createLoraConfig({
        targetModules: ["q_proj", "v_proj"],
        // r and alpha will use defaults (8 and 16)
    });
    console.log("Llama 3 LoRA Config:", llama3Config);
} catch (error) {
    console.error(error);
}
