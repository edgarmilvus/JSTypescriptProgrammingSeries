/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.tsx
// Description: Solutions and Explanations
// ==========================================

import React from 'react';

// 1. Define the state interface
interface TrainingState {
    currentEpoch: number;
    totalEpochs: number;
    currentLoss: number;
    isTraining: boolean;
}

// 2. Define the Props for the component
interface FineTuningProgressProps {
    state: TrainingState;
    onStartTraining: () => void; // Callback to trigger training
}

// 3. Implement the component
const FineTuningProgress: React.FC<FineTuningProgressProps> = ({ state, onStartTraining }) => {
    // Calculate progress percentage for the current epoch
    // Assuming a fixed number of batches per epoch for visualization logic
    const batchesPerEpoch = 10; 
    const currentBatch = (state.currentEpoch * batchesPerEpoch) % batchesPerEpoch; 
    const progressPercent = (state.currentEpoch / state.totalEpochs) * 100;

    return (
        <div style={{ padding: '20px', border: '1px solid #ccc', borderRadius: '8px', maxWidth: '300px' }}>
            <h3>Fine-Tuning Status</h3>
            
            {/* Epoch Display */}
            <p>
                Epoch {state.currentEpoch} / {state.totalEpochs}
            </p>

            {/* Progress Bar */}
            <div style={{ width: '100%', backgroundColor: '#e0e0e0', borderRadius: '4px', height: '20px', marginBottom: '10px' }}>
                <div 
                    style={{ 
                        width: `${Math.min(progressPercent, 100)}%`, 
                        backgroundColor: '#4caf50', 
                        height: '100%', 
                        borderRadius: '4px',
                        transition: 'width 0.3s ease'
                    }} 
                />
            </div>

            {/* Loss Display */}
            <p>
                Loss: <strong>{state.currentLoss.toFixed(4)}</strong>
            </p>

            {/* Conditional Button */}
            {!state.isTraining && (
                <button onClick={onStartTraining} style={{ padding: '8px 16px', cursor: 'pointer' }}>
                    Start Training
                </button>
            )}

            {state.isTraining && (
                <p style={{ color: '#666', fontStyle: 'italic' }}>Training in progress...</p>
            )}
        </div>
    );
};

export default FineTuningProgress;
