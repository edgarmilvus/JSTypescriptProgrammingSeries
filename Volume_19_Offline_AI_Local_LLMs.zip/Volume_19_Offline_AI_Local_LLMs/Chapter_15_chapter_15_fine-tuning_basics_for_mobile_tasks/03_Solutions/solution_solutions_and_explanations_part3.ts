/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

// 1. Define the union types for ToolResponse
type SuccessResponse = {
    status: "success";
    data: unknown;
};

type ErrorResponse = {
    status: "error";
    message: string;
};

type ToolResponse = SuccessResponse | ErrorResponse;

// 2. Implement the Type Guard
// The return type `response is SuccessResponse` tells the TS compiler to narrow the type
function isSuccessResponse(response: ToolResponse): response is SuccessResponse {
    return response.status === "success";
}

// 3. Process the output using the type guard
function processToolOutput(response: ToolResponse): string {
    if (isSuccessResponse(response)) {
        // Inside this block, TypeScript knows 'response' is SuccessResponse
        // We can safely access 'response.data'
        return `Data processed: ${JSON.stringify(response.data)}`;
    } else {
        // Inside this block, TypeScript knows 'response' is ErrorResponse
        // We can safely access 'response.message'
        return `Error encountered: ${response.message}`;
    }
}

// Example Usage
const successResp: ToolResponse = { status: "success", data: { result: 42 } };
const errorResp: ToolResponse = { status: "error", message: "File not found" };

console.log(processToolOutput(successResp)); // Output: Data processed: {"result":42}
console.log(processToolOutput(errorResp));   // Output: Error encountered: File not found
