/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

// 1. Define types for weights and adapters
type ModelWeights = Record<string, Float32Array>;
type LoraAdapter = Record<string, { lora_A: Float32Array; lora_B: Float32Array }>;

// 2. Implement the merge function
function mergeAdapters(
    baseWeights: ModelWeights,
    adapter: LoraAdapter,
    alpha: number,
    r: number
): ModelWeights {
    // Create a deep copy of baseWeights to avoid mutating the original
    const mergedWeights: ModelWeights = { ...baseWeights };
    const scaling = alpha / r;

    // Iterate over the layers present in the adapter
    for (const layerName in adapter) {
        if (!adapter.hasOwnProperty(layerName)) continue;

        const { lora_A, lora_B } = adapter[layerName];
        const baseWeight = baseWeights[layerName];

        if (!baseWeight) {
            console.warn(`Base weight for layer ${layerName} not found. Skipping.`);
            continue;
        }

        // Validate dimensions (simplified check)
        // In a real scenario, we would check shapes: [output_dim, input_dim]
        if (lora_B.length !== baseWeight.length) {
            throw new Error(`Dimension mismatch for layer ${layerName}`);
        }

        // Perform the merge: W_merged = W_base + (lora_B @ lora_A) * scaling
        // Since we are simulating 2D matrix multiplication with 1D arrays:
        // We create a delta array. For simplicity in this simulation, 
        // we calculate a delta value based on the first elements and apply it.
        // In a real implementation, this would be a full matrix multiplication loop.
        
        const newWeights = new Float32Array(baseWeight.length);
        
        for (let i = 0; i < baseWeight.length; i++) {
            // Simulation of Delta W = (lora_B @ lora_A)
            // We assume lora_A and lora_B are pre-computed for this shape.
            // Here we simply add a scaled value from the adapters to simulate the update.
            const delta = lora_B[i] * lora_A[i] * scaling;
            newWeights[i] = baseWeight[i] + delta;
        }

        mergedWeights[layerName] = newWeights;
    }

    return mergedWeights;
}

// Example Usage
const base: ModelWeights = {
    "q_proj": new Float32Array([1.0, 2.0, 3.0, 4.0])
};

const adapter: LoraAdapter = {
    "q_proj": {
        lora_A: new Float32Array([0.1, 0.1, 0.1, 0.1]),
        lora_B: new Float32Array([0.2, 0.2, 0.2, 0.2])
    }
};

const merged = mergeAdapters(base, adapter, 16, 8);
console.log("Merged Weights:", merged["q_proj"]); 
// Expected: [1.0 + (0.2 * 0.1 * 2), ...] -> [1.04, 2.04, 3.04, 4.04]
