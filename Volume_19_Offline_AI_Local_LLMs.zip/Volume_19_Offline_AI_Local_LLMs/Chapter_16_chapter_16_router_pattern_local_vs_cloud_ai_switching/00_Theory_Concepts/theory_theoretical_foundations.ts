/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: theory_theoretical_foundations.ts
// Description: Theoretical Foundations
// ==========================================

// The input to our router decision engine
interface RoutingContext {
    // The user's query or task
    query: string;
    // The type of task (e.g., 'summarization', 'translation', 'code_generation')
    taskType: string;
    // Metadata about the user's device
    deviceCapabilities: {
        hasGPU: boolean;
        availableMemory: number; // in MB
        isCharging: boolean;
    };
    // Network and connectivity state
    networkStatus: {
        isOnline: boolean;
        connectionType: 'wifi' | 'cellular' | 'none';
        latencyMs?: number;
    };
    // Privacy and data sensitivity flags
    dataSensitivity: 'public' | 'internal' | 'confidential' | 'restricted';
    // User preference or app configuration
    userPreference: 'local_first' | 'cloud_first' | 'balanced';
}

// The output of the router decision engine
interface RoutingDecision {
    target: 'local' | 'cloud';
    modelId: string; // e.g., 'llama-3-8b-instruct' or 'gpt-4-turbo'
    reason: string; // For logging and debugging
}
