/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part2.ts
// Description: Theoretical Foundations
// ==========================================

// Example of a rule-based router decision function
function makeRoutingDecision(context: RoutingContext): RoutingDecision {
    // Rule 1: Absolute Privacy Requirement
    if (context.dataSensitivity === 'restricted' || context.dataSensitivity === 'confidential') {
        return {
            target: 'local',
            modelId: 'llama-3-8b-instruct-quantized',
            reason: 'Data sensitivity mandates on-device processing.'
        };
    }

    // Rule 2: Offline Resilience
    if (!context.networkStatus.isOnline) {
        return {
            target: 'local',
            modelId: 'llama-3-8b-instruct-quantized',
            reason: 'No network connectivity.'
        };
    }

    // Rule 3: User Preference Override
    if (context.userPreference === 'local_first') {
        return {
            target: 'local',
            modelId: 'llama-3-8b-instruct-quantized',
            reason: 'User preference for local processing.'
        };
    }

    // Rule 4: Task Complexity Heuristic (Simplified)
    const complexTasks = ['creative_writing', 'deep_analysis', 'multi_step_reasoning'];
    if (complexTasks.includes(context.taskType)) {
        return {
            target: 'cloud',
            modelId: 'gpt-4-turbo',
            reason: 'Task complexity requires advanced cloud model.'
        };
    }

    // Default Rule: Route to local for everything else
    return {
        target: 'local',
        modelId: 'llama-3-8b-instruct-quantized',
        reason: 'Defaulting to local for efficiency and cost.'
    };
}
