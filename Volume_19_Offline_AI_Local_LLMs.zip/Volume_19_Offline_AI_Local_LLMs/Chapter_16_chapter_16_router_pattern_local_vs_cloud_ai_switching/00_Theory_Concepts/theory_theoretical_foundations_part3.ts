/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part3.ts
// Description: Theoretical Foundations
// ==========================================

// A unified interface for AI operations, abstracting away the routing logic
interface AIProvider {
    generateText(prompt: string, context: RoutingContext): Promise<string>;
    // Other methods like embedText, classifyText, etc.
}

// The Router Service implements this interface
class RouterService implements AIProvider {
    private localProvider: LocalAIProvider;
    private cloudProvider: CloudAIProvider;

    constructor(local: LocalAIProvider, cloud: CloudAIProvider) {
        this.localProvider = local;
        this.cloudProvider = cloud;
    }

    async generateText(prompt: string, context: RoutingContext): Promise<string> {
        // 1. Make the routing decision
        const decision = makeRoutingDecision(context);
        
        // 2. Delegate to the appropriate provider
        if (decision.target === 'local') {
            console.log(`[Router] Routing to LOCAL provider: ${decision.reason}`);
            return this.localProvider.generateText(prompt);
        } else {
            console.log(`[Router] Routing to CLOUD provider: ${decision.reason}`);
            return this.cloudProvider.generateText(prompt);
        }
    }
}

// Usage in the application is completely agnostic to the routing
async function handleUserQuery(query: string) {
    const aiService = getAIService(); // Gets the singleton RouterService instance
    const context: RoutingContext = {
        query,
        taskType: 'summarization',
        // ... populate other context fields
    };

    // The app doesn't know or care where the response comes from
    const response = await aiService.generateText(query, context);
    return response;
}
