/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * @fileoverview A "Hello World" implementation of the Router Pattern for Hybrid AI.
 * This simulates a backend service deciding between local (edge) and cloud AI execution.
 * 
 * Run this with: npx ts-node router-pattern.ts
 */

// --- 1. Types and Interfaces ---

/**
 * Represents the context of an AI request.
 * @property prompt - The user's input string.
 * @property maxTokens - Estimated complexity (simulated).
 * @property requiresPrivacy - If true, we must avoid sending data to the cloud.
 */
interface AIRequest {
  prompt: string;
  maxTokens: number;
  requiresPrivacy: boolean;
}

/**
 * Standardized response format regardless of the AI source.
 * @property source - 'local' or 'cloud'.
 * @property content - The generated text.
 * @property latency - Simulated processing time.
 */
interface AIResponse {
  source: 'local' | 'cloud';
  content: string;
  latency: number;
}

// --- 2. Mock Infrastructure (The "Local" and "Cloud" Environments) ---

/**
 * Simulates the Local AI Environment (Edge).
 * In a real app, this would be: WebGPU/WASM, ONNX Runtime, or a vector DB like SQLite.
 * 
 * CRITICAL: "Warm Start" means the model weights are already loaded in memory.
 * We simulate this by checking a global state flag.
 */
class LocalAIEnvironment {
  private isModelWarmedUp: boolean = false;

  /**
   * Simulates the heavy initialization of a local LLM (e.g., loading Llama 3 weights).
   * In reality, this might take 5-10 seconds on first load.
   */
  async warmUpModel(): Promise<void> {
    if (this.isModelWarmedUp) return;
    
    console.log("   [Local AI] Initializing WASM backend and loading weights...");
    // Simulate async initialization delay
    await new Promise(resolve => setTimeout(resolve, 1500)); 
    this.isModelWarmedUp = true;
    console.log("   [Local AI] Model ready. Warm Start active.");
  }

  /**
   * Executes inference locally.
   * Simulates a fast, cached inference run.
   */
  async generate(prompt: string): Promise<AIResponse> {
    if (!this.isModelWarmedUp) {
      throw new Error("Local model not initialized. Call warmUpModel first.");
    }

    // Simulate local inference latency (very low)
    const latency = Math.floor(Math.random() * 50) + 20; // 20-70ms

    await new Promise(resolve => setTimeout(resolve, latency));

    return {
      source: 'local',
      content: `[Local Llama 3] Processed: "${prompt}"`,
      latency: latency
    };
  }
}

/**
 * Simulates the Cloud AI Environment (External API).
 * In a real app, this would be OpenAI, Anthropic, or Azure AI.
 */
class CloudAIEnvironment {
  /**
   * Executes inference via a remote API call.
   * Simulates network latency and higher processing time.
   */
  async generate(prompt: string): Promise<AIResponse> {
    // Simulate network round-trip latency (100ms - 500ms)
    const latency = Math.floor(Math.random() * 400) + 100; 

    console.log(`   [Cloud AI] Sending request to external API...`);
    await new Promise(resolve => setTimeout(resolve, latency));

    return {
      source: 'cloud',
      content: `[Cloud GPT-4] Complex reasoning for: "${prompt}"`,
      latency: latency
    };
  }
}

// --- 3. The Router Logic ---

/**
 * The Router Class.
 * Contains the decision-making logic to switch between Local and Cloud.
 */
class HybridAIRouter {
  private localEnv: LocalAIEnvironment;
  private cloudEnv: CloudAIEnvironment;

  constructor() {
    this.localEnv = new LocalAIEnvironment();
    this.cloudEnv = new CloudAIEnvironment();
  }

  /**
   * Initializes the local environment.
   * This is crucial for the "Edge-First" strategy to ensure low latency on first request.
   */
  async initialize(): Promise<void> {
    // We pre-warm the local model in the background
    await this.localEnv.warmUpModel();
  }

  /**
   * The Core Decision Engine.
   * 
   * Logic:
   * 1. If privacy is required -> Route Local (Edge).
   * 2. If task is simple (low token count) -> Route Local (Edge).
   * 3. Otherwise -> Route Cloud.
   */
  async routeRequest(request: AIRequest): Promise<AIResponse> {
    console.log(`\n[Router] Received request: "${request.prompt}"`);

    // Decision Matrix
    const shouldUseLocal = request.requiresPrivacy || request.maxTokens < 50;

    if (shouldUseLocal) {
      console.log("[Router] Decision: Route to LOCAL (Edge). Reason: " + 
        (request.requiresPrivacy ? "Privacy required" : "Task is simple"));
      
      try {
        return await this.localEnv.generate(request.prompt);
      } catch (error) {
        // Fallback: If local fails (e.g., model not loaded), go to cloud
        console.warn("[Router] Local execution failed, falling back to Cloud.");
        return await this.cloudEnv.generate(request.prompt);
      }
    } else {
      console.log("[Router] Decision: Route to CLOUD. Reason: Complex task");
      return await this.cloudEnv.generate(request.prompt);
    }
  }
}

// --- 4. Execution Simulation ---

/**
 * Main execution block simulating a SaaS Web App handling multiple user requests.
 */
async function main() {
  console.log("=== SaaS App: Hybrid AI Router Demo ===\n");

  const router = new HybridAIRouter();
  
  // 1. Initialize the system (Warm up local model)
  console.log("System Boot: Preparing Edge environment...");
  await router.initialize();
  console.log("System Ready.\n");

  // 2. Simulate User Requests
  const requests: AIRequest[] = [
    { prompt: "Hello", maxTokens: 10, requiresPrivacy: false }, // Simple -> Local
    { prompt: "Summarize this confidential document", maxTokens: 100, requiresPrivacy: true }, // Private -> Local
    { prompt: "Explain quantum physics in detail", maxTokens: 200, requiresPrivacy: false }, // Complex -> Cloud
  ];

  for (const req of requests) {
    const response = await router.routeRequest(req);
    console.log(`   >> Result [${response.source.toUpperCase()}] (Latency: ${response.latency}ms): ${response.content}`);
  }
}

// Run the simulation
main().catch(console.error);
