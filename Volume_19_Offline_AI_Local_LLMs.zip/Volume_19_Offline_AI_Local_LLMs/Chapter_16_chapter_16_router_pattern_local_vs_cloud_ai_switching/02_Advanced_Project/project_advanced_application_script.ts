/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// pages/api/chat-router.ts (Next.js API Route)
// ---------------------------------------------------------
// DEPENDENCIES:
// 1. Local LLM/Vector: In a real app, this would be 'onnxruntime-node' or 'llama.cpp-node'.
//    Here, we simulate it with a local JSON dataset and vector math.
// 2. Cloud LLM: In a real app, this would be 'openai' or 'anthropic-sdk'.
//    Here, we simulate an async fetch call.
// ---------------------------------------------------------

import type { NextApiRequest, NextApiResponse } from 'next';

// --- TYPE DEFINITIONS ---

/**
 * Represents the capability of the routing system.
 * 'LOCAL': Uses on-device resources (Privacy/Offline).
 * 'CLOUD': Uses external API (Power/Connectivity).
 */
type RouteMode = 'LOCAL' | 'CLOUD';

/**
 * Unified response structure returned to the frontend.
 * Abstracts away the underlying source.
 */
interface RouterResponse {
  mode: RouteMode;
  content: string;
  metadata: {
    processingTimeMs: number;
    source: 'local_vector_db' | 'external_llm_api';
    tokensUsed?: number; // Only relevant for cloud
  };
}

/**
 * Internal representation of the Local Vector Database.
 * In a real scenario, this would be embeddings stored in a binary format.
 */
interface LocalKnowledgeBase {
  id: string;
  text: string;
  tags: string[];
}

// --- MOCKED LOCAL DATABASE (SIMULATION) ---
// In a real app, this resides in 'node_modules' or a local file system.
const LOCAL_DB: LocalKnowledgeBase[] = [
  { id: 'doc_1', text: 'User subscription expires on 2023-12-01.', tags: ['billing', 'date'] },
  { id: 'doc_2', text: 'System status is operational.', tags: ['status', 'health'] },
  { id: 'doc_3', text: 'API keys are rotated every 90 days.', tags: ['security', 'api'] },
];

// --- CORE LOGIC: THE ROUTER PATTERN ---

/**
 * Analyzes the user input to determine the optimal execution path.
 * 
 * @param query - The user's raw text input.
 * @returns RouteMode - 'LOCAL' for simple/structured data, 'CLOUD' for complex reasoning.
 */
function determineRoute(query: string): RouteMode {
  const lowerQuery = query.toLowerCase();

  // Heuristic 1: Privacy Keywords
  // If user mentions sensitive data, force local processing.
  if (lowerQuery.includes('my private') || lowerQuery.includes('password') || lowerQuery.includes('secret')) {
    return 'LOCAL';
  }

  // Heuristic 2: Complexity Check
  // If query starts with "How" or "Why", or contains multiple clauses, route to Cloud.
  if (lowerQuery.startsWith('how') || lowerQuery.startsWith('why') || lowerQuery.includes('compare')) {
    return 'CLOUD';
  }

  // Heuristic 3: Keyword Matching for Local DB
  // If query matches known local tags, route to Local.
  const matchedTag = LOCAL_DB.some(doc => doc.tags.some(tag => lowerQuery.includes(tag)));
  if (matchedTag) {
    return 'LOCAL';
  }

  // Default: Route to Cloud for general assistance
  return 'CLOUD';
}

/**
 * Executes the Local LLM / Vector Search path.
 * Simulates semantic search in a local vector store.
 * 
 * @param query - The user input.
 * @returns Promise<RouterResponse>
 */
async function executeLocalPath(query: string): Promise<RouterResponse> {
  const start = performance.now();
  
  // SIMULATION: Vector Search Logic
  // In reality: Embed query -> Compare cosine similarity with DB embeddings -> Retrieve top K.
  // Here: Simple string matching against tags/text.
  const queryLower = query.toLowerCase();
  const results = LOCAL_DB.filter(doc => 
    doc.tags.some(tag => queryLower.includes(tag)) || 
    queryLower.includes(doc.text.toLowerCase())
  );

  // Simulate processing delay (local inference takes time)
  await new Promise(resolve => setTimeout(resolve, 150)); 

  const content = results.length > 0 
    ? `Based on local records: ${results.map(r => r.text).join(' ')}`
    : "I couldn't find specific local data matching your query, but I'm ready to assist offline.";

  return {
    mode: 'LOCAL',
    content,
    metadata: {
      processingTimeMs: Math.round(performance.now() - start),
      source: 'local_vector_db'
    }
  };
}

/**
 * Executes the Cloud LLM path.
 * Simulates an API call to an external provider (e.g., OpenAI).
 * 
 * @param query - The user input.
 * @returns Promise<RouterResponse>
 */
async function executeCloudPath(query: string): Promise<RouterResponse> {
  const start = performance.now();

  // SIMULATION: Cloud API Call
  // In reality: await openai.chat.completions.create({ model: 'gpt-4', ... })
  // Here: We mock a network request and a generated response.
  try {
    // Simulate network latency
    await new Promise(resolve => setTimeout(resolve, 600));

    // Mock response generation based on query
    let generatedText = "";
    if (query.includes("compare")) {
      generatedText = "Comparing the two concepts involves analyzing their structural differences...";
    } else {
      generatedText = "Here is a comprehensive analysis based on external knowledge: ...";
    }

    return {
      mode: 'CLOUD',
      content: generatedText,
      metadata: {
        processingTimeMs: Math.round(performance.now() - start),
        source: 'external_llm_api',
        tokensUsed: 120 // Mock token count
      }
    };
  } catch (error) {
    // Cloud failure fallback: Try local if possible
    console.error("Cloud API failed, falling back to local...");
    return executeLocalPath(query);
  }
}

// --- NEXT.JS API HANDLER ---

/**
 * Main API Entry Point.
 * Handles the request and routes to the appropriate execution engine.
 */
export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse<RouterResponse | { error: string }>
) {
  // 1. Validate Request Method
  if (req.method !== 'POST') {
    res.setHeader('Allow', ['POST']);
    return res.status(405).end(`Method ${req.method} Not Allowed`);
  }

  // 2. Extract Input
  const { query } = req.body;
  if (!query || typeof query !== 'string') {
    return res.status(400).json({ error: 'Invalid query format.' });
  }

  try {
    // 3. The Router Decision Engine
    const routeMode = determineRoute(query);

    // 4. Execute Based on Route
    let response: RouterResponse;
    
    if (routeMode === 'LOCAL') {
      console.log(`[Router] Routing query to LOCAL engine.`);
      response = await executeLocalPath(query);
    } else {
      console.log(`[Router] Routing query to CLOUD engine.`);
      response = await executeCloudPath(query);
    }

    // 5. Return Unified Response
    return res.status(200).json(response);

  } catch (error) {
    console.error("Routing error:", error);
    return res.status(500).json({ error: 'Internal routing error.' });
  }
}
