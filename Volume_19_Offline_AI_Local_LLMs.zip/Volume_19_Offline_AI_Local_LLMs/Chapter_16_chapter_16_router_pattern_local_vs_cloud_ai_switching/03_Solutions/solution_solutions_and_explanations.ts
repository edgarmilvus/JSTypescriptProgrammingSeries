/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

/**
 * Simulates checking for an active internet connection.
 * Resolves true 80% of the time, false 20% of the time.
 */
async function checkNetworkStatus(): Promise<boolean> {
    // Simulate network check latency (non-blocking)
    await new Promise(resolve => setTimeout(resolve, 50)); 
    
    // Random number between 0 and 1
    const random = Math.random();
    // 80% chance of true (connected), 20% chance of false (offline)
    return random > 0.2;
}

/**
 * Analyzes the prompt to determine complexity.
 * Returns 'low' if < 20 words and no complexity keywords.
 * Otherwise returns 'high'.
 */
function estimateComplexity(prompt: string): 'low' | 'high' {
    const words = prompt.trim().split(/\s+/);
    const wordCount = words.length;
    
    // Keywords that imply high complexity
    const complexityKeywords = ['analyze', 'summarize', 'write code', 'generate'];
    
    const hasKeyword = complexityKeywords.some(keyword => 
        prompt.toLowerCase().includes(keyword)
    );

    if (wordCount < 20 && !hasKeyword) {
        return 'low';
    }
    return 'high';
}

/**
 * Main routing function.
 * Determines the source (local/cloud) based on hierarchy of rules.
 */
async function routeRequest(
    prompt: string, 
    isPrivateContext: boolean
): Promise<{ source: 'local' | 'cloud'; reason: string }> {
    
    // 1. Privacy Check (Highest Priority)
    if (isPrivateContext) {
        return { source: 'local', reason: "Privacy requirement." };
    }

    // 2. Network Status Check
    const isOnline = await checkNetworkStatus();
    if (!isOnline) {
        return { source: 'local', reason: "Offline." };
    }

    // 3. Complexity Analysis
    const complexity = estimateComplexity(prompt);
    if (complexity === 'high') {
        return { source: 'cloud', reason: "High complexity task." };
    }

    // 4. Default Fallback
    return { source: 'local', reason: "Default local routing." };
}

// --- Example Usage (for demonstration) ---
async function runDemo() {
    console.log("--- Testing Router Logic ---");
    
    // Case 1: Private context (bypasses everything)
    const result1 = await routeRequest("Simple hello", true);
    console.log("Test 1 (Private):", result1); 

    // Case 2: High complexity (likely cloud)
    const result2 = await routeRequest("Analyze this large dataset and summarize the trends", false);
    console.log("Test 2 (Complex):", result2);

    // Case 3: Low complexity (likely local, assuming online)
    const result3 = await routeRequest("Hello world", false);
    console.log("Test 3 (Simple):", result3);
}

// runDemo(); // Uncomment to run
