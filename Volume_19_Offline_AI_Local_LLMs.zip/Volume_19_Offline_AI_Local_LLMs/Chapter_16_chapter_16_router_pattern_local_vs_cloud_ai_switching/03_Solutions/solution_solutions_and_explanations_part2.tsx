/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState, useTransition } from 'react';

// Mocking the routeRequest function from Exercise 1 for this component context
async function mockRouteRequest(prompt: string, isPrivate: boolean) {
    // Simulate delay for decision logic
    await new Promise(r => setTimeout(r, 100));
    if (isPrivate) return { source: 'local', reason: 'Privacy requirement.' };
    if (prompt.length > 50) return { source: 'cloud', reason: 'High complexity task.' };
    return { source: 'local', reason: 'Default local routing.' };
}

// Mock AI Response Generator
async function getAIResponse(prompt: string, source: 'local' | 'cloud') {
    const delay = source === 'local' ? 2000 : 800; // Local is slower in simulation
    await new Promise(r => setTimeout(r, delay));
    return `Response from ${source}: I processed "${prompt}"`;
}

// Types for props
interface SmartInputProps {
    onRouteDecision: (decision: { source: 'local' | 'cloud'; reason: string }) => void;
}

export const SmartInput: React.FC<SmartInputProps> = ({ onRouteDecision }) => {
    const [input, setInput] = useState('');
    const [decision, setDecision] = useState<{ source: string; reason: string } | null>(null);
    const [response, setResponse] = useState<string | null>(null);
    const [isPending, startTransition] = useTransition();

    // Function to check route (Optimistic UI update)
    const handleCheckRoute = async () => {
        const decision = await mockRouteRequest(input, false);
        setDecision(decision);
        onRouteDecision(decision);
    };

    // Function to submit (Handling Loading States)
    const handleSubmit = async () => {
        // 1. Get the decision first
        const currentDecision = await mockRouteRequest(input, false);
        setDecision(currentDecision);
        onRouteDecision(currentDecision);

        // 2. Trigger the AI response with Suspense/Transition
        startTransition(async () => {
            const result = await getAIResponse(input, currentDecision.source as 'local' | 'cloud');
            setResponse(result);
        });
    };

    return (
        <div style={{ padding: '20px', border: '1px solid #ccc', borderRadius: '8px', maxWidth: '400px' }}>
            <h3>Smart Input</h3>
            
            {/* Input Field */}
            <input
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder="Type your prompt..."
                style={{ width: '100%', padding: '8px', marginBottom: '10px' }}
            />

            {/* Action Buttons */}
            <div style={{ display: 'flex', gap: '10px', marginBottom: '15px' }}>
                <button onClick={handleCheckRoute} disabled={!input}>
                    Check Route
                </button>
                <button onClick={handleSubmit} disabled={!input}>
                    Submit
                </button>
            </div>

            {/* Route Decision Badge */}
            {decision && (
                <div style={{ 
                    padding: '10px', 
                    borderRadius: '4px', 
                    backgroundColor: decision.source === 'local' ? '#e6fffa' : '#ebf8ff',
                    border: `1px solid ${decision.source === 'local' ? '#38b2ac' : '#4299e1'}`,
                    color: decision.source === 'local' ? '#2c7a7b' : '#2b6cb0',
                    marginBottom: '15px'
                }}>
                    <strong>Route: {decision.source.toUpperCase()}</strong>
                    <div style={{ fontSize: '0.85em' }}>{decision.reason}</div>
                </div>
            )}

            {/* Response Area with Suspense-like Fallback */}
            <div style={{ minHeight: '50px', padding: '10px', background: '#f7fafc', borderRadius: '4px' }}>
                {isPending ? (
                    <div style={{ color: '#718096' }}>
                        <span style={{ animation: 'pulse 1.5s infinite' }}>Processing...</span>
                    </div>
                ) : (
                    response && <div>{response}</div>
                )}
            </div>
        </div>
    );
};
