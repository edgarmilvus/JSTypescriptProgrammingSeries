/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

import * as fs from 'fs';
import * as path from 'path';

// Define heuristics for package analysis
const HEAVY_PACKAGES: Record<string, string> = {
    'openai': 'onnxruntime-node or transformers.js',
    'aws-sdk': 'expo-file-system or react-native-fs',
    'axios': 'native fetch API',
    'moment': 'date-fns or dayjs'
};

const LIGHT_PACKAGES = [
    'onnxruntime-node',
    'transformers.js',
    'expo-file-system',
    'react-native-fs',
    'dayjs',
    'date-fns'
];

interface PackageJson {
    dependencies?: Record<string, string>;
    devDependencies?: Record<string, string>;
}

function analyzePackageJson(filePath: string) {
    if (!fs.existsSync(filePath)) {
        console.error("Error: File not found.");
        return;
    }

    const fileContent = fs.readFileSync(filePath, 'utf-8');
    const pkg: PackageJson = JSON.parse(fileContent);

    const allDeps = { ...pkg.dependencies, ...pkg.devDependencies };
    const depNames = Object.keys(allDeps);

    let heavyCount = 0;
    let lightCount = 0;

    console.log("--- Local-First Dependency Analysis ---\n");

    depNames.forEach(dep => {
        if (HEAVY_PACKAGES[dep]) {
            heavyCount++;
            console.log(`⚠️  [${dep}] detected. This is likely for cloud usage.`);
            console.log(`   Suggestion: Consider ${HEAVY_PACKAGES[dep]} for local processing.\n`);
        } else if (LIGHT_PACKAGES.includes(dep)) {
            lightCount++;
            console.log(`✅ [${dep}] detected. Good for local execution.\n`);
        }
    });

    // Calculate Score: 0 if only heavy, 100 if only light.
    // Formula: (Light / Total) * 100
    const totalAnalyzed = heavyCount + lightCount;
    let score = 0;
    
    if (totalAnalyzed > 0) {
        score = Math.round((lightCount / totalAnalyzed) * 100);
    }

    console.log("--- Summary ---");
    console.log(`Total dependencies analyzed: ${totalAnalyzed}`);
    console.log(`Light/Local packages: ${lightCount}`);
    console.log(`Heavy/Cloud packages: ${heavyCount}`);
    console.log(`\nLocal-First Score: ${score}/100`);
    
    if (score < 50) {
        console.log("Recommendation: Refactor dependencies to favor local execution.");
    } else {
        console.log("Recommendation: Configuration looks good for local-first architecture.");
    }
}

// Usage example (assuming a package.json exists in the current directory)
// analyzePackageJson('./package.json');
