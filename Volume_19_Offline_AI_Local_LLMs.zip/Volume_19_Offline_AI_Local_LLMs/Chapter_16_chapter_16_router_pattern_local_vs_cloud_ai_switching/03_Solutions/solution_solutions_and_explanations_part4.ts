/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

import * as readline from 'readline';

// Setup standard input/output for CLI interaction
const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

/**
 * Simulates local processing time.
 * Formula: 1000ms base + 50ms per word.
 */
function simulateLocalInference(wordCount: number): Promise<number> {
    const duration = 1000 + (wordCount * 50);
    return new Promise(resolve => setTimeout(() => resolve(duration), duration));
}

/**
 * Simulates cloud processing time.
 * Formula: 200ms base + 10ms per word + random network delay (50-500ms).
 */
function simulateCloudInference(wordCount: number): Promise<number> {
    const networkDelay = Math.floor(Math.random() * (500 - 50 + 1)) + 50;
    const duration = 200 + (wordCount * 10) + networkDelay;
    return new Promise(resolve => setTimeout(() => resolve(duration), duration));
}

async function runLatencySimulator() {
    rl.question('Enter a prompt to simulate processing: ', async (prompt) => {
        const wordCount = prompt.trim().split(/\s+/).length;
        
        console.log(`\nPrompt Analysis: ${wordCount} words.`);
        console.log("----------------------------------------");

        // 1. Determine Route (Using logic from Exercise 1)
        // Simplified logic: > 20 words or specific keywords = Cloud, else Local
        const isComplex = wordCount > 20 || prompt.toLowerCase().includes('analyze');
        const route = isComplex ? 'Cloud' : 'Local';
        
        console.log(`Router Decision: Route to [${route}]`);

        // 2. Execution & Measurement
        console.log("Executing simulation...");
        
        const start = process.hrtime.bigint(); // High-res start
        
        if (route === 'Local') {
            await simulateLocalInference(wordCount);
        } else {
            await simulateCloudInference(wordCount);
        }
        
        const end = process.hrtime.bigint(); // High-res end
        
        // Convert nanoseconds to milliseconds
        const actualTimeMs = Number(end - start) / 1e6;

        // 3. Calculate Theoretical Best/Worst for comparison
        const theoreticalLocal = 1000 + (wordCount * 50);
        const theoreticalCloudBase = 200 + (wordCount * 10); 
        // Note: We can't predict the random network delay exactly for "Theoretical Best", 
        // so we use the base cloud time (no network delay) as the ideal best case.
        
        console.log("----------------------------------------");
        console.log("RESULTS:");
        console.log(`Actual Route Time: ${actualTimeMs.toFixed(2)} ms`);
        console.log("----------------------------------------");
        console.log("Comparison (Theoretical):");
        console.log(`Local Inference (Worst): ${theoreticalLocal} ms`);
        console.log(`Cloud Inference (Base):  ${theoreticalCloudBase} ms + random network latency`);
        console.log("----------------------------------------");
        
        rl.close();
    });
}

// runLatencySimulator();
