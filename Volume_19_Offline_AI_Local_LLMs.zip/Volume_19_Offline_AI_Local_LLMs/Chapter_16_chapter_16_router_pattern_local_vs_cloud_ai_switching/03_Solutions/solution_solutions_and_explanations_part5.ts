/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

// --- Mock Functions for Simulation ---
const delay = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

async function checkNetwork(): Promise<boolean> {
    await delay(100); // Simulates 100ms network ping
    console.log("Network checked.");
    return true;
}

async function queryLocalDB(prompt: string): Promise<boolean> {
    await delay(200); // Simulates 200ms local vector search
    console.log("Local DB queried.");
    return prompt.length > 0;
}

async function checkCloudCapacity(): Promise<boolean> {
    await delay(150); // Simulates 150ms API health check
    console.log("Cloud capacity checked.");
    return true;
}

// --- BUGGY IMPLEMENTATION (Sequential) ---
async function buggyRouter(prompt: string) {
    console.log("Starting Buggy Router (Sequential)...");
    const start = Date.now();

    // These run one after another: 100ms + 200ms + 150ms = 450ms total
    const network = await checkNetwork();
    const localCheck = await queryLocalDB(prompt);
    const cloudCheck = await checkCloudCapacity();

    const duration = Date.now() - start;
    console.log(`Buggy Router finished in ${duration}ms\n`);
    
    // Logic using results...
    return network && localCheck && cloudCheck;
}

// --- FIXED IMPLEMENTATION (Concurrent) ---
async function fixedRouter(prompt: string) {
    console.log("Starting Fixed Router (Concurrent)...");
    const start = Date.now();

    // 1. Initiate all promises immediately
    const networkPromise = checkNetwork();
    const localPromise = queryLocalDB(prompt);
    const cloudPromise = checkCloudCapacity();

    // 2. Wait for all of them to settle
    // The Event Loop handles I/O for these in parallel
    const [network, localCheck, cloudCheck] = await Promise.all([
        networkPromise,
        localPromise,
        cloudPromise
    ]);

    const duration = Date.now() - start;
    console.log(`Fixed Router finished in ${duration}ms`);
    
    // Logic using results...
    return network && localCheck && cloudCheck;
}

// --- EXPLANATION COMMENT ---
/*
 * How Promise.all improves Event Loop performance:
 * 
 * 1. Sequential (Buggy): 
 *    - Execution: `await checkNetwork()` starts. Node.js sends I/O request and pauses execution of this function.
 *    - Wait: The function waits for the 100ms response. The Event Loop handles other tasks (if any).
 *    - Next: Once resolved, `await queryLocalDB()` starts. Another 200ms wait.
 *    - Total I/O Wait: Sum of all individual latencies (450ms). The CPU is mostly idle, but the script cannot proceed.
 * 
 * 2. Concurrent (Fixed):
 *    - Execution: `checkNetwork()`, `queryLocalDB()`, and `checkCloudCapacity()` are called almost simultaneously.
 *    - Parallel I/O: Node.js initiates all three I/O operations. They are handled by the underlying system (libuv) in parallel.
 *    - Wait: The `Promise.all` waits only for the *slowest* task to complete (200ms in this case).
 *    - Total I/O Wait: Max(latencies) = 200ms.
 * 
 * Result: The fixed router reduces the blocking time by over 50%, allowing the application to remain responsive and process tasks faster.
 */

// --- Test Runner ---
async function runDebugTest() {
    await buggyRouter("test prompt");
    await fixedRouter("test prompt");
}

// runDebugTest();
