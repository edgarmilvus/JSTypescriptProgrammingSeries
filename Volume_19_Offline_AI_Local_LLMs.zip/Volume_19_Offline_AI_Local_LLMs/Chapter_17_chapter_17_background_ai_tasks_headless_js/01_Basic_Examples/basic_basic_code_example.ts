/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * @fileoverview A 'Hello World' example of Background AI Tasks using Web Workers.
 * This simulates a SaaS dashboard that offloads LLM inference to a background thread.
 */

// ==========================================
// 1. WORKER AGENT (Background Thread)
// ==========================================

// In a real app, this code lives in a separate file (e.g., 'ai-worker.ts').
// For this self-contained example, we construct the worker dynamically.

const workerCode = `
/**
 * The Worker Agent handles computationally expensive tasks.
 * It runs in a separate context, isolated from the DOM.
 */
self.onmessage = async (event) => {
  const { type, payload } = event.data;

  if (type === 'START_INFERENCE') {
    console.log('[Worker] Received inference task. Starting heavy computation...');
    
    // SIMULATION: In a real scenario, this is where WebGPU/WebAssembly 
    // would execute Llama 3 matrix multiplications.
    const result = await simulateLlamaInference(payload.prompt);
    
    // Send the result back to the Supervisor (Main Thread)
    self.postMessage({
      type: 'INFERENCE_COMPLETE',
      data: {
        summary: result,
        timestamp: Date.now()
      }
    });
  }
};

/**
 * Mocks the heavy computational load of a local LLM.
 * Uses a Promise to simulate async processing delay.
 */
async function simulateLlamaInference(prompt: string): Promise<string> {
  // Simulate 2 seconds of "thinking" (GPU compute time)
  await new Promise(resolve => setTimeout(resolve, 2000));
  
  // Return a structured response based on the prompt
  return \`Summary of: "\${prompt}"\n- Detected intent: Information Retrieval\n- Local Model: Llama-3-8B (WASM)\`;
}
`;

// Create a Blob from the string code to initialize the Worker without external files
const blob = new Blob([workerCode], { type: 'application/javascript' });
const workerUrl = URL.createObjectURL(blob);

// ==========================================
// 2. SUPERVISOR NODE (Main Thread / UI)
// ==========================================

class AISupervisor {
  private worker: Worker;

  constructor() {
    // Initialize the worker thread
    this.worker = new Worker(workerUrl);
    this.setupListeners();
  }

  /**
   * Listens for messages coming back from the background thread.
   */
  private setupListeners(): void {
    this.worker.onmessage = (event) => {
      const { type, data } = event.data;

      if (type === 'INFERENCE_COMPLETE') {
        this.handleInferenceResult(data);
      }
    };
  }

  /**
   * The entry point for the SaaS application UI.
   * Delegates the heavy lifting to the worker.
   */
  public requestBackgroundAnalysis(prompt: string): void {
    console.log('[Supervisor] UI is responsive. Delegating task to Worker...');
    
    // Update UI immediately (optimistic UI)
    this.updateUI('Processing in background...', true);

    // DELEGATION STRATEGY: Send structured data to the worker
    this.worker.postMessage({
      type: 'START_INFERENCE',
      payload: { prompt }
    });
  }

  /**
   * Handles the final result from the background thread.
   */
  private handleInferenceResult(data: any): void {
    console.log('[Supervisor] Result received from Worker:', data);
    this.updateUI(data.summary, false);
  }

  /**
   * Helper to update the DOM (Mocked for this example).
   */
  private updateUI(message: string, isLoading: boolean): void {
    const statusEl = document.getElementById('status');
    const contentEl = document.getElementById('content');

    if (statusEl) {
      statusEl.innerText = isLoading ? '⏳ ' + message : '✅ Ready';
      statusEl.style.color = isLoading ? '#d97706' : '#059669';
    }
    if (contentEl && !isLoading) {
      contentEl.innerText = message;
    }
  }
}

// ==========================================
// 3. USAGE EXAMPLE
// ==========================================

// Instantiate the supervisor
const app = new AISupervisor();

// Simulate a user clicking a "Summarize" button in a SaaS dashboard
// setTimeout is used to ensure the DOM is ready in a real browser environment.
setTimeout(() => {
  app.requestBackgroundAnalysis("Project Alpha: Q3 financial report and vector embeddings");
}, 1000);
