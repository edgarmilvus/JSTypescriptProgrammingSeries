/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

/**
 * BackgroundAISupervisor.ts
 * 
 * A Headless JS Supervisor designed to run in a Next.js API route or a dedicated Web Worker context.
 * It manages the lifecycle of a local Llama 3 instance via Transformers.js, handling memory
 * constraints and task delegation to prevent UI freezing.
 */

// ------------------------------------------------------------------
// 1. Type Definitions & Interfaces
// ------------------------------------------------------------------

/**
 * Defines the types of tasks the Supervisor can delegate to the Worker.
 */
export enum TaskType {
  INFERENCE = 'INFERENCE',    // LLM text generation
  EMBEDDING = 'EMBEDDING',    // Vectorization for search
  MEMORY_CLEANUP = 'CLEANUP'  // Explicit garbage collection trigger
}

/**
 * Standardized message structure for communication between Supervisor and Worker.
 */
export interface SupervisorMessage {
  type: TaskType;
  payload: any;
  id: string; // Unique correlation ID
}

/**
 * Response structure from the Worker.
 */
export interface WorkerResponse {
  id: string;
  status: 'success' | 'error';
  data?: any;
  error?: string;
  memoryUsage?: number; // Report memory pressure
}

// ------------------------------------------------------------------
// 2. The Supervisor Class (Headless Logic)
// ------------------------------------------------------------------

export class BackgroundAISupervisor {
  private worker: Worker | null = null;
  private taskQueue: SupervisorMessage[] = [];
  private isProcessing: boolean = false;
  private modelLoaded: boolean = false;

  // Configuration for memory management
  private readonly MAX_MEMORY_MB = 500; // Threshold to trigger aggressive cleanup
  private readonly BATCH_SIZE = 2;      // Process 2 tasks before checking memory

  constructor() {
    this.initWorker();
  }

  /**
   * Initializes the Web Worker.
   * In a Next.js environment, this typically points to a generated worker file.
   * For this example, we assume a standard worker path.
   */
  private initWorker(): void {
    // Note: In a real Next.js app, you'd use a loader or point to a specific .worker.ts file.
    // Here we simulate the worker creation.
    try {
      // @ts-ignore: Worker construction for demo purposes
      this.worker = new Worker(new URL('./BackgroundWorker.worker.ts', import.meta.url));
      
      this.worker.onmessage = (event: MessageEvent<WorkerResponse>) => {
        this.handleWorkerResponse(event.data);
      };

      this.worker.onerror = (error) => {
        console.error('[Supervisor] Worker Error:', error);
        this.isProcessing = false;
      };

      console.log('[Supervisor] Worker initialized successfully.');
    } catch (error) {
      console.error('[Supervisor] Failed to initialize worker:', error);
    }
  }

  /**
   * Public API to queue a task for background execution.
   * This decouples the UI from the heavy computation.
   * 
   * @param type - The type of AI task
   * @param payload - Data required for the task (e.g., prompt text)
   * @returns Promise<string> - A promise resolving to the task ID
   */
  public enqueueTask(type: TaskType, payload: any): Promise<string> {
    const taskId = crypto.randomUUID();
    const task: SupervisorMessage = {
      type,
      payload,
      id: taskId
    };

    this.taskQueue.push(task);
    console.log(`[Supervisor] Task ${taskId} enqueued. Queue length: ${this.taskQueue.length}`);
    
    this.processQueue();
    return Promise.resolve(taskId);
  }

  /**
   * The Core Logic Loop: Delegates tasks to the worker sequentially.
   * Implements a "Backpressure" mechanism to prevent memory overflows.
   */
  private async processQueue(): Promise<void> {
    if (this.isProcessing || this.taskQueue.length === 0) return;

    this.isProcessing = true;
    const task = this.taskQueue.shift()!;

    try {
      // 1. Check Memory Pressure (Simulated)
      // In a real scenario, we might use performance.memory or a heuristic.
      if (this.shouldTriggerMemoryCleanup()) {
        await this.triggerMemoryCleanup();
      }

      // 2. Delegate to Worker
      if (this.worker) {
        console.log(`[Supervisor] Dispatching task ${task.id} to Worker...`);
        this.worker.postMessage(task);
      } else {
        throw new Error('Worker not initialized');
      }

    } catch (error) {
      console.error(`[Supervisor] Error processing task ${task.id}:`, error);
      this.isProcessing = false;
    }
  }

  /**
   * Handles the response from the worker thread.
   * 
   * @param response - The data returned by the worker
   */
  private handleWorkerResponse(response: WorkerResponse): void {
    console.log(`[Supervisor] Received response for task ${response.id}`);
    
    if (response.status === 'error') {
      console.error(`[Supervisor] Task failed:`, response.error);
    } else {
      // Logic to update UI or store result (e.g., via Zustand/Redux context)
      console.log(`[Supervisor] Result:`, response.data);
    }

    // Update memory usage tracking
    if (response.memoryUsage) {
      this.checkMemoryConstraints(response.memoryUsage);
    }

    // Unlock and process next task
    this.isProcessing = false;
    this.processQueue();
  }

  /**
   * Heuristic to decide if we need to free up memory before the next inference.
   */
  private shouldTriggerMemoryCleanup(): boolean {
    // In a browser, we can access performance.memory (Chrome only)
    // @ts-ignore
    if (performance && performance.memory) {
      // @ts-ignore
      const usedMB = performance.memory.usedJSHeapSize / 1024 / 1024;
      return usedMB > this.MAX_MEMORY_MB;
    }
    return false;
  }

  /**
   * Sends a specific command to the worker to dispose of models or clear caches.
   */
  private async triggerMemoryCleanup(): Promise<void> {
    console.warn('[Supervisor] High memory pressure detected. Triggering cleanup...');
    if (this.worker) {
      const cleanupTask: SupervisorMessage = {
        type: TaskType.MEMORY_CLEANUP,
        payload: {},
        id: crypto.randomUUID()
      };
      this.worker.postMessage(cleanupTask);
      
      // Wait for cleanup confirmation (blocking strictly for safety in this demo)
      await new Promise(resolve => setTimeout(resolve, 100));
    }
  }

  private checkMemoryConstraints(memoryUsage: number): void {
    if (memoryUsage > this.MAX_MEMORY_MB) {
      console.warn(`[Supervisor] Worker reporting high memory: ${memoryUsage}MB. Throttling queue.`);
      // Implement throttling logic here if needed
    }
  }

  /**
   * Cleanup method to terminate the worker when the app closes or context is lost.
   */
  public terminate(): void {
    if (this.worker) {
      this.worker.terminate();
      this.worker = null;
      console.log('[Supervisor] Worker terminated.');
    }
  }
}

// ------------------------------------------------------------------
// 3. Mock Worker Implementation (For Context)
// ------------------------------------------------------------------
// Note: In a real project, this would be in a separate file: BackgroundWorker.worker.ts
// We include it here to demonstrate the complete logic flow in one block.

export const workerCode = `
import { pipeline, env } from '@xenova/transformers';

// Configure environment for local execution
env.allowLocalModels = true;
env.useBrowserCache = false; // Prevent UI thread blocking

let modelCache = null;

self.onmessage = async (event) => {
  const { type, payload, id } = event.data;

  try {
    switch (type) {
      case 'INFERENCE':
        // Lazy load the model only when needed
        if (!modelCache) {
          console.log('[Worker] Loading Llama 3 model...');
          modelCache = await pipeline('text-generation', 'Xenova/llama-3-8b-instruct-4bit');
        }
        
        const generator = await modelCache(payload.prompt, {
          max_new_tokens: 50,
          temperature: 0.9
        });
        
        // Report memory usage (approximate)
        const memUsage = performance.memory ? performance.memory.usedJSHeapSize / 1024 / 1024 : 0;

        self.postMessage({
          id,
          status: 'success',
          data: generator[0].generated_text,
          memoryUsage: memUsage
        });
        break;

      case 'EMBEDDING':
        // Run vectorization
        const embedder = await pipeline('feature-extraction', 'Xenova/all-MiniLM-L6-v2');
        const vector = await embedder(payload.text);
        self.postMessage({ id, status: 'success', data: vector.tolist() });
        break;

      case 'CLEANUP':
        // Explicitly dispose of models to free WASM memory
        if (modelCache) {
          modelCache.dispose();
          modelCache = null;
        }
        self.postMessage({ id, status: 'success', data: 'Memory cleaned' });
        break;
    }
  } catch (error) {
    self.postMessage({ id, status: 'error', error: error.message });
  }
};
`;

/**
 * Helper to instantiate the worker in a Next.js environment.
 * This is a utility function to blob the worker code if needed for dynamic loading.
 */
export function createWorkerBlob() {
  const blob = new Blob([workerCode], { type: 'application/javascript' });
  return new Worker(URL.createObjectURL(blob));
}
