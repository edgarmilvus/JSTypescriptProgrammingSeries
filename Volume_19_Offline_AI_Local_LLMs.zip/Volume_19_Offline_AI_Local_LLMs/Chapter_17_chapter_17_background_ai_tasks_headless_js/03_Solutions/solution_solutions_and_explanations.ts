/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// vectorWorker.ts
// This file defines the logic that runs inside the Web Worker.
// It listens for messages, processes data, and handles cancellation.

self.onmessage = (e: MessageEvent) => {
  const { type, payload } = e.data;

  if (type === 'START') {
    const vector = payload.vector;
    let sumOfSquares = 0;

    // Simulate heavy calculation loop
    // We check for a cancellation flag inside the loop
    for (let i = 0; i < vector.length; i++) {
      // Check if cancellation was requested
      if (self['shouldCancel']) {
        self.postMessage({ type: 'CANCELLED' });
        self['shouldCancel'] = false; // Reset flag
        return;
      }
      
      sumOfSquares += vector[i] * vector[i];
      // Artificial delay to make the processing visible
      if (i % 1000 === 0) {
        const start = performance.now();
        while (performance.now() - start < 0.5) {} // Block thread for 0.5ms
      }
    }

    const norm = Math.sqrt(sumOfSquares);
    const normalizedVector = vector.map((val: number) => val / norm);

    self.postMessage({ 
      type: 'DONE', 
      result: normalizedVector.slice(0, 5), // Send only first 5 for UI
      norm: norm 
    });
  } 
  else if (type === 'CANCEL') {
    // Signal the loop to stop in the next iteration
    self['shouldCancel'] = true;
  }
};

// Worker initialization message
self.postMessage({ type: 'WORKER_READY' });
