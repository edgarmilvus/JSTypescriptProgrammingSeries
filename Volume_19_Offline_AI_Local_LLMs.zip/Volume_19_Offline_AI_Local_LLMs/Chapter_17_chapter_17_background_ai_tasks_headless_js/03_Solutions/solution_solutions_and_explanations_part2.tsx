/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.tsx
// Description: Solutions and Explanations
// ==========================================

// BackgroundTask.tsx
import React, { useEffect, useRef, useState } from 'react';

// Define a type for the worker to ensure type safety
type WorkerType = Worker | null;

const BackgroundTask: React.FC = () => {
  const [vectorResult, setVectorResult] = useState<number[] | null>(null);
  const [processingTime, setProcessingTime] = useState<number>(0);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [counter, setCounter] = useState<number>(0);
  const workerRef = useRef<WorkerType>(null);
  const startTimeRef = useRef<number>(0);

  // 1. Initialize Worker
  useEffect(() => {
    // Note: In a real React Native/Webpack environment, you'd use a loader or specific path.
    // For this simulation, we create a Blob URL.
    const workerCode = `
      self.onmessage = (e) => {
        const { type, payload } = e.data;
        if (type === 'START') {
          const vector = payload.vector;
          let sumOfSquares = 0;
          for (let i = 0; i < vector.length; i++) {
            if (self['shouldCancel']) {
              self.postMessage({ type: 'CANCELLED' });
              self['shouldCancel'] = false;
              return;
            }
            sumOfSquares += vector[i] * vector[i];
            if (i % 1000 === 0) {
              const start = performance.now();
              while (performance.now() - start < 0.5) {}
            }
          }
          const norm = Math.sqrt(sumOfSquares);
          const normalizedVector = vector.map((val) => val / norm);
          self.postMessage({ type: 'DONE', result: normalizedVector.slice(0, 5), norm: norm });
        } else if (type === 'CANCEL') {
          self['shouldCancel'] = true;
        }
      };
      self.postMessage({ type: 'WORKER_READY' });
    `;
    
    const blob = new Blob([workerCode], { type: 'application/javascript' });
    const workerUrl = URL.createObjectURL(blob);
    const worker = new Worker(workerUrl);
    workerRef.current = worker;

    worker.onmessage = (e: MessageEvent) => {
      if (e.data.type === 'DONE') {
        const endTime = performance.now();
        setProcessingTime(endTime - startTimeRef.current);
        setVectorResult(e.data.result);
        setIsLoading(false);
      } else if (e.data.type === 'CANCELLED') {
        setIsLoading(false);
        setVectorResult(null); // Clear result on cancel
        console.log('Worker cancelled successfully');
      }
    };

    return () => {
      worker.terminate();
      URL.revokeObjectURL(workerUrl);
    };
  }, []);

  // 2. Counter to verify Main Thread Responsiveness
  useEffect(() => {
    const interval = setInterval(() => {
      setCounter((prev) => prev + 1);
    }, 1000);
    return () => clearInterval(interval);
  }, []);

  // 3. Handle Start
  const handleStart = () => {
    if (!workerRef.current) return;
    
    setIsLoading(true);
    setVectorResult(null);
    startTimeRef.current = performance.now();

    // Generate large vector (1024 dimensions)
    const vector = Array.from({ length: 1024 }, () => Math.random() * 100);
    
    workerRef.current.postMessage({
      type: 'START',
      payload: { vector }
    });
  };

  // 4. Handle Cancel
  const handleCancel = () => {
    if (workerRef.current && isLoading) {
      workerRef.current.postMessage({ type: 'CANCEL' });
    }
  };

  return (
    <div style={{ padding: '20px', fontFamily: 'sans-serif' }}>
      <h2>Background Vector Normalization</h2>
      
      {/* Verification of Responsiveness */}
      <div style={{ marginBottom: '20px', padding: '10px', background: '#f0f0f0' }}>
        <strong>Main Thread Counter (Should never freeze): </strong> {counter}
      </div>

      <div style={{ display: 'flex', gap: '10px' }}>
        <button onClick={handleStart} disabled={isLoading}>
          {isLoading ? 'Processing...' : 'Start Vector Task'}
        </button>
        <button onClick={handleCancel} disabled={!isLoading} style={{ backgroundColor: '#ffcccc' }}>
          Cancel Task
        </button>
      </div>

      <div style={{ marginTop: '20px' }}>
        {isLoading && <p style={{ color: 'blue' }}>Worker is crunching numbers...</p>}
        
        {vectorResult && (
          <div>
            <p><strong>Result (First 5 elements):</strong> [{vectorResult.join(', ')}]</p>
            <p><strong>Processing Time:</strong> {processingTime.toFixed(2)} ms</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default BackgroundTask;
