/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

// useLLMLifecycle.ts
import { useState, useEffect, useRef } from 'react';

// Mock AppState for web environment (normally from 'react-native')
type AppState = 'active' | 'background' | 'inactive';
const mockAppState = { current: 'active' as AppState, listeners: [] as Function[] };
export const mockAppStateModule = {
  addEventListener: (event: 'change', handler: (state: AppState) => void) => {
    mockAppState.listeners.push(handler);
  },
  removeEventListener: (event: 'change', handler: (state: AppState) => void) => {
    mockAppState.listeners = mockAppState.listeners.filter(l => l !== handler);
  },
  // Helper to simulate state changes for testing
  simulateChange: (state: AppState) => {
    mockAppState.current = state;
    mockAppState.listeners.forEach(handler => handler(state));
  }
};

// Mock LLM Instance
class MockLLM {
  private isLoaded = false;
  
  async load() {
    if (this.isLoaded) return;
    // Simulate async loading delay
    await new Promise(resolve => setTimeout(resolve, 500));
    this.isLoaded = true;
    console.log('Model Loaded into Memory');
  }

  dispose() {
    this.isLoaded = false;
    console.log('Model Disposed / Memory Released');
  }

  isModelLoaded() {
    return this.isLoaded;
  }
}

export const useLLMLifecycle = () => {
  const [modelState, setModelState] = useState<'unloaded' | 'loaded' | 'low_memory_mode'>('unloaded');
  const [loadTime, setLoadTime] = useState<number>(0);
  
  const modelRef = useRef<MockLLM | null>(null);
  const idleTimerRef = useRef<NodeJS.Timeout | null>(null);

  // 1. App State Listener
  useEffect(() => {
    const handleChange = (nextAppState: AppState) => {
      if (nextAppState === 'background') {
        handleBackground();
      } else if (nextAppState === 'active') {
        handleForeground();
      }
    };

    mockAppStateModule.addEventListener('change', handleChange);

    return () => {
      mockAppStateModule.removeEventListener('change', handleChange);
      if (idleTimerRef.current) clearTimeout(idleTimerRef.current);
    };
  }, []);

  // 2. Background Handler
  const handleBackground = () => {
    console.log('App Backgrounded: Logging memory usage...');
    // Simulate memory log
    console.log(`Memory Usage: ${(Math.random() * 100).toFixed(2)} MB`);
    
    if (modelRef.current) {
      modelRef.current.dispose();
      modelRef.current = null;
      setModelState('unloaded');
    }
  };

  // 3. Foreground Handler
  const handleForeground = async () => {
    if (modelState === 'low_memory_mode') return; // Don't auto-load in low memory mode

    const start = performance.now();
    const model = new MockLLM();
    await model.load();
    const end = performance.now();
    
    modelRef.current = model;
    setLoadTime(end - start);
    setModelState('loaded');

    // Reset Idle Timer logic
    resetIdleTimer();
  };

  // 4. Garbage Collection Simulation (Idle > 5 mins)
  const resetIdleTimer = () => {
    if (idleTimerRef.current) clearTimeout(idleTimerRef.current);
    // Using 5 seconds instead of 5 minutes for demonstration purposes
    idleTimerRef.current = setTimeout(() => {
      console.log('GC: Model idle too long. Disposing.');
      if (modelRef.current) {
        modelRef.current.dispose();
        modelRef.current = null;
        setModelState('unloaded');
      }
    }, 5000); 
  };

  // 5. Memory Pressure Simulation
  const simulateMemoryPressure = () => {
    console.log('OS Warning: didReceiveMemoryWarning');
    if (modelRef.current) {
      modelRef.current.dispose();
      modelRef.current = null;
    }
    // Clear caches (simulated)
    console.log('Caches Cleared');
    setModelState('low_memory_mode');
  };

  // 6. Manual Wake Up
  const wakeUp = async () => {
    if (modelState === 'low_memory_mode') {
      setModelState('unloaded'); // Reset flag
    }
    // Logic will trigger via foreground effect or direct call
    const start = performance.now();
    const model = new MockLLM();
    await model.load();
    const end = performance.now();
    modelRef.current = model;
    setLoadTime(end - start);
    setModelState('loaded');
    resetIdleTimer();
  };

  return {
    modelState,
    loadTime,
    simulateMemoryPressure,
    wakeUp
  };
};

// Component Usage Example (for context)
/*
const LifecycleComponent = () => {
  const { modelState, loadTime, simulateMemoryPressure, wakeUp } = useLLMLifecycle();
  
  return (
    <div>
      <p>Status: {modelState}</p>
      <p>Last Load Time: {loadTime}ms</p>
      <button onClick={() => mockAppStateModule.simulateChange('background')}>Go Background</button>
      <button onClick={() => mockAppStateModule.simulateChange('active')}>Go Foreground</button>
      <button onClick={simulateMemoryPressure} style={{color: 'red'}}>Simulate Memory Warning</button>
      {modelState === 'low_memory_mode' && <button onClick={wakeUp}>Wake Up (Manual Reload)</button>}
    </div>
  );
};
*/
