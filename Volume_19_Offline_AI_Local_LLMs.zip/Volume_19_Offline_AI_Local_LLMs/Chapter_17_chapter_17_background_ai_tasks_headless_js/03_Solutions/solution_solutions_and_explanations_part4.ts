/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

// types.ts
export interface Task {
  id: string;
  priority: 'high' | 'low';
  execute: () => Promise<void>;
}

// scheduler.ts
export type BatteryStatus = { isCharging: boolean; level: number };

export class TaskScheduler {
  private queue: Task[] = [];
  private isProcessing = false;
  
  // Simulated battery API
  private async getBatteryStatus(): Promise<BatteryStatus> {
    // In a real app, use navigator.getBattery()
    // Here we simulate or read from a mock state
    return (window as any).mockBatteryStatus || { isCharging: false, level: 0.5 };
  }

  public schedule(task: Task) {
    this.queue.push(task);
    console.log(`Task ${task.id} added. Queue size: ${this.queue.length}`);
    this.processQueue();
  }

  private async processQueue() {
    if (this.isProcessing) return;
    this.isProcessing = true;

    while (this.queue.length > 0) {
      const status = await this.getBatteryStatus();
      const nextTask = this.queue[0]; // Peek

      // Logic 1: Charging -> Process immediately
      if (status.isCharging) {
        await this.executeTask(this.queue.shift()!);
        continue;
      }

      // Logic 2: Not charging, Low Battery (<20%) -> Only High Priority
      if (!status.isCharging && status.level < 0.2) {
        const highPriorityIndex = this.queue.findIndex(t => t.priority === 'high');
        if (highPriorityIndex !== -1) {
          // Remove high priority task and execute
          const task = this.queue.splice(highPriorityIndex, 1)[0];
          await this.executeTask(task);
        } else {
          // No high priority tasks, stop processing to save battery
          console.log('Low battery. Pausing low-priority tasks.');
          break; 
        }
        continue;
      }

      // Logic 3: Not charging, Sufficient Battery -> Throttle
      if (!status.isCharging && status.level >= 0.2) {
        const task = this.queue.shift()!;
        await this.executeTask(task);
        // Throttling delay
        console.log('Throttling: Waiting 2s before next task...');
        await new Promise(resolve => setTimeout(resolve, 2000));
        continue;
      }
    }

    this.isProcessing = false;
  }

  private async executeTask(task: Task) {
    try {
      console.log(`Executing Task: ${task.id}`);
      await task.execute();
      console.log(`Task ${task.id} completed.`);
    } catch (error) {
      console.error(`Task ${task.id} failed:`, error);
    }
  }
}

// predictiveScheduler.ts (Interactive Challenge)
export class PredictiveScheduler extends TaskScheduler {
  private chargeHistory: number[] = []; // Hours (0-24) when user usually charges

  constructor() {
    super();
    // Simulate history: User usually charges around 8 PM (20:00)
    this.chargeHistory = [19, 20, 21]; 
  }

  public async schedule(task: Task) {
    // Check if we should predict
    const status = await (this as any).getBatteryStatus(); // Access private via cast for demo
    if (!status.isCharging && task.priority === 'low') {
      const predictedTime = this.predictNextCharge();
      const now = new Date().getHours();
      const hoursUntilCharge = (predictedTime - now + 24) % 24;

      if (hoursUntilCharge <= 1) {
        console.log(`Predictive Scheduling: Low priority task ${task.id} queued for immediate execution upon charging.`);
        // In a real app, we'd listen for 'chargingstart' event. 
        // Here we just flag it or simulate immediate execution if we were charging.
        // For the UI, we will return the prediction.
        task.execute = async () => {
           console.log(`(Predicted) Executing ${task.id} now because charge is imminent.`);
           await new Promise(r => setTimeout(r, 100));
        };
      } else {
        console.log(`Predictive Scheduling: Task ${task.id} deferred. Predicted charge in ${hoursUntilCharge} hours.`);
      }
    }
    
    super.schedule(task);
  }

  private predictNextCharge(): number {
    // Simple average of history
    const sum = this.chargeHistory.reduce((a, b) => a + b, 0);
    return sum / this.chargeHistory.length;
  }
  
  public getPredictionInfo(): string {
    const predictedHour = this.predictNextCharge();
    return `Predicted next charge: ~${predictedHour.toFixed(0)}:00`;
  }
}
