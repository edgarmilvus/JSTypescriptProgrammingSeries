/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.tsx
// Description: Solutions and Explanations
// ==========================================

// eventEmitter.ts
// Simple global event bus for simulation
export const eventBus = {
  events: {} as Record<string, Function[]>,
  emit(event: string, data: any) {
    if (this.events[event]) {
      this.events[event].forEach(cb => cb(data));
    }
  },
  on(event: string, callback: Function) {
    if (!this.events[event]) this.events[event] = [];
    this.events[event].push(callback);
    return () => {
      this.events[event] = this.events[event].filter(cb => cb !== callback);
    };
  }
};

// types.ts
export type TaskStatus = 'idle' | 'loading' | 'inference' | 'error';
export interface BackgroundTask {
  id: string;
  name: string;
  status: TaskStatus;
  progress?: number; // 0-100
}

// BackgroundInferenceStatus.tsx
import React, { useReducer, useEffect, useRef } from 'react';
import { eventBus, BackgroundTask, TaskStatus } from './eventEmitter'; // Assuming separate file

type State = {
  tasks: BackgroundTask[];
  systemStatus: TaskStatus;
};

type Action =
  | { type: 'ADD_TASK'; payload: BackgroundTask }
  | { type: 'UPDATE_TASK'; payload: { id: string; updates: Partial<BackgroundTask> } }
  | { type: 'REMOVE_TASK'; id: string }
  | { type: 'MEMORY_WARNING' };

const initialState: State = {
  tasks: [],
  systemStatus: 'idle',
};

function reducer(state: State, action: Action): State {
  switch (action.type) {
    case 'ADD_TASK':
      return {
        ...state,
        tasks: [...state.tasks, action.payload],
        systemStatus: action.payload.status === 'error' ? 'error' : 'loading'
      };
    case 'UPDATE_TASK':
      return {
        ...state,
        tasks: state.tasks.map(t => 
          t.id === action.payload.id ? { ...t, ...action.payload.updates } : t
        )
      };
    case 'REMOVE_TASK':
      const remaining = state.tasks.filter(t => t.id !== action.id);
      return {
        ...state,
        tasks: remaining,
        systemStatus: remaining.length === 0 ? 'idle' : state.systemStatus
      };
    case 'MEMORY_WARNING':
      return {
        ...state,
        systemStatus: 'error',
        tasks: [] // Clear tasks on critical warning
      };
    default:
      return state;
  }
}

export const BackgroundInferenceStatus: React.FC = () => {
  const [state, dispatch] = useReducer(reducer, initialState);
  const unsubscribeRef = useRef<Function | null>(null);

  useEffect(() => {
    // Subscribe to global events
    const unsubAdd = eventBus.on('BG_TASK_ADDED', (task: BackgroundTask) => {
      dispatch({ type: 'ADD_TASK', payload: task });
    });

    const unsubUpdate = eventBus.on('BG_TASK_PROGRESS', (data: { id: string; progress: number }) => {
      dispatch({ type: 'UPDATE_TASK', payload: { id: data.id, updates: { progress: data.progress } } });
    });

    const unsubError = eventBus.on('BG_TASK_ERROR', (taskId: string) => {
      dispatch({ type: 'UPDATE_TASK', payload: { id: taskId, updates: { status: 'error' } } });
    });

    const unsubMem = eventBus.on('MEMORY_WARNING', () => {
      dispatch({ type: 'MEMORY_WARNING' });
    });

    return () => {
      unsubAdd();
      unsubUpdate();
      unsubError();
      unsubMem();
    };
  }, []);

  const handleCancel = (taskId: string) => {
    // 1. Update UI immediately
    dispatch({ type: 'REMOVE_TASK', id: taskId });
    // 2. Send signal to background worker (simulated)
    eventBus.emit('CANCEL_TASK', taskId);
    console.log(`Sent cancellation signal for task ${taskId}`);
  };

  // Visual Indicator Helper
  const renderStatusIndicator = (status: TaskStatus) => {
    const colors = {
      idle: 'green',
      loading: 'blue',
      inference: 'purple',
      error: 'red'
    };
    return (
      <span 
        style={{ 
          display: 'inline-block', 
          width: '12px', 
          height: '12px', 
          borderRadius: '50%', 
          backgroundColor: colors[status],
          marginRight: '8px',
          animation: status === 'loading' ? 'pulse 1s infinite' : 'none'
        }} 
      />
    );
  };

  return (
    <div 
      aria-live="polite" 
      aria-label={`Background tasks status: ${state.systemStatus}`}
      style={{ border: '1px solid #ccc', padding: '10px', borderRadius: '8px', background: '#f9f9f9' }}
    >
      <h3>Background Inference Status</h3>
      
      {/* System Level Status */}
      <div style={{ marginBottom: '10px', fontWeight: 'bold', color: state.systemStatus === 'error' ? 'red' : 'black' }}>
        {renderStatusIndicator(state.systemStatus)}
        System: {state.systemStatus.toUpperCase()}
      </div>

      {/* Queue Visualization */}
      {state.tasks.length > 0 ? (
        <ul style={{ listStyle: 'none', padding: 0, margin: 0 }}>
          {state.tasks.map(task => (
            <li 
              key={task.id} 
              style={{ 
                background: 'white', 
                marginBottom: '5px', 
                padding: '8px', 
                borderLeft: `4px solid ${task.status === 'error' ? 'red' : 'blue'}`,
                display: 'flex',
                justifyContent: 'space-between',
                alignItems: 'center'
              }}
            >
              <div>
                <div style={{ fontWeight: 'bold' }}>{task.name}</div>
                <div style={{ fontSize: '0.8em', color: '#666' }}>
                  Status: {task.status} 
                  {task.progress !== undefined && ` (${task.progress}%)`}
                  {task.status === 'loading' && ' - Est. 2s'}
                </div>
              </div>
              <button onClick={() => handleCancel(task.id)} style={{ fontSize: '0.8em' }}>
                Cancel
              </button>
            </li>
          ))}
        </ul>
      ) : (
        <p style={{ fontStyle: 'italic', color: '#888' }}>No active background tasks.</p>
      )}
    </div>
  );
};
