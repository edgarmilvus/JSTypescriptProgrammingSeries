/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part6.ts
// Description: Solutions and Explanations
// ==========================================

// types.ts
export type Vector = number[];
export type VectorDB = Vector[];

// useWasmVectorSearch.ts
import { useState, useEffect, useCallback } from 'react';

// 1. Define WASM Interface
interface WasmExports {
  calculateCosineSimilarity(a: Float32Array, b: Float32Array): number;
}

// 2. Mock WASM Loader
const mockWasmLoader = (): Promise<WasmExports> => {
  return new Promise((resolve, reject) => {
    // Simulate network/compilation delay
    setTimeout(() => {
      // 30% chance of failure to test fallback
      if (Math.random() < 0.3) {
        reject(new Error('WASM binary missing or incompatible'));
      } else {
        resolve({
          calculateCosineSimilarity: (a, b) => {
            // Simulate native speed (very fast)
            // In reality, this calls into the WASM linear memory
            let dotProduct = 0;
            let normA = 0;
            let normB = 0;
            for (let i = 0; i < a.length; i++) {
              dotProduct += a[i] * b[i];
              normA += a[i] * a[i];
              normB += b[i] * b[i];
            }
            return dotProduct / (Math.sqrt(normA) * Math.sqrt(normB));
          }
        } as WasmExports);
      }
    }, 500);
  });
};

// 3. Pure JS Fallback
const jsCosineSimilarity = (a: Vector, b: Vector): number => {
  let dotProduct = 0;
  let normA = 0;
  let normB = 0;
  // Artificially slow this down to demonstrate the performance gap
  // (In reality, JS is fast, but WASM is faster for heavy math)
  const start = performance.now();
  while (performance.now() - start < 0.05) {} // Block 0.05ms per calculation
  
  for (let i = 0; i < a.length; i++) {
    dotProduct += a[i] * b[i];
    normA += a[i] * a[i];
    normB += b[i] * b[i];
  }
  return dotProduct / (Math.sqrt(normA) * Math.sqrt(normB));
};

export const useWasmVectorSearch = () => {
  const [wasmModule, setWasmModule] = useState<WasmExports | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [benchmarkResult, setBenchmarkResult] = useState<string | null>(null);

  // Load WASM on mount
  useEffect(() => {
    setIsLoading(true);
    mockWasmLoader()
      .then(module => {
        setWasmModule(module);
        setIsLoading(false);
      })
      .catch(err => {
        console.warn('WASM Load Failed, falling back to JS:', err.message);
        setError('WASM failed to load. Using JS fallback.');
        setIsLoading(false);
      });
  }, []);

  // Search Function
  const search = useCallback((query: Vector, db: VectorDB, k: number = 3) => {
    if (isLoading) return [];
    
    const start = performance.now();
    let results: { idx: number; score: number }[] = [];

    // Determine which function to use
    const similarityFn = (a: Vector, b: Vector) => {
      if (wasmModule) {
        // Convert to Float32Array for WASM (simulated)
        return wasmModule.calculateCosineSimilarity(
          new Float32Array(a), 
          new Float32Array(b)
        );
      } else {
        return jsCosineSimilarity(a, b);
      }
    };

    // Run Search
    for (let i = 0; i < db.length; i++) {
      const score = similarityFn(query, db[i]);
      results.push({ idx: i, score });
    }

    // Sort by score (descending for cosine similarity)
    results.sort((a, b) => b.score - a.score);
    const end = performance.now();

    // Benchmark Logic
    const timeTaken = end - start;
    let benchmark = `Time: ${timeTaken.toFixed(2)}ms (${wasmModule ? 'WASM' : 'JS'})`;
    
    // Interactive Challenge: Compare with "Mock" WASM speed
    if (wasmModule) {
      // If we used WASM, let's pretend the JS version would have been 80% slower
      const mockJsTime = timeTaken * 5; // 5x slower
      const gain = ((mockJsTime - timeTaken) / mockJsTime * 100).toFixed(1);
      benchmark += `\nVs JS Fallback (Simulated): -${gain}% (Saved ${mockJsTime - timeTaken}ms)`;
    }

    setBenchmarkResult(benchmark);
    return results.slice(0, k);

  }, [wasmModule, isLoading]);

  return { search, isLoading, error, benchmarkResult };
};

// Example Usage Component (Conceptual)
/*
const SearchComponent = () => {
  const { search, isLoading, error, benchmarkResult } = useWasmVectorSearch();
  
  const handleSearch = () => {
    // Generate random DB
    const db = Array.from({length: 100}, () => Array.from({length: 768}, () => Math.random()));
    const query = Array.from({length: 768}, () => Math.random());
    const results = search(query, db);
    console.log(results);
  };

  return (
    <div>
      {isLoading && <p>Loading WASM...</p>}
      {error && <p style={{color: 'orange'}}>{error}</p>}
      <button onClick={handleSearch} disabled={isLoading}>Benchmark Search</button>
      {benchmarkResult && <pre>{benchmarkResult}</pre>}
    </div>
  );
};
*/
