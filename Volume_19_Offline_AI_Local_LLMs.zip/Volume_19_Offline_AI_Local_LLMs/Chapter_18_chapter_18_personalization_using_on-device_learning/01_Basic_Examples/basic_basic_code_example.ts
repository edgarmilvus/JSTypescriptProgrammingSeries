/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * @fileoverview A simplified TypeScript implementation of an on-device personalization loop.
 * This simulates capturing user feedback, updating a local vector store, and adjusting model adapters.
 * 
 * Dependencies: None (Pure TypeScript for demonstration).
 * For production, you would use libraries like `@huggingface/transformers`, `llama-node`, or `chromadb`.
 */

// ==========================================
// 1. Type Definitions & Interfaces
// ==========================================

type FeedbackScore = 1 | -1; // 1 = Helpful, -1 = Not Helpful

interface UserInteraction {
  query: string;
  response: string;
  feedback: FeedbackScore;
  timestamp: Date;
}

interface VectorEntry {
  id: string;
  vector: number[]; // Embedding representation
  metadata: {
    query: string;
    feedback: FeedbackScore;
  };
}

interface LoRAAdapterConfig {
  alpha: number; // Scaling factor for LoRA weights
  rank: number;  // Rank of the low-rank matrices
  weightDelta: number[]; // Simulated adjustment to weights
}

// ==========================================
// 2. Mock Services (Simulating Real Hardware)
// ==========================================

/**
 * Simulates an Embedding Model (e.g., BERT-small running on WebGPU/NNAPI).
 * Converts text into a fixed-size vector.
 */
class EmbeddingModel {
  private readonly dimension = 4; // Reduced for "Hello World" clarity

  async embed(text: string): Promise<number[]> {
    // In reality, this runs a neural network. 
    // Here, we generate a deterministic pseudo-vector based on string length and char codes.
    const hash = text.split('').reduce((acc, char) => acc + char.charCodeAt(0), 0);
    const base = hash % 100;
    
    return Array.from({ length: this.dimension }, (_, i) => 
      parseFloat(((base + i * 13) % 100 / 100).toFixed(4))
    );
  }
}

/**
 * Simulates a Local Vector Database (e.g., SQLite with Vector extension or ChromaDB).
 * Stores embeddings for efficient similarity search.
 */
class LocalVectorStore {
  private store: VectorEntry[] = [];

  async addEntry(entry: VectorEntry): Promise<void> {
    this.store.push(entry);
    console.log(`[VectorStore] Added entry ${entry.id}. Total entries: ${this.store.length}`);
  }

  async search(queryVector: number[], limit: number = 1): Promise<VectorEntry[]> {
    // Simple Euclidean distance calculation
    const scored = this.store.map(entry => {
      const distance = Math.sqrt(
        queryVector.reduce((sum, val, idx) => sum + Math.pow(val - entry.vector[idx], 2), 0)
      );
      return { ...entry, distance };
    });

    return scored.sort((a, b) => a.distance - b.distance).slice(0, limit);
  }
}

/**
 * Simulates a LoRA (Low-Rank Adaptation) Adapter.
 * In a real scenario, this would hold the trainable parameters (LoRA A and B matrices).
 */
class LoRAAdapter {
  private config: LoRAAdapterConfig;

  constructor(config: LoRAAdapterConfig) {
    this.config = config;
  }

  /**
   * Adjusts the adapter weights based on successful feedback patterns.
   * This simulates the "learning" step.
   */
  async updateWeights(feedbackScore: FeedbackScore, contextVector: number[]): Promise<void> {
    const learningRate = 0.01;
    
    // In real LoRA, we update matrix A and B. Here we simulate a weight delta.
    // Positive feedback increases the delta, negative feedback decreases it.
    const adjustment = contextVector.map(v => v * feedbackScore * learningRate);
    
    // Update the simulated weight delta
    this.config.weightDelta = this.config.weightDelta.map((w, i) => w + (adjustment[i] || 0));
    
    console.log(`[LoRA Adapter] Weights updated. New Delta Norm: ${this.getWeightNorm().toFixed(4)}`);
  }

  private getWeightNorm(): number {
    return Math.sqrt(this.config.weightDelta.reduce((acc, val) => acc + val * val, 0));
  }
}

// ==========================================
// 3. The Personalization Engine
// ==========================================

class OnDevicePersonalizationEngine {
  private embeddingModel: EmbeddingModel;
  private vectorStore: LocalVectorStore;
  private loraAdapter: LoRAAdapter;

  constructor() {
    this.embeddingModel = new EmbeddingModel();
    this.vectorStore = new LocalVectorStore();
    this.loraAdapter = new LoRAAdapter({
      alpha: 16,
      rank: 8,
      weightDelta: Array(4).fill(0) // Initialize with zeros
    });
  }

  /**
   * Orchestrates the full flow: Query -> Response -> Feedback -> Learn.
   */
  async processInteraction(query: string, simulatedResponse: string, feedback: FeedbackScore): Promise<void> {
    console.log(`\n--- Processing Interaction: "${query}" ---`);

    // Step 1: Generate embedding for the query
    const queryVector = await this.embeddingModel.embed(query);

    // Step 2: Store the interaction in the vector DB for future retrieval
    const entryId = `entry_${Date.now()}`;
    await this.vectorStore.addEntry({
      id: entryId,
      vector: queryVector,
      metadata: { query, feedback }
    });

    // Step 3: "Learn" from the feedback by adjusting the adapter
    // In a real system, we might only learn if the feedback is negative or specific patterns emerge.
    await this.loraAdapter.updateWeights(feedback, queryVector);

    // Step 4: Simulate Retrieval-Augmented Generation (RAG) check
    // Check if we have seen similar queries before to personalize the next response.
    const similarEntries = await this.vectorStore.search(queryVector);
    
    if (similarEntries.length > 0 && similarEntries[0].distance < 0.1) {
      console.log(`[Personalization] Found similar past query with feedback: ${similarEntries[0].metadata.feedback}`);
      // Logic to modify future prompts based on history would go here
    }

    console.log("--- Interaction Complete ---\n");
  }
}

// ==========================================
// 4. Execution (Main Entry Point)
// ==========================================

async function main() {
  const engine = new OnDevicePersonalizationEngine();

  // Scenario 1: User asks a question and finds it helpful
  await engine.processInteraction(
    "What is the capital of France?",
    "The capital of France is Paris.",
    1 // Positive feedback
  );

  // Scenario 2: User asks a follow-up and finds the answer unhelpful
  await engine.processInteraction(
    "What is the capital of France?",
    "Paris is a city in Europe.", // Vague answer
    -1 // Negative feedback
  );
  
  // Scenario 3: User asks a related question
  await engine.processInteraction(
    "Where is the Eiffel Tower located?",
    "The Eiffel Tower is in Paris.",
    1 // Positive feedback
  );
}

// Run the example
if (require.main === module) {
  main().catch(console.error);
}

export {
  OnDevicePersonalizationEngine,
  EmbeddingModel,
  LocalVectorStore,
  LoRAAdapter
};
