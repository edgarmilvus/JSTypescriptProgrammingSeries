/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.tsx
// Description: Advanced Application Script
// ==========================================

/**
 * File: app/components/RecipeAssistant.tsx
 * 
 * Implements an On-Device Personalization Engine.
 * 
 * Architecture Highlights:
 * 1. Vector DB: In-memory embedding store (simulated) for recipe retrieval.
 * 2. Model: WebAssembly-based LLM with LoRA adapter support.
 * 3. State Management: React hooks for managing feedback and model configuration.
 * 4. Optimization: Uses requestIdleCallback for background weight updates.
 */

import React, { useState, useEffect, useRef, useCallback } from 'react';

// --- Types & Interfaces ---

interface Recipe {
  id: string;
  title: string;
  ingredients: string[];
  vector: Float32Array; // Embedding representation
  metadata: { tags: string[]; difficulty: 'easy' | 'medium' | 'hard' };
}

interface UserFeedback {
  recipeId: string;
  rating: number; // 1 to 5
  timestamp: number;
}

interface LoRAConfig {
  adapterId: string;
  alpha: number; // Scaling factor for adapter weights
}

// --- Constants & Configuration ---

const VECTOR_DIM = 128; // Reduced for demo performance
const ADAPTER_STORAGE_KEY = 'recipe_lora_adapters';
const FEEDBACK_KEY = 'user_feedback_log';

/**
 * Simulates a WebAssembly SIMD optimized vector operation.
 * In a real scenario, this would be handled by a library like ONNX Runtime Web
 * or WebLLM using WASM SIMD instructions for parallel dot products.
 */
const simulateWasmVectorOp = (a: Float32Array, b: Float32Array): number => {
  if (a.length !== b.length) throw new Error('Vector dimension mismatch');
  let dotProduct = 0;
  // SIMD optimization would process multiple float multiplications in parallel here
  for (let i = 0; i < a.length; i++) {
    dotProduct += a[i] * b[i];
  }
  return dotProduct;
};

// --- Core Logic: On-Device Learning Engine ---

class OnDevicePersonalizationEngine {
  private vectorDb: Recipe[] = [];
  private feedbackLog: UserFeedback[] = [];
  private activeAdapters: Map<string, LoRAConfig> = new Map();

  constructor() {
    this.loadPersistedState();
  }

  /**
   * Loads persisted LoRA adapters and feedback logs from LocalStorage.
   * This simulates the "Checkpointer" concept ensuring state hydration.
   */
  private loadPersistedState() {
    const storedAdapters = localStorage.getItem(ADAPTER_STORAGE_KEY);
    const storedFeedback = localStorage.getItem(FEEDBACK_KEY);

    if (storedAdapters) {
      const parsed = JSON.parse(storedAdapters);
      parsed.forEach((a: LoRAConfig) => this.activeAdapters.set(a.adapterId, a));
    }

    if (storedFeedback) {
      this.feedbackLog = JSON.parse(storedFeedback);
    }
  }

  /**
   * Searches the vector database for recipes similar to the query embedding.
   * Uses Cosine Similarity (simulated via dot product of normalized vectors).
   */
  public async searchRecipes(queryEmbedding: Float32Array): Promise<Recipe[]> {
    // Normalize query vector (simulated)
    const norm = Math.sqrt(queryEmbedding.reduce((sum, val) => sum + val * val, 0));
    const normalizedQuery = queryEmbedding.map(v => v / norm);

    // Calculate similarity scores
    const scored = this.vectorDb.map(recipe => {
      const score = simulateWasmVectorOp(normalizedQuery, recipe.vector);
      return { ...recipe, score };
    });

    // Return top 3 matches
    return scored.sort((a, b) => b.score - a.score).slice(0, 3);
  }

  /**
   * Records user feedback and triggers the background fine-tuning process.
   * This is the "Privacy-Preserving Feedback Loop".
   */
  public async logFeedback(feedback: UserFeedback) {
    this.feedbackLog.push(feedback);
    
    // Persist immediately
    localStorage.setItem(FEEDBACK_KEY, JSON.stringify(this.feedbackLog));

    // Trigger background LoRA update (non-blocking)
    if ('requestIdleCallback' in window) {
      requestIdleCallback(() => this.updateLoRAWeights(feedback));
    } else {
      // Fallback for Safari
      setTimeout(() => this.updateLoRAWeights(feedback), 0);
    }
  }

  /**
   * Simulates LoRA Fine-Tuning.
   * In a real implementation, this would calculate gradients for the LoRA
   * matrices (A and B) based on the loss between the model's prediction
   * and the user's rating.
   */
  private async updateLoRAWeights(feedback: UserFeedback) {
    const recipe = this.vectorDb.find(r => r.id === feedback.recipeId);
    if (!recipe) return;

    // Derive a specific adapter ID based on the recipe tags (e.g., "keto", "spicy")
    // This allows the model to specialize in different cuisines.
    const primaryTag = recipe.metadata.tags[0];
    const adapterId = `adapter_v1_${primaryTag}`;

    const currentAdapter = this.activeAdapters.get(adapterId) || { adapterId, alpha: 1.0 };

    // Simulate gradient descent update:
    // If rating is high, increase the adapter's influence (alpha).
    // If rating is low, decrease it or switch context.
    const learningRate = 0.05;
    const reward = (feedback.rating - 3) / 2; // Normalize rating to -1 to 1 range
    
    const newAlpha = Math.max(0.1, currentAdapter.alpha + (learningRate * reward));

    const updatedAdapter: LoRAConfig = {
      adapterId,
      alpha: newAlpha
    };

    this.activeAdapters.set(adapterId, updatedAdapter);
    
    // Persist the new adapter state
    localStorage.setItem(ADAPTER_STORAGE_KEY, JSON.stringify(Array.from(this.activeAdapters.values())));

    console.log(`[On-Device Learning] LoRA adapter '${adapterId}' updated. New Alpha: ${newAlpha.toFixed(3)}`);
  }

  /**
   * Retrieves the active LoRA configuration for the LLM inference engine.
   */
  public getActiveAdapters(): LoRAConfig[] {
    return Array.from(this.activeAdapters.values());
  }

  // --- Mock Data Initialization ---
  public seedMockData() {
    if (this.vectorDb.length > 0) return;
    
    // Generating dummy embeddings for recipes
    const mockRecipes: Omit<Recipe, 'vector'>[] = [
      { id: '1', title: 'Spicy Keto Tacos', ingredients: ['Beef', 'Lettuce', 'Cheese'], metadata: { tags: ['keto', 'spicy'], difficulty: 'easy' } },
      { id: '2', title: 'Vegan Buddha Bowl', ingredients: ['Quinoa', 'Chickpeas', 'Avocado'], metadata: { tags: ['vegan', 'healthy'], difficulty: 'medium' } },
      { id: '3', title: 'Classic Margherita', ingredients: ['Dough', 'Tomato', 'Mozzarella'], metadata: { tags: ['italian', 'vegetarian'], difficulty: 'easy' } },
    ];

    this.vectorDb = mockRecipes.map(r => ({
      ...r,
      vector: new Float32Array(Array.from({length: VECTOR_DIM}, () => Math.random())) // Random embedding
    }));
  }
}

// --- React Component ---

const RecipeAssistant: React.FC = () => {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<Recipe[]>([]);
  const [loading, setLoading] = useState(false);
  const [status, setStatus] = useState('Ready');
  
  // Ref to the engine instance (persists across renders)
  const engineRef = useRef(new OnDevicePersonalizationEngine());

  useEffect(() => {
    // Initialize mock data on mount
    engineRef.current.seedMockData();
    setStatus('Engine initialized. Vector DB ready.');
  }, []);

  /**
   * Handles the search request.
   * 1. Generates embedding for the query (simulated).
   * 2. Performs vector search.
   * 3. Generates LLM response (simulated) using active LoRA adapters.
   */
  const handleSearch = async () => {
    if (!query) return;
    
    setLoading(true);
    setStatus('Generating embeddings & searching...');

    // 1. Simulate Embedding Generation (Input Transformation)
    const queryEmbedding = new Float32Array(Array.from({length: VECTOR_DIM}, (_, i) => 
      Math.sin(i + query.length) // Deterministic pseudo-random based on query
    ));

    // 2. Vector Search
    const matches = await engineRef.current.searchRecipes(queryEmbedding);
    setResults(matches);

    // 3. Simulate LLM Inference with LoRA
    const adapters = engineRef.current.getActiveAdapters();
    const adapterSummary = adapters.length > 0 
      ? `Applying ${adapters.length} LoRA adapter(s) for personalization.` 
      : 'No active adapters (using base model).';

    setStatus(`Found ${matches.length} recipes. ${adapterSummary}`);
    setLoading(false);
  };

  /**
   * Handles user feedback (Like/Dislike).
   * Triggers the on-device learning loop.
   */
  const handleFeedback = async (recipeId: string, rating: number) => {
    setStatus(`Processing feedback for recipe #${recipeId}...`);
    
    await engineRef.current.logFeedback({
      recipeId,
      rating,
      timestamp: Date.now()
    });

    // Refresh UI to show updated adapter status
    const adapters = engineRef.current.getActiveAdapters();
    setStatus(`Feedback recorded. Active Adapters: ${adapters.map(a => a.adapterId).join(', ')}`);
  };

  return (
    <div style={{ fontFamily: 'system-ui, sans-serif', padding: '20px', maxWidth: '600px', margin: '0 auto' }}>
      <h1>Personalized Recipe Assistant (On-Device)</h1>
      
      <div style={{ marginBottom: '20px', padding: '10px', border: '1px solid #ddd', borderRadius: '8px' }}>
        <p style={{ fontSize: '0.9em', color: '#666' }}>
          <strong>Architecture:</strong> Local Vector DB + LoRA Adapters + WASM Inference
        </p>
        <div style={{ display: 'flex', gap: '10px' }}>
          <input 
            type="text" 
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="e.g., 'spicy dinner'"
            style={{ flex: 1, padding: '8px' }}
          />
          <button 
            onClick={handleSearch} 
            disabled={loading}
            style={{ padding: '8px 16px', background: '#0070f3', color: 'white', border: 'none', borderRadius: '4px' }}
          >
            {loading ? 'Processing...' : 'Search'}
          </button>
        </div>
      </div>

      <div style={{ marginBottom: '15px', fontSize: '0.85em', color: '#0070f3' }}>
        Status: {status}
      </div>

      <div>
        {results.map((recipe) => (
          <div key={recipe.id} style={{ border: '1px solid #eee', padding: '15px', marginBottom: '10px', borderRadius: '8px' }}>
            <h3 style={{ margin: '0 0 10px 0' }}>{recipe.title}</h3>
            <p style={{ fontSize: '0.9em' }}>Tags: {recipe.metadata.tags.join(', ')}</p>
            <div style={{ display: 'flex', gap: '10px', marginTop: '10px' }}>
              <button 
                onClick={() => handleFeedback(recipe.id, 5)}
                style={{ background: '#e0f7fa', border: '1px solid #006064', padding: '5px 10px', cursor: 'pointer' }}
              >
                👍 Like
              </button>
              <button 
                onClick={() => handleFeedback(recipe.id, 1)}
                style={{ background: '#ffebee', border: '1px solid #b71c1c', padding: '5px 10px', cursor: 'pointer' }}
              >
                👎 Dislike
              </button>
            </div>
          </div>
        ))}
        {results.length === 0 && query && !loading && (
          <p>No recipes found. Try different keywords.</p>
        )}
      </div>
    </div>
  );
};

export default RecipeAssistant;
