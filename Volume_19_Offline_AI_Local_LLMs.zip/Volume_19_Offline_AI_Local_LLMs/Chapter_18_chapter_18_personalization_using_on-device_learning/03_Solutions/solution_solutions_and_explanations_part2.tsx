/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState, useEffect } from 'react';

// Assuming FeedbackManager is available in scope
// (In a real app, this would be imported from the solution to Exercise 1)
declare class FeedbackManager {
    getRecentFeedback(limit: number): Promise<any[]>;
    // We need a method to count total logs, or we can infer from recent. 
    // For this exercise, we will simulate a count method or fetch recent and count.
    // To be robust, let's assume we add a count method to the class or just fetch a large batch.
    // Here, we will fetch a large batch (e.g., 1000) to approximate total count for the demo.
}

interface LearningProgressProps {
    feedbackManager: FeedbackManager;
}

const LearningProgressWidget: React.FC<LearningProgressProps> = ({ feedbackManager }) => {
    const [count, setCount] = useState<number>(0);
    const [loading, setLoading] = useState<boolean>(true);
    const [error, setError] = useState<string | null>(null);

    // Function to fetch data
    const fetchData = async () => {
        setLoading(true);
        setError(null);
        try {
            // In a real implementation, we would have a dedicated count() method in FeedbackManager.
            // Here, we simulate fetching all recent logs to get a count.
            // For performance, a count method using IDB.count() would be preferred.
            const logs = await feedbackManager.getRecentFeedback(1000); 
            setCount(logs.length);
        } catch (err) {
            setError("Failed to load feedback data.");
            console.error(err);
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        fetchData();
    }, [feedbackManager]);

    // Calculate strength: min(100, (count / 50) * 100)
    const targetCount = 50;
    const strengthPercentage = Math.min(100, (count / targetCount) * 100);
    const strengthLabel = `${Math.round(strengthPercentage)}%`;

    return (
        <div className="learning-widget" style={styles.widget}>
            <h3 style={styles.header}>Learning Progress</h3>
            
            {loading && <p>Loading...</p>}
            {error && <p style={{ color: 'red' }}>{error}</p>}
            
            {!loading && !error && (
                <>
                    <div style={styles.stats}>
                        <span>Feedback Logs: <strong>{count}</strong></span>
                        <span>Target: {targetCount}</span>
                    </div>
                    
                    {/* Visual Progress Bar */}
                    <div style={styles.progressBarContainer}>
                        <div 
                            style={{
                                ...styles.progressBarFill,
                                width: `${strengthPercentage}%`,
                                backgroundColor: strengthPercentage === 100 ? '#4caf50' : '#2196f3'
                            }}
                        >
                            <span style={styles.progressText}>{strengthLabel}</span>
                        </div>
                    </div>

                    <button onClick={fetchData} style={styles.button}>
                        Refresh
                    </button>
                </>
            )}
        </div>
    );
};

// Basic CSS-in-JS styles for the exercise
const styles: { [key: string]: React.CSSProperties } = {
    widget: {
        border: '1px solid #ddd',
        padding: '16px',
        borderRadius: '8px',
        maxWidth: '300px',
        fontFamily: 'Arial, sans-serif',
        boxShadow: '0 2px 4px rgba(0,0,0,0.1)'
    },
    header: {
        marginTop: 0,
        fontSize: '1.2rem',
        borderBottom: '1px solid #eee',
        paddingBottom: '8px'
    },
    stats: {
        display: 'flex',
        justifyContent: 'space-between',
        marginBottom: '10px',
        fontSize: '0.9rem'
    },
    progressBarContainer: {
        height: '20px',
        backgroundColor: '#e0e0e0',
        borderRadius: '10px',
        overflow: 'hidden',
        marginBottom: '10px'
    },
    progressBarFill: {
        height: '100%',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        transition: 'width 0.3s ease'
    },
    progressText: {
        color: 'white',
        fontSize: '0.75rem',
        fontWeight: 'bold'
    },
    button: {
        width: '100%',
        padding: '8px',
        backgroundColor: '#f0f0f0',
        border: '1px solid #ccc',
        borderRadius: '4px',
        cursor: 'pointer'
    }
};

export default LearningProgressWidget;
