/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

function mergeLoraWeights(
    baseWeights: Float32Array,
    loraA: Float32Array,
    loraB: Float32Array,
    inputDim: number,
    outputDim: number,
    alpha: number
): Float32Array {
    // Validate input dimensions
    const baseSize = inputDim * outputDim;
    if (baseWeights.length !== baseSize) {
        throw new Error(`Base weights size ${baseWeights.length} does not match dimensions ${inputDim}x${outputDim}`);
    }

    // Calculate Rank (r)
    // A is [r, inputDim], B is [outputDim, r]
    const rank = loraA.length / inputDim;
    
    if (loraA.length !== rank * inputDim) {
        throw new Error("LoRA A dimensions are invalid.");
    }
    if (loraB.length !== outputDim * rank) {
        throw new Error("LoRA B dimensions are invalid.");
    }

    // Scaling factor: (alpha / r)
    const scale = alpha / rank;

    // Initialize result array with a copy of base weights to avoid mutation
    const mergedWeights = new Float32Array(baseWeights);
    
    // Calculate Delta W = (B @ A) * scale
    // We iterate over the output dimensions (rows of B) and input dimensions (cols of A)
    
    for (let i = 0; i < outputDim; i++) {
        for (let j = 0; j < inputDim; j++) {
            let dotProduct = 0;
            
            // Matrix multiplication: Row i of B * Col j of A
            for (let k = 0; k < rank; k++) {
                // B index: i * rank + k
                const bVal = loraB[i * rank + k];
                // A index: k * inputDim + j
                const aVal = loraA[k * inputDim + j];
                dotProduct += bVal * aVal;
            }

            // Apply scaling
            const delta = dotProduct * scale;

            // Add to base weight
            // Flattened index for row i, col j in a row-major matrix
            const baseIndex = i * inputDim + j;
            mergedWeights[baseIndex] += delta;
        }
    }

    return mergedWeights;
}
