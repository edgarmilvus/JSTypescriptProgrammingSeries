/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

interface WasmSimdInput {
    buffer: ArrayBuffer;
    queryDim: number;
    docCount: number;
    paddedDim: number;
}

function prepareWasmSimdSearch(
    queryVector: Float32Array,
    documentVectors: Float32Array,
    chunkSize: number = 4
): WasmSimdInput {
    const originalDim = queryVector.length;
    const docCount = documentVectors.length / originalDim;

    // Validate dimensions
    if (documentVectors.length % originalDim !== 0) {
        throw new Error("Document vectors length is not a multiple of query dimension.");
    }

    // Calculate padding
    // SIMD instructions (e.g., float32x4) work best when data length is a multiple of the lane count.
    const remainder = originalDim % chunkSize;
    const paddedDim = remainder === 0 ? originalDim : originalDim + (chunkSize - remainder);

    // Helper to pad a vector
    const padVector = (vector: Float32Array): Float32Array => {
        if (paddedDim === vector.length) return vector;
        const padded = new Float32Array(paddedDim);
        padded.set(vector); // Copy original data
        // Remaining values are initialized to 0 by default
        return padded;
    };

    // 1. Prepare Query Vector
    const paddedQuery = padVector(queryVector);

    // 2. Prepare Document Vectors
    // We need to process the flattened array and insert padding at the end of every row (dimension)
    const paddedDocSize = docCount * paddedDim;
    const paddedDocs = new Float32Array(paddedDocSize);
    
    for (let i = 0; i < docCount; i++) {
        const startSrc = i * originalDim;
        const startDest = i * paddedDim;
        // Copy the row
        paddedDocs.set(documentVectors.subarray(startSrc, startSrc + originalDim), startDest);
        // Padding (zeros) is implicit in TypedArray initialization
    }

    // 3. Construct the Buffer Layout
    // Layout: [Query Length (4 bytes)] [Query Data...] [Doc Count (4 bytes)] [Doc Data...]
    // Note: In a real WASM scenario, we might pass pointers, but here we concatenate into one buffer.
    
    const headerSize = 8; // 2 integers (4 bytes each)
    const totalBytes = headerSize + (paddedQuery.byteLength + paddedDocs.byteLength);
    
    const buffer = new ArrayBuffer(totalBytes);
    const view = new DataView(buffer);
    const floatView = new Float32Array(buffer, headerSize);

    // Write Metadata to the start of the buffer
    view.setUint32(0, paddedDim, true); // Little-endian
    view.setUint32(4, docCount, true);

    // Write Data
    floatView.set(paddedQuery, 0);
    floatView.set(paddedDocs, paddedQuery.length);

    return {
        buffer,
        queryDim: originalDim, // Return original dim so WASM knows valid data length
        docCount,
        paddedDim
    };
}
