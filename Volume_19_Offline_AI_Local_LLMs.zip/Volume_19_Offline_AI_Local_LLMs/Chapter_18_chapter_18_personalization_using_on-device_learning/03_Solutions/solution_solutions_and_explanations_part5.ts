/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

digraph OnDeviceLearning {
    rankdir=TB;
    node [shape=box, style="rounded,filled", fillcolor="#e3f2fd", fontname="Helvetica"];
    edge [color="#555555", fontname="Helvetica", fontsize=10];

    // Define Nodes
    UserInput [label="User Input", fillcolor="#fff9c4", shape=ellipse];
    LocalLLM [label="Local LLM\n(Inference)", fillcolor="#bbdefb"];
    VectorDB [label="Vector Database\n(Local)", fillcolor="#d1c4e9", shape=cylinder];
    Response [label="Response", fillcolor="#c8e6c9", shape=ellipse];
    
    Feedback [label="Feedback Loop\n(Rating/Correction)", fillcolor="#ffccbc"];
    LoRATrainer [label="LoRA Trainer\n(On-Device)", fillcolor="#ffecb3"];
    MergedModel [label="Merged Model\n(Updated Weights)", fillcolor="#b2dfdb"];

    // Define Edges (Flow)
    
    // Inference Path
    UserInput -> LocalLLM [label="1. Query"];
    VectorDB -> LocalLLM [label="Context Retrieval", style=dashed];
    LocalLLM -> Response [label="2. Generated Answer"];

    // Feedback Path
    Response -> Feedback [label="3. User Interaction"];
    Feedback -> VectorDB [label="4. Store Context/Feedback", style=dashed];
    Feedback -> LoRATrainer [label="5. Training Data"];

    // Update Path
    LoRATrainer -> MergedModel [label="6. Adapter Weights"];
    MergedModel -> LocalLLM [label="7. Update Inference Engine", style=bold];
}
