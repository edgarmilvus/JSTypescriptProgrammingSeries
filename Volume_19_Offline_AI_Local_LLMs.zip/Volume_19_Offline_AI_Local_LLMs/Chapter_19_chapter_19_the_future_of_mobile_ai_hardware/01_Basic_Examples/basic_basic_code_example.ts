/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * @fileoverview Basic On-Device LLM Inference Example
 * @description Simulates running a local LLM using ONNX Runtime Web in a browser context.
 * @requires onnxruntime-web
 * @requires zod
 */

import * as ort from 'onnxruntime-web';
import { z } from 'zod';

// ==========================================
// 1. Configuration & Validation (Zod Schema)
// ==========================================

/**
 * Schema defining the expected structure for model configuration.
 * Ensures that model paths, execution providers, and input dimensions are valid at runtime.
 */
const ModelConfigSchema = z.object({
  modelPath: z.string().url().describe("URL to the ONNX model file"),
  executionProvider: z.enum(['wasm', 'webgpu']).describe("Hardware acceleration provider"),
  maxTokens: z.number().int().positive().default(512).describe("Maximum context window size"),
});

// Infer TypeScript type from the Zod schema for type safety
type ModelConfig = z.infer<typeof ModelConfigSchema>;

// ==========================================
// 2. Generic Utility for Type Safety
// ==========================================

/**
 * A generic helper to safely cast raw inference output tensors into a structured format.
 * This ensures that the output matches the expected shape defined by the consumer.
 * 
 * @template T - The expected return type of the inference result.
 * @param {ort.Tensor} tensor - The raw output tensor from ONNX Runtime.
 * @returns {T} The parsed and casted result.
 */
function parseInferenceOutput<T>(tensor: ort.Tensor): T {
  // Under the hood: ONNX tensors are multidimensional arrays. 
  // We flatten and map them to standard JS objects for consumption.
  const data = tensor.data as Float32Array; // Assuming float32 output
  const shape = tensor.dims;
  
  // In a real scenario, we would map this to logits or token IDs.
  // Here we simulate a simple return of the raw data array wrapped in a generic object.
  return {
    data: Array.from(data),
    shape: shape,
    timestamp: Date.now(),
  } as unknown as T;
}

// ==========================================
// 3. The Core Inference Engine
// ==========================================

class LocalLLMEngine {
  private session: ort.InferenceSession | null = null;
  private config: ModelConfig;

  constructor(configInput: unknown) {
    // Validate configuration using Zod
    this.config = ModelConfigSchema.parse(configInput);
  }

  /**
   * Initializes the ONNX Runtime session.
   * This is the heaviest operation, loading the model weights into memory.
   * On mobile devices, this leverages the browser's WebAssembly or WebGPU backend.
   */
  async initialize(): Promise<void> {
    console.log(`Initializing session with provider: ${this.config.executionProvider}`);
    
    try {
      // Configure execution providers based on hardware support
      const sessionOptions: ort.InferenceSession.SessionOptions = {
        executionProviders: [this.config.executionProvider],
        graphOptimizationLevel: 'all',
      };

      // Load the model from the URL (or IndexedDB cache in a real app)
      this.session = await ort.InferenceSession.create(
        this.config.modelPath,
        sessionOptions
      );
      
      console.log("Model loaded successfully.");
    } catch (error) {
      console.error("Failed to initialize ONNX session:", error);
      throw new Error("Initialization failed");
    }
  }

  /**
   * Executes inference on a given input prompt.
   * 
   * @param prompt - The text input from the user.
   * @returns A Promise resolving to the inference result.
   */
  async runInference(prompt: string): Promise<any> {
    if (!this.session) {
      throw new Error("Session not initialized. Call initialize() first.");
    }

    // 1. Preprocessing: Tokenize input (Mocked for this example)
    // In a real app, you would use a tokenizer library to convert text to numeric IDs.
    const inputIds = new Float32Array(this.config.maxTokens).fill(0);
    // Simulate tokenizing "Hello World"
    inputIds[0] = 999; // Token ID for "Hello"
    inputIds[1] = 1000; // Token ID for "World"

    // 2. Create Input Tensors
    // ONNX Runtime expects tensors. We shape them according to the model requirements (Batch x Sequence Length).
    const inputTensor = new ort.Tensor('float32', inputIds, [1, this.config.maxTokens]);

    // 3. Prepare Feed Dictionary
    const feeds: Record<string, ort.Tensor> = {};
    // The input name 'input_ids' must match the model's input layer name.
    feeds[this.session.inputNames[0]] = inputTensor;

    // 4. Run the Session (The actual AI computation)
    // This is where the NPU/GPU/WebAssembly kicks in.
    const results = await this.session.run(feeds);

    // 5. Post-processing
    // Extract the output tensor (usually named 'logits' or 'output')
    const outputKey = this.session.outputNames[0];
    const outputTensor = results[outputKey];

    // Use our generic parser to return type-safe data
    return parseInferenceOutput<any>(outputTensor);
  }
}

// ==========================================
// 4. Usage Example (Simulated Web App Context)
// ==========================================

/**
 * Example usage in a hypothetical SaaS dashboard component.
 * This function orchestrates the loading and execution flow.
 */
export async function runLocalLlamaDemo() {
  // Configuration for a quantized Llama 3 model hosted on a CDN
  const config = {
    modelPath: "https://example-cdn.com/models/llama3-quantized.onnx", // Placeholder URL
    executionProvider: "wasm" as const, // Fallback to WebAssembly for broad compatibility
    maxTokens: 128,
  };

  const engine = new LocalLLMEngine(config);

  try {
    // Step 1: Load the model (UI should show a loading spinner here)
    await engine.initialize();

    // Step 2: Run inference
    const userPrompt = "Explain local AI in one sentence.";
    console.log(`Running inference for: "${userPrompt}"`);
    
    const result = await engine.runInference(userPrompt);
    
    // Step 3: Display result
    console.log("Inference Result:", result);
    
    // In a React/SaaS app, you would setState({ output: result.data });
    return result;

  } catch (error) {
    console.error("Demo failed:", error);
  }
}

// Uncomment to run locally (requires bundler like Vite/Webpack)
// runLocalLlamaDemo();
