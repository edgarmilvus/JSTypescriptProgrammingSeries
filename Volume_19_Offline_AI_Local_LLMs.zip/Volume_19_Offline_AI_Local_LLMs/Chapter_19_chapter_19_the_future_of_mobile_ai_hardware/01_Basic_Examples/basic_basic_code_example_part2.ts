/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.ts
// Description: Basic Code Example
// ==========================================

digraph LLM_Inference {
    rankdir=TB;
    node [shape=box, style="rounded,filled", color="#e0e0e0"];
    
    User [label="User Input\n(Text Prompt)", shape=ellipse, fillcolor="#a7c7e7"];
    Config [label="Zod Schema\nValidation", fillcolor="#c1e1c1"];
    Engine [label="LocalLLMEngine\n(ONNX Runtime)", fillcolor="#fff2cc"];
    Hardware [label="Mobile Hardware\n(NPU / GPU / CPU)", shape=component, fillcolor="#f8cecc"];
    Output [label="Structured Output\n(TypeScript Object)", shape=ellipse, fillcolor="#d5e8d4"];

    User -> Config [label="1. Validate Input"];
    Config -> Engine [label="2. Safe Config"];
    Engine -> Hardware [label="3. Execute Graph\n(WebAssembly/WebGPU)"];
    Hardware -> Engine [label="4. Raw Tensor Data"];
    Engine -> Output [label="5. Parse & Type"];
}
