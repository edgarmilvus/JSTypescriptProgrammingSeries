/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.tsx
// Description: Advanced Application Script
// ==========================================

// app/components/OfflineRAG.tsx
'use client';

import React, { useState, useRef, useEffect } from 'react';
import * as ort from 'onnxruntime-web';

// --- Types and Interfaces ---

interface Message {
  role: 'user' | 'assistant' | 'system';
  content: string;
}

interface VectorDocument {
  id: string;
  text: string;
  embedding: Float32Array;
}

// --- Configuration Constants ---

const MODEL_PATHS = {
  // In a real app, these would be local paths or cached URLs
  EMBEDDING: '/models/bge-small-1.5-quantized.onnx',
  GENERATOR: '/models/llama-3-8b-instruct-q4.onnx',
};

const SYSTEM_PROMPT = `You are a helpful AI assistant running locally on the device. 
Answer the user's question based strictly on the provided context. 
If the context is irrelevant, say you don't have enough information.`;

// --- Utility: Vector Operations ---

/**
 * Calculates the cosine similarity between two embedding vectors.
 * This is the core of the "Vector Search" logic running on-device.
 * @param a - First vector (Float32Array)
 * @param b - Second vector (Float32Array)
 * @returns Similarity score between 0 and 1
 */
function cosineSimilarity(a: Float32Array, b: Float32Array): number {
  let dotProduct = 0;
  let normA = 0;
  let normB = 0;
  for (let i = 0; i < a.length; i++) {
    dotProduct += a[i] * b[i];
    normA += a[i] * a[i];
    normB += b[i] * b[i];
  }
  return dotProduct / (Math.sqrt(normA) * Math.sqrt(normB));
}

/**
 * Generates an embedding for a given text string using the ONNX model.
 * This simulates the hardware acceleration (NPU/GPU) usage via ONNX Runtime Web.
 */
async function generateEmbedding(text: string, session: ort.InferenceSession): Promise<Float32Array> {
  // Tokenization would happen here in a real scenario. 
  // For simplicity, we assume the model handles raw strings or pre-tokenized input.
  const inputTensor = new ort.Tensor('string', [text]); // ONNX Runtime Web supports string tensors
  
  const feeds: Record<string, ort.Tensor> = {};
  feeds[session.inputNames[0]] = inputTensor;

  const results = await session.run(feeds);
  const outputName = session.outputNames[0];
  return results[outputName].data as Float32Array;
}

// --- Core Component ---

export default function OfflineRAG() {
  const [status, setStatus] = useState<string>('Idle');
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputText, setInputText] = useState<string>('');
  
  // Refs to hold ONNX sessions (avoid re-renders)
  const embeddingSession = useRef<ort.InferenceSession | null>(null);
  const generatorSession = useRef<ort.InferenceSession | null>(null);
  
  // In-memory "Vector Database"
  const vectorDb = useRef<VectorDocument[]>([]);

  // Initialize ONNX Runtime and Load Models
  useEffect(() => {
    const initModels = async () => {
      try {
        setStatus('Loading ONNX Runtime...');
        
        // Configure WebGPU execution provider for mobile hardware acceleration
        // Fallback to WASM (WebAssembly) if WebGPU is not supported
        const executionProviders: ('webgpu' | 'wasm')[] = 
          (navigator as any).gpu ? ['webgpu'] : ['wasm'];

        setStatus('Loading Embedding Model...');
        embeddingSession.current = await ort.InferenceSession.create(
          MODEL_PATHS.EMBEDDING, 
          { executionProviders }
        );

        setStatus('Loading Llama 3 Model...');
        generatorSession.current = await ort.InferenceSession.create(
          MODEL_PATHS.GENERATOR, 
          { executionProviders }
        );

        // Initialize Vector DB with sample context data
        // In a real app, this would load from IndexedDB or local storage
        await initializeVectorDb();

        setStatus('Ready (Local Mode Active)');
      } catch (error) {
        console.error('Initialization failed:', error);
        setStatus('Error loading models. Check console.');
      }
    };

    initModels();

    // Cleanup function
    return () => {
      embeddingSession.current?.release();
      generatorSession.current?.release();
    };
  }, []);

  /**
   * Populates the in-memory vector database with sample documents.
   * This demonstrates the "Vector Search" component.
   */
  const initializeVectorDb = async () => {
    if (!embeddingSession.current) return;

    const sampleDocs = [
      { id: '1', text: 'The new iPhone 15 features a titanium chassis and USB-C port.' },
      { id: '2', text: 'Apple Intelligence is a new set of AI features integrated into iOS 18.' },
      { id: '3', text: 'Llama 3 is an open-source large language model by Meta.' },
      { id: '4', text: 'On-device processing enhances privacy by keeping data local.' },
    ];

    const processedDocs: VectorDocument[] = [];

    for (const doc of sampleDocs) {
      const embedding = await generateEmbedding(doc.text, embeddingSession.current);
      processedDocs.push({ ...doc, embedding });
    }

    // Using SharedArrayBuffer concept for memory efficiency (simulated here via direct reference)
    // In a multi-threaded Web Worker setup, this buffer would be shared.
    vectorDb.current = processedDocs;
  };

  /**
   * Main Logic: Retrieves relevant context via Vector Search, then generates a response.
   */
  const handleSendMessage = async () => {
    if (!inputText.trim() || !embeddingSession.current || !generatorSession.current) return;

    const userMessage: Message = { role: 'user', content: inputText };
    setMessages(prev => [...prev, userMessage]);
    setInputText('');
    setStatus('Processing...');

    try {
      // 1. Vector Search Phase
      setStatus('Generating embedding for query...');
      const queryEmbedding = await generateEmbedding(inputText, embeddingSession.current);
      
      setStatus('Searching local vector database...');
      // Calculate similarity scores for all documents
      const scores = vectorDb.current.map(doc => ({
        doc,
        score: cosineSimilarity(queryEmbedding, doc.embedding)
      }));

      // Sort by relevance and pick top context
      scores.sort((a, b) => b.score - a.score);
      const relevantContext = scores[0].score > 0.6 ? scores[0].doc.text : null;

      // 2. LLM Generation Phase (Prompt Engineering)
      setStatus('Generating response via Llama 3...');
      
      const contextPrompt = relevantContext 
        ? `Context: ${relevantContext}\n\n` 
        : '';
      
      const fullPrompt = `${SYSTEM_PROMPT}\n\n${contextPrompt}User: ${userMessage.content}\nAssistant:`;

      // Prepare input tensor for the LLM (simplified for demo)
      // Real implementation requires tokenization and KV cache management
      const inputTensor = new ort.Tensor('string', [fullPrompt]);
      const feeds = { [generatorSession.current.inputNames[0]]: inputTensor };

      // Run inference
      const output = await generatorSession.current.run(feeds);
      const responseText = output[generatorSession.current.outputNames[0]].data as string;

      const assistantMessage: Message = { role: 'assistant', content: responseText };
      setMessages(prev => [...prev, assistantMessage]);
      setStatus('Ready');

    } catch (error) {
      console.error('Inference error:', error);
      setStatus('Error during inference');
    }
  };

  return (
    <div className="p-6 border rounded-lg shadow-sm bg-white max-w-2xl mx-auto">
      <div className="mb-4 p-3 bg-gray-100 rounded text-sm font-mono">
        Status: <span className="font-bold">{status}</span>
      </div>

      <div className="h-64 overflow-y-auto border p-4 mb-4 rounded bg-gray-50 space-y-3">
        {messages.map((msg, idx) => (
          <div key={idx} className={`p-2 rounded max-w-[80%] ${msg.role === 'user' ? 'bg-blue-100 ml-auto' : 'bg-green-100'}`}>
            <strong className="block text-xs uppercase opacity-70">{msg.role}</strong>
            {msg.content}
          </div>
        ))}
      </div>

      <div className="flex gap-2">
        <input
          type="text"
          value={inputText}
          onChange={(e) => setInputText(e.target.value)}
          placeholder="Ask about iPhone or Llama 3..."
          className="flex-1 border p-2 rounded"
          onKeyDown={(e) => e.key === 'Enter' && handleSendMessage()}
        />
        <button 
          onClick={handleSendMessage}
          disabled={status !== 'Ready'}
          className="px-4 py-2 bg-blue-600 text-white rounded disabled:bg-gray-400"
        >
          Send
        </button>
      </div>
    </div>
  );
}
