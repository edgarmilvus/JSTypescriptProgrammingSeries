/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// utils/inference.ts
import * as ort from 'onnxruntime-web';

interface ModelConfig {
  modelUrl: string;
  executionProviders: ('wasm' | 'webgpu')[];
}

/**
 * Loads an ONNX model from a URL with specific execution providers.
 * Prioritizes WebGPU for mobile NPU/GPU acceleration, falls back to WASM for CPU.
 */
export async function loadModel(config: ModelConfig): Promise<ort.InferenceSession> {
  console.log(`Loading model from: ${config.modelUrl}`);
  
  // In a real scenario, we would validate the URL and file size here.
  // For mobile, we must be careful with memory. ONNX Runtime Web handles 
  // WASM memory growth, but large models can crash tabs on low-RAM devices.
  
  try {
    const session = await ort.InferenceSession.create(
      config.modelUrl,
      {
        executionProviders: config.executionProviders,
        graphOptimizationLevel: 'all', // Optimize graph for the specific provider
        enableCpuMemArena: true, // Helps manage memory fragmentation on mobile CPUs
      }
    );
    console.log('Model loaded successfully');
    return session;
  } catch (error) {
    console.error("Failed to load model:", error);
    throw new Error("Model load failed. Check network connectivity and model URL.");
  }
}

/**
 * Simulates tokenization for a distilled Llama model.
 * In production, use a library like 'gpt-tokenizer' or 'tiktoken'.
 */
export function tokenize(text: string, contextLength: number = 128): Float32Array {
  // Simulate mapping text to integers (token IDs)
  const tokens: number[] = [];
  for (let i = 0; i < text.length; i++) {
    // Simple ASCII mapping for simulation (not a real tokenizer)
    tokens.push(text.charCodeAt(i));
  }
  
  // Pad or truncate to fixed context length
  const paddedTokens = new Float32Array(contextLength);
  for (let i = 0; i < contextLength; i++) {
    paddedTokens[i] = i < tokens.length ? tokens[i] : 0; // 0 is usually <pad> token
  }
  
  return paddedTokens;
}

/**
 * Executes inference on the loaded session.
 * Returns raw logits (probabilities) for the next token.
 */
export async function runInference(
  session: ort.InferenceSession, 
  input: Float32Array
): Promise<Float32Array> {
  const feeds: Record<string, ort.Tensor> = {};
  
  // Determine input name (usually 'input_ids' or similar)
  const inputName = session.inputNames[0];
  feeds[inputName] = new ort.Tensor('float32', input, [1, input.length]); // Shape: [batch_size, seq_length]

  const start = performance.now();
  
  // Run the session
  const results = await session.run(feeds);
  
  const end = performance.now();
  console.log(`Inference execution time: ${(end - start).toFixed(2)}ms`);

  // Extract output (assuming output name is the first one)
  const outputName = session.outputNames[0];
  const outputTensor = results[outputName] as ort.Tensor;
  
  // Return the raw data (logits)
  return outputTensor.data as Float32Array;
}

/**
 * Helper to extract top-k tokens from logits.
 */
export function getTopK(logits: Float32Array, k: number = 5): number[] {
  // Create an array of [index, value] pairs
  const scores = Array.from(logits).map((score, index) => ({ index, score }));
  
  // Sort descending
  scores.sort((a, b) => b.score - a.score);
  
  // Return top k indices
  return scores.slice(0, k).map(item => item.index);
}
