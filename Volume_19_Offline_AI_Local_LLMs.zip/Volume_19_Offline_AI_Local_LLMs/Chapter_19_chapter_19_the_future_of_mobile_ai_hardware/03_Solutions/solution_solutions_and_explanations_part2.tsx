/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.tsx
// Description: Solutions and Explanations
// ==========================================

// components/LocalVectorSearch.tsx
import React, { useState, useImperativeHandle, forwardRef } from 'react';

interface Document {
  id: string;
  text: string;
  embedding: Float32Array;
}

interface LocalVectorSearchProps {}

const LocalVectorSearch = forwardRef((props: LocalVectorSearchProps, ref) => {
  const [documents, setDocuments] = useState<Document[]>([]);
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<Document[]>([]);

  /**
   * Calculates the cosine similarity between two vectors.
   * Formula: (A . B) / (||A|| * ||B||)
   */
  const cosineSimilarity = (vecA: Float32Array, vecB: Float32Array): number => {
    if (vecA.length !== vecB.length) return 0;
    
    let dotProduct = 0;
    let normA = 0;
    let normB = 0;

    for (let i = 0; i < vecA.length; i++) {
      dotProduct += vecA[i] * vecB[i];
      normA += vecA[i] * vecA[i];
      normB += vecB[i] * vecB[i];
    }

    if (normA === 0 || normB === 0) return 0;
    return dotProduct / (Math.sqrt(normA) * Math.sqrt(normB));
  };

  /**
   * Generates a random embedding vector for simulation purposes.
   * In a real app, this would come from an embedding model (e.g., BERT).
   */
  const generateRandomEmbedding = (dimension: number = 128): Float32Array => {
    const vector = new Float32Array(dimension);
    for (let i = 0; i < dimension; i++) {
      vector[i] = Math.random();
    }
    return vector;
  };

  const handleSearch = () => {
    if (!query.trim()) return;

    // 1. Generate dummy query embedding
    const queryEmbedding = generateRandomEmbedding();

    // 2. Calculate similarity scores
    const scoredDocs = documents.map(doc => ({
      ...doc,
      score: cosineSimilarity(queryEmbedding, doc.embedding)
    }));

    // 3. Sort by score (descending)
    scoredDocs.sort((a, b) => b.score - a.score);

    // 4. Update results (take top 3 as requested)
    setResults(scoredDocs.slice(0, 3));
  };

  // Expose handleSearch to parent via ref
  useImperativeHandle(ref, () => ({
    triggerSearch: handleSearch
  }));

  const addDocument = () => {
    if (!query.trim()) return;
    const newDoc: Document = {
      id: Date.now().toString(),
      text: query,
      embedding: generateRandomEmbedding()
    };
    setDocuments(prev => [...prev, newDoc]);
    setQuery(''); // Clear input after adding
  };

  return (
    <div style={{ padding: '20px', fontFamily: 'sans-serif' }}>
      <div style={{ marginBottom: '10px' }}>
        <input 
          value={query} 
          onChange={(e) => setQuery(e.target.value)} 
          placeholder="Enter text to add or search..." 
          style={{ padding: '8px', marginRight: '8px', width: '300px' }}
        />
        <button onClick={addDocument} style={{ marginRight: '8px' }}>Add Doc</button>
        <button onClick={handleSearch}>Search</button>
      </div>
      
      <div>
        <h4>Search Results (Top 3):</h4>
        {results.length === 0 ? (
          <p>No results yet. Add documents and search.</p>
        ) : (
          <ul>
            {results.map((doc) => (
              <li key={doc.id} style={{ padding: '4px 0' }}>
                <strong>{doc.text}</strong> (Score: {doc.score.toFixed(4)})
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
});

export default LocalVectorSearch;
