/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

// hardware/configurator.ts

interface HardwareConfig {
  executionProvider: 'wasm' | 'webgpu';
  maxContextLength: number;
  batchSize: number;
  threads: number;
}

/**
 * Detects hardware capabilities and power status.
 */
export async function detectHardwareCapabilities(): Promise<{
  isMobile: boolean;
  hasWebGPU: boolean;
  isLowPower: boolean;
}> {
  const userAgent = navigator.userAgent || navigator.vendor;
  const isMobile = /android|webos|iphone|ipad|ipod|blackberry|iemobile|opera mini/i.test(userAgent.toLowerCase());

  // Feature detection for WebGPU
  const hasWebGPU = 'gpu' in navigator;

  // Battery API check (standardized in older spec, still useful if available)
  let isLowPower = false;
  if ('getBattery' in navigator) {
    try {
      const battery = await (navigator as any).getBattery();
      isLowPower = !battery.charging && battery.level < 0.2; // Low battery and not charging
    } catch (e) {
      // Silently fail if battery API is restricted
    }
  }

  return { isMobile, hasWebGPU, isLowPower };
}

/**
 * Generates configuration based on hardware detection.
 * Logic:
 * 1. If WebGPU is available, use it (fastest).
 * 2. If on mobile, reduce threads and context length to save RAM.
 * 3. If low power, drastically reduce batch size and context length.
 */
export async function adaptiveInferenceSetup(): Promise<HardwareConfig | string> {
  const caps = await detectHardwareCapabilities();
  console.log("Hardware Profile:", caps);

  // Decision Logic Flowchart Implementation
  if (caps.isLowPower) {
    // Low Power Mode: Prioritize battery life over speed
    return {
      executionProvider: 'wasm', // WASM is often more power-efficient than GPU for small batches
      maxContextLength: 64,      // Drastically reduce context
      batchSize: 1,
      threads: 1                 // Single thread to reduce CPU wake-locks
    };
  }

  if (caps.isMobile) {
    // Mobile Mode: Balance performance and memory
    if (caps.hasWebGPU) {
      return {
        executionProvider: 'webgpu',
        maxContextLength: 256,
        batchSize: 1,
        threads: 0 // 0 lets the runtime decide, usually optimal for GPU
      };
    } else {
      // Mobile without WebGPU (older browser/device)
      return {
        executionProvider: 'wasm',
        maxContextLength: 128,
        batchSize: 1,
        threads: 2 // Limit threads to prevent overheating
      };
    }
  }

  // Desktop Mode: Max performance
  return {
    executionProvider: caps.hasWebGPU ? 'webgpu' : 'wasm',
    maxContextLength: 512,
    batchSize: 4,
    threads: 4
  };
}
