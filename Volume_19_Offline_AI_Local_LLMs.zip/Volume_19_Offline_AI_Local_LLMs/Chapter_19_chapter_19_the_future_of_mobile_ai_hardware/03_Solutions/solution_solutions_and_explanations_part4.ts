/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

// hooks/useLocalCompletion.ts
import { useState } from 'react';

interface UseLocalCompletionOptions {
  api: string; // Kept for interface compatibility
}

interface UseLocalCompletionReturn {
  completion: string;
  input: string;
  isLoading: boolean;
  handleInputChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
  handleSubmit: (e: React.FormEvent<HTMLFormElement>) => void;
}

// Mock local inference function (simulating Exercise 1 logic)
const mockLocalInference = async (prompt: string): Promise<string> => {
  // Simulate network/processing delay
  await new Promise(resolve => setTimeout(resolve, 500));
  
  // Return a static response for demonstration
  return `This is a simulated local response to: "${prompt}". Running entirely in the browser!`;
};

export function useLocalCompletion(options: UseLocalCompletionOptions): UseLocalCompletionReturn {
  const [completion, setCompletion] = useState('');
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setInput(e.target.value);
  };

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!input.trim()) return;

    setIsLoading(true);
    setCompletion(''); // Clear previous completion

    try {
      // 1. Run local inference (or mock)
      const fullResponse = await mockLocalInference(input);

      // 2. Simulate Streaming
      // We use setTimeout to chunk the text update, mimicking how 
      // server-sent events (SSE) would arrive over time.
      let index = 0;
      const streamInterval = setInterval(() => {
        setCompletion((prev) => prev + fullResponse.charAt(index));
        index++;
        
        if (index >= fullResponse.length) {
          clearInterval(streamInterval);
          setIsLoading(false);
        }
      }, 50); // Update every 50ms for visual effect
    } catch (error) {
      console.error("Local inference failed:", error);
      setCompletion("Error generating response.");
      setIsLoading(false);
    }
  };

  return {
    completion,
    input,
    isLoading,
    handleInputChange,
    handleSubmit,
  };
}
