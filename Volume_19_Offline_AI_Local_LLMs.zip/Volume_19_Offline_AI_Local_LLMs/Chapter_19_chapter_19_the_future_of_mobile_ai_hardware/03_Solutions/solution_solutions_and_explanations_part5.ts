/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

// memory/manager.ts

export interface Message {
  role: 'system' | 'user' | 'assistant';
  content: string;
}

export interface ContextWindow {
  maxTokens: number;
  history: Message[];
}

/**
 * Simulates token counting (usually 4 chars ≈ 1 token).
 * Truncates history using a sliding window approach.
 */
export function truncateContext(window: ContextWindow): Message[] {
  // 1. Estimate tokens (simplified: 4 chars = 1 token)
  const estimateTokens = (msg: Message) => Math.ceil(msg.content.length / 4);
  
  let totalTokens = window.history.reduce((sum, msg) => sum + estimateTokens(msg), 0);

  // 2. If within limit, return as is
  if (totalTokens <= window.maxTokens) {
    return window.history;
  }

  // 3. Sliding Window Logic
  const newHistory: Message[] = [];
  let systemPrompt: Message | null = null;

  // Separate system prompt if exists (it should be preserved)
  if (window.history.length > 0 && window.history[0].role === 'system') {
    systemPrompt = window.history[0];
    newHistory.push(systemPrompt);
    totalTokens -= estimateTokens(systemPrompt);
  }

  // Get the rest of the messages (excluding system prompt)
  const conversation = systemPrompt ? window.history.slice(1) : window.history;
  
  // We want to keep the most recent messages (end of array)
  // Iterate backwards
  let currentTokens = 0;
  const keptMessages: Message[] = [];

  for (let i = conversation.length - 1; i >= 0; i--) {
    const msg = conversation[i];
    const tokens = estimateTokens(msg);
    
    if (currentTokens + tokens <= window.maxTokens - (systemPrompt ? estimateTokens(systemPrompt) : 0)) {
      keptMessages.unshift(msg); // Add to beginning to maintain order
      currentTokens += tokens;
    } else {
      break; // Stop when we hit the limit
    }
  }

  // Combine preserved system prompt with truncated conversation
  return systemPrompt ? [systemPrompt, ...keptMessages] : keptMessages;
}

export class ModelSessionManager {
  // private session: ort.InferenceSession | null = null;

  constructor() {}

  /**
   * Explicitly releases resources.
   * In a real ONNX Runtime implementation, we would call session.release().
   */
  dispose(): void {
    console.log("Releasing model session and clearing caches...");
    // if (this.session) {
    //   this.session.release();
    //   this.session = null;
    // }
    // Clear any global caches or buffers here
  }
}

/**
 * Hook to simulate memory warnings.
 * In a real scenario, this might hook into 'beforeunload' or specific low-memory events.
 */
export function useMemoryWarning() {
  const [isMemoryCritical, setIsMemoryCritical] = React.useState(false);

  // Simulate a check (e.g., if context length > 500 tokens)
  const checkMemory = (currentLength: number) => {
    if (currentLength > 500) { // Arbitrary threshold for simulation
      setIsMemoryCritical(true);
    }
  };

  const clearContext = (resetCallback: () => void) => {
    setIsMemoryCritical(false);
    resetCallback(); // Clears the history in the parent component
  };

  return { isMemoryCritical, checkMemory, clearContext };
}
