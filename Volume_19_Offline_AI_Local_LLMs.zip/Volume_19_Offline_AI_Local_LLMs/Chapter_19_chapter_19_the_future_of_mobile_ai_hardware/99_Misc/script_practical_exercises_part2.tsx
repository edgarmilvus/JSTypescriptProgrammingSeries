/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: script_practical_exercises_part2.tsx
// Description: Practical Exercises
// ==========================================

// components/LocalVectorSearch.tsx
import React, { useState, useImperativeHandle, forwardRef } from 'react';

interface Document {
  id: string;
  text: string;
  embedding: Float32Array; // Simulated embedding (e.g., 128 dimensions)
}

interface LocalVectorSearchProps {}

const LocalVectorSearch = forwardRef((props: LocalVectorSearchProps, ref) => {
  const [documents, setDocuments] = useState<Document[]>([]);
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<Document[]>([]);

  // TODO: Implement cosineSimilarity function
  const cosineSimilarity = (vecA: Float32Array, vecB: Float32Array): number => {
    // Calculate dot product and magnitudes
    return 0.0; // Placeholder
  };

  // TODO: Implement the search logic
  const handleSearch = () => {
    // 1. Generate dummy query embedding (random Float32Array)
    // 2. Compare against all 'documents' state
    // 3. Sort by similarity score
    // 4. Update 'results' state
  };

  // TODO: Expose handleSearch to parent via ref
  useImperativeHandle(ref, () => ({
    triggerSearch: handleSearch
  }));

  return (
    <div>
      <input 
        value={query} 
        onChange={(e) => setQuery(e.target.value)} 
        placeholder="Enter search query..." 
      />
      <button onClick={handleSearch}>Search</button>
      <ul>
        {results.map((doc) => (
          <li key={doc.id}>{doc.text}</li>
        ))}
      </ul>
    </div>
  );
});

export default LocalVectorSearch;
