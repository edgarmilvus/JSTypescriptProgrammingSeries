/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * @fileoverview A minimal example of enforcing JSON Schema output
 * from an offline LLM to ensure structured, parseable responses.
 */

// 1. Define the TypeScript Interface (The "Schema")
// This represents the strict structure we expect from the LLM.
interface ChatResponse {
  reasoning: string; // The model's internal thought process
  answer: string;    // The final response to the user
  confidence: number; // A score between 0 and 1
}

/**
 * 2. The System Prompt Template
 * In a local LLM setup, we don't have a backend API to handle JSON modes.
 * We must inject the schema definition directly into the prompt.
 * This instructs the model to output ONLY valid JSON matching the structure.
 */
const SYSTEM_PROMPT = `
You are a helpful assistant. You must respond ONLY with a valid JSON object.
Do not include any text before or after the JSON.
The JSON must strictly adhere to the following schema:

{
  "reasoning": "string",
  "answer": "string",
  "confidence": "number"
}

Example valid output:
{
  "reasoning": "The user is asking for a greeting.",
  "answer": "Hello! How can I help you?",
  "confidence": 0.95
}
`;

/**
 * 3. Mock Local LLM Inference
 * In a real app, this function would interface with ONNX Runtime Web
 * or a WebAssembly build of Llama 3. Here, we simulate the model's
 * output to demonstrate the parsing logic.
 */
async function callLocalLLM(userInput: string): Promise<string> {
  // Simulate network/model latency
  await new Promise((resolve) => setTimeout(resolve, 100));

  // Simulate the LLM generating a response based on the SYSTEM_PROMPT
  // Note: Real LLMs might still add whitespace or newlines, so we trim.
  const mockResponse: ChatResponse = {
    reasoning: "The user wants a simple greeting.",
    answer: "Hello! I am running locally on your device.",
    confidence: 0.98,
  };

  return JSON.stringify(mockResponse);
}

/**
 * 4. The Parser and Validator
 * This is the critical safety layer. We attempt to parse the string
 * into the defined interface. If parsing fails, we handle the error gracefully.
 */
function parseLLMResponse(
  rawJsonString: string
): ChatResponse | { error: string } {
  try {
    // Remove potential markdown code blocks (common in LLM outputs)
    const sanitized = rawJsonString
      .replace(/