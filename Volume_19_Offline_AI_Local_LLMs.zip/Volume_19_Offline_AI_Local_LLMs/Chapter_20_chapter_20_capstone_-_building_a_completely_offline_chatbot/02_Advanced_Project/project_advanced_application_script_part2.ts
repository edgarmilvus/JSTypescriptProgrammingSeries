/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script_part2.ts
// Description: Advanced Application Script
// ==========================================

// File: lib/db/vectorStore.ts
/**
 * @description A lightweight, in-memory vector store for the browser.
 * Uses cosine similarity to find relevant context from previous chats.
 * In production, this would be backed by IndexedDB for persistence.
 */
export class LocalVectorStore {
  private store: Map<string, number[]> = new Map();

  /**
   * @description Converts text to a vector embedding (mocked for this example).
   * In a real app, use a local embedding model (e.g., 'Xenova/all-MiniLM-L6-v2').
   */
  private async embed(text: string): Promise<number[]> {
    // Placeholder: A real implementation would run a tokenizer and model here.
    // For demo purposes, we generate a deterministic hash-like vector.
    const hash = text.split('').reduce((acc, char) => acc + char.charCodeAt(0), 0);
    return Array.from({ length: 384 }, (_, i) => Math.sin(hash + i * 0.1));
  }

  /**
   * @description Adds a message to the vector store.
   * @param id - Unique ID for the message.
   * @param text - The text content.
   */
  async add(id: string, text: string) {
    const vector = await this.embed(text);
    this.store.set(id, vector);
  }

  /**
   * @description Retrieves the top k most similar vectors.
   * @param query - The user's current query.
   * @param k - Number of results to return.
   */
  async search(query: string, k: number = 3): Promise<string[]> {
    const queryVector = await this.embed(query);
    const scores: { id: string; score: number }[] = [];

    // Calculate Cosine Similarity
    this.store.forEach((vec, id) => {
      const dotProduct = queryVector.reduce((sum, q, i) => sum + q * vec[i], 0);
      const magA = Math.sqrt(queryVector.reduce((sum, q) => sum + q * q, 0));
      const magB = Math.sqrt(vec.reduce((sum, v) => sum + v * v, 0));
      const score = dotProduct / (magA * magB);
      scores.push({ id, score });
    });

    // Sort by score descending
    scores.sort((a, b) => b.score - a.score);
    
    // Return text content (mocked retrieval - in real app, we'd map ID to text)
    return scores.slice(0, k).map(s => `Context[${s.id}]: Retrieved memory snippet.`);
  }
}

export const vectorStore = new LocalVectorStore();
