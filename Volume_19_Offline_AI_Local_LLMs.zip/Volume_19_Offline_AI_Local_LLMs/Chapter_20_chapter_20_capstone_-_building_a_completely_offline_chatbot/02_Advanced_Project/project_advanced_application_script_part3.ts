/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script_part3.ts
// Description: Advanced Application Script
// ==========================================

// File: app/chat/page.tsx
"use client";

import { useChat } from 'ai/react';
import { useEffect, useRef } from 'react';
import { useLocalLLM } from '@/lib/hooks/useLocalLLM';
import { vectorStore } from '@/lib/db/vectorStore';

export default function OfflineChat() {
  // 1. Initialize Vercel AI SDK hook for UI state management
  const { messages, input, handleInputChange, handleSubmit, isLoading, append } = useChat({
    api: '/api/chat', // This endpoint is mocked; we will bypass it in handleLocalSubmit
  });

  // 2. Initialize Local LLM Hook
  const { loadModel, generate, isLoading: modelLoading } = useLocalLLM();
  
  // 3. Track initialization
  const isInitialized = useRef(false);

  useEffect(() => {
    if (!isInitialized.current) {
      // Pre-load the model in the background when the component mounts
      loadModel();
      isInitialized.current = true;
    }
  }, [loadModel]);

  /**
   * @description Custom handler to bypass the default API route.
   * This intercepts the submission, performs local RAG (Retrieval Augmented Generation),
   * and streams the response back into the useChat state.
   */
  const handleLocalSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!input.trim()) return;

    // 1. Add user message to UI immediately
    const userMessageId = `msg-${Date.now()}`;
    await append({ role: 'user', content: input }, { options: { body: { id: userMessageId } } });

    // 2. Perform Local Vector Search (RAG)
    // We search the history for relevant context before generating
    const context = await vectorStore.search(input);
    
    // 3. Store current input for future retrieval
    await vectorStore.add(userMessageId, input);

    // 4. Start Local Inference
    // Since useChat expects a stream, we simulate a stream manually
    // or use a library that supports streaming from local generators.
    // For this example, we update the UI once the local generation finishes.
    
    try {
      // Generate response using local model + context
      const responseText = await generate(input, context);
      
      // Append the AI response to the UI
      await append({ role: 'assistant', content: responseText });
      
      // Store the AI response for future context
      const aiMessageId = `msg-${Date.now()}-ai`;
      await vectorStore.add(aiMessageId, responseText);

    } catch (error) {
      console.error("Local Inference Error:", error);
      await append({ role: 'assistant', content: "Error: Local model failed to generate." });
    }
  };

  return (
    <div className="flex flex-col h-screen max-w-2xl mx-auto p-4 bg-gray-50">
      <header className="p-4 bg-white shadow-sm rounded-lg mb-4 flex justify-between items-center">
        <h1 className="text-xl font-bold text-gray-800">Offline AI Chat</h1>
        <span className={`text-xs px-2 py-1 rounded ${modelLoading ? 'bg-yellow-100 text-yellow-800' : 'bg-green-100 text-green-800'}`}>
          {modelLoading ? 'Loading Model...' : 'Ready (Offline)'}
        </span>
      </header>

      <div className="flex-1 overflow-y-auto space-y-4 p-2">
        {messages.map((msg) => (
          <div key={msg.id} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
            <div 
              className={`max-w-[80%] p-3 rounded-lg ${msg.role === 'user' ? 'bg-blue-600 text-white' : 'bg-white border border-gray-200 text-gray-800'}`}
            >
              <p className="text-sm whitespace-pre-wrap">{msg.content}</p>
            </div>
          </div>
        ))}
        {isLoading && (
          <div className="flex justify-start">
            <div className="bg-gray-200 text-gray-800 p-3 rounded-lg animate-pulse">
              Thinking...
            </div>
          </div>
        )}
      </div>

      <form onSubmit={handleLocalSubmit} className="mt-4 flex gap-2">
        <input
          type="text"
          value={input}
          onChange={handleInputChange}
          placeholder="Type a message... (e.g., 'What is the capital of France?')"
          className="flex-1 p-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
          disabled={modelLoading}
        />
        <button
          type="submit"
          disabled={modelLoading || !input.trim()}
          className="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:bg-gray-300 disabled:cursor-not-allowed"
        >
          Send
        </button>
      </form>
    </div>
  );
}
