/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

import { useState, useRef, useCallback } from 'react';

// 1. Type Definitions
interface Message {
  role: 'user' | 'assistant' | 'system';
  content: string;
}

interface UseLocalLLMProps {
  systemPrompt?: string;
}

interface UseLocalLLMReturn {
  messages: Message[];
  input: string;
  handleInputChange: (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => void;
  isLoading: boolean;
  error: string | null;
  sendMessage: (userInput?: string) => Promise<void>;
  setSystemPrompt: (prompt: string) => void;
}

// 2. The Hook
export const useLocalLLM = ({ 
  systemPrompt = "You are a helpful assistant." 
}: UseLocalLLMProps = {}): UseLocalLLMReturn => {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  
  // Store current system prompt in a ref to allow updates without triggering re-renders 
  // or clearing history when the prompt changes.
  const currentSystemPrompt = useRef(systemPrompt);

  const handleInputChange = useCallback((e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setInput(e.target.value);
  }, []);

  const setSystemPrompt = useCallback((prompt: string) => {
    currentSystemPrompt.current = prompt;
  }, []);

  const sendMessage = useCallback(async (userInput?: string) => {
    const text = userInput || input;
    if (!text.trim()) return;

    setError(null);
    setIsLoading(true);

    // Prepare the conversation history
    // We construct the payload dynamically to include the current system prompt
    const history: Message[] = [
      { role: 'system', content: currentSystemPrompt.current },
      ...messages,
      { role: 'user', content: text }
    ];

    // Optimistically add user message to UI
    const userMessage: Message = { role: 'user', content: text };
    const tempAssistantMessage: Message = { role: 'assistant', content: '' };
    
    setMessages(prev => [...prev, userMessage, tempAssistantMessage]);
    setInput(''); // Clear input immediately

    try {
      const response = await fetch('http://localhost:3000/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ messages: history }),
      });

      if (!response.body) {
        throw new Error('No response body received');
      }

      const reader = response.body.getReader();
      const decoder = new TextDecoder();
      let accumulatedContent = '';

      // Read the stream
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        const chunk = decoder.decode(value, { stream: true });
        accumulatedContent += chunk;

        // Update the specific assistant message in state
        setMessages(prev => {
          const newMessages = [...prev];
          // The last message is the one we are currently filling
          newMessages[newMessages.length - 1] = {
            role: 'assistant',
            content: accumulatedContent
          };
          return newMessages;
        });
      }

    } catch (err) {
      setError(err instanceof Error ? err.message : 'An unknown error occurred');
      // Rollback the temporary assistant message on error
      setMessages(prev => prev.slice(0, -1));
    } finally {
      setIsLoading(false);
    }
  }, [input, messages]);

  return {
    messages,
    input,
    handleInputChange,
    isLoading,
    error,
    sendMessage,
    setSystemPrompt,
  };
};

// 3. Example UI Component Usage
/*
export const ChatUI = () => {
  const [activePrompt, setActivePrompt] = useState("You are a helpful assistant.");
  const { messages, input, handleInputChange, sendMessage, isLoading, setSystemPrompt } = useLocalLLM({ 
    systemPrompt: activePrompt 
  });

  const handlePromptChange = (prompt: string) => {
    setActivePrompt(prompt);
    setSystemPrompt(prompt); // Updates the ref inside the hook
  };

  return (
    <div>
      <div>
        <button onClick={() => handlePromptChange("You are a helpful assistant.")}>Helpful</button>
        <button onClick={() => handlePromptChange("You are a concise technical expert.")}>Technical</button>
        <button onClick={() => handlePromptChange("You are a creative storyteller.")}>Creative</button>
      </div>
      
      <div className="chat-window">
        {messages.map((m, i) => (
          <div key={i} className={`message ${m.role}`}>
            <strong>{m.role.toUpperCase()}:</strong> {m.content}
          </div>
        ))}
        {isLoading && <div>Typing...</div>}
      </div>

      <input 
        value={input} 
        onChange={handleInputChange} 
        disabled={isLoading}
        onKeyDown={(e) => e.key === 'Enter' && sendMessage()}
      />
      <button onClick={() => sendMessage()} disabled={isLoading}>Send</button>
    </div>
  );
};
*/
