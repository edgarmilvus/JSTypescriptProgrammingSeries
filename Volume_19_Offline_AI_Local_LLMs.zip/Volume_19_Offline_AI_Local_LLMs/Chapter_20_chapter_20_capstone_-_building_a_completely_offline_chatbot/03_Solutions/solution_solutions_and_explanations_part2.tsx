/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.tsx
// Description: Solutions and Explanations
// ==========================================

// --- service-worker.ts (Simplified Logic) ---

const CACHE_NAME = 'llm-model-cache-v1.0.0';
const MODEL_URLS = [
  '/models/llama-3-8b-q4.gguf',
  '/models/tokenizer.json'
];

self.addEventListener('install', (event: ExtendableEvent) => {
  // Force immediate activation for updates
  self.skipWaiting();
});

self.addEventListener('activate', (event: ExtendableEvent) => {
  // Clean up old caches
  event.waitUntil(
    caches.keys().then((cacheNames) => {
      return Promise.all(
        cacheNames
          .filter((name) => name !== CACHE_NAME)
          .map((name) => caches.delete(name))
      );
    })
  );
});

self.addEventListener('fetch', (event: FetchEvent) => {
  const url = new URL(event.request.url);

  // 1. Cache-First Strategy for Model Assets
  if (MODEL_URLS.some((path) => url.pathname.includes(path))) {
    event.respondWith(
      caches.match(event.request).then((cachedResponse) => {
        if (cachedResponse) {
          return cachedResponse; // Serve from cache immediately
        }
        // If not in cache, fetch, cache it, then return it
        return fetch(event.request).then((response) => {
          const responseClone = response.clone();
          caches.open(CACHE_NAME).then((cache) => {
            cache.put(event.request, responseClone);
          });
          return response;
        });
      })
    );
    return;
  }

  // 2. Network-First Strategy with Offline Fallback for App Shell
  if (event.request.mode === 'navigate') {
    event.respondWith(
      fetch(event.request).catch(() => {
        // If network fails, try to serve the offline page from cache
        return caches.match('/offline.html');
      })
    );
  }
});

// --- ModelManager Component (React/TSX) ---

import React, { useState, useEffect } from 'react';

interface CacheStorageEstimate {
  quota?: number;
  usage?: number;
}

export const ModelManager: React.FC = () => {
  const [status, setStatus] = useState<string>('Checking cache...');
  const [storageInfo, setStorageInfo] = useState<CacheStorageEstimate>({});
  const CACHE_NAME = 'llm-model-cache-v1.0.0';

  useEffect(() => {
    checkCacheStatus();
    getStorageInfo();
  }, []);

  const checkCacheStatus = async () => {
    if ('caches' in window) {
      const cacheNames = await caches.keys();
      if (cacheNames.includes(CACHE_NAME)) {
        setStatus(`Model cached (${CACHE_NAME})`);
      } else {
        setStatus('Model not cached');
      }
    }
  };

  const getStorageInfo = async () => {
    if ('storage' in navigator && 'estimate' in navigator.storage) {
      const estimate = await navigator.storage.estimate();
      setStorageInfo(estimate);
    }
  };

  const precacheModel = async () => {
    setStatus('Downloading model...');
    try {
      // In a real app, this might trigger a background sync or direct fetch
      // Here we simulate the Service Worker fetching the assets
      await fetch('/models/llama-3-8b-q4.gguf'); 
      await fetch('/models/tokenizer.json');
      await checkCacheStatus();
      await getStorageInfo();
    } catch (e) {
      setStatus('Error caching model');
    }
  };

  const clearCache = async () => {
    if ('caches' in window) {
      await caches.delete(CACHE_NAME);
      setStatus('Model cleared');
      await getStorageInfo();
    }
  };

  const formatSize = (bytes?: number) => {
    if (!bytes) return '0 MB';
    return (bytes / (1024 * 1024)).toFixed(2) + ' MB';
  };

  return (
    <div style={{ border: '1px solid #ccc', padding: '1rem', borderRadius: '8px' }}>
      <h3>Model Manager</h3>
      <p><strong>Status:</strong> {status}</p>
      
      <div style={{ marginBottom: '1rem' }}>
        <button onClick={precacheModel} style={{ marginRight: '8px' }}>
          Pre-cache Model
        </button>
        <button onClick={clearCache}>Clear Cache</button>
      </div>

      <div style={{ fontSize: '0.9em', color: '#555' }}>
        <p>Storage Used: {formatSize(storageInfo.usage)}</p>
        <p>Quota: {formatSize(storageInfo.quota)}</p>
      </div>
    </div>
  );
};
