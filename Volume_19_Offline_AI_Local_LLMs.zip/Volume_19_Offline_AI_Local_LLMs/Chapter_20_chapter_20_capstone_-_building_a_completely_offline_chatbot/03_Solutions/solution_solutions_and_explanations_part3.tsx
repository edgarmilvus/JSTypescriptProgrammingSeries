/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

import { z } from 'zod';

// 1. Define the Zod Schema
const ToolCallSchema = z.object({
  toolName: z.string(),
  parameters: z.record(z.string(), z.any())
});

// Support for an array of tool calls (Interactive Challenge)
const ToolCallArraySchema = z.array(ToolCallSchema);

// Type inference
type ToolCall = z.infer<typeof ToolCallSchema>;

// 2. The Parsing Function
export function parseToolCalls(llmResponse: string): ToolCall[] {
  try {
    // Attempt to extract JSON from the response (handles potential markdown formatting)
    const jsonMatch = llmResponse.match(/\[[\s\S]*\]|\{[\s\S]*\}/);
    if (!jsonMatch) {
      throw new Error('No JSON object found in response');
    }

    const parsed = JSON.parse(jsonMatch[0]);
    
    // Validate against the schema (handles single object or array)
    let result;
    if (Array.isArray(parsed)) {
      result = ToolCallArraySchema.parse(parsed);
    } else {
      result = [ToolCallSchema.parse(parsed)]; // Normalize to array
    }
    
    return result;
  } catch (error) {
    if (error instanceof z.ZodError) {
      console.error('Validation errors:', error.errors);
      throw new Error(`Response did not match schema: ${error.message}`);
    }
    throw error;
  }
}

// 3. Integration: Weather Tool Component
import React, { useState } from 'react';

// Mock Data
const WEATHER_DATA: Record<string, string> = {
  'Tokyo': 'Sunny, 25°C',
  'Paris': 'Cloudy, 18°C',
  'London': 'Rainy, 15°C'
};

export const WeatherTool: React.FC = () => {
  const [results, setResults] = useState<string[]>([]);
  const [input, setInput] = useState('');

  // Simulate LLM Response based on input
  const simulateLLMCall = async (userText: string) => {
    // In a real app, this would call the local LLM with specific prompting
    // Here we simulate the LLM generating the correct JSON structure
    
    let mockResponse = '';
    if (userText.includes('Tokyo') && userText.includes('Paris')) {
      // Interactive Challenge: Multiple tool calls
      mockResponse = JSON.stringify([
        { toolName: "getWeather", parameters: { location: "Tokyo" } },
        { toolName: "getWeather", parameters: { location: "Paris" } }
      ]);
    } else if (userText.includes('Tokyo')) {
      mockResponse = JSON.stringify({ toolName: "getWeather", parameters: { location: "Tokyo" } });
    } else {
      return ["I don't understand the location."];
    }

    // Parse and Execute
    try {
      const toolCalls = parseToolCalls(mockResponse);
      const outputs = toolCalls.map(call => {
        if (call.toolName === 'getWeather') {
          const loc = call.parameters.location;
          return `Weather in ${loc}: ${WEATHER_DATA[loc] || 'Unknown'}`;
        }
        return 'Unknown tool';
      });
      return outputs;
    } catch (e) {
      return [`Error: ${(e as Error).message}`];
    }
  };

  const handleSubmit = async () => {
    setResults(['Loading...']);
    const outputs = await simulateLLMCall(input);
    setResults(outputs);
  };

  return (
    <div style={{ border: '1px solid #ddd', padding: '1rem', marginTop: '1rem' }}>
      <h4>Weather Tool Interface</h4>
      <input 
        value={input} 
        onChange={(e) => setInput(e.target.value)}
        placeholder="Ask about weather (e.g., Tokyo and Paris)"
        style={{ width: '80%', marginRight: '8px' }}
      />
      <button onClick={handleSubmit}>Ask LLM</button>
      
      <div style={{ marginTop: '1rem', background: '#f9f9f9', padding: '10px' }}>
        <strong>Results:</strong>
        <ul>
          {results.map((r, i) => <li key={i}>{r}</li>)}
        </ul>
      </div>
    </div>
  );
};
