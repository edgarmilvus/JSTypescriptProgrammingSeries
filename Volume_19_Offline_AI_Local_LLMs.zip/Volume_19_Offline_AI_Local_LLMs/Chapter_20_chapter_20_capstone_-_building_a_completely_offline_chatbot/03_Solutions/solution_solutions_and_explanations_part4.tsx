/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState, useEffect, useCallback } from 'react';

// 1. Mock Vector DB Interface
// In a real app, this would wrap something like `vector-db-wasm` or `localforage` with embeddings.
interface MemoryEntry {
  id: string;
  content: string;
  embeddingPreview: number[]; // Simplified for UI
}

const mockVectorDB = {
  memories: [] as MemoryEntry[],
  
  add: async (text: string): Promise<void> => {
    return new Promise(resolve => {
      // Simulate async embedding generation
      const embedding = Array.from({ length: 10 }, () => Math.random());
      mockVectorDB.memories.push({
        id: Date.now().toString(),
        content: text,
        embeddingPreview: embedding
      });
      setTimeout(resolve, 200);
    });
  },

  query: async (text: string, k: number): Promise<MemoryEntry[]> => {
    return new Promise(resolve => {
      // Simulate semantic search (random for demo purposes)
      // In reality, this would calculate cosine similarity
      const results = mockVectorDB.memories
        .sort(() => 0.5 - Math.random()) // Random shuffle for simulation
        .slice(0, k);
      setTimeout(() => resolve(results), 300);
    });
  }
};

// 2. SemanticMemoryManager Component
export const SemanticMemoryManager: React.FC = () => {
  const [memories, setMemories] = useState<MemoryEntry[]>([]);
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<MemoryEntry[]>([]);
  const [loading, setLoading] = useState(false);

  const refreshMemories = useCallback(async () => {
    // In a real app, this would fetch all keys from DB
    // Here we access the mock store directly
    setMemories([...mockVectorDB.memories]);
  }, []);

  useEffect(() => {
    refreshMemories();
  }, [refreshMemories]);

  const handleAddMemory = async () => {
    if (!query.trim()) return;
    setLoading(true);
    await mockVectorDB.add(query);
    setQuery('');
    await refreshMemories();
    setLoading(false);
  };

  const handleQuery = async () => {
    if (!query.trim()) return;
    setLoading(true);
    const k = 3;
    const found = await mockVectorDB.query(query, k);
    setResults(found);
    setLoading(false);
  };

  return (
    <div style={{ border: '1px solid #ccc', padding: '1rem', margin: '1rem 0' }}>
      <h3>Semantic Memory Manager</h3>
      
      <div style={{ display: 'flex', gap: '10px', marginBottom: '1rem' }}>
        <input 
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Add memory or query..."
          style={{ flex: 1 }}
        />
        <button onClick={handleAddMemory} disabled={loading}>Add</button>
        <button onClick={handleQuery} disabled={loading}>Query</button>
      </div>

      <div style={{ display: 'flex', gap: '20px' }}>
        <div style={{ flex: 1 }}>
          <h4>Stored Memories</h4>
          <ul style={{ maxHeight: '150px', overflowY: 'auto', border: '1px solid #eee', padding: '5px' }}>
            {memories.map(m => (
              <li key={m.id} style={{ fontSize: '0.9em', marginBottom: '5px' }}>
                {m.content}
              </li>
            ))}
          </ul>
        </div>
        
        <div style={{ flex: 1 }}>
          <h4>Query Results (Top 3)</h4>
          <ul style={{ maxHeight: '150px', overflowY: 'auto', border: '1px solid #eee', padding: '5px' }}>
            {results.map(m => (
              <li key={m.id} style={{ fontSize: '0.9em', marginBottom: '5px', color: 'blue' }}>
                {m.content}
              </li>
            ))}
          </ul>
        </div>
      </div>
    </div>
  );
};

// 3. Integration with Chat (Conceptual Wrapper)
export const EnhancedChatWrapper: React.FC = () => {
  // This component wraps the ChatUI from Exercise 1 and injects memory logic
  // Note: For brevity, this is a conceptual integration pattern
  
  const handleSendMessage = async (text: string) => {
    // 1. Query Vector DB
    const relevantMemories = await mockVectorDB.query(text, 2);
    const context = relevantMemories.map(m => m.content).join('\n');
    
    // 2. Construct Augmented Prompt
    const systemPrompt = `Context:\n${context}\n\nYou are a helpful assistant.`;
    
    // 3. Send to LLM (using the hook from Ex 1)
    // ... call useLocalLLM.sendMessage(text) with the new systemPrompt ...
    
    // 4. Save Response
    // Assuming we get 'responseText' back from LLM
    // await mockVectorDB.add(text); // Save user query
    // await mockVectorDB.add(responseText); // Save response
  };

  return (
    <div>
      <SemanticMemoryManager />
      {/* <ChatUI /> would go here, configured with handleSendMessage */}
      <p><em>(ChatUI integration logic shown in code comments)</em></p>
    </div>
  );
};
