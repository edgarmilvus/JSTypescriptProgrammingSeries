/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

digraph OfflineChatbotArchitecture {
    rankdir=TB;
    node [fontname="Arial", shape=box, style="rounded,filled", color="#4A90E2", fillcolor="#E6F3FF"];
    edge [fontname="Arial", fontsize=10];

    // Subgraph for User Interface Layer
    subgraph cluster_ui {
        label = "Frontend (React App)";
        style = "dashed";
        color = "#777";
        
        UI [label = "User Interface\n(Chat Window)", shape=component];
        State [label = "Browser State\n(LocalStorage/Redux)", fillcolor="#FFFACD"];
        Hook [label = "useLocalLLM Hook", fillcolor="#D1E8FF"];
    }

    // Subgraph for Storage Layer
    subgraph cluster_storage {
        label = "Local Storage";
        style = "dashed";
        color = "#777";

        Cache [label = "Cache Storage\n(Model Weights)", shape=database, fillcolor="#E0FFE0"];
        VectorDB [label = "Local Vector DB\n(IndexedDB)", shape=database, fillcolor="#E0FFE0"];
    }

    // Subgraph for Backend/Compute Layer
    subgraph cluster_backend {
        label = "Local Compute";
        style = "dashed";
        color = "#777";

        SW [label = "Service Worker", shape=component, fillcolor="#FFDAB9"];
        LLM_Endpoint [label = "Local LLM Endpoint\n(Web Worker/Server)", shape=component, fillcolor="#D8BFD8"];
    }

    // --- Data Flow (Standard Chat) ---
    
    // 1. User Input Flow
    UI -> Hook [label = "User Message"];
    Hook -> State [label = "Update UI State"];
    
    // 2. LLM Request Flow
    Hook -> LLM_Endpoint [label = "POST /api/chat\n(History + Prompt)"];
    
    // 3. Model Loading Flow
    LLM_Endpoint -> SW [label = "Fetch Model Assets"];
    SW -> Cache [label = "Cache-First Lookup"];
    
    // 4. Response Stream Flow
    LLM_Endpoint -> Hook [label = "Streamed Text Chunks"];
    Hook -> UI [label = "Update Message Stream"];
    Hook -> State [label = "Persist History"];

    // --- Semantic Memory Integration (Interactive Challenge) ---

    // 5. Retrieval Flow (Context Augmentation)
    // When user sends a message, the hook queries the DB before calling the LLM
    Hook -> VectorDB [label = "Query (Top K Memories)", color="green", style="dashed"];
    VectorDB -> Hook [label = "Retrieved Context", color="green", style="dashed"];
    
    // 6. Storage Flow (Learning Loop)
    // After LLM responds, the interaction is saved back to the DB
    LLM_Endpoint -> VectorDB [label = "Store Interaction\n(User + Response)", color="purple", style="dashed"];

    // Styling adjustments for specific nodes
    Cache [shape=database];
    VectorDB [shape=database];
}
