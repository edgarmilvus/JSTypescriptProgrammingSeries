/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

/**
 * @file runtime-validation-example.ts
 * @description A self-contained example demonstrating runtime validation using Zod
 *              to validate incoming data in a Node.js environment (V8 engine).
 * @context SaaS Backend API Endpoint
 */

// 1. Import the Zod library
// Zod is a schema validation library that works at runtime.
// It leverages TypeScript generics to infer static types from schemas.
import { z } from 'zod';

// 2. Define the Runtime Schema
// We define the structure of the data we expect to receive.
// This acts as the "single source of truth" for both validation and type inference.
const UserRegistrationSchema = z.object({
  // 'email' must be a valid string format (email)
  email: z.string().email(),
  
  // 'password' must be a string with a minimum length of 8 characters
  password: z.string().min(8),
  
  // 'metadata' is an optional object containing a 'source' string
  // This simulates tracking where the user came from (e.g., 'ios', 'android', 'web')
  metadata: z.object({
    source: z.enum(['ios', 'android', 'web']),
  }).optional(),
});

// 3. Infer the Static Type
// We use TypeScript's 'infer' keyword to extract the static type from the Zod schema.
// This allows us to use the same definition for both runtime validation and compile-time type safety.
type UserRegistration = z.infer<typeof UserRegistrationSchema>;

// 4. Simulate an Incoming API Payload
// In a real app, this would come from 'req.body' in Express or 'await request.json()' in Next.js.
// Here, we simulate data that is intentionally malformed:
// - 'email' is missing the '@' symbol.
// - 'password' is too short (less than 8 chars).
// - 'metadata' is missing (which is allowed since it's optional).
const incomingPayload: unknown = {
  email: "user.example.com", // Invalid email format
  password: "123456",        // Too short
  // metadata is omitted
};

/**
 * Validates the incoming payload against the defined schema.
 * 
 * @param data - The unknown data payload received from the client.
 * @returns The validated and typed data if validation succeeds.
 * @throws Error - If validation fails, containing detailed error messages.
 */
function validateUserRegistration(data: unknown): UserRegistration {
  // 5. Parse the data
  // Zod's .parse() method validates the data against the schema.
  // If successful, it returns the data with the correct type.
  // If it fails, it throws a ZodError containing specific issues.
  try {
    const validatedData = UserRegistrationSchema.parse(data);
    return validatedData;
  } catch (error) {
    // In a production environment, you would log this error and return a 400 Bad Request response.
    if (error instanceof z.ZodError) {
      const errorMessages = error.errors.map((err) => `${err.path.join('.')}: ${err.message}`).join(', ');
      throw new Error(`Validation failed: ${errorMessages}`);
    }
    throw new Error('An unknown error occurred during validation.');
  }
}

// 6. Execute the Validation
// We wrap the execution in a function to simulate an API handler.
async function handleApiRequest() {
  console.log("--- Starting Validation Process ---");
  console.log("Incoming Payload:", JSON.stringify(incomingPayload, null, 2));

  try {
    // Attempt to validate the payload
    const validUser = validateUserRegistration(incomingPayload);
    
    // If we reach here, validation passed.
    // We can now safely use 'validUser' with full type safety.
    // The V8 engine executes this block because the data structure matches the schema.
    console.log("\n✅ Validation Successful!");
    console.log("Validated Data:", validUser);
    
    // Example: Proceed to database insertion
    // await db.users.create(validUser); 
  } catch (error) {
    // Validation failed. The error caught contains specific details.
    console.error("\n❌ Validation Failed!");
    if (error instanceof Error) {
      console.error(error.message);
    }
  } finally {
    console.log("--- Process Complete ---");
  }
}

// Run the example
handleApiRequest();
