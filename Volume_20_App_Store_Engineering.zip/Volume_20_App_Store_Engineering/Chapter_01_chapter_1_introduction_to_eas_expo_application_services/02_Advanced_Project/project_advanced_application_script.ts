/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// app/api/build/status/route.ts
// ---------------------------------------------------------
// API Route: Handles Server-Sent Events (SSE) for real-time 
// build status updates. This simulates the EAS Build process 
// outputting logs to a client.
// ---------------------------------------------------------

import { NextRequest, NextResponse } from 'next/server';

export async function GET(req: NextRequest) {
  // Create a ReadableStream to push data to the client
  const stream = new ReadableStream({
    async start(controller) {
      const encoder = new TextEncoder();
      
      // Simulate EAS Build Phases
      const buildPhases = [
        { delay: 1000, message: "Queued build request..." },
        { delay: 2000, message: "Starting build environment..." },
        { delay: 3000, message: "Installing dependencies (npm install)..." },
        { delay: 4000, message: "Compiling React Native bundle..." },
        { delay: 5000, message: "Generating OTA update manifest..." },
        { delay: 6000, message: "Uploading to EAS Update CDN..." },
        { delay: 7000, message: "Build Complete: https://expo.dev/@demo/app?release-channel=prod" }
      ];

      for (const phase of buildPhases) {
        await new Promise(resolve => setTimeout(resolve, phase.delay));
        
        // Format as SSE message: "data: { ...JSON... }"
        const data = JSON.stringify({ 
          timestamp: new Date().toISOString(), 
          status: 'building', 
          message: phase.message 
        });
        
        controller.enqueue(encoder.encode(`data: ${data}\n\n`));
      }

      // Close stream after final message
      controller.close();
    },
  });

  return new Response(stream, {
    headers: {
      'Content-Type': 'text/event-stream',
      'Cache-Control': 'no-cache',
      'Connection': 'keep-alive',
    },
  });
}

// app/page.tsx
// ---------------------------------------------------------
// Frontend Component: Consumes the SSE stream and simulates 
// the EAS Update workflow logic.
// ---------------------------------------------------------

'use client';

import { useState, useEffect, useRef } from 'react';

// Type definitions for our simulated EAS Build payload
interface BuildStatus {
  timestamp: string;
  status: 'idle' | 'building' | 'success' | 'error';
  message: string;
}

// Type definition for the User Prompt configuration
interface UserPromptConfig {
  targetPlatform: 'ios' | 'android';
  optimizationLevel: 'standard' | 'aggressive';
  description: string;
}

export default function EASDashboard() {
  const [status, setStatus] = useState<BuildStatus>({ 
    timestamp: '', 
    status: 'idle', 
    message: 'Ready to start build.' 
  });
  
  const [userPrompt, setUserPrompt] = useState<UserPromptConfig>({
    targetPlatform: 'ios',
    optimizationLevel: 'standard',
    description: ''
  });

  const eventSourceRef = useRef<EventSource | null>(null);

  /**
   * Simulates the EAS Update "Publish" logic.
   * In a real scenario, this would call the EAS API to create an update.
   * Here, we validate the User Prompt and trigger the SSE stream.
   */
  const triggerEASBuild = async () => {
    // 1. Reset status
    setStatus({ timestamp: new Date().toISOString(), status: 'building', message: 'Initializing...' });

    // 2. Close existing connection if any
    if (eventSourceRef.current) {
      eventSourceRef.current.close();
    }

    // 3. Establish SSE Connection to our API route
    const eventSource = new EventSource('/api/build/status');
    eventSourceRef.current = eventSource;

    // 4. Listen for messages from the server
    eventSource.onmessage = (event) => {
      const data: BuildStatus = JSON.parse(event.data);
      setStatus(data);

      // Auto-close on completion
      if (data.message.includes('Build Complete')) {
        eventSource.close();
        eventSourceRef.current = null;
      }
    };

    eventSource.onerror = () => {
      setStatus(prev => ({ ...prev, status: 'error', message: 'Connection lost.' }));
      eventSource.close();
    };
  };

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      if (eventSourceRef.current) {
        eventSourceRef.current.close();
      }
    };
  }, []);

  return (
    <div className="min-h-screen bg-gray-900 text-white p-8 font-sans">
      <div className="max-w-4xl mx-auto">
        <header className="mb-8 border-b border-gray-700 pb-4">
          <h1 className="text-3xl font-bold text-blue-400">Expo Application Services (EAS)</h1>
          <p className="text-gray-400 mt-2">CI/CD Dashboard & OTA Update Simulator</p>
        </header>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          
          {/* LEFT PANEL: Configuration & User Prompt */}
          <div className="bg-gray-800 p-6 rounded-lg shadow-lg">
            <h2 className="text-xl font-semibold mb-4 text-green-400">1. Configuration (User Prompt)</h2>
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm text-gray-300 mb-1">Target Platform</label>
                <select 
                  value={userPrompt.targetPlatform}
                  onChange={(e) => setUserPrompt({...userPrompt, targetPlatform: e.target.value as any})}
                  className="w-full bg-gray-700 border border-gray-600 rounded p-2 text-white"
                >
                  <option value="ios">iOS (Simulator/Device)</option>
                  <option value="android">Android (APK/AAB)</option>
                </select>
              </div>

              <div>
                <label className="block text-sm text-gray-300 mb-1">Optimization Strategy</label>
                <select 
                  value={userPrompt.optimizationLevel}
                  onChange={(e) => setUserPrompt({...userPrompt, optimizationLevel: e.target.value as any})}
                  className="w-full bg-gray-700 border border-gray-600 rounded p-2 text-white"
                >
                  <option value="standard">Standard Build</option>
                  <option value="aggressive">Aggressive Tree-Shaking (Production)</option>
                </select>
              </div>

              <div>
                <label className="block text-sm text-gray-300 mb-1">Build Notes (Prompt)</label>
                <textarea 
                  placeholder="Describe specific requirements (e.g., 'Include AI SDK for image processing')..."
                  value={userPrompt.description}
                  onChange={(e) => setUserPrompt({...userPrompt, description: e.target.value})}
                  className="w-full bg-gray-700 border border-gray-600 rounded p-2 text-white h-24"
                />
              </div>

              <button 
                onClick={triggerEASBuild}
                disabled={status.status === 'building'}
                className="w-full bg-blue-600 hover:bg-blue-700 disabled:bg-gray-600 text-white font-bold py-2 px-4 rounded transition-colors"
              >
                {status.status === 'building' ? 'Building...' : 'Trigger EAS Build & Update'}
              </button>
            </div>
          </div>

          {/* RIGHT PANEL: Real-time Logs (SSE) */}
          <div className="bg-gray-800 p-6 rounded-lg shadow-lg flex flex-col">
            <h2 className="text-xl font-semibold mb-4 text-blue-400">2. Build Output (SSE Stream)</h2>
            
            <div className="flex-1 bg-black rounded border border-gray-700 p-4 font-mono text-sm overflow-y-auto h-64">
              <div className="text-gray-500 mb-2">
                <span className="text-yellow-500">///</span> EAS Build Logs
              </div>
              
              {/* Status Display */}
              <div className="mb-2">
                <span className="text-gray-400">Status:</span> 
                <span className={`ml-2 font-bold ${status.status === 'success' ? 'text-green-400' : status.status === 'error' ? 'text-red-400' : 'text-yellow-400'}`}>
                  {status.status.toUpperCase()}
                </span>
              </div>
              
              {/* Message Log */}
              {status.message && (
                <div className="border-l-2 border-gray-700 pl-3 py-1">
                  <span className="text-gray-300">[{status.timestamp.split('T')[1].split('.')[0]}]</span> 
                  <span className="text-white ml-2">{status.message}</span>
                </div>
              )}

              {/* Simulated OTA Update Link */}
              {status.status === 'success' && (
                <div className="mt-4 p-3 bg-green-900/30 border border-green-700 rounded">
                  <p className="text-green-400 font-bold">OTA Update Published!</p>
                  <p className="text-gray-300 text-xs mt-1">
                    The update has been pushed to the EAS Update CDN. 
                    Users on the "prod" channel will receive this patch on their next app launch.
                  </p>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* FOOTER: Architecture Context */}
        <div className="mt-8 p-4 bg-gray-800/50 rounded border border-gray-700">
          <h3 className="text-sm font-bold text-gray-400 uppercase mb-2">Under the Hood</h3>
          <p className="text-gray-300 text-sm leading-relaxed">
            This dashboard demonstrates how <strong>EAS Build</strong> and <strong>EAS Update</strong> integrate into a SaaS workflow. 
            The <strong>User Prompt</strong> simulates dynamic configuration injection (e.g., via CLI flags or <code>eas.json</code>). 
            The <strong>SSE Stream</strong> mimics the persistent HTTP connection established by the EAS CLI to report build progress. 
            Finally, the simulated "Success" state represents the generation of a new <code>manifest.json</code> bundle, 
            allowing React Native apps to fetch over-the-air updates without App Store review.
          </p>
        </div>
      </div>
    </div>
  );
}
