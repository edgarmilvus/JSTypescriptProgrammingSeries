/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

import React, { useState, useEffect } from 'react';
import * as Updates from 'expo-updates';
import { View, Text, Button, ActivityIndicator } from 'react-native';

// Define the possible states for the update process
type UpdateStatusState = 'idle' | 'checking' | 'downloading' | 'updateAvailable' | 'upToDate' | 'error';

interface UseOTAUpdatesReturn {
  status: UpdateStatusState;
  error: string | null;
  checkAndApply: () => Promise<void>;
}

// Custom Hook: useOTAUpdates
export const useOTAUpdates = (): UseOTAUpdatesReturn => {
  const [status, setStatus] = useState<UpdateStatusState>('idle');
  const [error, setError] = useState<string | null>(null);

  const checkAndApply = async () => {
    setStatus('checking');
    setError(null);

    try {
      // 1. Simulate network delay as per requirements
      await new Promise(resolve => setTimeout(resolve, 2000));

      // 2. Check for updates (In a real scenario, we would call Updates.checkForUpdateAsync())
      // For this simulation, we assume an update is always available to demonstrate the flow
      const isUpdateAvailable = true; 

      if (isUpdateAvailable) {
        setStatus('downloading');
        
        // Simulate download time
        await new Promise(resolve => setTimeout(resolve, 2000));

        setStatus('updateAvailable');
        
        // 3. Reload the app to apply the update
        // await Updates.reloadAsync(); // Commented out to prevent infinite reload loop during dev
      } else {
        setStatus('upToDate');
      }
    } catch (e) {
      setStatus('error');
      setError(e instanceof Error ? e.message : 'Unknown error occurred');
      console.error('OTA Update Error:', e);
    }
  };

  return { status, error, checkAndApply };
};

// Component: UpdateStatus
export const UpdateStatus = () => {
  const { status, error, checkAndApply } = useOTAUpdates();

  // Auto-trigger check on mount for demonstration
  useEffect(() => {
    checkAndApply();
  }, []);

  const renderContent = () => {
    switch (status) {
      case 'checking':
        return (
          <View>
            <ActivityIndicator size="small" color="#0000ff" />
            <Text>Checking for updates...</Text>
          </View>
        );
      case 'downloading':
        return (
          <View>
            <ActivityIndicator size="small" color="#0000ff" />
            <Text>Downloading update...</Text>
          </View>
        );
      case 'updateAvailable':
        return (
          <View>
            <Text>Update downloaded! Tap to restart.</Text>
            <Button title="Restart App" onPress={() => Updates.reloadAsync()} />
          </View>
        );
      case 'upToDate':
        return <Text>App is up to date.</Text>;
      case 'error':
        return <Text style={{ color: 'red' }}>Error: {error}</Text>;
      default:
        return <Text>Ready to check.</Text>;
    }
  };

  return (
    <View style={{ padding: 20, borderWidth: 1, borderColor: '#ccc', borderRadius: 8 }}>
      <Text style={{ fontWeight: 'bold', marginBottom: 10 }}>Update Status</Text>
      {renderContent()}
    </View>
  );
};
