/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part5.ts
// Description: Solutions and Explanations
// ==========================================

import { z } from 'zod';

// 1. Define the TypeScript Interface
export interface RemoteConfig {
  features: {
    darkMode: boolean;
    betaAccess: boolean;
  };
  version: string;
}

// 2. Create the Zod Schema
// This mirrors the interface exactly for runtime validation
const RemoteConfigSchema = z.object({
  features: z.object({
    darkMode: z.boolean(),
    betaAccess: z.boolean(),
  }),
  version: z.string().regex(/^\d+\.\d+\.\d+$/, "Version must be semantic (e.g., 1.0.0)"),
});

// 3. Validation Function
export function validateRemoteConfig(data: unknown): RemoteConfig {
  try {
    // .parse() throws an error if validation fails
    return RemoteConfigSchema.parse(data);
  } catch (error) {
    if (error instanceof z.ZodError) {
      // 4. Throw descriptive error
      const errorMessages = error.errors.map(err => 
        `${err.path.join('.')}: ${err.message}`
      ).join(', ');
      throw new Error(`Remote Config Validation Failed: ${errorMessages}`);
    }
    // Re-throw if it's an unexpected error type
    throw error;
  }
}

// Example Usage:
// const validData = { features: { darkMode: true, betaAccess: false }, version: "1.2.0" };
// const config = validateRemoteConfig(validData); // Returns typed RemoteConfig

// const invalidData = { features: { darkMode: "true", betaAccess: false }, version: "1.2" };
// validateRemoteConfig(invalidData); // Throws Error: "features.darkMode: Expected boolean, received string"
