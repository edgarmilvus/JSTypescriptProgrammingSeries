/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part6.ts
// Description: Solutions and Explanations
// ==========================================

digraph EAS_CICD_Pipeline {
    rankdir=LR;
    node [shape=box, style="rounded,filled", color="#4F46E5", fontname="Arial"];
    edge [fontname="Arial", fontsize=10];

    // Nodes
    CI_Trigger [label="CI/CD Trigger\n(Merge to main)", shape="ellipse", fillcolor="#F3F4F6"];
    EAS_Build [label="EAS Build\n(Production)", fillcolor="#DBEAFE"];
    EAS_Update [label="EAS Update\n(OTA)", fillcolor="#DBEAFE"];
    EAS_Submit [label="EAS Submit\n(App Store)", fillcolor="#DBEAFE"];
    App_Store_Review [label="App Store Review", fillcolor="#FEF3C7"];
    User_Device_Binary [label="User Device\n(Binary)", fillcolor="#D1FAE5", shape="circle"];
    User_Device_OTA [label="User Device\n(OTA)", fillcolor="#D1FAE5", shape="circle"];

    // Edges - Parallel Flow
    CI_Trigger -> EAS_Build [label="Triggers Build"];
    CI_Trigger -> EAS_Update [label="Triggers Update"];

    // Binary Path
    EAS_Build -> EAS_Submit [label="Uploads Binary"];
    EAS_Submit -> App_Store_Review [label="Sent for Review"];
    App_Store_Review -> User_Device_Binary [label="Approved & Downloaded"];

    // OTA Path
    EAS_Update -> User_Device_OTA [label="Delivers Patch"];
}
