/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

// app/page.tsx
"use client";

import { useChat } from "ai/react";
import { useState } from "react";
import { z } from "zod";
import { zodResponseFormat } from "ai";

// 1. Define the Schema using Zod
// This ensures the AI response matches our strict data structure.
const AppMetadataSchema = z.object({
  title: z.string().describe("The catchy title of the app"),
  subtitle: z.string().describe("A short, punchy subtitle"),
  keywords: z.array(z.string()).describe("A list of relevant keywords for SEO"),
  marketingCopy: z.string().describe("A short paragraph for the app description"),
});

export default function MetadataGenerator() {
  // 2. State to hold the parsed JSON result
  const [metadata, setMetadata] = useState<z.infer<typeof AppMetadataSchema> | null>(null);

  // 3. Initialize the useChat hook
  // We enable streamToolCalls to handle structured outputs.
  const { messages, input, handleInputChange, handleSubmit, isLoading, error } = useChat({
    api: "/api/generate-metadata", // The backend endpoint
    // We will handle the experimental_onToolCall later in the backend
  });

  // 4. Custom handler to parse the streamed response
  // Note: In a real app with Vercel AI SDK v3+, structured outputs are often handled 
  // via the 'onToolCall' or 'onResponse' callbacks, but for this simplified example,
  // we will simulate parsing the final message content as JSON.
  const handleFormSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setMetadata(null); // Reset previous results
    
    // We submit the input to the hook
    await handleSubmit(e);
  };

  // 5. Effect to parse the last message if it looks like JSON
  // In a production app, you would use the 'onToolCall' callback in the backend 
  // or 'onResponse' to extract the structured data directly.
  const lastMessage = messages[messages.length - 1];
  if (lastMessage?.role === "assistant" && !metadata && !isLoading) {
    try {
      // Attempt to parse the content as JSON
      const parsed = AppMetadataSchema.parse(JSON.parse(lastMessage.content));
      setMetadata(parsed);
    } catch (e) {
      // Parsing failed, content is likely free text or malformed JSON
      console.warn("Failed to parse AI response as schema:", e);
    }
  }

  return (
    <div style={{ padding: "20px", fontFamily: "sans-serif" }}>
      <h1>App Store Metadata Generator</h1>
      
      <form onSubmit={handleFormSubmit}>
        <textarea
          value={input}
          onChange={handleInputChange}
          placeholder="Enter your app description..."
          rows={4}
          style={{ width: "100%", marginBottom: "10px" }}
          disabled={isLoading}
        />
        <button type="submit" disabled={isLoading}>
          {isLoading ? "Generating..." : "Generate Metadata"}
        </button>
      </form>

      {error && (
        <div style={{ color: "red", marginTop: "10px" }}>
          Error: {error.message}
        </div>
      )}

      {metadata && (
        <div style={{ marginTop: "20px", border: "1px solid #ccc", padding: "15px" }}>
          <h2>Structured Output (JSON)</h2>
          <pre>{JSON.stringify(metadata, null, 2)}</pre>
          
          <h3>Rendered UI</h3>
          <div style={{ background: "#f0f0f0", padding: "10px" }}>
            <strong>Title:</strong> {metadata.title}<br />
            <strong>Subtitle:</strong> {metadata.subtitle}<br />
            <strong>Keywords:</strong> {metadata.keywords.join(", ")}<br />
            <p>{metadata.marketingCopy}</p>
          </div>
        </div>
      )}
    </div>
  );
}
