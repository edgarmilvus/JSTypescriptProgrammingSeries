/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.ts
// Description: Basic Code Example
// ==========================================

import { streamText } from "ai";
import { openai } from "@ai-sdk/openai";
import { z } from "zod";

// 1. Re-define the schema on the server
const AppMetadataSchema = z.object({
  title: z.string(),
  subtitle: z.string(),
  keywords: z.array(z.string()),
  marketingCopy: z.string(),
});

export async function POST(req: Request) {
  const { messages } = await req.json();

  // 2. Call the LLM with the schema
  const result = streamText({
    model: openai("gpt-4o-mini"),
    messages,
    // This is the key part: instructing the model to output structured data
    experimental_providerMetadata: {
      openai: {
        response_format: zodResponseFormat(AppMetadataSchema, "app_metadata"),
      },
    },
  });

  // 3. Stream the response back to the client
  return result.toAIStreamResponse();
}
