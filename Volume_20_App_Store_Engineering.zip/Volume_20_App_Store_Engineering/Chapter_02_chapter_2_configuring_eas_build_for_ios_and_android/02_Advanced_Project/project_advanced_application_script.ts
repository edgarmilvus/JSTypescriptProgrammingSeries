/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

/**
 * File: app/api/generate-eas-config/route.ts
 * 
 * Purpose: API Route handler that accepts a user prompt and returns a structured
 * EAS Build configuration. It enforces JSON Schema output to ensure the frontend
 * receives parseable, valid configuration data.
 */

import { NextResponse } from 'next/server';
import { generateText } from 'ai'; // Assuming Vercel AI SDK is installed
import { openai } from '@ai-sdk/openai';
import { z } from 'zod';

// 1. Define the Target JSON Schema
// This schema represents the structure of a valid eas.json file.
// We use Zod here to define the schema, which can be converted to JSON Schema
// for the LLM or used for validation on the backend.
const EasConfigSchema = z.object({
  build: z.object({
    development: z.object({
      android: z.object({
        buildType: z.enum(['apk', 'aab']),
        gradleCommand: z.string().optional(),
      }),
      ios: z.object({
        buildConfiguration: z.enum(['Debug', 'Release']),
        simulator: z.boolean().optional(),
      }),
    }),
    production: z.object({
      android: z.object({
        buildType: z.literal('aab'),
      }),
      ios: z.object({
        buildConfiguration: z.literal('Release'),
        buildNumber: z.string(),
      }),
    }),
  }),
  submit: z.object({
    production: z.object({
      android: z.object({
        serviceAccount: z.string(),
      }),
      ios: z.object({
        appleId: z.string(),
        ascAppId: z.string(),
      }),
    }),
  }).optional(),
});

// Convert Zod schema to a JSON Schema object for the LLM prompt
const jsonSchema = {
  type: 'object',
  properties: {
    build: {
      type: 'object',
      properties: {
        development: {
          type: 'object',
          properties: {
            android: { type: 'object', properties: { buildType: { type: 'string', enum: ['apk', 'aab'] } } },
            ios: { type: 'object', properties: { buildConfiguration: { type: 'string', enum: ['Debug', 'Release'] } } }
          }
        },
        production: {
          type: 'object',
          properties: {
            android: { type: 'object', properties: { buildType: { type: 'string', enum: ['aab'] } } },
            ios: { type: 'object', properties: { buildNumber: { type: 'string' } } }
          }
        }
      }
    }
  },
  required: ['build']
};

export async function POST(req: Request) {
  const { prompt } = await req.json();

  // 2. Construct the System Prompt
  // We instruct the AI to act as an Expo EAS expert and strictly adhere to the schema.
  const systemPrompt = `
    You are an expert Expo Application Services (EAS) engineer.
    The user wants to generate an 'eas.json' configuration.
    Based on their request, generate a valid JSON object.
    STRICT RULES:
    1. Output ONLY raw JSON. No markdown, no code blocks, no explanation.
    2. The JSON must strictly adhere to the following schema:
    ${JSON.stringify(jsonSchema, null, 2)}
  `;

  // 3. Call the LLM with Tool/Schema Enforcement
  // Note: Many LLM providers support JSON mode or tool calling. 
  // Here we simulate the generic text generation that expects JSON.
  const { text } = await generateText({
    model: openai('gpt-4-turbo'),
    prompt: `User Request: "${prompt}"`,
    system: systemPrompt,
  });

  // 4. Parse and Validate the Response
  // Even though we asked for JSON, we parse it safely.
  try {
    // Remove potential markdown code blocks if the LLM ignores strict instructions
    const rawJsonString = text.replace(/