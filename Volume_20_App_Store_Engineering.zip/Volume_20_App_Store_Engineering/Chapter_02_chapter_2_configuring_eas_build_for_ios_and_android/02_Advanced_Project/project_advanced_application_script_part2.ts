/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script_part2.ts
// Description: Advanced Application Script
// ==========================================

/**
 * File: app/components/EasConfigGenerator.tsx
 * 
 * Purpose: Frontend component using the `useChat` hook to manage the conversation
 * and display the generated configuration.
 */

'use client';

import { useChat } from 'ai/react';
import { useState, useEffect } from 'react';

export default function EasConfigGenerator() {
  // 1. Initialize useChat Hook
  // This hook handles message state, user input, and API communication.
  const { messages, input, handleInputChange, handleSubmit, isLoading, error } = useChat({
    api: '/api/generate-eas-config',
  });

  // 2. Local State for Generated Config
  // We extract the config from the message stream to render it specially.
  const [generatedConfig, setGeneratedConfig] = useState<any>(null);

  // 3. Effect: Parse the Last Message
  // When messages update, check if the last message contains valid JSON.
  useEffect(() => {
    const lastMessage = messages[messages.length - 1];
    if (lastMessage?.role === 'assistant' && lastMessage.content) {
      try {
        // Attempt to parse the content. In a streaming scenario, this might be partial.
        // For simplicity, we assume the full JSON string arrives in one message or we parse the final one.
        // Note: `useChat` streams tokens. To handle streaming JSON safely, we usually wait for the full block.
        // Here we check if it looks like JSON.
        if (lastMessage.content.trim().startsWith('{')) {
          const parsed = JSON.parse(lastMessage.content);
          setGeneratedConfig(parsed);
        }
      } catch (e) {
        // Ignore parsing errors until the stream completes
      }
    }
  }, [messages]);

  // 4. Helper: Apply Configuration
  // Simulates writing the file to the project repository.
  const handleApplyConfig = () => {
    if (!generatedConfig) return;
    const jsonBlob = JSON.stringify(generatedConfig, null, 2);
    
    // In a real SaaS, this would trigger a backend job to commit the file.
    // Here we simulate a download or toast notification.
    console.log("Applying EAS Config:", jsonBlob);
    alert(`Configuration applied successfully!\n\n${jsonBlob}`);
  };

  // 5. Helper: Format JSON for display
  const formatJson = (obj: any) => JSON.stringify(obj, null, 2);

  return (
    <div className="max-w-4xl mx-auto p-6 space-y-6 bg-gray-50 rounded-lg shadow-sm font-mono text-sm">
      
      {/* Header & Input */}
      <div className="bg-white p-4 rounded border border-gray-200">
        <h2 className="text-lg font-bold mb-2 text-gray-800">EAS Build Configurator</h2>
        <p className="text-gray-500 mb-4 text-xs">
          Describe your build requirements. The AI will generate a valid eas.json.
        </p>
        
        <form onSubmit={handleSubmit} className="flex gap-2">
          <input
            type="text"
            value={input}
            onChange={handleInputChange}
            placeholder="e.g., Generate dev builds for Android APK and iOS Simulator, plus production AAB."
            className="flex-1 p-2 border rounded text-gray-900 focus:outline-none focus:ring-2 focus:ring-blue-500"
            disabled={isLoading}
          />
          <button 
            type="submit" 
            disabled={isLoading}
            className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 disabled:opacity-50"
          >
            {isLoading ? 'Generating...' : 'Generate'}
          </button>
        </form>
      </div>

      {/* Error State */}
      {error && (
        <div className="p-3 bg-red-100 text-red-700 rounded border border-red-200">
          Error: {error.message}
        </div>
      )}

      {/* Result Display */}
      {generatedConfig && (
        <div className="space-y-3">
          <div className="flex justify-between items-center">
            <span className="font-bold text-gray-700">Generated eas.json</span>
            <button 
              onClick={handleApplyConfig}
              className="px-3 py-1 bg-green-600 text-white rounded text-xs hover:bg-green-700"
            >
              Apply Configuration
            </button>
          </div>
          
          {/* Code Block Visualization */}
          <pre className="bg-slate-800 text-green-400 p-4 rounded overflow-x-auto border border-slate-700 shadow-inner">
            {formatJson(generatedConfig)}
          </pre>
        </div>
      )}

      {/* Chat History (Optional Debug View) */}
      <div className="border-t pt-4 mt-4 opacity-50 hover:opacity-100 transition-opacity">
        <h3 className="text-xs font-bold uppercase tracking-wider mb-2 text-gray-400">Raw Message History</h3>
        <ul className="space-y-1 text-xs text-gray-500">
          {messages.map((m, i) => (
            <li key={i} className={`${m.role === 'user' ? 'text-blue-600' : 'text-green-600'}`}>
              <span className="font-bold uppercase">{m.role}:</span> {m.content.substring(0, 100)}...
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}
