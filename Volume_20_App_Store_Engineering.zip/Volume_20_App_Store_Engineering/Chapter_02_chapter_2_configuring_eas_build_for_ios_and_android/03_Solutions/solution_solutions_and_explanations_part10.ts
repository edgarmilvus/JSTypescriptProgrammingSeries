/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part10.ts
// Description: Solutions and Explanations
// ==========================================

// check-google-services.ts
// Checks for the existence and basic structure of google-services.json.

import * as fs from 'fs';
import * as path from 'path';

const filePath = path.join(process.cwd(), 'android/app/google-services.json');

console.log(`Checking for google-services.json at: ${filePath}`);

if (!fs.existsSync(filePath)) {
  console.error('\x1b[31m%s\x1b[0m', 'Error: google-services.json not found.');
  process.exit(1);
}

try {
  const fileContent = fs.readFileSync(filePath, 'utf8');
  const jsonData = JSON.parse(fileContent);

  // Basic validation of structure
  if (!jsonData.project_info || !Array.isArray(jsonData.client)) {
    throw new Error('Invalid structure: Missing project_info or client array.');
  }

  console.log('\x1b[32m%s\x1b[0m', 'Success: google-services.json exists and has valid structure.');
} catch (error) {
  console.error('\x1b[31m%s\x1b[0m', 'Error: Failed to parse or validate google-services.json.');
  console.error(error.message);
  process.exit(1);
}
