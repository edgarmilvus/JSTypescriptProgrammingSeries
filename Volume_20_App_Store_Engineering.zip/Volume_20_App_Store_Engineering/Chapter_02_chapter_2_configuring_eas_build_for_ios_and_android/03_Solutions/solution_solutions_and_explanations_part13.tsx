/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part13.tsx
// Description: Solutions and Explanations
// ==========================================

// BuildStatusMonitor.tsx
import React, { useState, useEffect } from 'react';
import { useChat } from 'ai/react';
import { Build, ApiBuildResponse } from './types/build';

interface BuildStatusMonitorProps {
  projectId: string;
}

const BuildStatusMonitor: React.FC<BuildStatusMonitorProps> = ({ projectId }) => {
  const [build, setBuild] = useState<Build | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);

  // Vercel AI SDK hook for conversational AI
  const { messages, input, handleInputChange, handleSubmit, isLoading: isAiLoading } = useChat();

  // Mock API fetch function
  const fetchBuildStatus = async () => {
    setLoading(true);
    setError(null);
    try {
      // Simulate API call
      const response: ApiBuildResponse = await new Promise(resolve => {
        setTimeout(() => {
          resolve({
            build: {
              id: '12345',
              status: 'FINISHED',
              platform: 'ANDROID',
              artifactUrl: 'https://expo.dev/artifacts/eas/xyz123.apk',
              logsUrl: 'https://expo.dev/logs/12345'
            }
          });
        }, 1000);
      });
      setBuild(response.build);
    } catch (err) {
      setError('Failed to fetch build status.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchBuildStatus();
  }, [projectId]);

  const handleSummarizeLogs = () => {
    setIsModalOpen(true);
  };

  return (
    <div style={{ padding: '20px', border: '1px solid #ccc', borderRadius: '8px', maxWidth: '400px' }}>
      <h3>Build Status for {projectId}</h3>
      
      {loading && <p>Loading...</p>}
      {error && (
        <div>
          <p style={{ color: 'red' }}>{error}</p>
          <button onClick={fetchBuildStatus}>Retry</button>
        </div>
      )}
      
      {build && (
        <div style={{ marginBottom: '10px' }}>
          <p><strong>ID:</strong> {build.id}</p>
          <p><strong>Platform:</strong> {build.platform}</p>
          <p><strong>Status:</strong> {build.status}</p>
          {build.artifactUrl && (
            <a href={build.artifactUrl} target="_blank" rel="noopener noreferrer">
              Download Artifact
            </a>
          )}
          {build.status === 'FINISHED' && (
            <button onClick={handleSummarizeLogs} style={{ marginLeft: '10px' }}>
              Summarize Logs with AI
            </button>
          )}
        </div>
      )}

      {/* AI Modal */}
      {isModalOpen && (
        <div style={{ marginTop: '20px', border: '1px solid #aaa', padding: '10px', background: '#f9f9f9' }}>
          <h4>AI Log Summary</h4>
          <div>
            {messages.map(m => (
              <div key={m.id} style={{ marginBottom: '8px' }}>
                <strong>{m.role === 'user' ? 'You: ' : 'AI: '}</strong>
                {m.content}
              </div>
            ))}
            {isAiLoading && <div>AI is thinking...</div>}
          </div>
          
          <form onSubmit={handleSubmit}>
            <input
              type="text"
              value={input}
              onChange={handleInputChange}
              placeholder="Ask about the logs..."
              style={{ width: '70%', marginRight: '5px' }}
            />
            <button type="submit">Send</button>
          </form>
          <button onClick={() => setIsModalOpen(false)} style={{ marginTop: '10px' }}>Close</button>
        </div>
      )}
    </div>
  );
};

export default BuildStatusMonitor;
