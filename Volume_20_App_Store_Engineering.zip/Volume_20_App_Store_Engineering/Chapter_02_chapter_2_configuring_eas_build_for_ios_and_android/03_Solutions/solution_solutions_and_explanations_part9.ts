/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part9.ts
// Description: Solutions and Explanations
// ==========================================

// Explanation
**Cache Invalidation Strategy for Native Modules:**

The `cache.key` in `eas.json` is the primary mechanism for invalidation. It is a string identifier for the cache archive. When the key changes, EAS Build ignores the existing cache and creates a new one.

For native modules like `react-native-reanimated`:
1.  **Manual Invalidation:** If you update a native module that requires a fresh rebuild of native code (e.g., changing from v2 to v3), you should update the `cache.key` in your `eas.json` profile. For example, change `production-cache-1` to `production-cache-2`. This forces a clean install of `node_modules` and `ios/Pods`, ensuring no artifacts from the old version are reused.
2.  **Dependency-based Keying:** While EAS automatically hashes `package-lock.json` for the default cache key, custom keys require manual management. A robust strategy involves appending a hash of the native dependency version to the key, though this is complex to automate in `eas.json` itself.
3.  **Why `paths` is necessary:** `cache.key` defines *when* to restore a cache (matching the key), while `cache.paths` defines *what* to save and restore. Without `paths`, EAS only caches the `node_modules` directory by default. Adding `ios/Pods` and workspace-specific `node_modules` ensures that CocoaPods installation (which is time-consuming) and monorepo dependencies are also cached, significantly reducing build times.
