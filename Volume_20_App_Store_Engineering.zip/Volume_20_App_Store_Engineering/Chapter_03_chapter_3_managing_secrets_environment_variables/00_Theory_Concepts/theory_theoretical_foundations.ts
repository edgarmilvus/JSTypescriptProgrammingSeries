/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: theory_theoretical_foundations.ts
// Description: Theoretical Foundations
// ==========================================

digraph SecureLifecycle {
    rankdir=TB;
    node [shape=box, style="rounded,filled", fillcolor="#e0e0e0", fontname="Helvetica"];

    subgraph cluster_0 {
        label = "Developer Machine";
        style = "rounded,dashed";
        fillcolor = "#f0f8ff";

        LocalCode [label="Source Code\n(No Secrets)", fillcolor="white"];
        LocalEnv [label=".env.local\n(Gitignored)", fillcolor="#fffacd"];
        LocalCode -> LocalEnv [label="Reads", style=dotted];
    }

    subgraph cluster_1 {
        label = "EAS Build (CI/CD)";
        style = "rounded,dashed";
        fillcolor = "#f0fff0";

        EASBuild [label="EAS Build Process", fillcolor="#90ee90"];
        EASSecrets [label="EAS Secrets Vault\n(Encrypted)", fillcolor="#ffd700"];
        BuildArtifact [label="App Binary\n(.ipa/.apk)", fillcolor="white"];

        EASSecrets -> EASBuild [label="Injects", style=dashed, color=red];
        LocalCode -> EASBuild [label="Git Push"];
        EASBuild -> BuildArtifact [label="Produces"];
    }

    subgraph cluster_2 {
        label = "Runtime Environment";
        style = "rounded,dashed";
        fillcolor = "#fff0f0";

        AppBinary [label="Installed App", fillcolor="#add8e6"];
        EdgeRuntime [label="Edge Runtime\n(e.g., Vercel/Cloudflare)", fillcolor="#ffb6c1"];
        ThirdParty [label="Third-Party APIs\n(Google Maps, Auth0)", fillcolor="#d3d3d3"];

        AppBinary -> EdgeRuntime [label="API Calls", color=blue];
        EdgeRuntime -> ThirdParty [label="Uses Secrets", style=dashed, color=red];
    }

    // Connections
    BuildArtifact -> AppBinary [label="Distributed via OTA/Store"];
}
