/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example.ts
// Description: Basic Code Example
// ==========================================

// Filename: inferenceService.ts
// A self-contained Node.js service demonstrating secure secret management
// and immutable state for configuration.

/**
 * Represents the immutable configuration state for the inference service.
 * This structure ensures that once loaded, the core secrets cannot be mutated.
 */
interface ServiceConfig {
    readonly openaiApiKey: string;
    readonly supabaseUrl: string;
    readonly supabaseServiceRoleKey: string;
    readonly modelVersion: string;
}

/**
 * Represents the immutable state of the application runtime.
 * This includes configuration and any derived state (like a database client).
 */
interface AppState {
    readonly config: ServiceConfig;
    // In a real app, this would be a Supabase client instance.
    // We use a simple object for demonstration.
    readonly dbClient: {
        readonly url: string;
        readonly isConnected: boolean;
    };
}

/**
 * Loads environment variables securely. Throws an error if any required
 * variable is missing, preventing the app from running in an insecure state.
 *
 * @returns {ServiceConfig} An immutable configuration object.
 * @throws {Error} If any required environment variable is not set.
 */
function loadConfig(): ServiceConfig {
    // List of required environment variables.
    // In a real app, you might have more (e.g., for different environments).
    const requiredEnvVars = [
        'OPENAI_API_KEY',
        'SUPABASE_URL',
        'SUPABASE_SERVICE_ROLE_KEY',
    ] as const;

    // Validate that all required variables are present.
    for (const envVar of requiredEnvVars) {
        if (!process.env[envVar]) {
            throw new Error(
                `Missing required environment variable: ${envVar}. Please check your .env file or deployment environment.`
            );
        }
    }

    // Create and return an immutable configuration object.
    // We use `as const` to enforce readonly properties.
    return {
        openaiApiKey: process.env.OPENAI_API_KEY!,
        supabaseUrl: process.env.SUPABASE_URL!,
        supabaseServiceRoleKey: process.env.SUPABASE_SERVICE_ROLE_KEY!,
        modelVersion: process.env.MODEL_VERSION || 'default-model-v1',
    } as const;
}

/**
 * Initializes the application state. This function simulates setting up
 * a database client and other resources based on the loaded config.
 *
 * @param config - The immutable service configuration.
 * @returns {AppState} The complete, immutable application state.
 */
function initializeAppState(config: ServiceConfig): AppState {
    // Simulate creating a database client.
    // In reality, this would be `createClient(config.supabaseUrl, config.supabaseServiceRoleKey)`
    const dbClient = {
        url: config.supabaseUrl,
        isConnected: true, // Simulated connection status
    } as const;

    // Return a new immutable state object combining the config and new resources.
    return {
        config, // Reuse the immutable config
        dbClient,
    } as const;
}

/**
 * Performs a headless inference task. This function receives the immutable
 * state and uses its secrets to perform an action without modifying the state.
 *
 * @param state - The immutable application state.
 * @param inputText - The text to process.
 * @returns A promise that resolves to the inference result.
 */
async function runInference(
    state: AppState,
    inputText: string
): Promise<string> {
    // Extract secrets from the immutable state.
    const { openaiApiKey } = state.config;

    // In a real scenario, this would be an API call to OpenAI.
    // We simulate it here to keep the example self-contained.
    console.log(`Processing text: "${inputText}"`);
    console.log(`Using API Key (masked): ${openaiApiKey.substring(0, 8)}...`);

    // Simulate an async API call.
    await new Promise((resolve) => setTimeout(resolve, 100));

    // Simulate a response.
    const embedding = `vector_for_${inputText}`;
    return embedding;
}

/**
 * Main entry point for the service.
 * This demonstrates the full lifecycle: loading config, initializing state,
 * and running a secure inference task.
 */
async function main() {
    try {
        // Step 1: Load and validate configuration. This is a critical security step.
        // If secrets are missing, the app fails fast.
        const config = loadConfig();
        console.log('Configuration loaded successfully.');

        // Step 2: Initialize the immutable application state.
        const appState = initializeAppState(config);
        console.log('Application state initialized.');

        // Step 3: Run the core business logic (headless inference).
        const result = await runInference(appState, 'Hello World from a secure service!');
        console.log('Inference result:', result);

        // Step 4: Demonstrate immutability by attempting (and failing) to modify state.
        // The following line would cause a TypeScript compilation error:
        // appState.config.openaiApiKey = 'new-key'; // Error: Cannot assign to 'openaiApiKey' because it is a read-only property.
        // This is the power of immutable state management in TypeScript.

    } catch (error) {
        console.error('Service failed to start:', error);
        process.exit(1); // Exit with a non-zero code to signal failure to orchestration systems.
    }
}

// Execute the main function if this file is run directly.
if (require.main === module) {
    main();
}

// Export for potential testing or module usage.
export { loadConfig, initializeAppState, runInference };
