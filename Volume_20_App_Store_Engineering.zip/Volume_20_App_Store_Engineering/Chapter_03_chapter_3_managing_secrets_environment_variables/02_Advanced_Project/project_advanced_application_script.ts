/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

/**
 * FILE: app/api/ai-context/route.ts
 * 
 * Overview:
 * This API route acts as a secure proxy between the client and external AI services 
 * (for embeddings) and the internal Supabase database (for vector search).
 * 
 * Security Features:
 * 1. Uses 'server-only' to ensure this code never executes on the client.
 * 2. Accesses secrets via process.env, validated at runtime.
 * 3. Performs vector search logic server-side, returning only sanitized results.
 * 
 * Runtime: Edge Runtime for low latency and global distribution.
 */

import { NextResponse } from 'next/server';
import { createClient } from '@supabase/supabase-js';
import { serverOnly } from 'server-only';

// ---------------------------------------------------------------------------
// 1. SECURE ENVIRONMENT VARIABLE MANAGEMENT
// ---------------------------------------------------------------------------

// CRITICAL: Importing 'server-only' guarantees that if this module is ever 
// imported by a client component, the build will fail. This prevents 
// accidental exposure of secrets.
import 'server-only';

// We define an interface for our environment variables to ensure type safety 
// and to make it clear exactly what secrets are required for this feature.
interface ServerEnv {
  SUPABASE_URL: string;
  SUPABASE_SERVICE_ROLE_KEY: string; // Use Service Role key for internal trusted operations
  OPENAI_API_KEY: string;
}

// We cast process.env to our interface. In a production app, you might use 
// a validation library like Zod here to throw errors if variables are missing.
const env = process.env as unknown as ServerEnv;

// ---------------------------------------------------------------------------
// 2. SERVER-SIDE LOGIC (EDGE RUNTIME)
// ---------------------------------------------------------------------------

// Configure this route to run on the Edge Runtime.
export const runtime = 'edge';

/**
 * POST /api/ai-context
 * 
 * Request Body: { query: string }
 * 
 * Logic:
 * 1. Receives a user query.
 * 2. Generates an embedding vector for the query using OpenAI.
 * 3. Connects to Supabase (PostgreSQL + pgvector).
 * 4. Performs a similarity search (Cosine Distance) against the 'docs_embeddings' table.
 * 5. Streams the results back to the client.
 */
export async function POST(req: Request) {
  try {
    // Parse the incoming request
    const { query } = await req.json();

    if (!query) {
      return new NextResponse('Query is required', { status: 400 });
    }

    // --- Step A: Generate Embeddings (Server-Side Only) ---
    // We call OpenAI securely. The API key is never sent to the browser.
    const embeddingResponse = await fetch('https://api.openai.com/v1/embeddings', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${env.OPENAI_API_KEY}`, // Securely accessed secret
      },
      body: JSON.stringify({
        model: 'text-embedding-ada-002',
        input: query,
      }),
    });

    if (!embeddingResponse.ok) {
      throw new Error('Failed to generate embedding');
    }

    const embeddingData = await embeddingResponse.json();
    const embeddingVector = embeddingData.data[0].embedding;

    // --- Step B: Initialize Secure Supabase Client ---
    // We use the Service Role Key (K). This bypasses Row Level Security (RLS)
    // because this is a trusted internal operation, but it must be kept secret.
    const supabase = createClient(env.SUPABASE_URL, env.SUPABASE_SERVICE_ROLE_KEY);

    // --- Step C: Vector Search with pgvector ---
    // We use a Remote Function (RPC) to perform the cosine distance calculation.
    // This keeps the SQL logic encapsulated and secure.
    // Note: We limit results to 3 for this example.
    const { data: matches, error } = await supabase.rpc('match_docs', {
      query_embedding: embeddingVector,
      match_threshold: 0.75, // Cosine similarity threshold
      match_count: 3,
    });

    if (error) {
      console.error('Database Error:', error);
      return new NextResponse('Database search failed', { status: 500 });
    }

    // --- Step D: Return Sanitized Data ---
    // We only return the content and similarity score. We do NOT return 
    // raw database IDs or internal metadata unless necessary.
    return NextResponse.json({ 
      success: true, 
      context: matches 
    });

  } catch (error: any) {
    // Log detailed error server-side, but return generic error to client
    console.error('API Route Error:', error);
    return new NextResponse('Internal Server Error', { status: 500 });
  }
}

// ---------------------------------------------------------------------------
// 3. CLIENT-SIDE CONSUMPTION (Conceptual Example)
// ---------------------------------------------------------------------------

/**
 * This is a conceptual React Component (Client Component) showing how 
 * to consume the API securely using Suspense for UI management.
 * 
 * "The Advanced Application Script" often involves coordinating these two layers.
 */

/*
'use client';

import { useSuspenseQuery } from '@tanstack/react-query';
import { Suspense } from 'react';

function AiResult({ query }: { query: string }) {
  // This fetch happens in the background. The parent Suspense boundary 
  // handles the loading state (Suspense Boundaries concept).
  const { data } = useSuspenseQuery({
    queryKey: ['ai-context', query],
    queryFn: async () => {
      const res = await fetch('/api/ai-context', {
        method: 'POST',
        body: JSON.stringify({ query }),
      });
      return res.json();
    },
  });

  return <div>{JSON.stringify(data.context)}</div>;
}

export default function SearchWrapper({ query }: { query: string }) {
  return (
    // Suspense Boundary handles the "loading" state while the Edge Function 
    // processes the AI request.
    <Suspense fallback={<div>Generating context...</div>}>
      <AiResult query={query} />
    </Suspense>
  );
}
*/
