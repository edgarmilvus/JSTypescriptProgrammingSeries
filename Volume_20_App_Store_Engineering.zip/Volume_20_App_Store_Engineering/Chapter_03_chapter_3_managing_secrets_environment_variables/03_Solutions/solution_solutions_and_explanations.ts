/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

import { z } from 'zod';

// 1. Define the Zod schema with defaults and transformations
const EnvSchema = z.object({
  EXPO_PUBLIC_API_URL: z.string().url("Must be a valid URL"),
  EXPO_PUBLIC_API_KEY: z.string().min(32, "String must contain at least 32 character(s)"),
  EXPO_PUBLIC_FEATURE_FLAG_AI: z.preprocess(
    (val) => (val === 'true' ? true : val === 'false' ? false : val),
    z.boolean().default(false)
  ),
  EXPO_PUBLIC_MAX_RETRIES: z.preprocess(
    (val) => (typeof val === 'string' ? parseInt(val, 10) : val),
    z.number().int().positive().default(3)
  ),
});

// 2. Infer the TypeScript type for export
export type Env = z.infer<typeof EnvSchema>;

// 3. Create the loading function
export function loadEnv(): Env {
  // Parse process.env against the schema
  const result = EnvSchema.safeParse(process.env);

  if (!result.success) {
    // Format errors for detailed reporting
    const formattedErrors = result.error.format();
    const errorMessages = Object.keys(formattedErrors).reduce((acc, key) => {
      if (key === "_errors") return acc;
      const fieldError = formattedErrors[key as keyof typeof formattedErrors];
      if (fieldError && typeof fieldError === 'object' && '_errors' in fieldError) {
        acc.push(`${key}: ${fieldError._errors.join(', ')}`);
      }
      return acc;
    }, [] as string[]);

    throw new Error(
      `Invalid environment configuration:\n${errorMessages.join('\n')}`
    );
  }

  // Return the validated data (defaults are applied here)
  return result.data;
}

// 4. Export the validated environment object
// Note: In a real app, you might export this immediately as a singleton
// to avoid parsing on every import.
export const env = loadEnv();
