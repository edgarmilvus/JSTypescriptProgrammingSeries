/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

// 1. Define the interface
interface AIModelConfig {
  model: string;
  parameters: {
    temperature: number;
    topP: number;
    maxTokens: number;
  };
  features: string[];
}

// 2. Create the Store class
class AIConfigStore {
  private state: AIModelConfig;

  constructor(initialConfig: AIModelConfig) {
    this.state = initialConfig;
  }

  // Getter to access current state
  get config(): AIModelConfig {
    return this.state;
  }

  // 3. Update methods returning new instances
  updateTemperature(newTemp: number): AIConfigStore {
    // Deep copy pattern: Spread top level, then nested objects
    const newState: AIModelConfig = {
      ...this.state,
      parameters: {
        ...this.state.parameters,
        temperature: newTemp,
      },
    };
    // Return a NEW store instance with the new state
    return new AIConfigStore(newState);
  }

  addFeature(feature: string): AIConfigStore {
    // Prevent duplicates
    if (this.state.features.includes(feature)) {
      return this; // Return current instance if no change needed
    }

    const newState: AIModelConfig = {
      ...this.state,
      features: [...this.state.features, feature], // New array reference
    };
    return new AIConfigStore(newState);
  }

  removeFeature(feature: string): AIConfigStore {
    const newState: AIModelConfig = {
      ...this.state,
      features: this.state.features.filter((f) => f !== feature), // New array reference
    };
    return new AIConfigStore(newState);
  }
}

// Example Usage
const initialConfig: AIModelConfig = {
  model: "gpt-4-turbo",
  parameters: { temperature: 0.7, topP: 1, maxTokens: 1024 },
  features: ["streaming"],
};

const storeV1 = new AIConfigStore(initialConfig);
const storeV2 = storeV1.updateTemperature(0.5);
const storeV3 = storeV2.addFeature("json-mode");

console.log(storeV1.config.parameters.temperature); // 0.7 (Unchanged)
console.log(storeV2.config.parameters.temperature); // 0.5 (New state)
console.log(storeV3.config.features); // ["streaming", "json-mode"]
