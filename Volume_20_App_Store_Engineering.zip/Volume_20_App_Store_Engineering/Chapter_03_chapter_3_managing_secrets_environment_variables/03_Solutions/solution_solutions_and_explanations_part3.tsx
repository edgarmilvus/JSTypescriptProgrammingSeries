/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.tsx
// Description: Solutions and Explanations
// ==========================================

import React, { useState } from 'react';

// 1. Define the strict Discriminated Union type
type UIState = 
  | { status: 'loading' }
  | { status: 'streaming'; text: string }
  | { status: 'finished'; summary: string; confidence: number };

// Mock Components (for context)
const SkeletonLoader = () => <div className="skeleton">Loading...</div>;
const StreamingText = ({ text }: { text: string }) => <div className="stream">{text}</div>;
const SummaryCard = ({ summary, confidence }: { summary: string; confidence: number }) => (
  <div className="card">
    <h3>Analysis</h3>
    <p>{summary}</p>
    <small>Confidence: {confidence}%</small>
  </div>
);

// 2. The AIDashboard Component
export function AIDashboard() {
  // Mocking useUIState with useState for the exercise
  const [uiState, setUiState] = useState<UIState>({ status: 'loading' });

  // Simulate "Regenerate" action handling
  const handleRegenerate = () => {
    // IMMEDIATE transition to loading to clear stale data
    setUiState({ status: 'loading' });
    
    // Simulate async fetch
    setTimeout(() => {
      setUiState({ status: 'streaming', text: 'Regenerating analysis...' });
    }, 500);
  };

  // 3. Conditional Rendering Logic
  const renderContent = () => {
    switch (uiState.status) {
      case 'loading':
        return <SkeletonLoader />;
      
      case 'streaming':
        // Ensure we don't show stale finished data if streaming restarts
        return (
          <>
            <StreamingText text={uiState.text} />
            <button onClick={handleRegenerate}>Regenerate</button>
          </>
        );
      
      case 'finished':
        return (
          <>
            <SummaryCard summary={uiState.summary} confidence={uiState.confidence} />
            <button onClick={handleRegenerate}>Regenerate</button>
          </>
        );
      
      default:
        // Fallback for unexpected states
        return <div>Initializing...</div>;
    }
  };

  return (
    <div className="dashboard-container">
      <h2>Smart Dashboard</h2>
      {renderContent()}
    </div>
  );
}
