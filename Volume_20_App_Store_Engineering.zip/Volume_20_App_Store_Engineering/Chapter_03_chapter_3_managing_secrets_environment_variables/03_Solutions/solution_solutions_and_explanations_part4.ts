/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

import { z } from 'zod';

// 1. Define the Zod schema
const OTAUpdateSchema = z.object({
  version: z.string().regex(/^\d+\.\d+\.\d+$/, "Must be a valid semantic version (x.x.x)"),
  bundleUrl: z.string().url(),
  changelog: z.string(),
  signature: z.string().regex(/^[a-f0-9]{64}$/i, "Must be a valid 64-character hex string (SHA-256)"),
});

type OTAUpdate = z.infer<typeof OTAUpdateSchema>;

// Mock "Admin Key" for the simulation
const ADMIN_SIGNATURE_KEY = "a".repeat(64); // A valid hex string

// 2. Validation function with simulated security check
export function validateOTAPayload(payload: unknown): OTAUpdate {
  // First, validate the structure and basic types
  const parsed = OTAUpdateSchema.parse(payload);

  // 3. Simulate Security Constraint: Major version signature check
  const currentMajor = parseInt(parsed.version.split('.')[0], 10);
  
  // Assume we have a "previous version" stored or known. 
  // For this exercise, we simulate that any jump to Major version 2 or higher requires admin verification.
  if (currentMajor >= 2) {
    // Simulate checking against a hardcoded admin key
    // In a real scenario, this would involve cryptographic verification (e.g., ECDSA)
    if (parsed.signature !== ADMIN_SIGNATURE_KEY) {
      throw new Error(`Security Violation: Signature mismatch for major version update.`);
    }
  }

  return parsed;
}

// 4. Interactive Challenge: Process function with Result Union Type
type Result<T> = { success: true; data: T } | { success: false; errors: string[] };

export function processOTAUpdate(payload: unknown): Result<OTAUpdate> {
  try {
    const data = validateOTAPayload(payload);
    return { success: true, data };
  } catch (error) {
    if (error instanceof z.ZodError) {
      // Extract Zod validation errors
      const errorMessages = error.errors.map((err) => `${err.path.join('.')}: ${err.message}`);
      return { success: false, errors: errorMessages };
    }
    if (error instanceof Error) {
      // Handle the custom security error
      return { success: false, errors: [error.message] };
    }
    // Handle unknown errors
    return { success: false, errors: ["An unknown error occurred"] };
  }
}

// --- Demonstration of the Interactive Challenge ---

// Scenario: Major version bump (2.0.0) with invalid signature
const maliciousPayload = {
  version: "2.0.0",
  bundleUrl: "https://malicious.com/bundle.js",
  changelog: "Critical update",
  signature: "invalid_hash" // Does not match ADMIN_SIGNATURE_KEY
};

const result = processOTAUpdate(maliciousPayload);

if (!result.success) {
  console.log("Update Rejected:");
  console.log(result.errors); 
  // Output: ["Security Violation: Signature mismatch for major version update."]
} else {
  console.log("Update Accepted");
}
