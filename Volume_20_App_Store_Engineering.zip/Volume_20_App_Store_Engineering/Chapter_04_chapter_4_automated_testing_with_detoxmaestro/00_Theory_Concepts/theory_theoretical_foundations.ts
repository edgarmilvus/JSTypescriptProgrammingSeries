/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: theory_theoretical_foundations.ts
// Description: Theoretical Foundations
// ==========================================

// A generic interface representing a UI element selector.
// <T> represents the type of data the element is expected to hold (e.g., string, number, boolean).
interface Matcher<T> {
  // The ID of the element in the UI tree.
  id: string;
  
  // A function that validates the content of the element.
  // It takes a value of type T and returns a boolean.
  validator: (value: T) => boolean;
}

// A generic function to assert the state of an element.
// This ensures that if we expect a string, we don't accidentally validate it as a number.
function assertElementState<T>(matcher: Matcher<T>, actualValue: T): void {
  if (matcher.validator(actualValue)) {
    console.log(`Validation passed for element ${matcher.id}`);
  } else {
    throw new Error(`Validation failed for element ${matcher.id}`);
  }
}

// Usage: Defining a matcher for a numeric price.
const priceMatcher: Matcher<number> = {
  id: 'product-price',
  validator: (price) => price > 0 // Ensures price is positive
};

// Usage: Defining a matcher for a text status.
const statusMatcher: Matcher<string> = {
  id: 'order-status',
  validator: (status) => status === 'Shipped' // Ensures status is exactly 'Shipped'
};

// assertElementState(priceMatcher, 19.99); // Valid
// assertElementState(statusMatcher, 'Shipped'); // Valid
// assertElementState(priceMatcher, 'Shipped'); // TypeScript Error: Argument of type 'string' is not assignable to parameter of type 'number'.
