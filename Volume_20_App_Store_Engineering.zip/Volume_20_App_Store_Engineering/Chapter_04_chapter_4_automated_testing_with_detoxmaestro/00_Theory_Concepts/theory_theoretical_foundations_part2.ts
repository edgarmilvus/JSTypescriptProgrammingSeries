/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: theory_theoretical_foundations_part2.ts
// Description: Theoretical Foundations
// ==========================================

// Define distinct interfaces for different event types.
interface NavigationEvent {
  type: 'navigation';
  screenName: string;
  params: Record<string, unknown>;
}

interface NetworkEvent {
  type: 'network';
  url: string;
  statusCode: number;
}

// A union type representing any event the app might emit.
type AppEvent = NavigationEvent | NetworkEvent;

// User-Defined Type Guard.
// The return type `event is NavigationEvent` is the magic syntax.
// It tells TypeScript: "If this function returns true, treat 'event' as a NavigationEvent inside this scope."
function isNavigationEvent(event: AppEvent): event is NavigationEvent {
  return event.type === 'navigation';
}

// Theoretical Test Logic
function analyzeAppLogs(event: AppEvent) {
  // Initially, TypeScript only knows that 'event' has a 'type' property.
  // console.log(event.screenName); // Error: Property 'screenName' does not exist on type 'AppEvent'.

  if (isNavigationEvent(event)) {
    // Inside this block, TypeScript has narrowed the type.
    // It now allows access to NavigationEvent specific properties.
    console.log(`Navigated to: ${event.screenName}`);
    
    // We can now perform specific assertions based on the narrowed type.
    if (event.params.userId) {
      console.log(`User ID detected: ${event.params.userId}`);
    }
  } else {
    // TypeScript knows 'event' must be NetworkEvent here.
    console.log(`Network call to ${event.url} finished with status ${event.statusCode}`);
  }
}
