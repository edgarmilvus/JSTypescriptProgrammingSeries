/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: basic_basic_code_example_part2.ts
// Description: Basic Code Example
// ==========================================

/**
 * @file runTests.ts
 * @description Orchestrates Maestro E2E tests for a SaaS application.
 * This script runs the 'login_flow.yaml' test against a local simulator.
 * It demonstrates how to wrap Maestro commands in a Node.js process for CI integration.
 */

import { exec } from 'child_process';
import { promisify } from 'util';
import * as path from 'path';

// Promisify exec to use async/await syntax
const execAsync = promisify(exec);

/**
 * Configuration for the test runner.
 * In a real SaaS environment, these would be injected via environment variables.
 */
const TEST_CONFIG = {
  flowPath: path.resolve(__dirname, '../flows/login_flow.yaml'),
  deviceId: 'emulator-5554', // Android Emulator ID (or Simulator UUID for iOS)
  platform: 'android', // 'android' or 'ios'
};

/**
 * Executes a Maestro test flow.
 * 
 * @param flowPath - Absolute path to the .yaml test file.
 * @param deviceId - The target device emulator/simulator ID.
 * @returns Promise<void> - Resolves when the test command finishes.
 */
async function runMaestroTest(flowPath: string, deviceId: string): Promise<void> {
  console.log(`🚀 Starting Maestro test on device: ${deviceId}`);
  console.log(`📄 Test Flow: ${flowPath}`);

  // Construct the Maestro CLI command.
  // 'maestro test' runs the flow. We pass the deviceId to target a specific simulator.
  const command = `maestro test ${flowPath} --device ${deviceId}`;

  try {
    // Execute the command asynchronously
    const { stdout, stderr } = await execAsync(command);

    // Log standard output (test results)
    console.log("📊 Test Output:\n", stdout);

    // Check for stderr (errors)
    if (stderr) {
      console.warn("⚠️  Standard Error Output:\n", stderr);
    }

    console.log("✅ Test execution completed successfully.");
  } catch (error: any) {
    // Handle execution errors (e.g., test failure, Maestro not installed)
    console.error("❌ Test Execution Failed:");
    console.error("Command Error:", error.message);
    console.error("Stderr:", error.stderr);
    console.error("Stdout:", error.stdout);
    
    // Throw error to stop CI pipeline
    throw new Error("E2E Test Suite Failed");
  }
}

/**
 * Main entry point.
 * In a CI environment (like EAS Build), this script would be invoked via package.json.
 */
(async () => {
  try {
    await runMaestroTest(TEST_CONFIG.flowPath, TEST_CONFIG.deviceId);
  } catch (error) {
    console.error("Critical failure in test runner:", error);
    process.exit(1); // Exit with failure code for CI
  }
})();
