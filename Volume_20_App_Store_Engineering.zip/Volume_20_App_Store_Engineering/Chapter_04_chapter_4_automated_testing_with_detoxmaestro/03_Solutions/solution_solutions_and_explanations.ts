/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// 1. detox.config.js
// This file configures Detox for both standard and debug testing scenarios.
const { execSync } = require('child_process');

// Helper to determine if we are in debug mode
const isDebug = process.env.DEBUG === 'true';

// Define the build command based on the environment variable
const buildCommand = isDebug
  ? 'eas build --profile development-debug --platform ios --output=build/TaskFlow.app'
  : 'eas build --profile development --platform ios --output=build/TaskFlow.app';

module.exports = {
  apps: {
    'ios.debug': {
      type: 'ios.app',
      binaryPath: 'build/TaskFlow.app',
      build: buildCommand,
    },
    'ios.release': {
      type: 'ios.app',
      binaryPath: 'build/TaskFlow.app',
      build: buildCommand,
    },
  },
  devices: {
    simulator: {
      type: 'ios.simulator',
      device: {
        type: 'iPhone 14',
      },
    },
  },
  configurations: {
    'ios.sim.debug': {
      device: 'simulator',
      app: 'ios.debug',
    },
    'ios.sim.release': {
      device: 'simulator',
      app: 'ios.release',
    },
  },
};

// 2. eas.json (Snippet for the development-debug profile)
/*
{
  "build": {
    "development": {
      "developmentClient": true,
      "distribution": "internal",
      "ios": {
        "simulator": true
      }
    },
    "development-debug": {
      "extends": "development",
      "env": {
        "EXPO_DEBUG": "true"
      },
      "ios": {
        "buildConfiguration": "Debug",
        "simulator": true
      }
    }
  }
}
*/

// 3. App.e2e.js
// A basic test script to verify the app launches and shows the header.
import { device, expect, by } from 'detox';

describe('TaskFlow App Launch', () => {
  beforeAll(async () => {
    // Launch the app before running tests
    await device.launchApp();
  });

  it('should show the app header', async () => {
    // Assert that an element with the text 'TaskFlow' is visible.
    // Assuming the main header has accessibilityLabel or text 'TaskFlow'
    await expect(element(by.text('TaskFlow'))).toBeVisible();
  });
});
