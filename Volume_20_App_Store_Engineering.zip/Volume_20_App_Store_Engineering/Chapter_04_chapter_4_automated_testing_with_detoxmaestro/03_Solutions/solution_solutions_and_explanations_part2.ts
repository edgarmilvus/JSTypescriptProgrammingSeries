/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part2.ts
// Description: Solutions and Explanations
// ==========================================

// TaskFlow.e2e.ts
import { device, expect, by, element, waitFor } from 'detox';

describe('TaskFlow User Flows', () => {
  beforeEach(async () => {
    // Relaunch the app for a clean state before each test
    await device.launchApp({ newInstance: true });
  });

  it('should create and complete a new task', async () => {
    // 1. Handle Asynchronous Data Loading (2s latency)
    // Wait for the main task list header to appear before proceeding.
    // This prevents interacting with elements that aren't on screen yet.
    await waitFor(element(by.text('My Tasks'))).toBeVisible().withTimeout(5000);

    // 2. Tap the 'Add Task' button
    // Assuming the button has a testID for reliable selection
    await element(by.id('add-task-button')).tap();

    // 3. Interact with the input and submit
    // Type a task title into the input field
    await element(by.id('task-title-input')).typeText('Buy groceries');
    
    // Verify the 'Save' button is enabled (not disabled)
    await expect(element(by.id('save-task-button'))).toBeEnabled();
    
    // Tap the save button
    await element(by.id('save-task-button')).tap();

    // 4. Verify the task appears in the list
    // We use waitFor to handle the UI update delay after saving
    const newTaskElement = element(by.text('Buy groceries'));
    await waitFor(newTaskElement).toBeVisible().withTimeout(3000);
    await expect(newTaskElement).toBeVisible();

    // 5. Mark the task as complete
    // Tap the task item itself (or a specific checkbox)
    await newTaskElement.tap();

    // 6. Verify the completion state
    // Check for a specific testID that indicates completion (e.g., a checkmark icon)
    // This is more reliable than checking for style changes.
    await expect(element(by.id('task-complete-icon'))).toBeVisible();
  });

  it('should prevent saving an empty task', async () => {
    // Navigate to the add task screen
    await waitFor(element(by.id('add-task-button'))).toBeVisible().withTimeout(5000);
    await element(by.id('add-task-button')).tap();

    // Verify the save button is initially disabled (or hidden)
    await expect(element(by.id('save-task-button'))).toBeDisabled();
    
    // Type a space (often treated as empty in some validations)
    await element(by.id('task-title-input')).typeText(' ');
    
    // If validation runs on change, the button might still be disabled.
    // If validation runs on submit, we'd try to tap it.
    // The requirement is to verify it is disabled when input is empty.
    // Assuming the app handles spaces as empty:
    await expect(element(by.id('save-task-button'))).toBeDisabled();
  });
});
