/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part3.ts
// Description: Solutions and Explanations
// ==========================================

// 1. eas.json (Snippet for the e2e-test profile)
/*
{
  "build": {
    "e2e-test": {
      "developmentClient": true,
      "distribution": "internal",
      "ios": {
        "simulator": true,
        "buildConfiguration": "Release"
      },
      "env": {
        "E2E_BUILD": "true"
      }
    }
  }
}
*/

// 2. package.json (Scripts)
/*
{
  "scripts": {
    "e2e:build": "eas build --profile e2e-test --platform ios --output=build/TaskFlow.app --non-interactive",
    "e2e:smoke": "detox test --configuration ios.sim.release --testNamePattern='Smoke'",
    "e2e:full": "detox test --configuration ios.sim.release",
    "e2e:ci": "npm run e2e:build && npm run e2e:smoke"
  }
}
*/

// 3. Example Test Files
// e2e/smoke/TaskFlow.smoke.e2e.ts
/*
import { device, expect, by, element } from 'detox';

describe('Smoke: Core Flow', () => {
  it('should launch and show header', async () => {
    await device.launchApp();
    await expect(element(by.text('TaskFlow'))).toBeVisible();
  });
});
*/

// e2e/full/TaskFlow.full.e2e.ts
/*
import { device, expect, by, element, waitFor } from 'detox';

describe('Full: Extended Features', () => {
  // ... comprehensive tests from Exercise 2
  it('Smoke: should launch and show header', async () => {
    await device.launchApp();
    await expect(element(by.text('TaskFlow'))).toBeVisible();
  });
  
  it('Full: should create, complete, and delete a task', async () => {
    // ... complex user flow test
  });
});
*/

// 4. .github/workflows/e2e.yml
/*
name: E2E Tests (Smoke)

on:
  pull_request:
    branches: [ main ]

jobs:
  test-ios-smoke:
    runs-on: macos-latest
    steps:
      - uses: actions/checkout@v3
      
      - name: Setup Node.js
        uses: actions/setup-node@v3
        with:
          node-version: '18'
          cache: 'npm'
      
      - name: Install Dependencies
        run: npm install
        
      - name: Install Detox CLI
        run: npm install -g detox-cli
        
      - name: Run E2E Smoke Tests
        run: |
          # Set up the environment for EAS
          npm install -g eas-cli
          # Run the build and test script
          npm run e2e:ci
          
      - name: Upload Test Report on Failure
        if: failure()
        uses: actions/upload-artifact@v3
        with:
          name: detox-report
          path: ./e2e/artifacts/
          
  # Nightly Full Test Job
  test-ios-full-nightly:
    runs-on: macos-latest
    # Schedule this job to run at midnight UTC
    schedule:
      - cron: '0 0 * * *'
    steps:
      - uses: actions/checkout@v3
      - name: Setup Node.js
        uses: actions/setup-node@v3
        with:
          node-version: '18'
      - name: Install Dependencies
        run: npm install
      - name: Install Detox CLI
        run: npm install -g detox-cli
      - name: Run Full E2E Suite
        run: |
          npm install -g eas-cli
          npm run e2e:build
          npm run e2e:full
*/
