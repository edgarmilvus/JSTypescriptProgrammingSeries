/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations_part4.ts
// Description: Solutions and Explanations
// ==========================================

// 1. detox.config.js (Parallel Execution Configuration)
/*
module.exports = {
  // ... existing config
  runnerConfig: 'e2e/config.json',
  // Enable parallel execution by specifying workers
  // This runs tests across multiple simulators if available
  cli: {
    'cleanup-workers': 2, 
  },
  devices: {
    'ios.simulator': {
      type: 'ios.simulator',
      device: {
        type: 'iPhone 14',
      },
    },
  },
  configurations: {
    'ios.sim.release': {
      device: 'ios.simulator',
      app: 'ios.release',
      // Run tests in parallel
      workers: 2, 
    },
  },
};
*/

// 2. e2e/config.json (Jest Configuration for Detox)
/*
{
  "preset": "ts-jest",
  "testEnvironment": "./node_modules/detox/runners/jest/testEnvironment",
  "globalSetup": "./node_modules/detox/runners/jest/globalSetup",
  "globalTeardown": "./node_modules/detox/runners/jest/globalTeardown",
  "setupFilesAfterEnv": ["./e2e/setup.ts"],
  "testMatch": ["**/*.e2e.ts"],
  "reporters": [
    "detox/runners/jest/reporter",
    ["./e2e/custom-json-reporter.ts", { outputName: "detox-results.json" }]
  ],
  "verbose": true
}
*/

// 3. e2e/setup.ts (Optimized Test Setup)
/*
import { device } from 'detox';

// Reset state instead of relaunching app for every test
beforeEach(async () => {
  // Use resetContentAndSettings to clear app data without full relaunch
  // This is faster than device.launchApp({ newInstance: true })
  await device.resetContentAndSettings();
  await device.launchApp();
});

// If resetContentAndSettings is too slow or not available, 
// use a manual "Clear All" button in the app UI:
/*
beforeEach(async () => {
  await device.launchApp({ newInstance: false });
  // Tap a settings icon -> Clear Data button
  await element(by.id('settings-icon')).tap();
  await element(by.id('clear-data-button')).tap();
});
*/
// */

// 4. e2e/custom-json-reporter.ts (Custom Reporter)
/*
import { Reporter, SpecReporter, SpecContext } from 'jest-reporters';

// A simple custom reporter to log test results to a JSON file
// Note: In a real scenario, you might extend Detox's base reporter class
const fs = require('fs');

class CustomJsonReporter {
  constructor(globalConfig, options) {
    this.globalConfig = globalConfig;
    this.options = options;
    this.results = [];
  }

  onTestResult(test, testResult, aggregatedResults) {
    const { testResults, numFailingTests, numPassingTests } = testResult;
    
    testResults.forEach((result) => {
      this.results.push({
        name: result.fullName,
        status: result.status, // 'passed' or 'failed'
        error: result.failureMessages.join('\n'),
        duration: result.duration,
        timestamp: new Date().toISOString(),
      });
    });
  }

  onRunComplete(contexts, results) {
    const output = {
      testRun: new Date().toISOString(),
      summary: {
        total: results.numTotalTests,
        passed: results.numPassedTests,
        failed: results.numFailedTests,
      },
      tests: this.results,
    };
    
    const outputName = this.options.outputName || 'detox-results.json';
    fs.writeFileSync(outputName, JSON.stringify(output, null, 2));
  }
}

module.exports = CustomJsonReporter;
*/

// 5. scripts/analyze-logs.js (Log Analysis Script)
/*
const fs = require('fs');

const rawData = fs.readFileSync('detox-results.json');
const data = JSON.parse(rawData);

const failures = data.tests.filter(t => t.status === 'failed');
const errorCounts = {};

// Aggregate errors
failures.forEach(f => {
  // Normalize error message (remove line numbers, file paths)
  const normalizedError = f.error
    .replace(/at .*\.js:\d+:\d+/g, '')
    .replace(/\s+/g, ' ')
    .trim();
    
  if (!errorCounts[normalizedError]) {
    errorCounts[normalizedError] = { count: 0, examples: [] };
  }
  errorCounts[normalizedError].count++;
  if (errorCounts[normalizedError].examples.length < 3) {
    errorCounts[normalizedError].examples.push(f.name);
  }
});

// Sort and get top 3
const topErrors = Object.entries(errorCounts)
  .sort((a, b) => b[1].count - a[1].count)
  .slice(0, 3);

// Generate AI Prompt
const aiPrompt = `
Analyze the following test failure data from a Detox E2E test run.

**Test Run Summary:**
Total Tests: ${data.summary.total}
Passed: ${data.summary.passed}
Failed: ${data.summary.failed}

**Top 3 Failure Reasons:**
${topErrors.map(([error, info], index) => 
  `${index + 1}. **Error:** "${error}"\n   - Occurrences: ${info.count}\n   - Failing Tests: ${info.examples.join(', ')}`
).join('\n')}

**Instructions for AI:**
1. Identify the root cause for each of the top 3 errors.
2. Suggest specific code changes (e.g., use 'waitFor', add 'testID', adjust timeout).
3. Correlate failures with specific test steps if possible.
`;

console.log(aiPrompt);
// Optionally write to a file: fs.writeFileSync('ai-prompt.txt', aiPrompt);
*/
