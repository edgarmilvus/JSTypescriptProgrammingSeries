/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: project_advanced_application_script.ts
// Description: Advanced Application Script
// ==========================================

// pages/api/submit-build.ts
// Target: Next.js API Route using Edge Runtime
// Objective: Orchestrate EAS Build, TestFlight Submission, and Internal Notification.

import { NextRequest, NextResponse } from 'next/server';

// -----------------------------------------------------------------------------
// 1. Configuration & Types
// -----------------------------------------------------------------------------
// We define strict types for the incoming payload to ensure data integrity.
// This aligns with the "Compliance Questionnaires" concept by validating inputs early.

interface BuildSubmissionPayload {
  projectId: string;
  platform: 'ios' | 'android';
  gitCommitHash: string;
  distributionGroup: 'internal' | 'public-link';
  releaseNotes: string;
}

// Mock type representing the response from an EAS Build/Submit command.
interface EASCommandResponse {
  success: boolean;
  buildId?: string;
  submissionId?: string;
  error?: string;
  artifacts?: {
    buildUrl: string;
    ipaUrl: string;
  };
}

// -----------------------------------------------------------------------------
// 2. Edge Runtime Configuration
// -----------------------------------------------------------------------------
// We export the runtime configuration to utilize the Edge Runtime.
// Why? Edge Runtime offers low-latency execution, ideal for handling webhook 
// requests and lightweight orchestration logic without the cold-start penalty 
// of serverless functions. It acts as the "middleware" for our CI/CD pipeline.

export const config = {
  runtime: 'edge',
};

// -----------------------------------------------------------------------------
// 3. The Core Logic: Orchestrator Function
// -----------------------------------------------------------------------------

/**
 * Main handler for the build submission process.
 * 
 * @param req - The incoming NextRequest object.
 * @returns A NextResponse object containing the optimistic update payload or error details.
 * 
 * Under the Hood:
 * 1. Validates the incoming payload.
 * 2. Triggers an "Optimistic UI Update" by immediately returning a processing state.
 * 3. Offloads the heavy lifting (EAS CLI execution) to a background worker (simulated here).
 * 4. Handles the result and updates the database (simulated).
 */
export default async function handler(req: NextRequest) {
  if (req.method !== 'POST') {
    return new NextResponse(JSON.stringify({ error: 'Method not allowed' }), { status: 405 });
  }

  try {
    // Parse and validate payload
    const payload: BuildSubmissionPayload = await req.json();
    const validationError = validatePayload(payload);
    if (validationError) {
      return new NextResponse(JSON.stringify({ error: validationError }), { status: 400 });
    }

    // -------------------------------------------------------------------------
    // 4. Optimistic UI Update Strategy
    // -------------------------------------------------------------------------
    // We do not wait for the build to finish. The user needs immediate feedback
    // that the process has started. This minimizes perceived latency.
    
    const optimisticResponse = {
      status: 'processing' as const,
      message: 'Build submission initiated. OTA update pending.',
      timestamp: new Date().toISOString(),
      trackingId: `track_${Date.now()}`,
    };

    // Trigger the background process (fire and forget)
    // In a real production environment, this would be a job pushed to Redis/BullMQ.
    // Here, we simulate it via a Promise that executes after the response is sent.
    processBuildSubmission(payload).catch(console.error);

    return new NextResponse(JSON.stringify(optimisticResponse), { 
      status: 202, // 202 Accepted: The request has been accepted for processing
      headers: { 'Content-Type': 'application/json' }
    });

  } catch (error) {
    console.error('Submission error:', error);
    return new NextResponse(JSON.stringify({ error: 'Internal server error' }), { status: 500 });
  }
}

// -----------------------------------------------------------------------------
// 5. Helper Functions & Tool Use Reflection
// -----------------------------------------------------------------------------

/**
 * Validates the input payload structure.
 * Acts as a guard clause to prevent invalid data from entering the pipeline.
 */
function validatePayload(payload: BuildSubmissionPayload): string | null {
  if (!payload.projectId || !payload.gitCommitHash) return 'Missing required fields: projectId or gitCommitHash';
  if (!['ios', 'android'].includes(payload.platform)) return 'Invalid platform specified';
  return null;
}

/**
 * Simulates the execution of EAS CLI commands for building and submitting.
 * 
 * Under the Hood:
 * This function represents the "Tool Use" layer. In a real scenario, this would
 * spawn a child process running `eas build --platform ios --auto-submit`.
 * 
 * Tool Use Reflection:
 * We simulate checking the output of the build command. If the build fails (e.g., 
 * compilation error), the logic reflects on that observation and triggers a 
 * failure notification instead of a success notification.
 */
async function processBuildSubmission(payload: BuildSubmissionPayload): Promise<void> {
  console.log(`[Worker] Starting build for project: ${payload.projectId}`);
  
  // Simulate network latency for build process
  await new Promise(resolve => setTimeout(resolve, 3000));

  // Simulate EAS Build Execution
  const buildResult: EASCommandResponse = {
    success: true,
    buildId: `ios-${Math.random().toString(36).substring(7)}`,
    submissionId: `sub-${Math.random().toString(36).substring(7)}`,
    artifacts: {
      buildUrl: `https://expo.dev/artifacts/eas/${payload.projectId}.ipa`,
      ipaUrl: `https://internal-storage.example.com/${payload.projectId}.ipa`
    }
  };

  if (buildResult.success) {
    await handleSuccessfulSubmission(payload, buildResult);
  } else {
    await handleFailedSubmission(payload, buildResult.error || 'Unknown error');
  }
}

/**
 * Handles the post-build logic: Database update and Notification.
 * This is where "OTA Updates" are effectively managed by storing the artifact URL.
 */
async function handleSuccessfulSubmission(payload: BuildSubmissionPayload, result: EASCommandResponse) {
  console.log(`[Worker] Build successful. Updating OTA manifest.`);
  
  // 1. Update Database with OTA Metadata
  // In a real app, this updates a record in PostgreSQL or MongoDB.
  await mockDatabaseUpdate({
    projectId: payload.projectId,
    otaUrl: result.artifacts!.ipaUrl,
    buildVersion: result.buildId,
    distributionGroup: payload.distributionGroup,
    releaseNotes: payload.releaseNotes
  });

  // 2. Notify Testers
  // If using a public link, we might update a Slack channel.
  // If internal, we rely on TestFlight's auto-notification.
  console.log(`[Worker] Notifying ${payload.distributionGroup} group via Webhook.`);
  
  // Simulate sending a webhook to a communication tool
  await fetch('https://hooks.slack.com/services/...', {
    method: 'POST',
    body: JSON.stringify({
      text: `🚀 New TestFlight build available!\nCommit: ${payload.gitCommitHash}\nLink: ${result.artifacts!.ipaUrl}`
    })
  });
}

/**
 * Handles failure logic, reflecting on the error to determine next steps.
 */
async function handleFailedSubmission(payload: BuildSubmissionPayload, error: string) {
  console.error(`[Worker] Build failed: ${error}`);
  
  // Update status in DB to 'failed'
  await mockDatabaseUpdate({
    projectId: payload.projectId,
    status: 'failed',
    errorLog: error
  });

  // Notify developers (e.g., via email or Slack alert)
  console.log(`[Worker] Alerting developers about build failure.`);
}

// -----------------------------------------------------------------------------
// 6. Mock Database Interface
// -----------------------------------------------------------------------------

/**
 * Simulates a database call to persist build artifacts and OTA metadata.
 * In a production SaaS app, this would be an ORM call (Prisma, Drizzle, etc.).
 */
async function mockDatabaseUpdate(data: any): Promise<void> {
  // Simulate async database write
  await new Promise(resolve => setTimeout(resolve, 100));
  console.log('[DB] Record updated:', JSON.stringify(data, null, 2));
}
