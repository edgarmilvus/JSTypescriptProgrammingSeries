/*
These sources are part of the "The Interplanetary Guide to Web AI" by Edgar Milvus.
You can find the series on Amazon.
New books info: https://linktr.ee/edgarmilvus

MIT License
Copyright (c) 2026 Edgar Milvus

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/

// Source File: solution_solutions_and_explanations.ts
// Description: Solutions and Explanations
// ==========================================

// submitToTestFlight.ts
import { execSync } from 'child_process';
import * as fs from 'fs';
import * as path from 'path';

// Configuration and Environment Validation
const requiredEnvVars = ['EXPO_TOKEN', 'ASC_API_KEY', 'ASC_ISSUER_ID'];
const appJsonPath = path.join(__dirname, 'app.json');
const dryRun = process.argv.includes('--dry-run');

// Interface for App.json structure
interface ExpoConfig {
  expo: {
    ios: {
      buildNumber: string;
    };
  };
}

/**
 * Validates that all necessary environment variables are present.
 * Throws an error if any are missing.
 */
function validateEnv() {
  console.log('🔍 Validating environment variables...');
  const missing = requiredEnvVars.filter((env) => !process.env[env]);
  if (missing.length > 0) {
    throw new Error(`Missing environment variables: ${missing.join(', ')}`);
  }
  console.log('✅ Environment validated.');
}

/**
 * Increments the iOS build number in app.json.
 * @param configPath - Path to the app.json file.
 */
function incrementBuildNumber(configPath: string) {
  console.log('🔢 Incrementing build number...');
  if (dryRun) {
    console.log('[DRY RUN] Would read app.json and increment build number.');
    return;
  }

  const fileContent = fs.readFileSync(configPath, 'utf-8');
  const config: ExpoConfig = JSON.parse(fileContent);
  
  const currentBuild = parseInt(config.expo.ios.buildNumber, 10);
  const newBuild = (currentBuild + 1).toString();
  
  config.expo.ios.buildNumber = newBuild;
  
  fs.writeFileSync(configPath, JSON.stringify(config, null, 2));
  console.log(`✅ Build number incremented to ${newBuild}.`);
}

/**
 * Executes a shell command with error handling.
 * @param command - The command to execute.
 */
function executeCommand(command: string) {
  if (dryRun) {
    console.log(`[DRY RUN] Would execute: ${command}`);
    return;
  }

  try {
    console.log(`🚀 Executing: ${command}`);
    execSync(command, { stdio: 'inherit' });
  } catch (error) {
    console.error(`❌ Command failed: ${command}`);
    throw error;
  }
}

/**
 * Main execution function.
 */
async function main() {
  try {
    validateEnv();

    // 1. Increment Build Number
    incrementBuildNumber(appJsonPath);

    // 2. Run EAS Build
    // Note: In a real scenario, we might parse the output to get the artifact path.
    // For this script, we assume 'eas build' completes successfully.
    const buildCommand = 'eas build --platform ios --profile production --non-interactive';
    executeCommand(buildCommand);

    // 3. Upload to App Store Connect
    // 'eas submit' handles the upload. 
    // Note: If running sequentially in CI, we might need to wait for the build to finish processing.
    const submitCommand = 'eas submit --platform ios';
    executeCommand(submitCommand);

    // 4. Add to Internal Testing Group
    // Since 'eas submit' doesn't directly expose the Build ID via CLI easily without parsing logs,
    // we simulate the API call here. In a full CI pipeline, you would extract the Build ID 
    // from the 'eas build' JSON output.
    console.log('🧪 Adding build to Internal QA group...');
    if (!dryRun) {
        // Mock API call to App Store Connect
        // Real implementation would use 'axios' or 'node-appstore-connect-api'
        // await addBuildToInternalGroup(process.env.ASC_API_KEY, ...);
    }
    
    console.log('🎉 Process completed successfully.');

  } catch (error) {
    console.error('💥 Critical Error:', error);
    process.exit(1);
  }
}

main();
